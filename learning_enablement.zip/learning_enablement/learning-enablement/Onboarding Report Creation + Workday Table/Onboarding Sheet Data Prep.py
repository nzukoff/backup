# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ### Steps:
# MAGIC * create a cell and run %run "/Users/liam.clifford@databricks.com/Liam's Notebook - readGoogleSheet UDF"
# MAGIC * share spreadsheet with service-liam-clifford@project-liam-clifford.iam.gserviceaccount.com as editor
# MAGIC * enter the name of the spreadsheet and the sheet you want to pull data from in the try blocks
# MAGIC * add the workbook id which can be found after /d/ in the sheet url
# MAGIC * for reading from:
# MAGIC   * add the sheet id which can be found in the url after gid=
# MAGIC   * create a temp view name that can be used to query the data from a temp view 
# MAGIC   * specify the cell range you want to pull data from
# MAGIC   * select * from the temp view name to see the data
# MAGIC * for writing to
# MAGIC   * create a dataframe of the data you want to write 
# MAGIC   * create values for the SHEET_NAME and WORKBOOK_ID variables
# MAGIC   * enter the sheet name, workbook id, and dataframe in the refresh_data_in_sheet function
# MAGIC   * specify which row and column to write to

# COMMAND ----------

# DBTITLE 1,Run Helper Functions for Writing & Reading from Google Sheets
# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

# DBTITLE 1,Get Backfil Data from the workbook
#Read Backfil Data
workbook_id='1GDwKPXSuLGgFOxr2W8cniEm2Z1wUjkQGBnGvBVqvzlI'
sheet_id='0'
read_google_sheet(workbook_id=workbook_id,sheet_id=sheet_id).createOrReplaceTempView('backfil_ds')

# COMMAND ----------

#Read existing Onboarding Data
workbook_id='1Uei8qCWyf9P8M2oRgTsBYaZKVEs1guWLNy3v2klrMWQ'
sheet_id='1739500783'
read_google_sheet(workbook_id=workbook_id,sheet_id=sheet_id).createOrReplaceTempView('existing_onboarding_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists main.field_learning_enablement.backfil_data;
# MAGIC create or replace table main.field_learning_enablement.backfil_data as (
# MAGIC select distinct
# MAGIC   coalesce(offer_id, 'NA') as name
# MAGIC , split(offer_id, ' ')[0] as first_name
# MAGIC , try_element_at(split(offer_id, ' ' ), 2) as last_name
# MAGIC , 'Null' as email
# MAGIC , coalesce(location, 'Null') as location
# MAGIC , coalesce(job_profile, 'Null') as job_profile
# MAGIC , coalesce(job_profile, 'Null') as business_title
# MAGIC , hire_rehire_date::string as start_date
# MAGIC , hire_rehire_date::string as start_date_or_last_promotion_date
# MAGIC --, coalesce(to_date(hire_rehire_date, 'M/dd/yy'),'2999-12-31')::string as start_date
# MAGIC --, coalesce(to_date(hire_rehire_date, 'M/dd/yy'),'2999-12-31')::string as start_date_or_last_promotion_date
# MAGIC , 'Null' as profile_prior_to_promotion
# MAGIC , 'Null' as title_prior_to_promotion
# MAGIC , coalesce(manager, 'Null') as manager
# MAGIC , 'Null' as manager_email
# MAGIC , 'Null' as manager_workday_id
# MAGIC , coalesce(department_l3, 'Null') as cost_center
# MAGIC , case when department_l3 like '610%' or department_l3 like '620%' or department_l3 like '650%' then "AE" else 'Non AE' end as AE_or_Non_AE
# MAGIC --, split_part(estaff,'(',1) as organization_leader_in_sales_org 
# MAGIC , trim(trailing ")" from split_part('Field Eng (Arsalan)','(',2)) as organization_leader_in_sales_org 
# MAGIC , 'Null' as organization_leader_email_in_sales_org
# MAGIC , 'Null' as manager_L4
# MAGIC , 'Null' as manager_email_L4 
# MAGIC from backfil_ds
# MAGIC where 1=1
# MAGIC and offer_id != ''
# MAGIC and coalesce(hire_rehire_date::string,'2999-12-31') != '2999-12-31'
# MAGIC )

# COMMAND ----------

# DBTITLE 1,Writing Data back to the defined Google sheet
# name	first_name	last_name	email	location	job_profile	business_title	start_date	start_date_or_last_promotion_date	profile_prior_to_promotion	title_prior_to_promotion	manager	manager_email	manager_workday_id	cost_center	AE_or_Non_AE	organization_leader_in_sales_org	organization_leader_email_in_sales_org	manager_L4	manager_email_L4


spark.sql("""select distinct
                    base.name
                  , base.first_name
                  , base.last_name
                  , base.primaryWorkEmail email
                  , base.location
                  , base.job_profile
                  , base.businessTitle business_title
                  , base.hire_date::string as start_date
                  , base.job_profile_start_date::string as start_date_or_last_promotion_date
                  , base.profile_prior_to_promotion
                  , base.title_prior_to_promotion
                  , base.manager as manager
                  , base.manager_email as manager_email
                  , base.manager_workday_id
                  , base.cost_center
                  , base.AE_or_Non_AE
                  , base.name_L3 as organization_leader_in_sales_org
                  , base.L3 as organization_leader_email_in_sales_org
                  , base.name_L4 as manager_L4
                  , base.L4 as manager_email_L4 
                from main.field_learning_enablement.workday base 
                where processDate = (select max(processdate) from main.field_learning_enablement.workday) and Status=true
                union 
                select 
                    name
                  , first_name
                  , last_name
                  , email
                  , location
                  , job_profile
                  , business_title
                  ,to_date(start_date,'M/d/yy') as start_date 
                  --, start_date
                  , to_date(start_date_or_last_promotion_date,'M/d/yy') start_date_or_last_promotion_date
                  --,start_date_or_last_promotion_date
                  , profile_prior_to_promotion
                  , title_prior_to_promotion
                  , manager
                  , manager_email
                  , manager_workday_id
                  , cost_center
                  , AE_or_Non_AE
                  , organization_leader_in_sales_org
                  , organization_leader_email_in_sales_org
                  , manager_L4
                  , manager_email_L4
                from main.field_learning_enablement.backfil_data
                where start_date is not null
                  """).createOrReplaceTempView('combined_data')

# sheet_id='0'
# retry_operation(
#     lambda: 


# COMMAND ----------

df=spark.sql("""
select 
C.*
  ,welcome_email 
  ,uploaded_in_lms_pre_work
  , bootcamp_am_or_pm
  , bootcamp_date
  , intake_exam_status
  , pre_work
  , entry_exam_status
  , final_exam_status
  , tactical_training_invite_sent
  , tactical_training_date
  , ae_report_card
  , mentor_assignment
from (select * from combined_data where email<>'Null')C
left join existing_onboarding_data B
on lower(C.email)=lower(B.email)
union
select 
  C.*
  ,welcome_email 
  ,uploaded_in_lms_pre_work
  , bootcamp_am_or_pm
  , bootcamp_date
  , intake_exam_status
  , pre_work
  , entry_exam_status
  , final_exam_status
  , tactical_training_invite_sent
  , tactical_training_date
  , ae_report_card
  , mentor_assignment
from (select * from combined_data where email='Null')C
left join existing_onboarding_data B
on lower(C.name)=lower(B.name)
""")

# COMMAND ----------

wb_id='1Uei8qCWyf9P8M2oRgTsBYaZKVEs1guWLNy3v2klrMWQ'
refreshDataInSheet(sheet_name= '1739500783',\
                   pandas_df=gsheetPandasConversion(df.distinct()),\
                   workbook_name_or_id=wb_id,\
                   row_number_to_push_into=2,\
                   column_letter_to_push_into='A',\
                   startRowIndexFilter=0,\
                   columnIndexFilter=1,\
                   push_spark_df_headers_into_sheet=df.distinct(),\
                   pause_between_sheet_updates=10) #,
#     sleep_time=30,
#     retries=3,
# )

# COMMAND ----------

# DBTITLE 1,Writing Data to SP All Sales Workbook
# name	teamCategory	email	Cost_Center	hire_date	Job_Profile	businessTitle	Manager	Manager_Email	Supervisory_Organization	Supervisory_Organization_cleaned	Location	Location_Address_Country	6th Level Manager	5th Level Manager	4th Level Manager	3rd Level Manager	2nd Level Manager	1st Level Manager	Direct Manager	Worker_Type	Original_Hire_Date	Job_Profile_Start_Date	is_manager	is_director	is_vp	org_size	managerial_reporting_hierarchy_path

wb_id='1V3lut5QginJgaKhqF5y-waae6KUxtYc_CBVpYZu6lME'
df1 = spark.sql("""select 
                    name
                  , first_name
                  , last_name
                  , teamCategory
                  , primaryWorkEmail email
                  , cost_center
                  , hire_date
                  , job_profile
                  , businessTitle business_title
                  , manager
                  , manager_email
                  , Supervisory_Organization
                  , Supervisory_Organization_cleaned
                  , location
                  , location_address_country
                  , 6th_level_manager
                  , 5th_level_manager
                  , 4th_level_manager
                  , 3rd_level_manager
                  , 2nd_level_manager
                  , 1st_level_manager
                  , Manager direct_manager
                  , worker_type
                  , original_hire_date
                  , job_profile_start_date
                  , is_manager
                  , is_director
                  , is_vp
                  , org_size
                  , manager_hierarchy_path managerial_reporting_hierarchy_path
                  from main.field_learning_enablement.workday base
                  where processDate = (select max(processdate) from main.field_learning_enablement.workday) and Status=true
                  """)

# sheet_id='0'
# retry_operation(
#     lambda: 
refreshDataInSheet(sheet_name= '1894740960',\
                   pandas_df=gsheetPandasConversion(df1.distinct()),\
                   workbook_name_or_id=wb_id,\
                   row_number_to_push_into=2,\
                   column_letter_to_push_into='A',\
                   startRowIndexFilter=0,\
                   columnIndexFilter=1,\
                   push_spark_df_headers_into_sheet=df1.distinct(),\
                   pause_between_sheet_updates=10) #,
#     sleep_time=30,
#     retries=3,
# )

# COMMAND ----------

# MAGIC %md
# MAGIC Records with same Names

# COMMAND ----------

# MAGIC %md
# MAGIC List of all records with same names

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from combined_data where name in
# MAGIC (select name from combined_data group by all having count(*)>1)
# MAGIC order by name

# COMMAND ----------

# MAGIC %md
# MAGIC List of all employees with same names in Anaplan and Workday 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from combined_data where name in
# MAGIC (select name from combined_data group by all having count(*)>1) and name in (select name from combined_data where email='Null')
# MAGIC order by name

# COMMAND ----------

# MAGIC %md
# MAGIC Hire date Date difference between records of same names to check for duplicates

# COMMAND ----------

# MAGIC %sql
# MAGIC with cte as (
# MAGIC select abs(date_diff(lead(start_date)over (partition by name order by start_date),start_date)) diff,start_date,* from combined_data where name in
# MAGIC (select name from combined_data group by all having count(*)>1) and name in (select name from combined_data where email='Null'))
# MAGIC
# MAGIC select * from cte order by diff nulls last