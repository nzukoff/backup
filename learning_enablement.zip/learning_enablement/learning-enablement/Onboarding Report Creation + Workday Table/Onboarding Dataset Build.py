# Databricks notebook source
# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

#spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint


warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
# from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------


active_workers='main.workday.active_workers'
print(focus_data_utils_path,focus_database_name,partition_date,partition_column,)

# COMMAND ----------

# utility methods
from pyspark.sql import DataFrame
from typing import Optional
from datetime import date,datetime
def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

spark.sql(f"""
with base_table as (
select distinct 
*
,case when cost_center in ("610 Enterprise Account Execs", "620 Federal Account Execs", "650 Comm'l/MM Account Execs") then "AE" else "Non AE" end as AE_or_Non_AE
,split(name, ' ')[0] as first_name
,try_element_at(split(name, ' '), 2) as last_name 
from {active_workers}
where effective_date = (select max(effective_date) from {active_workers})
)
, promotions_history_scd as (
    select  
        email,
        job_profile, 
        business_title,
        min(effective_date) as last_promotion_date,
        dense_rank() over(partition by email order by job_profile, business_title asc) as change_in_profile
    from {active_workers}
    group by email, job_profile, business_title
)

, promotion_history_ranked as(
select * 
from (  
  select 
  email
  , job_profile
  , business_title
  , lead(job_profile) over(partition by  email order by last_promotion_date desc) as profile_prior_to_promotion
  , lead(business_title) over(partition by email order by last_promotion_date desc) as title_prior_to_promotion
  ,last_promotion_date
  , rank() over(partition by email order by last_promotion_date desc) as rank
  from promotions_history_scd
)
where rank = 1
)

-- name	teamCategory	email	Cost_Center	hire_date	Job_Profile	businessTitle	Manager	Manager_Email	Supervisory_Organization	Supervisory_Organization_cleaned	Location	Location_Address_Country	6th Level Manager	5th Level Manager	4th Level Manager	3rd Level Manager	2nd Level Manager	1st Level Manager	Direct Manager	Worker_Type	Original_Hire_Date	Job_Profile_Start_Date	is_manager	is_director	is_vp	org_size	managerial_reporting_hierarchy_path

select distinct
  base.name as Name
, base.first_name 
, base.last_name
, base.workday_id as WorkdayID
, "Null" as teamcategory
, base.email as primaryWorkEmail
, base.cost_center as Cost_Center
, base.hire_date as Hire_Date 
, base.job_profile as Job_Profile
, base.business_title as businessTitle
, manager.name as Manager
,manager.name as init_level_manager_name
, manager.email as Manager_Email
,manager.email as init_level_manager
, base.sup_org_name as Supervisory_Organization
, split_part(base.sup_org_name, '(',1) as Supervisory_Organization_cleaned --to be cleaned
, base.location as Location
, split_part(base.location, '.',1) as Location_Address_Country --//to be cleaned
, wh.L2 as 6th_level_manager
, wh.L3 as 5th_level_manager
, wh.L4 as 4th_level_manager
, wh.L5 as 3rd_level_manager
, wh.L6 as 2nd_level_manager
, wh.L7 as 1st_level_manager
, manager.name as direct_manager
, manager.business_title as manager_business_title
, case when (base.job_profile = 'Contractor' or base.business_title = 'Contractor')  then 'Contingent Worker' else 'Employee' end as Worker_Type
, base.hire_date as Original_Hire_Date
, ph.last_promotion_date as job_profile_start_date
, "Null" as is_manager
, "Null" as is_director
, case when base.job_profile like '%VP,%' then 'Yes' else 'No' end as is_vp
, count(reportee.email) over(partition by reportee.manager_workday_id) as org_size
--, concat_ws(' ,', wh.L0, wh.L1, wh.L2, wh.L3 , wh.L4, wh.L5, wh.L6, wh.L7) as managerial_reporting_hierarchy_path
, concat_ws(';',
  NVL(wh.L11,''),
  NVL(wh.L10,''),
  NVL(wh.L9,''),
  NVL(wh.L8,''),
  NVL(wh.L7,''), 
  NVL(wh.L6,''), 
  NVL(wh.L5,''),
  NVL(wh.L4,'') , 
  NVL(wh.L3,''), 
  NVL(wh.L2,''), 
  NVL(wh.L1,''), 
  NVL(wh.L0,''),'') as manager_hierarchy_path
, ph.profile_prior_to_promotion
, ph.title_prior_to_promotion
, base.manager_workday_id
, base.AE_or_Non_AE
, wh.L0 Manager_Level_01
, wh.L1 Manager_Level_02
, wh.L2 Manager_Level_03
, wh.L3 
, wh.L4
, wh.L5
, wh.L6
, wh.L7
, wh.L8
, wh.L9
, wh.L10
, wh.L11
, wh_namel3.name as name_L3
, wh_namel4.name as name_L4
,  case
  when base.job_profile in (
    'Resident Solutions Architect',
    'Sr. Resident Solutions Architect'
  ) then 'RSA'
  when base.job_profile in (
    'Specialist Solutions Architect',
    'Sr. Specialist Solutions Architect',
    'Lead Specialist Solutions Architect',
    'Principal Specialist Solutions Architect'
  ) then 'SSA'
  when base.job_profile in (
    'Delivery Solutions Architect',
    'Lead Delivery Solutions Architect',
    'Sr. Delivery Solutions Architect'
  ) then 'DSA'
  when base.job_profile in (
    'Solutions Architect',
    'Sr. Solutions Architect',
    'Lead Solutions Architect',
    'Principal Solutions Architect'
  ) then 'SA'
  when base.job_profile ilike '%Manager%'
    then 'Manager'
  when base.job_profile ilike '%Technical Services Specialist%'
   then 'TSS'
  else 'Other'
end as job_role

 from base_table base
 left join promotion_history_ranked ph 
          on base.email = ph.email
          and base.job_profile = ph.job_profile
          and base.business_title = ph.business_title
  left join base_table manager
          on base.manager_workday_id = manager.workday_id
  left join base_table reportee
          on base.workday_id = reportee.manager_workday_id        
  left join main.workday.workday_hierarchy wh
          on base.email = wh.email
  left join base_table wh_namel4
          on wh.L4 = wh_namel4.email  
  left join base_table wh_namel3
          on wh.L3 = wh_namel3.email 
""").createOrReplaceTempView("emp_base_table")   

# COMMAND ----------

emp_augmented=spark.sql("""
select E.* except(Manager_Level_01,Manager_Level_02,Manager_Level_03,manager_hierarchy_path)

,lower(trim(leading ';' from E.manager_hierarchy_path)) manager_hierarchy_path

,ML1.name as Manager_Level_01
,ML2.name as Manager_Level_02
,ML3.name as Manager_Level_03

,M1.name as 1st_level_manager_name
,M2.name as 2nd_level_manager_name
,M3.name as 3rd_level_manager_name
,M4.name as 4th_level_manager_name
,M5.name as 5th_level_manager_name
,M6.name as 6th_level_manager_name

,trim(leading ';' from 
  lower(
    concat_ws(';'
      , NVL(M11.name,'')
      , NVL(M10.name,'')
      , NVL(M9.name,'')
      , NVL(M8.name,'')
      , NVL(1st_level_manager_name,'')
      , NVL(2nd_level_manager_name,'')
      , NVL(3rd_level_manager_name,'')
      , NVL(4th_level_manager_name,'')
      , NVL(5th_level_manager_name,'')
      , NVL(6th_level_manager_name,'')
      , NVL(ML2.name,'')
      , NVL(ML1.name,'')
      ,''
    )
  ) 
)
as manager_hierarchy_path_name
,sha2(E.primaryWorkEmail,256) as email_hash
,datediff(MONTH, E.hire_Date, current_date()) as tenure_in_months


from emp_base_table E
left join emp_base_table ML1 on E.Manager_Level_01 = ML1.primaryWorkEmail
left join emp_base_table ML2 on E.Manager_Level_02 = ML2.primaryWorkEmail
left join emp_base_table ML3 on E.Manager_Level_03 = ML3.primaryWorkEmail



left join emp_base_table M6 on E.6th_level_manager = M6.primaryWorkEmail
left join emp_base_table M5 on E.5th_level_manager = M5.primaryWorkEmail
left join emp_base_table M4 on E.4th_level_manager = M4.primaryWorkEmail
left join emp_base_table M3 on E.3rd_level_manager = M3.primaryWorkEmail
left join emp_base_table M2 on E.2nd_level_manager = M2.primaryWorkEmail
left join emp_base_table M1 on E.1st_level_manager = M1.primaryWorkEmail

left join emp_base_table M11 on NVL(E.L11,'') = NVL(M11.primaryWorkEmail ,'')
left join emp_base_table M10 on NVL(E.L10,'') = NVL(M10.primaryWorkEmail,'')
left join emp_base_table M9 on  NVL(E.L9 ,'')=  NVL(M9.primaryWorkEmail ,'')
left join emp_base_table M8 on  NVL(E.L8 ,'')=  NVL(M8.primaryWorkEmail,'')
left join emp_base_table M7 on  NVL(E.L7 ,'')=  NVL(M7.primaryWorkEmail,'')


""")



# COMMAND ----------

emp_augmented_gold = add_gold_metadata(emp_augmented)
emp_augmented_gold.createOrReplaceTempView("emp_augmented_gold")

# COMMAND ----------

workday_final_df=spark.sql(f"""
with 
existing_users as 
(select * from main.field_learning_enablement.workday where processDate=(select max(processdate) from main.field_learning_enablement.workday ) 
)
,termination_details as (
  select email,max(effective_date) max_effective_date from {active_workers} group by all
)
SELECT 
     NVL(A.Name,B.Name) AS Name
    ,NVL(A.first_name,B.first_name) AS first_name
    ,NVL(A.last_name,B.last_name) AS last_name
    ,NVL(A.WorkdayID,B.WorkdayID) AS WorkdayID
    ,NVL(A.Worker_Type,B.Worker_Type) AS Worker_Type
    ,NVL(A.primaryWorkEmail,B.primaryWorkEmail) AS primaryWorkEmail
    ,NVL(A.Hire_Date,B.Hire_Date) AS Hire_Date
    --Termination Date
    ,CASE WHEN A.processDate is null  THEN NVL(B.Termination_Date,B.processDate) END AS Termination_Date
    ,NVL(A.Cost_Center,B.Cost_Center) AS Cost_Center
    ,NVL(A.Location,B.Location) AS Location
    ,NVL(A.Location_Address_Country,B.Location_Address_Country) AS Location_Address_Country
    ,NVL(A.Job_Profile,B.Job_Profile) AS Job_Profile
    ,NVL(A.businessTitle,B.businessTitle) AS businessTitle
    ,NVL(A.Manager_Level_01,B.Manager_Level_01) AS Manager_Level_01
    ,NVL(A.Manager_Level_02,B.Manager_Level_02) AS Manager_Level_02
    ,NVL(A.Manager_Level_03,B.Manager_Level_03) AS Manager_Level_03
    ,NVL(A.Manager,B.Manager) AS Manager
    ,NVL(A.Manager_Email,B.Manager_Email) AS Manager_Email
    ,NVL(A.Supervisory_Organization,B.Supervisory_Organization) AS Supervisory_Organization
    ,NVL(A.Supervisory_Organization_cleaned,B.Supervisory_Organization_cleaned) AS Supervisory_Organization_cleaned
    --Status
    ,CASE WHEN A.processDate is null  THEN false ELSE true END AS Status
    ,NVL(A.Original_Hire_Date,B.Original_Hire_Date) AS Original_Hire_Date
    ,NVL(A.manager_hierarchy_path,B.manager_hierarchy_path) AS manager_hierarchy_path
    ,NVL(A.manager_hierarchy_path_name,B.manager_hierarchy_path_name) AS manager_hierarchy_path_name
    ,NVL(A.6th_level_manager,B.6th_level_manager) AS 6th_level_manager
    ,NVL(A.5th_level_manager,B.5th_level_manager) AS 5th_level_manager
    ,NVL(A.4th_level_manager,B.4th_level_manager) AS 4th_level_manager
    ,NVL(A.3rd_level_manager,B.3rd_level_manager) AS 3rd_level_manager
    ,NVL(A.2nd_level_manager,B.2nd_level_manager) AS 2nd_level_manager
    ,NVL(A.1st_level_manager,B.1st_level_manager) AS 1st_level_manager
    ,NVL(A.init_level_manager,B.init_level_manager) AS init_level_manager
    ,NVL(A.6th_level_manager_name,B.6th_level_manager_name) AS 6th_level_manager_name
    ,NVL(A.5th_level_manager_name,B.5th_level_manager_name) AS 5th_level_manager_name
    ,NVL(A.4th_level_manager_name,B.4th_level_manager_name) AS 4th_level_manager_name
    ,NVL(A.3rd_level_manager_name,B.3rd_level_manager_name) AS 3rd_level_manager_name
    ,NVL(A.2nd_level_manager_name,B.2nd_level_manager_name) AS 2nd_level_manager_name
    ,NVL(A.1st_level_manager_name,B.1st_level_manager_name) AS 1st_level_manager_name
    ,NVL(A.init_level_manager_name,B.init_level_manager_name) AS init_level_manager_name
    ,null AS tenure_in_months_old

    ,NVL(A.job_role,B.job_role) AS job_role
    ,NVL(A.teamcategory,B.teamcategory) AS teamcategory
    ,NVL(A.job_profile_start_date,B.job_profile_start_date) AS job_profile_start_date
    ,NVL(A.is_manager,B.is_manager) AS is_manager
    ,NVL(A.is_director,B.is_director) AS is_director
    ,NVL(A.is_vp,B.is_vp) AS is_vp
    ,NVL(A.org_size,B.org_size) AS org_size
    ,NVL(A.profile_prior_to_promotion,B.profile_prior_to_promotion) AS profile_prior_to_promotion
    ,NVL(A.title_prior_to_promotion,B.title_prior_to_promotion) AS title_prior_to_promotion
    ,NVL(A.manager_workday_id,B.manager_workday_id) AS manager_workday_id
    ,NVL(A.AE_or_Non_AE,B.AE_or_Non_AE) AS AE_or_Non_AE
    ,NVL(A.L3, B.L3) AS L3
    ,NVL(A.L4, B.L4) AS L4
    ,NVL(A.L5, B.L5) AS L5
    ,NVL(A.L6, B.L6) AS L6
    ,NVL(A.L7, B.L7) AS L7
    ,NVL(A.L8, B.L8) AS L8
    ,NVL(A.L9, B.L9) AS L9
    ,NVL(A.L10, B.L10) AS L10
    ,NVL(A.L11, B.L11) AS L11
    ,NVL(A.name_L3, B.name_L3) AS name_L3
    ,NVL(A.name_L4, B.name_L4) AS name_L4
    ,A.processDate
    ,NVL(A.manager_business_title,B.manager_business_title) AS manager_business_title
    ,NVL(A.email_hash,B.email_hash) AS email_hash
    ,NVL(A.tenure_in_months,B.tenure_in_months) AS tenure_in_months
from emp_augmented_gold  A
full outer join existing_users B 
on A.primaryWorkEmail=B.primaryWorkEmail
left join termination_details C on 
B.primaryWorkEmail=C.email
""")


# COMMAND ----------

workday_final_df_gold = add_gold_metadata(workday_final_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = workday_final_df_gold.distinct(), 
  table_name = f'{focus_database_name}.workday', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# DBTITLE 1,Checking Duplicate
# MAGIC %sql
# MAGIC select primaryWorkEmail from field_learning_enablement.workday where primaryWorkEmail in (
# MAGIC select primaryWorkEmail from field_learning_enablement.workday where processdate =(select max(processdate) from field_learning_enablement.workday)group by 1 having count(*)>1)