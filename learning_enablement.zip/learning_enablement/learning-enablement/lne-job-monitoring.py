# Databricks notebook source
# MAGIC %md
# MAGIC ## Initial Setup

# COMMAND ----------

# DBTITLE 1,Install Packages
# MAGIC %pip install --upgrade databricks-sdk
# MAGIC %pip install cron_converter 
# MAGIC %restart_python

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

# DBTITLE 1,Import Library
#standard libraries
import sys
import logging
import warnings
from pprint import pprint
from pyspark.sql.types import DoubleType
from pyspark.sql.functions import udf, col
from pyspark.sql.types import StructType, StructField, StringType
from cron_converter import Cron
from zoneinfo import ZoneInfo
from databricks.sdk import WorkspaceClient
from datetime import datetime, timedelta, timezone
import statistics
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC
warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)


# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *



# COMMAND ----------

# DBTITLE 1,Widget creation
#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

print(focus_database_name,partition_date)

# COMMAND ----------

# DBTITLE 1,Workspace Client creation
w = WorkspaceClient()

# COMMAND ----------

# MAGIC %md
# MAGIC ## UDF Definition

# COMMAND ----------

# DBTITLE 1,Fn: Cron to UTC Time Convertor
cron_to_utc_schema = StructType([
    StructField("next_occurrence_utc", StringType(), True),
    StructField("prev_occurrence_utc", StringType(), True)
])

def cron_to_utc_spark(cron_expression, timezone_str):
    try:
        
        cron_expression = cron_expression.split(" ", 1)[1].replace("?", "*")
        local_timezone = ZoneInfo(timezone_str)
        current_date_local = datetime.now(local_timezone)
        cron = Cron(cron_expression)
        schedule = cron.schedule(start_date=current_date_local)
        next_occurrence_local = schedule.next()
        prev_occurrence_local = schedule.prev()
        next_occurrence_utc = next_occurrence_local.astimezone(ZoneInfo("UTC"))
        prev_occurrence_utc = prev_occurrence_local.astimezone(ZoneInfo("UTC"))
        return (str(next_occurrence_utc), str(prev_occurrence_utc))
    except:
        return ("Cannot Retrieve", "Cannot Retrieve")

cron_to_utc_udf = udf(cron_to_utc_spark, cron_to_utc_schema)

# COMMAND ----------

# DBTITLE 1,Fn: Get Average run Duration for past 2 months

def get_avg_run_duration(job_ids, days=60):
  job_duration_avg_lst=[]
  for job_id in job_ids:
    start_time_from = datetime.today() - timedelta(days=days)
    start_time_from_utc_ms = int(start_time_from.replace(tzinfo=timezone.utc).timestamp() * 1000)
    run_durations = []
    for runs in w.jobs.list_runs(job_id=job_id, completed_only=True, start_time_from=start_time_from_utc_ms):
        run_dict = runs.as_dict()
        if ('run_duration' in run_dict) and (run_dict['run_duration'] is not None) and (run_dict["state"]["result_state"]=='SUCCESS'):
            run_durations.append(run_dict['run_duration'])
    if run_durations:
        avg_duration = statistics.mean(run_durations)/60000
        job_duration_avg_lst.append({'job_id':job_id,'avg_duration_min':avg_duration})
    else:
        job_duration_avg_lst.append({'job_id':job_id,'avg_duration_min':None})
  return(spark.createDataFrame(job_duration_avg_lst))

# COMMAND ----------

# DBTITLE 1,Fn: Get Latest Run Details of Job
def get_job_runs(job_ids):
    all_runs = []
    for job_id in job_ids:
        for runs in w.jobs.list_runs(job_id=job_id,completed_only=True):
          
            run_dict = runs.as_dict()
            
            if "start_time" in run_dict and run_dict["start_time"] is not None:
                run_dict["start_time"] = datetime.fromtimestamp(run_dict["start_time"] / 1000)
            if "end_time" in run_dict and run_dict["end_time"] is not None:
                run_dict["end_time"] = datetime.fromtimestamp(run_dict["end_time"] / 1000)
            if "run_duration" in run_dict and run_dict["run_duration"] is not None:
              
                run_dict["run_duration_min"]=run_dict["run_duration"]/60000
                duration_ms = run_dict["run_duration"]
        
                hours = duration_ms // (1000 * 60 * 60)
                minutes = (duration_ms // (1000 * 60)) % 60
                seconds = (duration_ms // 1000) % 60
                if hours != 0:
                    run_dict["run_duration"] = f"{hours} hours {minutes} minutes {seconds} seconds"
                elif minutes != 0:
                    run_dict["run_duration"] = f"{minutes} minutes {seconds} seconds"
                else:
                    run_dict["run_duration"] = f"{seconds} seconds"
            result_state = run_dict["state"]["result_state"]
            run_dict["result_state"] = result_state
           
            all_runs.append({
                    'job_id': run_dict['job_id'],
                    'run_id': run_dict['run_id'],
                    'run_type': run_dict['run_type'],
                    'trigger' :run_dict['trigger'],
                    'run_page_url' :run_dict['run_page_url'],
                    'start_time': run_dict['start_time'],
                    'end_time': run_dict['end_time'],
                    'run_duration': run_dict['run_duration'],
                    'result_state': run_dict['state']['result_state'],
                    'run_duration_min': run_dict['run_duration_min'],
                })
            break

    df = spark.createDataFrame(all_runs)
    return df

# COMMAND ----------

# DBTITLE 1,Fn: Get Dashboard Names for Published Dashboards
def get_dashboard_name(dashboard_ids):
    all_dashboard = []
    for dashboard_id in dashboard_ids:
     
      try:
        dashboard_name=w.lakeview.get_published(dashboard_id).display_name
        all_dashboard.append({'dashboard_id':dashboard_id,'dashboard_name':dashboard_name})
      except:
        all_dashboard.append({'dashboard_id':dashboard_id,'dashboard_name':None})
        
    df = spark.createDataFrame(all_dashboard)
    return df

# COMMAND ----------

# DBTITLE 1,Fn: Get Table metadata
# function to get record count and refresh date for all the tables
def refresh_check(full_table_name_lst):
    all_refresh = []

    for full_table_name in full_table_name_lst:
        print(full_table_name)
        try:
            # Get the last modified timestamp from table history
            query = f"""
                select 
                    timestamp as latest_date, 
                    operation,
                    operationMetrics.numOutputRows AS numOutputRows 
                from (DESCRIBE HISTORY {full_table_name})
                WHERE operation IN ('WRITE', 'CREATE TABLE AS SELECT', 'CREATE OR REPLACE TABLE AS SELECT')
                order by date(timestamp) desc 
                limit 2
            """

            history_info = spark.sql(query)

            last_updated = history_info.collect()[0]['latest_date']
            operation = history_info.collect()[0]['operation']
            count = history_info.collect()[0]['numOutputRows']

            try:
                last_updated_prev = history_info.collect()[1]['latest_date']
                operation_prev = history_info.collect()[1]['operation']
                count_prev = history_info.collect()[1]['numOutputRows']
                all_refresh.append({
                    'table': full_table_name,
                    'last_updated': last_updated,
                    'operation': operation,
                    'Count': count,
                    'last_updated_prev': last_updated_prev,
                    'operation_prev': operation_prev,
                    'Count_prev': count_prev,
                    
                })
            except:
                all_refresh.append({
                    'table': full_table_name,
                    'last_updated': last_updated,
                    'operation': operation,
                    'Count': count,
                    'last_updated_prev': None,
                    'operation_prev': None,
                    'Count_prev': 0,
                    
                })

        except:
            all_refresh.append({
                'table': full_table_name,
                'last_updated': None,
                'operation': None,
                'Count': 0,
                'last_updated_prev': None,
                'operation_prev': None,
                'Count_prev': 0,
                
            })
    all_refresh_df = spark.createDataFrame(all_refresh)
    return all_refresh_df
    # return count

# COMMAND ----------

# MAGIC %md
# MAGIC ## Retrive All Jobs starting with prefix lne

# COMMAND ----------

# DBTITLE 1,List jobs with prefix lne

job_list=[]

for job in w.jobs.list():
  job_dict=job.as_dict()
  if (str(job_dict["settings"]["name"]).startswith("lne") ):
    schedule = job_dict["settings"].get("schedule")

    if schedule is not None:
      schedule_cron = schedule.get("quartz_cron_expression", "")
      schedule_status = schedule.get("pause_status")
      schedule_timezone = schedule.get("timezone_id")
    else:
      schedule_cron = None
      schedule_status = None
      schedule_timezone = None

    job_list.append({"job_id": job_dict["job_id"]
       , "name": job_dict["settings"]["name"]
       , "schedule_status": schedule_status
       , "schedule_cron_expression": schedule_cron
       , "schedule_cron_expression_timezone": schedule_timezone})
    
jobs_list_df = spark.createDataFrame(job_list)
jobs_list_df.createOrReplaceTempView('jobs_list_vw')

# COMMAND ----------

# DBTITLE 1,Calculation of Previous and Next Job Schedule Time
jobs_list_aug_df = (
    jobs_list_df
    .withColumn(
        "cron_utc_info",
        cron_to_utc_udf(
            col("schedule_cron_expression"),
            col("schedule_cron_expression_timezone")
        )
    )
    .withColumn("next_run_utc", col("cron_utc_info.next_occurrence_utc"))
    .withColumn("prev_run_utc", col("cron_utc_info.prev_occurrence_utc"))
    .drop("cron_utc_info")
)

jobs_list_aug_df.createOrReplaceTempView('jobs_list_aug_vw')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Downstream Job and Dashboard

# COMMAND ----------

# DBTITLE 1,Downstream Tables
spark.sql(
  """select 
      distinct entity_id as job_id,
      target_table_full_name
    from system.access.table_lineage
    where cast(entity_id as string) in (select distinct cast(job_id as string) from jobs_list_aug_vw)
    and target_type = 'TABLE'"""
).createOrReplaceTempView('job_to_downstream_table_mapping_vw')

# COMMAND ----------

# DBTITLE 1,Downstream Dashboard
table_to_downstream_dashboard_mapping_df=spark.sql(
  """select distinct 
      entity_id::string as dashboard_id,
      source_table_full_name
    from system.access.table_lineage
    where entity_type = 'DASHBOARD_V3'
    and source_table_full_name in (select distinct target_table_full_name from job_to_downstream_table_mapping_vw)"""
)

# COMMAND ----------

# DBTITLE 1,Extract Downstream Dashboard Names
dashboard_id_list = [row.dashboard_id for row in table_to_downstream_dashboard_mapping_df.select("dashboard_id").distinct().collect()]
all_dashboard_df = get_dashboard_name(dashboard_id_list)

# COMMAND ----------

all_published_df=table_to_downstream_dashboard_mapping_df.join(all_dashboard_df, on='dashboard_id', how='inner')
all_published_df.filter(all_published_df.dashboard_name.isNotNull()).createOrReplaceTempView("all_dashboard_vw")

# COMMAND ----------

# DBTITLE 1,Job to Tables and Dashboard Mapping
job_downstream_objects_mapping_df = spark.sql("""
    SELECT DISTINCT
        A.*,
        B.target_table_full_name,
        C.dashboard_id,
        C.dashboard_name,
        concat_ws(
            "",
            "https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/",
            C.dashboard_id,
            "/published?o=2548836972759138"
        ) AS dashboard_link,
        current_date() updated_date
    FROM jobs_list_aug_vw A
    LEFT JOIN job_to_downstream_table_mapping_vw B
        ON CAST(A.job_id AS STRING) = CAST(B.job_id AS STRING)
    LEFT JOIN all_dashboard_vw C
        ON B.target_table_full_name = C.source_table_full_name
""")

# COMMAND ----------

# DBTITLE 1,Create temporary table for mapping
write_instructions = (
        job_downstream_objects_mapping_df.write.format("delta")
        .mode("overwrite")
        .option("overwriteSchema", True)
        .option("mergeSchema", True)
    )


write_instructions.saveAsTable('main.field_learning_enablement.job_monitoring_dwnstm_objs_mapping')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Metadata extraction

# COMMAND ----------

job_mapping_df=spark.sql("select * from main.field_learning_enablement.job_monitoring_dwnstm_objs_mapping")


# COMMAND ----------

# DBTITLE 1,Get Latest Run and Average Duration Details

job_id_list = [row.job_id for row in job_mapping_df.select("job_id").distinct().collect()] 
df_job_run=get_job_runs(job_id_list)
df_job_run_duration_avg=get_avg_run_duration(job_id_list)
df_job_run.join(df_job_run_duration_avg, "job_id","left").createOrReplaceTempView('job_run_vw')

# COMMAND ----------

# DBTITLE 1,Get Downstream Table Details
target_table_full_name_list = [row.target_table_full_name for row in job_mapping_df.select("target_table_full_name").distinct().collect() ]
all_refresh_df = refresh_check(target_table_full_name_list)
all_refresh_df.createOrReplaceTempView("all_refresh_vw")

# COMMAND ----------

# DBTITLE 1,Get Dashboard View Metrics
spark.sql("""
with daily_usage as (
  select distinct
    ds as event_date,
    id as visit,
    summary.workspaceId as workspace_id,
    summary.pseudoUserId as user,
    summary.productEntityInfo.closestEntityId as dashboard_id,
    summary.productEntityInfo.closestEntityType as dashboard_type
  from
    main.metric_store.ui_observability_impressions_and_actions
  where
    subType = 'page_view'
    and ds between date_add(current_date(), -30) and current_date()
    and summary.productEntityInfo.closestEntityType in ('LAKEVIEW_DASHBOARD', 'REDASH_DASHBOARD')
    and summary.workspaceId = '2548836972759138'
)
select
  dashboard_id,
  count(distinct visit) as visits,
  count(distinct user) as users
from
  daily_usage 
group by
  all
""").createOrReplaceTempView('dashboard_usage_vw')

# COMMAND ----------

# DBTITLE 1,Final Table Creation
final_df=spark.sql("""
select distinct
    A.*,
    B.* except (job_id),
    C.* except (table),
    D.visits,
    D.users,
    case
      when prev_run_utc <> 'Cannot Retrieve' and last_updated < date(prev_run_utc) then 'Refresh Delayed'
      else 'Refresh Completed'
    end as refresh_status,
    case
      when refresh_status = 'Refresh Delayed' then date_diff(prev_run_utc, last_updated)
      else null
    end as delay_in_days
  from main.field_learning_enablement.job_monitoring_dwnstm_objs_mapping A
  left join job_run_vw B
    on A.job_id = B.job_id
  left join all_refresh_vw C
    on A.target_table_full_name = C.table
  left join dashboard_usage_vw D
    on A.dashboard_id=D.dashboard_id
  where not (
    (A.job_id in ('720128877239047') and A.target_table_full_name in ('main.field_learning_enablement.employee_table_new', 'main.field_learning_enablement.workday'))
    or
    (A.target_table_full_name like 'users%')
  )
  """)
final_df_gold = add_gold_metadata(final_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = final_df_gold, 
  table_name = f'{focus_database_name}.job_monitoring_base', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Alert Email for Failed Jobs

# COMMAND ----------

df_failed_jobs = spark.sql("""
    SELECT DISTINCT
        job_id,
        name,
        start_time,
        run_page_url,
        COUNT(DISTINCT target_table_full_name) AS affected_downstream_tables_count,
        COUNT(DISTINCT dashboard_id) AS affected_dashboards_count
    FROM main.field_learning_enablement.job_monitoring_base
    WHERE result_state = 'FAILED'
    GROUP BY ALL
""")

# COMMAND ----------

# Email alert logic for OKR metrics
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
import re

# Convert to Pandas
pandas_df = df_failed_jobs.toPandas()

if 'run_page_url' in pandas_df.columns:
    def make_clickable(url):
        match = re.search(r'/run/(\d+)', url)
        if match:
            run_id = match.group(1)
            return f'<a href="{url}" target="_blank">{run_id}</a>'
        else:
            return url

    pandas_df['Run ID'] = pandas_df['run_page_url'].apply(make_clickable)
    pandas_df.drop(columns=['run_page_url'], inplace=True)

pandas_df.rename(
    columns={
        'job_id': 'Job ID',
        'name': 'Job Name',
        'start_time': 'Start Time',
        'affected_downstream_tables_count': 'Downstream Tables',
        'affected_dashboards_count': 'Dashboards Impacted'
    },
    inplace=True
)

desired_order = [
    'Job Name',
    'Start Time',
    'Job ID',
    'Run ID',
    'Downstream Tables',
    'Dashboards Impacted'
]
pandas_df = pandas_df[desired_order]

flags_present = not pandas_df.empty

if flags_present:
    # Build HTML table
    html_table = pandas_df.to_html(index=False, escape=False, border=0, justify="center")

    # --- Email Body ---
    html_body = f"""
    <html>
    <head>
        <style>
            table {{
                border-collapse: collapse;
                width: 90%;
                margin: auto;
                font-family: Arial, sans-serif;
                font-size: 14px;
            }}
            th, td {{
                border: 1px solid #dddddd;
                text-align: center;
                padding: 8px;
            }}
            th {{
                background-color: #f2f2f2;
            }}
            h2 {{
                text-align: center;
                color: #c0392b;
            }}
        </style>
    </head>
    <body>
        <h2>🚨 Production Monitoring Alert</h2>
        {html_table}
    </body>
    </html>
    """

    fromaddr = 'lekshmi.s@databricks.com'
    toaddrs = ['nivetta.t@databricks.com', 'lekshmi.s@databricks.com']

    username = fromaddr
    password = "wotzoqscmytjjaui "

    smtp_server = 'smtp.gmail.com'
    smtp_port = 587

    msg = MIMEMultipart('alternative')
    msg['Subject'] = "Production Monitoring Alert"
    msg['From'] = fromaddr
    msg['To'] = ", ".join(toaddrs)
    part1 = MIMEText(html_body, 'html')
    msg.attach(part1)

    # --- Send Email ---
    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(username, password)
        server.sendmail(fromaddr, toaddrs, msg.as_string())
        server.quit()
        print("Email Sent !")
    except Exception as e:
        print(f"Failed to send email: {e}")
else:
    print("No significant changes detected. No email sent.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Final

# COMMAND ----------

# MAGIC %sql
# MAGIC with final_data as (
# MAGIC select  
# MAGIC   job_id
# MAGIC   ,name
# MAGIC   ,target_table_full_name
# MAGIC   ,result_state
# MAGIC   ,refresh_status as `Refresh Status`
# MAGIC   ,max(Count) `Count`
# MAGIC   ,max(Count_prev) `Prev Count`
# MAGIC   ,NVL(max(delay_in_days),0) `Delay in Days`
# MAGIC   ,try_divide((max(Count)-max(NVL(Count_prev,0))),max(NVL(Count_prev,0)))*100  count_incr_perc
# MAGIC  from main.field_learning_enablement.job_monitoring_base 
# MAGIC  where processdate =(select max(processDate) from main.field_learning_enablement.job_monitoring_base)
# MAGIC  group by all
# MAGIC )
# MAGIC select *,
# MAGIC  case when abs(round(count_incr_perc,2)) = 0 then 'No Change' 
# MAGIC       when abs(round(count_incr_perc,2)) >0 and abs(round(count_incr_perc,2)) <=0.5 then '0 to 0.5%'
# MAGIC       when abs(round(count_incr_perc,2)) >0.5 and abs(round(count_incr_perc,2)) <=1 then '0.5 to 1%'
# MAGIC       when abs(round(count_incr_perc,2)) >1 then "> 1%"
# MAGIC  end threshold_count_incr
# MAGIC  from final_data
# MAGIC
# MAGIC