# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC create or replace table main.field_learning_enablement.dw_migration_usecase_base as  (
# MAGIC --granularity of universe considered - usecase x snapshot x stage  
# MAGIC with cleaned_DW_universe as (
# MAGIC select distinct 
# MAGIC   cu.usecase_id
# MAGIC  ,cu.snapshot_date
# MAGIC  ,dd.fiscal_year_quarter as fiscal_year_quarter_snapshot
# MAGIC  ,cu.account_id
# MAGIC  --,cu.business_unit --Change requested by Prakash
# MAGIC  ,acct.business_unit --Change requested by Prakash
# MAGIC  ,acct.sales_subregion_level_1
# MAGIC  ,cu.target_live_fiscal_year_quarter
# MAGIC  ,cu.estimated_monthly_dbus	
# MAGIC  ,cu.estimated_monthly_dollar_dbus
# MAGIC  ,cu.implementation_partner
# MAGIC  ,case 
# MAGIC   when cu.stage in ('U1','Prospecting','Potential') and coalesce(cu.stage_number,1)=1 then 'U1'
# MAGIC   when cu.stage in ('U2', 'Validating') and coalesce(cu.stage_number,2)=2 then 'U2'
# MAGIC   when cu.stage in ('U3', 'Evaluation') and coalesce(cu.stage_number,3)=3 then 'U3'
# MAGIC   when cu.stage in ('U4')  and coalesce(cu.stage_number,4)=4 then 'U4'
# MAGIC   when cu.stage in ('U5', 'Onboarding') and coalesce(cu.stage_number,5)=5 then 'U5'
# MAGIC   when cu.stage in ('U6', 'Live') and coalesce(cu.stage_number,6)=6 then 'U6'
# MAGIC   when cu.stage in ('Lost', 'Disqualified') then cu.stage
# MAGIC   else 'Unknown' end as stage_names_new
# MAGIC  ,cu.stage_name_ui
# MAGIC from main.gtm_data.core_usecase cu
# MAGIC left join main.it_core_dim.dim_dates dd
# MAGIC         on cu.snapshot_date = dd.`date`
# MAGIC inner join main.gtm_data.core_accounts_curated as acct
# MAGIC         on cu.account_id = acct.account_id 
# MAGIC where 
# MAGIC 1=1
# MAGIC and cu.stage is not null
# MAGIC and cu.is_migration_usecase = "true"
# MAGIC and cu.use_case_product like "%DBSQL%"
# MAGIC )
# MAGIC
# MAGIC ,DW_H1 as(
# MAGIC select 
# MAGIC    usecase_id
# MAGIC   ,stage_names_new
# MAGIC   ,fiscal_year_quarter_snapshot
# MAGIC   ,min(snapshot_date) over(partition by usecase_id, stage_names_new, fiscal_year_quarter_snapshot) as min_date_in_stage_in_qtr
# MAGIC   ,max(snapshot_date) over(partition by usecase_id, stage_names_new, fiscal_year_quarter_snapshot) as max_date_in_stage_in_qtr
# MAGIC   ,case when stage_names_new in ('U2','U3','U4') then 1 else 0 end as initial_condnition_flag
# MAGIC   ,case when stage_names_new='U6' and target_live_fiscal_year_quarter=fiscal_year_quarter_snapshot then 1 else 0 end as slated_to_close_and_live_flag -- Added by Indhu
# MAGIC   ,case when stage_names_new in ('U1','U2','U3') and implementation_partner is not null then 1 else 0 end as h3_flag
# MAGIC   ,case when target_live_fiscal_year_quarter=fiscal_year_quarter_snapshot then 1 else 0 end as expected_to_close_in_qtr_flag -- Added by Indhu
# MAGIC   ,case when stage_names_new='U6' then 1 else 0 end as live_flag
# MAGIC
# MAGIC from cleaned_DW_universe
# MAGIC )
# MAGIC
# MAGIC ,DW_H1_metrics_final_grain as
# MAGIC (
# MAGIC select distinct
# MAGIC   h1.usecase_id
# MAGIC  ,h1.fiscal_year_quarter_snapshot
# MAGIC  ,sum(h1.initial_condnition_flag)  as h1_initial_condnition_flag_cum_sum
# MAGIC  ,sum(h1.live_flag)  as h1_live_flag_cum_sum
# MAGIC  ,sum(h1.expected_to_close_in_qtr_flag) as slated_to_close_flag_cum_sum -- Added by Indhu
# MAGIC  ,sum(h1.slated_to_close_and_live_flag) as slated_to_close_and_closed_flag_cum_sum -- Added by Indhu
# MAGIC  ,sum(h1.h3_flag) as h3_flag_cum_sum   
# MAGIC  from DW_H1 h1
# MAGIC  group by
# MAGIC   h1.usecase_id
# MAGIC  ,h1.fiscal_year_quarter_snapshot     
# MAGIC )
# MAGIC
# MAGIC ,DW_H2 as(
# MAGIC select distinct
# MAGIC    h1.usecase_id
# MAGIC   ,h1.fiscal_year_quarter_snapshot
# MAGIC
# MAGIC   ,u1.min_date_in_stage_in_qtr as u1_min_date_in_stage_in_qtr
# MAGIC   ,u1.max_date_in_stage_in_qtr as u1_max_date_in_stage_in_qtr
# MAGIC   ,datediff(u1.max_date_in_stage_in_qtr, u1.min_date_in_stage_in_qtr) as u1_days_in_stage_in_qtr
# MAGIC
# MAGIC   ,u2.min_date_in_stage_in_qtr as u2_min_date_in_stage_in_qtr
# MAGIC   ,u2.max_date_in_stage_in_qtr as u2_max_date_in_stage_in_qtr
# MAGIC   ,datediff(u2.max_date_in_stage_in_qtr, u2.min_date_in_stage_in_qtr) as u2_days_in_stage_in_qtr
# MAGIC
# MAGIC   ,u3.min_date_in_stage_in_qtr as u3_min_date_in_stage_in_qtr
# MAGIC   ,u3.max_date_in_stage_in_qtr as u3_max_date_in_stage_in_qtr
# MAGIC   ,datediff(u3.max_date_in_stage_in_qtr, u3.min_date_in_stage_in_qtr) as u3_days_in_stage_in_qtr
# MAGIC
# MAGIC   ,u4.min_date_in_stage_in_qtr as u4_min_date_in_stage_in_qtr
# MAGIC   ,u4.max_date_in_stage_in_qtr as u4_max_date_in_stage_in_qtr
# MAGIC   ,datediff(u4.max_date_in_stage_in_qtr, u4.min_date_in_stage_in_qtr) as u4_days_in_stage_in_qtr
# MAGIC
# MAGIC   ,u5.min_date_in_stage_in_qtr as u5_min_date_in_stage_in_qtr
# MAGIC   ,u5.max_date_in_stage_in_qtr as u5_max_date_in_stage_in_qtr
# MAGIC   ,datediff(u5.max_date_in_stage_in_qtr, u5.min_date_in_stage_in_qtr) as u5_days_in_stage_in_qtr
# MAGIC
# MAGIC   ,u6.min_date_in_stage_in_qtr as u6_min_date_in_stage_in_qtr
# MAGIC   ,u6.max_date_in_stage_in_qtr as u6_max_date_in_stage_in_qtr
# MAGIC   ,datediff(u6.max_date_in_stage_in_qtr, u6.min_date_in_stage_in_qtr) as u6_days_in_stage_in_qtr
# MAGIC
# MAGIC   ,case when  
# MAGIC         coalesce(u5.min_date_in_stage_in_qtr,u4.min_date_in_stage_in_qtr) > 
# MAGIC         coalesce(u3.max_date_in_stage_in_qtr,u2.max_date_in_stage_in_qtr,u1.max_date_in_stage_in_qtr) 
# MAGIC         then 
# MAGIC         datediff(least(coalesce(u5.min_date_in_stage_in_qtr,u4.min_date_in_stage_in_qtr),
# MAGIC                        coalesce(u4.min_date_in_stage_in_qtr,u5.min_date_in_stage_in_qtr))
# MAGIC                 ,greatest(coalesce(u3.min_date_in_stage_in_qtr,u2.min_date_in_stage_in_qtr,u1.min_date_in_stage_in_qtr),
# MAGIC                           coalesce(u2.min_date_in_stage_in_qtr,u3.min_date_in_stage_in_qtr,u1.min_date_in_stage_in_qtr),
# MAGIC                           coalesce(u1.min_date_in_stage_in_qtr,u3.min_date_in_stage_in_qtr,u2.min_date_in_stage_in_qtr)))       
# MAGIC         else null 
# MAGIC         end as days_h2
# MAGIC from DW_H1 h1
# MAGIC left join DW_H1 u1
# MAGIC         on  h1.usecase_id = u1.usecase_id
# MAGIC         and h1.fiscal_year_quarter_snapshot = u1.fiscal_year_quarter_snapshot
# MAGIC         and u1.stage_names_new = 'U1'
# MAGIC left join DW_H1 u2
# MAGIC         on  h1.usecase_id = u2.usecase_id
# MAGIC         and h1.fiscal_year_quarter_snapshot = u2.fiscal_year_quarter_snapshot
# MAGIC         and u2.stage_names_new = 'U2'
# MAGIC left join DW_H1 u3
# MAGIC         on  h1.usecase_id = u3.usecase_id
# MAGIC         and h1.fiscal_year_quarter_snapshot = u3.fiscal_year_quarter_snapshot
# MAGIC         and u3.stage_names_new = 'U3'
# MAGIC left join DW_H1 u4
# MAGIC         on  h1.usecase_id = u4.usecase_id
# MAGIC         and h1.fiscal_year_quarter_snapshot = u4.fiscal_year_quarter_snapshot
# MAGIC         and u4.stage_names_new = 'U4'
# MAGIC left join DW_H1 u5
# MAGIC         on  h1.usecase_id = u5.usecase_id
# MAGIC         and h1.fiscal_year_quarter_snapshot = u5.fiscal_year_quarter_snapshot
# MAGIC         and u5.stage_names_new = 'U5'
# MAGIC left join DW_H1 u6
# MAGIC         on  h1.usecase_id = u6.usecase_id
# MAGIC         and h1.fiscal_year_quarter_snapshot = u6.fiscal_year_quarter_snapshot
# MAGIC         and u6.stage_names_new = 'U6'
# MAGIC )
# MAGIC
# MAGIC -- -------------Comments for Indhu/Lekshmi's ref:
# MAGIC -- What each field tells us:
# MAGIC -- h1_live_flag_cum_sum - If the usecase was slated to close in the qtr and actully did close in the qtr
# MAGIC -- h1_initial_condnition_flag_cum_sum - if the usecase was in in ('U2','U3','U4') during the qtr
# MAGIC -- h3_flag_cum_sum - if the usecase had a implimentation partner attached and was in ('U1','U2','U3') during the qtr
# MAGIC
# MAGIC -- Measure H1 - h1_initial_condnition_flag_cum_sum>=1 and h1_live_flag_cum_sum>=1
# MAGIC -- Measure H3 - h3_flag_cum_sum>=1 and h1_live_flag_cum_sum>=1 
# MAGIC -- Measure H2 - Use days_h2 --Need to get rid of negetive values - happens when the commit has overlapping stages
# MAGIC
# MAGIC -- Granularities to keep in mind
# MAGIC -- -- DW_H1
# MAGIC -- -- on usecase stage and qtr
# MAGIC -- -- common across usecase stage and qtr
# MAGIC -- -- DW_H2
# MAGIC -- -- use case and qtr
# MAGIC -- -- common across usecase x snapshot qtr
# MAGIC
# MAGIC ---Potential Dataset for BI Use - Use descretion and the query commented below to tweak as needed. 
# MAGIC ,dedup_cleaned_DW_universe as 
# MAGIC (
# MAGIC select
# MAGIC   clean.usecase_id
# MAGIC  ,clean.fiscal_year_quarter_snapshot
# MAGIC  ,clean.business_unit 
# MAGIC  ,clean.sales_subregion_level_1 
# MAGIC  ,clean.estimated_monthly_dollar_dbus  
# MAGIC  ,row_number() over (partition by clean.usecase_id,fiscal_year_quarter_snapshot order by clean.snapshot_date desc nulls last) rn
# MAGIC from cleaned_DW_universe clean 
# MAGIC qualify rn=1
# MAGIC ) 
# MAGIC
# MAGIC
# MAGIC
# MAGIC select distinct 
# MAGIC   clean.usecase_id
# MAGIC  ,clean.fiscal_year_quarter_snapshot
# MAGIC  ,clean.business_unit -- can duplicate and have nulls (1:many)
# MAGIC  ,clean.sales_subregion_level_1 -- can duplicate and have nulls (1:many)
# MAGIC  ,clean.estimated_monthly_dollar_dbus -- assuming this is the value of the usecase in $, can have multiple values for given usecase, needs to be summed.
# MAGIC  ,case when h1.h1_initial_condnition_flag_cum_sum>=1 and h1.h1_live_flag_cum_sum>=1 and h1.slated_to_close_flag_cum_sum >=1 then 1 else 0 end as h1_flag
# MAGIC  , case when h1.h1_initial_condnition_flag_cum_sum>=1 and h1.slated_to_close_flag_cum_sum >=1 then 1 else 0 end as slated_to_close_flag --Added by Indhu
# MAGIC  , case when h1.h1_initial_condnition_flag_cum_sum>=1 and h1.h1_live_flag_cum_sum>=1 and h1.slated_to_close_flag_cum_sum <1 then 1 else 0 end as closed_but_not_slated_flag -- Added by Indhu
# MAGIC  ,case when h1.h3_flag_cum_sum>=1 and h1.h1_live_flag_cum_sum>=1 then 1 else 0 end as h3_flag
# MAGIC  ,h2.days_h2 as h2_Days
# MAGIC  ,h2.u1_days_in_stage_in_qtr
# MAGIC  ,h2.u1_min_date_in_stage_in_qtr
# MAGIC  ,h2.u1_max_date_in_stage_in_qtr
# MAGIC  ,h2.u2_days_in_stage_in_qtr
# MAGIC  ,h2.u2_min_date_in_stage_in_qtr
# MAGIC  ,h2.u2_max_date_in_stage_in_qtr
# MAGIC  ,h2.u3_days_in_stage_in_qtr
# MAGIC  ,h2.u3_min_date_in_stage_in_qtr
# MAGIC  ,h2.u3_max_date_in_stage_in_qtr
# MAGIC  ,h2.u4_days_in_stage_in_qtr
# MAGIC  ,h2.u4_min_date_in_stage_in_qtr
# MAGIC  ,h2.u4_max_date_in_stage_in_qtr
# MAGIC  ,h2.u5_days_in_stage_in_qtr
# MAGIC  ,h2.u5_min_date_in_stage_in_qtr
# MAGIC  ,h2.u5_max_date_in_stage_in_qtr
# MAGIC  ,h2.u6_days_in_stage_in_qtr
# MAGIC  ,h2.u6_min_date_in_stage_in_qtr
# MAGIC  ,h2.u6_max_date_in_stage_in_qtr
# MAGIC from dedup_cleaned_DW_universe clean 
# MAGIC left join DW_H1_metrics_final_grain h1
# MAGIC         on clean.usecase_id = h1.usecase_id
# MAGIC         and clean.fiscal_year_quarter_snapshot = h1.fiscal_year_quarter_snapshot
# MAGIC left join DW_H2 h2
# MAGIC         on clean.usecase_id = h2.usecase_id
# MAGIC         and clean.fiscal_year_quarter_snapshot = h2.fiscal_year_quarter_snapshot
# MAGIC )
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# %sql
# with cleaned_DW_universe as (
# select distinct 
#   cu.usecase_id
#  ,cu.snapshot_date
#  ,dd.fiscal_year_quarter as fiscal_year_quarter_snapshot
#  ,cu.account_id
#  ,cu.business_unit
#  ,acct.sales_subregion_level_1
#  ,cu.target_live_fiscal_year_quarter
#  ,cu.estimated_monthly_dbus	
#  ,cu.estimated_monthly_dollar_dbus
#  ,cu.implementation_partner
#  ,case 
#   when cu.stage in ('U1','Prospecting','Potential') and coalesce(cu.stage_number,1)=1 then 'U1'
#   when cu.stage in ('U2', 'Validating') and coalesce(cu.stage_number,2)=2 then 'U2'
#   when cu.stage in ('U3', 'Evaluation') and coalesce(cu.stage_number,3)=3 then 'U3'
#   when cu.stage in ('U4')  and coalesce(cu.stage_number,4)=4 then 'U4'
#   when cu.stage in ('U5', 'Onboarding') and coalesce(cu.stage_number,5)=5 then 'U5'
#   when cu.stage in ('U6', 'Live') and coalesce(cu.stage_number,6)=6 then 'U6'
#   when cu.stage in ('Lost', 'Disqualified') then cu.stage
#   else 'Unknown' end as stage_names_new
#  ,cu.stage_name_ui
# from main.gtm_data.core_usecase cu
# left join main.it_core_dim.dim_dates dd
#         on cu.snapshot_date = dd.`date`
# inner join main.gtm_data.core_accounts_curated as acct
#         on cu.account_id = acct.account_id 
# where 
# 1=1
# and cu.stage is not null
# and cu.is_migration_usecase = "true"
# and cu.use_case_product like "%DBSQL%"
# )

# ,DW_H1 as(
# select 
#    usecase_id
#   ,stage_names_new
#   ,fiscal_year_quarter_snapshot
#   ,min(snapshot_date) over(partition by usecase_id, stage_names_new, fiscal_year_quarter_snapshot) as min_date_in_stage_in_qtr
#   ,max(snapshot_date) over(partition by usecase_id, stage_names_new, fiscal_year_quarter_snapshot) as max_date_in_stage_in_qtr
#   ,case when stage_names_new in ('U2','U3','U4') then 1 else 0 end as initial_condnition_flag
#   ,case when stage_names_new='U6' and target_live_fiscal_year_quarter=fiscal_year_quarter_snapshot then 1 else 0 end as live_flag
#   ,case when stage_names_new in ('U1','U2','U3') and implementation_partner is not null then 1 else 0 end as h3_flag
# from cleaned_DW_universe
# )

# ,DW_H1_metrics_final_grain as
# (
# select distinct
#   h1.usecase_id
#  ,h1.fiscal_year_quarter_snapshot
#  ,sum(h1.initial_condnition_flag)  as h1_initial_condnition_flag_cum_sum
#  ,sum(h1.live_flag)  as h1_live_flag_cum_sum
#  ,sum(h1.h3_flag) as h3_flag_cum_sum   
#  from DW_H1 h1
#  group by
#   h1.usecase_id
#  ,h1.fiscal_year_quarter_snapshot     
# )

# ,DW_H2 as(
# select distinct
#    h1.usecase_id
#   ,h1.fiscal_year_quarter_snapshot

#   ,u1.min_date_in_stage_in_qtr as u1_min_date_in_stage_in_qtr
#   ,u1.max_date_in_stage_in_qtr as u1_max_date_in_stage_in_qtr
#   ,datediff(u1.max_date_in_stage_in_qtr, u1.min_date_in_stage_in_qtr) as u1_days_in_stage_in_qtr

#   ,u2.min_date_in_stage_in_qtr as u2_min_date_in_stage_in_qtr
#   ,u2.max_date_in_stage_in_qtr as u2_max_date_in_stage_in_qtr
#   ,datediff(u2.max_date_in_stage_in_qtr, u2.min_date_in_stage_in_qtr) as u2_days_in_stage_in_qtr

#   ,u3.min_date_in_stage_in_qtr as u3_min_date_in_stage_in_qtr
#   ,u3.max_date_in_stage_in_qtr as u3_max_date_in_stage_in_qtr
#   ,datediff(u3.max_date_in_stage_in_qtr, u3.min_date_in_stage_in_qtr) as u3_days_in_stage_in_qtr

#   ,u4.min_date_in_stage_in_qtr as u4_min_date_in_stage_in_qtr
#   ,u4.max_date_in_stage_in_qtr as u4_max_date_in_stage_in_qtr
#   ,datediff(u4.max_date_in_stage_in_qtr, u4.min_date_in_stage_in_qtr) as u4_days_in_stage_in_qtr

#   ,u5.min_date_in_stage_in_qtr as u5_min_date_in_stage_in_qtr
#   ,u5.max_date_in_stage_in_qtr as u5_max_date_in_stage_in_qtr
#   ,datediff(u5.max_date_in_stage_in_qtr, u5.min_date_in_stage_in_qtr) as u5_days_in_stage_in_qtr

#   ,u6.min_date_in_stage_in_qtr as u6_min_date_in_stage_in_qtr
#   ,u6.max_date_in_stage_in_qtr as u6_max_date_in_stage_in_qtr
#   ,datediff(u6.max_date_in_stage_in_qtr, u6.min_date_in_stage_in_qtr) as u6_days_in_stage_in_qtr

#   ,case when  
#         coalesce(u5.min_date_in_stage_in_qtr,u4.min_date_in_stage_in_qtr) > 
#         coalesce(u3.max_date_in_stage_in_qtr,u2.max_date_in_stage_in_qtr,u1.max_date_in_stage_in_qtr) 
#         then 
#         datediff(least(coalesce(u5.min_date_in_stage_in_qtr,u4.min_date_in_stage_in_qtr),
#                        coalesce(u4.min_date_in_stage_in_qtr,u5.min_date_in_stage_in_qtr))
#                 ,greatest(coalesce(u3.min_date_in_stage_in_qtr,u2.min_date_in_stage_in_qtr,u1.min_date_in_stage_in_qtr),
#                           coalesce(u2.min_date_in_stage_in_qtr,u3.min_date_in_stage_in_qtr,u1.min_date_in_stage_in_qtr),
#                           coalesce(u1.min_date_in_stage_in_qtr,u3.min_date_in_stage_in_qtr,u2.min_date_in_stage_in_qtr)))       
#         else null 
#         end as days_h2
# from DW_H1 h1
# left join DW_H1 u1
#         on  h1.usecase_id = u1.usecase_id
#         and h1.fiscal_year_quarter_snapshot = u1.fiscal_year_quarter_snapshot
#         and u1.stage_names_new = 'U1'
# left join DW_H1 u2
#         on  h1.usecase_id = u2.usecase_id
#         and h1.fiscal_year_quarter_snapshot = u2.fiscal_year_quarter_snapshot
#         and u2.stage_names_new = 'U2'
# left join DW_H1 u3
#         on  h1.usecase_id = u3.usecase_id
#         and h1.fiscal_year_quarter_snapshot = u3.fiscal_year_quarter_snapshot
#         and u3.stage_names_new = 'U3'
# left join DW_H1 u4
#         on  h1.usecase_id = u4.usecase_id
#         and h1.fiscal_year_quarter_snapshot = u4.fiscal_year_quarter_snapshot
#         and u4.stage_names_new = 'U4'
# left join DW_H1 u5
#         on  h1.usecase_id = u5.usecase_id
#         and h1.fiscal_year_quarter_snapshot = u5.fiscal_year_quarter_snapshot
#         and u5.stage_names_new = 'U5'
# left join DW_H1 u6
#         on  h1.usecase_id = u6.usecase_id
#         and h1.fiscal_year_quarter_snapshot = u6.fiscal_year_quarter_snapshot
#         and u4.stage_names_new = 'U6'
# )

# -- -------------Comments for Indhu/Lekshmi's ref:
# -- What each field tells us:
# -- h1_live_flag_cum_sum - If the usecase was slated to close in the qtr and actully did close in the qtr
# -- h1_initial_condnition_flag_cum_sum - if the usecase was in in ('U2','U3','U4') during the qtr
# -- h3_flag_cum_sum - if the usecase had a implimentation partner attached and was in ('U1','U2','U3') during the qtr

# -- Measure H1 - h1_initial_condnition_flag_cum_sum>=1 and h1_live_flag_cum_sum>=1
# -- Measure H3 - h3_flag_cum_sum>=1 and h1_live_flag_cum_sum>=1 
# -- Measure H2 - Use days_h2 --Need to get rid of negetive values - happens when the commit has overlapping stages

# -- Granularities to keep in mind
# -- -- DW_H1
# -- -- on usecase stage and qtr
# -- -- common across usecase stage and qtr
# -- -- DW_H2
# -- -- use case and qtr
# -- -- common across usecase x snapshot qtr

# ---Potential Dataset for BI Use - Use descretion and the query commented below to tweak as needed. 
# ,dedup_cleaned_DW_universe as 
# (
# select
#   clean.usecase_id
#  ,clean.fiscal_year_quarter_snapshot
#  ,clean.business_unit 
#  ,clean.sales_subregion_level_1 
#  ,clean.estimated_monthly_dollar_dbus  
#  ,row_number() over (partition by clean.usecase_id,fiscal_year_quarter_snapshot order by clean.snapshot_date desc nulls last) rn
# from cleaned_DW_universe clean 
# qualify rn=1
# )  


# select distinct 
#   clean.usecase_id
#  ,clean.fiscal_year_quarter_snapshot
#  ,clean.business_unit -- can duplicate and have nulls (1:many)
#  ,clean.sales_subregion_level_1 -- can duplicate and have nulls (1:many)
#  ,clean.estimated_monthly_dollar_dbus -- assuming this is the value of the usecase in $, can have multiple values for given usecase, needs to be summed.
#  ,case when h1.h1_initial_condnition_flag_cum_sum>=1 and h1.h1_live_flag_cum_sum>=1 then 1 else 0 end as h1_flag
#  ,case when h1.h3_flag_cum_sum>=1 and h1.h1_live_flag_cum_sum>=1 then 1 else 0 end as h3_flag
#  ,h2.days_h2 as h2_Days
#  ,h2.u1_days_in_stage_in_qtr
#  ,h2.u1_min_date_in_stage_in_qtr
#  ,h2.u1_max_date_in_stage_in_qtr
#  ,h2.u2_days_in_stage_in_qtr
#  ,h2.u2_min_date_in_stage_in_qtr
#  ,h2.u2_max_date_in_stage_in_qtr
#  ,h2.u3_days_in_stage_in_qtr
#  ,h2.u3_min_date_in_stage_in_qtr
#  ,h2.u3_max_date_in_stage_in_qtr
#  ,h2.u4_days_in_stage_in_qtr
#  ,h2.u4_min_date_in_stage_in_qtr
#  ,h2.u4_max_date_in_stage_in_qtr
#  ,h2.u5_days_in_stage_in_qtr
#  ,h2.u5_min_date_in_stage_in_qtr
#  ,h2.u5_max_date_in_stage_in_qtr
#  ,h2.u6_days_in_stage_in_qtr
#  ,h2.u6_min_date_in_stage_in_qtr
#  ,h2.u6_max_date_in_stage_in_qtr
# from cleaned_DW_universe clean 
# left join DW_H1_metrics_final_grain h1
#         on clean.usecase_id = h1.usecase_id
#         and clean.fiscal_year_quarter_snapshot = h1.fiscal_year_quarter_snapshot
# left join DW_H2 h2
#         on clean.usecase_id = h2.usecase_id
#         and clean.fiscal_year_quarter_snapshot = h2.fiscal_year_quarter_snapshot

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC --QC for dups in the base table
# MAGIC select distinct usecase_id,fiscal_year_quarter_snapshot,estimated_monthly_dollar_dbus,business_unit,count(*)  
# MAGIC from field_learning_enablement.dw_migration_usecase_base 
# MAGIC where business_unit is not null
# MAGIC and sales_subregion_level_1 is not null
# MAGIC group by usecase_id,fiscal_year_quarter_snapshot,estimated_monthly_dollar_dbus,business_unit
# MAGIC having count(*)>1

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct *
# MAGIC from field_learning_enablement.dw_migration_usecase_base 
# MAGIC where usecase_id = 'aAvVp0000006I77KAE' and fiscal_year_quarter_snapshot = "FY'25 Q3"