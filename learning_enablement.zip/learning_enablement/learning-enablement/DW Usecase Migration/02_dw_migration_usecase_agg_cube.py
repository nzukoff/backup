# Databricks notebook source
# MAGIC %md
# MAGIC %md
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] smart-commit-dashboard-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Lekshmi S \
# MAGIC **Source(s):**      main.field_learning_enablement.dw_migration_usecase_base   \
# MAGIC **Target:**          main.field_learning_enablement.dw_migration_usecase_agg_cube \
# MAGIC **Description:**     The following notebook creates an aggregate cube of all dimensions for  Amount and Usecase Count. This will be leveraged in DW Migration Dashboard. The final dataset is created as a union of amount dataset and usecase_count dataset which are distinguished using the column group_value (Amount:group_value=0 , Usecase Count:group_value=1)\
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

import time
from delta.tables import *
from datetime import date, datetime
import logging

logging.basicConfig(format="%(asctime)-15s %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def write_delta_table(
    spark,
    dataframe,
    table_name,
    format="delta",
    mode="overwrite",
    overwrite_schema="true",
    merge_schema="true",
    optimize=True,
    partition_column=None,
    zorder=None,
    replace_where=None,
    location=None,
):

    num_rows = dataframe.count()
    logger_statement = """Written the dataframe. Please look at the stats:
                          Details:
                          - Table Name: {0} 
                          - Total time spent: {1} minutes
                          - Write Options:
                            - format: {2}
                            - mode: {3}
                            - optimize: {4}
                            - zorder: {5}
                            - partition by: {6}
                            - replace where: {7}
                            - location: {8}
                            - Schema Options:
                                - overwrite schema: {9}
                                - merge schema: {10}
                          - Written rows:  {11}
                       """
    logger.info("Writting the table {0}".format(table_name))
    start_time = time.time()
    write_instructions = (
        dataframe.write.format(format)
        .mode(mode)
        .option("overwriteSchema", overwrite_schema)
        .option("mergeSchema", merge_schema)
    )

    if partition_column is not None:
        write_instructions = write_instructions.partitionBy(partition_column)

    if replace_where is not None:
        write_instructions = write_instructions.option("replaceWhere", replace_where)

    write_instructions.saveAsTable(table_name)
    write_time = time.time()

    if optimize:
        logger.info("Running optimize the delta table now")
        start = time.time()
        optimize_instructions = "OPTIMIZE " + table_name
        if replace_where is not None:
            logger.info("Replacing the delta table according to where clause now")
            optimize_instructions += " WHERE " + replace_where
            if zorder:
                optimize_instructions += " ZORDER BY " + zorder
                spark.sql(optimize_instructions)
        logger.info(
            "Optimized in {} minutes.".format(
                str(round((time.time() - write_time) / 60, 1))
            )
        )

    logger.info(
        logger_statement.format(
            table_name,
            round((write_time - start_time) / 60, 1),
            format,
            mode,
            optimize,
            zorder,
            partition_column,
            replace_where,
            location,
            overwrite_schema,
            merge_schema,
            num_rows,
        )
    )

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
import json
import requests
from pprint import pprint
from urllib.parse import quote_plus as urlencode
import pandas as pd

from pyspark.sql.functions import sum as _sum
from pyspark.sql.functions import lit

# COMMAND ----------

focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

# COMMAND ----------

#from focus_databricks.common.date_utils import *
#from focus_databricks.koda.table_utils import *
#from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W

# COMMAND ----------

# MAGIC %md
# MAGIC Parameters Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values.
# MAGIC
# MAGIC Create as many as makes sense for your notebook For [param key/name], substitute the specific parameter name that you want, ex: target_database For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement Once the parameter widgets are defined, import the parameter values to local variables using try/except

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

source_table='main.field_learning_enablement.dw_migration_usecase_base' #Edited by Indhu
#source_table='users.lekshmi_s.smart_commits_base'
#focus_database_name='users.lekshmi_s'

# COMMAND ----------

# MAGIC %md
# MAGIC **Usecase Count**
# MAGIC The group_value=1

# COMMAND ----------

spark.sql(f"""
SELECT distinct 
  NVL(business_unit,'') business_unit
  ,NVL(sales_subregion_level_1,'') sales_subregion_level_1
  ,fy_qr.fiscal_year_quarter_snapshot
  ,fy_qr.fiscal_year_quarter_snapshot_mod
FROM {source_table}
CROSS JOIN 
  (SELECT distinct fiscal_year_quarter fiscal_year_quarter_snapshot
  ,SUBSTRING(fiscal_year_quarter, 7, 2)||SUBSTRING(fiscal_year_quarter, 0, 5) fiscal_year_quarter_snapshot_mod
  FROM main.it_core_dim.dim_dates where fiscal_year_quarter >="FY'22 Q4") fy_qr

  WHERE business_unit is not null and fy_qr.fiscal_year_quarter_snapshot<=(select max(fiscal_year_quarter_snapshot) from {source_table})
""").createOrReplaceTempView("all_combination_of_dimension")

# COMMAND ----------

spark.sql(f"""
SELECT
  NVL(business_unit,'') business_unit
  ,NVL(sales_subregion_level_1,'') sales_subregion_level_1
  ,usecase_id
  ,h1_flag
  ,h3_flag
  ,h2_Days
  ,slated_to_close_flag
  ,closed_but_not_slated_flag
  ,estimated_monthly_dollar_dbus
  ,fiscal_year_quarter_snapshot
FROM {source_table}
WHERE fiscal_year_quarter_snapshot is not null
""").createOrReplaceTempView("alldata")

# COMMAND ----------

spark.sql("""
SELECT 
  fiscal_year_quarter_snapshot
  ,business_unit
  ,sales_subregion_level_1

  ,count(distinct usecase_id) as total_usecases 
  ,count(distinct (case when h1_flag=1 then usecase_id end)) as h1_kpi
  ,count(distinct (case when h3_flag=1 then usecase_id end)) as h3_kpi
  ,count(distinct (case when slated_to_close_flag=1 then usecase_id end)) as slated_to_close_kpi
  ,count(distinct (case when closed_but_not_slated_flag=1 then usecase_id end)) as closed_but_not_slated_kpi
  ,count(distinct (case when h2_Days is not null then usecase_id end)) as h2_total_usecases
  ,sum(case when h2_Days >= 0 then h2_Days end) sum_h2_days_gte0
  ,count (distinct case when h2_Days >= 0 then usecase_id end) as count_h2_days_gte0

 FROM alldata 
 WHERE fiscal_year_quarter_snapshot is not null
 GROUP BY ALL
 """).createOrReplaceTempView("aggregate_by_quarter_cnt")

# COMMAND ----------

spark.sql ("""
SELECT 
  all_combination_of_dimension.*
  ,agg.total_usecases
  ,agg.h1_kpi
  ,agg.h3_kpi
  ,agg.slated_to_close_kpi
  ,agg.closed_but_not_slated_kpi
  ,agg.h2_total_usecases
  ,agg.sum_h2_days_gte0
  ,agg.count_h2_days_gte0
FROM all_combination_of_dimension 
LEFT OUTER JOIN aggregate_by_quarter_cnt agg
ON 
  all_combination_of_dimension.fiscal_year_quarter_snapshot=agg.fiscal_year_quarter_snapshot
  and all_combination_of_dimension.business_unit=agg.business_unit
  and all_combination_of_dimension.sales_subregion_level_1=agg.sales_subregion_level_1
WHERE all_combination_of_dimension.fiscal_year_quarter_snapshot is not null
"""
).createOrReplaceTempView("joined_data_with_all_combination_of_dimension_cnt")

# COMMAND ----------

spark.sql("""
SELECT 
  fiscal_year_quarter_snapshot
  ,fiscal_year_quarter_snapshot_mod
  ,business_unit
  ,sales_subregion_level_1
  

  ,total_usecases
  ,LAG(total_usecases) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) total_usecases_prev_qtr
  ,LAG(total_usecases) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) total_usecases_prev_year

  ,h1_kpi
  ,LAG(h1_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) h1_kpi_prev_qtr
  ,LAG(h1_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) h1_kpi_prev_year

  ,h3_kpi
  ,LAG(h3_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) h3_kpi_prev_qtr
  ,LAG(h3_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) h3_kpi_prev_year

  ,slated_to_close_kpi
  ,LAG(slated_to_close_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) slated_to_close_kpi_prev_qtr
  ,LAG(slated_to_close_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) slated_to_close_kpi_prev_year
  
  ,closed_but_not_slated_kpi
  ,LAG(closed_but_not_slated_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) closed_but_not_slated_kpi_prev_qtr
  ,LAG(closed_but_not_slated_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) closed_but_not_slated_kpi_prev_year
  

  ,h2_total_usecases
  ,LAG(h2_total_usecases) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) h2_total_usecases_prev_qtr
  ,LAG(h2_total_usecases) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) h2_total_usecases_prev_year


  ,sum_h2_days_gte0
  ,LAG(sum_h2_days_gte0) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) sum_h2_days_gte0_prev_qtr
  ,LAG(sum_h2_days_gte0) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) sum_h2_days_gte0_prev_year

  ,count_h2_days_gte0
  ,LAG(count_h2_days_gte0) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) count_h2_days_gte0_prev_qtr
  ,LAG(count_h2_days_gte0) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) count_h2_days_gte0_prev_year

 FROM joined_data_with_all_combination_of_dimension_cnt 
 WHERE fiscal_year_quarter_snapshot is not null
 
""").createOrReplaceTempView("data_with_previous_values_cnt")

# COMMAND ----------

query_usecase_cnt="""
  SELECT DISTINCT
  fiscal_year_quarter_snapshot
  ,fiscal_year_quarter_snapshot_mod
  ,business_unit
  ,sales_subregion_level_1

  ,total_usecases
  ,total_usecases_prev_qtr
  ,total_usecases_prev_year

  ,h1_kpi
  ,h1_kpi_prev_qtr
  ,h1_kpi_prev_year

  ,h3_kpi
  ,h3_kpi_prev_qtr
  ,h3_kpi_prev_year

  ,slated_to_close_kpi
  ,slated_to_close_kpi_prev_qtr
  ,slated_to_close_kpi_prev_year

  ,closed_but_not_slated_kpi
  ,closed_but_not_slated_kpi_prev_qtr
  ,closed_but_not_slated_kpi_prev_year

  ,h2_total_usecases
  ,h2_total_usecases_prev_qtr
  ,h2_total_usecases_prev_year

  ,sum_h2_days_gte0
  ,sum_h2_days_gte0_prev_qtr
  ,sum_h2_days_gte0_prev_year

  ,count_h2_days_gte0
  ,count_h2_days_gte0_prev_qtr
  ,count_h2_days_gte0_prev_year
FROM data_with_previous_values_cnt"""

df_cnt=spark.sql(query_usecase_cnt)

# COMMAND ----------

# MAGIC %md
# MAGIC **Creating a cube of all combination of dimensions**

# COMMAND ----------


# Apply cube() to aggregate the data
df_cube_cnt = df_cnt.cube(
  "business_unit"
  ,"fiscal_year_quarter_snapshot"
  ,"sales_subregion_level_1"
)\
.agg(\
  _sum("total_usecases").alias("total_usecases"), 
  _sum("total_usecases_prev_qtr").alias("total_usecases_prev_qtr"),
  _sum("total_usecases_prev_year").alias("total_usecases_prev_year"),

  _sum("h1_kpi").alias("h1_kpi"), 
  _sum("h1_kpi_prev_qtr").alias("h1_kpi_prev_qtr"),
  _sum("h1_kpi_prev_year").alias("h1_kpi_prev_year"),

  _sum("h3_kpi").alias("h3_kpi"),
  _sum("h3_kpi_prev_qtr").alias("h3_kpi_prev_qtr"),
  _sum("h3_kpi_prev_year").alias("h3_kpi_prev_year"),

  _sum("slated_to_close_kpi").alias("slated_to_close_kpi"),
  _sum("slated_to_close_kpi_prev_qtr").alias("slated_to_close_kpi_prev_qtr"),
  _sum("slated_to_close_kpi_prev_year").alias("slated_to_close_kpi_prev_year"),

  _sum("closed_but_not_slated_kpi").alias("closed_but_not_slated_kpi"),
  _sum("closed_but_not_slated_kpi_prev_qtr").alias("closed_but_not_slated_kpi_prev_qtr"),
  _sum("closed_but_not_slated_kpi_prev_year").alias("closed_but_not_slated_kpi_prev_year"),

  _sum("h2_total_usecases").alias("h2_total_usecases"),
  _sum("h2_total_usecases_prev_qtr").alias("h2_total_usecases_prev_qtr"),
  _sum("h2_total_usecases_prev_year").alias("h2_total_usecases_prev_year"), 

  _sum("sum_h2_days_gte0").alias("sum_h2_days_gte0"),
  _sum("sum_h2_days_gte0_prev_qtr").alias("sum_h2_days_gte0_prev_qtr"),
  _sum("sum_h2_days_gte0_prev_year").alias("sum_h2_days_gte0_prev_year"), 

  _sum("count_h2_days_gte0").alias("count_h2_days_gte0"),
  _sum("count_h2_days_gte0_prev_qtr").alias("count_h2_days_gte0_prev_qtr"),
  _sum("count_h2_days_gte0_prev_year").alias("count_h2_days_gte0_prev_year"), )


df_cube_transformed_cnt=\
df_cube_cnt\
  .filter("fiscal_year_quarter_snapshot is not null")\
  .withColumn("group_value",lit(1))\
  .withColumn("processDate", F.current_timestamp())\
  .na.fill('All')

# COMMAND ----------

# MAGIC %md
# MAGIC **Usecase Amt** 
# MAGIC The group_value=0

# COMMAND ----------

spark.sql("""
SELECT 
  fiscal_year_quarter_snapshot
  ,business_unit
  ,sales_subregion_level_1

  ,sum(estimated_monthly_dollar_dbus) as total_usecases 
  ,sum(distinct (case when h1_flag=1 then estimated_monthly_dollar_dbus end)) as h1_kpi
  ,sum(distinct (case when h3_flag=1 then estimated_monthly_dollar_dbus end)) as h3_kpi
  ,sum(distinct (case when slated_to_close_flag=1 then estimated_monthly_dollar_dbus end)) as slated_to_close_kpi
  ,sum(distinct (case when closed_but_not_slated_flag=1 then estimated_monthly_dollar_dbus end)) as closed_but_not_slated_kpi
  ,sum(distinct (case when h2_Days is not null then estimated_monthly_dollar_dbus end)) as h2_total_usecases
  ,sum(case when h2_Days >= 0 then h2_Days end) sum_h2_days_gte0
  ,count (distinct case when h2_Days >= 0 then usecase_id end) as count_h2_days_gte0

 FROM alldata 
 WHERE fiscal_year_quarter_snapshot is not null
 GROUP BY ALL
 """).createOrReplaceTempView("aggregate_by_quarter_amt")

# COMMAND ----------

spark.sql ("""
SELECT 
  all_combination_of_dimension.*
  ,agg.total_usecases
  ,agg.h1_kpi
  ,agg.h3_kpi
  ,agg.slated_to_close_kpi
  ,agg.closed_but_not_slated_kpi
  ,agg.h2_total_usecases
  ,agg.sum_h2_days_gte0
  ,agg.count_h2_days_gte0
FROM all_combination_of_dimension 
LEFT OUTER JOIN aggregate_by_quarter_amt agg
ON 
  all_combination_of_dimension.fiscal_year_quarter_snapshot=agg.fiscal_year_quarter_snapshot
  and all_combination_of_dimension.business_unit=agg.business_unit
  and all_combination_of_dimension.sales_subregion_level_1=agg.sales_subregion_level_1
WHERE all_combination_of_dimension.fiscal_year_quarter_snapshot is not null
"""
).createOrReplaceTempView("joined_data_with_all_combination_of_dimension_amt")

# COMMAND ----------

spark.sql("""
SELECT 
  fiscal_year_quarter_snapshot
  ,fiscal_year_quarter_snapshot_mod
  ,business_unit
  ,sales_subregion_level_1
  

  ,total_usecases
  ,LAG(total_usecases) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) total_usecases_prev_qtr
  ,LAG(total_usecases) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) total_usecases_prev_year

  ,h1_kpi
  ,LAG(h1_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) h1_kpi_prev_qtr
  ,LAG(h1_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) h1_kpi_prev_year

  ,h3_kpi
  ,LAG(h3_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) h3_kpi_prev_qtr
  ,LAG(h3_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) h3_kpi_prev_year

  ,slated_to_close_kpi
  ,LAG(slated_to_close_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) slated_to_close_kpi_prev_qtr
  ,LAG(slated_to_close_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) slated_to_close_kpi_prev_year
  
  ,closed_but_not_slated_kpi
  ,LAG(closed_but_not_slated_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) closed_but_not_slated_kpi_prev_qtr
  ,LAG(closed_but_not_slated_kpi) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) closed_but_not_slated_kpi_prev_year

  ,h2_total_usecases
  ,LAG(h2_total_usecases) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) h2_total_usecases_prev_qtr
  ,LAG(h2_total_usecases) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) h2_total_usecases_prev_year


  ,sum_h2_days_gte0
  ,LAG(sum_h2_days_gte0) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) sum_h2_days_gte0_prev_qtr
  ,LAG(sum_h2_days_gte0) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) sum_h2_days_gte0_prev_year

  ,count_h2_days_gte0
  ,LAG(count_h2_days_gte0) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot) count_h2_days_gte0_prev_qtr
  ,LAG(count_h2_days_gte0) OVER (PARTITION BY business_unit,sales_subregion_level_1 ORDER BY fiscal_year_quarter_snapshot_mod) count_h2_days_gte0_prev_year

 FROM joined_data_with_all_combination_of_dimension_amt 
 WHERE fiscal_year_quarter_snapshot is not null
 
""").createOrReplaceTempView("data_with_previous_values_amt")

# COMMAND ----------

query_usecase_amt="""
  SELECT DISTINCT
  fiscal_year_quarter_snapshot
  ,fiscal_year_quarter_snapshot_mod
  ,business_unit
  ,sales_subregion_level_1

  ,total_usecases
  ,total_usecases_prev_qtr
  ,total_usecases_prev_year

  ,h1_kpi
  ,h1_kpi_prev_qtr
  ,h1_kpi_prev_year

  ,h3_kpi
  ,h3_kpi_prev_qtr
  ,h3_kpi_prev_year

  ,slated_to_close_kpi
  ,slated_to_close_kpi_prev_qtr
  ,slated_to_close_kpi_prev_year

  ,closed_but_not_slated_kpi
  ,closed_but_not_slated_kpi_prev_qtr
  ,closed_but_not_slated_kpi_prev_year

  ,h2_total_usecases
  ,h2_total_usecases_prev_qtr
  ,h2_total_usecases_prev_year

  ,sum_h2_days_gte0
  ,sum_h2_days_gte0_prev_qtr
  ,sum_h2_days_gte0_prev_year

  ,count_h2_days_gte0
  ,count_h2_days_gte0_prev_qtr
  ,count_h2_days_gte0_prev_year
FROM data_with_previous_values_amt"""

df_amt=spark.sql(query_usecase_amt)

# COMMAND ----------


# Apply cube() to aggregate the data
df_cube_amt = df_amt.cube(
  "business_unit"
  ,"fiscal_year_quarter_snapshot"
  ,"sales_subregion_level_1"
)\
.agg(\
  _sum("total_usecases").alias("total_usecases"), 
  _sum("total_usecases_prev_qtr").alias("total_usecases_prev_qtr"),
  _sum("total_usecases_prev_year").alias("total_usecases_prev_year"),

  _sum("h1_kpi").alias("h1_kpi"), 
  _sum("h1_kpi_prev_qtr").alias("h1_kpi_prev_qtr"),
  _sum("h1_kpi_prev_year").alias("h1_kpi_prev_year"),

  _sum("h3_kpi").alias("h3_kpi"),
  _sum("h3_kpi_prev_qtr").alias("h3_kpi_prev_qtr"),
  _sum("h3_kpi_prev_year").alias("h3_kpi_prev_year"),

  _sum("slated_to_close_kpi").alias("slated_to_close_kpi"),
  _sum("slated_to_close_kpi_prev_qtr").alias("slated_to_close_kpi_prev_qtr"),
  _sum("slated_to_close_kpi_prev_year").alias("slated_to_close_kpi_prev_year"),

  _sum("closed_but_not_slated_kpi").alias("closed_but_not_slated_kpi"),
  _sum("closed_but_not_slated_kpi_prev_qtr").alias("closed_but_not_slated_kpi_prev_qtr"),
  _sum("closed_but_not_slated_kpi_prev_year").alias("closed_but_not_slated_kpi_prev_year"),

  _sum("h2_total_usecases").alias("h2_total_usecases"),
  _sum("h2_total_usecases_prev_qtr").alias("h2_total_usecases_prev_qtr"),
  _sum("h2_total_usecases_prev_year").alias("h2_total_usecases_prev_year"), 

  _sum("sum_h2_days_gte0").alias("sum_h2_days_gte0"),
  _sum("sum_h2_days_gte0_prev_qtr").alias("sum_h2_days_gte0_prev_qtr"),
  _sum("sum_h2_days_gte0_prev_year").alias("sum_h2_days_gte0_prev_year"), 

  _sum("count_h2_days_gte0").alias("count_h2_days_gte0"),
  _sum("count_h2_days_gte0_prev_qtr").alias("count_h2_days_gte0_prev_qtr"),
  _sum("count_h2_days_gte0_prev_year").alias("count_h2_days_gte0_prev_year"))

  

df_cube_transformed_amt=\
df_cube_amt\
  .filter("fiscal_year_quarter_snapshot is not null")\
  .withColumn("group_value",lit(0))\
  .withColumn("processDate", F.current_timestamp())\
  .na.fill('All')

# COMMAND ----------

df_transformed_union=df_cube_transformed_amt.union(df_cube_transformed_cnt)
df_transformed_union=df_transformed_union.na.fill(0)
df_transformed_union.createOrReplaceTempView("df_cube")

df_transformed_final=\
spark.sql("""
  select *
    ,NVL(round(try_divide(sum_h2_days_gte0,count_h2_days_gte0),2),0) as average_velocity
    ,NVL(round(try_divide(sum_h2_days_gte0_prev_qtr,count_h2_days_gte0_prev_qtr),2),0) as average_velocity_prev_qtr
    ,NVL(round(try_divide(sum_h2_days_gte0_prev_year,count_h2_days_gte0_prev_year),2),0) as average_velocity_prev_year
    ,NVL(try_divide((average_velocity-average_velocity_prev_qtr),average_velocity_prev_qtr),0) as qoq_average_velocity
    ,NVL(try_divide((average_velocity-average_velocity_prev_year),average_velocity_prev_year),0) as yoy_average_velocity
  from df_cube""")

                            


# COMMAND ----------


write_delta_table(
  spark, 
  dataframe =df_transformed_final , 
  table_name='main.field_learning_enablement.dw_migration_usecase_agg_cube'
)

# COMMAND ----------

# %sql
# GRANT USE SCHEMA ON SCHEMA users.lekshmi_s TO `prathiba.h@databricks.com`;
# GRANT SELECT ON TABLE users.lekshmi_s.dw_migration_usecase_base TO `prathiba.h@databricks.com`;
# GRANT SELECT ON TABLE users.lekshmi_s.dw_migration_usecase_agg_cube TO `prathiba.h@databricks.com`;
# GRANT USE SCHEMA ON SCHEMA users.lekshmi_s TO `indhu.roopini@databricks.com`;
# GRANT SELECT ON TABLE users.lekshmi_s.dw_migration_usecase_base TO `indhu.roopini@databricks.com`;
# GRANT SELECT ON TABLE users.lekshmi_s.dw_migration_usecase_agg_cube TO `indhu.roopini@databricks.com`;

# COMMAND ----------

# MAGIC %sql
# MAGIC /*
# MAGIC ------------------- Get values of current quarter (FY24Q4), previous quarter (FY24Q3) and previous year (FY23Q4)-------------------
# MAGIC with quarter_list as 
# MAGIC (select distinct  fiscal_year_quarter
# MAGIC   from main.it_core_dim.dim_dates where fiscal_year_quarter >='FY\'22 Q1' order by 1 desc)
# MAGIC
# MAGIC ,calc_qtr_prev as (
# MAGIC select 
# MAGIC fiscal_year_quarter
# MAGIC ,lag(fiscal_year_quarter) over (order by fiscal_year_quarter) as prev_quarter
# MAGIC ,substring(fiscal_year_quarter, 1, 3)||(int(substring(fiscal_year_quarter, 4, 2))-1)||substring(fiscal_year_quarter, 6, 3) 
# MAGIC as prev_quarter_year
# MAGIC from quarter_list )
# MAGIC
# MAGIC ,qtr_filter as (
# MAGIC select * from calc_qtr_prev where  fiscal_year_quarter="FY'25 Q4")
# MAGIC ---------------------------------------------------------------------------------------------------------
# MAGIC --------- Get Data for all the 3 quarters ---------------------------------------------------------------
# MAGIC
# MAGIC ,all_data_curr as 
# MAGIC (
# MAGIC select *
# MAGIC from users.lekshmi_s.dw_migration_usecase_base 
# MAGIC where business_unit='AMER Emerging'
# MAGIC and   fiscal_year_quarter_snapshot = (select fiscal_year_quarter from qtr_filter)
# MAGIC )
# MAGIC
# MAGIC ,all_data_prev_qtr as(
# MAGIC select *
# MAGIC from users.lekshmi_s.dw_migration_usecase_base 
# MAGIC where business_unit='AMER Emerging'
# MAGIC and   fiscal_year_quarter_snapshot = (select prev_quarter from qtr_filter))
# MAGIC
# MAGIC
# MAGIC ,all_data_prev_year as (
# MAGIC
# MAGIC select *
# MAGIC from users.lekshmi_s.dw_migration_usecase_base 
# MAGIC where business_unit='AMER Emerging'
# MAGIC and   fiscal_year_quarter_snapshot = (select prev_quarter_year from qtr_filter)
# MAGIC )
# MAGIC ---------------------------------------------------------------------------------------------------
# MAGIC ------- Calculate the average velocity of each quarter --------------------------------------------
# MAGIC
# MAGIC
# MAGIC ,agg_data (
# MAGIC select * from 
# MAGIC (select fiscal_year_quarter as curr_quarter_year from qtr_filter)
# MAGIC cross join (select count(*) c_curr_year ,avg(case when h2_days>=0 then h2_days  end) avg_h2_days_curr_year 
# MAGIC from all_data_curr)
# MAGIC cross join
# MAGIC (select prev_quarter_year as prev_quarter_year from qtr_filter)
# MAGIC cross join (select count(*) c_prev_year ,avg(case when h2_days>=0 then h2_days  end) avg_h2_days_prev_year 
# MAGIC from all_data_prev_year)
# MAGIC cross join
# MAGIC (select prev_quarter as prev_quarter from qtr_filter)
# MAGIC cross join (select count(*) c_prev_qtr ,avg(case when h2_days>=0 then h2_days  end) avg_h2_days_prev_qtr
# MAGIC from all_data_prev_qtr)
# MAGIC )
# MAGIC
# MAGIC ---------------------------------------------------------------------------------------------------
# MAGIC ------------ Calculate the count of usecases crossing the average velocity in each quarters--------
# MAGIC
# MAGIC ,final_data_cnt as(
# MAGIC select '1' as source,* from 
# MAGIC (select count(distinct usecase_id) curr_count,count(case when h2_days>avg_h2_days_curr_year then usecase_id end ) curr_vel from all_data_curr,agg_data )
# MAGIC cross join
# MAGIC (select count(distinct usecase_id) prev_year_count,count(case when h2_days>avg_h2_days_prev_year then usecase_id end ) prev_year_vel from all_data_prev_year,agg_data )
# MAGIC cross join
# MAGIC (select count(distinct usecase_id) prev_qtr_count,count(case when h2_days>avg_h2_days_prev_qtr then usecase_id end ) prev_qtr_vel from all_data_prev_qtr,agg_data )
# MAGIC )
# MAGIC
# MAGIC
# MAGIC -----------------------------------------------------------------------------------------------------------------
# MAGIC ------------ Calculate the amount corresponding to usecases crossing the average velocity in each quarters--------
# MAGIC
# MAGIC
# MAGIC ,final_data_amt as(
# MAGIC select '0' as source,* from 
# MAGIC (select sum(estimated_monthly_dollar_dbus) curr_count,count(case when h2_days>avg_h2_days_curr_year then estimated_monthly_dollar_dbus end ) curr_vel from all_data_curr,agg_data )
# MAGIC cross join
# MAGIC (select count(estimated_monthly_dollar_dbus) prev_year_count,count(case when h2_days>avg_h2_days_prev_year then estimated_monthly_dollar_dbus end ) prev_year_vel from all_data_prev_year,agg_data )
# MAGIC cross join
# MAGIC (select count(estimated_monthly_dollar_dbus) prev_qtr_count,count(case when h2_days>avg_h2_days_prev_qtr then estimated_monthly_dollar_dbus end ) prev_qtr_vel from all_data_prev_qtr,agg_data )
# MAGIC )
# MAGIC
# MAGIC ----------------------------------------------------------------------------------------------------------------
# MAGIC ------------ Calculate QOQ and YOY of the above metric ----------------------------------------------------------
# MAGIC
# MAGIC select *,curr_vel/curr_count
# MAGIC ,try_divide(curr_vel,curr_count)-try_divide(prev_year_vel,prev_year_count) yoy
# MAGIC ,try_divide(curr_vel,curr_count)-try_divide(prev_qtr_vel,prev_qtr_count) qoq from 
# MAGIC (select * from final_data_cnt union select * from final_data_amt)final_data
# MAGIC where source='1' */