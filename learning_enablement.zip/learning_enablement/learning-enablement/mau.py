# Databricks notebook source
# MAGIC %sql
# MAGIC create or replace temp view maus_base_gold as 
# MAGIC with t28_data as (
# MAGIC   SELECT 
# MAGIC     DATE_TRUNC('month', date)::date AS month,
# MAGIC     salesforce_account_id,
# MAGIC     COUNT(DISTINCT CASE WHEN login_num_events_t28d > 0 THEN user_id END) AS mau,
# MAGIC     COUNT(DISTINCT CASE WHEN login_num_events_t7d > 0 THEN user_id END) AS wau,
# MAGIC     COUNT(DISTINCT CASE WHEN login_num_events_t91d > 0 THEN user_id END) AS qau,
# MAGIC     COUNT(DISTINCT CASE WHEN login_num_events > 0 THEN user_id END) AS dau
# MAGIC FROM main.data_product_features.user_metrics
# MAGIC WHERE salesforce_account_id NOT IN ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
# MAGIC     AND date >= '2024-01-01'
# MAGIC     AND (DAYOFMONTH(date) = 28 OR date = (SELECT MAX(date) FROM main.data_product_features.user_metrics))
# MAGIC GROUP BY 1, 2
# MAGIC ORDER BY 1 DESC
# MAGIC )
# MAGIC , 
# MAGIC -- data as (
# MAGIC -- select 
# MAGIC --   d.*, 
# MAGIC --   t.t28_mau as t28_mau, 
# MAGIC --   t.wau as wau,
# MAGIC --   t.qau as qau,
# MAGIC --   t.dau as dau
# MAGIC -- from mau_data_old d 
# MAGIC -- left join t28_data t on d.month = t.month and d.salesforce_account_id = t.salesforce_account_id
# MAGIC -- )
# MAGIC data as (
# MAGIC select 
# MAGIC   -- d.*, 
# MAGIC   t.salesforce_account_id as salesforce_account_id, 
# MAGIC   t.month as month,
# MAGIC   nvl(t.mau, 0) as mau,
# MAGIC   -- nvl(t.t28_mau, 0) as t28_mau, 
# MAGIC   nvl(t.wau, 0) as wau,
# MAGIC   nvl(t.qau, 0) as qau,
# MAGIC   nvl(t.dau, 0) as dau
# MAGIC from t28_data t 
# MAGIC -- left join mau_data_old d on d.month = t.month and d.salesforce_account_id = t.salesforce_account_id
# MAGIC
# MAGIC )
# MAGIC ,
# MAGIC
# MAGIC min_month as 
# MAGIC   (
# MAGIC    select min(month) as start_month
# MAGIC    from data 
# MAGIC    where mau <> 0
# MAGIC   )
# MAGIC   ,
# MAGIC
# MAGIC   accounts_prep_1 as 
# MAGIC   (
# MAGIC   select  salesforce_account_id as account_id, min(month) as first_month
# MAGIC   from data 
# MAGIC   where mau <> 0
# MAGIC   group by all 
# MAGIC   )
# MAGIC
# MAGIC
# MAGIC
# MAGIC ,
# MAGIC    accounts_prep_2 as 
# MAGIC    (
# MAGIC  select  updated_account_id as account_id, min(date_trunc("month",completed_date)::date) as first_month
# MAGIC   from main.field_learning_enablement.all_learners
# MAGIC   where audience="Customer"
# MAGIC   and processdate =(select max(processDate) from main.field_learning_enablement.all_learners)
# MAGIC   and all_learners.dataset="net new learners"
# MAGIC   group by all 
# MAGIC    )
# MAGIC
# MAGIC    ,
# MAGIC
# MAGIC  accounts as 
# MAGIC  (
# MAGIC    select distinct account_id, first_month
# MAGIC    from accounts_prep_1
# MAGIC    union 
# MAGIC       select distinct account_id, first_month
# MAGIC       from accounts_prep_2 
# MAGIC  )
# MAGIC
# MAGIC
# MAGIC   ,
# MAGIC   
# MAGIC   accounts_months as (
# MAGIC
# MAGIC    select account_id, 
# MAGIC    min(first_month) as start_month
# MAGIC    from accounts
# MAGIC    group by all
# MAGIC   )
# MAGIC   
# MAGIC   ,
# MAGIC   timeframes as 
# MAGIC   (
# MAGIC    select distinct date as month
# MAGIC    from main.it_core_dim.dim_dates
# MAGIC   where is_month_start
# MAGIC   and date<=current_date::date
# MAGIC   )
# MAGIC   
# MAGIC   ,
# MAGIC
# MAGIC   accounts_timeframes as 
# MAGIC   (
# MAGIC   select account_id, start_month, month
# MAGIC   from accounts_months a
# MAGIC   cross join timeframes where month>=start_month and month<=current_date::date
# MAGIC   )
# MAGIC
# MAGIC
# MAGIC
# MAGIC   select 
# MAGIC     a.account_id as salesforce_account_id,
# MAGIC     a.month,
# MAGIC     nvl(d.mau,0) as mau,
# MAGIC     -- nvl(d.t28_mau,0) as t28_mau,
# MAGIC     nvl(d.wau,0) as wau,
# MAGIC     nvl(d.qau,0) as qau,
# MAGIC     nvl(d.dau,0) as dau,
# MAGIC     c.business_unit, 
# MAGIC     c.sales_subregion_level_1, 
# MAGIC     c.sales_subregion_level_2, 
# MAGIC     c.sales_subregion_level_3, 
# MAGIC     c.account_name, 
# MAGIC     c.account_status
# MAGIC   from accounts_timeframes a 
# MAGIC   left join data d on a.account_id=d.salesforce_account_id and a.month=d.month
# MAGIC   left join main.gtm_data.core_accounts_curated c on a.account_id=c.account_id   
# MAGIC   order by all     
# MAGIC

# COMMAND ----------

# MAGIC %sql 
# MAGIC select 
# MAGIC month, sum(mau) 
# MAGIC from maus_base_gold
# MAGIC group by all

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC   o.*,
# MAGIC   -- l.date as learning_date,
# MAGIC   case when contains(manager_hierarchy_path_name, 'jeff traylor') THEN "AMER Enterprise"
# MAGIC     when contains(manager_hierarchy_path_name, 'david hackett') THEN "AMER Regulated Verticals & AMER Emerging Business"
# MAGIC     when contains(manager_hierarchy_path_name, 'toby balfre') THEN "EMEA"
# MAGIC     when contains(manager_hierarchy_path_name, 'nicholas eayrs') THEN "APJ"
# MAGIC     when contains(manager_hierarchy_path_name, 'david totten') THEN "FE Scale"
# MAGIC     when contains(manager_hierarchy_path_name, 'jason martin') THEN "Pro Services"
# MAGIC     when contains(manager_hierarchy_path_name, 'richard garris') THEN "Product Specialists"
# MAGIC     ELSE 'Other'
# MAGIC   END as bu,
# MAGIC   case when CONTAINS(manager_hierarchy_path_name, 'steve rigo') THEN "RETAIL"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'shane martinez') THEN "MFG"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'christopher olenik') THEN "CME"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'nick mckerrall') THEN "Canada"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'marcelo sales') THEN "LATAM"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'michael riley') THEN "FINS"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'ravi dharnikota') THEN "HLS"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'sujit mohanty') THEN "PubSec"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'ajay singh') THEN "AMER Velocity"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'richard shaw') THEN "EMEA Northern"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'nicolas maillard') THEN "EMEA Southern"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'matthias ingerfeld') THEN "EMEA Central"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'mary downey') THEN "EMEA Velocity"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'rajesh ramdas') THEN "India"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'raela wang') THEN "GCR"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'kunal taneja') THEN "ASEAN"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'kyoungwoon chang') THEN "KOREA"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'keita nozaki') THEN "Japan"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'david totten') THEN "FE Scale"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'alex narkaj') THEN "PS AMER"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'stuart fenwick') THEN "PS EMEA"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'takehisa ueda') THEN "PS APJ"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'jason martin') THEN "Pro Services"
# MAGIC     ELSE "Others"
# MAGIC   END as bu_plus_1,
# MAGIC   case when CONTAINS(manager_hierarchy_path_name, 'jeff traylor') THEN "Jeff Traylor"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'david hackett') THEN "David Hackett"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'jason martin') THEN "Jason Martin"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'toby balfre') THEN "Toby Balfre"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'nicholas eayrs') THEN "Nick Eayrs"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'david totten') THEN "David Totten"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'richard garris') THEN "Richard Garris"
# MAGIC     ELSE "Other Leader"
# MAGIC   END as leader,
# MAGIC   case when CONTAINS(manager_hierarchy_path_name, 'shane martinez') THEN "Shane Martinez"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'marcelo sales') THEN "Marcelo Sales"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'ajay singh') THEN "Ajay Singh"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'nick mckerrall') THEN "Nick McKerrall"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'christopher olenik') THEN "Christopher Olenik"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'kyoungwoon chang') THEN "Kyoungwoon Chang"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'shane martinez') THEN "Shane Martinez"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'keita nozaki') THEN "Keita Nozaki"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'richard shaw') THEN "Richard Shaw"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'nicolas maillard') THEN "Nicolas Maillard"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'michael riley') THEN "Michael Riley"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'sujit mohanty') THEN "Sujit Mohanty"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'ravi dharnikota') THEN "Ravi Dharnikota"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'mary downey') THEN "Mary Downey"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'steve rigo') THEN "Steve Rigo"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'raela wang') THEN "Raela Wang"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'matthias ingerfeld') THEN "Matthias Ingerfeld"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'rajesh ramdas') THEN "Rajesh Ramdas"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'kunal taneja') THEN "Kunal Taneja"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'alex narkaj') THEN "Alex Narkaj"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'stuart fenwick') THEN "Stuart Fenwick"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'takehisa ueda') THEN "Takehisa Ueda"
# MAGIC     when CONTAINS(manager_hierarchy_path_name, 'nicholas eayrs') THEN "Nicholas Eayrs"
# MAGIC     else 'Others'
# MAGIC   END as tech_gm,
# MAGIC   case when o.completed_date = l.date then 1 else 0 end as learning_day_flag_completion,
# MAGIC   case when o.enrolled_date = l2.date then 1 else 0 end as learning_day_flag_enrollment
# MAGIC from
# MAGIC   main.field_learning_enablement.ongoing_learning o
# MAGIC   left join main.field_learning_enablement.learning_day_dates l on o.completed_date = l.date
# MAGIC   and l.processDate = (
# MAGIC     select
# MAGIC       max(processDate)
# MAGIC     from
# MAGIC       main.field_learning_enablement.learning_day_dates
# MAGIC   )
# MAGIC   and o.fe_org_leader = l.fe_org_leader
# MAGIC   left join main.field_learning_enablement.learning_day_dates l2 on o.enrolled_date=l2.date and  l2.processDate = (
# MAGIC     select
# MAGIC       max(processDate)
# MAGIC     from
# MAGIC       main.field_learning_enablement.learning_day_dates
# MAGIC   )
# MAGIC   and o.fe_org_leader = l2.fe_org_leader
# MAGIC where
# MAGIC   o.processDate = (
# MAGIC     select
# MAGIC       max(processDate)
# MAGIC     from
# MAGIC       main.field_learning_enablement.ongoing_learning
# MAGIC   )

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history main.field_learning_enablement.l200_reporting

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.field_learning_enablement.l200_reporting
# MAGIC where primaryWorkEmail = 'mojgan.mazouchi@databricks.com'
# MAGIC  and processDate = '2024-11-18'

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC from main.field_learning_enablement.training_revenue_forecast
# MAGIC where processDate = '2024-11-18'

# COMMAND ----------

# MAGIC %sql
# MAGIC select month, sum(mau) from main.field_learning_enablement.monthly_active_users
# MAGIC where processDate = '2024-11-18' and month < '2024-01-01'
# MAGIC group by all

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM 
# MAGIC main.gtm_data.core_accounts_curated 
# MAGIC where snapshot_date = (select max(snapshot_date) from main.gtm_data.core_accounts_curated)
# MAGIC
# MAGIC