# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      N/A  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      N/A \
# MAGIC **Target:**             blacklist_domains \
# MAGIC **Description:**     This notebook creates a list of blacklist email domains (personal email domains such as gmail.com etc) \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated when needed
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

import sys
from datetime import datetime, timedelta

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

sys.path.insert(0, focus_data_utils_path)

from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

# COMMAND ----------

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a (DataFrame, processDate) tuple
  """
  now = partition_date
  df2 = df.withColumn(partition_column, F.to_date(F.lit(now)))
  return (df2, now)

# COMMAND ----------

generic_domains = ["aol.com",
                   "GMAIL.COM",
                   "Gmail.com",
                   "gmail.com",
                   "gmail.com.br",
                   "gmail.con",
                   "hotmail.be",
                   "hotmail.co.in",
                   "hotmail.co.uk",
                   "hotmail.com.br",
                   "hotmail.com",
                   "hotmail.es",
                   "hotmail.fr",
                   "hotmail.it",
                   "outlook.be",
                   "OUTLOOK.COM",
                   "outlook.com",
                   "outlook.com.au",
                   "outlook.com.br",
                   "outlook.de",
                   "outlook.es",
                   "outlook.fr",
                   "outlook.in",
                   "outlook.it",
                   "yahoo.co.in",
                   "yahoo.co.uk",
                   "yahoo.com",
                   "yahoo.com.au",
                   "yahoo.com.br",
                   "yahoo.com.hk",
                   "yahoo.com.sg",
                   "yahoo.de",
                   "yahoo.es",
                   "yahoo.fr",
                   "ymail.com",
                   "danielesser.de",
                   "googlemail.com",
                   ".com",
                   "live.com",
                   "icloud.com",
                   "msn.com",
                   "me.com",
                   "live.nl",
                   "rocketmail.com",
                   "mail.com",
                   "test.com",
                   "proton.me",
                 "yahoo.co.jp",
                    "pm.me"]

# COMMAND ----------

df = spark.createDataFrame([{"blacklist_domain": domain} for domain in generic_domains])

# COMMAND ----------

final_df, process_date = add_gold_metadata(df, partition_date)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = final_df, 
  table_name = f'{focus_database_name}.blacklist_domains', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)