# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for instructor utilzation from Airtable \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Workspace/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

# spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import requests

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

import pandas as pd


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

def convertToDF(data):
  """
    data is a list of objects
  """
  json_obj = {}
  
  json_obj['field'] = data

  df = pd.json_normalize(json_obj['field'])
  lst = list(df)
  df[lst] = df[lst].astype(str)

  spark_df = (
    spark
      .createDataFrame(df)
  )
  return spark_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### Instructors

# COMMAND ----------

airtable_pat = dbutils.secrets.get('ldr-airtable', 'airtable-token')

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Instructor%20Skills%20%26%20Credentials?view=Master%20Logfood"
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

instructor_records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()


instructor_records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  instructor_records += response_json['records']

# COMMAND ----------

df = convertToDF(instructor_records)

# COMMAND ----------

#The only one to keep as actual list is languages

# display(df)

# COMMAND ----------

df.createOrReplaceTempView('instructors')

# COMMAND ----------

instructor_df = spark.sql('''
  with pre as (
    select
      `id`,
      `createdTime`,
      `fields.Instructor Email` as instructor_email,
      `fields.Course Name` as course_name,
      `fields.Status` as status, 
      `fields.Instructor` as instructor_airtable_id,
      `fields.Course Type (from Course Name)` as course_type, 
      `fields.ATP or Internal` as atp_or_internal,
      `fields.Region (from Instructor)` as region,
      `fields.Active? (from Instructor)` as active,
      `fields.Languages (from Instructor)` as languages,
      `fields.Country (from Instructor)` as country,
      `fields.Status (from Instructor)` as status_from_instructor,
      `fields.Created` as created,
      `fields.ATP or Internal (from Instructor)` as atp_or_internal_from_instructor,
      `fields.Complete Date` as completed_date,
      --`fields.Scheduling POC` as scheduling_poc,
      --`fields.Ramping Start Date` as ramping_start_date,
      --`fields.Trainer Notes` as trainer_notes,
      `fields.Ramping Goal Date` as ramping_goal_date
      --`fields.Cert Expiration Date` as cert_expiration_date,
      --`fields.Accredible URL` as accredible_url, 
      --`fields.Mentor (Instructor)` as mentor
    from instructors
  )
  ,
  cleaned as (
    select 
      id,
      createdTime, 
      case when instructor_email in ('nan', 'NaN') then null else trim(instructor_email) end as instructor_email,
      case when course_name in ('nan', 'NaN') then null else course_name end as course_name,
      case when status in ('nan', 'NaN') then null else status end as status,
      case when instructor_airtable_id in ('nan', 'NaN') then null else instructor_airtable_id end as instructor_airtable_id,
      case when course_type in ('nan', 'NaN') then null else course_type end as course_type,
      case when atp_or_internal in ('nan', 'NaN') then null else atp_or_internal end as atp_or_internal,
      case when region in ('nan', 'NaN') then null else region end as region,
      case when active in ('nan', 'NaN') then null else active end as active,
      case when languages in ('nan', 'NaN') then null else languages end as languages,
      case when country in ('nan', 'NaN') then null else country end as country,
      case when status_from_instructor in ('nan', 'NaN') then null else status_from_instructor end as status_from_instructor,
      case when created in ('nan', 'NaN') then null else created end as created,
      case when atp_or_internal_from_instructor in ('nan', 'NaN') then null else atp_or_internal_from_instructor end as atp_or_internal_from_instructor,
      case when completed_date in ('nan', 'NaN') then null else completed_date end as completed_date,
      -- case when scheduling_poc in ('nan', 'NaN') then null else scheduling_poc end as scheduling_poc,
      --case when ramping_start_date in ('nan', 'NaN') then null else ramping_start_date end as ramping_start_date,
      --case when trainer_notes in ('nan', 'NaN') then null else trainer_notes end as trainer_notes,
      case when ramping_goal_date in ('nan', 'NaN') then null else ramping_goal_date end as ramping_goal_date
      --case when cert_expiration_date in ('nan', 'NaN') then null else cert_expiration_date end as cert_expiration_date,
      --case when accredible_url in ('nan', 'NaN') then null else accredible_url end as accredible_url,
      --case when mentor in ('nan', 'NaN') then null else mentor end as mentor
    from pre
  )

  select 
    id,
    createdTime,
    instructor_email,
    split(regexp_replace(regexp_replace(course_name, "\\\\[|\\\\]", ""), "'", ""), ", ")[0] as course_name,
    status,
    split(regexp_replace(regexp_replace(instructor_airtable_id, "\\\\[|\\\\]", ""), "'", ""), ", ")[0] as instructor_airtable_id,
    split(regexp_replace(regexp_replace(course_type, "\\\\[|\\\\]", ""), "'", ""), ", ")[0] as course_type,
    split(regexp_replace(regexp_replace(atp_or_internal, "\\\\[|\\\\]", ""), "'", ""), ", ")[0] as atp_or_internal,
    from_json(
          regexp_replace(region, "\'", '"'), 
          'array<string>'
      ) AS regions,
    split(regexp_replace(regexp_replace(active, "\\\\[|\\\\]", ""), "'", ""), ", ")[0] as active,
    from_json(
          regexp_replace(languages, "\'", '"'), 
          'array<string>'
      ) AS languages,
    from_json(
          regexp_replace(country, "\'", '"'), 
          'array<string>'
      ) AS countries,
    split(regexp_replace(regexp_replace(status_from_instructor, "\\\\[|\\\\]", ""), "'", ""), ", ")[0] as status_from_instructor,
    created,
    split(regexp_replace(regexp_replace(atp_or_internal_from_instructor, "\\\\[|\\\\]", ""), "'", ""), ", ")[0] as atp_or_internal_from_instructor,
    completed_date,
    -- scheduling_poc,
    --ramping_start_date,
    --trainer_notes,
    ramping_goal_date
    --cert_expiration_date,
    --accredible_url,
    --mentor
  from cleaned
  
''')


# COMMAND ----------

instructor_df_gold = add_gold_metadata(instructor_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = instructor_df_gold, 
  table_name = f'{focus_database_name}.airtable_instructors_skills_credentials', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)