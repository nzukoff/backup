# Databricks notebook source
# MAGIC %md
# MAGIC # installs

# COMMAND ----------

!pip install --upgrade pip

# COMMAND ----------

!pip install authlib
!pip install gspread==5.12.4
!pip install gspread-dataframe
!pip install oauth2client
!pip install google-api-python-client
!pip install google-auth

# COMMAND ----------

# LC CHANGED 01.28.24 `!pip install gspread` >> `!pip install gspread==5.12.4` due to:
# Client() changes in: https://github.com/burnash/gspread/commit/617a63f045285f6c8376c6aed48818a290b4dcf5

# COMMAND ----------

#!pip install gspread==version=5.0.0

# COMMAND ----------

# LC 03.06.24 >> ADDED DUE TO `JSON_OBJECT` NO LONGER BEING VALID

import pandas as pd
import re
import urllib
import gspread
from gspread import Client

from authlib.integrations.requests_client import AssertionSession
from oauth2client.service_account import ServiceAccountCredentials
from google.oauth2.credentials import Credentials
from googleapiclient import discovery
from typing import Dict, Union, Optional, Tuple, Any, List

def generate_credentials_dict(credentials):
  
    """
    Purpose:
        Generate a dictionary containing the Google service account credentials.
    Args:
        project_id (str): The ID of the project containing the Google service account.
        private_key_id (str): The ID of the private key.
        private_key (str): The private key.
        client_email (str): The email address associated with the Google service account.
        client_id (str): The client ID associated with the Google service account.
    Returns:
        A dictionary containing the Google service account credentials.
    """
    
    # Ensure that all required keys are present
    assert "project_id" in credentials.keys(), "Error: 'project_id' key not found in `credentials`"
    assert "private_key_id" in credentials.keys(), "Error: 'private_key_id' key not found in `credentials`"
    assert "private_key" in credentials.keys(), "Error: 'private_key' key not found in `credentials`"
    assert "client_email" in credentials.keys(), "Error: 'client_email' key not found in `credentials`"
    assert "client_id" in credentials.keys(), "Error: 'client_id' key not found in `credentials`"

    # Extract the necessary values
    project_id = credentials["project_id"]
    private_key_id = credentials["private_key_id"]
    private_key = credentials["private_key"]
    client_email = credentials["client_email"]
    client_id = credentials["client_id"]
    
    type = 'service_account'
    auth_uri = 'https://accounts.google.com/o/oauth2/auth'
    token_uri = 'https://oauth2.googleapis.com/token'
    auth_provider_x509_cert_url = 'https://www.googleapis.com/oauth2/v1/certs'
    private_key = private_key.replace('\\n', '\n')

    
    credentials_dict = {
        'type': type,
        'project_id': project_id,
        'private_key_id': private_key_id,
        'private_key': f'-----BEGIN PRIVATE KEY-----\n{private_key}\n-----END PRIVATE KEY-----\n',
        'client_email': client_email,
        'client_id': client_id,
        'auth_uri': auth_uri,
        'token_uri': token_uri,
        'auth_provider_x509_cert_url': auth_provider_x509_cert_url,
        'client_x509_cert_url': f'https://www.googleapis.com/robot/v1/metadata/x509/{urllib.parse.quote(client_email)}'
    }
    return credentials_dict

def gen_creds():

  try:
    credentials_dict = {
        'project_id' : dbutils.secrets.get('gtm-gcp-creds', 'gcp_service_account_user_project_id'),
        'private_key_id' : dbutils.secrets.get('gtm-gcp-creds', 'gcp_service_account_user_private_key_id'),
        'private_key' : dbutils.secrets.get('gtm-gcp-creds', 'gcp_service_account_user_private_key'),
        'client_email' : dbutils.secrets.get('gtm-gcp-creds', 'gcp_service_account_user_client_email'),
        'client_id' : dbutils.secrets.get('gtm-gcp-creds', 'gcp_service_account_user_client_id')
    }
  except:
    try:
        credentials_dict = {
            'project_id' : dbutils.secrets.get('gtm-gcp-creds-2', 'gcp_service_account_user_project_id'),
            'private_key_id' : dbutils.secrets.get('gtm-gcp-creds-2', 'gcp_service_account_user_private_key_id'),
            'private_key' : dbutils.secrets.get('gtm-gcp-creds-2', 'gcp_service_account_user_private_key'),
            'client_email' : dbutils.secrets.get('gtm-gcp-creds-2', 'gcp_service_account_user_client_email'),
            'client_id' : dbutils.secrets.get('gtm-gcp-creds-2', 'gcp_service_account_user_client_id')
        }
    except:
        credentials_dict = {
            'project_id' : dbutils.secrets.get('gtm-gcp-creds-3', 'gcp_service_account_user_project_id'),
            'private_key_id' : dbutils.secrets.get('gtm-gcp-creds-3', 'gcp_service_account_user_private_key_id'),
            'private_key' : dbutils.secrets.get('gtm-gcp-creds-3', 'gcp_service_account_user_private_key'),
            'client_email' : dbutils.secrets.get('gtm-gcp-creds-3', 'gcp_service_account_user_client_email'),
            'client_id' : dbutils.secrets.get('gtm-gcp-creds-3', 'gcp_service_account_user_client_id')
        }


  credentials_dict = generate_credentials_dict(credentials_dict)

  return credentials_dict  


credentials_dict = gen_creds()

# COMMAND ----------

# json_object={}

# cred=dbutils.secrets.get('ga-gcp-sfdc-creds', 'gcp-creds-azure')
# # databricks secrets

# for i in cred.replace('https:','https;').split(','):
  
#   arg1=i.split(':')[0]
#   arg2=i.split(':')[1]
  
#   if arg2.find('\\')!=-1:
#     arg2=arg2.replace('\\n','\n')
    
#   if arg2.find('BEGINPRIVATEKEY')!=-1:
#     arg2=arg2.replace('BEGINPRIVATEKEY','BEGIN PRIVATE KEY')
    
#   if arg2.find('ENDPRIVATEKEY')!=-1:
#     arg2=arg2.replace('ENDPRIVATEKEY','END PRIVATE KEY')
    
#   if len(json_object)==0:
#     json_object[arg1]=arg2.replace('https;','https:')
#   else:
#     json_object[arg1]=arg2.replace('https;','https:')
  
#   # re-create json obj

# COMMAND ----------

# MAGIC %md
# MAGIC - if jobs are failing due to **py4j.Py4JException: Method secret([]) does not exist** error:
# MAGIC  - this is happening due to cluster owner not having any type of access to above db secret
# MAGIC  - source: <a href="https://docs.databricks.com/security/secrets/secrets.html" target="_blank">https://docs.databricks.com/security/secrets/secrets.html</a>

# COMMAND ----------

def get_service_account_credentials():
  credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 
  return credentials

# COMMAND ----------

def get_access_token():
    """
    from https://ga-dev-tools.appspot.com/embed-api/server-side-authorization/
    Defines a method to get an access token from the credentials object.
    The access token is automatically refreshed if it has expired.
    """

    # The scope for the OAuth2 request.

    SCOPE = ['https://spreadsheets.google.com/feeds',\
              'https://www.googleapis.com/auth/drive',\
              'https://www.googleapis.com/auth/documents',\
              'https://www.googleapis.com/auth/analytics.readonly',\
              'https://www.googleapis.com/auth/presentations']

    # Construct a credentials objects from the key data and OAuth2 scope.
    _credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict, SCOPE)

    return _credentials.get_access_token().access_token 

# COMMAND ----------

# DBTITLE 1,Google Sheet Data Reader
def readGoogleSheet(x,y,*args,**kwargs): 
  # x --> Spreadsheet name OR Spreadsheet key
  # y --> Sheet name 
  # args --> Name of Temp Table
  # kwargs --> cell_range / make_columns_unique / append_to_col_header / clean_column_names  (optional)
  
  import json
  import gspread
  from gspread import Client
  from authlib.integrations.requests_client import AssertionSession
  from oauth2client.service_account import ServiceAccountCredentials
#   from gspread_dataframe import get_as_dataframe, set_with_dataframe
#   LC : 1/6/22 - blocked off above code due to "ModuleNotFoundError: No module named 'gspread.models'" error
  import pandas as pd
  import re
  import time
  
  scope = ['https://spreadsheets.google.com/feeds',
           'https://www.googleapis.com/auth/drive']
  
  credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 

  def create_assertion_session(scopes, subject=None):
    token_url = credentials_dict['token_uri']
    issuer = credentials_dict['client_email']
    key = credentials_dict['private_key']
    key_id = credentials_dict['private_key_id']
    header = {'alg': 'RS256'}

    if key_id:
      header['kid'] = key_id
      # Google puts scope in payload
      claims = {'scope': ' '.join(scopes)}

      return AssertionSession(
        grant_type=AssertionSession.JWT_BEARER_GRANT_TYPE,
        token_endpoint=token_url,
        issuer=issuer,
        audience=token_url,
        claims=claims,
        subject=subject,
        key=key,
        header=header,
    )

  session = create_assertion_session(scope)
  client = Client(credentials,session)
  # auth

  if len(x) == 44:
    try:
      sht = client.open_by_key(x) 
    except:
      sht = client.open(x) 
  else:  
    sht = client.open(x) 
    
####   LC Added lines below 3.17.22   ####
  ss = client.open_by_key(sht.id)
  
  if len(re.sub("[^0-9]", "", str(y)))==len(str(y)):
    ws = sht.get_worksheet_by_id(int(y))
  else:
    ws = sht.worksheet(y)
####   LC Added lines above 3.17.22   ####
    
  # connect to workbook/sheet
  
    
####   LC Added lines below 3.17.22   ####
  if kwargs is not None and 'cell_range' in kwargs and len(re.sub("[^0-9]", "", str(y)))==len(str(y)):
    range_data = '%s!%s' % (ws.title,kwargs['cell_range'])
  
  elif kwargs is not None and 'cell_range' in kwargs:
    range_data = '%s' % kwargs['cell_range']
  else:
    range_data = '%s' % ws.title
  # specify cell range
  
####   LC Added lines above 3.17.22 (ws.title)   ####
  
  values = ss.values_get(range_data)
  values = values['values']
  pd_df = pd.DataFrame(values)
  pd_df.fillna("",inplace=True) # convert None --> ''
  # clean up dataset
  
  headers = pd_df.iloc[0]
  headers = [x.lower() for x in headers] # convert series to list
  # get column headers from 0 index (ie. first) row
  
  cols = []
  
  if kwargs is not None and 'make_columns_unique' in kwargs:
    for x in range(0,len(headers)):
      if headers[:x].count(headers[x]) >= 1:
        cols.append(str(headers[x]) + str(headers[:x].count(headers[x])))
      else:
        cols.append(str(headers[x]))
  else:
    cols=headers
  
  pd_df  = pd.DataFrame(pd_df.values[1:], columns=cols)
  # make columns unique --> if duplicate columns, then append the column index to end of respective column name

  if kwargs is not None and 'append_to_col_header' in kwargs:
    pd_df.columns = ['%s%s' % (kwargs['append_to_col_header'],col_name) for col_name in pd_df.columns]  
    cols = [x.lower() for x in pd_df.columns.values]
    # append kwargs['append_to_col_header'] to beginning of column name
    
  try:
    spark_df = spark.createDataFrame(pd_df)  
  except:
    cleaned_cols = []
    for x in range(0,len(cols)):
      if cols[:x].count(cols[x]) >= 1:
        cleaned_cols.append(str(cols[x]) + str(cols[:x].count(cols[x])))
      else:
        cleaned_cols.append(str(cols[x]))
    
    pd_df = pd.DataFrame(pd_df.values[1:], columns=cleaned_cols)
    spark_df = spark.createDataFrame(pd_df)  
    # if there are still duplicates, then map the column index to the end of the column name by default
  
  if kwargs is not None and 'clean_column_names' in kwargs: 

    pandas_before = spark_df.toPandas()
    
    pandas_before.columns = [re.sub("[^a-zA-Z0-9]+","_",x) for x in pandas_before.columns]
    headers=[re.sub('__','_',re.sub('___','_',x)) for x in pandas_before.columns.values]
    headers = [x[0:len(x)-3] if x.endswith('___', 0, len(x)) else x.lower() for x in headers]
    headers = [x[0:len(x)-2] if x.endswith('__', 0, len(x)) else x.lower() for x in headers]
    headers = [x[0:len(x)-1] if x.endswith('_', 0, len(x)) else x.lower() for x in headers]
    pandas_before.columns = headers
    # remove special characters, but keep numbers, letters, and '_' in column header
    # resource: https://stackoverflow.com/questions/4283351/how-to-replace-special-characters-in-a-string
    
    cols=[]
    headers=[x.lower() for x in pandas_before.columns.values]
    for x in range(0,len(headers)):
      if headers[:x].count(headers[x]) >= 1:
        cols.append(str(headers[x]) + str(headers[:x].count(headers[x])))
      else:
        cols.append(str(headers[x]))

    pandas_before.columns=cols
    pd_df = pandas_before
    
    # double check to make sure that, after cleaning the column names, that there aren't any duplicate column names leftover

  if args:
    spark_df = spark.createDataFrame(pd_df)
    spark_df.createOrReplaceTempView(args[0]) 
    
#   user = ''.join([x for x in str(dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().apply('user')).replace('@databricks.com','')])
#   notebook = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().replace("'","\\'")

#   try:
#     spark.sql("""insert into liam.udf_audit_log 
#                select distinct
#                  named_struct('workbook', '%s','worksheet','%s','sfdc_obj','%s') as dataSource
#                 , '%s' as tempTableName
#                 ,'%s' as user
#                 ,current_timestamp as executionTime
#                 ,'%s' as notebook
#                 ,'readGoogleSheet' as methodUsed""" \
#                % (x,y,'',args[0],user,notebook))
#   except:
#     time.sleep(10)
#     spark.sql("""insert into liam.udf_audit_log 
#                select distinct
#                  named_struct('workbook', '%s','worksheet','%s','sfdc_obj','%s') as dataSource
#                 , '%s' as tempTableName
#                 ,'%s' as user
#                 ,current_timestamp as executionTime
#                 ,'%s' as notebook
#                 ,'readGoogleSheet' as methodUsed""" \
#                % (x,y,'',args[0],user,notebook))
#   try:
#     spark.sql("""optimize liam.udf_audit_log""")
#   except:
#     time.sleep(10)
#     spark.sql("""optimize liam.udf_audit_log""")
  
  return (spark_df,pd_df,sht,ws,ss)
  

# COMMAND ----------

# LC ADDED 03.30.24 >> Enhanced retry handling support instances of higher demand (which might lead to rate limiting errors)

def readGoogleSheet(x,y,*args,**kwargs): 
  # x --> Spreadsheet name OR Spreadsheet key
  # y --> Sheet name 
  # args --> Name of Temp Table
  # kwargs --> cell_range / make_columns_unique / append_to_col_header / clean_column_names  (optional)
  
  import json
  import gspread
  from gspread import Client
  from authlib.integrations.requests_client import AssertionSession
  from oauth2client.service_account import ServiceAccountCredentials
  import pandas as pd
  import re
  import time
  
  scope = ['https://spreadsheets.google.com/feeds',
           'https://www.googleapis.com/auth/drive']
  
  credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 

  def create_assertion_session(scopes, subject=None):
    token_url = credentials_dict['token_uri']
    issuer = credentials_dict['client_email']
    key = credentials_dict['private_key']
    key_id = credentials_dict['private_key_id']
    header = {'alg': 'RS256'}

    if key_id:
      header['kid'] = key_id
      # Google puts scope in payload
      claims = {'scope': ' '.join(scopes)}

      return AssertionSession(
        grant_type=AssertionSession.JWT_BEARER_GRANT_TYPE,
        token_endpoint=token_url,
        issuer=issuer,
        audience=token_url,
        claims=claims,
        subject=subject,
        key=key,
        header=header,
    )
      
  def retry_api_call(api_call,sleep_time=60):
      retries = 7
      # LC CHANGED 05.25.24 FROM 5=>7
      for attempt in range(retries):
          try:
              return api_call()
          except Exception as error:
              error_message = str(error)
              retry_errors = ['RATE_LIMIT_EXCEEDED', 'RESOURCE_EXHAUSTED', '429', 'SpreadsheetNotFound']
              if any(err in error_message for err in retry_errors):
                  print(f"Retryable error occurred: {error_message}. Retrying...")
                  time.sleep(sleep_time)  # Adjust as needed, maybe use exponential backoff
              else:
                  print("An error occurred:", error_message)
                  raise
      print("Maximum retries reached. Exiting...")
      raise RuntimeError("Maximum retries reached.")

  session = create_assertion_session(scope)
  client = Client(credentials,session)
  # auth

  if len(x) == 44:
    try:
      sht = retry_api_call(lambda: client.open_by_key(x))
    except:
      sht = retry_api_call(lambda: client.open(x))
  else:  
    sht = retry_api_call(lambda: client.open(x))
    
####   LC Added lines below 3.17.22   ####
  ss = retry_api_call(lambda: client.open_by_key(sht.id))
  
  if len(re.sub("[^0-9]", "", str(y)))==len(str(y)):
    ws = retry_api_call(lambda: sht.get_worksheet_by_id(int(y)))
  else:
    ws = retry_api_call(lambda: sht.worksheet(y))
####   LC Added lines above 3.17.22   ####
    
  # connect to workbook/sheet
  
    
####   LC Added lines below 3.17.22   ####
  if kwargs is not None and 'cell_range' in kwargs and len(re.sub("[^0-9]", "", str(y)))==len(str(y)):
    range_data = '%s!%s' % (ws.title,kwargs['cell_range'])
  
  elif kwargs is not None and 'cell_range' in kwargs:
    range_data = '%s' % kwargs['cell_range']
  else:
    range_data = '%s' % ws.title
  # specify cell range
  
####   LC Added lines above 3.17.22 (ws.title)   ####
  
  values = retry_api_call(lambda: ss.values_get(range_data))
  values = values['values']
  pd_df = pd.DataFrame(values)
  pd_df.fillna("",inplace=True) # convert None --> ''
  # clean up dataset
  
  headers = pd_df.iloc[0]
  headers = [x.lower() for x in headers] # convert series to list
  # get column headers from 0 index (ie. first) row
  
  cols = []
  
  if kwargs is not None and 'make_columns_unique' in kwargs:
    for x in range(0,len(headers)):
      if headers[:x].count(headers[x]) >= 1:
        cols.append(str(headers[x]) + str(headers[:x].count(headers[x])))
      else:
        cols.append(str(headers[x]))
  else:
    cols=headers
  
  pd_df  = pd.DataFrame(pd_df.values[1:], columns=cols)
  # make columns unique --> if duplicate columns, then append the column index to end of respective column name

  if kwargs is not None and 'append_to_col_header' in kwargs:
    pd_df.columns = ['%s%s' % (kwargs['append_to_col_header'],col_name) for col_name in pd_df.columns]  
    cols = [x.lower() for x in pd_df.columns.values]
    # append kwargs['append_to_col_header'] to beginning of column name
    
  try:
    spark_df = spark.createDataFrame(pd_df)  
  except:
    cleaned_cols = []
    for x in range(0,len(cols)):
      if cols[:x].count(cols[x]) >= 1:
        cleaned_cols.append(str(cols[x]) + str(cols[:x].count(cols[x])))
      else:
        cleaned_cols.append(str(cols[x]))
    
    pd_df = pd.DataFrame(pd_df.values[1:], columns=cleaned_cols)
    spark_df = spark.createDataFrame(pd_df)  
    # if there are still duplicates, then map the column index to the end of the column name by default
  
  if kwargs is not None and 'clean_column_names' in kwargs: 

    pandas_before = spark_df.toPandas()
    
    pandas_before.columns = [re.sub("[^a-zA-Z0-9]+","_",x) for x in pandas_before.columns]
    headers=[re.sub('__','_',re.sub('___','_',x)) for x in pandas_before.columns.values]
    headers = [x[0:len(x)-3] if x.endswith('___', 0, len(x)) else x.lower() for x in headers]
    headers = [x[0:len(x)-2] if x.endswith('__', 0, len(x)) else x.lower() for x in headers]
    headers = [x[0:len(x)-1] if x.endswith('_', 0, len(x)) else x.lower() for x in headers]
    pandas_before.columns = headers
    # remove special characters, but keep numbers, letters, and '_' in column header
    # resource: https://stackoverflow.com/questions/4283351/how-to-replace-special-characters-in-a-string
    
    cols=[]
    headers=[x.lower() for x in pandas_before.columns.values]
    for x in range(0,len(headers)):
      if headers[:x].count(headers[x]) >= 1:
        cols.append(str(headers[x]) + str(headers[:x].count(headers[x])))
      else:
        cols.append(str(headers[x]))

    pandas_before.columns=cols
    pd_df = pandas_before
    
    # double check to make sure that, after cleaning the column names, that there aren't any duplicate column names leftover

  if args:
    spark_df = spark.createDataFrame(pd_df)
    spark_df.createOrReplaceTempView(args[0]) 
  
  return (spark_df,pd_df,sht,ws,ss)

# COMMAND ----------

def authGoogleSheet(x): 
  # x --> Spreadsheet name or Spreadsheet ID
  
  import json
  import gspread
  from gspread import Client
  from authlib.integrations.requests_client import AssertionSession
  from oauth2client.service_account import ServiceAccountCredentials
#   from gspread_dataframe import get_as_dataframe, set_with_dataframe
#   LC : 1/6/22 - blocked off above code due to "ModuleNotFoundError: No module named 'gspread.models'" error
  import pandas as pd
  
  scope = ['https://spreadsheets.google.com/feeds',
           'https://www.googleapis.com/auth/drive']
  
  credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 

  def create_assertion_session(scopes, subject=None):
    token_url = credentials_dict['token_uri']
    issuer = credentials_dict['client_email']
    key = credentials_dict['private_key']
    key_id = credentials_dict['private_key_id']
    header = {'alg': 'RS256'}

    if key_id:
      header['kid'] = key_id
      # Google puts scope in payload
      claims = {'scope': ' '.join(scopes)}

      return AssertionSession(
        grant_type=AssertionSession.JWT_BEARER_GRANT_TYPE,
        token_endpoint=token_url,
        issuer=issuer,
        audience=token_url,
        claims=claims,
        subject=subject,
        key=key,
        header=header,
    )

  session = create_assertion_session(scope)
  client = Client(credentials,session)
  # auth
  
  if len(x) == 44:
    try:
      sht = client.open_by_key(x) 
    except:
      sht = client.open(x) 
  else:  
    sht = client.open(x) 
  return (sht)

# COMMAND ----------

def client(): 
  # this is to pull in the service account user's client variable -- which allows you to access more holistic metadata (how many sheets are shared with user etc)
  
  import json
  import gspread
  from gspread import Client
  from authlib.integrations.requests_client import AssertionSession
  from oauth2client.service_account import ServiceAccountCredentials
  from googleapiclient import discovery
#   from gspread_dataframe import get_as_dataframe, set_with_dataframe
#   LC : 1/6/22 - blocked off above code due to "ModuleNotFoundError: No module named 'gspread.models'" error
  import pandas as pd
  
  scope = ['https://spreadsheets.google.com/feeds',
           'https://www.googleapis.com/auth/drive']
  
  credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 
  service = discovery.build('sheets', 'v4', credentials=credentials)
  
  def create_assertion_session(scopes, subject=None):
    token_url = credentials_dict['token_uri']
    issuer = credentials_dict['client_email']
    key = credentials_dict['private_key']
    key_id = credentials_dict['private_key_id']
    header = {'alg': 'RS256'}

    if key_id:
      header['kid'] = key_id
      # Google puts scope in payload
      claims = {'scope': ' '.join(scopes)}

      return AssertionSession(
        grant_type=AssertionSession.JWT_BEARER_GRANT_TYPE,
        token_endpoint=token_url,
        issuer=issuer,
        audience=token_url,
        claims=claims,
        subject=subject,
        key=key,
        header=header,
    )

  session = create_assertion_session(scope)
  client = Client(credentials,session)
  
  return client

# COMMAND ----------

def service(): 
  # this is to pull in the service account user's client variable -- which allows you to access more holistic metadata (how many sheets are shared with user etc)
  
  import json
  import gspread
  from gspread import Client
  from authlib.integrations.requests_client import AssertionSession
  from oauth2client.service_account import ServiceAccountCredentials
  from googleapiclient import discovery
#   from gspread_dataframe import get_as_dataframe, set_with_dataframe
#   LC : 1/6/22 - blocked off above code due to "ModuleNotFoundError: No module named 'gspread.models'" error
  import pandas as pd
  
  scope = ['https://spreadsheets.google.com/feeds',
           'https://www.googleapis.com/auth/drive']
  
  credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 
  service = discovery.build('sheets', 'v4', credentials=credentials)
  
  return service

# COMMAND ----------

def update_sheet(x,y,z,**kwargs): 
  # x = sht = client.open_by_key(kwargs['open_by_key']) or sht = client.open(x)
  # y = converted pandas
  # z = sheet/cell location
  # optional: 'cell_range'
  
  
    
####   LC Added lines below 3.17.22   ####
  if kwargs is not None and 'cell_range' in kwargs and len(re.sub("[^0-9]", "", str(z)))==len(str(z)):
    sheet_address = '%s!%s' % (x.get_worksheet_by_id(int(z)).title,kwargs['cell_range'])
  
  else:
    sheet_address = z
####   LC Added lines above 3.17.22   ####
  

###    LC Added 6.8.22 - lines below to accomodate gspread issue w/ sheet titles that include ':' in then ####
  if sheet_address.split('!')[0].count(':') >= 1:
    print(f'Sheet Title ({sheet_address}) contains colon; removing colon and update will take place starting in cell A1.')
    sheet_address = sheet_address.split('!')[0]
###    LC Added 6.8.22 - lines above to accomodate gspread issue w/ sheet titles that include ':' in then ####
  
  
  updated_data = y
  x.values_update(
      sheet_address, 
      params={'valueInputOption': 'USER_ENTERED'}, 
      body={'values': updated_data}
  )

# COMMAND ----------

def removeFilter(x,y):
  # x = client.open_by_key(kwargs['open_by_key']) or client.open(x)
  # y = client.open_by_key(kwargs['open_by_key']).worksheet() or client.open(x).worksheet()
  sheetId          = y._properties['sheetId']

  body = {
      'requests': [{
          'clearBasicFilter': {
              'sheetId': sheetId
          }
      }]
  }
  x.batch_update(body)

# COMMAND ----------

def reapplyFilter(x,y,**kwargs):
  # x                 = client.open_by_key(kwargs['open_by_key']) or client.open(x)
  # y                 = client.open_by_key(kwargs['open_by_key']).worksheet() or client.open(x).worksheet()
  # filterColumnIndex = integer [ default: 1 ]
  # filter_by         = str     [ default: '']
  # startRowIndex     = integer [ default: 0 ]
  # startColumnIndex  = integer [ default: 0 ]
  
  if kwargs is not None and 'filter_by' in kwargs: 
    filterVal = kwargs['filter_by']
  else:
    filterVal = ''
    
  if kwargs is not None and 'startRowIndex' in kwargs: 
    startRowIndex = kwargs['startRowIndex']
  else:
    startRowIndex = 0
    
  if kwargs is not None and 'startColumnIndex' in kwargs: 
    startColumnIndex = kwargs['startColumnIndex']
  else:
    startColumnIndex = 0
    
  if kwargs is not None and 'filterColumnIndex' in kwargs: 
    filterColumnIndex = kwargs['filterColumnIndex']
  else:
    filterColumnIndex = 1
  
  sheet_properties = y._properties
  sheetId          = y._properties['sheetId']

  my_range = {
          'sheetId': sheetId,
          'startRowIndex': startRowIndex,
          'startColumnIndex': startColumnIndex,
          'endRowIndex': sheet_properties['gridProperties']['rowCount'],
          'endColumnIndex': sheet_properties['gridProperties']['columnCount'],
  }

  body = (
    {
      'requests': [{
          'setBasicFilter': {
              'filter': {
                  'range': my_range,
                  'criteria': {
                      filterColumnIndex: {
                          'hiddenValues': ['%s' % filterVal]
                          }
                      }
                  }
              }
          }]
      }
  )
  x.batch_update(body)

# COMMAND ----------

def autoFitCols(x,y,**kwargs):
  # x                 = client.open_by_key(kwargs['open_by_key']) or client.open(x)
  # y                 = client.open_by_key(kwargs['open_by_key']).worksheet() or client.open(x).worksheet()
  # startIndex        = integer [ default: 0 ]
  # endIndex          = integer [ default: # cols ]
  
  if kwargs is not None and 'startIndex' in kwargs: 
    startIndex = kwargs['startIndex']
  else:
    startIndex = 0
    
  if kwargs is not None and 'endIndex' in kwargs: 
    endIndex = kwargs['endIndex']
  else:
    endIndex = y._properties['gridProperties']['columnCount']
  
  sheetId    = y._properties['sheetId']

  body = (
    {
      "requests": [
        {
          "autoResizeDimensions": {
            "dimensions": {
              "sheetId": sheetId,
              "dimension": "COLUMNS",
              "startIndex": startIndex,
              "endIndex": endIndex
            }
          }
        }
      ]
    }
  )
  x.batch_update(body)

# COMMAND ----------

def auto_fit_columns(spreadsheet_id,sheet_id,**kwargs):
  # **kwargs:
  # startIndex        = integer [ default: 0 ]
  # endIndex          = integer [ default: # cols ]

  x = client().open_by_key(spreadsheet_id) 
  y = x.get_worksheet_by_id(sheet_id)
  
  if kwargs is not None and 'startIndex' in kwargs: 
    startIndex = kwargs['startIndex']
  else:
    startIndex = 0
    
  if kwargs is not None and 'endIndex' in kwargs: 
    endIndex = kwargs['endIndex']
  else:
    endIndex = y._properties['gridProperties']['columnCount']
  
  sheetId    = y._properties['sheetId']

  body = (
    {
      "requests": [
        {
          "autoResizeDimensions": {
            "dimensions": {
              "sheetId": sheetId,
              "dimension": "COLUMNS",
              "startIndex": startIndex,
              "endIndex": endIndex
            }
          }
        }
      ]
    }
  )
  x.batch_update(body)

# COMMAND ----------

def util_func_data(a,b,c,**kwargs): 
  # used to get data in the [Usecase Taxonomy with Descriptions, Segments, Theme Mappings] workbook
  # delim = optional arg that splits according to any delims present in the cell string
  
  import numpy 
  import re
  
  try: 
    url = a[b]['values'][c]['hyperlink']
    name = a[b]['values'][c]['formattedValue']
    class_data = '=HYPERLINK("%s","%s")' % (url,name)
  except:
    
    try:
      ## LC ADDED BELOW CODE 3.23.22 ##
      stringVal = str(a[b]['values'][c]['userEnteredValue']['stringValue'])

      if kwargs is not None and 'delim' in kwargs: 
        stringValList = stringVal.split(kwargs['delim'])

        print(f'cell string:{stringValList}')
        
        urlList = []
        [urlList.append(a[b]['values'][c]['textFormatRuns'][y]['format']['link']['uri']) if len(a[b]['values'][c]['textFormatRuns'][y]['format'])==4 else None \
                                                                                         for y in numpy.arange(0,len(a[b]['values'][c]['textFormatRuns']))]
        urlListNew = []
        for x in range(0,len(urlList)):
          if urlList[:x].count(urlList[x])==0:
            urlListNew.append(urlList[x])
            
        stringValListNew = []
        for x in range(0,len(stringValList)):
          if stringValList[:x].count(stringValList[x])==0:
            stringValListNew.append(stringValList[x])

        urlList=urlListNew
        stringValList=stringValListNew
        
        class_data = []
        for title in stringValList:
          url = urlList[stringValList.index(title)]
          class_data.append(f'=HYPERLINK("{url}","{title}")')
        
        class_data = str(class_data)
      ## LC ADDED ABOVE CODE 3.23.22 ##
      
      else:
        url = ['=HYPERLINK("%s","test")' % a[b]['values'][c]['textFormatRuns'][y]['format']['link']['uri'] for y in numpy.arange(1,len(a[b]['values'][c]['textFormatRuns']))[::2]]

        index=[x for x in [x if x[0]<x[1] else (x[0],None) for x in [(a[b]['values'][c]['textFormatRuns'][y]['startIndex'],\
                                                                     [a[b]['values'][c]['textFormatRuns'][y]['startIndex'] \
                                                                      for y in numpy.arange(1,len(a[b]['values'][c]['textFormatRuns']))[1::2]][0]) for y in \
                                                                               numpy.arange(1,len(a[b]['values'][c]['textFormatRuns']))[::2]]]]
        
        title = [a[b]['values'][c]['userEnteredValue']['stringValue'][index[x][0]:index[x][1]] for x in numpy.arange(0,len(index))]
        
        class_data = str([re.sub('test',y,url[title.index(y)]) for y in title])
    except:
      try:
        class_data = a[b]['values'][c]['formattedValue']
      except:
        class_data = ''
    print(class_data)
  return class_data

# COMMAND ----------

# DBTITLE 1,GSpread Data Extraction Tool
def get_sheet_data_with_URL_orig(x,y,z,**kwargs): 
  # x = Spreadsheet name or Spreadsheet ID
  # y = sheet name 
  # z = starting row  
  # row_1_is_header --> sets the top row as your header row
  # clean_column_names  (optional)
  # make_columns_unique (optional)
  
  import gspread
  import json
  from gspread import Client
  from authlib.integrations.requests_client import AssertionSession
  from oauth2client.service_account import ServiceAccountCredentials
#   from gspread_dataframe import get_as_dataframe, set_with_dataframe
#   LC : 1/6/22 - blocked off above code due to "ModuleNotFoundError: No module named 'gspread.models'" error
  import pandas as pd
  import json
  from googleapiclient import discovery
  import numpy
  import re
  import time
  import datetime

  today = datetime.date.today()
  current_date = today.strftime('%Y-%m-%d')

  SCOPES = ['https://spreadsheets.google.com/feeds',
           'https://www.googleapis.com/auth/drive','https://www.googleapis.com/auth/analytics.readonly']

  credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 

  def create_assertion_session(scopes, subject=None):
    token_url = credentials_dict['token_uri']
    issuer = credentials_dict['client_email']
    key = credentials_dict['private_key']
    key_id = credentials_dict['private_key_id']
    header = {'alg': 'RS256'}

    if key_id:
      header['kid'] = key_id
      # Google puts scope in payload
      claims = {'scope': ' '.join(scopes)}

      return AssertionSession(
        grant_type=AssertionSession.JWT_BEARER_GRANT_TYPE,
        token_endpoint=token_url,
        issuer=issuer,
        audience=token_url,
        claims=claims,
        subject=subject,
        key=key,
        header=header,
    )

  session = create_assertion_session(SCOPES)
  client = Client(credentials,session)
  
  service = discovery.build('sheets', 'v4', credentials=credentials)
  
  if len(x) == 44:
    try:
      sht = client.open_by_key(x) 
    except:
      sht = client.open(x) 
  else:  
    sht = client.open(x) 

  sheet_properties = sht.worksheet(y)._properties
  sheetId          = sht.worksheet(y)._properties['sheetId']

  #   sheet_properties = ss.get_worksheet(z)._properties
  #   sheetId          = ss.get_worksheet(z)._properties['sheetId']
  #   gets worksheet by index

  # The spreadsheet to request.
  spreadsheet_id = sht.id 

  # The ranges to retrieve from the spreadsheet.
  ranges = [sheet_properties['title']]

  # True if grid data should be returned.
  # This parameter is ignored if a field mask was set in the request.
  include_grid_data = 'false'

  # process the `response` dict. 
  request = service.spreadsheets().get(spreadsheetId=spreadsheet_id, ranges=ranges, includeGridData=include_grid_data)

  try:
    response = request.execute()
  except Exception as e:
    print(e)
    time.sleep(60)
    response = request.execute()

  # this will tells us the pixelated size of the columns (ie. which columns are (partially) 'hidden' vs. 'visible')
  data = response['sheets'][0]['data'][0]['rowData']
  # create dict that will be used to capture hiddle / visible columns

  list_of_list = []

  for i in numpy.arange(z,len(data)): 
    # 4 AKA - we want to skip the first four rows --> (IMPORTANT bc this would break if new rows added at top)
    # alternative to range() --> doing this because gspread has range function --> which I think conflicts with built-in range function
    print(' ')
  
  
  ## LC ADDED BELOW CODE 3.23.22 ##
    if kwargs is not None and 'delim' in kwargs:
      list_of_list.append([util_func_data(data,i,x,delim=kwargs['delim']) for x in numpy.arange(0, len(data[i]['values']))])
    else:
      list_of_list.append([util_func_data(data,i,x) for x in numpy.arange(0, len(data[i]['values']))])
  ## LC ADDED ABOVE CODE 3.23.22 ##
  
  cols = []
  
  if kwargs is not None and 'row_1_is_header' in kwargs:
    for x in range(0,len(list_of_list[0])):
      if list_of_list[0][:x].count(list_of_list[0][x]) >= 1:
        cols.append(str(list_of_list[0][x]) + str(list_of_list[0][:x].count(list_of_list[0][x])))
      else:
        cols.append(str(list_of_list[0][x]))
    
    df = pd.DataFrame(data=list_of_list[1:],columns=cols)
  else:
    df = pd.DataFrame(data=list_of_list)
    
    
  if kwargs is not None and 'clean_column_names' in kwargs: 

    df.columns = [re.sub("[^a-zA-Z0-9]+","_",x) for x in df.columns]
    headers=[re.sub('__','_',re.sub('___','_',x)) for x in df.columns.values]
    headers = [x[0:len(x)-3] if x.endswith('___', 0, len(x)) else x.lower() for x in headers]
    headers = [x[0:len(x)-2] if x.endswith('__', 0, len(x)) else x.lower() for x in headers]
    headers = [x[0:len(x)-1] if x.endswith('_', 0, len(x)) else x.lower() for x in headers]
    df.columns = headers
    # remove special characters, but keep numbers, letters, and '_' in column header
    # resource: https://stackoverflow.com/questions/4283351/how-to-replace-special-characters-in-a-string
  
  
  cols = [x for x in df.columns]

  colsUpdated = []
  
  if kwargs is not None and 'make_columns_unique' in kwargs:
    for x in range(0,len(cols)):
      if cols[:x].count(cols[x]) >= 1:
        colsUpdated.append(str(cols[x]) + str(cols[:x].count(cols[x])))
      else:
        colsUpdated.append(str(cols[x]))
  else:
    colsUpdated=cols
  
  df.columns = colsUpdated 
    
  return df
  # create df

# COMMAND ----------

def set_all_spark_df_columns_to_strings(spark_df):
  p_df = spark_df.toPandas()
  p_df[p_df.columns] = p_df[p_df.columns].astype(str)
  spark_df = spark.createDataFrame(p_df)
  return spark_df

# COMMAND ----------

from pyspark.sql.functions import *

def gsheetPandasConversion(spark_df,**kwargs):
  # optional: pushDfAsHtml

  # LC ADDED BELOW 03.28.24 (SERVERLESS ANSI-COMPLIANCE)
  # for dataType in spark_df.dtypes:
  #   col_name = dataType[0]
  #   col_type = dataType[1]

  #   if col_type=='boolean':
  #     spark_df = spark_df.withColumn(col_name,when(col(col_name).isNull(),False).otherwise(col(col_name)).cast("string"))

  #   elif col_type.find('array') != -1:
  #     spark_df = spark_df.withColumn(col_name,when(col(col_name).isNull(),array()).otherwise(col(col_name)).cast("string"))
      
  #   else:
  #     spark_df = spark_df.withColumn(col_name,when(col('`'+col_name+'`').isNull(),'').otherwise(col('`'+col_name+'`')))
        
  for dataType in spark_df.dtypes:
    col_name = dataType[0]
    col_type = dataType[1]

    # if col_type=='boolean':
    #   spark_df = spark_df.withColumn(col_name,when(col(col_name).isNull(),False))
    
    if col_type == 'boolean':
      spark_df = spark_df.withColumn(col_name, when(col(col_name).isNull(), False).otherwise(col(col_name)))

    elif col_type.find('array') != -1:
      spark_df = spark_df.withColumn(col_name, when(col(col_name).isNull(), array()).otherwise(col(col_name)))

  spark_df = set_all_spark_df_columns_to_strings(spark_df)
  # converts all columns to strings
  # LC ADDED ABOVE 03.28.24 (SERVERLESS ANSI-COMPLIANCE)

  spark_df = spark_df.fillna('').replace('NaN','').replace('nan','').replace('None','').replace('none','')
  # LC ADDED 04.03.24 PER MARINA Z. SLACK
  
  if kwargs is not None and 'pushDfAsHtml' in kwargs:
    string = spark_df.toPandas().to_html(escape=False,index=False)
    string = string.split('<thead>')[0] + string.split('</thead>')[1]
    return string
  else:
    return spark_df.toPandas().values.tolist()

# COMMAND ----------

def getAllSheetRowMetadata(x,y,**kwargs): 
  # x = Spreadsheet ID
  # y = sheet id
  
  wb        = client().open_by_key(x) 
  sheet     = wb.get_worksheet_by_id(int(y))

  sheet_properties = sheet._properties
  spreadsheet_id   = int(y)

  # The ranges to retrieve from the spreadsheet.
  ranges = [sheet_properties['title']]

  # True if grid data should be returned.
  # This parameter is ignored if a field mask was set in the request.
  include_grid_data = 'false'

  # process the `response` dict. 
  request = service().spreadsheets().get(spreadsheetId=x, ranges=ranges, includeGridData=include_grid_data)
  response = request.execute()

  # this will tells us the pixelated size of the columns (ie. which columns are (partially) 'hidden' vs. 'visible')
  data = response['sheets'][0]['data'][0]['rowData']
  
  return data

# COMMAND ----------

def reprocessSheetData(x,sheetId,data):
  # x = workbook_id
  x = client().open_by_key(x)
  
  body = (
    {
      "requests": [
        {
          "update_cells": {
            "fields": "*",
            "range": {
              "sheet_id": sheetId,
              "start_column_index": 0,
              "start_row_index": 0,
            },
            "rows": data,
          },
        },
      ]
    }
  )
  x.batch_update(body)

# COMMAND ----------

def pushDfAsHtmlToSheet(x,sheetId,colIndex,list_of_html_of_df,rowIndex,kwargs):
  # x                  = client.open_by_key(kwargs['open_by_key']) or client.open(x)
  # list_of_html_of_df = list of the converted DF's html
  # OPTIONAL ARGS:
  # - horizontalAlignment (CENTER,LEFT,RIGHT)
  # - verticalAlignment (MIDDLE,BOTTOM,TOP)
  # - fontFamily
  # - fontSize
  # - wrapStrategy (WRAP,OVERFLOW,CLIP)
  
  workbook_id = x
  
  x = client().open_by_key(workbook_id)

  body = (
    {
      "requests": [
        {
          "pasteData": {
            "html": True,
            "data": list_of_html_of_df,
            "coordinate": {
              "sheetId": sheetId,
              "columnIndex": colIndex,
              "rowIndex": rowIndex
            },
          },
        },
      ]
    }
  )
  x.batch_update(body)
  
  time.sleep(5)
  
  data = getAllSheetRowMetadata(workbook_id,sheetId)
  
  ## -- LC ADDED BELOW 11.11.22 TO ACCOUNT FOR FORMATTING USE CASE -- ## 
  
  list_of_nested_dicts = []
  for i in data:
    try:
      nestedDict = dict(i)['values']
      if data.index(i) >= rowIndex: 
        # INTERPRETATION FOR LINE ABOVE: "ONLY UPDATE THE FORMAT OF THE BODY; PRESERVE EXISTING FORMAT OF EVERYTHING ABOVE BODY (HEADERS ETC)"
        for x in nestedDict:
          try:

            try:
              effectiveFormat = x['effectiveFormat']
            except:
              effectiveFormat = {}
              x['effectiveFormat'] = effectiveFormat

            try:
              userEnteredFormat = x['userEnteredFormat']
            except:
              userEnteredFormat = {}
              x['userEnteredFormat'] = userEnteredFormat



            if kwargs is not None and 'horizontalAlignment' in kwargs:
              effectiveFormat.update({'horizontalAlignment': kwargs['horizontalAlignment']})

            if kwargs is not None and 'horizontalAlignment' in kwargs:
              effectiveFormat.update({'verticalAlignment': kwargs['verticalAlignment']})

            if kwargs is not None and 'wrapStrategy' in kwargs:
              effectiveFormat.update({'wrapStrategy': kwargs['wrapStrategy']})

            x.update({'effectiveFormat':effectiveFormat})


            try:
              if kwargs is not None and 'fontFamily' in kwargs:
                textFormat = effectiveFormat['textFormat']
                textFormat.update({'fontFamily': kwargs['fontFamily']})

              if kwargs is not None and 'fontSize' in kwargs:
                textFormat = effectiveFormat['textFormat']
                textFormat.update({'fontSize': kwargs['fontSize']})


              try:
                if kwargs is not None and 'horizontalAlignment' in kwargs:
                  userEnteredFormat.update({'horizontalAlignment': kwargs['horizontalAlignment']})

                if kwargs is not None and 'verticalAlignment' in kwargs:
                  userEnteredFormat.update({'verticalAlignment': kwargs['verticalAlignment']})

                if kwargs is not None and 'wrapStrategy' in kwargs:
                  userEnteredFormat.update({'wrapStrategy': kwargs['wrapStrategy']})

                if kwargs is not None and 'fontFamily' in kwargs:
                  try:
                    textFormat = userEnteredFormat['textFormat']
                    textFormat.update({'fontFamily': kwargs['fontFamily']})
                  except:
                    userEnteredFormat.update({'textFormat':{'fontFamily': kwargs['fontFamily']}})

                if kwargs is not None and 'fontSize' in kwargs:
                  try:
                    textFormat = userEnteredFormat['textFormat']
                    textFormat.update({'fontSize': kwargs['fontSize']})
                  except:
                    userEnteredFormat.update({'textFormat':{'fontSize': kwargs['fontSize']}})

              except:
                continue

            except:
              continue

          except:
            continue
    except:
      nestedDict = {}

    list_of_nested_dicts.append({'values':nestedDict})

  data = list_of_nested_dicts#[{'values':list_of_nested_dicts[0]}]
  
  ## -- LC ADDED ABOVE 11.11.22 -- ##
  
  reprocessSheetData(workbook_id,sheetId,data)

# COMMAND ----------

def removeSheetFormattingFromRowIndexDownwards(x,sheetId,startRowIndex):
  # x                  = client.open_by_key(kwargs['open_by_key']) or client.open(x)
  # list_of_html_of_df = list of the converted DF's html
  
  x = client().open_by_key(x)

  body = (
    {
      "requests": [
        {
          "updateCells": {
            "range": 
              {
                "sheetId":sheetId,
                "startRowIndex":startRowIndex-1
              },
            "fields": "userEnteredFormat"
          },
        },
      ]
    }
  )
  x.batch_update(body)
# https://stackoverflow.com/questions/51389147/how-to-request-updatecells-for-multiple-rows-to-have-the-same-value

# COMMAND ----------

import time
import re

def column_string(n):
    string = ""
    while n > 0:
        n, remainder = divmod(n - 1, 26)
        string = chr(65 + remainder) + string
    return string
  
def refreshDataInSheet(sheet_name,\
                       pandas_df,\
                       workbook_name_or_id,\
                       row_number_to_push_into,\
                       column_letter_to_push_into,\
                       startRowIndexFilter,\
                       columnIndexFilter,\
                       **kwargs): 
  
                       # pause_between_sheet_updates = seconds to wait before next proceeding w/ next step in update 
                       # preserve_last_n_columns     = basically allows you to preserve the values in the x right-most column(s) 
                       # (^otherwise they'll be deleted)
        
                       # excludeFromColFilter = allows you to specify the value that you'd like to filter out of your table
                       # pushDfAsHtml         = will push a list of the converted DF's html into the spreadsheet
                       
                       # OPTIONAL ARGS (for pushDfAsHtmlToSheet()):
                       # - horizontalAlignment (CENTER,LEFT,RIGHT)
                       # - verticalAlignment (MIDDLE,BOTTOM,TOP)
                       # - fontFamily
                       # - fontSize
                       # - wrapStrategy (WRAP,OVERFLOW,CLIP)
  
  wb = authGoogleSheet(workbook_name_or_id)
  
  ####   LC Added lines below 3.17.22   ####
  if len(re.sub("[^0-9]", "", str(sheet_name)))==len(str(sheet_name)):
    sht_id     = int(sheet_name)
    sht        = wb.get_worksheet_by_id(int(sheet_name))
    sheet_name = sht.title
  else:
    sht = wb.worksheet('%s' % sheet_name)
  # connect to workbook/sheet
  
  #   sht = wb.worksheet('%s' % sheet_name)
  ####   LC Added lines above 3.17.22   ####

  sht_cols = sht._properties['gridProperties']['columnCount']
  
  if kwargs is not None and 'preserve_last_n_columns' in kwargs:
    end_col = column_string(sht_cols-int(kwargs['preserve_last_n_columns']))
  else:
    end_col = column_string(sht_cols)
    
  
  try:
    seconds = kwargs['pause_between_sheet_updates']
  except:
    seconds = 1
    
  removeFilter(wb,sht)
  time.sleep(seconds)
  
  if kwargs is not None and 'push_spark_df_headers_into_sheet' in kwargs:
    cols_df = [[x for x in kwargs['push_spark_df_headers_into_sheet'].columns]]
    update_sheet(wb,cols_df,"%s!%s%s" % (sheet_name,column_letter_to_push_into,row_number_to_push_into-1))
  else:
    pass
  
  wb.values_clear("%s!%s%s:%s" % (sheet_name,column_letter_to_push_into,row_number_to_push_into,end_col))
  time.sleep(seconds)

  # LC ADDED BELOW 11.12.22 -- TO ACCOUNT FOR SCENARIOS WHERE WE WANT TO PUSH RAW HTML TO TABLE
  
  if kwargs is not None and 'pushDfAsHtml' in kwargs:
    removeSheetFormattingFromRowIndexDownwards(workbook_name_or_id,sht_id,row_number_to_push_into)
    
    colIndex = ord(column_letter_to_push_into.lower())-97
    pushDfAsHtmlToSheet(workbook_name_or_id,sht_id,colIndex,pandas_df,row_number_to_push_into-1,kwargs)
  # LC ADDED ABOVE 11.12.22
  else:
    update_sheet(wb,pandas_df,"%s!%s%s" % (sheet_name,column_letter_to_push_into,row_number_to_push_into))
  time.sleep(seconds)
  
  
  if kwargs is not None and 'excludeFromColFilter' in kwargs: 
    reapplyFilter(wb,sht,startRowIndex=startRowIndexFilter,filterColumnIndex=columnIndexFilter,filter_by=kwargs['excludeFromColFilter'])
  else:
    reapplyFilter(wb,sht,startRowIndex=startRowIndexFilter,filterColumnIndex=columnIndexFilter)


# COMMAND ----------

import gspread
from gspread import Client
from authlib.integrations.requests_client import AssertionSession
from oauth2client.service_account import ServiceAccountCredentials

scope = ['https://spreadsheets.google.com/feeds',
         'https://www.googleapis.com/auth/drive']

credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 

# COMMAND ----------

class gsheetFunctions:
  def __init__(self):
    super()
    
  def credentials(self):
    import json
    import gspread
    from gspread import Client
    from authlib.integrations.requests_client import AssertionSession
    from oauth2client.service_account import ServiceAccountCredentials
    from googleapiclient import discovery

    scope = ['https://spreadsheets.google.com/feeds',
             'https://www.googleapis.com/auth/drive']

    credentials       = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 
    return credentials
  
  def sheets(self):
    import json
    import gspread
    from gspread import Client
    from authlib.integrations.requests_client import AssertionSession
    from oauth2client.service_account import ServiceAccountCredentials
    from googleapiclient import discovery

    scope = ['https://spreadsheets.google.com/feeds',
             'https://www.googleapis.com/auth/drive']

    credentials       = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 
    sheets_service    = discovery.build('sheets', 'v4', credentials=credentials)
    return sheets_service
  
  def analytics(self):
    import json
    import gspread
    from gspread import Client
    from authlib.integrations.requests_client import AssertionSession
    from oauth2client.service_account import ServiceAccountCredentials
    from googleapiclient import discovery

    scope = ['https://spreadsheets.google.com/feeds',
             'https://www.googleapis.com/auth/drive']

    credentials       = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 
    analytics_service = discovery.build('analyticsreporting', 'v4', credentials=credentials)
    return analytics_service
  
  def drive(self):
    import json
    import gspread
    from gspread import Client
    from authlib.integrations.requests_client import AssertionSession
    from oauth2client.service_account import ServiceAccountCredentials
    from googleapiclient import discovery

    scope = ['https://spreadsheets.google.com/feeds',
             'https://www.googleapis.com/auth/drive']

    credentials       = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 
    drive_service     = discovery.build('drive', 'v2', credentials=credentials)
    return drive_service
  
  def slides(self):
    import json
    import gspread
    from gspread import Client
    from authlib.integrations.requests_client import AssertionSession
    from oauth2client.service_account import ServiceAccountCredentials
    from googleapiclient import discovery

    scope = ['https://spreadsheets.google.com/feeds',
             'https://www.googleapis.com/auth/drive']

    credentials       = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict) 
    slides_service    = discovery.build('slides', 'v1', credentials=credentials)
    return slides_service

# COMMAND ----------

def displayWorksheetDict(wb_id: str):
  wb_id           = wb_id
  wb              = authGoogleSheet(wb_id)
  worksheets      = [[x.title,x.id] for x in wb.worksheets()]
  worksheets_dict = {item[0]: item[1:][0] for item in worksheets}
  for i in worksheets_dict:
    print (f"{i:<30}{worksheets_dict[i]}")
  print()
  return worksheets_dict

# COMMAND ----------

# MAGIC %md
# MAGIC # v2

# COMMAND ----------


###########################
####### VERSION 2 #########
###########################

import pandas as pd
import re
import urllib
import gspread
from gspread import Client

from authlib.integrations.requests_client import AssertionSession
from oauth2client.service_account import ServiceAccountCredentials
from google.oauth2.credentials import Credentials
from googleapiclient import discovery
from typing import Dict, Union, Optional, Tuple, Any, List

# LC ADDED 03.30.24 
def retry_api_call(api_call,sleep_time=60):
    retries = 7
    # LC CHANGED 05.25.24 FROM 5=>7
    for attempt in range(retries):
        try:
            return api_call()
        except Exception as error:
            error_message = str(error)
            retry_errors = ['RATE_LIMIT_EXCEEDED', 'RESOURCE_EXHAUSTED', '429', 'SpreadsheetNotFound']
            if any(err in error_message for err in retry_errors):
                print(f"Retryable error occurred: {error_message}. Retrying...")
                time.sleep(sleep_time)  # Adjust as needed, maybe use exponential backoff
            else:
                print("An error occurred:", error_message)
                raise
    print("Maximum retries reached. Exiting...")
    raise RuntimeError("Maximum retries reached.")

def generate_credentials_dict(credentials: Dict):
  
    """
    Purpose:
        Generate a dictionary containing the Google service account credentials.
    Args:
        project_id (str): The ID of the project containing the Google service account.
        private_key_id (str): The ID of the private key.
        private_key (str): The private key.
        client_email (str): The email address associated with the Google service account.
        client_id (str): The client ID associated with the Google service account.
    Returns:
        A dictionary containing the Google service account credentials.
    """
    
    # Ensure that all required keys are present
    assert "project_id" in credentials.keys(), "Error: 'project_id' key not found in `credentials`"
    assert "private_key_id" in credentials.keys(), "Error: 'private_key_id' key not found in `credentials`"
    assert "private_key" in credentials.keys(), "Error: 'private_key' key not found in `credentials`"
    assert "client_email" in credentials.keys(), "Error: 'client_email' key not found in `credentials`"
    assert "client_id" in credentials.keys(), "Error: 'client_id' key not found in `credentials`"

    # Extract the necessary values
    project_id = credentials["project_id"]
    private_key_id = credentials["private_key_id"]
    private_key = credentials["private_key"]
    client_email = credentials["client_email"]
    client_id = credentials["client_id"]
    
    type = 'service_account'
    auth_uri = 'https://accounts.google.com/o/oauth2/auth'
    token_uri = 'https://oauth2.googleapis.com/token'
    auth_provider_x509_cert_url = 'https://www.googleapis.com/oauth2/v1/certs'
    private_key = private_key.replace('\\n', '\n')
    
    credentials_dict = {
        'type': type,
        'project_id': project_id,
        'private_key_id': private_key_id,
        'private_key': f'-----BEGIN PRIVATE KEY-----\n{private_key}\n-----END PRIVATE KEY-----\n',
        'client_email': client_email,
        'client_id': client_id,
        'auth_uri': auth_uri,
        'token_uri': token_uri,
        'auth_provider_x509_cert_url': auth_provider_x509_cert_url,
        'client_x509_cert_url': f'https://www.googleapis.com/robot/v1/metadata/x509/{urllib.parse.quote(client_email)}'
    }
    return credentials_dict
  
def create_assertion_session(credentials_dict: Dict, subject: Optional[str] = None) -> AssertionSession:
    """
    Creates an assertion session using the provided credentials dictionary and subject.
    Args:
        credentials_dict: A dictionary containing the credentials to be used for the assertion session.
        subject: The subject of the assertion session.
    Returns:
        An AssertionSession object.
    """
    scopes = ['https://spreadsheets.google.com/feeds',
              'https://www.googleapis.com/auth/drive',
              'https://www.googleapis.com/auth/documents',\
              'https://www.googleapis.com/auth/analytics.readonly',
              'https://www.googleapis.com/auth/presentations']

    token_url = credentials_dict['token_uri']
    issuer = credentials_dict['client_email']
    key = credentials_dict['private_key']
    key_id = credentials_dict['private_key_id']
    header = {'alg': 'RS256'}

    if key_id:
        header['kid'] = key_id
    claims = {'scope': ' '.join(scopes)}

    return AssertionSession(
        grant_type=AssertionSession.JWT_BEARER_GRANT_TYPE,
        token_endpoint=token_url,
        issuer=issuer,
        audience=token_url,
        claims=claims,
        subject=subject,
        key=key,
        header=header,
    )
    
def get_credentials(credentials_dict: Dict) -> Tuple[ServiceAccountCredentials, AssertionSession]:
    """
    Returns a tuple containing credentials and an assertion session.
    Args:
        credentials_dict (dict): A dictionary containing credentials.
    Returns:
        Tuple[ServiceAccountCredentials, AssertionSession]: A tuple containing credentials and an assertion session.
    """

    scopes = ['https://spreadsheets.google.com/feeds',\
              'https://www.googleapis.com/auth/drive',\
              'https://www.googleapis.com/auth/documents',\
              'https://www.googleapis.com/auth/analytics.readonly',\
              'https://www.googleapis.com/auth/presentations']
    
    credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict)
    session = create_assertion_session(credentials_dict)
    return credentials, session

def get_client(credentials_dict: Dict) -> Client:
    """
    Returns an authorized client object for using the Google Sheets API.
    Parameters:
    credentials_dict (dict): Dictionary containing the service account credentials.
    Returns:
    gspread.Client: An authorized client object for using the Google Sheets API.
    """
    
    credentials, session = get_credentials(credentials_dict)
    return Client(credentials, session)

def get_service(credentials_dict: Dict):
    from googleapiclient import discovery
    """
    Returns an instance of the Google Sheets API client.
    Parameters:
    credentials_dict (dict): A dictionary containing service account credentials.
    Returns:
    Resource: An instance of the Google Sheets API client.
    """
    
    credentials, session = get_credentials(credentials_dict)
    return discovery.build('sheets', 'v4', credentials=credentials)

def open_spreadsheet_by_id(retries,credentials_dict,spreadsheet_id):
    while retries < 5:
        try:
            gc = get_client(credentials_dict).open_by_key(spreadsheet_id)
            break

        except Exception as e:
            print(f"Error: {e}")
            retries += 1
            if retries < 5:
                print(f"Retrying... (Attempt {retries}/5)")
                time.sleep(20)
            else:
                print("Max retries reached. Unable to open spreadsheet.")
                raise
    return gc

def auth_google_sheet(spreadsheet_id: str, credentials_dict: Dict):
    """
    Authenticate with Google Sheets API using service account credentials.
    Parameters:
    - spreadsheet_id: str - the ID of the spreadsheet to authenticate for
    - credentials_dict: Dict - a dictionary containing the service account credentials
    
    Returns:
    - gsheet: gspread.models.Spreadsheet - an authenticated instance of the Google Sheets API
    """
    
    scopes = ['https://spreadsheets.google.com/feeds',\
              'https://www.googleapis.com/auth/drive',\
              'https://www.googleapis.com/auth/documents',\
              'https://www.googleapis.com/auth/analytics.readonly',\
              'https://www.googleapis.com/auth/presentations']
    
    credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict)
    session = create_assertion_session(credentials_dict)
    client = Client(credentials, session)
    if len(spreadsheet_id) == 44:
        try:
            gsheet = open_spreadsheet_by_id(retries=0,credentials_dict=credentials_dict,spreadsheet_id=spreadsheet_id)
        except:
            gsheet = client.open(spreadsheet_id)
    else:
        gsheet = client.open(spreadsheet_id)
    return gsheet

def update_sheets(client, data, sheet, cell_range):
    """
    Updates the data of a sheet in a Google Sheets workbook with a given set of data.
    Args:
    - client (gspread.Client): an authorized Google Sheets API client.
    - data (list[list[str]]): the data to write to the sheet.
    - sheet (gspread.Worksheet): the worksheet object of the target sheet the data is going into. 
    - cell_range (str): the cell or range to update with the provided data (use R1C1 notation).
    Returns: None
    """
    
    sheet_title = sheet.title
    
    sheet_address = f'{sheet_title}!{cell_range}'
    
    if sheet_address.split('!')[0].count(':') >= 1:
        print(f'Sheet Title ({sheet_address}) contains colon; removing colon and update will take place starting in cell A1.')
        sheet_address = sheet_address.split('!')[0]

    print(sheet_address)
    
    try:
        client.values_update(sheet_address, params={'valueInputOption': 'USER_ENTERED'}, body={'values': data})
    except Exception as e:
        if 'try again' in str(e).lower():
            t = 45
            print(f'Initial sheet update failed due to error: {e}\nTrying again in {t} seconds')
            time.sleep(t)
            client.values_update(sheet_address, params={'valueInputOption': 'USER_ENTERED'}, body={'values': data})
        else:
            print(f'Error (`update_sheets`): {e}')

def remove_filter(client, sheet):
    """
    Removes any existing basic filter from the specified sheet.
    
    Args:
    - client (googleapiclient.discovery.Resource): authenticated Google Sheets API client object
    - sheet (gspread.Worksheet): the worksheet object to remove the filter from
    
    Returns: None
    """
    
    sheetId = sheet._properties['sheetId']
    body = {
        'requests': [{
            'clearBasicFilter': {
                'sheetId': sheetId
            }
        }]
    }
    client.batch_update(body)

def apply_filter(client, sheet, **kwargs: Any) -> None:
    """
    Reapply filters to a Google Sheet.
    Args:
        client (Resource): The Google Sheets API client.
        sheet (Resource): The Google Sheet to update.
        **kwargs: Additional arguments to configure filter settings.
            string_exclusion_filter (str): String value used to filter out rows (for a column) that you would like to be filtered out post-update.
            startRowIndex (int): The starting row index to apply the filter to. Default is 0.
            startColumnIndex (int): The index of the column you would like to start the filter at. Default is 0 (ie. column A).
            filterColumnIndex (int): The index of the column to apply the actual filter to. Default is 0 (ie. column A).
    """
    string_exclusion_filter = kwargs.get('string_exclusion_filter', '')
    start_row_index  = kwargs.get('startRowIndex', 0)
    start_col_index  = kwargs.get('startColumnIndex', 0)
    filter_col_index = kwargs.get('filterColumnIndex', 0)
    
    sheet_props = sheet._properties
    grid_props = sheet_props.get('gridProperties', {})
    row_count = grid_props.get('rowCount', 0)
    col_count = grid_props.get('columnCount', 0)
    
    filter_range = {
        'sheetId': sheet_props.get('sheetId', 0),
        'startRowIndex': start_row_index,
        'startColumnIndex': start_col_index,
        'endRowIndex': row_count,
        'endColumnIndex': col_count
    }
    
    criteria = {filter_col_index: {'hiddenValues': [f'{string_exclusion_filter}']}}
    
    filter_settings = {'range': filter_range, 'criteria': criteria}
    basic_filter = {'setBasicFilter': {'filter': filter_settings}}
    requests = [{'updateSheetProperties': {'properties': sheet_props, 'fields': 'gridProperties'}}]
    requests.append(basic_filter)
    
    body = {'requests': requests}
    client.batch_update(body)

def auto_fit_cols(client, sheet, **kwargs: Any) -> None:
    """
    Auto-fits columns in a worksheet.
    Args:
    - client: gspread.client.Client - The authenticated client object.
    - sheet: gspread.Worksheet - The worksheet to be processed.
    - kwargs:
        - startIndex: int - The index of the starting column (inclusive) to be processed. (default: 0)
        - endIndex: int - The index of the ending column (exclusive) to be processed. (default: the total number of columns in the worksheet)
    Returns: None
    """

    start_index = kwargs.get('startIndex', 0)
    end_index = kwargs.get('endIndex', sheet.col_count)

    body = {
        "requests": [
            {
                "autoResizeDimensions": {
                    "dimensions": {
                        "sheetId": sheet.id,
                        "dimension": "COLUMNS",
                        "startIndex": start_index,
                        "endIndex": end_index
                    }
                }
            }
        ]
    }
    
    client.batch_update(body)

def gsheet_pandas_conversion(spark_df, **kwargs) -> Union[str, List[List[Union[str, int, float]]]]:
    """
    Converts a PySpark DataFrame to a Pandas DataFrame.
    Args:
        spark_df (DataFrame): A PySpark DataFrame.
        push_df_as_html (bool, optional): A flag indicating whether to return an HTML table.
        html_table_style (str, optional): The style string to apply to the HTML table.
    Returns:
        If `push_df_as_html` is True, an HTML table string. Otherwise, a list of lists representing the Pandas DataFrame.
    """
  
    # Get the original column names
    original_columns = spark_df.columns
    
    # Rename duplicate columns to make them unique
    new_columns = []
    for x in range(len(original_columns)):
        if original_columns[:x].count(original_columns[x]) >= 1:
            new_columns.append(str(original_columns[x]) + str(original_columns[:x].count(original_columns[x])))
        else:
            new_columns.append(str(original_columns[x]))

    spark_df = spark_df.toDF(*new_columns)

    
    # LC ADDED BELOW 03.28.24 (SERVERLESS ANSI-COMPLIANCE)
    # # Convert boolean and array columns to string
    # for col_name, col_type in spark_df.dtypes:
    #     if col_type == 'boolean':
    #         spark_df = spark_df.withColumn(col_name, when(col(col_name).isNull(), False).otherwise(col(col_name)).cast('string'))
    #     elif col_type.find('array') != -1:
    #         spark_df = spark_df.withColumn(col_name, when(col(col_name).isNull(), array()).otherwise(col(col_name)).cast('string'))
    #     else:
    #         spark_df = spark_df.withColumn(col_name, when(col('`'+col_name+'`').isNull(), '').otherwise(col('`'+col_name+'`')))
        
    for dataType in spark_df.dtypes:
        col_name = dataType[0]
        col_type = dataType[1]

        # if col_type=='boolean':
        #     spark_df = spark_df.withColumn(col_name,when(col(col_name).isNull(),False))
        
        # if col_type == 'boolean':
        #     spark_df = spark_df.withColumn(col_name, when(col(col_name).isNull(), False).otherwise(col(col_name)))
        
        if col_type == 'boolean':
            spark_df = spark_df.withColumn(col_name, when(col(col_name).isNull(), False).otherwise(col(col_name)))

        elif col_type.find('array') != -1:
            spark_df = spark_df.withColumn(col_name, when(col(col_name).isNull(), array()).otherwise(col(col_name)))

    spark_df = set_all_spark_df_columns_to_strings(spark_df)
    # converts all columns to strings
    # LC ADDED ABOVE 03.28.24 (SERVERLESS ANSI-COMPLIANCE)

    spark_df = spark_df.fillna('').replace('NaN','').replace('nan','').replace('None','').replace('none','')
    # LC ADDED 04.03.24 PER MARINA Z. SLACK
    
    # Convert Spark DataFrame to Pandas DataFrame and remap original column names
    spark_df = spark_df.toDF(*original_columns).toPandas()

    if kwargs and kwargs.get('push_df_as_html',False):
        # Generate HTML table from Pandas DataFrame
        html_table = spark_df.to_html(escape=False, index=False)

        # Remove thead section of the HTML table
        html_table = html_table.split('<thead>')[0] + html_table.split('</thead>')[1]

        if kwargs.get('html_table_style'):
            # Add a style attribute to the HTML table
            html_table = html_table.replace('<table ', f'<table style="{kwargs["html_table_style"]}" ')

        return html_table
    else:
        # Convert Pandas DataFrame to list of lists
        return spark_df.values.tolist()

def get_all_sheet_row_metadata(spreadsheet_id: str, sheet_id: str, credentials_dict: Dict) -> List[Dict[str, Any]]:
    """
    Retrieves metadata for all rows in a Google Sheet.
    
    Args:
        spreadsheet_id (str): The ID of the Google Sheet to retrieve data from.
        sheet_id (str): The ID of the sheet within the Google Sheet to retrieve data from.
        
    Returns:
        List[Dict[str, Any]]: A list of dictionaries representing metadata for each row in the sheet.
    """
    gc = open_spreadsheet_by_id(retries=0,credentials_dict=credentials_dict,spreadsheet_id=spreadsheet_id)
    sheet = gc.get_worksheet_by_id(int(sheet_id))
    sheet_properties = sheet._properties
    ranges = [sheet_properties['title']]
    include_grid_data = 'false'
    request = get_service(credentials_dict).spreadsheets().get(
        spreadsheetId=spreadsheet_id, ranges=ranges, includeGridData=include_grid_data)
    response = request.execute()
    data = response['sheets'][0]['data'][0]['rowData']
    return data

def reprocess_sheet_data(workbook_id: str, sheet_id: str, data: List[Dict[str, Any]], credentials_dict: Dict) -> None:
    """
    Reprocesses sheet data by replacing the contents of the specified sheet with the given data.
    Args:
        workbook_id (str): The ID of the Google Sheets workbook.
        sheet_id (str): The ID of the sheet to reprocess.
        data (List[Dict[str, Any]]): A list of dictionaries representing the rows of the sheet. Each dictionary should
            have keys corresponding to the column names and values corresponding to the cell values.
    Returns:
        None
    """

    # Open the workbook by ID
    gc = open_spreadsheet_by_id(retries=0,credentials_dict=credentials_dict,spreadsheet_id=workbook_id)

    # Define the batch update request body
    request_body = {
        "requests": [
            {
                "update_cells": {
                    "fields": "*",
                    "range": {
                        "sheet_id": sheet_id,
                        "start_column_index": 0,
                        "start_row_index": 0,
                    },
                    "rows": data,
                },
            },
        ]
    }

    # Execute the batch update request
    gc.batch_update(request_body)

def push_df_as_html_to_sheet(workbook_id: str,\
                             sheet_id: str,\
                             col_index: int,\
                             row_index: int,\
                             html_list: List[str],\
                             credentials_dict: Dict,\
                             **kwargs: Any) -> None:
    """
    Pushes a list of HTML strings to a Google Sheet.
    Args:
    - workbook_id (str): ID of the Google Sheet workbook
    - sheet_id (str): ID of the Google Sheet
    - col_index (int): 0-based index of the starting column where the HTML should be pasted
    - row_index (int): 0-based index of the starting row where the HTML should be pasted
    - html_list (List[str]): list of HTML strings
    - **kwargs: additional keyword arguments to specify formatting of the pasted data. Available options:
        - horizontalAlignment (str): horizontal alignment for text in pasted cells (left, center, right)
        - verticalAlignment (str): vertical alignment for text in pasted cells (top, middle, bottom)
        - wrapStrategy (str): wrap strategy for text in pasted cells (overflow, wrap, clip)
        - fontFamily (str): font family for text in pasted cells (e.g. Arial)
        - fontSize (int): font size for text in pasted cells
    Returns:
    - None
    """

    # Open workbook
    gc = open_spreadsheet_by_id(retries=0,credentials_dict=credentials_dict,spreadsheet_id=workbook_id)
    
    # Update sheet with HTML data
    body = {
        "requests": [
            {
                "pasteData": {
                    "html": True,
                    "data": html_list,
                    "coordinate": {
                        "sheetId": sheet_id,
                        "columnIndex": col_index,
                        "rowIndex": row_index,
                    },
                },
            },
        ]
    }
    gc.batch_update(body)
    
    # Wait for update to take effect
    time.sleep(5)
    
    # Update cell formatting
    data = get_all_sheet_row_metadata(workbook_id, sheet_id, credentials_dict)
    list_of_nested_dicts = []
    for i in data:
        try:
            nested_dict = dict(i)['values']
            if data.index(i) >= row_index: 
                for x in nested_dict:
                    try:
                        effective_format = x.get('effectiveFormat', {})
                        user_entered_format = x.get('userEnteredFormat', {})
                        
                        # if 'uri' in str(user_entered_format):
                        #   print('1: ',effective_format)
                        #   print()
                        #   print('2: ',user_entered_format)

                        #   print()
                        #   print('hyperlink: ',x.get('hyperlink'))
                        #   print()
                        #   print('textFormatRuns: ',x.get('textFormatRuns'))
                        #   # print()
                        #   # print(x.get('textFormatRuns', {}).get('link',{}))
                        #   # print()
                        #   # print(x.get('userEnteredValue',{}).get('formulaValue',''))
                        #   print()
                        #   print('test',x.get('userEnteredValue',{}))
                        #   print()
                        #   print('test2: ', x.get('userEnteredValue',{})==None, x.get('userEnteredValue',{}))
                        ## LC INCLUDED ABOVE FOR FUTURE DEBUGGING PURPOSES

                        if kwargs.get('horizontalAlignment'):
                            effective_format['horizontalAlignment'] = kwargs['horizontalAlignment']
                        if kwargs.get('verticalAlignment'):
                            effective_format['verticalAlignment'] = kwargs['verticalAlignment']
                        if kwargs.get('wrapStrategy'):
                            effective_format['wrapStrategy'] = kwargs['wrapStrategy']
                            
                        x.update({'effectiveFormat': effective_format})
                        
                        # LC ADDED BELOW 07.11.24
                        if x.get('hyperlink')!=None and x.get('textFormatRuns', {}) == {} and \
                          '=HYPERLINK' not in x.get('userEnteredValue',{}).get('formulaValue',''):
                            textFormatRuns = [{'format': {'link': {'uri': x.get('hyperlink')}}}]
                            x.update({'textFormatRuns': textFormatRuns})

                        # LC ADDED BELOW 08.08.24
                        # Check if 'link' is already present in textFormatRuns
                        text_format_runs = x.get('textFormatRuns', [])
                        link_present = any('link' in entry.get('format', {}) for entry in text_format_runs)

                        # If hyperlink is present and link is not already in textFormatRuns
                        if x.get('hyperlink') is not None and not link_present and \
                          x.get('userEnteredValue',{}).get('formulaValue','') == '':
                            # Create a new format dictionary with the existing format
                            new_format = {}
                            for entry in text_format_runs:
                                new_format.update(entry.get('format', {}))
                            
                            # Add the hyperlink to the new format
                            new_format['link'] = {'uri': x.get('hyperlink')}
                            
                            # Update textFormatRuns with the new format
                            text_format_runs = [{'format': new_format}]
                            x.update({'textFormatRuns': text_format_runs})
                        # LC ADDED ABOVE 08.08.24
                        
                        if kwargs.get('fontFamily') or kwargs.get('fontSize'):
                            try:
                                text_format = effective_format['textFormat']
                                if kwargs.get('fontFamily'):
                                    text_format['fontFamily'] = kwargs['fontFamily']
                                if kwargs.get('fontSize'):
                                    text_format['fontSize'] = kwargs['fontSize']
                            except KeyError:
                                text_format = {'fontFamily': kwargs.get('fontFamily', None),
                                               'fontSize': kwargs.get('fontSize', None)}
                            user_entered_format.update({'textFormat': text_format})
                            
                            if kwargs.get('horizontalAlignment'):
                                user_entered_format['horizontalAlignment'] = kwargs['horizontalAlignment']
                            if kwargs.get('verticalAlignment'):
                                user_entered_format['verticalAlignment'] = kwargs['verticalAlignment']
                            if kwargs.get('wrapStrategy'):
                                user_entered_format['wrapStrategy'] = kwargs['wrapStrategy']
                            
                            x.update({'userEnteredFormat': user_entered_format})
                    except:
                        continue
        except:
            nested_dict = {}
        list_of_nested_dicts.append({'values':nested_dict})
    
    reprocess_sheet_data(workbook_id, sheet_id, list_of_nested_dicts, credentials_dict)

def remove_sheet_formatting_from_row_index_downwards(spreadsheet_id: str, sheet_id: str, start_row_index: int, credentials_dict: Dict):
    """
    Removes all formatting from a Google Sheet from the given row index downwards.
    
    Args:
    - spreadsheet_id (str): the ID of the Google Sheet to update
    - sheet_id (int): the ID of the sheet within the workbook to update
    - start_row_index (int): the row index from which to start removing formatting (inclusive)
    
    Returns: None
    """
    
    # Authenticate with Google Sheets API
    gc = get_client(credentials_dict)
    
    # Get the specified sheet by ID
    wb = open_spreadsheet_by_id(retries=0,credentials_dict=credentials_dict,spreadsheet_id=spreadsheet_id)

    sheet = wb.get_worksheet_by_id(sheet_id)
    
    # Construct the batch update request body
    body = {
        "requests": [
            {
                "updateCells": {
                    "range": {
                        "sheetId": sheet_id,
                        "startRowIndex": start_row_index - 1  # Subtract 1 because API uses 0-indexing
                    },
                    "fields": "userEnteredFormat"  # Remove all user-entered formatting
                }
            }
        ]
    }
    
    # Send the batch update request to the API to remove formatting
    sheet.spreadsheet.batch_update(body)
    
    return None

def column_string(n):
    """
    Convert a column number to its corresponding column string.
    e.g. 1 -> 'A', 2 -> 'B', ..., 26 -> 'Z', 27 -> 'AA', 28 -> 'AB', ..., 703 -> 'AAA', etc.
    """
    result = ""
    while n > 0:
        n, remainder = divmod(n - 1, 26)
        result = chr(65 + remainder) + result
    return result


def refresh_data_in_sheet(sheet_name_or_id,\
                          spark_df,\
                          workbook_id,\
                          row_number_to_push_into,\
                          column_letter_to_push_into,
                          credentials_dict=credentials_dict,\
                          include_header=True,\
                          **kwargs):

    """
    Refreshes data in a Google Sheet with new data from a PySpark DataFrame.
    Args:
    - sheet_name_or_id (str or int): name or ID of the Google Sheet to update
    - spark_df (pyspark.sql.DataFrame): PySpark DataFrame containing the data to update the sheet with
    - workbook_id (str): ID of the Google Sheet workbook
    - row_number_to_push_into (int): 1-based index of the row to start pasting data into
    - column_letter_to_push_into (str): letter representing the column to start pasting data into
    - credentials_dict (dict): dictionary containing authentication credentials for Google Sheets API
    - **kwargs: additional keyword arguments to specify optional behavior:
        - pause_between_sheet_updates (int, optional): the number of seconds to wait between each update to the sheet. Default is 1 second.
        - preserve_last_n_columns (int, optional): the number of columns to preserve at the end of the sheet. Default is 0.
        - push_df_as_html (bool, optional): If True, push the data to the sheet as HTML. Default is False.
        - horizontalAlignment (str, optional): The horizontal alignment for text in pasted cells (left, center, right).
        - verticalAlignment (str, optional): The vertical alignment for text in pasted cells (top, middle, bottom).
        - wrapStrategy (str, optional): The wrap strategy for text in pasted cells (overflow, wrap, clip).
        - fontFamily (str, optional): The font family for text in pasted cells (e.g. Arial).
        - fontSize (int, optional): The font size for text in pasted cells.
        - starting_row_filter_index (int, optional): The 0-based index of the starting row for applying the filter. Default is 0.
        - starting_column_filter_index (int, optional): The 0-based index of the starting column for applying the filter. Default is 0.
        - apply_filter_to_column_index (int, optional): The 0-based index of the column to apply the filter to. Default is 0.
        - string_exclusion_filter (str, optional): A string to exclude from the filter. Default is an empty string.
        - do_not_clear_entire_target_sheet_range (bool, optional): If true, then it will only clear the range of the cells that your df will eventually replace
    Returns:
    - None
    """
    
    # Authenticate with Google Sheets API
    gc = auth_google_sheet(workbook_id, credentials_dict)

    # Get the specified sheet by name or ID
    if len(re.sub("[^0-9]", "", str(sheet_name_or_id)))==len(str(sheet_name_or_id)):
        sheet = gc.get_worksheet_by_id(int(sheet_name_or_id))
    else:
        sheet = gc.worksheet(sheet_name_or_id)

    sheet_name = sheet.title
    sheet_id = sheet._properties['sheetId']

    # Remove any existing filters from the sheet
    remove_filter(gc, sheet)

    # Wait for the specified amount of time between sheet updates
    time.sleep(kwargs.get('pause_between_sheet_updates', 1))
    
    # convert spark_df into proper payload format needed to handle various Google Sheet API requests 
    spark_body_list_of_list = gsheet_pandas_conversion(spark_df, push_df_as_html=kwargs.get('push_df_as_html',False))

    # get size of df
    size_of_df = len(spark_body_list_of_list)

    #START OF OLD CODE
    # # Write headers to the sheet
    # headers = [[col for col in spark_df.columns]]
    # update_sheets(client=gc,
    #              data=headers,
    #              sheet=sheet,
    #              cell_range=f"{column_letter_to_push_into}{row_number_to_push_into}")


    # # determine end row of sheet clearing step (slated to happen next)
    # end_row = kwargs.get('do_not_clear_entire_target_sheet_range', False)
    # if end_row:
    #   end_row = size_of_df+row_number_to_push_into+1
    #   end_col = column_string(len(spark_body_list_of_list[0]))
    # if not end_row:
    #   end_row = ''
    #   end_col = column_string(sheet.col_count - kwargs.get('preserve_last_n_columns', 0))

    # # Clear the sheet data from the starting cell to the end of the row
    # range_to_clear = f"{sheet_name}!{column_letter_to_push_into}{row_number_to_push_into+1}:{end_col}{end_row}"
    # gc.values_clear(range_to_clear)

    # # Wait for the specified amount of time between sheet updates
    # time.sleep(kwargs.get('pause_between_sheet_updates', 1))

    # # Write data to the sheet as HTML, if specified
    # if 'push_df_as_html' in kwargs and kwargs.get('push_df_as_html',False):
    #     remove_sheet_formatting_from_row_index_downwards(spreadsheet_id=workbook_id,
    #                                                      sheet_id=sheet_id,
    #                                                      start_row_index=row_number_to_push_into+1,
    #                                                      credentials_dict=credentials_dict)
        
    #     colIndex = ord(column_letter_to_push_into.lower()) - 97
    #     push_df_as_html_to_sheet(workbook_id=workbook_id,
    #                              sheet_id=sheet_id,
    #                              col_index=colIndex,
    #                              row_index=row_number_to_push_into,
    #                              html_list=spark_body_list_of_list,
    #                              credentials_dict=credentials_dict,
    #                              **kwargs)
        
    # # Otherwise, write dataframe body data to the sheet
    # else:
    #     update_sheets(client=gc,
    #                  data=spark_body_list_of_list,
    #                  sheet=sheet,
    #                  cell_range=f"{column_letter_to_push_into}{row_number_to_push_into+1}")
    #END OF OLD CODE

    # --- HEADER LOGIC ---
    if include_header:
        headers = [[col for col in spark_df.columns]]
        update_sheets(client=gc,
                      data=headers,
                      sheet=sheet,
                      cell_range=f"{column_letter_to_push_into}{row_number_to_push_into}")
        
        # If header is included, data body starts 1 row below
        data_start_row = row_number_to_push_into + 1
    else:
        # If no header, data body starts exactly at row_number_to_push_into
        data_start_row = row_number_to_push_into

    # determine end row of sheet clearing step
    end_row = kwargs.get('do_not_clear_entire_target_sheet_range', False)
    if end_row:
      # Adjusted to use data_start_row
      end_row = size_of_df + data_start_row
      end_col = column_string(len(spark_body_list_of_list[0]))
    if not end_row:
      end_row = ''
      end_col = column_string(sheet.col_count - kwargs.get('preserve_last_n_columns', 0))

    # Clear the sheet data starting from the data_start_row
    range_to_clear = f"{sheet_name}!{column_letter_to_push_into}{data_start_row}:{end_col}{end_row}"
    gc.values_clear(range_to_clear)

    # Wait for the specified amount of time between sheet updates
    time.sleep(kwargs.get('pause_between_sheet_updates', 1))

    # Write data to the sheet as HTML, if specified
    if 'push_df_as_html' in kwargs and kwargs.get('push_df_as_html',False):
        remove_sheet_formatting_from_row_index_downwards(spreadsheet_id=workbook_id,
                                                         sheet_id=sheet_id,
                                                         start_row_index=data_start_row,
                                                         credentials_dict=credentials_dict)
        
        colIndex = ord(column_letter_to_push_into.lower()) - 97
        push_df_as_html_to_sheet(workbook_id=workbook_id,
                                 sheet_id=sheet_id,
                                 col_index=colIndex,
                                 row_index=data_start_row - 1, # API usually uses 0-based index
                                 html_list=spark_body_list_of_list,
                                 credentials_dict=credentials_dict,
                                 **kwargs)
        
    # Otherwise, write dataframe body data to the sheet
    else:
        update_sheets(client=gc,
                      data=spark_body_list_of_list,
                      sheet=sheet,
                      cell_range=f"{column_letter_to_push_into}{data_start_row}")

    # Wait for the specified amount of time between sheet updates
    time.sleep(kwargs.get('pause_between_sheet_updates', 1))

    # Apply a filter to the sheet, if specified
    if kwargs is not None and 'apply_filter_to_column_index' in kwargs:
      
        assert 'starting_row_filter_index' in kwargs, '`starting_row_filter_index` is missing'
        assert 'starting_column_filter_index' in kwargs, '`starting_column_filter_index` is missing'
      
        string_exclusion_filter = kwargs.get('string_exclusion_filter', '')
        startRowIndex = kwargs.get('starting_row_filter_index', 0)
        startColumnIndex = kwargs.get('starting_column_filter_index', 0)
        filterColumnIndex = kwargs.get('apply_filter_to_column_index', 0)
        
        apply_filter(client=gc,
                       sheet=sheet,
                       string_exclusion_filter=string_exclusion_filter,
                       startRowIndex=startRowIndex,
                       startColumnIndex=startColumnIndex,
                       filterColumnIndex=filterColumnIndex)

        
def read_google_sheet(
      workbook_id: str, # ID of the Google Sheets workbook
      sheet_id: str, # ID of the sheet within the workbook
      credentials=None, # authentication credentials for accessing the Google Sheets API
      make_columns_unique: bool = True, # flag indicating whether to make column names unique
      clean_column_names: bool = True, # flag indicating whether to clean column names
      drop_empty_rows: bool = True, # flag indicating whether to drop empty rows
      cell_range: Optional[str] = None, # optional string specifying a range of cells to retrieve from the sheet
      temp_view_name: Optional[str] = None, # optional string specifying a temporary view name for the data in the Spark DataFrame
    ): # returns a Spark DataFrame containing the data from the Google Sheet

    credentials = credentials_dict

    gc = retry_api_call(lambda: get_client(credentials)) # creates a gspread client object using the provided credentials

    try:
        spreadsheet = retry_api_call(lambda: open_spreadsheet_by_id(retries=0,credentials_dict=credentials_dict,spreadsheet_id=workbook_id))
    except:
        spreadsheet = retry_api_call(lambda: gc.open(workbook_id)) # if that fails, tries to open the workbook by name

    worksheet = (retry_api_call(lambda: spreadsheet.get_worksheet_by_id(int(sheet_id))) # gets the worksheet by ID if sheet_id is an integer
                 if re.match(r"^\d+$", sheet_id) # else gets the worksheet by name
                 else retry_api_call(lambda: spreadsheet.worksheet(sheet_id)))

    range_data = (f"{worksheet.title}!{cell_range}" # specifies a cell range to retrieve if cell_range is provided
                  if cell_range else worksheet.title)

    values = retry_api_call(lambda: spreadsheet.values_get(range_data)) # retrieves the values within the specified cell range
    values = values['values'] # extracts the values from the response
    df = pd.DataFrame(values) # creates a pandas DataFrame from the values
    df.fillna("",inplace=True) # replaces any null values with empty strings
    
    if drop_empty_rows:
        df.dropna(how="all", inplace=True) # drops any rows where all values are null
        df = df[df.astype(bool).sum(axis=1) > 0] # drops any rows where all values are empty strings
        
    headers = df.iloc[0] # extracts the header row from the DataFrame
    headers = [str(col).lower() for col in headers] # converts the header names to lowercase strings

    if make_columns_unique:
        cols = []
        for i, header in enumerate(headers):
            if headers[:i].count(header):
                cols.append(f"{header}{headers[:i].count(header)}") # appends a count to duplicate header names
            else:
                cols.append(header)
    else:
        cols = headers

    df = pd.DataFrame(df.values[1:], columns=cols) # creates a new DataFrame with the headers and data

    # try:
    #     spark_df = spark.createDataFrame(df) # try to create a Spark DataFrame from the pandas DataFrame
    # except:
    #     # if creating a Spark DataFrame from pandas fails, it's likely because there are duplicate column names
    #     cleaned_cols = []
    #     for i, col in enumerate(cols):
    #         if cols[:i].count(col):
    #             cleaned_cols.append(f"{col}{cols[:i].count(col)}")
    #         else:
    #             cleaned_cols.append(col)
    #     df = df.rename(columns=dict(zip(cols, cleaned_cols))) # rename columns to make them unique
    #     spark_df = spark.createDataFrame(df) # try to create Spark DataFrame again with the cleaned columns
    # LC BLOCKED OFF 03.06.24 AND ADDED BELOW:

    def spark_df_converter(df):
        try:
            spark_df = spark.createDataFrame(df)  # try to create a Spark DataFrame from the pandas DataFrame
            return spark_df
        except Exception as e:
            # If the DataFrame is empty, create an empty Spark DataFrame with the same columns
            if df.empty or 'can not infer schema from empty dataset' in e:
                # Create an empty schema with the same columns as the original DataFrame
                schema = StructType([StructField(col, StringType(), True) for col in df.columns])
                spark_df = spark.createDataFrame([], schema=schema)
                return spark_df
            else:
                # if creating a Spark DataFrame from pandas fails for other reasons
                cleaned_cols = []
                for i, col in enumerate(cols):
                    if cols[:i].count(col):
                        cleaned_cols.append(f"{col}{cols[:i].count(col)}")
                    else:
                        cleaned_cols.append(col)
                df = df.rename(columns=dict(zip(cols, cleaned_cols)))  # rename columns to make them unique
                spark_df = spark.createDataFrame(df)  # try to create Spark DataFrame again with the cleaned columns
                return spark_df
    
    spark_df = spark_df_converter(df)

    if clean_column_names:
        # if specified, clean up the column names in the Spark DataFrame
        pandas_before = spark_df.toPandas()
        pandas_before.columns = [
            re.sub("[^a-zA-Z0-9]+", "_", col) # replace non-alphanumeric characters with underscores
            for col in pandas_before.columns
        ]
        headers = [
            re.sub("__", "_", re.sub("___", "_", col)) # replace multiple consecutive underscores with a single underscore
            for col in pandas_before.columns.values
        ]
        headers = [
            col[:-3] if col.endswith("___") else col # remove trailing underscores if there are three consecutive underscores
            for col in headers
        ]
        headers = [
            col[:-2] if col.endswith("__") else col # remove trailing underscores if there are two consecutive underscores
            for col in headers
        ]
        headers = [
            col[:-1] if col.endswith("_") else col # remove trailing underscore if there is only one underscore
            for col in headers
        ]
        pandas_before.columns = headers
        cols = [col.lower() for col in pandas_before.columns.values] # convert column names to lowercase
        df = pandas_before.rename(columns=dict(zip(headers, cols))) # rename columns in pandas DataFrame to lowercase
        spark_df = spark_df_converter(df) # create Spark DataFrame from the cleaned up pandas DataFrame

    if temp_view_name:
        spark_df.createOrReplaceTempView(temp_view_name) # create a temporary view of the Spark DataFrame with the specified name

    return spark_df # return the Spark DataFrame

# COMMAND ----------

def hide_or_unhide_sheet(spreadsheet_id, sheet_id, hide_or_unhide_boolean):
    ss = auth_google_sheet(
        spreadsheet_id=spreadsheet_id, credentials_dict=credentials_dict
    )
    body = {
        "requests": [
            {
                "updateSheetProperties": {
                    "properties": {
                        "sheetId": sheet_id,
                        "hidden": hide_or_unhide_boolean,
                    },
                    "fields": "hidden",
                }
            }
        ]
    }
    ss.batch_update(body)

# COMMAND ----------

def add_gdrive_permissions(file_id, email_list=[], share_with_company=False):
  ## `email_list` = [[email,permission]] 
  
  gc_client = get_client(credentials_dict)
  
  permission_list = ['reader', 'commenter', 'writer', 'fileOrganizer', 'organizer']
  # NO OWNER ALLOWED

  # perm_type = 'user', 'group', 'domain'

  if share_with_company:
    email_list = [['databricks.com','reader','domain']]
    # NEEDED FOR WHEN WE SHARE W/ COMPANY

  for i in email_list:
    assert i[1] in permission_list, f'ERROR - {i[1]} not a valid permission'
    perm_type =i[2]
    role      =i[1]
    value     =i[0]
      
    gc_client.insert_permission(
      file_id,
      value=value,
      perm_type=perm_type,
      role=role,
      notify=False
    )
    print(f'Successfully gave {i[0]} access ({i[1]}) to {file_id}')

# COMMAND ----------

def clone_google_spreadsheet_based_on_template_id(template_spreadsheet_id, new_spreadsheet_name):

  drive_service = build('drive', 'v3', credentials=get_service_account_credentials())
  
  # Define the file metadata for the new spreadsheet
  file_metadata = {
      'name': new_spreadsheet_name
  }

  try:
      # Copy the existing Google Spreadsheet template
      copied_file = drive_service.files().copy(
          fileId=template_spreadsheet_id,
          body=file_metadata
      ).execute()

      # Get the ID of the newly copied spreadsheet
      new_spreadsheet_id = copied_file.get('id')
      
      return new_spreadsheet_id

  except Exception as e:
      print(f"An error occurred while cloning the spreadsheet: {e}")
      return None

# COMMAND ----------

def delete_google_drive_file_by_id(file_id):
  from googleapiclient.discovery import build
  drive_service = build('drive', 'v3', credentials=get_service_account_credentials())
  drive_service.files().delete(fileId=file_id).execute()
  return f'SUCCESSFULLY DELETED FILE - {file_id}'

# COMMAND ----------

def apply_conditional_format(formula_dict):
  def add_conditional_formatting(formula_dict):
    for i in formula_dict:
      service = build('sheets', 'v4', credentials=get_service_account_credentials())
      requests = [
          {
              "addConditionalFormatRule": {
                  "rule": {
                      "ranges": [{
                          "sheetId": formula_dict[i]['sheet_id'],
                          "startRowIndex": 0,
                          "startColumnIndex": 0,
                          "endRowIndex": formula_dict[i]['row_count'],
                          "endColumnIndex": formula_dict[i]['num_columns']+1
                      }],
                      "booleanRule": {
                          "condition": {
                              "type": "CUSTOM_FORMULA",
                              "values": [{
                                  "userEnteredValue": formula_dict[i]['formula']
                              }]
                          },
                          "format": {
                              "backgroundColor": formula_dict[i]['background_color']
                          }
                      }
                  },
                  "index": 0
              }
          }
      ]
      request = service.spreadsheets().batchUpdate(spreadsheetId=formula_dict[i]['spreadsheet_id'], body={"requests": requests})
      response = request.execute()

  add_conditional_formatting(formula_dict)

# COMMAND ----------

# DBTITLE 1,Google Slides Text Extractor
def scrape_google_slide_text(presentation_id,slide_beginning_index=0,slide_end_index=None):
    from googleapiclient.discovery import build
    service = build('slides', 'v1', credentials=get_service_account_credentials())

    presentation = service.presentations().get(presentationId=presentation_id).execute()
    slides = presentation.get('slides')

    all_text = []

    if slide_end_index == None:
      slide_end_index = len(slides)-1
    for slide in slides[slide_beginning_index:slide_end_index]:
        page_elements = slide.get('pageElements', [])
        for element in page_elements:
            if 'shape' in element:
                shape = element['shape']
                if 'text' in shape:
                    text_elements = shape['text']['textElements']
                    for text_element in text_elements:
                        text_run = text_element.get('textRun')
                        if text_run:
                            content = text_run.get('content')
                            if content:
                                all_text.append(content)
    return all_text

# COMMAND ----------

# DBTITLE 1,Duplicate Sheet Renamer Function
def clone_and_rename_sheet(spreadsheet_id, sheet_id, new_sheet_name):
    """
    Duplicate a sheet within the same spreadsheet and rename the duplicated sheet.

    Args:
        spreadsheet_id (str): ID of the spreadsheet containing the sheet to clone.
        sheet_id (int): ID of the sheet to clone.
        new_sheet_name (str): Name for the duplicated sheet.

    Returns:
        int: ID of the duplicated sheet.
    """

    print(f'Attempting to copy a sheet ({sheet_id}) and then name the cloned sheet ({new_sheet_name})')

    from googleapiclient.discovery import build

    service = build('sheets', 'v4', credentials=get_service_account_credentials())

    # Duplicate the sheet
    request = service.spreadsheets().sheets().copyTo(
        spreadsheetId=spreadsheet_id,
        sheetId=sheet_id,
        body={'destinationSpreadsheetId': spreadsheet_id}
    )
    response = request.execute()
    new_sheet_id = response['sheetId']

    # Rename the duplicated sheet
    request = service.spreadsheets().batchUpdate(
        spreadsheetId=spreadsheet_id,
        body={
            'requests': [
                {
                    'updateSheetProperties': {
                        'properties': {'sheetId': new_sheet_id, 'title': new_sheet_name, 'hidden': False},
                        'fields': 'title,hidden'
                    }
                }
            ]
        }
    )
    request.execute()

    print('SUCCESS')

    return new_sheet_id


# COMMAND ----------

# DBTITLE 1,Sheet ImportRange Auth Tool
def auth_importrange_permission_in_sheet(spreadsheet_id, donor_doc_id,type='importrange'):
    if type == 'importrange':
        url_string = 'addimportrangepermissions'
    if type == 'image':
        url_string = 'allowexternalurlaccess'
    access_token = get_access_token()
    headers = {
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Origin': 'https://docs.google.com',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'Authorization': f'Bearer {access_token}',
    }

    url  = f'https://docs.google.com/spreadsheets/d/{spreadsheet_id}/'
    url += f'externaldata/{url_string}?donorDocId={donor_doc_id}&includes_info_params=true&cros_files=false'

    response = requests.post(url, headers=headers)

    print('authenticating IMPORTRANGE...')
    print('Response Status Code:', response.status_code)
    print('Response Content:', response.text)

# COMMAND ----------

def add_hyperlinks_to_slides(presentationId, keyword, hyperlink_url):
    from googleapiclient.discovery import build

    slides_service = build('slides', 'v1', credentials=get_service_account_credentials())

    # Retrieve the slides from the presentation
    presentation = slides_service.presentations().get(presentationId=presentationId).execute()
    slides = presentation.get('slides', [])
    
    # Define a list to store update requests
    update_requests = []

    # Iterate over each slide in the presentation
    for slide in slides:
        # Iterate over each shape in the slide
        for shape in slide.get('pageElements', []):
            if 'shape' in shape:
                text_elements = shape['shape'].get('text', {}).get('textElements', [])
                for text_element in text_elements:
                    if 'textRun' in text_element:
                        text_run = text_element['textRun']
                        content = text_run.get('content', '')

                        if keyword in content:
                            start_index = text_element.get('startIndex', 0)
                            start_index = content.find(keyword) + start_index
                            end_index = start_index + len(keyword)
                            # end_index = text_run.get('endIndex', None)
                            update_requests.append({
                                "updateTextStyle": {
                                    "objectId": shape['objectId'],
                                    "style": {
                                        "link": {
                                            "url": hyperlink_url
                                        }
                                    },
                                    "textRange": {
                                        "startIndex": start_index,
                                        "endIndex": end_index,
                                        "type": 'FIXED_RANGE'
                                    },
                                    "fields": "link"
                                }
                            })

    # Check if there are any update requests
    if update_requests:
        # Define the request body to update text styles
        body_update_text_styles = {"requests": update_requests}

        # Execute the update text styles request
        response_update_text_styles = slides_service.presentations().batchUpdate(
            presentationId=presentationId, body=body_update_text_styles).execute()
    else:
        print("No update requests found.")


# COMMAND ----------

def get_sheet_data_with_URL(workbook_id, sheet_id, starting_row, **kwargs):
    from googleapiclient.discovery import build
    import pandas as pd
    import numpy as np
    import datetime

    def get_client_and_service():
        client = get_client(credentials_dict)
        service = build('sheets', 'v4', credentials=get_service_account_credentials())
        return client, service

    def get_spreadsheet_info(client, workbook_id):
        ss = client.open_by_key(workbook_id)
        return ss

    def retrieve_data(service, spreadsheet_id, sheet_id):
        sheet_properties = ss.get_worksheet_by_id(int(sheet_id))._properties
        ranges = [sheet_properties['title']]
        include_grid_data = 'false'
        
        request = service.spreadsheets().get(spreadsheetId=spreadsheet_id, ranges=ranges, includeGridData=include_grid_data)
        response = request.execute()
        
        return response['sheets'][0]['data'][0]['rowData']

    def extract_multiple_hyperlinks(json_data):
        hyperlinks = []
        formatted_value = json_data.get("formattedValue", "")
        user_entered_value = json_data.get("userEnteredValue", "")
        labels = formatted_value if formatted_value else user_entered_value
        text_format_runs = json_data.get("textFormatRuns", [])
        
        for i, run in enumerate(text_format_runs):
            link = run.get("format", {}).get("link", {})
            uri = link.get("uri")
            if uri:
                label_start = run.get("startIndex", 0)
                # Check if next index exists
                next_index = i + 1
                if next_index < len(text_format_runs):
                    next_run = text_format_runs[next_index]
                    label_end = next_run.get("startIndex", len(labels))
                else:
                    label_end = len(labels)
                label = labels[label_start:label_end]
                hyperlink = '=HYPERLINK("{uri}", "{label}")'.format(uri=uri, label=label)
                hyperlinks.append(hyperlink)
        return str(hyperlinks)
  

    def extract_single_hyperlink(json_data):
        uri = json_data.get("userEnteredFormat", {}).get("textFormat", {}).get("link", {}).get("uri")
        label = json_data.get("formattedValue", "")
        if uri:
            hyperlink = '=HYPERLINK("{uri}", "{label}")'.format(uri=uri, label=label)
            return hyperlink
        else:
            return label


    def extract_cell_data(json_data):
        try: 
            multi_url_check = len(json_data.get('textFormatRuns', '')) > 0
            if multi_url_check:
                class_data = extract_multiple_hyperlinks(json_data)
            else:
                class_data = extract_single_hyperlink(json_data)
        except Exception as e:
            class_data = extract_single_hyperlink(json_data)
        return class_data

    today = datetime.date.today()
    current_date = today.strftime('%Y-%m-%d')

    client, service = get_client_and_service()
    ss = get_spreadsheet_info(client, workbook_id)
    data = retrieve_data(service, workbook_id, sheet_id)

    list_of_list = []
    for i in np.arange(starting_row, len(data)): 
        if 'values' in data[i]:
            list_of_list.append([extract_cell_data(cell) for cell in data[i]['values']])
  
    cols = []
  
    if kwargs is not None and 'row_1_is_header' in kwargs:
        for x in range(0, len(list_of_list[0])):
            if list_of_list[0][:x].count(list_of_list[0][x]) >= 1:
                cols.append(str(list_of_list[0][x]) + str(list_of_list[0][:x].count(list_of_list[0][x])))
            else:
                cols.append(str(list_of_list[0][x]))
        df = pd.DataFrame(data=list_of_list[1:], columns=cols)
    else:
        df = pd.DataFrame(data=list_of_list)
    return df


# COMMAND ----------

def build_drive_service():
    from googleapiclient.discovery import build
    return build("drive", "v3", credentials=get_service_account_credentials())

# COMMAND ----------

def generate_downloadable_google_pdf_url_from_html(
    html,
    pdf_name,
    emails,
    page_size_width="700mm",
    page_size_height="275mm",
    email_constants=["liam.clifford@databricks.com", "kevin.jordan@databricks.com","it-datamap-group@databricks.com"],
):
    import io
    import json
    import pdfkit
    from datetime import datetime
    from weasyprint import HTML, CSS
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaIoBaseUpload

    drive_service = build_drive_service()

    # LC ADDED 06.12.24
    # `TypeError: expected string or bytes-like object`
    try:
        html = re.sub("```", "", re.sub("```html", "", html))
    except:
        return ''
    
    emails        = emails + email_constants
    today         = datetime.today()
    todays_date   = today.strftime("%m/%d/%y")
    pdf_name      = pdf_name + f" ({todays_date})"

    def delete_file_from_drive(file_id):
        try:
            drive_service.files().delete(fileId=file_id).execute()
            print(f"File with ID {file_id} deleted successfully.")
        except Exception as e:
            print(f"Error deleting file with ID {file_id}: {e}")

    def convert_html_to_pdf(html_content, pdf_name, page_size):
        pdf_content = retry_api_call(
            lambda: HTML(string=html_content).write_pdf(
                stylesheets=[
                    CSS(
                        string="@page { size: %(width)s %(height)s; margin: 0mm; }"
                        % page_size
                    )
                ]
            )
        )
        pdf_file_id = retry_api_call(
            lambda: upload_html_to_google_drive(
                pdf_content, pdf_name
            )
        )
        return pdf_file_id

    def upload_html_to_google_drive(pdf_content, pdf_name):
        metadata = {
            "name": pdf_name,
            "mimeType": "application/pdf",
        }

        media = MediaIoBaseUpload(
            io.BytesIO(pdf_content), mimetype="application/pdf", resumable=True
        )

        body = {"name": pdf_name}

        file = retry_api_call(
            lambda: drive_service.files()
            .create(body=body, media_body=media, fields="id")
            .execute()
        )
        
        file_id = file.get("id")
        return file_id

    try:
        pdf_file_id = retry_api_call(
            lambda: convert_html_to_pdf(
                html_content=html,
                pdf_name=pdf_name,
                page_size={"width": page_size_width, "height": page_size_height},
            )
        )
        print(f"Converted PDF file created with ID: {pdf_file_id}")

        if len(emails)>0:
            email_list=[[email, "writer", "user"] for email in emails if email != None and email != ""]
            retry_api_call(lambda: add_gdrive_permissions(file_id=pdf_file_id, email_list=email_list))

        final_url = f"https://drive.usercontent.google.com/u/0/uc?id={pdf_file_id}&export=download"

        print(f"Successfully created and shared PDF -- {pdf_name}")

        return final_url
    
    except Exception as e:
        print(f"Error generating PDF: {e}")
        return ''


# COMMAND ----------

def check_storage():
  drive = build('drive', 'v3', credentials=credentials)
  about_info = drive.about().get(fields="storageQuota").execute()

  # Extract quota information
  quota_info = about_info.get('storageQuota', {})
  total_bytes = int(quota_info.get('limit', '0'))
  used_bytes = int(quota_info.get('usage', '0'))

  # Convert bytes to gigabytes
  def bytes_to_gb(bytes):
      return bytes / (1024 ** 3)

  total_gb = bytes_to_gb(total_bytes)
  used_gb = bytes_to_gb(used_bytes)

  print(f'Total Storage Quota: {total_gb:.2f} GB')
  print(f'Used Storage: {used_gb:.2f} GB')

# COMMAND ----------

def remove_access_to_google_files_in_batch(service, file_ids, service_account_email='service-liam-clifford@project-liam-clifford.iam.gserviceaccount.com'):
    """
    Remove the service account's access to a list of files in batches.

    Parameters:
        service (Resource): The Google Drive API service instance.
        file_ids (list): List of file IDs to remove access from.
        service_account_email (str): Email of the service account whose access is to be removed.
    """
    
    def process_chunk(chunk):
        """
        Process a chunk of file IDs in a batch request.

        Parameters:
            chunk (list): A list of file IDs to process.
        """
        batch = service.new_batch_http_request()
        
        for file_id in chunk:
            try:
                # Retrieve the permissions of the file
                permissions = service.permissions().list(
                    fileId=file_id,
                    fields='permissions(id, emailAddress)'
                ).execute()
                
                # Find and handle the permission ID for the service account
                permission_id = None
                for permission in permissions.get('permissions', []):
                    if permission['emailAddress'] == service_account_email:
                        permission_id = permission['id']
                        print(f"Found permission for {permission['emailAddress']} on file ID: {file_id}")
                        break
                
                if permission_id:
                    request = service.permissions().delete(fileId=file_id, permissionId=permission_id)
                    batch.add(request, callback=lambda req_id, resp, exc: callback(req_id, resp, exc, file_id))
                else:
                    print(f"No access found for {service_account_email} on file ID: {file_id}")

            except Exception as e:
                print(f"An error occurred while processing file ID {file_id}: {e}")

        # Execute the batch request
        batch.execute()

    def callback(request_id, response, exception, file_id):
        """
        Callback function to handle the batch request response.

        Parameters:
            request_id (str): The ID of the request.
            response (dict): The response from the API.
            exception (Exception): The exception if an error occurred.
            file_id (str): The ID of the file the permission was removed from.
        """
        if exception:
            print(f"Request {request_id} failed for file ID {file_id}: {exception}")
        else:
            print(f"Successfully removed permission from file ID {file_id}")

    # Split file_ids into chunks of 100
    chunk_size = 100
    for i in range(0, len(file_ids), chunk_size):
        chunk = file_ids[i:i + chunk_size]
        process_chunk(chunk)


# COMMAND ----------

from googleapiclient.http import BatchHttpRequest
from googleapiclient.errors import HttpError

# Assumes `file_ids` == list of list

def delete_files_in_batches(file_ids, batch_size=100):
    """
    Delete Google Drive files by IDs in batches and return status.

    Parameters:
        file_ids (list): List of file IDs to delete.
        batch_size (int): Number of deletions to process in each batch.
    """
    
    def batch_delete_callback(request_id, response, exception):
        """
        Callback function to handle batch request responses.

        Parameters:
            request_id (str): The ID of the request.
            response (dict): The response from the API.
            exception (Exception): The exception if an error occurred.
        """
        if exception:
            print(f'Failed to delete file with request ID {request_id}: {exception}')
        else:
            print(f'Successfully deleted file with request ID {request_id}')

    def delete_google_drive_files_by_ids_in_batches(file_ids, batch_size=100):
        """
        Delete files in batches using Google Drive API.

        Parameters:
            file_ids (list): List of file IDs to delete.
            batch_size (int): Number of deletions to process in each batch.
        """
        file_ids = [x[0] for x in file_ids]  # Flatten list of lists to a simple list
        drive_service = build('drive', 'v3', credentials=get_service_account_credentials())
        
        total_files = len(file_ids)
        
        for start in range(0, total_files, batch_size):
            end = __builtins__.min(start + batch_size, total_files)
            batch = drive_service.new_batch_http_request(callback=batch_delete_callback)
            
            for file_id in file_ids[start:end]:
                batch.add(drive_service.files().delete(fileId=file_id))
            
            try:
                batch.execute()
            except HttpError as e:
                print(f'An error occurred: {e}')

    # Call the nested function to process file IDs
    delete_google_drive_files_by_ids_in_batches(file_ids, batch_size)


# COMMAND ----------

from googleapiclient.http import BatchHttpRequest
from googleapiclient.errors import HttpError

def restore_files_in_batches(file_ids, batch_size=1000):
    """
    Restore Google Drive files from trash in batches and handle responses.

    Parameters:
        file_ids (list): List of file IDs to restore.
        batch_size (int): Number of restore operations to process in each batch.
    """
    
    def batch_restore_callback(request_id, response, exception):
        """
        Callback function to handle batch request responses.

        Parameters:
            request_id (str): The ID of the request.
            response (dict): The response from the API.
            exception (Exception): The exception if an error occurred.
        """
        if exception:
            print(f'Failed to restore file with request ID {request_id}: {exception}')
        else:
            print(f'Successfully restored file with request ID {request_id}')
    
    try:
        # Set up Google Drive API client
        credentials = get_service_account_credentials()
        drive = build('drive', 'v3', credentials=credentials)
        
        def process_batches(file_ids):
            """
            Process file IDs in batches to restore them from trash.

            Parameters:
                file_ids (list): List of file IDs to process.
            """
            total_files = len(file_ids)
            
            for start in range(0, total_files, batch_size):
                end = __builtins__.min(start + batch_size, total_files)
                batch = drive.new_batch_http_request(callback=batch_restore_callback)
                
                for file_id in file_ids[start:end]:
                    batch.add(drive.files().update(fileId=file_id, body={'trashed': False}))
                
                batch.execute()

        # Call the nested function to process file IDs
        process_batches(file_ids)
    
    except HttpError as e:
        print(f'An error occurred: {e}')

# COMMAND ----------

# MAGIC %md
# MAGIC # bottom