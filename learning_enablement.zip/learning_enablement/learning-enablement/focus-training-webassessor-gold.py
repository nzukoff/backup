# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# from pprint import pprint
# from pyspark.sql import DataFrame, Column
# from typing import Optional, Sequence as Seq, Dict, Callable, Any

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# verbose = get_verbose_func(VERBOSE)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Users

# COMMAND ----------

# MAGIC %sql 
# MAGIC create or replace temp view sfdc_contacts_leads as (
# MAGIC   with sfdc_contacts_rank as (
# MAGIC     select 
# MAGIC       email,
# MAGIC       id as sfdc_contact_id,
# MAGIC       accountId as account_id,
# MAGIC       LastModifiedDate,
# MAGIC       'contact' as type,
# MAGIC       rank() over (
# MAGIC         partition by email
# MAGIC         order by
# MAGIC           LastModifiedDate desc nulls last
# MAGIC       ) as rank
# MAGIC     from main.sfdc_bronze.contact
# MAGIC     where processDate = (select max(processDate) from main.sfdc_bronze.contact)
# MAGIC     and email is not null
# MAGIC     
# MAGIC   )
# MAGIC   ,
# MAGIC   sfdc_contacts as (
# MAGIC     select *
# MAGIC     from sfdc_contacts_rank 
# MAGIC     where rank = 1
# MAGIC   )
# MAGIC   ,
# MAGIC
# MAGIC   sfdc_leads_rank as (
# MAGIC     select 
# MAGIC       email,
# MAGIC       id as sfdc_contact_id,
# MAGIC       LeanData__Reporting_Matched_Account__c as account_id,
# MAGIC       LastModifiedDate,
# MAGIC       'lead' as type,
# MAGIC       rank() over (
# MAGIC         partition by email
# MAGIC         order by
# MAGIC           LastModifiedDate desc nulls last
# MAGIC       ) as rank
# MAGIC     from main.sfdc_bronze.lead
# MAGIC     where processDate = (select max(processDate) from main.sfdc_bronze.lead)
# MAGIC     and email is not null
# MAGIC     
# MAGIC   )
# MAGIC   ,
# MAGIC   sfdc_leads as (
# MAGIC     select *
# MAGIC     from sfdc_leads_rank 
# MAGIC     where rank = 1
# MAGIC   )
# MAGIC   ,
# MAGIC   sfdc_contact_lead_pre as (
# MAGIC     select * except(rank)
# MAGIC     from sfdc_contacts 
# MAGIC     union all 
# MAGIC     select * except(rank)
# MAGIC     from sfdc_leads
# MAGIC   )
# MAGIC   ,
# MAGIC   sfdc_contact_lead_rank as (
# MAGIC     select 
# MAGIC       *,
# MAGIC       rank() over (
# MAGIC         partition by email
# MAGIC         order by
# MAGIC           account_id, LastModifiedDate desc nulls last
# MAGIC       ) as rank
# MAGIC     from sfdc_contact_lead_pre
# MAGIC   )
# MAGIC   ,
# MAGIC   sfdc_contact_lead as (
# MAGIC     select 
# MAGIC       *,
# MAGIC       sha2(email, 256) as email_hash
# MAGIC     from sfdc_contact_lead_rank  
# MAGIC     where rank = 1
# MAGIC   )
# MAGIC   select *
# MAGIC   from sfdc_contact_lead
# MAGIC )

# COMMAND ----------

# for rows not matched to accredible
# first match to docebo users 
# match to partner domains to get audience and account info
# match to microsoft 
# match to databricks 
# for customers, match to salesforce 
# follow same pattern from docebo users to get accounts 



# COMMAND ----------

# MAGIC %sql
# MAGIC -- # users_df = spark.sql('''
# MAGIC
# MAGIC with accredible as (
# MAGIC   select distinct 
# MAGIC       learner_email_hash,
# MAGIC       learner_alternate_email_hash,
# MAGIC       learner_alternate_email_domain,
# MAGIC       -- learner_branch_code,
# MAGIC       country_derived,
# MAGIC       region_derived,
# MAGIC       audience,
# MAGIC       updated_account_id,
# MAGIC       updated_account_name,
# MAGIC       updated_ultimate_parent_account_id,
# MAGIC       updated_ultimate_parent_account_name,
# MAGIC       match_method
# MAGIC   from main.field_learning_enablement.accredible_credentials
# MAGIC   where processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
# MAGIC )
# MAGIC ,
# MAGIC webassessor_users as (
# MAGIC   select 
# MAGIC     u.*,
# MAGIC     c.string_value as learner_alternate_email,
# MAGIC     split(c.string_value, '@')[1] as learner_alternate_email_domain, 
# MAGIC     sha2(c.string_value, 256) as learner_alternate_email_hash
# MAGIC     a.* except(learner_email_hash)
# MAGIC   from main.it_training_silver.webassessor_users u
# MAGIC   left join accredible a on u.email_hash = a.learner_email_hash
# MAGIC   left join main.it_training_silver.webassessor_custom_fields c on d.user_id = c.user_id and c.processDate = (select max(processDate) from main.it_training_silver.webassessor_custom_fields) and custom_field_id='2100153'
# MAGIC   where processDate = (select max(processDate) from main.it_training_silver.webassessor_users)
# MAGIC )
# MAGIC ,
# MAGIC accredible_matched as (
# MAGIC   select 
# MAGIC     *
# MAGIC   from webassessor_users
# MAGIC   where updated_account_id is not null
# MAGIC )
# MAGIC , 
# MAGIC accredible_not_matched as (
# MAGIC   select 
# MAGIC     * except (
# MAGIC       learner_alternate_email_hash,
# MAGIC       learner_alternate_email_domain,
# MAGIC       country_derived,
# MAGIC       region_derived,
# MAGIC       audience,
# MAGIC       updated_account_id,
# MAGIC       updated_account_name,
# MAGIC       updated_ultimate_parent_account_id,
# MAGIC       updated_ultimate_parent_account_name,
# MAGIC       match_method)
# MAGIC   from webassessor_users
# MAGIC   where updated_account_id is null
# MAGIC )
# MAGIC ,
# MAGIC docebo_users as (
# MAGIC   select distinct 
# MAGIC       email_hash as learner_email_hash,
# MAGIC       alternate_email as learner_alternate_email_hash,
# MAGIC       alternate_email_domain as learner_alternate_email_domain,
# MAGIC       -- learner_branch_code,
# MAGIC       country_derived,
# MAGIC       region_derived,
# MAGIC       audience,
# MAGIC       updated_account_id,
# MAGIC       updated_account_name,
# MAGIC       updated_ultimate_parent_account_id,
# MAGIC       updated_ultimate_parent_account_name,
# MAGIC       match_method
# MAGIC   from main.field_learning_enablement.docebo_users
# MAGIC   where processDate = (select max(processDate) from main.field_learning_enablement.docebo_users)
# MAGIC )
# MAGIC ,
# MAGIC
# MAGIC accredible_not_matched_docebo as (
# MAGIC   select 
# MAGIC     a.*,
# MAGIC     d.* except(learner_email_hash)
# MAGIC   from accredible_not_matched a
# MAGIC   left join docebo_users d on (a.email_hash = d.learner_email_hash or a.alternate_email_hash = d.learner_alternate_email_hash)
# MAGIC
# MAGIC )
# MAGIC ,
# MAGIC docebo_matched as (
# MAGIC   select *
# MAGIC   from accredible_not_matched_docebo
# MAGIC   where updated_account_id is not null
# MAGIC )
# MAGIC ,
# MAGIC docebo_not_matched as (
# MAGIC   select *
# MAGIC   from accredible_not_matched_docebo
# MAGIC   where updated_account_id is null
# MAGIC )
# MAGIC ,
# MAGIC partner_domains_accounts as (
# MAGIC   select *
# MAGIC   from main.field_learning_enablement.partner_domains_accounts
# MAGIC   where processDate = (select max(processDate) from main.field_learning_enablement.partner_domains_accounts)
# MAGIC )
# MAGIC ,
# MAGIC not_matched_extra_fields as (
# MAGIC   select d.* except (
# MAGIC       learner_alternate_email_hash,
# MAGIC       learner_alternate_email_domain,
# MAGIC       country_derived,
# MAGIC       region_derived,
# MAGIC       audience,
# MAGIC       updated_account_id,
# MAGIC       updated_account_name,
# MAGIC       updated_ultimate_parent_account_id,
# MAGIC       updated_ultimate_parent_account_name,
# MAGIC       match_method), 
# MAGIC     d.address_country as country_derived,
# MAGIC     d.address_region as region_derived,
# MAGIC
# MAGIC
# MAGIC   from docebo_not_matched d 
# MAGIC   
# MAGIC )
# MAGIC select * 
# MAGIC from not_matched_extra_fields
# MAGIC
# MAGIC -- # -- ''')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select *
# MAGIC from main.it_training_silver.webassessor_custom_fields
# MAGIC where processDate = (select max(processDate) from main.it_training_silver.webassessor_custom_fields)
# MAGIC and custom_field_id=2100153

# COMMAND ----------

display(
  users_df
    
)

# COMMAND ----------

users_df_gold = add_gold_metadata(users_df)

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Transcripts

# COMMAND ----------

transcripts_df = spark.sql('''
select 
  *,
  case 
  when hour(from_utc_timestamp(date, 'America/Phoenix')) < 7 
  then from_utc_timestamp(date, 'America/Phoenix') - interval 1 day
  else from_utc_timestamp(date, 'America/Phoenix')
end AS adjusted_exam_date
from main.it_training_silver.webassessor_transcripts t
where processDate = (select max(processDate) from main.it_training_silver.webassessor_transcripts)
''')

# COMMAND ----------

transcripts_df_gold = add_gold_metadata(transcripts_df)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Registrations

# COMMAND ----------

reg_df = spark.sql('''
  select 
  r.*, 
  case when r.voucher_codes is not null then 1 else 0 end as has_voucher,
  case when p.name ilike '%in-person%' then 'in person' else 'virtual' end as type,
  case 
    when test_name ilike '%Data Analyst Associate%' then 'Databricks Certified Data Analyst Associate'
    when test_name ilike '%Associate Data Analyst%' then 'Databricks Certified Data Analyst Associate'
    when test_name ilike '%Machine Learning Professional%' then 'Databricks Certified Machine Learning Professional'
    when test_name ilike '%Associate Data Engineer%' then 'Databricks Certified Data Engineer Associate'
    when test_name ilike '%Data Engineer Associate%' then 'Databricks Certified Data Engineer Associate'
    when test_name ilike '%Machine Learning Associate%' then 'Databricks Certified Machine Learning Associate'
    when test_name ilike '%Associate ML Practitioner%' then 'Databricks Certified Machine Learning Associate'
    when test_name ilike '%Associate Developer for Apache Spark 3.0%' then 'Databricks Certified Associate Developer for Apache Spark 3.0'
    when test_name ilike '%Professional Data Engineer%' then 'Databricks Certified Data Engineer Professional'
    when test_name ilike '%Data Engineer Professional%' then 'Databricks Certified Data Engineer Professional'
    when test_name ilike '%Professional Data Scientist%' then 'Databricks Certified Data Scientist Professional'
    when test_name ilike '%Hadoop Migration Architect%' then 'Academy Accreditation - Hadoop Migration Architect'
    when test_name ilike '%Associate Platform Administrator%' then 'Azure Databricks Certified Associate Platform Administrator'
    when test_name ilike '%Associate Developer for Apache Spark 2.4%' then 'Databricks Certified Associate Developer for Apache Spark 2.4'
  end as credential_name
  from main.it_training_silver.webassessor_registrations r
  left join main.it_training_silver.webassessor_products p on r.product_code = p.code and p.processDate = '2024-01-08'
  where r.processdate = (select max(processdate) from main.it_training_silver.webassessor_registrations)
''')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select *
# MAGIC   from main.it_training_silver.webassessor_registrations r
# MAGIC   where r.processdate = (select max(processdate) from main.it_training_silver.webassessor_registrations)

# COMMAND ----------

reg_df_gold = add_gold_metadata(reg_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = users_df_gold, 
  table_name = f'{focus_database_name}.webassessor_users', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = transcripts_df_gold, 
  table_name = f'{focus_database_name}.webassessor_transcripts', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = reg_df_gold, 
  table_name = f'{focus_database_name}.webassessor_registrations', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)