# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for instructor utilzation from Airtable \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Workspace/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

# spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import requests

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

import pandas as pd


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

def convertToDF(data):
  """
    data is a list of objects
  """
  json_obj = {}
  
  json_obj['field'] = data

  df = pd.json_normalize(json_obj['field'])
  lst = list(df)
  df[lst] = df[lst].astype(str)

  spark_df = (
    spark
      .createDataFrame(df)
  )
  return spark_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### Training Requests

# COMMAND ----------

# MAGIC %sql 
# MAGIC create or replace temp view training_requests as 
# MAGIC with recent_status as (
# MAGIC   select 
# MAGIC     processdate,
# MAGIC     status,
# MAGIC     id, 
# MAGIC     max(processdate) as recent_date,
# MAGIC     first_value(status) over (partition by id order by processdate desc) as most_recent_status
# MAGIC   from main.field_learning_enablement.training_requests_queue
# MAGIC   where status is not null
# MAGIC   group by all
# MAGIC )
# MAGIC , 
# MAGIC cutoff_date as (
# MAGIC   select 
# MAGIC     t.id, 
# MAGIC     max(t.date_last_modified_status) as cutoff_date
# MAGIC   from main.field_learning_enablement.training_requests_queue t
# MAGIC   where t.status IN (
# MAGIC     '*Approved for Revenue',
# MAGIC     '*Rejected - Course Not Ready',
# MAGIC     '*Rejected - Employee',
# MAGIC     '*Rejected - No Opportunity',
# MAGIC     '*Rejected - Not an active customer',
# MAGIC     '*Rejected - Partner',
# MAGIC     '*Unrelated > Help Center',
# MAGIC     'Cancelled',
# MAGIC     'Completed PS&T Learning Sub Field',
# MAGIC     'Complimentary Certification - ILT Issue',
# MAGIC     'Duplicate Request',
# MAGIC     'Rejected - Unrelated',
# MAGIC     'Revenue Recognized Previously'
# MAGIC   )
# MAGIC   group by t.id
# MAGIC )
# MAGIC ,
# MAGIC first_response_date as (
# MAGIC   select 
# MAGIC     id,
# MAGIC     min(date_last_modified_status) as first_response_date
# MAGIC   from main.field_learning_enablement.training_requests_queue
# MAGIC   where date_last_modified_status is not null
# MAGIC   group by id
# MAGIC )
# MAGIC ,
# MAGIC weekdays AS (
# MAGIC   SELECT 
# MAGIC     date,
# MAGIC     is_weekday
# MAGIC   FROM main.it_core_dim.dim_dates
# MAGIC   where is_weekday 
# MAGIC   AND date_format(date, 'MM-dd') NOT IN ('01-01', '12-25')
# MAGIC ),
# MAGIC id_level_metrics as (
# MAGIC   select 
# MAGIC     t.id,
# MAGIC     t.submission_date,
# MAGIC     t.created_time,
# MAGIC     c.cutoff_date as completion_date,
# MAGIC     frd.first_response_date
# MAGIC   from main.field_learning_enablement.training_requests_queue t
# MAGIC   left join cutoff_date c on t.id = c.id
# MAGIC   left join first_response_date frd on t.id = frd.id
# MAGIC   where t.submission_date::date >= '2024-10-01'
# MAGIC   group by all
# MAGIC ),
# MAGIC completion_days_excl_weekends AS (
# MAGIC   SELECT 
# MAGIC     m.id,
# MAGIC     count(*) as completion_days
# MAGIC   FROM id_level_metrics m
# MAGIC   JOIN weekdays w
# MAGIC     ON w.date >= m.submission_date::date 
# MAGIC     AND w.date <= m.completion_date::date
# MAGIC   WHERE m.completion_date IS NOT NULL
# MAGIC   GROUP BY m.id
# MAGIC ),
# MAGIC completion_hours_excl_weekends AS (
# MAGIC   SELECT 
# MAGIC     m.id,
# MAGIC     sum(
# MAGIC       CASE 
# MAGIC         WHEN w.date = m.submission_date::date 
# MAGIC           AND w.date = m.completion_date::date THEN 
# MAGIC           extract(hour FROM m.completion_date) - extract(hour FROM m.submission_date)
# MAGIC         WHEN w.date = m.submission_date::date THEN 24 - extract(hour FROM m.submission_date)
# MAGIC         WHEN w.date = m.completion_date::date THEN extract(hour FROM m.completion_date)
# MAGIC         ELSE 24
# MAGIC       END
# MAGIC     ) as completion_hours
# MAGIC   FROM id_level_metrics m
# MAGIC   JOIN weekdays w
# MAGIC     ON w.date BETWEEN m.submission_date::date AND m.completion_date::date
# MAGIC   WHERE m.completion_date IS NOT NULL
# MAGIC   GROUP BY m.id
# MAGIC ),
# MAGIC first_response_days_excl_weekends AS (
# MAGIC   SELECT 
# MAGIC     m.id,
# MAGIC     count(*) as first_response_days
# MAGIC   FROM id_level_metrics m
# MAGIC   JOIN weekdays w
# MAGIC     ON w.date >= m.created_time::date 
# MAGIC     AND w.date <= m.first_response_date::date
# MAGIC   WHERE m.first_response_date IS NOT NULL
# MAGIC   GROUP BY m.id
# MAGIC ),
# MAGIC first_response_hours_excl_weekends AS (
# MAGIC   SELECT 
# MAGIC     m.id,
# MAGIC     sum(
# MAGIC       CASE 
# MAGIC         WHEN w.date = m.created_time::date 
# MAGIC           AND w.date = m.first_response_date::date THEN 
# MAGIC           extract(hour FROM m.first_response_date) - extract(hour FROM m.created_time)
# MAGIC         WHEN w.date = m.created_time::date THEN 24 - extract(hour FROM m.created_time)
# MAGIC         WHEN w.date = m.first_response_date::date THEN extract(hour FROM m.first_response_date)
# MAGIC         ELSE 24
# MAGIC       END
# MAGIC     ) as first_response_hours
# MAGIC   FROM id_level_metrics m
# MAGIC   JOIN weekdays w
# MAGIC     ON w.date BETWEEN m.created_time::date AND m.first_response_date::date
# MAGIC   WHERE m.first_response_date IS NOT NULL
# MAGIC   GROUP BY m.id
# MAGIC ),
# MAGIC date_diffs as (
# MAGIC select 
# MAGIC   t.*,
# MAGIC   split(regexp_replace(regexp_replace(t.region_from_class_name, '\\[|\\]', ''), "'", ""), ', ')[0] as region,
# MAGIC   split(regexp_replace(regexp_replace(t.projects_from_class_name, '\\[|\\]', ''), "'", ""), ', ')[0] as course,
# MAGIC   regexp_extract_all(t.collaborator, "'email':\\s*'([^']+)'") AS collaborator_emails,
# MAGIC   d.*,
# MAGIC   c.cutoff_date as completion_date,
# MAGIC   frd.first_response_date,
# MAGIC   date_diff(c.cutoff_date::date, submission_date::date) as completion_days_with_weekends,
# MAGIC   timestampdiff(HOUR, submission_date, c.cutoff_date) as completion_hours_with_weekends,
# MAGIC   COALESCE(cd.completion_days, 0) as completion_days,
# MAGIC   COALESCE(ch.completion_hours, 0) as completion_hours,
# MAGIC   COALESCE(frd_days.first_response_days, 0) as first_response_days,
# MAGIC   COALESCE(frh.first_response_hours, 0) as first_response_hours
# MAGIC from main.field_learning_enablement.training_requests_queue t
# MAGIC inner join main.it_core_dim.dim_dates d on t.submission_date::date = d.date
# MAGIC left join cutoff_date c on t.id = c.id
# MAGIC left join first_response_date frd on t.id = frd.id
# MAGIC left join completion_days_excl_weekends cd on t.id = cd.id
# MAGIC left join completion_hours_excl_weekends ch on t.id = ch.id
# MAGIC left join first_response_days_excl_weekends frd_days on t.id = frd_days.id
# MAGIC left join first_response_hours_excl_weekends frh on t.id = frh.id
# MAGIC where t.submission_date::date >= '2024-10-01'
# MAGIC   and (c.cutoff_date is null or t.processDate <= c.cutoff_date::date)
# MAGIC order by id, submission_date asc, processdate asc
# MAGIC )
# MAGIC select 
# MAGIC   id, 
# MAGIC   created_time, 
# MAGIC   request_num, 
# MAGIC   submission_date, 
# MAGIC   milestone_name_ff_psa as milestone_name,
# MAGIC   requestor_type, 
# MAGIC   requestor_name, 
# MAGIC   requestor_email, 
# MAGIC   payment_type, 
# MAGIC   request_type, 
# MAGIC   status, 
# MAGIC   last_modified_by_email,
# MAGIC   last_modified_by_name,
# MAGIC   date_last_modified_status,
# MAGIC   notes, 
# MAGIC   collaborator_emails, 
# MAGIC   ff_psa_milestone_link as milestone_link, 
# MAGIC   ops_notes, 
# MAGIC   processDate as action_date, 
# MAGIC   region, 
# MAGIC   completion_days, 
# MAGIC   completion_hours,
# MAGIC   first_response_days,
# MAGIC   first_response_hours
# MAGIC from date_diffs 
# MAGIC order by id, submission_date asc, processdate asc

# COMMAND ----------

# Private Onboarding Classes (Skills@Scale Subscription)
# Private Instructor Led Training
# Public Instructor Led Training
# Private Half-Day Classes

# Who is the Trainer assigned
# Has the Calendar invite been sent? When
# Link of invite
# Zoom / MS Teams link
# What is still outstanding (this might be the hardest)
# Final registration list of event (to view or download)
# Total TSU count

# COMMAND ----------

training_requests_df = spark.sql('''
  select 
    id,
    request_num,
    status,
    submission_date,
    notes,
    ops_notes,
    action_date,
    milestone_name,
    milestone_link,
    requestor_type,
    requestor_name,
    requestor_email,
    last_modified_by_email,
    last_modified_by_name,
    payment_type,
    request_type,
    date_last_modified_status,
    collaborator_emails,
    created_time,
    region,
    completion_days,
    completion_hours,
    first_response_days,
    first_response_hours
  from training_requests
''')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view sfdc_cases as 
# MAGIC WITH ai_case_final AS (
# MAGIC   -- Get the final state of each case from ai_training_case
# MAGIC   SELECT 
# MAGIC     id,
# MAGIC     CaseNumber,
# MAGIC     CreatedDate,
# MAGIC     ClosedDate,
# MAGIC     LastModifiedDate,
# MAGIC     Status,
# MAGIC     category,
# MAGIC     training_issue,
# MAGIC     priority,
# MAGIC     owner_email,
# MAGIC     owner_name,
# MAGIC     relationship_with_databricks,
# MAGIC     Subject,
# MAGIC     Description,
# MAGIC     IsClosed,
# MAGIC     Case_Age_in_Days__c,
# MAGIC     CASE 
# MAGIC       WHEN IsClosed THEN ClosedDate
# MAGIC       ELSE LastModifiedDate
# MAGIC     END as end_date
# MAGIC   FROM main.field_learning_enablement.ai_training_case
# MAGIC   WHERE processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.ai_training_case)
# MAGIC ),
# MAGIC sfdc_cases_raw as (
# MAGIC   select 
# MAGIC     Id, 
# MAGIC     processdate, 
# MAGIC     Latest_Public_Comment__c
# MAGIC   FROM main.sfdc_bronze.case
# MAGIC ),
# MAGIC first_modified_date AS (
# MAGIC   SELECT 
# MAGIC     c.id,
# MAGIC     MIN(c.processdate) as first_modified_date
# MAGIC   FROM sfdc_cases_raw c
# MAGIC   WHERE c.Latest_Public_Comment__c IS NOT NULL
# MAGIC   GROUP BY c.id
# MAGIC ),
# MAGIC weekdays AS (
# MAGIC   SELECT 
# MAGIC     date,
# MAGIC     is_weekday
# MAGIC   FROM main.it_core_dim.dim_dates
# MAGIC   WHERE is_weekday 
# MAGIC     AND date_format(date, 'MM-dd') NOT IN ('01-01', '12-25')
# MAGIC ),
# MAGIC id_level_metrics AS (
# MAGIC   SELECT 
# MAGIC     ai.id,
# MAGIC     ai.CreatedDate,
# MAGIC     ai.end_date,
# MAGIC     fmd.first_modified_date
# MAGIC   FROM ai_case_final ai
# MAGIC   LEFT JOIN first_modified_date fmd ON ai.id = fmd.id
# MAGIC ),
# MAGIC completion_days_excl_weekends AS (
# MAGIC   SELECT 
# MAGIC     m.id,
# MAGIC     COUNT(*) as completion_days
# MAGIC   FROM id_level_metrics m
# MAGIC   JOIN weekdays w
# MAGIC     ON w.date >= m.CreatedDate::date 
# MAGIC     AND w.date <= m.end_date::date
# MAGIC   GROUP BY m.id
# MAGIC ),
# MAGIC completion_hours_excl_weekends AS (
# MAGIC   SELECT 
# MAGIC     m.id,
# MAGIC     SUM(
# MAGIC       CASE 
# MAGIC         WHEN w.date = m.CreatedDate::date 
# MAGIC           AND w.date = m.end_date::date THEN 
# MAGIC           EXTRACT(HOUR FROM m.end_date) - EXTRACT(HOUR FROM m.CreatedDate)
# MAGIC         WHEN w.date = m.CreatedDate::date THEN 24 - EXTRACT(HOUR FROM m.CreatedDate)
# MAGIC         WHEN w.date = m.end_date::date THEN EXTRACT(HOUR FROM m.end_date)
# MAGIC         ELSE 24
# MAGIC       END
# MAGIC     ) as completion_hours
# MAGIC   FROM id_level_metrics m
# MAGIC   JOIN weekdays w
# MAGIC     ON w.date BETWEEN m.CreatedDate::date AND m.end_date::date
# MAGIC   GROUP BY m.id
# MAGIC ),
# MAGIC first_response_days_excl_weekends AS (
# MAGIC   SELECT 
# MAGIC     m.id,
# MAGIC     COUNT(*) as first_response_days
# MAGIC   FROM id_level_metrics m
# MAGIC   JOIN weekdays w
# MAGIC     ON w.date >= m.CreatedDate::date 
# MAGIC     AND w.date <= m.first_modified_date::date
# MAGIC   WHERE m.first_modified_date IS NOT NULL
# MAGIC   GROUP BY m.id
# MAGIC ),
# MAGIC first_response_hours_excl_weekends AS (
# MAGIC   SELECT 
# MAGIC     m.id,
# MAGIC     SUM(
# MAGIC       CASE 
# MAGIC         WHEN w.date = m.CreatedDate::date 
# MAGIC           AND w.date = m.first_modified_date::date THEN 
# MAGIC           EXTRACT(HOUR FROM m.first_modified_date) - EXTRACT(HOUR FROM m.CreatedDate)
# MAGIC         WHEN w.date = m.CreatedDate::date THEN 24 - EXTRACT(HOUR FROM m.CreatedDate)
# MAGIC         WHEN w.date = m.first_modified_date::date THEN EXTRACT(HOUR FROM m.first_modified_date)
# MAGIC         ELSE 24
# MAGIC       END
# MAGIC     ) as first_response_hours
# MAGIC   FROM id_level_metrics m
# MAGIC   JOIN weekdays w
# MAGIC     ON w.date BETWEEN m.CreatedDate::date AND m.first_modified_date::date
# MAGIC   WHERE m.first_modified_date IS NOT NULL
# MAGIC   GROUP BY m.id
# MAGIC ),
# MAGIC date_range AS (
# MAGIC   -- Create one row per weekday between CreatedDate and end_date (ClosedDate if closed, LastModifiedDate if open)
# MAGIC   SELECT 
# MAGIC     ai.id,
# MAGIC     ai.CaseNumber,
# MAGIC     ai.CreatedDate,
# MAGIC     ai.ClosedDate,
# MAGIC     ai.LastModifiedDate,
# MAGIC     ai.Status,
# MAGIC     ai.category,
# MAGIC     ai.training_issue,
# MAGIC     ai.priority,
# MAGIC     ai.owner_email,
# MAGIC     ai.owner_name,
# MAGIC     ai.relationship_with_databricks,
# MAGIC     ai.Subject,
# MAGIC     ai.Description,
# MAGIC     ai.IsClosed,
# MAGIC     ai.Case_Age_in_Days__c,
# MAGIC     fmd.first_modified_date,
# MAGIC     w.date as action_date,
# MAGIC     COALESCE(cd.completion_days, 0) as completion_days,
# MAGIC     COALESCE(ch.completion_hours, 0) as completion_hours,
# MAGIC     COALESCE(frd.first_response_days, 0) as first_response_days,
# MAGIC     COALESCE(frh.first_response_hours, 0) as first_response_hours
# MAGIC   FROM ai_case_final ai
# MAGIC   JOIN weekdays w
# MAGIC     ON w.date >= ai.CreatedDate::date 
# MAGIC     AND w.date <= ai.end_date::date
# MAGIC   LEFT JOIN first_modified_date fmd ON ai.id = fmd.id
# MAGIC   LEFT JOIN completion_days_excl_weekends cd ON ai.id = cd.id
# MAGIC   LEFT JOIN completion_hours_excl_weekends ch ON ai.id = ch.id
# MAGIC   LEFT JOIN first_response_days_excl_weekends frd ON ai.id = frd.id
# MAGIC   LEFT JOIN first_response_hours_excl_weekends frh ON ai.id = frh.id
# MAGIC ),
# MAGIC cases_over_time as (
# MAGIC   select 
# MAGIC     dr.*, 
# MAGIC     regexp_replace(c.Latest_Public_Comment__c, '<[^>]+>', '') as Latest_Public_Comment__c
# MAGIC   from date_range dr
# MAGIC   left join sfdc_cases_raw c
# MAGIC   on c.id = dr.id and dr.action_date = c.processdate
# MAGIC   order by id, action_date
# MAGIC )
# MAGIC
# MAGIC select * 
# MAGIC from cases_over_time

# COMMAND ----------

sfdc_cases_df = spark.sql('''
  select 
    id,
    CaseNumber,
    Subject,
    Description,
    Latest_Public_Comment__c,
    Status,
    CreatedDate,
    LastModifiedDate,
    ClosedDate,
    category,
    training_issue,
    IsClosed,
    priority,
    owner_email,
    owner_name,
    relationship_with_databricks,
    Case_Age_in_Days__c,
    first_modified_date,
    action_date,
    completion_days,
    completion_hours,
    first_response_days,
    first_response_hours
  from sfdc_cases
''')




# COMMAND ----------

training_requests_df_gold = add_gold_metadata(training_requests_df)
sfdc_cases_df_gold = add_gold_metadata(sfdc_cases_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = training_requests_df_gold, 
  table_name = f'{focus_database_name}.training_requests_over_time', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = sfdc_cases_df_gold, 
  table_name = f'{focus_database_name}.sfdc_training_cases_over_time', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)