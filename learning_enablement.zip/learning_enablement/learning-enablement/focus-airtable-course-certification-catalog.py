# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for instructor utilzation from Airtable \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Workspace/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

# spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import requests

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

import pandas as pd


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

def convertToDF(data):
  """
    data is a list of objects
  """
  json_obj = {}
  
  json_obj['field'] = data

  df = pd.json_normalize(json_obj['field'])
  lst = list(df)
  df[lst] = df[lst].astype(str)

  spark_df = (
    spark
      .createDataFrame(df)
  )
  return spark_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### Instructors

# COMMAND ----------

airtable_pat = dbutils.secrets.get('ldr-airtable', 'airtable-token')

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Course%20Certification%20Catalog?view=Course%20Catalog"
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

course_records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()


course_records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  course_records += response_json['records']

# COMMAND ----------

df = convertToDF(course_records)

# COMMAND ----------

df.createOrReplaceTempView('courses')

# COMMAND ----------

course_df = spark.sql('''
  with pre as (
    select
    `id`,
    `createdTime`,
    `fields.Course Name/Project` as course_name, 
    `fields.Duration (Hours)` as duration_hours,
    `fields.Course Abbreviation` as course_abbreviation,
    `fields.Instructor Skills` as instructor_skills,
    `fields.Audience` as audience,
    `fields.APPROVED Instructors` as approved_instructors,
    `fields.Instructors INTERESTED` as instructors_interested,
    `fields.Private Training Request Queue` as private_training_request_queue,
    `fields.Course Type` as course_type,
    `fields.Training Request Queue` as training_request_queue,
    `fields.Latest Version #` as latest_version,
    `fields.Type` as type,
    `fields.ILT Schedule 2` as ilt_schedule_2,
    `fields..com Facing?` as dot_com_facing,
    `fields.Certification Catalog` as certification_catalog,
    `fields.Candidate Instructors` as candidate_instructors,
    `fields.Course Name (2)` as course_name_2,
    `fields.ILT Schedule copy` as ilt_schedule_copy,
    `fields.Duration (Days)` as duration_days,
    `fields.Duration (Weeks)` as duration_weeks,
    `fields.Parent Course` as parent_course,
    `fields.Active or Inactive Course` as active_inactive,
    `fields.Content Review Status` as content_review_status,
    `fields.Session Mapping` as session_mapping,
    `fields.Session Type / Module` as session_type_module
    from courses
  )
  ,
  cleaned as (
    select 
      id,
      case when createdTime in ('nan', 'NaN') then null else createdTime end as createdTime, 
      case when course_name in ('nan', 'NaN') then null else course_name end as course_name,
      case when duration_hours in ('nan', 'NaN') then null else duration_hours end as duration_hours,
      case when course_abbreviation in ('nan', 'NaN') then null else course_abbreviation end as course_abbreviation,
      case when instructor_skills in ('nan', 'NaN') then null else instructor_skills end as instructor_skills,
      case when audience in ('nan', 'NaN') then null else audience end as audience,
      case when approved_instructors in ('nan', 'NaN') then null else approved_instructors end as approved_instructors,
      case when instructors_interested in ('nan', 'NaN') then null else instructors_interested end as instructors_interested,
      case when private_training_request_queue in ('nan', 'NaN') then null else private_training_request_queue end as private_training_request_queue,
      case when course_type in ('nan', 'NaN') then null else course_type end as course_type,
      case when training_request_queue in ('nan', 'NaN') then null else training_request_queue end as training_request_queue,
      case when latest_version in ('nan', 'NaN') then null else latest_version end as latest_version,
      case when type in ('nan', 'NaN') then null else type end as type,
      case when ilt_schedule_2 in ('nan', 'NaN') then null else ilt_schedule_2 end as ilt_schedule_2,
      case when dot_com_facing in ('nan', 'NaN') then null else dot_com_facing end as dot_com_facing,
      case when certification_catalog in ('nan', 'NaN') then null else certification_catalog end as certification_catalog,
      case when candidate_instructors in ('nan', 'NaN') then null else candidate_instructors end as candidate_instructors,
      case when course_name_2 in ('nan', 'NaN') then null else course_name_2 end as course_name_2,
      case when ilt_schedule_copy in ('nan', 'NaN') then null else ilt_schedule_copy end as ilt_schedule_copy,
      case when duration_days in ('nan', 'NaN') then null else duration_days end as duration_days,
      case when duration_weeks in ('nan', 'NaN') then null else duration_weeks end as duration_weeks,
      case when parent_course in ('nan', 'NaN') then null else parent_course end as parent_course,
      case when active_inactive in ('nan', 'NaN') then null else active_inactive end as active_inactive,
      case when content_review_status in ('nan', 'NaN') then null else content_review_status end as content_review_status,
      case when session_mapping in ('nan', 'NaN') then null else session_mapping end as session_mapping,
      case when session_type_module in ('nan', 'NaN') then null else session_type_module end as session_type_module
    from pre
  )

  select 
    id,
    createdTime,
    course_name,
    try_cast(duration_hours as double) as duration_hours,
    course_abbreviation,
    from_json(
          regexp_replace(instructor_skills, "\'", '"'), 
          'array<string>'
      ) AS instructor_skills,
    from_json(
          regexp_replace(audience, "\'", '"'), 
          'array<string>'
      ) AS audience,
    split(approved_instructors, ',') as approved_instructors,
    from_json(
          regexp_replace(instructors_interested, "\'", '"'), 
          'array<string>'
      ) AS instructors_interested,
    split(private_training_request_queue, ',') as private_training_request_queue,
    from_json(
          regexp_replace(course_type, "\'", '"'), 
          'array<string>'
      ) AS course_type,
    from_json(
          regexp_replace(training_request_queue, "\'", '"'), 
          'array<string>'
      ) AS training_request_queue,
    latest_version,
    type,
    from_json(
          regexp_replace(ilt_schedule_2, "\'", '"'), 
          'array<string>'
      ) AS ilt_schedule_2,
    dot_com_facing,
    certification_catalog,
    split(candidate_instructors, ',') as candidate_instructors,
    course_name_2,
    from_json(
          regexp_replace(ilt_schedule_copy, "\'", '"'), 
          'array<string>'
      ) AS ilt_schedule_copy,
    try_cast(duration_days as double) as duration_days,
    duration_weeks,
    parent_course,
    active_inactive,
    session_mapping,
    session_type_module
  from cleaned
  
''')


# COMMAND ----------

course_df_gold = add_gold_metadata(course_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = course_df_gold, 
  table_name = f'{focus_database_name}.airtable_course_catalog', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

