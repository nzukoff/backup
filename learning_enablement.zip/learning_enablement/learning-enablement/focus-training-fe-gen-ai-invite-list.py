# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
# from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import json
import requests
from pprint import pprint
from urllib.parse import quote_plus as urlencode
import pandas as pd

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

try:
  sht = authGoogleSheet("GenAI enrollments")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')

  
try:
  worksheet = sht.worksheet("Sheet2")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "GenAI enrollments",
 "Sheet2",
 "invite_list",
 clean_column_names="true", 
 make_columns_unique="true"
)

invite_list_raw = (spark.sql("""select * from invite_list"""))
invite_list_df = invite_list_raw.select(F.col('username').alias('primaryWorkEmail')).filter(F.col("primaryWorkEmail").isNotNull())

# COMMAND ----------

invite_list_gold = add_gold_metadata(invite_list_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = invite_list_gold, 
  table_name = f'{focus_database_name}.fe_gen_ai_invite_list', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)