# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Karthik Reddy \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
from pyspark.sql.functions import col, when

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC
from pyspark.sql import functions as F
from pyspark.sql.window import Window as W 

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# DBTITLE 1,Fetching Uplimit users
uplimit_latest_process_date = get_latest_partition_value(spark, "main.field_learning_enablement.uplimit_users_bronze",  "processDate")

uplimit_users = (
  spark.read.table("main.field_learning_enablement.uplimit_users_bronze")
    .filter(F.col("processDate") == uplimit_latest_process_date)
    .drop("processDate")
)



# COMMAND ----------

# DBTITLE 1,SFDC data
#SFDC Tables

sfdc_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.account",  "processDate")

sfdc_accounts = (
  spark.read.table("main.sfdc_bronze.account")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

sfdc_contacts = (
  spark.read.table("main.sfdc_bronze.contact")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

sfdc_leads = (
  spark.read.table("main.sfdc_bronze.lead")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

region_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.countryregionmap__c",  "processDate")

countries_regions = (
  spark.read.table("main.sfdc_bronze.countryregionmap__c")
  .filter(F.col("processDate") == region_latest_process_date)
  .select(
    # F.col("Name").alias("country_code"),
    F.col("Country__c").alias("country_name"),
    F.col("Region__c").alias("region")
  ).distinct()
)

# Docebo Logfood data
silver_docebo_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_self_paced_enrollments",  "processDate")

salesforce_account_email_domain_mapping = (
  spark.read.table("main.it_training_silver.docebo_salesforce_account_email_domain_mapping")
    .filter(~F.col("account_name").isin('Individual LMS Account', 'Individual LMS Account(Generic)', 'SFDC Test Customer', 'Databricks Partners Test'))
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

salesforce_account_email_domain_mapping.createOrReplaceTempView("salesforce_account_email_domain_mapping_temp")

# Blacklisted domains

blacklist_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.blacklist_domains",  "processDate")

blacklist_domains = (
  spark.read.table(f"{focus_database_name}.blacklist_domains")
    .filter(F.col("processDate") == blacklist_latest_process_date)
)

blacklist = [domain["blacklist_domain"] for domain in blacklist_domains.collect()]

first_migration_branches = ["DBK_PRTNR", "DBK_MCSFT"]
first_migration_date = "2021-12-08"
second_migration_date = "2022-01-07"

databricks_account_id = "0016100001FyvmIAAR"

# COMMAND ----------

# DBTITLE 1,Partner Domains
partner_domains_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.partner_domains_accounts",  "processDate")

partner_domains_df = (
  spark.read.table(f"{focus_database_name}.partner_domains_accounts")
    .filter(F.col("processDate") == partner_domains_latest_process_date)
    # .filter(F.col("email_domain") != "microsoft.com")
    .drop("processDate")
)

partner_domains = [domain["email_domain"] for domain in partner_domains_df.collect()]

partner_accounts = [domain["ultimate_parent_account_name"] for domain in partner_domains_df.collect()]

# Accounts Curated

accounts_curated_snapshot_date = get_latest_partition_value(spark, "main.gtm_data.core_accounts_curated",  "snapshot_date")

accounts_curated = (
  spark.read.table("main.gtm_data.core_accounts_curated")
    .filter(F.col("snapshot_date") == accounts_curated_snapshot_date)
    .select("account_id", "business_unit")
)

microsoft_account_id = "00161000005eOdjAAE"
microsoft_account_name = "Microsoft"
microsoft_parent_account_id = "0014N00002BAYhLQAX"
microsoft_parent_account_name = "Microsoft Consulting Services"

# COMMAND ----------

# DBTITLE 1,Setting the email domain and branch in users list
uplimit_users = (
    uplimit_users
    .withColumn("email_domain", lower(trim(split(col("Email"), "@").getItem(1))))
    .withColumn("alternate_email_domain", col("email_domain"))
    .withColumn("email_domain_final", coalesce(col("email_domain"), col("alternate_email_domain")))
    .withColumn("email_hash", F.sha2(F.col("Email"), 256))
)

# Step 1: Prepare partner domain mapping
partner_domains_data_df = (
    partner_domains_df
    .select(col("email_domain").alias("email_domain_pre"))
    .distinct()
)

# Step 2: Join users with partner domain list
uplimit_users_emails = (
    uplimit_users
    .join(
        partner_domains_data_df,
        uplimit_users["email_domain_final"] == partner_domains_data_df["email_domain_pre"],
        how="left"
    )
)

# Step 3: Assign branch_name and branch_code
uplimit_users_emails = uplimit_users_emails.withColumn(
    "branch_code",
    when(col("email_domain_final") == "databricks.com", lit("DBK_EMP"))
    .when(col("email_domain_pre").isNotNull(), lit("DBK_PRTNR"))
    .when(col("email_domain_final") == "microsoft.com", lit("DBK_MCSFT"))
    .otherwise(lit("DBKS_ACDMY"))
).withColumn(
  "branch_name",
  when(col("email_domain_final") == "databricks.com", lit("Employee Academy"))
    .when(col("email_domain_pre").isNotNull(), lit("Partner Academy"))
    .when(col("email_domain_final") == "microsoft.com", lit("Microsoft Other"))
    .otherwise(lit("Customer Academy"))
)

# Step 4: Drop temp columns
uplimit_users_emails = uplimit_users_emails.drop("email_domain_final", "email_domain_pre")

# Sanity check
assert unit_test_df_count(uplimit_users) == unit_test_df_count(uplimit_users_emails)

# COMMAND ----------

uplimit_users_emails.createOrReplaceTempView("uplimit_users_emails_temp")

# COMMAND ----------

source_df = (uplimit_users_emails
.withColumnRenamed("UserId", "id")
.withColumnRenamed("Email", "email")
.withColumn("alternate_email", F.col("Email"))
.withColumn("alternate_email_domain", F.col("email_domain"))
.withColumn("alternate_email_hash", F.col("email_hash"))
.select(
  "id",
    "email",
    "email_domain",
    "email_hash",
    "branch_name",
    "alternate_email",
    "alternate_email_domain",
    "alternate_email_hash",
    "branch_code"
)
)

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import Window as W

def process_uplimit_user_accounts(
    uplimit_users,
    sfdc_contacts,
    sfdc_leads,
    sfdc_accounts,
    partner_domains_df,
    salesforce_account_email_domain_mapping,
    accounts_curated,
    partner_domains,
    blacklist,
    databricks_account_id,
    microsoft_account_id,
    microsoft_account_name,
    microsoft_parent_account_id,
    microsoft_parent_account_name,
    partner_accounts
):
    """
    Processes uplimit user data by enriching it with Salesforce account information,
    deduplicating contacts/leads, and categorizing users into different audiences
    (Customer, Partner, Employee, Microsoft).

    Args:
        uplimit_users (DataFrame): Initial DataFrame containing uplimit user data.
        sfdc_contacts (DataFrame): Salesforce contacts DataFrame.
        sfdc_leads (DataFrame): Salesforce leads DataFrame.
        sfdc_accounts (DataFrame): Salesforce accounts DataFrame.
        partner_domains_df (DataFrame): DataFrame containing partner email domains.
        salesforce_account_email_domain_mapping (DataFrame): Mapping of Salesforce
                                                              accounts to email domains.
        accounts_curated (DataFrame): Curated accounts DataFrame, likely containing
                                      business unit information.
        partner_domains (list): List of partner email domains.
        blacklist (list): List of blacklisted email domains.
        databricks_account_id (str): Account ID for Databricks.
        microsoft_account_id (str): Account ID for Microsoft.
        microsoft_account_name (str): Account name for Microsoft.
        microsoft_parent_account_id (str): Parent account ID for Microsoft.
        microsoft_parent_account_name (str): Parent account name for Microsoft.
        partner_accounts (list): List of partner account names to filter out.

    Returns:
        DataFrame: A cleaned and enriched DataFrame of uplimit users with associated
                   account and audience information.
    """

    # --- PAGE 1: Initial email domain and learner branch processing ---
    uplimit_users_emails_pre = (
        uplimit_users
        .withColumn('email_domain_pre',
                    F.when((F.col('email_domain').isin('databricks.com')) & (F.col('branch_code') == 'DBK_EMP'), F.col('email_domain'))
                    .when(F.col('email_domain').isin(partner_domains), F.col('email_domain'))
                    .when(F.col('alternate_email_domain').isin(partner_domains), F.col('alternate_email_domain'))
                    .when((F.col('email_domain').isin(blacklist)) & (~F.col('alternate_email_domain').isin(blacklist)), F.col('alternate_email_domain'))
                    .otherwise(F.col('email_domain')))
        .withColumn('learner_branch',
                    F.when(F.col('branch_name') == "Employee Academy", F.lit("Databricks"))
                    .when(F.col('branch_name') == "Customer Academy", F.lit("Academy"))
                    .when(F.col('branch_name').isin("Microsoft Academy", "Partner Academy"), F.lit("Partner"))
                    .otherwise(F.lit(None))) # Added .otherwise(F.lit(None)) for completeness
    )

    uplimit_users_emails = (
        uplimit_users_emails_pre
        .withColumn('email_domain_final', F.coalesce(F.col("email_domain_pre"), F.lit("unknown")))
        .withColumn('audience_pre',
                    F.when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBKS_ACDMY'), F.lit('Customer Other'))
                    .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_PRTNR'), F.lit('Partner Other'))
                    .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_EMP'), F.lit('Employee Other'))
                    .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_MCSFT'), F.lit('Microsoft Other'))
                    .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_ADA'), F.lit('Customer'))
                    .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_ATT'), F.lit('Partner Other'))
                    .when((F.col('email_domain_final').isin(blacklist)) & ((F.col('branch_code').isNull()) | (F.col('branch_code') == "")), F.lit('Customer Other'))
                    .when((F.col('email_domain_final') == 'databricks.com') & ((F.col("branch_code") != "DBK_EMP") | (F.col("branch_code").isNull())), F.lit('Customer Other'))
                    .otherwise(F.lit(None))) # Added .otherwise(F.lit(None)) for completeness
    )

    # --- PAGE 2: Filtering and unioning for different user segments (Customers, Partners, Microsoft, Databricks) ---
    uplimit_users_emails_customers_domains = (
        uplimit_users_emails
        .filter(~F.col("email_domain_final").isin(partner_domains))
        .filter(~F.col("email_domain_final").isin(['microsoft.com', 'databricks.com']))
        .filter(~F.col("email_domain_final").isin(blacklist) | (F.col("branch_code") == "DBK_ADA"))
    )

    uplimit_users_emails_customers_blacklist = (
        uplimit_users_emails
        .filter(F.col("audience_pre") == "Customer Other")
    )

    uplimit_users_emails_customers_users = (
        uplimit_users_emails_customers_domains
        .union(uplimit_users_emails_customers_blacklist)
        .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Customer')).otherwise(F.col('audience_pre')))
    )

    uplimit_users_emails_partners_domains = (
        uplimit_users_emails
        .filter(F.col("email_domain_final").isin(partner_domains))
        .filter(~F.col("email_domain_final").isin(blacklist))
    )

    uplimit_users_emails_partners_blacklist = (
        uplimit_users_emails
        .filter(F.col("audience_pre") == "Partner Other")
    )

    uplimit_users_emails_partners_users = (
        uplimit_users_emails_partners_domains
        .union(uplimit_users_emails_partners_blacklist)
        .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Partner')).otherwise(F.col('audience_pre')))
    )

    uplimit_users_emails_microsoft_domains = (
        uplimit_users_emails
        .filter(F.col("email_domain_final") == "microsoft.com")
        .filter(~F.col("email_domain_final").isin(blacklist))
    )

    # --- PAGE 3: Microsoft and Databricks specific user filtering ---
    uplimit_users_emails_microsoft_blacklist = (
        uplimit_users_emails
        .filter(F.col("audience_pre") == "Microsoft Other")
    )

    uplimit_users_emails_microsoft_users = (
        uplimit_users_emails_microsoft_domains
        .union(uplimit_users_emails_microsoft_blacklist)
        .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Microsoft')).otherwise(F.col('audience_pre')))
    )

    uplimit_users_emails_databricks_domains = (
        uplimit_users_emails
        .filter(F.col("email_domain_final") == "databricks.com")
        .filter(~F.col("email_domain_final").isin(blacklist))
        .filter(F.col("branch_code") == "DBK_EMP")
    )

    uplimit_users_emails_databricks_blacklist = (
        uplimit_users_emails
        .filter(F.col("audience_pre") == "Employee Other")
    )

    uplimit_users_emails_databricks_users = (
        uplimit_users_emails_databricks_domains
        .union(uplimit_users_emails_databricks_blacklist)
        .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Employee')).otherwise(F.col('audience_pre')))
    )

    # --- PAGE 4: SFDC Contact and Lead Deduplication ---
    contact_dedupe_window = W.partitionBy("Email").orderBy(F.desc("LastModifiedDate"), "tiebreak")
    lead_dedupe_window = W.partitionBy("Email").orderBy(F.desc("LastModifiedDate"), "tiebreak")
    lead_contact_dedupe_window = W.partitionBy("Email").orderBy(F.desc("account_id"), F.desc("LastModifiedDate"), "tiebreak")

    sfdc_contact_dedupe = (
        sfdc_contacts
        .withColumn("tiebreak", F.monotonically_increasing_id())
        .withColumn("rank", F.rank().over(contact_dedupe_window))
        .filter(F.col("rank") == "1")
        .drop("tiebreak", "rank")
        .select(F.col("Email").alias('email'), F.col("Id").alias('sfdc_contact_id'), F.col("AccountId").alias('account_id'), F.col('LastModifiedDate'))
        .withColumn('sfdc_contact_type', F.lit('contact'))
    )

    sfdc_lead_dedupe = (
        sfdc_leads
        .withColumn("tiebreak", F.monotonically_increasing_id())
        .withColumn("rank", F.rank().over(lead_dedupe_window))
        .filter(F.col("rank") == "1")
        .drop("tiebreak", "rank")
        .select(F.col("Email").alias('email'), F.col("Id").alias('sfdc_contact_id'), F.col("LeanData__Reporting_Matched_Account__c").alias('account_id'), F.col('LastModifiedDate'))
        .withColumn('sfdc_contact_type', F.lit('lead'))
    )

    sfdc_lead_contact_dedupe = (
        sfdc_contact_dedupe
        .union(sfdc_lead_dedupe)
        .withColumn("tiebreak", F.monotonically_increasing_id())
        .withColumn("rank", F.rank().over(lead_contact_dedupe_window))
        .filter(F.col("rank") == "1")
        .drop("tiebreak", "rank")
    )

    sfdc_lead_contact = (
        sfdc_lead_contact_dedupe
        .withColumn('email_hash', F.sha2(F.col('email'), 256))
        .select('email_hash', 'account_id', 'sfdc_contact_id', 'sfdc_contact_type')
    )

    # --- PAGE 5: Customer Account Name Resolution and Joins ---
    account_names = (
        sfdc_accounts
        .select(F.col("Id").alias('account_id'), F.col("Name").alias('account_name_pre'), F.col("Account_Record_Type_Name__c").alias("record_type"))
        .filter((F.col("Account_Record_Type_Name__c") == "Account") | (F.col("Account_Record_Type_Name__c").isNull()))
        .filter(~F.col("Name").isin(partner_accounts))
        .filter(~F.col("Name").isin(["Unknown", "Generic Account", "Self", "Generic/Public Business Subscription Account", "None", "-", "Self Incorporated", "Databricks K.K. (データブリックス・ジャパン株式会社)"]))
        .filter(~F.col("Name").like("%Individual LMS Account%"))
    )

    uplimit_users_emails_account_ids_customers = (
        uplimit_users_emails_customers_users
        .join(sfdc_lead_contact, "email_hash", "left")
    )

    uplimit_users_emails_account_names_customers_email_join = (
        uplimit_users_emails_account_ids_customers
        .join(account_names, "account_id", "left")
        .withColumn('account_name', F.coalesce(F.col("account_name_pre"), F.lit("Unknown")))
    )

    uplimit_users_emails_account_ids_customers_alt_email_join = (
        uplimit_users_emails_account_names_customers_email_join
        .filter(F.col("account_name") == "Unknown")
        .drop('account_id', 'account_name', 'account_name_pre', 'record_type')
        .join(sfdc_lead_contact.withColumnRenamed('email_hash', 'alternate_email_hash'), "alternate_email_hash", "left")
    )

    uplimit_users_emails_account_names_customers_alt_email_join = (
        uplimit_users_emails_account_ids_customers_alt_email_join
        .join(account_names, "account_id", "left")
        .withColumn('account_name', F.coalesce(F.col("account_name_pre"), F.lit("Unknown")))
    )

    # --- PAGE 6 & 7: Unioning email and alternate email joins for customers ---
    uplimit_users_emails_account_names_customers = (
        uplimit_users_emails_account_names_customers_email_join
        .filter(F.col("account_name") != "Unknown")
        .select(
            'account_id', 'email', 'id',  'email_domain', 'email_hash',
            'branch_name', 'learner_branch', 'alternate_email_domain', 'alternate_email_hash',
            'branch_code', 'alternate_email',
            'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
            'account_name', 'audience'
        )
        .union(
            uplimit_users_emails_account_names_customers_alt_email_join.select(
                'account_id', 'email', 'id',  'email_domain', 'email_hash', 
                'branch_name', 'learner_branch', 'alternate_email_domain', 'alternate_email_hash',
                'branch_code', 'alternate_email',
                'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
                'account_name', 'audience'
            )
        )
    )

    # --- PAGE 7 & 8: Filtering for found accounts and joining with curated accounts ---
    uplimit_users_emails_account_names_customers_account_found = (
        uplimit_users_emails_account_names_customers
        .filter(F.col("account_name") != "Unknown")
        .select(
            'account_id', 'email', 'id',  'email_domain', 'email_hash',
            'branch_name', 'learner_branch', 'alternate_email_domain', 'alternate_email_hash',
            'branch_code', 'alternate_email',
            'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
            'account_name', 'audience'
        )
    )

    uplimit_users_emails_account_names_customers_account_found_bu = (
        uplimit_users_emails_account_names_customers_account_found
        .join(accounts_curated, 'account_id', 'left')
        .filter(F.col("business_unit").isNotNull())
        .drop('business_unit')
    )

    # --- PAGE 9: Handling accounts without business unit ---
    uplimit_users_emails_account_names_customers_account_found_no_bu = (
        uplimit_users_emails_account_names_customers_account_found
        .join(accounts_curated, 'account_id', 'left')
        .filter(F.col("business_unit").isNull())
        .withColumnRenamed('account_name', 'account_name_pre_2')
        .withColumn('account_name', F.lit("Unknown"))
        .drop('business_unit', 'account_name_pre_2')
        .select(
            'account_id', 'email', 'id',  'email_domain', 'email_hash',
            'branch_name', 'learner_branch', 'alternate_email_domain', 'alternate_email_hash',
            'branch_code', 'alternate_email',
            'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
            'account_name', 'audience'
        )
    )

    # --- PAGE 10: Customer account mapping based on email domains ---
    domain_window_customer_mapping = W.partitionBy("email_domain_final").orderBy(F.desc("total_emails"), "tiebreak")

    customer_account_mapping = (
        uplimit_users_emails_account_names_customers_account_found
        .select('account_id', 'account_name', "email_domain_final", 'email_domain', 'alternate_email_domain')
        .filter(~F.col("email_domain_final").isin(blacklist))
        .groupBy(['account_id', "account_name", "email_domain_final"])
        .agg(F.count(F.col('email_domain')).alias('total_emails'))
        .withColumn("tiebreak", F.monotonically_increasing_id())
        .withColumn("rank", F.rank().over(domain_window_customer_mapping))
        .filter(F.col("rank") == 1)
        .drop("total_emails", "tiebreak", "rank")
    )

    uplimit_users_emails_account_names_customers_no_account_no_bu = (
        uplimit_users_emails_account_names_customers
        .filter(F.col("account_name") == "Unknown")
        .union(uplimit_users_emails_account_names_customers_account_found_no_bu)
    )

    uplimit_users_emails_account_names_customers_account_not_found = (
        uplimit_users_emails_account_names_customers_no_account_no_bu
        .drop('account_id')
        .withColumnRenamed('account_name', 'account_name_pre_2')
        .join(customer_account_mapping, 'email_domain_final', 'left')
        .withColumn('account_name', F.coalesce(F.col("account_name"), F.col("account_name_pre_2")))
        .select(
            'account_id', 'email', 'id',  'email_domain', 'email_hash',
            'branch_name', 'learner_branch', 'alternate_email_domain', 'alternate_email_hash',
            'branch_code', 'alternate_email',
            'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
            'account_name', 'audience'
        )
    )

    # --- PAGE 11 & 12: Remapping customers based on domain frequency (more than 5 domains) ---
    mapping_window_more_than_5 = W.partitionBy("email_domain").orderBy(F.desc("total_emails"), "tiebreak")

    mapping_more_than_5_domains = (
        salesforce_account_email_domain_mapping
        .filter(F.col("email_domain").isNotNull())
        .filter(~F.col("email_domain").isin(blacklist))
        .filter(F.col("total_for_email_and_account") >= 5)
        .groupBy(["email_domain", "account_id", "account_name"])
        .agg(F.sum("total_for_email_and_account").alias("total_emails"))
        .withColumn("tiebreak", F.monotonically_increasing_id())
        .withColumn("rank", F.rank().over(mapping_window_more_than_5))
        .filter(F.col("rank") == 1)
        .drop("total_emails", "tiebreak", "rank")
        .select(F.col("email_domain").alias("email_domain_final"), F.col("account_id"), F.col("account_name"))
    )

    uplimit_users_emails_account_names_customers_account_found_1 = (
        uplimit_users_emails_account_names_customers_account_not_found
        .filter(F.col("account_name") != "Unknown")
    )

    uplimit_users_emails_account_names_customers_remap_1 = (
        uplimit_users_emails_account_names_customers_account_not_found
        .filter(F.col("account_name") == "Unknown")
        .drop('account_id')
        .withColumnRenamed('account_name', 'account_name_pre_2')
        .join(mapping_more_than_5_domains, 'email_domain_final', 'left')
        .withColumn('account_name', F.coalesce(F.col("account_name"), F.col("account_name_pre_2")))
        .select(
            'account_id', 'email', 'id',  'email_domain', 'email_hash',
            'branch_name', 'learner_branch', 'alternate_email_domain', 'alternate_email_hash',
            'branch_code', 'alternate_email',
            'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
            'account_name', 'audience'
        )
    )

    # --- PAGE 13 & 14: Remapping customers based on most common domains ---
    uplimit_users_emails_account_names_customers_account_found_2 = (
        uplimit_users_emails_account_names_customers_remap_1
        .filter(F.col("account_name") != "Unknown")
    )

    mapping_most_common_domains = (
        salesforce_account_email_domain_mapping
        .filter(F.col("email_domain").isNotNull())
        .filter(~F.col("email_domain").isin(blacklist))
        .groupBy(["email_domain", "account_id", "account_name"])
        .agg(F.sum("total_for_email_and_account").alias("total_emails"))
        .withColumn("tiebreak", F.monotonically_increasing_id())
        .withColumn("rank", F.rank().over(mapping_window_more_than_5)) # Reusing the window definition
        .filter(F.col("rank") == 1)
        .drop("total_emails", "tiebreak", "rank")
        .select(F.col("email_domain").alias("email_domain_final"), F.col("account_id"), F.col("account_name"))
    )

    uplimit_users_emails_account_names_customers_remap_2 = (
        uplimit_users_emails_account_names_customers_remap_1
        .filter(F.col("account_name") == "Unknown")
        .drop('account_id')
        .withColumnRenamed('account_name', 'account_name_pre_2')
        .join(mapping_most_common_domains, 'email_domain_final', 'left')
        .withColumn('account_name', F.coalesce(F.col("account_name"), F.col("account_name_pre_2")))
        .select(
            'account_id', 'email', 'id',  'email_domain', 'email_hash',
            'branch_name', 'learner_branch', 'alternate_email_domain', 'alternate_email_hash',
            'branch_code', 'alternate_email',
            'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
            'account_name', 'audience'
        )
    )

    # --- PAGE 15 & 16: Unioning all customer account mappings and joining ultimate parents ---
    uplimit_users_emails_account_names_customers_accounts = (
        uplimit_users_emails_account_names_customers_account_found_bu.withColumn('match_method', F.lit('direct_salesforce_contact_match'))
        .union(uplimit_users_emails_account_names_customers_account_found_1.withColumn('match_method', F.lit('matched_contacts_domain_account_mapping')))
        .union(uplimit_users_emails_account_names_customers_account_found_2.withColumn('match_method', F.lit('more_than_5_domains_on_account')))
        .union(uplimit_users_emails_account_names_customers_remap_2.withColumn('match_method', F.lit('most_common_domain_on_account')))
    )

    account_ultimate_parents_customers = ( # Renamed to avoid conflict
        sfdc_accounts
        .select(
            F.col("Id").alias('account_id'),
            F.col("Ultimate_Parent_Account__c").alias('ultimate_parent_account_name_pre'),
            F.col("Ultimate_parent_account_casesafe_ID__c").alias("ultimate_parent_account_id_pre")
        )
    )

    uplimit_users_emails_customers = (
        uplimit_users_emails_account_names_customers_accounts
        .join(account_ultimate_parents_customers, "account_id", "left")
        .withColumn('ultimate_parent_account_name',
                    F.when(F.col("account_name") != "Unknown", F.col("ultimate_parent_account_name_pre")).otherwise(F.lit("Unknown")))
        .withColumn('ultimate_parent_account_id',
                    F.when(F.col("account_name") != "Unknown", F.col("ultimate_parent_account_id_pre")).otherwise(F.lit("Unknown")))
        .select(
            'email_domain_final', 'id',  'email_domain', 'email_hash',
            'branch_name', 'alternate_email_domain', 'alternate_email_hash', 'branch_code', 'email','alternate_email', 'learner_branch',
            'account_id', 'account_name', 'ultimate_parent_account_id', 'ultimate_parent_account_name',
            'audience', 'match_method'
        )
    )

    # --- PAGE 17 & 18: Partner data processing ---
    # Reusing account_ultimate_parents logic for partners, but keeping it distinct in variable name
    account_ultimate_parents_partners = (
        sfdc_accounts
        .select(
            F.col("Id").alias('account_id'),
            F.col("Ultimate_Parent_Account__c").alias('ultimate_parent_account_name_pre'),
            F.col("Ultimate_parent_account_casesafe_ID__c").alias("ultimate_parent_account_id_pre")
        )
    )

    uplimit_users_emails_partner = (
        uplimit_users_emails_partners_users
        .join(partner_domains_df.withColumnRenamed('email_domain', 'email_domain_final'), "email_domain_final", "left")
        .withColumnRenamed('ultimate_parent_account_id', 'ultimate_parent_account_id_pre')
        .withColumnRenamed('ultimate_parent_account_name', 'ultimate_parent_account_name_pre')
        .withColumn('ultimate_parent_account_id', F.coalesce(F.col("ultimate_parent_account_id_pre"), F.lit("Unknown")))
        .withColumn('ultimate_parent_account_name', F.coalesce(F.col("ultimate_parent_account_name_pre"), F.lit("Unknown")))
        .withColumn('account_id', F.col("ultimate_parent_account_id"))
        .withColumn('account_name', F.col("ultimate_parent_account_name"))
        .withColumn('match_method', F.lit('partner_ops_report'))
        .select(
            'email_domain_final', 'id',  'email_domain', 'email_hash',
            'branch_name', 'alternate_email_domain', 'alternate_email_hash', 'branch_code', 'email', 'alternate_email', 'learner_branch',
            'account_id', 'account_name', 'ultimate_parent_account_id', 'ultimate_parent_account_name',
            'audience', 'match_method'
        )
    )

    # --- PAGE 19 & 20: Unique mappings for Databricks and Microsoft ---
    account_window_unique_mapping = W.partitionBy("account_name").orderBy(F.desc("total_for_email_and_account"), "tiebreak")
    domain_window_unique_mapping = W.partitionBy("email_domain").orderBy(F.desc("total_emails"), "tiebreak")

    accounts_df_unique = (
        sfdc_accounts
        .select(
            F.col("Id").alias("ultimate_parent_account_id"),
            F.col("Name").alias("ultimate_parent_account_name")
        )
    )

    account_names_unique = (
        sfdc_accounts
        .select(
            F.col("Id").alias("account_id"),
            F.col("Name").alias("account_name"),
            F.col("ParentId").alias("ultimate_parent_account_id")
        )
        .join(accounts_df_unique, "ultimate_parent_account_id", "left")
    )

    mapping_2_databricks = (
        salesforce_account_email_domain_mapping
        .filter(F.col("account_id") == databricks_account_id)
        .filter(F.col("email_domain") == "databricks.com")
        .orderBy(F.col("account_last_modified_timestamp").desc())
        .limit(1)
        .select("email_domain", "account_id")
        .join(account_names_unique, "account_id", "left")
        .withColumnRenamed('ultimate_parent_account_id', 'ultimate_parent_account_id_pre')
        .withColumnRenamed('ultimate_parent_account_name', 'ultimate_parent_account_name_pre')
        .withColumn('ultimate_parent_account_id', F.col('account_id'))
        .withColumn('ultimate_parent_account_name', F.col('account_name'))
        .select(
            F.col("email_domain").alias("email_domain_final"),
            F.col("account_id"),
            F.col("account_name"),
            F.col("ultimate_parent_account_id"),
            F.col("ultimate_parent_account_name"),
        )
    )

    mapping_2_microsoft = (
        salesforce_account_email_domain_mapping
        .filter(F.col("account_id") == microsoft_account_id)
        .filter(F.col("email_domain") == "microsoft.com")
        .orderBy(F.col("account_last_modified_timestamp").desc())
        .limit(1)
        .select("email_domain", "account_id")
        .join(account_names_unique, "account_id", "left")
        .select(
            F.col("email_domain").alias("email_domain_final"),
            F.col("account_id"),
            F.col("account_name"),
            F.col("ultimate_parent_account_id"),
            F.col("ultimate_parent_account_name"),
        )
    )

    # --- PAGE 21 & 22: Databricks data processing ---
    uplimit_users_emails_databricks = (
        uplimit_users_emails_databricks_users
        .join(mapping_2_databricks, "email_domain_final", "left")
        .withColumn('match_method', F.lit('hard_code_databricks'))
        .select(
            'email_domain_final', 'id',  'email_domain', 'email_hash',
            'branch_name', 'alternate_email_domain', 'alternate_email_hash', 'branch_code', 'email', 'alternate_email', 'learner_branch',
            'account_id', 'account_name', 'ultimate_parent_account_id', 'ultimate_parent_account_name',
            'audience', 'match_method'
        )
    )

    # --- PAGE 22 & 23: Microsoft data processing ---
    uplimit_users_emails_microsoft = (
        uplimit_users_emails_microsoft_users
        .join(mapping_2_microsoft, "email_domain_final", "left")
        .withColumn('match_method', F.lit('hard_code_microsoft'))
        .select(
            'email_domain_final', 'id',  'email_domain', 'email_hash',
            'branch_name', 'alternate_email_domain', 'alternate_email_hash', 'branch_code', 'email','alternate_email', 'learner_branch',
            'account_id', 'account_name', 'ultimate_parent_account_id', 'ultimate_parent_account_name',
            'audience', 'match_method'
        )
    )

    # --- PAGE 23 & 24: Cleaning customer data ---
    uplimit_users_emails_customers_clean = (
        uplimit_users_emails_customers
        .withColumnRenamed("account_id", "account_id_pre")
        .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
        .withColumnRenamed("account_name", "account_name_pre")
        .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
        .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
        .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
        .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
        .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
        .withColumnRenamed("audience", "audience_pre")
        .withColumn("audience",
                    F.when(F.col("account_name") == "Unknown", F.lit("Customer Other"))
                    .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Customer Other"), F.lit("Customer"))
                    .otherwise(F.col("audience_pre")))
        .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
    )

    # --- PAGE 24: Cleaning partner data ---
    uplimit_users_emails_partner_clean = (
        uplimit_users_emails_partner
        .withColumnRenamed("account_id", "account_id_pre")
        .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
        .withColumnRenamed("account_name", "account_name_pre")
        .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
        .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
        .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
        .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
        .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
        .withColumnRenamed("audience", "audience_pre")
        .withColumn("audience",
                    F.when(F.col("account_name") == "Unknown", F.lit("Partner Other"))
                    .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Partner Other"), F.lit("Partner"))
                    .otherwise(F.col("audience_pre")))
        .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
    )

    # --- PAGE 25: Cleaning Databricks data ---
    uplimit_users_emails_databricks_clean = (
        uplimit_users_emails_databricks
        .withColumnRenamed("account_id", "account_id_pre")
        .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
        .withColumnRenamed("account_name", "account_name_pre")
        .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
        .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
        .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
        .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
        .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
        .withColumnRenamed("audience", "audience_pre")
        .withColumn("audience",
                    F.when(F.col("account_name") == "Unknown", F.lit("Employee Other"))
                    .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Employee Other"), F.lit("Employee"))
                    .otherwise(F.col("audience_pre")))
        .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
    )

    # --- PAGE 25 & 26: Cleaning Microsoft data ---
    uplimit_users_emails_microsoft_clean = (
        uplimit_users_emails_microsoft
        .withColumnRenamed("account_id", "account_id_pre")
        .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit(microsoft_account_id)).otherwise(F.col("account_id_pre")))
        .withColumnRenamed("account_name", "account_name_pre")
        .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit(microsoft_account_name)).otherwise(F.col("account_name_pre")))
        .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
        .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit(microsoft_parent_account_id)).otherwise(F.col("ultimate_parent_account_id_pre")))
        .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
        .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit(microsoft_parent_account_name)).otherwise(F.col("ultimate_parent_account_name_pre")))
        .withColumnRenamed("audience", "audience_pre")
        .withColumn("audience",
                    F.when(F.col("account_name") == "Unknown", F.lit("Microsoft Other"))
                    .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Microsoft Other"), F.lit("Microsoft"))
                    .otherwise(F.col("audience_pre")))
        .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
    )

    # --- PAGE 26: Final Union of all cleaned user accounts ---
    uplimit_users_accounts_clean = (
        uplimit_users_emails_customers_clean
        .union(uplimit_users_emails_partner_clean)
        .union(uplimit_users_emails_databricks_clean)
        .union(uplimit_users_emails_microsoft_clean)
    )

    return uplimit_users_accounts_clean


# COMMAND ----------

temp_df = process_uplimit_user_accounts(
    source_df,
    sfdc_contacts,
    sfdc_leads,
    sfdc_accounts,
    partner_domains_df,
    salesforce_account_email_domain_mapping,
    accounts_curated,
    partner_domains,
    blacklist,
    databricks_account_id,
    microsoft_account_id,
    microsoft_account_name,
    microsoft_parent_account_id,
    microsoft_parent_account_name,
    partner_accounts
)

temp_df.createOrReplaceTempView("temp_data")


# COMMAND ----------

uplimit_users_accounts = spark.sql("""
    SELECT
      uu.*,
      t.learner_branch, 
      t.account_id,
      t.account_name,
      t.ultimate_parent_account_id,
      t.ultimate_parent_account_name,
      t.audience,
      t.match_method
    from uplimit_users_emails_temp uu 
    LEFT JOIN temp_data t ON uu.email = t.email
 """)


# COMMAND ----------

uplimit_users_gold = (
    uplimit_users_accounts
    .select(
        F.col("email_hash").alias("email_hash"),
        F.col("branch_code").alias("branch_code"),
        F.col("UserId").alias("user_id"),
        F.col("FirstName").alias("first_name"),
        F.col("LastName").alias("last_name"),
        F.col("Email").alias("email"),
        F.col("Company").alias("company"),
        F.col("AccountActivated").alias("account_activated"),
        F.col("NumEnrollments").alias("num_enrollments"),
        F.col("FirstLoginCompleted").alias("first_login_completed"),
        F.col("Country").alias("country"),
        F.col("CountryCode").alias("country_code"),
        F.col("ActiveSubscriptionCommitmentIds").alias("active_subscription_commitment_ids"),
        F.col("email_domain").alias("email_domain"),
        F.col("alternate_email_domain").alias("alternate_email_domain"),
        F.col("branch_name").alias("branch_name"),
        F.col("learner_branch").alias("learner_branch"),
        F.col("account_id").alias("account_id"),
        F.col("account_name").alias("account_name"),
        F.col("audience").alias("audience"),
        F.col("ultimate_parent_account_id").alias("ultimate_parent_account_id"),
        F.col("ultimate_parent_account_name").alias("ultimate_parent_account_name"),
        F.col("match_method"),
        F.col("FirstLoginTimestamp").alias("first_login_timestamp")
    )
)


# COMMAND ----------

uplimit_users_gold_cleaned_accounts_partition = add_gold_metadata(uplimit_users_gold)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = uplimit_users_gold_cleaned_accounts_partition, 
  table_name = f'{focus_database_name}.uplimit_users', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

# %sql
# -- Combine users from both tables, ensuring all users are included
# select 
#     d.id, 
#     d.uuid, 
#     coalesce(d.email, u.Email) AS email,  
#     coalesce(d.first_name, u.FirstName) AS first_name,
#     coalesce(d.last_name, u.LastName) AS last_name,
#     coalesce(d.email_hash, null) AS email_hash,
#     coalesce(d.email_domain, null) AS email_domain,
#     coalesce(d.alternate_email, null) AS alternate_email,
#     coalesce(d.alternate_email_hash, null) AS alternate_email_hash,
#     coalesce(d.alternate_email_domain, null) AS alternate_email_domain,
#     coalesce(d.username, null) AS username,
#     coalesce(d.username_hash, null) AS username_hash,
#     coalesce(d.email_verified, null) AS email_verified,
#     coalesce(d.valid, null) AS valid,
#     coalesce(d.created_timestamp, null) AS created_timestamp, 
#     coalesce(d.last_updated_timestamp, null) AS last_updated_timestamp,
#     coalesce(d.suspended_timestamp, null) AS suspended_timestamp,
#     coalesce(d.last_login, null) AS last_login,
#     coalesce(d.branch_code, null) AS branch_code,
#     coalesce(d.branch_name, null) AS branch_name,
#     coalesce(d.level, null) AS level,
#     coalesce(d.timezone, null) AS timezone,
#     coalesce(d.account_id, null) AS account_id,
#     coalesce(d.account_name, null) AS account_name,
#     coalesce(d.ultimate_parent_account_id, null) AS ultimate_parent_account_id,
#     coalesce(d.ultimate_parent_account_name, null) AS ultimate_parent_account_name,
#     coalesce(d.country_code, null) AS country_code,
#     coalesce(d.country_name, null) AS country_name,
#     coalesce(d.region, null) AS region,
#     coalesce(d.processDate, null) AS processDate,
#     coalesce(d.audience, null) AS audience,
#     coalesce(d.updated_account_id, null) AS updated_account_id,
#     coalesce(d.updated_ultimate_parent_account_id, null) AS updated_ultimate_parent_account_id,
#     coalesce(d.updated_ultimate_parent_account_name, null) AS updated_ultimate_parent_account_name,
#     coalesce(d.match_method, null) AS match_method,
#     coalesce(d.sfdc_contact_id, null) AS sfdc_contact_id,
#     coalesce(d.sfdc_contact_type, null) AS sfdc_contact_type,
#     coalesce(d.sfdc_lead_or_contact_id, null) AS sfdc_lead_or_contact_id,
#     coalesce(d.sfdc_and_updated_account_match, null) AS sfdc_and_updated_account_match,
#     coalesce(d.country_webassessor, null) AS country_webassessor,
#     d.sfdc_contact_id, 
#     d.sfdc_contact_type, 
#     d.sfdc_lead_or_contact_id, 
#     d.sfdc_and_updated_account_match, 
#     d.country_webassessor, 
#     d.region_webassessor, 
#     d.country_derived, 
#     d.region_derived, 
#     d.greenfield_account, 
#     d.business_unit, 
#     d.sales_subregion_level_1, 
#     d.sales_subregion_level_2, 
#     d.sales_subregion_level_3, 
#     d.fq2, 

#     coalesce(d.updated_account_name, u.Company) AS updated_account_name,  

#     coalesce(u.AccountActivated, null) AS account_activated,  
#     coalesce(u.NumEnrollments, null) AS num_enrollments,  
#     coalesce(u.FirstLoginCompleted, null) AS first_login_completed,  
#     coalesce(u.Country, d.country_name) AS country, 
#     coalesce(u.CountryCode, d.country_code) AS country_code, 
#     coalesce(u.ActiveSubscriptionCommitmentIds, null) AS active_subscription_commitments,  

#     -- Flags to indicate user source:
#     -- If UserId from uplimit_users_bronze is not null, it's a Uplimit user
#     case when u.Email is not null then 'true' else 'false' end AS is_uplimit_user,
#     -- If id from docebo_users is not null, it's a Docebo user
#     case when d.email is not null then 'true' else 'false' end AS is_docebo_user

# from 
#     main.field_learning_enablement.uplimit_users_bronze u
# full outer join 
#     main.field_learning_enablement.docebo_users d
# on 
#     u.Email = d.email  -- Join on the common field 'email'
# where 
#     -- Only select the most recent processDate from each table
#     u.processDate = (select max(processDate) from main.field_learning_enablement.uplimit_users_bronze)
#     and d.processDate = (select max(processDate) from main.field_learning_enablement.docebo_users)
