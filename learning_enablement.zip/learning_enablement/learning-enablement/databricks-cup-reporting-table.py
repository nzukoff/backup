# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for databricks cup data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Users/liam.clifford@databricks.com/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

# spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
# from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import json
import requests
from urllib.parse import quote_plus as urlencode
import pandas as pd

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
    print(partition_date)
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# DBTITLE 1,Reading the List of SA IC's
# Reading the List of SA IC's for Databricks Cup
try:
  sht = authGoogleSheet("List of SA IC's for Databricks Cup")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')

  
try:
  worksheet = sht.worksheet("First Line")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "List of SA IC's for Databricks Cup",
 "First Line",
 "first_line_managers_list",
 clean_column_names="true", 
 make_columns_unique="true"
)

readGoogleSheet(
 "List of SA IC's for Databricks Cup",
 "IC's",
 "first_line_managers_emails",
 clean_column_names="true", 
 make_columns_unique="true"
)

readGoogleSheet(
  "List of SA IC's for Databricks Cup",
  "Second Line",
  "second_line_managers_list",
  clean_column_names="true",
  make_columns_unique="true"
)

first_line_managers_list_df = (spark.sql("""select * from first_line_managers_list"""))
first_line_managers_emails = (spark.sql("""select * from first_line_managers_emails"""))
second_line_managers_list_df = (spark.sql("""select * from second_line_managers_list"""))
# display(first_line_managers_list_df)
# display(first_line_managers_emails)
display(second_line_managers_list_df)

# invite_list_df = invite_list_raw.select(F.col('brickster_email').alias('primaryWorkEmail'))

# COMMAND ----------

# DBTITLE 1,Reading the List of First Line Responses
# Reading the FY25 Databricks Cup First Line FE Submission Form (Responses)
try:
  sht = authGoogleSheet("FY25 Databricks Cup First Line FE Submission Form (Responses)")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')

  
try:
  worksheet = sht.worksheet("Form Responses 1")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "FY25 Databricks Cup First Line FE Submission Form (Responses)",
 "Form Responses 1",
 "db_cup_first_line_responses",
 clean_column_names="true", 
 make_columns_unique="true"
)

db_cup_first_line_responses_df = (spark.sql("""select * from db_cup_first_line_responses"""))
print('completed')
display(db_cup_first_line_responses_df)

# COMMAND ----------

# DBTITLE 1,Reading the List of Second Line Responses
# # Reading the Finalist FY25 Databricks Cup Second Line+ FE Submission Form (Responses)
# try:
#   sht = authGoogleSheet("Copy of Finalist FY25 Databricks Cup Second Line+ FE Submission Form (Responses)")
# except:
#   print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')

  
# try:
#   worksheet = sht.worksheet("Form Responses 2")
# except Exception as e: 
#   print('%s' % 'Worksheet Not Found: ')


# readGoogleSheet(
#  "Copy of Finalist FY25 Databricks Cup Second Line+ FE Submission Form (Responses)",
#  "Form Responses 2",
#  "db_cup_second_line_responses",
#  clean_column_names="true", 
#  make_columns_unique="true"
# )

# db_cup_second_line_responses_df = (spark.sql("""select * from db_cup_second_line_responses"""))
# display(db_cup_second_line_responses_df)

# COMMAND ----------

# DBTITLE 1,Manager Data Extraction Script
# Get all the Manager's data from the sheets and workday table
first_line_data = spark.sql('''
      select distinct
      trim(l.management_chain_level_08) as manager_name,
      trim(lower(e.email_primary_work)) as email_primary_work,
      trim(e.management_chain_level_07) as Manager_level_7,
      case when r.email_address is null then 0 else 1 end as response_submitted_flag,
      r.timestamp,
      (TO_TIMESTAMP(r.timestamp, 'M/d/yyyy H:mm:ss')::timestamp) as converted_timestamp,
      --  converted_timestamp::date as new_coverted_timestamp,
      r.email_address,
      r.has_everyone_on_your_team_completed_their_assigned_technical_demo_or_pitch as team_assignment_completion,
      nvl(r.are_you_submitting_a_recording_of_a_technical_pitch_and_or_a_demo, 'Not Submitted') as submission_type, 
      nvl(r.name_of_technical_pitch_finalist, '') as tech_pitch_finalists,
      nvl(r.name_of_technical_demo_finalist, '') as tech_demo_finalists,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      w.Hire_Date,
    --  Last_Promotion_Date,
    --  Termination_Date,
    --  Job_Profile_Prior_To_Last_Promotion_Date,
    --  Business_Title_Prior_To_Last_Promotion_Date,
    --  Cost_Center,
      w.Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
    --  Manager_Level_01,
    --  Manager_Level_02,
    --  Manager_Level_03,
      Manager,
      Manager_Email,
    --  Supervisory_Organization,
    --  Supervisory_Organization_cleaned,
    --  Time_Zone,
    --  Time_Zone_GMT_Factor,
    --  Original_Hire_Date,
    --  Job_Profile_Start_Date,
    --  Last_Job_Req_Event_Date,
      wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      category,
      department,
    --  6th_level_manager,
    --  5th_level_manager,
    --  4th_level_manager,
    --  3rd_level_manager,
    --  2nd_level_manager,
    --  1st_level_manager,
    --  init_level_manager,
    --  6th_level_manager_name,
    --  5th_level_manager_name,
    --  4th_level_manager_name,
    --  3rd_level_manager_name,
    --  2nd_level_manager_name,
    --  1st_level_manager_name,
    --  init_level_manager_name,
      status as workday_status
      from first_line_managers_list l
      left join first_line_managers_emails e on l.management_chain_level_08 = e.management_chain_level_08
      left join main.field_learning_enablement.workday w on lower(w.primaryWorkEmail) = lower(e.email_primary_work)
      left join db_cup_first_line_responses r on lower(r.email_address) = lower(w.primaryWorkEmail)
      where l.management_chain_level_08 <> ''
      and w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
          ''')
display(first_line_data)

# COMMAND ----------

# Add the data from the first line response sheet to check if s/he has completed the first line or not

# COMMAND ----------

# DBTITLE 1,Manager Email Retrieval Query
# second_line_data = spark.sql('''
# with second_line_emails as (
#   select l.management_chain_level_07 as name,
#   case when l.management_chain_level_07 = 'Panos Athanasiou' then 'panos.athanasiou@databricks.com'
#   else trim(lower(w.primaryWorkEmail)) end as email
#   from second_line_managers_list l
#   left join main.field_learning_enablement.workday w on l.management_chain_level_07 = w.Name
#   and w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
# )

# select 
# e.name,
# e.email,
# trim(l.management_chain_level_06) as Manager_level_6,
# case when r.email_address is null then 0 else 1 end as response_submitted_flag,
# r.timestamp,
# (TO_TIMESTAMP(r.timestamp, 'M/d/yyyy H:mm:ss')::timestamp) as converted_timestamp,
# r.email_address,
# r.name_of_technical_pitch_finalist,
# r.name_of_technical_demo_finalist,
# w.Hire_Date,
# w.Location,
# Location_Address_Country,
# Job_Profile,
# businessTitle,
# Manager,
# Manager_Email,
# wd_id,
# manager_hierarchy_path,
# manager_hierarchy_path_name,
# category,
# department,
# status as workday_status
# from second_line_emails e
# left join second_line_managers_list l on e.name = l.management_chain_level_07
# left join main.field_learning_enablement.workday w on e.email = w.primaryWorkEmail
# and w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
# left join db_cup_second_line_responses r on w.primaryWorkEmail = r.email_address
# ''')
# display(second_line_data)


# COMMAND ----------

# DBTITLE 1,Enhanced First Line Data Display
db_cup_first_line_data_gold = add_gold_metadata(first_line_data)
display(db_cup_first_line_data_gold)

# COMMAND ----------

# db_cup_second_line_data_gold = add_gold_metadata(second_line_data)
# display(db_cup_second_line_data_gold)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = db_cup_first_line_data_gold, 
  table_name = f'{focus_database_name}.db_cup_responses_data', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

# DBTITLE 1,Current Process Date Query
# MAGIC %sql
# MAGIC select processDate, * from main.field_learning_enablement.db_cup_responses_data
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.db_cup_responses_data)

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = db_cup_second_line_data_gold, 
#   table_name = f'{focus_database_name}.db_cup_second_line_responses_data', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'"
# )

# COMMAND ----------

# MAGIC %sql
# MAGIC select processDate, * from main.field_learning_enablement.db_cup_second_line_responses_data
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.db_cup_second_line_responses_data)