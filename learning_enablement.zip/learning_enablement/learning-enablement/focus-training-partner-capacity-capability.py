# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# from pprint import pprint
# from pyspark.sql import DataFrame, Column
# from typing import Optional, Sequence as Seq, Dict, Callable, Any

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# verbose = get_verbose_func(VERBOSE)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

dates_raw = (
  spark.read.table("main.it_core_dim.bi_dates")
     .withColumn("fiscal_quarter_year", F.concat(F.lit("FY"), F.col('fiscalYear'), F.lit("Q"), F.col('fiscalQuarter')))
)

# Docebo Logfood data
gold_docebo_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.self_paced_enrollments",  "processDate")


self_paced_enrollments = (
  spark.read.table(f"{focus_database_name}.self_paced_enrollments")
    .filter(F.col("processDate") == gold_docebo_latest_process_date)
    .filter(F.col("learner_branch_code").isin(["DBK_MCSFT", "DBK_PRTNR"]))
    .withColumn("date", F.to_date(F.col("completed_timestamp")))
    .join(dates_raw, "date", "left")
    .drop("processDate")
)

ilt_enrollments = (
  spark.read.table(f"{focus_database_name}.ilt_enrollments")
    .filter(F.col("processDate") == gold_docebo_latest_process_date)
    .filter(F.col("learner_branch_code").isin(["DBK_MCSFT", "DBK_PRTNR"]))
    .withColumn("date", F.to_date(F.col("completed_timestamp")))
    .join(dates_raw, "date", "left")
    .drop("processDate")
)

accredible_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.accredible_credentials",  "processDate")


partner_badges = (
  spark.table(f"{focus_database_name}.accredible_credentials")
    .filter(F.col("processDate") == accredible_latest_process_date)
    .filter(F.col("learner_branch_code").isin(["DBK_PRTNR", "DBK_MCSFT"]))
    .withColumnRenamed("issued_on", "date")
    .join(dates_raw, "date", "left")
    .withColumn("fiscal_quarter_year", F.concat(F.lit("FY"), F.col("fiscalYear"), F.lit("Q"), F.col("fiscalQuarter")))
)

#sfdc data

sfdc_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.account",  "processDate")


sfdc_users = (
  spark
    .table(f"main.sfdc_bronze.user")
    .filter(F.col("processDate") == sfdc_latest_process_date)
    .select(F.col("Id").alias("partner_manager_id"), F.col("Name").alias("partner_manager"))
)

sfdc_account = (
  spark
    .table(f"main.sfdc_bronze.account")
    .filter(F.col("processDate") == sfdc_latest_process_date)
    .select(
      F.col("Id").alias("ultimate_parent_account_id"), 
      F.col("Partner_Manager__c").alias("partner_manager_id"), 
      F.col("BillingCountry").alias("billing_country"), 
      F.col("Partner_Level__c").alias("partner_level"),
      F.col("Partner_Tier__c").alias("partner_tier")
      
    )
    .join(sfdc_users, "partner_manager_id", "left")
    .select("ultimate_parent_account_id", "partner_manager", "billing_country", "partner_level", "partner_tier")
)

#Sales Data

# sales_legacy_raw = spark.table("scott_smith_databricks_com_db.sales_training_raw")
sales_legacy_raw = spark.table("users.nathan_zukoff.sales_training_raw")

silver_docebo_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_salesforce_account_email_domain_mapping",  "processDate")


salesforce_account_email_domain_mapping = (
  spark.read.table("main.it_training_silver.docebo_salesforce_account_email_domain_mapping")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

sfdc_accounts = (
  spark.read.table("main.sfdc_bronze.account")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

# COMMAND ----------

mapping_window = W.Window.partitionBy("email_domain").orderBy(F.desc("total_for_email_and_account"), "tiebreak")

accounts_df = (
  sfdc_accounts
    .select(
      F.col("Id").alias("ultimate_parent_account_id"),
      F.col("Name").alias("ultimate_parent_account_name")
    )
)

account_names = (
  sfdc_accounts
    .select(
      F.col("Id").alias("account_id"),
      F.col("ParentId").alias("ultimate_parent_account_id")
    )
    .join(accounts_df, "ultimate_parent_account_id", "left")
)

unique_partner_mappings = (
    salesforce_account_email_domain_mapping
    # filter for partner domains
    .filter(F.col("account_record_type") == "Partner")
    # keep only domains that appear more than 5 times
    .filter(F.col("total_for_email_and_account") >= 5)
    # filter out null domains
    .filter(F.col("email_domain").isNotNull())
    # find most common account for each domain
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(mapping_window))
    .filter(F.col("rank") == 1)
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

# COMMAND ----------

#unit tests to make sure dfs are pulled correctly
assert unit_test_df_count(sfdc_account) > 0

# unit tests to make sure parameters are set up correctly
catalog, database = focus_database_name.split('.')
assert unit_test_valid_db(database, spark, catalog)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

partner_technical_ilt = ["Azure Databricks Core Technical Training",
"Azure Databricks Core Technical Virtual Training",
"AWS Databricks Core Technical Virtual Training",
"Azure Databricks Advanced Technical Virtual Training",
"AWS Databricks Core Technical Training",
"Scalable Machine Learning with Apache Spark™ Virtual Training",
"Deloitte - Custom DB 105 | DB 110",
"Databricks Partners: Training Cohorts",
"Databricks Partners: Core Technical Series",
"Azure Databricks Advanced Technical + Hadoop Migration Virtual Training", 
"Core Technical Series",
"Core Technical Series (Private Training)",
"Scalable Machine Learning with Apache Spark™ (Partner) (RETIRED)",
"Scalable Machine Learning with Apache Spark™ (Private Partner)",
"Azure Databricks Advanced Technical and Hadoop Migration Training",
"Core Technical Series: Advanced Data Engineering with Databricks (Partner)",
"Azure Databricks Advanced Technical and Hadoop Migration Training (Private Training)",
"Machine Learning in Production (Private ILT)",
"Optimizing Apache Spark™ on Databricks (Private ILT)",
"Scalable Machine Learning with Apache Spark™ (ILT)",
"Data Engineering with Databricks (Private ILT)",
"Apache Spark™ Programming with Databricks (ILT)",
"Data Engineering with Databricks (ILT)",
"Deep Learning with Databricks (Partner)",
"Data Engineering with Databricks (Private Partner)",
"Advanced Data Engineering with Databricks (Private Partner)",
"Machine Learning in Production (ILT)",
"Data Engineering with Databricks (Private ILT) (RETIRED)",
"Data Engineering with Databricks (ILT) (RETIRED)", 
"Core Technical Series: Data Engineering with Databricks (Partner)",
"Core Technical Series: Data Engineering with Databricks (Private Partner)",
"Scalable Machine Learning with Apache Spark™ (Private ILT)",
"Advanced Data Engineering with Databricks (Partner)",
"Optimizing Apache Spark™ on Databricks (ILT)",
"Data Engineering with Databricks (Partner)",
"Deep Learning with Databricks (Private ILT)",
"Apache Spark™ Programming with Databricks (Private ILT)",
"ELEVATE Training Series: Databricks for Data Analysts",
"ELEVATE Training Series: Databricks for Data Engineers",
"ELEVATE Training Series: Databricks for Machine Learning Practitioners"
]

technical_self_paced_list = [
  {'course_name': 'Apache Spark Programming with Databricks',                     'course_code': 'aC13f000000004rCAA'},
  {'course_name': 'Apache Spark™ Programming with Databricks',                    'course_code': 'ACAD-ALL-SLP-v3-FREE-ASPWD-ACT'},
  {'course_name': 'Data Engineering with Databricks',                             'course_code': 'aC13f000000005uCAA'},
  {'course_name': 'Scalable Machine Learning with Apache Spark',                  'course_code': 'aC13f00000000A6CAI'},
  {'course_name': 'Data Science on Databricks Rapidstart',                        'course_code': 'aC13f000000003ECAQ'},
  {'course_name': 'Data Science on Databricks: The Bias-Variance Tradeoff',       'course_code': 'aC13f0000000052CAA'},
  {'course_name': 'Deploying a Machine Learning Project with MLflow Projects',    'course_code': 'aC13f0000000051CAA'},
  {'course_name': 'Tracking Experiments with MLflow',                             'course_code': 'ACAD-ALL-SLP-v1-FREE-TEXPMLF-ACT'},
]

technical_self_paced = [course['course_name'] for course in technical_self_paced_list]

technical_sales_ilt_list = [
  {'course_name': 'Modernizing Financial Risk Management with Databricks - Virtual Training',     'course_code': 'aC13f0000000039CAA'},
  {'course_name': 'Generating Reliable Inventory Forecasts with Databricks - Virtual Training',   'course_code': 'aC13f0000000034CAA'},
  {'course_name': 'Partner Solutions Architect Essentials - Virtual Training',                    'course_code': 'aC13f000000003OCAQ'},
  {'course_name': 'Partner Solutions Architect Essentials (Partner)',                             'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-PSAE'},
  {'course_name': 'Partner Solutions Architect Essentials (Private Partner)',                     'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-PSAE-ACT'},
  {'course_name': 'Partner Solutions Architect Essentials (Partner) (RETIRED)',                   'course_code': 'ACAD-PART-ILT-v1-FREE-PSAE-RET'},
  {'course_name': 'Hadoop Migration Architecture V2',                                             'course_code': 'ACAD-PART-SLP-v2-FREE-HADOOPMIG-ACT'},
]

technical_sales_ilt = [course['course_name'] for course in technical_sales_ilt_list]

business_ess_courses_list = [
  {'course_name': 'Partner Intro',                                                  'course_code': 'PARS-PARTNER-INTRO'},
  {'course_name': 'Databricks Partner Program Overview',                            'course_code': 'PARS-DBPART-OVERVIEW'},
  {'course_name': 'Consulting & SI Partner POV Why Partner with Databricks',        'course_code': 'PARS-POV-WHYDB'},
  {'course_name': 'Partner Services Opportunity',                                   'course_code': 'PARS-PSV-OPP'},
  {'course_name': 'Persona - Data Scientist',                                       'course_code': 'PARS-PERSONA-DS'},
  {'course_name': 'Persona - Data Engineer',                                        'course_code': 'PARS-PERSONA-DE'},
  {'course_name': 'Databricks Security',                                            'course_code': 'PARS-DB-SECURITY'},
  {'course_name': 'SI Partners Win with Databricks on AWS',                         'course_code': 'PARS-DB-AWSWIN'},
  {'course_name': 'Azure Databricks and Partners',                                  'course_code': 'PARS-AZURE-DBP'},
  {'course_name': 'Databricks: The Data and AI Company',                            'course_code': 'PARS-DB-UDAP'},
  {'course_name': 'The Partner Process - Better Together',                          'course_code': 'PARS-BETTER-TOGETHER'},
  {'course_name': 'Demo - Intro into Databricks',                                   'course_code': 'PARS-DEMO-INTDB'},
  {'course_name': 'Product - Delta Lake',                                           'course_code': 'PARS-PROD-DELTA'},
  {'course_name': 'Product - Run Time + Spark 3.0 Preview',                         'course_code': 'PARS-PROD-RTS3'},
  {'course_name': 'Product - Managed MLflow',                                       'course_code': 'PARS-PROD-MLFLOW'},
  {'course_name': 'Demo - Operationalizing Data Science and Machine Learning',      'course_code': 'PARS-DEMO-ODSML'},
  {'course_name': 'Demo - Data + AI Tour - SQL Analytics on all of your Data',      'course_code': 'PARS-DEMO-DAITSQLA'},
  {'course_name': 'Demo - Next Gen. Data Science Workspace',                        'course_code': 'PARS-DEMO-NGDSW'},
  {'course_name': 'Demo - Koalas',                                                  'course_code': 'PARS-DEMO-KOALAS'},
  {'course_name': 'Demo - Redash',                                                  'course_code': 'PARS-DEMO-REDASH'},
  {'course_name': 'Demo - Azure Databricks',                                        'course_code': 'PARS-DEMO-AZUREDB'},
]

business_ess_courses = [course['course_code'] for course in business_ess_courses_list]

sales_self_paced_list = [
  {'course_name': 'Hadoop Migration Partner Badge - All Clouds',                'course_code': 'PARS - Hadoop Migration Partner Badge - All Clouds'},
  {'course_name': 'EDW-ETL Pre-Sales Migration Partner Badge - All Clouds',     'course_code': 'PARS - EDW Migration Partner Badge - All Clouds'},
  {'course_name': 'Databricks Partner Essentials',                              'course_code': 'PARS - DATABRICKS PARTNER ESSENTIALS'},
  {'course_name': '(Verified) Snowflake to Lakehouse Migration Badge',          'course_code': 'PARS - Snowflake to Lakehouse Migration Verified'},
  {'course_name': 'Snowflake to Lakehouse Migration PreSales Partner Badge',    'course_code': 'PARS - Snowflake to Lakehouse Migration PreSales '},
  {'course_name': '(Leadership) Advantages of the Lakehouse',                   'course_code': 'PARS - (Leadership) Advantages of the Lakehouse'},
]

sales_self_paced = [course['course_code'] for course in sales_self_paced_list]

technical_partner_badges_list = [
  {'credential_name': 'Databricks Certified Data Engineer Associate',                   'group_id': '353856'},
  {'credential_name': 'Databricks Certified Data Engineer Professional',                'group_id': '331743'},
  {'credential_name': 'Databricks Certified Data Scientist Professional',               'group_id': '227970'},
  {'credential_name': 'Databricks Certified Machine Learning Associate',                'group_id': '371215'},
  {'credential_name': 'Databricks Certified Machine Learning Professional',             'group_id': '357057'},
  {'credential_name': 'Partner Program -  Developer Champion',                          'group_id': '231242'},
  {'credential_name': 'Partner Training - Azure Databricks Developer Essentials',       'group_id': '229948'},
  {'credential_name': 'Partner Training - Developer Essentials',                        'group_id': '230012'},
  {'credential_name': 'Partner Training - Developer Foundations',                       'group_id': '247511'},
]

technical_partner_badges = [cred['group_id'] for cred in technical_partner_badges_list]

technical_sales_badges_list = [
  {'credential_name': 'Partner Program - Solutions Architect Champion',       'group_id': '231241'},
  {'credential_name': 'Partner Training - Solutions Architect Essentials',    'group_id': '231328'},
  {'credential_name': 'Databricks Certified Hadoop Migration Architect',      'group_id': '416340'},
]

technical_sales_badges = [cred['group_id'] for cred in technical_sales_badges_list]

total_num_badges_list = [
  {'credential_name': 'Databricks Certified Data Engineer Associate',                           'group_id': '353856'},
  {'credential_name': 'Azure Databricks Certified Associate Platform Administrator',            'group_id': '255536'},
  {'credential_name': 'Databricks Certified Data Analyst Associate',                            'group_id': '364119'},
  {'credential_name': 'Databricks Certified Associate Developer for Apache Spark 2.4',          'group_id': '227818'},
  {'credential_name': 'Databricks Certified Machine Learning Professional',                     'group_id': '357057'},
  {'credential_name': 'Partner Training - Developer Essentials',                                'group_id': '230012'},
  {'credential_name': 'Partner Program - Solutions Architect Champion',                         'group_id': '231241'},
  {'credential_name': 'Partner Training - Solutions Architect Essentials',                      'group_id': '231328'},
  {'credential_name': 'Databricks Certified Associate Developer for Apache Spark 3.0',          'group_id': '227965'},
  {'credential_name': 'Partner Training - Business Essentials',                                 'group_id': '238118'},
  {'credential_name': 'Partner Training - Sales Ready',                                         'group_id': '237937'},
  {'credential_name': 'Partner Program -  Developer Champion',                                  'group_id': '231242'},
  {'credential_name': 'Databricks Certified Data Engineer Professional',                        'group_id': '331743'},
  {'credential_name': 'Databricks Certified Machine Learning Associate',                        'group_id': '371215'},
  {'credential_name': 'Partner Training - Azure Databricks Developer Essentials',               'group_id': '229948'},
  {'credential_name': 'Databricks Certified Associate ML Practitioner for Apache Spark 2.4',    'group_id': '229201'},
  {'credential_name': 'Databricks Certified Data Scientist Professional',                       'group_id': '227970'},
  {'credential_name': 'Partner Training - Developer Foundations',                               'group_id': '247511'},
]

total_num_badges = [cred['group_id'] for cred in total_num_badges_list]

champion_badges_list = [
  {'credential_name': 'Partner Program - Solutions Architect Champion',     'group_id': '231241'},
  {'credential_name': 'Partner Program -  Developer Champion',              'group_id': '231242'},
]

champion_badges = [cred['group_id'] for cred in champion_badges_list]

sales_badges_list = [
  {'credential_name': 'Partner Training - Business Essentials',                       'group_id': '238118'},
  {'credential_name': 'Partner Training - Sales Ready',                               'group_id': '237937'},
  {'credential_name': 'Partner Training - Sales Hadoop Migration - All Clouds',       'group_id': '385601'},
  {'credential_name': 'PT - Presales EDW-ETL Migration',                              'group_id': '428755'},
  {'credential_name': 'Partner Training - Partner Essentials',                        'group_id': '416015'},
  {'credential_name': 'Partner Training - Advantages of the Lakehouse',               'group_id': '473387'},
  {'credential_name': 'PT-Snowflake to Lakehouse Migration',                          'group_id': '473403'},
  {'credential_name': 'PT-Snowflake Migration',                                       'group_id': '473415'},
  {'credential_name': 'Partner Training - Spark Migration',                           'group_id': '511547'},
  {'credential_name': 'Partner Training - Cloud Native SPARK Migration(Verified)',    'group_id': '514772'},
  
]

sales_badges = [cred['group_id'] for cred in sales_badges_list]

certification_badges_list = [
  {'credential_name': 'Databricks Certified Data Engineer Associate',                             'group_id': '353856'},
  {'credential_name': 'Databricks Certified Data Analyst Associate',                              'group_id': '364119'},
  {'credential_name': 'Databricks Certified Associate Developer for Apache Spark 2.4',            'group_id': '227818'},
  {'credential_name': 'Databricks Certified Machine Learning Professional',                       'group_id': '357057'},
  {'credential_name': 'Databricks Certified Associate Developer for Apache Spark 3.0',            'group_id': '227965'},
  {'credential_name': 'Databricks Certified Data Engineer Professional',                          'group_id': '331743'},
  {'credential_name': 'Databricks Certified Machine Learning Associate',                          'group_id': '371215'},
  {'credential_name': 'Databricks Certified Associate ML Practitioner for Apache Spark 2.4',      'group_id': '229201'},
  {'credential_name': 'Databricks Certified Data Scientist Professional',                         'group_id': '227970'},
]

certification_badges = [cred['group_id'] for cred in certification_badges_list]

# COMMAND ----------

technical_trained_list = [
  {'course_name': 'Data Analysis with Databricks SQL (ILT)',                                                'course_code': 'ACAD-CUST-ILTPUB-v1-PAID-DAWD-ACT'},
  {'course_name': 'Data Analysis with Databricks SQL (Partner)',                                            'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-DAWD-ACT'},
  {'course_name': 'Data Analysis with Databricks SQL (Private ILT)',                                        'course_code': 'ACAD-CUST-ILTPRV-v1-PAID-DAWD-ACT'},
  {'course_name': 'Data Analysis with Databricks SQL (Private Partner)',                                    'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-DAWD-ACT'},
  {'course_name': 'Data Analysis with Databricks SQL',                                                      'course_code': 'ACAD-ALL-SLP-v2-FREE-DAWD-ACT'},
  {'course_name': 'DAIS 2022 Data Analysis with Databricks SQL',                                            'course_code': 'ACAD-CUST-ILTUS-v1-PAID-DAIS22DAWD-ACT'},
  {'course_name': 'Data Engineering with Databricks (ILT) (RETIRED)',                                       'course_code': 'ACAD-ALL-ILTPUB-v1-PAID-DEWDOLD-RET'},
  {'course_name': 'Data Engineering with Databricks (ILT)',                                                 'course_code': 'ACAD-ALL-ILTPUB-v2-PAID-DEWD-ACT'},
  {'course_name': 'Data Engineering with Databricks (Partner)',                                             'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-DEWD-ACT'},
  {'course_name': 'Data Engineering with Databricks (Private ILT) (RETIRED)',                               'course_code': 'ACAD-ALL-ILTPRV-v1-PAID-DEWDOLD-RET'},
  {'course_name': 'Data Engineering with Databricks (Private ILT)',                                         'course_code': 'ACAD-ALL-ILTPRV-v2-PAID-DEWD-ACT'},
  {'course_name': 'Core Technical Series: Data Engineering with Databricks (Private Partner)',              'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-DEWD-ACT'},
  {'course_name': 'Core Technical Series: Data Engineering with Databricks (Private Partner)',              'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-DEWD-ACT'},
  {'course_name': 'Data Engineering with Databricks V2',                                                    'course_code': 'ACAD-ALL-SLP-v2-FREE-DEWD-ACT'},
  {'course_name': 'Data Engineering with Databricks V3',                                                    'course_code': 'ACAD-ALL-SLP-v3-FREE-DEWD-ACT'},
  {'course_name': 'DAIS 2022 Data Engineering with Databricks',                                             'course_code': 'ACAD-CUST-ILTUS-v1-PAID-DAIS22DEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks (ILT)',                                        'course_code': 'ACAD-CUST-ILTPUB-v1-PAID-ADEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks (Partner)',                                    'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-ADEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks (Private ILT)',                                'course_code': 'ACAD-CUST-ILTPRV-v1-PAID-ADEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks (Private Partner)',                            'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-ADEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks (Partner)',                                    'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-ADEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks',                                              'course_code': 'ACAD-ALL-SLP-v2-FREE-ADEWD-ACT'},
  {'course_name': 'DAIS 2022 Advanced Data Engineering with Databricks',                                    'course_code': 'ACAD-CUST-ILTUS-v1-PAID-DAIS22ADEWD-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (ILT)',                                     'course_code': 'ACAD-CUST-ILTPUB-v1-PAID-SMLWAS-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (Partner) ',                                'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-SMLAS-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (Private ILT)',                             'course_code': 'ACAD-CUST-ILTPRV-v1-PAID-SMLWAS-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (Private Partner)',                         'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-SMLAP-ACT'},
  {'course_name': 'Core Technical Series Scalable ML (Private Partner)',                                    'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-SCALML-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (V1)',                                      'course_code': 'ACAD-ALL-SLP-v1-FREE-SMLWAS-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (V2)',                                      'course_code': 'ACAD-ALL-SLP-v2-FREE-SMLWAS-ACT'},
  {'course_name': 'ELEVATE Training Series: Databricks for Data Analysts',                                  'course_code': 'PART-ALL-ILTUS-v1-FREE-DFDA-ACT'},
  {'course_name': 'Core Technical Series: Advanced Data Engineering with Databricks (Private Partner)',     'course_code': 'ACAD-PART-ILT-PRIVATE-v2-FREE-ADEWD-ACT'},
  {'course_name': 'ELEVATE Training Series: Databricks for Data Engineers',                                 'course_code': 'PART-ALL-SLP-v1-FREE-DFDE-ACT'},
  {'course_name': 'ELEVATE Training Series: Databricks for Machine Learning Practitioners',                 'course_code': 'PART-ALL-ILTUS-v1-FREE-DMLP-ACT'},
  {'course_name': 'Machine Learning in Production (ILT)',                                                   'course_code': 'ACAD-CUST-ILTPUB-v1-PAID-MLINPROD-ACT'},
  {'course_name': 'Machine Learning in Production (Partner)',                                               'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-MLPROD-ACT'},
  {'course_name': 'Machine Learning in Production (Private ILT)',                                           'course_code': 'ACAD-CUST-ILTPRV-v1-PAID-MLINPROD-ACT'},
  {'course_name': 'Machine Learning in Production (Private Partner)',                                       'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-MLPROD-ACT'},
  {'course_name': 'Machine Learning in Production (V1)',                                                    'course_code': 'ACAD-ALL-SLP-v1-FREE-MLINPROD-ACT'},
  {'course_name': 'DAIS 2022 Advanced Machine Learning with Databricks',                                    'course_code': 'ACAD-CUST-ILTUS-v1-PAID-DAIS22AMLWD-ACT'},
  ]

technical_trained = [course['course_code'] for course in technical_trained_list]

technical_certified_list = [
{'credential_name': 'Databricks Certified Data Engineer Associate',                             'group_id': '353856'},
{'credential_name': 'Databricks Certified Data Analyst Associate',                              'group_id': '364119'},
{'credential_name': 'Databricks Certified Associate Developer for Apache Spark 2.4',            'group_id': '227818'},
{'credential_name': 'Databricks Certified Machine Learning Professional',                       'group_id': '357057'},
{'credential_name': 'Databricks Certified Associate Developer for Apache Spark 3.0',            'group_id': '227965'},
{'credential_name': 'Databricks Certified Data Engineer Professional',                          'group_id': '331743'},
{'credential_name': 'Databricks Certified Machine Learning Associate',                          'group_id': '371215'},
{'credential_name': 'Databricks Certified Associate ML Practitioner for Apache Spark 2.4',      'group_id': '229201'},
]

technical_certified = [cred['group_id'] for cred in technical_certified_list]

technical_partner_badges_less_certs_list = [
  {'credential_name': 'Partner Program -  Developer Champion',                          'group_id': '231242'},
  {'credential_name': 'Partner Training - Azure Databricks Developer Essentials',       'group_id': '229948'},
  {'credential_name': 'Partner Training - Developer Essentials',                        'group_id': '230012'},
  {'credential_name': 'Partner Training - Developer Foundations',                       'group_id': '247511'},
]

technical_partner_badges_less_certs = [cred['group_id'] for cred in technical_partner_badges_less_certs_list]

# COMMAND ----------

def enablementResults(category, sales=False, ilt_courses=[], sp_courses=[], new_ilt_courses=[], new_sp_courses=[], badges=[], new_badges=[]):

  schema = T.StructType([
             T.StructField("learner_email", T.StringType(), True),
             T.StructField("learner_email_hash", T.StringType(), True),
             T.StructField("learner_email_domain", T.StringType(), True),
             T.StructField("learner_alternate_email", T.StringType(), True),
             T.StructField("learner_alternate_email_hash", T.StringType(), True),
             T.StructField("learner_alternate_email_domain", T.StringType(), True),
             T.StructField("ultimate_parent_account_name", T.StringType(), True),
             T.StructField("ultimate_parent_account_id", T.StringType(), True),
             T.StructField("fiscal_quarter_year", T.StringType(), True),
             T.StructField("month", T.StringType(), True),
             T.StructField("week", T.StringType(), True),
             T.StructField("fiscal_quarter", T.StringType(), True),
             T.StructField("fiscal_year", T.StringType(), True),
             T.StructField("course", T.StringType(), True),
             T.StructField("date", T.StringType(), True),
             T.StructField("country_code", T.StringType(), True),
             T.StructField("country_name", T.StringType(), True),
             T.StructField("region", T.StringType(), True),
             T.StructField("course_type", T.StringType(), True),
           ])

  # empty = sqlContext.createDataFrame(sc.emptyRDD(), schema)
  empty = spark.createDataFrame([], schema)

  if category != 'Technical Trained' or category != 'Technical Consultants':
    if len(ilt_courses) != 0:
      ilt1 = (
        ilt_enrollments
          .filter(F.col("status") == "completed")
          # .filter(F.col("course_code").isin(ilt_courses))
          .filter(F.col("course_name").isin(ilt_courses))
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name", 
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region")
          )
          .withColumn("course_type", F.lit("classroom"))
      )

    else:
      ilt1 = empty
    ilt2 = empty

    if len(sp_courses) != 0:
      sp1 = (
        self_paced_enrollments
          .filter(F.col("status") == "completed")
          # .filter(F.col("course_code").isin(sp_courses))
          .filter(F.col("course_name").isin(sp_courses))
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name",  
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region")
          )
          .withColumn("course_type", F.lit("e-learning"))
      )

    else:
      sp1 = empty
    sp2 = empty

  if category == 'Technical Trained' or category == 'Technical Consultants':

    if len(ilt_courses) != 0:
      ilt1 = (
        ilt_enrollments
          .filter(F.col("status") == "completed")
          # .filter(F.col("course_code").isin(ilt_courses))
          .filter(F.col("fiscalYear") <= '2023')
          .filter(F.col("course_name").isin(ilt_courses))
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name", 
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region")
          )
          .withColumn("course_type", F.lit("classroom"))
      )

    else:
      ilt1 = empty
    
    if len(new_ilt_courses) != 0:
      ilt2 = (
        ilt_enrollments
          .filter(F.col("status") == "completed")
          .filter(F.col("fiscalYear") >= '2024')
          .filter(F.col("course_code").isin(new_ilt_courses))
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name", 
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region")
          )
          .withColumn("course_type", F.lit("classroom"))
      )

    else:
      ilt2 = empty
    
      
    if len(sp_courses) != 0:
      sp1 = (
        self_paced_enrollments
          .filter(F.col("status") == "completed")
          # .filter(F.col("course_code").isin(sp_courses))
          .filter(F.col("course_name").isin(sp_courses))
          .filter(F.col("fiscalYear") <= '2023')
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name",  
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region")
          )
          .withColumn("course_type", F.lit("e-learning"))
      )

    else:
      sp1 = empty

    if len(new_sp_courses) != 0:
      sp2 = (
        self_paced_enrollments
          .filter(F.col("status") == "completed")
          .filter(F.col("course_code").isin(new_sp_courses))
          .filter(F.col("fiscalYear") >= '2024')
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name",  
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region")
          )
          .withColumn("course_type", F.lit("e-learning"))
      )

    else:
      sp2 = empty
    
  if len(badges) != 0:
    badge1 = (
      partner_badges
        .filter(F.col("group_id").isin(badges))
        .withColumn("learner_email", F.lit(None))
        .withColumn("learner_alternate_email", F.lit(None))
        .select(
          "learner_email",
          "learner_email_hash", 
          "learner_email_domain",
          "learner_alternate_email",
          "learner_alternate_email_hash",
          "learner_alternate_email_domain",
          "ultimate_parent_account_name",  
          "ultimate_parent_account_id",
          "fiscal_quarter_year",
          "month", 
          "week",
          F.col("fiscalQuarter").alias("fiscal_quarter"),
          F.col("fiscalYear").alias("fiscal_year"),
          F.col("credential_name").alias("course"), 
          "date",
          F.col("country_code"),
          F.col("country_name"),
          F.col("region")
        )
        .withColumn("course_type", F.lit("badge"))
    )
  else:
    badge1 = empty

  if len(new_badges) != 0:
    badge2 = (
      partner_badges
        .filter(F.col("group_id").isin(new_badges))
        .filter(F.col("calculated_is_expired") == "false")
        .withColumn("learner_email", F.lit(None))
        .withColumn("learner_alternate_email", F.lit(None))
        .select(
          "learner_email",
          "learner_email_hash", 
          "learner_email_domain",
          "learner_alternate_email",
          "learner_alternate_email_hash",
          "learner_alternate_email_domain",
          "ultimate_parent_account_name",  
          "ultimate_parent_account_id",
          "fiscal_quarter_year",
          "month", 
          "week",
          F.col("fiscalQuarter").alias("fiscal_quarter"),
          F.col("fiscalYear").alias("fiscal_year"),
          F.col("credential_name").alias("course"), 
          "date",
          F.col("country_code"),
          F.col("country_name"),
          F.col("region")
        )
        .withColumn("course_type", F.lit("certification"))
    )
  else:
    badge2 = empty

  if sales:
    sales_trained = sales_trained_data
  else:
    sales_trained = empty

  all_enrollments = (
    ilt1
      .union(ilt2)
      .union(sp1)
      .union(sp2)
      .union(badge1)
      .union(badge2)
      .union(sales_trained)
      .withColumn("category", F.lit(f"{category}"))
  )
  
  return all_enrollments

# COMMAND ----------

def capacity(df):
  first_enrollment_ids = (
    df
      .orderBy("date")
      .groupBy("learner_email_hash")
      .agg(F.collect_list(F.struct("date", "learner_email_hash", "course")).alias("enrollment_dates"))
      .select(
        F.array_min(F.array_sort(F.col("enrollment_dates"))).getItem("date").alias("date"),
        F.array_min(F.array_sort(F.col("enrollment_dates"))).getItem("learner_email_hash").alias("learner_email_hash"),
        F.array_min(F.array_sort(F.col("enrollment_dates"))).getItem("course").alias("course"),
      )
  )

  first_enrollments = (
    df
      .join(first_enrollment_ids, ["date", "learner_email_hash", "course"])
      .dropDuplicates(["learner_email_hash", "date", "course"])
  )

  return first_enrollments

# COMMAND ----------

sales_docebo_ilt = (
  ilt_enrollments
    .filter(F.col("status") == "completed")
    .filter(F.col("course_name").like("%10X%"))
    .dropDuplicates(["course_name", "learner_email_hash"])
    .select(
      "learner_email",
      "learner_email_hash", 
      "learner_email_domain",
      "learner_alternate_email",
      "learner_alternate_email_hash",
      "learner_alternate_email_domain",
      "ultimate_parent_account_name", 
      "ultimate_parent_account_id",
#       "partner_account_id_sfdc", 
      "fiscal_quarter_year",
      "month", 
      "week",
      F.col("fiscalQuarter").alias("fiscal_quarter"),
      F.col("fiscalYear").alias("fiscal_year"),
      F.col("course_name").alias("course"), 
      "date",
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
  .withColumn("course_type", F.lit("classroom"))
)

sales_docebo_sp = (
  self_paced_enrollments
    .filter(F.col("status") == "completed")
    .filter((F.col("course_code").isin(business_ess_courses)) | (F.col("course_name").like("%10X%")) |(F.col("course_code").isin(sales_self_paced)))
    .dropDuplicates(["course_name", "learner_email_hash"])
    .select(
      "learner_email",
      "learner_email_hash", 
      "learner_email_domain",
      "learner_alternate_email",
      "learner_alternate_email_hash",
      "learner_alternate_email_domain",
      "ultimate_parent_account_name", 
      "ultimate_parent_account_id",
#       "partner_account_id_sfdc", 
      "fiscal_quarter_year",
      "month", 
      "week",
      F.col("fiscalQuarter").alias("fiscal_quarter"),
      F.col("fiscalYear").alias("fiscal_year"),
      F.col("course_name").alias("course"), 
      "date",
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
    .withColumn("course_type", F.lit("e-learning"))
)

spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

sales_legacy = (
  sales_legacy_raw
    .drop('partner_account_name', 'partner_account_id_sfdc', )
    .withColumn("email_domain_final", F.split(F.lower('contact_email'), '@', 2).getItem(1))
    .join(unique_partner_mappings, "email_domain_final", "left")
    .withColumn('ultimate_parent_account_id', F.coalesce('ultimate_parent_account_id', 'account_id'))
    .withColumn('ultimate_parent_account_name', F.coalesce('ultimate_parent_account_name', 'account_name'))
)

sales_legacy_data = (
  sales_legacy
    .join(dates_raw, "date", "left")
    .withColumn("fiscal_quarter_year", F.concat(F.lit("FY"), F.col('fiscalYear'), F.lit("Q"), F.col('fiscalQuarter')))
    .withColumnRenamed('email_domain_final', 'learner_email_domain')
    .withColumn("learner_email_hash", F.sha2("contact_email", 256))
    .withColumn("country_code", F.lit(None))
    .withColumn("country_name", F.lit(None))
    .withColumn("region", F.lit(None))
    .withColumn("learner_alternate_email", F.lit(None))
    .withColumn("learner_alternate_email_hash", F.lit(None))
    .withColumn("learner_alternate_email_domain", F.lit(None))
    .select(
      F.col("contact_email").alias("learner_email"),
      "learner_email_hash", 
      "learner_email_domain",
      "learner_alternate_email",
      "learner_alternate_email_hash",
      "learner_alternate_email_domain",
      "ultimate_parent_account_name",
      "ultimate_parent_account_id",
      "fiscal_quarter_year", 
      "month", 
      "week",
      F.col("fiscalQuarter").alias("fiscal_quarter"),
      F.col("fiscalYear").alias("fiscal_year"),
      F.col("event").alias("course"), 
      "date",
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
    .dropDuplicates(["learner_email_hash", "course", "date"])
    .withColumn("course_type", F.lit("ILT"))
)

sales_trained_data = (
  sales_legacy_data
    .union(sales_docebo_ilt)
    .union(sales_docebo_sp)
)

# COMMAND ----------

# Delivery Trained

delivery_trained_capability = (
  enablementResults(
    ilt_courses=partner_technical_ilt, 
    sp_courses=technical_self_paced, 
    new_ilt_courses=technical_trained, 
    new_sp_courses=technical_trained, 
    category="Technical Trained"
  )
)

delivery_trained_capacity = capacity(delivery_trained_capability)

# Technical Sales Trained

technical_sales_trained_capability = (
  enablementResults(
    ilt_courses=technical_sales_ilt,
    category="Technical Sales Trained"
  )
)

technical_sales_trained_capacity = capacity(technical_sales_trained_capability)

# Sales Trained

sales_trained_capability = (
  enablementResults(
    sales=True,
    category="Sales Trained"
  )
)

sales_trained_capacity = capacity(sales_trained_capability)

# Total Trained

total_trained_capability = (
  enablementResults(
    ilt_courses=partner_technical_ilt+technical_sales_ilt,
    sp_courses=technical_self_paced,
    badges=technical_sales_badges,
    sales=True,
    category="Total Trained"
  )
)

total_trained_capacity = capacity(total_trained_capability)

# Delivery Badged

delivery_badged_capability = (
  enablementResults(
    badges=technical_partner_badges, 
    category="Technical Badged"
  )
)

delivery_badged_capacity = capacity(delivery_badged_capability)

# Technical Sales Badged

technical_sales_badged_capability = (
  enablementResults(
    badges=technical_sales_badges, 
    category="Technical Sales Badged"
  )
)

technical_sales_badged_capacity = capacity(technical_sales_badged_capability)

# Sales Badged

sales_badged_capability = (
  enablementResults(
    badges=sales_badges, 
    category="Sales Badged"
  )
)

sales_badged_capacity = capacity(sales_badged_capability)

# Academy Certification Badged

academy_certification_badged_capability = (
  enablementResults(
    badges=certification_badges, 
    category="Academy Certification Badged"
  )
)

academy_certification_badged_capacity = capacity(academy_certification_badged_capability)

# Champion Badged

champion_badged_capability = (
  enablementResults(
    badges=champion_badges, 
    category="Champion Badged"
  )
)

champion_badged_capacity = capacity(champion_badged_capability)

# Total Badged

total_badged_capability = (
  enablementResults(
    badges=technical_partner_badges+technical_sales_badges+sales_badges+certification_badges+champion_badges, 
    category="Total Badged"
  )
)

total_badged_capacity = capacity(total_badged_capability)

# Total Sales

total_sales_capability = (
  enablementResults(
    badges=technical_sales_badges+sales_badges,
    ilt_courses=technical_sales_ilt,
    sales=True,
    category="Total Trained or Badged (Sales)"
  )
)

total_sales_capacity = capacity(total_sales_capability)

# Total Delivery

total_delivery_capability = (
  enablementResults(
    ilt_courses=partner_technical_ilt, 
    sp_courses=technical_self_paced, 
    badges=certification_badges+technical_partner_badges,
    category="Total Trained or Badged (Technical)"
  )
)

total_delivery_capacity = capacity(total_delivery_capability)

# Total Trained and Badged

total_all_capability = (
  enablementResults(
    ilt_courses=partner_technical_ilt+technical_sales_ilt, 
    sp_courses=technical_self_paced, 
    badges=technical_partner_badges+technical_sales_badges+sales_badges+certification_badges+champion_badges,
    sales=True,
    category="Total Trained or Badged (All Training and Badge Categories)"
  )
)

total_all_capacity = capacity(total_all_capability)

# Technical Certified

technical_certified_capability = (
  enablementResults(
    new_badges=technical_certified, 
    category="Technical Certified"
  )
)

technical_certified_capacity = capacity(technical_certified_capability)

# Technical consultants

technical_consultants_capability = (
  enablementResults(
    ilt_courses=partner_technical_ilt, 
    sp_courses=technical_self_paced, 
    new_ilt_courses=technical_trained, 
    new_sp_courses=technical_trained, 
    badges=technical_partner_badges_less_certs,
    new_badges=technical_certified,
    category="Technical Consultants"
  )
)

technical_consultants_capacity = capacity(technical_consultants_capability)


# COMMAND ----------

all_capacity = (
  delivery_trained_capacity
    .union(technical_sales_trained_capacity)
    .union(sales_trained_capacity)
    .union(total_trained_capacity)
    .union(delivery_badged_capacity)
    .union(technical_sales_badged_capacity)
    .union(sales_badged_capacity)
    .union(academy_certification_badged_capacity)
    .union(champion_badged_capacity)
    .union(total_badged_capacity)
    .union(total_sales_capacity)
    .union(total_delivery_capacity)
    .union(total_all_capacity)
    .union(technical_certified_capacity)
    .union(technical_consultants_capacity)
)

all_capability = (
  delivery_trained_capability
    .union(technical_sales_trained_capability)
    .union(sales_trained_capability)
    .union(total_trained_capability)
    .union(delivery_badged_capability)
    .union(technical_sales_badged_capability)
    .union(sales_badged_capability)
    .union(academy_certification_badged_capability)
    .union(champion_badged_capability)
    .union(total_badged_capability)
    .union(total_sales_capability)
    .union(total_delivery_capability)
    .union(total_all_capability)
    .union(technical_certified_capability)
    .union(technical_consultants_capability)

)

# COMMAND ----------

all_capacity_enhanced = (all_capacity.join(sfdc_account, "ultimate_parent_account_id", "left"))
all_capability_enhanced = (all_capability.join(sfdc_account, "ultimate_parent_account_id", "left"))

# COMMAND ----------

all_capacity_enhanced = (
  all_capacity_enhanced
    .select(
      F.col('learner_email').alias('contact_email'),
      'learner_email_hash',
      'learner_email_domain',
      F.col('ultimate_parent_account_name').alias('partner_account_name'),
      F.col('ultimate_parent_account_id').alias('partner_account_id_sfdc'),
      'fiscal_quarter_year',
      'month',
      'week',
      'fiscal_quarter',
      'fiscal_year',
      'course',
      F.date_format(F.to_date(F.col('date'), 'yyyy-MM-dd'), 'yyyy-MM-dd').alias('date'),
      'course_type',
      'category',
      'partner_manager',
      'billing_country',
      'partner_level',
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      'partner_tier',
      "learner_alternate_email",
      "learner_alternate_email_hash",
      "learner_alternate_email_domain",
    )
)

all_capability_enhanced = (
  all_capability_enhanced
    .select(
      F.col('learner_email').alias('contact_email'),
      'learner_email_hash',
      'learner_email_domain',
      F.col('ultimate_parent_account_name').alias('partner_account_name'),
      F.col('ultimate_parent_account_id').alias('partner_account_id_sfdc'),
      'fiscal_quarter_year',
      'month',
      'week',
      'fiscal_quarter',
      'fiscal_year',
      'course',
      F.date_format(F.to_date(F.col('date'), 'yyyy-MM-dd'), 'yyyy-MM-dd').alias('date'),
      'course_type',
      'category',
      'partner_manager',
      'billing_country',
      'partner_level',
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      'partner_tier',
      "learner_alternate_email",
      "learner_alternate_email_hash",
      "learner_alternate_email_domain",
    )
)

# COMMAND ----------

all_capability_enhanced_partition = add_gold_metadata(all_capability_enhanced)
all_capacity_enhanced_partition = add_gold_metadata(all_capacity_enhanced)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_capability_enhanced_partition, 
  table_name = f'{focus_database_name}.partner_capability_old', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_capacity_enhanced_partition, 
  table_name = f'{focus_database_name}.partner_capacity_old', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)