# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             ILT Zoom Audit \
# MAGIC **Description:**     This notebook gives the data for the Audit of the Zoom Attendances in the ILT Zoom Sessions \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

# MAGIC %run "/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

# MAGIC %run "/Users/liam.clifford@databricks.com/Liam's Notebook - getMeetingInformation UDF"

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# DBTITLE 1,Instructor Session Data Extraction
# Step 1: Get the Session Instructors and session data
session_instructors_df = spark.sql('''

with session_details as (
  select 
    --case when docebo_session_url_internal is not null and CHARINDEX("\\?", docebo_session_url_internal) > 0
    --  then split(split(docebo_session_url_internal, '/')[5], "\\\\?")[0]
    --  else split(docebo_session_url_internal, '/')[5]
    --end as session_code,
    academy_session_number,
    case when resources_meeting_link is not null and CHARINDEX("\\?", resources_meeting_link)>0
      then split(split(resources_meeting_link, '/')[4], "\\\\?")[0]
      when resources_meeting_link is not null and CHARINDEX(" ", resources_meeting_link)>0
      then split(split(resources_meeting_link, '/')[4], " ")[0]
      else split(resources_meeting_link, '/')[4]
    end as meeting_id,
    start_date::date,
    end_date::date,
    REPLACE(REPLACE(REPLACE(instructor_email, '[', ''), ']', ''), "'") AS instructor_email
  from 
    main.field_learning_enablement.training_operations_ilt_schedule_master
  where 
    processdate = (select max(processDate) from main.field_learning_enablement.training_operations_ilt_schedule_master)
    and meeting_platform = "['Zoom']"
    and resources_meeting_link ilike 'https://databricks.zoom.us/j%'
),

course_desc as (
  select
    d.course_id,
    d.code, 
    d.id as session_code, 
    d.course_code, 
    d.session_name, 
    c.category_code,
    case when contains(d.course_code, 'FREE') then 'FREE'
    when contains(d.course_code, 'PART') then 'Partner Paid'
    when contains(d.course_code, 'CUST') then 'Customer Paid'
    else 'Others'
    end as category_type
    from 
      main.it_training_silver.docebo_ilt_sessions d
      join main.it_training_silver.docebo_courses c
      on c.id = d.course_id
      and c.processDate = d.processDate
    where d.processDate = (select max(processDate) from main.it_training_silver.docebo_ilt_sessions)
  )


select * 
  from session_details s
  left join course_desc c on s.academy_session_number = c.code
'''
)
session_instructors = session_instructors_df.toPandas()
display(session_instructors_df)

# COMMAND ----------

# DBTITLE 1,Zoom Meeting Data Aggregator
# Step 2: Get the meeting_details and meeting_participants from zoom
meeting_details_dfs = []
meeting_participants_dfs = []

for host in session_instructors.to_dict(orient='records'):
  try:
    getMeetingDetailsByMeetingIdV3(meeting_id=host['meeting_id'],type='meetings',fromDate=host['start_date'],toDate=host['end_date'])

    meeting_details = spark.sql("""select * from meeting_details""")
    meeting_participants = spark.sql("""select * from meeting_participants""")

    meeting_details_dfs.append(meeting_details)
    meeting_participants_dfs.append(meeting_participants)

  except json.JSONDecodeError as e:
    print(host['meeting_id'])
    print(f"Failed to parse JSON response: {e}")
    continue

# COMMAND ----------

def remove_duplicates(dataset_list):
    unique_datasets = []

    for data in dataset_list:
        if data not in unique_datasets:
            unique_datasets.append(data)

    return unique_datasets


unique_df_list = list(set(map(lambda df: tuple(df.collect()), meeting_details_dfs)))
unique_dfs = [spark.createDataFrame(data) for data in unique_df_list]
display(len(unique_dfs))

# COMMAND ----------

# Step 3: Get unique datasets
unique_participants_list = list(set(map(lambda df: tuple(df.collect()), meeting_participants_dfs)))
unique_participants_dfs = [spark.createDataFrame(data) for data in unique_participants_list]
display(len(unique_participants_dfs))

# COMMAND ----------

details_schema = T.StructType([
  T.StructField('uuid', T.StringType(), True),
  T.StructField('id', T.StringType(), True),
  T.StructField('host_id', T.StringType(), True),
  T.StructField('type', T.StringType(), True),
  T.StructField('topic', T.StringType(), True),
  T.StructField('user_name', T.StringType(), True),
  T.StructField('user_email', T.StringType(), True),
  T.StructField('start_time', T.StringType(), True),
  T.StructField('end_time', T.StringType(), True),
  T.StructField('duration', T.StringType(), True),
  T.StructField('total_minutes', T.StringType(), True),
  T.StructField('participants_count', T.StringType(), True),
  T.StructField('tracking_fields', T.StringType(), True),
  T.StructField('dept', T.StringType(), True),
  T.StructField('webinars', T.StringType(), True)
])

participants_schema = T.StructType([
  T.StructField('id', T.StringType(), True),
  T.StructField('user_id', T.StringType(), True),
  T.StructField('name', T.StringType(), True),
  T.StructField('user_email', T.StringType(), True),
  T.StructField('join_time', T.StringType(), True),
  T.StructField('leave_time', T.StringType(), True),
  T.StructField('duration', T.StringType(), True),
  T.StructField('attentiveness_score', T.StringType(), True),
  T.StructField('failover', T.StringType(), True),
  T.StructField('status', T.StringType(), True),
  T.StructField('customer_key', T.StringType(), True),
  T.StructField('uuid', T.StringType(), True),
  T.StructField('participant_user_id', T.StringType(), True),
])

# COMMAND ----------

# Step 4: Create a list of the meeting_details and meeting_participants dfs
meeting_details_df = sqlContext.createDataFrame([], details_schema)
meeting_participants_df = sqlContext.createDataFrame([], participants_schema)

for df in unique_dfs:
  meeting_details_df = meeting_details_df.unionByName(df, allowMissingColumns=True)

for df in unique_participants_dfs:
    meeting_participants_df = meeting_participants_df.unionByName(df, allowMissingColumns=True)

# COMMAND ----------

meeting_details_df.createOrReplaceTempView('meeting_details')
meeting_participants_df.createOrReplaceTempView('meeting_participants')
session_instructors_df.createOrReplaceTempView('session_instructors')

# COMMAND ----------

# DBTITLE 1,Session Attendance Analysis Report
# -- Meeting Details table
zoom_audit_attendance_details = spark.sql('''
with meeting_participants_list as (
  select f.academy_session_number, f.session_code, m.name, count(distinct m.uuid) as attended_count
  from meeting_participants m
  join
  (select d.uuid, d.id, s.session_code,s.academy_session_number from meeting_details d join session_instructors s on d.id = s.meeting_id) f on m.uuid = f.uuid
  where user_email not ilike '%databricks.com%'
  group by 1,2,3
  order by 2
),
session_meetings_count as (
  select s.academy_session_number, s.session_code, 
  count(distinct m.uuid) as total_meeting_count
  from meeting_details m 
  join session_instructors s on m.id = s.meeting_id
  group by 1,2
  order by 2
  
),

zoom_participants_count as (
  select l.academy_session_number, l.session_code, count(distinct name) as participants_present
  from meeting_participants_list l
  join session_meetings_count c on l.academy_session_number = c.academy_session_number
  where l.attended_count = c.total_meeting_count
  group by 1,2
  order by 2
),

total_ilt_enrollments as (
  select 
  s.academy_session_number, 
  e.session_id, 
  count(distinct learner_user_id) as enrollments_count,
  count(distinct learner_user_id) FILTER(where status = 'completed') as completed_count
  from main.field_learning_enablement.ilt_enrollments e
  right join session_instructors s on e.session_id = s.session_code
  where processDate = (select max(processDate) from main.field_learning_enablement. ilt_enrollments)
  group by 1,2
  order by 2
),

-- total_ilt_completions as (
--   select s.academy_session_number,e.session_id, count(distinct learner_user_id) as ilt_completed_count
--   from main.field_learning_enablement.ilt_enrollments e
--   left join session_instructors s on e.session_id = s.session_code
--   where processDate = (select max(processDate) from main.field_learning_enablement.ilt_enrollments)
--   and session_id in (select session_code from session_instructors)
--   and status = 'completed'
--   group by 1,2
--   order by 2
-- ),

percent_attendance as (
select 
 
  distinct m.name,
  f.academy_session_number,
  f.session_code,
  Sum(m.duration) as attended_duration,
  sum(f.duration*60) as total_duration,
  ROUND((attended_duration/total_duration)*100,2) as percent_duration
  from meeting_participants m
  join
  (select d.uuid, d.id, s.session_code,s.academy_session_number, d.duration from meeting_details d join session_instructors s on d.id = s.meeting_id) f on m.uuid = f.uuid
  where user_email not like '%databricks.com%'
  group by 1,2,3
  -- order by 1,2,4
order by 1,2
)
,

final_attendance_data as (
  select
  e.academy_session_number,
  e.session_id,
  e.enrollments_count, 
  e.completed_count,
  nvl(m.participants_present,0) as participants_present,
  s.instructor_email,
  collect_list(distinct  s.meeting_id) as meeting_ids,
  min(s.start_date) as start_date,
  max(s.end_date) as end_date,
  s.course_id,
  s.code, 
  s.course_code, 
  s.session_name, 
  s.category_code,
  s.category_type



  from 
  session_instructors s 
  right join total_ilt_enrollments e on s.session_code = e.session_id
  -- left join total_ilt_completions c on c.academy_session_number = s.academy_session_number
  left join zoom_participants_count m on m.session_code = s.session_code
  left join percent_attendance p on p.session_code = s.session_code
  group by all
  order by 2
)

select * from final_attendance_data

''')


# COMMAND ----------

# DBTITLE 1,Docebo Sessions Join Courses Query
# %sql
# -- DEBUG
# select
#     d.course_code, 
#     case when contains(d.course_code, 'FREE') then 'FREE'
#     when contains(d.course_code, 'PART') then 'Partner Paid'
#     when contains(d.course_code, 'CUST') then 'Customer Paid'
#     else 'Others'
#     end as category,
#     d.course_id,
#     d.code, 
#     d.id as session_code, 
#     d.session_name, 
#     c.*
#     from 
#       main.it_training_silver.docebo_ilt_sessions d
#       join main.it_training_silver.docebo_courses c
#       on c.id = d.course_id
#       and c.processDate = d.processDate
#     where d.processDate = (select max(processDate) from main.it_training_silver.docebo_ilt_sessions)
#     -- and d.code = 11046

# COMMAND ----------

zoom_audit_summary_gold = add_gold_metadata(zoom_audit_attendance_details)

# COMMAND ----------

# DBTITLE 1,Session Participant Analysis Query
# %sql
# -- Participants Details table
zoom_audit_participants_details = spark.sql('''
-- with meeting_participants_list as (
  select 
  f.academy_session_number, 
  f.session_code, 
  m.name, 
  count(distinct m.uuid) as attended_count,
  collect_list(distinct f.uuid) as uuids,
  collect_list(distinct f.id) as meeting_ids,
  f.instructor_email,
  f.course_id,
  f.code, 
  f.course_code, 
  f.session_name, 
  f.category_code,
  Sum(m.duration) as attended_duration,
  sum(f.duration*60) as total_duration,
  ROUND((attended_duration/total_duration)*100,2) as percent_duration,
  min(f.start_date) as start_date,
  max(f.end_date) as end_date,
  user_email
  from meeting_participants m
  left join
  (select d.uuid, d.id, s.session_code,s.academy_session_number,s.*,d.duration from meeting_details d left join session_instructors s on d.id = s.meeting_id) f on m.uuid = f.uuid
  where user_email not ilike '%databricks.com%'
  group by 1,2,3,7,8,9,10,11,12,18
  order by 2
''')




# COMMAND ----------

zoom_audit_details_gold = add_gold_metadata(zoom_audit_participants_details)

# COMMAND ----------

display(zoom_audit_summary_gold)
display(zoom_audit_details_gold)

# COMMAND ----------

print(partition_date)

# COMMAND ----------

write_delta_table(
  spark, 
 dataframe = zoom_audit_summary_gold,
  table_name = f'{focus_database_name}.ilt_zoom_audit_summary', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = zoom_audit_details_gold, 
  table_name = f'{focus_database_name}.ilt_zoom_audit_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

