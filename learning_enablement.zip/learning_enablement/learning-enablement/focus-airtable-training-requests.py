# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for instructor utilzation from Airtable \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Workspace/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import requests

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

import pandas as pd


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

def convertToDF(data):
  """
    data is a list of objects
  """
  json_obj = {}
  
  json_obj['field'] = data

  df = pd.json_normalize(json_obj['field'])
  lst = list(df)
  df[lst] = df[lst].astype(str)

  spark_df = (
    spark
      .createDataFrame(df)
  )
  return spark_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### Instructors

# COMMAND ----------

airtable_pat = dbutils.secrets.get('ldr-airtable', 'airtable-token')

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Instructors?view=All%20Resources"
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

fy24_instructor_records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()


fy24_instructor_records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  fy24_instructor_records += response_json['records']

fy24_instructor_data = []
for record in fy24_instructor_records:
  fields = record['fields']
  if 'Instructor Email' in fields:
    instructor = {
      'id': record['id'],
      'email': fields['Instructor Email'],
      'organization_name': fields.get('Organization Name', ''),
      'location_country': fields.get('Country', '')
    }
    fy24_instructor_data.append(instructor)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Training Request Queue

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Training%20Request%20Queue?view=All%20Training%20Requests"
# headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()

# pprint(response_json)

records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  records += response_json['records']

# pprint(records)


# COMMAND ----------

training_requests_df_raw = convertToDF(records)
training_requests_df_raw.createOrReplaceTempView('training_requests_raw')

# COMMAND ----------

training_requests_df = spark.sql('''
with pre as (
select 
id,
createdTime,
`fields.Request #` as request_num,
`fields.[FF-PSA] Revenue per Learner.specialValue` as ff_psa_revenue_per_learner_special_value,
`fields.Submission Date` as submission_date,
`fields.Submission Month` as submission_month,
`fields.Quarter` as quarter,
`fields.Milestone Amount (Updated)` as milestone_amount_updated,
`fields.Created By.id` as created_by_id,
`fields.Created By.email` as created_by_email,
`fields.Created By.name` as created_by_name,
`fields.#TSUs Consumed` as numtsus_consumed,
`fields.Milestone Name [FF-PSA]` as milestone_name_ff_psa,
`fields.Requestor Type` as requestor_type,
`fields.[SFDC] Project or Opportunity ` as sfdc_project_or_opportunity,
`fields.Learner First Name` as learner_first_name,
`fields.Learner Email` as learner_email,
`fields.# Participants` as num_participants,
`fields.Requestor Name` as requestor_name,
`fields.Requestor Email` as requestor_email,
`fields.Payment Type` as payment_type,
`fields.Request Type` as request_type,
`fields.Learner Last Name` as learner_last_name,
`fields.Customer or Partner?` as customer_or_partner,
`fields.Course Name` as course_name,
`fields.Preferred Time Zone` as preferred_time_zone,
`fields.Virtual or Onsite?` as virtual_or_onsite,
`fields.Full-Day or Half-Day Delivery?` as full_day_or_half_day_delivery,
`fields.Preferred Class Dates` as preferred_class_dates,
`fields.Preferred Class Time` as preferred_class_time,
`fields.Meeting Platform` as meeting_platform,
`fields.Preferred Video Conference Tool` as preferred_video_conference_tool,
`fields.Company Name` as company_name,
`fields.[FF-PSA] Revenue per Learner` as ff_psa_revenue_per_learner,
`fields.Class Name` as class_name,
`fields.Status (from Class Name)` as status_from_class_name,
`fields.Quarter + FY (from Class Name)` as quarter_and_fy_from_class_name,
`fields.Projects (from Class Name)` as projects_from_class_name,
`fields.[FORM] Start Date (from Class Name)` as form_start_date_from_class_name,
`fields.[FORM] End Date (from Class Name)` as form_end_date_from_class_name,
`fields.Provider (from Class Name)` as provider_from_class_name,
`fields.Month (from Class Name)` as month_from_class_name,
`fields.# Enrollments (from Class Name)` as num_enrollments_from_class_name,
`fields.[DOCEBO] Session Code (from Class Name)` as docebo_session_code_from_class_name,
`fields.Course Abbreviation (from Course/Project) (from Class Name)` as course_abbreviation_from_course_project_from_class_name,
`fields.Start Date (from Class Name)` as start_date_from_class_name,
`fields.End Date (from Class Name)` as end_date_from_class_name,
`fields.Region (from Class Name)` as region_from_class_name,
`fields.Duration (Days) (from Class Name)` as duration_days_from_class_name,
`fields.Status` as status,
`fields.Last Modified By.id` as last_modified_by_id,
`fields.Last Modified By.email` as last_modified_by_email,
`fields.Last Modified By.name` as last_modified_by_name,
`fields.Date Last Modified (Status)` as date_last_modified_status,
`fields.[COMPANY] Contact Name (from Class Name)` as company_contact_name_from_class_name,
`fields.[FF-PSA] Milestone ID (from Class Name)` as ff_psa_milestone_id_from_class_name,
`fields.Learner Time Zone` as learner_time_zone,
`fields.Databricks Academy Account` as databricks_academy_account,
`fields.[DOCEBO] Session URL (from Class Name)` as docebo_session_url_from_class_name,
`fields.Onboarding PDF` as onboarding_pdf,
`fields.Notes` as notes,
`fields.Collaborator` as collaborator,
`fields.[FF-PSA] Milestone Link` as ff_psa_milestone_link,
`fields.Date Last Modified (Revenue)` as date_last_modified_revenue,
`fields.[FF-PSA] Revenue` as ff_psa_revenue,
`fields.Subscription Start Date` as subscription_start_date,
`fields.Subscription End Date` as subscription_end_date,
`fields.Subscription Coupon Code [License]` as subscription_coupon_code_license,
`fields.[DOCEBO] Learners Enrolled? ` as docebo_learners_enrolled,
`fields.Milestone ID (Lookup)` as milestone_id_lookup,
`fields.Pipeline Milestone Amount` as pipeline_milestone_amount,
`fields.Enrollment List` as enrollment_list,
`fields.TR Subscriptions` as tr_subscriptions,
`fields.Stage (from PS&T Learning Subscriptions - All Time)` as stage_from_ps_and_t_learning_subscriptions_all_time,
`fields.End Date (from PS&T Learning Subscriptions - All Time)` as end_date_from_ps_and_t_learning_subscriptions_all_time,
`fields.Start Date (from PS&T Learning Subscriptions - All Time)` as start_date_from_ps_and_t_learning_subscriptions_all_time,
`fields.Location` as location,
`fields.Certification Vouchers - Customer` as certification_vouchers_customer,
`fields.Enrollment Type?` as enrollment_type,
`fields.Number of Licenses` as number_of_licenses,
`fields.Licenses to Activate Now` as licenses_to_activate_now,
`fields.Is this for a Databricks Partner?` as is_this_for_a_databricks_partner,
`fields.Is this for a Databricks Customer?` as is_this_for_a_databricks_customer,
`fields.Learner End Date` as learner_end_date,
`fields.Language` as language,
`fields.Alternative Time Zone` as alternative_time_zone,
`fields.Ops Notes` as ops_notes,
`fields.Milestone Name [FF-PSA].error` as milestone_name_ff_psa_error,
`fields.Do you have access to Slack? Slack is used to communicate with the Instructor during the training. It is very helpful for sharing resources throughout the training (as Zoom does not maintain a chat history across sessions).` as access_to_slack,
`fields.ILT Schedule copy` as ilt_schedule_copy,
`fields.TR Subscriptions copy` as tr_subscriptions_copy,
`fields.Old Request #` as old_request_num,
`fields.Old Submission Date` as old_submission_date,
`fields.Pricing + Payment` as pricing_and_payment,
`fields.Certification Voucher Batch Code` as voucher_batch_code

from training_requests_raw
)

select 
  case when id in ('nan', 'NaN') then null else id end as id,
  case when createdTime in ('nan', 'NaN') then null else createdTime end as created_time,
  case when request_num in ('nan', 'NaN') then null else request_num end as request_num,
  case when ff_psa_revenue_per_learner_special_value in ('nan', 'NaN') then null else ff_psa_revenue_per_learner_special_value end as ff_psa_revenue_per_learner_special_value,
  case when submission_date in ('nan', 'NaN') then null else submission_date end as submission_date,
  case when submission_month in ('nan', 'NaN') then null else submission_month end as submission_month,
  case when quarter in ('nan', 'NaN') then null else quarter end as quarter,
  case when milestone_amount_updated in ('nan', 'NaN') then null else milestone_amount_updated end as milestone_amount_updated,
  case when created_by_id in ('nan', 'NaN') then null else created_by_id end as created_by_id,
  case when created_by_email in ('nan', 'NaN') then null else created_by_email end as created_by_email,
  case when created_by_name in ('nan', 'NaN') then null else created_by_name end as created_by_name,
  case when numtsus_consumed in ('nan', 'NaN') then null else numtsus_consumed end as numtsus_consumed,
  case when milestone_name_ff_psa in ('nan', 'NaN') then null else milestone_name_ff_psa end as milestone_name_ff_psa,
  case when requestor_type in ('nan', 'NaN') then null else requestor_type end as requestor_type,
  case when sfdc_project_or_opportunity in ('nan', 'NaN') then null else sfdc_project_or_opportunity end as sfdc_project_or_opportunity,
  case when learner_first_name in ('nan', 'NaN') then null else learner_first_name end as learner_first_name,
  case when learner_email in ('nan', 'NaN') then null else learner_email end as learner_email,
  case when num_participants in ('nan', 'NaN') then null else num_participants end as num_participants,
  case when requestor_name in ('nan', 'NaN') then null else requestor_name end as requestor_name,
  case when requestor_email in ('nan', 'NaN') then null else requestor_email end as requestor_email,
  case when payment_type in ('nan', 'NaN') then null else payment_type end as payment_type,
  case when request_type in ('nan', 'NaN') then null else request_type end as request_type,
  case when learner_last_name in ('nan', 'NaN') then null else learner_last_name end as learner_last_name,
  case when customer_or_partner in ('nan', 'NaN') then null else customer_or_partner end as customer_or_partner,
  case when course_name in ('nan', 'NaN') then null else course_name end as course_name,
  case when preferred_time_zone in ('nan', 'NaN') then null else preferred_time_zone end as preferred_time_zone,
  case when virtual_or_onsite in ('nan', 'NaN') then null else virtual_or_onsite end as virtual_or_onsite,
  case when full_day_or_half_day_delivery in ('nan', 'NaN') then null else full_day_or_half_day_delivery end as full_day_or_half_day_delivery,
  case when preferred_class_dates in ('nan', 'NaN') then null else preferred_class_dates end as preferred_class_dates,
  case when preferred_class_time in ('nan', 'NaN') then null else preferred_class_time end as preferred_class_time,
  case when meeting_platform in ('nan', 'NaN') then null else meeting_platform end as meeting_platform,
  case when preferred_video_conference_tool in ('nan', 'NaN') then null else preferred_video_conference_tool end as preferred_video_conference_tool,
  case when company_name in ('nan', 'NaN') then null else company_name end as company_name,
  case when ff_psa_revenue_per_learner in ('nan', 'NaN') then null else ff_psa_revenue_per_learner end as ff_psa_revenue_per_learner,
  case when class_name in ('nan', 'NaN') then null else class_name end as class_name,
  case when status_from_class_name in ('nan', 'NaN') then null else status_from_class_name end as status_from_class_name,
  case when quarter_and_fy_from_class_name in ('nan', 'NaN') then null else quarter_and_fy_from_class_name end as quarter_and_fy_from_class_name,
  case when projects_from_class_name in ('nan', 'NaN') then null else projects_from_class_name end as projects_from_class_name,
  case when form_start_date_from_class_name in ('nan', 'NaN') then null else form_start_date_from_class_name end as form_start_date_from_class_name,
  case when form_end_date_from_class_name in ('nan', 'NaN') then null else form_end_date_from_class_name end as form_end_date_from_class_name,
  case when provider_from_class_name in ('nan', 'NaN') then null else provider_from_class_name end as provider_from_class_name,
  case when month_from_class_name in ('nan', 'NaN') then null else month_from_class_name end as month_from_class_name,
  case when num_enrollments_from_class_name in ('nan', 'NaN') then null else num_enrollments_from_class_name end as num_enrollments_from_class_name,
  case when docebo_session_code_from_class_name in ('nan', 'NaN') then null else docebo_session_code_from_class_name end as docebo_session_code_from_class_name,
  case when course_abbreviation_from_course_project_from_class_name in ('nan', 'NaN') then null else course_abbreviation_from_course_project_from_class_name end as course_abbreviation_from_course_project_from_class_name,
  case when start_date_from_class_name in ('nan', 'NaN') then null else start_date_from_class_name end as start_date_from_class_name,
  case when end_date_from_class_name in ('nan', 'NaN') then null else end_date_from_class_name end as end_date_from_class_name,
  case when region_from_class_name in ('nan', 'NaN') then null else region_from_class_name end as region_from_class_name,
  case when duration_days_from_class_name in ('nan', 'NaN') then null else duration_days_from_class_name end as duration_days_from_class_name,
  case when status in ('nan', 'NaN') then null else status end as status,
  case when last_modified_by_id in ('nan', 'NaN') then null else last_modified_by_id end as last_modified_by_id,
  case when last_modified_by_email in ('nan', 'NaN') then null else last_modified_by_email end as last_modified_by_email,
  case when last_modified_by_name in ('nan', 'NaN') then null else last_modified_by_name end as last_modified_by_name,
  case when date_last_modified_status in ('nan', 'NaN') then null else date_last_modified_status end as date_last_modified_status,
  case when company_contact_name_from_class_name in ('nan', 'NaN') then null else company_contact_name_from_class_name end as company_contact_name_from_class_name,
  case when ff_psa_milestone_id_from_class_name in ('nan', 'NaN') then null else ff_psa_milestone_id_from_class_name end as ff_psa_milestone_id_from_class_name,
  case when learner_time_zone in ('nan', 'NaN') then null else learner_time_zone end as learner_time_zone,
  case when databricks_academy_account in ('nan', 'NaN') then null else databricks_academy_account end as databricks_academy_account,
  case when docebo_session_url_from_class_name in ('nan', 'NaN') then null else docebo_session_url_from_class_name end as docebo_session_url_from_class_name,
  case when onboarding_pdf in ('nan', 'NaN') then null else onboarding_pdf end as onboarding_pdf,
  case when notes in ('nan', 'NaN') then null else notes end as notes,
  case when collaborator in ('nan', 'NaN') then null else collaborator end as collaborator,
  case when ff_psa_milestone_link in ('nan', 'NaN') then null else ff_psa_milestone_link end as ff_psa_milestone_link,
  case when date_last_modified_revenue in ('nan', 'NaN') then null else date_last_modified_revenue end as date_last_modified_revenue,
  case when ff_psa_revenue in ('nan', 'NaN') then null else ff_psa_revenue end as ff_psa_revenue,
  case when subscription_start_date in ('nan', 'NaN') then null else subscription_start_date end as subscription_start_date,
  case when subscription_end_date in ('nan', 'NaN') then null else subscription_end_date end as subscription_end_date,
  case when subscription_coupon_code_license in ('nan', 'NaN') then null else subscription_coupon_code_license end as subscription_coupon_code_license,
  case when docebo_learners_enrolled in ('nan', 'NaN') then null else docebo_learners_enrolled end as docebo_learners_enrolled,
  case when milestone_id_lookup in ('nan', 'NaN') then null else milestone_id_lookup end as milestone_id_lookup,
  case when pipeline_milestone_amount in ('nan', 'NaN') then null else pipeline_milestone_amount end as pipeline_milestone_amount,
  case when enrollment_list in ('nan', 'NaN') then null else enrollment_list end as enrollment_list,
  case when tr_subscriptions in ('nan', 'NaN') then null else tr_subscriptions end as tr_subscriptions,
  case when stage_from_ps_and_t_learning_subscriptions_all_time in ('nan', 'NaN') then null else stage_from_ps_and_t_learning_subscriptions_all_time end as stage_from_ps_and_t_learning_subscriptions_all_time,
  case when end_date_from_ps_and_t_learning_subscriptions_all_time in ('nan', 'NaN') then null else end_date_from_ps_and_t_learning_subscriptions_all_time end as end_date_from_ps_and_t_learning_subscriptions_all_time,
  case when start_date_from_ps_and_t_learning_subscriptions_all_time in ('nan', 'NaN') then null else start_date_from_ps_and_t_learning_subscriptions_all_time end as start_date_from_ps_and_t_learning_subscriptions_all_time,
  case when location in ('nan', 'NaN') then null else location end as location,
  case when certification_vouchers_customer in ('nan', 'NaN') then null else certification_vouchers_customer end as certification_vouchers_customer,
  case when enrollment_type in ('nan', 'NaN') then null else enrollment_type end as enrollment_type,
  case when number_of_licenses in ('nan', 'NaN') then null else number_of_licenses end as number_of_licenses,
  case when licenses_to_activate_now in ('nan', 'NaN') then null else licenses_to_activate_now end as licenses_to_activate_now,
  case when is_this_for_a_databricks_partner in ('nan', 'NaN') then null else is_this_for_a_databricks_partner end as is_this_for_a_databricks_partner,
  case when is_this_for_a_databricks_customer in ('nan', 'NaN') then null else is_this_for_a_databricks_customer end as is_this_for_a_databricks_customer,
  case when learner_end_date in ('nan', 'NaN') then null else learner_end_date end as learner_end_date,
  case when language in ('nan', 'NaN') then null else language end as language,
  case when alternative_time_zone in ('nan', 'NaN') then null else alternative_time_zone end as alternative_time_zone,
  case when ops_notes in ('nan', 'NaN') then null else ops_notes end as ops_notes,
  case when milestone_name_ff_psa_error in ('nan', 'NaN') then null else milestone_name_ff_psa_error end as milestone_name_ff_psa_error,
  case when access_to_slack in ('nan', 'NaN') then null else access_to_slack end as access_to_slack,
  case when ilt_schedule_copy in ('nan', 'NaN') then null else ilt_schedule_copy end as ilt_schedule_copy,
  case when tr_subscriptions_copy in ('nan', 'NaN') then null else tr_subscriptions_copy end as tr_subscriptions_copy,
  case when old_request_num in ('nan', 'NaN') then null else old_request_num end as old_request_num,
  case when old_submission_date in ('nan', 'NaN') then null else old_submission_date end as old_submission_date,
  case when pricing_and_payment in ('nan', 'NaN') then null else pricing_and_payment end as pricing_and_payment,
  case when voucher_batch_code in ('nan', 'NaN') then null else voucher_batch_code end as voucher_batch_code
from pre 
''')

# COMMAND ----------

# display(
#   training_requests_df
    
# )

# COMMAND ----------

training_requests_df_gold = add_gold_metadata(training_requests_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = training_requests_df_gold, 
  table_name = f'{focus_database_name}.training_requests_queue', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)