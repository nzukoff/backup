# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
# spark.conf.set("spark.network.timeout", "800s")             # default is 120s
# spark.conf.set("spark.executor.heartbeatInterval", "60s")   # default is 10s
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
from pyspark.sql.functions import coalesce


warnings.filterwarnings("ignore")

# from pprint import pprint
# from pyspark.sql import DataFrame, Column
# from typing import Optional, Sequence as Seq, Dict, Callable, Any

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# verbose = get_verbose_func(VERBOSE)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

spark.sql("select * from main.field_learning_enablement.partner_capability where  processdate= (select max(processdate) from main.field_learning_enablement.partner_capability)").dropDuplicates().createOrReplaceTempView("partner_capability_vw")

# COMMAND ----------

# DBTITLE 1,Partner Engagement Reporting Script
dates_raw = (
  spark.read.table("main.it_core_dim.bi_dates")
     .withColumn("fiscal_quarter_year", F.concat(F.lit("FY"), F.col('fiscalYear'), F.lit("Q"), F.col('fiscalQuarter')))
)

# Docebo Logfood data

gold_docebo_users_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.docebo_users",  "processDate")

docebo_users = (
  spark.read.table(f"{focus_database_name}.docebo_users")
    .filter(F.col("processDate") == gold_docebo_users_latest_process_date)
)

gold_docebo_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.self_paced_enrollments",  "processDate")


self_paced_enrollments = (
  spark.read.table(f"{focus_database_name}.self_paced_enrollments")
    .filter(F.col("processDate") == gold_docebo_latest_process_date)
    # .filter(F.col("learner_branch_code").isin(["DBK_MCSFT", "DBK_PRTNR"]))
    .filter(F.col("audience").isin(['Partner', 'Partner Other', 'Microsoft', 'Microsoft Other']))
    .withColumn("date", F.to_date(F.col("completed_timestamp")))
    .join(dates_raw, "date", "left")
    .drop("processDate", "account_id", "account_name", "ultimate_parent_account_id", "ultimate_parent_account_name")
    .withColumnRenamed("updated_account_id", "account_id")
    .withColumnRenamed("updated_account_name", "account_name")
    .withColumnRenamed("updated_ultimate_parent_account_id", "ultimate_parent_account_id")
    .withColumnRenamed("updated_ultimate_parent_account_name", "ultimate_parent_account_name")
)

ilt_enrollments = (
  spark.read.table(f"{focus_database_name}.ilt_enrollments")
    .filter(F.col("processDate") == gold_docebo_latest_process_date)
    # .filter(F.col("learner_branch_code").isin(["DBK_MCSFT", "DBK_PRTNR"]))
    .filter(F.col("audience").isin(['Partner', 'Partner Other', 'Microsoft', 'Microsoft Other']))
    .withColumn("date", F.to_date(F.col("completed_timestamp")))
    .join(dates_raw, "date", "left")
    .drop("processDate", "account_id", "account_name", "ultimate_parent_account_id", "ultimate_parent_account_name")
    .withColumnRenamed("updated_account_id", "account_id")
    .withColumnRenamed("updated_account_name", "account_name")
    .withColumnRenamed("updated_ultimate_parent_account_id", "ultimate_parent_account_id")
    .withColumnRenamed("updated_ultimate_parent_account_name", "ultimate_parent_account_name")
)

accredible_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.accredible_credentials",  "processDate")


partner_badges = (
  spark.table(f"{focus_database_name}.accredible_credentials")
    .filter(F.col("processDate") == accredible_latest_process_date)
    # .filter(F.col("learner_branch_code").isin(["DBK_PRTNR", "DBK_MCSFT"]))
    .filter(F.col("audience").isin(['Partner', 'Partner Other', 'Microsoft', 'Microsoft Other']))
    .withColumnRenamed("issued_on", "date")
    .join(dates_raw, "date", "left")
    .withColumn("fiscal_quarter_year", F.concat(F.lit("FY"), F.col("fiscalYear"), F.lit("Q"), F.col("fiscalQuarter")))
    .drop("processDate", "account_id", "account_name", "ultimate_parent_account_id", "ultimate_parent_account_name")
    .withColumnRenamed("updated_account_id", "account_id")
    .withColumnRenamed("updated_account_name", "account_name")
    .withColumnRenamed("updated_ultimate_parent_account_id", "ultimate_parent_account_id")
    .withColumnRenamed("updated_ultimate_parent_account_name", "ultimate_parent_account_name")
)

#sfdc data

sfdc_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.account",  "processDate")


sfdc_users = (
  spark
    .table(f"main.sfdc_bronze.user")
    .filter(F.col("processDate") == sfdc_latest_process_date)
    .select(F.col("Id").alias("partner_manager_id"), F.col("Name").alias("partner_manager"))
)

sfdc_account = (
  spark
    .table(f"main.sfdc_bronze.account")
    .filter(F.col("processDate") == sfdc_latest_process_date)
    .select(
      F.col("Id").alias("ultimate_parent_account_id"), 
      F.col("Partner_Manager__c").alias("partner_manager_id"), 
      F.col("BillingCountry").alias("billing_country"), 
      F.col("Partner_Level__c").alias("partner_level"),
      F.col("Partner_Tier__c").alias("partner_tier")
      
    )
    .join(sfdc_users, "partner_manager_id", "left")
    .select("ultimate_parent_account_id", "partner_manager", "billing_country", "partner_level", "partner_tier")
)

#Sales Data

# sales_legacy_raw = spark.table("scott_smith_databricks_com_db.sales_training_raw")
sales_legacy_raw = spark.table("users.nathan_zukoff.sales_training_raw")

silver_docebo_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_salesforce_account_email_domain_mapping",  "processDate")


salesforce_account_email_domain_mapping = (
  spark.read.table("main.it_training_silver.docebo_salesforce_account_email_domain_mapping")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

sfdc_accounts = (
  spark.read.table("main.sfdc_bronze.account")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

# Blacklisted domains

blacklist_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.blacklist_domains",  "processDate")

blacklist_domains = (
  # spark.read.table("user_success_dev.blacklist_domains")
  spark.read.table(f"{focus_database_name}.blacklist_domains")
    .filter(F.col("processDate") == blacklist_latest_process_date)
)

blacklist = [domain["blacklist_domain"] for domain in blacklist_domains.collect()]


# COMMAND ----------

# DBTITLE 1,Partner Domain Mapping Generator

mapping_window = W.Window.partitionBy("email_domain").orderBy(F.desc("total_for_email_and_account"), "tiebreak")

accounts_df = (
  sfdc_accounts
    .select(
      F.col("Id").alias("ultimate_parent_account_id"),
      F.col("Name").alias("ultimate_parent_account_name")
    )
)

account_names = (
  sfdc_accounts
    .select(
      F.col("Id").alias("account_id"),
      F.col("ParentId").alias("ultimate_parent_account_id")
    )
    .join(accounts_df, "ultimate_parent_account_id", "left")
)

unique_partner_mappings_pre = (
    salesforce_account_email_domain_mapping
    # filter for partner domains
    .filter(F.col("account_record_type") == "Partner")
    # keep only domains that appear more than 5 times
    .filter(F.col("total_for_email_and_account") >= 5)
    # filter out null domains
    .filter(F.col("email_domain").isNotNull())
    # find most common account for each domain
    .filter(F.col("email_domain") != 'microsoft.com')
    .filter(~F.col("email_domain").isin(blacklist))
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(mapping_window))
    .filter(F.col("rank") == 1)
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

msft_mapping_schema = (
  T.StructType([
    StructField("email_domain_final", T.StringType()),
    StructField("account_id", T.StringType()),
    StructField("account_name", T.StringType()),
    StructField("ultimate_parent_account_id", T.StringType()),
    StructField("ultimate_parent_account_name", T.StringType()),
  ])
)

msft_data = [
  ("microsoft.com", "00161000005eOdjAAE", "Microsoft", "0014N00002BAYhLQAX", "Microsoft Consulting Services")
]

msft_mapping = (
  spark.createDataFrame(msft_data, msft_mapping_schema)
)

unique_partner_mappings = (
  unique_partner_mappings_pre
    .union(msft_mapping)
)

# COMMAND ----------

#unit tests to make sure dfs are pulled correctly
assert unit_test_df_count(sfdc_account) > 0

# unit tests to make sure parameters are set up correctly
catalog, database = focus_database_name.split('.')
assert unit_test_valid_db(database, spark, catalog)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

partner_technical_ilt = ["Azure Databricks Core Technical Training",
"Azure Databricks Core Technical Virtual Training",
"AWS Databricks Core Technical Virtual Training",
"Azure Databricks Advanced Technical Virtual Training",
"AWS Databricks Core Technical Training",
"Scalable Machine Learning with Apache Spark™ Virtual Training",
"Deloitte - Custom DB 105 | DB 110",
"Databricks Partners: Training Cohorts",
"Databricks Partners: Core Technical Series",
"Azure Databricks Advanced Technical + Hadoop Migration Virtual Training", 
"Core Technical Series",
"Core Technical Series (Private Training)",
"Scalable Machine Learning with Apache Spark™ (Partner) (RETIRED)",
"Scalable Machine Learning with Apache Spark™ (Private Partner)",
"Azure Databricks Advanced Technical and Hadoop Migration Training",
"Core Technical Series: Advanced Data Engineering with Databricks (Partner)",
"Azure Databricks Advanced Technical and Hadoop Migration Training (Private Training)",
"Machine Learning in Production (Private ILT)",
"Optimizing Apache Spark™ on Databricks (Private ILT)",
"Scalable Machine Learning with Apache Spark™ (ILT)",
"Data Engineering with Databricks (Private ILT)",
"Apache Spark™ Programming with Databricks (ILT)",
"Data Engineering with Databricks (ILT)",
"Deep Learning with Databricks (Partner)",
"Data Engineering with Databricks (Private Partner)",
"Advanced Data Engineering with Databricks (Private Partner)",
"Machine Learning in Production (ILT)",
"Data Engineering with Databricks (Private ILT) (RETIRED)",
"Data Engineering with Databricks (ILT) (RETIRED)", 
"Core Technical Series: Data Engineering with Databricks (Partner)",
"Core Technical Series: Data Engineering with Databricks (Private Partner)",
"Scalable Machine Learning with Apache Spark™ (Private ILT)",
"Advanced Data Engineering with Databricks (Partner)",
"Optimizing Apache Spark™ on Databricks (ILT)",
"Data Engineering with Databricks (Partner)",
"Deep Learning with Databricks (Private ILT)",
"Apache Spark™ Programming with Databricks (Private ILT)",
"ELEVATE Training Series: Databricks for Data Analysts",
"ELEVATE Training Series: Databricks for Data Engineers",
"ELEVATE Training Series: Databricks for Machine Learning Practitioners"
]

technical_self_paced_list = [
  {'course_name': 'Apache Spark Programming with Databricks',                     'course_code': 'aC13f000000004rCAA'},
  {'course_name': 'Apache Spark™ Programming with Databricks',                    'course_code': 'ACAD-ALL-SLP-v3-FREE-ASPWD-ACT'},
  {'course_name': 'Data Engineering with Databricks',                             'course_code': 'aC13f000000005uCAA'},
  {'course_name': 'Scalable Machine Learning with Apache Spark',                  'course_code': 'aC13f00000000A6CAI'},
  {'course_name': 'Data Science on Databricks Rapidstart',                        'course_code': 'aC13f000000003ECAQ'},
  {'course_name': 'Data Science on Databricks: The Bias-Variance Tradeoff',       'course_code': 'aC13f0000000052CAA'},
  {'course_name': 'Deploying a Machine Learning Project with MLflow Projects',    'course_code': 'aC13f0000000051CAA'},
  {'course_name': 'Tracking Experiments with MLflow',                             'course_code': 'ACAD-ALL-SLP-v1-FREE-TEXPMLF-ACT'},
]

technical_self_paced = [course['course_name'] for course in technical_self_paced_list]

technical_sales_ilt_list = [
  {'course_name': 'Modernizing Financial Risk Management with Databricks - Virtual Training',     'course_code': 'aC13f0000000039CAA'},
  {'course_name': 'Generating Reliable Inventory Forecasts with Databricks - Virtual Training',   'course_code': 'aC13f0000000034CAA'},
  {'course_name': 'Partner Solutions Architect Essentials - Virtual Training',                    'course_code': 'aC13f000000003OCAQ'},
  {'course_name': 'Partner Solutions Architect Essentials (Partner)',                             'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-PSAE'},
  {'course_name': 'Partner Solutions Architect Essentials (Private Partner)',                     'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-PSAE-ACT'},
  {'course_name': 'Partner Solutions Architect Essentials (Partner) (RETIRED)',                   'course_code': 'ACAD-PART-ILT-v1-FREE-PSAE-RET'},
  {'course_name': 'Hadoop Migration Architecture V2',                                             'course_code': 'ACAD-PART-SLP-v2-FREE-HADOOPMIG-ACT'},
]

technical_sales_ilt = [course['course_name'] for course in technical_sales_ilt_list]

business_ess_courses_list = [
  {'course_name': 'Partner Intro',                                                        'course_code': 'PARS-PARTNER-INTRO'},
  {'course_name': 'Databricks Partner Program Overview',                                  'course_code': 'PARS-DBPART-OVERVIEW'},
  {'course_name': 'Consulting & SI Partner POV Why Partner with Databricks',              'course_code': 'PARS-POV-WHYDB'},
  {'course_name': 'Partner Services Opportunity',                                         'course_code': 'PARS-PSV-OPP'},
  {'course_name': 'Persona - Data Scientist',                                             'course_code': 'PARS-PERSONA-DS'},
  {'course_name': 'Persona - Data Engineer',                                              'course_code': 'PARS-PERSONA-DE'},
  {'course_name': 'Databricks Security',                                                  'course_code': 'PARS-DB-SECURITY'},
  {'course_name': 'SI Partners Win with Databricks on AWS',                               'course_code': 'PARS-DB-AWSWIN'},
  {'course_name': 'Azure Databricks and Partners',                                        'course_code': 'PARS-AZURE-DBP'},
  {'course_name': 'Databricks: The Data and AI Company',                                  'course_code': 'PARS-DB-UDAP'},
  {'course_name': 'The Partner Process - Better Together',                                'course_code': 'PARS-BETTER-TOGETHER'},
  {'course_name': 'Demo - Intro into Databricks',                                         'course_code': 'PARS-DEMO-INTDB'},
  {'course_name': 'Product - Delta Lake',                                                 'course_code': 'PARS-PROD-DELTA'},
  {'course_name': 'Product - Run Time + Spark 3.0 Preview',                               'course_code': 'PARS-PROD-RTS3'},
  {'course_name': 'Product - Managed MLflow',                                             'course_code': 'PARS-PROD-MLFLOW'},
  {'course_name': 'Demo - Operationalizing Data Science and Machine Learning',            'course_code': 'PARS-DEMO-ODSML'},
  {'course_name': 'Demo - Data + AI Tour - SQL Analytics on all of your Data',            'course_code': 'PARS-DEMO-DAITSQLA'},
  {'course_name': 'Demo - Next Gen. Data Science Workspace',                              'course_code': 'PARS-DEMO-NGDSW'},
  {'course_name': 'Demo - Koalas',                                                        'course_code': 'PARS-DEMO-KOALAS'},
  {'course_name': 'Demo - Redash',                                                        'course_code': 'PARS-DEMO-REDASH'},
  {'course_name': 'Demo - Azure Databricks',                                              'course_code': 'PARS-DEMO-AZUREDB'},
]

business_ess_courses = [course['course_code'] for course in business_ess_courses_list]

sales_self_paced_list = [
  {'course_name': 'Hadoop Migration Partner Badge - All Clouds',                                                                'course_code': 'PARS - Hadoop Migration Partner Badge - All Clouds'},
  {'course_name': 'EDW-ETL Pre-Sales Migration Partner Badge - All Clouds',                                                     'course_code': 'PARS - EDW Migration Partner Badge - All Clouds'},
  {'course_name': 'Databricks Partner Essentials',                                                                              'course_code': 'PARS - DATABRICKS PARTNER ESSENTIALS'},
  {'course_name': '(Verified) Snowflake to Lakehouse Migration Badge',                                                          'course_code': 'PARS - Snowflake to Lakehouse Migration Verified'},
  {'course_name': 'Snowflake to Lakehouse Migration PreSales Partner Badge',                                                    'course_code': 'PARS - Snowflake to Lakehouse Migration PreSales '},
  {'course_name': '(Leadership) Advantages of the Lakehouse',                                                                   'course_code': 'PARS - (Leadership) Advantages of the Lakehouse'},
  {'course_name': 'Fundamentals of the Databricks Lakehouse Platform Accreditation',                                            'course_code': 'ACAD-ALL-SLP-v1-FREE-FDBLPACC-RET'},
  {'course_name': 'Fundamentals of the Databricks Lakehouse Platform Accreditation (V2)',                                       'course_code': 'ACAD-ALL-SLP-v3-FREE-FODLP-ACT'},
  {'course_name': 'Generative AI Fundamentals Accreditation',                                                                   'course_code': 'ACAD-ALL-SLP-v1-FREE-GENAIACCRED-ACT'},
  {'course_name': 'Cloud Native SPARK Migration PreSales Partner Badge',                                                        'course_code': 'PARS - Cloud Native SPARK Migration Partner Badge'},
  {'course_name': '(Verified) Cloud Native SPARK Migration Partner Badge',                                                      'course_code': 'PARS - Cloud Native SPARK Migration Verified'},
  {'course_name': 'Data & AI Governance with Unity Catalog PreSales Partner Badge',                                             'course_code': 'PARS - Data&AI Gov. with UC PreSales Partner Badge'},
  {'course_name': '(Verified) Data & AI Governance with Unity Catalog PreSales Partner Badge',                                  'course_code': 'PARS - Data & AI Gov w/UC PreSales Partner Badge'},
  {'course_name': 'Data Intelligence Platform Whiteboard',                                                                      'course_code': 'PARS - (Leadership) DI Platform Whiteboard'},
  {'course_name': '(Leadership) Advantages of Data & AI Goverance',                                                             'course_code': 'PARS - (Leadership) Adv Data & AI Governance '},
  {'course_name': '(Leadership) Advantages of Azure Databricks & Microsoft Fabric',                                             'course_code': 'PARS - (Leadership) Advantages of Azure DB & Fab'},
  {'course_name': '(On Demand) Sales Ready - The Keys to 10X Multiplier of Partner Services Revenue with Databricks - FY25',    'course_code': 'PARS- Sales Ready 10X - FY25'},
  {'course_name': '(Leadership) Advantages of Gen AI on Databricks',                                                            'course_code': 'PARS - (Leadership) Adv. of Data & AI Governance'},
  {'course_name': 'Gen AI & LLM on Databricks PreSales Partner Badge',                                                          'course_code': 'PARS - Gen AI & LLM on DB PreSales Partner Badge'},
  {'course_name': '(Verified) Gen AI on Databricks Partner Badge',                                                              'course_code': 'PARS - (Verified) Gen AI on DB Partner Badge'},
  {'course_name': 'EDW-ETL Migration to the Data Intelligence Platform Partner Presales Badge',                                 'course_code': 'PARS - EDW-ETL Migration to DI Plat Partner Badge'},
  {'course_name': 'Winning the Lakehouse 101',                                                                                  'course_code': 'MSFT-ADB-WTL101'},
  {'course_name': 'Workflows 101',                                                                                              'course_code': 'MSFT-ADB-WF101'},
  {'course_name': 'Databricks Machine Learning 101',                                                                            'course_code': 'MSFT-ADB-DSML101'},
  {'course_name': 'DBSQL 101',                                                                                                  'course_code': 'MSFT-ADB-DBSQL101'},
  {'course_name': 'Streaming & DLT 101',                                                                                        'course_code': 'MSFT-ADB-SDLT101'},
  {'course_name': 'Unity Catalog 101',                                                                                          'course_code': 'MSFT-ADB-UC101'},
  {'course_name': 'Delta Lake 101',                                                                                             'course_code': 'MSFT-ADB-DL101'},
  {'course_name': 'Azure Lakehouse 101',                                                                                        'course_code': 'MSFT-ADB-LK101'},
  {'course_name': 'Pitching Azure Databricks: Delivery of Better Together',                                                     'course_code': 'SLEN-BB-PAR-HDBSGP-AZU-018'},
  {'course_name': 'How Databricks Sellers Get Paid',                                                                            'course_code': 'SLEN-BB-PAR-HDBSGP-AZU-017'},
  {'course_name': 'Leveraging funding for Azure Databricks',                                                                    'course_code': 'SLEN-BB-PAR-LFFADB-AZU-019'},
  {'course_name': '(Verified) EDW-ETL Migration to the Data Intelligence Platform Badge',                                       'course_code': 'PARS - (Verified) EDW-ETL Mig. to DI Platform '},
  {'course_name': '(Exclusive) LIVE Partner Leadership Badge 9/13 at 9am IST Expanding EDW with Data Intelligence',             'course_code': 'PARS - (Leadership)  ILT Adv. of Exp EDW with DI'},
  {'course_name': '(Leadership) Advantages of Expanding on EDW with Data Intelligence',                                         'course_code': 'PARS - (Leadership) Adv. of Expanding EDW with DI'},
  {'course_name': '(Leadership) Advantages of Being GTM Ready and the Art of the Possible',                                     'course_code': 'PARS - (Leadership) Ad.v of Being GTM Ready '},
  {'course_name': '(Industry) Energy Gen AI & LLM on Databricks PreSales Partner Badge',                                        'course_code': 'PARS - (Industry) Energy Gen AI &LLM on DB '},
  {'course_name': '(Industry) FSI Gen AI & LLM on Databricks PreSales Partner Badge',                                           'course_code': 'PARS - (Industry) FSI Gen AI & LLM on Databricks '},
  {'course_name': '(Industry) Comm. Media & Ent. Gen AI & LLM on Databricks PreSales Partner Badge',                            'course_code': 'PARS - (Industry) Com,Media, Ent Gen AI&LLM on DB '},
  {'course_name': '(Industry) Retail & Consumer Goods Gen AI & LLM on Databricks PreSales Partner Badge',                       'course_code': 'PARS - (Industry) RCG Gen AI & LLM on Databricks '},
  {'course_name': '(Industry) HLS Gen AI & LLM on Databricks PreSales Partner Badge',                                           'course_code': 'PARS - (Industry) HLS Gen AI & LLM on Databricks '},
  {'course_name': '(Industry) Manufacturing & Transportation Gen AI & LLM on Databricks PreSales Partner Badge',                'course_code': 'PARS - (Industry) MFG & Trans Gen AI & LLM on DB '},
  {'course_name': '(Leadership) Advantages of Data Intelligence & Interoperability with SAP',                                   'course_code': 'PARS - (Leadership) Adv. of DI & Interop w/ SAP '},
  {'course_name': 'Azure Databricks Selling Foundations',                                                                       'course_code': 'SLEN-ADBSF-SLP-ENG'},
  {'course_name': 'SAP GTM Foundations for Partners',                                                                           'course_code': 'PARS - SAP GTM Foundations for Partners'},
  {'course_name': '(Leadership) Advantages of Tech Readiness & Data Intelligence',                                              'course_code': 'PARS - (Leadership) Advantages of Tech Readiness '},
  {'course_name': '(Leadership) Advantages of Gen AI with Data Intelligence',                                                   'course_code': 'PARS - (Leadership) Adv. of Gen AI with DI'},
  {'course_name': '(Leadership) Industry in Action',                                                                            'course_code': 'PARS - (Leadership) Industry in Action'},
  {'course_name': '2025 Data + AI Summit Product Announcement Enablement for Partners',                                         'course_code': 'PARS-DAIS-2025'},
  {'course_name': 'Lakebridge for SQL Source System Migration',                                                                 'course_code': 'PART-SP-LSTDD-v1'},
  
]

sales_self_paced = [course['course_code'] for course in sales_self_paced_list]

technical_partner_badges_list = [
  {'credential_name': 'Databricks Certified Data Engineer Associate',                   'group_id': '353856'},
  {'credential_name': 'Databricks Certified Data Engineer Professional',                'group_id': '331743'},
  {'credential_name': 'Databricks Certified Data Scientist Professional',               'group_id': '227970'},
  {'credential_name': 'Databricks Certified Machine Learning Associate',                'group_id': '371215'},
  {'credential_name': 'Databricks Certified Machine Learning Professional',             'group_id': '357057'},
  {'credential_name': 'Partner Program -  Developer Champion',                          'group_id': '231242'},
  {'credential_name': 'Partner Training - Azure Databricks Developer Essentials',       'group_id': '229948'},
  {'credential_name': 'Partner Training - Developer Essentials',                        'group_id': '230012'},
  {'credential_name': 'Partner Training - Developer Foundations',                       'group_id': '247511'},
]

technical_partner_badges = [cred['group_id'] for cred in technical_partner_badges_list]

technical_sales_badges_list = [
  {'credential_name': 'Partner Program - Solutions Architect Champion',       'group_id': '231241'},
  {'credential_name': 'Partner Training - Solutions Architect Essentials',    'group_id': '231328'},
  {'credential_name': 'Databricks Certified Hadoop Migration Architect',      'group_id': '416340'},
]

technical_sales_badges = [cred['group_id'] for cred in technical_sales_badges_list]

total_num_badges_list = [
  {'credential_name': 'Databricks Certified Data Engineer Associate',                           'group_id': '353856'},
  {'credential_name': 'Azure Databricks Certified Associate Platform Administrator',            'group_id': '255536'},
  {'credential_name': 'Databricks Certified Data Analyst Associate',                            'group_id': '364119'},
  {'credential_name': 'Databricks Certified Associate Developer for Apache Spark 2.4',          'group_id': '227818'},
  {'credential_name': 'Databricks Certified Machine Learning Professional',                     'group_id': '357057'},
  {'credential_name': 'Partner Training - Developer Essentials',                                'group_id': '230012'},
  {'credential_name': 'Partner Program - Solutions Architect Champion',                         'group_id': '231241'},
  {'credential_name': 'Partner Training - Solutions Architect Essentials',                      'group_id': '231328'},
  {'credential_name': 'Databricks Certified Associate Developer for Apache Spark 3.0',          'group_id': '227965'},
  {'credential_name': 'Partner Training - Business Essentials',                                 'group_id': '238118'},
  {'credential_name': 'Partner Training - Sales Ready',                                         'group_id': '237937'},
  {'credential_name': 'Partner Program -  Developer Champion',                                  'group_id': '231242'},
  {'credential_name': 'Databricks Certified Data Engineer Professional',                        'group_id': '331743'},
  {'credential_name': 'Databricks Certified Machine Learning Associate',                        'group_id': '371215'},
  {'credential_name': 'Partner Training - Azure Databricks Developer Essentials',               'group_id': '229948'},
  {'credential_name': 'Databricks Certified Associate ML Practitioner for Apache Spark 2.4',    'group_id': '229201'},
  {'credential_name': 'Databricks Certified Data Scientist Professional',                       'group_id': '227970'},
  {'credential_name': 'Partner Training - Developer Foundations',                               'group_id': '247511'},
]

total_num_badges = [cred['group_id'] for cred in total_num_badges_list]

champion_badges_list = [
  {'credential_name': 'Partner Program - Solutions Architect Champion',     'group_id': '231241'},
  {'credential_name': 'Partner Program -  Developer Champion',              'group_id': '231242'},
]

champion_badges = [cred['group_id'] for cred in champion_badges_list]

sales_badges_list = [
  {'credential_name': 'Partner Training - Business Essentials',                                                               'group_id': '238118'},
  {'credential_name': 'Partner Training - Sales Ready',                                                                       'group_id': '237937'},
  {'credential_name': 'Partner Training - Sales Hadoop Migration - All Clouds',                                               'group_id': '385601'},
  {'credential_name': 'PT - Presales EDW-ETL Migration',                                                                      'group_id': '428755'},
  {'credential_name': 'Partner Training - Partner Essentials',                                                                'group_id': '416015'},
  {'credential_name': 'Partner Training - Advantages of the Lakehouse',                                                       'group_id': '473387'},
  {'credential_name': 'PT-Snowflake to Lakehouse Migration',                                                                  'group_id': '473403'},
  {'credential_name': 'PT-Snowflake Migration',                                                                               'group_id': '473415'},
  {'credential_name': 'Partner Training - Spark Migration',                                                                   'group_id': '511547'},
  {'credential_name': 'Partner Training - Cloud Native SPARK Migration(Verified)',                                            'group_id': '514772'},
  {'credential_name': 'PT-Data & AI Governance with Unity Catalog',                                                           'group_id': '524251'},
  {'credential_name': 'PARS - Data & AI Gov w/UC PreSales Partner Badge',                                                     'group_id': '526887'},
  {'credential_name': 'PT-Data Intelligence Platform Whiteboard',                                                             'group_id': '545340'},
  {'credential_name': 'PT-Advantages of Data & AI Governance',                                                                'group_id': '562532'},
  {'credential_name': 'PT-Advantages of Azure Databricks & Microsoft Fabric',                                                 'group_id': '564495'},
  {'credential_name': 'PT-Advantages of Gen AI & LLM',                                                                        'group_id': '582711'},
  {'credential_name': 'PT-Gen AI & LLM on Databricks',                                                                        'group_id': '592281'},
  {'credential_name': 'PT-Gen AI & LLM on Databricks (Verified)',                                                             'group_id': '595574'},
  {'credential_name': 'PT - EDW-ETL Migration to the Data Intelligence Platform Partner Presales Badge',                      'group_id': '611713'},
  {'credential_name': 'PT-EDW-ETL Migration to the Data Intelligence Platform (Verified)',                                    'group_id': '615200'},
  {'credential_name': 'PT-Advantages of Expanding EDW with Data Intelligence',                                                'group_id': '622072'},
  {'credential_name': 'PT-Advantages of Being GTM Ready',                                                                     'group_id': '639408'},
  {'credential_name': 'Partner Training - Communication, Media & Entertainment Industry Specialization for Gen AI & LLM',     'group_id': '665841'},
  {'credential_name': 'Partner Training - Financial Services Industry Specialization for Gen AI & LLM',                       'group_id': '665839'},
  {'credential_name': 'Partner Training - Retail and Consumer Goods Industry Specialization for Gen AI & LLM',                'group_id': '665834'},
  {'credential_name': 'Partner Training - Energy Industry Specialization for Gen AI & LLM',                                   'group_id': '665836'},
  {'credential_name': 'Partner Training - Manufacturing & Transportation Industry Specialization for Gen AI & LLM',           'group_id': '665837'},
  {'credential_name': 'Partner Training - Healthcare & LIfe Sciences Industry Specialization for Gen AI & LLM',               'group_id': '665838'},
  {'credential_name': 'Partner Training - Advantages of Data Intelligence & Interoperability with SAP',                       'group_id': '679305'},
  {'credential_name': 'Partner Training - Azure Databricks GTM Foundations',                                                  'group_id': '682370'},
  {'credential_name': 'Partner Training - SAP Databricks GTM Foundations',                                                    'group_id': '688634'},
  {'credential_name': 'Academy Accreditation - Generative AI Fundamentals',                                                   'group_id': '473432'},
  {'credential_name': 'Partner Training - Advantages of Tech Readiness & Data Intelligence',                                  'group_id': '698774'},

  {'credential_name': 'Academy Accreditation - Platform Administrator',                                  'group_id': '405160'},
  {'credential_name': 'Academy Accreditation - Databricks Fundamentals',                                  'group_id': '547441'},
  {'credential_name': 'Academy Accreditation - Databricks Lakehouse Fundamentals',                                  'group_id': '296467'},
  {'credential_name': 'Academy Accreditation - GCP Databricks Platform Architect',                                  'group_id': '479290'},
  {'credential_name': 'Academy Accreditation - AWS Databricks Platform Architect',                                  'group_id': '479297'},
  {'credential_name': 'Academy Accreditation - Azure Databricks Platform Architect',                                  'group_id': '479298'},
  {'credential_name': 'Academy Accreditation - AI Security Fundamentals',                                  'group_id': '667100'},


  {'credential_name': 'Partner Training - Advantages of Gen AI with Data Intelligence',                                       'group_id': '705063'},
  {'credential_name': 'Partner Training - Industry Leadership in Action',                                                     'group_id': '713198'},
  {'credential_name': 'Partner Training - 2025 Data + AI Summit Product Announcement Enablement for Partners',                'group_id': '713941'},
  {'credential_name': 'Partner Training - Lakebridge for SQL Source Migration (Verified)',                                    'group_id': '734433'},
  {'credential_name': 'KB - Selling & Winning for Partners: Gen AI',                                       'group_id': '747184'},
  {'credential_name': 'KB - Selling & Winning for Partners: Data Engineering',                                       'group_id': '749597'},
  {'credential_name': 'Academy Accreditation - AI Agent Fundamentals',                                       'group_id': '739543'},

]

sales_badges = [cred['group_id'] for cred in sales_badges_list]

certification_badges_list = [
  {'credential_name': 'Databricks Certified Data Engineer Associate',                             'group_id': '353856'},
  {'credential_name': 'Databricks Certified Data Analyst Associate',                              'group_id': '364119'},
  {'credential_name': 'Databricks Certified Associate Developer for Apache Spark 2.4',            'group_id': '227818'},
  {'credential_name': 'Databricks Certified Machine Learning Professional',                       'group_id': '357057'},
  {'credential_name': 'Databricks Certified Associate Developer for Apache Spark 3.0',            'group_id': '227965'},
  {'credential_name': 'Databricks Certified Data Engineer Professional',                          'group_id': '331743'},
  {'credential_name': 'Databricks Certified Machine Learning Associate',                          'group_id': '371215'},
  {'credential_name': 'Databricks Certified Associate ML Practitioner for Apache Spark 2.4',      'group_id': '229201'},
  {'credential_name': 'Databricks Certified Data Scientist Professional',                         'group_id': '227970'},
  {'credential_name': 'Databricks Certified Generative AI Engineer Associate',                    'group_id': '583499'},
]

certification_badges = [cred['group_id'] for cred in certification_badges_list]

# COMMAND ----------

delivery_specialization_list = [
  {'credential_name': 'UC Upgrade Delivery Specialization',                             'group_id': '628550'},
  {'credential_name': 'EDW Migration Delivery Specialization',                             'group_id': '655788'},
  {'credential_name': 'CDW Migration Delivery Specialization',                             'group_id': '655781'},
]

delivery_specialization = [cred['group_id'] for cred in delivery_specialization_list]

# COMMAND ----------


# {'course_name': 'Winning the Lakehouse 101', 'course_code': 'MSFT-ADB-WTL101'},
# {'course_name': 'Workflows 101', 'course_code': 'MSFT-ADB-WF101'},
# {'course_name': 'Databricks Machine Learning 101', 'course_code': 'MSFT-ADB-DSML101'},
# {'course_name': 'DBSQL 101', 'course_code': 'MSFT-ADB-DBSQL101'},
# {'course_name': 'Streaming & DLT 101', 'course_code': 'MSFT-ADB-SDLT101'},
# {'course_name': 'Unity Catalog 101', 'course_code': 'MSFT-ADB-UC101'},
# {'course_name': 'Delta Lake 101', 'course_code': 'MSFT-ADB-DL101'},
# {'course_name': 'Azure Lakehouse 101', 'course_code': 'MSFT-ADB-LK101'},
# {'course_name': 'Pitching Azure Databricks: Delivery of Better Together', 'course_code': 'SLEN-BB-PAR-HDBSGP-AZU-018'},
# {'course_name': 'How Databricks Sellers Get Paid', 'course_code': 'SLEN-BB-PAR-HDBSGP-AZU-017'},
# {'course_name': 'Leveraging funding for Azure Databricks', 'course_code': 'SLEN-BB-PAR-LFFADB-AZU-019'},

# COMMAND ----------

technical_trained_list = [
  {'course_name': 'Data Analysis with Databricks SQL (ILT)',                                                'course_code': 'ACAD-CUST-ILTPUB-v1-PAID-DAWD-ACT'},
  {'course_name': 'Data Analysis with Databricks SQL (Partner)',                                            'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-DAWD-ACT'},
  {'course_name': 'Data Analysis with Databricks SQL (Private ILT)',                                        'course_code': 'ACAD-CUST-ILTPRV-v1-PAID-DAWD-ACT'},
  {'course_name': 'Data Analysis with Databricks SQL (Private Partner)',                                    'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-DAWD-ACT'},
  {'course_name': 'Data Analysis with Databricks SQL',                                                      'course_code': 'ACAD-ALL-SLP-v2-FREE-DAWD-ACT'},
  {'course_name': 'DAIS 2022 Data Analysis with Databricks SQL',                                            'course_code': 'ACAD-CUST-ILTUS-v1-PAID-DAIS22DAWD-ACT'},
  {'course_name': 'Data Engineering with Databricks (ILT) (RETIRED)',                                       'course_code': 'ACAD-ALL-ILTPUB-v1-PAID-DEWDOLD-RET'},
  {'course_name': 'Data Engineering with Databricks (ILT)',                                                 'course_code': 'ACAD-ALL-ILTPUB-v2-PAID-DEWD-ACT'},
  {'course_name': 'Data Engineering with Databricks (Partner)',                                             'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-DEWD-ACT'},
  {'course_name': 'Data Engineering with Databricks (Private ILT) (RETIRED)',                               'course_code': 'ACAD-ALL-ILTPRV-v1-PAID-DEWDOLD-RET'},
  {'course_name': 'Data Engineering with Databricks (Private ILT)',                                         'course_code': 'ACAD-ALL-ILTPRV-v2-PAID-DEWD-ACT'},
  {'course_name': 'Core Technical Series: Data Engineering with Databricks (Private Partner)',              'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-DEWD-ACT'},
  {'course_name': 'Core Technical Series: Data Engineering with Databricks (Private Partner)',              'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-DEWD-ACT'},
  {'course_name': 'Data Engineering with Databricks V2',                                                    'course_code': 'ACAD-ALL-SLP-v2-FREE-DEWD-ACT'},
  # {'course_name': 'Data Engineering with Databricks V3',                                                    'course_code': 'ACAD-ALL-SLP-v3-FREE-DEWD-ACT'},
  {'course_name': 'Data Engineering with Databricks V3 (RETIRED)',                                          'course_code': 'ACAD-ALL-SLP-v3-FREE-DEWD-RET'},
  {'course_name': 'Data Engineering with Databricks',                                                       'course_code': 'ACAD-PART-ILTPVT-FREE-DEWD-V4'},
  {'course_name': 'Data Engineering with Databricks',                                                       'course_code': 'ACAD-PART-ILTPUB-FREE-DEWD-v4'},
  {'course_name': 'DAIS 2022 Data Engineering with Databricks',                                             'course_code': 'ACAD-CUST-ILTUS-v1-PAID-DAIS22DEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks (ILT)',                                        'course_code': 'ACAD-CUST-ILTPUB-v1-PAID-ADEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks (Partner)',                                    'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-ADEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks (Private ILT)',                                'course_code': 'ACAD-CUST-ILTPRV-v1-PAID-ADEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks (Private Partner)',                            'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-ADEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks (Partner)',                                    'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-ADEWD-ACT'},
  {'course_name': 'Advanced Data Engineering with Databricks',                                              'course_code': 'ACAD-ALL-SLP-v2-FREE-ADEWD-ACT'},
  {'course_name': 'DAIS 2022 Advanced Data Engineering with Databricks',                                    'course_code': 'ACAD-CUST-ILTUS-v1-PAID-DAIS22ADEWD-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (ILT)',                                     'course_code': 'ACAD-CUST-ILTPUB-v1-PAID-SMLWAS-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (Partner) ',                                'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-SMLAS-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (Private ILT)',                             'course_code': 'ACAD-CUST-ILTPRV-v1-PAID-SMLWAS-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (Private Partner)',                         'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-SMLAP-ACT'},
  {'course_name': 'Core Technical Series Scalable ML (Private Partner)',                                    'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-SCALML-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (V1)',                                      'course_code': 'ACAD-ALL-SLP-v1-FREE-SMLWAS-ACT'},
  {'course_name': 'Scalable Machine Learning with Apache Spark™ (V2)',                                      'course_code': 'ACAD-ALL-SLP-v2-FREE-SMLWAS-ACT'},
  {'course_name': 'ELEVATE Training Series: Databricks for Data Analysts',                                  'course_code': 'PART-ALL-ILTUS-v1-FREE-DFDA-ACT'},
  {'course_name': 'Core Technical Series: Advanced Data Engineering with Databricks (Private Partner)',     'course_code': 'ACAD-PART-ILT-PRIVATE-v2-FREE-ADEWD-ACT'},
  {'course_name': 'ELEVATE Training Series: Databricks for Data Engineers',                                 'course_code': 'PART-ALL-SLP-v1-FREE-DFDE-ACT'},
  {'course_name': 'ELEVATE Training Series: Databricks for Machine Learning Practitioners',                 'course_code': 'PART-ALL-ILTUS-v1-FREE-DMLP-ACT'},
  {'course_name': 'Machine Learning in Production (ILT)',                                                   'course_code': 'ACAD-CUST-ILTPUB-v1-PAID-MLINPROD-ACT'},
  {'course_name': 'Machine Learning in Production (Partner)',                                               'course_code': 'ACAD-PART-ILT-PUBLIC-v1-FREE-MLPROD-ACT'},
  {'course_name': 'Machine Learning in Production (Private ILT)',                                           'course_code': 'ACAD-CUST-ILTPRV-v1-PAID-MLINPROD-ACT'},
  {'course_name': 'Machine Learning in Production (Private Partner)',                                       'course_code': 'ACAD-PART-ILT-PRIVATE-v1-FREE-MLPROD-ACT'},
  {'course_name': 'Machine Learning in Production (V1)',                                                    'course_code': 'ACAD-ALL-SLP-v1-FREE-MLINPROD-ACT'},
  {'course_name': 'DAIS 2022 Advanced Machine Learning with Databricks',                                    'course_code': 'ACAD-CUST-ILTUS-v1-PAID-DAIS22AMLWD-ACT'},
  {'course_name': 'Delivery Specialization: UC Upgrade',                                                    'course_code': 'ACAD-PART-SLP-v1-FREE-UCUPG-RET'},
  {'course_name': 'Generative AI Engineering with Databricks',                                              'course_code': 'ACAD-PART-SLP-v1-PAID-GENAIWDB-ACT'},
  {'course_name':	'Generative AI Engineering with Databricks - Portuguese BR',                              'course_code': 'ACAD-PART-ILTPRV-v2-PAID-GENAI-PTBR-ACT'},
  {'course_name':	'Generative AI Engineering with Databricks - Portuguese BR',                              'course_code': 'ACAD-PART-ILTPUB-v1-PAID-GENAI-PTBR-ACT'},
  {'course_name':	'Generative AI Engineering with Databricks - Japanese',                                   'course_code': 'ACAD-PART-ILTPRV-v2-PAID-GENAI-JAP-ACT'},
  {'course_name':	'Generative AI Engineering with Databricks - Japanese',                                   'course_code': 'ACAD-PART-ILTPUB-v1-PAID-GENAI-JAP-ACT'},
  {'course_name':	'Generative AI Engineering with Databricks',                                              'course_code': 'ACAD-PART-ILT-v1-FREE-LLMWDBPVT-ACT'},
  {'course_name':	'Generative AI Engineering with Databricks',                                              'course_code': 'ACAD-PART-ILT-v1-FREE-LLMWDB-ACT'},
  {'course_name':	'Generative AI Engineering with Databricks',                                              'course_code': 'ACAD-PART-SLP-v1-PAID-GENAIWDB-ACT'},
  {'course_name':	'Core Technical Series: Generative AI Engineering with Databricks (Private Partner)',     'course_code': 'ACAD-PART-ILT-v1-FREE-LLMWDBCOREPVT-ACT'},
  {'course_name': 'Delivery Specialization: UC Upgrade',                                                    'course_code': 'ACAD-PART-SLP-v1-FREE-UCUPG-RET'},
  {'course_name': 'Data Engineering with Databricks - Japanese',                                              'course_code': 'PART-PART-ILT-DEWD-JA-v3'},
  {'course_name': 'Delivery Specialization: EDW Migration Best Practices',                                       'course_code': 'ACAD-PART-SLP-PAID-DSEDWMBP-ENG-v1'},
  {'course_name': 'Delivery Specialization: CDW Migration Best Practices',                              'course_code': 'ACAD-PART-SLP-DSCDW-ENG-v1'},
  {'course_name': 'Delivery Specialization: UC Upgrade with Assessment',                              'course_code': 'ACAD-PART-SLP-v1-PAID-UCUPG-ACT'},
  ]

technical_trained = [course['course_code'] for course in technical_trained_list]

technical_certified_list = [
{'credential_name': 'Databricks Certified Data Engineer Associate',                             'group_id': '353856'},
{'credential_name': 'Databricks Certified Data Analyst Associate',                              'group_id': '364119'},
{'credential_name': 'Databricks Certified Associate Developer for Apache Spark 2.4',            'group_id': '227818'},
{'credential_name': 'Databricks Certified Machine Learning Professional',                       'group_id': '357057'},
{'credential_name': 'Databricks Certified Associate Developer for Apache Spark 3.0',            'group_id': '227965'},
{'credential_name': 'Databricks Certified Data Engineer Professional',                          'group_id': '331743'},
{'credential_name': 'Databricks Certified Machine Learning Associate',                          'group_id': '371215'},
{'credential_name': 'Databricks Certified Associate ML Practitioner for Apache Spark 2.4',      'group_id': '229201'},
{'credential_name': 'Databricks Certified Generative AI Engineer Associate',                    'group_id': '583499'},
]

technical_certified = [cred['group_id'] for cred in technical_certified_list]

technical_partner_badges_less_certs_list = [
  {'credential_name': 'Partner Program -  Developer Champion',                          'group_id': '231242'},
  {'credential_name': 'Partner Training - Azure Databricks Developer Essentials',       'group_id': '229948'},
  {'credential_name': 'Partner Training - Developer Essentials',                        'group_id': '230012'},
  {'credential_name': 'Partner Training - Developer Foundations',                       'group_id': '247511'},
]

technical_partner_badges_less_certs = [cred['group_id'] for cred in technical_partner_badges_less_certs_list]

# COMMAND ----------

def enablementResults(category, sales=False, ilt_courses=[], sp_courses=[], new_ilt_courses=[], new_sp_courses=[], badges=[], new_badges=[]):

  schema = T.StructType([
             T.StructField("learner_email", T.StringType(), True),
             T.StructField("learner_email_hash", T.StringType(), True),
             T.StructField("learner_email_domain", T.StringType(), True),
             T.StructField("learner_alternate_email", T.StringType(), True),
             T.StructField("learner_alternate_email_hash", T.StringType(), True),
             T.StructField("learner_alternate_email_domain", T.StringType(), True),
             T.StructField("ultimate_parent_account_name", T.StringType(), True),
             T.StructField("ultimate_parent_account_id", T.StringType(), True),
             T.StructField("fiscal_quarter_year", T.StringType(), True),
             T.StructField("month", T.StringType(), True),
             T.StructField("week", T.StringType(), True),
             T.StructField("fiscal_quarter", T.StringType(), True),
             T.StructField("fiscal_year", T.StringType(), True),
             T.StructField("course", T.StringType(), True),
             T.StructField("date", T.StringType(), True),
             T.StructField("country_code", T.StringType(), True),
             T.StructField("country_name", T.StringType(), True),
             T.StructField("region", T.StringType(), True),
             T.StructField("course_type", T.StringType(), True),
             T.StructField("learner_user_id", T.StringType(), True),
             T.StructField("credential_id", T.StringType(), True),
           ])

  # empty = sqlContext.createDataFrame(sc.emptyRDD(), schema)
  empty = spark.createDataFrame([], schema)

  if category != 'Technical Trained' or category != 'Technical Consultants':
    if len(ilt_courses) != 0:
      ilt1 = (
        ilt_enrollments
          .filter(F.col("status") == "completed")
          # .filter(F.col("course_code").isin(ilt_courses))
          .filter(F.col("course_name").isin(ilt_courses))
          .withColumn("course_type", F.lit("classroom"))
          .withColumn('credential_id', F.lit(None))          
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name", 
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region"),
            F.col('course_type'),
            F.col('learner_user_id'),
            F.col('credential_id')
          )

      )

    else:
      ilt1 = empty
    ilt2 = empty

    if len(sp_courses) != 0:
      sp1 = (
        self_paced_enrollments
          .filter(F.col("status") == "completed")
          # .filter(F.col("course_code").isin(sp_courses))
          .filter(F.col("course_name").isin(sp_courses))
          .withColumn("course_type", F.lit("e-learning"))
          .withColumn('credential_id', F.lit(None))
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name",  
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region"),
            F.col('course_type'),
            F.col('learner_user_id'),
            F.col('credential_id')
          )

      )

    else:
      sp1 = empty
    sp2 = empty

  if category == 'Technical Trained' or category == 'Technical Consultants':

    if len(ilt_courses) != 0:
      ilt1 = (
        ilt_enrollments
          .filter(F.col("status") == "completed")
          # .filter(F.col("course_code").isin(ilt_courses))
          .filter(F.col("fiscalYear") <= '2023')
          .filter(F.col("course_name").isin(ilt_courses))
          .withColumn("course_type", F.lit("classroom"))
          .withColumn('credential_id', F.lit(None))
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name", 
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region"),
            F.col('course_type'),
            F.col('learner_user_id'),
            F.col('credential_id')
          )

      )

    else:
      ilt1 = empty
    
    if len(new_ilt_courses) != 0:
      ilt2 = (
        ilt_enrollments
          .filter(F.col("status") == "completed")
          .filter(F.col("fiscalYear") >= '2024')
          .filter(F.col("course_code").isin(new_ilt_courses))
          .withColumn("course_type", F.lit("classroom"))
          .withColumn('credential_id', F.lit(None))
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name", 
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region"),
            F.col('course_type'),
            F.col('learner_user_id'),
            F.col('credential_id')
          )

      )

    else:
      ilt2 = empty
    
      
    if len(sp_courses) != 0:
      sp1 = (
        self_paced_enrollments
          .filter(F.col("status") == "completed")
          # .filter(F.col("course_code").isin(sp_courses))
          .filter(F.col("course_name").isin(sp_courses))
          .filter(F.col("fiscalYear") <= '2023')
          .withColumn("course_type", F.lit("e-learning"))
          .withColumn('credential_id', F.lit(None))
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name",  
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region"),
            F.col('course_type'),
            F.col('learner_user_id'),
            F.col('credential_id')
          )

      )

    else:
      sp1 = empty

    if len(new_sp_courses) != 0:
      sp2 = (
        self_paced_enrollments
          .filter(F.col("status") == "completed")
          .filter(F.col("course_code").isin(new_sp_courses))
          .filter(F.col("fiscalYear") >= '2024')
          .withColumn("course_type", F.lit("e-learning"))
          .withColumn('credential_id', F.lit(None))
          .select(
            "learner_email",
            "learner_email_hash", 
            "learner_email_domain",
            "learner_alternate_email",
            "learner_alternate_email_hash",
            "learner_alternate_email_domain",
            "ultimate_parent_account_name",  
            "ultimate_parent_account_id",
            "fiscal_quarter_year",
            "month", 
            "week",
            F.col("fiscalQuarter").alias("fiscal_quarter"),
            F.col("fiscalYear").alias("fiscal_year"),
            F.col("course_name").alias("course"), 
            "date",
            F.col("country_code"),
            F.col("country_name"),
            F.col("region"),
            F.col('course_type'),
            F.col('learner_user_id'),
            F.col('credential_id')
          )

      )

    else:
      sp2 = empty
    
  if len(badges) != 0:
    badge1 = (
      partner_badges
        .filter(F.col("group_id").isin(badges))
        .withColumn("learner_email", F.lit(None))
        .withColumn("learner_alternate_email", F.lit(None))
        .withColumn("course_type", F.lit("badge"))
        .withColumn('learner_user_id', F.lit(None))
        .select(
          "learner_email",
          "learner_email_hash", 
          "learner_email_domain",
          "learner_alternate_email",
          "learner_alternate_email_hash",
          "learner_alternate_email_domain",
          "ultimate_parent_account_name",  
          "ultimate_parent_account_id",
          "fiscal_quarter_year",
          "month", 
          "week",
          F.col("fiscalQuarter").alias("fiscal_quarter"),
          F.col("fiscalYear").alias("fiscal_year"),
          F.col("credential_name").alias("course"), 
          "date",
          F.col("country_code"),
          F.col("country_name"),
          F.col("region"),
          F.col('course_type'),
          F.col('learner_user_id'),
          F.col('credential_id')
        )

    )
  else:
    badge1 = empty

  if len(new_badges) != 0:
    badge2 = (
      partner_badges
        .filter(F.col("group_id").isin(new_badges))
        .filter(F.col("calculated_is_expired") == "false")
        .withColumn("learner_email", F.lit(None))
        .withColumn("learner_alternate_email", F.lit(None))
        .withColumn("course_type", F.lit("certification"))
        .withColumn('learner_user_id', F.lit(None))
        .select(
          "learner_email",
          "learner_email_hash", 
          "learner_email_domain",
          "learner_alternate_email",
          "learner_alternate_email_hash",
          "learner_alternate_email_domain",
          "ultimate_parent_account_name",  
          "ultimate_parent_account_id",
          "fiscal_quarter_year",
          "month", 
          "week",
          F.col("fiscalQuarter").alias("fiscal_quarter"),
          F.col("fiscalYear").alias("fiscal_year"),
          F.col("credential_name").alias("course"), 
          "date",
          F.col("country_code"),
          F.col("country_name"),
          F.col("region"),
          F.col('course_type'),
          F.col('learner_user_id'),
          F.col('credential_id')
        )

    )
  else:
    badge2 = empty

  if sales:
    sales_trained = sales_trained_data
  else:
    sales_trained = empty

  all_enrollments = (
    ilt1
      .union(ilt2)
      .union(sp1)
      .union(sp2)
      .union(badge1)
      .union(badge2)
      .union(sales_trained)
      .withColumn("category", F.lit(f"{category}"))
  )
  
  return all_enrollments

# COMMAND ----------

def capacity(df):
  first_enrollment_ids = (
    df
      .orderBy("date")
      .groupBy("learner_email_hash")
      .agg(F.collect_list(F.struct("date", "learner_email_hash", "course")).alias("enrollment_dates"))
      .select(
        F.array_min(F.array_sort(F.col("enrollment_dates"))).getItem("date").alias("date"),
        F.array_min(F.array_sort(F.col("enrollment_dates"))).getItem("learner_email_hash").alias("learner_email_hash"),
        F.array_min(F.array_sort(F.col("enrollment_dates"))).getItem("course").alias("course"),
      )
  )

  first_enrollments = (
    df
      .join(first_enrollment_ids, ["date", "learner_email_hash", "course"])
      .dropDuplicates(["learner_email_hash", "date", "course"])
  )

  return first_enrollments

# COMMAND ----------

# DBTITLE 1,Sales Enrollment Data Transformation
sales_docebo_ilt = (
  ilt_enrollments
    .filter(F.col("status") == "completed")
    .filter(F.col("course_name").like("%10X%"))
    .dropDuplicates(["course_name", "learner_email_hash"])
    .withColumn("course_type", F.lit("classroom"))
    .withColumn('credential_id', F.lit(None))
    .select(
      "learner_email",
      "learner_email_hash", 
      "learner_email_domain",
      "learner_alternate_email",
      "learner_alternate_email_hash",
      "learner_alternate_email_domain",
      "ultimate_parent_account_name", 
      "ultimate_parent_account_id",
#       "partner_account_id_sfdc", 
      "fiscal_quarter_year",
      "month", 
      "week",
      F.col("fiscalQuarter").alias("fiscal_quarter"),
      F.col("fiscalYear").alias("fiscal_year"),
      F.col("course_name").alias("course"), 
      "date",
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('course_type'),
      F.col('learner_user_id'),
      F.col('credential_id')
    )

)

sales_docebo_sp = (
  self_paced_enrollments
    .filter(F.col("status") == "completed")
    .filter((F.col("course_code").isin(business_ess_courses)) | (F.col("course_name").like("%10X%")) |(F.col("course_code").isin(sales_self_paced)))
    .dropDuplicates(["course_name", "learner_email_hash"])
    .withColumn("course_type", F.lit("e-learning"))
    .withColumn('credential_id', F.lit(None))
    .select(
      "learner_email",
      "learner_email_hash", 
      "learner_email_domain",
      "learner_alternate_email",
      "learner_alternate_email_hash",
      "learner_alternate_email_domain",
      "ultimate_parent_account_name", 
      "ultimate_parent_account_id",
#       "partner_account_id_sfdc", 
      "fiscal_quarter_year",
      "month", 
      "week",
      F.col("fiscalQuarter").alias("fiscal_quarter"),
      F.col("fiscalYear").alias("fiscal_year"),
      F.col("course_name").alias("course"), 
      "date",
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('course_type'),
      F.col('learner_user_id'),
      F.col('credential_id')
    )
    
)

spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

sales_legacy = (
  sales_legacy_raw
    .drop('partner_account_name', 'partner_account_id_sfdc', )
    .withColumn("email_domain_final", F.split(F.lower('contact_email'), '@', 2).getItem(1))
    .join(unique_partner_mappings, "email_domain_final", "left")
    .withColumn('ultimate_parent_account_id', F.coalesce('ultimate_parent_account_id', 'account_id'))
    .withColumn('ultimate_parent_account_name', F.coalesce('ultimate_parent_account_name', 'account_name'))
)

sales_legacy_data = (
  sales_legacy
    .join(dates_raw, "date", "left")
    .withColumn("fiscal_quarter_year", F.concat(F.lit("FY"), F.col('fiscalYear'), F.lit("Q"), F.col('fiscalQuarter')))
    .withColumnRenamed('email_domain_final', 'learner_email_domain')
    .withColumn("learner_email_hash", F.sha2("contact_email", 256))
    .withColumn("country_code", F.lit(None))
    .withColumn("country_name", F.lit(None))
    .withColumn("region", F.lit(None))
    .withColumn("learner_alternate_email", F.lit(None))
    .withColumn("learner_alternate_email_hash", F.lit(None))
    .withColumn("learner_alternate_email_domain", F.lit(None))
    .withColumn("course_type", F.lit("classroom"))
    .withColumn('learner_user_id', F.lit(None))
    .withColumn('credential_id', F.lit(None))
    .select(
      F.col("contact_email").alias("learner_email"),
      "learner_email_hash", 
      "learner_email_domain",
      "learner_alternate_email",
      "learner_alternate_email_hash",
      "learner_alternate_email_domain",
      "ultimate_parent_account_name",
      "ultimate_parent_account_id",
      "fiscal_quarter_year", 
      "month", 
      "week",
      F.col("fiscalQuarter").alias("fiscal_quarter"),
      F.col("fiscalYear").alias("fiscal_year"),
      F.col("event").alias("course"), 
      "date",
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('course_type'),
      F.col('learner_user_id'),
      F.col('credential_id')
    )
    .dropDuplicates(["learner_email_hash", "course", "date"])
    
)

sales_trained_data = (
  sales_legacy_data
    .union(sales_docebo_ilt)
    .union(sales_docebo_sp)
)

# COMMAND ----------

# DBTITLE 1,Enablement Results Capacity Tracker
# Delivery Trained

delivery_trained_capability = (
  enablementResults(
    ilt_courses=partner_technical_ilt, 
    sp_courses=technical_self_paced, 
    new_ilt_courses=technical_trained, 
    new_sp_courses=technical_trained, 
    category="Technical Trained"
  )
)

delivery_trained_capacity = capacity(delivery_trained_capability)

# Technical Sales Trained

technical_sales_trained_capability = (
  enablementResults(
    ilt_courses=technical_sales_ilt,
    category="Technical Sales Trained"
  )
)

technical_sales_trained_capacity = capacity(technical_sales_trained_capability)

# Sales Trained

sales_trained_capability = (
  enablementResults(
    sales=True,
    category="Sales Trained"
  )
)

sales_trained_capacity = capacity(sales_trained_capability)

# Total Trained

# total_trained_capability = (
#   enablementResults(
#     ilt_courses=partner_technical_ilt+technical_sales_ilt,
#     sp_courses=technical_self_paced,
#     badges=technical_sales_badges,
#     sales=True,
#     category="Total Trained"
#   )
# )

# total_trained_capacity = capacity(total_trained_capability)

# Delivery Badged

# delivery_badged_capability = (
#   enablementResults(
#     badges=technical_partner_badges, 
#     category="Technical Badged"
#   )
# )

#delivery_badged_capacity = capacity(delivery_badged_capability)

# Technical Sales Badged

technical_sales_badged_capability = (
  enablementResults(
    badges=technical_sales_badges, 
    category="Technical Sales Badged"
  )
)

technical_sales_badged_capacity = capacity(technical_sales_badged_capability)

# Sales Badged

sales_badged_capability = (
  enablementResults(
    badges=sales_badges, 
    category="Sales Badged"
  )
)

sales_badged_capacity = capacity(sales_badged_capability)

# Academy Certification Badged

# academy_certification_badged_capability = (
#   enablementResults(
#     badges=certification_badges, 
#     category="Academy Certification Badged"
#   )
# )

#academy_certification_badged_capacity = capacity(academy_certification_badged_capability)

# Champion Badged

champion_badged_capability = (
  enablementResults(
    badges=champion_badges, 
    category="Champion Badged"
  )
)

champion_badged_capacity = capacity(champion_badged_capability)

# Total Badged

# total_badged_capability = (
#   enablementResults(
#     badges=technical_partner_badges+technical_sales_badges+sales_badges+certification_badges+champion_badges, 
#     category="Total Badged"
#   )
# )

#total_badged_capacity = capacity(total_badged_capability)

# Total Sales

# total_sales_capability = (
#   enablementResults(
#     badges=technical_sales_badges+sales_badges,
#     ilt_courses=technical_sales_ilt,
#     sales=True,
#     category="Total Trained or Badged (Sales)"
#   )
# )

# total_sales_capacity = capacity(total_sales_capability)

# Total Delivery

# total_delivery_capability = (
#   enablementResults(
#     ilt_courses=partner_technical_ilt, 
#     sp_courses=technical_self_paced, 
#     badges=certification_badges+technical_partner_badges,
#     category="Total Trained or Badged (Technical)"
#   )
# )

# total_delivery_capacity = capacity(total_delivery_capability)

# Total Trained and Badged

# total_all_capability = (
#   enablementResults(
#     ilt_courses=partner_technical_ilt+technical_sales_ilt, 
#     sp_courses=technical_self_paced, 
#     badges=technical_partner_badges+technical_sales_badges+sales_badges+certification_badges+champion_badges,
#     sales=True,
#     category="Total Trained or Badged (All Training and Badge Categories)"
#   )
# )

# total_all_capacity = capacity(total_all_capability)

# Technical Certified

technical_certified_capability = (
  enablementResults(
    new_badges=technical_certified, 
    category="Technical Certified"
  )
)

technical_certified_capacity = capacity(technical_certified_capability)

# Technical consultants

# technical_consultants_capability = (
#   enablementResults(
#     ilt_courses=partner_technical_ilt, 
#     sp_courses=technical_self_paced, 
#     new_ilt_courses=technical_trained, 
#     new_sp_courses=technical_trained, 
#     badges=technical_partner_badges_less_certs,
#     new_badges=technical_certified,
#     category="Technical Consultants"
#   )
# )

# technical_consultants_capacity = capacity(technical_consultants_capability)

# Delivery Specialization

delivery_specialization_capability = (
  enablementResults(
    new_badges=delivery_specialization, 
    category="Delivery Specialization"
  )
)

delivery_specialization_capacity = capacity(delivery_specialization_capability)


# COMMAND ----------

# DBTITLE 1,Comprehensive Capacity Capability Union
all_capacity = (
  delivery_trained_capacity
    .union(technical_sales_trained_capacity)
    .union(sales_trained_capacity)
#    .union(total_trained_capacity)
#    .union(delivery_badged_capacity)
    .union(technical_sales_badged_capacity)
    .union(sales_badged_capacity)
#    .union(academy_certification_badged_capacity)
    .union(champion_badged_capacity)
#    .union(total_badged_capacity)
#    .union(total_sales_capacity)
#    .union(total_delivery_capacity)
#    .union(total_all_capacity)
    .union(technical_certified_capacity)
#    .union(technical_consultants_capacity)
    .union(delivery_specialization_capacity)
)

all_capability = (
  delivery_trained_capability
    .union(technical_sales_trained_capability)
    .union(sales_trained_capability)
#    .union(total_trained_capability)
#    .union(delivery_badged_capability)
    .union(technical_sales_badged_capability)
    .union(sales_badged_capability)
#    .union(academy_certification_badged_capability)
    .union(champion_badged_capability)
#    .union(total_badged_capability)
#    .union(total_sales_capability)
#    .union(total_delivery_capability)
#    .union(total_all_capability)
    .union(technical_certified_capability)
#    .union(technical_consultants_capability)
    .union(delivery_specialization_capability)

)

# COMMAND ----------

all_capacity_enhanced = (all_capacity.join(sfdc_account, "ultimate_parent_account_id", "left"))
all_capability_enhanced = (all_capability.join(sfdc_account, "ultimate_parent_account_id", "left"))

# COMMAND ----------

# DBTITLE 1,Data Transformation Pipeline
all_capacity_enhanced = (
  all_capacity_enhanced
    .select(
      F.col('learner_email').alias('contact_email'),
      'learner_email_hash',
      'learner_email_domain',
      F.col('ultimate_parent_account_name').alias('partner_account_name'),
      F.col('ultimate_parent_account_id').alias('partner_account_id_sfdc'),
      'fiscal_quarter_year',
      'month',
      'week',
      'fiscal_quarter',
      'fiscal_year',
      'course',
      F.date_format(F.to_date(F.col('date'), 'yyyy-MM-dd'), 'yyyy-MM-dd').alias('date'),
      'course_type',
      'category',
      'partner_manager',
      'billing_country',
      'partner_level',
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      'partner_tier',
      "learner_alternate_email",
      "learner_alternate_email_hash",
      "learner_alternate_email_domain",
      "learner_user_id",
      "credential_id"
    )
)

all_capability_enhanced = (
  all_capability_enhanced
    .select(
      F.col('learner_email').alias('contact_email'),
      'learner_email_hash',
      'learner_email_domain',
      F.col('ultimate_parent_account_name').alias('partner_account_name'),
      F.col('ultimate_parent_account_id').alias('partner_account_id_sfdc'),
      'fiscal_quarter_year',
      'month',
      'week',
      'fiscal_quarter',
      'fiscal_year',
      'course',
      F.date_format(F.to_date(F.col('date'), 'yyyy-MM-dd'), 'yyyy-MM-dd').alias('date'),
      'course_type',
      'category',
      'partner_manager',
      'billing_country',
      'partner_level',
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      'partner_tier',
      "learner_alternate_email",
      "learner_alternate_email_hash",
      "learner_alternate_email_domain",
      "learner_user_id",
      "credential_id"
    )
)

# COMMAND ----------

all_capacity_enhanced.createOrReplaceTempView('capacity')

# COMMAND ----------

# DBTITLE 1,Partner Certification Persona Analysis
# MAGIC %sql
# MAGIC create or replace temp view partner_personas as (
# MAGIC   with pre as (
# MAGIC     select
# MAGIC       learner_email_hash,
# MAGIC       partner_account_name,
# MAGIC       region,
# MAGIC       min(fiscal_quarter_year) as fq,
# MAGIC       collect_set(course) as credentials,
# MAGIC       size(collect_set(course)) as credential_count,
# MAGIC       case
# MAGIC         when size(
# MAGIC           collect_set(
# MAGIC             case
# MAGIC               when course ilike '%generative%ai%engineer%associate%' then course
# MAGIC             end
# MAGIC           )
# MAGIC         ) > 0 then 1
# MAGIC         else 0
# MAGIC       end as gen_ai_associate_flag,
# MAGIC       case
# MAGIC         when size(
# MAGIC           collect_set(
# MAGIC             case
# MAGIC               when course ilike '%data%analyst%associate%' then course
# MAGIC             end
# MAGIC           )
# MAGIC         ) > 0 then 1
# MAGIC         else 0
# MAGIC       end as da_associate_flag,
# MAGIC       case
# MAGIC         when size(
# MAGIC           collect_set(
# MAGIC             case
# MAGIC               when course ilike '%machine%learning%associate%' then course
# MAGIC             end
# MAGIC           )
# MAGIC         ) > 0 then 1
# MAGIC         else 0
# MAGIC       end as ml_associate_flag,
# MAGIC       case
# MAGIC         when size(
# MAGIC           collect_set(
# MAGIC             case
# MAGIC               when course ilike '%developer%spark%' then course
# MAGIC             end
# MAGIC           )
# MAGIC         ) > 0 then 1
# MAGIC         else 0
# MAGIC       end as spark_dev_associate_flag,
# MAGIC       case
# MAGIC         when size(
# MAGIC           collect_set(
# MAGIC             case
# MAGIC               when course ilike '%ML Practitioner for Apache Spark 2.4%' then course
# MAGIC             end
# MAGIC           )
# MAGIC         ) > 0 then 1
# MAGIC         else 0
# MAGIC       end as spark_ml_associate_flag,
# MAGIC       case
# MAGIC         when size(
# MAGIC           collect_set(
# MAGIC             case
# MAGIC               when course ilike '%machine%learning%professional%' then course
# MAGIC             end
# MAGIC           )
# MAGIC         ) > 0 then 1
# MAGIC         else 0
# MAGIC       end as ml_professional_flag,
# MAGIC       case
# MAGIC         when size(
# MAGIC           collect_set(
# MAGIC             case
# MAGIC               when course ilike '%data%engineer%professional%' then course
# MAGIC             end
# MAGIC           )
# MAGIC         ) > 0 then 1
# MAGIC         else 0
# MAGIC       end as de_professional_flag,
# MAGIC       case
# MAGIC         when size(
# MAGIC           collect_set(
# MAGIC             case
# MAGIC               when course ilike '%data%engineer%associate%' then course
# MAGIC             end
# MAGIC           )
# MAGIC         ) > 0 then 1
# MAGIC         else 0
# MAGIC       end as de_associate_flag,
# MAGIC       case
# MAGIC         when size(
# MAGIC           collect_set(
# MAGIC             case
# MAGIC               when course ilike '%associate%' then course
# MAGIC             end
# MAGIC           )
# MAGIC         ) > 0 then 1
# MAGIC         else 0
# MAGIC       end as associate_flag,
# MAGIC       case
# MAGIC         when size(
# MAGIC           collect_set(
# MAGIC             case
# MAGIC               when course ilike '%professional%' then course
# MAGIC             end
# MAGIC           )
# MAGIC         ) > 0 then 1
# MAGIC         else 0
# MAGIC       end as professional_flag
# MAGIC     from
# MAGIC       partner_capability_vw
# MAGIC     where
# MAGIC       processdate = (
# MAGIC         select
# MAGIC           max(processDate)
# MAGIC         from
# MAGIC           partner_capability_vw
# MAGIC       )
# MAGIC       and category = 'Technical Certified'
# MAGIC     group by
# MAGIC       1,
# MAGIC       2,
# MAGIC       3
# MAGIC   ),
# MAGIC   pre_final as (
# MAGIC     select
# MAGIC       *,
# MAGIC       case
# MAGIC         when professional_flag = 1 then 'Professional'
# MAGIC         else 'Associate'
# MAGIC       end as final_level
# MAGIC     from
# MAGIC       pre
# MAGIC   )
# MAGIC   select
# MAGIC     *,
# MAGIC     case
# MAGIC       when final_level = 'Professional' then case
# MAGIC         when ml_professional_flag = 1 then "ml_pro"
# MAGIC         when de_professional_flag = 1 then "de_pro"
# MAGIC         else "Other"
# MAGIC       end
# MAGIC       when final_level = 'Associate' then case
# MAGIC         when gen_ai_associate_flag = 1 then "gen_ai_associate"
# MAGIC         when ml_associate_flag = 1 then "ml_associate"
# MAGIC         when spark_ml_associate_flag = 1 then "spark_ml_associate"
# MAGIC         when de_associate_flag = 1 then "de_associate"
# MAGIC         when spark_dev_associate_flag = 1 then "spark_dev_associate"
# MAGIC         when da_associate_flag = 1 then "da_associate"
# MAGIC         else "Other"
# MAGIC       end
# MAGIC     end as persona
# MAGIC   from
# MAGIC     pre_final
# MAGIC )

# COMMAND ----------

all_capacity_enhanced_personas = spark.sql('''
  select 
    c.*,
    case when c.category = "Technical Certified" then p.final_level else "" end as final_level,
    case when c.category = "Technical Certified" then p.persona else "" end as persona
  from capacity c
  left join partner_personas p on c.learner_email_hash = p.learner_email_hash                                      
''')

# COMMAND ----------

from pyspark.sql.functions import when

def null_if_unknown(col):
    return when((F.col(col).isNull()) | (F.col(col) == "Unknown"), None).otherwise(F.col(col))


# COMMAND ----------

# DBTITLE 1,Learner Data Enrichment Process
user_info = (
  docebo_users
    .select(F.col('id').alias('learner_user_id'), F.col('country_derived').alias('country_derived_pre_1'), F.col('region_derived').alias('region_derived_pre_1'))
)

badge_country_region = (
  partner_badges
    .select(F.col('credential_id'), F.col('country_derived').alias('country_derived_pre_2'), F.col('region_derived').alias('region_derived_pre_2'))
)

all_capacity_enhanced_pre_1 = (
  all_capacity_enhanced_personas
    .join(user_info, 'learner_user_id', 'left')
    .join(badge_country_region, 'credential_id', 'left')
)

all_capacity_enhanced_country_region = (
  all_capacity_enhanced_pre_1
    .withColumn('country_derived', F.coalesce(F.coalesce(F.col('country_name'), F.col('country_derived_pre_1'), F.col('country_derived_pre_2')), F.lit("Unknown")))
    .withColumn('region_derived', F.coalesce(F.coalesce(F.col('region'), F.col('region_derived_pre_1'), F.col('region_derived_pre_2')), F.lit("Unknown")))
    .select(
      'contact_email',
      'learner_email_hash',
      'learner_email_domain',
      'partner_account_name',
      'partner_account_id_sfdc',
      'fiscal_quarter_year',
      'month',
      'week',
      'fiscal_quarter',
      'fiscal_year',
      'course',
      'date',
      'course_type',
      'category',
      'partner_manager',
      'billing_country',
      'partner_level',
      'country_code',
      'country_name',
      'region',
      'partner_tier',
      'learner_alternate_email',
      'learner_alternate_email_hash',
      'learner_alternate_email_domain',
      'learner_user_id',
      'credential_id',
      'final_level',
      'persona',
      'country_derived',
      'region_derived'
    )
)

# all_capability_enhanced_pre_1 = (
#   all_capability_enhanced
#     .join(user_info, 'learner_user_id', 'left')
#     .join(badge_country_region, 'credential_id', 'left')
#     .withColumn('country_derived', coalesce(
#         F.col('country_derived_pre_1'), 
#         F.col('country_derived_pre_2')
#     ))
#     .withColumn('region_derived', coalesce(
#         F.col('region_derived_pre_1'), 
#         F.col('region_derived_pre_2')
#     ))
#     .drop(
#         'country_derived_pre_1', 'country_derived_pre_2',
#         'region_derived_pre_1', 'region_derived_pre_2'
#     )
# )

all_capability_enhanced_pre_1 = (
  all_capability_enhanced
    .join(user_info, 'learner_user_id', 'left')
    .join(badge_country_region, 'credential_id', 'left')
)

all_capability_enhanced_country_region = (
  all_capability_enhanced_pre_1
    .withColumn('country_derived', F.coalesce(F.coalesce(F.col('country_name'), F.col('country_derived_pre_1'), F.col('country_derived_pre_2')), F.lit("Unknown")))
    .withColumn('region_derived', F.coalesce(F.coalesce(F.col('region'), F.col('region_derived_pre_1'), F.col('region_derived_pre_2')), F.lit("Unknown")))
    .select(
      'contact_email',
      'learner_email_hash',
      'learner_email_domain',
      'partner_account_name',
      'partner_account_id_sfdc',
      'fiscal_quarter_year',
      'month',
      'week',
      'fiscal_quarter',
      'fiscal_year',
      'course',
      'date',
      'course_type',
      'category',
      'partner_manager',
      'billing_country',
      'partner_level',
      'country_code',
      'country_name',
      'region',
      'partner_tier',
      'learner_alternate_email',
      'learner_alternate_email_hash',
      'learner_alternate_email_domain',
      'learner_user_id',
      'credential_id', 
      'country_derived',
      'region_derived'
    )
)

# COMMAND ----------

all_capability_enhanced_country_region.display()

# COMMAND ----------

user_info.filter(F.col('learner_user_id') == 28820).display()

# COMMAND ----------

all_capability_enhanced_country_region.createOrReplaceTempView('all_capability')
all_capacity_enhanced_country_region.createOrReplaceTempView('all_capacity')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create or replace temp view alternate_emails as 
# MAGIC with blacklist_domains as (
# MAGIC   select
# MAGIC     distinct blacklist_domain
# MAGIC   from
# MAGIC     main.field_learning_enablement.blacklist_domains
# MAGIC   where
# MAGIC     processDate = (
# MAGIC       select
# MAGIC         max(processDate)
# MAGIC       from
# MAGIC         main.field_learning_enablement.blacklist_domains
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC alt_emails as (
# MAGIC   select 
# MAGIC     id as id_user, 
# MAGIC     lower(alternate_email) as alternate_email, 
# MAGIC     lower(alternate_email_2) as alternate_email_2, 
# MAGIC     lower(alternate_email_domain) as alternate_email_domain,
# MAGIC     lower(alternate_email_2_domain) as alternate_email_2_domain, 
# MAGIC     branch_code, 
# MAGIC     b.blacklist_domain as b_blacklist_domain,
# MAGIC     b1.blacklist_domain as b1_blacklist_domain
# MAGIC   from main.it_training_silver.docebo_users u
# MAGIC   left join blacklist_domains b on u.alternate_email_domain = b.blacklist_domain
# MAGIC   left join blacklist_domains b1 on u.alternate_email_2_domain = b1.blacklist_domain
# MAGIC   where u.processDate = (select max(processDate) from main.it_training_silver.docebo_users)
# MAGIC )
# MAGIC , 
# MAGIC alt_emails_blacklist as (
# MAGIC   select
# MAGIC     *,
# MAGIC     case
# MAGIC       when b_blacklist_domain is not null
# MAGIC       and (
# MAGIC         b1_blacklist_domain is null
# MAGIC         and alternate_email_2_domain is not null
# MAGIC       ) then 'Email is blacklist - select secondary'
# MAGIC       when b1_blacklist_domain is not null
# MAGIC       and (
# MAGIC         b_blacklist_domain is null
# MAGIC         and alternate_email_domain is not null
# MAGIC       ) then 'Alternate email is blacklist - select primary'
# MAGIC       when (
# MAGIC         b_blacklist_domain is not null
# MAGIC         and b1_blacklist_domain is not null
# MAGIC         and alternate_email_domain is not null
# MAGIC       ) then 'Only blacklist domains - select primary'
# MAGIC       when (
# MAGIC         b_blacklist_domain is null
# MAGIC         and b1_blacklist_domain is null
# MAGIC         and alternate_email_domain is not null
# MAGIC       ) then 'Email Good - select primary'
# MAGIC       else 'Others'
# MAGIC     end as bucket
# MAGIC   from alt_emails
# MAGIC )
# MAGIC , 
# MAGIC final as (
# MAGIC   select
# MAGIC     p.*,
# MAGIC     case
# MAGIC       when p.bucket = 'Email is blacklist - select secondary' then p.alternate_email_2
# MAGIC       else p.alternate_email
# MAGIC     end as final_email,
# MAGIC     case
# MAGIC       when p.bucket = 'Email is blacklist - select secondary' then p.alternate_email_2_domain
# MAGIC       else p.alternate_email_domain
# MAGIC     end as final_email_domain
# MAGIC   from
# MAGIC     alt_emails_blacklist p
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC   id_user, 
# MAGIC   final_email as alternate_email, 
# MAGIC   final_email_domain as alternate_email_domain
# MAGIC from final 

# COMMAND ----------

# DBTITLE 1,Top Partner Certification View
# MAGIC %sql
# MAGIC create or replace temp view top_80_partner_certs as 
# MAGIC
# MAGIC with ranked_docebo_users as (
# MAGIC     select
# MAGIC       *,
# MAGIC       rank() over (
# MAGIC         partition by email_hash
# MAGIC         order by
# MAGIC           last_login
# MAGIC       ) as rank_data
# MAGIC     from
# MAGIC       main.field_learning_enablement.docebo_users
# MAGIC     where
# MAGIC       processdate =(
# MAGIC         Select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.docebo_users
# MAGIC       )
# MAGIC       and nvl(audience, 'Unknown') in ('Partner', 'Partner Other')
# MAGIC   ),
# MAGIC   docebo_users as (
# MAGIC     select
# MAGIC       *
# MAGIC     from
# MAGIC       ranked_docebo_users
# MAGIC     where
# MAGIC       rank_data = 1
# MAGIC   ),
# MAGIC   blacklist_domains as (
# MAGIC     select
# MAGIC       distinct blacklist_domain
# MAGIC     from
# MAGIC       main.field_learning_enablement.blacklist_domains
# MAGIC     where
# MAGIC       processDate = (
# MAGIC         select
# MAGIC           max(processDate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.blacklist_domains
# MAGIC       )
# MAGIC   ),
# MAGIC   capability as (
# MAGIC     select
# MAGIC       c.*
# MAGIC     except(c.learner_email_domain),
# MAGIC       case
# MAGIC         when c.learner_email_hash = '78dfc4089d9f80cbae14429cb95508c1955262ebdee4184c4e3fb3503a70ae18' then 'gmail.com'
# MAGIC         else learner_email_domain
# MAGIC       end as learner_email_domain
# MAGIC     from
# MAGIC       partner_capability_vw c
# MAGIC     where
# MAGIC       c.processdate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           partner_capability_vw
# MAGIC       )
# MAGIC       and learner_email_hash is not null
# MAGIC   ),
# MAGIC   -- fix learner_user_ids records that have one row with contact email and another without (because of learndot data)
# MAGIC   contact_email_fix as (
# MAGIC     select
# MAGIC       distinct learner_email_hash,
# MAGIC       contact_email,
# MAGIC       dense_rank() over (
# MAGIC         partition by learner_email_hash
# MAGIC         order by
# MAGIC           contact_email nulls last
# MAGIC       ) as rank
# MAGIC     from
# MAGIC       partner_capability_vw
# MAGIC     where
# MAGIC       category = 'Technical Trained'
# MAGIC       and processDate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           partner_capability_vw
# MAGIC       )
# MAGIC   ),
# MAGIC   capability_v2 as (
# MAGIC     select
# MAGIC       c.*,
# MAGIC       case
# MAGIC         when category in ('Technical Certified','Sales Badged','Delivery Specialization') then a.recipient_email
# MAGIC         else d.contact_email
# MAGIC       end as updated_email
# MAGIC     from
# MAGIC       capability c
# MAGIC       left join contact_email_fix d on c.learner_email_hash = d.learner_email_hash
# MAGIC       and d.rank = 1
# MAGIC       and c.category = 'Technical Trained'
# MAGIC       left join main.it_accredible_bronze.credentials a on c.credential_id = a.credential_id
# MAGIC       and a.processdate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.it_accredible_bronze.credentials
# MAGIC       )
# MAGIC   ),
# MAGIC   capability_v3 as (
# MAGIC     select
# MAGIC       c.*,
# MAGIC       b.blacklist_domain as b_blacklist_domain,
# MAGIC       b1.blacklist_domain as b1_blacklist_domain
# MAGIC     from
# MAGIC       capability_v2 c
# MAGIC       left join blacklist_domains b on c.learner_email_domain = b.blacklist_domain
# MAGIC       left join blacklist_domains b1 on c.learner_alternate_email_domain = b1.blacklist_domain
# MAGIC   ),
# MAGIC   capability_pre as (
# MAGIC     select
# MAGIC       *,
# MAGIC       case
# MAGIC         when b_blacklist_domain is not null
# MAGIC         and (
# MAGIC           b1_blacklist_domain is null
# MAGIC           and learner_alternate_email_domain is not null
# MAGIC         ) then 'Email is blacklist - select secondary'
# MAGIC         when b1_blacklist_domain is not null
# MAGIC         and (
# MAGIC           b_blacklist_domain is null
# MAGIC           and learner_email_domain is not null
# MAGIC         ) then 'Alternate email is blacklist - select primary'
# MAGIC         when (
# MAGIC           b_blacklist_domain is not null
# MAGIC           and b1_blacklist_domain is not null
# MAGIC           and learner_email_domain is not null
# MAGIC         ) then 'Only blacklist domains - select primary'
# MAGIC         when (
# MAGIC           b_blacklist_domain is null
# MAGIC           and b1_blacklist_domain is null
# MAGIC           and learner_email_domain is not null
# MAGIC         ) then 'Email Good - select primary'
# MAGIC         else 'Others'
# MAGIC       end as bucket
# MAGIC     from
# MAGIC       capability_v3
# MAGIC   ),
# MAGIC   alternate_emails as (
# MAGIC     select
# MAGIC       id_user,
# MAGIC       alternate_email,
# MAGIC       alternate_email_domain
# MAGIC     from
# MAGIC       alternate_emails
# MAGIC     -- select
# MAGIC     --   id_user,
# MAGIC     --   case
# MAGIC     --     trim(lower(field_37))
# MAGIC     --     when '' then null
# MAGIC     --     else trim(lower(field_37))
# MAGIC     --   end as alternate_email,
# MAGIC     --   split(trim(lower(field_37)), '@', 2) [1] as alternate_email_domain
# MAGIC     -- from
# MAGIC     --   main.it_docebo_bronze.core_user_field_value
# MAGIC     -- where
# MAGIC     --   processDate = (
# MAGIC     --     select
# MAGIC     --       max(processDate)
# MAGIC     --     from
# MAGIC     --       main.it_docebo_bronze.core_user_field_value
# MAGIC     --   )
# MAGIC   ),
# MAGIC   emails as (
# MAGIC     select
# MAGIC       distinct lower(email) as email,
# MAGIC       sha2(lower(email), 256) as email_hash
# MAGIC     from
# MAGIC       -- main.it_docebo_bronze.core_user
# MAGIC       main.it_training_silver.docebo_users
# MAGIC     where
# MAGIC       processdate =(
# MAGIC         Select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           -- main.it_docebo_bronze.core_user
# MAGIC           main.it_training_silver.docebo_users
# MAGIC       )
# MAGIC       and split(trim(lower(email)), '@', 2) [1] not in (
# MAGIC         select
# MAGIC           distinct blacklist_domain
# MAGIC         from
# MAGIC           blacklist_domains
# MAGIC       )
# MAGIC     union
# MAGIC       (
# MAGIC         select
# MAGIC           distinct lower(alternate_emails.alternate_email) as email,
# MAGIC           sha2(lower(alternate_Email), 256) as email_hash
# MAGIC         from
# MAGIC           alternate_emails
# MAGIC         where
# MAGIC           alternate_email_domain not in (
# MAGIC             select
# MAGIC               distinct blacklist_domain
# MAGIC             from
# MAGIC               blacklist_domains
# MAGIC           )
# MAGIC       )
# MAGIC   ),
# MAGIC   capability_final as (
# MAGIC     select
# MAGIC       p.*,
# MAGIC       e.email,
# MAGIC       case
# MAGIC         when p.bucket = 'Email is blacklist - select secondary' then e.email
# MAGIC         else p.updated_email
# MAGIC       end as final_email
# MAGIC     from
# MAGIC       capability_pre p
# MAGIC       left join emails e on p.learner_alternate_email_hash = e.email_hash
# MAGIC       and p.bucket = 'Email is blacklist - select secondary'
# MAGIC   ),
# MAGIC   -- fix learner_email_hash records that have one row with partner account and another without (because of learndot data)
# MAGIC   account_fix as (
# MAGIC     select
# MAGIC       distinct learner_email_hash,
# MAGIC       partner_account_name,
# MAGIC       partner_account_id_sfdc,
# MAGIC       dense_rank() over (
# MAGIC         partition by learner_email_hash
# MAGIC         order by
# MAGIC           partner_account_name nulls last
# MAGIC       ) as rank
# MAGIC     from
# MAGIC       partner_capability_vw
# MAGIC     where
# MAGIC       category = 'Technical Trained'
# MAGIC       and processDate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           partner_capability_vw
# MAGIC       )
# MAGIC   ),
# MAGIC   certs as (
# MAGIC     select
# MAGIC       p.final_email as certification_email,
# MAGIC       sha2(p.final_email, 256) as certification_email_hash,
# MAGIC       split(p.final_email, '@')[1] as email_domain,
# MAGIC       -- array_join(collect_set(p.updated_email), ",") as updated_email,
# MAGIC       -- array_join(collect_set(p.learner_email_hash), ",") as learner_email_hash,
# MAGIC       p.partner_account_name,
# MAGIC       p.partner_account_id_sfdc,
# MAGIC       u.region_derived,
# MAGIC       p.credential_id,
# MAGIC       p.course as credential_name
# MAGIC     from
# MAGIC       capability_final p
# MAGIC       left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
# MAGIC     where
# MAGIC       p.category in ('Technical Certified','Sales Badged','Delivery Specialization')
# MAGIC     -- group by
# MAGIC     --   all
# MAGIC   )
# MAGIC   ,
# MAGIC   top_80_partner_domains as (
# MAGIC     select distinct email_domain
# MAGIC     from main.field_learning_enablement.partner_domains_accounts
# MAGIC     where processDate = (select max(processDate) from main.field_learning_enablement.partner_domains_accounts)
# MAGIC     and ultimate_parent_account_name in (
# MAGIC       'Accenture (HQ)',
# MAGIC       'Tata Consultancy Services (HQ)',
# MAGIC       'Cognizant Technology Solutions (HQ)',
# MAGIC       'LTIMindtree Limited (HQ)',
# MAGIC       'Capgemini S.A. (HQ)',
# MAGIC       'Deloitte Consulting (HQ)',
# MAGIC       'E&Y (HQ)',
# MAGIC       'Avanade Inc (HQ)',
# MAGIC       'Infosys Technologies (HQ)',
# MAGIC       'Celebal Technologies Private Limited (HQ)',
# MAGIC       'Wipro (HQ)',
# MAGIC       'EPAM (HQ)',
# MAGIC       'Tech Mahindra Limited (HQ)',
# MAGIC       'Booz Allen Hamilton Partner',
# MAGIC       'Slalom Consulting (HQ)',
# MAGIC       'Impetus Technologies',
# MAGIC       'KPMG LLP (HQ)',
# MAGIC       'Tredence Inc (HQ)',
# MAGIC       'Fractal Analytics (HQ)',
# MAGIC       'Eviden (HQ)',
# MAGIC       'NTT Data Corporation (HQ)',
# MAGIC       'IBM (HQ)',
# MAGIC       'Tiger Analytics (HQ)',
# MAGIC       'Reply (HQ)',
# MAGIC       'DXC Technology (HQ)',
# MAGIC       'Conseillers en Gestion et Informatique CGI Inc. (HQ)',
# MAGIC       'Datametica Solutions',
# MAGIC       'Quantiphi (HQ)',
# MAGIC       'Persistent Systems Inc.',
# MAGIC       'Devoteam SA (HQ)',
# MAGIC       'Koantek LLC',
# MAGIC       'Kubrick Group (HQ)',
# MAGIC       'Wavicle Data Solutions',
# MAGIC       'McKinsey & Company (HQ)',
# MAGIC       'Agilisium Consulting (HQ)',
# MAGIC       'Perficient Inc',
# MAGIC       'Hitachi Solutions (HQ)',
# MAGIC       'Mphasis',
# MAGIC       'HCL Technologies (HQ)',
# MAGIC       'Fujitsu Australia Ltd. (HQ)',
# MAGIC       'Neudesic',
# MAGIC       'Insight Enterprises (HQ)',
# MAGIC       'Zeb',
# MAGIC       'ZS Associates',
# MAGIC       '3Cloud LLC',
# MAGIC       'JEMS Datafactory SASU',
# MAGIC       'Blackstraw.ai',
# MAGIC       'OpenValue',
# MAGIC       'CitiusTech Inc.',
# MAGIC       'ARQ',
# MAGIC       'Mantel Operations Pty Ltd',
# MAGIC       'Hexaware Technologies (HQ)',
# MAGIC       'Adastra (HQ)',
# MAGIC       'Factored, Inc.',
# MAGIC       'Valcon',
# MAGIC       'Thorogood Associates',
# MAGIC       'Nagarro Software Pvt Ltd (HQ)',
# MAGIC       'KPI Partners',
# MAGIC       'BlueShift Brasil',
# MAGIC       'SDK Tek Services Ltd.',
# MAGIC       'Virtusa',
# MAGIC       'Publicis sapient (APAC)',
# MAGIC       'Incedo Inc',
# MAGIC       'Fragma Data Systems',
# MAGIC       'Infogain Corporation (HQ)',
# MAGIC       'Computomic Software & Consulting LLC',
# MAGIC       'BI4ALL',
# MAGIC       'EXL Service',
# MAGIC       'BOSONIT S.L.',
# MAGIC       'Servian',
# MAGIC       'Minsait - Indra Sistemas Brand',
# MAGIC       'initions GmbH',
# MAGIC       'Lingaro sp. z o.o.',
# MAGIC       'Ekimetrics',
# MAGIC       'Elastacloud',
# MAGIC       'Guidehouse',
# MAGIC       'West Monroe',
# MAGIC       'Rackspace Hosting (HQ)',
# MAGIC       'twoday Holding Denmark ApS (HQ)',
# MAGIC       'Lovelytics (HQ)',
# MAGIC       'KPMG LLP (HQ)',
# MAGIC       'GENPACT (UK) LIMITED (HQ)',
# MAGIC       'Publicis Sapient (HQ)',
# MAGIC       'Kyndryl Inc (HQ)',
# MAGIC       'Aimpoint Digital',
# MAGIC       'LatentView Analytics',
# MAGIC       'PWC (HQ)',
# MAGIC       'Onix Networking Corp.',
# MAGIC       'Nagarro (HQ)',
# MAGIC       'Mantel Operations Pty Ltd (HQ)',
# MAGIC       'NCS Pte Ltd (HQ)',
# MAGIC       'Thoughtworks US',
# MAGIC       'Sopra Steria EspaÃ±a S.A.',
# MAGIC       'Lenovo (Hong Kong) Limited (HQ)',
# MAGIC       'syrencloud Inc',
# MAGIC       'Lingaro',
# MAGIC       'iLink Digital (HQ)',
# MAGIC       'Indicium',
# MAGIC       'Cuelebre AB (HQ)',
# MAGIC       'Bizmetric',
# MAGIC       'FPT Asia Pacific Pte Ltd (HQ)',
# MAGIC       'TO THE NEW Private Limited',
# MAGIC       'Hitachi Solutions, Ltd. (HQ)',
# MAGIC       'D ONE Value Creation AG',
# MAGIC       'RevoData',
# MAGIC       'Thorogood Associates (HQ)',
# MAGIC       'Lufthansa Industry Solutions GmbH & Co. KG',
# MAGIC       'Sigmoid (HQ)',
# MAGIC       'DIGIVATE LABS PRIVATE LIMITED',
# MAGIC       'BJSS',
# MAGIC       'Eleflow Big Data e Analytics',
# MAGIC       'XponentL Data, Inc.',
# MAGIC       'Tier One Analytics (HQ)',
# MAGIC       'Datapao',
# MAGIC       'InfoCepts LLC (HQ)',
# MAGIC       'Exponentia.ai Private limited',
# MAGIC       'Rackspace Singapore Pte Ltd',
# MAGIC       'NS Solutions Corporation',
# MAGIC       'Lovelytics Data, LLC (HQ)',
# MAGIC       'Blend360',
# MAGIC       'Eucloid Data Inc',
# MAGIC       'b.telligent Deutschland GmbH',
# MAGIC       'Xebia (HQ)',
# MAGIC       'Inteltion',
# MAGIC       'Nousot, Inc.',
# MAGIC       'DataNimbus',
# MAGIC       'Cegeka NV',
# MAGIC       'Tavant Technologies, Inc.',
# MAGIC       'Entrada AI, Inc.',
# MAGIC       'Daugherty Business Solutions',
# MAGIC       'MentorMate',
# MAGIC       'LumenData',
# MAGIC       'BDO Canada',
# MAGIC       'Encora Digital LLC',
# MAGIC       'Marlabs Inc.',
# MAGIC       'ORAYLIS GmbH',
# MAGIC       'STRATEQ SYSTEMS SDN BHD',
# MAGIC       'Telstra Purple (HQ)',
# MAGIC       'SDG Group (HQ)',
# MAGIC       'ELITMIND sp. z o. o.',
# MAGIC       'Advancing Analytics',
# MAGIC       'MACNICA, Inc. (HQ)',
# MAGIC       'Cavallo Technologies Inc',
# MAGIC       'Delaware Consulting CV',
# MAGIC       'Concentrix Catalyst',
# MAGIC       'Infinitive',
# MAGIC       'Cellenza SAS',
# MAGIC       'MEGAZONE CLOUD CORPORATION',
# MAGIC       'Fission Labs Inc',
# MAGIC       'Synechron',
# MAGIC       'SoftwareOne AG (HQ)',
# MAGIC       'Cloocus Co., Ltd. (HQ)',
# MAGIC       'Infomotion GmbH',
# MAGIC       'Analytics8, LLC',
# MAGIC       'Aubay (HQ)',
# MAGIC       'Wortell Smart',
# MAGIC       'Birlasoft Solutions Inc.',
# MAGIC       'Unify Consulting',
# MAGIC       'Artefact',
# MAGIC       'Woodmark AG',
# MAGIC       'Endava',
# MAGIC       'Quantori',
# MAGIC       'InfoServices LLC (HQ)',
# MAGIC       'MFEC Public Company Limited',
# MAGIC       'Nexer Group (HQ)',
# MAGIC       'Mastek Limited (HQ)',
# MAGIC       'Xoriant',
# MAGIC       'Fog Solutions Inc',
# MAGIC       'Xorbix Technologies Inc.',
# MAGIC       'Rearc',
# MAGIC       'Sunnydata Inc.',
# MAGIC       'Orion Innovation',
# MAGIC       'Brillio',
# MAGIC       'Blueprint Technologies',
# MAGIC       'Bosch Global Software Technologies Private Limited',
# MAGIC       'MatrixDnA (HQ)',
# MAGIC       'CI&T Software',
# MAGIC       'Billigence',
# MAGIC       'Orion Digital Solutions',
# MAGIC       'Ippon Technologies (HQ)',
# MAGIC       'Pariveda Solutions',
# MAGIC       'Jarvis Consulting Group',
# MAGIC       'Zennify, INC',
# MAGIC       'Searce PTE Ltd',
# MAGIC       'Aarini Consulting BV',
# MAGIC       'Acxiom',
# MAGIC       'ADA DIGITAL SINGAPORE PTE. LTD.',
# MAGIC       'ADD d.o.o. - Business Solutions',
# MAGIC       'Adesso',
# MAGIC       'Affine Inc (HQ)',
# MAGIC       'AIM Consulting',
# MAGIC       'AIonOS PTE. LTD.',
# MAGIC       'Aivix (HQ)',
# MAGIC       'Alexander Thamm GmbH',
# MAGIC       'Apex Systems (HQ)',
# MAGIC       'Ardentisys',
# MAGIC       'areto Consulting GmbH (HQ)',
# MAGIC       'ARKON DATA (COMPLEX ADAPTIVE SYSTEMS S.A.P.I. DE C.V.)',
# MAGIC       'Arsaga Partners Co., Ltd.',
# MAGIC       'Avvale S.p.A.',
# MAGIC       'BeesBridge LLC',
# MAGIC       'Bespin Global',
# MAGIC       'Bi3 technologies Pty Ltd',
# MAGIC       'BIP - Business Integration Partners SPA (HQ)',
# MAGIC       'Bits In Glass Inc.',
# MAGIC       'Blazeclan Technologies',
# MAGIC       'Bluechip Technologies Limited',
# MAGIC       'Bluetab Solutions S.L.U.',
# MAGIC       'Boston Consulting Group (HQ)',
# MAGIC       'Bounteous',
# MAGIC       'Bouvet Norge AS',
# MAGIC       'Brightly Works Oy',
# MAGIC       'BUSINESS PROCESS & TECHNOLOGIES INTEGRATION S.A.S',
# MAGIC       'C2S Technologies Inc',
# MAGIC       'CapTech',
# MAGIC       'Caylent',
# MAGIC       'Cloud1 Oy',
# MAGIC       'Cloudaeon Technology Limited',
# MAGIC       'CloudIQ Technologies',
# MAGIC       'Cognitivo Pty Ltd',
# MAGIC       'Colibri LTD',
# MAGIC       'Collaboration Betters The World GmbH (HQ)',
# MAGIC       'COMPASS UOL',
# MAGIC       'Confiz LLC (HQ)',
# MAGIC       'Credera',
# MAGIC       'Customertimes Corp',
# MAGIC       'Cyber Hunters Ltd',
# MAGIC       'Data Dynamics Inc',
# MAGIC       'Data Solucoes',
# MAGIC       'Data Surge LLC',
# MAGIC       'Dataeaze Systems Pvt. Ltd.',
# MAGIC       'DataPattern',
# MAGIC       'Dataside Solucoes em Dados LTDA',
# MAGIC       'Definitive Healthcare, LLC (SI Partner)',
# MAGIC       'Delegate',
# MAGIC       'DevScope',
# MAGIC       'Dufrain Consulting',
# MAGIC       'E-Simplicity',
# MAGIC       'Effectual Inc.',
# MAGIC       'ELCA',
# MAGIC       'element61',
# MAGIC       'Epical Sweden AB',
# MAGIC       'Epsilon',
# MAGIC       'Factspan Inc',
# MAGIC       'FTI Consulting, Inc.',
# MAGIC       'Futurice Oy',
# MAGIC       'Gainwell Technologies',
# MAGIC       'Ganit Business Solutions Private Limited',
# MAGIC       'GlobalLogic Corp. UK Ltd (HQ)',
# MAGIC       'Globant, LLC (HQ)',
# MAGIC       'Grid Dynamics Holdings Inc',
# MAGIC       'Halfspace',
# MAGIC       'Hiflylabs',
# MAGIC       'HOONAR TEKWURKS PRIVATE LIMITED',
# MAGIC       'Hoster-JP, Inc',
# MAGIC       'HSO ANZ (HQ)',
# MAGIC       'Hvar Consultoria LTDA',
# MAGIC       'ICONSULTING S.P.A.',
# MAGIC       'iData',
# MAGIC       'INDRA SOLUCIONES TECNOLOGÍAS DE LA INFORMACIÓN, S.L.U (HQ)',
# MAGIC       'InfoObjects, Inc.',
# MAGIC       'Infostretch Corporation (Apexon)',
# MAGIC       'Inovex GmbH',
# MAGIC       'Insight Global',
# MAGIC       'intelia',
# MAGIC       'Intelli5 INC',
# MAGIC       'Jump Label Solutions',
# MAGIC       'Kagool',
# MAGIC       'KI performance GmbH',
# MAGIC       'Knowit Ab (HQ)',
# MAGIC       'Kumulus',
# MAGIC       'Kushagramati Analytics Private Limited',
# MAGIC       'Lantern',
# MAGIC       'Leading Edge Group Limited',
# MAGIC       'Leega Consultoria e Informatica Ltda',
# MAGIC       'Lirik Inc.',
# MAGIC       'Long View Systems',
# MAGIC       'MICROPOLE',
# MAGIC       'MobiLab Solutions GmbH',
# MAGIC       'Modak Analytics LLP',
# MAGIC       'MP DATA',
# MAGIC       'Mu Sigma Business Solutions LLC',
# MAGIC       'Mutt Data (Vuriltek S.A)',
# MAGIC       'Ness Digital Engineering',
# MAGIC       'Netlight Consulting Oy (HQ)',
# MAGIC       'NucleusTeq',
# MAGIC       'OutcomeCatalyst LLC',
# MAGIC       'Paltech Consulting Private Limited',
# MAGIC       'Plain Concepts (HQ)',
# MAGIC       'Profinit EU, s.r.o.',
# MAGIC       'PUE Data',
# MAGIC       'Qubika (CLV Corp)',
# MAGIC       'RBA',
# MAGIC       'Redeploy AB (HQ)',
# MAGIC       'Rocket Science Development',
# MAGIC       'SAIC',
# MAGIC       'Scigility Switzerland AG',
# MAGIC       'Shorthills AI',
# MAGIC       'Smoothstack LLC',
# MAGIC       'SoftServe Inc. (HQ)',
# MAGIC       'Solita (HQ)',
# MAGIC       'SOUTHWORKS LLC',
# MAGIC       'synvert GmbH',
# MAGIC       'Systech Solutions, Inc.',
# MAGIC       'Talan SAS',
# MAGIC       'Tech Fabric LLC',
# MAGIC       'TEKsystems Global Services, LLC',
# MAGIC       'Telefónica Tech',
# MAGIC       'The Math Company',
# MAGIC       'Theta Systems Limited',
# MAGIC       'Tietoevry Finland Oy (HQ)',
# MAGIC       'Trace3',
# MAGIC       'Tudip Technologies',
# MAGIC       'UBDS Group Holdings Limited',
# MAGIC       'Ultra Tendency International GmbH (HQ)',
# MAGIC       'Valtech UK Limited(HQ)',
# MAGIC       'Value Momentum (HQ)',
# MAGIC       'WeVision LLC',
# MAGIC       'WinWire Technologies',
# MAGIC       'WISEANALYTICS.IO LTD',
# MAGIC       'WorldLink US',
# MAGIC       'Zeal Corporation',
# MAGIC       'Zsahar LLC'
# MAGIC     )
# MAGIC
# MAGIC   )
# MAGIC   ,
# MAGIC   top_80_partner_certs_emails as (
# MAGIC     select 
# MAGIC       certification_email, 
# MAGIC       credential_id
# MAGIC     from certs
# MAGIC     where email_domain in (select email_domain from top_80_partner_domains)
# MAGIC   )
# MAGIC
# MAGIC   select *
# MAGIC   from top_80_partner_certs_emails
# MAGIC   

# COMMAND ----------

# DBTITLE 1,Capability Certification Resolver
all_capability_certs = spark.sql('''
with capability_partner_certs as (
  select
    p.*,
    c.certification_email
  from all_capability p
  left join top_80_partner_certs c on p.credential_id = c.credential_id
    
)

select 
  case when contact_email is null and certification_email is not null then certification_email else contact_email end as contact_email,
  * except(contact_email, certification_email)
from capability_partner_certs
''')

# COMMAND ----------

# DBTITLE 1,Spark SQL Email Resolver
all_capacity_certs = spark.sql('''
with capacity_partner_certs as (
  select
    p.*,
    c.certification_email
  from all_capacity p
  left join top_80_partner_certs c on p.credential_id = c.credential_id
    
)
select 
  case when contact_email is null and certification_email is not null then certification_email else contact_email end as contact_email,
  * except(contact_email, certification_email)
from capacity_partner_certs
''')

# COMMAND ----------

# DBTITLE 1,Capacity Certificates TempView Generator
all_capability_certs.createOrReplaceTempView('all_capability_certs')
all_capacity_certs.createOrReplaceTempView('all_capacity_certs')

# COMMAND ----------

# DBTITLE 1,Enhanced Credential Reports Query
all_capability_certs_enhanced = spark.sql('''
  select 
    a.*,
    c.issued_on::date,
    c.calculated_expired_on::date,
    c.credential_name,
    case
      when a.partner_account_name in (
        'Accenture (HQ)',
        'Deloitte Consulting (HQ)',
        'Capgemini S.A. (HQ)',
        'Avanade Inc (HQ)',
        'Infosys Technologies (HQ)',
        'Cognizant Technology Solutions (HQ)',
        'E&Y (HQ)',
        'Slalom Consulting (HQ)',
        'Wipro (HQ)',
        'Tata Consultancy Services (HQ)'
      ) then 'GSI'
      else 'Others'
      end as classification,
      nvl(p.`Managed Coverage Group`, 'Scale Ecosystem - Unmanaged') as portfolio, 
      case when p.`Managed Coverage Group` is null then "Unmanaged" else "Managed" end as managed_partner
  from all_capability_certs a 
  left join main.field_learning_enablement.accredible_credentials c on a.credential_id = c.credential_id and c.processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
  left join main.gtm_partner_data.csi_partner_ecosystem_portfolio_mapping p on p.`Partner Id` = a.partner_account_id_sfdc

''')
all_capacity_certs_enhanced = spark.sql('''
  select 
    a.*,
    c.issued_on::date,
    c.calculated_expired_on::date,
    c.credential_name,
    case
      when a.partner_account_name in (
        'Accenture (HQ)',
        'Deloitte Consulting (HQ)',
        'Capgemini S.A. (HQ)',
        'Avanade Inc (HQ)',
        'Infosys Technologies (HQ)',
        'Cognizant Technology Solutions (HQ)',
        'E&Y (HQ)',
        'Slalom Consulting (HQ)',
        'Wipro (HQ)',
        'Tata Consultancy Services (HQ)'
      ) then 'GSI'
      else 'Others'
  end as classification,
  nvl(p.`Managed Coverage Group`, 'Scale Ecosystem - Unmanaged') as portfolio,
  case when p.`Managed Coverage Group` is null then "Unmanaged" else "Managed" end as managed_partner
  from all_capacity_certs a 
  left join main.field_learning_enablement.accredible_credentials c on a.credential_id = c.credential_id and c.processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
  left join main.gtm_partner_data.csi_partner_ecosystem_portfolio_mapping p on p.`Partner Id` = a.partner_account_id_sfdc

''')

# COMMAND ----------

# DBTITLE 1,Enhanced Capability Category Count
all_capability_certs_enhanced.createOrReplaceTempView('capability_final')

# COMMAND ----------

# DBTITLE 1,Partner Certification Analysis Query
all_partner_certs_by_company_email = spark.sql('''
  with ranked_docebo_users as (
    select
      *,
      rank() over (
        partition by email_hash
        order by
          last_login
      ) as rank_data
    from
      main.field_learning_enablement.docebo_users
    where
      processdate =(
        Select
          max(processdate)
        from
          main.field_learning_enablement.docebo_users
      )
      and nvl(audience, 'Unknown') in ('Partner', 'Partner Other')
  ),
  docebo_users as (
    select
      *
    from
      ranked_docebo_users
    where
      rank_data = 1
  ),
  blacklist_domains as (
    select
      distinct blacklist_domain
    from
      main.field_learning_enablement.blacklist_domains
    where
      processDate = (
        select
          max(processDate)
        from
          main.field_learning_enablement.blacklist_domains
      )
  ),
  capability as (
    select
      c.*
    except(c.learner_email_domain),
      case
        when c.learner_email_hash = '78dfc4089d9f80cbae14429cb95508c1955262ebdee4184c4e3fb3503a70ae18' then 'gmail.com'
        else learner_email_domain
      end as learner_email_domain
    from
      capability_final c
    where
      learner_email_hash is not null
  ),
  -- fix learner_user_ids records that have one row with contact email and another without (because of learndot data)
  contact_email_fix as (
    select
      distinct learner_email_hash,
      contact_email,
      dense_rank() over (
        partition by learner_email_hash
        order by
          contact_email nulls last
      ) as rank
    from
      capability_final
    where
      category = 'Technical Trained'
  ),
  capability_v2 as (
    select
      c.*,
      case
        when category = 'Technical Certified' then a.recipient_email
        else d.contact_email
      end as updated_email
    from
      capability c
      left join contact_email_fix d on c.learner_email_hash = d.learner_email_hash
      and d.rank = 1
      and c.category = 'Technical Trained'
      left join main.it_accredible_bronze.credentials a on c.credential_id = a.credential_id
      and a.processdate = (
        select
          max(processdate)
        from
          main.it_accredible_bronze.credentials
      )
  ),
  capability_v3 as (
    select
      c.*,
      b.blacklist_domain as b_blacklist_domain,
      b1.blacklist_domain as b1_blacklist_domain
    from
      capability_v2 c
      left join blacklist_domains b on c.learner_email_domain = b.blacklist_domain
      left join blacklist_domains b1 on c.learner_alternate_email_domain = b1.blacklist_domain
  ),
  capability_pre as (
    select
      *,
      case
        when b_blacklist_domain is not null
        and (
          b1_blacklist_domain is null
          and learner_alternate_email_domain is not null
        ) then 'Email is blacklist - select secondary'
        when b1_blacklist_domain is not null
        and (
          b_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Alternate email is blacklist - select primary'
        when (
          b_blacklist_domain is not null
          and b1_blacklist_domain is not null
          and learner_email_domain is not null
        ) then 'Only blacklist domains - select primary'
        when (
          b_blacklist_domain is null
          and b1_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Email Good - select primary'
        else 'Others'
      end as bucket
    from
      capability_v3
  ),
  alternate_emails as (
    select
      id_user,
      alternate_email,
      alternate_email_domain
    from
      alternate_emails
   -- select
   --   id_user,
   --   case
   --     trim(lower(field_37))
   --     when '' then null
   --     else trim(lower(field_37))
   --   end as alternate_email,
   --   split(trim(lower(field_37)), '@', 2) [1] as alternate_email_domain
   -- from
   --   main.it_docebo_bronze.core_user_field_value
   -- where
   --   processDate = (
   --     select
   --       max(processDate)
   --     from
   --       main.it_docebo_bronze.core_user_field_value
   --   )
  ),
  emails as (
    select
      distinct lower(email) as email,
      sha2(lower(email), 256) as email_hash
    from
      -- main.it_docebo_bronze.core_user
      main.it_training_silver.docebo_users
    where
      processdate =(
        Select
          max(processdate)
        from
          -- main.it_docebo_bronze.core_user
          main.it_training_silver.docebo_users
      )
      and split(trim(lower(email)), '@', 2) [1] not in (
        select
          distinct blacklist_domain
        from
          blacklist_domains
      )
    union
      (
        select
          distinct lower(alternate_emails.alternate_email) as email,
          sha2(lower(alternate_Email), 256) as email_hash
        from
          alternate_emails
        where
          alternate_email_domain not in (
            select
              distinct blacklist_domain
            from
              blacklist_domains
          )
      )
  ),
  capability_final as (
    select
      p.*,
      e.email,
      case
        when p.bucket = 'Email is blacklist - select secondary' then e.email
        else p.updated_email
      end as final_email
    from
      capability_pre p
      left join emails e on p.learner_alternate_email_hash = e.email_hash
      and p.bucket = 'Email is blacklist - select secondary'
  ),
  -- fix learner_email_hash records that have one row with partner account and another without (because of learndot data)
  account_fix as (
    select
      distinct learner_email_hash,
      partner_account_name,
      partner_account_id_sfdc,
      dense_rank() over (
        partition by learner_email_hash
        order by
          partner_account_name nulls last
      ) as rank
    from
      capability_final
    where
      category = 'Technical Trained'
  ),
  certs as (
    select
      p.final_email as certification_email,
      sha2(p.final_email, 256) as certification_email_hash,
      split(p.final_email, '@')[1] as email_domain,
      -- array_join(collect_set(p.updated_email), ",") as updated_email,
      -- array_join(collect_set(p.learner_email_hash), ",") as learner_email_hash,
      p.partner_account_name,
      p.partner_account_id_sfdc,
      u.region_derived,
      p.credential_id,
      p.issued_on,
      p.calculated_expired_on,
      p.course as credential_name
    from
      capability_final p
      left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
    where
      p.category = 'Technical Certified'
    -- group by
    --   all
  )
  

  ,
  final_1 as (
    select 
      credential_id, 
      certification_email, 
      credential_name, 
      partner_account_name, 
      issued_on, 
      calculated_expired_on as expired_on
    from certs
    where partner_account_name in (
      'Accenture (HQ)',
      'Tata Consultancy Services (HQ)',
      'Cognizant Technology Solutions (HQ)',
      'LTIMindtree Limited (HQ)',
      'Capgemini S.A. (HQ)',
      'Deloitte Consulting (HQ)',
      'E&Y (HQ)',
      'Avanade Inc (HQ)',
      'Infosys Technologies (HQ)',
      'Celebal Technologies Private Limited (HQ)',
      'Wipro (HQ)',
      'EPAM (HQ)',
      'Tech Mahindra Limited (HQ)',
      'Booz Allen Hamilton Partner',
      'Slalom Consulting (HQ)',
      'Impetus Technologies',
      'KPMG LLP (HQ)',
      'Tredence Inc (HQ)',
      'Fractal Analytics (HQ)',
      'Eviden (HQ)',
      'NTT Data Corporation (HQ)',
      'IBM (HQ)',
      'Tiger Analytics (HQ)',
      'Reply (HQ)',
      'DXC Technology (HQ)',
      'Conseillers en Gestion et Informatique CGI Inc. (HQ)',
      'Datametica Solutions',
      'Quantiphi (HQ)',
      'Persistent Systems Inc.',
      'Devoteam SA (HQ)',
      'Koantek LLC',
      'Kubrick Group (HQ)',
      'Wavicle Data Solutions',
      'McKinsey & Company (HQ)',
      'Agilisium Consulting (HQ)',
      'Perficient Inc',
      'Hitachi Solutions (HQ)',
      'Mphasis',
      'HCL Technologies (HQ)',
      'Fujitsu Australia Ltd. (HQ)',
      'Neudesic',
      'Insight Enterprises (HQ)',
      'Zeb',
      'ZS Associates',
      '3Cloud LLC',
      'JEMS Datafactory SASU',
      'Blackstraw.ai',
      'OpenValue',
      'CitiusTech Inc.',
      'ARQ',
      'Mantel Operations Pty Ltd',
      'Hexaware Technologies (HQ)',
      'Adastra (HQ)',
      'Factored, Inc.',
      'Valcon',
      'Thorogood Associates',
      'Nagarro Software Pvt Ltd (HQ)',
      'KPI Partners',
      'BlueShift Brasil',
      'SDK Tek Services Ltd.',
      'Virtusa',
      'Publicis sapient (APAC)',
      'Incedo Inc',
      'Fragma Data Systems',
      'Infogain Corporation (HQ)',
      'Computomic Software & Consulting LLC',
      'BI4ALL',
      'EXL Service',
      'BOSONIT S.L.',
      'Servian',
      'Minsait - Indra Sistemas Brand',
      'initions GmbH',
      'Lingaro sp. z o.o.',
      'Ekimetrics',
      'Elastacloud',
      'Guidehouse',
      'West Monroe',
      'Rackspace Hosting (HQ)',
      'twoday Holding Denmark ApS (HQ)',
      'Lovelytics (HQ)',
      'KPMG LLP (HQ)',
      'GENPACT (UK) LIMITED (HQ)',
      'Publicis Sapient (HQ)',
      'Kyndryl Inc (HQ)',
      'Aimpoint Digital',
      'LatentView Analytics',
      'PWC (HQ)',
      'Onix Networking Corp.',
      'Nagarro (HQ)',
      'Mantel Operations Pty Ltd (HQ)',
      'NCS Pte Ltd (HQ)',
      'Thoughtworks US',
      'Sopra Steria EspaÃ±a S.A.',
      'Lenovo (Hong Kong) Limited (HQ)',
      'syrencloud Inc',
      'Lingaro',
      'iLink Digital (HQ)',
      'Indicium',
      'Cuelebre AB (HQ)',
      'Bizmetric',
      'FPT Asia Pacific Pte Ltd (HQ)',
      'TO THE NEW Private Limited',
      'Hitachi Solutions, Ltd. (HQ)',
      'D ONE Value Creation AG',
      'RevoData',
      'Thorogood Associates (HQ)',
      'Lufthansa Industry Solutions GmbH & Co. KG',
      'Sigmoid (HQ)',
      'DIGIVATE LABS PRIVATE LIMITED',
      'BJSS',
      'Eleflow Big Data e Analytics',
      'XponentL Data, Inc.',
      'Tier One Analytics (HQ)',
      'Datapao',
      'InfoCepts LLC (HQ)',
      'Exponentia.ai Private limited',
      'Rackspace Singapore Pte Ltd',
      'NS Solutions Corporation',
      'Lovelytics Data, LLC (HQ)',
      'Blend360',
      'Eucloid Data Inc',
      'b.telligent Deutschland GmbH',
      'Xebia (HQ)',
      'Inteltion',
      'Nousot, Inc.',
      'DataNimbus',
      'Cegeka NV',
      'Tavant Technologies, Inc.',
      'Entrada AI, Inc.',
      'Daugherty Business Solutions',
      'MentorMate',
      'LumenData',
      'BDO Canada',
      'Encora Digital LLC',
      'Marlabs Inc.',
      'ORAYLIS GmbH',
      'STRATEQ SYSTEMS SDN BHD',
      'Telstra Purple (HQ)',
      'SDG Group (HQ)',
      'ELITMIND sp. z o. o.',
      'Advancing Analytics',
      'MACNICA, Inc. (HQ)',
      'Cavallo Technologies Inc',
      'Delaware Consulting CV',
      'Concentrix Catalyst',
      'Infinitive',
      'Cellenza SAS',
      'MEGAZONE CLOUD CORPORATION',
      'Fission Labs Inc',
      'Synechron',
      'SoftwareOne AG (HQ)',
      'Cloocus Co., Ltd. (HQ)',
      'Infomotion GmbH',
      'Analytics8, LLC',
      'Aubay (HQ)',
      'Wortell Smart',
      'Birlasoft Solutions Inc.',
      'Unify Consulting',
      'Artefact',
      'Woodmark AG',
      'Endava',
      'Quantori',
      'InfoServices LLC (HQ)',
      'MFEC Public Company Limited',
      'Nexer Group (HQ)',
      'Mastek Limited (HQ)',
      'Xoriant',
      'Fog Solutions Inc',
      'Xorbix Technologies Inc.',
      'Rearc',
      'Sunnydata Inc.',
      'Orion Innovation',
      'Brillio',
      'Blueprint Technologies',
      'Bosch Global Software Technologies Private Limited',
      'MatrixDnA (HQ)',
      'CI&T Software',
      'Billigence',
      'Orion Digital Solutions',
      'Ippon Technologies (HQ)',
      'Pariveda Solutions',
      'Jarvis Consulting Group',
      'Zennify, INC',
      'Searce PTE Ltd',
      'Aarini Consulting BV',
      'Acxiom',
      'ADA DIGITAL SINGAPORE PTE. LTD.',
      'ADD d.o.o. - Business Solutions',
      'Adesso',
      'Affine Inc (HQ)',
      'AIM Consulting',
      'AIonOS PTE. LTD.',
      'Aivix (HQ)',
      'Alexander Thamm GmbH',
      'Apex Systems (HQ)',
      'Ardentisys',
      'areto Consulting GmbH (HQ)',
      'ARKON DATA (COMPLEX ADAPTIVE SYSTEMS S.A.P.I. DE C.V.)',
      'Arsaga Partners Co., Ltd.',
      'Avvale S.p.A.',
      'BeesBridge LLC',
      'Bespin Global',
      'Bi3 technologies Pty Ltd',
      'BIP - Business Integration Partners SPA (HQ)',
      'Bits In Glass Inc.',
      'Blazeclan Technologies',
      'Bluechip Technologies Limited',
      'Bluetab Solutions S.L.U.',
      'Boston Consulting Group (HQ)',
      'Bounteous',
      'Bouvet Norge AS',
      'Brightly Works Oy',
      'BUSINESS PROCESS & TECHNOLOGIES INTEGRATION S.A.S',
      'C2S Technologies Inc',
      'CapTech',
      'Caylent',
      'Cloud1 Oy',
      'Cloudaeon Technology Limited',
      'CloudIQ Technologies',
      'Cognitivo Pty Ltd',
      'Colibri LTD',
      'Collaboration Betters The World GmbH (HQ)',
      'COMPASS UOL',
      'Confiz LLC (HQ)',
      'Credera',
      'Customertimes Corp',
      'Cyber Hunters Ltd',
      'Data Dynamics Inc',
      'Data Solucoes',
      'Data Surge LLC',
      'Dataeaze Systems Pvt. Ltd.',
      'DataPattern',
      'Dataside Solucoes em Dados LTDA',
      'Definitive Healthcare, LLC (SI Partner)',
      'Delegate',
      'DevScope',
      'Dufrain Consulting',
      'E-Simplicity',
      'Effectual Inc.',
      'ELCA',
      'element61',
      'Epical Sweden AB',
      'Epsilon',
      'Factspan Inc',
      'FTI Consulting, Inc.',
      'Futurice Oy',
      'Gainwell Technologies',
      'Ganit Business Solutions Private Limited',
      'GlobalLogic Corp. UK Ltd (HQ)',
      'Globant, LLC (HQ)',
      'Grid Dynamics Holdings Inc',
      'Halfspace',
      'Hiflylabs',
      'HOONAR TEKWURKS PRIVATE LIMITED',
      'Hoster-JP, Inc',
      'HSO ANZ (HQ)',
      'Hvar Consultoria LTDA',
      'ICONSULTING S.P.A.',
      'iData',
      'INDRA SOLUCIONES TECNOLOGÍAS DE LA INFORMACIÓN, S.L.U (HQ)',
      'InfoObjects, Inc.',
      'Infostretch Corporation (Apexon)',
      'Inovex GmbH',
      'Insight Global',
      'intelia',
      'Intelli5 INC',
      'Jump Label Solutions',
      'Kagool',
      'KI performance GmbH',
      'Knowit Ab (HQ)',
      'Kumulus',
      'Kushagramati Analytics Private Limited',
      'Lantern',
      'Leading Edge Group Limited',
      'Leega Consultoria e Informatica Ltda',
      'Lirik Inc.',
      'Long View Systems',
      'MICROPOLE',
      'MobiLab Solutions GmbH',
      'Modak Analytics LLP',
      'MP DATA',
      'Mu Sigma Business Solutions LLC',
      'Mutt Data (Vuriltek S.A)',
      'Ness Digital Engineering',
      'Netlight Consulting Oy (HQ)',
      'NucleusTeq',
      'OutcomeCatalyst LLC',
      'Paltech Consulting Private Limited',
      'Plain Concepts (HQ)',
      'Profinit EU, s.r.o.',
      'PUE Data',
      'Qubika (CLV Corp)',
      'RBA',
      'Redeploy AB (HQ)',
      'Rocket Science Development',
      'SAIC',
      'Scigility Switzerland AG',
      'Shorthills AI',
      'Smoothstack LLC',
      'SoftServe Inc. (HQ)',
      'Solita (HQ)',
      'SOUTHWORKS LLC',
      'synvert GmbH',
      'Systech Solutions, Inc.',
      'Talan SAS',
      'Tech Fabric LLC',
      'TEKsystems Global Services, LLC',
      'Telefónica Tech',
      'The Math Company',
      'Theta Systems Limited',
      'Tietoevry Finland Oy (HQ)',
      'Trace3',
      'Tudip Technologies',
      'UBDS Group Holdings Limited',
      'Ultra Tendency International GmbH (HQ)',
      'Valtech UK Limited(HQ)',
      'Value Momentum (HQ)',
      'WeVision LLC',
      'WinWire Technologies',
      'WISEANALYTICS.IO LTD',
      'WorldLink US',
      'Zeal Corporation',
      'Zsahar LLC'
    )
  ),

  final_2 as (
     select 
       credential_id, 
       "PII Redacted" as certification_email, 
       credential_name, 
       partner_account_name, 
       issued_on, 
       calculated_expired_on as expired_on
     from certs 
     where partner_account_name not in (
       'Accenture (HQ)',
      'Tata Consultancy Services (HQ)',
      'Cognizant Technology Solutions (HQ)',
      'LTIMindtree Limited (HQ)',
      'Capgemini S.A. (HQ)',
      'Deloitte Consulting (HQ)',
      'E&Y (HQ)',
      'Avanade Inc (HQ)',
      'Infosys Technologies (HQ)',
      'Celebal Technologies Private Limited (HQ)',
      'Wipro (HQ)',
      'EPAM (HQ)',
      'Tech Mahindra Limited (HQ)',
      'Booz Allen Hamilton Partner',
      'Slalom Consulting (HQ)',
      'Impetus Technologies',
      'KPMG LLP (HQ)',
      'Tredence Inc (HQ)',
      'Fractal Analytics (HQ)',
      'Eviden (HQ)',
      'NTT Data Corporation (HQ)',
      'IBM (HQ)',
      'Tiger Analytics (HQ)',
      'Reply (HQ)',
      'DXC Technology (HQ)',
      'Conseillers en Gestion et Informatique CGI Inc. (HQ)',
      'Datametica Solutions',
      'Quantiphi (HQ)',
      'Persistent Systems Inc.',
      'Devoteam SA (HQ)',
      'Koantek LLC',
      'Kubrick Group (HQ)',
      'Wavicle Data Solutions',
      'McKinsey & Company (HQ)',
      'Agilisium Consulting (HQ)',
      'Perficient Inc',
      'Hitachi Solutions (HQ)',
      'Mphasis',
      'HCL Technologies (HQ)',
      'Fujitsu Australia Ltd. (HQ)',
      'Neudesic',
      'Insight Enterprises (HQ)',
      'Zeb',
      'ZS Associates',
      '3Cloud LLC',
      'JEMS Datafactory SASU',
      'Blackstraw.ai',
      'OpenValue',
      'CitiusTech Inc.',
      'ARQ',
      'Mantel Operations Pty Ltd',
      'Hexaware Technologies (HQ)',
      'Adastra (HQ)',
      'Factored, Inc.',
      'Valcon',
      'Thorogood Associates',
      'Nagarro Software Pvt Ltd (HQ)',
      'KPI Partners',
      'BlueShift Brasil',
      'SDK Tek Services Ltd.',
      'Virtusa',
      'Publicis sapient (APAC)',
      'Incedo Inc',
      'Fragma Data Systems',
      'Infogain Corporation (HQ)',
      'Computomic Software & Consulting LLC',
      'BI4ALL',
      'EXL Service',
      'BOSONIT S.L.',
      'Servian',
      'Minsait - Indra Sistemas Brand',
      'initions GmbH',
      'Lingaro sp. z o.o.',
      'Ekimetrics',
      'Elastacloud',
      'Guidehouse',
      'West Monroe',
      'Rackspace Hosting (HQ)',
      'twoday Holding Denmark ApS (HQ)',
      'Lovelytics (HQ)',
      'KPMG LLP (HQ)',
      'GENPACT (UK) LIMITED (HQ)',
      'Publicis Sapient (HQ)',
      'Kyndryl Inc (HQ)',
      'Aimpoint Digital',
      'LatentView Analytics',
      'PWC (HQ)',
      'Onix Networking Corp.',
      'Nagarro (HQ)',
      'Mantel Operations Pty Ltd (HQ)',
      'NCS Pte Ltd (HQ)',
      'Thoughtworks US',
      'Sopra Steria EspaÃ±a S.A.',
      'Lenovo (Hong Kong) Limited (HQ)',
      'syrencloud Inc',
      'Lingaro',
      'iLink Digital (HQ)',
      'Indicium',
      'Cuelebre AB (HQ)',
      'Bizmetric',
      'FPT Asia Pacific Pte Ltd (HQ)',
      'TO THE NEW Private Limited',
      'Hitachi Solutions, Ltd. (HQ)',
      'D ONE Value Creation AG',
      'RevoData',
      'Thorogood Associates (HQ)',
      'Lufthansa Industry Solutions GmbH & Co. KG',
      'Sigmoid (HQ)',
      'DIGIVATE LABS PRIVATE LIMITED',
      'BJSS',
      'Eleflow Big Data e Analytics',
      'XponentL Data, Inc.',
      'Tier One Analytics (HQ)',
      'Datapao',
      'InfoCepts LLC (HQ)',
      'Exponentia.ai Private limited',
      'Rackspace Singapore Pte Ltd',
      'NS Solutions Corporation',
      'Lovelytics Data, LLC (HQ)',
      'Blend360',
      'Eucloid Data Inc',
      'b.telligent Deutschland GmbH',
      'Xebia (HQ)',
      'Inteltion',
      'Nousot, Inc.',
      'DataNimbus',
      'Cegeka NV',
      'Tavant Technologies, Inc.',
      'Entrada AI, Inc.',
      'Daugherty Business Solutions',
      'MentorMate',
      'LumenData',
      'BDO Canada',
      'Encora Digital LLC',
      'Marlabs Inc.',
      'ORAYLIS GmbH',
      'STRATEQ SYSTEMS SDN BHD',
      'Telstra Purple (HQ)',
      'SDG Group (HQ)',
      'ELITMIND sp. z o. o.',
      'Advancing Analytics',
      'MACNICA, Inc. (HQ)',
      'Cavallo Technologies Inc',
      'Delaware Consulting CV',
      'Concentrix Catalyst',
      'Infinitive',
      'Cellenza SAS',
      'MEGAZONE CLOUD CORPORATION',
      'Fission Labs Inc',
      'Synechron',
      'SoftwareOne AG (HQ)',
      'Cloocus Co., Ltd. (HQ)',
      'Infomotion GmbH',
      'Analytics8, LLC',
      'Aubay (HQ)',
      'Wortell Smart',
      'Birlasoft Solutions Inc.',
      'Unify Consulting',
      'Artefact',
      'Woodmark AG',
      'Endava',
      'Quantori',
      'InfoServices LLC (HQ)',
      'MFEC Public Company Limited',
      'Nexer Group (HQ)',
      'Mastek Limited (HQ)',
      'Xoriant',
      'Fog Solutions Inc',
      'Xorbix Technologies Inc.',
      'Rearc',
      'Sunnydata Inc.',
      'Orion Innovation',
      'Brillio',
      'Blueprint Technologies',
      'Bosch Global Software Technologies Private Limited',
      'MatrixDnA (HQ)',
      'CI&T Software',
      'Billigence',
      'Orion Digital Solutions',
      'Ippon Technologies (HQ)',
      'Pariveda Solutions',
      'Jarvis Consulting Group',
      'Zennify, INC',
      'Searce PTE Ltd',
      'Aarini Consulting BV',
      'Acxiom',
      'ADA DIGITAL SINGAPORE PTE. LTD.',
      'ADD d.o.o. - Business Solutions',
      'Adesso',
      'Affine Inc (HQ)',
      'AIM Consulting',
      'AIonOS PTE. LTD.',
      'Aivix (HQ)',
      'Alexander Thamm GmbH',
      'Apex Systems (HQ)',
      'Ardentisys',
      'areto Consulting GmbH (HQ)',
      'ARKON DATA (COMPLEX ADAPTIVE SYSTEMS S.A.P.I. DE C.V.)',
      'Arsaga Partners Co., Ltd.',
      'Avvale S.p.A.',
      'BeesBridge LLC',
      'Bespin Global',
      'Bi3 technologies Pty Ltd',
      'BIP - Business Integration Partners SPA (HQ)',
      'Bits In Glass Inc.',
      'Blazeclan Technologies',
      'Bluechip Technologies Limited',
      'Bluetab Solutions S.L.U.',
      'Boston Consulting Group (HQ)',
      'Bounteous',
      'Bouvet Norge AS',
      'Brightly Works Oy',
      'BUSINESS PROCESS & TECHNOLOGIES INTEGRATION S.A.S',
      'C2S Technologies Inc',
      'CapTech',
      'Caylent',
      'Cloud1 Oy',
      'Cloudaeon Technology Limited',
      'CloudIQ Technologies',
      'Cognitivo Pty Ltd',
      'Colibri LTD',
      'Collaboration Betters The World GmbH (HQ)',
      'COMPASS UOL',
      'Confiz LLC (HQ)',
      'Credera',
      'Customertimes Corp',
      'Cyber Hunters Ltd',
      'Data Dynamics Inc',
      'Data Solucoes',
      'Data Surge LLC',
      'Dataeaze Systems Pvt. Ltd.',
      'DataPattern',
      'Dataside Solucoes em Dados LTDA',
      'Definitive Healthcare, LLC (SI Partner)',
      'Delegate',
      'DevScope',
      'Dufrain Consulting',
      'E-Simplicity',
      'Effectual Inc.',
      'ELCA',
      'element61',
      'Epical Sweden AB',
      'Epsilon',
      'Factspan Inc',
      'FTI Consulting, Inc.',
      'Futurice Oy',
      'Gainwell Technologies',
      'Ganit Business Solutions Private Limited',
      'GlobalLogic Corp. UK Ltd (HQ)',
      'Globant, LLC (HQ)',
      'Grid Dynamics Holdings Inc',
      'Halfspace',
      'Hiflylabs',
      'HOONAR TEKWURKS PRIVATE LIMITED',
      'Hoster-JP, Inc',
      'HSO ANZ (HQ)',
      'Hvar Consultoria LTDA',
      'ICONSULTING S.P.A.',
      'iData',
      'INDRA SOLUCIONES TECNOLOGÍAS DE LA INFORMACIÓN, S.L.U (HQ)',
      'InfoObjects, Inc.',
      'Infostretch Corporation (Apexon)',
      'Inovex GmbH',
      'Insight Global',
      'intelia',
      'Intelli5 INC',
      'Jump Label Solutions',
      'Kagool',
      'KI performance GmbH',
      'Knowit Ab (HQ)',
      'Kumulus',
      'Kushagramati Analytics Private Limited',
      'Lantern',
      'Leading Edge Group Limited',
      'Leega Consultoria e Informatica Ltda',
      'Lirik Inc.',
      'Long View Systems',
      'MICROPOLE',
      'MobiLab Solutions GmbH',
      'Modak Analytics LLP',
      'MP DATA',
      'Mu Sigma Business Solutions LLC',
      'Mutt Data (Vuriltek S.A)',
      'Ness Digital Engineering',
      'Netlight Consulting Oy (HQ)',
      'NucleusTeq',
      'OutcomeCatalyst LLC',
      'Paltech Consulting Private Limited',
      'Plain Concepts (HQ)',
      'Profinit EU, s.r.o.',
      'PUE Data',
      'Qubika (CLV Corp)',
      'RBA',
      'Redeploy AB (HQ)',
      'Rocket Science Development',
      'SAIC',
      'Scigility Switzerland AG',
      'Shorthills AI',
      'Smoothstack LLC',
      'SoftServe Inc. (HQ)',
      'Solita (HQ)',
      'SOUTHWORKS LLC',
      'synvert GmbH',
      'Systech Solutions, Inc.',
      'Talan SAS',
      'Tech Fabric LLC',
      'TEKsystems Global Services, LLC',
      'Telefónica Tech',
      'The Math Company',
      'Theta Systems Limited',
      'Tietoevry Finland Oy (HQ)',
      'Trace3',
      'Tudip Technologies',
      'UBDS Group Holdings Limited',
      'Ultra Tendency International GmbH (HQ)',
      'Valtech UK Limited(HQ)',
      'Value Momentum (HQ)',
      'WeVision LLC',
      'WinWire Technologies',
      'WISEANALYTICS.IO LTD',
      'WorldLink US',
      'Zeal Corporation',
      'Zsahar LLC'
     )
  )

  , 

  final_3 as (
    select *
    from final_1
    union all 
    select *
    from final_2
  )

  select * from final_3

  
''')

# COMMAND ----------

expired_certs_df = spark.sql('''
  with ranked_docebo_users as ( 
    select
      *,
      rank() over (
        partition by email_hash
        order by
          last_login
      ) as rank_data
    from
      main.field_learning_enablement.docebo_users
    where
      processdate =(
        Select
          max(processdate)
        from
          main.field_learning_enablement.docebo_users
      )
      and nvl(audience, 'Unknown') in ('Partner', 'Partner Other')
  ),
  docebo_users as (
    select
      *
    from
      ranked_docebo_users
    where
      rank_data = 1
  ),
  blacklist_domains as (
    select
      distinct blacklist_domain
    from
      main.field_learning_enablement.blacklist_domains
    where
      processDate = (
        select
          max(processDate)
        from
          main.field_learning_enablement.blacklist_domains
      )
  )
  ,
  
  credentials as (
    select 
      c.*,
      a.recipient_email as contact_email
    from main.field_learning_enablement.accredible_credentials c
    left join main.it_accredible_bronze.credentials a on a.credential_id = c.credential_id and a.processDate = (select max(processDate) from main.it_accredible_bronze.credentials)
    where c.processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
    and c.group_id in (
      '371215', 
      '364119', 
      '357057', 
      '353856', 
      '331743', 
      '229201', 
      '227965', 
      '227818', 
      '583499'
    )
    and c.audience in ('Partner', 'Partner Other', 'Microsoft', 'Microsoft Other')
    and c.calculated_is_expired
  )
  ,

  blacklist as (
    select
      c.*,
      b.blacklist_domain as b_blacklist_domain,
      b1.blacklist_domain as b1_blacklist_domain
    from
      credentials c
      left join blacklist_domains b on c.learner_email_domain = b.blacklist_domain
      left join blacklist_domains b1 on c.learner_alternate_email_domain = b1.blacklist_domain
  )
  ,
  capability_pre as (
    select
      *,
      case
        when b_blacklist_domain is not null
        and (
          b1_blacklist_domain is null
          and learner_alternate_email_domain is not null
        ) then 'Email is blacklist - select secondary'
        when b1_blacklist_domain is not null
        and (
          b_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Alternate email is blacklist - select primary'
        when (
          b_blacklist_domain is not null
          and b1_blacklist_domain is not null
          and learner_email_domain is not null
        ) then 'Only blacklist domains - select primary'
        when (
          b_blacklist_domain is null
          and b1_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Email Good - select primary'
        else 'Others'
      end as bucket
    from
      blacklist
  )
  ,
  alternate_emails as (
    select
      id_user,
      alternate_email,
      alternate_email_domain
    from
      alternate_emails
  --  select
  --    id_user,
  --    case
  --      trim(lower(field_37))
  --      when '' then null
  --      else trim(lower(field_37))
  --    end as alternate_email,
  --    split(trim(lower(field_37)), '@', 2) [1] as alternate_email_domain
  --  from
  --    main.it_docebo_bronze.core_user_field_value
  --  where
  --    processDate = (
  --      select
  --        max(processDate)
  --      from
  --        main.it_docebo_bronze.core_user_field_value
  --    )
  ),
  emails as (
    select
      distinct lower(email) as email,
      sha2(lower(email), 256) as email_hash
    from
      -- main.it_docebo_bronze.core_user
      main.it_training_silver.docebo_users
    where
      processdate =(
        Select
          max(processdate)
        from
          -- main.it_docebo_bronze.core_user
          main.it_training_silver.docebo_users
      )
      and split(trim(lower(email)), '@', 2) [1] not in (
        select
          distinct blacklist_domain
        from
          blacklist_domains
      )
    union
      (
        select
          distinct lower(alternate_emails.alternate_email) as email,
          sha2(lower(alternate_Email), 256) as email_hash
        from
          alternate_emails
        where
          alternate_email_domain not in (
            select
              distinct blacklist_domain
            from
              blacklist_domains
          )
      )
  ),
  capability_final as (
    select
      p.*,
      e.email,
      case
        when p.bucket = 'Email is blacklist - select secondary' then e.email
        else p.contact_email
      end as final_email
    from
      capability_pre p
      left join emails e on p.learner_alternate_email_hash = e.email_hash
      and p.bucket = 'Email is blacklist - select secondary'
  )
  ,
  certs as (
    select
      p.final_email as certification_email,
      sha2(p.final_email, 256) as certification_email_hash,
      split(p.final_email, '@')[1] as email_domain,
      -- array_join(collect_set(p.updated_email), ",") as updated_email,
      -- array_join(collect_set(p.learner_email_hash), ",") as learner_email_hash,
      p.updated_ultimate_parent_account_name as partner_account_name,
      p.updated_ultimate_parent_account_id as partner_account_id_sfdc,
      u.region_derived,
      p.credential_id,
      p.issued_on,
      p.calculated_expired_on,
      p.credential_name
    from
      capability_final p
      left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
  )
  ,
  final_1 as (
    select 
      credential_id, 
      certification_email, 
      credential_name, 
      partner_account_name, 
      date_format(issued_on, "yyyy-MM-dd") as issued_on, 
      date_format(calculated_expired_on, "yyyy-MM-dd") as expired_on
    from certs
    where partner_account_name in (
      'Accenture (HQ)',
      'Tata Consultancy Services (HQ)',
      'Cognizant Technology Solutions (HQ)',
      'LTIMindtree Limited (HQ)',
      'Capgemini S.A. (HQ)',
      'Deloitte Consulting (HQ)',
      'E&Y (HQ)',
      'Avanade Inc (HQ)',
      'Infosys Technologies (HQ)',
      'Celebal Technologies Private Limited (HQ)',
      'Wipro (HQ)',
      'EPAM (HQ)',
      'Tech Mahindra Limited (HQ)',
      'Booz Allen Hamilton Partner',
      'Slalom Consulting (HQ)',
      'Impetus Technologies',
      'KPMG LLP (HQ)',
      'Tredence Inc (HQ)',
      'Fractal Analytics (HQ)',
      'Eviden (HQ)',
      'NTT Data Corporation (HQ)',
      'IBM (HQ)',
      'Tiger Analytics (HQ)',
      'Reply (HQ)',
      'DXC Technology (HQ)',
      'Conseillers en Gestion et Informatique CGI Inc. (HQ)',
      'Datametica Solutions',
      'Quantiphi (HQ)',
      'Persistent Systems Inc.',
      'Devoteam SA (HQ)',
      'Koantek LLC',
      'Kubrick Group (HQ)',
      'Wavicle Data Solutions',
      'McKinsey & Company (HQ)',
      'Agilisium Consulting (HQ)',
      'Perficient Inc',
      'Hitachi Solutions (HQ)',
      'Mphasis',
      'HCL Technologies (HQ)',
      'Fujitsu Australia Ltd. (HQ)',
      'Neudesic',
      'Insight Enterprises (HQ)',
      'Zeb',
      'ZS Associates',
      '3Cloud LLC',
      'JEMS Datafactory SASU',
      'Blackstraw.ai',
      'OpenValue',
      'CitiusTech Inc.',
      'ARQ',
      'Mantel Operations Pty Ltd',
      'Hexaware Technologies (HQ)',
      'Adastra (HQ)',
      'Factored, Inc.',
      'Valcon',
      'Thorogood Associates',
      'Nagarro Software Pvt Ltd (HQ)',
      'KPI Partners',
      'BlueShift Brasil',
      'SDK Tek Services Ltd.',
      'Virtusa',
      'Publicis sapient (APAC)',
      'Incedo Inc',
      'Fragma Data Systems',
      'Infogain Corporation (HQ)',
      'Computomic Software & Consulting LLC',
      'BI4ALL',
      'EXL Service',
      'BOSONIT S.L.',
      'Servian',
      'Minsait - Indra Sistemas Brand',
      'initions GmbH',
      'Lingaro sp. z o.o.',
      'Ekimetrics',
      'Elastacloud',
      'Guidehouse',
      'West Monroe',
      'Rackspace Hosting (HQ)',
      'twoday Holding Denmark ApS (HQ)',
      'Lovelytics (HQ)',
      'KPMG LLP (HQ)',
      'GENPACT (UK) LIMITED (HQ)',
      'Publicis Sapient (HQ)',
      'Kyndryl Inc (HQ)',
      'Aimpoint Digital',
      'LatentView Analytics',
      'PWC (HQ)',
      'Onix Networking Corp.',
      'Nagarro (HQ)',
      'Mantel Operations Pty Ltd (HQ)',
      'NCS Pte Ltd (HQ)',
      'Thoughtworks US',
      'Sopra Steria EspaÃ±a S.A.',
      'Lenovo (Hong Kong) Limited (HQ)',
      'syrencloud Inc',
      'Lingaro',
      'iLink Digital (HQ)',
      'Indicium',
      'Cuelebre AB (HQ)',
      'Bizmetric',
      'FPT Asia Pacific Pte Ltd (HQ)',
      'TO THE NEW Private Limited',
      'Hitachi Solutions, Ltd. (HQ)',
      'D ONE Value Creation AG',
      'RevoData',
      'Thorogood Associates (HQ)',
      'Lufthansa Industry Solutions GmbH & Co. KG',
      'Sigmoid (HQ)',
      'DIGIVATE LABS PRIVATE LIMITED',
      'BJSS',
      'Eleflow Big Data e Analytics',
      'XponentL Data, Inc.',
      'Tier One Analytics (HQ)',
      'Datapao',
      'InfoCepts LLC (HQ)',
      'Exponentia.ai Private limited',
      'Rackspace Singapore Pte Ltd',
      'NS Solutions Corporation',
      'Lovelytics Data, LLC (HQ)',
      'Blend360',
      'Eucloid Data Inc',
      'b.telligent Deutschland GmbH',
      'Xebia (HQ)',
      'Inteltion',
      'Nousot, Inc.',
      'DataNimbus',
      'Cegeka NV',
      'Tavant Technologies, Inc.',
      'Entrada AI, Inc.',
      'Daugherty Business Solutions',
      'MentorMate',
      'LumenData',
      'BDO Canada',
      'Encora Digital LLC',
      'Marlabs Inc.',
      'ORAYLIS GmbH',
      'STRATEQ SYSTEMS SDN BHD',
      'Telstra Purple (HQ)',
      'SDG Group (HQ)',
      'ELITMIND sp. z o. o.',
      'Advancing Analytics',
      'MACNICA, Inc. (HQ)',
      'Cavallo Technologies Inc',
      'Delaware Consulting CV',
      'Concentrix Catalyst',
      'Infinitive',
      'Cellenza SAS',
      'MEGAZONE CLOUD CORPORATION',
      'Fission Labs Inc',
      'Synechron',
      'SoftwareOne AG (HQ)',
      'Cloocus Co., Ltd. (HQ)',
      'Infomotion GmbH',
      'Analytics8, LLC',
      'Aubay (HQ)',
      'Wortell Smart',
      'Birlasoft Solutions Inc.',
      'Unify Consulting',
      'Artefact',
      'Woodmark AG',
      'Endava',
      'Quantori',
      'InfoServices LLC (HQ)',
      'MFEC Public Company Limited',
      'Nexer Group (HQ)',
      'Mastek Limited (HQ)',
      'Xoriant',
      'Fog Solutions Inc',
      'Xorbix Technologies Inc.',
      'Rearc',
      'Sunnydata Inc.',
      'Orion Innovation',
      'Brillio',
      'Blueprint Technologies',
      'Bosch Global Software Technologies Private Limited',
      'MatrixDnA (HQ)',
      'CI&T Software',
      'Billigence',
      'Orion Digital Solutions',
      'Ippon Technologies (HQ)',
      'Pariveda Solutions',
      'Jarvis Consulting Group',
      'Zennify, INC',
      'Searce PTE Ltd',
      'Aarini Consulting BV',
      'Acxiom',
      'ADA DIGITAL SINGAPORE PTE. LTD.',
      'ADD d.o.o. - Business Solutions',
      'Adesso',
      'Affine Inc (HQ)',
      'AIM Consulting',
      'AIonOS PTE. LTD.',
      'Aivix (HQ)',
      'Alexander Thamm GmbH',
      'Apex Systems (HQ)',
      'Ardentisys',
      'areto Consulting GmbH (HQ)',
      'ARKON DATA (COMPLEX ADAPTIVE SYSTEMS S.A.P.I. DE C.V.)',
      'Arsaga Partners Co., Ltd.',
      'Avvale S.p.A.',
      'BeesBridge LLC',
      'Bespin Global',
      'Bi3 technologies Pty Ltd',
      'BIP - Business Integration Partners SPA (HQ)',
      'Bits In Glass Inc.',
      'Blazeclan Technologies',
      'Bluechip Technologies Limited',
      'Bluetab Solutions S.L.U.',
      'Boston Consulting Group (HQ)',
      'Bounteous',
      'Bouvet Norge AS',
      'Brightly Works Oy',
      'BUSINESS PROCESS & TECHNOLOGIES INTEGRATION S.A.S',
      'C2S Technologies Inc',
      'CapTech',
      'Caylent',
      'Cloud1 Oy',
      'Cloudaeon Technology Limited',
      'CloudIQ Technologies',
      'Cognitivo Pty Ltd',
      'Colibri LTD',
      'Collaboration Betters The World GmbH (HQ)',
      'COMPASS UOL',
      'Confiz LLC (HQ)',
      'Credera',
      'Customertimes Corp',
      'Cyber Hunters Ltd',
      'Data Dynamics Inc',
      'Data Solucoes',
      'Data Surge LLC',
      'Dataeaze Systems Pvt. Ltd.',
      'DataPattern',
      'Dataside Solucoes em Dados LTDA',
      'Definitive Healthcare, LLC (SI Partner)',
      'Delegate',
      'DevScope',
      'Dufrain Consulting',
      'E-Simplicity',
      'Effectual Inc.',
      'ELCA',
      'element61',
      'Epical Sweden AB',
      'Epsilon',
      'Factspan Inc',
      'FTI Consulting, Inc.',
      'Futurice Oy',
      'Gainwell Technologies',
      'Ganit Business Solutions Private Limited',
      'GlobalLogic Corp. UK Ltd (HQ)',
      'Globant, LLC (HQ)',
      'Grid Dynamics Holdings Inc',
      'Halfspace',
      'Hiflylabs',
      'HOONAR TEKWURKS PRIVATE LIMITED',
      'Hoster-JP, Inc',
      'HSO ANZ (HQ)',
      'Hvar Consultoria LTDA',
      'ICONSULTING S.P.A.',
      'iData',
      'INDRA SOLUCIONES TECNOLOGÍAS DE LA INFORMACIÓN, S.L.U (HQ)',
      'InfoObjects, Inc.',
      'Infostretch Corporation (Apexon)',
      'Inovex GmbH',
      'Insight Global',
      'intelia',
      'Intelli5 INC',
      'Jump Label Solutions',
      'Kagool',
      'KI performance GmbH',
      'Knowit Ab (HQ)',
      'Kumulus',
      'Kushagramati Analytics Private Limited',
      'Lantern',
      'Leading Edge Group Limited',
      'Leega Consultoria e Informatica Ltda',
      'Lirik Inc.',
      'Long View Systems',
      'MICROPOLE',
      'MobiLab Solutions GmbH',
      'Modak Analytics LLP',
      'MP DATA',
      'Mu Sigma Business Solutions LLC',
      'Mutt Data (Vuriltek S.A)',
      'Ness Digital Engineering',
      'Netlight Consulting Oy (HQ)',
      'NucleusTeq',
      'OutcomeCatalyst LLC',
      'Paltech Consulting Private Limited',
      'Plain Concepts (HQ)',
      'Profinit EU, s.r.o.',
      'PUE Data',
      'Qubika (CLV Corp)',
      'RBA',
      'Redeploy AB (HQ)',
      'Rocket Science Development',
      'SAIC',
      'Scigility Switzerland AG',
      'Shorthills AI',
      'Smoothstack LLC',
      'SoftServe Inc. (HQ)',
      'Solita (HQ)',
      'SOUTHWORKS LLC',
      'synvert GmbH',
      'Systech Solutions, Inc.',
      'Talan SAS',
      'Tech Fabric LLC',
      'TEKsystems Global Services, LLC',
      'Telefónica Tech',
      'The Math Company',
      'Theta Systems Limited',
      'Tietoevry Finland Oy (HQ)',
      'Trace3',
      'Tudip Technologies',
      'UBDS Group Holdings Limited',
      'Ultra Tendency International GmbH (HQ)',
      'Valtech UK Limited(HQ)',
      'Value Momentum (HQ)',
      'WeVision LLC',
      'WinWire Technologies',
      'WISEANALYTICS.IO LTD',
      'WorldLink US',
      'Zeal Corporation',
      'Zsahar LLC'
    )
  )
  ,
  final_2 as (
    select 
      credential_id, 
      "PII Redacted" as certification_email, 
      credential_name, 
      partner_account_name, 
      issued_on, 
      calculated_expired_on as expired_on
    from certs 
    where partner_account_name not in (
      'Accenture (HQ)',
      'Tata Consultancy Services (HQ)',
      'Cognizant Technology Solutions (HQ)',
      'LTIMindtree Limited (HQ)',
      'Capgemini S.A. (HQ)',
      'Deloitte Consulting (HQ)',
      'E&Y (HQ)',
      'Avanade Inc (HQ)',
      'Infosys Technologies (HQ)',
      'Celebal Technologies Private Limited (HQ)',
      'Wipro (HQ)',
      'EPAM (HQ)',
      'Tech Mahindra Limited (HQ)',
      'Booz Allen Hamilton Partner',
      'Slalom Consulting (HQ)',
      'Impetus Technologies',
      'KPMG LLP (HQ)',
      'Tredence Inc (HQ)',
      'Fractal Analytics (HQ)',
      'Eviden (HQ)',
      'NTT Data Corporation (HQ)',
      'IBM (HQ)',
      'Tiger Analytics (HQ)',
      'Reply (HQ)',
      'DXC Technology (HQ)',
      'Conseillers en Gestion et Informatique CGI Inc. (HQ)',
      'Datametica Solutions',
      'Quantiphi (HQ)',
      'Persistent Systems Inc.',
      'Devoteam SA (HQ)',
      'Koantek LLC',
      'Kubrick Group (HQ)',
      'Wavicle Data Solutions',
      'McKinsey & Company (HQ)',
      'Agilisium Consulting (HQ)',
      'Perficient Inc',
      'Hitachi Solutions (HQ)',
      'Mphasis',
      'HCL Technologies (HQ)',
      'Fujitsu Australia Ltd. (HQ)',
      'Neudesic',
      'Insight Enterprises (HQ)',
      'Zeb',
      'ZS Associates',
      '3Cloud LLC',
      'JEMS Datafactory SASU',
      'Blackstraw.ai',
      'OpenValue',
      'CitiusTech Inc.',
      'ARQ',
      'Mantel Operations Pty Ltd',
      'Hexaware Technologies (HQ)',
      'Adastra (HQ)',
      'Factored, Inc.',
      'Valcon',
      'Thorogood Associates',
      'Nagarro Software Pvt Ltd (HQ)',
      'KPI Partners',
      'BlueShift Brasil',
      'SDK Tek Services Ltd.',
      'Virtusa',
      'Publicis sapient (APAC)',
      'Incedo Inc',
      'Fragma Data Systems',
      'Infogain Corporation (HQ)',
      'Computomic Software & Consulting LLC',
      'BI4ALL',
      'EXL Service',
      'BOSONIT S.L.',
      'Servian',
      'Minsait - Indra Sistemas Brand',
      'initions GmbH',
      'Lingaro sp. z o.o.',
      'Ekimetrics',
      'Elastacloud',
      'Guidehouse',
      'West Monroe',
      'Rackspace Hosting (HQ)',
      'twoday Holding Denmark ApS (HQ)',
      'Lovelytics (HQ)',
      'KPMG LLP (HQ)',
      'GENPACT (UK) LIMITED (HQ)',
      'Publicis Sapient (HQ)',
      'Kyndryl Inc (HQ)',
      'Aimpoint Digital',
      'LatentView Analytics',
      'PWC (HQ)',
      'Onix Networking Corp.',
      'Nagarro (HQ)',
      'Mantel Operations Pty Ltd (HQ)',
      'NCS Pte Ltd (HQ)',
      'Thoughtworks US',
      'Sopra Steria EspaÃ±a S.A.',
      'Lenovo (Hong Kong) Limited (HQ)',
      'syrencloud Inc',
      'Lingaro',
      'iLink Digital (HQ)',
      'Indicium',
      'Cuelebre AB (HQ)',
      'Bizmetric',
      'FPT Asia Pacific Pte Ltd (HQ)',
      'TO THE NEW Private Limited',
      'Hitachi Solutions, Ltd. (HQ)',
      'D ONE Value Creation AG',
      'RevoData',
      'Thorogood Associates (HQ)',
      'Lufthansa Industry Solutions GmbH & Co. KG',
      'Sigmoid (HQ)',
      'DIGIVATE LABS PRIVATE LIMITED',
      'BJSS',
      'Eleflow Big Data e Analytics',
      'XponentL Data, Inc.',
      'Tier One Analytics (HQ)',
      'Datapao',
      'InfoCepts LLC (HQ)',
      'Exponentia.ai Private limited',
      'Rackspace Singapore Pte Ltd',
      'NS Solutions Corporation',
      'Lovelytics Data, LLC (HQ)',
      'Blend360',
      'Eucloid Data Inc',
      'b.telligent Deutschland GmbH',
      'Xebia (HQ)',
      'Inteltion',
      'Nousot, Inc.',
      'DataNimbus',
      'Cegeka NV',
      'Tavant Technologies, Inc.',
      'Entrada AI, Inc.',
      'Daugherty Business Solutions',
      'MentorMate',
      'LumenData',
      'BDO Canada',
      'Encora Digital LLC',
      'Marlabs Inc.',
      'ORAYLIS GmbH',
      'STRATEQ SYSTEMS SDN BHD',
      'Telstra Purple (HQ)',
      'SDG Group (HQ)',
      'ELITMIND sp. z o. o.',
      'Advancing Analytics',
      'MACNICA, Inc. (HQ)',
      'Cavallo Technologies Inc',
      'Delaware Consulting CV',
      'Concentrix Catalyst',
      'Infinitive',
      'Cellenza SAS',
      'MEGAZONE CLOUD CORPORATION',
      'Fission Labs Inc',
      'Synechron',
      'SoftwareOne AG (HQ)',
      'Cloocus Co., Ltd. (HQ)',
      'Infomotion GmbH',
      'Analytics8, LLC',
      'Aubay (HQ)',
      'Wortell Smart',
      'Birlasoft Solutions Inc.',
      'Unify Consulting',
      'Artefact',
      'Woodmark AG',
      'Endava',
      'Quantori',
      'InfoServices LLC (HQ)',
      'MFEC Public Company Limited',
      'Nexer Group (HQ)',
      'Mastek Limited (HQ)',
      'Xoriant',
      'Fog Solutions Inc',
      'Xorbix Technologies Inc.',
      'Rearc',
      'Sunnydata Inc.',
      'Orion Innovation',
      'Brillio',
      'Blueprint Technologies',
      'Bosch Global Software Technologies Private Limited',
      'MatrixDnA (HQ)',
      'CI&T Software',
      'Billigence',
      'Orion Digital Solutions',
      'Ippon Technologies (HQ)',
      'Pariveda Solutions',
      'Jarvis Consulting Group',
      'Zennify, INC',
      'Searce PTE Ltd',
      'Aarini Consulting BV',
      'Acxiom',
      'ADA DIGITAL SINGAPORE PTE. LTD.',
      'ADD d.o.o. - Business Solutions',
      'Adesso',
      'Affine Inc (HQ)',
      'AIM Consulting',
      'AIonOS PTE. LTD.',
      'Aivix (HQ)',
      'Alexander Thamm GmbH',
      'Apex Systems (HQ)',
      'Ardentisys',
      'areto Consulting GmbH (HQ)',
      'ARKON DATA (COMPLEX ADAPTIVE SYSTEMS S.A.P.I. DE C.V.)',
      'Arsaga Partners Co., Ltd.',
      'Avvale S.p.A.',
      'BeesBridge LLC',
      'Bespin Global',
      'Bi3 technologies Pty Ltd',
      'BIP - Business Integration Partners SPA (HQ)',
      'Bits In Glass Inc.',
      'Blazeclan Technologies',
      'Bluechip Technologies Limited',
      'Bluetab Solutions S.L.U.',
      'Boston Consulting Group (HQ)',
      'Bounteous',
      'Bouvet Norge AS',
      'Brightly Works Oy',
      'BUSINESS PROCESS & TECHNOLOGIES INTEGRATION S.A.S',
      'C2S Technologies Inc',
      'CapTech',
      'Caylent',
      'Cloud1 Oy',
      'Cloudaeon Technology Limited',
      'CloudIQ Technologies',
      'Cognitivo Pty Ltd',
      'Colibri LTD',
      'Collaboration Betters The World GmbH (HQ)',
      'COMPASS UOL',
      'Confiz LLC (HQ)',
      'Credera',
      'Customertimes Corp',
      'Cyber Hunters Ltd',
      'Data Dynamics Inc',
      'Data Solucoes',
      'Data Surge LLC',
      'Dataeaze Systems Pvt. Ltd.',
      'DataPattern',
      'Dataside Solucoes em Dados LTDA',
      'Definitive Healthcare, LLC (SI Partner)',
      'Delegate',
      'DevScope',
      'Dufrain Consulting',
      'E-Simplicity',
      'Effectual Inc.',
      'ELCA',
      'element61',
      'Epical Sweden AB',
      'Epsilon',
      'Factspan Inc',
      'FTI Consulting, Inc.',
      'Futurice Oy',
      'Gainwell Technologies',
      'Ganit Business Solutions Private Limited',
      'GlobalLogic Corp. UK Ltd (HQ)',
      'Globant, LLC (HQ)',
      'Grid Dynamics Holdings Inc',
      'Halfspace',
      'Hiflylabs',
      'HOONAR TEKWURKS PRIVATE LIMITED',
      'Hoster-JP, Inc',
      'HSO ANZ (HQ)',
      'Hvar Consultoria LTDA',
      'ICONSULTING S.P.A.',
      'iData',
      'INDRA SOLUCIONES TECNOLOGÍAS DE LA INFORMACIÓN, S.L.U (HQ)',
      'InfoObjects, Inc.',
      'Infostretch Corporation (Apexon)',
      'Inovex GmbH',
      'Insight Global',
      'intelia',
      'Intelli5 INC',
      'Jump Label Solutions',
      'Kagool',
      'KI performance GmbH',
      'Knowit Ab (HQ)',
      'Kumulus',
      'Kushagramati Analytics Private Limited',
      'Lantern',
      'Leading Edge Group Limited',
      'Leega Consultoria e Informatica Ltda',
      'Lirik Inc.',
      'Long View Systems',
      'MICROPOLE',
      'MobiLab Solutions GmbH',
      'Modak Analytics LLP',
      'MP DATA',
      'Mu Sigma Business Solutions LLC',
      'Mutt Data (Vuriltek S.A)',
      'Ness Digital Engineering',
      'Netlight Consulting Oy (HQ)',
      'NucleusTeq',
      'OutcomeCatalyst LLC',
      'Paltech Consulting Private Limited',
      'Plain Concepts (HQ)',
      'Profinit EU, s.r.o.',
      'PUE Data',
      'Qubika (CLV Corp)',
      'RBA',
      'Redeploy AB (HQ)',
      'Rocket Science Development',
      'SAIC',
      'Scigility Switzerland AG',
      'Shorthills AI',
      'Smoothstack LLC',
      'SoftServe Inc. (HQ)',
      'Solita (HQ)',
      'SOUTHWORKS LLC',
      'synvert GmbH',
      'Systech Solutions, Inc.',
      'Talan SAS',
      'Tech Fabric LLC',
      'TEKsystems Global Services, LLC',
      'Telefónica Tech',
      'The Math Company',
      'Theta Systems Limited',
      'Tietoevry Finland Oy (HQ)',
      'Trace3',
      'Tudip Technologies',
      'UBDS Group Holdings Limited',
      'Ultra Tendency International GmbH (HQ)',
      'Valtech UK Limited(HQ)',
      'Value Momentum (HQ)',
      'WeVision LLC',
      'WinWire Technologies',
      'WISEANALYTICS.IO LTD',
      'WorldLink US',
      'Zeal Corporation',
      'Zsahar LLC'
    )
  )

  , 

  final_3 as (
    select *
    from final_1
    union all 
    select *
    from final_2
  )

  select *
  from final_3

''')

# COMMAND ----------

# %sql

# select Partner_Type__c, Account_Record_Type_Name__c, Partner_Manager__c, *
# from main.sfdc_bronze.account
# where processDate = (select max(processDate) from main.sfdc_bronze.account)
# and Partner_Type__c = 'Consulting & SI'
# and Account_Record_Type_Name__c = 'Partner'
# -- and id = '0013f000002n9WvAAI'
# and account.Account_Record_Id__c = "0013f000002n9WvAAI"

# COMMAND ----------

# display(
#   sfdc_account
#     # .filter(F.col("Partner_Type__c") == "Consulting & SI")
# )

# COMMAND ----------

# %sql
# select *
# from main.sfdc_bronze.contact 
# where processdate = (select max(processDate) from main.sfdc_bronze.contact)
# -- and id = "0053f000000Wam6AAC"

# COMMAND ----------

# MAGIC %md
# MAGIC The below 2 lines are used to excluded reporting of "Partner Training - Advantages of Tech Readiness & Data Intelligence" as Sales Badged (JIRA ticket: https://databricks.atlassian.net/browse/ESO-280)

# COMMAND ----------

all_capacity_certs_enhanced=all_capacity_certs_enhanced.withColumn("category",\
                                      when(all_capacity_certs_enhanced.credential_name=="Partner Training - Advantages of Tech Readiness & Data Intelligence","Other")\
                                      .otherwise(all_capacity_certs_enhanced.category))

# COMMAND ----------

all_capability_certs_enhanced=all_capability_certs_enhanced.withColumn("category",\
                                      when(all_capability_certs_enhanced.credential_name=="Partner Training - Advantages of Tech Readiness & Data Intelligence","Other")\
                                      .otherwise(all_capability_certs_enhanced.category))

# COMMAND ----------

# DBTITLE 1,Gold Metadata Augmentation Routine
all_capability_enhanced_partition = add_gold_metadata(all_capability_certs_enhanced)
all_capacity_enhanced_partition = add_gold_metadata(all_capacity_certs_enhanced)
all_partner_certs_by_company_email_partition = add_gold_metadata(all_partner_certs_by_company_email)
expired_certs_df_partition = add_gold_metadata(expired_certs_df)

# COMMAND ----------

# all_capability_enhanced_partition = add_gold_metadata(all_capability_enhanced_country_region)
# all_capacity_enhanced_partition = add_gold_metadata(all_capacity_enhanced_country_region)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_capability_enhanced_partition.distinct(), 
  table_name = f'{focus_database_name}.partner_capability', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_capacity_enhanced_partition.distinct(), 
  table_name = f'{focus_database_name}.partner_capacity', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = all_partner_certs_by_company_email_partition, 
#   table_name = f'{focus_database_name}.partner_certs_by_company_email', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = expired_certs_df_partition, 
#   table_name = f'{focus_database_name}.partner_expired_certs_by_company_email', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )

# COMMAND ----------

