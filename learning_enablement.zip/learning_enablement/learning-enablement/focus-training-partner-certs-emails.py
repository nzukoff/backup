# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# from pprint import pprint
# from pyspark.sql import DataFrame, Column
# from typing import Optional, Sequence as Seq, Dict, Callable, Any

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view top_80_partner_certs as 
# MAGIC
# MAGIC with ranked_docebo_users as (
# MAGIC     select
# MAGIC       *,
# MAGIC       rank() over (
# MAGIC         partition by email_hash
# MAGIC         order by
# MAGIC           last_login
# MAGIC       ) as rank_data
# MAGIC     from
# MAGIC       main.field_learning_enablement.docebo_users
# MAGIC     where
# MAGIC       processdate =(
# MAGIC         Select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.docebo_users
# MAGIC       )
# MAGIC       and nvl(audience, 'Unknown') in ('Partner', 'Partner Other')
# MAGIC   ),
# MAGIC   docebo_users as (
# MAGIC     select
# MAGIC       *
# MAGIC     from
# MAGIC       ranked_docebo_users
# MAGIC     where
# MAGIC       rank_data = 1
# MAGIC   ),
# MAGIC   blacklist_domains as (
# MAGIC     select
# MAGIC       distinct blacklist_domain
# MAGIC     from
# MAGIC       main.field_learning_enablement.blacklist_domains
# MAGIC     where
# MAGIC       processDate = (
# MAGIC         select
# MAGIC           max(processDate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.blacklist_domains
# MAGIC       )
# MAGIC   ),
# MAGIC   capability as (
# MAGIC     select
# MAGIC       c.*
# MAGIC     except(c.learner_email_domain),
# MAGIC       case
# MAGIC         when c.learner_email_hash = '78dfc4089d9f80cbae14429cb95508c1955262ebdee4184c4e3fb3503a70ae18' then 'gmail.com'
# MAGIC         else learner_email_domain
# MAGIC       end as learner_email_domain
# MAGIC     from
# MAGIC       main.field_learning_enablement.partner_capability c
# MAGIC     where
# MAGIC       c.processdate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.partner_capability
# MAGIC       )
# MAGIC       and learner_email_hash is not null
# MAGIC   ),
# MAGIC   -- fix learner_user_ids records that have one row with contact email and another without (because of learndot data)
# MAGIC   contact_email_fix as (
# MAGIC     select
# MAGIC       distinct learner_email_hash,
# MAGIC       contact_email,
# MAGIC       dense_rank() over (
# MAGIC         partition by learner_email_hash
# MAGIC         order by
# MAGIC           contact_email nulls last
# MAGIC       ) as rank
# MAGIC     from
# MAGIC       main.field_learning_enablement.partner_capability
# MAGIC     where
# MAGIC       category = 'Technical Trained'
# MAGIC       and processDate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.partner_capability
# MAGIC       )
# MAGIC   ),
# MAGIC   capability_v2 as (
# MAGIC     select
# MAGIC       c.*,
# MAGIC       case
# MAGIC         when category = 'Technical Certified' then a.recipient_email
# MAGIC         else d.contact_email
# MAGIC       end as updated_email
# MAGIC     from
# MAGIC       capability c
# MAGIC       left join contact_email_fix d on c.learner_email_hash = d.learner_email_hash
# MAGIC       and d.rank = 1
# MAGIC       and c.category = 'Technical Trained'
# MAGIC       left join main.it_accredible_bronze.credentials a on c.credential_id = a.credential_id
# MAGIC       and a.processdate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.it_accredible_bronze.credentials
# MAGIC       )
# MAGIC   ),
# MAGIC   capability_v3 as (
# MAGIC     select
# MAGIC       c.*,
# MAGIC       b.blacklist_domain as b_blacklist_domain,
# MAGIC       b1.blacklist_domain as b1_blacklist_domain
# MAGIC     from
# MAGIC       capability_v2 c
# MAGIC       left join blacklist_domains b on c.learner_email_domain = b.blacklist_domain
# MAGIC       left join blacklist_domains b1 on c.learner_alternate_email_domain = b1.blacklist_domain
# MAGIC   ),
# MAGIC   capability_pre as (
# MAGIC     select
# MAGIC       *,
# MAGIC       case
# MAGIC         when b_blacklist_domain is not null
# MAGIC         and (
# MAGIC           b1_blacklist_domain is null
# MAGIC           and learner_alternate_email_domain is not null
# MAGIC         ) then 'Email is blacklist - select secondary'
# MAGIC         when b1_blacklist_domain is not null
# MAGIC         and (
# MAGIC           b_blacklist_domain is null
# MAGIC           and learner_email_domain is not null
# MAGIC         ) then 'Alternate email is blacklist - select primary'
# MAGIC         when (
# MAGIC           b_blacklist_domain is not null
# MAGIC           and b1_blacklist_domain is not null
# MAGIC           and learner_email_domain is not null
# MAGIC         ) then 'Only blacklist domains - select primary'
# MAGIC         when (
# MAGIC           b_blacklist_domain is null
# MAGIC           and b1_blacklist_domain is null
# MAGIC           and learner_email_domain is not null
# MAGIC         ) then 'Email Good - select primary'
# MAGIC         else 'Others'
# MAGIC       end as bucket
# MAGIC     from
# MAGIC       capability_v3
# MAGIC   ),
# MAGIC   --alternate_emails as (
# MAGIC   --  select
# MAGIC   --    id_user,
# MAGIC   --    case
# MAGIC   --      trim(lower(field_37))
# MAGIC   --      when '' then null
# MAGIC   --      else trim(lower(field_37))
# MAGIC   --    end as alternate_email,
# MAGIC   --    split(trim(lower(field_37)), '@', 2) [1] as alternate_email_domain
# MAGIC   --  from
# MAGIC   --    main.it_docebo_bronze.core_user_field_value
# MAGIC   --  where
# MAGIC   --    processDate = (
# MAGIC   --      select
# MAGIC   --        max(processDate)
# MAGIC   --      from
# MAGIC   --        main.it_docebo_bronze.core_user_field_value
# MAGIC   --    )
# MAGIC   --),
# MAGIC
# MAGIC   alternate_emails as (
# MAGIC     select
# MAGIC       id_user,
# MAGIC       case
# MAGIC         trim(lower(field_value))
# MAGIC         when '' then null
# MAGIC         else trim(lower(field_value))
# MAGIC       end as alternate_email,
# MAGIC       split(trim(lower(field_value)), '@', 2) [1] as alternate_email_domain
# MAGIC     from
# MAGIC       main.it_docebo_bronze.core_user_field_value
# MAGIC     where
# MAGIC       processDate = (
# MAGIC         select
# MAGIC           max(processDate)
# MAGIC         from
# MAGIC           main.it_docebo_bronze.core_user_field_value
# MAGIC       )
# MAGIC     and id_field = 37
# MAGIC   ),
# MAGIC   emails as (
# MAGIC     select
# MAGIC       distinct lower(email) as email,
# MAGIC       sha2(lower(email), 256) as email_hash
# MAGIC     from
# MAGIC       main.it_docebo_bronze.core_user
# MAGIC     where
# MAGIC       processdate =(
# MAGIC         Select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.it_docebo_bronze.core_user
# MAGIC       )
# MAGIC       and split(trim(lower(email)), '@', 2) [1] not in (
# MAGIC         select
# MAGIC           distinct blacklist_domain
# MAGIC         from
# MAGIC           blacklist_domains
# MAGIC       )
# MAGIC     union
# MAGIC       (
# MAGIC         select
# MAGIC           distinct lower(alternate_emails.alternate_email) as email,
# MAGIC           sha2(lower(alternate_Email), 256) as email_hash
# MAGIC         from
# MAGIC           alternate_emails
# MAGIC         where
# MAGIC           alternate_email_domain not in (
# MAGIC             select
# MAGIC               distinct blacklist_domain
# MAGIC             from
# MAGIC               blacklist_domains
# MAGIC           )
# MAGIC       )
# MAGIC   ),
# MAGIC   capability_final as (
# MAGIC     select
# MAGIC       p.*,
# MAGIC       e.email,
# MAGIC       case
# MAGIC         when p.bucket = 'Email is blacklist - select secondary' then e.email
# MAGIC         else p.updated_email
# MAGIC       end as final_email
# MAGIC     from
# MAGIC       capability_pre p
# MAGIC       left join emails e on p.learner_alternate_email_hash = e.email_hash
# MAGIC       and p.bucket = 'Email is blacklist - select secondary'
# MAGIC   ),
# MAGIC   -- fix learner_email_hash records that have one row with partner account and another without (because of learndot data)
# MAGIC   account_fix as (
# MAGIC     select
# MAGIC       distinct learner_email_hash,
# MAGIC       partner_account_name,
# MAGIC       partner_account_id_sfdc,
# MAGIC       dense_rank() over (
# MAGIC         partition by learner_email_hash
# MAGIC         order by
# MAGIC           partner_account_name nulls last
# MAGIC       ) as rank
# MAGIC     from
# MAGIC       main.field_learning_enablement.partner_capability
# MAGIC     where
# MAGIC       category = 'Technical Trained'
# MAGIC       and processDate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.partner_capability
# MAGIC       )
# MAGIC   ),
# MAGIC   certs as (
# MAGIC     select
# MAGIC       p.final_email as certification_email,
# MAGIC       sha2(p.final_email, 256) as certification_email_hash,
# MAGIC       split(p.final_email, '@')[1] as email_domain,
# MAGIC       -- array_join(collect_set(p.updated_email), ",") as updated_email,
# MAGIC       -- array_join(collect_set(p.learner_email_hash), ",") as learner_email_hash,
# MAGIC       p.partner_account_name,
# MAGIC       p.partner_account_id_sfdc,
# MAGIC       u.region_derived,
# MAGIC       p.credential_id,
# MAGIC       p.course as credential_name
# MAGIC     from
# MAGIC       capability_final p
# MAGIC       left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
# MAGIC     where
# MAGIC       p.category = 'Technical Certified'
# MAGIC     -- group by
# MAGIC     --   all
# MAGIC   )
# MAGIC   ,
# MAGIC   top_80_partner_domains as (
# MAGIC     select distinct email_domain
# MAGIC     from main.field_learning_enablement.partner_domains_accounts
# MAGIC     where processDate = (select max(processDate) from main.field_learning_enablement.partner_domains_accounts)
# MAGIC     and ultimate_parent_account_name in (
# MAGIC       'Accenture (HQ)',
# MAGIC       'Tata Consultancy Services (HQ)',
# MAGIC       'Cognizant Technology Solutions (HQ)',
# MAGIC       'LTIMindtree Limited (HQ)',
# MAGIC       'Capgemini S.A. (HQ)',
# MAGIC       'Deloitte Consulting (HQ)',
# MAGIC       'E&Y (HQ)',
# MAGIC       'Avanade Inc (HQ)',
# MAGIC       'Infosys Technologies (HQ)',
# MAGIC       'Celebal Technologies Private Limited (HQ)',
# MAGIC       'Wipro (HQ)',
# MAGIC       'EPAM (HQ)',
# MAGIC       'Tech Mahindra Limited (HQ)',
# MAGIC       'Booz Allen Hamilton Partner',
# MAGIC       'Slalom Consulting (HQ)',
# MAGIC       'Impetus Technologies',
# MAGIC       'KPMG LLP (HQ)',
# MAGIC       'Tredence Inc (HQ)',
# MAGIC       'Fractal Analytics (HQ)',
# MAGIC       'Eviden (HQ)',
# MAGIC       'NTT Data Corporation (HQ)',
# MAGIC       'IBM (HQ)',
# MAGIC       'Tiger Analytics (HQ)',
# MAGIC       'Reply (HQ)',
# MAGIC       'DXC Technology (HQ)',
# MAGIC       'Conseillers en Gestion et Informatique CGI Inc. (HQ)',
# MAGIC       'Datametica Solutions',
# MAGIC       'Quantiphi (HQ)',
# MAGIC       'Persistent Systems Inc.',
# MAGIC       'Devoteam SA (HQ)',
# MAGIC       'Koantek LLC',
# MAGIC       'Kubrick Group (HQ)',
# MAGIC       'Wavicle Data Solutions',
# MAGIC       'McKinsey & Company (HQ)',
# MAGIC       'Agilisium Consulting (HQ)',
# MAGIC       'Perficient Inc',
# MAGIC       'Hitachi Solutions (HQ)',
# MAGIC       'Mphasis',
# MAGIC       'HCL Technologies (HQ)',
# MAGIC       'Fujitsu Australia Ltd. (HQ)',
# MAGIC       'Neudesic',
# MAGIC       'Insight Enterprises (HQ)',
# MAGIC       'Zeb',
# MAGIC       'ZS Associates',
# MAGIC       '3Cloud LLC',
# MAGIC       'JEMS Datafactory SASU',
# MAGIC       'Blackstraw.ai',
# MAGIC       'OpenValue',
# MAGIC       'CitiusTech Inc.',
# MAGIC       'ARQ',
# MAGIC       'Mantel Operations Pty Ltd',
# MAGIC       'Hexaware Technologies (HQ)',
# MAGIC       'Adastra (HQ)',
# MAGIC       'Factored, Inc.',
# MAGIC       'Valcon',
# MAGIC       'Thorogood Associates',
# MAGIC       'Nagarro Software Pvt Ltd (HQ)',
# MAGIC       'KPI Partners',
# MAGIC       'BlueShift Brasil',
# MAGIC       'SDK Tek Services Ltd.',
# MAGIC       'Virtusa',
# MAGIC       'Publicis sapient (APAC)',
# MAGIC       'Incedo Inc',
# MAGIC       'Fragma Data Systems',
# MAGIC       'Infogain Corporation (HQ)',
# MAGIC       'Computomic Software & Consulting LLC',
# MAGIC       'BI4ALL',
# MAGIC       'EXL Service',
# MAGIC       'BOSONIT S.L.',
# MAGIC       'Servian',
# MAGIC       'Minsait - Indra Sistemas Brand',
# MAGIC       'initions GmbH',
# MAGIC       'Lingaro sp. z o.o.',
# MAGIC       'Ekimetrics',
# MAGIC       'Elastacloud',
# MAGIC       'Guidehouse',
# MAGIC       'West Monroe',
# MAGIC       'Rackspace Hosting (HQ)',
# MAGIC       'twoday Holding Denmark ApS (HQ)',
# MAGIC       'Lovelytics (HQ)',
# MAGIC       'KPMG LLP (HQ)',
# MAGIC       'GENPACT (UK) LIMITED (HQ)',
# MAGIC       'Publicis Sapient (HQ)',
# MAGIC       'Kyndryl Inc (HQ)',
# MAGIC       'Aimpoint Digital',
# MAGIC       'LatentView Analytics',
# MAGIC       'PWC (HQ)',
# MAGIC       'Onix Networking Corp.',
# MAGIC       'Nagarro (HQ)',
# MAGIC       'Mantel Operations Pty Ltd (HQ)',
# MAGIC       'NCS Pte Ltd (HQ)',
# MAGIC       'Thoughtworks US',
# MAGIC       'Sopra Steria EspaÃ±a S.A.',
# MAGIC       'Lenovo (Hong Kong) Limited (HQ)',
# MAGIC       'syrencloud Inc',
# MAGIC       'Lingaro',
# MAGIC       'iLink Digital (HQ)',
# MAGIC       'Indicium',
# MAGIC       'Cuelebre AB (HQ)',
# MAGIC       'Bizmetric',
# MAGIC       'FPT Asia Pacific Pte Ltd (HQ)',
# MAGIC       'TO THE NEW Private Limited',
# MAGIC       'Hitachi Solutions, Ltd. (HQ)',
# MAGIC       'D ONE Value Creation AG',
# MAGIC       'RevoData',
# MAGIC       'Thorogood Associates (HQ)',
# MAGIC       'Lufthansa Industry Solutions GmbH & Co. KG',
# MAGIC       'Sigmoid (HQ)',
# MAGIC       'DIGIVATE LABS PRIVATE LIMITED',
# MAGIC       'BJSS',
# MAGIC       'Eleflow Big Data e Analytics',
# MAGIC       'XponentL Data, Inc.',
# MAGIC       'Tier One Analytics (HQ)',
# MAGIC       'Datapao',
# MAGIC       'InfoCepts LLC (HQ)',
# MAGIC       'Exponentia.ai Private limited',
# MAGIC       'Rackspace Singapore Pte Ltd',
# MAGIC       'NS Solutions Corporation',
# MAGIC       'Lovelytics Data, LLC (HQ)',
# MAGIC       'Blend360',
# MAGIC       'Eucloid Data Inc',
# MAGIC       'b.telligent Deutschland GmbH',
# MAGIC       'Xebia (HQ)',
# MAGIC       'Inteltion',
# MAGIC       'Nousot, Inc.',
# MAGIC       'DataNimbus',
# MAGIC       'Cegeka NV',
# MAGIC       'Tavant Technologies, Inc.',
# MAGIC       'Entrada AI, Inc.',
# MAGIC       'Daugherty Business Solutions',
# MAGIC       'MentorMate',
# MAGIC       'LumenData',
# MAGIC       'BDO Canada',
# MAGIC       'Encora Digital LLC',
# MAGIC       'Marlabs Inc.',
# MAGIC       'ORAYLIS GmbH',
# MAGIC       'STRATEQ SYSTEMS SDN BHD',
# MAGIC       'Telstra Purple (HQ)',
# MAGIC       'SDG Group (HQ)',
# MAGIC       'ELITMIND sp. z o. o.',
# MAGIC       'Advancing Analytics',
# MAGIC       'MACNICA, Inc. (HQ)',
# MAGIC       'Cavallo Technologies Inc',
# MAGIC       'Delaware Consulting CV',
# MAGIC       'Concentrix Catalyst',
# MAGIC       'Infinitive',
# MAGIC       'Cellenza SAS',
# MAGIC       'MEGAZONE CLOUD CORPORATION',
# MAGIC       'Fission Labs Inc',
# MAGIC       'Synechron',
# MAGIC       'SoftwareOne AG (HQ)',
# MAGIC       'Cloocus Co., Ltd. (HQ)',
# MAGIC       'Infomotion GmbH',
# MAGIC       'Analytics8, LLC',
# MAGIC       'Aubay (HQ)',
# MAGIC       'Wortell Smart',
# MAGIC       'Birlasoft Solutions Inc.',
# MAGIC       'Unify Consulting',
# MAGIC       'Artefact',
# MAGIC       'Woodmark AG',
# MAGIC       'Endava',
# MAGIC       'Quantori',
# MAGIC       'InfoServices LLC (HQ)',
# MAGIC       'MFEC Public Company Limited',
# MAGIC       'Nexer Group (HQ)',
# MAGIC       'Mastek Limited (HQ)',
# MAGIC       'Xoriant',
# MAGIC       'Fog Solutions Inc',
# MAGIC       'Xorbix Technologies Inc.',
# MAGIC       'Rearc',
# MAGIC       'Sunnydata Inc.',
# MAGIC       'Orion Innovation',
# MAGIC       'Brillio',
# MAGIC       'Blueprint Technologies',
# MAGIC       'Bosch Global Software Technologies Private Limited',
# MAGIC       'MatrixDnA (HQ)',
# MAGIC       'CI&T Software',
# MAGIC       'Billigence',
# MAGIC       'Orion Digital Solutions',
# MAGIC       'Ippon Technologies (HQ)',
# MAGIC       'Pariveda Solutions',
# MAGIC       'Jarvis Consulting Group',
# MAGIC       'Zennify, INC',
# MAGIC       'Searce PTE Ltd',
# MAGIC       'Aarini Consulting BV',
# MAGIC       'Acxiom',
# MAGIC       'ADA DIGITAL SINGAPORE PTE. LTD.',
# MAGIC       'ADD d.o.o. - Business Solutions',
# MAGIC       'Adesso',
# MAGIC       'Affine Inc (HQ)',
# MAGIC       'AIM Consulting',
# MAGIC       'AIonOS PTE. LTD.',
# MAGIC       'Aivix (HQ)',
# MAGIC       'Alexander Thamm GmbH',
# MAGIC       'Apex Systems (HQ)',
# MAGIC       'Ardentisys',
# MAGIC       'areto Consulting GmbH (HQ)',
# MAGIC       'ARKON DATA (COMPLEX ADAPTIVE SYSTEMS S.A.P.I. DE C.V.)',
# MAGIC       'Arsaga Partners Co., Ltd.',
# MAGIC       'Avvale S.p.A.',
# MAGIC       'BeesBridge LLC',
# MAGIC       'Bespin Global',
# MAGIC       'Bi3 technologies Pty Ltd',
# MAGIC       'BIP - Business Integration Partners SPA (HQ)',
# MAGIC       'Bits In Glass Inc.',
# MAGIC       'Blazeclan Technologies',
# MAGIC       'Bluechip Technologies Limited',
# MAGIC       'Bluetab Solutions S.L.U.',
# MAGIC       'Boston Consulting Group (HQ)',
# MAGIC       'Bounteous',
# MAGIC       'Bouvet Norge AS',
# MAGIC       'Brightly Works Oy',
# MAGIC       'BUSINESS PROCESS & TECHNOLOGIES INTEGRATION S.A.S',
# MAGIC       'C2S Technologies Inc',
# MAGIC       'CapTech',
# MAGIC       'Caylent',
# MAGIC       'Cloud1 Oy',
# MAGIC       'Cloudaeon Technology Limited',
# MAGIC       'CloudIQ Technologies',
# MAGIC       'Cognitivo Pty Ltd',
# MAGIC       'Colibri LTD',
# MAGIC       'Collaboration Betters The World GmbH (HQ)',
# MAGIC       'COMPASS UOL',
# MAGIC       'Confiz LLC (HQ)',
# MAGIC       'Credera',
# MAGIC       'Customertimes Corp',
# MAGIC       'Cyber Hunters Ltd',
# MAGIC       'Data Dynamics Inc',
# MAGIC       'Data Solucoes',
# MAGIC       'Data Surge LLC',
# MAGIC       'Dataeaze Systems Pvt. Ltd.',
# MAGIC       'DataPattern',
# MAGIC       'Dataside Solucoes em Dados LTDA',
# MAGIC       'Definitive Healthcare, LLC (SI Partner)',
# MAGIC       'Delegate',
# MAGIC       'DevScope',
# MAGIC       'Dufrain Consulting',
# MAGIC       'E-Simplicity',
# MAGIC       'Effectual Inc.',
# MAGIC       'ELCA',
# MAGIC       'element61',
# MAGIC       'Epical Sweden AB',
# MAGIC       'Epsilon',
# MAGIC       'Factspan Inc',
# MAGIC       'FTI Consulting, Inc.',
# MAGIC       'Futurice Oy',
# MAGIC       'Gainwell Technologies',
# MAGIC       'Ganit Business Solutions Private Limited',
# MAGIC       'GlobalLogic Corp. UK Ltd (HQ)',
# MAGIC       'Globant, LLC (HQ)',
# MAGIC       'Grid Dynamics Holdings Inc',
# MAGIC       'Halfspace',
# MAGIC       'Hiflylabs',
# MAGIC       'HOONAR TEKWURKS PRIVATE LIMITED',
# MAGIC       'Hoster-JP, Inc',
# MAGIC       'HSO ANZ (HQ)',
# MAGIC       'Hvar Consultoria LTDA',
# MAGIC       'ICONSULTING S.P.A.',
# MAGIC       'iData',
# MAGIC       'INDRA SOLUCIONES TECNOLOGÍAS DE LA INFORMACIÓN, S.L.U (HQ)',
# MAGIC       'InfoObjects, Inc.',
# MAGIC       'Infostretch Corporation (Apexon)',
# MAGIC       'Inovex GmbH',
# MAGIC       'Insight Global',
# MAGIC       'intelia',
# MAGIC       'Intelli5 INC',
# MAGIC       'Jump Label Solutions',
# MAGIC       'Kagool',
# MAGIC       'KI performance GmbH',
# MAGIC       'Knowit Ab (HQ)',
# MAGIC       'Kumulus',
# MAGIC       'Kushagramati Analytics Private Limited',
# MAGIC       'Lantern',
# MAGIC       'Leading Edge Group Limited',
# MAGIC       'Leega Consultoria e Informatica Ltda',
# MAGIC       'Lirik Inc.',
# MAGIC       'Long View Systems',
# MAGIC       'MICROPOLE',
# MAGIC       'MobiLab Solutions GmbH',
# MAGIC       'Modak Analytics LLP',
# MAGIC       'MP DATA',
# MAGIC       'Mu Sigma Business Solutions LLC',
# MAGIC       'Mutt Data (Vuriltek S.A)',
# MAGIC       'Ness Digital Engineering',
# MAGIC       'Netlight Consulting Oy (HQ)',
# MAGIC       'NucleusTeq',
# MAGIC       'OutcomeCatalyst LLC',
# MAGIC       'Paltech Consulting Private Limited',
# MAGIC       'Plain Concepts (HQ)',
# MAGIC       'Profinit EU, s.r.o.',
# MAGIC       'PUE Data',
# MAGIC       'Qubika (CLV Corp)',
# MAGIC       'RBA',
# MAGIC       'Redeploy AB (HQ)',
# MAGIC       'Rocket Science Development',
# MAGIC       'SAIC',
# MAGIC       'Scigility Switzerland AG',
# MAGIC       'Shorthills AI',
# MAGIC       'Smoothstack LLC',
# MAGIC       'SoftServe Inc. (HQ)',
# MAGIC       'Solita (HQ)',
# MAGIC       'SOUTHWORKS LLC',
# MAGIC       'synvert GmbH',
# MAGIC       'Systech Solutions, Inc.',
# MAGIC       'Talan SAS',
# MAGIC       'Tech Fabric LLC',
# MAGIC       'TEKsystems Global Services, LLC',
# MAGIC       'Telefónica Tech',
# MAGIC       'The Math Company',
# MAGIC       'Theta Systems Limited',
# MAGIC       'Tietoevry Finland Oy (HQ)',
# MAGIC       'Trace3',
# MAGIC       'Tudip Technologies',
# MAGIC       'UBDS Group Holdings Limited',
# MAGIC       'Ultra Tendency International GmbH (HQ)',
# MAGIC       'Valtech UK Limited(HQ)',
# MAGIC       'Value Momentum (HQ)',
# MAGIC       'WeVision LLC',
# MAGIC       'WinWire Technologies',
# MAGIC       'WISEANALYTICS.IO LTD',
# MAGIC       'WorldLink US',
# MAGIC       'Zeal Corporation',
# MAGIC       'Zsahar LLC'
# MAGIC     )
# MAGIC
# MAGIC   )
# MAGIC   ,
# MAGIC   top_80_partner_certs_emails as (
# MAGIC     select 
# MAGIC       certification_email, 
# MAGIC       credential_id
# MAGIC     from certs
# MAGIC     where email_domain in (select email_domain from top_80_partner_domains)
# MAGIC   )
# MAGIC
# MAGIC   select *
# MAGIC   from top_80_partner_certs_emails
# MAGIC   

# COMMAND ----------

all_capability_certs = spark.sql('''
with capability_partner_certs as (
  select
    p.*,
    c.certification_email
  from all_capability p
  left join top_80_partner_certs c on p.credential_id = c.credential_id
    
)

select 
  case when contact_email is null and certification_email is not null then certification_email else contact_email end as contact_email,
  * except(contact_email, certification_email)
from capability_partner_certs
''')

# COMMAND ----------

all_capacity_certs = spark.sql('''
with capacity_partner_certs as (
  select
    p.*,
    c.certification_email
  from all_capacity p
  left join top_80_partner_certs c on p.credential_id = c.credential_id
    
)
select 
  case when contact_email is null and certification_email is not null then certification_email else contact_email end as contact_email,
  * except(contact_email, certification_email)
from capacity_partner_certs
''')

# COMMAND ----------

all_capability_certs.createOrReplaceTempView('all_capability_certs')
all_capacity_certs.createOrReplaceTempView('all_capacity_certs')

# COMMAND ----------

all_capability_certs_enhanced = spark.sql('''
  select 
    a.*,
    c.issued_on::date,
    c.calculated_expired_on::date,
    c.credential_name,
    case
      when a.partner_account_name in (
        'Accenture (HQ)',
        'Deloitte Consulting (HQ)',
        'Capgemini S.A. (HQ)',
        'Avanade Inc (HQ)',
        'Infosys Technologies (HQ)',
        'Cognizant Technology Solutions (HQ)',
        'E&Y (HQ)',
        'Slalom Consulting (HQ)',
        'Wipro (HQ)',
        'Tata Consultancy Services (HQ)'
      ) then 'GSI'
      else 'Others'
      end as classification,
      nvl(p.`Managed Coverage Group`, 'Scale Ecosystem - Unmanaged') as portfolio, 
      case when p.`Managed Coverage Group` is null then "Unmanaged" else "Managed" end as managed_partner
  from all_capability_certs a 
  left join main.field_learning_enablement.accredible_credentials c on a.credential_id = c.credential_id and c.processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
  left join main.gtm_partner_data.csi_partner_ecosystem_portfolio_mapping p on p.`Partner Id` = a.partner_account_id_sfdc

''')
all_capacity_certs_enhanced = spark.sql('''
  select 
    a.*,
    c.issued_on::date,
    c.calculated_expired_on::date,
    c.credential_name,
    case
      when a.partner_account_name in (
        'Accenture (HQ)',
        'Deloitte Consulting (HQ)',
        'Capgemini S.A. (HQ)',
        'Avanade Inc (HQ)',
        'Infosys Technologies (HQ)',
        'Cognizant Technology Solutions (HQ)',
        'E&Y (HQ)',
        'Slalom Consulting (HQ)',
        'Wipro (HQ)',
        'Tata Consultancy Services (HQ)'
      ) then 'GSI'
      else 'Others'
  end as classification,
  nvl(p.`Managed Coverage Group`, 'Scale Ecosystem - Unmanaged') as portfolio,
  case when p.`Managed Coverage Group` is null then "Unmanaged" else "Managed" end as managed_partner
  from all_capacity_certs a 
  left join main.field_learning_enablement.accredible_credentials c on a.credential_id = c.credential_id and c.processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
  left join main.gtm_partner_data.csi_partner_ecosystem_portfolio_mapping p on p.`Partner Id` = a.partner_account_id_sfdc

''')

# COMMAND ----------

all_capability_enhanced_partition = add_gold_metadata(all_capability_certs_enhanced)
all_capacity_enhanced_partition = add_gold_metadata(all_capacity_certs_enhanced)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_capability_enhanced_partition, 
  table_name = f'{focus_database_name}.partner_capability', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_capacity_enhanced_partition, 
  table_name = f'{focus_database_name}.partner_capacity', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# DBTITLE 1,Docebo User Data Processing
all_partner_certs_by_company_email = spark.sql('''
  with ranked_docebo_users as (
    select
      *,
      rank() over (
        partition by email_hash
        order by
          last_login
      ) as rank_data
    from
      main.field_learning_enablement.docebo_users
    where
      processdate =(
        Select
          max(processdate)
        from
          main.field_learning_enablement.docebo_users
      )
      and nvl(audience, 'Unknown') in ('Partner', 'Partner Other')
  ),
  docebo_users as (
    select
      *
    from
      ranked_docebo_users
    where
      rank_data = 1
  ),
  blacklist_domains as (
    select
      distinct blacklist_domain
    from
      main.field_learning_enablement.blacklist_domains
    where
      processDate = (
        select
          max(processDate)
        from
          main.field_learning_enablement.blacklist_domains
      )
  )
  ,
  capability as (
    select
      c.*
    except(c.learner_email_domain),
      case
        when c.learner_email_hash = '78dfc4089d9f80cbae14429cb95508c1955262ebdee4184c4e3fb3503a70ae18' then 'gmail.com'
        else learner_email_domain
      end as learner_email_domain
    from
      -- capability_final c
      main.field_learning_enablement.partner_capability c
    where
      learner_email_hash is not null
    and c.processDate = (select max(processDate) from main.field_learning_enablement.partner_capability)
  )
  ,
  -- fix learner_user_ids records that have one row with contact email and another without (because of learndot data)
  contact_email_fix as (
    select
      distinct learner_email_hash,
      contact_email,
      dense_rank() over (
        partition by learner_email_hash
        order by
          contact_email nulls last
      ) as rank
    from
      -- capability_final
      main.field_learning_enablement.partner_capability
    where
      category = 'Technical Trained'
      and processDate = (select max(processDate) from main.field_learning_enablement.partner_capability)
  ),
  capability_v2 as (
    select
      c.*,
      case
        when category = 'Technical Certified' then a.recipient_email
        else d.contact_email
      end as updated_email
    from
      capability c
      left join contact_email_fix d on c.learner_email_hash = d.learner_email_hash
      and d.rank = 1
      and c.category = 'Technical Trained'
      left join main.it_accredible_bronze.credentials a on c.credential_id = a.credential_id
      and a.processdate = (
        select
          max(processdate)
        from
          main.it_accredible_bronze.credentials
      )
  ),
  capability_v3 as (
    select
      c.*,
      b.blacklist_domain as b_blacklist_domain,
      b1.blacklist_domain as b1_blacklist_domain
    from
      capability_v2 c
      left join blacklist_domains b on c.learner_email_domain = b.blacklist_domain
      left join blacklist_domains b1 on c.learner_alternate_email_domain = b1.blacklist_domain
  ),
  capability_pre as (
    select
      *,
      case
        when b_blacklist_domain is not null
        and (
          b1_blacklist_domain is null
          and learner_alternate_email_domain is not null
        ) then 'Email is blacklist - select secondary'
        when b1_blacklist_domain is not null
        and (
          b_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Alternate email is blacklist - select primary'
        when (
          b_blacklist_domain is not null
          and b1_blacklist_domain is not null
          and learner_email_domain is not null
        ) then 'Only blacklist domains - select primary'
        when (
          b_blacklist_domain is null
          and b1_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Email Good - select primary'
        else 'Others'
      end as bucket
    from
      capability_v3
  ),
  --alternate_emails as (
  --  select
  --    id_user,
  --    case
  --      trim(lower(field_37))
  --      when '' then null
  --      else trim(lower(field_37))
  --    end as alternate_email,
  --    split(trim(lower(field_37)), '@', 2) [1] as alternate_email_domain
  --  from
  --    main.it_docebo_bronze.core_user_field_value
  --  where
  --    processDate = (
  --      select
  --        max(processDate)
  --      from
  --        main.it_docebo_bronze.core_user_field_value
  --    )
  --),
  alternate_emails as (
    select
      id_user,
      case
        trim(lower(field_value))
        when '' then null
        else trim(lower(field_value))
      end as alternate_email,
      split(trim(lower(field_value)), '@', 2) [1] as alternate_email_domain
    from
      main.it_docebo_bronze.core_user_field_value
    where
      processDate = (
        select
          max(processDate)
        from
          main.it_docebo_bronze.core_user_field_value
      )
    and id_field = 37
  ),
  emails as (
    select
      distinct lower(email) as email,
      sha2(lower(email), 256) as email_hash
    from
      main.it_docebo_bronze.core_user
    where
      processdate =(
        Select
          max(processdate)
        from
          main.it_docebo_bronze.core_user
      )
      and split(trim(lower(email)), '@', 2) [1] not in (
        select
          distinct blacklist_domain
        from
          blacklist_domains
      )
    union
      (
        select
          distinct lower(alternate_emails.alternate_email) as email,
          sha2(lower(alternate_Email), 256) as email_hash
        from
          alternate_emails
        where
          alternate_email_domain not in (
            select
              distinct blacklist_domain
            from
              blacklist_domains
          )
      )
  ),
  capability_final as (
    select
      p.*,
      e.email,
      case
        when p.bucket = 'Email is blacklist - select secondary' then e.email
        else p.updated_email
      end as final_email
    from
      capability_pre p
      left join emails e on p.learner_alternate_email_hash = e.email_hash
      and p.bucket = 'Email is blacklist - select secondary'
  ),
  -- fix learner_email_hash records that have one row with partner account and another without (because of learndot data)
  account_fix as (
    select
      distinct learner_email_hash,
      partner_account_name,
      partner_account_id_sfdc,
      dense_rank() over (
        partition by learner_email_hash
        order by
          partner_account_name nulls last
      ) as rank
    from
      capability_final
    where
      category = 'Technical Trained'
  ),
  certs as (
    select
      p.final_email as certification_email,
      sha2(p.final_email, 256) as certification_email_hash,
      split(p.final_email, '@')[1] as email_domain,
      -- array_join(collect_set(p.updated_email), ",") as updated_email,
      -- array_join(collect_set(p.learner_email_hash), ",") as learner_email_hash,
      p.partner_account_name,
      p.partner_account_id_sfdc,
      u.region_derived,
      p.credential_id,
      p.issued_on,
      p.calculated_expired_on,
      p.course as credential_name
    from
      capability_final p
      left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
    where
      p.category = 'Technical Certified'
    -- group by
    --   all
  )
  

  ,
  final_1 as (
    select 
      credential_id, 
      certification_email, 
      credential_name, 
      partner_account_name, 
      issued_on, 
      calculated_expired_on as expired_on
    from certs
    where partner_account_name in (
      'Accenture (HQ)',
      'Tata Consultancy Services (HQ)',
      'Cognizant Technology Solutions (HQ)',
      'LTIMindtree Limited (HQ)',
      'Capgemini S.A. (HQ)',
      'Deloitte Consulting (HQ)',
      'E&Y (HQ)',
      'Avanade Inc (HQ)',
      'Infosys Technologies (HQ)',
      'Celebal Technologies Private Limited (HQ)',
      'Wipro (HQ)',
      'EPAM (HQ)',
      'Tech Mahindra Limited (HQ)',
      'Booz Allen Hamilton Partner',
      'Slalom Consulting (HQ)',
      'Impetus Technologies',
      'KPMG LLP (HQ)',
      'Tredence Inc (HQ)',
      'Fractal Analytics (HQ)',
      'Eviden (HQ)',
      'NTT Data Corporation (HQ)',
      'IBM (HQ)',
      'Tiger Analytics (HQ)',
      'Reply (HQ)',
      'DXC Technology (HQ)',
      'Conseillers en Gestion et Informatique CGI Inc. (HQ)',
      'Datametica Solutions',
      'Quantiphi (HQ)',
      'Persistent Systems Inc.',
      'Devoteam SA (HQ)',
      'Koantek LLC',
      'Kubrick Group (HQ)',
      'Wavicle Data Solutions',
      'McKinsey & Company (HQ)',
      'Agilisium Consulting (HQ)',
      'Perficient Inc',
      'Hitachi Solutions (HQ)',
      'Mphasis',
      'HCL Technologies (HQ)',
      'Fujitsu Australia Ltd. (HQ)',
      'Neudesic',
      'Insight Enterprises (HQ)',
      'Zeb',
      'ZS Associates',
      '3Cloud LLC',
      'JEMS Datafactory SASU',
      'Blackstraw.ai',
      'OpenValue',
      'CitiusTech Inc.',
      'ARQ',
      'Mantel Operations Pty Ltd',
      'Hexaware Technologies (HQ)',
      'Adastra (HQ)',
      'Factored, Inc.',
      'Valcon',
      'Thorogood Associates',
      'Nagarro Software Pvt Ltd (HQ)',
      'KPI Partners',
      'BlueShift Brasil',
      'SDK Tek Services Ltd.',
      'Virtusa',
      'Publicis sapient (APAC)',
      'Incedo Inc',
      'Fragma Data Systems',
      'Infogain Corporation (HQ)',
      'Computomic Software & Consulting LLC',
      'BI4ALL',
      'EXL Service',
      'BOSONIT S.L.',
      'Servian',
      'Minsait - Indra Sistemas Brand',
      'initions GmbH',
      'Lingaro sp. z o.o.',
      'Ekimetrics',
      'Elastacloud',
      'Guidehouse',
      'West Monroe',
      'Rackspace Hosting (HQ)',
      'twoday Holding Denmark ApS (HQ)',
      'Lovelytics (HQ)',
      'KPMG LLP (HQ)',
      'GENPACT (UK) LIMITED (HQ)',
      'Publicis Sapient (HQ)',
      'Kyndryl Inc (HQ)',
      'Aimpoint Digital',
      'LatentView Analytics',
      'PWC (HQ)',
      'Onix Networking Corp.',
      'Nagarro (HQ)',
      'Mantel Operations Pty Ltd (HQ)',
      'NCS Pte Ltd (HQ)',
      'Thoughtworks US',
      'Sopra Steria EspaÃ±a S.A.',
      'Lenovo (Hong Kong) Limited (HQ)',
      'syrencloud Inc',
      'Lingaro',
      'iLink Digital (HQ)',
      'Indicium',
      'Cuelebre AB (HQ)',
      'Bizmetric',
      'FPT Asia Pacific Pte Ltd (HQ)',
      'TO THE NEW Private Limited',
      'Hitachi Solutions, Ltd. (HQ)',
      'D ONE Value Creation AG',
      'RevoData',
      'Thorogood Associates (HQ)',
      'Lufthansa Industry Solutions GmbH & Co. KG',
      'Sigmoid (HQ)',
      'DIGIVATE LABS PRIVATE LIMITED',
      'BJSS',
      'Eleflow Big Data e Analytics',
      'XponentL Data, Inc.',
      'Tier One Analytics (HQ)',
      'Datapao',
      'InfoCepts LLC (HQ)',
      'Exponentia.ai Private limited',
      'Rackspace Singapore Pte Ltd',
      'NS Solutions Corporation',
      'Lovelytics Data, LLC (HQ)',
      'Blend360',
      'Eucloid Data Inc',
      'b.telligent Deutschland GmbH',
      'Xebia (HQ)',
      'Inteltion',
      'Nousot, Inc.',
      'DataNimbus',
      'Cegeka NV',
      'Tavant Technologies, Inc.',
      'Entrada AI, Inc.',
      'Daugherty Business Solutions',
      'MentorMate',
      'LumenData',
      'BDO Canada',
      'Encora Digital LLC',
      'Marlabs Inc.',
      'ORAYLIS GmbH',
      'STRATEQ SYSTEMS SDN BHD',
      'Telstra Purple (HQ)',
      'SDG Group (HQ)',
      'ELITMIND sp. z o. o.',
      'Advancing Analytics',
      'MACNICA, Inc. (HQ)',
      'Cavallo Technologies Inc',
      'Delaware Consulting CV',
      'Concentrix Catalyst',
      'Infinitive',
      'Cellenza SAS',
      'MEGAZONE CLOUD CORPORATION',
      'Fission Labs Inc',
      'Synechron',
      'SoftwareOne AG (HQ)',
      'Cloocus Co., Ltd. (HQ)',
      'Infomotion GmbH',
      'Analytics8, LLC',
      'Aubay (HQ)',
      'Wortell Smart',
      'Birlasoft Solutions Inc.',
      'Unify Consulting',
      'Artefact',
      'Woodmark AG',
      'Endava',
      'Quantori',
      'InfoServices LLC (HQ)',
      'MFEC Public Company Limited',
      'Nexer Group (HQ)',
      'Mastek Limited (HQ)',
      'Xoriant',
      'Fog Solutions Inc',
      'Xorbix Technologies Inc.',
      'Rearc',
      'Sunnydata Inc.',
      'Orion Innovation',
      'Brillio',
      'Blueprint Technologies',
      'Bosch Global Software Technologies Private Limited',
      'MatrixDnA (HQ)',
      'CI&T Software',
      'Billigence',
      'Orion Digital Solutions',
      'Ippon Technologies (HQ)',
      'Pariveda Solutions',
      'Jarvis Consulting Group',
      'Zennify, INC',
      'Searce PTE Ltd',
      'Aarini Consulting BV',
      'Acxiom',
      'ADA DIGITAL SINGAPORE PTE. LTD.',
      'ADD d.o.o. - Business Solutions',
      'Adesso',
      'Affine Inc (HQ)',
      'AIM Consulting',
      'AIonOS PTE. LTD.',
      'Aivix (HQ)',
      'Alexander Thamm GmbH',
      'Apex Systems (HQ)',
      'Ardentisys',
      'areto Consulting GmbH (HQ)',
      'ARKON DATA (COMPLEX ADAPTIVE SYSTEMS S.A.P.I. DE C.V.)',
      'Arsaga Partners Co., Ltd.',
      'Avvale S.p.A.',
      'BeesBridge LLC',
      'Bespin Global',
      'Bi3 technologies Pty Ltd',
      'BIP - Business Integration Partners SPA (HQ)',
      'Bits In Glass Inc.',
      'Blazeclan Technologies',
      'Bluechip Technologies Limited',
      'Bluetab Solutions S.L.U.',
      'Boston Consulting Group (HQ)',
      'Bounteous',
      'Bouvet Norge AS',
      'Brightly Works Oy',
      'BUSINESS PROCESS & TECHNOLOGIES INTEGRATION S.A.S',
      'C2S Technologies Inc',
      'CapTech',
      'Caylent',
      'Cloud1 Oy',
      'Cloudaeon Technology Limited',
      'CloudIQ Technologies',
      'Cognitivo Pty Ltd',
      'Colibri LTD',
      'Collaboration Betters The World GmbH (HQ)',
      'COMPASS UOL',
      'Confiz LLC (HQ)',
      'Credera',
      'Customertimes Corp',
      'Cyber Hunters Ltd',
      'Data Dynamics Inc',
      'Data Solucoes',
      'Data Surge LLC',
      'Dataeaze Systems Pvt. Ltd.',
      'DataPattern',
      'Dataside Solucoes em Dados LTDA',
      'Definitive Healthcare, LLC (SI Partner)',
      'Delegate',
      'DevScope',
      'Dufrain Consulting',
      'E-Simplicity',
      'Effectual Inc.',
      'ELCA',
      'element61',
      'Epical Sweden AB',
      'Epsilon',
      'Factspan Inc',
      'FTI Consulting, Inc.',
      'Futurice Oy',
      'Gainwell Technologies',
      'Ganit Business Solutions Private Limited',
      'GlobalLogic Corp. UK Ltd (HQ)',
      'Globant, LLC (HQ)',
      'Grid Dynamics Holdings Inc',
      'Halfspace',
      'Hiflylabs',
      'HOONAR TEKWURKS PRIVATE LIMITED',
      'Hoster-JP, Inc',
      'HSO ANZ (HQ)',
      'Hvar Consultoria LTDA',
      'ICONSULTING S.P.A.',
      'iData',
      'INDRA SOLUCIONES TECNOLOGÍAS DE LA INFORMACIÓN, S.L.U (HQ)',
      'InfoObjects, Inc.',
      'Infostretch Corporation (Apexon)',
      'Inovex GmbH',
      'Insight Global',
      'intelia',
      'Intelli5 INC',
      'Jump Label Solutions',
      'Kagool',
      'KI performance GmbH',
      'Knowit Ab (HQ)',
      'Kumulus',
      'Kushagramati Analytics Private Limited',
      'Lantern',
      'Leading Edge Group Limited',
      'Leega Consultoria e Informatica Ltda',
      'Lirik Inc.',
      'Long View Systems',
      'MICROPOLE',
      'MobiLab Solutions GmbH',
      'Modak Analytics LLP',
      'MP DATA',
      'Mu Sigma Business Solutions LLC',
      'Mutt Data (Vuriltek S.A)',
      'Ness Digital Engineering',
      'Netlight Consulting Oy (HQ)',
      'NucleusTeq',
      'OutcomeCatalyst LLC',
      'Paltech Consulting Private Limited',
      'Plain Concepts (HQ)',
      'Profinit EU, s.r.o.',
      'PUE Data',
      'Qubika (CLV Corp)',
      'RBA',
      'Redeploy AB (HQ)',
      'Rocket Science Development',
      'SAIC',
      'Scigility Switzerland AG',
      'Shorthills AI',
      'Smoothstack LLC',
      'SoftServe Inc. (HQ)',
      'Solita (HQ)',
      'SOUTHWORKS LLC',
      'synvert GmbH',
      'Systech Solutions, Inc.',
      'Talan SAS',
      'Tech Fabric LLC',
      'TEKsystems Global Services, LLC',
      'Telefónica Tech',
      'The Math Company',
      'Theta Systems Limited',
      'Tietoevry Finland Oy (HQ)',
      'Trace3',
      'Tudip Technologies',
      'UBDS Group Holdings Limited',
      'Ultra Tendency International GmbH (HQ)',
      'Valtech UK Limited(HQ)',
      'Value Momentum (HQ)',
      'WeVision LLC',
      'WinWire Technologies',
      'WISEANALYTICS.IO LTD',
      'WorldLink US',
      'Zeal Corporation',
      'Zsahar LLC'
    )
  )
  ,
  final_2 as (
     select 
       credential_id, 
       "PII Redacted" as certification_email, 
       credential_name, 
       partner_account_name, 
       issued_on, 
       calculated_expired_on as expired_on
     from certs 
     where partner_account_name not in (
       'Accenture (HQ)',
      'Tata Consultancy Services (HQ)',
      'Cognizant Technology Solutions (HQ)',
      'LTIMindtree Limited (HQ)',
      'Capgemini S.A. (HQ)',
      'Deloitte Consulting (HQ)',
      'E&Y (HQ)',
      'Avanade Inc (HQ)',
      'Infosys Technologies (HQ)',
      'Celebal Technologies Private Limited (HQ)',
      'Wipro (HQ)',
      'EPAM (HQ)',
      'Tech Mahindra Limited (HQ)',
      'Booz Allen Hamilton Partner',
      'Slalom Consulting (HQ)',
      'Impetus Technologies',
      'KPMG LLP (HQ)',
      'Tredence Inc (HQ)',
      'Fractal Analytics (HQ)',
      'Eviden (HQ)',
      'NTT Data Corporation (HQ)',
      'IBM (HQ)',
      'Tiger Analytics (HQ)',
      'Reply (HQ)',
      'DXC Technology (HQ)',
      'Conseillers en Gestion et Informatique CGI Inc. (HQ)',
      'Datametica Solutions',
      'Quantiphi (HQ)',
      'Persistent Systems Inc.',
      'Devoteam SA (HQ)',
      'Koantek LLC',
      'Kubrick Group (HQ)',
      'Wavicle Data Solutions',
      'McKinsey & Company (HQ)',
      'Agilisium Consulting (HQ)',
      'Perficient Inc',
      'Hitachi Solutions (HQ)',
      'Mphasis',
      'HCL Technologies (HQ)',
      'Fujitsu Australia Ltd. (HQ)',
      'Neudesic',
      'Insight Enterprises (HQ)',
      'Zeb',
      'ZS Associates',
      '3Cloud LLC',
      'JEMS Datafactory SASU',
      'Blackstraw.ai',
      'OpenValue',
      'CitiusTech Inc.',
      'ARQ',
      'Mantel Operations Pty Ltd',
      'Hexaware Technologies (HQ)',
      'Adastra (HQ)',
      'Factored, Inc.',
      'Valcon',
      'Thorogood Associates',
      'Nagarro Software Pvt Ltd (HQ)',
      'KPI Partners',
      'BlueShift Brasil',
      'SDK Tek Services Ltd.',
      'Virtusa',
      'Publicis sapient (APAC)',
      'Incedo Inc',
      'Fragma Data Systems',
      'Infogain Corporation (HQ)',
      'Computomic Software & Consulting LLC',
      'BI4ALL',
      'EXL Service',
      'BOSONIT S.L.',
      'Servian',
      'Minsait - Indra Sistemas Brand',
      'initions GmbH',
      'Lingaro sp. z o.o.',
      'Ekimetrics',
      'Elastacloud',
      'Guidehouse',
      'West Monroe',
      'Rackspace Hosting (HQ)',
      'twoday Holding Denmark ApS (HQ)',
      'Lovelytics (HQ)',
      'KPMG LLP (HQ)',
      'GENPACT (UK) LIMITED (HQ)',
      'Publicis Sapient (HQ)',
      'Kyndryl Inc (HQ)',
      'Aimpoint Digital',
      'LatentView Analytics',
      'PWC (HQ)',
      'Onix Networking Corp.',
      'Nagarro (HQ)',
      'Mantel Operations Pty Ltd (HQ)',
      'NCS Pte Ltd (HQ)',
      'Thoughtworks US',
      'Sopra Steria EspaÃ±a S.A.',
      'Lenovo (Hong Kong) Limited (HQ)',
      'syrencloud Inc',
      'Lingaro',
      'iLink Digital (HQ)',
      'Indicium',
      'Cuelebre AB (HQ)',
      'Bizmetric',
      'FPT Asia Pacific Pte Ltd (HQ)',
      'TO THE NEW Private Limited',
      'Hitachi Solutions, Ltd. (HQ)',
      'D ONE Value Creation AG',
      'RevoData',
      'Thorogood Associates (HQ)',
      'Lufthansa Industry Solutions GmbH & Co. KG',
      'Sigmoid (HQ)',
      'DIGIVATE LABS PRIVATE LIMITED',
      'BJSS',
      'Eleflow Big Data e Analytics',
      'XponentL Data, Inc.',
      'Tier One Analytics (HQ)',
      'Datapao',
      'InfoCepts LLC (HQ)',
      'Exponentia.ai Private limited',
      'Rackspace Singapore Pte Ltd',
      'NS Solutions Corporation',
      'Lovelytics Data, LLC (HQ)',
      'Blend360',
      'Eucloid Data Inc',
      'b.telligent Deutschland GmbH',
      'Xebia (HQ)',
      'Inteltion',
      'Nousot, Inc.',
      'DataNimbus',
      'Cegeka NV',
      'Tavant Technologies, Inc.',
      'Entrada AI, Inc.',
      'Daugherty Business Solutions',
      'MentorMate',
      'LumenData',
      'BDO Canada',
      'Encora Digital LLC',
      'Marlabs Inc.',
      'ORAYLIS GmbH',
      'STRATEQ SYSTEMS SDN BHD',
      'Telstra Purple (HQ)',
      'SDG Group (HQ)',
      'ELITMIND sp. z o. o.',
      'Advancing Analytics',
      'MACNICA, Inc. (HQ)',
      'Cavallo Technologies Inc',
      'Delaware Consulting CV',
      'Concentrix Catalyst',
      'Infinitive',
      'Cellenza SAS',
      'MEGAZONE CLOUD CORPORATION',
      'Fission Labs Inc',
      'Synechron',
      'SoftwareOne AG (HQ)',
      'Cloocus Co., Ltd. (HQ)',
      'Infomotion GmbH',
      'Analytics8, LLC',
      'Aubay (HQ)',
      'Wortell Smart',
      'Birlasoft Solutions Inc.',
      'Unify Consulting',
      'Artefact',
      'Woodmark AG',
      'Endava',
      'Quantori',
      'InfoServices LLC (HQ)',
      'MFEC Public Company Limited',
      'Nexer Group (HQ)',
      'Mastek Limited (HQ)',
      'Xoriant',
      'Fog Solutions Inc',
      'Xorbix Technologies Inc.',
      'Rearc',
      'Sunnydata Inc.',
      'Orion Innovation',
      'Brillio',
      'Blueprint Technologies',
      'Bosch Global Software Technologies Private Limited',
      'MatrixDnA (HQ)',
      'CI&T Software',
      'Billigence',
      'Orion Digital Solutions',
      'Ippon Technologies (HQ)',
      'Pariveda Solutions',
      'Jarvis Consulting Group',
      'Zennify, INC',
      'Searce PTE Ltd',
      'Aarini Consulting BV',
      'Acxiom',
      'ADA DIGITAL SINGAPORE PTE. LTD.',
      'ADD d.o.o. - Business Solutions',
      'Adesso',
      'Affine Inc (HQ)',
      'AIM Consulting',
      'AIonOS PTE. LTD.',
      'Aivix (HQ)',
      'Alexander Thamm GmbH',
      'Apex Systems (HQ)',
      'Ardentisys',
      'areto Consulting GmbH (HQ)',
      'ARKON DATA (COMPLEX ADAPTIVE SYSTEMS S.A.P.I. DE C.V.)',
      'Arsaga Partners Co., Ltd.',
      'Avvale S.p.A.',
      'BeesBridge LLC',
      'Bespin Global',
      'Bi3 technologies Pty Ltd',
      'BIP - Business Integration Partners SPA (HQ)',
      'Bits In Glass Inc.',
      'Blazeclan Technologies',
      'Bluechip Technologies Limited',
      'Bluetab Solutions S.L.U.',
      'Boston Consulting Group (HQ)',
      'Bounteous',
      'Bouvet Norge AS',
      'Brightly Works Oy',
      'BUSINESS PROCESS & TECHNOLOGIES INTEGRATION S.A.S',
      'C2S Technologies Inc',
      'CapTech',
      'Caylent',
      'Cloud1 Oy',
      'Cloudaeon Technology Limited',
      'CloudIQ Technologies',
      'Cognitivo Pty Ltd',
      'Colibri LTD',
      'Collaboration Betters The World GmbH (HQ)',
      'COMPASS UOL',
      'Confiz LLC (HQ)',
      'Credera',
      'Customertimes Corp',
      'Cyber Hunters Ltd',
      'Data Dynamics Inc',
      'Data Solucoes',
      'Data Surge LLC',
      'Dataeaze Systems Pvt. Ltd.',
      'DataPattern',
      'Dataside Solucoes em Dados LTDA',
      'Definitive Healthcare, LLC (SI Partner)',
      'Delegate',
      'DevScope',
      'Dufrain Consulting',
      'E-Simplicity',
      'Effectual Inc.',
      'ELCA',
      'element61',
      'Epical Sweden AB',
      'Epsilon',
      'Factspan Inc',
      'FTI Consulting, Inc.',
      'Futurice Oy',
      'Gainwell Technologies',
      'Ganit Business Solutions Private Limited',
      'GlobalLogic Corp. UK Ltd (HQ)',
      'Globant, LLC (HQ)',
      'Grid Dynamics Holdings Inc',
      'Halfspace',
      'Hiflylabs',
      'HOONAR TEKWURKS PRIVATE LIMITED',
      'Hoster-JP, Inc',
      'HSO ANZ (HQ)',
      'Hvar Consultoria LTDA',
      'ICONSULTING S.P.A.',
      'iData',
      'INDRA SOLUCIONES TECNOLOGÍAS DE LA INFORMACIÓN, S.L.U (HQ)',
      'InfoObjects, Inc.',
      'Infostretch Corporation (Apexon)',
      'Inovex GmbH',
      'Insight Global',
      'intelia',
      'Intelli5 INC',
      'Jump Label Solutions',
      'Kagool',
      'KI performance GmbH',
      'Knowit Ab (HQ)',
      'Kumulus',
      'Kushagramati Analytics Private Limited',
      'Lantern',
      'Leading Edge Group Limited',
      'Leega Consultoria e Informatica Ltda',
      'Lirik Inc.',
      'Long View Systems',
      'MICROPOLE',
      'MobiLab Solutions GmbH',
      'Modak Analytics LLP',
      'MP DATA',
      'Mu Sigma Business Solutions LLC',
      'Mutt Data (Vuriltek S.A)',
      'Ness Digital Engineering',
      'Netlight Consulting Oy (HQ)',
      'NucleusTeq',
      'OutcomeCatalyst LLC',
      'Paltech Consulting Private Limited',
      'Plain Concepts (HQ)',
      'Profinit EU, s.r.o.',
      'PUE Data',
      'Qubika (CLV Corp)',
      'RBA',
      'Redeploy AB (HQ)',
      'Rocket Science Development',
      'SAIC',
      'Scigility Switzerland AG',
      'Shorthills AI',
      'Smoothstack LLC',
      'SoftServe Inc. (HQ)',
      'Solita (HQ)',
      'SOUTHWORKS LLC',
      'synvert GmbH',
      'Systech Solutions, Inc.',
      'Talan SAS',
      'Tech Fabric LLC',
      'TEKsystems Global Services, LLC',
      'Telefónica Tech',
      'The Math Company',
      'Theta Systems Limited',
      'Tietoevry Finland Oy (HQ)',
      'Trace3',
      'Tudip Technologies',
      'UBDS Group Holdings Limited',
      'Ultra Tendency International GmbH (HQ)',
      'Valtech UK Limited(HQ)',
      'Value Momentum (HQ)',
      'WeVision LLC',
      'WinWire Technologies',
      'WISEANALYTICS.IO LTD',
      'WorldLink US',
      'Zeal Corporation',
      'Zsahar LLC'
     )
  )

  , 

  final_3 as (
    select *
    from final_1
    union all 
    select *
    from final_2
  )

  select * from final_3

  
''')

# COMMAND ----------

expired_certs_df = spark.sql('''
  with ranked_docebo_users as ( 
    select
      *,
      rank() over (
        partition by email_hash
        order by
          last_login
      ) as rank_data
    from
      main.field_learning_enablement.docebo_users
    where
      processdate =(
        Select
          max(processdate)
        from
          main.field_learning_enablement.docebo_users
      )
      and nvl(audience, 'Unknown') in ('Partner', 'Partner Other')
  ),
  docebo_users as (
    select
      *
    from
      ranked_docebo_users
    where
      rank_data = 1
  ),
  blacklist_domains as (
    select
      distinct blacklist_domain
    from
      main.field_learning_enablement.blacklist_domains
    where
      processDate = (
        select
          max(processDate)
        from
          main.field_learning_enablement.blacklist_domains
      )
  )
  ,
  
  credentials as (
    select 
      c.*,
      a.recipient_email as contact_email
    from main.field_learning_enablement.accredible_credentials c
    left join main.it_accredible_bronze.credentials a on a.credential_id = c.credential_id and a.processDate = (select max(processDate) from main.it_accredible_bronze.credentials)
    where c.processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
    and c.group_id in (
      '371215', 
      '364119', 
      '357057', 
      '353856', 
      '331743', 
      '229201', 
      '227965', 
      '227818', 
      '583499'
    )
    and c.audience in ('Partner', 'Partner Other', 'Microsoft', 'Microsoft Other')
    and c.calculated_is_expired
  )
  ,

  blacklist as (
    select
      c.*,
      b.blacklist_domain as b_blacklist_domain,
      b1.blacklist_domain as b1_blacklist_domain
    from
      credentials c
      left join blacklist_domains b on c.learner_email_domain = b.blacklist_domain
      left join blacklist_domains b1 on c.learner_alternate_email_domain = b1.blacklist_domain
  )
  ,
  capability_pre as (
    select
      *,
      case
        when b_blacklist_domain is not null
        and (
          b1_blacklist_domain is null
          and learner_alternate_email_domain is not null
        ) then 'Email is blacklist - select secondary'
        when b1_blacklist_domain is not null
        and (
          b_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Alternate email is blacklist - select primary'
        when (
          b_blacklist_domain is not null
          and b1_blacklist_domain is not null
          and learner_email_domain is not null
        ) then 'Only blacklist domains - select primary'
        when (
          b_blacklist_domain is null
          and b1_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Email Good - select primary'
        else 'Others'
      end as bucket
    from
      blacklist
  )
  ,
  --alternate_emails as (
  --  select
  --    id_user,
  --    case
  --      trim(lower(field_37))
  --      when '' then null
  --      else trim(lower(field_37))
  --    end as alternate_email,
  --    split(trim(lower(field_37)), '@', 2) [1] as alternate_email_domain
  --  from
  --    main.it_docebo_bronze.core_user_field_value
  --  where
  --    processDate = (
  --      select
  --        max(processDate)
  --      from
  --        main.it_docebo_bronze.core_user_field_value
  --    )
  --),
  alternate_emails as (
    select
      id_user,
      case
        trim(lower(field_value))
        when '' then null
        else trim(lower(field_value))
      end as alternate_email,
      split(trim(lower(field_value)), '@', 2) [1] as alternate_email_domain
    from
      main.it_docebo_bronze.core_user_field_value
    where
      processDate = (
        select
          max(processDate)
        from
          main.it_docebo_bronze.core_user_field_value
      )
    and id_field = 37
  ),
  emails as (
    select
      distinct lower(email) as email,
      sha2(lower(email), 256) as email_hash
    from
      main.it_docebo_bronze.core_user
    where
      processdate =(
        Select
          max(processdate)
        from
          main.it_docebo_bronze.core_user
      )
      and split(trim(lower(email)), '@', 2) [1] not in (
        select
          distinct blacklist_domain
        from
          blacklist_domains
      )
    union
      (
        select
          distinct lower(alternate_emails.alternate_email) as email,
          sha2(lower(alternate_Email), 256) as email_hash
        from
          alternate_emails
        where
          alternate_email_domain not in (
            select
              distinct blacklist_domain
            from
              blacklist_domains
          )
      )
  ),
  capability_final as (
    select
      p.*,
      e.email,
      case
        when p.bucket = 'Email is blacklist - select secondary' then e.email
        else p.contact_email
      end as final_email
    from
      capability_pre p
      left join emails e on p.learner_alternate_email_hash = e.email_hash
      and p.bucket = 'Email is blacklist - select secondary'
  )
  ,
  certs as (
    select
      p.final_email as certification_email,
      sha2(p.final_email, 256) as certification_email_hash,
      split(p.final_email, '@')[1] as email_domain,
      -- array_join(collect_set(p.updated_email), ",") as updated_email,
      -- array_join(collect_set(p.learner_email_hash), ",") as learner_email_hash,
      p.updated_ultimate_parent_account_name as partner_account_name,
      p.updated_ultimate_parent_account_id as partner_account_id_sfdc,
      u.region_derived,
      p.credential_id,
      p.issued_on,
      p.calculated_expired_on,
      p.credential_name
    from
      capability_final p
      left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
  )
  ,
  final_1 as (
    select 
      credential_id, 
      certification_email, 
      credential_name, 
      partner_account_name, 
      date_format(issued_on, "yyyy-MM-dd") as issued_on, 
      date_format(calculated_expired_on, "yyyy-MM-dd") as expired_on
    from certs
    where partner_account_name in (
      'Accenture (HQ)',
      'Tata Consultancy Services (HQ)',
      'Cognizant Technology Solutions (HQ)',
      'LTIMindtree Limited (HQ)',
      'Capgemini S.A. (HQ)',
      'Deloitte Consulting (HQ)',
      'E&Y (HQ)',
      'Avanade Inc (HQ)',
      'Infosys Technologies (HQ)',
      'Celebal Technologies Private Limited (HQ)',
      'Wipro (HQ)',
      'EPAM (HQ)',
      'Tech Mahindra Limited (HQ)',
      'Booz Allen Hamilton Partner',
      'Slalom Consulting (HQ)',
      'Impetus Technologies',
      'KPMG LLP (HQ)',
      'Tredence Inc (HQ)',
      'Fractal Analytics (HQ)',
      'Eviden (HQ)',
      'NTT Data Corporation (HQ)',
      'IBM (HQ)',
      'Tiger Analytics (HQ)',
      'Reply (HQ)',
      'DXC Technology (HQ)',
      'Conseillers en Gestion et Informatique CGI Inc. (HQ)',
      'Datametica Solutions',
      'Quantiphi (HQ)',
      'Persistent Systems Inc.',
      'Devoteam SA (HQ)',
      'Koantek LLC',
      'Kubrick Group (HQ)',
      'Wavicle Data Solutions',
      'McKinsey & Company (HQ)',
      'Agilisium Consulting (HQ)',
      'Perficient Inc',
      'Hitachi Solutions (HQ)',
      'Mphasis',
      'HCL Technologies (HQ)',
      'Fujitsu Australia Ltd. (HQ)',
      'Neudesic',
      'Insight Enterprises (HQ)',
      'Zeb',
      'ZS Associates',
      '3Cloud LLC',
      'JEMS Datafactory SASU',
      'Blackstraw.ai',
      'OpenValue',
      'CitiusTech Inc.',
      'ARQ',
      'Mantel Operations Pty Ltd',
      'Hexaware Technologies (HQ)',
      'Adastra (HQ)',
      'Factored, Inc.',
      'Valcon',
      'Thorogood Associates',
      'Nagarro Software Pvt Ltd (HQ)',
      'KPI Partners',
      'BlueShift Brasil',
      'SDK Tek Services Ltd.',
      'Virtusa',
      'Publicis sapient (APAC)',
      'Incedo Inc',
      'Fragma Data Systems',
      'Infogain Corporation (HQ)',
      'Computomic Software & Consulting LLC',
      'BI4ALL',
      'EXL Service',
      'BOSONIT S.L.',
      'Servian',
      'Minsait - Indra Sistemas Brand',
      'initions GmbH',
      'Lingaro sp. z o.o.',
      'Ekimetrics',
      'Elastacloud',
      'Guidehouse',
      'West Monroe',
      'Rackspace Hosting (HQ)',
      'twoday Holding Denmark ApS (HQ)',
      'Lovelytics (HQ)',
      'KPMG LLP (HQ)',
      'GENPACT (UK) LIMITED (HQ)',
      'Publicis Sapient (HQ)',
      'Kyndryl Inc (HQ)',
      'Aimpoint Digital',
      'LatentView Analytics',
      'PWC (HQ)',
      'Onix Networking Corp.',
      'Nagarro (HQ)',
      'Mantel Operations Pty Ltd (HQ)',
      'NCS Pte Ltd (HQ)',
      'Thoughtworks US',
      'Sopra Steria EspaÃ±a S.A.',
      'Lenovo (Hong Kong) Limited (HQ)',
      'syrencloud Inc',
      'Lingaro',
      'iLink Digital (HQ)',
      'Indicium',
      'Cuelebre AB (HQ)',
      'Bizmetric',
      'FPT Asia Pacific Pte Ltd (HQ)',
      'TO THE NEW Private Limited',
      'Hitachi Solutions, Ltd. (HQ)',
      'D ONE Value Creation AG',
      'RevoData',
      'Thorogood Associates (HQ)',
      'Lufthansa Industry Solutions GmbH & Co. KG',
      'Sigmoid (HQ)',
      'DIGIVATE LABS PRIVATE LIMITED',
      'BJSS',
      'Eleflow Big Data e Analytics',
      'XponentL Data, Inc.',
      'Tier One Analytics (HQ)',
      'Datapao',
      'InfoCepts LLC (HQ)',
      'Exponentia.ai Private limited',
      'Rackspace Singapore Pte Ltd',
      'NS Solutions Corporation',
      'Lovelytics Data, LLC (HQ)',
      'Blend360',
      'Eucloid Data Inc',
      'b.telligent Deutschland GmbH',
      'Xebia (HQ)',
      'Inteltion',
      'Nousot, Inc.',
      'DataNimbus',
      'Cegeka NV',
      'Tavant Technologies, Inc.',
      'Entrada AI, Inc.',
      'Daugherty Business Solutions',
      'MentorMate',
      'LumenData',
      'BDO Canada',
      'Encora Digital LLC',
      'Marlabs Inc.',
      'ORAYLIS GmbH',
      'STRATEQ SYSTEMS SDN BHD',
      'Telstra Purple (HQ)',
      'SDG Group (HQ)',
      'ELITMIND sp. z o. o.',
      'Advancing Analytics',
      'MACNICA, Inc. (HQ)',
      'Cavallo Technologies Inc',
      'Delaware Consulting CV',
      'Concentrix Catalyst',
      'Infinitive',
      'Cellenza SAS',
      'MEGAZONE CLOUD CORPORATION',
      'Fission Labs Inc',
      'Synechron',
      'SoftwareOne AG (HQ)',
      'Cloocus Co., Ltd. (HQ)',
      'Infomotion GmbH',
      'Analytics8, LLC',
      'Aubay (HQ)',
      'Wortell Smart',
      'Birlasoft Solutions Inc.',
      'Unify Consulting',
      'Artefact',
      'Woodmark AG',
      'Endava',
      'Quantori',
      'InfoServices LLC (HQ)',
      'MFEC Public Company Limited',
      'Nexer Group (HQ)',
      'Mastek Limited (HQ)',
      'Xoriant',
      'Fog Solutions Inc',
      'Xorbix Technologies Inc.',
      'Rearc',
      'Sunnydata Inc.',
      'Orion Innovation',
      'Brillio',
      'Blueprint Technologies',
      'Bosch Global Software Technologies Private Limited',
      'MatrixDnA (HQ)',
      'CI&T Software',
      'Billigence',
      'Orion Digital Solutions',
      'Ippon Technologies (HQ)',
      'Pariveda Solutions',
      'Jarvis Consulting Group',
      'Zennify, INC',
      'Searce PTE Ltd',
      'Aarini Consulting BV',
      'Acxiom',
      'ADA DIGITAL SINGAPORE PTE. LTD.',
      'ADD d.o.o. - Business Solutions',
      'Adesso',
      'Affine Inc (HQ)',
      'AIM Consulting',
      'AIonOS PTE. LTD.',
      'Aivix (HQ)',
      'Alexander Thamm GmbH',
      'Apex Systems (HQ)',
      'Ardentisys',
      'areto Consulting GmbH (HQ)',
      'ARKON DATA (COMPLEX ADAPTIVE SYSTEMS S.A.P.I. DE C.V.)',
      'Arsaga Partners Co., Ltd.',
      'Avvale S.p.A.',
      'BeesBridge LLC',
      'Bespin Global',
      'Bi3 technologies Pty Ltd',
      'BIP - Business Integration Partners SPA (HQ)',
      'Bits In Glass Inc.',
      'Blazeclan Technologies',
      'Bluechip Technologies Limited',
      'Bluetab Solutions S.L.U.',
      'Boston Consulting Group (HQ)',
      'Bounteous',
      'Bouvet Norge AS',
      'Brightly Works Oy',
      'BUSINESS PROCESS & TECHNOLOGIES INTEGRATION S.A.S',
      'C2S Technologies Inc',
      'CapTech',
      'Caylent',
      'Cloud1 Oy',
      'Cloudaeon Technology Limited',
      'CloudIQ Technologies',
      'Cognitivo Pty Ltd',
      'Colibri LTD',
      'Collaboration Betters The World GmbH (HQ)',
      'COMPASS UOL',
      'Confiz LLC (HQ)',
      'Credera',
      'Customertimes Corp',
      'Cyber Hunters Ltd',
      'Data Dynamics Inc',
      'Data Solucoes',
      'Data Surge LLC',
      'Dataeaze Systems Pvt. Ltd.',
      'DataPattern',
      'Dataside Solucoes em Dados LTDA',
      'Definitive Healthcare, LLC (SI Partner)',
      'Delegate',
      'DevScope',
      'Dufrain Consulting',
      'E-Simplicity',
      'Effectual Inc.',
      'ELCA',
      'element61',
      'Epical Sweden AB',
      'Epsilon',
      'Factspan Inc',
      'FTI Consulting, Inc.',
      'Futurice Oy',
      'Gainwell Technologies',
      'Ganit Business Solutions Private Limited',
      'GlobalLogic Corp. UK Ltd (HQ)',
      'Globant, LLC (HQ)',
      'Grid Dynamics Holdings Inc',
      'Halfspace',
      'Hiflylabs',
      'HOONAR TEKWURKS PRIVATE LIMITED',
      'Hoster-JP, Inc',
      'HSO ANZ (HQ)',
      'Hvar Consultoria LTDA',
      'ICONSULTING S.P.A.',
      'iData',
      'INDRA SOLUCIONES TECNOLOGÍAS DE LA INFORMACIÓN, S.L.U (HQ)',
      'InfoObjects, Inc.',
      'Infostretch Corporation (Apexon)',
      'Inovex GmbH',
      'Insight Global',
      'intelia',
      'Intelli5 INC',
      'Jump Label Solutions',
      'Kagool',
      'KI performance GmbH',
      'Knowit Ab (HQ)',
      'Kumulus',
      'Kushagramati Analytics Private Limited',
      'Lantern',
      'Leading Edge Group Limited',
      'Leega Consultoria e Informatica Ltda',
      'Lirik Inc.',
      'Long View Systems',
      'MICROPOLE',
      'MobiLab Solutions GmbH',
      'Modak Analytics LLP',
      'MP DATA',
      'Mu Sigma Business Solutions LLC',
      'Mutt Data (Vuriltek S.A)',
      'Ness Digital Engineering',
      'Netlight Consulting Oy (HQ)',
      'NucleusTeq',
      'OutcomeCatalyst LLC',
      'Paltech Consulting Private Limited',
      'Plain Concepts (HQ)',
      'Profinit EU, s.r.o.',
      'PUE Data',
      'Qubika (CLV Corp)',
      'RBA',
      'Redeploy AB (HQ)',
      'Rocket Science Development',
      'SAIC',
      'Scigility Switzerland AG',
      'Shorthills AI',
      'Smoothstack LLC',
      'SoftServe Inc. (HQ)',
      'Solita (HQ)',
      'SOUTHWORKS LLC',
      'synvert GmbH',
      'Systech Solutions, Inc.',
      'Talan SAS',
      'Tech Fabric LLC',
      'TEKsystems Global Services, LLC',
      'Telefónica Tech',
      'The Math Company',
      'Theta Systems Limited',
      'Tietoevry Finland Oy (HQ)',
      'Trace3',
      'Tudip Technologies',
      'UBDS Group Holdings Limited',
      'Ultra Tendency International GmbH (HQ)',
      'Valtech UK Limited(HQ)',
      'Value Momentum (HQ)',
      'WeVision LLC',
      'WinWire Technologies',
      'WISEANALYTICS.IO LTD',
      'WorldLink US',
      'Zeal Corporation',
      'Zsahar LLC'
    )
  )
  ,
  final_2 as (
    select 
      credential_id, 
      "PII Redacted" as certification_email, 
      credential_name, 
      partner_account_name, 
      issued_on, 
      calculated_expired_on as expired_on
    from certs 
    where partner_account_name not in (
      'Accenture (HQ)',
      'Tata Consultancy Services (HQ)',
      'Cognizant Technology Solutions (HQ)',
      'LTIMindtree Limited (HQ)',
      'Capgemini S.A. (HQ)',
      'Deloitte Consulting (HQ)',
      'E&Y (HQ)',
      'Avanade Inc (HQ)',
      'Infosys Technologies (HQ)',
      'Celebal Technologies Private Limited (HQ)',
      'Wipro (HQ)',
      'EPAM (HQ)',
      'Tech Mahindra Limited (HQ)',
      'Booz Allen Hamilton Partner',
      'Slalom Consulting (HQ)',
      'Impetus Technologies',
      'KPMG LLP (HQ)',
      'Tredence Inc (HQ)',
      'Fractal Analytics (HQ)',
      'Eviden (HQ)',
      'NTT Data Corporation (HQ)',
      'IBM (HQ)',
      'Tiger Analytics (HQ)',
      'Reply (HQ)',
      'DXC Technology (HQ)',
      'Conseillers en Gestion et Informatique CGI Inc. (HQ)',
      'Datametica Solutions',
      'Quantiphi (HQ)',
      'Persistent Systems Inc.',
      'Devoteam SA (HQ)',
      'Koantek LLC',
      'Kubrick Group (HQ)',
      'Wavicle Data Solutions',
      'McKinsey & Company (HQ)',
      'Agilisium Consulting (HQ)',
      'Perficient Inc',
      'Hitachi Solutions (HQ)',
      'Mphasis',
      'HCL Technologies (HQ)',
      'Fujitsu Australia Ltd. (HQ)',
      'Neudesic',
      'Insight Enterprises (HQ)',
      'Zeb',
      'ZS Associates',
      '3Cloud LLC',
      'JEMS Datafactory SASU',
      'Blackstraw.ai',
      'OpenValue',
      'CitiusTech Inc.',
      'ARQ',
      'Mantel Operations Pty Ltd',
      'Hexaware Technologies (HQ)',
      'Adastra (HQ)',
      'Factored, Inc.',
      'Valcon',
      'Thorogood Associates',
      'Nagarro Software Pvt Ltd (HQ)',
      'KPI Partners',
      'BlueShift Brasil',
      'SDK Tek Services Ltd.',
      'Virtusa',
      'Publicis sapient (APAC)',
      'Incedo Inc',
      'Fragma Data Systems',
      'Infogain Corporation (HQ)',
      'Computomic Software & Consulting LLC',
      'BI4ALL',
      'EXL Service',
      'BOSONIT S.L.',
      'Servian',
      'Minsait - Indra Sistemas Brand',
      'initions GmbH',
      'Lingaro sp. z o.o.',
      'Ekimetrics',
      'Elastacloud',
      'Guidehouse',
      'West Monroe',
      'Rackspace Hosting (HQ)',
      'twoday Holding Denmark ApS (HQ)',
      'Lovelytics (HQ)',
      'KPMG LLP (HQ)',
      'GENPACT (UK) LIMITED (HQ)',
      'Publicis Sapient (HQ)',
      'Kyndryl Inc (HQ)',
      'Aimpoint Digital',
      'LatentView Analytics',
      'PWC (HQ)',
      'Onix Networking Corp.',
      'Nagarro (HQ)',
      'Mantel Operations Pty Ltd (HQ)',
      'NCS Pte Ltd (HQ)',
      'Thoughtworks US',
      'Sopra Steria EspaÃ±a S.A.',
      'Lenovo (Hong Kong) Limited (HQ)',
      'syrencloud Inc',
      'Lingaro',
      'iLink Digital (HQ)',
      'Indicium',
      'Cuelebre AB (HQ)',
      'Bizmetric',
      'FPT Asia Pacific Pte Ltd (HQ)',
      'TO THE NEW Private Limited',
      'Hitachi Solutions, Ltd. (HQ)',
      'D ONE Value Creation AG',
      'RevoData',
      'Thorogood Associates (HQ)',
      'Lufthansa Industry Solutions GmbH & Co. KG',
      'Sigmoid (HQ)',
      'DIGIVATE LABS PRIVATE LIMITED',
      'BJSS',
      'Eleflow Big Data e Analytics',
      'XponentL Data, Inc.',
      'Tier One Analytics (HQ)',
      'Datapao',
      'InfoCepts LLC (HQ)',
      'Exponentia.ai Private limited',
      'Rackspace Singapore Pte Ltd',
      'NS Solutions Corporation',
      'Lovelytics Data, LLC (HQ)',
      'Blend360',
      'Eucloid Data Inc',
      'b.telligent Deutschland GmbH',
      'Xebia (HQ)',
      'Inteltion',
      'Nousot, Inc.',
      'DataNimbus',
      'Cegeka NV',
      'Tavant Technologies, Inc.',
      'Entrada AI, Inc.',
      'Daugherty Business Solutions',
      'MentorMate',
      'LumenData',
      'BDO Canada',
      'Encora Digital LLC',
      'Marlabs Inc.',
      'ORAYLIS GmbH',
      'STRATEQ SYSTEMS SDN BHD',
      'Telstra Purple (HQ)',
      'SDG Group (HQ)',
      'ELITMIND sp. z o. o.',
      'Advancing Analytics',
      'MACNICA, Inc. (HQ)',
      'Cavallo Technologies Inc',
      'Delaware Consulting CV',
      'Concentrix Catalyst',
      'Infinitive',
      'Cellenza SAS',
      'MEGAZONE CLOUD CORPORATION',
      'Fission Labs Inc',
      'Synechron',
      'SoftwareOne AG (HQ)',
      'Cloocus Co., Ltd. (HQ)',
      'Infomotion GmbH',
      'Analytics8, LLC',
      'Aubay (HQ)',
      'Wortell Smart',
      'Birlasoft Solutions Inc.',
      'Unify Consulting',
      'Artefact',
      'Woodmark AG',
      'Endava',
      'Quantori',
      'InfoServices LLC (HQ)',
      'MFEC Public Company Limited',
      'Nexer Group (HQ)',
      'Mastek Limited (HQ)',
      'Xoriant',
      'Fog Solutions Inc',
      'Xorbix Technologies Inc.',
      'Rearc',
      'Sunnydata Inc.',
      'Orion Innovation',
      'Brillio',
      'Blueprint Technologies',
      'Bosch Global Software Technologies Private Limited',
      'MatrixDnA (HQ)',
      'CI&T Software',
      'Billigence',
      'Orion Digital Solutions',
      'Ippon Technologies (HQ)',
      'Pariveda Solutions',
      'Jarvis Consulting Group',
      'Zennify, INC',
      'Searce PTE Ltd',
      'Aarini Consulting BV',
      'Acxiom',
      'ADA DIGITAL SINGAPORE PTE. LTD.',
      'ADD d.o.o. - Business Solutions',
      'Adesso',
      'Affine Inc (HQ)',
      'AIM Consulting',
      'AIonOS PTE. LTD.',
      'Aivix (HQ)',
      'Alexander Thamm GmbH',
      'Apex Systems (HQ)',
      'Ardentisys',
      'areto Consulting GmbH (HQ)',
      'ARKON DATA (COMPLEX ADAPTIVE SYSTEMS S.A.P.I. DE C.V.)',
      'Arsaga Partners Co., Ltd.',
      'Avvale S.p.A.',
      'BeesBridge LLC',
      'Bespin Global',
      'Bi3 technologies Pty Ltd',
      'BIP - Business Integration Partners SPA (HQ)',
      'Bits In Glass Inc.',
      'Blazeclan Technologies',
      'Bluechip Technologies Limited',
      'Bluetab Solutions S.L.U.',
      'Boston Consulting Group (HQ)',
      'Bounteous',
      'Bouvet Norge AS',
      'Brightly Works Oy',
      'BUSINESS PROCESS & TECHNOLOGIES INTEGRATION S.A.S',
      'C2S Technologies Inc',
      'CapTech',
      'Caylent',
      'Cloud1 Oy',
      'Cloudaeon Technology Limited',
      'CloudIQ Technologies',
      'Cognitivo Pty Ltd',
      'Colibri LTD',
      'Collaboration Betters The World GmbH (HQ)',
      'COMPASS UOL',
      'Confiz LLC (HQ)',
      'Credera',
      'Customertimes Corp',
      'Cyber Hunters Ltd',
      'Data Dynamics Inc',
      'Data Solucoes',
      'Data Surge LLC',
      'Dataeaze Systems Pvt. Ltd.',
      'DataPattern',
      'Dataside Solucoes em Dados LTDA',
      'Definitive Healthcare, LLC (SI Partner)',
      'Delegate',
      'DevScope',
      'Dufrain Consulting',
      'E-Simplicity',
      'Effectual Inc.',
      'ELCA',
      'element61',
      'Epical Sweden AB',
      'Epsilon',
      'Factspan Inc',
      'FTI Consulting, Inc.',
      'Futurice Oy',
      'Gainwell Technologies',
      'Ganit Business Solutions Private Limited',
      'GlobalLogic Corp. UK Ltd (HQ)',
      'Globant, LLC (HQ)',
      'Grid Dynamics Holdings Inc',
      'Halfspace',
      'Hiflylabs',
      'HOONAR TEKWURKS PRIVATE LIMITED',
      'Hoster-JP, Inc',
      'HSO ANZ (HQ)',
      'Hvar Consultoria LTDA',
      'ICONSULTING S.P.A.',
      'iData',
      'INDRA SOLUCIONES TECNOLOGÍAS DE LA INFORMACIÓN, S.L.U (HQ)',
      'InfoObjects, Inc.',
      'Infostretch Corporation (Apexon)',
      'Inovex GmbH',
      'Insight Global',
      'intelia',
      'Intelli5 INC',
      'Jump Label Solutions',
      'Kagool',
      'KI performance GmbH',
      'Knowit Ab (HQ)',
      'Kumulus',
      'Kushagramati Analytics Private Limited',
      'Lantern',
      'Leading Edge Group Limited',
      'Leega Consultoria e Informatica Ltda',
      'Lirik Inc.',
      'Long View Systems',
      'MICROPOLE',
      'MobiLab Solutions GmbH',
      'Modak Analytics LLP',
      'MP DATA',
      'Mu Sigma Business Solutions LLC',
      'Mutt Data (Vuriltek S.A)',
      'Ness Digital Engineering',
      'Netlight Consulting Oy (HQ)',
      'NucleusTeq',
      'OutcomeCatalyst LLC',
      'Paltech Consulting Private Limited',
      'Plain Concepts (HQ)',
      'Profinit EU, s.r.o.',
      'PUE Data',
      'Qubika (CLV Corp)',
      'RBA',
      'Redeploy AB (HQ)',
      'Rocket Science Development',
      'SAIC',
      'Scigility Switzerland AG',
      'Shorthills AI',
      'Smoothstack LLC',
      'SoftServe Inc. (HQ)',
      'Solita (HQ)',
      'SOUTHWORKS LLC',
      'synvert GmbH',
      'Systech Solutions, Inc.',
      'Talan SAS',
      'Tech Fabric LLC',
      'TEKsystems Global Services, LLC',
      'Telefónica Tech',
      'The Math Company',
      'Theta Systems Limited',
      'Tietoevry Finland Oy (HQ)',
      'Trace3',
      'Tudip Technologies',
      'UBDS Group Holdings Limited',
      'Ultra Tendency International GmbH (HQ)',
      'Valtech UK Limited(HQ)',
      'Value Momentum (HQ)',
      'WeVision LLC',
      'WinWire Technologies',
      'WISEANALYTICS.IO LTD',
      'WorldLink US',
      'Zeal Corporation',
      'Zsahar LLC'
    )
  )

  , 

  final_3 as (
    select *
    from final_1
    union all 
    select *
    from final_2
  )

  select *
  from final_3

''')

# COMMAND ----------

df = spark.sql('''
  with ranked_docebo_users as (
    select
      *,
      rank() over (
        partition by email_hash
        order by
          last_login
      ) as rank_data
    from
      main.field_learning_enablement.docebo_users
    where
      processdate =(
        Select
          max(processdate)
        from
          main.field_learning_enablement.docebo_users
      )
      and nvl(audience, 'Unknown') in ('Partner', 'Partner Other')
  ),
  docebo_users as (
    select
      *
    from
      ranked_docebo_users
    where
      rank_data = 1
  ),
  blacklist_domains as (
    select
      distinct blacklist_domain
    from
      main.field_learning_enablement.blacklist_domains
    where
      processDate = (
        select
          max(processDate)
        from
          main.field_learning_enablement.blacklist_domains
      )
  ),
  capability as (
    select
      c.*
    except(c.learner_email_domain),
      case
        when c.learner_email_hash = '78dfc4089d9f80cbae14429cb95508c1955262ebdee4184c4e3fb3503a70ae18' then 'gmail.com'
        else learner_email_domain
      end as learner_email_domain
    from
      main.field_learning_enablement.partner_capability c
    where
      c.processdate = (
        select
          max(processdate)
        from
          main.field_learning_enablement.partner_capability
      )
      and learner_email_hash is not null
  ),
  -- fix learner_user_ids records that have one row with contact email and another without (because of learndot data)
  contact_email_fix as (
    select
      distinct learner_email_hash,
      contact_email,
      dense_rank() over (
        partition by learner_email_hash
        order by
          contact_email nulls last
      ) as rank
    from
      main.field_learning_enablement.partner_capability
    where
      category = 'Technical Trained'
      and processDate = (
        select
          max(processdate)
        from
          main.field_learning_enablement.partner_capability
      )
  ),
  capability_v2 as (
    select
      c.*,
      case
        when category = 'Technical Certified' then a.recipient_email
        else d.contact_email
      end as updated_email
    from
      capability c
      left join contact_email_fix d on c.learner_email_hash = d.learner_email_hash
      and d.rank = 1
      and c.category = 'Technical Trained'
      left join main.it_accredible_bronze.credentials a on c.credential_id = a.credential_id
      and a.processdate = (
        select
          max(processdate)
        from
          main.it_accredible_bronze.credentials
      )
  ),
  capability_v3 as (
    select
      c.*,
      b.blacklist_domain as b_blacklist_domain,
      b1.blacklist_domain as b1_blacklist_domain
    from
      capability_v2 c
      left join blacklist_domains b on c.learner_email_domain = b.blacklist_domain
      left join blacklist_domains b1 on c.learner_alternate_email_domain = b1.blacklist_domain
  ),
  capability_pre as (
    select
      *,
      case
        when b_blacklist_domain is not null
        and (
          b1_blacklist_domain is null
          and learner_alternate_email_domain is not null
        ) then 'Email is blacklist - select secondary'
        when b1_blacklist_domain is not null
        and (
          b_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Alternate email is blacklist - select primary'
        when (
          b_blacklist_domain is not null
          and b1_blacklist_domain is not null
          and learner_email_domain is not null
        ) then 'Only blacklist domains - select primary'
        when (
          b_blacklist_domain is null
          and b1_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Email Good - select primary'
        else 'Others'
      end as bucket
    from
      capability_v3
  ),
  --alternate_emails as (
  --  select
  --    id_user,
  --    case
  --      trim(lower(field_37))
  --      when '' then null
  --      else trim(lower(field_37))
  --    end as alternate_email,
  --    split(trim(lower(field_37)), '@', 2) [1] as alternate_email_domain
  --  from
  --    main.it_docebo_bronze.core_user_field_value
  --  where
  --    processDate = (
  --      select
  --        max(processDate)
  --      from
  --        main.it_docebo_bronze.core_user_field_value
  --    )
  --),
  alternate_emails as (
    select
      id_user,
      case
        trim(lower(field_value))
        when '' then null
        else trim(lower(field_value))
      end as alternate_email,
      split(trim(lower(field_value)), '@', 2) [1] as alternate_email_domain
    from
      main.it_docebo_bronze.core_user_field_value
    where
      processDate = (
        select
          max(processDate)
        from
          main.it_docebo_bronze.core_user_field_value
      )
    and id_field = 37
  ),
  emails as (
    select
      distinct lower(email) as email,
      sha2(lower(email), 256) as email_hash
    from
      main.it_docebo_bronze.core_user
    where
      processdate =(
        Select
          max(processdate)
        from
          main.it_docebo_bronze.core_user
      )
      and split(trim(lower(email)), '@', 2) [1] not in (
        select
          distinct blacklist_domain
        from
          blacklist_domains
      )
    union
      (
        select
          distinct lower(alternate_emails.alternate_email) as email,
          sha2(lower(alternate_Email), 256) as email_hash
        from
          alternate_emails
        where
          alternate_email_domain not in (
            select
              distinct blacklist_domain
            from
              blacklist_domains
          )
      )
  ),
  capability_final as (
    select
      p.*,
      e.email,
      case
        when p.bucket = 'Email is blacklist - select secondary' then e.email
        else p.updated_email
      end as final_email
    from
      capability_pre p
      left join emails e on p.learner_alternate_email_hash = e.email_hash
      and p.bucket = 'Email is blacklist - select secondary'
  ),
  -- fix learner_email_hash records that have one row with partner account and another without (because of learndot data)
  account_fix as (
    select
      distinct learner_email_hash,
      partner_account_name,
      partner_account_id_sfdc,
      dense_rank() over (
        partition by learner_email_hash
        order by
          partner_account_name nulls last
      ) as rank
    from
      main.field_learning_enablement.partner_capability
    where
      category = 'Technical Trained'
      and processDate = (
        select
          max(processdate)
        from
          main.field_learning_enablement.partner_capability
      )
  ),
  trainings as (
    select
      nvl(p.final_email, 'Unknown') as training_email,
      sha2(nvl(p.final_email, 'Unknown'), 256) as training_email_hash,
      p.updated_email,
      p.learner_email_hash,
      a.partner_account_name,
      a.partner_account_id_sfdc,
      p.updated_email,
      u.region_derived,
      u.country_derived,
      collect_set(p.course) as courses_completed,
      max(p.date) :: date as date_last_course_completed,
      max(p.fiscal_quarter_year) as qtr_last_course_completed
    from
      capability_final p
      left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
      left join account_fix a on p.learner_email_hash = a.learner_email_hash
      and a.rank = 1
    where
      p.category = 'Technical Trained'
    group by
      all
  ),
  certs as (
    select
      p.final_email as certification_email,
      sha2(p.final_email, 256) as certification_email_hash,
      array_join(collect_set(p.updated_email), ",") as updated_email,
      array_join(collect_set(p.learner_email_hash), ",") as learner_email_hash,
      p.partner_account_name,
      p.partner_account_id_sfdc,
      u.region_derived,
      u.country_derived,
      -- combining two different email to the same email means there could be two regions for the same email
      collect_set(p.credential_id) as credential_ids,
      collect_set(p.course) as certs_completed,
      max(p.date) :: date as date_last_cert_completed,
      max(p.fiscal_quarter_year) as qtr_last_cert_completed
    from
      capability_final p
      left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
    where
      p.category = 'Technical Certified'
    group by
      all
  ),
  trainings_certs as (
    select
      t.training_email,
      t.training_email_hash,
      t.updated_email,
      t.learner_email_hash,
      t.partner_account_name,
      t.partner_account_id_sfdc,
      t.region_derived,
      t.country_derived,
      t.courses_completed,
      t.date_last_course_completed,
      t.qtr_last_course_completed,
      c.certification_email,
      c.certification_email_hash,
      c.certs_completed,
      c.date_last_cert_completed,
      c.qtr_last_cert_completed
    from
      trainings t
      left join certs c on t.training_email = c.certification_email
  ),
  certified_not_trained as (
    select
      null as training_email,
      null as training_email_hash,
      c.updated_email,
      c.learner_email_hash,
      c.partner_account_name,
      c.partner_account_id_sfdc,
      c.region_derived,
      c.country_derived,
      null as courses_completed,
      null as date_last_course_completed,
      null as qtr_last_course_completed,
      c.certification_email,
      c.certification_email_hash,
      c.certs_completed,
      c.date_last_cert_completed,
      c.qtr_last_cert_completed
    from
      certs c
    where
      certification_email_hash not in (
        select
          distinct certification_email_hash
        from
          trainings_certs
        where
          certification_email is not null
      )
  ),
  final as (
    select
      *
    from
      trainings_certs
    union all
    select
      *
    from
      certified_not_trained
  ),
  pre as (
    select
      case
        when size(certs_completed) > 0 then 1
        else 0
      end as certified_flag,
      case
        when size(courses_completed) > 0 then 1
        else 0
      end as trained_flag,
      *
    from
      final
  )
  select
    certified_flag,
    trained_flag,
    training_email,
    training_email_hash,
    updated_email as contact_email,
    learner_email_hash,
    partner_account_name,
    partner_account_id_sfdc,
    region_derived as region,
    country_derived as country,
    courses_completed,
    date_last_course_completed,
    qtr_last_course_completed,
    certification_email,
    certification_email_hash,
    certs_completed,
    date_last_cert_completed,
    qtr_last_cert_completed
  from
    pre


''')

# COMMAND ----------

df.createOrReplaceTempView('trained_not_certified')

# COMMAND ----------

trained_not_certified = spark.sql('''
  with pre as (
    select distinct partner_account_id_sfdc, partner_manager, portfolio, managed_partner
    from main.field_learning_enablement.partner_capability
    where processDate = (select max(processDate) from main.field_learning_enablement.partner_capability)
  )
  select 
    t.*, 
    a.Partner_Level__c as partner_level,
    a.Partner_Tier__c as partner_tier, 
    p.partner_manager, 
    p.portfolio, 
    p.managed_partner
  from trained_not_certified t 
  left join main.sfdc_bronze.account a on t.partner_account_id_sfdc = a.id and a.processDate = (select max(processDate) from main.sfdc_bronze.account)
  left join pre p on t.partner_account_id_sfdc = p.partner_account_id_sfdc

''')

# COMMAND ----------

expiring_certs_df = spark.sql('''
with data as (
  select
    t.learner_email_hash as email_hash,
    t.partner_account_name,
    t.partner_account_id_sfdc,
    t.region_derived as cert_Region,
    t.country_derived as cert_country,
    -- case
    --   when t.partner_account_name in (
    --     'Accenture (HQ)',
    --     'Deloitte Consulting (HQ)',
    --     'Capgemini S.A. (HQ)',
    --     'Avanade Inc (HQ)',
    --     'Infosys Technologies (HQ)',
    --     'Cognizant Technology Solutions (HQ)',
    --     'E&Y (HQ)',
    --     'Slalom Consulting (HQ)',
    --     'Wipro (HQ)',
    --     'Tata Consultancy Services (HQ)'
    --   ) then 'GSI'
    --   else 'Others'
    -- end as classification,
    t.* except (t.country_derived),
    ac.* except (ac.issued_on, ac.calculated_expired_on)
  from
    main.field_learning_enablement.partner_capability t
    inner join main.field_learning_enablement.accredible_credentials ac on t.learner_email_hash = ac.learner_email_hash
    and t.course = ac.credential_name
    and ac.processDate = (Select max(processdate) from main.field_learning_enablement.accredible_credentials)
  where
    t.processdate =  (Select max(processdate) from main.field_learning_enablement.partner_capability)
    and t.category = 'Technical Certified'
),
pre as (
  select
    t.email_hash,
    t.partner_account_name,
    t.partner_account_id_sfdc,
    t.cert_Region,
    t.cert_country,
    t.classification,
    t.date :: date,
    t.issued_on :: date,
    t.calculated_expired_on :: date
  from
    data t
),
final as (
  select
    t.email_hash,
    t.partner_account_name,
    t.partner_account_id_sfdc,
    t.cert_region,
    t.cert_country,
    t.classification,
    min(issued_on::date) as date_first_cert_issued,
    max(issued_on :: date) as date_last_cert_issued,
    max(calculated_expired_on :: date) as date_last_cert_expiring
  from
    pre t
  group by
    1,
    2,
    3,
    4,
    5,
    6
)
select
  classification,
  case when cert_region in ('AMER','LATAM') then 'AMER' else cert_region end as cert_region,
  partner_account_name,
  partner_account_id_sfdc,
  cert_country,
  -- persona,
  -- count(distinct email_hash),
  -- ,
  -- count(
  --   distinct case
  --     when (
  --       date_last_cert_expiring :: date > '2023-07-31'
  --       and date_last_cert_expiring :: date <= '2023-10-31'
  --     ) then email_hash
  --   end
  -- ) as q3_expiries,
  count(
    distinct case
      when (
        date_last_cert_expiring :: date > '2024-01-31'
        and date_last_cert_expiring :: date <= '2025-01-31'
      ) then email_hash
    end
  ) as fy25_expiries,
 count(
    distinct case
      when (
        date_last_cert_expiring :: date > '2024-01-31'
        and date_last_cert_expiring :: date <= '2024-04-30'
      ) then email_hash
    end
  ) as q1_fy25_expiries,
   count(
    distinct case
      when (
        date_last_cert_expiring :: date > '2024-04-30'
        and date_last_cert_expiring :: date <= '2024-07-31'
      ) then email_hash
    end
  ) as q2_fy25_expiries,
  count(
    distinct case
      when (
        date_last_cert_expiring :: date > '2024-07-31'
        and date_last_cert_expiring :: date <= '2024-10-31'
      ) then email_hash
    end
  ) as q3_fy25_expiries,
  count(
    distinct case
      when (
        date_last_cert_expiring :: date > '2024-10-31'
        and date_last_cert_expiring :: date <= '2025-01-31'
      ) then email_hash
    end
  ) as q4_fy25_expiries--,
 -- count(
 --    distinct case
 --      when (
 --         date_last_cert_expiring :: date <= '2025-01-31'
 --      ) then email_hash
 --    end
 --  ) as total_expiries
from
  final f 
-- left join  partner_personas p on f.email_hash=p.learner_email_hash
where 1=1
group by all
  -- date_first_cert_issued < '2023-02-01'
-- and classification='GSI'
-- group by
--   1--  where t.date::date<>t.issued_on::date
  -- group by 1,2,3                              
                              
''')

# COMMAND ----------

all_partner_certs_by_company_email_partition = add_gold_metadata(all_partner_certs_by_company_email)
expired_certs_df_partition = add_gold_metadata(expired_certs_df)
df_gold = add_gold_metadata(trained_not_certified)
expiring_certs_df_gold = add_gold_metadata(expiring_certs_df)

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = all_partner_certs_by_company_email_partition, 
#   table_name = f'{focus_database_name}.partner_certs_by_company_email', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = expired_certs_df_partition, 
#   table_name = f'{focus_database_name}.partner_expired_certs_by_company_email', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = df_gold, 
#   table_name = f'{focus_database_name}.partner_trained_and_certified_splits', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = expiring_certs_df_gold, 
#   table_name = f'{focus_database_name}.partner_expiring_certifications', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )