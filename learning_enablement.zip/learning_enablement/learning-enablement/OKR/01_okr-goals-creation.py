# Databricks notebook source
# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

#%run "/Users/liam.clifford@databricks.com/Liam's Notebook - readGoogleSheet UDF" 

# COMMAND ----------

import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
#from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove; these will be handy
# from focus_databricks.common.date_utils import *
# from focus_databricks.koda.table_utils import *
# from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

workbook_id='1SyQOSWqHbHwDal9C1bCxeCnwKWJW1U2tXfo25h2ko7E'
sheet_id='110421946'
read_google_sheet(workbook_id=workbook_id,sheet_id=sheet_id).createOrReplaceTempView('GOALS_FY26_AUD')

# COMMAND ----------

workbook_id='1SyQOSWqHbHwDal9C1bCxeCnwKWJW1U2tXfo25h2ko7E'
sheet_id='1645555310'
read_google_sheet(workbook_id=workbook_id,sheet_id=sheet_id).createOrReplaceTempView('GOALS_FY26_WO_AUD')

# COMMAND ----------

workbook_id='1SyQOSWqHbHwDal9C1bCxeCnwKWJW1U2tXfo25h2ko7E'
sheet_id='710025539'
read_google_sheet(workbook_id=workbook_id,sheet_id=sheet_id).createOrReplaceTempView('GOALS_FY26_TRAINED_ACC')

# COMMAND ----------

df=spark.sql("""select metric,fq2,audience,bu,bu_1,value     from GOALS_FY26_AUD
             union all 
             select metric,fq2,'NA' as audience,bu,bu_1,value from GOALS_FY26_WO_AUD""")

# COMMAND ----------

# MAGIC %md
# MAGIC Preprocessing the extracted data \
# MAGIC All #NA and DIV0 in column target mapped to null \
# MAGIC Calculate Fiscal Quarter value

# COMMAND ----------

df.withColumn("goal1", regexp_replace('value',",",''))\
  .withColumn("goal", col("goal1").cast('double'))\
  .withColumnRenamed("fq2","fq2_date")\
  .createOrReplaceTempView('GOALS_FY26')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table main.field_learning_enablement.okr_metrics_goals as
# MAGIC select 
# MAGIC G.*
# MAGIC ,D.fiscal_year_quarter as FQ2 
# MAGIC ,D.fiscal_quarter_start_date as qtr_start_date
# MAGIC ,D.fiscal_quarter_end_date as qtr_end_date
# MAGIC ,cast(D.fiscal_year AS INT) as fiscalYear
# MAGIC ,current_date as processDate
# MAGIC from GOALS_FY26 G
# MAGIC inner join main.it_core_dim.dim_dates D
# MAGIC on G.fq2_date=D.date

# COMMAND ----------

df_trained_acc=spark.sql("select * from GOALS_FY26_TRAINED_ACC")

# COMMAND ----------

df_trained_acc.withColumn("goal_trained_acc1", regexp_replace('trained_accounts',",",''))\
  .withColumn("goal_trained_acc", col("goal_trained_acc1").cast('double'))\
  .withColumn("goal_tot_acc1", regexp_replace('total_accounts',",",''))\
  .withColumn("goal_tot_acc", col("goal_tot_acc1").cast('double'))\
  .withColumnRenamed("fq2","fq2_date") \
  .createOrReplaceTempView("GOALS_FY26_trained_accounts")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table main.field_learning_enablement.okr_trained_acc_goals as
# MAGIC select 
# MAGIC G.metric
# MAGIC ,G.fq2_date
# MAGIC ,G.bu
# MAGIC ,G.bu_1
# MAGIC ,G.goal_trained_acc trained_accounts
# MAGIC ,G.goal_tot_acc total_accounts
# MAGIC ,D.fiscal_year_quarter as FQ2 
# MAGIC ,D.fiscal_quarter_start_date as qtr_start_date
# MAGIC ,D.fiscal_quarter_end_date as qtr_end_date
# MAGIC ,cast(D.fiscal_year AS INT) as fiscalYear
# MAGIC ,current_date as processDate
# MAGIC from GOALS_FY26_trained_accounts G
# MAGIC inner join main.it_core_dim.dim_dates D
# MAGIC on G.fq2_date=D.date