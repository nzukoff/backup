# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Karthik Reddy \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

#spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from pyspark.sql.types import DoubleType
#from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
# from focus_databricks.common.date_utils import *
# from focus_databricks.koda.table_utils import *
# from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

import time
from delta.tables import *
from datetime import date, datetime
import logging

logging.basicConfig(format="%(asctime)-15s %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def write_delta_table(
    spark,
    dataframe,
    table_name,
    format="delta",
    mode="overwrite",
    overwrite_schema="true",
    merge_schema="true",
    optimize=True,
    partition_column=None,
    zorder=None,
    replace_where=None,
    location=None,
):

    num_rows = dataframe.count()
    logger_statement = """Written the dataframe. Please look at the stats:
                          Details:
                          - Table Name: {0} 
                          - Total time spent: {1} minutes
                          - Write Options:
                            - format: {2}
                            - mode: {3}
                            - optimize: {4}
                            - zorder: {5}
                            - partition by: {6}
                            - replace where: {7}
                            - location: {8}
                            - Schema Options:
                                - overwrite schema: {9}
                                - merge schema: {10}
                          - Written rows:  {11}
                       """
    logger.info("Writting the table {0}".format(table_name))
    start_time = time.time()
    write_instructions = (
        dataframe.write.format(format)
        .mode(mode)
        .option("overwriteSchema", overwrite_schema)
        .option("mergeSchema", merge_schema)
    )

    if partition_column is not None:
        write_instructions = write_instructions.partitionBy(partition_column)

    if replace_where is not None:
        write_instructions = write_instructions.option("replaceWhere", replace_where)

    write_instructions.saveAsTable(table_name)
    write_time = time.time()

    if optimize:
        logger.info("Running optimize the delta table now")
        start = time.time()
        optimize_instructions = "OPTIMIZE " + table_name
        if replace_where is not None:
            logger.info("Replacing the delta table according to where clause now")
            optimize_instructions += " WHERE " + replace_where
            if zorder:
                optimize_instructions += " ZORDER BY " + zorder
                spark.sql(optimize_instructions)
        logger.info(
            "Optimized in {} minutes.".format(
                str(round((time.time() - write_time) / 60, 1))
            )
        )

    logger.info(
        logger_statement.format(
            table_name,
            round((write_time - start_time) / 60, 1),
            format,
            mode,
            optimize,
            zorder,
            partition_column,
            replace_where,
            location,
            overwrite_schema,
            merge_schema,
            num_rows,
        )
    )



# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

from pyspark.sql import DataFrame
from typing import Optional
from datetime import date,datetime
def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC # WEEKLY ACTIVE USERS

# COMMAND ----------

# DBTITLE 1,WAUs
final_wau_base_data_df = spark.sql('''
-- WITH base_data AS (
    SELECT 
        date,
        salesforce_account_id AS account_id,
        COUNT(DISTINCT CASE WHEN login_num_events_t7d > 0 THEN user_id END) AS wau
    FROM main.data_product_features.user_metrics
    WHERE salesforce_account_id NOT IN ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
      AND date >= '2024-02-01'
    GROUP BY date, salesforce_account_id

''').createOrReplaceTempView("final_wau_base_data")


# COMMAND ----------

# MAGIC %md
# MAGIC # HUMAN WEEKLY ACTIVE USERS

# COMMAND ----------

# DBTITLE 1,Human WAU
final_hwau_base_data_df = spark.sql('''
    SELECT 
        c.date,
        c.salesforce_account_id AS account_id,
        COUNT(DISTINCT CASE WHEN c.login_num_events_t7d > 0 THEN c.user_id END) AS hwau
    FROM main.data_product_features.user_metrics c
    LEFT JOIN
    main.metric_store.dim_user_login_user_type AS ut 
    ON c.user_id = ut.user_id

    WHERE c.salesforce_account_id NOT IN ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
      AND c.date >= '2024-02-01'
      AND ut.dim_login_user_type = 'USER'
    GROUP BY c.date, c.salesforce_account_id

''').createOrReplaceTempView("final_hwau_base_data")


# COMMAND ----------

# MAGIC %md
# MAGIC # ACCOUNT LEARNERS

# COMMAND ----------

# DBTITLE 1,Account Learners
spark.sql("""
-- 1. Daily first‑time learners per account
WITH learners_data AS (
    SELECT
        updated_account_id,
        updated_account_name,
        business_unit,
        sales_subregion_level_1,
        sales_subregion_level_2,
        sales_subregion_level_3,
        CAST(completed_date AS DATE) AS learner_date,
        COUNT(DISTINCT learner_user_id) AS daily_new_learners
    FROM main.field_learning_enablement.all_learners
    WHERE processdate = (
            SELECT MAX(processdate)
            FROM main.field_learning_enablement.all_learners
        )
      AND dataset  = 'net new learners'
      AND audience = 'Customer'
    GROUP BY ALL
),

-- 2. Calendar from 1‑Jun‑2019 through today
calendar AS (
    SELECT date
    FROM   main.it_core_dim.dim_dates
    WHERE  date BETWEEN DATE('2019-06-01') AND current_date()
),

-- 3. Unique list of accounts
accounts AS (
    SELECT DISTINCT
        updated_account_id,
        updated_account_name,
        business_unit,
        sales_subregion_level_1,
        sales_subregion_level_2,
        sales_subregion_level_3
    FROM learners_data
),

-- 4. All (date, account) pairs, zeros where no learners
calendar_per_account AS (
    SELECT
        c.date,
        a.updated_account_id,
        a.updated_account_name,
        a.business_unit,
        a.sales_subregion_level_1,
        a.sales_subregion_level_2,
        a.sales_subregion_level_3,
        COALESCE(l.daily_new_learners, 0) AS daily_new_learners
    FROM         accounts  a
    CROSS  JOIN  calendar  c
    LEFT   JOIN  learners_data l
           ON    l.updated_account_id = a.updated_account_id
           AND   l.learner_date       = c.date
)

-- 5. Running total
SELECT
    date,
    updated_account_id,
    updated_account_name,
    business_unit,
    sales_subregion_level_1,
    sales_subregion_level_2,
    sales_subregion_level_3,
    daily_new_learners,
    SUM(daily_new_learners) OVER (
        PARTITION BY updated_account_id
        ORDER BY date
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS cumulative_learners
FROM calendar_per_account
ORDER BY updated_account_id, date;

""").createOrReplaceTempView("accounts_learners")


# COMMAND ----------

# MAGIC %md
# MAGIC # TRAINED ACCOUNTS AND LEARNERS

# COMMAND ----------

# DBTITLE 1,learners + trained accounts new
spark.sql("""
-- 0) adjust the calendar window as tight as you need
WITH calendar AS (
  SELECT date
  FROM   main.it_core_dim.dim_dates
  WHERE  date BETWEEN DATE('2024-01-01') AND current_date()
),

-- 1) all (account_id , date) pairs we care about
scaffold AS (
  SELECT  DISTINCT ch.account_id
  FROM    main.gtm_data.core_accounts_curated_history ch
),
acct_dates AS (
  SELECT s.account_id , c.date
  FROM   scaffold s
  JOIN   calendar c
),

-- 2) lay the real tables on top (may return NULLs on gap-days)
raw AS (
  SELECT
    ad.account_id ,
    ad.date                                         AS snapshot_date ,
    ch.account_name ,
    ch.business_unit ,
    ch.sales_subregion_level_1 ,
    ch.sales_subregion_level_2,
    ch.sales_subregion_level_3,
    ch.account_segment ,
    ch.t3m_annualized ,
    al.cumulative_learners
  FROM  acct_dates                         ad
  LEFT  JOIN main.gtm_data.core_accounts_curated_history ch
         ON ad.account_id  = ch.account_id
        AND ad.date        = ch.snapshot_date
  LEFT  JOIN accounts_learners             al
         ON ad.account_id  = al.updated_account_id
        AND ad.date        = al.date
),

-- 3) forward-fill every column that might be NULL
filled AS (
  SELECT
    account_id                                         AS updated_account_id ,
    last(account_name            , TRUE)
        OVER w                                         AS updated_account_name ,
    last(business_unit           , TRUE) OVER w        AS business_unit ,
    last(sales_subregion_level_1 , TRUE) OVER w        AS sales_subregion_level_1 ,
    last(sales_subregion_level_2 , TRUE) OVER w        AS sales_subregion_level_2 ,
    last(sales_subregion_level_3 , TRUE) OVER w        AS sales_subregion_level_3 ,
    last(account_segment         , TRUE) OVER w        AS account_segment ,
    last(t3m_annualized          , TRUE) OVER w        AS t3m_annualized ,
    last(cumulative_learners     , TRUE) OVER w        AS cumulative_learners ,
    snapshot_date                                   -- keep the full daily spine
  FROM raw
  WINDOW w AS (
    PARTITION BY account_id
    ORDER BY      snapshot_date
    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
  )
),

-- 4) business rules stay exactly as you wrote them
final AS (
SELECT
  updated_account_id ,
  updated_account_name ,
  business_unit ,
  sales_subregion_level_1 ,
  sales_subregion_level_2,
  sales_subregion_level_3,
  snapshot_date                                          AS date ,

  CASE
    WHEN account_segment IN ('Geo','Emerging Enterprise','Emerging DNB','DNB Named')
         THEN 'Emerging'
    WHEN account_segment IN ('Strategic','DNB Strategic')
         THEN 'Strategic'
    WHEN account_segment IN ('Named','PubSec Fed','Pub Sec','PubSec SLED')
         THEN 'Named'
    ELSE 'Other'
  END                                                    AS account_segment_grouped ,

  t3m_annualized ,
  cumulative_learners ,

  CASE
    WHEN account_segment IN ('Strategic','DNB Strategic')                                       THEN 100
    WHEN account_segment IN ('Geo','Emerging Enterprise','Emerging DNB','DNB Named')            THEN 10
    WHEN account_segment IN ('Named','PubSec Fed','Pub Sec','PubSec SLED')                      THEN 30
  END                                                    AS threshold ,

  CASE
  WHEN t3m_annualized > 240000
       AND account_segment IN (   -- any segment that is *not* “Other”
         'Geo','Emerging Enterprise','Emerging DNB','DNB Named',
         'Strategic','DNB Strategic',
         'Named','PubSec Fed','Pub Sec','PubSec SLED'
       )
  THEN 1 ELSE 0
END AS over240k ,


  CASE
    WHEN t3m_annualized > 240000
         AND cumulative_learners >=
             CASE
               WHEN account_segment IN ('Strategic','DNB Strategic') THEN 100
               WHEN account_segment IN ('Geo','Emerging Enterprise','Emerging DNB','DNB Named') THEN 10
               WHEN account_segment IN ('Named','PubSec Fed','Pub Sec','PubSec SLED') THEN 30
             END
    THEN 1 ELSE 0
  END                                                    AS trained_flag
FROM filled
)

SELECT *
FROM   final
ORDER  BY date DESC, updated_account_id;

""").createOrReplaceTempView("learners_and_trained_accounts")


# COMMAND ----------

# DBTITLE 1,final result set
gtm_df = spark.sql("""
SELECT 
  COALESCE(l.date, w.date) AS date,
  COALESCE(l.updated_account_id, w.account_id) AS updated_account_id,
  l.updated_account_name,
  l.business_unit,
  l.sales_subregion_level_1,
  l.sales_subregion_level_2,
  l.sales_subregion_level_3,
  l.account_segment_grouped,
  l.t3m_annualized,
  l.cumulative_learners,
  l.threshold,
  l.trained_flag,
  l.over240k,
  w.wau,
  h.hwau
FROM learners_and_trained_accounts l
FULL OUTER JOIN final_wau_base_data w
  ON l.updated_account_id = w.account_id AND l.date = w.date
LEFT JOIN final_hwau_base_data h
  ON COALESCE(l.updated_account_id, w.account_id) = h.account_id 
  AND COALESCE(l.date, w.date) = h.date
""")


# COMMAND ----------

gtm_gold_df = add_gold_metadata(gtm_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = gtm_gold_df, 
  table_name = f'{focus_database_name}.gtm_account_engagement_by_period', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # MONTHLY DATA

# COMMAND ----------

# DBTITLE 1,Monthly Hwaus and Wau
# MAGIC %sql
# MAGIC create or replace temp view monthly_waus as
# MAGIC -- 1. Get list of active accounts
# MAGIC WITH accounts AS (
# MAGIC   SELECT DISTINCT updated_account_id,
# MAGIC   business_unit,
# MAGIC   sales_subregion_level_1,
# MAGIC   sales_subregion_level_2,
# MAGIC   sales_subregion_level_3
# MAGIC   FROM main.field_learning_enablement.gtm_account_engagement_by_period
# MAGIC   WHERE processDate = (
# MAGIC     SELECT MAX(processDate)
# MAGIC     FROM main.field_learning_enablement.gtm_account_engagement_by_period
# MAGIC   )
# MAGIC ),
# MAGIC
# MAGIC -- 2. Generate calendar of dates
# MAGIC calendar AS (
# MAGIC   SELECT date
# MAGIC   FROM main.it_core_dim.dim_dates
# MAGIC   WHERE date >= DATE('2024-01-01') 
# MAGIC ),
# MAGIC
# MAGIC -- 3. Build full matrix of (date, account)
# MAGIC calendar_per_account AS (
# MAGIC   SELECT
# MAGIC     c.date,
# MAGIC     a.updated_account_id,
# MAGIC     a.business_unit,
# MAGIC     a.sales_subregion_level_1,
# MAGIC     a.sales_subregion_level_2,
# MAGIC     a.sales_subregion_level_3
# MAGIC   FROM accounts a
# MAGIC   CROSS JOIN calendar c
# MAGIC ),
# MAGIC
# MAGIC -- 4. Actual WAU/HWAU per (date, account)
# MAGIC wau_data AS (
# MAGIC   SELECT
# MAGIC     date,
# MAGIC     updated_account_id,
# MAGIC     business_unit,
# MAGIC     sales_subregion_level_1,
# MAGIC     sales_subregion_level_2,
# MAGIC     sales_subregion_level_3,
# MAGIC     SUM(wau) AS wau,
# MAGIC     SUM(hwau) AS hwau
# MAGIC   FROM main.field_learning_enablement.gtm_account_engagement_by_period
# MAGIC   WHERE processDate = (
# MAGIC     SELECT MAX(processDate)
# MAGIC     FROM main.field_learning_enablement.gtm_account_engagement_by_period
# MAGIC   )
# MAGIC   GROUP BY ALL
# MAGIC ),
# MAGIC
# MAGIC -- 5. Left join actual data into calendar matrix; fill missing with 0
# MAGIC daily_filled AS (
# MAGIC   SELECT
# MAGIC     cal.date,
# MAGIC     cal.updated_account_id,
# MAGIC     COALESCE(w.wau, 0) AS wau,
# MAGIC     COALESCE(w.hwau, 0) AS hwau
# MAGIC   FROM calendar_per_account cal
# MAGIC   LEFT JOIN wau_data w
# MAGIC     ON cal.date = w.date AND cal.updated_account_id = w.updated_account_id
# MAGIC ),
# MAGIC
# MAGIC dim_data as (
# MAGIC   SELECT
# MAGIC     snapshot_date,
# MAGIC     account_id as updated_account_id,
# MAGIC     sales_business_unit,
# MAGIC     sales_subregion_level_1,
# MAGIC     sales_subregion_level_2,
# MAGIC     sales_subregion_level_3
# MAGIC     from main.gtm_data.core_accounts_curated
# MAGIC ),
# MAGIC
# MAGIC -- 6. Calculate average WAU/HWAU per account per month
# MAGIC monthly_account_avg AS (
# MAGIC   SELECT
# MAGIC     DATE_TRUNC('month', df.date) AS month,
# MAGIC     df.updated_account_id,
# MAGIC     dd.sales_business_unit,
# MAGIC     dd.sales_subregion_level_1,
# MAGIC     dd.sales_subregion_level_2,
# MAGIC     dd.sales_subregion_level_3,
# MAGIC     CASE 
# MAGIC       WHEN DATE_TRUNC('month', df.date) = DATE_TRUNC('month', CURRENT_DATE())
# MAGIC       THEN ROUND(SUM(df.wau) / COUNT(df.date), 2)
# MAGIC       ELSE ROUND(AVG(df.wau), 2)
# MAGIC     END AS wau,
# MAGIC     CASE 
# MAGIC       WHEN DATE_TRUNC('month', df.date) = DATE_TRUNC('month', CURRENT_DATE())
# MAGIC       THEN ROUND(SUM(df.hwau) / COUNT(df.date), 2)
# MAGIC       ELSE ROUND(AVG(df.hwau), 2)
# MAGIC     END AS hwau
# MAGIC   FROM daily_filled df
# MAGIC   LEFT JOIN dim_data dd
# MAGIC     ON df.updated_account_id = dd.updated_account_id
# MAGIC   WHERE df.date <= CURRENT_DATE()-3
# MAGIC   GROUP BY ALL
# MAGIC )
# MAGIC
# MAGIC select * from monthly_account_avg
# MAGIC
# MAGIC

# COMMAND ----------

# DBTITLE 1,Trained Accounts
# MAGIC %sql
# MAGIC create or replace temp view monthly_trained_accounts as
# MAGIC WITH trained_accts AS (
# MAGIC   SELECT
# MAGIC     period,
# MAGIC     account_id,
# MAGIC     trained_flag
# MAGIC   FROM main.field_learning_enablement.okr_trained_accounts_base
# MAGIC   WHERE processDate = (
# MAGIC     SELECT MAX(processDate)
# MAGIC     FROM main.field_learning_enablement.okr_trained_accounts_base
# MAGIC   )
# MAGIC )
# MAGIC select * from trained_accts

# COMMAND ----------

# DBTITLE 1,learners
# MAGIC %sql
# MAGIC create or replace temp view monthly_learners as
# MAGIC /* ──────────────────────────────────────────────────────────────
# MAGIC    0. Parameters – easy to change later
# MAGIC    ────────────────────────────────────────────────────────────── */
# MAGIC WITH params AS (SELECT DATE('2024-01-01') AS calendar_start)
# MAGIC
# MAGIC /* 1. Daily calendar from start-date to today */
# MAGIC , calendar AS (
# MAGIC   SELECT d.date
# MAGIC   FROM   main.it_core_dim.dim_dates d
# MAGIC   CROSS  JOIN params p
# MAGIC   WHERE  d.date BETWEEN p.calendar_start AND current_date()
# MAGIC )
# MAGIC
# MAGIC /* 2. All Customer accounts that have EVER had learners */
# MAGIC , accounts AS (
# MAGIC   SELECT DISTINCT updated_account_id,
# MAGIC   updated_account_name
# MAGIC   FROM   field_learning_enablement.all_learners
# MAGIC   WHERE  processDate = (SELECT MAX(processDate)
# MAGIC                         FROM field_learning_enablement.all_learners)
# MAGIC     AND  dataset  = 'net new learners'
# MAGIC     AND  audience = 'Customer'
# MAGIC )
# MAGIC
# MAGIC /* 3. Opening balance – learners BEFORE the calendar start */
# MAGIC , opening_balance AS (
# MAGIC   SELECT
# MAGIC     updated_account_id,
# MAGIC     COUNT(DISTINCT learner_user_id) AS base_learners
# MAGIC   FROM   field_learning_enablement.all_learners l
# MAGIC          JOIN params p
# MAGIC            ON l.completed_date < p.calendar_start
# MAGIC   WHERE  processDate = (SELECT MAX(processDate)
# MAGIC                         FROM field_learning_enablement.all_learners)
# MAGIC     AND  dataset  = 'net new learners'
# MAGIC     AND  audience = 'Customer'
# MAGIC   GROUP BY updated_account_id
# MAGIC )
# MAGIC
# MAGIC /* 4. Full (date × account) matrix */
# MAGIC , calendar_per_account AS (
# MAGIC   SELECT c.date , a.updated_account_id, a.updated_account_name
# MAGIC   FROM   calendar c
# MAGIC   CROSS  JOIN accounts a
# MAGIC )
# MAGIC
# MAGIC /* 5. Net-new learners per day (on / after calendar_start) */
# MAGIC , daily AS (
# MAGIC   SELECT
# MAGIC     completed_date AS date,
# MAGIC     updated_account_id,
# MAGIC     COUNT(DISTINCT learner_user_id) AS learners
# MAGIC   FROM   field_learning_enablement.all_learners l
# MAGIC          JOIN params p
# MAGIC            ON l.completed_date >= p.calendar_start
# MAGIC   WHERE  processDate = (SELECT MAX(processDate)
# MAGIC                         FROM field_learning_enablement.all_learners)
# MAGIC     AND  dataset  = 'net new learners'
# MAGIC     AND  audience = 'Customer'
# MAGIC   GROUP BY date, updated_account_id
# MAGIC )
# MAGIC
# MAGIC /* 6. Merge onto calendar, fill gaps with 0 */
# MAGIC , scaffolded AS (
# MAGIC   SELECT
# MAGIC     cpa.date,
# MAGIC     cpa.updated_account_id,
# MAGIC     cpa.updated_account_name,
# MAGIC     COALESCE(d.learners, 0) AS learners
# MAGIC   FROM  calendar_per_account cpa
# MAGIC   LEFT  JOIN daily d
# MAGIC     ON  d.date = cpa.date
# MAGIC    AND  d.updated_account_id = cpa.updated_account_id
# MAGIC )
# MAGIC
# MAGIC /* 7. Cumulative learners per account (including opening balance) */
# MAGIC , cumulative AS (
# MAGIC   SELECT
# MAGIC     s.date,
# MAGIC     s.updated_account_id,
# MAGIC     s.updated_account_name,
# MAGIC     s.learners,
# MAGIC     COALESCE(ob.base_learners, 0) AS base_learners,
# MAGIC     COALESCE(ob.base_learners, 0) +
# MAGIC       SUM(s.learners) OVER (
# MAGIC         PARTITION BY s.updated_account_id
# MAGIC         ORDER BY     s.date
# MAGIC         ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
# MAGIC       ) AS cumulative_learners
# MAGIC   FROM scaffolded s
# MAGIC   LEFT JOIN opening_balance ob
# MAGIC     ON  ob.updated_account_id = s.updated_account_id
# MAGIC )
# MAGIC
# MAGIC /* 8. Month-end roll-up  ► one row per account per month */
# MAGIC , monthly_account AS (
# MAGIC   SELECT
# MAGIC     LAST_DAY(date)                      AS month_end,
# MAGIC     updated_account_id,
# MAGIC     updated_account_name,
# MAGIC     MAX(cumulative_learners)            AS cumulative_learners,
# MAGIC     SUM(learners)                       AS new_learners
# MAGIC   FROM cumulative
# MAGIC   GROUP BY month_end, updated_account_id, updated_account_name
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC DATE_TRUNC('month', month_end) AS month,
# MAGIC updated_account_id,
# MAGIC updated_account_name,
# MAGIC cumulative_learners,
# MAGIC new_learners
# MAGIC FROM monthly_account
# MAGIC

# COMMAND ----------

# DBTITLE 1,final output for monthly data
monthly_data_df = spark.sql('''
                            with pre as (
SELECT
  mw.*,
  COALESCE(ta.trained_flag, 0) AS trained_flag,
  CASE WHEN ta.account_id IS NOT NULL THEN 1 ELSE 0 END AS account_over_240k
FROM monthly_waus mw
LEFT JOIN monthly_trained_accounts ta
  ON mw.updated_account_id = ta.account_id
  AND mw.month = ta.period
)

select 
p.*,
l.updated_account_name,
sum(l.cumulative_learners) as cumulative_learners,
sum(l.new_learners) as new_learners
from pre p
left join monthly_learners l
on p.updated_account_id = l.updated_account_id
and p.month = l.month
group by all
                            ''')

# COMMAND ----------

gtm_gold_monthly_df = add_gold_metadata(monthly_data_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = gtm_gold_monthly_df, 
  table_name = f'{focus_database_name}.gtm_account_engagement_by_month', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # QUARTERLY DATA

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW quarterly_data AS
# MAGIC
# MAGIC WITH monthly_data AS (
# MAGIC     SELECT 
# MAGIC         updated_account_id, 
# MAGIC         updated_account_name,
# MAGIC         month, 
# MAGIC         sales_business_unit, 
# MAGIC         sales_subregion_level_1, 
# MAGIC         sales_subregion_level_2,
# MAGIC         sales_subregion_level_3,
# MAGIC         wau, 
# MAGIC         hwau, 
# MAGIC         cumulative_learners, 
# MAGIC         new_learners, 
# MAGIC         trained_flag, 
# MAGIC         account_over_240k, 
# MAGIC         processDate,
# MAGIC         YEAR(month) AS year,
# MAGIC         CASE
# MAGIC             WHEN MONTH(month) IN (2, 3, 4) THEN 'Q1'
# MAGIC             WHEN MONTH(month) IN (5, 6, 7) THEN 'Q2'
# MAGIC             WHEN MONTH(month) IN (8, 9, 10) THEN 'Q3'
# MAGIC             WHEN MONTH(month) IN (11, 12) THEN 'Q4'
# MAGIC             WHEN MONTH(month) = 1 THEN 'Q4'  -- Jan is part of Q4 of previous year
# MAGIC         END AS custom_quarter,
# MAGIC         CASE
# MAGIC             WHEN MONTH(month) = 1 THEN YEAR(month) - 1  -- assign Jan to previous year
# MAGIC             ELSE YEAR(month)
# MAGIC         END AS quarter_year
# MAGIC     FROM main.field_learning_enablement.gtm_account_engagement_by_month
# MAGIC     WHERE processDate = (
# MAGIC         SELECT MAX(processDate)
# MAGIC         FROM main.field_learning_enablement.gtm_account_engagement_by_month
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC latest_quarter_months AS (
# MAGIC     SELECT 
# MAGIC         custom_quarter,
# MAGIC         quarter_year,
# MAGIC         MAX(month) AS latest_month
# MAGIC     FROM monthly_data
# MAGIC     GROUP BY custom_quarter, quarter_year
# MAGIC ),
# MAGIC
# MAGIC accounts AS (
# MAGIC     SELECT DISTINCT 
# MAGIC         md.updated_account_id AS updated_account_id, 
# MAGIC         md.updated_account_name AS updated_account_name,
# MAGIC         md.month AS month, 
# MAGIC         md.sales_business_unit AS sales_business_unit, 
# MAGIC         md.sales_subregion_level_1 AS sales_subregion_level_1, 
# MAGIC         md.sales_subregion_level_2 AS sales_subregion_level_2,
# MAGIC         md.sales_subregion_level_3 AS sales_subregion_level_3,
# MAGIC         md.wau AS wau, 
# MAGIC         md.hwau AS hwau, 
# MAGIC         md.cumulative_learners AS cumulative_learners, 
# MAGIC         md.new_learners AS new_learners, 
# MAGIC         md.trained_flag AS trained_flag, 
# MAGIC         md.account_over_240k AS account_over_240k,
# MAGIC         md.custom_quarter AS quarter,
# MAGIC         md.quarter_year AS year
# MAGIC     FROM monthly_data md
# MAGIC     INNER JOIN latest_quarter_months lqm 
# MAGIC         ON md.custom_quarter = lqm.custom_quarter 
# MAGIC         AND md.quarter_year = lqm.quarter_year
# MAGIC         AND md.month = lqm.latest_month
# MAGIC )
# MAGIC
# MAGIC select gtm.*, 
# MAGIC d.fiscal_year_quarter 
# MAGIC from accounts gtm
# MAGIC inner join main.it_core_dim.dim_dates d on gtm.month = d.date
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW commits_data AS
# MAGIC
# MAGIC WITH Opp_Bookings AS (
# MAGIC
# MAGIC   SELECT
# MAGIC     account_name,
# MAGIC     account_id,
# MAGIC     opportunity_name,
# MAGIC     opportunity_id,
# MAGIC     close_date,
# MAGIC     opportunity_close_fiscal_year_quarter,
# MAGIC     business_unit,
# MAGIC     opportunity_role_region,
# MAGIC     account_executive,
# MAGIC     opportunity_region_level_1,
# MAGIC     opportunity_region_level_2,
# MAGIC     professional_services_owner,
# MAGIC     t3m_annualized_band,
# MAGIC     opportunity_type,
# MAGIC     opportunity_stage,
# MAGIC     forecast_category,
# MAGIC     product_name,
# MAGIC
# MAGIC     /* ================== Amounts ================== */
# MAGIC     SUM(CASE WHEN product_family_derived IN ('License','Support')
# MAGIC              THEN total_price ELSE 0 END)                                   AS product_total_amount,
# MAGIC
# MAGIC     SUM(CASE WHEN product_family_derived IN ('Professional Services',
# MAGIC                                              'CS Subscription',
# MAGIC                                              'Training')
# MAGIC              THEN total_price ELSE 0 END)                                   AS services_total_amount,
# MAGIC
# MAGIC     /* ========= Incremental Bookings (by family) ========= */
# MAGIC     SUM(CASE WHEN product_family_derived IN ('License','Support')
# MAGIC              THEN incremental_booking_total_forecast ELSE 0 END)            AS product_bookings,
# MAGIC
# MAGIC     SUM(CASE WHEN product_family_derived IN ('Professional Services',
# MAGIC                                              'Training',
# MAGIC                                              'CS Subscription')
# MAGIC              THEN incremental_booking_total_forecast ELSE 0 END)            AS services_bookings,
# MAGIC
# MAGIC     SUM(CASE WHEN product_family_derived =  'Professional Services'
# MAGIC              THEN incremental_booking_total_forecast ELSE 0 END)            AS ps_bookings,
# MAGIC
# MAGIC     SUM(CASE WHEN product_family_derived =  'Training'
# MAGIC              THEN incremental_booking_total_forecast ELSE 0 END)            AS tr_bookings,
# MAGIC
# MAGIC     SUM(CASE WHEN product_family_derived =  'CS Subscription'
# MAGIC              THEN incremental_booking_total_forecast ELSE 0 END)            AS dsa_bookings,
# MAGIC
# MAGIC     /* ========= Segmentation on incremental product bookings ========= */
# MAGIC     CASE
# MAGIC       WHEN SUM(CASE WHEN product_family_derived IN ('License','Support')
# MAGIC                     THEN incremental_booking_total_forecast ELSE 0 END) <  500000 THEN '0-500K'
# MAGIC       WHEN SUM(CASE WHEN product_family_derived IN ('License','Support')
# MAGIC                     THEN incremental_booking_total_forecast ELSE 0 END) < 3000000 THEN '500K-3M'
# MAGIC       WHEN SUM(CASE WHEN product_family_derived IN ('License','Support')
# MAGIC                     THEN incremental_booking_total_forecast ELSE 0 END) >= 3000000 THEN '>3M'
# MAGIC       ELSE 'ERROR'
# MAGIC     END                                                                     AS segmentation,
# MAGIC
# MAGIC     /* ========= Attach-calculation inclusion flag ========= */
# MAGIC     CASE
# MAGIC       WHEN close_date < current_dates.current_fiscal_quarter_start_date
# MAGIC            AND opportunity_stage NOT IN ('Closed Won') THEN FALSE
# MAGIC       ELSE TRUE
# MAGIC     END                                                                     AS include_oppty_in_attach_calc_ind,
# MAGIC
# MAGIC     /* ========= Quarter-boundary helpers ========= */
# MAGIC     current_fiscal_quarter_end_date,
# MAGIC     last_year_fiscal_quarter_start_date,
# MAGIC     next_year_fiscal_quarter_start_date
# MAGIC
# MAGIC   FROM main.gtm_data.core_opportunity_product p
# MAGIC
# MAGIC   /* ---- helper rows for current / LY / NY fiscal-quarter dates ---- */
# MAGIC   CROSS JOIN (
# MAGIC         SELECT date                              AS current_date,
# MAGIC                fiscal_quarter_start_date         AS current_fiscal_quarter_start_date,
# MAGIC                fiscal_quarter_end_date           AS current_fiscal_quarter_end_date
# MAGIC         FROM   main.it_core_dim.dim_dates
# MAGIC         WHERE  date = current_date()
# MAGIC   ) current_dates
# MAGIC   CROSS JOIN (
# MAGIC         SELECT date                              AS last_fy_date,
# MAGIC                fiscal_quarter_start_date         AS last_year_fiscal_quarter_start_date,
# MAGIC                fiscal_quarter_end_date           AS last_year_fiscal_quarter_end_date
# MAGIC         FROM   main.it_core_dim.dim_dates
# MAGIC         WHERE  date = add_months(current_date(),-12)
# MAGIC   ) last_year_dates
# MAGIC   CROSS JOIN (
# MAGIC         SELECT date                              AS next_fy_date,
# MAGIC                fiscal_quarter_start_date         AS next_year_fiscal_quarter_start_date,
# MAGIC                fiscal_quarter_end_date           AS next_year_fiscal_quarter_end_date
# MAGIC         FROM   main.it_core_dim.dim_dates
# MAGIC         WHERE  date = add_months(current_date(),12)
# MAGIC   ) next_year_dates
# MAGIC
# MAGIC   /* ---- filters identical to your original query ---- */
# MAGIC   WHERE snapshot_date = (SELECT MAX(snapshot_date)
# MAGIC                          FROM main.gtm_data.core_opportunity_product)
# MAGIC     AND product_family IN ('License','Support','Professional Services',
# MAGIC                            'Training','Services Subscriptions')
# MAGIC     AND opportunity_stage NOT IN ('Closed Lost','Disqualified')
# MAGIC     AND close_date >= '2023-02-01'
# MAGIC     AND close_date <= add_months(current_fiscal_quarter_end_date,12)
# MAGIC     AND product_name NOT IN ('Burst')
# MAGIC     AND opportunity_name NOT LIKE '%P3 Only (System Created Opportunity)%'
# MAGIC     AND incremental_booking_total_forecast IS NOT NULL
# MAGIC   GROUP BY ALL
# MAGIC ),
# MAGIC
# MAGIC /* ========== account-level service presence, by quarter ========== */
# MAGIC account_qtr_bookings AS (
# MAGIC   SELECT
# MAGIC     account_id,
# MAGIC     opportunity_close_fiscal_year_quarter,
# MAGIC     SUM(ps_bookings)  AS ps_bookings,
# MAGIC     SUM(tr_bookings)  AS tr_bookings,
# MAGIC     SUM(dsa_bookings) AS dsa_bookings
# MAGIC   FROM Opp_Bookings
# MAGIC   WHERE include_oppty_in_attach_calc_ind = TRUE
# MAGIC   GROUP BY ALL
# MAGIC ),
# MAGIC
# MAGIC Account_Bookings_2 AS (
# MAGIC   SELECT
# MAGIC     account_id,
# MAGIC     opportunity_close_fiscal_year_quarter,
# MAGIC     /* boolean flags per service family */
# MAGIC     ps_bookings  > 0                        AS account_has_ps_in_qtr_ind,
# MAGIC     tr_bookings  > 0                        AS account_has_tr_in_qtr_ind,
# MAGIC     dsa_bookings > 0                        AS account_has_dsa_in_qtr_ind,
# MAGIC     /* helpers */
# MAGIC     (ps_bookings  > 0 OR tr_bookings > 0 OR dsa_bookings > 0)
# MAGIC                                             AS account_has_services_in_qtr_ind,
# MAGIC     (ps_bookings  > 0 AND tr_bookings > 0 AND dsa_bookings > 0)
# MAGIC                                             AS account_has_coe_in_qtr_ind
# MAGIC   FROM account_qtr_bookings
# MAGIC ),
# MAGIC
# MAGIC /* ========== attach-calculation fact table ========== */
# MAGIC Final_CTE AS (
# MAGIC   SELECT
# MAGIC     ob.*,
# MAGIC     a.account_has_tr_in_qtr_ind
# MAGIC   FROM Opp_Bookings ob
# MAGIC   LEFT JOIN Account_Bookings_2 a
# MAGIC     ON  ob.account_id = a.account_id
# MAGIC     AND ob.opportunity_close_fiscal_year_quarter = a.opportunity_close_fiscal_year_quarter
# MAGIC   WHERE ob.include_oppty_in_attach_calc_ind = TRUE
# MAGIC )
# MAGIC
# MAGIC /* ========== FINAL RESULT ========== */
# MAGIC SELECT DISTINCT
# MAGIC   account_name,
# MAGIC   account_id,
# MAGIC   close_date,
# MAGIC   opportunity_close_fiscal_year_quarter,
# MAGIC   business_unit,
# MAGIC   opportunity_region_level_1,
# MAGIC   t3m_annualized_band,
# MAGIC   forecast_category,
# MAGIC   opportunity_type,
# MAGIC   account_has_tr_in_qtr_ind
# MAGIC FROM Final_CTE
# MAGIC WHERE close_date >= last_year_fiscal_quarter_start_date
# MAGIC   AND close_date <  next_year_fiscal_quarter_start_date;
# MAGIC

# COMMAND ----------

quarterly_data_df = spark.sql('''
SELECT 
  q.*, 
  CASE 
    WHEN c.account_has_tr_in_qtr_ind IS TRUE THEN 1 
    ELSE 0 
  END AS account_has_tr_in_qtr_ind
FROM quarterly_data q 
LEFT JOIN commits_data c 
  ON q.fiscal_year_quarter = c.opportunity_close_fiscal_year_quarter
  and q.updated_account_id = c.account_id
''')

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Gold Enhancement

# COMMAND ----------

gtm_gold_quarterly_df = add_gold_metadata(quarterly_data_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = gtm_gold_quarterly_df, 
  table_name = f'{focus_database_name}.gtm_account_engagement_by_quarter', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)