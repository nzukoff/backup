# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Lekshmi S \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

#spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from pyspark.sql.types import DoubleType
#from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
# from focus_databricks.common.date_utils import *
# from focus_databricks.koda.table_utils import *
# from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

import time
from delta.tables import *
from datetime import date, datetime
import logging

logging.basicConfig(format="%(asctime)-15s %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def write_delta_table(
    spark,
    dataframe,
    table_name,
    format="delta",
    mode="overwrite",
    overwrite_schema="true",
    merge_schema="true",
    optimize=True,
    partition_column=None,
    zorder=None,
    replace_where=None,
    location=None,
):

    num_rows = dataframe.count()
    logger_statement = """Written the dataframe. Please look at the stats:
                          Details:
                          - Table Name: {0} 
                          - Total time spent: {1} minutes
                          - Write Options:
                            - format: {2}
                            - mode: {3}
                            - optimize: {4}
                            - zorder: {5}
                            - partition by: {6}
                            - replace where: {7}
                            - location: {8}
                            - Schema Options:
                                - overwrite schema: {9}
                                - merge schema: {10}
                          - Written rows:  {11}
                       """
    logger.info("Writting the table {0}".format(table_name))
    start_time = time.time()
    write_instructions = (
        dataframe.write.format(format)
        .mode(mode)
        .option("overwriteSchema", overwrite_schema)
        .option("mergeSchema", merge_schema)
    )

    if partition_column is not None:
        write_instructions = write_instructions.partitionBy(partition_column)

    if replace_where is not None:
        write_instructions = write_instructions.option("replaceWhere", replace_where)

    write_instructions.saveAsTable(table_name)
    write_time = time.time()

    if optimize:
        logger.info("Running optimize the delta table now")
        start = time.time()
        optimize_instructions = "OPTIMIZE " + table_name
        if replace_where is not None:
            logger.info("Replacing the delta table according to where clause now")
            optimize_instructions += " WHERE " + replace_where
            if zorder:
                optimize_instructions += " ZORDER BY " + zorder
                spark.sql(optimize_instructions)
        logger.info(
            "Optimized in {} minutes.".format(
                str(round((time.time() - write_time) / 60, 1))
            )
        )

    logger.info(
        logger_statement.format(
            table_name,
            round((write_time - start_time) / 60, 1),
            format,
            mode,
            optimize,
            zorder,
            partition_column,
            replace_where,
            location,
            overwrite_schema,
            merge_schema,
            num_rows,
        )
    )



# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

goals_table="main.field_learning_enablement.okr_metrics_goals"
goals_trained_acc_table="main.field_learning_enablement.okr_trained_acc_goals"
print(focus_database_name,partition_date)

# COMMAND ----------

# utility methods

from pyspark.sql import DataFrame
from typing import Optional
from datetime import date,datetime
def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md # Learners

# COMMAND ----------

# DBTITLE 1,Learner Data Aggregation Script
learners_df = spark.sql(f'''with learners_data as 
(
  select
    "Total Unique Learners" as metric,
    fiscalYear,
    fq2,
    case
      when audience in (
        "Partner",
        "Partner Other",
        "Microsoft",
        "Microsoft Other"
      ) then "Partner"
      else audience
    end as audience,
    updated_account_id,
    region_derived,
    country_derived,
    business_unit,
    sales_subregion_level_1,
    count (distinct learner_user_id) as learners
  from main.field_learning_enablement.all_learners
  where dataset = "net new learners"
  and processDate =(select max(processDate) from main.field_learning_enablement.all_learners)
  group by all
)
,customer_learners_actuals as 
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,business_unit
    ,sales_subregion_level_1
    ,sum (learners) as learners
  from learners_data 
  where audience='Customer'
  group by all 
)
,partner_wo_india_learners_actuals as 
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,nvl(region_derived, "Unknown") business_unit
    ,nvl(region_derived, "Unknown") sales_subregion_level_1
    ,sum (learners) as learners
  from learners_data 
  where audience='Partner' and upper(NVL(country_derived,''))<>'INDIA'
  group by all 
)
,partner_india_learners_actuals as 
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,'India' business_unit
    ,'India' sales_subregion_level_1
    ,sum (learners) as learners
  from learners_data 
  where audience='Partner' and upper(NVL(country_derived,''))='INDIA'
  group by all 
)

,others_learners_actuals as 
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,business_unit
    ,sales_subregion_level_1
    ,sum (learners) as learners
  from learners_data 
  where audience not in ('Customer','Partner')
  group by all
)

,learners_actuals as (
  select * from customer_learners_actuals
  union all
  select * from partner_wo_india_learners_actuals
  union all
  select * from partner_india_learners_actuals
  union all
  select * from others_learners_actuals
)

,learners_goals(
  select * 
  from {goals_table} 
  where metric='Total Unique Learners' 
)

,cumulative_learners as
(
  SELECT
    nvl(A.metric, G.metric) as metric
    ,nvl(A.fiscalYear, G.fiscalYear) as fiscalYear
    ,nvl(A.FQ2, G.FQ2) as timeframe
    ,nvl(A.audience, G.audience) as audience
    ,nvl(A.business_unit, G.bu) as business_unit
    ,nvl(A.sales_subregion_level_1, G.bu_1) as sales_subregion_level_1
    ,sum(A.learners) over (partition by A.metric,A.audience,A.business_unit,A.sales_subregion_level_1 order by A.fq2) as cumulative_learners
    ,learners
    ,nvl(G.goal, 0) as target 
  FROM learners_actuals A
  FULL OUTER JOIN learners_goals G
  on A.metric=G.metric
  and A.audience=G.audience
  and A.business_unit=G.bu
  and A.sales_subregion_level_1=G.bu_1
  and A.fq2=G.FQ2
  and A.fiscalYear=G.fiscalYear
)


select
  c.metric
  ,c.timeframe
  ,c.fiscalYear
  ,c.audience
  ,c.business_unit
  ,c.sales_subregion_level_1
  ,c.learners
  ,case 
  when ( 
    c.cumulative_learners is null and c.timeframe >=
    (select fiscal_year_quarter from main.it_core_dim.dim_dates where date = current_date :: date)
    )
  then last_value (c.cumulative_learners, true) over (partition by c.metric,c.audience,c.business_unit,c.sales_subregion_level_1
      order by timeframe ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
  else c.cumulative_learners
  end as cumulative_learners
  ,c.target
  from cumulative_learners c 

''')

# COMMAND ----------

learners_df.createOrReplaceTempView('learners')

# COMMAND ----------

# MAGIC %md # Active Certifications

# COMMAND ----------

# DBTITLE 1,Quarterly Certification Data Aggregator
certs_df = spark.sql(f'''
with qtr_end_dates AS 
(
  select distinct qtr_end_date, fq2, processDate from main.field_learning_enablement.certifications_and_badges where processdate=(Select max(processdate) from main.field_learning_enablement.certifications_and_badges)
  and fq2>="FY'24 Q2"
) 

,processdates AS 
(
  select 
    case when qtr_end_date<=current_date::date then qtr_end_date 
         else processDate
    end as processdates
  from qtr_end_dates 
)

,cert_data as 
(
  select
    "Active Certifications" as metric,
    fiscalYear,
    processDate,
    case
      when audience in (
        "Partner",
        "Partner Other",
        "Microsoft",
        "Microsoft Other"
      ) then "Partner"
      else audience
    end as audience,
    updated_account_id,
    region_derived,
    business_unit,
    sales_subregion_level_1,
    country_derived,
    count (learner_email_hash) as certs
  from main.field_learning_enablement.certifications_and_badges
  where credential_type = "Certification"
    and is_expired = "false"
    and processDate in (select processdates from processdates)
  group by all
)

,customer_cert_actuals as 
(
  select 
    processDate
    ,metric
    ,p.fiscal_year as fiscalYear
    ,p.fiscal_year_quarter as timeframe
    ,audience
    ,business_unit
    ,sales_subregion_level_1
    ,sum(certs) as total_certs
  from cert_data c
  inner join main.it_core_dim.dim_dates p on c.processdate = p.date
  where audience='Customer'
  group by all 
)  
,partner_wo_india_cert_actuals as 
(
  select 
    processDate
    ,metric
    ,p.fiscal_year as fiscalYear
    ,p.fiscal_year_quarter as timeframe
    ,audience
    ,nvl(region_derived, "Unknown") business_unit
    ,nvl(region_derived, "Unknown") sales_subregion_level_1
    ,sum(certs) as total_certs
  from cert_data c
  inner join main.it_core_dim.dim_dates p on c.processdate = p.date
  where audience='Partner' and upper(NVL(country_derived,''))<>'INDIA'
  group by all 
) 
,partner_india_cert_actuals as 
(
  select 
    processDate
    ,metric
    ,p.fiscal_year as fiscalYear
    ,p.fiscal_year_quarter as timeframe
    ,audience
    ,'India' business_unit
    ,'India' sales_subregion_level_1
    ,sum(certs) as total_certs
  from cert_data c
  inner join main.it_core_dim.dim_dates p on c.processdate = p.date
  where audience='Partner' and upper(NVL(country_derived,''))='INDIA'
  group by all 
)
,others_cert_actuals as
(
  select 
    processDate
    ,metric
    ,p.fiscal_year as fiscalYear
    ,p.fiscal_year_quarter as timeframe
    ,audience
    ,'Unknown' as business_unit
    ,'Unknown' as sales_subregion_level_1
    ,sum(certs) as total_certs
  from cert_data c
  inner join main.it_core_dim.dim_dates p on c.processdate = p.date
  where audience not in ('Customer','Partner')
  group by all  
)
,cert_actuals
(
  select * from customer_cert_actuals
  union all
  select * from partner_wo_india_cert_actuals
  union all
  select * from partner_india_cert_actuals
  union all 
  select * from others_cert_actuals
)
,cert_goals as 
(
  select * 
  from {goals_table} 
  where metric='Active Certifications'
)
select 
  nvl(A.metric, G.metric) as metric
  ,nvl(A.fiscalYear, G.fiscalYear) as fiscalYear
  ,nvl(A.timeframe, G.FQ2) as timeframe
  ,nvl(A.audience, G.audience) as audience
  ,nvl(A.business_unit, G.bu) as business_unit
  ,nvl(A.sales_subregion_level_1, G.bu_1) as sales_subregion_level_1
  ,nvl(A.total_certs, 0) as total_certs
  ,nvl(G.goal, 0) as target 
from cert_actuals A
full outer join cert_goals G
  on A.metric=G.metric
  and A.audience=G.audience
  and A.business_unit=G.bu
  and A.sales_subregion_level_1=G.bu_1
  and A.timeframe=G.FQ2
''')

# COMMAND ----------

# MAGIC %md
# MAGIC # Delivery Specializations

# COMMAND ----------

delivery_specialization_df = spark.sql(f'''
with delivery_specialization_data as 
(
  select
    "Delivery Specializations" as metric,
    fiscalYear,
    fq2,
    case when audience in (
      "Partner",
      "Partner Other",
      "Microsoft",
      "Microsoft Other"
    ) 
    then "Partner"
    else audience
    end as audience,
    updated_account_id,
    region_derived,
    business_unit,
    sales_subregion_level_1,
    country_derived,
    count (learner_email_hash) as badges
  from main.field_learning_enablement.certifications_and_badges
  where group_id in ('628550','655781','655788')
    --and is_expired = "false" --leks JIRA : ESO-229
    and processDate = (select max(processDate) from main.field_learning_enablement.certifications_and_badges)
  group by all
)
,customer_delivery_specialization_actuals as 
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,business_unit
    ,sales_subregion_level_1
    ,sum (badges) as total_delivery_specialization
  from delivery_specialization_data 
  where audience='Customer'
  group by all 
)
,partner_wo_india_delivery_specialization_actuals as 
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,nvl(region_derived, "Unknown") business_unit
    ,nvl(region_derived, "Unknown") sales_subregion_level_1
    ,sum (badges) as total_delivery_specialization
  from delivery_specialization_data 
  where audience='Partner' and upper(NVL(country_derived,''))<>'INDIA'
  group by all 
)

,partner_india_delivery_specialization_actuals as
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,'India' business_unit
    ,'India' sales_subregion_level_1
    ,sum (badges) as total_delivery_specialization
  from delivery_specialization_data 
  where audience='Partner' and upper(NVL(country_derived,''))='INDIA'
  group by all 
)
,others_delivery_specialization_actuals as
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,'Unknown' as business_unit
    ,'Unknown' as sales_subregion_level_1
    ,sum (badges) as total_delivery_specialization
  from delivery_specialization_data 
  where audience not in ('Customer','Partner')
  group by all  
)
,delivery_specialization_actuals as 
(
  select * from customer_delivery_specialization_actuals
  union all
  select * from partner_wo_india_delivery_specialization_actuals
  union all
  select * from partner_india_delivery_specialization_actuals
  union all
  select * from others_delivery_specialization_actuals
)       
,delivery_specialization_goals as
(
  select * 
  from {goals_table} 
  where metric='Delivery Specializations' 
)
,cumulative_delivery_specialization as
(
  select 
    nvl(A.metric, G.metric) as metric
    ,nvl(A.fiscalYear, G.fiscalYear) as fiscalYear
    ,nvl(A.FQ2, G.FQ2) as timeframe
    ,nvl(A.audience, G.audience) as audience
    ,nvl(A.business_unit, G.bu) as business_unit
    ,nvl(A.sales_subregion_level_1, G.bu_1) as sales_subregion_level_1
    ,sum(total_delivery_specialization) over (partition by A.metric,A.audience,A.business_unit,A.sales_subregion_level_1  order by A.fq2) as cumulative_delivery_specialization
    ,total_delivery_specialization
    ,nvl(G.goal, 0) as target 
  from delivery_specialization_actuals A
  full outer join delivery_specialization_goals G
    on A.metric=G.metric
    and A.audience=G.audience
    and A.business_unit=G.bu
    and A.sales_subregion_level_1=G.bu_1
    and A.fq2=G.FQ2
)
select
  c.metric
  ,c.timeframe
  ,c.fiscalYear
  ,c.audience
  ,c.business_unit
  ,c.sales_subregion_level_1
  ,c.total_delivery_specialization
  ,COALESCE(
    c.cumulative_delivery_specialization,
    LAST_VALUE(c.cumulative_delivery_specialization, TRUE) OVER (
      PARTITION BY
        c.metric,
        c.audience,
        c.business_unit,
        c.sales_subregion_level_1
      ORDER BY c.timeframe
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    )
  ) AS cumulative_delivery_specialization -- prakas jira ESO-561
  ,c.target
  from cumulative_delivery_specialization c          
''')

# COMMAND ----------

# MAGIC %md # Fiscal Badges - Marketing

# COMMAND ----------

# DBTITLE 1,Badge Data Aggregation Engine
badges_df = spark.sql(f'''
with badge_data as 
(
  select
    "Fiscal Badges - Marketing" as metric,
    fiscalYear,
    fq2,
    case when audience in (
      "Partner",
      "Partner Other",
      "Microsoft",
      "Microsoft Other"
    ) 
    then "Partner"
    else audience
    end as audience,
    updated_account_id,
    region_derived,
    business_unit,
    sales_subregion_level_1,
    country_derived,
    count (learner_email_hash) as badges
  from main.field_learning_enablement.certifications_and_badges
  where credential_type = "Badge"
    --and is_expired = "false" --leks JIRA : ESO-229
    and processDate = (select max(processDate) from main.field_learning_enablement.certifications_and_badges)
  group by all
)
,customer_badges_actuals as 
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,business_unit
    ,sales_subregion_level_1
    ,sum (badges) as total_badges
  from badge_data 
  where audience='Customer'
  group by all 
)
,partner_wo_india_badges_actuals as 
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,nvl(region_derived, "Unknown") business_unit
    ,nvl(region_derived, "Unknown") sales_subregion_level_1
    ,sum (badges) as total_badges
  from badge_data 
  where audience='Partner' and upper(NVL(country_derived,''))<>'INDIA'
  group by all 
)

,partner_india_badges_actuals as
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,'India' business_unit
    ,'India' sales_subregion_level_1
    ,sum (badges) as total_badges
  from badge_data 
  where audience='Partner' and upper(NVL(country_derived,''))='INDIA'
  group by all 
)
,others_badges_actuals as
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,'Unknown' as business_unit
    ,'Unknown' as sales_subregion_level_1
    ,sum (badges) as total_badges
  from badge_data 
  where audience not in ('Customer','Partner')
  group by all  
)
,badges_actuals as 
(
  select * from customer_badges_actuals
  union all
  select * from partner_wo_india_badges_actuals
  union all
  select * from partner_india_badges_actuals
  union all
  select * from others_badges_actuals
)       
,badges_goals as
(
  select 
  case when metric ='Fiscal Badges' then 'Fiscal Badges - Marketing' else metric end as metric
   ,* except(metric)
from {goals_table} 
  where metric='Fiscal Badges' 
)
,cumulative_badges as
(
  select 
    nvl(A.metric, G.metric) as metric
    ,nvl(A.fiscalYear, G.fiscalYear) as fiscalYear
    ,nvl(A.FQ2, G.FQ2) as timeframe
    ,nvl(A.audience, G.audience) as audience
    ,nvl(A.business_unit, G.bu) as business_unit
    ,nvl(A.sales_subregion_level_1, G.bu_1) as sales_subregion_level_1
    ,sum(total_badges) over (partition by A.metric,A.audience,A.business_unit,A.sales_subregion_level_1 ,A.fiscalYear order by A.fq2) as cumulative_badges
    ,total_badges
    ,nvl(G.goal, 0) as target 
  from badges_actuals A
  full outer join badges_goals G
    on A.metric=G.metric
    and A.audience=G.audience
    and A.business_unit=G.bu
    and A.sales_subregion_level_1=G.bu_1
    and A.fq2=G.FQ2
)
select
  c.metric
  ,c.timeframe
  ,c.fiscalYear
  ,c.audience
  ,c.business_unit
  ,c.sales_subregion_level_1
  ,c.total_badges
  ,case when (c.cumulative_badges is null and c.timeframe >=
    (select fiscal_year_quarter from main.it_core_dim.dim_dates where date = current_date :: date)
  )
  then last_value (c.cumulative_badges, true) over (partition by c.metric,c.audience,c.business_unit,c.sales_subregion_level_1
    order by timeframe ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
  else c.cumulative_badges
  end as cumulative_badges
  ,c.target
  from cumulative_badges c          
''')

# COMMAND ----------

# MAGIC %md
# MAGIC # Total Fiscal Badges

# COMMAND ----------

badges_df_total = spark.sql(f'''
with badge_data as 
(
  select
    "Total Fiscal Badges" as metric,
    fiscalYear,
    fq2,
    case when audience in (
      "Partner",
      "Partner Other",
      "Microsoft",
      "Microsoft Other"
    ) 
    then "Partner"
    else audience
    end as audience,
    updated_account_id,
    region_derived,
    business_unit,
    sales_subregion_level_1,
    country_derived,
    count (learner_email_hash) as badges
  from main.field_learning_enablement.certifications_and_badges
  where credential_type in  ("Badge","Sales Badge")
    --and is_expired = "false" --leks JIRA : ESO-229
    and processDate = (select max(processDate) from main.field_learning_enablement.certifications_and_badges)
  group by all
)
,customer_badges_actuals as 
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,business_unit
    ,sales_subregion_level_1
    ,sum (badges) as total_badges
  from badge_data 
  where audience='Customer'
  group by all 
)
,partner_wo_india_badges_actuals as 
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,nvl(region_derived, "Unknown") business_unit
    ,nvl(region_derived, "Unknown") sales_subregion_level_1
    ,sum (badges) as total_badges
  from badge_data 
  where audience='Partner' and upper(NVL(country_derived,''))<>'INDIA'
  group by all 
)

,partner_india_badges_actuals as
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,'India' business_unit
    ,'India' sales_subregion_level_1
    ,sum (badges) as total_badges
  from badge_data 
  where audience='Partner' and upper(NVL(country_derived,''))='INDIA'
  group by all 
)
,others_badges_actuals as
(
  select 
    metric
    ,fq2
    ,fiscalYear
    ,audience
    ,'Unknown' as business_unit
    ,'Unknown' as sales_subregion_level_1
    ,sum (badges) as total_badges
  from badge_data 
  where audience not in ('Customer','Partner')
  group by all  
)
,badges_actuals as 
(
  select * from customer_badges_actuals
  union all
  select * from partner_wo_india_badges_actuals
  union all
  select * from partner_india_badges_actuals
  union all
  select * from others_badges_actuals
)       
,badges_goals as
(
  select * 
  from {goals_table} 
  where metric="Total Fiscal Badges"
)
,cumulative_badges as
(
  select 
    nvl(A.metric, G.metric) as metric
    ,nvl(A.fiscalYear, G.fiscalYear) as fiscalYear
    ,nvl(A.FQ2, G.FQ2) as timeframe
    ,nvl(A.audience, G.audience) as audience
    ,nvl(A.business_unit, G.bu) as business_unit
    ,nvl(A.sales_subregion_level_1, G.bu_1) as sales_subregion_level_1
    ,sum(total_badges) over (partition by A.metric,A.audience,A.business_unit,A.sales_subregion_level_1 ,A.fiscalYear order by A.fq2) as cumulative_badges
    ,total_badges
    ,nvl(G.goal, 0) as target 
  from badges_actuals A
  full outer join badges_goals G
    on A.metric=G.metric
    and A.audience=G.audience
    and A.business_unit=G.bu
    and A.sales_subregion_level_1=G.bu_1
    and A.fq2=G.FQ2
)
select
  c.metric
  ,c.timeframe
  ,c.fiscalYear
  ,c.audience
  ,c.business_unit
  ,c.sales_subregion_level_1
  ,c.total_badges
  ,case when (c.cumulative_badges is null and c.timeframe >=
    (select fiscal_year_quarter from main.it_core_dim.dim_dates where date = current_date :: date)
  )
  then last_value (c.cumulative_badges, true) over (partition by c.metric,c.audience,c.business_unit,c.sales_subregion_level_1
    order by timeframe ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
  else c.cumulative_badges
  end as cumulative_badges
  ,c.target
  from cumulative_badges c          
''')

# COMMAND ----------

# MAGIC %md
# MAGIC # Paid Training

# COMMAND ----------

paid_df = spark.sql(f'''with milestone_data as 
(
  select
    m.milestone_target_fiscal_year_quarter,
    m.milestone_target_fiscal_year,
    m.milestone_target_date,
    m.milestone_id,
    m.milestone_revenue_type,
    m.class_generated_project_id,
    m.class_name,
    case
      when m.class_custom_id = 12710 then 11083
      when m.class_custom_id = 12708 then 11082
      when m.class_custom_id = 14132 then 14131
      when m.class_custom_id = 13219 then 12632
      else m.class_custom_id
    end as class_custom_id,
    m.class_format,
    m.course,
    m.provider,
    m.milestone_name,
    m.milestone_amount,
    m.gaap_milestone_amount,
    m.milestone_status,
    m.is_milestone_approved,
    m.include_milestone_in_financial,
    m.billing_event_status,
    m.project_id,
    m.project_name,
    m.project_region,
    m.account_name,
    m.billing_invoice_date,
    p.account_id,
    p.project_service_tier,
    p.project_Service_type,
    p.project_unscheduled_backlog,
    p.project_unused_success_credits,
    p.opportunity_id,
    p.parent_project_id,
    p.parent_project_name,
    p1.id, 
    p1.OpportunityID_CaseSafe__c,
    c.sales_business_unit,
    c.opportunity_region_level_1, 
    a.sales_subregion_level_1
  from main.gtm_data.core_professional_services_milestones m
  inner join main.gtm_data.core_professional_services_dim_project p 
    on m.project_id = p.project_id
    and p.snapshot_date =( select max(snapshot_date) from main.gtm_data.core_professional_services_dim_project)
  left join main.sfdc_bronze.pse__proj__c p1 
    on m.project_id=p1.id and p1.processdate=(select max(processdate) from main.sfdc_bronze.pse__proj__c)
  left join main.gtm_data.core_opportunity_curated c 
    on  p1.OpportunityID_CaseSafe__c=c.opportunity_id
  left join main.gtm_data.core_accounts_curated a 
    on a.account_id = p.account_id
  where m.snapshot_date =(select max(snapshot_date) from main.gtm_data.core_professional_services_milestones)
    and m.practice_name = 'Training'
    and m.milestone_status = "Approved"
    and p.project_service_type not in ('SCP', 'BIF')
)
,paid_training_actuals as
(
  select
    "Training Revenue Pre GAAP" as metric,
    milestone_target_fiscal_year as fiscalYear,
    milestone_target_fiscal_year_quarter as timeframe,
    sales_business_unit as business_unit,
    sales_subregion_level_1 ,
    sum(milestone_amount) as total_delivered_revenue_pre_gaap
  from milestone_data
  group by all
)

,paid_training_goals as
(
  select * 
  from {goals_table} 
  where fq2>="25-Q1"
  and metric="Training Revenue Pre GAAP"
)

,pre_final_overall as 
(
  select 
    nvl(A.metric, G.metric) as metric
    ,nvl(A.fiscalYear, G.fiscalYear) as fiscalYear
    ,nvl(A.timeframe, G.FQ2) as timeframe
    ,nvl(A.business_unit, G.bu) as business_unit
    ,nvl(A.sales_subregion_level_1, G.bu_1) as sales_subregion_level_1
    ,nvl(a.total_delivered_revenue_pre_gaap,0) as total_delivered_revenue_pre_gaap 
    ,nvl(g.goal,0) as target
  from paid_training_actuals a 
  full outer join paid_training_goals g 
  on a.metric=g.metric
  and a.fiscalyear=g.fiscalYear
  and a.timeframe=g.fq2
  and a.business_unit=g.bu
  and a.sales_subregion_level_1=g.bu_1
  where 1=1
)

select * from pre_final_overall 
''')

# COMMAND ----------

# MAGIC %md
# MAGIC # Weekly Active Users (WAU)

# COMMAND ----------

# MAGIC %md
# MAGIC Creation of WAU base tables

# COMMAND ----------

wau_base_df=spark.sql("""
with base_data as (
select 
    date,
    salesforce_account_id as account_id,
    COUNT(DISTINCT case when login_num_events_t7d > 0 then user_id end) as wau 
  from main.data_product_features.user_metrics
  where salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
  and date >= '2024-02-01' 
  group by ALL
  
)

,dates_table as (
select 
   date
  ,fiscal_year 
  ,fiscal_month
  ,count(date) over (partition by fiscal_year,fiscal_month) as days_in_month
  from main.it_core_dim.dim_dates where date<=(select max(date) from base_data)
)

, base_data_agg_augmented as 
(
  select 
  B.date,
  B.account_id,
  DATE_TRUNC('month', b.date)::date AS month,
  c.business_unit, 
  c.sales_subregion_level_1,
  D.*,
  sum(wau) as wau
  from base_data B
  left join main.gtm_data.core_accounts_curated c 
  on B.account_id=c.account_id 
  left join dates_table D
  on B.date=D.date
  group by all 
)

,final_wau_base_data as 
(
  select 
    month,
    account_id,
    business_unit, 
    sales_subregion_level_1,
    fiscal_year,
    days_in_month,
    sum(wau) as wau
  from base_data_agg_augmented
  group by all
)
select * from final_wau_base_data 
""")

# COMMAND ----------

wau_df=spark.sql(f"""
with base_data as (
select 
    date,
    salesforce_account_id as account_id,
    COUNT(DISTINCT case when login_num_events_t7d > 0 then user_id end) as wau 
  from main.data_product_features.user_metrics
  where salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
  and date >= '2024-02-01'
  group by ALL
  
)

, base_data_agg_augmented as 
(
  select 
  B.date,
  c.business_unit, 
  c.sales_subregion_level_1,
  sum(wau) as wau
   from base_data B
  left join main.gtm_data.core_accounts_curated c 
  on B.account_id=c.account_id 
  group by all 
)

,wau_actual as (
select 
  'WAU' as metric
  ,DATE_TRUNC('month', b.date)::date AS month,
  d.fiscal_year as fiscalYear
  ,business_unit
  ,sales_subregion_level_1 
  ,ROUND(AVG (wau),0)  WAU
  from base_data_agg_augmented b
  left join main.it_core_dim.dim_dates d
  on b.date=d.date  --where business_unit='APJ' and sales_subregion_level_1='Korea' 
 group by all
order by month asc)

,goals_data as (
  select
    *
  from
    {goals_table} 
  where
    fq2 >= "25-Q1"
    and metric = "WAU"
    and processDate =(
      Select
        max(processDate)
      from
        {goals_table} 
    ))


select 

nvl(a.metric, G.metric) as metric,
  nvl(a.month::string, G.FQ2_date::string) as timeframe,
  nvl(a.fiscalYear, g.fiscalYear) as fiscalYear,
  nvl(a.business_unit,g.bu) as business_unit,
  nvl(a.sales_subregion_level_1,g.bu_1) as sales_subregion_level_1,
  --nvl(a.grain_lvl_3,b.grain_lvl_3) as grain_lvl_3,
  nvl(a.wau,0) as wau,
  nvl(G.goal, 0) as target
from wau_actual A 
left outer join goals_data G
on A.metric=G.metric 
and A.fiscalYear=G.FiscalYear
and A.business_unit=G.bu
and A.sales_subregion_level_1=G.bu_1
and A.month=G.FQ2_date
""")






# COMMAND ----------

# MAGIC %md
# MAGIC # TRAINED ACCOUNTS

# COMMAND ----------

# MAGIC %md
# MAGIC Trained account Actual Calculation
# MAGIC - We look at the snapshot date of the moment when looking a trained accounts
# MAGIC - This means that our actuals is the snapshot of the last day recorded
# MAGIC - For Q1, it would be snapshot date of the last day of April
# MAGIC - Same logic should apply to all dates
# MAGIC

# COMMAND ----------

trained_accounts_actuals_df = spark.sql(f'''
---------- JIRA https://databricks.atlassian.net/browse/ESO-264 --------------------------------------
with qtr_end_dates AS 
(
  select distinct fiscal_quarter_end_date , fq2, period 
  from main.field_learning_enablement.okr_trained_accounts_base a
  left join main.it_core_dim.dim_dates d
  on a.period=d.date
  where processdate=(Select max(processdate) from main.field_learning_enablement.okr_trained_accounts_base)
) 

,dates_filter AS 
(
  select 
    distinct
    fiscal_quarter_end_date,
    case when fiscal_quarter_end_date<=current_date::date then date(date_trunc('MONTH',fiscal_quarter_end_date)) 
         else date(date_trunc('MONTH',current_date::date))
    end as period
  from qtr_end_dates 
)

---------- JIRA https://databricks.atlassian.net/browse/ESO-264 --------------------------------------
,customers AS (
  SELECT
      account_id,
      account_name,
      business_unit sales_business_unit, --lek modified 
      sales_subregion_level_1,
      t3m_annualized,
      learners cumulative_learners, --lek modified 
      snapshot_date,
      d.fiscal_year as fiscalYear,
      d.fiscal_year_quarter fq2
  --FROM main.field_learning_enablement.trained_accounts t --lek modified 
  FROM main.field_learning_enablement.okr_trained_accounts_base t
  left join main.it_core_dim.dim_dates d
  on t.snapshot_date=d.date
  WHERE processDate = (SELECT MAX(processDate) 
                       FROM main.field_learning_enablement.okr_trained_accounts_base) --lek modified 
  and period in (select period from dates_filter)-- JIRA https://databricks.atlassian.net/browse/ESO-264 
  and t.account_segment is not null
    
),
segment AS (
  SELECT 
      account_id,
      account_segment
  FROM main.gtm_data.core_accounts_curated
  WHERE snapshot_date = (SELECT MAX(snapshot_date) FROM main.gtm_data.core_accounts_curated)
),
final AS (
  SELECT
      c.fq2,
      c.fiscalYear,
      c.account_id,
      c.account_name,
      c.sales_business_unit,
      c.sales_subregion_level_1,
      s.account_segment,
      c.t3m_annualized,
      NVL(c.cumulative_learners, 0) AS cumulative_learners
  FROM customers c
  LEFT JOIN segment s ON c.account_id = s.account_id
),
-- Aggregate data and compute normalized segment and learners total
agg AS (
  SELECT 
      fiscalYear,
      fq2,
      account_name,
      sales_business_unit,
      sales_subregion_level_1,
      CASE
          WHEN account_segment IN ('Geo', 'Emerging Enterprise', 'Emerging DNB', 'DNB Named') THEN 'Emerging'
          WHEN account_segment IN ('Strategic', 'DNB Strategic') THEN 'Strategic'
          WHEN account_segment IN ('Named', 'PubSec Fed', 'Pub Sec', 'PubSec SLED') THEN 'Named'
      END AS segment,
      MAX(cumulative_learners) AS learners
  FROM final
  WHERE  account_segment IS NOT NULL 
  GROUP BY ALL
)
,trained_account_actual as (
SELECT
  'Trained Accounts' as metric,
  fiscalYear,
  fq2,
  account_name,
  sales_business_unit business_unit,
  sales_subregion_level_1,
  segment AS account_segment,
  learners,
  -- Calculate Threshold based on the segment
  CASE
    WHEN segment = 'Strategic' THEN 100
    WHEN segment = 'Named' THEN 30
    WHEN segment = 'Emerging' THEN 10
  END AS Threshold,
  -- Determine if the account is trained based on learners vs. threshold
  CASE
    WHEN learners >= (CASE
                        WHEN segment = 'Strategic' THEN 100
                        WHEN segment = 'Named' THEN 30
                        WHEN segment = 'Emerging' THEN 10
                      END) THEN 1
    ELSE 0
  END AS trained_flag
  
FROM agg
)
,final_trained_actual as (
  select
    metric,
    p.fq2,
    p.fiscalYear,
    p.business_unit,
    p.sales_subregion_level_1 ,
    sum(trained_flag) actual_trained_acc,
    count(trained_flag) actual_total_acc,
    try_divide(sum(trained_flag) , count(trained_flag)) as ratio_trained_accounts
  from
    trained_account_actual p
  group by
    all
  order by
    all
)
,trained_accounts_goals as (
  select
    *
  from
    {goals_trained_acc_table}
  where
    fq2 >= "25-Q1"
    and metric = "Trained Accounts"
    and processDate =(
      Select
        max(processDate)
      from
        {goals_trained_acc_table}
    )
),

pre_final as 
(
select
  nvl(a.metric, b.metric) as metric,
  nvl(a.fq2, b.fq2) as timeframe,
  nvl(a.fiscalYear, b.fiscalYear) as fiscalYear,
  nvl(a.business_unit,b.bu) as business_unit,
  nvl(a.sales_subregion_level_1,b.bu_1) as sales_subregion_level_1,
  nvl(a.actual_trained_acc,0) actual_trained_acc,
  nvl(a.actual_total_acc,0) actual_total_acc,
  nvl(a.ratio_trained_accounts,0) as ratio_trained_accounts,
  nvl(b.trained_accounts::string, '0') as target_trained_acc,
  nvl(b.total_accounts::string, '0') as target_total_acc
from
  final_trained_actual a
  full outer join trained_accounts_goals b 
  on a.metric = b.metric
  and a.fq2 = b.fq2
  and a.business_unit = b.bu
  and a.sales_subregion_level_1 = b.bu_1
  
)


select * from pre_final

''')

# COMMAND ----------

# DBTITLE 1,Fiscal Quarter Learners Report
dim_dates = spark.read.table('main.it_core_dim.dim_dates')

unique_quarters = (
  dim_dates
    .select('fiscal_year_quarter', 'fiscal_quarter_start_date', 'fiscal_quarter_end_date')
    .distinct()
)

learners_df_final = (
  learners_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == learners_df.timeframe, 'left')
    .select(
        'metric',
        'fiscalYear',
        'timeframe',
        'audience',
        'business_unit',
        'sales_subregion_level_1',
        F.col('cumulative_learners').alias('actuals'),
        F.col('target').cast(DoubleType()),
        F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
        F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
      
      )
)

certs_df_final = (
  certs_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == certs_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'audience',
      'business_unit',
      'sales_subregion_level_1',
      F.col('total_certs').alias('actuals'),
      F.col('target').cast(DoubleType()),
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
    )
)

badges_df_final = (
  badges_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == badges_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'audience',
      'business_unit',
      'sales_subregion_level_1',
      F.col('cumulative_badges').alias('actuals'),
      F.col('target').cast(DoubleType()),
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
    )
)

badges_df_total_final = (
  badges_df_total
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == badges_df_total.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'audience',
      'business_unit',
      'sales_subregion_level_1',
      F.col('cumulative_badges').alias('actuals'),
      F.col('target').cast(DoubleType()),
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
    )
)

delivery_specialization_df_final = (
  delivery_specialization_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == delivery_specialization_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'audience',
      'business_unit',
      'sales_subregion_level_1',
      F.col('cumulative_delivery_specialization').alias('actuals'),
      F.col('target').cast(DoubleType()),
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
    )
)

paid_df_final = (
  paid_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == paid_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'business_unit',
      'sales_subregion_level_1',
      F.col('total_delivered_revenue_pre_gaap').alias('actuals'),
      F.col('target').cast(DoubleType()),
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
    )
)


trained_accounts_actuals_df_final = (
  trained_accounts_actuals_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == trained_accounts_actuals_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'business_unit',
      'sales_subregion_level_1',
      'actual_trained_acc',
      'actual_total_acc',
      'ratio_trained_accounts',
      'target_trained_acc',
      'target_total_acc',
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
    )
)

wau_df_final = (
  wau_df
    .join(dim_dates, dim_dates.date == wau_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'business_unit',
      'sales_subregion_level_1',
      F.col('wau').alias('actuals'),
      F.col('target').cast(DoubleType()),
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
    )
)

# COMMAND ----------

# dim_dates = spark.read.table('main.it_core_dim.dim_dates')

# unique_quarters = (
#   dim_dates
#     .select('fiscal_year_quarter', 'fiscal_quarter_start_date', 'fiscal_quarter_end_date')
#     .distinct()
# )

# COMMAND ----------

# paid_df_final = (
#   paid_df
#     .join(unique_quarters, unique_quarters.fiscal_year_quarter == paid_df.timeframe, 'left')
#     .select(
#       'metric',
#       'fiscalYear',
#       'timeframe',
#       'business_unit',
#       'sales_subregion_level_1',
#       F.col('total_delivered_revenue_pre_gaap').alias('actuals'),
#       F.col('target').cast(DoubleType()),
#       F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
#       F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
#     )
# )

# wau_df_final = (
#   wau_df
#     .join(dim_dates, dim_dates.date == wau_df.timeframe, 'left')
#     .select(
#       'metric',
#       'fiscalYear',
#       'timeframe',
#       'business_unit',
#       'sales_subregion_level_1',
#       F.col('wau').alias('actuals'),
#       F.col('target').cast(DoubleType()),
#       F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
#       F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
#     )
# )


# COMMAND ----------

df_no_aud=paid_df_final.union(wau_df_final)

# COMMAND ----------

all_df = (
  learners_df_final
    .union(certs_df_final)
    .union(badges_df_final)
    .union(badges_df_total_final)
    .union(delivery_specialization_df_final)
)

# COMMAND ----------

# DBTITLE 1,Pyspark DataFrame Column Casting
# from pyspark.sql.types import DoubleType



# all_df = (
#   all_df
#     .select(
#       'metric', 
#       'fiscalYear', 
#       'timeframe',
#       'audience',
#       'business_unit',
#       'sales_subregion_level_1',
#       'actuals',
#       F.col('target').cast(DoubleType()),
#       'timeframe_start_date',
#       'timeframe_end_date'
#     )
    

# )


# paid_df_final = (
#   paid_df_final
#     .select(
#       'metric', 
#       'fiscalYear', 
#       'timeframe',
#       'business_unit',
#       'sales_subregion_level_1',
#       'actuals',
#       F.col('target').cast(DoubleType()),
#       'timeframe_start_date',
#       'timeframe_end_date'
#     )
    

# )

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Gold Enhancement

# COMMAND ----------

df_no_aud_gold=add_gold_metadata(df_no_aud)

# COMMAND ----------

all_df_gold = add_gold_metadata(all_df)
#paid_df_gold = add_gold_metadata(paid_df_final)
trained_accounts_actuals_df_final_gold = add_gold_metadata(trained_accounts_actuals_df_final)
df_no_aud_gold=add_gold_metadata(df_no_aud)
wau_base_df_gold = add_gold_metadata(wau_base_df)

# COMMAND ----------

wau_base_df_gold = add_gold_metadata(wau_base_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = wau_base_df_gold, 
  table_name = f'{focus_database_name}.weekly_active_users', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_df_gold, 
  table_name = f'{focus_database_name}.fy26_goals_actuals_aud_metrics', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = df_no_aud_gold, 
  table_name = f'{focus_database_name}.fy26_goals_actuals_rev_metrics', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = trained_accounts_actuals_df_final_gold, 
  table_name = 'main.field_learning_enablement.fy26_goals_actuals_trained_acc_metrics', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = wau_df_gold, 
#   table_name = f'{focus_database_name}.fy26_goals_actuals_wau_metrics', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )