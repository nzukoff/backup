# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Lekshmi S \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

#spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from pyspark.sql.types import DoubleType
#from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
# from focus_databricks.common.date_utils import *
# from focus_databricks.koda.table_utils import *
# from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

import time
from delta.tables import *
from datetime import date, datetime
import logging

logging.basicConfig(format="%(asctime)-15s %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def write_delta_table(
    spark,
    dataframe,
    table_name,
    format="delta",
    mode="overwrite",
    overwrite_schema="true",
    merge_schema="true",
    optimize=True,
    partition_column=None,
    zorder=None,
    replace_where=None,
    location=None,
):

    num_rows = dataframe.count()
    logger_statement = """Written the dataframe. Please look at the stats:
                          Details:
                          - Table Name: {0} 
                          - Total time spent: {1} minutes
                          - Write Options:
                            - format: {2}
                            - mode: {3}
                            - optimize: {4}
                            - zorder: {5}
                            - partition by: {6}
                            - replace where: {7}
                            - location: {8}
                            - Schema Options:
                                - overwrite schema: {9}
                                - merge schema: {10}
                          - Written rows:  {11}
                       """
    logger.info("Writting the table {0}".format(table_name))
    start_time = time.time()
    write_instructions = (
        dataframe.write.format(format)
        .mode(mode)
        .option("overwriteSchema", overwrite_schema)
        .option("mergeSchema", merge_schema)
    )

    if partition_column is not None:
        write_instructions = write_instructions.partitionBy(partition_column)

    if replace_where is not None:
        write_instructions = write_instructions.option("replaceWhere", replace_where)

    write_instructions.saveAsTable(table_name)
    write_time = time.time()

    if optimize:
        logger.info("Running optimize the delta table now")
        start = time.time()
        optimize_instructions = "OPTIMIZE " + table_name
        if replace_where is not None:
            logger.info("Replacing the delta table according to where clause now")
            optimize_instructions += " WHERE " + replace_where
            if zorder:
                optimize_instructions += " ZORDER BY " + zorder
                spark.sql(optimize_instructions)
        logger.info(
            "Optimized in {} minutes.".format(
                str(round((time.time() - write_time) / 60, 1))
            )
        )

    logger.info(
        logger_statement.format(
            table_name,
            round((write_time - start_time) / 60, 1),
            format,
            mode,
            optimize,
            zorder,
            partition_column,
            replace_where,
            location,
            overwrite_schema,
            merge_schema,
            num_rows,
        )
    )



# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------


print(focus_database_name,partition_date)

# COMMAND ----------

# utility methods

from pyspark.sql import DataFrame
from typing import Optional
from datetime import date,datetime
def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC # TRAINED ACCOUNTS

# COMMAND ----------

# %sql
# with learners as (
#   select
#     updated_account_id,
#     updated_account_name,
#     date_trunc('MONTH', completed_date)::date as learner_month,
#     count (distinct learner_user_id) as learners
#   from
#     main.field_learning_enablement.all_learners
#   where processdate =(select max(processdate) from main.field_learning_enablement.all_learners)
#     and dataset = "net new learners"
#     and audience = 'Customer'
#   group by all
#   order by all
# ) 
# ,snapshot_dates as (
#   select date_trunc("MONTH", snapshot_date)::date as month, max(snapshot_date) as snapshot_date
#   from main.gtm_data.core_accounts_curated_history
#   where snapshot_date >= "2023-01-01" 
#   group by all
#   order by all
# )

# ,accounts as (
#   select
#     date_trunc('MONTH', snapshot_date)::date as snapshot_date,
#     account_id,
#     account_name,
#     t3m_annualized
# from main.gtm_data.core_accounts_curated_history
# where snapshot_date in (select distinct snapshot_date from snapshot_dates)
# and snapshot_date >= "2023-01-01" 
# and t3m_annualized > 240000
# and account_id='0016100001H6k8nAAB'
# )
# ,learners_combined as 

# (
#   select 
#      NVL(updated_account_id,account_id) updated_account_id
#     ,NVL(updated_account_name,account_name) updated_account_name
#     ,NVL(learner_month,snapshot_date) as learner_month
#     ,NVL(learners,0) learners
#   from learners
#   full outer join accounts 
#   on learners.updated_account_id = accounts.account_id
#   and learners.updated_account_name = accounts.account_name
#   and learners.learner_month = accounts.snapshot_date

# )


# select * from learners_combined where updated_account_id='0016100001H6k8nAAB'

# COMMAND ----------

spark.sql("""
          
-- with dates as (
--   select distinct date_trunc('MONTH', date) as period from it_core_dim.dim_dates where date>=2023-01-01
-- ),

with learners as (
  select
    updated_account_id,
    updated_account_name,
    date_trunc('MONTH', completed_date)::date as learner_month,
    count (distinct learner_user_id) as learners
  from
    main.field_learning_enablement.all_learners
  where processdate =(select max(processdate) from main.field_learning_enablement.all_learners)
    and dataset = "net new learners"
    and audience = 'Customer'
  group by all
  order by all

)
,snapshot_dates as (
  select date_trunc("MONTH", snapshot_date)::date as month, max(snapshot_date) as snapshot_date
  from main.gtm_data.core_accounts_curated_history
  where snapshot_date >= "2023-01-01" 
  group by all
  order by all
)

,accounts as (
  select
    date_trunc('MONTH', snapshot_date)::date as snapshot_date,
    account_id,
    account_name,
    t3m_annualized
from main.gtm_data.core_accounts_curated_history
where snapshot_date in (select distinct snapshot_date from snapshot_dates)
and snapshot_date >= "2023-01-01" 
and t3m_annualized > 240000
--and account_id='0016100001H6k8nAAB'
)
,learners_combined as 

(
  select 
     NVL(updated_account_id,account_id) updated_account_id
    ,NVL(updated_account_name,account_name) updated_account_name
    ,NVL(learner_month,snapshot_date) as learner_month
    ,NVL(learners,0) learners
  from learners
  full outer join accounts 
  on learners.updated_account_id = accounts.account_id
  and learners.updated_account_name = accounts.account_name
  and learners.learner_month = accounts.snapshot_date

)


,learners_agg as (
  select
    updated_account_id account_id,
    updated_account_name account_name,
    learner_month period,
    learners,
    sum(learners) over (partition by updated_account_id order by learner_month) as cumulative_learners_pre
  from learners_combined l
  group by all
  order by all
) 
,
learners_cumulative as (
  select 
    *,
    last_value (l.cumulative_learners_pre, true) over (partition by l.account_id order by period ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as cumulative_learners 
  from learners_agg l
)
,
final as (
  select 
    p.account_id,
    p.account_name,
    p.learners,
    nvl(p.cumulative_learners, 0) as cumulative_learners,
    p.period,
    nvl(c.sales_business_unit, "Unknown") as sales_business_unit,
    nvl(c.sales_subregion_level_1, "Unknown") as sales_subregion_level_1,
    nvl(c.sales_subregion_level_2, "Unknown") as sales_subregion_level_2,
    nvl(c.sales_subregion_level_3, "Unknown") as sales_subregion_level_3 
  from learners_cumulative p 
  left join main.gtm_data.core_accounts_curated c on p.account_id = c.account_id
)
,
greenfield as (
  SELECT
    ca.account_id,
    CASE WHEN ba.accountspendtier__c = 'Greenfield'
        AND lower(ba.Owner_Role__c) not like '%unassigned%'
        AND ca.business_unit is not null
        AND ca.dbx in ('DB400','DB3000')   
            THEN 'Yes'
    ELSE 'No' 
    END as greenfield_account
    FROM main.gtm_data.core_accounts_curated ca
    LEFT JOIN main.sfdc_bronze.account ba 
      ON ca.account_id = ba.AccountID_CaseSafe__c
    AND ba.processDate IN (SELECT MAX(processDate) FROM main.sfdc_bronze.account)
)


select 
  f.*,
  g.greenfield_account
from final f
left join greenfield g on f.account_id=g.account_id
order by account_id,period
""").createOrReplaceTempView("accounts_learners")

# COMMAND ----------

trained_account_base_df = spark.sql('''
with snapshot_dates as (
  select date_trunc("MONTH", snapshot_date)::date as month, max(snapshot_date) as snapshot_date
  from main.gtm_data.core_accounts_curated_history
  where snapshot_date >= "2023-01-01" 
  group by all
  order by all
)

,
accounts as (
  select
    date_trunc('MONTH', snapshot_date)::date as snapshot_date,
    account_id,
    account_name,
    t3m_annualized
from main.gtm_data.core_accounts_curated_history
where snapshot_date in (select distinct snapshot_date from snapshot_dates)
and snapshot_date >= "2023-01-01" 
and t3m_annualized > 240000
)

,
data as (
  select
    t.*,
    m.period,
    m.learners,
    m.cumulative_learners
  from
    accounts t
    left join accounts_learners m on t.account_id = m.account_id
    and t.snapshot_date = m.period
  where 1=1
    and t.snapshot_date :: date <= (select current_date::date)
  order by
    all
)

,customers as 
(SELECT
      t.account_id,
      t.account_name,
      c.sales_business_unit,
      c.sales_subregion_level_1,
      t.t3m_annualized,
      t.cumulative_learners,
      t.snapshot_date,
      d.fiscal_year as fiscalYear,
      d.fiscal_year_quarter fq2,
      t.period
  FROM data t
  left join main.gtm_data.core_accounts_curated c on t.account_id=c.account_id
  left join main.it_core_dim.dim_dates d
  on t.snapshot_date=d.date
  
),
segment AS (
  SELECT 
      account_id,
      account_segment
  FROM main.gtm_data.core_accounts_curated
  WHERE snapshot_date = (SELECT MAX(snapshot_date) FROM main.gtm_data.core_accounts_curated)
),
final AS (
  SELECT
      c.fq2,
      c.fiscalYear,
      c.account_id,
      c.account_name,
      c.sales_business_unit,
      c.sales_subregion_level_1,
      s.account_segment,
      c.t3m_annualized,
      c.period,
      c.snapshot_date,
      NVL(c.cumulative_learners, 0) AS cumulative_learners
  FROM customers c
  LEFT JOIN segment s ON c.account_id = s.account_id
),
-- Aggregate data and compute normalized segment and learners total
agg AS (
  SELECT 
      fiscalYear,
      fq2,
      period,
      account_id,
      account_name,
      t3m_annualized,
      sales_business_unit,
      snapshot_date,
      sales_subregion_level_1,
      CASE
          WHEN account_segment IN ('Geo', 'Emerging Enterprise', 'Emerging DNB', 'DNB Named') THEN 'Emerging'
          WHEN account_segment IN ('Strategic', 'DNB Strategic') THEN 'Strategic'
          WHEN account_segment IN ('Named', 'PubSec Fed', 'Pub Sec', 'PubSec SLED') THEN 'Named'
      END AS segment,
      MAX(cumulative_learners) AS learners
  FROM final
  WHERE  account_segment IS NOT NULL 
  GROUP BY ALL
)
,trained_account_actual as (
SELECT
  'Trained Accounts' as metric,
  fiscalYear,
  fq2,
  period,
  account_id,
  account_name,
  t3m_annualized,
  snapshot_date,
  sales_business_unit business_unit,
  sales_subregion_level_1,
  segment AS account_segment,
  learners,
  -- Calculate Threshold based on the segment
  CASE
    WHEN segment = 'Strategic' THEN 100
    WHEN segment = 'Named' THEN 30
    WHEN segment = 'Emerging' THEN 10
  END AS Threshold,
  -- Determine if the account is trained based on learners vs. threshold
  CASE
    WHEN learners >= (CASE
                        WHEN segment = 'Strategic' THEN 100
                        WHEN segment = 'Named' THEN 30
                        WHEN segment = 'Emerging' THEN 10
                      END) THEN 1
    ELSE 0
  END AS trained_flag

  ,CASE
    WHEN learners >= (
          CASE
            WHEN segment = 'Strategic' THEN 100
            WHEN segment = 'Named' THEN 30
            WHEN segment = 'Emerging' THEN 10
          END
        ) THEN 'Trained Account'
    ELSE CAST(
          (
            (CASE
               WHEN segment = 'Strategic' THEN 100
               WHEN segment = 'Named' THEN 30
               WHEN segment = 'Emerging' THEN 10
             END) - learners
          ) AS VARCHAR(10)
         )
  END AS Required_Learners
  
FROM agg
where segment is not null
)

select 
  d.metric
  ,d.fiscalYear
  ,d.fq2
  ,d.period
  ,d.account_id
  ,d.account_name
  ,d.t3m_annualized
  ,d.snapshot_date
  ,d.business_unit
  ,d.sales_subregion_level_1
  ,nvl(c.sales_subregion_level_2, "Unknown") as sales_subregion_level_2
  ,nvl(c.sales_subregion_level_3, "Unknown") as sales_subregion_level_3 
  ,d.account_segment
  ,d.learners
  ,d.Required_Learners
  ,d.Threshold
  ,d.trained_flag
  
from trained_account_actual d
left join main.gtm_data.core_accounts_curated c 
on d.account_id = c.account_id



''').createOrReplaceTempView('trained_account')

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Gold Enhancement

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# %sql
# drop table main.field_learning_enablement.okr_trained_accounts_base

# COMMAND ----------

trained_account_df = spark.sql('''
                               select * from trained_account
                               ''')

# COMMAND ----------

trained_account_base_df_gold = add_gold_metadata(trained_account_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = trained_account_base_df_gold, 
  table_name = f'{focus_database_name}.okr_trained_accounts_base', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)