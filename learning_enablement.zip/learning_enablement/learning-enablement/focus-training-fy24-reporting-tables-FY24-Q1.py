# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "focus_dev")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = '2023-04-30' #dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### Certifications Badge dataset

# COMMAND ----------

certs_badges_df = spark.sql('''
  with date_year AS (
    select distinct fiscalYear,current_date as date from users.ravi_gangumalla.sql_dates where date::date=current_date
  )
  ,

  fiscal_year_end AS (
    select d.date, max(s.fiscalYear) as next_fiscal_year, max(s.qtr_end_date) as fiscal_year_end_date from users.ravi_gangumalla.sql_dates s inner join date_year d on s.fiscalYear=d.fiscalYear
    group by 1
  )
  ,
  employee_data AS (
    select 
      department, 
      category, 
      `1st_level_manager`,
      `1st_level_manager_name`,
      `2nd_level_manager`, 
      `2nd_level_manager_name`,
      `3rd_level_manager`, 
      `3rd_level_manager_name`,
      `4th_level_manager`,
      `4th_level_manager_name`,
      `5th_level_manager`, 
      `5th_level_manager_name`,
      `6th_level_manager`,
      `6th_level_manager_name`,
      Supervisory_Organization_cleaned,
      primaryWorkEmail,
      sha2(primaryWorkEmail,256) as email_hash
    from liam.wd
    where worker_type='Employee'
    and Termination_Date is null
  )
  ,
  badges as (
    select
      processdate,
      complete,
      credential_id,
      credential_name,
      expired_on :: date,
      is_expired,
      group_id,
      group_name, 
      issued_on :: date,
      learner_id,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email_domain,
      learner_branch_code,
      audience,
      b.account_id,
      b.account_name,
      ultimate_parent_account_id,
      ultimate_parent_account_name,
      d.fq2,
      d.qtr_start_date,
      d.qtr_end_date,
      d.fiscalYear,
      d2.fq2 as current_fiscal_quarter,
      d2.qtr_end_date as current_fiscal_quarter_end_date,
      f.fiscal_year_end_date,
      country_code,
      country_name,
      region,
      c.business_unit,
      c.sales_subregion_level_1,
      c.sales_subregion_level_2,
      case 
        when group_id in (
          '371215', 
          '364119', 
          '357057', 
          '353856', 
          '331743', 
          '229201', 
          '227965', 
          '227818'
        )
        then "Certification"
        when group_id in (
          '296467',
          '405160'
        ) then "Badge"
        else "Other" end as credential_type,
        case  
          when p.`Account ID` is not null then 1 else 0 end as partner_account_list_flag,
      dense_rank() over (partition by processdate,learner_email_hash order by issued_on::date) as rank_learner
    from focus_dev.accredible_credentials_fy24_q1 b
    inner join users.ravi_gangumalla.sql_dates d on b.issued_on::date=d.date
    inner join users.ravi_gangumalla.sql_dates d2 on current_date()::date=d2.date
    inner join fiscal_year_end f on current_date()::date=f.date
    left join focus_prod.core_accounts_curated c on b.account_id=c.account_id and c.snapshot_date=(select max(snapshot_date) from focus_prod.core_accounts_curated)
    left join focus_dev.partner_domains_priyanka p on left(b.ultimate_parent_account_id, 15) = p.`Account ID`
    where b.processdate= '2023-04-30' --(select max(processdate) from focus_dev.accredible_credentials_test)
  )

  ,

  working AS (
    select 
      case 
        when expired_on::date>current_date::date 
        then date_diff(expired_on,current_date) 
        else 0 end as days_to_expiration, 
      b.*,
      e.department, 
      e.category, 
      e.`1st_level_manager`,
      e.`1st_level_manager_name`,
      e.`2nd_level_manager`, 
      e.`2nd_level_manager_name`,
      e.`3rd_level_manager`, 
      e.`3rd_level_manager_name`,
      e.`4th_level_manager`,
      e.`4th_level_manager_name`,
      e.`5th_level_manager`, 
      e.`5th_level_manager_name`,
      e.`6th_level_manager`,
      e.`6th_level_manager_name`,
      e.Supervisory_Organization_cleaned,
      e.primaryWorkEmail
    from badges b
    left join employee_data e on b.learner_email_hash=e.email_hash and b.learner_branch_code='DBK_EMP' 
  )

  select * 
  from working

''')

# COMMAND ----------

certs_badges_gold = add_gold_metadata(certs_badges_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = certs_badges_gold, 
  table_name = f'{focus_database_name}.certifications_and_badges_fy24_q1', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select count(*)
# MAGIC from focus_dev.certifications_and_badges_fy24_q1
# MAGIC where processDate = '2023-04-30'
# MAGIC and credential_type = 'Certification'
# MAGIC and is_expired = 'false'

# COMMAND ----------

