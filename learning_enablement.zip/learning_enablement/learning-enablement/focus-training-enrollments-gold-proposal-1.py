# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

#SFDC Tables

sfdc_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.account",  "processDate")

sfdc_accounts = (
  spark.read.table("main.sfdc_bronze.account")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

# sfdc_contacts = (
#   spark.read.table("sfdc_prod.contact")
#     .filter(F.col("processDate") == sfdc_latest_process_date)
# )

# sfdc_leads = (
#   spark.read.table("sfdc_prod.lead")
#     .filter(F.col("processDate") == sfdc_latest_process_date)
# )

region_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.countryregionmap__c",  "processDate")

countries_regions = (
  spark.read.table("main.sfdc_bronze.countryregionmap__c")
  .filter(F.col("processDate") == region_latest_process_date)
  .select(
    F.col("Name").alias("country_code"),
    F.col("Region__c").alias("region")
  )
)

# Docebo Logfood data
silver_docebo_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_self_paced_enrollments",  "processDate")

docebo_self_paced_enrollments = (
  spark.read.table("main.it_training_silver.docebo_self_paced_enrollments")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

docebo_ilt_enrollments = (
  spark.read.table("main.it_training_silver.docebo_ilt_enrollments")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

account_status = (
  sfdc_accounts 
    .select(
      F.col("Id").alias("account_id"),
      F.col("Account_Status__c").alias("status")
    )
)

salesforce_account_email_domain_mapping = (
  spark.read.table("main.it_training_silver.docebo_salesforce_account_email_domain_mapping")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .filter(~F.col("account_name").isin('Individual LMS Account', 'Individual LMS Account(Generic)'))
    .drop("processDate")
    .join(account_status, "account_id", "left")
)

docebo_users_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.docebo_users_test",  "processDate")

docebo_users_gold = (
  spark.read.table(f"{focus_database_name}.docebo_users_test")
    .filter(F.col("processDate") == docebo_users_latest_process_date)
    .drop("processDate")
)

partner_domains_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.partner_domains_accounts",  "processDate")

partner_domains_df = (
  spark.read.table(f"{focus_database_name}.partner_domains_accounts")
    .filter(F.col("processDate") == partner_domains_latest_process_date)
    .drop("processDate")
)

partner_domains = [domain["email_domain"] for domain in partner_domains_df.collect()]

partner_accounts = [domain["ultimate_parent_account_name"] for domain in partner_domains_df.collect()]

# Blacklisted domains

blacklist_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.blacklist_domains",  "processDate")

blacklist_domains = (
  # spark.read.table("user_success_dev.blacklist_domains")
  spark.read.table(f"{focus_database_name}.blacklist_domains")
    .filter(F.col("processDate") == blacklist_latest_process_date)
)

blacklist = [domain["blacklist_domain"] for domain in blacklist_domains.collect()]

historical_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.historical_learndot_enrollments_self_paced",  "processDate")

# Learndot Historical ILT and Self Paced
ld_ilt = (
  spark.table(f"{focus_database_name}.historical_learndot_enrollments_ilt")
  .filter(F.col("processDate") == historical_latest_process_date)
    .drop("processDate")
)

ld_self_paced = (
  spark.table(f"{focus_database_name}.historical_learndot_enrollments_self_paced")
  .filter(F.col("processDate") == historical_latest_process_date)
    .drop("processDate")
)

# ld_latest_process_date = get_latest_partition_value(spark, "sfdc_ds.learndot__learndot_contact__c",  "processDate")

# ld_users = (
#   spark.table(f"sfdc_ds.learndot__learndot_contact__c")
#     .filter(F.col("processDate") == ld_latest_process_date)
#     .drop("processDate")
# )

# Partners (and Microsoft) were migrated from Learndot to Docebo on a different dates than other branches. We will need to filter enrollments based on branch and migration date

first_migration_branches = ["DBK_PRTNR", "DBK_MCSFT"]
first_migration_date = "2021-12-08"
second_migration_date = "2022-01-07"

databricks_account_id = "0016100001FyvmIAAR"

microsoft_account_id = "00161000005eOdjAAE"
microsoft_account_name = "Microsoft"
microsoft_parent_account_id = "0014N00002BAYhLQAX"
microsoft_parent_account_name = "Microsoft Consulting Services"

# COMMAND ----------

#unit tests to make sure dfs are pulled correctly
assert unit_test_df_count(sfdc_accounts) > 0

# unit tests to make sure parameters are set up correctly
catalog, database = focus_database_name.split('.')
assert unit_test_valid_db(database, spark, catalog)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# Lead -> Mapped Account + Contact to Account Mapping
# Ignore the mapping for all contacts and leads that have domains that appear in Priyanka's sheet. 
# Create a domain to account repository using 1 and backing out blacklist domains. 
# Use this mapping to parse through unmapped learners
# For employee branch use branch for audience. Everything remains unchanged.
# For customer, microsoft, partner branch use top 5 domain rule. If domain mapped to partner account then "Partner" else "Customer or "Other" (mapped to an account with null account record type)
# If "Other" then update attribute to be Partner Other or Customer Other or MSFT Other based on branch
# For the remaining learners map to most common domain -> account pair. 

# COMMAND ----------

domain_window = W.Window.partitionBy("email_domain_final").orderBy(F.desc("total_emails"), "tiebreak")

customer_account_mapping = (
  docebo_users_gold
    .withColumn('email_domain_final', 
                F.when((F.col('email_domain').isin(blacklist)) & (~F.col('alternate_email_domain').isin(blacklist)), F.col('alternate_email_domain')).otherwise(F.col('email_domain')))
    .filter(F.col("account_name") != "Unknown")
    .filter(F.col("audience") == "Customer")
    .select('account_id', 'account_name', "email_domain_final", 'email_domain', 'alternate_email_domain')
    .filter(~F.col("email_domain_final").isin(blacklist))
    .groupBy(['account_id', "account_name", "email_domain_final"]).agg(F.count(F.col('email_domain_final')).alias('total_emails'))
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(domain_window))
    .filter(F.col("rank") == 1)
    .drop("total_emails", "tiebreak", "rank")
    
)

# COMMAND ----------

# # unique mappings all accounts

# account_window = W.Window.partitionBy("account_name").orderBy(F.desc("total_for_email_and_account"), "tiebreak")
# domain_window = W.Window.partitionBy("email_domain").orderBy(F.desc("total_emails"), "tiebreak")
# # domain_window = W.Window.partitionBy("email_domain").orderBy(F.asc("rank"), "tiebreak")


accounts_df = (
  sfdc_accounts
    .select(
      F.col("Id").alias("ultimate_parent_account_id"),
      F.col("Name").alias("ultimate_parent_account_name")
    )
)

account_names = (
  sfdc_accounts
    .select(
      F.col("Id").alias("account_id"),
      F.col("Name").alias("account_name"),
      F.col("ParentId").alias("ultimate_parent_account_id")
    )
    .join(accounts_df, "ultimate_parent_account_id", "left")
)


mapping_2_databricks = (
  salesforce_account_email_domain_mapping  
    # filter for databricks id
    .filter(F.col("account_id") == databricks_account_id)
    .filter(F.col("email_domain") == "databricks.com")
    # find most recent 
    .orderBy(F.col("account_last_modified_timestamp").desc())
    .limit(1)
    .select("email_domain", "account_id")
    .join(account_names, "account_id", "left")
    .withColumnRenamed('ultimate_parent_account_id', 'ultimate_parent_account_id_pre')
    .withColumnRenamed('ultimate_parent_account_name', 'ultimate_parent_account_name_pre')
    .withColumn('ultimate_parent_account_id', F.col('account_id'))
    .withColumn('ultimate_parent_account_name', F.col('account_name'))
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

mapping_2_microsoft = (
  salesforce_account_email_domain_mapping  
    # filter for databricks id
    .filter(F.col("account_id") == microsoft_account_id)
    .filter(F.col("email_domain") == "microsoft.com")
    # find most recent 
    .orderBy(F.col("account_last_modified_timestamp").desc())
    .limit(1)
    .select("email_domain", "account_id")
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)


# COMMAND ----------

docebo_learner_ids_accounts = (
  docebo_users_gold
    .select(
      F.col("id").alias("learner_user_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("learner_branch"),
      F.col("match_method")
    )
)

# COMMAND ----------

# partners and non partners were migrated at different times

docebo_self_paced_enrollments_partner = (
  docebo_self_paced_enrollments
    .filter(F.col("learner_branch_code").isin(first_migration_branches))
    .filter(F.col("enrolled_timestamp") >= first_migration_date)
)

docebo_self_paced_enrollments_not_partner = (
  docebo_self_paced_enrollments
    .filter(~F.col("learner_branch_code").isin(first_migration_branches))
    .filter(F.col("enrolled_timestamp") >= second_migration_date)
)

docebo_self_paced = (
  docebo_self_paced_enrollments_partner
    .union(docebo_self_paced_enrollments_not_partner)
)

docebo_ilt_enrollments_partner = (
  docebo_ilt_enrollments
    .filter(F.col("learner_branch_code").isin(first_migration_branches))
    .filter(F.col("enrolled_timestamp") >= first_migration_date)
)

docebo_ilt_enrollments_not_partner = (
  docebo_ilt_enrollments
    .filter(~F.col("learner_branch_code").isin(first_migration_branches))
    .filter(F.col("enrolled_timestamp") >= second_migration_date)
)

docebo_ilt = (
  docebo_ilt_enrollments_partner
    .union(docebo_ilt_enrollments_not_partner)
)

# COMMAND ----------

# enrollments with accounts

docebo_self_paced_enrollments_accounts = (
  docebo_self_paced
    .join(docebo_learner_ids_accounts, "learner_user_id", "left")
    .withColumn("source", F.lit("Docebo"))
    
)

docebo_ilt_enrollments_accounts = (
  docebo_ilt
    .join(docebo_learner_ids_accounts, "learner_user_id", "left")
    .withColumn("source", F.lit("Docebo"))
 
)

# COMMAND ----------

docebo_self_paced_enrollments_union_prep = (
  docebo_self_paced_enrollments_accounts
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"), 
      F.col("learner_alternate_email_2_domain"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

docebo_ilt_enrollments_union_prep = (
  docebo_ilt_enrollments_accounts
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      # F.col("learner_alternate_email_2").alias("learner_alternate_2_email"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"), 
      F.col("learner_alternate_email_2_domain"),
      F.col("learner_branch_code"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

email_window = W.Window.partitionBy("email_join").orderBy(F.desc("last_updated_timestamp"), "tiebreak")

docebo_user_emails_accounts = (
  docebo_users_gold
    .withColumn('email_join', F.when(F.col('email_domain').isin(blacklist), F.col('alternate_email_hash')).otherwise(F.col('email_hash')))
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(email_window))
    .filter(F.col("rank") == 1)
    .select(
      'email_join',
      'account_id', 
      'account_name', 
      'ultimate_parent_account_id',
      'ultimate_parent_account_name',
      'audience', 
      'country_code',
      'country_name',
      'match_method'
    )
)

# COMMAND ----------

# ld self paced customers

ld_self_paced_docebo_join = (
  ld_self_paced
    .join(docebo_user_emails_accounts.withColumnRenamed('email_join', 'learner_email_hash'), 'learner_email_hash', 'left')
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

ld_self_paced_account_found = (
  ld_self_paced_docebo_join
    .filter(F.col("account_name") != "Unknown")
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

ld_self_paced_account_not_found = (
  ld_self_paced_docebo_join
    .filter((F.col("account_name").isNull()) | (F.col("account_name") == "Unknown"))
    .drop('account_id',
          'account_name',
          'ultimate_parent_account_id',
          'ultimate_parent_account_name', 
          'country_code',
          'country_name',
          'audience',
          'match_method')
)


ld_self_paced_academy_users = (
  ld_self_paced_account_not_found
    .filter(~F.col("learner_email_domain").isin(partner_domains))
    .filter(~F.col("learner_email_domain").isin(['microsoft.com', 'databricks.com']))
    .join(customer_account_mapping.withColumnRenamed('email_domain_final', 'learner_email_domain'), 'learner_email_domain', 'left')
    .withColumn('audience', F.lit('Customer'))
    .withColumn('country_code', F.lit(None))
    .withColumn('country_name', F.lit(None))
    .withColumn('match_method', F.lit('docebo_users_customer_mapping'))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      # F.col("ultimate_parent_account_id"),
      # F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
    
)

ld_self_paced_academy_users_blacklist = (
  ld_self_paced_account_not_found
    .filter(F.col("learner_email_domain").isNull())
    .withColumn('account_name', F.lit("Unknown"))
    .withColumn('account_id', F.lit("Unknown"))
    .withColumn('audience', F.lit("Customer Other"))
    .withColumn('country_code', F.lit(None))
    .withColumn('country_name', F.lit(None))
    .withColumn('match_method', F.lit('no_match'))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      # F.col("ultimate_parent_account_id"),
      # F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

account_ultimate_parents = (
  sfdc_accounts
    .select(
      F.col("Id").alias('account_id'), 
      F.col("Ultimate_Parent_Account__c").alias('ultimate_parent_account_name'), 
      F.col("Ultimate_parent_account_casesafe_ID__c").alias("ultimate_parent_account_id")
    )
)

ld_self_paced_academy = (
  ld_self_paced_academy_users
    .union(ld_self_paced_academy_users_blacklist)
    .join(account_ultimate_parents, "account_id", "left")
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)


# COMMAND ----------

# ld ilt customers

ld_ilt_docebo_join = (
  ld_ilt
    .join(docebo_user_emails_accounts.withColumnRenamed('email_join', 'learner_email_hash'), 'learner_email_hash', 'left')
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_branch_code"),
      F.col("learner_branch"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

ld_ilt_account_found = (
  ld_ilt_docebo_join
    .filter(F.col("account_name") != "Unknown")
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_branch_code"),
      F.col("learner_branch"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

ld_ilt_account_not_found = (
  ld_ilt_docebo_join
    .filter((F.col("account_name").isNull()) | (F.col("account_name") == "Unknown"))
    .drop('account_id',
          'account_name',
          'ultimate_parent_account_id',
          'ultimate_parent_account_name',
          'audience', 
          'country_code',
          'country_name',
          'match_method'
          )
)


ld_ilt_academy_users = (
  ld_ilt_account_not_found
    .filter(~F.col("learner_email_domain").isin(partner_domains))
    .filter(~F.col("learner_email_domain").isin(['microsoft.com', 'databricks.com']))
    .join(customer_account_mapping.withColumnRenamed('email_domain_final', 'learner_email_domain'), 'learner_email_domain', 'left')
    .drop('audience')
    .withColumn('audience', F.lit('Customer'))
    .withColumn('country_code', F.lit(None))
    .withColumn('country_name', F.lit(None))
    .withColumn('match_method', F.lit('docebo_users_customer_mapping'))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_branch_code"),
      F.col("learner_branch"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      # F.col("ultimate_parent_account_id"),
      # F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

ld_ilt_academy_users_blacklist = (
  ld_ilt_account_not_found
    .filter(F.col("learner_email_domain").isNull())
    .drop('audience')
    .withColumn('account_name', F.lit("Unknown"))
    .withColumn('account_id', F.lit("Unknown"))
    .withColumn('audience', F.lit("Customer Other"))
    .withColumn('country_code', F.lit(None))
    .withColumn('country_name', F.lit(None))
    .withColumn('match_method', F.lit('no_match'))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_branch_code"),
      F.col("learner_branch"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      # F.col("ultimate_parent_account_id"),
      # F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

account_ultimate_parents = (
  sfdc_accounts
    .select(
      F.col("Id").alias('account_id'), 
      F.col("Ultimate_Parent_Account__c").alias('ultimate_parent_account_name'), 
      F.col("Ultimate_parent_account_casesafe_ID__c").alias("ultimate_parent_account_id")
    )
)

ld_ilt_academy = (
  ld_ilt_academy_users
    .union(ld_ilt_academy_users_blacklist)
    .join(account_ultimate_parents, "account_id", "left")
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_branch_code"),
      F.col("learner_branch"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)


# COMMAND ----------

# ld self paced partners

ld_self_paced_partners = (
  ld_self_paced_account_not_found
    .filter(F.col("learner_email_domain").isin(partner_domains))
    .join(partner_domains_df.withColumnRenamed('email_domain', 'learner_email_domain'), "learner_email_domain", "left")
    .withColumn('account_id',  F.col("ultimate_parent_account_id"))
    .withColumn('account_name',  F.col("ultimate_parent_account_name"))
    .withColumn('audience', F.lit('Partner'))
    .withColumn('country_code', F.lit(None))
    .withColumn('country_name', F.lit(None))
    .withColumn('match_method', F.lit('partner_ops_report'))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)


# COMMAND ----------

# ld ilt partners

ld_ilt_partners = (
  ld_ilt_account_not_found
    .filter(F.col("learner_email_domain").isin(partner_domains))
    .join(partner_domains_df.withColumnRenamed('email_domain', 'learner_email_domain'), "learner_email_domain", "left")
    .withColumn('account_id',  F.col("ultimate_parent_account_id"))
    .withColumn('account_name',  F.col("ultimate_parent_account_name"))
    .withColumn('audience', F.lit('Partner'))
    .withColumn('country_code', F.lit(None))
    .withColumn('country_name', F.lit(None))
    .withColumn('match_method', F.lit('partner_ops_report'))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_branch_code"),
      F.col("learner_branch"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)


# COMMAND ----------

# ld self paced microsoft

ld_self_paced_microsoft = (
  ld_self_paced_account_not_found
    .filter(F.col("learner_email_domain") == "microsoft.com")
    .join(mapping_2_microsoft.withColumnRenamed('email_domain_final', 'learner_email_domain'), "learner_email_domain", "left")
    .withColumn('audience', F.lit('Microsoft'))
    .withColumn('country_code', F.lit(None))
    .withColumn('country_name', F.lit(None))
    .withColumn('match_method', F.lit('hard_code_microsoft'))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

# ld ilt microsoft

ld_ilt_microsoft = (
  ld_ilt_account_not_found
    .filter(F.col("learner_email_domain") == "microsoft.com")
    .join(mapping_2_microsoft.withColumnRenamed('email_domain_final', 'learner_email_domain'), "learner_email_domain", "left")
    .withColumn('audience', F.lit('Microsoft'))
    .withColumn('country_code', F.lit(None))
    .withColumn('country_name', F.lit(None))
    .withColumn('match_method', F.lit('hard_code_microsoft'))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_branch_code"),
      F.col("learner_branch"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

# ld self paced databricks

ld_self_paced_databricks = (
  ld_self_paced_account_not_found
    .filter(F.col("learner_email_domain") == "databricks.com")
    .join(mapping_2_databricks.withColumnRenamed('email_domain_final', 'learner_email_domain'), "learner_email_domain", "left")
    .withColumn('audience', F.lit('Employee'))
    .withColumn('country_code', F.lit(None))
    .withColumn('country_name', F.lit(None))
    .withColumn('match_method', F.lit('hard_code_databricks'))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)


# COMMAND ----------

# ld ilt databricks

ld_ilt_databricks = (
  ld_ilt_account_not_found
    .filter(F.col("learner_email_domain") == "databricks.com")
    .join(mapping_2_databricks.withColumnRenamed('email_domain_final', 'learner_email_domain'), "learner_email_domain", "left")
    .withColumn('audience', F.lit('Employee'))
    .withColumn('country_code', F.lit(None))
    .withColumn('country_name', F.lit(None))
    .withColumn('match_method', F.lit('hard_code_databricks'))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_branch_code"),
      F.col("learner_branch"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)


# COMMAND ----------

ld_self_paced_accounts = (
  ld_self_paced_account_found
    .union(ld_self_paced_academy)
    .union(ld_self_paced_partners)
    .union(ld_self_paced_microsoft)
    .union(ld_self_paced_databricks)
)

ld_ilt_accounts = (
  ld_ilt_account_found
    .union(ld_ilt_academy)
    .union(ld_ilt_partners)
    .union(ld_ilt_microsoft)
    .union(ld_ilt_databricks)
)




# COMMAND ----------

ld_self_paced_enrollments_union_prep = (
  ld_self_paced_accounts
    .withColumn("learner_alternate_2_email", F.lit(None))
    .withColumn("learner_alternate_email_2_hash", F.lit(None))
    .withColumn("learner_alternate_email_2_domain", F.lit(None))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"), 
      F.col("learner_alternate_email_2_domain"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

ld_ilt_enrollments_union_prep = (
  ld_ilt_accounts
  .withColumn("learner_alternate_2_email", F.lit(None))
  .withColumn("learner_alternate_email_2_hash", F.lit(None))
  .withColumn("learner_alternate_email_2_domain", F.lit(None))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"), 
      F.col("learner_alternate_email_2_domain"),
      F.col("learner_branch_code"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

all_self_paced_enrollments = (
  ld_self_paced_enrollments_union_prep
    .union(docebo_self_paced_enrollments_union_prep)
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)



# COMMAND ----------

all_ilt_enrollments = (
  ld_ilt_enrollments_union_prep
    .union(docebo_ilt_enrollments_union_prep)
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

all_self_paced_enrollments_cleaned_accounts = (
  all_self_paced_enrollments
    .withColumnRenamed('ultimate_parent_account_id','ultimate_parent_account_id_raw')
    .withColumnRenamed('ultimate_parent_account_name','ultimate_parent_account_name_raw')
    .withColumn('ultimate_parent_account_id', F.coalesce('ultimate_parent_account_id_raw', 'account_id'))
    .withColumn('ultimate_parent_account_name', F.coalesce('ultimate_parent_account_name_raw', 'account_name'))
    .join(countries_regions, "country_code", "left")
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)  


all_ilt_enrollments_cleaned_accounts = (
  all_ilt_enrollments
    .withColumnRenamed('ultimate_parent_account_id','ultimate_parent_account_id_raw')
    .withColumnRenamed('ultimate_parent_account_name','ultimate_parent_account_name_raw')
    .withColumn('ultimate_parent_account_id', F.coalesce('ultimate_parent_account_id_raw', 'account_id'))
    .withColumn('ultimate_parent_account_name', F.coalesce('ultimate_parent_account_name_raw', 'account_name'))
    .join(countries_regions, "country_code", "left")
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

all_self_paced_enrollments_cleaned_accounts_alt_emails = (
  all_self_paced_enrollments_cleaned_accounts
    .withColumnRenamed('learner_alternate_email', 'learner_alternate_email_check')
    .withColumnRenamed('learner_alternate_email_hash', 'learner_alternate_email_hash_check')
    .withColumnRenamed('learner_alternate_email_domain', 'learner_alternate_email_domain_check')
    .withColumn('learner_alternate_email', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_2_email')).otherwise(F.col('learner_alternate_email_check')))
    .withColumn('learner_alternate_email_hash', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_email_2_hash')).otherwise(F.col('learner_alternate_email_hash_check')))
    .withColumn('learner_alternate_email_domain', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_email_2_domain')).otherwise(F.col('learner_alternate_email_domain_check')))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

all_ilt_enrollments_cleaned_accounts_alt_emails = (
  all_ilt_enrollments_cleaned_accounts
    .withColumnRenamed('learner_alternate_email', 'learner_alternate_email_check')
    .withColumnRenamed('learner_alternate_email_hash', 'learner_alternate_email_hash_check')
    .withColumnRenamed('learner_alternate_email_domain', 'learner_alternate_email_domain_check')
    .withColumn('learner_alternate_email', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_2_email')).otherwise(F.col('learner_alternate_email_check')))
    .withColumn('learner_alternate_email_hash', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_email_2_hash')).otherwise(F.col('learner_alternate_email_hash_check')))
    .withColumn('learner_alternate_email_domain', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_email_2_domain')).otherwise(F.col('learner_alternate_email_domain_check')))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)



# COMMAND ----------

all_self_paced_enrollments_cleaned_accounts_alt_emails_clean = (
  all_self_paced_enrollments_cleaned_accounts_alt_emails
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when((F.col("account_name") == "Unknown") & (F.col("audience_pre") == "Customer"), F.lit("Customer Other"))
                .when((F.col("account_name") == "Unknown") & (F.col("audience_pre") == "Partner"), F.lit("Partner Other"))
                .when((F.col("account_name") == "Unknown") & (F.col("audience_pre") == "Employee"), F.lit("Employee Other"))
                .when((F.col("account_name") == "Unknown") & (F.col("audience_pre") == "Microsoft"), F.lit("Microsoft Other"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Customer Other"), F.lit("Customer"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Partner Other"), F.lit("Partner"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Employee Other"), F.lit("Employee"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Microsoft Other"), F.lit("Microsoft"))
                .otherwise(F.col("audience_pre"))
                )
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
                
)

all_ilt_enrollments_cleaned_accounts_alt_emails_clean = (
  all_ilt_enrollments_cleaned_accounts_alt_emails
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when((F.col("account_name") == "Unknown") & (F.col("audience_pre") == "Customer"), F.lit("Customer Other"))
                .when((F.col("account_name") == "Unknown") & (F.col("audience_pre") == "Partner"), F.lit("Partner Other"))
                .when((F.col("account_name") == "Unknown") & (F.col("audience_pre") == "Employee"), F.lit("Employee Other"))
                .when((F.col("account_name") == "Unknown") & (F.col("audience_pre") == "Microsoft"), F.lit("Microsoft Other"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Customer Other"), F.lit("Customer"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Partner Other"), F.lit("Partner"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Employee Other"), F.lit("Employee"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Microsoft Other"), F.lit("Microsoft"))
                .otherwise(F.col("audience_pre"))
                )
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

all_ilt_enrollments_cleaned_accounts_alt_emails_clean_audience = (
  all_ilt_enrollments_cleaned_accounts_alt_emails_clean
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when((F.col("audience_pre") == "Customer Other") & (F.col("learner_branch_code") == "DBK_PRTNR"), F.lit("Partner Other"))
                .when((F.col("audience_pre") == "Customer Other") & (F.col("learner_branch_code") == "DBK_EMP"), F.lit("Employee Other"))
                .when((F.col("audience_pre") == "Customer Other") & (F.col("learner_branch_code") == "DBK_MCSFT"), F.lit("Microsoft Other"))
                .otherwise(F.col("audience_pre")))
    .withColumnRenamed('match_method', 'match_method_check')
    .withColumn('match_method', F.when(F.col('account_name') == "Unknown", F.lit('no_match')).otherwise(F.col('match_method_check')))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

all_self_paced_enrollments_cleaned_accounts_alt_emails_clean_audience = (
  all_self_paced_enrollments_cleaned_accounts_alt_emails_clean
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when((F.col("audience_pre") == "Customer Other") & (F.col("learner_branch_code") == "DBK_PRTNR"), F.lit("Partner Other"))
                .when((F.col("audience_pre") == "Customer Other") & (F.col("learner_branch_code") == "DBK_EMP"), F.lit("Employee Other"))
                .when((F.col("audience_pre") == "Customer Other") & (F.col("learner_branch_code") == "DBK_MCSFT"), F.lit("Microsoft Other"))
                .otherwise(F.col("audience_pre")))
    .withColumnRenamed('match_method', 'match_method_check')
    .withColumn('match_method', F.when(F.col('account_name') == "Unknown", F.lit('no_match')).otherwise(F.col('match_method_check')))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

all_ilt_enrollments_cleaned_accounts_alt_emails_clean_audience_msft_fix = (
  all_ilt_enrollments_cleaned_accounts_alt_emails_clean_audience
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", 
        F.when((F.col("audience").like("%Microsoft%")), F.lit(microsoft_account_id))
          .otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", 
        F.when(F.col("audience").like("%Microsoft%"), F.lit(microsoft_account_name))
          .otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", 
        F.when(F.col("audience").like("%Microsoft%"), F.lit(microsoft_parent_account_id))
          .otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", 
        F.when(F.col("audience").like("%Microsoft%"), F.lit(microsoft_parent_account_name))
          .otherwise(F.col("ultimate_parent_account_name_pre")))
    .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre")
)

all_self_paced_enrollments_cleaned_accounts_partition_msft_fix = (
  all_self_paced_enrollments_cleaned_accounts_alt_emails_clean_audience
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", 
        F.when((F.col("audience").like("%Microsoft%")), F.lit(microsoft_account_id))
          .otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", 
        F.when(F.col("audience").like("%Microsoft%"), F.lit(microsoft_account_name))
          .otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", 
        F.when(F.col("audience").like("%Microsoft%"), F.lit(microsoft_parent_account_id))
          .otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", 
        F.when(F.col("audience").like("%Microsoft%"), F.lit(microsoft_parent_account_name))
          .otherwise(F.col("ultimate_parent_account_name_pre")))
    .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre")
)

# COMMAND ----------

all_ilt_enrollments_cleaned_accounts_partition = add_gold_metadata(all_ilt_enrollments_cleaned_accounts_alt_emails_clean_audience_msft_fix)
all_self_paced_enrollments_cleaned_accounts_partition = add_gold_metadata(all_self_paced_enrollments_cleaned_accounts_partition_msft_fix)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_ilt_enrollments_cleaned_accounts_partition, 
  table_name = f'{focus_database_name}.ilt_enrollments_test', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_self_paced_enrollments_cleaned_accounts_partition, 
  table_name = f'{focus_database_name}.self_paced_enrollments_test', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)