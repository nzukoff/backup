# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for instructor utilzation from Airtable \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Workspace/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import requests

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

import pandas as pd


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

def convertToDF(data):
  """
    data is a list of objects
  """
  json_obj = {}
  
  json_obj['field'] = data

  df = pd.json_normalize(json_obj['field'])
  lst = list(df)
  df[lst] = df[lst].astype(str)

  spark_df = (
    spark
      .createDataFrame(df)
  )
  return spark_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### FY24 Instructors

# COMMAND ----------

airtable_pat = dbutils.secrets.get('ldr-airtable', 'airtable-token')

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Instructors?view=All%20Resources"
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

fy24_instructor_records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()


fy24_instructor_records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  fy24_instructor_records += response_json['records']

fy24_instructor_data = []
for record in fy24_instructor_records:
  fields = record['fields']
  if 'Instructor Email' in fields:
    instructor = {
      'id': record['id'],
      'email': fields['Instructor Email'],
      'organization_name': fields.get('Organization Name', ''),
      'location_country': fields.get('Country', '')
    }
    fy24_instructor_data.append(instructor)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### FY24 Base

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/ILT%20Schedule?view=%5BMASTER-ALL%5D%20Public%20%2B%20Private%20%7C%20ILT%20Schedule"
# headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()

# pprint(response_json)

records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  records += response_json['records']

fy24data = []
for record in records:
  fields = record['fields']
  row = {
    'num_enrollments': fields.get('# Enrollments', ''),
    'atp_or_internal_instructor': fields.get('ATP or Internal (from Instructor)', ''),
    'atp_or_internal_ta': fields.get('ATP or Internal (from TA)', ''),
    'account_based_training': fields.get('Account Based Training', ''),
    'attendance_checked_private': fields.get('Attendance Checked (Private Only)', ''),
    'audience': fields.get('Audience', ''),
    'calendar_invitation_private_only': fields.get('Calendar Invitation (Private Only)', ''),
    'class_duration_days': fields.get('Class Duration (Days)', ''),
    'class_duration_hours': fields.get('Class Duration (Hours)', ''),
    'class_time': fields.get('Class Time', ''),
    'completed_customer_onsite_prep_sheet': fields.get('Completed Customer Onsite Prep Sheet', ''),
    # 'created_by_email': fields['Created By'].get('email', ''),
    # 'created_by_name': fields.get['Created By'].get('name', ''),
    # 'created_date': fields.get('Created Date', ''),
    'customer_onsite_prep_sheet': fields.get('Customer Onsite Prep Sheet', ''),
    'dates': fields.get('Dates', ''),
    'docebo_end_time': fields.get('Docebo - End Time', ''),
    'docebo_start_time': fields.get('Docebo - Start Time', ''),
    'end_date': fields.get('End Date', ''),
    'fy': fields.get('FY', ''),
    'goal_utilization': fields.get('GoalUtilization', ''),
    'ilt_name': fields.get('ILT Name', ''),
    'instructor': fields.get('Instructor', ''),
    'instructor_and_ta_assignments': fields.get('Instructor + TA Assignments', ''),
    'landing_page': fields.get('Landing Page', ''),
    'last_modified': fields.get('Last Modified', ''),
    'location_from_private_training_request_queue': fields.get('Location (from [PRIVATE] Training Request Queue)', ''),
    'modality': fields.get('Modality', ''),
    'month': fields.get('Month', ''),
    'notes': fields.get('Notes', ''),
    'onsite_instructor_expenses': fields.get('Onsite Instructor Expenses', ''),
    'payment_type_from_training_request_queue': fields.get('Payment Type (from [PRIVATE] Training Request Queue)', ''),
    'preferred_video_conference_tool': fields.get('Preferred Video Conference Tool (from [PRIVATE] Training Request Queue)', ''),
    'project_type': fields.get('Project Type', ''),
    'projects': fields.get('Projects', ''),
    'provider': fields.get('Provider', ''),
    'provider_2': fields.get('Provider (2)', ''),
    'quarter': fields.get('Quarter', ''),
    'quarter_fy': fields.get('Quarter + FY', ''),
    'region': fields.get('Region', ''),
    'revenue_from_revenue_cc_from_all_enrollments': fields.get('Revenue (from Revenue (CC)) (from All Enrollments)', ''),
    'revenue_credit_card': fields.get('Revenue: Credit Card', ''),
    'revenue_pre_purchased_credits': fields.get('Revenue: Pre-purchased Credits', ''),
    'roster': fields.get('Roster', ''),
    'sfdc_airtable_projects': fields.get('SFDC <> Airtable Projects', ''),
    'send_survey_results': fields.get('Send Survey Results?', ''),
    'slack_access': fields.get('Slack Access? (from [PRIVATE] Training Request Queue)', ''),
    'start_date': fields.get('Start Date', ''),
    'status': fields.get('Status', ''),
    'tas': fields.get('TA', ''),
    'time': fields.get('Time', ''),
    'timezone': fields.get('Timezone', ''),
    'total_revenue': fields.get('Total Revenue', ''),
    'training_type': fields.get('Training Type', ''),
    'username_from_all_enrollments': fields.get('Username (from All Enrollments)', ''),
    'temp_enterprise_workspaces': fields.get('We provision temporary enterprise Databricks workspaces for the duration of the training course. This way, every user has the same permission levels and Databricks covers the cost of DBUs/VMs for the training. (from [PRIVATE] Training Request Queue)', ''),
    'week_num_end_date': fields.get('Week # - End Date', ''),
    'which_preferred_video_conference_platform': fields.get('Which is your preferred video conference platform? Our default tool is Zoom (test access here). If you would like to use MSFT Teams, you will need to set up your own Teams meeting and share that information with us. (from [PRIVATE] Training Request Queue)', ''),
    'workspace_url': fields.get('Workspace URL (from Workspace URL)', ''),
    'year': fields.get('Year', ''),
    'aws_workspace_anticipated_deleted_date': fields.get('[AWS] Workspace Anticipated Deleted Date', ''),
    'aws_workspace_url': fields.get('[AWS] Workspace URL', ''),
    'end_date_core_series': fields.get('[Automation] End Date - Core Series', ''),
    'cloudlabs_azure_request_id': fields.get('[CLOUDLABS-AZURE] Request ID', ''),
    'cloudlabs_azure_workspace_activation_link': fields.get('[CLOUDLABS-AZURE] Workspace Activation Code', ''),
    'cloudlabs_azure_workspace_signup_link': fields.get('[CLOUDLABS-AZURE] Workspace Signup Link', ''),
    'cloudlabs_azure_workspace_url': fields.get('[CLOUDLABS-AZURE] Workspace URL', ''),
    'cloudlabs_workspace_provisioned': fields.get('[CLOUDLABS] Workspace Provisioned?', ''),
    'company_contanct_email': fields.get('[COMPANY] Contact Email', ''),
    'company_contanct_name': fields.get('[COMPANY] Contact Name', ''),
    'company_name': fields.get('[COMPANY] Name', ''),
    'docebo_class_created': fields.get('[DOCEBO] Class Created?', ''),
    'docebo_session_code': fields.get('[DOCEBO] Session Code', ''),
    'docebo_session_url_internal': fields.get('[DOCEBO] Session URL (internal)', ''),
    'ff_psa_budget_id': fields.get('[FF-PSA] Budget ID', ''),
    'ff_psa_long_project_id': fields.get('[FF-PSA] Long_Project ID', ''),
    'ff_psa_milestone_id': fields.get('[FF-PSA] Milestone ID', ''),
    'ff_psa_revenue': fields.get('[FF-PSA] Revenue (from [PUBLIC] Training Request Queue)', ''),
    'form_end_date': fields.get('[FORM] End Date', ''),
    'form_ilt_name': fields.get('[FORM] ILT Name', ''),
    'form_start_date': fields.get('[FORM] Start Date', ''),
    'location_address': fields.get('[LOCATION] Address', ''),
    'lookup_ilt_name': fields.get('[LOOKUP] ILT Name (from [PUBLIC] Training Request Queue)', ''),
    'ops_slack_setup': fields.get('[OPS] Slack Setup', ''),
    'private_training_request_queue': fields.get('[PRIVATE] Training Request Queue', ''),
    'public_training_request_queue': fields.get('[PUBLIC] Training Request Queue', ''),
    'resources_meeting_link': fields.get('[RESOURCES] Meeting Link', ''),
    'resources_slack_link': fields.get('[RESOURCES] Slack Link', ''),
    'resources_survey_link': fields.get('[RESOURCES] Survey Link', ''),
    'resources_survey_results': fields.get('[RESOURCES] Survey Results', ''),
    'sfdc_blanket_opporunity_case_id': fields.get('[SFDC] Blanket Opportunity CaseID', ''),
    'sfdc_name_date': fields.get('[SFDC] Name: Date', ''),
    'sfdc_pr_name_course_name_abbreviation': fields.get('[SFDC] PR Name: Course Name Abbreviation', ''),
    'sfdc_pr_name_region_timezone': fields.get('[SFDC] PR Name: Region + Timezone', ''),
    'sfdc_pr_region': fields.get('[SFDC] PR Region', ''),
    'sfdc_project_id_chain': fields.get('[SFDC] Project ID + ID Chain', ''),
    'sfdc_project_manager': fields.get('[SFDC] Project Manager', ''),
    'sfdc_project_url': fields.get('[SFDC] Project URL', ''),
    'sfdc_short_project_id': fields.get('[SFDC] Short_Project ID', ''),
    'sfdc_milestone_id': fields.get('[SFDC] Milestone ID',''), #new field
    'tray_io_session_name': fields.get('[Tray.io] Session Name', ''),
    'meeting_platform': fields.get('Meeting Platform', ''),
    'line_of_business': fields.get('LOB (Line of Business)'),
    'academy_session_number': fields.get('Academy Session #',''),
    'atp_or_internal_text': fields.get('ATP or Internal (Text)', ''), #new field
    'atp_or_fte': fields.get('ATPxFTE', ''), #new field
    'available_hours': fields.get('Available Hours',''), #new field
    'cohort_start_date': fields.get('Cohort Start Date',''), #new field
    'course_abbreviation_from_course_or_project': fields.get('Course Abbreviation (from Course/Project)',''), #new field
    'course_dates': fields.get('Course Dates',''), #new field
    'course_duration_hours': fields.get('Course Duration (Hours)', ''), #new field
    'course_duration_days': fields.get('Course Duration (Days)',''), #new field
    'course_name': fields.get('Course Name',''), #new field
    'course_times': fields.get('Course Times',''), #new field
    'course_type': fields.get('Course Type',''), #new field
    'course_or_project': fields.get('Course/Project',''), #new field
    # 'created_by_email': fields['Created By'].get('email', ''),
    # 'created_by_name': fields.get['Created By'].get('name', ''),
    # 'created_by_id': fields.get['Created By'].get('id', ''), #new field
    # 'created_date': fields.get('Created Date', ''),
    'db_zoom_control_reporting': fields.get('DB Zoom? [Control Reporting]'), #new field
    'form_end_date': fields.get('End Date [FORM]', ''), #field_changed
    'monday_hours': fields.get('Monday Hours', ''), #new field
    'tuesday_hours': fields.get('Tuesday Hours', ''), #new field
    'wednesday_hours': fields.get('Wednesday Hours', ''), #new field
    'thursday_hours': fields.get('Thursday Hours', ''), #new field
    'friday_hours': fields.get('Friday Hours', ''), #new field
    'half_day_units': fields.get('HDUs', ''), #new field
    'ilt_duration_in_days': fields.get('ILT Duration (Days)', ''), #new field
    'ilt_duration_in_hours': fields.get('ILT Duration (Hours)', ''), #new field
    'form_ilt_name': fields.get('ILT Name [FORM]', ''), #field_changed
    'ilt_readiness': fields.get('ILT Readiness'),  #new field
    'instructor_led_training_project_name': fields.get('Instructor Led Training / Project Name', ''), #new field
    'language': fields.get('Language',''), #new field
    'revenue_skus': fields.get('Revenue: SKUs', ''), #new field
    'form_start_date': fields.get('Start Date [FORM]', ''), #field_changed
    'StartDoW': fields.get('StartDoW',''), #new field
    'preferred_video_conference_tool': fields.get('Preferred Video Conference Tool', ''),  #field_changed
    'academy_class_creation': fields.get('Academy Class Creation', ''), #new field
    'academy_session_url_internal': fields.get('Academy Session URL (internal)', ''), #new field
    'company_name': fields.get('Company Name', ''),  #new field
    'current_registrations': fields.get('Current Registrations', ''), #new field
    'metrics_docebo_creation_date': fields.get('[METRICS] Docebo Creation Date', ''), #new field
    'metrics_meeting_link_creation': fields.get('[METRICS] Meeting Link Creation', ''), #new field
    'metrics_survey_link_creation': fields.get('[METRICS] Survey Link Creation', ''), #new field
    'metrics_slack_creation': fields.get('[METRICS] Slack Creation', ''), #new field
    'training_request_queue': fields.get('Training Request Queue', ''), #new field
    'revenue_milestone_amount': fields.get('Revenue: Milestone Amount'), #new field
    'company_contact_name': fields.get('Company Contact Name', ''), #new field
    'company_contact_email': fields.get('Company Contact Email', ''), #new field
    'calendar_invite': fields.get('Calendar Invite', ''), #new field
    'payment_type_from_training_request_queue': fields.get('Payment Type (from Training Request Queue)', ''), #new field
    'slack_access': fields.get('Slack Access?', ''), #new field
    'location_address': fields.get('Location Address', ''), #new field
    'attachment_customer_onsite_prep_sheet': fields.get('Attachment] Customer Onsite Prep Sheet', '') #new field
    



  }
  fy24data.append(row)

for d in fy24data:
  d['instructor_email'] = [ins['email'] for ins in fy24_instructor_data if ins['id'] in d['instructor']]
  d['instructor_location_or_country'] = [ins['location_country'] for ins in fy24_instructor_data if ins['id'] in d['instructor']]
  d['ta_emails'] = [ins['email'] for ins in fy24_instructor_data if ins['id'] in d['tas']]
  d['instructor_and_ta_assignment_emails'] = [ins['email'] for ins in fy24_instructor_data if ins['id'] in d['instructor_and_ta_assignments']]
  d['instructor_organization_name'] = [ins['organization_name'] for ins in fy24_instructor_data if ins['id'] in d['instructor']]
fy24base = convertToDF(fy24data)
fy24base.createOrReplaceTempView('fy24base')

# COMMAND ----------

# pprint(records[0:100])
# for record in records:
#   if record['id'] == 'rec3vA38fT6p2NaWr':
#     pprint(record)

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/ILT%20Schedule?view=%5BMASTER-ALL%5D%20Public%20%2B%20Private%20%7C%20ILT%20Schedule"
# headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

records2 = []
response2 = requests.request("GET", url, headers=headers)
response_json2 = response2.json()

# pprint(response_json)

records2 += response_json2['records']
while 'offset' in response_json2:
  response2 = requests.request("GET", url+f"&offset={response_json2['offset']}", headers=headers)
  response_json2 = response2.json()
  records2 += response_json2['records']

fy25data = []
for record in records2:
  fields = record['fields']
  row = {
    'num_enrollments': fields.get('# Enrollments', ''),
    'atp_or_internal_text': fields.get('ATP or Internal (Text)', ''),
    'atp_or_internal_instructor': fields.get('ATP or Internal (from Instructor)', ''),
    'atp_or_internal_ta': fields.get('ATP or Internal (from TA)', ''),
    'atp_or_fte': fields.get('ATPxFTE', ''), #new field
    'academy_session_number': fields.get('Academy Session #',''),
    'account_based_training': fields.get('Account Based Training', ''),
    'attendance_checked_private': fields.get('Attendance Checked (Private Only)', ''),
    'audience': fields.get('Audience', ''),
    'available_hours': fields.get('Available Hours',''), #new field
    'class_time': fields.get('Class Time', ''),
    'completed_customer_onsite_prep_sheet': fields.get('Completed Customer Onsite Prep Sheet', ''),
    'course_duration_hours': fields.get('Course Duration (Hours)', ''), #new field
    'cohort_start_date': fields.get('Cohort Start Date',''), #new field
    'course_abbreviation_from_course_or_project': fields.get('Course Abbreviation (from Course/Project)',''), #new field
    'course_dates': fields.get('Course Dates',''), #new field
    'course_duration_days': fields.get('Course Duration (Days)',''), #new field
    'course_name': fields.get('Course Name',''), #new field
    'course_times': fields.get('Course Times',''), #new field
    'course_type': fields.get('Course Type',''), #new field
    'course_or_project': fields.get('Course/Project',''), #new field
    # 'created_by_email': fields['Created By'].get('email', ''),
    # 'created_by_name': fields.get['Created By'].get('name', ''),
    # 'created_by_id': fields.get['Created By'].get('id', ''), #new field
    # 'created_date': fields.get('Created Date', ''),
    'customer_onsite_prep_sheet': fields.get('Customer Onsite Prep Sheet', ''),
    'db_zoom_control_reporting': fields.get('DB Zoom? [Control Reporting]'), #new field
    'docebo_end_time': fields.get('Docebo - End Time', ''),
    'docebo_start_time': fields.get('Docebo - Start Time', ''),
    'end_date': fields.get('End Date', ''),
    'form_end_date': fields.get('End Date [FORM]', ''), #field_changed
    'fy': fields.get('FY', ''),
    'monday_hours': fields.get('Monday Hours', ''),
    'tuesday_hours': fields.get('Tuesday Hours', ''),
    'wednesday_hours': fields.get('Wednesday Hours', ''),
    'thursday_hours': fields.get('Thursday Hours', ''),
    'friday_hours': fields.get('Friday Hours', ''),
    'half_day_units': fields.get('HDUs', ''),
    'ilt_duration_in_days': fields.get('ILT Duration (Days)', ''),
    'ilt_duration_in_hours': fields.get('ILT Duration (Hours)', ''),
    'form_ilt_name': fields.get('ILT Name [FORM]', ''),
    'ilt_readiness': fields.get('ILT Readiness'),
    'instructor': fields.get('Instructor', ''),
    'instructor_and_ta_assignments': fields.get('Instructor + TA Assignments', ''),
    'landing_page': fields.get('Landing Page', ''),
    'last_modified': fields.get('Last Modified', ''),
    'instructor_led_training_project_name': fields.get('Instructor Led Training / Project Name', ''),
    'line_of_business': fields.get('LOB (Line of Business)',''),
    'language': fields.get('Language',''),
    'meeting_platform': fields.get('Meeting Platform', ''),
    'modality': fields.get('Modality', ''),
    'month': fields.get('Month', ''),
    'notes': fields.get('Notes', ''),
    'onsite_instructor_expenses': fields.get('Onsite Instructor Expenses', ''),
    'ops_slack_setup': fields.get('[OPS] Slack Setup', ''),
    'project_type': fields.get('Project Type', ''),
    'projects': fields.get('Projects', ''),
    'provider': fields.get('Provider', ''),
    'provider_2': fields.get('Provider (2)', ''),
    'quarter': fields.get('Quarter', ''),
    'quarter_fy': fields.get('Quarter + FY', ''),
    'revenue_credit_card': fields.get('Revenue: Credit Card', ''),
    'revenue_skus': fields.get('Revenue: SKUs', ''),
    'roster': fields.get('Roster', ''),
    'sfdc_airtable_projects': fields.get('SFDC <> Airtable Projects', ''),
    'send_survey_results': fields.get('Send Survey Results?', ''),
    'start_date': fields.get('Start Date', ''),
    'status': fields.get('Status', ''),
    'tas': fields.get('TA', ''),
    'form_start_date': fields.get('Start Date [FORM]', ''),
    'StartDoW': fields.get('StartDoW',''),
    'total_revenue': fields.get('Total Revenue', ''),
    'training_type': fields.get('Training Type', ''),
    'week_num_end_date': fields.get('Week # - End Date', ''),
    'preferred_video_conference_tool': fields.get('Preferred Video Conference Tool', ''),
    'year': fields.get('Year', ''),
    'end_date_core_series': fields.get('[Automation] End Date - Core Series', ''),
    'sfdc_blanket_opporunity_case_id': fields.get('[SFDC] Blanket Opportunity CaseID', ''),
    'sfdc_name_date': fields.get('[SFDC] Name: Date', ''),
    'sfdc_pr_name_region_timezone': fields.get('[SFDC] PR Name: Region + Timezone', ''),
    'sfdc_pr_region': fields.get('[SFDC] PR Region', ''),
    'sfdc_project_id_chain': fields.get('[SFDC] Project ID + ID Chain', ''),
    'sfdc_project_manager': fields.get('[SFDC] Project Manager', ''),
    'sfdc_project_url': fields.get('[SFDC] Project URL', ''),
    'sfdc_short_project_id': fields.get('[SFDC] Short_Project ID', ''),
    'region': fields.get('Region', ''),
    'timezone': fields.get('Timezone', ''),
    'academy_class_creation': fields.get('Academy Class Creation', ''),
    'academy_session_url_internal': fields.get('Academy Session URL (internal)', ''),
    'cloudlabs_workspace_provisioned': fields.get('[CLOUDLABS] Workspace Provisioned?', ''),
    'cloudlabs_azure_workspace_signup_link': fields.get('[CLOUDLABS-AZURE] Workspace Signup Link', ''),
    'cloudlabs_azure_workspace_activation_link': fields.get('[CLOUDLABS-AZURE] Workspace Activation Code', ''),
    'cloudlabs_azure_workspace_url': fields.get('[CLOUDLABS-AZURE] Workspace URL', ''),
    'cloudlabs_azure_request_id': fields.get('[CLOUDLABS-AZURE] Request ID', ''),
    'resources_meeting_link': fields.get('[RESOURCES] Meeting Link', ''),
    'resources_slack_link': fields.get('[RESOURCES] Slack Link', ''),
    'resources_survey_link': fields.get('[RESOURCES] Survey Link', ''),
    'resources_survey_results': fields.get('[RESOURCES] Survey Results', ''),
    'company_name': fields.get('Company Name', ''),
    'ff_psa_long_project_id': fields.get('[FF-PSA] Long_Project ID', ''),
    'current_registrations': fields.get('Current Registrations', ''),
    'metrics_docebo_creation_date': fields.get('[METRICS] Docebo Creation Date', ''),
    'metrics_meeting_link_creation': fields.get('[METRICS] Meeting Link Creation', ''),
    'metrics_survey_link_creation': fields.get('[METRICS] Survey Link Creation', ''),
    'metrics_slack_creation': fields.get('[METRICS] Slack Creation', ''),


  }
  fy25data.append(row)

for d in fy25data:
  d['instructor_email'] = [ins['email'] for ins in fy24_instructor_data if ins['id'] in d['instructor']]
  d['instructor_location_or_country'] = [ins['location_country'] for ins in fy24_instructor_data if ins['id'] in d['instructor']]
  d['ta_emails'] = [ins['email'] for ins in fy24_instructor_data if ins['id'] in d['tas']]
  d['instructor_and_ta_assignment_emails'] = [ins['email'] for ins in fy24_instructor_data if ins['id'] in d['instructor_and_ta_assignments']]
  d['instructor_organization_name'] = [ins['organization_name'] for ins in fy24_instructor_data if ins['id'] in d['instructor']]
fy25base = convertToDF(fy25data)
fy25base.createOrReplaceTempView('fy25base')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### FY23 Instructors

# COMMAND ----------

url = "https://api.airtable.com/v0/app2xcFKwnbjBWatZ/Instructors?view=All%20Instructors"
# headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

fy23_instructor_records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()

fy23_instructor_records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  fy23_instructor_records += response_json['records']

fy23_instructor_data = []
for record in fy23_instructor_records:
  fields = record['fields']
  instructor = {
    'id': record['id'],
    'email': fields['Instructor Email']
  }
  fy23_instructor_data.append(instructor)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### FY23 Base

# COMMAND ----------

url = "https://api.airtable.com/v0/app2xcFKwnbjBWatZ/ILT%20Schedule?view=MASTER%20-%20ALL%20TRAINING%20"
# headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()

records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  records += response_json['records']



fy23data = []
for record in records:
  fields = record['fields']
  row = {
    'num_enrollments': fields.get('# Enrollments', ''),
    'atp_or_internal': fields.get('ATP or Internal (from Instructor)', ''),
    'created_date': fields.get('Created Date'),
    'dates': fields.get('Dates', ''),
    'end_date': fields.get('End Date', ''),
    'fy': fields.get('FY', ''),
    'ilt_name': fields.get('ILT Name', ''),
    'instructor': fields.get('Instructor', ''),
    'month': fields.get('Month', ''),
    'projects': fields.get('Projects', ''),
    'provider': fields.get('Provider', ''),
    'quarter': fields.get('Quarter', ''),
    'quarter_fy': fields.get('Quarter + FY', ''),
    'credit_card_revenue': fields.get('Revenue (CC)', ''),
    'pre_purchased_credits_revenue': fields.get('Revenue - Public (Non CC)', ''),
    'start_date': fields.get('Start Date', ''),
    'status': fields.get('Status', ''),
    'tas': fields.get('TA', ''),
    'time': fields.get('Time', ''),
    'timezone': fields.get('Timezone', ''),
    'total_revenue': fields.get('Total Revenue', ''),
    'training_type': fields.get('Training Type', ''),
    'year': str(fields.get('Year', '')),
    'docebo_session_code': fields.get('[DOCEBO] Session Code', ''),
    'sfdc_project_id': fields.get('[SFDC] Project Long ID', ''),
    'sfdc_project_id_chain': fields.get('[SFDC] Project ID + ID Chain', '')
    }
  
  fy23data.append(row)

for d in fy23data:
  d['instructor_email'] = [ins['email'] for ins in fy23_instructor_data if ins['id'] in d['instructor']]
  d['ta_emails'] = [ins['email'] for ins in fy23_instructor_data if ins['id'] in d['tas']]

fy23base = convertToDF(fy23data)
fy23base.createOrReplaceTempView('fy23base')

# COMMAND ----------

instructor_utilization = spark.sql('''
  select 
    num_enrollments,
    atp_or_internal_instructor,
    atp_or_internal_ta,
    atp_or_internal_text, --1
    atp_or_fte, --2
    account_based_training,
    attendance_checked_private,
    audience,
    available_hours, --3
    calendar_invitation_private_only, --4
    class_duration_days, --5
    class_duration_hours, --6
    class_time,
    completed_customer_onsite_prep_sheet,
    customer_onsite_prep_sheet, 
    course_duration_hours, --8
    course_duration_days, --9
    cohort_start_date, --10
    course_abbreviation_from_course_or_project, --11
    course_dates, --12
    course_name, --13
    course_times, --14
    course_type, --15
    course_or_project, --16
    db_zoom_control_reporting, --17
    dates, --59
    docebo_end_time,
    docebo_start_time,
    end_date,
    fy,
    half_day_units, --IMP
    monday_hours, --18
    tuesday_hours, --19
    wednesday_hours, --20
    thursday_hours, --21
    friday_hours, --22
    goal_utilization, --23
    ilt_duration_in_days, --24
    ilt_duration_in_hours, --25
    ilt_name, --26
    landing_page,
    last_modified,
    language, --27
    location_from_private_training_request_queue, --28
    modality,
    month,
    notes,
    -- onsite_instructor_expenses,
    payment_type_from_training_request_queue, --58
    preferred_video_conference_tool,
    project_type,
    projects,
    provider,
    provider_2,
    quarter,
    quarter_fy,
    region,
    revenue_skus, --30
    revenue_from_revenue_cc_from_all_enrollments, --31
    revenue_credit_card,
    revenue_pre_purchased_credits, --32
    -- roster,
    -- sfdc_airtable_projects,
    send_survey_results,
    slack_access, --33
    start_date,
    status,
    time, --34
    timezone,
    total_revenue,
    training_type,
    username_from_all_enrollments, --39
    temp_enterprise_workspaces, --40
    week_num_end_date,
    which_preferred_video_conference_platform, --35
    workspace_url, --36
    year,
    aws_workspace_anticipated_deleted_date, --59
    -- aws_workspace_url,
    end_date_core_series,
    academy_class_creation, --37
    academy_session_url_internal, --38
    cloudlabs_azure_request_id,
    cloudlabs_azure_workspace_activation_link,
    cloudlabs_azure_workspace_signup_link,
    cloudlabs_azure_workspace_url,
    cloudlabs_workspace_provisioned,
    company_contanct_email, --42
    company_contanct_name, --43
    company_name,
    docebo_class_created, --44
    docebo_session_code, --45
    docebo_session_url_internal, --41
    ff_psa_budget_id, --46
    ff_psa_long_project_id,
    ff_psa_milestone_id, --47
    ff_psa_revenue, --48
    form_end_date,
    form_ilt_name,
    form_start_date,
    location_address, --49
    lookup_ilt_name, --50
    -- ops_slack_setup,
    -- private_training_request_queue,
    -- public_training_request_queue,
    resources_meeting_link,
    resources_slack_link,
    resources_survey_link,
    resources_survey_results,
    sfdc_blanket_opporunity_case_id,
    sfdc_name_date,
    sfdc_pr_name_course_name_abbreviation, --51
    sfdc_milestone_id,
    sfdc_pr_name_region_timezone,
    sfdc_pr_region,
    sfdc_project_id_chain,
    sfdc_project_manager,
    sfdc_project_url,
    sfdc_short_project_id,
    tray_io_session_name, --52
    meeting_platform,
    line_of_business,
    academy_session_number,
    instructor_email,
    ta_emails,
    instructor_and_ta_assignment_emails,
    instructor_organization_name,
    instructor_location_or_country,
    current_registrations, -- 53
    metrics_docebo_creation_date, --54
    metrics_meeting_link_creation, --55
    metrics_survey_link_creation, --56
    metrics_slack_creation, --57
    'FY24' as airtable_base
  from fy24base
  union all 
  select 
    num_enrollments,
    atp_or_internal as atp_or_internal_instructor,
    '' as atp_or_internal_ta,
    '' as atp_or_internal_text, --1
    '' as atp_or_fte, --2
    '' as account_based_training,
    '' as attendance_checked_private,
    '' as audience,
    '' as available_hours, --3
    '' as calendar_invitation_private_only, --4
    '' as class_duration_days, --5
    '' as class_duration_hours, --6
    '' as class_time,
    '' as completed_customer_onsite_prep_sheet,
    '' as customer_onsite_prep_sheet,
    '' as course_duration_hours, --8
    '' as course_duration_days, --9
    '' as cohort_start_date, --10
    '' as course_abbreviation_from_course_or_project, --11
    '' as course_dates, --12
    '' as course_name, --13
    '' as course_times, --14
    '' as course_type, --15
    '' as course_or_project, --16
    '' as db_zoom_control_reporting, --17
    '' as dates, --59
    '' as docebo_end_time,
    '' as docebo_start_time,
    '' as end_date,
    '' as fy,
    '' as half_day_units, --IMP
    '' as monday_hours, --18
    '' as tuesday_hours, --19
    '' as wednesday_hours, --20
    '' as thursday_hours, --21
    '' as friday_hours, --22
    '' as goal_utilization, --23
    '' as ilt_duration_in_days, --24
    '' as ilt_duration_in_hours, --25
    '' as ilt_name, --26
    '' as landing_page,
    '' as last_modified,
    '' as language, --27
    '' as location_from_private_training_request_queue, --28
    '' as modality,
    '' as month,
    '' as notes,
    -- '' as onsite_instructor_expenses,
    '' as payment_type_from_training_request_queue, --58
    '' as preferred_video_conference_tool,
    '' as project_type,
    projects,
    provider,
    '' as provider_2,
    '' as quarter,
    '' as quarter_fy,
    '' as region,
    '' as revenue_skus, --30
    '' as revenue_from_revenue_cc_from_all_enrollments, --31
    credit_card_revenue as revenue_credit_card,
    pre_purchased_credits_revenue as revenue_pre_purchased_credits, --32
    -- '' as roster,
    -- '' as sfdc_airtable_projects,
    '' as send_survey_results,
    '' as slack_access, --33
    start_date,
    status,
    '' as time, --34
    timezone,
    total_revenue,
    training_type,
    '' as username_from_all_enrollments, --39
    '' as temp_enterprise_workspaces, --40
    '' as week_num_end_date,
    '' as which_preferred_video_conference_platform, --35
    '' as workspace_url, --36
    year,
    '' as aws_workspace_anticipated_deleted_date, --59
    -- '' as aws_workspace_url,
    '' as end_date_core_series,
    '' as academy_class_creation, --37
    '' as academy_session_url_internal, --38
    '' as cloudlabs_azure_request_id,
    '' as cloudlabs_azure_workspace_activation_link,
    '' as cloudlabs_azure_workspace_signup_link,
    '' as cloudlabs_azure_workspace_url,
    '' as cloudlabs_workspace_provisioned,
    '' as company_contanct_email, --42
    '' as company_contanct_name, --43
    '' as company_name,
    '' as docebo_class_created, --44
    docebo_session_code, --45
    '' as docebo_session_url_internal, --41
    '' as ff_psa_budget_id, --46
    sfdc_project_id as ff_psa_long_project_id,
    '' as ff_psa_milestone_id, --47
    '' as ff_psa_revenue, --48
    '' as form_end_date,
    '' as form_ilt_name,
    '' as form_start_date,
    '' as location_address, --49
    '' as lookup_ilt_name, --50
    -- '' as ops_slack_setup,
    -- '' as private_training_request_queue,
    -- '' as public_training_request_queue,
    '' as resources_meeting_link,
    '' as resources_slack_link,
    '' as resources_survey_link,
    '' as resources_survey_results,
    '' as sfdc_blanket_opporunity_case_id,
    '' as sfdc_name_date,
    '' as sfdc_pr_name_course_name_abbreviation, --51
    '' as sfdc_milestone_id,
    '' as sfdc_pr_name_region_timezone,
    '' as sfdc_pr_region,
    sfdc_project_id_chain,
    '' as sfdc_project_manager,
    '' as sfdc_project_url,
    '' as sfdc_short_project_id,
    '' as tray_io_session_name, --52
    '' as meeting_platform,
    '' as line_of_business,
    '' as academy_session_number,
    instructor_email,
    ta_emails, 
    '' as instructor_and_ta_assignment_emails,
    '' as instructor_organization_name,
    '' as instructor_location_or_country,
    '' as current_registrations, -- 53
    '' as metrics_docebo_creation_date, --54
    '' as metrics_meeting_link_creation, --55
    '' as metrics_survey_link_creation, --56
    '' as metrics_slack_creation, --57
    'FY23' as airtable_base
  from fy23base
''')


# COMMAND ----------

instructor_utilization2 = spark.sql('''
  select 
    num_enrollments,
    atp_or_internal_instructor,
    atp_or_internal_ta,
    atp_or_internal_text, --1
    atp_or_fte, --2
    account_based_training,
    attendance_checked_private,
    audience,
    available_hours, --3
    -- calendar_invitation_private_only, --4
    -- class_duration_days, --5
    -- class_duration_hours, --6
    class_time,
    completed_customer_onsite_prep_sheet,
    customer_onsite_prep_sheet, 
    course_duration_hours, --8
    course_duration_days, --9
    cohort_start_date, --10
    course_abbreviation_from_course_or_project, --11
    course_dates, --12
    course_name, --13
    course_times, --14
    course_type, --15
    course_or_project, --16
    db_zoom_control_reporting, --17
    -- dates, --59
    docebo_end_time,
    docebo_start_time,
    end_date,
    fy,
    half_day_units, --IMP
    monday_hours, --18
    tuesday_hours, --19
    wednesday_hours, --20
    thursday_hours, --21
    friday_hours, --22
    -- goal_utilization, --23
    ilt_duration_in_days, --24
    ilt_duration_in_hours, --25
    -- ilt_name, --26
    landing_page,
    last_modified,
    language, --27
    -- location_from_private_training_request_queue, --28
    modality,
    month,
    notes,
    -- onsite_instructor_expenses,
    -- payment_type_from_training_request_queue, --58
    preferred_video_conference_tool,
    project_type,
    projects,
    provider,
    provider_2,
    quarter,
    quarter_fy,
    region,
    revenue_skus, --30
    -- revenue_from_revenue_cc_from_all_enrollments, --31
    revenue_credit_card,
    -- revenue_pre_purchased_credits, --32
    -- roster,
    -- sfdc_airtable_projects,
    send_survey_results,
    -- slack_access, --33
    start_date,
    status,
    -- time, --34
    timezone,
    total_revenue,
    training_type,
    -- username_from_all_enrollments, --39
    -- temp_enterprise_workspaces, --40
    week_num_end_date,
    -- which_preferred_video_conference_platform, --35
    -- workspace_url, --36
    year,
    -- aws_workspace_anticipated_deleted_date, --59
    -- aws_workspace_url,
    end_date_core_series,
    academy_class_creation, --37
    academy_session_url_internal, --38
    cloudlabs_azure_request_id,
    cloudlabs_azure_workspace_activation_link,
    cloudlabs_azure_workspace_signup_link,
    cloudlabs_azure_workspace_url,
    cloudlabs_workspace_provisioned,
    -- company_contanct_email, --42
    -- company_contanct_name, --43
    company_name,
    -- docebo_class_created, --44
    -- docebo_session_code, --/--45
    -- docebo_session_url_internal, --41
    -- ff_psa_budget_id, 46
    ff_psa_long_project_id,
    -- ff_psa_milestone_id, --47
    -- ff_psa_revenue, --48
    form_end_date,
    form_ilt_name,
    form_start_date,
    -- location_address, --49
    -- lookup_ilt_name, --50
    -- ops_slack_setup,
    -- private_training_request_queue,
    -- public_training_request_queue,
    resources_meeting_link,
    resources_slack_link,
    resources_survey_link,
    resources_survey_results,
    sfdc_blanket_opporunity_case_id,
    sfdc_name_date,
    -- sfdc_pr_name_course_name_abbreviation, --51
    sfdc_pr_name_region_timezone,
    sfdc_pr_region,
    sfdc_project_id_chain,
    sfdc_project_manager,
    sfdc_project_url,
    sfdc_short_project_id,
    -- tray_io_session_name, --52
    meeting_platform,
    line_of_business,
    academy_session_number,
    instructor_email,
    ta_emails,
    instructor_and_ta_assignment_emails,
    instructor_organization_name,
    instructor_location_or_country,
    current_registrations, -- 53
    metrics_docebo_creation_date, --54
    metrics_meeting_link_creation, --55
    metrics_survey_link_creation, --56
    metrics_slack_creation, --57
    'FY24' as airtable_base
  from fy25base
  union all 
  select 
    num_enrollments,
    atp_or_internal as atp_or_internal_instructor,
    '' as atp_or_internal_ta,
    '' as atp_or_internal_text, --1
    '' as atp_or_fte, --2
    '' as account_based_training,
    '' as attendance_checked_private,
    '' as audience,
    '' as available_hours, --3
    -- '' as calendar_invitation_private_only, --4
    -- '' as class_duration_days, --5
    -- '' as class_duration_hours, --6
    '' as class_time,
    '' as completed_customer_onsite_prep_sheet,
    '' as customer_onsite_prep_sheet,
    '' as course_duration_hours, --8
    '' as course_duration_days, --9
    '' as cohort_start_date, --10
    '' as course_abbreviation_from_course_or_project, --11
    '' as course_dates, --12
    '' as course_name, --13
    '' as course_times, --14
    '' as course_type, --15
    '' as course_or_project, --16
    '' as db_zoom_control_reporting, --17
    -- '' as dates, --59
    '' as docebo_end_time,
    '' as docebo_start_time,
    '' as end_date,
    '' as fy,
    '' as half_day_units, --IMP
    '' as monday_hours, --18
    '' as tuesday_hours, --19
    '' as wednesday_hours, --20
    '' as thursday_hours, --21
    '' as friday_hours, --22
    -- '' as goal_utilization, --23
    '' as ilt_duration_in_days, --24
    '' as ilt_duration_in_hours, --25
    -- '' as ilt_name, --26
    '' as landing_page,
    '' as last_modified,
    '' as language, --27
    -- '' as location_from_private_training_request_queue, --28
    '' as modality,
    '' as month,
    '' as notes,
    -- '' as onsite_instructor_expenses,
    -- '' as payment_type_from_training_request_queue, --58
    '' as preferred_video_conference_tool,
    '' as project_type,
    projects,
    provider,
    '' as provider_2,
    '' as quarter,
    '' as quarter_fy,
    '' as region,
    '' as revenue_skus, --30
    -- '' as revenue_from_revenue_cc_from_all_enrollments, --31
    credit_card_revenue as revenue_credit_card,
    -- pre_purchased_credits_revenue as revenue_pre_purchased_credits, --32
    -- '' as roster,
    -- '' as sfdc_airtable_projects,
    '' as send_survey_results,
    -- '' as slack_access, --33
    start_date,
    status,
    -- '' as time, --34
    timezone,
    total_revenue,
    training_type,
    -- '' as username_from_all_enrollments, --39
    -- '' as temp_enterprise_workspaces, --40
    '' as week_num_end_date,
    -- '' as which_preferred_video_conference_platform, --35
    -- '' as workspace_url, --36
    year,
    -- '' as aws_workspace_anticipated_deleted_date, --59
    -- '' as aws_workspace_url,
    '' as end_date_core_series,
    '' as academy_class_creation, --37
    '' as academy_session_url_internal, --38
    '' as cloudlabs_azure_request_id,
    '' as cloudlabs_azure_workspace_activation_link,
    '' as cloudlabs_azure_workspace_signup_link,
    '' as cloudlabs_azure_workspace_url,
    '' as cloudlabs_workspace_provisioned,
    -- '' as company_contanct_email, --42
    -- '' as company_contanct_name, --43
    '' as company_name,
    -- '' as docebo_class_created, --44
    -- docebo_session_code, --/--45
    -- '' as docebo_session_url_internal, --41
    -- '' as ff_psa_budget_id, --46
    sfdc_project_id as ff_psa_long_project_id,
    -- '' as ff_psa_milestone_id, --47
    -- '' as ff_psa_revenue, --48
    '' as form_end_date,
    '' as form_ilt_name,
    '' as form_start_date,
    -- '' as location_address, --49
    -- '' as lookup_ilt_name, --50
    -- '' as ops_slack_setup,
    -- '' as private_training_request_queue,
    -- '' as public_training_request_queue,
    '' as resources_meeting_link,
    '' as resources_slack_link,
    '' as resources_survey_link,
    '' as resources_survey_results,
    '' as sfdc_blanket_opporunity_case_id,
    '' as sfdc_name_date,
    -- '' as sfdc_pr_name_course_name_abbreviation, --51
    '' as sfdc_pr_name_region_timezone,
    '' as sfdc_pr_region,
    sfdc_project_id_chain,
    '' as sfdc_project_manager,
    '' as sfdc_project_url,
    '' as sfdc_short_project_id,
    -- '' as tray_io_session_name, --52
    '' as meeting_platform,
    '' as line_of_business,
    '' as academy_session_number,
    instructor_email,
    ta_emails, 
    '' as instructor_and_ta_assignment_emails,
    '' as instructor_organization_name,
    '' as instructor_location_or_country,
    '' as current_registrations, -- 53
    '' as metrics_docebo_creation_date, --54
    '' as metrics_meeting_link_creation, --55
    '' as metrics_survey_link_creation, --56
    '' as metrics_slack_creation, --57
    'FY23' as airtable_base
  from fy23base
''')


# COMMAND ----------

instructor_utilization_gold = add_gold_metadata(instructor_utilization)

# COMMAND ----------

instructor_utilization2_gold = add_gold_metadata(instructor_utilization2)

# COMMAND ----------

# MAGIC %md
# MAGIC #Instructor Skills Data

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Instructor%20Skills%20&%20Credentials?view=Instructor%20Skills%20(By%20Instructor)"
# headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

records = [] 
response = requests.request("GET", url, headers=headers)
response_json = response.json()
# print(response_json)

records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  records += response_json['records']
# pprint(records)

# COMMAND ----------



# COMMAND ----------

instructors_skills_data = []
for record in records:
  fields = record['fields']
  row = {
    'instructor_email': fields.get('Instructor Email',''),
    'course_name': fields.get('Course Name',''),
    'complete_date': fields.get('Complete Date',''),
    'status': fields.get('Status',''),
    'instructor': fields.get('Instructor',''),
    'course_type_from_course_name': fields.get('Course Type (from Course Name)',''),
    'atp_or_internal': fields.get('ATP or Internal',''),
    'region_from_nstructor': fields.get('Region (from Instructor)',''),
    'is_active_from_instructor': fields.get('Active? (from Instructor)',''),
    'languages_from_instructor': fields.get('Languages (from Instructor)',''),
    'country_from_instructor': fields.get('Country (from Instructor)',''),
    'status_from_instructor': fields.get('Status (from Instructor)',''),
    'created': fields.get('Created',''),
    'atp_or_internal_from_instructor': fields.get('ATP or Internal (from Instructor)',''),
    'accredible_url': fields.get('Accredible URL',''),
    'scheduling_poc': fields.get('Scheduling POC',''),
    'ramping_start_date': fields.get('Ramping Start Date',''),
    'trainer_notes': fields.get('Trainer Notes',''),
    'cert_expiration_date': fields.get('Cert Expiration Date',''),
    'ramping_goal_date': fields.get('Ramping Goal Date',''),
    'mentor_instructor': fields.get('Mentor (Instructor)',''),
    }
  
  instructors_skills_data.append(row)

instructors_skills_base = convertToDF(instructors_skills_data)

# COMMAND ----------

instructors_skills_data_gold = add_gold_metadata(instructors_skills_base)

# COMMAND ----------

# MAGIC %md
# MAGIC #Utilisation Goals Data

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Utilization%20Goals?view=Grid%20view"
# headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

records = [] 
response = requests.request("GET", url, headers=headers)
response_json = response.json()
# print(response_json)

records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  records += response_json['records']
# pprint(records)

# COMMAND ----------

utilization_goals_data = []
for record in records:
  fields = record['fields']
  row = {
    'fte_staffing_level': fields.get('FTE Staffing Level', ''),
    'available_trainers': fields.get('Available Trainers', ''),
    'total_hours': fields.get('Total hours', ''),
    'total_hdus': fields.get('Total HDUs',''),
    'fte_goal': fields.get('P60-FTEGoal',''),
    'atp_goal': fields.get('P60-ATPGoal',''),
    }
  
  utilization_goals_data.append(row)

utilization_goals_base = convertToDF(utilization_goals_data)
utilization_goals_base.createOrReplaceTempView('utilization_goals_data')

# COMMAND ----------

utilization_goals_data_df = spark.sql(
    """
  select 
    fte_staffing_level,
    available_trainers,
    total_hours,
    total_hdus,
    fte_goal,
    atp_goal,
    replace(split(d.fiscal_year_quarter, ' ')[0], "'", "") as fy,
    -- split(d.fiscal_year_quarter, ' ')[0] as fy,
    split(d.fiscal_year_quarter, ' ')[1] as quarter
  from utilization_goals_data u
  left join main.it_core_dim.dim_dates d on u.fte_staffing_level::date = d.date
"""
)

# COMMAND ----------

instructor_utilization_goals_data_gold = add_gold_metadata(utilization_goals_data_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = instructor_utilization_gold, 
  table_name = f'{focus_database_name}.training_operations_ilt_schedule_master', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = instructor_utilization2_gold, 
  table_name = f'{focus_database_name}.revised_training_operations_ilt_schedule_master', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = instructors_skills_data_gold, 
  table_name = f'{focus_database_name}.training_operations_ilt_instructors_and_skills_data', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = instructor_utilization_goals_data_gold, 
  table_name = f'{focus_database_name}.training_operations_instructor_utilization_goals_data', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)