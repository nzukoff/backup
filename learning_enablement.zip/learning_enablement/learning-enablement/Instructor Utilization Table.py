# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             ATP Utilization \
# MAGIC **Description:**     This notebook gives the data for the ATP Utilization for the Cost Centers 643 and 704 \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

# MAGIC %run "/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

from datetime import date

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# %sql
# -- # instructor_utilization_data_df = spark.sql('''
# select *,
#   int(half_day_units) as half_day_units
#  from main.field_learning_enablement.training_operations_ilt_schedule_master
# where processDate = '2024-07-12'
# -- # ''')


# COMMAND ----------

instructor_utilization_data_df = spark.sql('''
with airtable_ilt_data as (
select 
REPLACE(REPLACE(REPLACE(instructor_email, '[', ''), ']', ''), "'") as instructor_email,
--int(half_day_units) as half_day_units,
int(half_day_units)*size(split(instructor_email,',')) half_day_units,
academy_session_number,
ta_emails,
instructor_and_ta_assignment_emails,
REPLACE(REPLACE(REPLACE(instructor_organization_name, '[', ''), ']', ''), "'") as instructor_organization_name,
REPLACE(REPLACE(REPLACE(instructor_location_or_country, '[', ''), ']', ''), "'") AS instructor_country,
atp_or_internal_instructor,
-- case 
--     when contains(atp_or_internal_instructor, 'ATP') then 'ATP'
--     when contains(atp_or_internal_instructor, 'Internal') then 'Internal'
--     else 
-- end as atp_or_internal_instructor,
atp_or_internal_text,
case 
  when atp_or_fte = '' then 'Not Specified'
  else nvl(atp_or_fte, 'Not Specified') 
end as atp_or_fte,
num_enrollments,
audience,
class_time,
int(REPLACE(REPLACE(REPLACE(course_duration_hours, '[', ''), ']', ''), "'")) as course_duration_hours,
int(REPLACE(REPLACE(REPLACE(course_duration_days, '[', ''), ']', ''), "'")) as course_duration_days,
cohort_start_date,
start_date::date,
end_date::date,
course_abbreviation_from_course_or_project,
course_dates,
course_name,
course_times,
-- REPLACE(REPLACE(REPLACE(course_type, '[', ''), ']', ''), "'") as course_type,
case 
  when contains(course_type, 'ILT') then 'ILT'
  when contains(course_type, 'Half-Day') then 'Half-Day'
  when course_type = "" then "Not Mentioned"
  else REPLACE(REPLACE(REPLACE(course_type, '[', ''), ']', ''), "'")
  end as course_type,
course_or_project,
db_zoom_control_reporting,
docebo_start_time::timestamp,
docebo_end_time::timestamp,
month,
quarter,
quarter_fy,
fy,
year,
int(year) as int_year,
monday_hours,
tuesday_hours,
wednesday_hours,
thursday_hours,
friday_hours,
ilt_duration_in_hours,
ilt_duration_in_days,
language,
projects,
provider,
provider_2,
case 
  when region = '' then 'Not Mentioned'
  else nvl(region, 'Not Mentioned') 
end as region,
revenue_skus,
revenue_credit_card,
status,
total_revenue,
-- milestone_amount as revenue,
training_type,
academy_class_creation,
academy_session_url_internal,
company_name,
ff_psa_long_project_id,
form_start_date,
form_end_date,
form_ilt_name,
sfdc_blanket_opporunity_case_id,
sfdc_name_date,
sfdc_pr_name_region_timezone,
sfdc_pr_region,
sfdc_project_id_chain,
sfdc_project_manager,
sfdc_short_project_id,
current_registrations,
metrics_docebo_creation_date,
airtable_base,
line_of_business,
-- -- TODO: Check with Nathan whether this logic still works
--   case when line_of_business = 'Customer (Paid)' then 704
--     when line_of_business = 'User Enablement (Free)' and atp_or_int_instructor = 'ATP' then 643
--     when line_of_business = 'User Enablement (Free)' and atp_or_int_instructor = 'Internal' then 704
--     -- when line_of_business = 'Internal Teach' then 704
--     when line_of_business = 'Partner (Free)' and atp_or_int_instructor = 'ATP' then 643
--     when line_of_business = 'Partner (Free)' and atp_or_int_instructor = 'Internal' then 704
--     -- Instructor Not Available
--     -- Holiday
-- end as Cost_Center,
notes
-- case 
--     when contains(session_name, 'Language: ')
--     then trim(initcap(lower(trim(split(session_name, 'Language: ')[1]))))
--     when contains(project_type, 'Language ')
--     then trim(initcap(lower(trim(split(project_type, ': ')[1]))))
--     when contains(notes, 'Language in') 
--     then trim(initcap(lower(trim(split(notes, 'Language in ')[1]))))
--     when contains(notes, 'Language: ')
--     then trim(initcap(lower(trim(split(notes, 'Language: ')[1]))) )
--     else 'English'
--   end as session_language

from main.field_learning_enablement.revised_training_operations_ilt_schedule_master
  where processDate = (select max(processDate) from main.field_learning_enablement.revised_training_operations_ilt_schedule_master)
)
,
courses as (
  select 
    d.course_name, 
    d.course_code, 
    d.session_name, 
    d.code
    -- min(started_timestamp::date) as started_date, 
    -- count(distinct learner_user_id) as total_enrollments 
    from main.it_training_silver.docebo_ilt_sessions d
  -- left join main.field_learning_enablement.ilt_enrollments i on i.course_code = d.course_code and i.processDate = (select max(processDate) from main.field_learning_enablement.ilt_enrollments)
  where d.processDate = (select max(processDate) from main.it_training_silver.docebo_ilt_sessions)
  -- group by all
)
,
all_data as (
select session_name,
d.course_name as ilt_course_name, 
-- course_code,
-- started_date,
-- case 
--     when contains(session_name, 'Language: ')
--     then trim(initcap(lower(trim(split(session_name, 'Language: ')[1]))))
--     -- when contains(project_type, 'Language ')
--     -- then trim(initcap(lower(trim(split(project_type, ': ')[1]))))
--     when contains(notes, 'Language in') 
--     then trim(initcap(lower(trim(split(notes, 'Language in ')[1]))))
--     when contains(notes, 'Language: ')
--     then trim(initcap(lower(trim(split(notes, 'Language: ')[1]))) )
--     else 'English'
--   end as course_language,
-- end_date - start_date as no_of_days,
e.*
from airtable_ilt_data e
left join courses d on (d.course_name = e.projects and e.academy_session_number = d.code)
-- where status = 'Completed'
)
select  distinct * from all_data
where line_of_business not in ('Instructor Not Available', 'Holiday')
''')


# COMMAND ----------

instructor_utilization_gold = add_gold_metadata(instructor_utilization_data_df)

# COMMAND ----------

display(instructor_utilization_gold)
# null	null	luca.gennari@databricks.com, mark.ott@databricks.com	1	0	['jessamyn.evans@databricks.com']	['jessamyn.evans@databricks.com', 'luca.gennari@databricks.com', 'mark.ott@databricks.com']	Instructors (FTE), Instructors (FTE)	Spain, USA	['Internal - Instructors (FTE)', 'Internal - Instructors (FTE)']	Internal - Instructors (FTE);Internal - Instructors (FTE)	FTE	0	DAIS	09:00-13:00	8	1	June 10, 2024	2024-06-10	2024-06-10	['DAWD']	June 10, 2024 to June 10, 2024	['Data Analysis with Databricks SQL']	09:00AM - 01:00PM	ILT	['recI07UqTnIDzht6v']	No	2024-08-09T09:00:00.000+00:00	2024-08-09T13:00:00.000+00:00	06	Q2	FY25-Q2	FY25	2024.0	4.0	0.0	0.0	0.0	0.0	4.0	1.0	English	Data Analysis with Databricks SQL	Databricks	Databricks	AMER	0.0	0	Completed	0.0	Conference					2024-06-10	2024-06-10	Jun10 [PT - LOS ANGELES] | Data Analysis with Databricks SQL () - 		Jun10	AMER-WEST	a4c61000000PQGFAA4		0054N000003pN92QAE				FY24	Customer (Paid)		2024-07-31

# COMMAND ----------

# DBTITLE 1,Instructor and Course Analytics Query

all_atp_utilization_data_df = spark.sql('''
with all_ilt_data as (
select 

  REPLACE(REPLACE(REPLACE(instructor_email, '[', ''), ']', ''), "'") AS instructor_email,
  REPLACE(REPLACE(REPLACE(instructor_location_or_country, '[', ''), ']', ''), "'") AS instructor_country,
  instructor_location_or_country,

  REPLACE(REPLACE(REPLACE(ta_emails, '[', ''), ']', ''), "'") AS ta_emails,
  
  atp_or_internal_instructor,
  academy_session_number,

  case 
    when contains(atp_or_internal_instructor, 'ATP') then 'ATP'
    when contains(e.provider, 'ATP') then 'ATP'
    when contains(atp_or_internal_instructor, 'Internal') then 'Internal'
    when contains(e.provider, 'Databricks') then 'Internal'

    -- then split(split(REPLACE(REPLACE(REPLACE(atp_or_internal_instructor, '[', ''), ']', ''), "'"), ' ')[0], '-')[0]
    when contains(atp_or_internal_instructor, 'None') then 'None'
    when contains(atp_or_internal_instructor, 'Independent') then 'ATP' -- need to check if this is ATP or Internal
  end as atp_or_int_instructor,

  atp_or_internal_ta,
  
  case when line_of_business = 'Customer (Paid)' then 704
    when line_of_business = 'User Enablement (Free)' and atp_or_int_instructor = 'ATP' then 643
    when line_of_business = 'User Enablement (Free)' and atp_or_int_instructor = 'Internal' then 704
    when line_of_business = 'Internal Teach' then 704
    when line_of_business = 'Partner (Free)' and atp_or_int_instructor = 'ATP' then 643
    when line_of_business = 'Partner (Free)' and atp_or_int_instructor = 'Internal' then 704
  end as Cost_Center,
  
  -- d.name,
  -- d.code,
  
  docebo_end_time::timestamp,
  docebo_start_time::timestamp,
  
  start_date::date,
  end_date::date,
  
  fy,
  d.calendar_year,
  d.calendar_year_month,
  d.fiscal_year_quarter,
  int(year) as year,
  quarter,
  quarter_fy,
  
  notes,
  projects,
  project_type,

  e.provider,
  provider_2,
  region,
  trim(split(timezone, '-')[1]) as location,
  

  -- add language from docebo session names
  -- add country/location from the new location data in ilt_schedule_master

  case 
  when lower(location) = 'mumbai/kolkata' then 'India'
  when lower(location) = 'chicago' then 'US'
  when lower(location) = 'denver' then 'US'
  when lower(location) = 'hong kong' then 'China'
  when lower(location) = 'london' then 'UK'
  when lower(location) = 'los angeles' then 'US'
  when lower(location) = 'new york' then 'US'
  when lower(location) = 'paris' then 'France'
  when lower(location) = 'sydney' then 'Australia'
  when lower(location) = 'tokyo' then 'Japan'
  when lower(location) = 'uk' then 'UK'
  else initcap(location) end
  as Country,
  status,
  timezone,
  training_type,
  docebo_session_code,
  instructor_and_ta_assignment_emails,
  line_of_business,
  milestone_amount as revenue,
  airtable_base,

  REPLACE(REPLACE(REPLACE(instructor_organization_name, '[', ''), ']', ''), "'") AS instructor_organization_name
  from 
  main.field_learning_enablement.training_operations_ilt_schedule_master e
  left join main.it_core_dim.dim_dates d on d.`date` = e.start_date
  left join main.field_learning_enablement.training_milestones t on t.class_custom_id = e.academy_session_number
  and t.processDate = (select max(processDate) from main.field_learning_enablement.training_milestones)
  where e.processDate = (select max(processDate) from main.field_learning_enablement.training_operations_ilt_schedule_master) 
  -- and status = 'Completed'

)
,
courses as (
  select d.course_name, d.course_code, d.session_name, d.code, min(started_timestamp::date) as started_date, count(distinct learner_user_id) as total_enrollments from main.it_training_silver.docebo_ilt_sessions d
  left join main.field_learning_enablement.ilt_enrollments i on i.course_code = d.course_code and i.processDate = (select max(processDate) from main.field_learning_enablement.ilt_enrollments)
  where d.processDate = (select max(processDate) from main.it_training_silver.docebo_courses)
  group by all
)
  
, 
all_data as (
select session_name,
 course_name, 
course_code,
started_date,
case 
    when contains(session_name, 'Language: ')
    then trim(initcap(lower(trim(split(session_name, 'Language: ')[1]))))
    when contains(project_type, 'Language ')
    then trim(initcap(lower(trim(split(project_type, ': ')[1]))))
    when contains(notes, 'Language in') 
    then trim(initcap(lower(trim(split(notes, 'Language in ')[1]))))
    when contains(notes, 'Language: ')
    then trim(initcap(lower(trim(split(notes, 'Language: ')[1]))) )
    else 'English'
  end as Language,
end_date - start_date as no_of_days,
e.*
from all_ilt_data e
left join courses d on (d.course_name = e.projects and e.academy_session_number = d.code)
-- where status = 'Completed'
)

select * from all_data
-- where Language <> 'English'
-- and academy_session_number = 11296
-- where atp_or_int_instructor <> 'None'
where Cost_Center is not null
-- and revenue is null
-- and Contains(line_of_business, "Paid")
''')


# COMMAND ----------


atp_utilization_gold = add_gold_metadata(all_atp_utilization_data_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.field_learning_enablement.instructor_utilization
# MAGIC where processDate = '2024-10-09'

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = instructor_utilization_gold, 
  table_name = f'{focus_database_name}.instructor_utilization', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

# DBTITLE 1,ATP Utilization Delta Writer
write_delta_table(
  spark, 
  dataframe = atp_utilization_gold, 
  table_name = f'{focus_database_name}.atp_utilization', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

