# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
# from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import json
import requests
from pprint import pprint
from urllib.parse import quote_plus as urlencode
import pandas as pd

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# DBTITLE 1,Google Sheets Audit Handler
try:
  sht = authGoogleSheet("Account Mapping Audit")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')

  
try:
  worksheet = sht.worksheet("Exclude")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "Account Mapping Audit",
 "Exclude",
 "exlude_pdf",
 clean_column_names="true", 
 make_columns_unique="true"
)

exclude_df_raw = (spark.sql("""select * from exlude_pdf"""))

# COMMAND ----------

# DBTITLE 1,Google Sheet Access Validator
try:
  sht = authGoogleSheet("Account Mapping Audit")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')

  
try:
  worksheet = sht.worksheet("Exclude")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "Account Mapping Audit",
 "Exclude",
 "exlude_pdf",
 clean_column_names="true", 
 make_columns_unique="true"
)

exclude_df_raw = (spark.sql("""select * from exlude_pdf"""))
exclude_df = exclude_df_raw.select('exclude_domains').filter(F.col("exclude_domains").isNotNull())
exclude_df.createOrReplaceTempView('exclude_df')



# COMMAND ----------

import time
time.sleep(2)

# COMMAND ----------

# DBTITLE 1,Worksheet Inclusion Processor
try:
  worksheet = sht.worksheet("Include")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "Account Mapping Audit",
 "Include",
 "include_worksheet",
 clean_column_names="true", 
 make_columns_unique="true"
)

include_pdf = (spark.sql("""select * from include_worksheet"""))
include_list = [d['include_domains'] for d in include_pdf.select(F.col('include_domains')).collect()]

# COMMAND ----------

display(include_pdf)

# COMMAND ----------

# DBTITLE 1,Domain Filtering and User Mapping
# Blacklisted domains

blacklist_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.blacklist_domains",  "processDate")

blacklist_domains = (
  spark.read.table(f"{focus_database_name}.blacklist_domains")
    .filter(F.col("processDate") == blacklist_latest_process_date)
)

blacklist = [domain["blacklist_domain"] for domain in blacklist_domains.collect()]


# Docebo Logfood data
silver_docebo_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_users",  "processDate")

docebo_users = (
  spark.read.table("main.it_training_silver.docebo_users")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

salesforce_account_email_domain_mapping_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_salesforce_account_email_domain_mapping",  "processDate")


salesforce_account_email_domain_mapping = (
  spark.read.table("main.it_training_silver.docebo_salesforce_account_email_domain_mapping")
    .filter(~F.col("account_name").isin('Individual LMS Account', 'Individual LMS Account(Generic)', 'SFDC Test Customer', 'Databricks Partners Test'))
    .filter(F.col("processDate") == salesforce_account_email_domain_mapping_process_date)
    .drop("processDate")
)

# COMMAND ----------

# DBTITLE 1,Email Domain Mapping Ranker
mapping_window = W.Window.partitionBy("email_domain").orderBy(F.desc("total_for_email_and_account"), "tiebreak")

include_partner_domains = (
    salesforce_account_email_domain_mapping
    # filter for partner domains
    .filter(F.col("account_record_type") == "Partner")
    # filter out null domains
    .filter(F.col("email_domain").isNotNull())
    # find most common account for each domain
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(mapping_window))
    .filter(F.col("rank") == 1)
    # .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain"), 
      F.col("account_id").alias("ultimate_parent_account_id"),
      F.col("account_name").alias("ultimate_parent_account_name")
    )
    .filter(F.col("email_domain").isin(include_list))
)

# COMMAND ----------

# DBTITLE 1,Daugherty Domain Union Query
#exception_df = spark.sql('''
#  select 'daugherty.pl' as email_domain, '0018Y00002qS0CEQA0' as ultimate_parent_account_id, 'Daugherty Business Solutions' as utlimate_parent_account_name
#  union all 
#  select 'daugherty.pa' as email_domain, '0018Y00002qS0CEQA0' as ultimate_parent_account_id, 'Daugherty Business Solutions' as utlimate_parent_account_name
#  union all 
#  select 'daugherty.com' as email_domain, '0018Y00002qS0CEQA0' as ultimate_parent_account_id, 'Daugherty Business Solutions' as utlimate_parent_account_name
#  -- union all 
#  -- select 'milliman.com' as email_domain, '0016100000d0N03AAE' as ultimate_parent_account_id, 'MILLIMAN' as utlimate_parent_account_name
#''') # Commented based on JIRA request https://databricks.atlassian.net/browse/ESO-238

# COMMAND ----------

exception_df = spark.sql('''
  -- select 'neudesic.com' as email_domain, '0014N00001ip6SSQAY' as ultimate_parent_account_id, 'Neudesic' as utlimate_parent_account_name
  -- union all -- Commented out based on Request from Andrea to revert the change
  select 'daugherty.pa' as email_domain, '0016100001QciS7AAJ' as ultimate_parent_account_id, 'Conseillers en Gestion et Informatique CGI Inc. (HQ)' as utlimate_parent_account_name
  union all 
  select 'jump.dev.br' as email_domain, '0014N00001irNkOQAU' as ultimate_parent_account_id, 'Jump Label Solutions' as utlimate_parent_account_name
  union all
  select 'opsguru.com' as email_domain, '0018Y00002fq0anQAA' as ultimate_parent_account_id, 'OpsGuru Canada, Inc' as utlimate_parent_account_name
''') # Added based on JIRA request https://databricks.atlassian.net/browse/ESO-238 and https://databricks.atlassian.net/browse/ESO-251

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### Partner Domains

# COMMAND ----------

# DBTITLE 1,Filtered Partner Account Analysis
parter_domains_accounts = spark.sql('''
  with data as (
  select
    a.name as account_name, 
    a.Partner_Type__c, 
    a.partner_status__c,  
    u.Username,
    u.Email, 
    u.accountid as account_id,
    --a.Ultimate_Parent_Account__c as ultimate_parent_account_name,
    a1.name as ultimate_parent_account_name,
    a.Ultimate_parent_account_casesafe_ID__c as ultimate_parent_account_id,
    a.LastModifiedDate,
    split(u.email, '@')[1] as email_domain
  from
    main.sfdc_bronze.user u
    inner join main.sfdc_bronze.account a on u.accountid = a.id
        and a.processdate =(
      Select
        max(processdate)
      from
        main.sfdc_bronze.account
    )
    inner join main.sfdc_bronze.account a1 on a.Ultimate_parent_account_casesafe_ID__c = a1.id
        and a1.processdate =(
      Select
        max(processdate)
      from
        main.sfdc_bronze.account
    )

    anti join main.field_learning_enablement.blacklist_domains b on split(u.email, '@')[1] = b.blacklist_domain and b.processDate = (select max(processDate) from main.field_learning_enablement.blacklist_domains)
    anti join exclude_df e on split(u.email, '@')[1] = e.exclude_domains
    where
    u.processDate =(
      Select
        max(processDate)
      from
        main.sfdc_bronze.user
    )
    and a.partner_type__c in ('RSI', 'GSI', 'Fed SI', 'Consulting & SI', 'Reseller')
    -- and partner_status__c='Active'
  )
  ,
  grouped_data as (
  select email_domain, ultimate_parent_account_id, ultimate_parent_account_name, count(distinct email) as email_count
  from data d
  where email_domain <> 'databricks.com'
  group by 1,2,3
  )

  ,

  rank_data as (
    select 
      email_domain, 
      ultimate_parent_account_id, 
      ultimate_parent_account_name, 
      email_count,
      rank() over (partition by email_domain order by email_count desc) as rank
    from grouped_data
  )
  ,
  pre as (
  select r.email_domain, r.ultimate_parent_account_id, r.ultimate_parent_account_name, max(d.LastModifiedDate) as LastModifiedDate
  from rank_data r
  left join data d on r.email_domain = d.email_domain and r.ultimate_parent_account_id = d.ultimate_parent_account_id and r.ultimate_parent_account_name = d.ultimate_parent_account_name
  where r.rank = 1
  -- and r.email_domain = 'kytheralabs.com'
  group by 1,2,3                              
  )
  ,
  pre_2 as (
  select *, rank() over (partition by email_domain order by LastModifiedDate desc) as mod_rank
  from pre
  )

  ,

  pre_3 as (
    select 
      email_domain, 
      ultimate_parent_account_id, 
      ultimate_parent_account_name, 
      rank() over (partition by email_domain order by ultimate_parent_account_name desc) as alph_rank
    from pre_2
    where mod_rank = 1
  )         
  ,
  pre_4 as (
    select 
      email_domain, 
      ultimate_parent_account_id, 
      ultimate_parent_account_name,
      rank() over (partition by email_domain order by ultimate_parent_account_id desc) as id_rank
    from pre_3
    where alph_rank = 1
  )  
  ,
  final as (
    select 
      email_domain, 
      ultimate_parent_account_id, 
      ultimate_parent_account_name
    from pre_4
    where id_rank = 1
  )
 

  select *
  from final    
  where email_domain != 'microsoft.com'
  
                                    
''')



# COMMAND ----------

all_parter_domains_accounts = (
  parter_domains_accounts
    .union(include_partner_domains)
    .union(exception_df)
)

# COMMAND ----------

display(all_parter_domains_accounts)

# COMMAND ----------

# DBTITLE 1,Parent Account Override Logic
# all_parter_domains_accounts_override = (
#   all_parter_domains_accounts
#     .withColumnRenamed('ultimate_parent_account_id', 'ultimate_parent_account_id_pre')
#     .withColumnRenamed('ultimate_parent_account_name', 'ultimate_parent_account_name_pre')
#     .withColumn('ultimate_parent_account_id', F.when(F.col('email_domain').isin('daugherty.pa', 'daugherty.pl'), '0018Y00002qS0CEQA0').otherwise(F.col('ultimate_parent_account_id_pre')))
#     .withColumn('ultimate_parent_account_name', F.when(F.col('email_domain').isin('daugherty.pa', 'daugherty.pl'), 'Daugherty Business Solutions').otherwise(F.col('ultimate_parent_account_name_pre')))
#     .drop('ultimate_parent_account_id_pre', 'ultimate_parent_account_name_pre')
# )

# COMMAND ----------

parter_domains_accounts_gold = add_gold_metadata(all_parter_domains_accounts)

# COMMAND ----------

display(parter_domains_accounts_gold)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = parter_domains_accounts_gold, 
  table_name = f'{focus_database_name}.partner_domains_accounts', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)