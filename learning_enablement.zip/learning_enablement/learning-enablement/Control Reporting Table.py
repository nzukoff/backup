# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             control_reporting \
# MAGIC **Description:**     This notebook gives the data for the Control Reporting of the courses in Docebo Courses \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Workspace/Users/nathan.zukoff@databricks.com/Reporting/Docebo/Docebo Functions"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

# MAGIC %run "/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# courses from docebo_courses
all_courses = spark.sql(
'''
with enrollments as (
  select 
    s.course_id, 
    s.course_name, 
    s.course_code, 
    max(s.enrolled_timestamp::date) as last_enrollment_time, 
    count(distinct s.learner_user_id) as total_enrollments, 
    count(s.completed_timestamp) as total_completions 
  from main.field_learning_enablement.self_paced_enrollments s
  where s.processDate = (select max(processDate) from main.field_learning_enablement.self_paced_enrollments)
  group by 1,2,3
  union all
  select 
    e.course_id, 
    e.course_name, 
    e.course_code, 
    max(e.enrolled_timestamp::date) as last_enrollment_time, 
    count(distinct e.learner_user_id) as total_enrollments, 
    count(e.completed_timestamp) as total_completions 
  from main.field_learning_enablement.ilt_enrollments e
  where e.processDate = (select max(processDate) from main.field_learning_enablement.ilt_enrollments)
  group by 1,2,3
),

courses as (
  select * from main.it_training_silver.docebo_courses
where processDate = (select max(processDate) from main.it_training_silver.docebo_courses)
-- and course_status_meaning = 'Published'
)
,
learning_plans as (
  select * from main.it_training_silver.docebo_learning_plans lp
  left join main.it_training_silver.docebo_learning_plan_courses lpc on lp.id = lpc.path_id
  and lpc.processDate = (select max(processDate) from main.it_training_silver.docebo_learning_plan_courses)
  where lp.processDate = (select max(processDate) from main.it_training_silver.docebo_learning_plans)
),
catalogs as (
  select * from main.it_training_silver.docebo_catalogs c
  left join main.it_training_silver.docebo_catalog_items cc on c.id = cc.catalog_id
  and cc.processDate = (select max(processDate) from main.it_training_silver.docebo_catalog_items)
  where c.processDate = (select max(processDate) from main.it_training_silver.docebo_catalogs)
)

select 
  c.id, 
  c.code, 
  c.name, 
  c.type, 
  c.created_timestamp::date, 
  c.deleted_timestamp::date, 
  c.expected_time_to_complete_in_seconds, 
  c.course_status_meaning, 
  c.category_code, 
  e.last_enrollment_time, 
  float(nvl(e.total_enrollments,0.0)) as total_enrollments, 
  float(nvl(e.total_completions,0.0)) as total_completions, 
  c.author_username,
  lp.name as learning_plan_name,
  lp.code as learning_plan_code,
  lp.id as learning_plan_id,
  lp.created_timestamp::timestamp as lp_created_timestamp,
  lp.author_email as lp_author_email,
  lp.total_courses as lp_total_courses,
  ct.name as catalog_name,
  ct.code as catalog_code,
  ct.id as catalog_id,
  ct.total_items as catalog_total_items,
  ct.number_of_learners
from courses c
left join enrollments e on c.id = e.course_id
left join learning_plans lp on c.id = lp.course_id
left join catalogs ct on c.id = ct.entry_id
-- where c.course_status_meaning = 'Published'
order by 2
'''
)

# print(all_courses.schema)

# COMMAND ----------

all_courses_gold = add_gold_metadata(all_courses)
all_courses_gold.createOrReplaceTempView('all_courses_gold')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- main.it_training_silver.docebo_catalog_items to get the catalogs and courses mapping
# MAGIC -- main.it_training_silver.docebo_learning_plan_courses
# MAGIC -- select * from main.it_training_silver.docebo_learning_plan_courses
# MAGIC -- where processDate = (select max(processDate) from main.it_training_silver.docebo_learning_plan_courses)
# MAGIC
# MAGIC -- select * from main.it_training_silver.docebo_users c
# MAGIC --   left join main.it_training_silver.docebo_catalog_items cc on c.id = cc.catalog_id
# MAGIC --   and cc.processDate = (select max(processDate) from main.it_training_silver.docebo_catalog_items)
# MAGIC   -- where c.processDate = (select max(processDate) from main.it_training_silver.docebo_users)
# MAGIC
# MAGIC -- select count(distinct path_id) from main.it_training_silver.docebo_learning_plan_courses lp
# MAGIC   -- left join main.it_training_silver.docebo_learning_plan_courses lpc on lp.id = lpc.path_id
# MAGIC   -- and lpc.processDate = (select max(processDate) from main.it_training_silver.docebo_learning_plan_courses)
# MAGIC   -- where lp.processDate = (select max(processDate) from main.it_training_silver.docebo_learning_plan_courses)
# MAGIC   -- and lp.id in (
# MAGIC --    94,
# MAGIC -- 144,
# MAGIC -- 143,
# MAGIC -- 161,
# MAGIC -- 258,
# MAGIC -- 246,
# MAGIC -- 257,
# MAGIC -- 248,
# MAGIC -- 114,
# MAGIC -- 100,
# MAGIC -- 249,
# MAGIC -- 200,
# MAGIC -- 62,
# MAGIC -- 260,
# MAGIC -- 269,
# MAGIC -- 244,
# MAGIC -- 164,
# MAGIC -- 245,
# MAGIC -- 14,
# MAGIC -- 60,
# MAGIC -- 336
# MAGIC --   )
# MAGIC   -- and lp.id not in (select distinct learning_plan_id from all_courses_gold)
# MAGIC

# COMMAND ----------


# get all the invalid course codes from the docebo courses
def get_invalid_course_ids(course_code: str, id: int, invalid_course_codes_ids: list):
  """
  Check if the course code is null or if it is Invalid.
  """
  
  if course_code == '' or course_code == 'None':
    invalid_course_codes_ids.append(id)
  else:
    ls = course_code.split('-')
    if(ls[0].lower() not in ['acad', 'part', 'slen', 'pars', 'feng', 'cust']):
      invalid_course_codes_ids.append(id)
    elif len(ls)>1 and (ls[1].lower() not in ['all', 'cust', 'part', 'cusu', 'feng', 'tech', 'slen']):
      invalid_course_codes_ids.append(id)
    elif len(ls)>2 and (ls[2].lower() not in ['slp', 'iltus', 'iltprv', 'iltpub', 'lplan', 'ilt', 'slpht', 'sp', 'iltb', 'spl', 'blnd']):
      invalid_course_codes_ids.append(id)

# COMMAND ----------


invalid_course_codes_ids = []
null_expected_time_ids = []
category_code_null_ids = []

all_courses_pd = all_courses.toPandas()


for index, row in all_courses_pd.iterrows():
  expected_time = int(row['expected_time_to_complete_in_seconds'])
  category_code = str(row['category_code'])
  course_code = str(row['code'])
  id = int(row['id'])

  get_invalid_course_ids(course_code, id, invalid_course_codes_ids)


  # check if expected time to complete is 0
  if expected_time == 0:
    null_expected_time_ids.append(id)


  # check if the category code is null
  if category_code == 'None':
    category_code_null_ids.append(id)

# print(len(invalid_course_codes_ids))
# print(len(null_expected_time_ids))
# print(len(category_code_null_ids))

combined_courses_list = []
invalid_course_codes = []
null_expected_time = []
category_code_null = []
id = invalid_course_codes_ids[0]

for index, row in all_courses_pd.iterrows():
  for id in invalid_course_codes_ids:
    if id == int(row['id']):
      row['err_type'] = 'invalid_course_code'
      invalid_course_codes.append(row)
  for id in null_expected_time_ids:
    if id == int(row['id']):
      row['err_type'] = 'null_expected_time'
      null_expected_time.append(row)
  for id in category_code_null_ids:
    if id == int(row['id']):
      row['err_type'] = 'category_code_null'
      category_code_null.append(row)


combined_courses_list.extend(invalid_course_codes)
combined_courses_list.extend(null_expected_time)
combined_courses_list.extend(category_code_null)
combined_courses_list = pd.DataFrame(combined_courses_list)


# COMMAND ----------


courses_schema = T.StructType(
    [
        T.StructField("id", T.IntegerType(), True),
        T.StructField("code", T.StringType(), True),
        T.StructField("name", T.StringType(), True),
        T.StructField("type", T.StringType(), True),
        T.StructField("created_timestamp", T.DateType(), True),
        T.StructField("deleted_timestamp", T.TimestampType(), True),
        T.StructField("expected_time_to_complete_in_seconds", T.IntegerType(), True),
        T.StructField("course_status_meaning", T.StringType(), True),
        T.StructField("category_code", T.StringType(), True),
        T.StructField("last_enrollment_time", T.DateType(), True),
        T.StructField("total_enrollments", T.FloatType(), True),
        T.StructField("total_completions", T.FloatType(), True),
        T.StructField("author_username", T.StringType(), True),
        T.StructField("learning_plan_name", T.StringType(), True),
        T.StructField("learning_plan_code", T.StringType(), True),
        T.StructField("learning_plan_id", T.FloatType(), True),
        T.StructField("lp_created_timestamp", T.TimestampType(), True),
        T.StructField("lp_author_email", T.StringType(), True),
        T.StructField("lp_total_courses", T.FloatType(), True),
        T.StructField("catalog_name", T.StringType(), True),
        T.StructField("catalog_code", T.StringType(), True),
        T.StructField("catalog_id", T.FloatType(), True),
        T.StructField("catalog_total_items", T.FloatType(), True),
        T.StructField("number_of_learners", T.FloatType(), True),
        T.StructField("err_type", T.StringType(), True),
    ]
)

# COMMAND ----------

control_reporting_courses_list_df = spark.createDataFrame(combined_courses_list, schema=courses_schema)  
control_reporting_courses_list_df.createOrReplaceTempView('control_reporting_data')

# COMMAND ----------

control_reporting_gold = add_gold_metadata(control_reporting_courses_list_df)

# COMMAND ----------

# DBTITLE 1,Get Docebo Groups Data
group_records = getDoceboAudiences()
groups_total_members_records = getDoceboGroups()
# get_superset_of_all_keys(group_records)

# COMMAND ----------

groups_data = []
for fields in group_records:
  row = {
    'group_name': fields.get('name', ''),
    'group_description': fields.get('description', ''),
    'group_labels': fields.get('labels', ''),
    'group_type': fields.get('type', ''),
    'group_uuid': fields.get('uuid', ''),
    'group_created_by_name': fields.get('created_by', '').get('name', ''),
    'group_created_by_email': fields.get('created_by', '').get('email', ''),
    'group_created_by_userid': fields.get('created_by', '').get('userid', ''),
    'group_created_by_idst': fields.get('created_by', '').get('idst', ''),
    'group_updated_by_name': fields.get('updated_by', '').get('name', ''),
    'group_updated_by_email': fields.get('updated_by', '').get('email', ''),
    'group_updated_by_userid': fields.get('updated_by', '').get('userid', ''),
    'updated_at': fields.get('updated_at', ''),
    # 'ruleset_status': fields.get('ruleset', '').get('status', ''),
    # 'ruleset_operator': fields.get('ruleset', '').get('operator', ''),
    # 'ruleset_sets': fields.get('ruleset', '').get('sets', '')
    }
  
  groups_data.append(row)

groups_data_base = convertToDF(groups_data)
groups_data_base.createOrReplaceTempView('groups_data_base')

# COMMAND ----------

groups_total_members = []
for fields in groups_total_members_records:
  row = {
    'name': fields.get('name', ''),
    'members_count': fields.get('members_count', ''),
    'id': fields.get('id', ''),
    'description': fields.get('description', '')
  }
  groups_total_members.append(row)

groups_total_base = convertToDF(groups_total_members)
groups_total_base.createOrReplaceTempView('groups_total_base')

# COMMAND ----------

all_groups_data = spark.sql(
'''
  select 
    group_name,
    group_description,
    group_type,
    group_created_by_name,
    group_created_by_email,
    group_created_by_userid,
    group_created_by_idst,
    members_count
    from groups_data_base g
    left join groups_total_base t on g.group_name = t.name

'''
)


# COMMAND ----------

display(all_groups_data)

# COMMAND ----------

docebo_groups_gold = add_gold_metadata(all_groups_data)

# COMMAND ----------

# DBTITLE 1,Get Docebo Notifications Data
notification_records = getDoceboNotifications()
# pprint(notifications)
# get_superset_of_all_keys(notifications)

# COMMAND ----------

notifications_data = []
for fields in notification_records:
  row = {
    'id': fields.get('id', ''),
    'type': fields.get('type', ''),
    'code': fields.get('code', ''),
    'active': fields.get('active', ''),
    'schedule_type': fields.get('schedule_type', ''),
    'schedule_time': fields.get('schedule_time', ''),
    'schedule_shift_period': fields.get('schedule_shift_period', ''),
    'schedule_shift_number': fields.get('schedule_shift_number', ''),
    'job_handler_id': fields.get('job_handler_id', ''),
    'id_job': fields.get('id_job', ''),
    'id_author': fields.get('id_author', ''),
    'ufilter_option': fields.get('ufilter_option', ''),
    'cfilter_option': fields.get('cfilter_option', ''),
    'puProfileId': fields.get('puProfileId', ''),
    'scan_days': fields.get('scan_days', ''),
    'send_exact_interval': fields.get('send_exact_interval', ''),
    'notification_method': fields.get('notification_method', ''),
    'subject': fields.get('subject', ''),
    'recipient': fields.get('recipient', ''),
    }
  
  notifications_data.append(row)

notifications_data_base = convertToDF(notifications_data)
# notifications_data_base.createOrReplaceTempView('notifications_data')

# COMMAND ----------

# %sql
# -- select * from notifications_data
docebo_notifications_gold = add_gold_metadata(notifications_data_base)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = control_reporting_gold, 
  table_name = f'{focus_database_name}.control_reporting', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_courses_gold, 
  table_name = f'{focus_database_name}.docebo_courses_lp_catalogs', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = docebo_notifications_gold, 
  table_name = f'{focus_database_name}.docebo_notifications_gold', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = docebo_groups_gold, 
  table_name = f'{focus_database_name}.docebo_groups', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)