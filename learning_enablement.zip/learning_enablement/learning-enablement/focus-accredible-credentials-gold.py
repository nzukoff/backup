# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

from pyspark.sql import DataFrame, Column
from typing import Optional, Sequence as Seq, Dict, Callable, Any

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC ######Env & Parameter Unit Tests
# MAGIC
# MAGIC **Code below has wrong indentation when uncommented**

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Define tables  (examples included below with comments; adjust as necessary)

# COMMAND ----------

#SFDC Tables

sfdc_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.account",  "processDate")

sfdc_accounts = (
  spark.read.table("main.sfdc_bronze.account")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

# Docebo Logfood data
silver_docebo_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_salesforce_account_email_domain_mapping",  "processDate")

salesforce_account_email_domain_mapping = (
  spark.read.table("main.it_training_silver.docebo_salesforce_account_email_domain_mapping")
    .filter(~F.col("account_name").isin('Individual LMS Account', 'Individual LMS Account(Generic)'))
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

gold_docebo_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.docebo_users",  "processDate")

docebo_users = (
  spark.read.table(f"{focus_database_name}.docebo_users")
    .filter(F.col("processDate") == gold_docebo_latest_process_date)
    .drop("processDate")
)

# Blacklisted domains

blacklist_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.blacklist_domains",  "processDate")


blacklist_domains = (
  spark.read.table(f"{focus_database_name}.blacklist_domains")
    .filter(F.col("processDate") == blacklist_latest_process_date)
)

blacklist = [domain["blacklist_domain"] for domain in blacklist_domains.collect()]

# Accredible Data

silver_accredible_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.accredible_credentials",  "processDate")

credentials = (
  spark.read.table("main.it_training_silver.accredible_credentials")
    .filter(F.col("processDate") == silver_accredible_latest_process_date)
    .drop("processDate", "branch_code")
)

# Webassessor Data

webassessor_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.webassessor_users",  "processDate")

webassessor_users = (
  spark.table(f"main.it_training_silver.webassessor_users")
    .filter(F.col("processDate") == webassessor_latest_process_date)
    .drop("processDate")
)


# Updated Credentials Data

updated_credentials_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.accredible_credentials_test",  "processDate")

updated_accredible_credentials = (
  spark.read.table(f"{focus_database_name}.accredible_credentials_test")
    .filter(F.col("processDate") == updated_credentials_latest_process_date)
    .select(
      'credential_id',
      'audience', 
      F.col('account_id').alias('updated_account_id'),
      F.col('account_name').alias('updated_account_name'),
      F.col('ultimate_parent_account_id').alias('updated_ultimate_parent_account_id'),
      F.col('ultimate_parent_account_name').alias('updated_ultimate_parent_account_name'),
      'match_method'
    )
)

databricks_account_id = "0016100001FyvmIAAR"

# COMMAND ----------

#unit tests to make sure dfs are pulled correctly
assert unit_test_df_count(sfdc_accounts) > 0

# unit tests to make sure parameters are set up correctly
catalog, database = focus_database_name.split('.')
assert unit_test_valid_db(database, spark, catalog)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# unique mappings all accounts

account_window = W.Window.partitionBy("account_name").orderBy(F.desc("total_for_email_and_account"), "tiebreak")
domain_window = W.Window.partitionBy("email_domain").orderBy(F.desc("total_emails"), "tiebreak")

accounts_df = (
  sfdc_accounts
    .select(
      F.col("Id").alias("ultimate_parent_account_id"),
      F.col("Name").alias("ultimate_parent_account_name")
    )
)

account_names = (
  sfdc_accounts
    .select(
      F.col("Id").alias("account_id"),
      F.col("Name").alias("account_name"),
      F.col("ParentId").alias("ultimate_parent_account_id")
    )
    .join(accounts_df, "ultimate_parent_account_id", "left")
)

mapping_2_all = (
 salesforce_account_email_domain_mapping
    # remove any accounts without email domains
    .filter(F.col("email_domain").isNotNull())
    # keep domains that appear more than 5 times 
    .filter(F.col("total_for_email_and_account") >= 5)
    # rank to find most common email domain per account
    .groupBy(["email_domain", "account_id"])
    .agg(F.sum("total_for_email_and_account").alias("total_emails"))
    # rank to find most common domain for each account
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(domain_window))
    .filter(F.col("rank") == 1)
    .drop("total_emails", "tiebreak", "rank")
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

mapping_2_databricks = (
  salesforce_account_email_domain_mapping  
    .filter(F.col("account_id") == databricks_account_id)
    .filter(F.col("email_domain") == "databricks.com")
    .orderBy(F.col("account_last_modified_timestamp").desc())
    .limit(1)
    .select("email_domain", "account_id")
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

# COMMAND ----------

email_window = W.Window.partitionBy("email_hash").orderBy(F.desc("last_updated_timestamp"), "tiebreak")
alt_email_window = W.Window.partitionBy("alternate_email_hash").orderBy(F.desc("last_updated_timestamp"), "tiebreak")


docebo_emails_accounts = (
  docebo_users
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(email_window))
    .filter(F.col("rank") == 1)
    .select(
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("branch_code"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)

docebo_alt_emails_accounts = (
  docebo_users
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(alt_email_window))
    .filter(F.col("rank") == 1)
    .select(
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("branch_code"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)

# COMMAND ----------

credentials_prim_accounts = (
  credentials
    .join(docebo_emails_accounts, credentials.learner_email_hash == docebo_emails_accounts.email_hash, "left")
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
      F.col("learner_name"),
      F.col("email").alias("learner_primary_email_check"),
      F.col("email_hash").alias("learner_primary_email_hash_check"),
      F.col("email_domain").alias("learner_primary_email_domain_check"),
      F.col("alternate_email").alias("learner_alternate_email_check"),
      F.col("alternate_email_hash").alias("learner_alternate_email_hash_check"),
      F.col("alternate_email_domain").alias("learner_alternate_email_domain_check"),
      F.col("learner_id"),
      F.col("branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_email_hash"),
      F.col("learner_email"),
      F.col("learner_email_domain"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
  
)
credentials_alt_accounts = (
  credentials_prim_accounts
    .filter(F.col("account_id").isNull())
    .drop(      
      "account_id",
      "account_name",
      "ultimate_parent_account_id",
      "ultimate_parent_account_name",
      "learner_primary_email_check",
      "learner_primary_email_hash_check",
      "learner_primary_email_domain_check",
      "learner_alternate_email_check",
      "learner_alternate_email_hash_check",
      "learner_alternate_email_domain_check",
      "branch_code",
      "country_code",
      "country_name",
      "region"
     )
    .join(docebo_alt_emails_accounts, credentials_prim_accounts.learner_email_hash == docebo_alt_emails_accounts.alternate_email_hash, "left")
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
      F.col("learner_name"),
      F.col("email").alias("learner_primary_email_check"),
      F.col("email_hash").alias("learner_primary_email_hash_check"),
      F.col("email_domain").alias("learner_primary_email_domain_check"),
      F.col("alternate_email").alias("learner_alternate_email_check"),
      F.col("alternate_email_hash").alias("learner_alternate_email_hash_check"),
      F.col("alternate_email_domain").alias("learner_alternate_email_domain_check"),
      F.col("learner_id"),
      F.col("branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_email_hash"),
      F.col("learner_email"),
      F.col("learner_email_domain"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)

credentials_accounts_matched = (
  credentials_prim_accounts
    .filter(F.col("account_id").isNotNull())
)

credentials_accounts_alt = (
  credentials_accounts_matched
    .union(credentials_alt_accounts)
    .withColumn("learner_alternate_email_hash", 
                F.when(F.col("learner_email_hash") == F.col("learner_primary_email_hash_check"), F.col("learner_alternate_email_hash_check"))
                 .when(F.col("learner_email_hash") == F.col("learner_alternate_email_hash_check"), F.col("learner_primary_email_hash_check"))
             )
    .withColumn("learner_alternate_email", 
                F.when(F.col("learner_email") == F.col("learner_primary_email_check"), F.col("learner_alternate_email_check"))
                 .when(F.col("learner_email") == F.col("learner_alternate_email_check"), F.col("learner_primary_email_check"))
             )
    .withColumn("learner_alternate_email_domain", 
                F.when(F.col("learner_email_domain") == F.col("learner_primary_email_domain_check"), F.col("learner_alternate_email_domain_check"))
                 .when(F.col("learner_email_domain") == F.col("learner_alternate_email_domain_check"), F.col("learner_primary_email_domain_check"))
             )
    .select(
        F.col("approve"),
        F.col("complete"),
        F.col("credential_id"),
        F.col("credential_name"),
        F.col("expired_on"),
        F.col("is_expired"),
        F.col("group_id"),
        F.col("group_name"),
        F.col("issued_on"),
        F.col("learner_name"),
        F.col("learner_email"),
        F.col("learner_email_hash"),
        F.col("learner_email_domain"),
        F.col("learner_alternate_email"),
        F.col("learner_alternate_email_hash"),
        F.col("learner_alternate_email_domain"),
        F.col("learner_id"),
        F.col("branch_code"),
        F.col("account_id"),
        F.col("account_name"),
        F.col("ultimate_parent_account_id"),
        F.col("ultimate_parent_account_name"),
        F.col("learner_email_hash"),
        F.col("learner_email"),
        F.col("country_code"),
        F.col("country_name"),
        F.col("region")
      )
      .withColumn("learner_email_domain_final", 
        F.when(~F.col("learner_email_domain").isin(blacklist), F.col("learner_email_domain"))
        .when(F.col("learner_email_domain").isin(blacklist) & ~F.col("learner_alternate_email_domain").isin(blacklist), F.col("learner_alternate_email_domain"))
        .otherwise(None)
      )
)

credentials_accounts_alt_not_found = (
  credentials_accounts_alt
    .filter(F.col("learner_alternate_email_hash").isNull())
    .drop(
      'learner_alternate_email',
      'learner_alternate_email_hash', 
      'learner_alternate_email_domain'
    )
    .join(docebo_emails_accounts
          .select(
            F.col('alternate_email').alias('learner_alternate_email'), 
            F.col('alternate_email_hash').alias('learner_alternate_email_hash'), F.col('alternate_email_domain').alias('learner_alternate_email_domain'),
            F.col('email_hash')), 
          credentials_accounts_alt.learner_email_hash == docebo_emails_accounts.email_hash, "left")
    .select('approve',
            'complete',
            'credential_id',
            'credential_name',
            'expired_on',
            'is_expired',
            'group_id',
            'group_name',
            'issued_on',
            'learner_name',
            'learner_email',
            'learner_email_hash',
            'learner_email_domain',
            'learner_alternate_email',
            'learner_alternate_email_hash',
            'learner_alternate_email_domain',
            'learner_id',
            'branch_code',
            'account_id',
            'account_name',
            'ultimate_parent_account_id',
            'ultimate_parent_account_name',
            'learner_email_hash',
            'learner_email',
            'country_code',
            'country_name',
            'region',
            'learner_email_domain_final'
            )
)

credentials_accounts_alt_found = (credentials_accounts_alt.filter(F.col("learner_alternate_email_hash").isNotNull()))

credentials_accounts = (
  credentials_accounts_alt_found
  .union(credentials_accounts_alt_not_found)
)

assert unit_test_df_count(credentials_accounts) == unit_test_df_count(credentials)

# COMMAND ----------

credentials_rematched = (
  credentials_accounts
    .filter(F.col("account_id").isNull())
    .drop(      
      "account_id",
      "account_name",
      "ultimate_parent_account_id",
      "ultimate_parent_account_name",
     )
    .join(mapping_2_all, credentials_accounts.learner_email_domain_final == mapping_2_all.email_domain_final, "left")
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)

credentials_matched = (
  credentials_accounts
    .filter(F.col("account_id").isNotNull())
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)

all_credentials = (
  credentials_matched
    .union(credentials_rematched)
)

assert unit_test_df_count(all_credentials) == unit_test_df_count(credentials)

credentials_databricks = (
  all_credentials
    .filter(F.col("learner_email_domain") == "databricks.com")
    .drop(      
      "account_id",
      "account_name",
      "ultimate_parent_account_id",
      "ultimate_parent_account_name",
     )
    .join(mapping_2_databricks, all_credentials.learner_email_domain == mapping_2_databricks.email_domain_final, "left")
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("branch_code").alias("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)



credentials_not_databricks = (
  all_credentials
    .filter((F.col("learner_email_domain") != "databricks.com") | (F.col("learner_email_domain").isNull()))
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("branch_code").alias("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)


credentials_accounts_mappings = (
  credentials_databricks
    .union(credentials_not_databricks)
)


assert unit_test_df_count(credentials_accounts_mappings) == unit_test_df_count(credentials)

# COMMAND ----------

credentials_accounts_mappings_clean = (
  credentials_accounts_mappings
    .withColumnRenamed('ultimate_parent_account_id','ultimate_parent_account_id_raw')
    .withColumnRenamed('ultimate_parent_account_name','ultimate_parent_account_name_raw')
    .withColumn('ultimate_parent_account_id', F.coalesce('ultimate_parent_account_id_raw', 'account_id'))
    .withColumn('ultimate_parent_account_name', F.coalesce('ultimate_parent_account_name_raw', 'account_name'))
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)

assert unit_test_df_count(credentials_accounts_mappings_clean) == unit_test_df_count(credentials)

# COMMAND ----------

credentials_accounts_mappings_updated = (
  credentials_accounts_mappings_clean
    .join(updated_accredible_credentials, 'credential_id', 'left')
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method')
    )
)

assert unit_test_df_count(credentials_accounts_mappings_updated) == unit_test_df_count(credentials)

# COMMAND ----------

credentials_accounts_mappings_updated_clean = (
  credentials_accounts_mappings_updated
    .withColumnRenamed('audience','audience_pre')
    .withColumn('audience',
                F.when(F.col("audience_pre") == "Employee Other", F.lit("Employee"))
                .otherwise(F.col("audience_pre"))
                )
    .withColumn('calculated_expired_on', 
        F.when(F.col('credential_name').isin('Databricks Certified Associate ML Practitioner for Apache Spark 2.4', 'Databricks Certified Associate Developer for Apache Spark 2.4', 'Databricks Certified Associate Developer for Apache Spark 3.0'), F.date_add(F.col("issued_on"), 365*2))
        .otherwise(F.col('expired_on'))
        )
    .withColumn('calculated_is_expired', 
        F.when(F.col('calculated_expired_on').isNull(), False)
         .when(F.col('calculated_expired_on') <= F.current_timestamp(), True)
         .otherwise(False)
                )
    .drop('audience_pre')
)

# COMMAND ----------

webassessor_users_countries_prim = (
  webassessor_users.select(F.col('email_hash').alias('learner_email_hash'), 'address_country', 'address_region').distinct()
)

webassessor_users_countries_alt = (
  webassessor_users.select(F.col('email_hash').alias('learner_alternate_email_hash'), 'address_country', 'address_region').distinct()
)

credentials_accounts_mappings_webassessor = (
  credentials_accounts_mappings_updated_clean
    .join(webassessor_users_countries_prim, 'learner_email_hash', 'left')
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("updated_account_id"),
      F.col("updated_account_name"),
      F.col("updated_ultimate_parent_account_id"),
      F.col("updated_ultimate_parent_account_name"),
      F.col("match_method"),
      F.col("audience"),
      F.col("calculated_expired_on"),
      F.col("calculated_is_expired"),
      F.col('address_country').alias('country_webassessor'),
      F.col('address_region').alias('region_webassessor')
    )
    
)

credentials_accounts_mappings_webassessor_match_1 = (
  credentials_accounts_mappings_webassessor
  .filter(F.col("country_webassessor").isNotNull())
)

credentials_accounts_mappings_webassessor_match_2 = (
  credentials_accounts_mappings_webassessor
  .filter(F.col("country_webassessor").isNull())
  .drop('country_webassessor')
  .join(webassessor_users_countries_alt, 'learner_alternate_email_hash', 'left')
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("updated_account_id"),
      F.col("updated_account_name"),
      F.col("updated_ultimate_parent_account_id"),
      F.col("updated_ultimate_parent_account_name"),
      F.col("match_method"),
      F.col("audience"),
      F.col("calculated_expired_on"),
      F.col("calculated_is_expired"),
      F.col('address_country').alias('country_webassessor'),
      F.col('address_region').alias('region_webassessor')
    )
)

credentials_accounts_mappings_updated_clean_webassessor = (
  credentials_accounts_mappings_webassessor_match_1
    .union(credentials_accounts_mappings_webassessor_match_2)
)

credentials_accounts_mappings_updated_clean_webassessor = (
  credentials_accounts_mappings_updated_clean_webassessor
    .withColumn('country_derived_pre', F.coalesce(F.col('country_webassessor'), F.col('country_name')))
    .withColumn('country_derived', F.coalesce(F.col('country_derived_pre'), F.lit('Unknown')))
    .withColumn('region_derived_pre', F.coalesce(F.col('region_webassessor'), F.col('region')))
    .withColumn('region_derived', F.coalesce(F.col('region_derived_pre'), F.lit('Unknown')))
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("updated_account_id"),
      F.col("updated_account_name"),
      F.col("updated_ultimate_parent_account_id"),
      F.col("updated_ultimate_parent_account_name"),
      F.col("match_method"),
      F.col("audience"),
      F.col("calculated_expired_on"),
      F.col("calculated_is_expired"),
      F.col('country_webassessor'),
      F.col('region_webassessor'),
      F.col('country_derived'),
      F.col('region_derived')
    )
).createOrReplaceTempView('credentials_accounts_mappings_updated_clean_webassessor')

# COMMAND ----------

from pyspark.sql.functions import col, when

# COMMAND ----------

result_df = spark.sql('''
WITH docebo_users_dedupe AS (
    SELECT 
        u.email_hash,
        u.created_timestamp,
        u.country_derived AS m_country_derived,
        u.region_derived AS m_region_derived,
        RANK() OVER (PARTITION BY u.email_hash ORDER BY u.created_timestamp DESC) AS dedupe_rank
    FROM main.field_learning_enablement.docebo_users u
    WHERE u.processDate = (
        SELECT MAX(processDate) 
        FROM main.field_learning_enablement.docebo_users
    )
    AND u.email_hash IS NOT NULL
),
docebo_users_filtered AS (
    SELECT * 
    FROM docebo_users_dedupe 
    WHERE dedupe_rank = 1
),
webassessor_cleaned AS (
    SELECT 
        -- Select all columns except country_derived and region_derived
        d.* 
    FROM credentials_accounts_mappings_updated_clean_webassessor d
),
final_result AS (
    SELECT 
        d.* EXCEPT(country_derived,region_derived),
        CASE 
            WHEN d.country_derived IS NULL OR d.country_derived = 'Unknown' THEN m.m_country_derived
            ELSE d.country_derived
        END AS country_derived,
        CASE 
            WHEN d.region_derived IS NULL OR d.region_derived = 'Unknown' THEN m.m_region_derived
            ELSE d.region_derived
        END AS region_derived
    FROM webassessor_cleaned d
    LEFT JOIN docebo_users_filtered m
        ON d.learner_email_hash = m.email_hash
)

SELECT * FROM final_result

''')

# COMMAND ----------

credentials_accounts_mappings_clean_partition = add_gold_metadata(result_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = credentials_accounts_mappings_clean_partition, 
  table_name = f'{focus_database_name}.accredible_credentials', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)