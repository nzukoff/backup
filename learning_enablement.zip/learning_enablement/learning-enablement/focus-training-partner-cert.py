# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Karthik Reddy \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# from pprint import pprint
# from pyspark.sql import DataFrame, Column
# from typing import Optional, Sequence as Seq, Dict, Callable, Any

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# verbose = get_verbose_func(VERBOSE)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# %sql
# create or replace temp view all_capability as 
# select *
# from main.field_learning_enablement.partner_capability
# where processDate = (select max(processDate) from main.field_learning_enablement.partner_capability)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create or replace temp view alternate_emails as 
# MAGIC with blacklist_domains as (
# MAGIC   select
# MAGIC     distinct blacklist_domain
# MAGIC   from
# MAGIC     main.field_learning_enablement.blacklist_domains
# MAGIC   where
# MAGIC     processDate = (
# MAGIC       select
# MAGIC         max(processDate)
# MAGIC       from
# MAGIC         main.field_learning_enablement.blacklist_domains
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC alt_emails as (
# MAGIC   select 
# MAGIC     id as id_user, 
# MAGIC     lower(alternate_email) as alternate_email, 
# MAGIC     lower(alternate_email_2) as alternate_email_2, 
# MAGIC     lower(alternate_email_domain) as alternate_email_domain,
# MAGIC     lower(alternate_email_2_domain) as alternate_email_2_domain, 
# MAGIC     branch_code, 
# MAGIC     b.blacklist_domain as b_blacklist_domain,
# MAGIC     b1.blacklist_domain as b1_blacklist_domain
# MAGIC   from main.it_training_silver.docebo_users u
# MAGIC   left join blacklist_domains b on u.alternate_email_domain = b.blacklist_domain
# MAGIC   left join blacklist_domains b1 on u.alternate_email_2_domain = b1.blacklist_domain
# MAGIC   where u.processDate = (select max(processDate) from main.it_training_silver.docebo_users)
# MAGIC )
# MAGIC , 
# MAGIC alt_emails_blacklist as (
# MAGIC   select
# MAGIC     *,
# MAGIC     case
# MAGIC       when b_blacklist_domain is not null
# MAGIC       and (
# MAGIC         b1_blacklist_domain is null
# MAGIC         and alternate_email_2_domain is not null
# MAGIC       ) then 'Email is blacklist - select secondary'
# MAGIC       when b1_blacklist_domain is not null
# MAGIC       and (
# MAGIC         b_blacklist_domain is null
# MAGIC         and alternate_email_domain is not null
# MAGIC       ) then 'Alternate email is blacklist - select primary'
# MAGIC       when (
# MAGIC         b_blacklist_domain is not null
# MAGIC         and b1_blacklist_domain is not null
# MAGIC         and alternate_email_domain is not null
# MAGIC       ) then 'Only blacklist domains - select primary'
# MAGIC       when (
# MAGIC         b_blacklist_domain is null
# MAGIC         and b1_blacklist_domain is null
# MAGIC         and alternate_email_domain is not null
# MAGIC       ) then 'Email Good - select primary'
# MAGIC       else 'Others'
# MAGIC     end as bucket
# MAGIC   from alt_emails
# MAGIC )
# MAGIC , 
# MAGIC final as (
# MAGIC   select
# MAGIC     p.*,
# MAGIC     case
# MAGIC       when p.bucket = 'Email is blacklist - select secondary' then p.alternate_email_2
# MAGIC       else p.alternate_email
# MAGIC     end as final_email,
# MAGIC     case
# MAGIC       when p.bucket = 'Email is blacklist - select secondary' then p.alternate_email_2_domain
# MAGIC       else p.alternate_email_domain
# MAGIC     end as final_email_domain
# MAGIC   from
# MAGIC     alt_emails_blacklist p
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC   id_user, 
# MAGIC   final_email as alternate_email, 
# MAGIC   final_email_domain as alternate_email_domain
# MAGIC from final 

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view top_80_partner_certs as 
# MAGIC
# MAGIC with ranked_docebo_users as (
# MAGIC     select
# MAGIC       *,
# MAGIC       rank() over (
# MAGIC         partition by email_hash
# MAGIC         order by
# MAGIC           last_login
# MAGIC       ) as rank_data
# MAGIC     from
# MAGIC       main.field_learning_enablement.docebo_users
# MAGIC     where
# MAGIC       processdate =(
# MAGIC         Select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.docebo_users
# MAGIC       )
# MAGIC       and nvl(audience, 'Unknown') in ('Partner', 'Partner Other')
# MAGIC   ),
# MAGIC   docebo_users as (
# MAGIC     select
# MAGIC       *
# MAGIC     from
# MAGIC       ranked_docebo_users
# MAGIC     where
# MAGIC       rank_data = 1
# MAGIC   ),
# MAGIC   blacklist_domains as (
# MAGIC     select
# MAGIC       distinct blacklist_domain
# MAGIC     from
# MAGIC       main.field_learning_enablement.blacklist_domains
# MAGIC     where
# MAGIC       processDate = (
# MAGIC         select
# MAGIC           max(processDate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.blacklist_domains
# MAGIC       )
# MAGIC   ),
# MAGIC   capability as (
# MAGIC     select
# MAGIC       c.*
# MAGIC     except(c.learner_email_domain),
# MAGIC       case
# MAGIC         when c.learner_email_hash = '78dfc4089d9f80cbae14429cb95508c1955262ebdee4184c4e3fb3503a70ae18' then 'gmail.com'
# MAGIC         else learner_email_domain
# MAGIC       end as learner_email_domain
# MAGIC     from
# MAGIC       main.field_learning_enablement.partner_capability c
# MAGIC     where
# MAGIC       c.processdate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.partner_capability
# MAGIC       )
# MAGIC       and learner_email_hash is not null
# MAGIC   ),
# MAGIC   -- fix learner_user_ids records that have one row with contact email and another without (because of learndot data)
# MAGIC   contact_email_fix as (
# MAGIC     select
# MAGIC       distinct learner_email_hash,
# MAGIC       contact_email,
# MAGIC       dense_rank() over (
# MAGIC         partition by learner_email_hash
# MAGIC         order by
# MAGIC           contact_email nulls last
# MAGIC       ) as rank
# MAGIC     from
# MAGIC       main.field_learning_enablement.partner_capability
# MAGIC     where
# MAGIC       category = 'Technical Trained'
# MAGIC       and processDate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.partner_capability
# MAGIC       )
# MAGIC   ),
# MAGIC   capability_v2 as (
# MAGIC     select
# MAGIC       c.*,
# MAGIC       case
# MAGIC         when category = 'Technical Certified' then a.recipient_email
# MAGIC         else d.contact_email
# MAGIC       end as updated_email
# MAGIC     from
# MAGIC       capability c
# MAGIC       left join contact_email_fix d on c.learner_email_hash = d.learner_email_hash
# MAGIC       and d.rank = 1
# MAGIC       and c.category = 'Technical Trained'
# MAGIC       left join main.it_accredible_bronze.credentials a on c.credential_id = a.credential_id
# MAGIC       and a.processdate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.it_accredible_bronze.credentials
# MAGIC       )
# MAGIC   ),
# MAGIC   capability_v3 as (
# MAGIC     select
# MAGIC       c.*,
# MAGIC       b.blacklist_domain as b_blacklist_domain,
# MAGIC       b1.blacklist_domain as b1_blacklist_domain
# MAGIC     from
# MAGIC       capability_v2 c
# MAGIC       left join blacklist_domains b on c.learner_email_domain = b.blacklist_domain
# MAGIC       left join blacklist_domains b1 on c.learner_alternate_email_domain = b1.blacklist_domain
# MAGIC   ),
# MAGIC   capability_pre as (
# MAGIC     select
# MAGIC       *,
# MAGIC       case
# MAGIC         when b_blacklist_domain is not null
# MAGIC         and (
# MAGIC           b1_blacklist_domain is null
# MAGIC           and learner_alternate_email_domain is not null
# MAGIC         ) then 'Email is blacklist - select secondary'
# MAGIC         when b1_blacklist_domain is not null
# MAGIC         and (
# MAGIC           b_blacklist_domain is null
# MAGIC           and learner_email_domain is not null
# MAGIC         ) then 'Alternate email is blacklist - select primary'
# MAGIC         when (
# MAGIC           b_blacklist_domain is not null
# MAGIC           and b1_blacklist_domain is not null
# MAGIC           and learner_email_domain is not null
# MAGIC         ) then 'Only blacklist domains - select primary'
# MAGIC         when (
# MAGIC           b_blacklist_domain is null
# MAGIC           and b1_blacklist_domain is null
# MAGIC           and learner_email_domain is not null
# MAGIC         ) then 'Email Good - select primary'
# MAGIC         else 'Others'
# MAGIC       end as bucket
# MAGIC     from
# MAGIC       capability_v3
# MAGIC   ),
# MAGIC   alternate_emails as (
# MAGIC     select
# MAGIC       id_user,
# MAGIC       alternate_email,
# MAGIC       alternate_email_domain
# MAGIC     from
# MAGIC       alternate_emails
# MAGIC     -- select
# MAGIC     --   id_user,
# MAGIC     --   case
# MAGIC     --     trim(lower(field_37))
# MAGIC     --     when '' then null
# MAGIC     --     else trim(lower(field_37))
# MAGIC     --   end as alternate_email,
# MAGIC     --   split(trim(lower(field_37)), '@', 2) [1] as alternate_email_domain
# MAGIC     -- from
# MAGIC     --   main.it_docebo_bronze.core_user_field_value
# MAGIC     -- where
# MAGIC     --   processDate = (
# MAGIC     --     select
# MAGIC     --       max(processDate)
# MAGIC     --     from
# MAGIC     --       main.it_docebo_bronze.core_user_field_value
# MAGIC     --   )
# MAGIC   ),
# MAGIC   emails as (
# MAGIC     select
# MAGIC       distinct lower(email) as email,
# MAGIC       sha2(lower(email), 256) as email_hash
# MAGIC     from
# MAGIC       -- main.it_docebo_bronze.core_user
# MAGIC       main.it_training_silver.docebo_users
# MAGIC     where
# MAGIC       processdate =(
# MAGIC         Select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           -- main.it_docebo_bronze.core_user
# MAGIC           main.it_training_silver.docebo_users
# MAGIC       )
# MAGIC       and split(trim(lower(email)), '@', 2) [1] not in (
# MAGIC         select
# MAGIC           distinct blacklist_domain
# MAGIC         from
# MAGIC           blacklist_domains
# MAGIC       )
# MAGIC     union
# MAGIC       (
# MAGIC         select
# MAGIC           distinct lower(alternate_emails.alternate_email) as email,
# MAGIC           sha2(lower(alternate_Email), 256) as email_hash
# MAGIC         from
# MAGIC           alternate_emails
# MAGIC         where
# MAGIC           alternate_email_domain not in (
# MAGIC             select
# MAGIC               distinct blacklist_domain
# MAGIC             from
# MAGIC               blacklist_domains
# MAGIC           )
# MAGIC       )
# MAGIC   ),
# MAGIC   capability_final as (
# MAGIC     select
# MAGIC       p.*,
# MAGIC       e.email,
# MAGIC       case
# MAGIC         when p.bucket = 'Email is blacklist - select secondary' then e.email
# MAGIC         else p.updated_email
# MAGIC       end as final_email
# MAGIC     from
# MAGIC       capability_pre p
# MAGIC       left join emails e on p.learner_alternate_email_hash = e.email_hash
# MAGIC       and p.bucket = 'Email is blacklist - select secondary'
# MAGIC   ),
# MAGIC   -- fix learner_email_hash records that have one row with partner account and another without (because of learndot data)
# MAGIC   account_fix as (
# MAGIC     select
# MAGIC       distinct learner_email_hash,
# MAGIC       partner_account_name,
# MAGIC       partner_account_id_sfdc,
# MAGIC       dense_rank() over (
# MAGIC         partition by learner_email_hash
# MAGIC         order by
# MAGIC           partner_account_name nulls last
# MAGIC       ) as rank
# MAGIC     from
# MAGIC       main.field_learning_enablement.partner_capability
# MAGIC     where
# MAGIC       category = 'Technical Trained'
# MAGIC       and processDate = (
# MAGIC         select
# MAGIC           max(processdate)
# MAGIC         from
# MAGIC           main.field_learning_enablement.partner_capability
# MAGIC       )
# MAGIC   ),
# MAGIC   certs as (
# MAGIC     select
# MAGIC       p.final_email as certification_email,
# MAGIC       sha2(p.final_email, 256) as certification_email_hash,
# MAGIC       split(p.final_email, '@')[1] as email_domain,
# MAGIC       -- array_join(collect_set(p.updated_email), ",") as updated_email,
# MAGIC       -- array_join(collect_set(p.learner_email_hash), ",") as learner_email_hash,
# MAGIC       p.partner_account_name,
# MAGIC       p.partner_account_id_sfdc,
# MAGIC       u.region_derived,
# MAGIC       p.credential_id,
# MAGIC       p.issued_on,
# MAGIC       p.course as credential_name
# MAGIC     from
# MAGIC       capability_final p
# MAGIC       left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
# MAGIC     where
# MAGIC       p.category = 'Technical Certified'
# MAGIC     -- group by
# MAGIC     --   all
# MAGIC   )
# MAGIC
# MAGIC   select * 
# MAGIC   from certs
# MAGIC  
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC from top_80_partner_certs

# COMMAND ----------

# all_partner_certs_by_company_email_partition = add_gold_metadata(all_partner_certs_by_company_email)

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = all_partner_certs_by_company_email_partition, 
#   table_name = f'{focus_database_name}.partner_certs_by_company_email', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )