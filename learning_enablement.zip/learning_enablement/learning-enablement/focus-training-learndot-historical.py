# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from enum import Enum
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.historical_learndot_enrollments_ilt",  "processDate")


ld_ilt = (
  spark.table(f"{focus_database_name}.historical_learndot_enrollments_ilt")
    .filter(F.col("processDate") == latest_process_date)
    .drop("processDate")
)

ld_self_paced = (
  spark.table(f"{focus_database_name}.historical_learndot_enrollments_self_paced")
    .filter(F.col("processDate") == latest_process_date)
    # .filter(F.col("processDate") == '2024-01-01')
    .drop("processDate")
)

docebo_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.docebo_users",  "processDate")

docebo_users = (
  spark.table(f"{focus_database_name}.docebo_users")
    .filter(F.col("processDate") == docebo_latest_process_date)
    .select(
      'id',
      'email_hash',
      'email',
      'email_domain',
      'alternate_email_hash',
      'alternate_email',
      'alternate_email_domain',
      'last_login'
    )
)

ts_cs_process_date = get_latest_partition_value(spark, f"main.it_training_silver.docebo_users",  "processDate")

terms_conditions = (
  spark.table(f"main.it_training_silver.docebo_users")
    .filter(F.col("processDate") == docebo_latest_process_date)
    .select(
      'id',
      'accepted_t_and_c'
    )
)

users_conditions_pre = (
  docebo_users
    .join(terms_conditions, 'id', 'left')
)

# COMMAND ----------

mapping_window = W.Window.partitionBy("email_hash").orderBy(F.desc("last_login"), "tiebreak")


users_conditions_rank = (
  users_conditions_pre
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(mapping_window))
)

users_conditions = (
  users_conditions_rank 
    .filter(F.col("rank") == 1)
    .select(
      "id",
      "email_hash",
      "email",
      "email_domain",
      "alternate_email_hash",
      "alternate_email",
      "alternate_email_domain",
      "last_login",
      "accepted_t_and_c",
    )
)



# COMMAND ----------

ld_self_paced_pre = (
  ld_self_paced
    .withColumnRenamed('learner_email', 'learner_email_pre')
    .withColumnRenamed('learner_email_domain', 'learner_email_domain_pre')
    .withColumnRenamed('learner_alternate_email', 'learner_alternate_email_pre')
    .withColumnRenamed('learner_alternate_email_domain', 'learner_alternate_email_domain_pre')
    .withColumnRenamed('learner_alternate_email_hash', 'learner_alternate_email_hash_pre')
    .join(users_conditions, ld_self_paced.learner_email_hash==users_conditions.email_hash, 'left')
)

ld_self_paced_pre_2 = (
  ld_self_paced_pre
    .withColumn('learner_email', F.when((F.col('email').isNotNull() & F.col('accepted_t_and_c') == True), F.col('email')).when(F.col('accepted_t_and_c') == False, F.lit(None)).otherwise(F.col('learner_email_pre')))
    .withColumn('learner_email_domain', F.when(F.col('email_domain').isNotNull(), F.col('email_domain')).otherwise(F.col('learner_email_domain_pre')))
    .withColumn('learner_alternate_email', F.when(F.col('alternate_email').isNotNull(), F.col('alternate_email')).otherwise(F.col('learner_alternate_email_pre')))
    .withColumn('learner_alternate_email_domain', F.when(F.col('alternate_email_domain').isNotNull(), F.col('alternate_email_domain')).otherwise(F.col('learner_alternate_email_domain_pre')))
    .withColumn('learner_alternate_email_hash', F.when(F.col('alternate_email_hash').isNotNull(), F.col('alternate_email_hash')).otherwise(F.col('learner_alternate_email_hash_pre')))
    .select(
      'learner_user_id',
      'learner_email',
      'learner_branch_code',
      'learner_branch',
      'learner_email_hash',
      'learner_email_domain',
      'learner_alternate_email',
      'learner_alternate_email_domain',
      'learner_alternate_email_hash',
      'course_id',
      'course_code',
      'course_name',
      'course_type',
      'author_user_id',
      'category_id',
      'category_code',
      'status',
      'enrolled_timestamp',
      'completed_timestamp',
      'score',
      'author_email',
      'waiting',
      'source'
    )
)



# COMMAND ----------

ld_ilt_pre = (
  ld_ilt
    .withColumnRenamed('learner_email', 'learner_email_pre')
    .withColumnRenamed('learner_email_domain', 'learner_email_domain_pre')
    .withColumnRenamed('learner_alternate_email', 'learner_alternate_email_pre')
    .withColumnRenamed('learner_alternate_email_domain', 'learner_alternate_email_domain_pre')
    .withColumnRenamed('learner_alternate_email_hash', 'learner_alternate_email_hash_pre')
    .join(users_conditions, ld_ilt.learner_email_hash==users_conditions.email_hash, 'left')
)

ld_ilt_pre_2 = (
  ld_ilt_pre
    .withColumn('learner_email', F.when((F.col('email').isNotNull() & F.col('accepted_t_and_c') == True), F.col('email')).when(F.col('accepted_t_and_c') == False, F.lit(None)).otherwise(F.col('learner_email_pre')))
    .withColumn('learner_email_domain', F.when(F.col('email_domain').isNotNull(), F.col('email_domain')).otherwise(F.col('learner_email_domain_pre')))
    .withColumn('learner_alternate_email', F.when(F.col('alternate_email').isNotNull(), F.col('alternate_email')).otherwise(F.col('learner_alternate_email_pre')))
    .withColumn('learner_alternate_email_domain', F.when(F.col('alternate_email_domain').isNotNull(), F.col('alternate_email_domain')).otherwise(F.col('learner_alternate_email_domain_pre')))
    .withColumn('learner_alternate_email_hash', F.when(F.col('alternate_email_hash').isNotNull(), F.col('alternate_email_hash')).otherwise(F.col('learner_alternate_email_hash_pre')))
    .select(
      'learner_email',
      'learner_email_hash',
      'learner_email_domain',
      'learner_alternate_email',
      'learner_alternate_email_domain',
      'learner_alternate_email_hash',
      'learner_branch_code',
      'learner_branch',
      'session_id',
      'learner_user_id',
      'status',
      'waiting',
      'enrolled_timestamp',
      'completed_timestamp',
      'evaluated_timestamp',
      'score',
      'session_name',
      'course_id',
      'course_code',
      'course_name',
      'course_type',
      'author_user_id',
      'author_email',
      'category_code',
      'category_id',
      'source'
    )
)




# COMMAND ----------

# #Learndot Tables

# latest_process_date = get_latest_partition_value(spark, "sfdc_ds.learndot__learndot_contact__c",  "processDate")

# ld_contacts_source = (
#   spark.table(f"sfdc_ds.learndot__learndot_contact__c")
#     .filter(F.col("processDate") == latest_process_date)
# )

# ld_courses_source = (
#   spark.table(f"sfdc_ds.learndot__learndot_product__c")
#     .filter(F.col("processDate") == latest_process_date)
# )

# ld_enrollments_source = (
#   spark.table(f"sfdc_ds.learndot__learndot_enrollments__c")
#     .filter(F.col("processDate") == latest_process_date)
# )

# # Blacklisted domains

# blacklist_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.blacklist_domains",  "processDate")

# blacklist_domains = (
#   # spark.read.table("user_success_dev.blacklist_domains")
#   spark.read.table("focus_dev.blacklist_domains")
#     .filter(F.col("processDate") == blacklist_latest_process_date)
# )


# blacklist = [domain["blacklist_domain"] for domain in blacklist_domains.collect()]

# # Docebo Logfood data

# silver_docebo_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_salesforce_account_email_domain_mapping",  "processDate")

# salesforce_account_email_domain_mapping = (
#   spark.read.table("main.it_training_silver.docebo_salesforce_account_email_domain_mapping")
#     .filter(F.col("processDate") == silver_docebo_latest_process_date)
#     .drop("processDate")
# )

# # Partners (and Microsoft) were migrated from Learndot to Docebo on a different dates than other branches. We will need to filter enrollments based on branch and migration date
# first_migration_branches = ["DBK_PRTNR", "DBK_MCSFT"]
# first_migration_date = "2021-12-08"
# second_migration_date = "2022-01-07"

# # Docebo Branch Code Values
# class BranchCodes(Enum):
#   CUSTOMER = "DBKS_ACDMY"
#   PARTNER = "DBK_PRTNR"
#   EMPLOYEE = "DBK_EMP"
#   MICROSOFT = "DBK_MCSFT"

# # Docebo Branch Values
# class Branches(Enum):
#   CUSTOMER = "Academy"
#   PARTNER = "Partner"
#   EMPLOYEE = "Databricks"
#   MICROSOFT = "Microsoft"

# COMMAND ----------

# MAGIC %md
# MAGIC ######Env & Parameter Unit Tests

# COMMAND ----------

# # unit test to make sure dfs are pulled correctly
# assert unit_test_df_count(ld_enrollments_source) > 0

# # unit test to make sure parameters are set up correctly
# assert unit_test_valid_db(focus_database_name, spark)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# @udf("string")
# def updateEnrollmentStatus(status):
#   """ returns an updated enrollment status value """
#   if status == "COMPLETED":
#     enrollment_status = "completed"
#   elif status == "CONFIRMED":
#     enrollment_status = "subscribed"
#   elif status == "IN_PROGRESS":
#     enrollment_status = "in_progress"
#   else:
#     enrollment_status = status.lower()
  
#   return enrollment_status

# spark.udf.register("updateEnrollmentStatus", updateEnrollmentStatus)


# @udf("string")
# def courseType(enrollment_component_type, course_component_self_paced):
#   """ determines if course is self-paced, ilt, or other """
#   if enrollment_component_type == "eLearning Component" or course_component_self_paced == "course":
#     course_type = "elearning"
#   elif enrollment_component_type == "Instructor Led Training":
#     course_type = "classroom"
#   else:
#     course_type = enrollment_component_type
  
#   return course_type

# spark.udf.register("courseType", courseType)


# @udf("string")
# def learnerBranchCode(learner_email_domain, enrollment_provider):
#   """ assigns learner branch code values """
#   if learner_email_domain == "databricks.com":
#     learner_branch_code = BranchCodes.EMPLOYEE.value
#   elif learner_email_domain == "microsoft.com":
#     learner_branch_code = BranchCodes.MICROSOFT.value
#   elif learner_email_domain in partner_email_domains_list or enrollment_provider == "Databricks - Partner Enablement":
#     learner_branch_code = BranchCodes.PARTNER.value
#   else:
#     learner_branch_code = BranchCodes.CUSTOMER.value
  
#   return learner_branch_code

# spark.udf.register("learnerBranchCode", learnerBranchCode)

# @udf("string")
# def learnerBranch(learner_email_domain, enrollment_provider):
#   """ assigns learner branch code values """
#   if learner_email_domain == "databricks.com":
#     learner_branch = Branches.EMPLOYEE.value
#   elif learner_email_domain == "microsoft.com":
#     learner_branch = Branches.MICROSOFT.value
#   elif learner_email_domain in partner_email_domains_list or enrollment_provider == "Databricks - Partner Enablement":
#     learner_branch = Branches.PARTNER.value
#   else:
#     learner_branch = Branches.CUSTOMER.value
  
#   return learner_branch

# spark.udf.register("learnerBranch", learnerBranch)

# COMMAND ----------

# ld_contacts = (
#   ld_contacts_source
#     .select(
#       F.col("Id").alias("user_id"),
#       F.col("learndot__Email__c").alias("learner_email"),
#       F.col("Contact__c").alias("contact_id_sfdc"),
#       F.col("LastModifiedDate").alias("last_modified_date"),
#       F.col("learndot__ID__c").alias("learner_user_id"),
#     )
#     .withColumn("learner_email_domain", F.split("learner_email", "@", 2)[1])
#     .withColumn("learner_email_hash", F.sha2("learner_email", 256))
# )

# ld_courses = (
#   ld_courses_source
#     .select(
#       F.col("Id").alias("course_code"), 
#       F.col("learndot__name__c").alias("course_name"),
#       F.col("learndot__Custom_Field_10__c").alias("course_component_self_paced")
#            )
# )

# ld_enrollments = (
#   ld_enrollments_source
#     .select(
#       F.col("CreatedDate").alias("enrolled_timestamp"),
#       F.col("learndot__Learndot_Catalog_Item__c").alias("enrollment_catalog_item_sfdc"),
#       F.col("learndot__Provider__c").alias("enrollment_provider"),
#       F.col("learndot__completion_date__c").alias("completed_timestamp"),
#       F.col("learndot__component_type__c").alias("enrollment_component_type"),
#       F.col("learndot__component_name__c").alias("enrollment_component_name"),
#       F.col("learndot__status__c").alias("enrollment_status"),
#       F.col("learndot__Learndot_Contact__c").alias("enrollment_lms_contact_sfdc"),
#     )
# )

# account_name_window = W.Window.partitionBy("account_name").orderBy(F.desc("total_for_email_and_account"))
# email_domain_window = W.Window.partitionBy("email_domain").orderBy(F.desc("total_emails"))

# partner_email_domains = (
#   salesforce_account_email_domain_mapping
#     # limit to only partner accounts
#     .filter(F.col("account_record_type") == "Partner")
#     # remove any accounts without email domains
#     .filter(F.col("email_domain").isNotNull())
#     # remove blacklist email domains
#     .filter(~F.col("email_domain").isin(blacklist))
#     # rank to find most common email domain per account
#     .withColumn("rank", F.row_number().over(account_name_window))
#     .filter(F.col("rank") == 1)
#     # count total emails for each domain
#     .groupBy(["email_domain", "account_id"])
#     .agg(F.sum("total_for_email_and_account").alias("total_emails"))
#     # rank to find most common domain for each account
#     .withColumn("rank", F.row_number().over(email_domain_window))
#     .filter(F.col("rank") == 1)
#     .select("email_domain")
# )

# partner_email_domains_list = [domain["email_domain"] for domain in partner_email_domains.collect()]

# ld_enrollments_courses_contacts = (
#   ld_enrollments
#     .join(ld_courses, ld_enrollments.enrollment_catalog_item_sfdc == ld_courses.course_code, "left")
#     .join(ld_contacts, ld_enrollments.enrollment_lms_contact_sfdc == ld_contacts.user_id, "left")
#     .withColumn("learner_branch_code", learnerBranchCode("learner_email_domain", "enrollment_provider"))
#     .withColumn("learner_branch", learnerBranch("learner_email_domain", "enrollment_provider"))
# )

# ld_enrollments_courses_contacts_partners = (
#   ld_enrollments_courses_contacts
#     .filter(F.col("learner_branch_code").isin(first_migration_branches))
#     .filter(F.col("enrolled_timestamp") < first_migration_date)
# )

# ld_enrollments_courses_contacts_not_partners = (
#   ld_enrollments_courses_contacts
#     .filter(~F.col("learner_branch_code").isin(first_migration_branches))
#     .filter(F.col("enrolled_timestamp") < second_migration_date)
# )

# ld_enrollments_final = (
#   ld_enrollments_courses_contacts_partners
#     .union(ld_enrollments_courses_contacts_not_partners)
#     .withColumn("status", updateEnrollmentStatus("enrollment_status"))
#     .withColumn("course_type", courseType("enrollment_component_type", "course_component_self_paced")
#      )
#     .withColumn("learner_alternate_email", F.lit(None))
#     .withColumn("learner_alternate_email_domain", F.lit(None))
#     .withColumn("learner_alternate_email_hash", F.lit(None))
#     .withColumn("category_code", F.lit(None))
#     .withColumn("course_id", F.lit(None))
#     .withColumn("author_user_id", F.lit(None))
#     .withColumn("author_email", F.lit(None))
#     .withColumn("category_id", F.lit(None))
#     .withColumn("score", F.lit(None))
#     .withColumn("evaluated_timestamp", F.lit(None))
#     .withColumn("session_id", F.lit(None))
#     .withColumn("session_name", F.lit(None))
#     .withColumn("waiting", F.lit(None))
#     .withColumn("processDate", F.to_date(F.lit(partition_date)))
#     .withColumn("source", F.lit("Learndot"))
# )

# ld_self_paced_enrollments = (
#   ld_enrollments_final
#     .filter(F.col("course_type") == "elearning")
#     .select(
#         F.col("learner_user_id").cast(T.LongType()),
#         F.col("learner_email"),
#         F.col("learner_branch_code"),
#         F.col("learner_branch"),
#         F.col("learner_email_hash"),
#         F.col("learner_email_domain"),
#         F.col("learner_alternate_email").cast(T.StringType()),
#         F.col("learner_alternate_email_domain").cast(T.StringType()),
#         F.col("learner_alternate_email_hash").cast(T.StringType()),
#         F.col("course_id").cast(T.LongType()),
#         F.col("course_code"),
#         F.col("course_name"),
#         F.col("course_type"),
#         F.col("author_user_id").cast(T.LongType()),
#         F.col("category_id").cast(T.LongType()),
#         F.col("category_code").cast(T.StringType()),
#         F.col("status"),
#         F.col("enrolled_timestamp"),
#         F.col("completed_timestamp"),
#         F.col("score").cast(T.DoubleType()),
#         F.col("author_email").cast(T.StringType()),
#         F.col("waiting").cast(T.LongType()),
#         F.col("processDate"),
#         F.col("source"),
#       )
# )

# ld_ilt_enrollments = (
#   ld_enrollments_final
#     .filter(F.col("course_type") == "classroom")
#     .select(     
#         F.col("learner_email"),
#         F.col("learner_email_hash"),
#         F.col("learner_email_domain"),
#         F.col("learner_alternate_email").cast(T.StringType()),
#         F.col("learner_alternate_email_domain").cast(T.StringType()),
#         F.col("learner_alternate_email_hash").cast(T.StringType()),
#         F.col("learner_branch_code"),
#         F.col("learner_branch"),
#         F.col("session_id").cast(T.LongType()),
#         F.col("learner_user_id").cast(T.LongType()),
#         F.col("status"),
#         F.col("waiting").cast(T.LongType()),
#         F.col("enrolled_timestamp"),
#         F.col("completed_timestamp"),
#         F.col("evaluated_timestamp").cast(T.TimestampType()),
#         F.col("score").cast(T.DoubleType()),
#         F.col("session_name").cast(T.StringType()),
#         F.col("course_id").cast(T.LongType()),
#         F.col("course_code"),
#         F.col("course_name"),
#         F.col("course_type"),
#         F.col("author_user_id").cast(T.LongType()),
#         F.col("author_email").cast(T.StringType()),
#         F.col("category_code").cast(T.StringType()),
#         F.col("category_id").cast(T.LongType()),        
#         F.col("processDate"),
#         F.col("source"),
#       )
# )


# COMMAND ----------

ld_ilt_partition = add_gold_metadata(ld_ilt_pre_2)
ld_self_paced_partition = add_gold_metadata(ld_self_paced_pre_2)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = ld_self_paced_partition, 
  table_name = f'{focus_database_name}.historical_learndot_enrollments_self_paced', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = ld_ilt_partition, 
  table_name = f'{focus_database_name}.historical_learndot_enrollments_ilt', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)