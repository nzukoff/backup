# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.field_learning_enablement.all_enrollments_df AS
# MAGIC SELECT DISTINCT learner_user_id, course_code, course_name, status, enrolled_date, completed_date, course_type, all_enrollments.audience,
# MAGIC       all_enrollments.business_unit, all_enrollments.sales_subregion_level_1,
# MAGIC        CASE WHEN status = 'completed' THEN 1 ELSE 0 END AS is_completed
# MAGIC FROM main.field_learning_enablement.all_enrollments
# MAGIC WHERE processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.all_enrollments)
# MAGIC and all_enrollments.source = 'Docebo';
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.field_learning_enablement.all_enrollments_metrics AS(
# MAGIC SELECT 
# MAGIC     a.learner_user_id,
# MAGIC     a.course_code, 
# MAGIC     a.course_name, 
# MAGIC     a.course_type, 
# MAGIC     a.audience,
# MAGIC     a.business_unit, 
# MAGIC     a.sales_subregion_level_1,
# MAGIC     a.status,
# MAGIC     -- Number of enrolled and completed users
# MAGIC     COUNT(DISTINCT CASE WHEN a.status = 'subscribed' THEN a.learner_user_id END) AS enrolled_users,
# MAGIC     COUNT(DISTINCT CASE WHEN a.status = 'completed' THEN a.learner_user_id END) AS completed_users,
# MAGIC     -- Drop rate
# MAGIC     try_divide(COUNT(DISTINCT CASE
# MAGIC         WHEN a.status = 'completed' AND DATEDIFF(a.completed_date, a.enrolled_date) > 90 THEN a.learner_user_id
# MAGIC         WHEN a.status = 'subscribed' AND DATEDIFF(current_date, a.enrolled_date) > 90 THEN a.learner_user_id
# MAGIC         END) * 1.0 ,
# MAGIC     COUNT(DISTINCT CASE
# MAGIC         WHEN a.status IN ('completed', 'subscribed') THEN a.learner_user_id END)) * 100 AS drop_rate_percentage,
# MAGIC     -- Avg days to complete course
# MAGIC     AVG(CASE 
# MAGIC         WHEN a.completed_date > a.enrolled_date THEN DATEDIFF(a.completed_date, a.enrolled_date) + 1
# MAGIC         WHEN a.enrolled_date = a.completed_date THEN 1
# MAGIC         WHEN a.enrolled_date > a.completed_date THEN 0
# MAGIC         END) AS avg_days_to_complete
# MAGIC FROM 
# MAGIC     main.field_learning_enablement.all_enrollments_df a
# MAGIC GROUP BY 
# MAGIC     a.learner_user_id,
# MAGIC     a.course_code, 
# MAGIC     a.course_name, 
# MAGIC     a.course_type, 
# MAGIC     a.audience,
# MAGIC     a.business_unit, 
# MAGIC     a.sales_subregion_level_1,
# MAGIC     a.status
# MAGIC )
# MAGIC