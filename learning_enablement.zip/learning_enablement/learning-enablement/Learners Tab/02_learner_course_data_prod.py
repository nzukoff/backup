# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE table main.field_learning_enablement.learner_data_metrics AS
# MAGIC WITH avg_time_pre_rank AS (
# MAGIC     SELECT 
# MAGIC         id, 
# MAGIC         expected_time_to_complete_in_seconds,
# MAGIC         RANK() OVER (PARTITION BY id ORDER BY expected_time_to_complete_in_seconds NULLS LAST, category_code DESC) AS rank 
# MAGIC     FROM main.it_training_silver.docebo_courses
# MAGIC     WHERE processDate = (SELECT MAX(processDate) FROM main.it_training_silver.docebo_courses)
# MAGIC ),
# MAGIC
# MAGIC employee_data AS (
# MAGIC     SELECT 
# MAGIC         department, 
# MAGIC         category, 
# MAGIC         `1st_level_manager`,
# MAGIC         `1st_level_manager_name`,
# MAGIC         `2nd_level_manager`, 
# MAGIC         `2nd_level_manager_name`,
# MAGIC         `3rd_level_manager`, 
# MAGIC         `3rd_level_manager_name`,
# MAGIC         `4th_level_manager`,
# MAGIC         `4th_level_manager_name`,
# MAGIC         `5th_level_manager`, 
# MAGIC         `5th_level_manager_name`,
# MAGIC         `6th_level_manager`,
# MAGIC         `6th_level_manager_name`,
# MAGIC         Supervisory_Organization_cleaned,
# MAGIC         primaryWorkEmail,
# MAGIC         SHA2(primaryWorkEmail,256) AS email_hash
# MAGIC     FROM main.field_learning_enablement.workday
# MAGIC     WHERE processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.workday)
# MAGIC     AND worker_type = 'Employee'
# MAGIC     AND Termination_Date IS NULL
# MAGIC ),
# MAGIC
# MAGIC avg_time AS (
# MAGIC     SELECT * 
# MAGIC     FROM avg_time_pre_rank 
# MAGIC     WHERE rank = 1
# MAGIC ),
# MAGIC
# MAGIC sp_enrollments AS (
# MAGIC     SELECT
# MAGIC         processdate,
# MAGIC         learner_user_id,
# MAGIC         learner_email,
# MAGIC         learner_email_hash,
# MAGIC         learner_email_domain,
# MAGIC         learner_alternate_email,
# MAGIC         learner_alternate_email_hash,
# MAGIC         learner_alternate_email_domain,
# MAGIC         learner_branch_code,
# MAGIC         account_id,
# MAGIC         account_name,
# MAGIC         ultimate_parent_account_id,
# MAGIC         ultimate_parent_account_name, 
# MAGIC         updated_account_id,
# MAGIC         updated_account_name,
# MAGIC         updated_ultimate_parent_account_id,
# MAGIC         updated_ultimate_parent_account_name, 
# MAGIC         audience,
# MAGIC         course_code,
# MAGIC         course_name,
# MAGIC         course_type,
# MAGIC         category_code,
# MAGIC         status,
# MAGIC         enrolled_timestamp::DATE AS enrolled_date,
# MAGIC         completed_timestamp::DATE AS completed_date,
# MAGIC         completed_timestamp,
# MAGIC         source,
# MAGIC         country_code, 
# MAGIC         country_name, 
# MAGIC         region, 
# MAGIC         d.fiscal_year_quarter AS fq2,
# MAGIC         CAST(d.calendar_month AS INT) AS month,
# MAGIC         CAST(d.calendar_year AS INT) AS year,
# MAGIC         CAST(d.fiscal_year AS INT) AS fiscalYear,
# MAGIC         d.fiscal_quarter_start_date AS qtr_start_date,
# MAGIC         d.fiscal_quarter_end_date AS qtr_end_date,
# MAGIC         t.expected_time_to_complete_in_seconds,
# MAGIC         match_method, 
# MAGIC         country_derived,
# MAGIC         region_derived
# MAGIC     FROM main.field_learning_enablement.self_paced_enrollments e
# MAGIC     INNER JOIN main.it_core_dim.dim_dates d ON e.completed_timestamp::DATE = d.date 
# MAGIC     LEFT JOIN avg_time t ON e.course_id = t.id
# MAGIC     WHERE e.status IN ('completed')
# MAGIC     AND e.source = 'Learndot'
# MAGIC     AND e.learner_branch_code IN ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
# MAGIC     AND e.processdate = (SELECT MAX(processdate) FROM main.field_learning_enablement.self_paced_enrollments)
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT     
# MAGIC         processdate,
# MAGIC         learner_user_id,
# MAGIC         learner_email,
# MAGIC         learner_email_hash,
# MAGIC         learner_email_domain,
# MAGIC         learner_alternate_email,
# MAGIC         learner_alternate_email_hash,
# MAGIC         learner_alternate_email_domain,
# MAGIC         learner_branch_code,
# MAGIC         account_id,
# MAGIC         account_name,
# MAGIC         ultimate_parent_account_id,
# MAGIC         ultimate_parent_account_name, 
# MAGIC         updated_account_id,
# MAGIC         updated_account_name,
# MAGIC         updated_ultimate_parent_account_id,
# MAGIC         updated_ultimate_parent_account_name, 
# MAGIC         audience,
# MAGIC         course_code,
# MAGIC         course_name,
# MAGIC         course_type,
# MAGIC         category_code,
# MAGIC         status,
# MAGIC         enrolled_timestamp::DATE AS enrolled_date,
# MAGIC         completed_timestamp::DATE AS completed_date,
# MAGIC         completed_timestamp,
# MAGIC         source,
# MAGIC         country_code, 
# MAGIC         country_name, 
# MAGIC         region, 
# MAGIC         d.fiscal_year_quarter AS fq2,
# MAGIC         CAST(d.calendar_month AS INT) AS month,
# MAGIC         CAST(d.calendar_year AS INT) AS year,
# MAGIC         CAST(d.fiscal_year AS INT) AS fiscalYear,
# MAGIC         d.fiscal_quarter_start_date AS qtr_start_date,
# MAGIC         d.fiscal_quarter_end_date AS qtr_end_date,
# MAGIC         t.expected_time_to_complete_in_seconds,
# MAGIC         match_method, 
# MAGIC         country_derived,
# MAGIC         region_derived
# MAGIC     FROM main.field_learning_enablement.self_paced_enrollments e
# MAGIC     INNER JOIN main.it_core_dim.dim_dates d ON e.completed_timestamp::DATE = d.date
# MAGIC     LEFT JOIN avg_time t ON e.course_id = t.id
# MAGIC     WHERE e.status IN ('completed')
# MAGIC     AND e.source = 'Docebo'
# MAGIC     AND e.category_code IN ('PART','ACAD','FENG/CUSU','FENG')
# MAGIC     AND (e.course_code ILIKE ('%-SLP%') OR e.course_code ILIKE '%-ILTB-%')
# MAGIC     AND e.course_code NOT ILIKE ('%DNR')
# MAGIC     AND e.learner_branch_code IN ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
# MAGIC     AND e.processdate = (SELECT MAX(processdate) FROM main.field_learning_enablement.self_paced_enrollments)
# MAGIC ),
# MAGIC
# MAGIC ilt_enrollments_pre AS (
# MAGIC     SELECT 
# MAGIC         processdate,
# MAGIC         learner_user_id,
# MAGIC         learner_email,
# MAGIC         learner_email_hash,
# MAGIC         learner_email_domain,
# MAGIC         learner_alternate_email,
# MAGIC         learner_alternate_email_hash,
# MAGIC         learner_alternate_email_domain,
# MAGIC         learner_branch_code,
# MAGIC         account_id,
# MAGIC         account_name,
# MAGIC         ultimate_parent_account_id,
# MAGIC         ultimate_parent_account_name, 
# MAGIC         updated_account_id,
# MAGIC         updated_account_name,
# MAGIC         updated_ultimate_parent_account_id,
# MAGIC         updated_ultimate_parent_account_name, 
# MAGIC         audience,
# MAGIC         course_code,
# MAGIC         course_name,
# MAGIC         course_type,
# MAGIC         category_code,
# MAGIC         status,
# MAGIC         enrolled_timestamp::DATE AS enrolled_date,
# MAGIC         completed_timestamp::DATE AS completed_date,
# MAGIC         completed_timestamp,
# MAGIC         source,
# MAGIC         country_code, 
# MAGIC         country_name,
# MAGIC         region,
# MAGIC         d.fiscal_year_quarter AS fq2,
# MAGIC         CAST(d.calendar_month AS INT) AS month,
# MAGIC         CAST(d.calendar_year AS INT) AS year,
# MAGIC         CAST(d.fiscal_year AS INT) AS fiscalYear,
# MAGIC         d.fiscal_quarter_start_date AS qtr_start_date,
# MAGIC         d.fiscal_quarter_end_date AS qtr_end_date,
# MAGIC         3*60*60 AS expected_time_to_complete_in_seconds,
# MAGIC         match_method, 
# MAGIC         country_derived,
# MAGIC         region_derived
# MAGIC     FROM main.field_learning_enablement.ilt_enrollments e
# MAGIC     INNER JOIN main.it_core_dim.dim_dates d ON e.completed_timestamp::DATE = d.date
# MAGIC     WHERE e.status IN ('completed')
# MAGIC     AND e.source = 'Learndot'
# MAGIC     AND e.learner_branch_code IN ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
# MAGIC     AND e.processdate = (SELECT MAX(processdate) FROM main.field_learning_enablement.ilt_enrollments)
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT 
# MAGIC         processdate,
# MAGIC         learner_user_id,
# MAGIC         learner_email,
# MAGIC         learner_email_hash,
# MAGIC         learner_email_domain,
# MAGIC         learner_alternate_email,
# MAGIC         learner_alternate_email_hash,
# MAGIC         learner_alternate_email_domain,
# MAGIC         learner_branch_code,
# MAGIC         account_id,
# MAGIC         account_name,
# MAGIC         ultimate_parent_account_id,
# MAGIC         ultimate_parent_account_name, 
# MAGIC         updated_account_id,
# MAGIC         updated_account_name,
# MAGIC         updated_ultimate_parent_account_id,
# MAGIC         updated_ultimate_parent_account_name, 
# MAGIC         audience,
# MAGIC         course_code,
# MAGIC         course_name,
# MAGIC         course_type,
# MAGIC         category_code,
# MAGIC         status,
# MAGIC         enrolled_timestamp::DATE AS enrolled_date,
# MAGIC         completed_timestamp::DATE AS completed_date,
# MAGIC         completed_timestamp,
# MAGIC         source,
# MAGIC         country_code, 
# MAGIC         country_name, 
# MAGIC         region, 
# MAGIC         d.fiscal_year_quarter AS fq2,
# MAGIC         CAST(d.calendar_month AS INT) AS month,
# MAGIC         CAST(d.calendar_year AS INT) AS year,
# MAGIC         CAST(d.fiscal_year AS INT) AS fiscalYear,
# MAGIC         d.fiscal_quarter_start_date AS qtr_start_date,
# MAGIC         d.fiscal_quarter_end_date AS qtr_end_date,
# MAGIC         t.expected_time_to_complete_in_seconds,
# MAGIC         match_method, 
# MAGIC         country_derived,
# MAGIC         region_derived
# MAGIC     FROM main.field_learning_enablement.ilt_enrollments e
# MAGIC     INNER JOIN main.it_core_dim.dim_dates d ON e.completed_timestamp::DATE = d.date
# MAGIC     LEFT JOIN avg_time t ON e.course_id = t.id
# MAGIC     WHERE e.status IN ('completed')
# MAGIC     AND e.category_code IN ('PART','ACAD','FENG/CUSU','FENG', 'ACAD-ALL-ILT-PAID')
# MAGIC     AND e.source = 'Docebo'
# MAGIC     AND e.learner_branch_code IN ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
# MAGIC     AND e.processdate = (SELECT MAX(processdate) FROM main.field_learning_enablement.ilt_enrollments)
# MAGIC ),
# MAGIC
# MAGIC ilt_enrollments_dedupe AS (
# MAGIC     SELECT 
# MAGIC         *,
# MAGIC         RANK() OVER (PARTITION BY i.learner_user_id, i.course_code, i.completed_timestamp ORDER BY i.category_code) AS dedupe_rank
# MAGIC     FROM ilt_enrollments_pre i
# MAGIC     where i.source = 'Docebo'
# MAGIC ),
# MAGIC
# MAGIC ilt_enrollments_final AS (
# MAGIC     SELECT * 
# MAGIC     FROM ilt_enrollments_dedupe 
# MAGIC     WHERE dedupe_rank = 1
# MAGIC     and source = 'Docebo'
# MAGIC ),
# MAGIC
# MAGIC sp_enrollments_dedupe AS (
# MAGIC     SELECT 
# MAGIC         s.*, 
# MAGIC         RANK() OVER (PARTITION BY s.learner_user_id, s.course_code, s.completed_timestamp ORDER BY s.category_code) AS dedupe_rank 
# MAGIC     FROM sp_enrollments s
# MAGIC     where s.source = 'Docebo'
# MAGIC ),
# MAGIC
# MAGIC sp_enrollments_final AS (
# MAGIC     SELECT * 
# MAGIC     FROM sp_enrollments_dedupe 
# MAGIC     WHERE dedupe_rank = 1
# MAGIC     and source = 'Docebo'
# MAGIC ),
# MAGIC
# MAGIC all_enrollments AS (
# MAGIC     SELECT * FROM ilt_enrollments_final
# MAGIC     UNION ALL
# MAGIC     SELECT * FROM sp_enrollments_final
# MAGIC ),
# MAGIC
# MAGIC rolling_totals AS (
# MAGIC     SELECT 
# MAGIC         completed_timestamp, 
# MAGIC         learner_user_id, 
# MAGIC         course_code, 
# MAGIC         category_code,
# MAGIC         expected_time_to_complete_in_seconds,
# MAGIC         SUM(expected_time_to_complete_in_seconds) OVER (PARTITION BY learner_user_id ORDER BY completed_timestamp ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS rollingTotal 
# MAGIC     FROM all_enrollments e
# MAGIC     GROUP BY 1,2,3,4,5
# MAGIC ),
# MAGIC
# MAGIC all_enrollments_filtered AS (
# MAGIC     SELECT 
# MAGIC         s.*,
# MAGIC         t.rollingTotal
# MAGIC     FROM all_enrollments s 
# MAGIC     LEFT JOIN rolling_totals t
# MAGIC         ON s.learner_user_id = t.learner_user_id
# MAGIC         AND s.course_code = t.course_code
# MAGIC         AND s.completed_timestamp = t.completed_timestamp
# MAGIC ),
# MAGIC
# MAGIC learners_added_fields AS (
# MAGIC     SELECT *,
# MAGIC         CASE 
# MAGIC             WHEN rollingTotal >= 3*60*60 THEN 1 
# MAGIC             ELSE 0 
# MAGIC         END AS learner_status_in_time,
# MAGIC         MAX(rollingTotal) OVER (PARTITION BY learner_user_id) AS max_time_spent
# MAGIC     FROM all_enrollments_filtered
# MAGIC     WHERE processdate = (SELECT MAX(processdate) FROM all_enrollments_filtered)
# MAGIC )
# MAGIC
# MAGIC SELECT DISTINCT 
# MAGIC     processdate,
# MAGIC     learner_user_id, 
# MAGIC     course_type,
# MAGIC     course_code, 
# MAGIC     course_name, 
# MAGIC     status, 
# MAGIC     enrolled_date, 
# MAGIC     completed_date, 
# MAGIC     expected_time_to_complete_in_seconds, 
# MAGIC     max_time_spent, 
# MAGIC     rollingTotal
# MAGIC
# MAGIC FROM learners_added_fields
# MAGIC where learners_added_fields.source = 'Docebo'
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.field_learning_enablement.learner_data_metrics_final AS
# MAGIC WITH learner_cross_3hr AS (
# MAGIC     SELECT
# MAGIC         DISTINCT course_code, course_type,
# MAGIC         learner_user_id,
# MAGIC         rollingTotal,
# MAGIC         RANK() OVER (PARTITION BY learner_user_id ORDER BY rollingTotal, completed_date ASC) AS rank_of_course
# MAGIC     FROM main.field_learning_enablement.learner_data_metrics
# MAGIC     WHERE rollingTotal >= 10800   
# MAGIC ),
# MAGIC helped_become_learner AS (
# MAGIC     SELECT 
# MAGIC         course_code,course_type,learner_user_id,
# MAGIC         CASE WHEN rank_of_course = 1 THEN 1 ELSE 0 END AS helped_become_learner
# MAGIC     FROM learner_cross_3hr
# MAGIC ),
# MAGIC longest_course_duration AS (
# MAGIC     SELECT distinct
# MAGIC         course_code, 
# MAGIC         course_type,
# MAGIC         learner_user_id, 
# MAGIC         RANK() OVER(PARTITION BY learner_user_id ORDER BY expected_time_to_complete_in_seconds DESC) AS longest_course_duration_taken 
# MAGIC     FROM main.field_learning_enablement.learner_data_metrics
# MAGIC ),
# MAGIC duration_courses_max as(
# MAGIC   SELECT 
# MAGIC         course_code, 
# MAGIC         course_type,
# MAGIC         learner_user_id, 
# MAGIC         CASE WHEN longest_course_duration_taken = 1 THEN 1 ELSE 0 END AS longest_duration_course
# MAGIC   from longest_course_duration
# MAGIC )
# MAGIC SELECT 
# MAGIC     m.course_code, 
# MAGIC     m.course_type,
# MAGIC     m.learner_user_id,
# MAGIC     m.expected_time_to_complete_in_seconds,
# MAGIC     lc.helped_become_learner,
# MAGIC     d.longest_duration_course
# MAGIC FROM main.field_learning_enablement.learner_data_metrics m
# MAGIC LEFT JOIN helped_become_learner lc ON m.course_code = lc.course_code AND m.learner_user_id = lc.learner_user_id AND m.course_type = lc.course_type
# MAGIC left join duration_courses_max d on d.course_code = m.course_code AND d.learner_user_id = m.learner_user_id AND m.course_type = d.course_type
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.field_learning_enablement.learner_unified AS
# MAGIC select 
# MAGIC a.course_code,
# MAGIC a.course_name,
# MAGIC a.course_type,
# MAGIC a.audience,
# MAGIC a.business_unit, 
# MAGIC a.sales_subregion_level_1, 
# MAGIC sum(a.enrolled_users) as enrolled_users, 
# MAGIC sum(a.completed_users) as completed_users, 
# MAGIC avg(a.drop_rate_percentage) as  drop_rate_percentage, 
# MAGIC avg(a.avg_days_to_complete) as avg_days_to_complete,  
# MAGIC sum(case when a.status = 'completed' then b.expected_time_to_complete_in_seconds/3600 else 0 end) as total_time_spent_completed,
# MAGIC sum(b.helped_become_learner) as helped_become_learner,
# MAGIC sum(b.longest_duration_course) as longest_duration_course
# MAGIC from
# MAGIC main.field_learning_enablement.all_enrollments_metrics a
# MAGIC left join main.field_learning_enablement.learner_data_metrics_final b
# MAGIC on a.learner_user_id = b.learner_user_id
# MAGIC and a.course_code = b.course_code
# MAGIC and a.course_type = b.course_type
# MAGIC group by 
# MAGIC a.course_code,
# MAGIC a.course_name,
# MAGIC a.course_type,
# MAGIC a.audience,
# MAGIC a.business_unit, 
# MAGIC a.sales_subregion_level_1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC grant select on table main.field_learning_enablement.learner_unified to `joey.frazee@databricks.com`