# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# from pprint import pprint
# from pyspark.sql import DataFrame, Column
# from typing import Optional, Sequence as Seq, Dict, Callable, Any

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# verbose = get_verbose_func(VERBOSE)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view alternate_emails as 
# MAGIC with blacklist_domains as (
# MAGIC   select
# MAGIC     distinct blacklist_domain
# MAGIC   from
# MAGIC     main.field_learning_enablement.blacklist_domains
# MAGIC   where
# MAGIC     processDate = (
# MAGIC       select
# MAGIC         max(processDate)
# MAGIC       from
# MAGIC         main.field_learning_enablement.blacklist_domains
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC alt_emails as (
# MAGIC   select 
# MAGIC     id as id_user, 
# MAGIC     lower(alternate_email) as alternate_email, 
# MAGIC     lower(alternate_email_2) as alternate_email_2, 
# MAGIC     lower(alternate_email_domain) as alternate_email_domain,
# MAGIC     lower(alternate_email_2_domain) as alternate_email_2_domain, 
# MAGIC     branch_code, 
# MAGIC     b.blacklist_domain as b_blacklist_domain,
# MAGIC     b1.blacklist_domain as b1_blacklist_domain
# MAGIC   from main.it_training_silver.docebo_users u
# MAGIC   left join blacklist_domains b on u.alternate_email_domain = b.blacklist_domain
# MAGIC   left join blacklist_domains b1 on u.alternate_email_2_domain = b1.blacklist_domain
# MAGIC   where u.processDate = (select max(processDate) from main.it_training_silver.docebo_users)
# MAGIC )
# MAGIC , 
# MAGIC alt_emails_blacklist as (
# MAGIC   select
# MAGIC     *,
# MAGIC     case
# MAGIC       when b_blacklist_domain is not null
# MAGIC       and (
# MAGIC         b1_blacklist_domain is null
# MAGIC         and alternate_email_2_domain is not null
# MAGIC       ) then 'Email is blacklist - select secondary'
# MAGIC       when b1_blacklist_domain is not null
# MAGIC       and (
# MAGIC         b_blacklist_domain is null
# MAGIC         and alternate_email_domain is not null
# MAGIC       ) then 'Alternate email is blacklist - select primary'
# MAGIC       when (
# MAGIC         b_blacklist_domain is not null
# MAGIC         and b1_blacklist_domain is not null
# MAGIC         and alternate_email_domain is not null
# MAGIC       ) then 'Only blacklist domains - select primary'
# MAGIC       when (
# MAGIC         b_blacklist_domain is null
# MAGIC         and b1_blacklist_domain is null
# MAGIC         and alternate_email_domain is not null
# MAGIC       ) then 'Email Good - select primary'
# MAGIC       else 'Others'
# MAGIC     end as bucket
# MAGIC   from alt_emails
# MAGIC )
# MAGIC , 
# MAGIC final as (
# MAGIC   select
# MAGIC     p.*,
# MAGIC     case
# MAGIC       when p.bucket = 'Email is blacklist - select secondary' then p.alternate_email_2
# MAGIC       else p.alternate_email
# MAGIC     end as final_email,
# MAGIC     case
# MAGIC       when p.bucket = 'Email is blacklist - select secondary' then p.alternate_email_2_domain
# MAGIC       else p.alternate_email_domain
# MAGIC     end as final_email_domain
# MAGIC   from
# MAGIC     alt_emails_blacklist p
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC   id_user, 
# MAGIC   final_email as alternate_email, 
# MAGIC   final_email_domain as alternate_email_domain
# MAGIC from final 

# COMMAND ----------

# DBTITLE 1,Docebo User Data Processing
df = spark.sql('''
  with ranked_docebo_users as (
    select
      *,
      rank() over (
        partition by email_hash
        order by
          last_login
      ) as rank_data
    from
      main.field_learning_enablement.docebo_users
    where
      processdate =(
        Select
          max(processdate)
        from
          main.field_learning_enablement.docebo_users
      )
      and nvl(audience, 'Unknown') in ('Partner', 'Partner Other')
  ),
  docebo_users as (
    select
      *
    from
      ranked_docebo_users
    where
      rank_data = 1
  ),
  blacklist_domains as (
    select
      distinct blacklist_domain
    from
      main.field_learning_enablement.blacklist_domains
    where
      processDate = (
        select
          max(processDate)
        from
          main.field_learning_enablement.blacklist_domains
      )
  ),
  capability as (
    select
      c.*
    except(c.learner_email_domain),
      case
        when c.learner_email_hash = '78dfc4089d9f80cbae14429cb95508c1955262ebdee4184c4e3fb3503a70ae18' then 'gmail.com'
        else learner_email_domain
      end as learner_email_domain
    from
      main.field_learning_enablement.partner_capability c
    where
      c.processdate = (
        select
          max(processdate)
        from
          main.field_learning_enablement.partner_capability
      )
      and learner_email_hash is not null
  ),
  -- fix learner_user_ids records that have one row with contact email and another without (because of learndot data)
  contact_email_fix as (
    select
      distinct learner_email_hash,
      contact_email,
      dense_rank() over (
        partition by learner_email_hash
        order by
          contact_email nulls last
      ) as rank
    from
      main.field_learning_enablement.partner_capability
    where
      category = 'Technical Trained'
      and processDate = (
        select
          max(processdate)
        from
          main.field_learning_enablement.partner_capability
      )
  ),
  capability_v2 as (
    select
      c.*,
      case
        when category = 'Technical Certified' then a.recipient_email
        else d.contact_email
      end as updated_email
    from
      capability c
      left join contact_email_fix d on c.learner_email_hash = d.learner_email_hash
      and d.rank = 1
      and c.category = 'Technical Trained'
      left join main.it_accredible_bronze.credentials a on c.credential_id = a.credential_id
      and a.processdate = (
        select
          max(processdate)
        from
          main.it_accredible_bronze.credentials
      )
  ),
  capability_v3 as (
    select
      c.*,
      b.blacklist_domain as b_blacklist_domain,
      b1.blacklist_domain as b1_blacklist_domain
    from
      capability_v2 c
      left join blacklist_domains b on c.learner_email_domain = b.blacklist_domain
      left join blacklist_domains b1 on c.learner_alternate_email_domain = b1.blacklist_domain
  ),
  capability_pre as (
    select
      *,
      case
        when b_blacklist_domain is not null
        and (
          b1_blacklist_domain is null
          and learner_alternate_email_domain is not null
        ) then 'Email is blacklist - select secondary'
        when b1_blacklist_domain is not null
        and (
          b_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Alternate email is blacklist - select primary'
        when (
          b_blacklist_domain is not null
          and b1_blacklist_domain is not null
          and learner_email_domain is not null
        ) then 'Only blacklist domains - select primary'
        when (
          b_blacklist_domain is null
          and b1_blacklist_domain is null
          and learner_email_domain is not null
        ) then 'Email Good - select primary'
        else 'Others'
      end as bucket
    from
      capability_v3
  ),
  alternate_emails as (
    select
      id_user,
      alternate_email,
      alternate_email_domain
    from
      alternate_emails
    -- select
    --   id_user,
    --   case
    --     trim(lower(field_37))
    --     when '' then null
    --     else trim(lower(field_37))
    --   end as alternate_email,
    --   split(trim(lower(field_37)), '@', 2) [1] as alternate_email_domain
    -- from
    --   main.it_docebo_bronze.core_user_field_value
    -- where
    --   processDate = (
    --     select
    --       max(processDate)
    --     from
    --       main.it_docebo_bronze.core_user_field_value
    --   )
  ),
  emails as (
    select
      distinct lower(email) as email,
      sha2(lower(email), 256) as email_hash
    from
      main.it_training_silver.docebo_users
      -- main.it_docebo_bronze.core_user
    where
      processdate =(
        Select
          max(processdate)
        from
          main.it_training_silver.docebo_users
          -- main.it_docebo_bronze.core_user
      )
      and split(trim(lower(email)), '@', 2) [1] not in (
        select
          distinct blacklist_domain
        from
          blacklist_domains
      )
    union
      (
        select
          distinct lower(alternate_emails.alternate_email) as email,
          sha2(lower(alternate_Email), 256) as email_hash
        from
          alternate_emails
        where
          alternate_email_domain not in (
            select
              distinct blacklist_domain
            from
              blacklist_domains
          )
      )
  ),
  capability_final as (
    select
      p.*,
      e.email,
      case
        when p.bucket = 'Email is blacklist - select secondary' then e.email
        else p.updated_email
      end as final_email
    from
      capability_pre p
      left join emails e on p.learner_alternate_email_hash = e.email_hash
      and p.bucket = 'Email is blacklist - select secondary'
  ),
  -- fix learner_email_hash records that have one row with partner account and another without (because of learndot data)
  account_fix as (
    select
      distinct learner_email_hash,
      partner_account_name,
      partner_account_id_sfdc,
      dense_rank() over (
        partition by learner_email_hash
        order by
          partner_account_name nulls last
      ) as rank
    from
      main.field_learning_enablement.partner_capability
    where
      category = 'Technical Trained'
      and processDate = (
        select
          max(processdate)
        from
          main.field_learning_enablement.partner_capability
      )
  ),
  trainings as (
    select
      nvl(p.final_email, 'Unknown') as training_email,
      sha2(nvl(p.final_email, 'Unknown'), 256) as training_email_hash,
      p.updated_email,
      p.learner_email_hash,
      a.partner_account_name,
      a.partner_account_id_sfdc,
      p.updated_email,
      u.region_derived,
      u.country_derived,
      collect_set(p.course) as courses_completed,
      max(p.date) :: date as date_last_course_completed,
      max(p.fiscal_quarter_year) as qtr_last_course_completed
    from
      capability_final p
      left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
      left join account_fix a on p.learner_email_hash = a.learner_email_hash
      and a.rank = 1
    where
      p.category = 'Technical Trained'
    group by
      all
  ),
  certs as (
    select
      p.final_email as certification_email,
      sha2(p.final_email, 256) as certification_email_hash,
      array_join(collect_set(p.updated_email), ",") as updated_email,
      array_join(collect_set(p.learner_email_hash), ",") as learner_email_hash,
      p.partner_account_name,
      p.partner_account_id_sfdc,
      u.region_derived,
      u.country_derived,
      -- combining two different email to the same email means there could be two regions for the same email
      collect_set(p.credential_id) as credential_ids,
      collect_set(p.course) as certs_completed,
      max(p.date) :: date as date_last_cert_completed,
      max(p.fiscal_quarter_year) as qtr_last_cert_completed
    from
      capability_final p
      left join docebo_users u on sha2(p.final_email, 256) = u.email_hash
    where
      p.category = 'Technical Certified'
    group by
      all
  ),
  trainings_certs as (
    select
      t.training_email,
      t.training_email_hash,
      t.updated_email,
      t.learner_email_hash,
      t.partner_account_name,
      t.partner_account_id_sfdc,
      t.region_derived,
      t.country_derived,
      t.courses_completed,
      t.date_last_course_completed,
      t.qtr_last_course_completed,
      c.certification_email,
      c.certification_email_hash,
      c.certs_completed,
      c.date_last_cert_completed,
      c.qtr_last_cert_completed
    from
      trainings t
      left join certs c on t.training_email = c.certification_email
  ),
  certified_not_trained as (
    select
      null as training_email,
      null as training_email_hash,
      c.updated_email,
      c.learner_email_hash,
      c.partner_account_name,
      c.partner_account_id_sfdc,
      c.region_derived,
      c.country_derived,
      null as courses_completed,
      null as date_last_course_completed,
      null as qtr_last_course_completed,
      c.certification_email,
      c.certification_email_hash,
      c.certs_completed,
      c.date_last_cert_completed,
      c.qtr_last_cert_completed
    from
      certs c
    where
      certification_email_hash not in (
        select
          distinct certification_email_hash
        from
          trainings_certs
        where
          certification_email is not null
      )
  ),
  final as (
    select
      *
    from
      trainings_certs
    union all
    select
      *
    from
      certified_not_trained
  ),
  pre as (
    select
      case
        when size(certs_completed) > 0 then 1
        else 0
      end as certified_flag,
      case
        when size(courses_completed) > 0 then 1
        else 0
      end as trained_flag,
      *
    from
      final
  )
  select
    certified_flag,
    trained_flag,
    training_email,
    training_email_hash,
    updated_email as contact_email,
    learner_email_hash,
    partner_account_name,
    partner_account_id_sfdc,
    region_derived as region,
    country_derived as country,
    courses_completed,
    date_last_course_completed,
    qtr_last_course_completed,
    certification_email,
    certification_email_hash,
    certs_completed,
    date_last_cert_completed,
    qtr_last_cert_completed
  from
    pre


''')

# COMMAND ----------

df.createOrReplaceTempView('trained_not_certified')

# COMMAND ----------

trained_not_certified = spark.sql('''
  with pre as (
    select distinct partner_account_id_sfdc, partner_manager, portfolio, managed_partner
    from main.field_learning_enablement.partner_capability
    where processDate = (select max(processDate) from main.field_learning_enablement.partner_capability)
  )
  select 
    t.*, 
    a.Partner_Level__c as partner_level,
    a.Partner_Tier__c as partner_tier, 
    p.partner_manager, 
    p.portfolio, 
    p.managed_partner
  from trained_not_certified t 
  left join main.sfdc_bronze.account a on t.partner_account_id_sfdc = a.id and a.processDate = (select max(processDate) from main.sfdc_bronze.account)
  left join pre p on t.partner_account_id_sfdc = p.partner_account_id_sfdc

''')

# COMMAND ----------

# DBTITLE 1,Partner Certification Expiry Tracker
expiring_certs_df = spark.sql('''
with data as (
  select
    t.learner_email_hash as email_hash,
    t.partner_account_name,
    t.partner_account_id_sfdc,
    t.region_derived as cert_Region,
    t.country_derived as cert_country,
    -- case
    --   when t.partner_account_name in (
    --     'Accenture (HQ)',
    --     'Deloitte Consulting (HQ)',
    --     'Capgemini S.A. (HQ)',
    --     'Avanade Inc (HQ)',
    --     'Infosys Technologies (HQ)',
    --     'Cognizant Technology Solutions (HQ)',
    --     'E&Y (HQ)',
    --     'Slalom Consulting (HQ)',
    --     'Wipro (HQ)',
    --     'Tata Consultancy Services (HQ)'
    --   ) then 'GSI'
    --   else 'Others'
    -- end as classification,
    t.* except (t.country_derived),
    ac.* except (ac.issued_on, ac.calculated_expired_on)
  from
    main.field_learning_enablement.partner_capability t
    inner join main.field_learning_enablement.accredible_credentials ac on t.learner_email_hash = ac.learner_email_hash
    and t.course = ac.credential_name
    and ac.processDate = (Select max(processdate) from main.field_learning_enablement.accredible_credentials)
  where
    t.processdate =  (Select max(processdate) from main.field_learning_enablement.partner_capability)
    and t.category = 'Technical Certified'
),
pre as (
  select
    t.email_hash,
    t.partner_account_name,
    t.partner_account_id_sfdc,
    t.cert_Region,
    t.cert_country,
    t.classification,
    t.date :: date,
    t.issued_on :: date,
    t.calculated_expired_on :: date
  from
    data t
),
final as (
  select
    t.email_hash,
    t.partner_account_name,
    t.partner_account_id_sfdc,
    t.cert_region,
    t.cert_country,
    t.classification,
    min(issued_on::date) as date_first_cert_issued,
    max(issued_on :: date) as date_last_cert_issued,
    max(calculated_expired_on :: date) as date_last_cert_expiring
  from
    pre t
  group by
    1,
    2,
    3,
    4,
    5,
    6
)
select
  classification,
  case when cert_region in ('AMER','LATAM') then 'AMER' else cert_region end as cert_region,
  partner_account_name,
  partner_account_id_sfdc,
  cert_country,
  -- persona,
  -- count(distinct email_hash),
  -- ,
  -- count(
  --   distinct case
  --     when (
  --       date_last_cert_expiring :: date > '2023-07-31'
  --       and date_last_cert_expiring :: date <= '2023-10-31'
  --     ) then email_hash
  --   end
  -- ) as q3_expiries,
  count(
    distinct case
      when (
        date_last_cert_expiring :: date > '2024-01-31'
        and date_last_cert_expiring :: date <= '2025-01-31'
      ) then email_hash
    end
  ) as fy25_expiries,
 count(
    distinct case
      when (
        date_last_cert_expiring :: date > '2024-01-31'
        and date_last_cert_expiring :: date <= '2024-04-30'
      ) then email_hash
    end
  ) as q1_fy25_expiries,
   count(
    distinct case
      when (
        date_last_cert_expiring :: date > '2024-04-30'
        and date_last_cert_expiring :: date <= '2024-07-31'
      ) then email_hash
    end
  ) as q2_fy25_expiries,
  count(
    distinct case
      when (
        date_last_cert_expiring :: date > '2024-07-31'
        and date_last_cert_expiring :: date <= '2024-10-31'
      ) then email_hash
    end
  ) as q3_fy25_expiries,
  count(
    distinct case
      when (
        date_last_cert_expiring :: date > '2024-10-31'
        and date_last_cert_expiring :: date <= '2025-01-31'
      ) then email_hash
    end
  ) as q4_fy25_expiries--,
 -- count(
 --    distinct case
 --      when (
 --         date_last_cert_expiring :: date <= '2025-01-31'
 --      ) then email_hash
 --    end
 --  ) as total_expiries
from
  final f 
-- left join  partner_personas p on f.email_hash=p.learner_email_hash
where 1=1
group by all
  -- date_first_cert_issued < '2023-02-01'
-- and classification='GSI'
-- group by
--   1--  where t.date::date<>t.issued_on::date
  -- group by 1,2,3                              
                              
''')

# COMMAND ----------

df_gold = add_gold_metadata(trained_not_certified)
expiring_certs_df_gold = add_gold_metadata(expiring_certs_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = df_gold, 
  table_name = f'{focus_database_name}.partner_trained_and_certified_splits', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = expiring_certs_df_gold, 
  table_name = f'{focus_database_name}.partner_expiring_certifications', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

