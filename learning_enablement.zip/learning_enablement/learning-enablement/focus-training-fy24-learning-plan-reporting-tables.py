# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# %run "/Users/liam.clifford@databricks.com/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

# try:
#   sht = authGoogleSheet("Learning Plan Reporting")
# except:
#   print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')
  
# try:
#   worksheet = sht.worksheet("Learning Plans")
# except Exception as e: 
#   print('%s' % 'Worksheet Not Found: ')


# readGoogleSheet(
#  "Learning Plan Reporting",
#  "Learning Plans",
#  "learning_plans_reporting",
#  clean_column_names="true", 
#  make_columns_unique="true"
# )

# learning_plans_reporting = (spark.sql("""select * from learning_plans_reporting"""))

# learning_plans_reporting.createOrReplaceTempView('learning_plans_reporting')

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# DBTITLE 1,Lakehouse Invite Processing
# lakehouse invite list 

lakehouse_invite_list_process_date = (
  spark.table(f'{focus_database_name}.fe_lakehouse_ai_invite_list')
  .select(F.col("processDate"))
  .distinct()
  .orderBy(F.col("processDate").desc())
  .limit(1).collect()[0].processDate
)

lakehouse_invite_list_df = (
  spark.table(f'{focus_database_name}.fe_lakehouse_ai_invite_list')
    .filter(F.col("processDate") == lakehouse_invite_list_process_date)
    .select(F.col("primaryWorkEmail"))
)

lakehouse_invite_list_df.createOrReplaceTempView('lakehouse_invite_list')

# COMMAND ----------

# DBTITLE 1,AI Invitation List Generator
# gen ai invite list 

gen_ai_invite_list_process_date = (
  spark.table(f'{focus_database_name}.fe_gen_ai_invite_list')
  .select(F.col("processDate"))
  .distinct()
  .orderBy(F.col("processDate").desc())
  .limit(1).collect()[0].processDate
)

gen_ai_invite_list_df = (
  spark.table(f'{focus_database_name}.fe_gen_ai_invite_list')
    .filter(F.col("processDate") == gen_ai_invite_list_process_date)
    .select(F.col("primaryWorkEmail"))
)

gen_ai_invite_list_df.createOrReplaceTempView('gen_ai_invite_list')

# COMMAND ----------

# DBTITLE 1,Invite List Upgrade Processor
# uc_upgrade invite list 

uc_upgrade_invite_list_process_date = (
  spark.table(f'{focus_database_name}.get_certified')
  .select(F.col("processDate"))
  .distinct()
  .orderBy(F.col("processDate").desc())
  .limit(1).collect()[0].processDate
)

uc_upgrade_invite_list_df = (
  spark.table(f'{focus_database_name}.get_certified')
    .filter(F.col("processDate") == uc_upgrade_invite_list_process_date)
    .select(F.col("primaryWorkEmail"))
)

uc_upgrade_invite_list_df.createOrReplaceTempView('uc_upgrade_invite_list')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### Employee Onboarding Learning Plan

# COMMAND ----------

# DBTITLE 1,Employee Onboarding Process Data
employee_onboarding_df = spark.sql('''
with workday as (
  select 
    Name,
    WorkdayID,
    Worker_Type,
    trim(lower(primaryWorkEmail)) as primaryWorkEmail,
    Hire_Date,
    -- Last_Promotion_Date,
    -- Termination_Date,
    -- Job_Profile_Prior_To_Last_Promotion_Date,
    -- Business_Title_Prior_To_Last_Promotion_Date,
    Cost_Center,
    Location,
    Location_Address_Country,
    Job_Profile,
    businessTitle,
    Manager_Level_01,
    Manager_Level_02,
    Manager_Level_03,
    Manager,
    Manager_Email,
    Supervisory_Organization,
    Supervisory_Organization_cleaned,
    -- Time_Zone,
    -- Time_Zone_GMT_Factor,
    Original_Hire_Date,
    -- Job_Profile_Start_Date,
    -- Last_Job_Req_Event_Date,
    -- wd_id,
    manager_hierarchy_path,
    manager_hierarchy_path_name,
    -- category,
    -- department,
    6th_level_manager,
    5th_level_manager,
    4th_level_manager,
    3rd_level_manager,
    2nd_level_manager,
    1st_level_manager,
    init_level_manager,
    6th_level_manager_name,
    5th_level_manager_name,
    4th_level_manager_name,
    3rd_level_manager_name,
    2nd_level_manager_name,
    1st_level_manager_name,
    init_level_manager_name,
    status as workday_status
  from main.field_learning_enablement.workday
  where processDate = (select max(processDate) from main.field_learning_enablement.workday)
)
,

lp_enrollments as (
  select * 
  from main.it_training_silver.docebo_learning_plan_enrollments e
  inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
  where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
  and learner_branch_code = 'DBK_EMP'
)

,
learning_plans as (
  select
    id as learning_plan_id,
    name as learning_plan_name,
    code as learning_plan_code,
    total_courses
  from main.it_training_silver.docebo_learning_plans 
  where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
  and code = "FENG-FY24-ONBOARDING"
),
learning_plan_courses as (
  select 
    path_id,
    course_id,
    course_name,
    course_code
  from main.it_training_silver.docebo_learning_plan_courses e
  where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
),
self_paced_enrollments as (
  select distinct
    course_id,
    course_name,
    learner_user_id,
    status as enrollment_status, 
    completed_timestamp
  from main.field_learning_enablement.self_paced_enrollments e
  where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
  and learner_branch_code = 'DBK_EMP'
)

,
ilt_enrollments as (
  select distinct
    course_id,
    course_name,
    learner_user_id,
    status as enrollment_status, 
    completed_timestamp
  from main.field_learning_enablement.ilt_enrollments e
  where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
  and learner_branch_code = 'DBK_EMP'
)
,
all_enrollments as ( 
  select
    course_id,
    course_name,
    learner_user_id,
    enrollment_status, 
    completed_timestamp
  from self_paced_enrollments
  union all 
  select
    course_id,
    course_name,
    learner_user_id,
    enrollment_status, 
    completed_timestamp
  from ilt_enrollments
)
,
all_lp as (
    select 
      e.learner_user_id,
      learner_email,
      learning_path_id, 
      learning_path_name,
      learning_path_code,
      c.course_id,
      c.course_name,
      c.course_code,
      nvl(enrollment_status, "Not Enrolled") as enrollment_status,
      completed_timestamp
    from lp_enrollments e
    join learning_plans l on e.learning_path_id = l.learning_plan_id
    join learning_plan_courses c on e.learning_path_id = c.path_id 
    left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
  )
,

email_path_completed_courses as (
  select 
    learner_email,
    learning_path_id,
    count(distinct course_id) as total_courses,
    sum(case when enrollment_status="completed" then 1 else 0 end) as completed_courses,
    -- collect_list(struct(course_name, enrollment_status)) as course_enrollment_status,
    collect_set(course_name) as lp_courses, 
    collect_set(course_code) as lp_course_codes
  from all_lp
  group by learner_email, learning_path_id
  -- order by course_enrollment_status.course_name
)
,

courses_completed as (
  select *
  from (
    select learner_email, course_name, enrollment_status from all_lp
  )
  pivot (
    max(nvl(enrollment_status, 'Not Enrolled'))
    for course_name in ("Data Engineering with Databricks V3 ","FE Onboarding: Readiness","Welcome to Field Engineering Onboarding!","Flight School Registration","FE Onboarding: Technical Foundations")
  )
)


,
completed_lps as (
  select distinct 
    learner_email, 
    learning_path_id
  from email_path_completed_courses
  where total_courses = completed_courses
)

,
completed_timestamps as (
  select 
    u.learner_email, 
    u.learning_path_id, 
    max(completed_timestamp) as completed_timestamp
  from all_lp u 
  join completed_lps c on c.learner_email = u.learner_email and c.learning_path_id = u.learning_path_id
  group by u.learner_email, u.learning_path_id
)



,
lp_info as (
  select 
    e.*, 
    c1.`Data Engineering with Databricks V3 ` as `Data Engineering with Databricks V3`,
    c1.`FE Onboarding: Technical Foundations`,
    c1.`FE Onboarding: Readiness` as `Field Engineering Onboarding: Readiness`,
    c1.`Flight School Registration`,
    c1.`Welcome to Field Engineering Onboarding!`,
    completed_timestamp
  from email_path_completed_courses e
  left join completed_timestamps c on c.learner_email = e.learner_email and c.learning_path_id = e.learning_path_id
  left join courses_completed c1 on e.learner_email = c1.learner_email
  -- order by course_enrollment_status.course_name
)

,

emp_de_associate_certs as ( 
  select 
    learner_email_hash,
    credential_name,
    issued_on
  from main.field_learning_enablement.accredible_credentials
  where processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
  and group_id = '353856'
  and learner_branch_code = 'DBK_EMP'
  and is_expired = 'false'
)

,
lp_enrollments_workday as (
  select 
    Name,
    e.learner_email,
    learning_path_name,
    learning_path_code,
    e.learning_path_id,
    assigned_timestamp,
    completed_timestamp,
    completed_courses,
    total_courses,
    lp_courses,
    lp_course_codes,
    `Data Engineering with Databricks V3` as data_engineering_with_databricks_v3,
    `FE Onboarding: Technical Foundations` as fe_onboarding_technical_foundations,
    `Field Engineering Onboarding: Readiness` as field_engineering_onboarding_readiness,
    `Flight School Registration` as flight_school,
    `Welcome to Field Engineering Onboarding!` as welcome_to_field_engineering_onboarding,
    round(completed_courses/total_courses * 100, 1) as percent_completed,
    case 
      when completed_courses = 0 then 'Not Started' 
      when completed_courses < total_courses then 'In Progress'
      when completed_courses = total_courses then 'Completed'
    end as lp_enrollment_status,
    case 
      when Original_Hire_Date >= DATEADD(month, -1, getdate()) then '<1 month' 
      when Original_Hire_Date < DATEADD(month, -1, getdate()) and Original_Hire_Date >= DATEADD(month, -3, getdate()) then '1-3 months'
      when Original_Hire_Date < DATEADD(month, -3, getdate()) and Original_Hire_Date >= DATEADD(month, -6, getdate()) then '3-6 months'
      when Original_Hire_Date < DATEADD(month, -6, getdate()) and Original_Hire_Date >= DATEADD(month, -12, getdate()) then '6-12 months'
      when Original_Hire_Date < DATEADD(month, -12, getdate()) and Original_Hire_Date >= DATEADD(month, -36, getdate()) then '1-3 years'
      when Original_Hire_Date < DATEADD(month, -36, getdate()) then '>3 years'
    end as tenure,
    date,
    day,
    cast(calendar_year as INT) as year,
    cast(calendar_month as INT) as month,
    month_name as monthName,
    cast(calendar_quarter as INT) as quarter,
    cast(calendar_week as INT) as week,
    cast(day_of_week as INT) as dayofweek,
    cast(fiscal_year as INT) as fiscalYear,
    cast(fiscal_quarter as INT) as fiscalQuarter,
    fiscal_year_quarter as FQ2,
    Worker_Type,
    workday_status,
    Hire_Date,
    -- Last_Promotion_Date,
    -- Cost_Center,
    Location,
    Location_Address_Country,
    Job_Profile,
    businessTitle,
    Manager_Level_01,
    Manager_Level_02,
    Manager_Level_03,
    Manager,
    Manager_Email,
    Supervisory_Organization,
    Supervisory_Organization_cleaned,
    --sfdc_businessUnit,
    -- Time_Zone,
    -- Time_Zone_GMT_Factor,
    Original_Hire_Date,
    -- Job_Profile_Start_Date,
    -- Last_Job_Req_Event_Date,
    -- wd_id,
    manager_hierarchy_path,
    manager_hierarchy_path_name,
    -- category,
    -- department,
    6th_level_manager,
    5th_level_manager,
    4th_level_manager,
    3rd_level_manager,
    2nd_level_manager,
    1st_level_manager,
    init_level_manager,
    6th_level_manager_name,
    5th_level_manager_name,
    4th_level_manager_name,
    3rd_level_manager_name,
    2nd_level_manager_name,
    1st_level_manager_name,
    init_level_manager_name,
    credential_name,
    issued_on
    
  from lp_enrollments e
  join lp_info i on i.learner_email = e.learner_email and i.learning_path_id = e.learning_path_id
  left outer join workday w on e.learner_email = w.primaryWorkEmail
  left join emp_de_associate_certs c on e.learner_email_hash = c.learner_email_hash
  -- left join wd d on w.primaryWorkEmail = d.primaryWorkEmail
)


-- select * from courses_completed
select 
  *,
  case when credential_name is not null then 1 else 0 end as has_badge
from lp_enrollments_workday
                  
                  ''')

# COMMAND ----------

employee_onboarding_gold = add_gold_metadata(employee_onboarding_df)

# COMMAND ----------

# MAGIC %md ### Employee Onboarding Learning Plan Details

# COMMAND ----------

# DBTITLE 1,Employee Onboarding Analysis Query
employee_onboarding_details_df = spark.sql('''
with workday as (
  select 
    Name,
    WorkdayID,
    Worker_Type,
    trim(lower(primaryWorkEmail)) as primaryWorkEmail,
    Hire_Date,
    -- Last_Promotion_Date,
    -- Termination_Date,
    -- Job_Profile_Prior_To_Last_Promotion_Date,
    -- Business_Title_Prior_To_Last_Promotion_Date,
    Cost_Center,
    Location,
    Location_Address_Country,
    Job_Profile,
    businessTitle,
    Manager_Level_01,
    Manager_Level_02,
    Manager_Level_03,
    Manager,
    Manager_Email,
    Supervisory_Organization,
    Supervisory_Organization_cleaned,
    -- Time_Zone,
    -- Time_Zone_GMT_Factor,
    Original_Hire_Date,
    Job_Profile_Start_Date,
    -- Last_Job_Req_Event_Date,
    -- wd_id,
    manager_hierarchy_path,
    manager_hierarchy_path_name,
    -- category,
    -- department,
    6th_level_manager,
    5th_level_manager,
    4th_level_manager,
    3rd_level_manager,
    2nd_level_manager,
    1st_level_manager,
    init_level_manager,
    6th_level_manager_name,
    5th_level_manager_name,
    4th_level_manager_name,
    3rd_level_manager_name,
    2nd_level_manager_name,
    1st_level_manager_name,
    init_level_manager_name,
    status as workday_status
  from main.field_learning_enablement.workday
  where processDate = (select max(processDate) from main.field_learning_enablement.workday)
)
,
--wd as ( 
--  select 
--    wd_email as primaryWorkEmail, 
--    sfdc_businessUnit 
--  from liam.list_of_workday_users_and_respective_sfdc_user_ids
--)
--,
lp_enrollments as (
  select * 
  from main.it_training_silver.docebo_learning_plan_enrollments e
  inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
  where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
  and learner_branch_code = 'DBK_EMP'
)

,
learning_plans as (
  select
    id as learning_plan_id,
    name as learning_plan_name,
    code as learning_plan_code,
    total_courses
  from main.it_training_silver.docebo_learning_plans 
  where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
  and code = "FENG-FY24-ONBOARDING"
),
learning_plan_courses as (
  select 
    path_id,
    course_id,
    course_name,
    course_code
  from main.it_training_silver.docebo_learning_plan_courses e
  where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
),
self_paced_enrollments as (
  select distinct
    course_id,
    course_name,
    learner_user_id,
    status as enrollment_status, 
    completed_timestamp
  from main.field_learning_enablement.self_paced_enrollments e
  where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
  and learner_branch_code = 'DBK_EMP'
)

,
ilt_enrollments as (
  select distinct
    course_id,
    course_name,
    learner_user_id,
    status as enrollment_status, 
    completed_timestamp
  from main.field_learning_enablement.ilt_enrollments e
  where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
  and learner_branch_code = 'DBK_EMP'
)
,
all_enrollments as ( 
  select
    course_id,
    course_name,
    learner_user_id,
    enrollment_status, 
    completed_timestamp
  from self_paced_enrollments
  union all 
  select
    course_id,
    course_name,
    learner_user_id,
    enrollment_status, 
    completed_timestamp
  from ilt_enrollments
)
,
all_lp as (
    select 
      e.learner_user_id,
      learner_email,
      learning_path_id, 
      learning_path_name,
      learning_path_code,
      c.course_id,
      c.course_name,
      c.course_code,
      nvl(enrollment_status, "Not Enrolled") as enrollment_status,
      completed_timestamp,
      w.*
    from lp_enrollments e
    join learning_plans l on e.learning_path_id = l.learning_plan_id
    join learning_plan_courses c on e.learning_path_id = c.path_id 
    left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
    left join workday w on w.primaryWorkEmail = e.learner_email
  )

select 
  *,
  case when enrollment_status = "Not Enrolled" then 0 else 1 end as enrolled_flag
from all_lp
order by learner_email
                  
                  ''')

# COMMAND ----------

employee_onboarding_details_gold = add_gold_metadata(employee_onboarding_details_df)

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC ### Lakehouse AI Learning Plan

# COMMAND ----------

# DBTITLE 1,Workforce Learning Plan Query
lakehouse_ai_summary = spark.sql('''

  with workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    inner join lakehouse_invite_list i on trim(lower(w.primaryWorkEmail)) = i.primaryWorkEmail
    where w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,
  --wd as ( 
  --  select 
  --    wd_email as primaryWorkEmail, 
  --    sfdc_businessUnit 
  --  from liam.list_of_workday_users_and_respective_sfdc_user_ids
  --)
  --,
  lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    and code = 'FENG-ALL-SLP--v1-FREE-LHAMP-ACT' 
  ),
  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
  ),
  self_paced_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  ilt_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )
  ,
  all_enrollments as ( 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from ilt_enrollments
  )
  ,
  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        completed_timestamp
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
      order by c.course_name
    )

  ,

  email_path_completed_courses as (
    select 
      learner_email,
      learning_path_id,
      count(distinct course_id) as total_courses,
      sum(case when enrollment_status="completed" then 1 else 0 end) as completed_courses,
      -- collect_list(struct(course_name, enrollment_status)) as course_enrollment_status,
      collect_list(course_name) as lp_courses, 
      collect_list(course_code) as lp_course_codes
    from all_lp
    group by learner_email, learning_path_id
    -- order by course_enrollment_status.course_name
  )
  ,

  courses_completed as (
    select *
    from (
      select learner_email, course_name, enrollment_status from all_lp
    )
    pivot (
      max(nvl(enrollment_status, 'Not Enrolled'))
      for course_name in ('Large Language Models (LLMs): Application through Production', 'Generative AI Fundamentals')
    )
  )

  ,
  completed_lps as (
    select distinct 
      learner_email, 
      learning_path_id
    from email_path_completed_courses
    where total_courses = completed_courses
  )

  ,
  completed_timestamps as (
    select 
      u.learner_email, 
      u.learning_path_id, 
      max(completed_timestamp) as completed_timestamp
    from all_lp u 
    join completed_lps c on c.learner_email = u.learner_email and c.learning_path_id = u.learning_path_id
    group by u.learner_email, u.learning_path_id
  )



  ,
  lp_info as (
    select 
      e.*, 
      -- e.course_enrollment_status[0].enrollment_status as Generative_AI_Fundamentals,
      -- e.course_enrollment_status[1].enrollment_status as LLM_Application_through_Production,
      c1.`Generative AI Fundamentals` as Generative_AI_Fundamentals,
      c1.`Large Language Models (LLMs): Application through Production` as LLM_Application_through_Production,
      completed_timestamp
    from email_path_completed_courses e
    left join completed_timestamps c on c.learner_email = e.learner_email and c.learning_path_id = e.learning_path_id
    left join courses_completed c1 on e.learner_email = c1.learner_email
    -- order by course_enrollment_status.course_name
  )

  ,

  lp_enrollments_workday as (
    select 
      Name,
      e.learner_email,
      learning_path_name,
      learning_path_code,
      e.learning_path_id,
      assigned_timestamp,
      completed_timestamp,
      completed_courses,
      total_courses,
      lp_courses,
      -- course_enrollment_status,
      Generative_AI_Fundamentals,
      LLM_Application_through_Production,
      round(completed_courses/total_courses * 100, 1) as percent_completed,
      case 
        when completed_courses = 0 then 'Not Started' 
        when completed_courses < total_courses then 'In Progress'
        when completed_courses = total_courses then 'Completed'
      end as lp_enrollment_status,
      case 
        when Original_Hire_Date >= DATEADD(month, -1, getdate()) then '<1 month' 
        when Original_Hire_Date < DATEADD(month, -1, getdate()) and Original_Hire_Date >= DATEADD(month, -3, getdate()) then '1-3 months'
        when Original_Hire_Date < DATEADD(month, -3, getdate()) and Original_Hire_Date >= DATEADD(month, -6, getdate()) then '3-6 months'
        when Original_Hire_Date < DATEADD(month, -6, getdate()) and Original_Hire_Date >= DATEADD(month, -12, getdate()) then '6-12 months'
        when Original_Hire_Date < DATEADD(month, -12, getdate()) and Original_Hire_Date >= DATEADD(month, -36, getdate()) then '1-3 years'
        when Original_Hire_Date < DATEADD(month, -36, getdate()) then '>3 years'
      end as tenure,
      date,
      day,
      cast(calendar_year as INT) as year,
      cast(calendar_month as INT) as month,
      month_name as monthName,
      cast(calendar_quarter as INT) as quarter,
      cast(calendar_week as INT) as week,
      cast(day_of_week as INT) as dayofweek,
      cast(fiscal_year as INT) as fiscalYear,
      cast(fiscal_quarter as INT) as fiscalQuarter,
      fiscal_year_quarter as FQ2,
      Worker_Type,
      workday_status,
      Hire_Date,
      -- Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      --sfdc_businessUnit,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name
      
    from lp_enrollments e
    join lp_info i on i.learner_email = e.learner_email and i.learning_path_id = e.learning_path_id
    join workday w on e.learner_email = w.primaryWorkEmail
    --left join wd d on w.primaryWorkEmail = d.primaryWorkEmail
    -- order by course_enrollment_status.course_name
  )

  select 
    *
  from lp_enrollments_workday
''')

# COMMAND ----------

lakehouse_ai_gold = add_gold_metadata(lakehouse_ai_summary)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Lakehouse AI Details

# COMMAND ----------

# DBTITLE 1,Workday Learning Analytics Query
lakehouse_ai_details = spark.sql('''
  with workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    inner join lakehouse_invite_list i on trim(lower(w.primaryWorkEmail)) = i.primaryWorkEmail
    where processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,
  --wd as ( 
  --  select 
  --    wd_email as primaryWorkEmail, 
  --    sfdc_businessUnit 
  --  from liam.list_of_workday_users_and_respective_sfdc_user_ids
  --)
  --,
  lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    and code = 'FENG-ALL-SLP--v1-FREE-LHAMP-ACT' 
  ),
  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
  ),
  self_paced_enrollments as (
    select distinct
      course_id,
      course_code,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  ilt_enrollments as (
    select distinct
      course_id,
      course_code,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )
  ,
  all_enrollments as ( 
    select
      course_id,
      course_code,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_code,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from ilt_enrollments
  )
  ,
  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        completed_timestamp,
        w.*
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_code = a.course_code and e.learner_user_id = a.learner_user_id
      join workday w on w.primaryWorkEmail = e.learner_email
    )


  select 
    *,
    case when enrollment_status = "Not Enrolled" then 0 else 1 end as enrolled_flag
  from all_lp
  order by learner_email   
''')

# COMMAND ----------

lakehouse_ai_details_gold = add_gold_metadata(lakehouse_ai_details)

# COMMAND ----------

# MAGIC %md ### Mosaic AI Summary

# COMMAND ----------

# DBTITLE 1,Learning Plan Enrollments Analysis
gen_ai_summary = spark.sql('''

  with 
  lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  ),

 workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    inner join (select distinct learner_email from lp_enrollments) i on trim(lower(w.primaryWorkEmail)) = trim(lower(i.learner_email))
    where w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
  ),

  --wd as ( 
  --  select 
  --    wd_email as primaryWorkEmail,  
  --    sfdc_businessUnit 
  --  from liam.list_of_workday_users_and_respective_sfdc_user_ids
  --),

  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    and code = 'ACAD-FENG-LPLAN-v1-FREE-MAITF-ACT' 
  ),

  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
  ),

  self_paced_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  ),

  ilt_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  ),

  all_enrollments as ( 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from ilt_enrollments
  ),

  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        completed_timestamp
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
      order by c.course_name
    ),

  email_path_completed_courses as (
    select 
      learner_email,
      learning_path_id,
      count(distinct course_id) as total_courses,
      sum(case when enrollment_status="completed" then 1 else 0 end) as completed_courses,
      -- collect_list(struct(course_name, enrollment_status)) as course_enrollment_status,
      collect_list(course_name) as lp_courses, 
      collect_list(course_code) as lp_course_codes
    from all_lp
    group by learner_email, learning_path_id
    -- order by course_enrollment_status.course_name
  ),

  courses_completed as (
    select *
    from (
      select learner_email, course_name, enrollment_status from all_lp
    )
    pivot (
      max(nvl(enrollment_status, 'Not Enrolled'))
      for course_name in ('Generative AI Fundamentals', 'Generative AI Fundamentals Accreditation', 'Generative AI Engineering with Databricks', 'Selling & Winning: Generative AI')
    )
  ),

  completed_lps as (
    select distinct 
      learner_email, 
      learning_path_id
    from email_path_completed_courses
    where total_courses = completed_courses
  ),

  completed_timestamps as (
    select 
      u.learner_email, 
      u.learning_path_id, 
      max(completed_timestamp) as completed_timestamp
    from all_lp u 
    join completed_lps c on c.learner_email = u.learner_email and c.learning_path_id = u.learning_path_id
    group by u.learner_email, u.learning_path_id
  ),

  lp_info as (
    select 
      e.*, 
      -- e.course_enrollment_status[0].enrollment_status as Generative_AI_Fundamentals,
      -- e.course_enrollment_status[1].enrollment_status as LLM_Application_through_Production,
      c1.`Generative AI Fundamentals` as Generative_AI_Fundamentals,
      c1.`Generative AI Fundamentals Accreditation` as Generative_AI_Fundamentals_Accreditation,
      c1.`Generative AI Engineering with Databricks` as Generative_AI_Engineering_with_Databricks, 
      c1.`Selling & Winning: Generative AI` as Selling_and_Winning_Generative_AI,
      -- c1.`Fine-Tuning Large Language Models` as Fine_Tuning_Large_Language_Models,
      completed_timestamp
    from email_path_completed_courses e
    left join completed_timestamps c on c.learner_email = e.learner_email and c.learning_path_id = e.learning_path_id
    left join courses_completed c1 on e.learner_email = c1.learner_email
    -- order by course_enrollment_status.course_name
  ),

  gen_ai_accred as ( 
    select 
      learner_email_hash,
      credential_name,
      issued_on
    from main.field_learning_enablement.accredible_credentials
    where processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
    and group_id = '473432'
    and learner_branch_code = 'DBK_EMP'
    and is_expired = 'false'
  ),

  lp_enrollments_workday as (
    select 
      Name,
      e.learner_email,
      learning_path_name,
      learning_path_code,
      e.learning_path_id,
      assigned_timestamp,
      completed_timestamp,
      completed_courses,
      total_courses,
      lp_courses,
      -- course_enrollment_status,
      Generative_AI_Fundamentals,
      Generative_AI_Fundamentals_Accreditation,
      Generative_AI_Engineering_with_Databricks,
      -- Retrieval_Augmented_Generation_with_Vector_Search_and_Storage,
      Selling_and_Winning_Generative_AI,
      -- Fine_Tuning_Large_Language_Models,
      round(completed_courses/total_courses * 100, 1) as percent_completed,
      case 
        when completed_courses = 0 then 'Not Started' 
        when completed_courses < total_courses then 'In Progress'
        when completed_courses = total_courses then 'Completed'
      end as lp_enrollment_status,
      case 
        when Original_Hire_Date >= DATEADD(month, -1, getdate()) then '<1 month' 
        when Original_Hire_Date < DATEADD(month, -1, getdate()) and Original_Hire_Date >= DATEADD(month, -3, getdate()) then '1-3 months'
        when Original_Hire_Date < DATEADD(month, -3, getdate()) and Original_Hire_Date >= DATEADD(month, -6, getdate()) then '3-6 months'
        when Original_Hire_Date < DATEADD(month, -6, getdate()) and Original_Hire_Date >= DATEADD(month, -12, getdate()) then '6-12 months'
        when Original_Hire_Date < DATEADD(month, -12, getdate()) and Original_Hire_Date >= DATEADD(month, -36, getdate()) then '1-3 years'
        when Original_Hire_Date < DATEADD(month, -36, getdate()) then '>3 years'
      end as tenure,
      date,
      day,
      cast(calendar_year as INT) as year,
      cast(calendar_month as INT) as month,
      month_name as monthName,
      cast(calendar_quarter as INT) as quarter,
      cast(calendar_week as INT) as week,
      cast(day_of_week as INT) as dayofweek,
      cast(fiscal_year as INT) as fiscalYear,
      cast(fiscal_quarter as INT) as fiscalQuarter,
      fiscal_year_quarter as FQ2,
      Worker_Type,
      workday_status,
      Hire_Date,
      -- Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- sfdc_businessUnit,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      credential_name,
      issued_on,
      l.primaryworkemail
    from lp_enrollments e
    join lp_info i on i.learner_email = e.learner_email and i.learning_path_id = e.learning_path_id
    -- left join wd d on w.primaryWorkEmail = d.primaryWorkEmail
    left join gen_ai_accred g on e.learner_email_hash = g.learner_email_hash
    left join workday w on e.learner_email = w.primaryWorkEmail
    left join gen_ai_invite_list l on e.learner_email=l.primaryworkemail
    -- order by course_enrollment_status.course_name
  )

  select 
    *,
    case when credential_name is not null then 1 else 0 end as has_badge,
    case when primaryworkemail is not null then 1 else 0 end as in_invite_list
  from lp_enrollments_workday
  order by learner_email
''')

# COMMAND ----------

gen_ai_gold = add_gold_metadata(gen_ai_summary)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Mosaic AI Details

# COMMAND ----------

# DBTITLE 1,Employee Learning Plan Tracker
gen_ai_details = spark.sql('''

  with lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  ),

  workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    inner join (select distinct learner_email from lp_enrollments) i on trim(lower(w.primaryWorkEmail)) = trim(lower(i.learner_email))
    where w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,
  --wd as ( 
  --  select 
  --    wd_email as primaryWorkEmail, 
  --    sfdc_businessUnit 
  --  from liam.list_of_workday_users_and_respective_sfdc_user_ids
  --)
--
  --,
  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    and code = 'ACAD-FENG-LPLAN-v1-FREE-MAITF-ACT' 
  ),
  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
  ),
  self_paced_enrollments as (
    select distinct
      course_id,
      course_code,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  ilt_enrollments as (
    select distinct
      course_id,
      course_code,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )
  ,
  all_enrollments as ( 
    select
      course_id,
      course_code,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_code,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from ilt_enrollments
  )
  ,
  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        completed_timestamp,
        w.*,
        i.primaryworkemail as invite_list_work_email
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_code = a.course_code and e.learner_user_id = a.learner_user_id
      left join workday w on w.primaryWorkEmail = e.learner_email
      left join gen_ai_invite_list i on e.learner_email = i.primaryworkemail
    ),
  course_completion as (
    select 
    learner_user_id,
    count(course_id) as completed_course_count,
    enrollment_status
  from all_lp
  where course_id in ('1811', '1772')
  and enrollment_status = 'completed'
  group by learner_user_id, enrollment_status
  having count(distinct course_id) = 2
  )

  select 
    a.*,
    case when completed_course_count = 2 then 1 else 0 end as major_courses_completions,
    case when a.enrollment_status = "Not Enrolled" then 0 else 1 end as enrolled_flag,
    case when invite_list_work_email is not null then 1 else 0 end as in_invite_list

  from all_lp a
  left join course_completion c on a.learner_user_id = c.learner_user_id
  order by learner_email   
''')

# COMMAND ----------

gen_ai_details_gold = add_gold_metadata(gen_ai_details)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Selling and Winning Summary

# COMMAND ----------

# DBTITLE 1,Workday Learning Enrollment Report
selling_and_winning_summary = spark.sql('''
  with workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    where w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,
  --wd as ( 
  --  select 
  --    wd_email as primaryWorkEmail, 
  --    sfdc_businessUnit 
  --  from liam.list_of_workday_users_and_respective_sfdc_user_ids
  --)
  --,
  lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    and code = 'FENG-ALL-SLP-v1-FREE-SWFY24-ACT' 
  ),
  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
  ),
  self_paced_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  ilt_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )
  ,
  all_enrollments as ( 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from ilt_enrollments
  )
  ,
  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        completed_timestamp
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
      order by c.course_name
    )


  ,
  

  email_path_completed_courses as (
    select 
      learner_email,
      learning_path_id,
      count(distinct course_id) as total_courses,
      sum(case when enrollment_status="completed" then 1 else 0 end) as completed_courses,
      collect_list(course_name) as lp_courses, 
      collect_list(course_code) as lp_course_codes
    from all_lp
    group by learner_email, learning_path_id
  )

  ,

  courses_completed as (
    select *
    from (
      select learner_email, course_name, enrollment_status from all_lp
    )
    pivot (
      max(nvl(enrollment_status, 'Not Enrolled'))
      for course_name in (
        'Selling & Winning: Generative AI', 
        'Selling & Winning: Platform', 
        'Selling & Winning: Data Engineering', 
        'Selling & Winning: Data Governance', 
        'Selling & Winning: Data Warehousing',
        'Selling & Winning: An Overview',
        'Selling & Winning: Data Science and Machine Learning'
        )
    )
  )

  ,
  
  completed_lps as (
    select distinct 
      learner_email, 
      learning_path_id
    from email_path_completed_courses
    where total_courses = completed_courses
  )

  ,
  completed_timestamps as (
    select 
      u.learner_email, 
      u.learning_path_id, 
      max(completed_timestamp) as completed_timestamp
    from all_lp u 
    join completed_lps c on c.learner_email = u.learner_email and c.learning_path_id = u.learning_path_id
    group by u.learner_email, u.learning_path_id
  )



  ,
  lp_info as (
    select 
      e.*, 
      c1.`Selling & Winning: An Overview` as Selling_Winning_Overview,
      c1.`Selling & Winning: Generative AI` as Selling_Winning_Generative_AI,
      c1.`Selling & Winning: Platform` as Selling_Winning_Platform,
      c1.`Selling & Winning: Data Engineering` as Selling_Winning_Data_Engineering,
      c1.`Selling & Winning: Data Governance` as Selling_Winning_Data_Governance,
      c1.`Selling & Winning: Data Science and Machine Learning` as Selling_Winning_Data_Science_Machine_Learning,
      c1.`Selling & Winning: Data Warehousing` as Selling_Winning_Data_Warehousing,
      completed_timestamp
    from email_path_completed_courses e
    left join completed_timestamps c on c.learner_email = e.learner_email and c.learning_path_id = e.learning_path_id
    left join courses_completed c1 on e.learner_email = c1.learner_email
  )
  ,

  lp_enrollments_workday as (
    select 
      Name,
      e.learner_email,
      learning_path_name,
      learning_path_code,
      e.learning_path_id,
      assigned_timestamp,
      completed_timestamp,
      completed_courses,
      total_courses,
      lp_courses,
      Selling_Winning_Overview,
      Selling_Winning_Generative_AI,
      Selling_Winning_Platform,
      Selling_Winning_Data_Engineering,
      Selling_Winning_Data_Governance,
      Selling_Winning_Data_Science_Machine_Learning,
      Selling_Winning_Data_Warehousing,
      round(completed_courses/total_courses * 100, 1) as percent_completed,
      case 
        when completed_courses = 0 then 'Not Started' 
        when completed_courses < total_courses then 'In Progress'
        when completed_courses = total_courses then 'Completed'
      end as lp_enrollment_status,
      case 
        when Original_Hire_Date >= DATEADD(month, -1, getdate()) then '<1 month' 
        when Original_Hire_Date < DATEADD(month, -1, getdate()) and Original_Hire_Date >= DATEADD(month, -3, getdate()) then '1-3 months'
        when Original_Hire_Date < DATEADD(month, -3, getdate()) and Original_Hire_Date >= DATEADD(month, -6, getdate()) then '3-6 months'
        when Original_Hire_Date < DATEADD(month, -6, getdate()) and Original_Hire_Date >= DATEADD(month, -12, getdate()) then '6-12 months'
        when Original_Hire_Date < DATEADD(month, -12, getdate()) and Original_Hire_Date >= DATEADD(month, -36, getdate()) then '1-3 years'
        when Original_Hire_Date < DATEADD(month, -36, getdate()) then '>3 years'
      end as tenure,
      date,
      day,
      cast(calendar_year as INT) as year,
      cast(calendar_month as INT) as month,
      month_name as monthName,
      cast(calendar_quarter as INT) as quarter,
      cast(calendar_week as INT) as week,
      cast(day_of_week as INT) as dayofweek,
      cast(fiscal_year as INT) as fiscalYear,
      cast(fiscal_quarter as INT) as fiscalQuarter,
      fiscal_year_quarter as FQ2,
      Worker_Type,
      workday_status,
      Hire_Date,
      -- Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      --sfdc_businessUnit,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name
      
    from lp_enrollments e
    join lp_info i on i.learner_email = e.learner_email and i.learning_path_id = e.learning_path_id
    left join workday w on e.learner_email = w.primaryWorkEmail
    --left join wd d on w.primaryWorkEmail = d.primaryWorkEmail
  )

  select 
    *
  from lp_enrollments_workday
''')

# COMMAND ----------

selling_and_winning_summary_gold = add_gold_metadata(selling_and_winning_summary)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Selling and Winning Details

# COMMAND ----------

# DBTITLE 1,Employee Training Dashboard Query
# MAGIC %sql         
# MAGIC -- # selling_and_winning_summary = spark.sql('''
# MAGIC create or replace temp view selling_and_winning_v1 as 
# MAGIC   with workday as (
# MAGIC     select 
# MAGIC       Name,
# MAGIC       WorkdayID,
# MAGIC       Worker_Type,
# MAGIC       trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
# MAGIC       Hire_Date,
# MAGIC       -- Last_Promotion_Date,
# MAGIC       -- Termination_Date,
# MAGIC       -- Job_Profile_Prior_To_Last_Promotion_Date,
# MAGIC       -- Business_Title_Prior_To_Last_Promotion_Date,
# MAGIC       Cost_Center,
# MAGIC       Location,
# MAGIC       Location_Address_Country,
# MAGIC       Job_Profile,
# MAGIC       businessTitle,
# MAGIC       Manager_Level_01,
# MAGIC       Manager_Level_02,
# MAGIC       Manager_Level_03,
# MAGIC       Manager,
# MAGIC       Manager_Email,
# MAGIC       Supervisory_Organization,
# MAGIC       Supervisory_Organization_cleaned,
# MAGIC       -- Time_Zone,
# MAGIC       -- Time_Zone_GMT_Factor,
# MAGIC       Original_Hire_Date,
# MAGIC       Job_Profile_Start_Date,
# MAGIC       -- Last_Job_Req_Event_Date,
# MAGIC       -- wd_id,
# MAGIC       manager_hierarchy_path,
# MAGIC       manager_hierarchy_path_name,
# MAGIC       -- category,
# MAGIC       -- department,
# MAGIC       6th_level_manager,
# MAGIC       5th_level_manager,
# MAGIC       4th_level_manager,
# MAGIC       3rd_level_manager,
# MAGIC       2nd_level_manager,
# MAGIC       1st_level_manager,
# MAGIC       init_level_manager,
# MAGIC       6th_level_manager_name,
# MAGIC       5th_level_manager_name,
# MAGIC       4th_level_manager_name,
# MAGIC       3rd_level_manager_name,
# MAGIC       2nd_level_manager_name,
# MAGIC       1st_level_manager_name,
# MAGIC       init_level_manager_name,
# MAGIC       status as workday_status
# MAGIC     from main.field_learning_enablement.workday w
# MAGIC     where w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
# MAGIC   )
# MAGIC   ,
# MAGIC
# MAGIC   lp_enrollments as (
# MAGIC     select * 
# MAGIC     from main.it_training_silver.docebo_learning_plan_enrollments e
# MAGIC     -- inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
# MAGIC     where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
# MAGIC     and learner_branch_code = 'DBK_EMP'
# MAGIC     and learning_path_code = 'FENG-ALL-SLP-v1-FREE-SWFY24-ACT' 
# MAGIC   )
# MAGIC
# MAGIC   ,
# MAGIC   learning_plans as (
# MAGIC     select
# MAGIC       id as learning_plan_id,
# MAGIC       name as learning_plan_name,
# MAGIC       code as learning_plan_code,
# MAGIC       total_courses
# MAGIC     from main.it_training_silver.docebo_learning_plans 
# MAGIC     where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
# MAGIC     and code = 'FENG-ALL-SLP-v1-FREE-SWFY24-ACT' 
# MAGIC   ),
# MAGIC   learning_plan_courses_v1 as (
# MAGIC     select 
# MAGIC       path_id,
# MAGIC       course_id,
# MAGIC       course_name,
# MAGIC       course_code
# MAGIC     from main.it_training_silver.docebo_learning_plan_courses e
# MAGIC     -- where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
# MAGIC     where e.processdate = '2024-01-05'
# MAGIC   ),
# MAGIC   self_paced_enrollments as (
# MAGIC     select distinct
# MAGIC       course_id,
# MAGIC       course_name,
# MAGIC       learner_user_id,
# MAGIC       status as enrollment_status, 
# MAGIC       completed_timestamp
# MAGIC     from main.field_learning_enablement.self_paced_enrollments e
# MAGIC     -- where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
# MAGIC     where e.processdate = '2024-01-08'
# MAGIC     and learner_branch_code = 'DBK_EMP'
# MAGIC   )
# MAGIC
# MAGIC   ,
# MAGIC   ilt_enrollments as (
# MAGIC     select distinct
# MAGIC       course_id,
# MAGIC       course_name,
# MAGIC       course_code,
# MAGIC       learner_user_id,
# MAGIC       status as enrollment_status, 
# MAGIC       completed_timestamp
# MAGIC     from main.field_learning_enablement.ilt_enrollments e
# MAGIC     -- where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
# MAGIC     where e.processdate = '2024-01-08'
# MAGIC     and learner_branch_code = 'DBK_EMP'
# MAGIC   )
# MAGIC   ,
# MAGIC   all_enrollments as ( 
# MAGIC     select
# MAGIC       course_id,
# MAGIC       course_name,
# MAGIC       learner_user_id,
# MAGIC       enrollment_status, 
# MAGIC       completed_timestamp
# MAGIC     from self_paced_enrollments
# MAGIC     union all 
# MAGIC     select
# MAGIC       course_id,
# MAGIC       course_name,
# MAGIC       learner_user_id,
# MAGIC       enrollment_status, 
# MAGIC       completed_timestamp
# MAGIC     from ilt_enrollments
# MAGIC   )
# MAGIC   ,
# MAGIC   all_lp as (
# MAGIC       select 
# MAGIC         e.learner_user_id,
# MAGIC         learner_email,
# MAGIC         learning_path_id, 
# MAGIC         learning_path_name,
# MAGIC         learning_path_code,
# MAGIC         c.course_id,
# MAGIC         c.course_name,
# MAGIC         c.course_code,
# MAGIC         nvl(enrollment_status, "Not Enrolled") as enrollment_status,
# MAGIC         completed_timestamp,
# MAGIC         date,
# MAGIC         day,
# MAGIC         cast(calendar_year as INT) as year,
# MAGIC         cast(calendar_month as INT) as month,
# MAGIC         month_name as monthName,
# MAGIC         cast(calendar_quarter as INT) as quarter,
# MAGIC         cast(calendar_week as INT) as week,
# MAGIC         cast(day_of_week as INT) as dayofweek,
# MAGIC         cast(fiscal_year as INT) as fiscalYear,
# MAGIC         cast(fiscal_quarter as INT) as fiscalQuarter,
# MAGIC         fiscal_year_quarter as FQ2
# MAGIC       from lp_enrollments e
# MAGIC       join learning_plans l on e.learning_path_id = l.learning_plan_id
# MAGIC       -- join learning_plan_courses c on e.learning_path_id = c.path_id 
# MAGIC       join learning_plan_courses_v1 c on e.learning_path_id = c.path_id 
# MAGIC       left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
# MAGIC       inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
# MAGIC       order by c.course_name
# MAGIC     )
# MAGIC
# MAGIC
# MAGIC   ,
# MAGIC   
# MAGIC
# MAGIC   email_path_completed_courses as (
# MAGIC     select 
# MAGIC       learner_email,
# MAGIC       learning_path_id,
# MAGIC       count(distinct course_id) as total_courses,
# MAGIC       sum(case when enrollment_status="completed" then 1 else 0 end) as completed_courses,
# MAGIC       collect_list(course_name) as lp_courses, 
# MAGIC       collect_list(course_code) as lp_course_codes
# MAGIC     from all_lp
# MAGIC     group by learner_email, learning_path_id
# MAGIC   )
# MAGIC
# MAGIC   ,
# MAGIC
# MAGIC   completed_lps as (
# MAGIC     select distinct 
# MAGIC       learner_email, 
# MAGIC       learning_path_id
# MAGIC     from email_path_completed_courses
# MAGIC     where total_courses = completed_courses
# MAGIC   )
# MAGIC
# MAGIC   ,
# MAGIC   completed_timestamps as (
# MAGIC     select 
# MAGIC       u.learner_email, 
# MAGIC       u.learning_path_id, 
# MAGIC       max(completed_timestamp) as completed_timestamp
# MAGIC     from all_lp u 
# MAGIC     join completed_lps c on c.learner_email = u.learner_email and c.learning_path_id = u.learning_path_id
# MAGIC     group by u.learner_email, u.learning_path_id
# MAGIC   )
# MAGIC
# MAGIC   ,
# MAGIC
# MAGIC
# MAGIC   lp_enrollments_workday as (
# MAGIC     select 
# MAGIC       Name,
# MAGIC       e.learner_email,
# MAGIC       learning_path_name,
# MAGIC       learning_path_code,
# MAGIC       e.learning_path_id,
# MAGIC       1 as learning_path_version,
# MAGIC       e.completed_timestamp,
# MAGIC       t.completed_timestamp as lp_completed_timestamp,
# MAGIC       completed_courses,
# MAGIC       total_courses,
# MAGIC       e.course_name,
# MAGIC       e.enrollment_status,
# MAGIC       lp_courses,
# MAGIC       round(completed_courses/total_courses * 100, 1) as percent_completed,
# MAGIC       case 
# MAGIC         when completed_courses = 0 then 'Not Started' 
# MAGIC         when completed_courses < total_courses then 'In Progress'
# MAGIC         when completed_courses = total_courses then 'Completed'
# MAGIC       end as lp_enrollment_status,
# MAGIC       case 
# MAGIC         when Original_Hire_Date >= DATEADD(month, -1, getdate()) then '<1 month' 
# MAGIC         when Original_Hire_Date < DATEADD(month, -1, getdate()) and Original_Hire_Date >= DATEADD(month, -3, getdate()) then '1-3 months'
# MAGIC         when Original_Hire_Date < DATEADD(month, -3, getdate()) and Original_Hire_Date >= DATEADD(month, -6, getdate()) then '3-6 months'
# MAGIC         when Original_Hire_Date < DATEADD(month, -6, getdate()) and Original_Hire_Date >= DATEADD(month, -12, getdate()) then '6-12 months'
# MAGIC         when Original_Hire_Date < DATEADD(month, -12, getdate()) and Original_Hire_Date >= DATEADD(month, -36, getdate()) then '1-3 years'
# MAGIC         when Original_Hire_Date < DATEADD(month, -36, getdate()) then '>3 years'
# MAGIC       end as tenure,
# MAGIC       date,
# MAGIC       day,
# MAGIC       year,
# MAGIC       month,
# MAGIC       monthName,
# MAGIC       quarter,
# MAGIC       week,
# MAGIC       dayofweek,
# MAGIC       fiscalYear,
# MAGIC       fiscalQuarter,
# MAGIC       FQ2,
# MAGIC       Worker_Type,
# MAGIC       workday_status,
# MAGIC       Hire_Date,
# MAGIC       -- Last_Promotion_Date,
# MAGIC       Cost_Center,
# MAGIC       Location,
# MAGIC       Location_Address_Country,
# MAGIC       Job_Profile,
# MAGIC       businessTitle,
# MAGIC       Manager_Level_01,
# MAGIC       Manager_Level_02,
# MAGIC       Manager_Level_03,
# MAGIC       Manager,
# MAGIC       Manager_Email,
# MAGIC       Supervisory_Organization,
# MAGIC       Supervisory_Organization_cleaned,
# MAGIC       -- Time_Zone,
# MAGIC       -- Time_Zone_GMT_Factor,
# MAGIC       Original_Hire_Date,
# MAGIC       Job_Profile_Start_Date,
# MAGIC       -- Last_Job_Req_Event_Date,
# MAGIC       -- wd_id,
# MAGIC       manager_hierarchy_path,
# MAGIC       manager_hierarchy_path_name,
# MAGIC       -- category,
# MAGIC       -- department,
# MAGIC       6th_level_manager,
# MAGIC       5th_level_manager,
# MAGIC       4th_level_manager,
# MAGIC       3rd_level_manager,
# MAGIC       2nd_level_manager,
# MAGIC       1st_level_manager,
# MAGIC       init_level_manager,
# MAGIC       6th_level_manager_name,
# MAGIC       5th_level_manager_name,
# MAGIC       4th_level_manager_name,
# MAGIC       3rd_level_manager_name,
# MAGIC       2nd_level_manager_name,
# MAGIC       1st_level_manager_name,
# MAGIC       init_level_manager_name
# MAGIC     from all_lp e 
# MAGIC     left join email_path_completed_courses c on e.learner_email = c.learner_email and e.learning_path_id = c.learning_path_id
# MAGIC     left join completed_timestamps t on e.learner_email = t.learner_email and e.learning_path_id = t.learning_path_id
# MAGIC     left join workday w on e.learner_email = w.primaryWorkEmail
# MAGIC   )
# MAGIC
# MAGIC   select 
# MAGIC     *
# MAGIC   from lp_enrollments_workday
# MAGIC   where lp_enrollment_status = 'Completed'
# MAGIC -- # ''')

# COMMAND ----------

# DBTITLE 1,Workday Employee Learning Tracking
# MAGIC %sql
# MAGIC
# MAGIC create or replace temp view selling_and_winning_v2 as 
# MAGIC   with workday as (
# MAGIC     select 
# MAGIC       Name,
# MAGIC       WorkdayID,
# MAGIC       Worker_Type,
# MAGIC       trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
# MAGIC       Hire_Date,
# MAGIC       -- Last_Promotion_Date,
# MAGIC       -- Termination_Date,
# MAGIC       -- Job_Profile_Prior_To_Last_Promotion_Date,
# MAGIC       -- Business_Title_Prior_To_Last_Promotion_Date,
# MAGIC       Cost_Center,
# MAGIC       Location,
# MAGIC       Location_Address_Country,
# MAGIC       Job_Profile,
# MAGIC       businessTitle,
# MAGIC       Manager_Level_01,
# MAGIC       Manager_Level_02,
# MAGIC       Manager_Level_03,
# MAGIC       Manager,
# MAGIC       Manager_Email,
# MAGIC       Supervisory_Organization,
# MAGIC       Supervisory_Organization_cleaned,
# MAGIC       -- Time_Zone,
# MAGIC       -- Time_Zone_GMT_Factor,
# MAGIC       Original_Hire_Date,
# MAGIC       Job_Profile_Start_Date,
# MAGIC       -- Last_Job_Req_Event_Date,
# MAGIC       -- wd_id,
# MAGIC       manager_hierarchy_path,
# MAGIC       manager_hierarchy_path_name,
# MAGIC       -- category,
# MAGIC       -- department,
# MAGIC       6th_level_manager,
# MAGIC       5th_level_manager,
# MAGIC       4th_level_manager,
# MAGIC       3rd_level_manager,
# MAGIC       2nd_level_manager,
# MAGIC       1st_level_manager,
# MAGIC       init_level_manager,
# MAGIC       6th_level_manager_name,
# MAGIC       5th_level_manager_name,
# MAGIC       4th_level_manager_name,
# MAGIC       3rd_level_manager_name,
# MAGIC       2nd_level_manager_name,
# MAGIC       1st_level_manager_name,
# MAGIC       init_level_manager_name,
# MAGIC       status as workday_status
# MAGIC     from main.field_learning_enablement.workday w
# MAGIC     where w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
# MAGIC   )
# MAGIC   ,
# MAGIC
# MAGIC   lp_enrollments as (
# MAGIC     select * 
# MAGIC     from main.it_training_silver.docebo_learning_plan_enrollments e
# MAGIC     -- inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
# MAGIC     where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
# MAGIC     and learner_branch_code = 'DBK_EMP'
# MAGIC     and learning_path_code = 'FENG-ALL-SLP-v1-FREE-SWFY24-ACT' 
# MAGIC   )
# MAGIC
# MAGIC   ,
# MAGIC   learning_plans as (
# MAGIC     select
# MAGIC       id as learning_plan_id,
# MAGIC       name as learning_plan_name,
# MAGIC       code as learning_plan_code,
# MAGIC       total_courses
# MAGIC     from main.it_training_silver.docebo_learning_plans 
# MAGIC     where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
# MAGIC     and code = 'FENG-ALL-SLP-v1-FREE-SWFY24-ACT' 
# MAGIC   ),
# MAGIC   learning_plan_courses_v1 as (
# MAGIC     select 
# MAGIC       path_id,
# MAGIC       course_id,
# MAGIC       course_name,
# MAGIC       course_code
# MAGIC     from main.it_training_silver.docebo_learning_plan_courses e
# MAGIC     where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
# MAGIC     -- where e.processdate = '2024-01-05'
# MAGIC   ),
# MAGIC   self_paced_enrollments as (
# MAGIC     select distinct
# MAGIC       course_id,
# MAGIC       course_name,
# MAGIC       learner_user_id,
# MAGIC       status as enrollment_status, 
# MAGIC       completed_timestamp
# MAGIC     from main.field_learning_enablement.self_paced_enrollments e
# MAGIC     where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
# MAGIC     -- where e.processdate = '2024-01-08'
# MAGIC     and learner_branch_code = 'DBK_EMP'
# MAGIC   )
# MAGIC
# MAGIC   ,
# MAGIC   ilt_enrollments as (
# MAGIC     select distinct
# MAGIC       course_id,
# MAGIC       course_name,
# MAGIC       learner_user_id,
# MAGIC       status as enrollment_status, 
# MAGIC       completed_timestamp
# MAGIC     from main.field_learning_enablement.ilt_enrollments e
# MAGIC     where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
# MAGIC     -- where e.processdate = '2024-01-08'
# MAGIC     and learner_branch_code = 'DBK_EMP'
# MAGIC   )
# MAGIC   ,
# MAGIC   all_enrollments as ( 
# MAGIC     select
# MAGIC       course_id,
# MAGIC       course_name,
# MAGIC       learner_user_id,
# MAGIC       enrollment_status, 
# MAGIC       completed_timestamp
# MAGIC     from self_paced_enrollments
# MAGIC     union all 
# MAGIC     select
# MAGIC       course_id,
# MAGIC       course_name,
# MAGIC       learner_user_id,
# MAGIC       enrollment_status, 
# MAGIC       completed_timestamp
# MAGIC     from ilt_enrollments
# MAGIC   )
# MAGIC   ,
# MAGIC   all_lp as (
# MAGIC       select 
# MAGIC         e.learner_user_id,
# MAGIC         learner_email,
# MAGIC         learning_path_id, 
# MAGIC         learning_path_name,
# MAGIC         learning_path_code,
# MAGIC         c.course_id,
# MAGIC         c.course_name,
# MAGIC         c.course_code,
# MAGIC         nvl(enrollment_status, "Not Enrolled") as enrollment_status,
# MAGIC         completed_timestamp,
# MAGIC         date,
# MAGIC         day,
# MAGIC         cast(calendar_year as INT) as year,
# MAGIC         cast(calendar_month as INT) as month,
# MAGIC         month_name as monthName,
# MAGIC         cast(calendar_quarter as INT) as quarter,
# MAGIC         cast(calendar_week as INT) as week,
# MAGIC         cast(day_of_week as INT) as dayofweek,
# MAGIC         cast(fiscal_year as INT) as fiscalYear,
# MAGIC         cast(fiscal_quarter as INT) as fiscalQuarter,
# MAGIC         fiscal_year_quarter as FQ2
# MAGIC       from lp_enrollments e
# MAGIC       join learning_plans l on e.learning_path_id = l.learning_plan_id
# MAGIC       -- join learning_plan_courses c on e.learning_path_id = c.path_id 
# MAGIC       join learning_plan_courses_v1 c on e.learning_path_id = c.path_id 
# MAGIC       left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
# MAGIC       inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
# MAGIC       order by c.course_name
# MAGIC     )
# MAGIC
# MAGIC
# MAGIC   ,
# MAGIC   
# MAGIC
# MAGIC   email_path_completed_courses as (
# MAGIC     select 
# MAGIC       learner_email,
# MAGIC       learning_path_id,
# MAGIC       count(distinct course_id) as total_courses,
# MAGIC       sum(case when enrollment_status="completed" then 1 else 0 end) as completed_courses,
# MAGIC       collect_list(course_name) as lp_courses, 
# MAGIC       collect_list(course_code) as lp_course_codes
# MAGIC     from all_lp
# MAGIC     group by learner_email, learning_path_id
# MAGIC   )
# MAGIC
# MAGIC   ,
# MAGIC
# MAGIC   completed_lps as (
# MAGIC     select distinct 
# MAGIC       learner_email, 
# MAGIC       learning_path_id
# MAGIC     from email_path_completed_courses
# MAGIC     where total_courses = completed_courses
# MAGIC   )
# MAGIC
# MAGIC   ,
# MAGIC   completed_timestamps as (
# MAGIC     select 
# MAGIC       u.learner_email, 
# MAGIC       u.learning_path_id, 
# MAGIC       max(completed_timestamp) as completed_timestamp
# MAGIC     from all_lp u 
# MAGIC     join completed_lps c on c.learner_email = u.learner_email and c.learning_path_id = u.learning_path_id
# MAGIC     group by u.learner_email, u.learning_path_id
# MAGIC   )
# MAGIC
# MAGIC   ,
# MAGIC
# MAGIC
# MAGIC   lp_enrollments_workday as (
# MAGIC     select 
# MAGIC       Name,
# MAGIC       e.learner_email,
# MAGIC       learning_path_name,
# MAGIC       learning_path_code,
# MAGIC       e.learning_path_id,
# MAGIC       2 as learning_path_version,
# MAGIC       e.completed_timestamp,
# MAGIC       t.completed_timestamp as lp_completed_timestamp,
# MAGIC       completed_courses,
# MAGIC       total_courses,
# MAGIC       e.course_name,
# MAGIC       e.enrollment_status,
# MAGIC       lp_courses,
# MAGIC       round(completed_courses/total_courses * 100, 1) as percent_completed,
# MAGIC       case 
# MAGIC         when completed_courses = 0 then 'Not Started' 
# MAGIC         when completed_courses < total_courses then 'In Progress'
# MAGIC         when completed_courses = total_courses then 'Completed'
# MAGIC       end as lp_enrollment_status,
# MAGIC       case 
# MAGIC         when Original_Hire_Date >= DATEADD(month, -1, getdate()) then '<1 month' 
# MAGIC         when Original_Hire_Date < DATEADD(month, -1, getdate()) and Original_Hire_Date >= DATEADD(month, -3, getdate()) then '1-3 months'
# MAGIC         when Original_Hire_Date < DATEADD(month, -3, getdate()) and Original_Hire_Date >= DATEADD(month, -6, getdate()) then '3-6 months'
# MAGIC         when Original_Hire_Date < DATEADD(month, -6, getdate()) and Original_Hire_Date >= DATEADD(month, -12, getdate()) then '6-12 months'
# MAGIC         when Original_Hire_Date < DATEADD(month, -12, getdate()) and Original_Hire_Date >= DATEADD(month, -36, getdate()) then '1-3 years'
# MAGIC         when Original_Hire_Date < DATEADD(month, -36, getdate()) then '>3 years'
# MAGIC       end as tenure,
# MAGIC       date,
# MAGIC       day,
# MAGIC       year,
# MAGIC       month,
# MAGIC       monthName,
# MAGIC       quarter,
# MAGIC       week,
# MAGIC       dayofweek,
# MAGIC       fiscalYear,
# MAGIC       fiscalQuarter,
# MAGIC       FQ2,
# MAGIC       Worker_Type,
# MAGIC       workday_status,
# MAGIC       Hire_Date,
# MAGIC       -- Last_Promotion_Date,
# MAGIC       Cost_Center,
# MAGIC       Location,
# MAGIC       Location_Address_Country,
# MAGIC       Job_Profile,
# MAGIC       businessTitle,
# MAGIC       Manager_Level_01,
# MAGIC       Manager_Level_02,
# MAGIC       Manager_Level_03,
# MAGIC       Manager,
# MAGIC       Manager_Email,
# MAGIC       Supervisory_Organization,
# MAGIC       Supervisory_Organization_cleaned,
# MAGIC       -- Time_Zone,
# MAGIC       -- Time_Zone_GMT_Factor,
# MAGIC       Original_Hire_Date,
# MAGIC       Job_Profile_Start_Date,
# MAGIC       -- Last_Job_Req_Event_Date,
# MAGIC       -- wd_id,
# MAGIC       manager_hierarchy_path,
# MAGIC       manager_hierarchy_path_name,
# MAGIC       -- category,
# MAGIC       -- department,
# MAGIC       6th_level_manager,
# MAGIC       5th_level_manager,
# MAGIC       4th_level_manager,
# MAGIC       3rd_level_manager,
# MAGIC       2nd_level_manager,
# MAGIC       1st_level_manager,
# MAGIC       init_level_manager,
# MAGIC       6th_level_manager_name,
# MAGIC       5th_level_manager_name,
# MAGIC       4th_level_manager_name,
# MAGIC       3rd_level_manager_name,
# MAGIC       2nd_level_manager_name,
# MAGIC       1st_level_manager_name,
# MAGIC       init_level_manager_name
# MAGIC     from all_lp e 
# MAGIC     left join email_path_completed_courses c on e.learner_email = c.learner_email and e.learning_path_id = c.learning_path_id
# MAGIC     left join completed_timestamps t on e.learner_email = t.learner_email and e.learning_path_id = t.learning_path_id
# MAGIC     left join workday w on e.learner_email = w.primaryWorkEmail
# MAGIC     where e.learner_email not in (select distinct learner_email from selling_and_winning_v1)
# MAGIC   )
# MAGIC
# MAGIC   select 
# MAGIC     *
# MAGIC   from lp_enrollments_workday

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view selling_and_winning_v3 as 
# MAGIC with spe_cte as (
# MAGIC     select
# MAGIC     w.Name
# MAGIC     ,spe.learner_email
# MAGIC     ,spe.course_name as learning_path_name
# MAGIC     ,spe.course_code as learning_path_code
# MAGIC     ,spe.course_id as learning_path_id
# MAGIC     ,null as learning_path_version
# MAGIC     ,spe.completed_timestamp
# MAGIC     ,spe.completed_timestamp as lp_completed_timestamp
# MAGIC     ,null as completed_courses
# MAGIC     ,null as total_courses
# MAGIC     ,spe.course_name
# MAGIC     ,spe.status as enrollment_status
# MAGIC     ,null as lp_courses
# MAGIC     ,100 as percent_completed
# MAGIC     ,'Completed' as lp_enrollment_status
# MAGIC     ,null as tenure
# MAGIC     ,null as date
# MAGIC     ,null as day
# MAGIC     ,null as year
# MAGIC     ,null as month
# MAGIC     ,null as monthName
# MAGIC     ,null as quarter
# MAGIC     ,null as week
# MAGIC     ,null as dayofweek
# MAGIC     ,null as fiscalYear
# MAGIC     ,null as fiscalQuarter
# MAGIC     ,null as FQ2
# MAGIC     ,w.Worker_Type
# MAGIC     ,null as workday_status
# MAGIC     ,w.Hire_Date
# MAGIC     -- ,null as Last_Promotion_Date
# MAGIC     ,w.Cost_Center
# MAGIC     ,w.Location
# MAGIC     ,w.Location_Address_Country
# MAGIC     ,w.Job_Profile
# MAGIC     ,w.businessTitle
# MAGIC     ,w.Manager_Level_01
# MAGIC     ,w.Manager_Level_02
# MAGIC     ,w.Manager_Level_03
# MAGIC     ,w.Manager
# MAGIC     ,w.Manager_Email
# MAGIC     ,w.Supervisory_Organization
# MAGIC     ,w.Supervisory_Organization_cleaned
# MAGIC     -- ,null as Time_Zone
# MAGIC     -- ,null as Time_Zone_GMT_Factor
# MAGIC     ,w.Original_Hire_Date
# MAGIC     ,w.job_profile_start_date
# MAGIC     -- ,null as Last_Job_Req_Event_Date
# MAGIC     -- ,w.WorkdayID as wd_id
# MAGIC     ,w.manager_hierarchy_path
# MAGIC     ,w.manager_hierarchy_path_name
# MAGIC     -- ,null as category
# MAGIC     -- ,null as department
# MAGIC     ,w.6th_level_manager
# MAGIC     ,w.5th_level_manager
# MAGIC     ,w.4th_level_manager
# MAGIC     ,w.3rd_level_manager
# MAGIC     ,w.2nd_level_manager
# MAGIC     ,w.1st_level_manager
# MAGIC     ,w.init_level_manager
# MAGIC     ,w.6th_level_manager_name
# MAGIC     ,w.5th_level_manager_name
# MAGIC     ,w.4th_level_manager_name
# MAGIC     ,w.3rd_level_manager_name
# MAGIC     ,w.2nd_level_manager_name
# MAGIC     ,w.1st_level_manager_name
# MAGIC     ,w.init_level_manager_name
# MAGIC     -- ,w.processDate
# MAGIC     from 
# MAGIC     (select * from main.field_learning_enablement.self_paced_enrollments where course_code = 'ACAD-FENG-sp-v1-onboarding-s/w'
# MAGIC     and status = 'completed' and processDate = (select max(processDate) from main.field_learning_enablement.self_paced_enrollments)) spe
# MAGIC     left join
# MAGIC     (select * from Main.field_learning_enablement.workday where status = TRUE
# MAGIC     and processDate = (select max(processDate) from main.field_learning_enablement.workday) ) w
# MAGIC     on spe.learner_email = w.primaryWorkemail
# MAGIC     and spe.processDate = w.processDate
# MAGIC   )
# MAGIC   ,
# MAGIC
# MAGIC   selling_and_winning_details_updated as (
# MAGIC     select s.* from 
# MAGIC     (select * from selling_and_winning_v2)s
# MAGIC     left join spe_cte
# MAGIC     on s.learner_email = spe_cte.learner_email
# MAGIC     union all
# MAGIC     select * from spe_cte 
# MAGIC     where learner_email is not null
# MAGIC     and learner_email not in (select distinct learner_email from selling_and_winning_v2 where learner_email is not null)
# MAGIC   )
# MAGIC
# MAGIC   select * from selling_and_winning_details_updated

# COMMAND ----------

selling_winning_details = spark.sql('''
  select *
  from selling_and_winning_v1
  union all 
  select *
  from selling_and_winning_v3

''')

# COMMAND ----------

selling_winning_details_gold = add_gold_metadata(selling_winning_details)

# COMMAND ----------

# MAGIC %md # UC Upgrade Summary

# COMMAND ----------

# DBTITLE 1,Employee Learning Plan Analysis
uc_upgrade_summary = spark.sql('''
  with get_certified_audience as (
    select
      primaryWorkEmail 
    from main.field_learning_enablement.get_certified 
    where processDate = (select max(processDate) from main.field_learning_enablement.get_certified)
  )
  ,
  workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    -- inner join get_certified_audience i on trim(lower(w.primaryWorkEmail)) = trim(lower(i.primaryWorkEmail))
    where w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,
  --wd as ( 
  --  select 
  --    wd_email as primaryWorkEmail, 
  --    sfdc_businessUnit 
  --  from liam.list_of_workday_users_and_respective_sfdc_user_ids
  --)
  --,
  lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    and code = 'ACAD-FENG-LPLAN-v1-FREE-UCUE-ACT' 
  ),
  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
  ),
  self_paced_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  ilt_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )
  ,
  all_enrollments as ( 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from ilt_enrollments
  )
  ,
  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        completed_timestamp
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
      order by c.course_name
    )

  ,

  email_path_completed_courses as (
    select 
      learner_email,
      learning_path_id,
      count(distinct course_id) as total_courses,
      sum(case when enrollment_status="completed" then 1 else 0 end) as completed_courses,
      -- collect_list(struct(course_name, enrollment_status)) as course_enrollment_status,
      collect_list(course_name) as lp_courses, 
      collect_list(course_code) as lp_course_codes
    from all_lp
    group by learner_email, learning_path_id
    -- order by course_enrollment_status.course_name
  )


  ,

  courses_completed as (
    select *
    from (
      select learner_email, course_name, enrollment_status from all_lp
    )
    pivot (
      max(nvl(enrollment_status, 'Not Enrolled'))
      for course_name in ('Qualifying and Positioning Unity Catalog Upgrades', 'Upgrading Unity Catalog', 'Upgrading Unity Catalog Reprise Walkthrough')
    )
  )

  ,
  completed_lps as (
    select distinct 
      learner_email, 
      learning_path_id
    from email_path_completed_courses
    where total_courses = completed_courses
  )

  ,
  completed_timestamps as (
    select 
      u.learner_email, 
      u.learning_path_id, 
      max(completed_timestamp) as completed_timestamp
    from all_lp u 
    join completed_lps c on c.learner_email = u.learner_email and c.learning_path_id = u.learning_path_id
    group by u.learner_email, u.learning_path_id
  )



  ,
  lp_info as (
    select 
      e.*, 
      -- e.course_enrollment_status[0].enrollment_status as Generative_AI_Fundamentals,
      -- e.course_enrollment_status[1].enrollment_status as LLM_Application_through_Production,
      c1.`Qualifying and Positioning Unity Catalog Upgrades` as Qualifying_and_Positioning_Unity_Catalog_Upgrades,
      c1.`Upgrading Unity Catalog` as Upgrading_Unity_Catalog,
      c1.`Upgrading Unity Catalog Reprise Walkthrough` as Upgrading_Unity_Catalog_Reprise_Walkthrough,
      completed_timestamp
    from email_path_completed_courses e
    left join completed_timestamps c on c.learner_email = e.learner_email and c.learning_path_id = e.learning_path_id
    left join courses_completed c1 on e.learner_email = c1.learner_email
    -- order by course_enrollment_status.course_name
  )

  ,

  lp_enrollments_workday as (
    select 
      Name,
      e.learner_email,
      learning_path_name,
      learning_path_code,
      e.learning_path_id,
      assigned_timestamp,
      completed_timestamp,
      completed_courses,
      total_courses,
      lp_courses,
      -- course_enrollment_status,
      Qualifying_and_Positioning_Unity_Catalog_Upgrades,
      Upgrading_Unity_Catalog,
      Upgrading_Unity_Catalog_Reprise_Walkthrough,
      round(completed_courses/total_courses * 100, 1) as percent_completed,
      case 
        when completed_courses = 0 then 'Not Started' 
        when completed_courses < total_courses then 'In Progress'
        when completed_courses = total_courses then 'Completed'
      end as lp_enrollment_status,
      case 
        when Original_Hire_Date >= DATEADD(month, -1, getdate()) then '<1 month' 
        when Original_Hire_Date < DATEADD(month, -1, getdate()) and Original_Hire_Date >= DATEADD(month, -3, getdate()) then '1-3 months'
        when Original_Hire_Date < DATEADD(month, -3, getdate()) and Original_Hire_Date >= DATEADD(month, -6, getdate()) then '3-6 months'
        when Original_Hire_Date < DATEADD(month, -6, getdate()) and Original_Hire_Date >= DATEADD(month, -12, getdate()) then '6-12 months'
        when Original_Hire_Date < DATEADD(month, -12, getdate()) and Original_Hire_Date >= DATEADD(month, -36, getdate()) then '1-3 years'
        when Original_Hire_Date < DATEADD(month, -36, getdate()) then '>3 years'
      end as tenure,
      date,
      day,
      cast(calendar_year as INT) as year,
      cast(calendar_month as INT) as month,
      month_name as monthName,
      cast(calendar_quarter as INT) as quarter,
      cast(calendar_week as INT) as week,
      cast(day_of_week as INT) as dayofweek,
      cast(fiscal_year as INT) as fiscalYear,
      cast(fiscal_quarter as INT) as fiscalQuarter,
      fiscal_year_quarter as FQ2,
      Worker_Type,
      workday_status,
      Hire_Date,
      -- Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- sfdc_businessUnit,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name
      
    from lp_enrollments e
    join lp_info i on i.learner_email = e.learner_email and i.learning_path_id = e.learning_path_id
    left join workday w on e.learner_email = w.primaryWorkEmail
    -- left join wd d on w.primaryWorkEmail = d.primaryWorkEmail
    -- order by course_enrollment_status.course_name
  )

  select 
    *
  from lp_enrollments_workday
''')

# COMMAND ----------

uc_upgrade_summary_gold = add_gold_metadata(uc_upgrade_summary)

# COMMAND ----------

# MAGIC %md # UC Upgrade Details

# COMMAND ----------

# DBTITLE 1,Certified User Upgrade Analysis
uc_upgrade_details = spark.sql('''
  with get_certified_audience as (
    select
      primaryWorkEmail 
    from main.field_learning_enablement.get_certified 
    where processDate = (select max(processDate) from main.field_learning_enablement.get_certified)
  )
  ,
  workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    -- inner join get_certified_audience i on trim(lower(w.primaryWorkEmail)) = trim(lower(i.primaryWorkEmail))
    where processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,
  --wd as ( 
  --  select 
  --    wd_email as primaryWorkEmail, 
  --    sfdc_businessUnit 
  --  from liam.list_of_workday_users_and_respective_sfdc_user_ids
  --)
  --,
  lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    and code = 'ACAD-FENG-LPLAN-v1-FREE-UCUE-ACT' 
  ),
  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
  ),
  self_paced_enrollments as (
    select distinct
      course_id,
      course_code,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  ilt_enrollments as (
    select distinct
      course_id,
      course_code,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )
  ,
  all_enrollments as ( 
    select
      course_id,
      course_code,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_code,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from ilt_enrollments
  )
  ,
  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        completed_timestamp,
        w.*
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_code = a.course_code and e.learner_user_id = a.learner_user_id
      left join workday w on w.primaryWorkEmail = e.learner_email
    )


  select 
    *,
    case when enrollment_status = "Not Enrolled" then 0 else 1 end as enrolled_flag
  from all_lp
  where 1=1
  -- and enrollment_status="Not Enrolled"
  order by learner_email   

''')

# COMMAND ----------

uc_upgrade_details_gold = add_gold_metadata(uc_upgrade_details)

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Databricks Intelligence Platform Summary

# COMMAND ----------

# DBTITLE 1,Dynamic Training Enrollment Query
dip_summary = spark.sql('''
  with workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    where w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,
 -- wd as ( 
 --   select 
 --     wd_email as primaryWorkEmail, 
 --     sfdc_businessUnit 
 --   from liam.list_of_workday_users_and_respective_sfdc_user_ids
 -- )
 -- ,
  lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    and code = 'ACAD-FENG-LPLAN-v1-FREE-DIP-ACT' 
  ),
  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
  ),
  self_paced_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  ilt_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )
  ,
  all_enrollments as ( 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from ilt_enrollments
  )
  ,
  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        completed_timestamp
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
      order by c.course_name
    )
  ,

  email_path_completed_courses as (
    select 
      learner_email,
      learning_path_id,
      count(distinct course_id) as total_courses,
      sum(case when enrollment_status="completed" then 1 else 0 end) as completed_courses,
      -- collect_list(struct(course_name, enrollment_status)) as course_enrollment_status,
      collect_list(course_name) as lp_courses, 
      collect_list(course_code) as lp_course_codes
    from all_lp
    group by learner_email, learning_path_id
    -- order by course_enrollment_status.course_name
  )

  ,

  courses_completed as (
    select *
    from (
      select learner_email, course_name, enrollment_status from all_lp
    )
    pivot (
      max(nvl(enrollment_status, 'Not Enrolled'))
      for course_name in ('Data Intelligence Platform: All You Need To Know - BrickBites', 'Data Intelligence Platform Technical Pitch Walkthrough', 'Data Intelligence Platform Demo Walkthrough')
    )
  )

  ,
  completed_lps as (
    select distinct 
      learner_email, 
      learning_path_id
    from email_path_completed_courses
    where total_courses = completed_courses
  )

  ,
  completed_timestamps as (
    select 
      u.learner_email, 
      u.learning_path_id, 
      max(completed_timestamp) as completed_timestamp
    from all_lp u 
    join completed_lps c on c.learner_email = u.learner_email and c.learning_path_id = u.learning_path_id
    group by u.learner_email, u.learning_path_id
  )

  ,
  lp_info as (
    select 
      e.*, 
      -- e.course_enrollment_status[0].enrollment_status as Generative_AI_Fundamentals,
      -- e.course_enrollment_status[1].enrollment_status as LLM_Application_through_Production,
      c1.`Data Intelligence Platform: All You Need To Know - BrickBites` as dip_brickbites,
      c1.`Data Intelligence Platform Technical Pitch Walkthrough` as dip_technical_pitch,
      c1.`Data Intelligence Platform Demo Walkthrough` as dip_demo_walkthrough, 
      completed_timestamp
    from email_path_completed_courses e
    left join completed_timestamps c on c.learner_email = e.learner_email and c.learning_path_id = e.learning_path_id
    left join courses_completed c1 on e.learner_email = c1.learner_email
    -- order by course_enrollment_status.course_name
  )

  ,


  lp_enrollments_workday as (
    select 
      Name,
      e.learner_email,
      learning_path_name,
      learning_path_code,
      e.learning_path_id,
      assigned_timestamp,
      completed_timestamp,
      completed_courses,
      total_courses,
      lp_courses,
      -- course_enrollment_status,
      dip_brickbites,
      dip_technical_pitch,
      dip_demo_walkthrough,
      round(completed_courses/total_courses * 100, 1) as percent_completed,
      case 
        when completed_courses = 0 then 'Not Started' 
        when completed_courses < total_courses then 'In Progress'
        when completed_courses = total_courses then 'Completed'
      end as lp_enrollment_status,
      case 
        when Original_Hire_Date >= DATEADD(month, -1, getdate()) then '<1 month' 
        when Original_Hire_Date < DATEADD(month, -1, getdate()) and Original_Hire_Date >= DATEADD(month, -3, getdate()) then '1-3 months'
        when Original_Hire_Date < DATEADD(month, -3, getdate()) and Original_Hire_Date >= DATEADD(month, -6, getdate()) then '3-6 months'
        when Original_Hire_Date < DATEADD(month, -6, getdate()) and Original_Hire_Date >= DATEADD(month, -12, getdate()) then '6-12 months'
        when Original_Hire_Date < DATEADD(month, -12, getdate()) and Original_Hire_Date >= DATEADD(month, -36, getdate()) then '1-3 years'
        when Original_Hire_Date < DATEADD(month, -36, getdate()) then '>3 years'
      end as tenure,
      date,
      day,
      cast(calendar_year as INT) as year,
      cast(calendar_month as INT) as month,
      month_name as monthName,
      cast(calendar_quarter as INT) as quarter,
      cast(calendar_week as INT) as week,
      cast(day_of_week as INT) as dayofweek,
      cast(fiscal_year as INT) as fiscalYear,
      cast(fiscal_quarter as INT) as fiscalQuarter,
      fiscal_year_quarter as FQ2,
      Worker_Type,
      workday_status,
      Hire_Date,
      -- Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
     -- sfdc_businessUnit,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name
    from lp_enrollments e
    join lp_info i on i.learner_email = e.learner_email and i.learning_path_id = e.learning_path_id
    left join workday w on e.learner_email = w.primaryWorkEmail
    --left join wd d on w.primaryWorkEmail = d.primaryWorkEmail

  )

  select 
    *
  from lp_enrollments_workday
''')

# COMMAND ----------

dip_summary_gold = add_gold_metadata(dip_summary)

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Databricks Intelligence Platform Details

# COMMAND ----------

# DBTITLE 1,Employee Learning Data Aggregator
dip_details = spark.sql('''
  with workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    where processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,
  --wd as ( 
  --  select 
  --    wd_email as primaryWorkEmail, 
  --    sfdc_businessUnit 
  --  from liam.list_of_workday_users_and_respective_sfdc_user_ids
  --)
  --,
  lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    and code = 'ACAD-FENG-LPLAN-v1-FREE-DIP-ACT' 
  ),
  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
  ),
  self_paced_enrollments as (
    select distinct
      course_id,
      course_code,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  ilt_enrollments as (
    select distinct
      course_id,
      course_code,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )
  ,
  all_enrollments as ( 
    select
      course_id,
      course_code,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_code,
      course_name,
      learner_user_id,
      enrollment_status, 
      completed_timestamp
    from ilt_enrollments
  )
  ,
  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        completed_timestamp,
        w.*
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_code = a.course_code and e.learner_user_id = a.learner_user_id
      left join workday w on w.primaryWorkEmail = e.learner_email
    )


  select 
    *,
    case when enrollment_status = "Not Enrolled" then 0 else 1 end as enrolled_flag
  from all_lp
  order by learner_email   
''')

# COMMAND ----------

dip_details_gold = add_gold_metadata(dip_details)

# COMMAND ----------

# MAGIC %md
# MAGIC #Scaled Summary

# COMMAND ----------

# DBTITLE 1,Employee Training Analytics Query
all_summary = spark.sql('''
  with workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    where w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,
 -- wd as ( 
 --   select 
 --     wd_email as primaryWorkEmail, 
 --     sfdc_businessUnit 
 --   from liam.list_of_workday_users_and_respective_sfdc_user_ids
 -- )
 -- ,
  lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    -- and code = 'ACAD-FENG-LPLAN-v1-FREE-DIP-ACT' 
  ),
  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    left join main.it_training_silver.docebo_courses c on e.course_id = c.id 
    and c.processDate = (select max(processdate) from main.it_training_silver.docebo_courses)
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
    and course_status = 2
  ),
  self_paced_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      enrolled_timestamp,
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  ilt_enrollments as (
    select distinct
      course_id,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      enrolled_timestamp,
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )
  ,
  all_enrollments as ( 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      enrolled_timestamp,
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_name,
      learner_user_id,
      enrollment_status, 
      enrolled_timestamp,
      completed_timestamp
    from ilt_enrollments
  )
  ,
  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        enrolled_timestamp,
        completed_timestamp
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
      order by c.course_name
    )
  ,

  email_path_completed_courses as (
    select 
      learner_email,
      learning_path_id,
      count(distinct course_id) as total_courses,
      sum(case when enrollment_status="completed" then 1 else 0 end) as completed_courses,
      -- collect_list(struct(course_name, enrollment_status)) as course_enrollment_status,
      collect_list(course_name) as lp_courses, 
      collect_list(course_code) as lp_course_codes
    from all_lp
    group by learner_email, learning_path_id
    -- order by course_enrollment_status.course_name
  )

  ,

  courses_completed as (
    select *
    from (
      select learner_email, course_name, enrollment_status from all_lp
    )
  )

  ,
  completed_lps as (
    select distinct 
      learner_email, 
      learning_path_id
    from email_path_completed_courses
    where total_courses = completed_courses
  )

  ,

  enrolled_timestamps as (
    select 
      u.learner_email, 
      u.learning_path_id, 
      min(enrolled_timestamp) as enrolled_timestamp
    from all_lp u 
    left join completed_lps c on c.learner_email = u.learner_email and c.learning_path_id = u.learning_path_id
    group by u.learner_email, u.learning_path_id
  )

  ,
  completed_timestamps as (
    select 
      u.learner_email, 
      u.learning_path_id, 
      max(completed_timestamp) as completed_timestamp
    from all_lp u 
    join completed_lps c on c.learner_email = u.learner_email and c.learning_path_id = u.learning_path_id
    group by u.learner_email, u.learning_path_id
  )
  -- select * from completed_timestamps 
  -- where learning_path_id = 282 
  -- and learner_email = 'a.liu@databricks.com'

  ,
  lp_info as (
    select 
      e.*, 
      completed_timestamp,
      enrolled_timestamp
    from email_path_completed_courses e
    left join completed_timestamps c on c.learner_email = e.learner_email and c.learning_path_id = e.learning_path_id
    left join enrolled_timestamps n on n.learner_email = e.learner_email and n.learning_path_id = e.learning_path_id
    -- left join courses_completed c1 on e.learner_email = c1.learner_email
    -- order by course_enrollment_status.course_name
  )

  ,


  lp_enrollments_workday as (
    select 
      Name,
      e.learner_email,
      learning_path_name,
      learning_path_code,
      e.learning_path_id,
      assigned_timestamp,
      enrolled_timestamp,
      completed_timestamp,
      completed_courses,
      total_courses,
      lp_courses,
      round(completed_courses/total_courses * 100, 1) as percent_completed,
      case 
        when completed_courses = 0 then 'Not Started' 
        when completed_courses < total_courses then 'In Progress'
        when completed_courses = total_courses then 'Completed'
      end as lp_enrollment_status,
      case 
        when Original_Hire_Date >= DATEADD(month, -1, getdate()) then '<1 month' 
        when Original_Hire_Date < DATEADD(month, -1, getdate()) and Original_Hire_Date >= DATEADD(month, -3, getdate()) then '1-3 months'
        when Original_Hire_Date < DATEADD(month, -3, getdate()) and Original_Hire_Date >= DATEADD(month, -6, getdate()) then '3-6 months'
        when Original_Hire_Date < DATEADD(month, -6, getdate()) and Original_Hire_Date >= DATEADD(month, -12, getdate()) then '6-12 months'
        when Original_Hire_Date < DATEADD(month, -12, getdate()) and Original_Hire_Date >= DATEADD(month, -36, getdate()) then '1-3 years'
        when Original_Hire_Date < DATEADD(month, -36, getdate()) then '>3 years'
      end as tenure,
      date,
      day,
      cast(calendar_year as INT) as year,
      cast(calendar_month as INT) as month,
      month_name as monthName,
      cast(calendar_quarter as INT) as quarter,
      cast(calendar_week as INT) as week,
      cast(day_of_week as INT) as dayofweek,
      cast(fiscal_year as INT) as fiscalYear,
      cast(fiscal_quarter as INT) as fiscalQuarter,
      fiscal_year_quarter as FQ2,
      Worker_Type,
      workday_status,
      Hire_Date,
      -- Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
     -- sfdc_businessUnit,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name
    from lp_enrollments e
    join lp_info i on i.learner_email = e.learner_email and i.learning_path_id = e.learning_path_id
    left join workday w on e.learner_email = w.primaryWorkEmail
    --left join wd d on w.primaryWorkEmail = d.primaryWorkEmail

  )

  select 
    *
  from lp_enrollments_workday
  -- where enrolled_timestamp is null and trim(lower(learning_path_name)) = 'l200: selling and winning'

''')

# COMMAND ----------

all_summary_gold = add_gold_metadata(all_summary)

# COMMAND ----------

# MAGIC %md
# MAGIC #Scaled Details

# COMMAND ----------

# DBTITLE 1,Employee Training Enrollment Query
all_details = spark.sql('''
  with workday as (
    select 
      Name,
      WorkdayID,
      Worker_Type,
      trim(lower(w.primaryWorkEmail)) as primaryWorkEmail,
      Hire_Date,
      -- Last_Promotion_Date,
      -- Termination_Date,
      -- Job_Profile_Prior_To_Last_Promotion_Date,
      -- Business_Title_Prior_To_Last_Promotion_Date,
      Cost_Center,
      Location,
      Location_Address_Country,
      Job_Profile,
      businessTitle,
      Manager_Level_01,
      Manager_Level_02,
      Manager_Level_03,
      Manager,
      Manager_Email,
      Supervisory_Organization,
      Supervisory_Organization_cleaned,
      -- Time_Zone,
      -- Time_Zone_GMT_Factor,
      Original_Hire_Date,
      Job_Profile_Start_Date,
      -- Last_Job_Req_Event_Date,
      -- wd_id,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      -- category,
      -- department,
      6th_level_manager,
      5th_level_manager,
      4th_level_manager,
      3rd_level_manager,
      2nd_level_manager,
      1st_level_manager,
      init_level_manager,
      6th_level_manager_name,
      5th_level_manager_name,
      4th_level_manager_name,
      3rd_level_manager_name,
      2nd_level_manager_name,
      1st_level_manager_name,
      init_level_manager_name,
      status as workday_status
    from main.field_learning_enablement.workday w
    where processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,
  --wd as ( 
  --  select 
  --    wd_email as primaryWorkEmail, 
  --    sfdc_businessUnit 
  --  from liam.list_of_workday_users_and_respective_sfdc_user_ids
  --)
  --,
  lp_enrollments as (
    select * 
    from main.it_training_silver.docebo_learning_plan_enrollments e
    inner join main.it_core_dim.dim_dates d on e.assigned_timestamp::date=d.date
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  learning_plans as (
    select
      id as learning_plan_id,
      name as learning_plan_name,
      code as learning_plan_code,
      total_courses
    from main.it_training_silver.docebo_learning_plans 
    where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
    -- and code = 'ACAD-FENG-LPLAN-v1-FREE-DIP-ACT' 
  ),
  learning_plan_courses as (
    select 
      path_id,
      course_id,
      course_name,
      course_code
    from main.it_training_silver.docebo_learning_plan_courses e
    left join main.it_training_silver.docebo_courses c on e.course_id = c.id 
    and c.processDate = (select max(processdate) from main.it_training_silver.docebo_courses)
    where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
    and course_status = 2
  ),
  self_paced_enrollments as (
    select distinct
      course_id,
      course_code,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      enrolled_timestamp,
      completed_timestamp
    from main.field_learning_enablement.self_paced_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )

  ,
  ilt_enrollments as (
    select distinct
      course_id,
      course_code,
      course_name,
      learner_user_id,
      status as enrollment_status, 
      enrolled_timestamp,
      completed_timestamp
    from main.field_learning_enablement.ilt_enrollments e
    where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
    and learner_branch_code = 'DBK_EMP'
  )
  ,
  all_enrollments as ( 
    select
      course_id,
      course_code,
      course_name,
      learner_user_id,
      enrollment_status,
      enrolled_timestamp, 
      completed_timestamp
    from self_paced_enrollments
    union all 
    select
      course_id,
      course_code,
      course_name,
      learner_user_id,
      enrollment_status, 
      enrolled_timestamp,
      completed_timestamp
    from ilt_enrollments
  )
  ,
  all_lp as (
      select 
        e.learner_user_id,
        learner_email,
        learning_path_id, 
        learning_path_name,
        learning_path_code,
        c.course_id,
        c.course_name,
        c.course_code,
        nvl(enrollment_status, "Not Enrolled") as enrollment_status,
        enrolled_timestamp,
        completed_timestamp,
        w.*
      from lp_enrollments e
      join learning_plans l on e.learning_path_id = l.learning_plan_id
      join learning_plan_courses c on e.learning_path_id = c.path_id 
      left join all_enrollments a on c.course_code = a.course_code and e.learner_user_id = a.learner_user_id
      left join workday w on w.primaryWorkEmail = e.learner_email
    )


  select 
    *,
    case when enrollment_status = "Not Enrolled" then 0 else 1 end as enrolled_flag
  from all_lp
  order by learner_email   
''')

# COMMAND ----------

all_details_gold = add_gold_metadata(all_details)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = employee_onboarding_gold, 
  table_name = f'{focus_database_name}.employee_onboarding_learning_plan', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = employee_onboarding_details_gold, 
  table_name = f'{focus_database_name}.employee_onboarding_learning_plan_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = lakehouse_ai_gold, 
  table_name = f'{focus_database_name}.lakehouse_ai_learning_plan', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = lakehouse_ai_details_gold, 
  table_name = f'{focus_database_name}.lakehouse_ai_learning_plan_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = gen_ai_gold, 
  table_name = f'{focus_database_name}.gen_ai_learning_plan', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = gen_ai_details_gold, 
  table_name = f'{focus_database_name}.gen_ai_learning_plan_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = selling_and_winning_summary_gold, 
#   table_name = f'{focus_database_name}.selling_and_winning_learning_plan', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'"
# )

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = selling_and_winning_summary_gold, 
#   table_name = f'focus_dev.selling_and_winning_learning_plan', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'"
# )

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = selling_winning_details_gold, 
  table_name = f'{focus_database_name}.selling_and_winning_learning_plan_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = uc_upgrade_summary_gold, 
  table_name = f'{focus_database_name}.uc_upgrade_learning_plan', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = uc_upgrade_details_gold, 
  table_name = f'{focus_database_name}.uc_upgrade_learning_plan_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = dip_summary_gold, 
  table_name = f'{focus_database_name}.dip_learning_plan_summary', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = dip_details_gold, 
  table_name = f'{focus_database_name}.dip_learning_plan_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_summary_gold, 
  table_name = f'{focus_database_name}.scaled_enablement_all_learning_plans', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_details_gold, 
  table_name = f'{focus_database_name}.scaled_enablement_all_learning_plans_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)