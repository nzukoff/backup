# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

import requests
import zipfile
import json
import os
import sys
import re
import io
from pprint import pprint

data_center_id = "sjc1"
survey_id = "SV_0PURSxKVFboxaXs"
fileFormat = "csv"

url = f"https://{data_center_id}.qualtrics.com/API/v3"
token = dbutils.secrets.get(scope="nate.hast-secrets", key="qualtrics")
# token = "ZQXU86VvkcQR3qPFdopcw8ZQpyCyGnF5jGJSOLQS"

def exportSurvey(apiToken,surveyId, dataCenter, fileFormat):

    surveyId = survey_id
    fileFormat = fileFormat
    dataCenter = data_center_id 
    apiToken =token

    # Setting static parameters
    requestCheckProgress = 0.0
    progressStatus = "inProgress"
    baseUrl = "https://{0}.qualtrics.com/API/v3/surveys/{1}/export-responses/".format(dataCenter, surveyId)
    headers = {
    "content-type": "application/json",
    "x-api-token": apiToken,
    }

    # Step 1: Creating Data Export
    downloadRequestUrl = baseUrl
    downloadRequestPayload = '{"format":"' + fileFormat + '"}'
    downloadRequestResponse = requests.request("POST", downloadRequestUrl, data=downloadRequestPayload, headers=headers)
    pprint(downloadRequestResponse.json())
    progressId = downloadRequestResponse.json()["result"]["progressId"]
    print(downloadRequestResponse.text)

    # Step 2: Checking on Data Export Progress and waiting until export is ready
    while progressStatus != "complete" and progressStatus != "failed":
        print ("progressStatus=", progressStatus)
        requestCheckUrl = baseUrl + progressId
        requestCheckResponse = requests.request("GET", requestCheckUrl, headers=headers)
        requestCheckProgress = requestCheckResponse.json()["result"]["percentComplete"]
        print("Download is " + str(requestCheckProgress) + " complete")
        progressStatus = requestCheckResponse.json()["result"]["status"]

    #step 2.1: Check for error
    if progressStatus == "failed":
        raise Exception("export failed")

    fileId = requestCheckResponse.json()["result"]["fileId"]

    # Step 3: Downloading file
    requestDownloadUrl = baseUrl + fileId + '/file'
    requestDownload = requests.request("GET", requestDownloadUrl, headers=headers, stream=True)

    # Step 4: Unzipping the file
    
    path = "/Volumes/users/tilak_parajiya/qualtrics_data"

    zipfile.ZipFile(io.BytesIO(requestDownload.content)).extractall(path)

    print('Complete')


# COMMAND ----------

exportSurvey(token,survey_id,data_center_id,fileFormat)

# COMMAND ----------

import pandas as pd
survey_df = pd.read_csv("/Volumes/users/tilak_parajiya/qualtrics_data/INVESTech.csv", header=1).drop(index=0)

# COMMAND ----------

spark_df = spark.createDataFrame(survey_df)
spark_df.createOrReplaceTempView("survey_feedback")

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC     *
# MAGIC     from survey_feedback

# COMMAND ----------

survey_clean_df = spark.sql('''
  with survey_pre as (
    select 
    s.`Recipient First Name` as recipient_first_name,
    s.`Recipient Last Name` as recipient_last_name,
    s.`Recipient Email` as recipient_email,
    s.`How satisfied are you with the content of this presentation?` as satisfaction_score,
    s.`How relevant was the topic to your role?` as relevant_score,
    s.`Did the session provide actionable insights or solutions you can apply to your work?` as insights_applicability,
    s.`What topic would you like to see in future sessions?` as future_topics,
    s.`Additional comments` as additional_comments,
    s.Progress as progress, --.
    s.`Duration (in seconds)` as duration_seconds, --.
    s.Finished as finished, --.
    split(s.`Recorded Date`, ' ')[0]::date as recorded_date, --.
    s.`Response ID` as response_id --.
    from survey_feedback s
  )
  , 
  survey as (
    select 
      case 
        when recipient_email = "NaN" then null else recipient_email end as recipient_email,
      case 
        when recipient_email = "NaN" then null else split(recipient_email, "@")[1] end as email_domain,
      case 
        when recipient_first_name = "NaN" then null else recipient_first_name end as recipient_first_name,
      case 
        when recipient_last_name = "NaN" then null else recipient_last_name end as recipient_last_name,
      -- worthwhile,
      int(satisfaction_score) as satisfaction_score,
      case when satisfaction_score >= 4 then 1 else 0 end as satisfaction_attractor,
      case when satisfaction_score < 4 then 1 else 0 end as satisfaction_detractor,
      int(relevant_score) as relevant_score,
      case when relevant_score >= 4 then 1 else 0 end as relevance_attractor,
      case when relevant_score < 4 then 1 else 0 end as relevance_detractor,
      int(insights_applicability) as insights_applicability,
      case when insights_applicability >= 4 then 1 else 0 end as insights_applicability_attractor,
      case when insights_applicability < 4 then 1 else 0 end as insights_applicability_detractor,
      -- recommend,
      -- case when recommend >= 9 then 1 else 0 end as recommend_attractor,
      -- case when recommend >= 7 and recommend < 9 then 1 else 0 end as recommend_neutral,
      -- case when recommend < 7 then 1 else 0 end as recommend_detractor,
      --case 
      -- when certification_prep = 1 then 1
      -- when certification_prep = 2 then 0
      -- when certification_prep = "NaN" then null 
      --end as certification_prep,
      --case 
        --when favorite_part = "NaN" then null else favorite_part end as favorite_part,
      --case 
        --when recommended_change = "NaN" then null else recommended_change end as recommended_change,
      --project_id,
      additional_comments,
      progress,
      duration_seconds,
      finished,
      recorded_date,
      response_id
    from survey_pre
  )

  select *
  from survey

''')

# COMMAND ----------

display(survey_clean_df)

# COMMAND ----------

# survey_clean_df.createOrReplaceTempView('survey_results_cleaned')

# COMMAND ----------

# survey_results_cleaned_df = spark.sql('''
#   with project_sessions as (
#   select 
#     project_id, 
#     fiscal_year_quarter, 
#     opportunity_name, 
#     opportunity_type, 
#     practice_name, 
#     project_class_format, 
#     project_delivery_format, 
#     project_end_fiscal_year_quarter, 
#     project_name, split(project_name, ' | ')[1] as session_code
#   from main.gtm_data.core_professional_services_dim_project
#   where snapshot_date = (select max(snapshot_date) from main.gtm_data.core_professional_services_dim_project)
#   )
#   , 
#   ilt_sessions as (
#     select 
#       id as session_id, 
#       code as session_code, 
#       course_id, 
#       session_name, 
#       instructor_emails, 
#       course_name, 
#       course_code, 
#       course_category_code
#     from main.it_training_silver.docebo_ilt_sessions
#     where processDate = (select max(processDate) from main.it_training_silver.docebo_ilt_sessions)
#   )

#   select 
#     s.*,
#     p.* except (project_id),
#     i.* except (session_code)
#   from survey_results_cleaned s
#   left join project_sessions p on s.project_id = p.project_id
#   left join ilt_sessions i on p.session_code = i.session_code
# ''')

# COMMAND ----------

# survey_grouped_df = spark.sql('''
#   with survey as (
#     select 
#       project_id, 
#       sum(worthwhile_attractor) as worthwhile_attractors,
#       sum(worthwhile_detractor) as worthwhile_detractors,
#       round(avg(worthwhile),2) as worthwhile_avg,
#       sum(instructor_effective_attractor) as instructor_effective_attractors,
#       sum(instructor_effective_detractor) as instructor_effective_detractors,
#       round(avg(instructor_effective),2) as instructor_effective_avg,
#       sum(expected_content_attractor) as expected_content_attractors,
#       sum(expected_content_detractor) as expected_content_detractors,
#       round(avg(expected_content),2) as expected_content_avg,
#       sum(recommend_attractor) as recommend_attractors,
#       sum(recommend_neutral) as recommend_neutrals,
#       sum(recommend_detractor) as recommend_detractors,
#       round(avg(recommend),2) as recommend_avg,
#       sum(certification_prep) as certification_prep,
#       count(*) as total_responses,
#       collect_set(favorite_part) as favorite_parts, 
#       collect_set(recommended_change) as recommended_changes
#     from survey_results_cleaned
#     where worthwhile <> 'NaN'
#     and instructor_effective <> 'NaN'
#     and expected_content <> 'NaN'
#     and recommend <> 'NaN'
#     group by 1 
#   )
#   ,
#   project_sessions as (
#   select 
#     project_id, 
#     fiscal_year_quarter, 
#     opportunity_name, 
#     opportunity_type, 
#     practice_name, 
#     project_class_format, 
#     project_delivery_format, 
#     project_end_fiscal_year_quarter, 
#     project_name, split(project_name, ' | ')[1] as session_code
#   from main.gtm_data.core_professional_services_dim_project
#   where snapshot_date = (select max(snapshot_date) from main.gtm_data.core_professional_services_dim_project)
#   )
#   , 
#   ilt_sessions as (
#     select 
#       id as session_id, 
#       code as session_code, 
#       course_id, 
#       session_name, 
#       instructor_emails, 
#       course_name, 
#       course_code, 
#       course_category_code
#     from main.it_training_silver.docebo_ilt_sessions
#     where processDate = (select max(processDate) from main.it_training_silver.docebo_ilt_sessions)
#   )
#   ,
#   milestones_pre as (
#     select 
#       m.class_format,
#       m.course,
#       m.provider,
#       m.milestone_name,
#       m.milestone_amount,
#       m.gaap_milestone_amount,
#       m.milestone_status,
#       m.is_milestone_approved,
#       m.include_milestone_in_financial,
#       m.billing_event_status,
#       m.project_id as milestone_project_id,
#       m.project_name as milestone_project_name,
#       m.project_region,
#       m.account_name,
#       m.billing_invoice_date
#     from main.gtm_data.core_professional_services_milestones m
#     where snapshot_date = (select max(snapshot_date) from main.gtm_data.core_professional_services_milestones)
#   )
#   ,
#   milestones as (
#     select 
#       milestone_project_id, 
#       sum(milestone_amount) as milestones_amount,
#       sum(gaap_milestone_amount) as gaap_milestones_amount,
#       collect_set(milestone_name) as milestone_names, 
#       collect_set(milestone_project_name) as milestone_project_names, 
#       collect_set(project_region) as project_regions,
#       collect_set(account_name) as account_names,
#       collect_set(billing_invoice_date) as billing_invoice_dates
#     from milestones_pre
#     group by 1
#     order by milestone_project_id
#   )
#   ,
#   session_enrollments as (
#     select 
#       session_id, 
#       count(distinct learner_user_id) as total_enrollments,
#       count(distinct case when status = 'completed' then learner_user_id end) as completed_enrollments
#     from main.it_training_silver.docebo_ilt_enrollments
#     where processDate = (select max(processDate) from main.it_training_silver.docebo_ilt_enrollments)
#     and status in ('completed', 'in_progress', 'subscribed')
#     group by session_id
#   )
#   , 
#   pre as (
#   select
#     s.*,
#     round(round(s.worthwhile_attractors/s.total_responses,2)*100,0) as worthwhile_attractors_percentage,
#     round(round(s.worthwhile_detractors/s.total_responses,2)*100,0) as worthwhile_detractors_percentage,
#     round(round(s.instructor_effective_attractors/s.total_responses,2)*100,0) as instructor_effective_attractors_percentage,
#     round(round(s.instructor_effective_detractors/s.total_responses,2)*100,0) as instructor_effective_detractors_percentage,
#     round(round(s.expected_content_attractors/s.total_responses,2)*100,0) as expected_content_attractors_percentage,
#     round(round(s.expected_content_detractors/s.total_responses,2)*100,0) as expected_content_detractors_percentage,
#     round(round(s.recommend_attractors/s.total_responses,2)*100,0) as recommend_attractors_percentage,
#     round(round(s.recommend_neutrals/s.total_responses,2)*100,0) as recommend_neutrals_percentage,
#     round(round(s.recommend_detractors/s.total_responses,2)*100,0) as recommend_detractors_percentage,
#     p.* except (project_id),
#     i.* except (session_code),
#     m.*, 
#     e.total_enrollments, 
#     e.completed_enrollments, 
#     round(round(total_responses / completed_enrollments, 2)*100,0) as response_rate

#   from survey s
#   left join project_sessions p on s.project_id = p.project_id
#   left join ilt_sessions i on p.session_code = i.session_code
#   left join milestones m on s.project_id = m.milestone_project_id
#   left join session_enrollments e on i.session_id = e.session_id
#   order by s.project_id
#   )

#   select *
#   from pre                              

# ''')

# COMMAND ----------

survey_results_cleaned_df_gold = add_gold_metadata(survey_clean_df)
# survey_grouped_df_gold = add_gold_metadata(survey_grouped_df)

# COMMAND ----------

print(partition_date)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = survey_results_cleaned_df_gold, 
  table_name = f'{focus_database_name}.investech_qualtrics_ilt_survey', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.field_learning_enablement.investech_qualtrics_ilt_survey
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.investech_qualtrics_ilt_survey)

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = survey_grouped_df_gold, 
#   table_name = f'{focus_database_name}.qualtrics_ilt_survey_summary', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'"
# )