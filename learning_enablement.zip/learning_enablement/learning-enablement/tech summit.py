# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Users/liam.clifford@databricks.com/Liam's Notebook - getMeetingInformation UDF"

# COMMAND ----------

# MAGIC %run "/Users/liam.clifford@databricks.com/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import json
import requests
from pprint import pprint
from urllib.parse import quote_plus as urlencode
import pandas as pd


warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

today = datetime.today()
one_year_ago = today - timedelta(days=365)
one_year_ago_formatted = one_year_ago.strftime('%Y-%m-%d')

investtech_hosts = [
  {
    'host': 'eric.waldron@databricks.com',
    'meeting_id': 'An2mlL08rW0z8QwBnJk5DBbyW_T2_Ty63fAfjZCLCvYVUNqByN1k~A7bb7Tne2ftO3V-v-eeWGk_-UWXfmOZJJ-5yGhUHJdHG1vqs2V-jdvnjgc2Iqnx-mmK-H8_n7UVLIayFg-JN-o-fFFn1OiydZ_wh4-eOpFUw',
    # 'from_date': '2023-01-03',
    'from_date': one_year_ago_formatted,
    'to_date': datetime.today().strftime('%Y-%m-%d'),
    'type': 'webinars'
  }
  # ,
  # {
  #   'host': 'miriam.cox@databricks.com',
  #   'meeting_id': '84990355981',
  #   'from_date': one_year_ago_formatted,
  #   # 'from_date': '2022-05-03', # from noelia/miriam
  #   # 'from_date': '2021-11-08', # from google cal
  #   'to_date': datetime.today().strftime('%Y-%m-%d'),
  #   'type': 'webinars'
  # }
]

# COMMAND ----------

meeting_details_dfs = []
meeting_participants_dfs = []

for host in investtech_hosts:
  getMeetingDetailsByMeetingIdV3(meeting_id=host['meeting_id'],type=host['type'],fromDate=host['from_date'],toDate=host['to_date'])

  meeting_details = spark.sql("""select * from meeting_details""")
  meeting_participants = spark.sql("""select * from meeting_participants""")

  meeting_details_dfs.append(meeting_details)
  meeting_participants_dfs.append(meeting_participants)

# COMMAND ----------

details_schema = T.StructType([
  T.StructField('uuid', T.StringType(), True),
  T.StructField('id', T.StringType(), True),
  T.StructField('host_id', T.StringType(), True),
  T.StructField('type', T.StringType(), True),
  T.StructField('topic', T.StringType(), True),
  T.StructField('user_name', T.StringType(), True),
  T.StructField('user_email', T.StringType(), True),
  T.StructField('start_time', T.StringType(), True),
  T.StructField('end_time', T.StringType(), True),
  T.StructField('duration', T.StringType(), True),
  T.StructField('total_minutes', T.StringType(), True),
  T.StructField('participants_count', T.StringType(), True),
  T.StructField('tracking_fields', T.StringType(), True),
  T.StructField('dept', T.StringType(), True),
  T.StructField('webinars', T.StringType(), True)
])

participants_schema = T.StructType([
  T.StructField('id', T.StringType(), True),
  T.StructField('user_id', T.StringType(), True),
  T.StructField('name', T.StringType(), True),
  T.StructField('user_email', T.StringType(), True),
  T.StructField('join_time', T.StringType(), True),
  T.StructField('leave_time', T.StringType(), True),
  T.StructField('duration', T.StringType(), True),
  T.StructField('attentiveness_score', T.StringType(), True),
  T.StructField('failover', T.StringType(), True),
  T.StructField('status', T.StringType(), True),
  T.StructField('customer_key', T.StringType(), True),
  T.StructField('participant_user_id', T.StringType(), True),
  T.StructField('uuid', T.StringType(), True),
])

# COMMAND ----------

meeting_details_df = sqlContext.createDataFrame([], details_schema)
meeting_participants_df = sqlContext.createDataFrame([], participants_schema)
for df in meeting_details_dfs:
  meeting_details_df = meeting_details_df.union(df)
    
for df in meeting_participants_dfs:
  meeting_participants_df = meeting_participants_df.unionByName(df, True)

# COMMAND ----------

meeting_details_df.createOrReplaceTempView('meeting_details')
meeting_participants_df.createOrReplaceTempView('meeting_participants')
# display(meeting_details_df)

# COMMAND ----------

# try:
#   sht = authGoogleSheet("INVESTech Scheduling")
# except:
#   print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')

  
# try:
#   worksheet = sht.worksheet("2024")
# except Exception as e: 
#   print('%s' % 'Worksheet Not Found: ')


# readGoogleSheet(
#  "INVESTech Scheduling",
#  "2024",
#  "investech_data",
#  clean_column_names="true", 
#  make_columns_unique="true"
# )

# investech_data_df = (spark.sql("""select * from investech_data"""))


# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC       name,
# MAGIC       code,*
# MAGIC     from main.it_training_silver.docebo_courses
# MAGIC     where processDate = (select max(processDate) from main.it_training_silver.docebo_courses)
# MAGIC     and category_code = 'FENG-INVESTech'

# COMMAND ----------

invest_df = spark.sql('''             
  with invest_events as ( 
    select 
      d.uuid,
      start_time,
      to_date(start_time, "yyyy-MM-dd'T'HH:mm:ss'Z'") as event_date,
      end_time,
      participants_count as registered,
      sum (case when nvl(p.id, "Unknown") != "Unknown" then 1 else 0 end) as attended
    from meeting_details d
    left join meeting_participants p on d.uuid=p.uuid
    where p.duration >= 1200
    group by 1,2,3,4,5
    order by start_time
  )
  ,
  invest_courses as (
    -- Need to add the new date string date from the new name nomenclature
    select 
      case 
        when (name ilike '%) INVESTech%' or name ilike '%): INVESTech%')
          then to_date(replace(replace(element_at(split(name, " "),1),'(',''), ')', ''), 'MM/dd/yy')
        when name = 'INVESTech: DATA + AI Enablement' 
          then to_date('06/21/2022', 'MM/dd/yy')
        when name ilike 'INVESTech %' or name ilike 'INVESTech: %'
          then to_date(date_format(to_date(substring(element_at(split(element_at(split(code, "-"),-1), 'IT'),-1), 1, 6), "MMddyy"), "MM/dd/yy"), "MM/dd/yy")
      end as event_date,
      -- to_date(replace(replace(element_at(split(name, " "),1),'(',''), ')', ''), 'MM/dd/yy') as event_date,
      name,
      code
    from main.it_training_silver.docebo_courses
    where processDate = (select max(processDate) from main.it_training_silver.docebo_courses)
    and category_code = 'FENG-INVESTech'
  )
  ,
  sp_invest_enrollment_dates as (
  select 
    *
  from main.field_learning_enablement.self_paced_enrollments
  where processDate = (select max(processDate) from main.field_learning_enablement.self_paced_enrollments)
  and category_code = 'FENG-INVESTech'
  -- and course_code ilike '%FENG-INVESTech%'
  and status = 'completed'
  order by enrolled_timestamp 
  )

  ,
  sp_invest as (
    select distinct
      course_name,
      course_code,
      count(learner_email_hash) as completed_sp
    from sp_invest_enrollment_dates
    group by 1,2
  )

  select 
    i.name as course_name,
    i.code as course_code,
    e.event_date,
    e.registered,
    e.attended,
    nvl(s.completed_sp,0) as completed_sp
  from invest_events e
  left join invest_courses i on e.event_date = i.event_date
  left join sp_invest s on i.code = s.course_code
  order by e.event_date desc
''')

# COMMAND ----------

invest_details_df = spark.sql('''     
  with sp_titles as (
    -- Need to add the course names and dates from the sheet and match them with the self_paced_enrollments table
      select distinct
      case 
        when (course_name ilike '%) INVESTech%' or course_name ilike '%): INVESTech%')
          then to_date(replace(replace(element_at(split(course_name, " "),1),'(',''), ')', ''), 'MM/dd/yy')
        when course_name = 'INVESTech: DATA + AI Enablement' 
          then to_date('06/21/2022', 'MM/dd/yy')
        when course_name ilike 'INVESTech %' or course_name ilike 'INVESTech: %'
          then to_date(date_format(to_date(substring(element_at(split(element_at(split(course_code, "-"),-1), 'IT'),-1), 1, 6), "MMddyy"), "MM/dd/yy"), "MM/dd/yy")
      end as event_date,
      --to_date(replace(replace(element_at(split(course_name, " "),1),'(',''), ')', ''), 'MM/dd/yy') as event_date,
      course_name
    from main.field_learning_enablement.self_paced_enrollments
    where processDate = (select max(processDate) from main.field_learning_enablement.self_paced_enrollments)
    and category_code = 'FENG-INVESTech'
  )
  ,
  ilt_event_dates as (
    select 
      to_date(start_time, "yyyy-MM-dd'T'HH:mm:ss'Z'") as event_date,
      *
    from meeting_details
  )         

  select 
    d.id,
    d.host_id,
    d.type,
    d.topic,
    d.user_name,
    d.user_email as host_email,
    d.start_time,
    d.end_time,
    d.duration as event_duration,
    d.total_minutes,
    d.participants_count,
    d.tracking_fields,
    d.dept,
    d.webinars,
    d.event_date,
    p.user_id,
    p.name,
    p.user_email,
    p.join_time,
    p.leave_time,
    p.duration,
    case when p.duration >= 1200 then 1 else 0 end as attended,
    case when p.duration >= 1200 then 'Completed' else 'Subscribed' end as status,
    p.attentiveness_score,
    p.failover,
    p.status as meeting_status,
    p.customer_key,
    p.participant_user_id,
    p.uuid,
    s.course_name,
    w.Manager,
    w.manager_hierarchy_path_name,
    w.Location_Address_Country,
    w.3rd_level_manager_name,
    w.2nd_level_manager_name,
    w.1st_level_manager_name,
    split(w.Location, '.')[0] as Region
  from ilt_event_dates d
  left join meeting_participants p on d.uuid=p.uuid
  left join sp_titles s on d.event_date=s.event_date
  left join main.field_learning_enablement.workday w on p.user_email = w.primaryWorkEmail
  and w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
''')

# COMMAND ----------

invest_details_df.createOrReplaceTempView('invest_ilt_details')

# COMMAND ----------

invest_all_enrollments = spark.sql('''
WITH ilt_enrollments AS (
    select 
      d.id as learner_user_id,
      i.user_email as learner_email, 
      i.course_name, -- Need to add the new date string date from the new name nomenclature
      c.id as course_id, 
      c.code as course_code, 
      'classroom' as course_type, 
      case when sum(i.attended) > 0 then 'completed' else 'subscribed' end as status,
      to_timestamp(min(i.join_time), "yyyy-MM-dd'T'HH:mm:ss'Z'") as enrolled_timestamp,
      to_timestamp(max(i.leave_time), "yyyy-MM-dd'T'HH:mm:ss'Z'") as completed_timestamp,
      sum(i.duration) as total_duration
    from invest_ilt_details  i 
    left join main.it_training_silver.docebo_courses c on i.course_name = c.name and c.processDate = (select max(processDate) from main.it_training_silver.docebo_courses) and c.category_code = 'FENG-INVESTech'
    left join main.field_learning_enablement.docebo_users d on i.user_email = d.email and d.processDate = (select max(processDate) from main.field_learning_enablement.docebo_users) and d.branch_code = 'DBK_EMP'
    group by learner_user_id, learner_email, course_name, course_id, course_code
),
sp_enrollments AS (
    select 
      s.learner_user_id,
      s.learner_email, 
      s.course_name, 
      s.course_id, 
      s.course_code, 
      s.course_type, 
      s.status,
      s.enrolled_timestamp, 
      s.completed_timestamp,
      d.expected_time_to_complete_in_seconds as total_duration
    from main.field_learning_enablement.self_paced_enrollments s
    left join main.it_training_silver.docebo_courses d on s.course_name = d.name
    and d.processDate = (select max(processDate) from main.it_training_silver.docebo_courses)
    and d.category_code = 'FENG-INVESTech'
    where s.processDate = (select max(processDate) from main.field_learning_enablement.self_paced_enrollments)
    and s.category_code = 'FENG-INVESTech'
),
all_enrollments AS (
    SELECT
        learner_user_id,
        learner_email,
        course_name,
        course_id,
        course_code,
        course_type,
        status,
        enrolled_timestamp,
        completed_timestamp,
        total_duration
    FROM sp_enrollments
    UNION ALL
    SELECT
        learner_user_id,
        learner_email,
        course_name,
        course_id,
        course_code,
        course_type,
        status,
        enrolled_timestamp,
        completed_timestamp,
        total_duration
    FROM ilt_enrollments
)
SELECT
    e.learner_user_id,
    e.learner_email,
    e.course_name,
    e.course_id,
    e.course_code,
    case when array_contains(collect_list(e.status), 'completed') then 'completed'
    when array_contains(collect_list(e.status), 'in_progress') then 'in_progress' 
    else 'subscribed' end as status,
    array_join(collect_list(e.course_type), ' + ') AS course_type,
    MIN(e.enrolled_timestamp) as enrolled_timestamp,
    MAX(e.completed_timestamp) as completed_timetamp,
    SUM(e.total_duration) AS total_duration, -- Sum total_durations for records with the same course_id
    w.Manager,
    w.manager_hierarchy_path_name,
    w.Location_Address_Country,
    w.3rd_level_manager_name,
    w.2nd_level_manager_name,
    w.1st_level_manager_name,
    split(w.Location, '\\.')[0] as Region
FROM all_enrollments e
left join main.field_learning_enablement.workday w on e.learner_email = w.primaryWorkEmail
and w.processDate = (select max(processDate) from main.field_learning_enablement.workday)
WHERE learner_user_id IS NOT NULL
GROUP BY learner_user_id, learner_email, course_name, course_id, course_code, Manager, manager_hierarchy_path_name, Location_Address_Country, Location, 3rd_level_manager_name, 2nd_level_manager_name, 1st_level_manager_name
ORDER BY learner_user_id, course_name
''')

# COMMAND ----------

invest_tech_gold = add_gold_metadata(invest_df)
invest_tech_details_gold = add_gold_metadata(invest_details_df)
invest_tech_all_enrollments_gold = add_gold_metadata(invest_all_enrollments)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = invest_tech_gold, 
  table_name = f'{focus_database_name}.invest_tech_summary', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = invest_tech_details_gold, 
  table_name = f'{focus_database_name}.invest_tech_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = invest_tech_all_enrollments_gold, 
  table_name = f'{focus_database_name}.invest_tech_all_enrollments', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)