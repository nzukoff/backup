# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

#SFDC Tables

# sfdc_latest_process_date = get_latest_partition_value(spark, "sfdc_prod.account",  "processDate")

# sfdc_accounts = (
#   spark.read.table("sfdc_prod.account")
#     .filter(F.col("processDate") == sfdc_latest_process_date)
# )

sfdc_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.account",  "processDate")

# sfdc_account_ultimate_parent_account_names = (
#   spark.read.table("main.sfdc_bronze.account")
#     .filter(F.col("processDate") == sfdc_latest_process_date)
#     .select(
#       F.col("Id").alias("Ultimate_parent_account_casesafe_ID__c"), 
#       F.col("Name").alias("Ultimate_Parent_Account__c")
#     )
# )

sfdc_latest_contact_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.contact",  "processDate")

sfdc_latest_lead_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.lead",  "processDate")

sfdc_accounts = (
  spark.read.table("main.sfdc_bronze.account")
    .filter(F.col("processDate") == sfdc_latest_process_date)
    # .join(sfdc_account_ultimate_parent_account_names, "Ultimate_parent_account_casesafe_ID__c", "left")
)

sfdc_contacts = (
  spark.read.table("main.sfdc_bronze.contact")
    .filter(F.col("processDate") == sfdc_latest_contact_process_date)
)

sfdc_leads = (
  spark.read.table("main.sfdc_bronze.lead")
    .filter(F.col("processDate") == sfdc_latest_lead_process_date)
)

region_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.countryregionmap__c",  "processDate")

countries_regions = (
  spark.read.table("main.sfdc_bronze.countryregionmap__c")
  .filter(F.col("processDate") == region_latest_process_date)
  .select(
    F.col("Name").alias("country_code"),
    F.col("Region__c").alias("region")
  )
)

# Accounts Curated

accounts_curated_snapshot_date = get_latest_partition_value(spark, "main.gtm_data.core_accounts_curated",  "snapshot_date")

accounts_curated = (
  spark.read.table("main.gtm_data.core_accounts_curated")
    .filter(F.col("snapshot_date") == accounts_curated_snapshot_date)
    .select("account_id", "business_unit")
)



# # Docebo Logfood data
silver_docebo_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_self_paced_enrollments",  "processDate")


account_status = (
  sfdc_accounts 
    .select(
      F.col("Id").alias("account_id"),
      F.col("Account_Status__c").alias("status")
    )
)

salesforce_account_email_domain_mapping = (
  spark.read.table("main.it_training_silver.docebo_salesforce_account_email_domain_mapping")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .filter(~F.col("account_name").isin('Individual LMS Account', 'Individual LMS Account(Generic)', 'Unmapped Workspaces - AMER', 'Unmapped Workspaces - EMEA'))
    .drop("processDate")
    .join(account_status, "account_id", "left")
)

docebo_users = (
  spark.read.table("main.it_training_silver.docebo_users")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

partner_domains_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.partner_domains_accounts",  "processDate")

partner_domains_df = (
  spark.read.table(f"{focus_database_name}.partner_domains_accounts")
    .filter(F.col("processDate") == partner_domains_latest_process_date)
    # .filter(F.col("email_domain") != "microsoft.com")
    .drop("processDate")
)

partner_domains = [domain["email_domain"] for domain in partner_domains_df.collect()]

partner_accounts = [domain["ultimate_parent_account_name"] for domain in partner_domains_df.collect()]

# Blacklisted domains

blacklist_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.blacklist_domains",  "processDate")

blacklist_domains = (
  # spark.read.table("user_success_dev.blacklist_domains")
  spark.read.table(f"{focus_database_name}.blacklist_domains")
    .filter(F.col("processDate") == blacklist_latest_process_date)
)

blacklist = [domain["blacklist_domain"] for domain in blacklist_domains.collect()]

historical_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.historical_learndot_enrollments_self_paced",  "processDate")

# # Learndot Historical ILT and Self Paced
# ld_ilt = (
#   spark.table("focus_dev.historical_learndot_enrollments_ilt")
#   .filter(F.col("processDate") == historical_latest_process_date)
#     .drop("processDate")
# )

# ld_self_paced = (
#   spark.table("focus_dev.historical_learndot_enrollments_self_paced")
#   .filter(F.col("processDate") == historical_latest_process_date)
#     .drop("processDate")
# )

# ld_latest_process_date = get_latest_partition_value(spark, "sfdc_ds.learndot__learndot_contact__c",  "processDate")

# ld_users = (
#   spark.table(f"sfdc_ds.learndot__learndot_contact__c")
#     .filter(F.col("processDate") == ld_latest_process_date)
#     .drop("processDate")
# )

# Partners (and Microsoft) were migrated from Learndot to Docebo on a different dates than other branches. We will need to filter enrollments based on branch and migration date

first_migration_branches = ["DBK_PRTNR", "DBK_MCSFT"]
first_migration_date = "2021-12-08"
second_migration_date = "2022-01-07"

databricks_account_id = "0016100001FyvmIAAR"
databricks_account_name = "Databricks"
databricks_parent_account_id = "0016100001FyvmIAAR"
databricks_parent_account_name = "Databricks"


microsoft_account_id = "00161000005eOdjAAE"
microsoft_account_name = "Microsoft"
microsoft_parent_account_id = "0014N00002BAYhLQAX"
microsoft_parent_account_name = "Microsoft Consulting Services"

# COMMAND ----------

#unit tests to make sure dfs are pulled correctly
assert unit_test_df_count(sfdc_accounts) > 0

# unit tests to make sure parameters are set up correctly
catalog, database = focus_database_name.split('.')
assert unit_test_valid_db(database, spark, catalog)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# Lead -> Mapped Account + Contact to Account Mapping
# Ignore the mapping for all contacts and leads that have domains that appear in Priyanka's sheet. 
# Create a domain to account repository using 1 and backing out blacklist domains. 
# Use this mapping to parse through unmapped learners
# For employee branch use branch for audience. Everything remains unchanged.
# For customer, microsoft, partner branch use top 5 domain rule. If domain mapped to partner account then "Partner" else "Customer or "Other" (mapped to an account with null account record type)
# If "Other" then update attribute to be Partner Other or Customer Other or MSFT Other based on branch
# For the remaining learners map to most common domain -> account pair. 

# COMMAND ----------

try:
  sht = authGoogleSheet("skills_at_scale_master_branch_code_list")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')
  
  
try:
  worksheet = sht.worksheet("Sheet1")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "skills_at_scale_master_branch_code_list",
 "Sheet1",
 "branch_codes",
 clean_column_names="true", 
 make_columns_unique="true"
)

# COMMAND ----------

# Load the branch codes table
branch_codes_df = spark.read.table("branch_codes").select("branch_codes").distinct()

# Collect the values into a Python list
branch_code_list = [row["branch_codes"] for row in branch_codes_df.collect()]

docebo_users_emails_pre = (  
  docebo_users 
    .withColumn('email_domain_pre', 
                F.when((F.col('email_domain').isin('databricks.com')) & (F.col('branch_code') == 'DBK_EMP'), F.col('email_domain'))
                .when(F.col('email_domain').isin(partner_domains), F.col('email_domain'))
                .when(F.col('alternate_email_domain').isin(partner_domains), F.col('alternate_email_domain'))
                .when((F.col('email_domain').isin(blacklist)) & (~F.col('alternate_email_domain').isin(blacklist)), F.col('alternate_email_domain'))
                .otherwise(F.col('email_domain')))
    .withColumn('learner_branch', 
            F.when(F.col('branch_name') == "Employee Academy", F.lit(("Databricks")))
            .when(F.col('branch_name') == "Customer Academy", F.lit(("Academy")))
            .when(F.col('branch_name').isin("Microsoft Academy", "Partner Academy"), F.lit(("Partner")))
            .otherwise(F.lit(None))
            )
)

docebo_users_emails = (
  docebo_users_emails_pre 
    .withColumn('email_domain_final', 
               F.coalesce(F.col("email_domain_pre"), F.lit("unknown")))
    .withColumn('audience_pre',
                F.when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBKS_ACDMY'), F.lit('Customer Other'))
                .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_PRTNR'), F.lit('Partner Other'))
                .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_EMP'), F.lit('Employee Other'))
                .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_MCSFT'), F.lit('Microsoft Other'))
                .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code').isin(branch_code_list)), F.lit('Customer'))
                .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_ATT'), F.lit('Partner Other'))
                .when((F.col('email_domain_final').isin(blacklist)) & ((F.col('branch_code').isNull()) | (F.col('branch_code') == "")), F.lit('Customer Other'))
                .when((F.col('email_domain_final')=='databricks.com') & ((F.col("branch_code") != "DBK_EMP") | (F.col("branch_code").isNull())), F.lit('Customer Other'))
                )
)


docebo_users_emails_customers_domains = (
  docebo_users_emails
    .filter(~F.col("email_domain_final").isin(partner_domains))
    .filter(~F.col("email_domain_final").isin(['microsoft.com', 'databricks.com']))
    .filter(~F.col("email_domain_final").isin(blacklist) | (F.col("branch_code").isin(branch_code_list)))
)

docebo_users_emails_customers_blacklist = (
  docebo_users_emails
    .filter(F.col("audience_pre") == "Customer Other")
    
)

docebo_users_emails_customers_users = (
  docebo_users_emails_customers_domains
    .union(docebo_users_emails_customers_blacklist)
    .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Customer')).otherwise(F.col('audience_pre')))
)

docebo_users_emails_partners_domains = (
  docebo_users_emails
  .filter(F.col("email_domain_final").isin(partner_domains))
  .filter(~F.col("email_domain_final").isin(blacklist))
)

docebo_users_emails_partners_blacklist = (
  docebo_users_emails
    .filter(F.col("audience_pre") == "Partner Other")
)

docebo_users_emails_partners_users = (
  docebo_users_emails_partners_domains
    .union(docebo_users_emails_partners_blacklist)
    .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Partner')).otherwise(F.col('audience_pre')))
)

docebo_users_emails_microsoft_domains = (
  docebo_users_emails
    .filter(F.col("email_domain_final") == "microsoft.com")
    .filter(~F.col("email_domain_final").isin(blacklist))
)

docebo_users_emails_microsoft_blacklist = (
  docebo_users_emails
    .filter(F.col("audience_pre") == "Microsoft Other")
)

docebo_users_emails_microsoft_users = (
  docebo_users_emails_microsoft_domains
    .union(docebo_users_emails_microsoft_blacklist)
    .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Microsoft')).otherwise(F.col('audience_pre')))
)

docebo_users_emails_databricks_domains = (
  docebo_users_emails
    .filter(F.col("email_domain_final") == "databricks.com")
    .filter(~F.col("email_domain_final").isin(blacklist))
    .filter(F.col("branch_code") == "DBK_EMP")
)



docebo_users_emails_databricks_blacklist = (
  docebo_users_emails
    .filter(F.col("audience_pre") == "Employee Other")
)

docebo_users_emails_databricks_users = (
  docebo_users_emails_databricks_domains
    .union(docebo_users_emails_databricks_blacklist)
    .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Employee')).otherwise(F.col('audience_pre')))
)

# COMMAND ----------

contact_dedupe_window = W.Window.partitionBy("Email").orderBy(F.desc("LastModifiedDate"), "tiebreak")
lead_dedupe_window = W.Window.partitionBy("Email").orderBy(F.desc("LastModifiedDate"), "tiebreak")
lead_contact_dedupe_window = W.Window.partitionBy("Email").orderBy(F.desc("account_id"),F.desc("LastModifiedDate"), "tiebreak")

sfdc_contact_dedupe = (
  sfdc_contacts
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(contact_dedupe_window))
    .filter(F.col("rank") == "1")
    .drop("tiebreak", "rank")
    .select(F.col("Email").alias('email'), F.col("Id").alias('sfdc_contact_id'), F.col("AccountId").alias('account_id'), F.col('LastModifiedDate'))
    .withColumn('sfdc_contact_type', F.lit('contact'))
    # ContactID_CaseSafe__c
)

sfdc_lead_dedupe = (
  sfdc_leads
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(lead_dedupe_window))
    .filter(F.col("rank") == "1")
    .drop("tiebreak", "rank")
    # .select(F.col("Email").alias('email'), F.col("Matched_SF_Account__c").alias('account_id'), F.col('LastModifiedDate'))
    .select(F.col("Email").alias('email'), F.col("Id").alias('sfdc_contact_id'), F.col("LeanData__Reporting_Matched_Account__c").alias('account_id'), F.col('LastModifiedDate'))
    .withColumn('sfdc_contact_type', F.lit('lead'))
)

sfdc_lead_contact_dedupe = (
  sfdc_contact_dedupe
    .union(sfdc_lead_dedupe)
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(lead_contact_dedupe_window))
    .filter(F.col("rank") == "1")
    .drop("tiebreak", "rank")
)

sfdc_lead_contact = (
  sfdc_lead_contact_dedupe
    .withColumn('email_hash', F.sha2(F.col('email'), 256))
    .select('email_hash', 'account_id', 'sfdc_contact_id', 'sfdc_contact_type')
)


# COMMAND ----------

# customers

account_names = (
  sfdc_accounts
    .select(F.col("Id").alias('account_id'), F.col("Name").alias('account_name_pre'), F.col("Account_Record_Type_Name__c").alias("record_type"))
    .filter((F.col("Account_Record_Type_Name__c") == "Account") | (F.col("Account_Record_Type_Name__c").isNull()))
    .filter(~F.col("Name").isin(partner_accounts))
    .filter(~F.col("Name").isin(["Unknown", "Generic Account", "Self", "Generic/Public Business Subscription Account", "None", "-", "Self Incorporated", "Databricks K.K. (データブリックス・ジャパン株式会社)"]))
    .filter(~F.col("Name").like("%Individual LMS Account%"))
)


docebo_users_emails_account_ids_customers = (
  docebo_users_emails_customers_users
    .join(sfdc_lead_contact, "email_hash", "left")
)

docebo_users_emails_account_names_customers_email_join = (
  docebo_users_emails_account_ids_customers
    .join(account_names, "account_id", "left")
    .withColumn('account_name', F.coalesce(F.col("account_name_pre"), F.lit("Unknown")))
)


docebo_users_emails_account_ids_customers_alt_email_join = (
  docebo_users_emails_account_names_customers_email_join
    .filter(F.col("account_name") == "Unknown")
    .drop('account_id', 'account_name', 'account_name_pre', 'record_type')
    .join(sfdc_lead_contact.withColumnRenamed('email_hash', 'alternate_email_hash'), "alternate_email_hash", "left")
)

docebo_users_emails_account_names_customers_alt_email_join = (
  docebo_users_emails_account_ids_customers_alt_email_join
    .join(account_names, "account_id", "left")
    .withColumn('account_name', F.coalesce(F.col("account_name_pre"), F.lit("Unknown")))
)

docebo_users_emails_account_names_customers = (
  docebo_users_emails_account_names_customers_email_join
    .filter(F.col("account_name") != "Unknown")
    .select('account_id',
            'email',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'learner_branch', 
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'email_domain_pre',
            'email_domain_final',
            'audience_pre',
            'account_name_pre',
            'record_type',
            'account_name',
            'audience')
    .union(docebo_users_emails_account_names_customers_alt_email_join.select('account_id',
            'email',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'learner_branch', 
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'email_domain_pre',
            'email_domain_final',
            'audience_pre',
            'account_name_pre',
            'record_type',
            'account_name',
            'audience'))
)




docebo_users_emails_account_names_customers_account_found = (
  docebo_users_emails_account_names_customers
    .filter(F.col("account_name") != "Unknown")
    .select(
      'account_id',
            'email',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'learner_branch', 
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'email_domain_pre',
            'email_domain_final',
            'audience_pre',
            'account_name_pre',
            'record_type',
            'account_name',
            'audience')
)

docebo_users_emails_account_names_customers_account_found_bu = (
  docebo_users_emails_account_names_customers_account_found
  .join(accounts_curated, 'account_id', 'left')
  .filter(F.col("business_unit").isNotNull())
  .drop('business_unit')
)

docebo_users_emails_account_names_customers_account_found_no_bu = (
  docebo_users_emails_account_names_customers_account_found
  .join(accounts_curated, 'account_id', 'left')
  .filter(F.col("business_unit").isNull())
  .withColumnRenamed('account_name', 'account_name_pre_2')
  .withColumn('account_name', F.lit("Unknown"))
  .drop('business_unit', 'account_name_pre_2')
  .select('account_id',
            'email',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'learner_branch', 
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'email_domain_pre',
            'email_domain_final',
            'audience_pre',
            'account_name_pre',
            'record_type',
            'account_name',
            'audience')
)

domain_window = W.Window.partitionBy("email_domain_final").orderBy(F.desc("total_emails"), "tiebreak")

customer_account_mapping = (
  docebo_users_emails_account_names_customers_account_found
    .select('account_id', 'account_name', "email_domain_final", 'email_domain', 'alternate_email_domain')
    .filter(~F.col("email_domain_final").isin(blacklist))
    .groupBy(['account_id', "account_name", "email_domain_final"]).agg(F.count(F.col('email_domain')).alias('total_emails'))
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(domain_window))
    .filter(F.col("rank") == 1)
    .drop("total_emails", "tiebreak", "rank")
    
)

docebo_users_emails_account_names_customers_no_account_no_bu = (
  docebo_users_emails_account_names_customers
    .filter(F.col("account_name") == "Unknown")
    .union(docebo_users_emails_account_names_customers_account_found_no_bu)
)

docebo_users_emails_account_names_customers_account_not_found = (
  docebo_users_emails_account_names_customers_no_account_no_bu
    .drop('account_id')
    .withColumnRenamed('account_name', 'account_name_pre_2')
    .join(customer_account_mapping, 'email_domain_final', 'left')
    .withColumn('account_name', F.coalesce(F.col("account_name"), F.col("account_name_pre_2")))
    .select('account_id',
            'email',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'learner_branch', 
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'email_domain_pre',
            'email_domain_final',
            'audience_pre',
            'account_name_pre',
            'record_type',
            'account_name',
            'audience')
)

mapping_window = W.Window.partitionBy("email_domain").orderBy(F.desc("total_emails"), "tiebreak")

mapping_more_than_5_domains = (
 salesforce_account_email_domain_mapping
    # remove any accounts without email domains
    .filter(F.col("email_domain").isNotNull())
    .filter(~F.col("email_domain").isin(blacklist))
    # keep domains that appear more than 5 times 
    .filter(F.col("total_for_email_and_account") >= 5)
    # rank to find most common email domain per account
    .groupBy(["email_domain", "account_id", "account_name"])
    .agg(F.sum("total_for_email_and_account").alias("total_emails"))
    # rank to find most common domain for each account
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(mapping_window))
    .filter(F.col("rank") == 1)
    .drop("total_emails", "tiebreak", "rank")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
    )
)

docebo_users_emails_account_names_customers_account_found_1 = (
    docebo_users_emails_account_names_customers_account_not_found
    .filter(F.col("account_name") != "Unknown")
)

docebo_users_emails_account_names_customers_remap_1 = (
  docebo_users_emails_account_names_customers_account_not_found
    .filter(F.col("account_name") == "Unknown")
    .drop('account_id')
    .withColumnRenamed('account_name', 'account_name_pre_2')
    .join(mapping_more_than_5_domains, 'email_domain_final', 'left')
    .withColumn('account_name', F.coalesce(F.col("account_name"), F.col("account_name_pre_2")))
    .select('account_id',
            'email',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'learner_branch', 
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'email_domain_pre',
            'email_domain_final',
            'audience_pre',
            'account_name_pre',
            'record_type',
            'account_name',
            'audience')

)

docebo_users_emails_account_names_customers_account_found_2 = (
  docebo_users_emails_account_names_customers_remap_1
    .filter(F.col("account_name") != "Unknown")
)

mapping_most_common_domains = (
 salesforce_account_email_domain_mapping
    # remove any accounts without email domains
    .filter(F.col("email_domain").isNotNull())
    .filter(~F.col("email_domain").isin(blacklist))
    # rank to find most common email domain per account
    .groupBy(["email_domain", "account_id", "account_name"])
    .agg(F.sum("total_for_email_and_account").alias("total_emails"))
    # rank to find most common domain for each account
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(mapping_window))
    .filter(F.col("rank") == 1)
    .drop("total_emails", "tiebreak", "rank")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
    )
)

docebo_users_emails_account_names_customers_remap_2 = (
  docebo_users_emails_account_names_customers_remap_1
    .filter(F.col("account_name") == "Unknown")
    .drop('account_id')
    .withColumnRenamed('account_name', 'account_name_pre_2')
    .join(mapping_most_common_domains, 'email_domain_final', 'left')
    .withColumn('account_name', F.coalesce(F.col("account_name"), F.col("account_name_pre_2")))
    .select('account_id',
            'email',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'learner_branch', 
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'email_domain_pre',
            'email_domain_final',
            'audience_pre',
            'account_name_pre',
            'record_type',
            'account_name',
            'audience')
)


docebo_users_emails_account_names_customers_accounts = (
  docebo_users_emails_account_names_customers_account_found_bu.withColumn('match_method', F.lit('direct_salesforce_contact_match'))
  .union(docebo_users_emails_account_names_customers_account_found_1.withColumn('match_method', F.lit('matched_contacts_domain_account_mapping')))
  .union(docebo_users_emails_account_names_customers_account_found_2.withColumn('match_method', F.lit('more_than_5_domains_on_account')))
  .union(docebo_users_emails_account_names_customers_remap_2.withColumn('match_method', F.lit('most_common_domain_on_account')))
  
)


account_ultimate_parents = (
  sfdc_accounts
    .select(
      F.col("Id").alias('account_id'), 
      F.col("Ultimate_Parent_Account__c").alias('ultimate_parent_account_name_pre'), 
      F.col("Ultimate_parent_account_casesafe_ID__c").alias("ultimate_parent_account_id_pre")
    )
)
  

docebo_users_emails_customers = (
  docebo_users_emails_account_names_customers_accounts
    .join(account_ultimate_parents, "account_id", "left")
    .withColumn('ultimate_parent_account_name', 
                F.when(F.col("account_name") != "Unknown", F.col("ultimate_parent_account_name_pre")).otherwise(F.lit("Unknown"))
                )
    .withColumn('ultimate_parent_account_id', 
                F.when(F.col("account_name") != "Unknown", F.col("ultimate_parent_account_id_pre")).otherwise(F.lit("Unknown"))
                )
    .select('email_domain_final',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'email',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'learner_branch',
            'account_id',
            'account_name',
            'ultimate_parent_account_id',
            'ultimate_parent_account_name',
            'audience',
            'match_method')
)



# display(
#   docebo_users_emails_customers
#     .withColumn('account_found', F.when(F.col('account_name') == "Unknown", F.lit(0)).otherwise(F.lit(1)))
#     .groupBy("account_found")
#     .count()
#     .orderBy(F.desc("count"))
# )

# display(
#   docebo_users_emails_customers
#     .select(
#       'email',
#       'email_domain_final',
#       'account_id',
#       'account_name',
#       'ultimate_parent_account_id',
#       'ultimate_parent_account_name'
#     )
# )



# COMMAND ----------

# partners


account_ultimate_parents = (
  sfdc_accounts
    .select(
      F.col("Id").alias('account_id'), 
      F.col("Ultimate_Parent_Account__c").alias('ultimate_parent_account_name_pre'), 
      F.col("Ultimate_parent_account_casesafe_ID__c").alias("ultimate_parent_account_id_pre")
    )
)

docebo_users_emails_partner = (
  docebo_users_emails_partners_users
    .join(partner_domains_df.withColumnRenamed('email_domain', 'email_domain_final'), "email_domain_final", "left")
    .withColumnRenamed('ultimate_parent_account_id', 'ultimate_parent_account_id_pre')
    .withColumnRenamed('ultimate_parent_account_name', 'ultimate_parent_account_name_pre')
    .withColumn('ultimate_parent_account_id',  F.coalesce(F.col("ultimate_parent_account_id_pre"), F.lit("Unknown")))
    .withColumn('ultimate_parent_account_name',  F.coalesce(F.col("ultimate_parent_account_name_pre"), F.lit("Unknown")))
    .withColumn('account_id',  F.col("ultimate_parent_account_id"))
    .withColumn('account_name',  F.col("ultimate_parent_account_name"))
    .withColumn('match_method', F.lit('partner_ops_report'))
    .select('email_domain_final',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'email',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'learner_branch',
            'account_id',
            'account_name',
            'ultimate_parent_account_id',
            'ultimate_parent_account_name',
            'audience',
            'match_method')
)

# display(
#   docebo_users_emails_partner
#     .select('email', 'email_domain_final', 'account_name', 'ultimate_parent_account_name')
# )

# display(
#   docebo_users_emails_partner
#     .withColumn('account_found', F.when(F.col('ultimate_parent_account_name') == "Unknown", F.lit(0)).otherwise(F.lit(1)))
#     .groupBy("account_found")
#     .count()
#     .orderBy(F.desc("count"))
# )


# COMMAND ----------

# unique mappings databricks and microsoft

account_window = W.Window.partitionBy("account_name").orderBy(F.desc("total_for_email_and_account"), "tiebreak")
domain_window = W.Window.partitionBy("email_domain").orderBy(F.desc("total_emails"), "tiebreak")
# domain_window = W.Window.partitionBy("email_domain").orderBy(F.asc("rank"), "tiebreak")


accounts_df = (
  sfdc_accounts
    .select(
      F.col("Id").alias("ultimate_parent_account_id"),
      F.col("Name").alias("ultimate_parent_account_name")
    )
)

account_names = (
  sfdc_accounts
    .select(
      F.col("Id").alias("account_id"),
      F.col("Name").alias("account_name"),
      F.col("ParentId").alias("ultimate_parent_account_id")
    )
    .join(accounts_df, "ultimate_parent_account_id", "left")
)

mapping_2_databricks = (
  salesforce_account_email_domain_mapping  
    # filter for databricks id
    .filter(F.col("account_id") == databricks_account_id)
    .filter(F.col("email_domain") == "databricks.com")
    # find most recent 
    .orderBy(F.col("account_last_modified_timestamp").desc())
    .limit(1)
    .select("email_domain", "account_id")
    .join(account_names, "account_id", "left")
    .withColumnRenamed('ultimate_parent_account_id', 'ultimate_parent_account_id_pre')
    .withColumnRenamed('ultimate_parent_account_name', 'ultimate_parent_account_name_pre')
    .withColumn('ultimate_parent_account_id', F.col('account_id'))
    .withColumn('ultimate_parent_account_name', F.col('account_name'))
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

mapping_2_microsoft = (
  salesforce_account_email_domain_mapping  
    # filter for databricks id
    .filter(F.col("account_id") == microsoft_account_id)
    .filter(F.col("email_domain") == "microsoft.com")
    # find most recent 
    .orderBy(F.col("account_last_modified_timestamp").desc())
    .limit(1)
    .select("email_domain", "account_id")
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)


# COMMAND ----------

# databricks 

docebo_users_emails_databricks = (
   docebo_users_emails_databricks_users
    .join(mapping_2_databricks, "email_domain_final", "left")
    .withColumn('match_method', F.lit('hard_code_databricks'))
    .select('email_domain_final',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'email',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'learner_branch',
            'account_id',
            'account_name',
            'ultimate_parent_account_id',
            'ultimate_parent_account_name',
            'audience',
            'match_method')
)

# display(
#   docebo_users_emails_databricks
    
# )

# COMMAND ----------

# microsoft 

docebo_users_emails_microsoft = (
   docebo_users_emails_microsoft_users
    .join(mapping_2_microsoft, "email_domain_final", "left")
    .withColumn('match_method', F.lit('hard_code_microsoft'))
    .select('email_domain_final',
            'id',
            'uuid',
            'username_hash',
            'email_domain',
            'email_hash',
            'valid',
            'created_timestamp',
            'suspended_timestamp',
            'last_login',
            'email_verified',
            'last_updated_timestamp',
            'branch_name',
            'alternate_email_domain',
            'level',
            'alternate_email_hash',
            'branch_code',
            'timezone',
            'username',
            'email',
            'first_name',
            'last_name',
            'alternate_email',
            'accepted_t_and_c',
            'accepted_t_and_c_timestamp',
            't_and_c_version_id',
            'country_code',
            'country_name',
            'alternate_email_2',
            'alternate_email_2_domain',
            'alternate_email_2_hash',
            'learner_branch',
            'account_id',
            'account_name',
            'ultimate_parent_account_id',
            'ultimate_parent_account_name',
            'audience',
            'match_method')
)

# display(
#   docebo_users_emails_microsoft
    
# )

# COMMAND ----------

docebo_users_emails_customers_clean = (
  docebo_users_emails_customers
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when(F.col("account_name") == "Unknown", F.lit("Customer Other"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Customer Other"), F.lit("Customer"))
                .otherwise(F.col("audience_pre")))
    .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
)

docebo_users_emails_partner_clean = (
  docebo_users_emails_partner
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when(F.col("account_name") == "Unknown", F.lit("Partner Other"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Partner Other"), F.lit("Partner"))
                .otherwise(F.col("audience_pre")))
    .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
)

docebo_users_emails_databricks_clean = (
  docebo_users_emails_databricks
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when(F.col("account_name") == "Unknown", F.lit("Employee Other"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Employee Other"), F.lit("Employee"))
                .otherwise(F.col("audience_pre")))
    .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
)

docebo_users_emails_microsoft_clean = (
  docebo_users_emails_microsoft
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit(microsoft_account_id)).otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit(microsoft_account_name)).otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit(microsoft_parent_account_id)).otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit(microsoft_parent_account_name)).otherwise(F.col("ultimate_parent_account_name_pre")))
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when(F.col("account_name") == "Unknown", F.lit("Microsoft Other"))
                .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Microsoft Other"), F.lit("Microsoft"))
                .otherwise(F.col("audience_pre")))
    .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
)

# COMMAND ----------

docebo_users_accounts = (
  docebo_users_emails_customers_clean
    .union(docebo_users_emails_partner_clean)
    .union(docebo_users_emails_databricks_clean)
    .union(docebo_users_emails_microsoft_clean)
)

docebo_users_accounts = (
  docebo_users_accounts
    .select(
      "email_domain_final",
      "id",
      "uuid",
      "username_hash",
      "email_domain",
      "email_hash",
      "valid",
      "created_timestamp",
      "suspended_timestamp",
      "last_login",
      "email_verified",
      "last_updated_timestamp",
      "branch_name",
      "alternate_email_domain",
      "level",
      "alternate_email_hash",
      "branch_code",
      "timezone",
      "username",
      "email",
      "first_name",
      "last_name",
      "alternate_email",
      "accepted_t_and_c",
      "accepted_t_and_c_timestamp",
      "t_and_c_version_id",
      "country_code",
      "country_name",
      "alternate_email_2",
      "alternate_email_2_domain",
      "alternate_email_2_hash",
      "learner_branch",
      "match_method",
      "account_id",
      "account_name",
      "ultimate_parent_account_id",
      "ultimate_parent_account_name",
      "audience"
    ).distinct()
)

#assert unit_test_df_count(docebo_users) == unit_test_df_count(docebo_users_accounts)

# COMMAND ----------

docebo_users_accounts_audience = (
  docebo_users_accounts
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when((F.col("audience_pre") == "Customer Other") & (F.col("branch_code") == "DBK_PRTNR"), F.lit("Partner Other"))
                .when((F.col("audience_pre") == "Customer Other") & (F.col("branch_code") == "DBK_EMP"), F.lit("Employee Other"))
                .when((F.col("audience_pre") == "Customer Other") & (F.col("branch_code") == "DBK_MCSFT"), F.lit("Microsoft Other"))
                .otherwise(F.col("audience_pre")))
    .drop("audience_pre")
)

# COMMAND ----------

# from pyspark.sql import functions as F
# from pyspark.sql import Window as W

# def process_docebo_user_accounts(
#     docebo_users,
#     sfdc_contacts,
#     sfdc_leads,
#     sfdc_accounts,
#     partner_domains_df,
#     salesforce_account_email_domain_mapping,
#     accounts_curated,
#     partner_domains,
#     blacklist,
#     databricks_account_id,
#     microsoft_account_id,
#     microsoft_account_name,
#     microsoft_parent_account_id,
#     microsoft_parent_account_name,
#     partner_accounts
# ):
#     """
#     Processes Docebo user data by enriching it with Salesforce account information,
#     deduplicating contacts/leads, and categorizing users into different audiences
#     (Customer, Partner, Employee, Microsoft).

#     Args:
#         docebo_users (DataFrame): Initial DataFrame containing Docebo user data.
#         sfdc_contacts (DataFrame): Salesforce contacts DataFrame.
#         sfdc_leads (DataFrame): Salesforce leads DataFrame.
#         sfdc_accounts (DataFrame): Salesforce accounts DataFrame.
#         partner_domains_df (DataFrame): DataFrame containing partner email domains.
#         salesforce_account_email_domain_mapping (DataFrame): Mapping of Salesforce
#                                                               accounts to email domains.
#         accounts_curated (DataFrame): Curated accounts DataFrame, likely containing
#                                       business unit information.
#         partner_domains (list): List of partner email domains.
#         blacklist (list): List of blacklisted email domains.
#         databricks_account_id (str): Account ID for Databricks.
#         microsoft_account_id (str): Account ID for Microsoft.
#         microsoft_account_name (str): Account name for Microsoft.
#         microsoft_parent_account_id (str): Parent account ID for Microsoft.
#         microsoft_parent_account_name (str): Parent account name for Microsoft.
#         partner_accounts (list): List of partner account names to filter out.

#     Returns:
#         DataFrame: A cleaned and enriched DataFrame of Docebo users with associated
#                    account and audience information.
#     """

#     # --- PAGE 1: Initial email domain and learner branch processing ---
#     docebo_users_emails_pre = (
#         docebo_users
#         .withColumn('email_domain_pre',
#                     F.when((F.col('email_domain').isin('databricks.com')) & (F.col('branch_code') == 'DBK_EMP'), F.col('email_domain'))
#                     .when(F.col('email_domain').isin(partner_domains), F.col('email_domain'))
#                     .when(F.col('alternate_email_domain').isin(partner_domains), F.col('alternate_email_domain'))
#                     .when((F.col('email_domain').isin(blacklist)) & (~F.col('alternate_email_domain').isin(blacklist)), F.col('alternate_email_domain'))
#                     .otherwise(F.col('email_domain')))
#         .withColumn('learner_branch',
#                     F.when(F.col('branch_name') == "Employee Academy", F.lit("Databricks"))
#                     .when(F.col('branch_name') == "Customer Academy", F.lit("Academy"))
#                     .when(F.col('branch_name').isin("Microsoft Academy", "Partner Academy"), F.lit("Partner"))
#                     .otherwise(F.lit(None))) # Added .otherwise(F.lit(None)) for completeness
#     )

#     docebo_users_emails = (
#         docebo_users_emails_pre
#         .withColumn('email_domain_final', F.coalesce(F.col("email_domain_pre"), F.lit("unknown")))
#         .withColumn('audience_pre',
#                     F.when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBKS_ACDMY'), F.lit('Customer Other'))
#                     .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_PRTNR'), F.lit('Partner Other'))
#                     .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_EMP'), F.lit('Employee Other'))
#                     .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_MCSFT'), F.lit('Microsoft Other'))
#                     .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_ADA'), F.lit('Customer'))
#                     .when((F.col('email_domain_final').isin(blacklist)) & (F.col('branch_code') == 'DBK_ATT'), F.lit('Partner Other'))
#                     .when((F.col('email_domain_final').isin(blacklist)) & ((F.col('branch_code').isNull()) | (F.col('branch_code') == "")), F.lit('Customer Other'))
#                     .when((F.col('email_domain_final') == 'databricks.com') & ((F.col("branch_code") != "DBK_EMP") | (F.col("branch_code").isNull())), F.lit('Customer Other'))
#                     .otherwise(F.lit(None))) # Added .otherwise(F.lit(None)) for completeness
#     )

#     # --- PAGE 2: Filtering and unioning for different user segments (Customers, Partners, Microsoft, Databricks) ---
#     docebo_users_emails_customers_domains = (
#         docebo_users_emails
#         .filter(~F.col("email_domain_final").isin(partner_domains))
#         .filter(~F.col("email_domain_final").isin(['microsoft.com', 'databricks.com']))
#         .filter(~F.col("email_domain_final").isin(blacklist) | (F.col("branch_code") == "DBK_ADA"))
#     )

#     docebo_users_emails_customers_blacklist = (
#         docebo_users_emails
#         .filter(F.col("audience_pre") == "Customer Other")
#     )

#     docebo_users_emails_customers_users = (
#         docebo_users_emails_customers_domains
#         .union(docebo_users_emails_customers_blacklist)
#         .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Customer')).otherwise(F.col('audience_pre')))
#     )

#     docebo_users_emails_partners_domains = (
#         docebo_users_emails
#         .filter(F.col("email_domain_final").isin(partner_domains))
#         .filter(~F.col("email_domain_final").isin(blacklist))
#     )

#     docebo_users_emails_partners_blacklist = (
#         docebo_users_emails
#         .filter(F.col("audience_pre") == "Partner Other")
#     )

#     docebo_users_emails_partners_users = (
#         docebo_users_emails_partners_domains
#         .union(docebo_users_emails_partners_blacklist)
#         .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Partner')).otherwise(F.col('audience_pre')))
#     )

#     docebo_users_emails_microsoft_domains = (
#         docebo_users_emails
#         .filter(F.col("email_domain_final") == "microsoft.com")
#         .filter(~F.col("email_domain_final").isin(blacklist))
#     )

#     # --- PAGE 3: Microsoft and Databricks specific user filtering ---
#     docebo_users_emails_microsoft_blacklist = (
#         docebo_users_emails
#         .filter(F.col("audience_pre") == "Microsoft Other")
#     )

#     docebo_users_emails_microsoft_users = (
#         docebo_users_emails_microsoft_domains
#         .union(docebo_users_emails_microsoft_blacklist)
#         .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Microsoft')).otherwise(F.col('audience_pre')))
#     )

#     docebo_users_emails_databricks_domains = (
#         docebo_users_emails
#         .filter(F.col("email_domain_final") == "databricks.com")
#         .filter(~F.col("email_domain_final").isin(blacklist))
#         .filter(F.col("branch_code") == "DBK_EMP")
#     )

#     docebo_users_emails_databricks_blacklist = (
#         docebo_users_emails
#         .filter(F.col("audience_pre") == "Employee Other")
#     )

#     docebo_users_emails_databricks_users = (
#         docebo_users_emails_databricks_domains
#         .union(docebo_users_emails_databricks_blacklist)
#         .withColumn("audience", F.when(F.col('audience_pre').isNull(), F.lit('Employee')).otherwise(F.col('audience_pre')))
#     )

#     # --- PAGE 4: SFDC Contact and Lead Deduplication ---
#     contact_dedupe_window = W.partitionBy("Email").orderBy(F.desc("LastModifiedDate"), "tiebreak")
#     lead_dedupe_window = W.partitionBy("Email").orderBy(F.desc("LastModifiedDate"), "tiebreak")
#     lead_contact_dedupe_window = W.partitionBy("Email").orderBy(F.desc("account_id"), F.desc("LastModifiedDate"), "tiebreak")

#     sfdc_contact_dedupe = (
#         sfdc_contacts
#         .withColumn("tiebreak", F.monotonically_increasing_id())
#         .withColumn("rank", F.rank().over(contact_dedupe_window))
#         .filter(F.col("rank") == "1")
#         .drop("tiebreak", "rank")
#         .select(F.col("Email").alias('email'), F.col("Id").alias('sfdc_contact_id'), F.col("AccountId").alias('account_id'), F.col('LastModifiedDate'))
#         .withColumn('sfdc_contact_type', F.lit('contact'))
#     )

#     sfdc_lead_dedupe = (
#         sfdc_leads
#         .withColumn("tiebreak", F.monotonically_increasing_id())
#         .withColumn("rank", F.rank().over(lead_dedupe_window))
#         .filter(F.col("rank") == "1")
#         .drop("tiebreak", "rank")
#         .select(F.col("Email").alias('email'), F.col("Id").alias('sfdc_contact_id'), F.col("LeanData__Reporting_Matched_Account__c").alias('account_id'), F.col('LastModifiedDate'))
#         .withColumn('sfdc_contact_type', F.lit('lead'))
#     )

#     sfdc_lead_contact_dedupe = (
#         sfdc_contact_dedupe
#         .union(sfdc_lead_dedupe)
#         .withColumn("tiebreak", F.monotonically_increasing_id())
#         .withColumn("rank", F.rank().over(lead_contact_dedupe_window))
#         .filter(F.col("rank") == "1")
#         .drop("tiebreak", "rank")
#     )

#     sfdc_lead_contact = (
#         sfdc_lead_contact_dedupe
#         .withColumn('email_hash', F.sha2(F.col('email'), 256))
#         .select('email_hash', 'account_id', 'sfdc_contact_id', 'sfdc_contact_type')
#     )

#     # --- PAGE 5: Customer Account Name Resolution and Joins ---
#     account_names = (
#         sfdc_accounts
#         .select(F.col("Id").alias('account_id'), F.col("Name").alias('account_name_pre'), F.col("Account_Record_Type_Name__c").alias("record_type"))
#         .filter((F.col("Account_Record_Type_Name__c") == "Account") | (F.col("Account_Record_Type_Name__c").isNull()))
#         .filter(~F.col("Name").isin(partner_accounts))
#         .filter(~F.col("Name").isin(["Unknown", "Generic Account", "Self", "Generic/Public Business Subscription Account", "None", "-", "Self Incorporated", "Databricks K.K. (データブリックス・ジャパン株式会社)"]))
#         .filter(~F.col("Name").like("%Individual LMS Account%"))
#     )

#     docebo_users_emails_account_ids_customers = (
#         docebo_users_emails_customers_users
#         .join(sfdc_lead_contact, "email_hash", "left")
#     )

#     docebo_users_emails_account_names_customers_email_join = (
#         docebo_users_emails_account_ids_customers
#         .join(account_names, "account_id", "left")
#         .withColumn('account_name', F.coalesce(F.col("account_name_pre"), F.lit("Unknown")))
#     )

#     docebo_users_emails_account_ids_customers_alt_email_join = (
#         docebo_users_emails_account_names_customers_email_join
#         .filter(F.col("account_name") == "Unknown")
#         .drop('account_id', 'account_name', 'account_name_pre', 'record_type')
#         .join(sfdc_lead_contact.withColumnRenamed('email_hash', 'alternate_email_hash'), "alternate_email_hash", "left")
#     )

#     docebo_users_emails_account_names_customers_alt_email_join = (
#         docebo_users_emails_account_ids_customers_alt_email_join
#         .join(account_names, "account_id", "left")
#         .withColumn('account_name', F.coalesce(F.col("account_name_pre"), F.lit("Unknown")))
#     )

#     # --- PAGE 6 & 7: Unioning email and alternate email joins for customers ---
#     docebo_users_emails_account_names_customers = (
#         docebo_users_emails_account_names_customers_email_join
#         .filter(F.col("account_name") != "Unknown")
#         .select(
#             'account_id', 'email', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#             'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#             'branch_name', 'learner_branch', 'alternate_email_domain', 'level', 'alternate_email_hash',
#             'branch_code', 'timezone', 'username', 'first_name', 'last_name', 'alternate_email',
#             'accepted_t_and_c', 'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code',
#             'country_name', 'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash',
#             'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
#             'account_name', 'audience'
#         )
#         .union(
#             docebo_users_emails_account_names_customers_alt_email_join.select(
#                 'account_id', 'email', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#                 'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#                 'branch_name', 'learner_branch', 'alternate_email_domain', 'level', 'alternate_email_hash',
#                 'branch_code', 'timezone', 'username', 'first_name', 'last_name', 'alternate_email',
#                 'accepted_t_and_c', 'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code',
#                 'country_name', 'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash',
#                 'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
#                 'account_name', 'audience'
#             )
#         )
#     )

#     # --- PAGE 7 & 8: Filtering for found accounts and joining with curated accounts ---
#     docebo_users_emails_account_names_customers_account_found = (
#         docebo_users_emails_account_names_customers
#         .filter(F.col("account_name") != "Unknown")
#         .select(
#             'account_id', 'email', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#             'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#             'branch_name', 'learner_branch', 'alternate_email_domain', 'level', 'alternate_email_hash',
#             'branch_code', 'timezone', 'username', 'first_name', 'last_name', 'alternate_email',
#             'accepted_t_and_c', 'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code',
#             'country_name', 'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash',
#             'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
#             'account_name', 'audience'
#         )
#     )

#     docebo_users_emails_account_names_customers_account_found_bu = (
#         docebo_users_emails_account_names_customers_account_found
#         .join(accounts_curated, 'account_id', 'left')
#         .filter(F.col("business_unit").isNotNull())
#         .drop('business_unit')
#     )

#     # --- PAGE 9: Handling accounts without business unit ---
#     docebo_users_emails_account_names_customers_account_found_no_bu = (
#         docebo_users_emails_account_names_customers_account_found
#         .join(accounts_curated, 'account_id', 'left')
#         .filter(F.col("business_unit").isNull())
#         .withColumnRenamed('account_name', 'account_name_pre_2')
#         .withColumn('account_name', F.lit("Unknown"))
#         .drop('business_unit', 'account_name_pre_2')
#         .select(
#             'account_id', 'email', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#             'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#             'branch_name', 'learner_branch', 'alternate_email_domain', 'level', 'alternate_email_hash',
#             'branch_code', 'timezone', 'username', 'first_name', 'last_name', 'alternate_email',
#             'accepted_t_and_c', 'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code',
#             'country_name', 'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash',
#             'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
#             'account_name', 'audience'
#         )
#     )

#     # --- PAGE 10: Customer account mapping based on email domains ---
#     domain_window_customer_mapping = W.partitionBy("email_domain_final").orderBy(F.desc("total_emails"), "tiebreak")

#     customer_account_mapping = (
#         docebo_users_emails_account_names_customers_account_found
#         .select('account_id', 'account_name', "email_domain_final", 'email_domain', 'alternate_email_domain')
#         .filter(~F.col("email_domain_final").isin(blacklist))
#         .groupBy(['account_id', "account_name", "email_domain_final"])
#         .agg(F.count(F.col('email_domain')).alias('total_emails'))
#         .withColumn("tiebreak", F.monotonically_increasing_id())
#         .withColumn("rank", F.rank().over(domain_window_customer_mapping))
#         .filter(F.col("rank") == 1)
#         .drop("total_emails", "tiebreak", "rank")
#     )

#     docebo_users_emails_account_names_customers_no_account_no_bu = (
#         docebo_users_emails_account_names_customers
#         .filter(F.col("account_name") == "Unknown")
#         .union(docebo_users_emails_account_names_customers_account_found_no_bu)
#     )

#     docebo_users_emails_account_names_customers_account_not_found = (
#         docebo_users_emails_account_names_customers_no_account_no_bu
#         .drop('account_id')
#         .withColumnRenamed('account_name', 'account_name_pre_2')
#         .join(customer_account_mapping, 'email_domain_final', 'left')
#         .withColumn('account_name', F.coalesce(F.col("account_name"), F.col("account_name_pre_2")))
#         .select(
#             'account_id', 'email', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#             'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#             'branch_name', 'learner_branch', 'alternate_email_domain', 'level', 'alternate_email_hash',
#             'branch_code', 'timezone', 'username', 'first_name', 'last_name', 'alternate_email',
#             'accepted_t_and_c', 'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code',
#             'country_name', 'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash',
#             'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
#             'account_name', 'audience'
#         )
#     )

#     # --- PAGE 11 & 12: Remapping customers based on domain frequency (more than 5 domains) ---
#     mapping_window_more_than_5 = W.partitionBy("email_domain").orderBy(F.desc("total_emails"), "tiebreak")

#     mapping_more_than_5_domains = (
#         salesforce_account_email_domain_mapping
#         .filter(F.col("email_domain").isNotNull())
#         .filter(~F.col("email_domain").isin(blacklist))
#         .filter(F.col("total_for_email_and_account") >= 5)
#         .groupBy(["email_domain", "account_id", "account_name"])
#         .agg(F.sum("total_for_email_and_account").alias("total_emails"))
#         .withColumn("tiebreak", F.monotonically_increasing_id())
#         .withColumn("rank", F.rank().over(mapping_window_more_than_5))
#         .filter(F.col("rank") == 1)
#         .drop("total_emails", "tiebreak", "rank")
#         .select(F.col("email_domain").alias("email_domain_final"), F.col("account_id"), F.col("account_name"))
#     )

#     docebo_users_emails_account_names_customers_account_found_1 = (
#         docebo_users_emails_account_names_customers_account_not_found
#         .filter(F.col("account_name") != "Unknown")
#     )

#     docebo_users_emails_account_names_customers_remap_1 = (
#         docebo_users_emails_account_names_customers_account_not_found
#         .filter(F.col("account_name") == "Unknown")
#         .drop('account_id')
#         .withColumnRenamed('account_name', 'account_name_pre_2')
#         .join(mapping_more_than_5_domains, 'email_domain_final', 'left')
#         .withColumn('account_name', F.coalesce(F.col("account_name"), F.col("account_name_pre_2")))
#         .select(
#             'account_id', 'email', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#             'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#             'branch_name', 'learner_branch', 'alternate_email_domain', 'level', 'alternate_email_hash',
#             'branch_code', 'timezone', 'username', 'first_name', 'last_name', 'alternate_email',
#             'accepted_t_and_c', 'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code',
#             'country_name', 'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash',
#             'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
#             'account_name', 'audience'
#         )
#     )

#     # --- PAGE 13 & 14: Remapping customers based on most common domains ---
#     docebo_users_emails_account_names_customers_account_found_2 = (
#         docebo_users_emails_account_names_customers_remap_1
#         .filter(F.col("account_name") != "Unknown")
#     )

#     mapping_most_common_domains = (
#         salesforce_account_email_domain_mapping
#         .filter(F.col("email_domain").isNotNull())
#         .filter(~F.col("email_domain").isin(blacklist))
#         .groupBy(["email_domain", "account_id", "account_name"])
#         .agg(F.sum("total_for_email_and_account").alias("total_emails"))
#         .withColumn("tiebreak", F.monotonically_increasing_id())
#         .withColumn("rank", F.rank().over(mapping_window_more_than_5)) # Reusing the window definition
#         .filter(F.col("rank") == 1)
#         .drop("total_emails", "tiebreak", "rank")
#         .select(F.col("email_domain").alias("email_domain_final"), F.col("account_id"), F.col("account_name"))
#     )

#     docebo_users_emails_account_names_customers_remap_2 = (
#         docebo_users_emails_account_names_customers_remap_1
#         .filter(F.col("account_name") == "Unknown")
#         .drop('account_id')
#         .withColumnRenamed('account_name', 'account_name_pre_2')
#         .join(mapping_most_common_domains, 'email_domain_final', 'left')
#         .withColumn('account_name', F.coalesce(F.col("account_name"), F.col("account_name_pre_2")))
#         .select(
#             'account_id', 'email', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#             'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#             'branch_name', 'learner_branch', 'alternate_email_domain', 'level', 'alternate_email_hash',
#             'branch_code', 'timezone', 'username', 'first_name', 'last_name', 'alternate_email',
#             'accepted_t_and_c', 'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code',
#             'country_name', 'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash',
#             'email_domain_pre', 'email_domain_final', 'audience_pre', 'account_name_pre', 'record_type',
#             'account_name', 'audience'
#         )
#     )

#     # --- PAGE 15 & 16: Unioning all customer account mappings and joining ultimate parents ---
#     docebo_users_emails_account_names_customers_accounts = (
#         docebo_users_emails_account_names_customers_account_found_bu.withColumn('match_method', F.lit('direct_salesforce_contact_match'))
#         .union(docebo_users_emails_account_names_customers_account_found_1.withColumn('match_method', F.lit('matched_contacts_domain_account_mapping')))
#         .union(docebo_users_emails_account_names_customers_account_found_2.withColumn('match_method', F.lit('more_than_5_domains_on_account')))
#         .union(docebo_users_emails_account_names_customers_remap_2.withColumn('match_method', F.lit('most_common_domain_on_account')))
#     )

#     account_ultimate_parents_customers = ( # Renamed to avoid conflict
#         sfdc_accounts
#         .select(
#             F.col("Id").alias('account_id'),
#             F.col("Ultimate_Parent_Account__c").alias('ultimate_parent_account_name_pre'),
#             F.col("Ultimate_parent_account_casesafe_ID__c").alias("ultimate_parent_account_id_pre")
#         )
#     )

#     docebo_users_emails_customers = (
#         docebo_users_emails_account_names_customers_accounts
#         .join(account_ultimate_parents_customers, "account_id", "left")
#         .withColumn('ultimate_parent_account_name',
#                     F.when(F.col("account_name") != "Unknown", F.col("ultimate_parent_account_name_pre")).otherwise(F.lit("Unknown")))
#         .withColumn('ultimate_parent_account_id',
#                     F.when(F.col("account_name") != "Unknown", F.col("ultimate_parent_account_id_pre")).otherwise(F.lit("Unknown")))
#         .select(
#             'email_domain_final', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#             'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#             'branch_name', 'alternate_email_domain', 'level', 'alternate_email_hash', 'branch_code', 'timezone',
#             'username', 'email', 'first_name', 'last_name', 'alternate_email', 'accepted_t_and_c',
#             'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code', 'country_name',
#             'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash', 'learner_branch',
#             'account_id', 'account_name', 'ultimate_parent_account_id', 'ultimate_parent_account_name',
#             'audience', 'match_method'
#         )
#     )

#     # --- PAGE 17 & 18: Partner data processing ---
#     # Reusing account_ultimate_parents logic for partners, but keeping it distinct in variable name
#     account_ultimate_parents_partners = (
#         sfdc_accounts
#         .select(
#             F.col("Id").alias('account_id'),
#             F.col("Ultimate_Parent_Account__c").alias('ultimate_parent_account_name_pre'),
#             F.col("Ultimate_parent_account_casesafe_ID__c").alias("ultimate_parent_account_id_pre")
#         )
#     )

#     docebo_users_emails_partner = (
#         docebo_users_emails_partners_users
#         .join(partner_domains_df.withColumnRenamed('email_domain', 'email_domain_final'), "email_domain_final", "left")
#         .withColumnRenamed('ultimate_parent_account_id', 'ultimate_parent_account_id_pre')
#         .withColumnRenamed('ultimate_parent_account_name', 'ultimate_parent_account_name_pre')
#         .withColumn('ultimate_parent_account_id', F.coalesce(F.col("ultimate_parent_account_id_pre"), F.lit("Unknown")))
#         .withColumn('ultimate_parent_account_name', F.coalesce(F.col("ultimate_parent_account_name_pre"), F.lit("Unknown")))
#         .withColumn('account_id', F.col("ultimate_parent_account_id"))
#         .withColumn('account_name', F.col("ultimate_parent_account_name"))
#         .withColumn('match_method', F.lit('partner_ops_report'))
#         .select(
#             'email_domain_final', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#             'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#             'branch_name', 'alternate_email_domain', 'level', 'alternate_email_hash', 'branch_code', 'timezone',
#             'username', 'email', 'first_name', 'last_name', 'alternate_email', 'accepted_t_and_c',
#             'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code', 'country_name',
#             'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash', 'learner_branch',
#             'account_id', 'account_name', 'ultimate_parent_account_id', 'ultimate_parent_account_name',
#             'audience', 'match_method'
#         )
#     )

#     # --- PAGE 19 & 20: Unique mappings for Databricks and Microsoft ---
#     account_window_unique_mapping = W.partitionBy("account_name").orderBy(F.desc("total_for_email_and_account"), "tiebreak")
#     domain_window_unique_mapping = W.partitionBy("email_domain").orderBy(F.desc("total_emails"), "tiebreak")

#     accounts_df_unique = (
#         sfdc_accounts
#         .select(
#             F.col("Id").alias("ultimate_parent_account_id"),
#             F.col("Name").alias("ultimate_parent_account_name")
#         )
#     )

#     account_names_unique = (
#         sfdc_accounts
#         .select(
#             F.col("Id").alias("account_id"),
#             F.col("Name").alias("account_name"),
#             F.col("ParentId").alias("ultimate_parent_account_id")
#         )
#         .join(accounts_df_unique, "ultimate_parent_account_id", "left")
#     )

#     mapping_2_databricks = (
#         salesforce_account_email_domain_mapping
#         .filter(F.col("account_id") == databricks_account_id)
#         .filter(F.col("email_domain") == "databricks.com")
#         .orderBy(F.col("account_last_modified_timestamp").desc())
#         .limit(1)
#         .select("email_domain", "account_id")
#         .join(account_names_unique, "account_id", "left")
#         .withColumnRenamed('ultimate_parent_account_id', 'ultimate_parent_account_id_pre')
#         .withColumnRenamed('ultimate_parent_account_name', 'ultimate_parent_account_name_pre')
#         .withColumn('ultimate_parent_account_id', F.col('account_id'))
#         .withColumn('ultimate_parent_account_name', F.col('account_name'))
#         .select(
#             F.col("email_domain").alias("email_domain_final"),
#             F.col("account_id"),
#             F.col("account_name"),
#             F.col("ultimate_parent_account_id"),
#             F.col("ultimate_parent_account_name"),
#         )
#     )

#     mapping_2_microsoft = (
#         salesforce_account_email_domain_mapping
#         .filter(F.col("account_id") == microsoft_account_id)
#         .filter(F.col("email_domain") == "microsoft.com")
#         .orderBy(F.col("account_last_modified_timestamp").desc())
#         .limit(1)
#         .select("email_domain", "account_id")
#         .join(account_names_unique, "account_id", "left")
#         .select(
#             F.col("email_domain").alias("email_domain_final"),
#             F.col("account_id"),
#             F.col("account_name"),
#             F.col("ultimate_parent_account_id"),
#             F.col("ultimate_parent_account_name"),
#         )
#     )

#     # --- PAGE 21 & 22: Databricks data processing ---
#     docebo_users_emails_databricks = (
#         docebo_users_emails_databricks_users
#         .join(mapping_2_databricks, "email_domain_final", "left")
#         .withColumn('match_method', F.lit('hard_code_databricks'))
#         .select(
#             'email_domain_final', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#             'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#             'branch_name', 'alternate_email_domain', 'level', 'alternate_email_hash', 'branch_code', 'timezone',
#             'username', 'email', 'first_name', 'last_name', 'alternate_email', 'accepted_t_and_c',
#             'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code', 'country_name',
#             'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash', 'learner_branch',
#             'account_id', 'account_name', 'ultimate_parent_account_id', 'ultimate_parent_account_name',
#             'audience', 'match_method'
#         )
#     )

#     # --- PAGE 22 & 23: Microsoft data processing ---
#     docebo_users_emails_microsoft = (
#         docebo_users_emails_microsoft_users
#         .join(mapping_2_microsoft, "email_domain_final", "left")
#         .withColumn('match_method', F.lit('hard_code_microsoft'))
#         .select(
#             'email_domain_final', 'id', 'uuid', 'username_hash', 'email_domain', 'email_hash', 'valid',
#             'created_timestamp', 'suspended_timestamp', 'last_login', 'email_verified', 'last_updated_timestamp',
#             'branch_name', 'alternate_email_domain', 'level', 'alternate_email_hash', 'branch_code', 'timezone',
#             'username', 'email', 'first_name', 'last_name', 'alternate_email', 'accepted_t_and_c',
#             'accepted_t_and_c_timestamp', 't_and_c_version_id', 'country_code', 'country_name',
#             'alternate_email_2', 'alternate_email_2_domain', 'alternate_email_2_hash', 'learner_branch',
#             'account_id', 'account_name', 'ultimate_parent_account_id', 'ultimate_parent_account_name',
#             'audience', 'match_method'
#         )
#     )

#     # --- PAGE 23 & 24: Cleaning customer data ---
#     docebo_users_emails_customers_clean = (
#         docebo_users_emails_customers
#         .withColumnRenamed("account_id", "account_id_pre")
#         .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
#         .withColumnRenamed("account_name", "account_name_pre")
#         .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
#         .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
#         .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
#         .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
#         .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
#         .withColumnRenamed("audience", "audience_pre")
#         .withColumn("audience",
#                     F.when(F.col("account_name") == "Unknown", F.lit("Customer Other"))
#                     .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Customer Other"), F.lit("Customer"))
#                     .otherwise(F.col("audience_pre")))
#         .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
#     )

#     # --- PAGE 24: Cleaning partner data ---
#     docebo_users_emails_partner_clean = (
#         docebo_users_emails_partner
#         .withColumnRenamed("account_id", "account_id_pre")
#         .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
#         .withColumnRenamed("account_name", "account_name_pre")
#         .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
#         .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
#         .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
#         .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
#         .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
#         .withColumnRenamed("audience", "audience_pre")
#         .withColumn("audience",
#                     F.when(F.col("account_name") == "Unknown", F.lit("Partner Other"))
#                     .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Partner Other"), F.lit("Partner"))
#                     .otherwise(F.col("audience_pre")))
#         .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
#     )

#     # --- PAGE 25: Cleaning Databricks data ---
#     docebo_users_emails_databricks_clean = (
#         docebo_users_emails_databricks
#         .withColumnRenamed("account_id", "account_id_pre")
#         .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
#         .withColumnRenamed("account_name", "account_name_pre")
#         .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
#         .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
#         .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
#         .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
#         .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
#         .withColumnRenamed("audience", "audience_pre")
#         .withColumn("audience",
#                     F.when(F.col("account_name") == "Unknown", F.lit("Employee Other"))
#                     .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Employee Other"), F.lit("Employee"))
#                     .otherwise(F.col("audience_pre")))
#         .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
#     )

#     # --- PAGE 25 & 26: Cleaning Microsoft data ---
#     docebo_users_emails_microsoft_clean = (
#         docebo_users_emails_microsoft
#         .withColumnRenamed("account_id", "account_id_pre")
#         .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit(microsoft_account_id)).otherwise(F.col("account_id_pre")))
#         .withColumnRenamed("account_name", "account_name_pre")
#         .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit(microsoft_account_name)).otherwise(F.col("account_name_pre")))
#         .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
#         .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit(microsoft_parent_account_id)).otherwise(F.col("ultimate_parent_account_id_pre")))
#         .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
#         .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit(microsoft_parent_account_name)).otherwise(F.col("ultimate_parent_account_name_pre")))
#         .withColumnRenamed("audience", "audience_pre")
#         .withColumn("audience",
#                     F.when(F.col("account_name") == "Unknown", F.lit("Microsoft Other"))
#                     .when((F.col("account_name") != "Unknown") & (F.col("audience_pre") == "Microsoft Other"), F.lit("Microsoft"))
#                     .otherwise(F.col("audience_pre")))
#         .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre", "audience_pre")
#     )

#     # --- PAGE 26: Final Union of all cleaned user accounts ---
#     docebo_users_accounts_clean = (
#         docebo_users_emails_customers_clean
#         .union(docebo_users_emails_partner_clean)
#         .union(docebo_users_emails_databricks_clean)
#         .union(docebo_users_emails_microsoft_clean)
#     )

#     return docebo_users_accounts_clean


# COMMAND ----------

# temp_df = process_docebo_user_accounts(
#     docebo_users,
#     sfdc_contacts,
#     sfdc_leads,
#     sfdc_accounts,
#     partner_domains_df,
#     salesforce_account_email_domain_mapping,
#     accounts_curated,
#     partner_domains,
#     blacklist,
#     databricks_account_id,
#     microsoft_account_id,
#     microsoft_account_name,
#     microsoft_parent_account_id,
#     microsoft_parent_account_name,
#     partner_accounts
# )

# temp_df.createOrReplaceTempView("temp_data1")


# COMMAND ----------

docebo_users_accounts_audience_cleaned = (
  docebo_users_accounts_audience
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", 
        F.when((F.col("audience") == "Microsoft Other"), F.lit(microsoft_account_id))
          .when((F.col("audience") == "Employee Other"), F.lit(databricks_account_id))
          .otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", 
        F.when(F.col("audience") == "Microsoft Other", F.lit(microsoft_account_name))
          .when(F.col("audience") == "Employee Other", F.lit(databricks_account_name))
          .otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", 
        F.when(F.col("audience") == "Microsoft Other", F.lit(microsoft_parent_account_id))
          .when(F.col("audience") == "Employee Other", F.lit(databricks_parent_account_id))
          .otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", 
        F.when(F.col("audience") == "Microsoft Other", F.lit(microsoft_parent_account_name))
          .when(F.col("audience") == "Employee Other", F.lit(databricks_parent_account_name))
          .otherwise(F.col("ultimate_parent_account_name_pre")))
    .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre")
)

# COMMAND ----------

docebo_users_gold = (
  docebo_users_accounts_audience_cleaned
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("alternate_email_2"),
      F.col("alternate_email_2_hash"),
      F.col("alternate_email_2_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("learner_branch"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

docebo_users_gold_cleaned_accounts = (
  docebo_users_gold
    .withColumnRenamed('ultimate_parent_account_id','ultimate_parent_account_id_raw')
    .withColumnRenamed('ultimate_parent_account_name','ultimate_parent_account_name_raw')
    .withColumn('ultimate_parent_account_id', F.coalesce('ultimate_parent_account_id_raw', 'account_id'))
    .withColumn('ultimate_parent_account_name', F.coalesce('ultimate_parent_account_name_raw', 'account_name'))
    .join(countries_regions, "country_code", "left")
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("alternate_email_2"),
      F.col("alternate_email_2_hash"),
      F.col("alternate_email_2_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("learner_branch"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)


# COMMAND ----------

docebo_users_gold_cleaned_accounts_alt_emails = (
  docebo_users_gold_cleaned_accounts
    .withColumnRenamed('alternate_email', 'alternate_email_check')
    .withColumnRenamed('alternate_email_hash', 'alternate_email_hash_check')
    .withColumnRenamed('alternate_email_domain', 'alternate_email_domain_check')
    .withColumnRenamed('match_method', 'match_method_check')
    .withColumn('alternate_email', F.when(F.col('branch_code') == "DBK_EMP", F.col('alternate_email_2')).otherwise(F.col('alternate_email_check')))
    .withColumn('alternate_email_hash', F.when(F.col('branch_code') == "DBK_EMP", F.col('alternate_email_2_hash')).otherwise(F.col('alternate_email_hash_check')))
    .withColumn('alternate_email_domain', F.when(F.col('branch_code') == "DBK_EMP", F.col('alternate_email_2_domain')).otherwise(F.col('alternate_email_domain_check')))
    .withColumn('match_method', F.when(F.col('account_name') == "Unknown", F.lit('no_match')).otherwise(F.col('match_method_check')))
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("learner_branch"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)


# COMMAND ----------

sfdc_lead_contact_join = (
  sfdc_lead_contact
    .select(
      F.col('email_hash'), 
    F.col('sfdc_contact_id').alias('sfdc_contact_id_pre'), 
    F.col('sfdc_contact_type').alias('sfdc_contact_type_pre'))
)

docebo_users_gold_cleaned_sfdc_contacts = (
  docebo_users_gold_cleaned_accounts_alt_emails
    .join(sfdc_lead_contact_join, "email_hash", "left")
    .withColumn('sfdc_contact_id', F.coalesce(F.col("sfdc_contact_id_pre"), F.lit("unknown")))
    .withColumn('sfdc_contact_type', F.coalesce(F.col("sfdc_contact_type_pre"), F.lit("unknown")))
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("learner_branch"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method"),
      F.col('sfdc_contact_id'), 
      F.col('sfdc_contact_type')
    )
)

# COMMAND ----------

docebo_users_gold_cleaned_sfdc_contacts_with_nab_override = (
  docebo_users_gold_cleaned_sfdc_contacts
    .withColumn(
        "account_name",
        F.when(
            (F.col("email_domain").contains("nab.com.au")) | (F.col("alternate_email_domain").contains("nab.com.au")),
            F.lit("NAB")
        ).otherwise(F.col("account_name"))
    )
    .withColumn(
        "account_id",
        F.when(
            (F.col("email_domain").contains("nab.com.au")) | (F.col("alternate_email_domain").contains("nab.com.au")),
            F.lit("0016100000Y5d0pAAB")
        ).otherwise(F.col("account_id"))
    )
    .withColumn(
        "account_id",
        F.when(
            F.col("account_id").isin("0016100001OCRfdAAH","0016100001TPJaWAAX"),
            F.lit("0016100000U5DsSAAV")
        ).otherwise(F.col("account_id"))
    )
    .withColumn(
        "account_name",
        F.when(
            F.col("account_name") == F.lit("NVIDIA *"),
            F.lit("NVIDIA Corporation")
        ).otherwise(F.col("account_name"))
    )
    .withColumn(
        "ultimate_parent_account_id",
        F.when(
            F.col("ultimate_parent_account_id").isin("0016100001TPJaWAAX"),
            F.lit("0016100000U5DsSAAV")
        ).otherwise(F.col("ultimate_parent_account_id"))
    )
    .withColumn(
        "ultimate_parent_account_name",
        F.when(
            F.col("ultimate_parent_account_name") == F.lit("NVIDIA *"),
            F.lit("NVIDIA Corporation")
        ).otherwise(F.col("ultimate_parent_account_name"))
    )

)

# COMMAND ----------

docebo_users_gold_cleaned_accounts_partition = add_gold_metadata(docebo_users_gold_cleaned_sfdc_contacts_with_nab_override)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = docebo_users_gold_cleaned_accounts_partition, 
  table_name = f'{focus_database_name}.docebo_users_test', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)