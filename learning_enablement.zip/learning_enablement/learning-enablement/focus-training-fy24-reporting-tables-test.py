# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "focus_dev")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### Learners Dataset

# COMMAND ----------

learners_df = spark.sql('''
  with avg_time_pre_rank AS (
    select 
        id, 
        expected_time_to_complete_in_seconds,
        rank() over (partition by id order by expected_time_to_complete_in_seconds nulls last , category_code desc) as rank 
    from docebo_silver.courses
    where processDate = (select max(processDate) from docebo_silver.courses)

  ),

  employee_data AS (
    select 
      department, 
      category, 
      `1st_level_manager`,
      `1st_level_manager_name`,
      `2nd_level_manager`, 
      `2nd_level_manager_name`,
      `3rd_level_manager`, 
      `3rd_level_manager_name`,
      `4th_level_manager`,
      `4th_level_manager_name`,
      `5th_level_manager`, 
      `5th_level_manager_name`,
      `6th_level_manager`,
      `6th_level_manager_name`,
      Supervisory_Organization_cleaned,
      primaryWorkEmail,
      sha2(primaryWorkEmail,256) as email_hash
    from liam.wd
    where worker_type='Employee'
    and Termination_Date is null
  )
  ,

  avg_time AS (
    select * from avg_time_pre_rank where rank=1
  )
  ,

  sp_enrollments as (
    select
      processdate,
      learner_user_id,
      learner_email,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email,
      learner_alternate_email_hash,
      learner_alternate_email_domain,
      learner_branch_code,
      account_id,
      account_name,
      ultimate_parent_account_id,
      ultimate_parent_account_name, 
      course_code,
      course_name,
      course_type,
      category_code,
      status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      completed_timestamp,
      source,
      country_code, 
      country_name, 
      region, 
      audience,
      d.fq2,
      d.month,
      d.year,
      d.fiscalYear,
      d.qtr_start_date,
      d.qtr_end_date,
      t.expected_time_to_complete_in_seconds
    from focus_dev.self_paced_enrollments_test e
    inner join users.ravi_gangumalla.sql_dates d on e.completed_timestamp::date=d.date 
    left join avg_time t on e.course_id = t.id
    where e.status in ('completed')
    and e.source = 'Learndot'
    and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
    and e.processdate= (select max(processdate) from focus_dev.self_paced_enrollments_test)
    
    union all

    select     
      processdate,
      learner_user_id,
      learner_email,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email,
      learner_alternate_email_hash,
      learner_alternate_email_domain,
      learner_branch_code,
      account_id,
      account_name,
      ultimate_parent_account_id,
      ultimate_parent_account_name, 
      course_code,
      course_name,
      course_type,
      category_code,
      status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      completed_timestamp,
      source,
      country_code, 
      country_name, 
      region, 
      audience,
      d.fq2,
      d.month,
      d.year,
      d.fiscalYear,
      d.qtr_start_date,
      d.qtr_end_date,
      t.expected_time_to_complete_in_seconds
    from focus_dev.self_paced_enrollments_test e
    inner join users.ravi_gangumalla.sql_dates d on e.completed_timestamp::date=d.date
    left join avg_time t on e.course_id = t.id
    where e.status in ('completed')
    and e.source='Docebo'
    and e.category_code in ('PART','ACAD','FENG/CUSU','FENG')
    and e.course_id not in (723, 721, 724, 687, 1182)
    and e.course_code ilike ('%-SLP-%')
    and e.course_code not ilike ('%DNR')
    and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
    and e.processdate= (select max(processdate) from focus_dev.self_paced_enrollments_test)
  ),
  ilt_enrollments_pre as (
    select 
      processdate,
      learner_user_id,
      learner_email,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email,
      learner_alternate_email_hash,
      learner_alternate_email_domain,
      learner_branch_code,
      account_id,
      account_name,
      ultimate_parent_account_id,
      ultimate_parent_account_name, 
      course_code,
      course_name,
      course_type,
      category_code,
      status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      completed_timestamp,
      source,
      country_code, 
      country_name,
      region,
      audience,
      d.fq2,
      d.month,
      d.year,
      d.fiscalYear,
      d.qtr_start_date,
      d.qtr_end_date,
      3*60*60 as expected_time_to_complete_in_seconds
    from focus_dev.ilt_enrollments_test e
    inner join users.ravi_gangumalla.sql_dates d on e.completed_timestamp::date=d.date
    where e.status in ('completed')
    and e.source = 'Learndot'
    and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
    and e.processdate= (select max(processdate) from focus_dev.ilt_enrollments_test)

    union all
    
    select 
      processdate,
      learner_user_id,
      learner_email,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email,
      learner_alternate_email_hash,
      learner_alternate_email_domain,
      learner_branch_code,
      account_id,
      account_name,
      ultimate_parent_account_id,
      ultimate_parent_account_name, 
      course_code,
      course_name,
      course_type,
      category_code,
      status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      completed_timestamp,
      source,
      country_code, 
      country_name, 
      region, 
      audience,
      d.fq2,
      d.month,
      d.year,
      d.fiscalYear,
      d.qtr_start_date,
      d.qtr_end_date,
      t.expected_time_to_complete_in_seconds
    from focus_dev.ilt_enrollments_test e
    inner join users.ravi_gangumalla.sql_dates d on e.completed_timestamp::date=d.date
    left join avg_time t on e.course_id = t.id
    where e.status in ('completed')
    and e.category_code in ('PART','ACAD','FENG/CUSU','FENG')
    and e.source = 'Docebo'
    and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
    and e.processdate= (select max(processdate) from focus_dev.ilt_enrollments_test)
  ),

  ilt_enrollments_dedupe AS 
  (
    select 
      *,
      rank() over (partition by i.learner_user_id, i.course_code, i.completed_timestamp order by i.category_code) as dedupe_rank
    from ilt_enrollments_pre i
  )
  ,

  ilt_enrollments_final AS (
    select * 
    from ilt_enrollments_dedupe 
    where dedupe_rank=1
  )
  ,

  sp_enrollments_dedupe as
  (
    select 
      s.*, 
      rank() over (partition by s.learner_user_id, s.course_code, s.completed_timestamp order by s.category_code) as dedupe_rank 
    from sp_enrollments s
  )
  ,

  sp_enrollments_final as
  (
    select * from sp_enrollments_dedupe where dedupe_rank=1
  )
  ,

  all_enrollments as
  (
    select * from ilt_enrollments_final
    union all
    select * from sp_enrollments_final
  )

  ,
  rolling_totals as (
    select 
      completed_timestamp, 
      learner_user_id, 
      course_code, 
      category_code,
      expected_time_to_complete_in_seconds,
      sum(expected_time_to_complete_in_seconds) over (partition by learner_user_id order by completed_timestamp asc ROWS BETWEEN unbounded preceding AND CURRENT ROW) as rollingTotal 
    from all_enrollments e
    group by 1,2,3,4,5
  )
  ,
  all_enrollments_filtered as (
    select 
      s.*,
      t.rollingTotal
    from all_enrollments s 
    left join rolling_totals t
      on s.learner_user_id = t.learner_user_id
      and s.course_code = t.course_code
      and s.completed_timestamp = t.completed_timestamp
    where t.rollingTotal >= 3*60*60
  )
  ,
  pre as (
    select
      processdate,
      learner_user_id,
      learner_email,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email,
      learner_alternate_email_hash,
      learner_alternate_email_domain,
      a.account_id as a_account_id,
      a.account_name,
      a.ultimate_parent_account_id,
      a.ultimate_parent_account_name, 
      learner_branch_code,
      course_code,
      course_name,
      course_type,
      category_code,
      status,
      enrolled_date,
      completed_date,
      completed_timestamp,
      source,
      fq2,
      month,
      year,
      fiscalYear,
      qtr_start_date,
      qtr_end_date,
      expected_time_to_complete_in_seconds,
      rollingTotal,
      country_code, 
      country_name, 
      region, 
      audience,
      b.account_id,
      b.business_unit,
      b.sales_subregion_level_1,
      b.sales_subregion_level_2,
      case  
        when p.`Account ID` is not null then 1 else 0 end as partner_account_list_flag,
      dense_rank() over (partition by learner_user_id order by completed_timestamp, enrolled_date) as rank_learner,
      dense_rank() over (partition by learner_user_id, fiscalYear order by completed_timestamp, enrolled_date) as fiscal_rank -- needed to find the first time a learner crossed the threshold
    from all_enrollments_filtered a
    left join focus_prod.core_accounts_curated b on a.account_id=b.account_id and b.snapshot_date = (select max(snapshot_date) from focus_prod.core_accounts_curated)
    left join focus_dev.partner_domains_priyanka p on left(a.ultimate_parent_account_id, 15) = p.`Account ID`
    )

  ,


  pre_final_net_new_learner as 
  (
  select *, dense_rank() over (partition by learner_user_id order by course_name) as rank_dedupe -- needed to dedupe scenarios where the same learner has completed a few courses at the exact same time to cross the learner threshold
  from pre where rank_learner = 1 
  )
  ,

  net_new_learners AS (
    select 
      'net new learners' as dataset,
      *
    from pre_final_net_new_learner where rank_dedupe=1
  )
  ,

  pre_final_fiscal_learner AS (
    select 
      *, 
      dense_rank() over (partition by fiscalYear, learner_user_id order by course_name) as rank_dedupe
    from pre where fiscal_rank=1
  )
  ,

  fiscal_learners AS (
    select 
      'fiscal learners' as dataset, 
      *
    from pre_final_fiscal_learner 
    where rank_dedupe=1
  )
  ,

  pre_final_dataset AS (
    select * from net_new_learners
    union all
    select * from fiscal_learners
  )
  ,

  final_dataset AS (

    select 
      f.*,
      e.department, 
      e.category, 
      e.`1st_level_manager`,
      e.`1st_level_manager_name`,
      e.`2nd_level_manager`, 
      e.`2nd_level_manager_name`,
      e.`3rd_level_manager`, 
      e.`3rd_level_manager_name`,
      e.`4th_level_manager`,
      e.`4th_level_manager_name`,
      e.`5th_level_manager`, 
      e.`5th_level_manager_name`,
      e.`6th_level_manager`,
      e.`6th_level_manager_name`,
      e.Supervisory_Organization_cleaned,
      e.primaryWorkEmail
    from pre_final_dataset f
    left join employee_data e on f.learner_email_hash=e.email_hash and f.learner_branch_code='DBK_EMP' 
  )


  select  * from final_dataset

''')

# COMMAND ----------

all_learners_gold = add_gold_metadata(learners_df)

# COMMAND ----------

# MAGIC %md ### Certifications Badge dataset

# COMMAND ----------

certs_badges_df = spark.sql('''
  with date_year AS (
    select distinct fiscalYear,current_date as date from users.ravi_gangumalla.sql_dates where date::date=current_date
  )
  ,

  fiscal_year_end AS (
    select d.date, max(s.fiscalYear) as next_fiscal_year, max(s.qtr_end_date) as fiscal_year_end_date from users.ravi_gangumalla.sql_dates s inner join date_year d on s.fiscalYear=d.fiscalYear
    group by 1
  )
  ,
  employee_data AS (
    select 
      department, 
      category, 
      `1st_level_manager`,
      `1st_level_manager_name`,
      `2nd_level_manager`, 
      `2nd_level_manager_name`,
      `3rd_level_manager`, 
      `3rd_level_manager_name`,
      `4th_level_manager`,
      `4th_level_manager_name`,
      `5th_level_manager`, 
      `5th_level_manager_name`,
      `6th_level_manager`,
      `6th_level_manager_name`,
      Supervisory_Organization_cleaned,
      primaryWorkEmail,
      sha2(primaryWorkEmail,256) as email_hash
    from liam.wd
    where worker_type='Employee'
    and Termination_Date is null
  )
  ,
  badges as (
    select
      processdate,
      complete,
      credential_id,
      credential_name,
      expired_on :: date,
      is_expired,
      group_id,
      group_name, 
      issued_on :: date,
      learner_id,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email_domain,
      learner_branch_code,
      audience,
      b.account_id,
      b.account_name,
      ultimate_parent_account_id,
      ultimate_parent_account_name,
      d.fq2,
      d.qtr_start_date,
      d.qtr_end_date,
      d.fiscalYear,
      d2.fq2 as current_fiscal_quarter,
      d2.qtr_end_date as current_fiscal_quarter_end_date,
      f.fiscal_year_end_date,
      country_code,
      country_name,
      region,
      c.business_unit,
      c.sales_subregion_level_1,
      c.sales_subregion_level_2,
      case 
        when group_id in (
          '371215', 
          '364119', 
          '357057', 
          '353856', 
          '331743', 
          '229201', 
          '227965', 
          '227818'
        )
        then "Certification"
        when group_id in (
          '296467',
          '405160'
        ) then "Badge"
        else "Other" end as credential_type,
        case  
          when p.`Account ID` is not null then 1 else 0 end as partner_account_list_flag,
      dense_rank() over (partition by processdate,learner_email_hash order by issued_on::date) as rank_learner
    from focus_dev.accredible_credentials_test b
    inner join users.ravi_gangumalla.sql_dates d on b.issued_on::date=d.date
    inner join users.ravi_gangumalla.sql_dates d2 on current_date()::date=d2.date
    inner join fiscal_year_end f on current_date()::date=f.date
    left join focus_prod.core_accounts_curated c on b.account_id=c.account_id and c.snapshot_date=(select max(snapshot_date) from focus_prod.core_accounts_curated)
    left join focus_dev.partner_domains_priyanka p on left(b.ultimate_parent_account_id, 15) = p.`Account ID`
    where b.processdate= (select max(processdate) from focus_dev.accredible_credentials_test)
  )

  ,

  working AS (
    select 
      case 
        when expired_on::date>current_date::date 
        then date_diff(expired_on,current_date) 
        else 0 end as days_to_expiration, 
      b.*,
      e.department, 
      e.category, 
      e.`1st_level_manager`,
      e.`1st_level_manager_name`,
      e.`2nd_level_manager`, 
      e.`2nd_level_manager_name`,
      e.`3rd_level_manager`, 
      e.`3rd_level_manager_name`,
      e.`4th_level_manager`,
      e.`4th_level_manager_name`,
      e.`5th_level_manager`, 
      e.`5th_level_manager_name`,
      e.`6th_level_manager`,
      e.`6th_level_manager_name`,
      e.Supervisory_Organization_cleaned,
      e.primaryWorkEmail
    from badges b
    left join employee_data e on b.learner_email_hash=e.email_hash and b.learner_branch_code='DBK_EMP' 
  )

  select * 
  from working

''')

# COMMAND ----------

certs_badges_gold = add_gold_metadata(certs_badges_df)

# COMMAND ----------

# MAGIC %md ### All Enrollments

# COMMAND ----------

all_enrollments_df = spark.sql('''
with sp_enrollments AS (
  select
     processdate,
     learner_user_id,
     learner_email,
     learner_email_hash,
     learner_email_domain,
     learner_alternate_email,
     learner_alternate_email_hash,
     learner_alternate_email_domain,
     learner_branch_code,
     account_id,
     account_name,
     ultimate_parent_account_id,
     ultimate_parent_account_name, 
     course_code,
     course_name,
     course_type,
     course_id,
     null as session_id,
     category_code,
     status,
     enrolled_timestamp :: date as enrolled_date,
     completed_timestamp :: date as completed_date,
     completed_timestamp,
     source,
     country_code, 
     country_name, 
     region, 
     audience,
     d.fq2,
     d2.fq2 as completed_fq2,
     d.month,
     d.year,
     d.fiscalYear,
     d.qtr_start_date,
     d.qtr_end_date
   from focus_dev.self_paced_enrollments_test e
   inner join users.ravi_gangumalla.sql_dates d on e.enrolled_timestamp::date=d.date
   left join users.ravi_gangumalla.sql_dates d2 on e.completed_timestamp::date=d2.date
   where e.source = 'Learndot'
   and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
   and e.processdate= (select max(processdate) from focus_dev.self_paced_enrollments_test)
   
   union all
 
   select     
     processdate,
     learner_user_id,
     learner_email,
     learner_email_hash,
     learner_email_domain,
     learner_alternate_email,
     learner_alternate_email_hash,
     learner_alternate_email_domain,
     learner_branch_code,
     account_id,
     account_name,
     ultimate_parent_account_id,
     ultimate_parent_account_name, 
     course_code,
     course_name,
     course_type,
     course_id,
     null as session_id,
     category_code,
     status,
     enrolled_timestamp :: date as enrolled_date,
     completed_timestamp :: date as completed_date,
     completed_timestamp,
     source,
     country_code,
     country_name,
     region,
     audience,
     d.fq2,
     d2.fq2 as completed_fq2,
     d.month,
     d.year,
     d.fiscalYear,
     d.qtr_start_date,
     d.qtr_end_date
   from focus_dev.self_paced_enrollments_test e
   inner join users.ravi_gangumalla.sql_dates d on e.enrolled_timestamp::date=d.date
   left join users.ravi_gangumalla.sql_dates d2 on e.completed_timestamp::date=d2.date
   where e.source='Docebo'
   and e.category_code in ('PART','ACAD','FENG/CUSU','FENG')
   and e.course_id not in (723, 721, 724, 687, 1182)
   and e.course_code ilike ('%-SLP-%')
   and e.course_code not ilike ('%DNR')
   and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
   and e.processdate= (select max(processdate) from focus_dev.self_paced_enrollments_test)
  )
 ,
 
 ilt_enrollments AS (
   select 
     processdate,
     learner_user_id,
     learner_email,
     learner_email_hash,
     learner_email_domain,
     learner_alternate_email,
     learner_alternate_email_hash,
     learner_alternate_email_domain,
     learner_branch_code,
     account_id,
     account_name,
     ultimate_parent_account_id,
     ultimate_parent_account_name, 
     course_code,
     course_name,
     course_type,
     course_id,
     session_id,
     category_code,
     status,
     enrolled_timestamp :: date as enrolled_date,
     completed_timestamp :: date as completed_date,
     completed_timestamp,
     source,
     country_code, 
     country_name, 
     region, 
     audience,
     d.fq2,
     d2.fq2 as completed_fq2,
     d.month,
     d.year,
     d.fiscalYear,
     d.qtr_start_date,
     d.qtr_end_date
   from focus_dev.ilt_enrollments_test e
   inner join users.ravi_gangumalla.sql_dates d on e.enrolled_timestamp::date=d.date
   left join users.ravi_gangumalla.sql_dates d2 on e.completed_timestamp::date=d2.date
   where e.source = 'Learndot'
   and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
   and e.processdate= (select max(processdate) from focus_dev.ilt_enrollments_test)
 union all
   
   select 
     processdate,
     learner_user_id,
     learner_email,
     learner_email_hash,
     learner_email_domain,
     learner_alternate_email,
     learner_alternate_email_hash,
     learner_alternate_email_domain,
     learner_branch_code,
     account_id,
     account_name,
     ultimate_parent_account_id,
     ultimate_parent_account_name, 
     course_code,
     course_name,
     course_type,
     course_id,
     session_id,
     category_code,
     status,
     enrolled_timestamp :: date as enrolled_date,
     completed_timestamp :: date as completed_date,
     completed_timestamp,
     source,
     country_code, 
     country_name, 
     region, 
     audience,
     d.fq2,
     d2.fq2 as completed_fq2,
     d.month,
     d.year,
     d.fiscalYear,
     d.qtr_start_date,
     d.qtr_end_date
   from focus_dev.ilt_enrollments_test e
   inner join users.ravi_gangumalla.sql_dates d on e.enrolled_timestamp::date=d.date
   left join users.ravi_gangumalla.sql_dates d2 on e.completed_timestamp::date=d2.date
   where e.category_code in ('PART','ACAD','FENG/CUSU','FENG')
   and e.source = 'Docebo'
   and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
   and e.processdate= (select max(processdate) from focus_dev.ilt_enrollments_test)
 )
 ,
  learner_enrollments as (
    select *
    from sp_enrollments
    union all
    select *
    from ilt_enrollments
  )
 ,
  wd as ( 
    select 
      lower(wd_email) as primaryWorkEmail, 
      sfdc_businessUnit 
    from liam.list_of_workday_users_and_respective_sfdc_user_ids
  )
  ,

  employee_data AS (
    select 
      department, 
      category, 
      businessTitle,
      `1st_level_manager`,
      `1st_level_manager_name`,
      `2nd_level_manager`, 
      `2nd_level_manager_name`,
      `3rd_level_manager`, 
      `3rd_level_manager_name`,
      `4th_level_manager`,
      `4th_level_manager_name`,
      `5th_level_manager`, 
      `5th_level_manager_name`,
      `6th_level_manager`,
      `6th_level_manager_name`,
      Supervisory_Organization_cleaned,
      lower(d.primaryWorkEmail) as primaryWorkEmail,
      sha2(lower(d.primaryWorkEmail),256) as email_hash,
      sfdc_businessUnit,
      manager_hierarchy_path_name,
      manager_hierarchy_path,
      Manager
    from liam.wd d
    left join wd w on w.primaryWorkEmail = d.primaryWorkEmail
    where worker_type='Employee'
    and Termination_Date is null
  )
  ,
 
 ilt_sessions_dedupe as (
   select s.*,
   rank() over (partition by s.id order by s.course_category_code) as dedupe_rank 
   from docebo_silver.ilt_sessions s
   where s.processDate=(select max(processDate) from docebo_silver.ilt_sessions)
 )
 ,
 ilt_sessions as (
   select s.*
   from ilt_sessions_dedupe s
   where s.dedupe_rank = 1
 )

 select 
   e.*,
   s.id,
   s.session_name,
   s.started_timestamp,
   s.ended_timestamp,
   b.business_unit,
   b.sales_subregion_level_1,
   b.sales_subregion_level_2,
   d.*,
   case when nvl(e.status,'Unknown') in ('in_progress','completed','subscribed') then 1 else 0 end as registered_flag,
   case when nvl(e.status,'Unknown') in ('completed') then 1 else 0 end as attended_flag
 from learner_enrollments e
 left join ilt_sessions s on e.session_id=s.id
 left join focus_prod.core_accounts_curated b on e.account_id=b.account_id and b.snapshot_date = (select max(snapshot_date) from focus_prod.core_accounts_curated)
 left join employee_data d on e.learner_email_hash=d.email_hash and e.learner_branch_code='DBK_EMP'
''')

# COMMAND ----------

all_enrollments_gold = add_gold_metadata(all_enrollments_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_learners_gold, 
  table_name = f'{focus_database_name}.all_learners_test', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = certs_badges_gold, 
  table_name = f'{focus_database_name}.certifications_and_badges_test', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_enrollments_gold, 
  table_name = f'{focus_database_name}.all_enrollments_test', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

