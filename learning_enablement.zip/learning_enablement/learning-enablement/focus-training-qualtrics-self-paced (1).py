# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

import requests
import zipfile
import json
import os
import sys
import re
import io
from pprint import pprint

data_center_id = "pdx1"
survey_id = "SV_0PURSxKVFboxaXs"
fileFormat = "csv"

url = f"https://{data_center_id}.qualtrics.com/API/v3"
# token = dbutils.secrets.get(scope="nate.hast-secrets", key="qualtrics")
token = "ZQXU86VvkcQR3qPFdopcw8ZQpyCyGnF5jGJSOLQS"

def exportSurvey(apiToken,surveyId, dataCenter, fileFormat):

    surveyId = survey_id
    fileFormat = fileFormat
    dataCenter = data_center_id 
    apiToken =token

    # Setting static parameters
    requestCheckProgress = 0.0
    progressStatus = "inProgress"
    baseUrl = "https://{0}.qualtrics.com/API/v3/surveys/{1}/export-responses/".format(dataCenter, surveyId)
    headers = {
    "content-type": "application/json",
    "x-api-token": apiToken,
    }

    # Step 1: Creating Data Export
    downloadRequestUrl = baseUrl
    downloadRequestPayload = '{"format":"' + fileFormat + '"}'
    downloadRequestResponse = requests.request("POST", downloadRequestUrl, data=downloadRequestPayload, headers=headers)
    pprint(downloadRequestResponse.json())
    progressId = downloadRequestResponse.json()["result"]["progressId"]
    print(downloadRequestResponse.text)

    # Step 2: Checking on Data Export Progress and waiting until export is ready
    while progressStatus != "complete" and progressStatus != "failed":
        print ("progressStatus=", progressStatus)
        requestCheckUrl = baseUrl + progressId
        requestCheckResponse = requests.request("GET", requestCheckUrl, headers=headers)
        requestCheckProgress = requestCheckResponse.json()["result"]["percentComplete"]
        print("Download is " + str(requestCheckProgress) + " complete")
        progressStatus = requestCheckResponse.json()["result"]["status"]

    #step 2.1: Check for error
    if progressStatus == "failed":
        raise Exception("export failed")

    fileId = requestCheckResponse.json()["result"]["fileId"]

    # Step 3: Downloading file
    requestDownloadUrl = baseUrl + fileId + '/file'
    requestDownload = requests.request("GET", requestDownloadUrl, headers=headers, stream=True)

    # Step 4: Unzipping the file
    
    path = "/Volumes/users/tilak_parajiya/qualtrics_data"

    zipfile.ZipFile(io.BytesIO(requestDownload.content)).extractall(path)

    print('Complete')


# COMMAND ----------

exportSurvey(token,survey_id,data_center_id,fileFormat)

# COMMAND ----------

import pandas as pd
survey_df = pd.read_csv("/Volumes/users/nathan_zukoff/qualtrics_test/Databricks Academy Course Feedback Survey.csv", header=1).drop(index=0)

# COMMAND ----------

spark_df = spark.createDataFrame(survey_df)
spark_df.createOrReplaceTempView("survey_feedback")

# COMMAND ----------

survey_clean_df = spark.sql('''
  with survey_pre_1 as (
    select 
    s.`How would you rate this course (1 being the lowest and 10 being the highest)?` as course_rating,
    s.`This course covered the content I was expecting.` as expected_content,
    s.`How likely is it that you would recommend Databricks training to a friend or colleague?` as recommend,
    s.`How was the audio quality of this course?` as audio_quality,
    s.`Is there anything else you would like to share with us about this course?` as extra_course_feedback,
    s.course_id, 
    s.course_title,
    s.Progress as progress, 
    s.`Duration (in seconds)` as duration_seconds, 
    s.Finished as finished,
    split(s.`Recorded Date`, ' ')[0]::date as recorded_date,
    s.`Response ID` as response_id
    from survey_feedback s
  )
  , 
  survey_pre_2 as (
    select 
      case 
        when course_rating = "NaN" then null else cast(course_rating as int) end as course_rating,
      case
        when expected_content = "NaN" then null else cast(expected_content as int) end as expected_content,
      case
        when recommend = "NaN" then null else cast(recommend as int) end as recommend,
      case
        when audio_quality = "NaN" then null else cast(audio_quality as int) end as audio_quality,
      case
        when extra_course_feedback = "NaN" then null else extra_course_feedback end as extra_course_feedback,
      course_id, 
      course_title,
      progress, 
      duration_seconds, 
      finished,
      recorded_date,
      response_id
      from survey_pre_1 
  )
, 
survey as (
  select 
    course_rating,
    case when course_rating >= 9 then 1 when course_rating is null then null else 0 end as course_rating_attractor,
    case when course_rating >= 7 and course_rating < 9 then 1 when course_rating is null then null else 0 end as course_rating_neutral,
    case when course_rating < 7 then 1 when course_rating is null then null else 0 end as course_rating_detractor,
    expected_content,
    case when expected_content >= 4 then 1 when expected_content is null then null else 0 end as expected_content_attractor,
    case when expected_content < 4 then 1 when expected_content is null then null else 0 end as expected_content_detractor,
    recommend,
    case when recommend >= 9 then 1 when recommend is null then null else 0 end as recommend_attractor,
    case when recommend >= 7 and recommend < 9 then 1 when recommend is null then null else 0 end as recommend_neutral,
    case when recommend < 7 then 1 when recommend is null then null else 0 end as recommend_detractor,
    audio_quality,
    case when audio_quality >= 9 then 1 when audio_quality is null then null else 0 end as audio_quality_attractor,
    case when audio_quality >= 7 and audio_quality < 9 then 1 when audio_quality is null then null else 0 end as audio_quality_neutral,
    case when audio_quality < 7 then 1 when audio_quality is null then null else 0 end as audio_quality_detractor,
    extra_course_feedback,
    course_id, 
    course_title as course_name,
    progress, 
    duration_seconds, 
    finished,
    recorded_date,
    response_id
  from survey_pre_2
)

select 
  s.*,
  c.code as course_code
from survey s
left join main.it_training_silver.docebo_courses c on s.course_id = c.id and c.processDate = (select max(processDate) from main.it_training_silver.docebo_courses)

''')

# COMMAND ----------

survey_clean_df.createOrReplaceTempView('survey_results_cleaned')

# COMMAND ----------

survey_grouped_df = spark.sql('''
  with survey as (
    select 
      course_id, 
      course_name,
      course_code,
      sum(course_rating_attractor) as course_rating_attractors,
      sum(course_rating_neutral) as course_rating_neutrals,
      sum(course_rating_detractor) as course_rating_detractors,
      round(avg(course_rating),2) as course_rating_avg,
      sum(expected_content_attractor) as expected_content_attractors,
      sum(expected_content_detractor) as expected_content_detractors,
      round(avg(expected_content),2) as expected_content_avg,
      sum(recommend_attractor) as recommend_attractors,
      sum(recommend_neutral) as recommend_neutrals,
      sum(recommend_detractor) as recommend_detractors,
      round(avg(recommend),2) as recommend_avg,
      sum(audio_quality_attractor) as audio_quality_attractors,
      sum(audio_quality_neutral) as audio_quality_neutrals,
      sum(audio_quality_detractor) as audio_quality_detractors,
      round(avg(audio_quality),2) as audio_quality_avg,
      count(*) as total_responses,
      collect_set(extra_course_feedback) as extra_course_feedback
    from survey_results_cleaned
    group by all
  )
  ,
  course_enrollments as (
    select 
      course_id, 
      count(distinct learner_user_id) as total_enrollments,
      count(distinct case when status = 'completed' then learner_user_id end) as completed_enrollments
    from main.it_training_silver.docebo_self_paced_enrollments
    where processDate = (select max(processDate) from main.it_training_silver.docebo_self_paced_enrollments)
    and status in ('completed', 'in_progress', 'subscribed')
    group by 1
  )
  , 
  pre as (
  select
    s.*,
    round(round(s.course_rating_attractors/s.total_responses,2)*100,0) as course_rating_attractors_percentage,
    round(round(s.course_rating_neutrals/s.total_responses,2)*100,0) as course_rating_neutrals_percentage,
    round(round(s.course_rating_detractors/s.total_responses,2)*100,0) as course_rating_detractors_percentage,
    round(round(s.expected_content_attractors/s.total_responses,2)*100,0) as expected_content_attractors_percentage,
    round(round(s.expected_content_detractors/s.total_responses,2)*100,0) as expected_content_detractors_percentage,
    round(round(s.recommend_attractors/s.total_responses,2)*100,0) as recommend_attractors_percentage,
    round(round(s.recommend_neutrals/s.total_responses,2)*100,0) as recommend_neutrals_percentage,
    round(round(s.recommend_detractors/s.total_responses,2)*100,0) as recommend_detractors_percentage,
    round(round(s.audio_quality_attractors/s.total_responses,2)*100,0) as audio_quality_attractors_percentage,
    round(round(s.audio_quality_neutrals/s.total_responses,2)*100,0) as audio_quality_neutrals_percentage,
    round(round(s.audio_quality_detractors/s.total_responses,2)*100,0) as audio_quality_detractors_percentage,
    e.total_enrollments, 
    e.completed_enrollments, 
    round(round(total_responses / completed_enrollments, 2)*100,0) as response_rate
  from survey s
  left join course_enrollments e on s.course_id = e.course_id
  -- order by s.project_id
  )

  select *
  from pre                              

''')

# COMMAND ----------

survey_results_cleaned_df_gold = add_gold_metadata(survey_clean_df)
survey_grouped_df_gold = add_gold_metadata(survey_grouped_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = survey_results_cleaned_df_gold, 
  table_name = f'{focus_database_name}.qualtrics_self_paced_survey_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = survey_grouped_df_gold, 
  table_name = f'{focus_database_name}.qualtrics_self_paced_survey_summary', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

