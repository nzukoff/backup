def unit_test_valid_date(date_val):
  format = "%Y-%d-%M"
 
  try:
    res = bool(datetime.strptime(date_val, format))
  except ValueError:
    res = False
 
  return res
 
def unit_test_valid_db(db_val, spark, catalog):
  try:
    res = bool([x.databaseName for x in spark.sql(f"show databases in {catalog}").collect() if x.databaseName == db_val])
  except ValueError:
    res = False
 
  return res

def unit_test_df_count(df):
  try:
    res = df.count()
  except ValueError:
    res = False
 
  return res