# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for webassessor data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# from pprint import pprint
# from pyspark.sql import DataFrame, Column
# from typing import Optional, Sequence as Seq, Dict, Callable, Any

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md 
# MAGIC ###Total Accounts, Accounts created MOM, accounts with no exams associated in Webassessor

# COMMAND ----------


accounts_df = spark.sql("""
  select
    u.user_id,
    u.email,
    u.email_hash,
    u.active_inactive,
    u.email_domain,
    u.branch_code,
    u.date_created::timestamp,
    u.first_name,
    u.last_name,
    u.address_region,
    u.address_country,
    r.user_id as registered_user_id,
    -- r.registration_id,
    -- collect_list(r.test_name) as test_name,
    -- Checking if the user_id is present in the registrations table then marking exam associated as yes, even though some of them don't have a test_name in the registrations table.
    MAX(
      CASE
        WHEN r.user_id IS NULL THEN false
        ELSE true
      END
    ) AS is_exam_associated
  from
    main.it_training_silver.webassessor_users u
    left join main.it_training_silver.webassessor_registrations r on r.user_id = u.user_id
    and r.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_registrations
    )
    and r.status = 'NORMAL'
  where
    u.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_users
    )
  group by
    all
  order by
    u.user_id 
""")

# COMMAND ----------

webassessor_users = spark.sql('''
          select distinct user_id from main.it_training_silver.webassessor_users
          where processDate = (select max(processDate) from main.it_training_silver.webassessor_users)
          ''')
# display(webassessor_users)
pprint(unit_test_df_count(webassessor_users))
pprint(unit_test_df_count(accounts_df))
# assert unit_test_df_count(webassessor_users) == unit_test_df_count(accounts_df)

# COMMAND ----------

webassessor_accounts_gold = add_gold_metadata(accounts_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Pass Rates
# MAGIC

# COMMAND ----------

# DBTITLE 1,Pass Rates by Exam
# pass_rates_by_exam_df = spark.sql('''
# with passes as (
#   select
#     pass_fail,
#     exam_name,
#     transcript_id,
#     case
#       when pass_fail = 'PASS'
#       and progress = 'COMPLETED' then 1
#       else 0
#     end as contains_pass
#   from
#     main.it_training_silver.webassessor_transcripts
#   where
#     processDate = (
#       select
#         max(processDate)
#       from
#         main.it_training_silver.webassessor_transcripts
#     )
# )
# select
#   exam_name,
#   round(sum(contains_pass) / count(transcript_id) * 100, 2) as pass_rate,
#   count(transcript_id) as total_exams,
#   sum(contains_pass) as total_passed
# from
#   passes
# group by
#   exam_name
# order by
#   exam_name
# ''')
# exams_df = spark.sql('''
#     select distinct exam_name from
#     main.it_training_silver.webassessor_transcripts
#   where
#     processDate = (
#       select
#         max(processDate)
#       from
#         main.it_training_silver.webassessor_transcripts
#     )
#                      ''')

# assert unit_test_df_count(pass_rates_by_exam_df) == unit_test_df_count(exams_df)

# COMMAND ----------

# DBTITLE 1,Pass Rates by voucher batch and by % discount
# pass_rates_by_voucher_df = spark.sql('''
# with passes as (
#   select
#     t.pass_fail,
#     v.voucher_code,
#     v.percentage,
#     v.batch_name,
#     t.transcript_id,
#     case
#       when t.pass_fail = 'PASS'
#       and t.progress = 'COMPLETED'
#       -- and t.status = "NORMAL"
#        then 1
#       else 0
#     end as contains_pass
#   from
#     main.it_training_silver.webassessor_transcripts t
#     left join main.it_training_silver.webassessor_registrations r on r.registration_id = t.registration_id
#     and r.processDate = (
#       select
#         max(processDate)
#       from
#         main.it_training_silver.webassessor_registrations
#     )
#     left join main.it_training_silver.webassessor_vouchers v on v.voucher_code = r.voucher_codes
#     and v.processDate = (
#       select
#         max(processDate)
#       from
#         main.it_training_silver.webassessor_vouchers
#     )
#   where
#     t.processDate = (
#       select
#         max(processDate)
#       from
#         main.it_training_silver.webassessor_transcripts
#     )
# )
# select
#   voucher_code,
#   percentage,
#   batch_name,
#   round(sum(contains_pass) / count(transcript_id) * 100, 2) as pass_rate,
#   count(transcript_id) as total_exams,
#   sum(contains_pass) as total_passed
# from
#   passes
# group by
#   voucher_code, percentage, batch_name
# order by
#   voucher_code, percentage
# ''')

# vouchers_df = spark.sql('''
#     select distinct voucher_code,
#   percentage,
#   batch_name
#    from
#     main.it_training_silver.webassessor_transcripts t
#     left join main.it_training_silver.webassessor_registrations r on r.registration_id = t.registration_id
#     and r.processDate = (select max(processDate) from main.it_training_silver.webassessor_registrations)
#     left join main.it_training_silver.webassessor_vouchers v on v.voucher_code = r.voucher_codes and v.processDate = (select max(processDate) from main.it_training_silver.webassessor_vouchers)
#   where t.processDate = (select max(processDate) from main.it_training_silver.webassessor_transcripts)
# ''')
# display(unit_test_df_count(pass_rates_by_voucher_df))
# display(unit_test_df_count(vouchers_df))

# assert unit_test_df_count(pass_rates_by_voucher_df) == unit_test_df_count(vouchers_df)


# COMMAND ----------

# DBTITLE 1,Pass Rates by Geo
# pass_rates_by_geo_df = spark.sql('''
# with passes as (
#   select
#     t.pass_fail,
#     u.address_region,
#     u.address_country,
#     t.transcript_id,
#     case
#       when t.pass_fail = 'PASS'
#       and t.progress = 'COMPLETED' then 1
#       else 0
#     end as contains_pass
#   from
#     main.it_training_silver.webassessor_transcripts t
#     left join main.it_training_silver.webassessor_users u on u.user_id = t.user_id
#     and u.processDate = (
#       select
#         max(processDate)
#       from
#         main.it_training_silver.webassessor_users
#     )
#   where
#     t.processDate = (
#       select
#         max(processDate)
#       from
#         main.it_training_silver.webassessor_transcripts
#     )
# )

# select
#   address_region,
#   address_country,
#   round(sum(contains_pass) / count(transcript_id) * 100, 2) as pass_rate,
#   count(transcript_id) as total_exams,
#   sum(contains_pass) as total_passed
# from
#   passes
# group by
#   address_region,
#   address_country
# order by
#   address_region,
#   address_country
# ''')


# geo_df = spark.sql('''
#   select distinct
#     address_region,
#     address_country
#     from
#       main.it_training_silver.webassessor_transcripts t
#       left join main.it_training_silver.webassessor_users u on u.user_id = t.user_id
#       and u.processDate = (
#         select
#           max(processDate)
#         from
#           main.it_training_silver.webassessor_users
#       )
#     where
#       t.processDate = (
#         select
#           max(processDate)
#         from
#           main.it_training_silver.webassessor_transcripts
#       )
# ''')

# display(unit_test_df_count(pass_rates_by_geo_df))
# display(unit_test_df_count(geo_df))

# assert unit_test_df_count(pass_rates_by_geo_df) == unit_test_df_count(geo_df)


# COMMAND ----------

# DBTITLE 1,Pass Rates by Event vs Virtual
# %sql
# with passes as (
#   select
#     t.pass_fail,
#     p.name,
#     case when p.name ilike '%in-person%' then 'in person' else 'virtual' end as type,
#     r.product_code,
#     t.transcript_id,
#     case
#       when t.pass_fail = 'PASS'
#       and t.progress = 'COMPLETED' then 1
#       else 0
#     end as contains_pass
#   from
#     main.it_training_silver.webassessor_transcripts t
#     left join main.it_training_silver.webassessor_registrations r on r.registration_id = t.registration_id
#     and r.processDate = (
#       select
#         max(processDate)
#       from
#         main.it_training_silver.webassessor_registrations
#     )
#     left join main.it_training_silver.webassessor_products p on r.product_code = p.code
#     and p.processDate = (
#       select
#         max(processDate)
#       from
#         main.it_training_silver.webassessor_products
#     )
#   where
#     t.processDate = (
#       select
#         max(processDate)
#       from
#         main.it_training_silver.webassessor_transcripts
#     )
# )

# select
#   type,
#   round(sum(contains_pass) / count(distinct transcript_id) * 100, 2) as pass_rate,
#   count(distinct transcript_id) as total_exams,
#   sum(contains_pass) as total_passed
# from
#   passes
# group by
#   type
# order by
#   type





# COMMAND ----------

# MAGIC %md
# MAGIC ####Pass Rates

# COMMAND ----------

# DBTITLE 1,Pass Rates
pass_rates_df = spark.sql("""
  with voucher_percentage as (
    select 
    v.voucher_code,
    replace(v.percentage, '%', '') AS percentage,
    v.batch_name
    from main.it_training_silver.webassessor_vouchers v
    where v.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_vouchers
    )
  )
  select
    distinct t.transcript_id,
    t.pass_fail,
    r.event_date::date,
    t.exam_name,
    v.voucher_code,
    v.percentage,
    v.batch_name,
    u.address_region,
    u.address_country,
    p.name,
    case
      when p.name ilike '%in-person%' then 'in person'
      else 'virtual'
    end as type,
    r.product_code,
    case
      when t.pass_fail = 'PASS'
      and t.progress = 'COMPLETED' then 1
      else 0
    end as contains_pass
  from
    main.it_training_silver.webassessor_transcripts t
    left join main.it_training_silver.webassessor_registrations r on r.registration_id = t.registration_id
    and r.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_registrations
    )
    left join voucher_percentage v on v.voucher_code = r.voucher_codes
    left join main.it_training_silver.webassessor_users u on u.user_id = t.user_id
    and u.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_users
    )
    left join main.it_training_silver.webassessor_products p on r.product_code = p.code
    and p.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_products
    )
  where
    t.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_transcripts
    )
    
""")

data_df = spark.sql('''
select
    distinct t.transcript_id,
    t.pass_fail,
    t.exam_name,
    v.voucher_code,
    v.percentage,
    v.batch_name,
    u.address_region,
    u.address_country,
    p.name
    from
    main.it_training_silver.webassessor_transcripts t
    left join main.it_training_silver.webassessor_registrations r on r.registration_id = t.registration_id
    and r.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_registrations
    )
    left join main.it_training_silver.webassessor_vouchers v on v.voucher_code = r.voucher_codes
    and v.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_vouchers
    )
    left join main.it_training_silver.webassessor_users u on u.user_id = t.user_id
    and u.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_users
    )
    left join main.it_training_silver.webassessor_products p on r.product_code = p.code
    and p.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_products
    )
  where
    t.processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.webassessor_transcripts
    )
''')

display(unit_test_df_count(pass_rates_df))
display(unit_test_df_count(data_df))
assert unit_test_df_count(pass_rates_df) == unit_test_df_count(data_df)



# COMMAND ----------

webassessor_passrates_gold = add_gold_metadata(pass_rates_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Registrations by time, completions, by exam, by voucher_batch, by % discount

# COMMAND ----------

# DBTITLE 1,Registrations Data
registrations_data_df = spark.sql(
    """
      with pre as (
    select
    distinct
    r.user_id,
    r.registration_id,
    r.registration_date,
    r.status,
    r.event_date,
    r.email_hash,
    r.progress,
    r.test_name,
    r.voucher_codes,
    d.calendar_year_month as registration_year_month,
    d.fiscal_year_quarter as registration_fiscal_year_quarter,
    d.fiscal_year as registration_fiscal_year

    from main.it_training_silver.webassessor_registrations r
    left join main.it_core_dim.dim_dates d on r.registration_date :: date = d.date
    where r.processDate = (select max(processDate) from main.it_training_silver.webassessor_registrations)
  )

  select 
    distinct
    p.user_id, 
    p.registration_id,
    p.registration_date::timestamp,
    p.status,
    p.event_date::timestamp,
    p.email_hash,
    p.progress,
    p.test_name,
    t.exam_name,
    p.voucher_codes,
    p.registration_year_month,
    p.registration_fiscal_year_quarter,
    p.registration_fiscal_year,
    t.transcript_id,
    case when t.pass_fail is null then 'Not Attempted'
    else t.pass_fail end as pass_fail,
    -- t.progress,
    v.voucher_code,
    v.batch_name,
    replace(v.percentage, '%', '') AS percentage
    
    from pre p 
    left join main.it_training_silver.webassessor_transcripts t on p.registration_id = t.registration_id
      and t.processDate = (select max(processDate) from main.it_training_silver.webassessor_transcripts)
    left join main.it_training_silver.webassessor_vouchers v on v.voucher_code = p.voucher_codes
      and v.processDate = (
        select
          max(processDate)
        from
          main.it_training_silver.webassessor_vouchers)

""")

registrations_df = spark.sql('''
  select distinct p.user_id,p.registration_id, p.test_name,p.voucher_codes, p.event_date, t.transcript_id,
    t.pass_fail from main.it_training_silver.webassessor_registrations p
    left join main.it_core_dim.dim_dates d on p.registration_date :: date = d.date
    left join main.it_training_silver.webassessor_transcripts t on p.registration_id = t.registration_id
      and t.processDate = (select max(processDate) from main.it_training_silver.webassessor_transcripts)
    left join main.it_training_silver.webassessor_vouchers v on v.voucher_code = p.voucher_codes
      and v.processDate = (
        select
          max(processDate)
        from
          main.it_training_silver.webassessor_vouchers)
    where p.processDate = (select max(processDate) from main.it_training_silver.webassessor_registrations)
                             ''')
# display(registrations_data_df)
display(unit_test_df_count(registrations_data_df))
display(unit_test_df_count(registrations_df))
#assert unit_test_df_count(registrations_data_df) == unit_test_df_count(registrations_df)



# COMMAND ----------

# MAGIC %sql
# MAGIC       with pre as (
# MAGIC     select
# MAGIC     distinct
# MAGIC     r.user_id,
# MAGIC     r.registration_id,
# MAGIC     r.registration_date,
# MAGIC     r.status,
# MAGIC     r.event_date,
# MAGIC     r.email_hash,
# MAGIC     r.progress,
# MAGIC     r.test_name,
# MAGIC     r.voucher_codes,
# MAGIC     d.calendar_year_month as registration_year_month,
# MAGIC     d.fiscal_year_quarter as registration_fiscal_year_quarter,
# MAGIC     d.fiscal_year as registration_fiscal_year
# MAGIC
# MAGIC     from main.it_training_silver.webassessor_registrations r
# MAGIC     left join main.it_core_dim.dim_dates d on r.registration_date :: date = d.date
# MAGIC     where r.processDate = (select max(processDate) from main.it_training_silver.webassessor_registrations)
# MAGIC   )
# MAGIC
# MAGIC   select 
# MAGIC     distinct
# MAGIC     p.user_id, 
# MAGIC     p.registration_id,
# MAGIC     p.registration_date::timestamp,
# MAGIC     p.status,
# MAGIC     p.event_date::timestamp,
# MAGIC     p.email_hash,
# MAGIC     p.progress,
# MAGIC     p.test_name,
# MAGIC     t.exam_name,
# MAGIC     p.voucher_codes,
# MAGIC     p.registration_year_month,
# MAGIC     p.registration_fiscal_year_quarter,
# MAGIC     p.registration_fiscal_year,
# MAGIC     t.transcript_id,
# MAGIC     case when t.pass_fail is null then 'Not Attempted'
# MAGIC     else t.pass_fail end as pass_fail,
# MAGIC     -- t.progress,
# MAGIC     v.voucher_code,
# MAGIC     v.batch_name,
# MAGIC     replace(v.percentage, '%', '') AS percentage
# MAGIC     
# MAGIC     from pre p 
# MAGIC     left join main.it_training_silver.webassessor_transcripts t on p.registration_id = t.registration_id
# MAGIC       and t.processDate = (select max(processDate) from main.it_training_silver.webassessor_transcripts)
# MAGIC     left join main.it_training_silver.webassessor_vouchers v on v.voucher_code = p.voucher_codes
# MAGIC       and v.processDate = (
# MAGIC         select
# MAGIC           max(processDate)
# MAGIC         from
# MAGIC           main.it_training_silver.webassessor_vouchers)

# COMMAND ----------

webassessor_registrations_gold = add_gold_metadata(registrations_data_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Voucher batches by creator, by created month, % discount, expiry, 

# COMMAND ----------

# DBTITLE 1,Vouchers Data

webassessor_voucher_df = spark.sql("""

    select 
      -- distinct
      v.voucher_code,
      v.voucher_used,
      v.batch_name,
      replace(v.percentage, '%', '') AS percentage,
      v.quantity,
      v.creator,
      v.creation_date::timestamp,
      -- v.exam,
      v.expiration_date::timestamp,
      r.voucher_codes as registrations_voucher_code,
      t.transcript_id as transcripts_id,
      t.pass_fail as transcripts_pass_fail
    from main.it_training_silver.webassessor_vouchers v
      left join main.it_training_silver.webassessor_registrations r on v.voucher_code = r.voucher_codes 
      and r.processDate = (select max(processDate) from main.it_training_silver.webassessor_registrations)
      left join main.it_training_silver.webassessor_transcripts t on r.registration_id = t.registration_id
      and t.processDate = (select max(processDate) from main.it_training_silver.webassessor_transcripts)
      where v.processDate = (select max(processDate) from main.it_training_silver.webassessor_vouchers)
      -- and voucher_used is not null
    group by all
    order by voucher_code
""")
# display(unit_test_df_count(webassessor_voucher_df))
# voucher_df = spark.sql('''
#   select distinct voucher_code from main.it_training_silver.webassessor_vouchers
#   where processDate = (select max(processDate) from main.it_training_silver.webassessor_vouchers)
#   and voucher_used is not null
#                        ''')
# display(unit_test_df_count(voucher_df))


# COMMAND ----------

webassessor_vouchers_gold_v1 = add_gold_metadata(webassessor_voucher_df)

# COMMAND ----------

# DBTITLE 1,Vouchers Life Cycle

# -- Total vouchers
# -- select count(voucher_code) as voucher_code_count, batch_name as voucher_batch_name from main.it_training_silver.webassessor_vouchers
# -- where processDate = (select max(processDate) from main.it_training_silver.webassessor_vouchers)
# -- group by all

# -- Vouchers used for registration
# -- select count(voucher_used) as voucher_used_count, batch_name as voucher_batch_name
# -- from main.it_training_silver.webassessor_registrations r 
# -- left join main.it_training_silver.webassessor_vouchers v on v.voucher_code = r.voucher_codes
# --       and v.processDate = (select max(processDate) from main.it_training_silver.webassessor_vouchers)
# -- where r.processDate = (select max(processDate) from main.it_training_silver.webassessor_registrations)
# -- group by all

# -- Vouchers used and exam attempted
# -- select count(voucher_used) as voucher_used_count, batch_name as voucher_batch_name
# -- from main.it_training_silver.webassessor_transcripts t
# -- left join main.it_training_silver.webassessor_registrations r on r.registration_id = t.registration_id 
# --       and r.processDate = (select max(processDate) from main.it_training_silver.webassessor_registrations)
# -- left join main.it_training_silver.webassessor_vouchers v on v.voucher_code = r.voucher_codes
# --       and v.processDate = (select max(processDate) from main.it_training_silver.webassessor_vouchers)
# -- where t.processDate = (select max(processDate) from main.it_training_silver.webassessor_transcripts)
# -- group by all


# -- Vouchers used and exam passed
vouchers_utilisation_df = spark.sql('''

with passes as (
  select t.registration_id, t.pass_fail, t.transcript_id
  from main.it_training_silver.webassessor_transcripts t
      where t.processDate = (select max(processDate) from main.it_training_silver.webassessor_transcripts)
      and t.pass_fail = 'PASS'
)
select
count(distinct v.voucher_code) as total_voucher_codes,
v.batch_name as voucher_batch_name,
v.expiration_date::timestamp as voucher_expiration_date,
v.creation_date::timestamp as voucher_creation_date,
count(distinct r.voucher_codes) as vouchers_registered,
count(distinct t.transcript_id) as exams_attempted,
count(distinct p.transcript_id) as exams_passed
-- t.pass_fail as transcripts_pass_fail
from main.it_training_silver.webassessor_vouchers v
left join main.it_training_silver.webassessor_registrations r on v.voucher_code = r.voucher_codes 
      and r.processDate = (select max(processDate) from main.it_training_silver.webassessor_registrations)
left join main.it_training_silver.webassessor_transcripts t on r.registration_id = t.registration_id
      and t.processDate = (select max(processDate) from main.it_training_silver.webassessor_transcripts)
left join passes p on r.registration_id = p.registration_id
where v.processDate = (select max(processDate) from main.it_training_silver.webassessor_vouchers)
-- and r.voucher_codes is null
-- and t.pass_fail = 'FAIL'
-- and t.pass_fail = 'PASS'
group by all
''')


# COMMAND ----------

webassessor_vouchers_utilisation_gold = add_gold_metadata(vouchers_utilisation_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Writing Tables

# COMMAND ----------

# Vouchers
write_delta_table(
  spark, 
  dataframe = webassessor_vouchers_gold_v1, 
  table_name = f'{focus_database_name}.webassessor_vouchers', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# Accounts
write_delta_table(
  spark, 
  dataframe = webassessor_accounts_gold, 
  table_name = f'{focus_database_name}.webassessor_accounts', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# Passrates
write_delta_table(
  spark, 
  dataframe = webassessor_passrates_gold, 
  table_name = f'{focus_database_name}.webassessor_pass_rates', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# Registrations
write_delta_table(
  spark, 
  dataframe = webassessor_registrations_gold, 
  table_name = f'{focus_database_name}.webassessor_registrations_data', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = webassessor_vouchers_utilisation_gold, 
  table_name = f'{focus_database_name}.webassessor_vouchers_utilisation', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)