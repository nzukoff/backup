# Databricks notebook source
spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

# MAGIC %run "/Users/liam.clifford@databricks.com/utility_functions"

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC # Helpful medium post covering wsdl auth/parsing

# COMMAND ----------

#https://adriennedomingus.medium.com/using-zeep-to-make-soap-requests-in-python-c575ea0ee954

# COMMAND ----------

# MAGIC %md
# MAGIC # Install Package

# COMMAND ----------

pip install zeep

# COMMAND ----------

# MAGIC %md
# MAGIC # Auth

# COMMAND ----------

from zeep import Client
from zeep.wsse.username import UsernameToken

username=dbutils.secrets.get('sales-performance', 'wd_username')
password=dbutils.secrets.get('sales-performance', 'wd_password')

client = Client('https://services1.myworkday.com/ccx/service/customreport2/databricks/ISU-Logfood/Employee_Demographics_-_Logfood?wsdl',wsse=UsernameToken(username, password))

# COMMAND ----------

# from zeep import Client, Settings
# from zeep.wsse.username import UsernameToken
# import logging.config

# # # Enable logging
# # logging.config.dictConfig({
# #     'version': 1,
# #     'formatters': {
# #         'verbose': {
# #             'format': '%(name)s: %(message)s'
# #         }
# #     },
# #     'handlers': {
# #         'console': {
# #             'level': 'DEBUG',
# #             'class': 'logging.StreamHandler',
# #             'formatter': 'verbose',
# #         },
# #     },
# #     'loggers': {
# #         'zeep': {
# #             'level': 'DEBUG',
# #             'propagate': True,
# #             'handlers': ['console'],
# #         },
# #     }
# # })


# # Enable logging
# logging.basicConfig(level=logging.DEBUG)
# logging.getLogger('zeep').setLevel(logging.DEBUG)

# wsdl = 'https://services1.myworkday.com/ccx/service/customreport2/databricks/ISU-Logfood/Employee_Demographics_-_Logfood?wsdl'

# username = dbutils.secrets.get('sales-performance', 'wd_username')
# password = dbutils.secrets.get('sales-performance', 'wd_password')

# # Create a Zeep client with WSSE username token
# client = Client(wsdl, wsse=UsernameToken(username, password))

# # Print available services and methods for debugging
# print(client.service)

# # Call the report execution method
# try:
#     response = client.service.Execute_Report()
#     print(response)
# except Exception as e:
#     print(f"An error occurred: {e}")



# COMMAND ----------

# MAGIC %md
# MAGIC # Get Data

# COMMAND ----------

data = client.service.Execute_Report('**Report_Entry')

# COMMAND ----------

# MAGIC %md
# MAGIC # Structure into DataFrame

# COMMAND ----------

for i in data[0]:
  print(i)

# COMMAND ----------

# for i in data:
#   if i['primaryWorkEmail']== 'p.patel@databricks.com': 
#     print(i)

# COMMAND ----------

# for i in data:
#   if i['CF_-_Termination_Date__Blank_for_Rehire_']!= None: 
#     print(i)

# COMMAND ----------

# original_tbl         = 'users.liam_clifford.wd_stg'
# prod_table_name      = 'wd_r'
# partially_masked_tbl = 'users.liam_clifford.wd'

# COMMAND ----------

original_tbl         = f'{focus_database_name}.workday_stg'
prod_table_name      = 'wd_r'
partially_masked_tbl = f'{focus_database_name}.workday'

# COMMAND ----------

# DBTITLE 1,Employee Data Processing Script
import pandas as pd

List = []
for i in data:
  Name = i['Name']['Descriptor']
  WorkdayID = i['Name']['ID'][0]['_value_1']
  Worker_Type = i['Worker_Type']['Descriptor']
  primaryWorkEmail = i['primaryWorkEmail']
  Hire_Date = i['Hire_Date']
  Last_Promotion_Date = i['Last_Promotion_Date']
  Termination_Date = i['CF_-_Termination_Date__Blank_for_Rehire_']
  Job_Profile_Prior_To_Last_Promotion_Date = i['Job_Profile_Prior_To_Last_Promotion_Date']
  Business_Title_Prior_To_Last_Promotion_Date = i['Business_Title_Prior_To_Last_Promotion_Date']
  
  try:
    Cost_Center = i['Cost_Center']['Descriptor']
  except:
    Cost_Center = ''
  # LC ADDED 09.02.23 DUE TO `Cost_Center` BEING NULL FOR EMPLOYEE

  Location = i['Location']['Descriptor']
  try:
    Location_Address_Country = i['Location_Address_-_Country']['Descriptor']
  except:
    Location_Address_Country = ''
  Job_Profile = i['Job_Profile']['Descriptor']

  try:
    Job_Level = i['Job_Level']['Descriptor']
  except:
    Job_Level = ''

  businessTitle = i['businessTitle']
  Supervisory_Organization = i['Supervisory_Organization']['Descriptor']
  Supervisory_Organization_cleaned = str(i['Supervisory_Organization']['Descriptor']).split(' (')[0]
  try:
    Time_Zone = i['Time_Zone'][0]['Descriptor']
  except:
    Time_Zone = 'None Available'
  Status = i['Status']
  
  try:
    Manager_Level_01 = i['Management_Chain_-_Level_01']['Descriptor']
  except:
    Manager_Level_01 = ''
  try:
    Manager_Level_02 = i['Management_Chain_-_Level_02']['Descriptor']
  except:
    Manager_Level_02 = ''
  try:
    Manager_Level_03 = i['Management_Chain_-_Level_03']['Descriptor']
  except:
    Manager_Level_03 = ''
  
  try:
    Original_Hire_Date = i['Original_Hire_Date']
    if Original_Hire_Date == None:
      Original_Hire_Date = ''
    else:
      Original_Hire_Date = Original_Hire_Date
  except:
    Original_Hire_Date = ''
  try:
    Job_Profile_Start_Date = i['Job_Profile_Start_Date']
    if Job_Profile_Start_Date == None:
      Job_Profile_Start_Date = ''
    else:
      Job_Profile_Start_Date = Job_Profile_Start_Date
  except:
    Job_Profile_Start_Date = ''
  try:
    Last_Job_Req_Event_Date = i['Last_Job_Req_Event_Date']
    if Last_Job_Req_Event_Date == None:
      Last_Job_Req_Event_Date = ''
    else:
      Last_Job_Req_Event_Date = Last_Job_Req_Event_Date
  except:
    Last_Job_Req_Event_Date = ''
  
  
  try:
    Manager = i['Manager'][0]['Descriptor']
    Manager_Email = i['Manager_Email']
  except:
    Manager = ''
    Manager = ''
    
  if primaryWorkEmail == 'selene.garcia@databricks.com': 
    Time_Zone_GMT_Factor = -6  
    
  elif str(Time_Zone).find('+') != -1:
    Time_Zone_GMT_Factor = +1 * (int(str(Time_Zone).split('+')[1].split(':')[0]) + \
                               float(str(Time_Zone).split('+')[1].split(':')[1].split(' ')[0])/60)
  elif str(Time_Zone).find('-') != -1:
    Time_Zone_GMT_Factor = -1 * (int(str(Time_Zone).split('-')[1].split(':')[0]) + \
                               float(str(Time_Zone).split('-')[1].split(':')[1].split(' ')[0])/60)
  elif str(Time_Zone).find('-') == -1 and str(Time_Zone).find('+') == -1: 
    Time_Zone_GMT_Factor = 0
  
  metadata = \
        [ 
          Name,\
          WorkdayID,\
          Worker_Type,\
          primaryWorkEmail,\
          Hire_Date,\
          Last_Promotion_Date,\
          Termination_Date,\
          Job_Profile_Prior_To_Last_Promotion_Date,\
          Business_Title_Prior_To_Last_Promotion_Date,\
          Cost_Center,\
          Location,\
          Location_Address_Country,\
          Job_Profile,\
          Job_Level,\
          businessTitle,\
          Manager_Level_01,\
          Manager_Level_02,\
          Manager_Level_03,\
          Manager,\
          Manager_Email,\
          Supervisory_Organization,\
          Supervisory_Organization_cleaned,\
          Time_Zone,\
          Time_Zone_GMT_Factor,\
          Status,\
          Original_Hire_Date,\
          Job_Profile_Start_Date,\
          Last_Job_Req_Event_Date\
  ]
  List.append(metadata)
  cols=['Name','WorkdayID','Worker_Type','primaryWorkEmail','Hire_Date','Last_Promotion_Date','Termination_Date','Job_Profile_Prior_To_Last_Promotion_Date',\
        'Business_Title_Prior_To_Last_Promotion_Date','Cost_Center','Location','Location_Address_Country','Job_Profile','Job_Level','businessTitle',\
        'Manager_Level_01','Manager_Level_02','Manager_Level_03','Manager','Manager_Email',\
        'Supervisory_Organization','Supervisory_Organization_cleaned','Time_Zone','Time_Zone_GMT_Factor','Status',\
        'Original_Hire_Date','Job_Profile_Start_Date','Last_Job_Req_Event_Date']

df = pd.DataFrame()
df = pd.DataFrame(columns = cols,data=List)

columns_before = df.columns
# get columns before dropping nulls

df = df.dropna(axis=1, how='all')
# drop columns that are all null 

columns_after = df.columns
# get columns after dropping nulls

deleted_columns = [i for i in columns_before if i not in columns_after]
# determine which columns were removed
print(deleted_columns)

# df = df[(df['Worker_Type'].str.contains('Contingent Worker')==False)]

spark_df = spark.createDataFrame(df)

spark_df.createOrReplaceTempView('wd')

spark_df = spark.sql(f"""
select * from wd where Worker_Type = 'Employee'
union
select * from wd where Worker_type = 'Contingent Worker' and lower(primaryWorkEmail) 
  not in 
    (select lower(primaryWorkEmail) from {original_tbl} where Worker_Type = 'Employee' and primaryWorkEmail like '%@%' )
""")

# COMMAND ----------

# gold_spark_df = add_gold_metadata(spark_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Update

# COMMAND ----------

spark_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(original_tbl)
# write_delta_table(
#   spark, 
#   dataframe = gold_spark_df, 
#   table_name = f'{original_tbl}', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )

display(spark.sql(f"""
  merge into {original_tbl} as x 
  using main.field_learning_enablement.wd_sfdc_people_fixes as y
  on y.wd_id=x.WorkdayId
  when matched then update set primaryWorkEmail=sfdc_email,name=sfdc_name
"""))

# https://adb-2548836972759138.18.azuredatabricks.net/?o=2548836972759138#notebook/4350774126907996

# COMMAND ----------

# MAGIC %md
# MAGIC # get WD hierarchy

# COMMAND ----------

spark.sql(f"""
with manager_hierarchy_init as (
  select
    l1.name as user_name,
    l1.workdayid as user_id,
    l1.primaryWorkEmail as level1_managerid,
    l2.primaryWorkEmail as level2_managerid,
    l3.primaryWorkEmail as level3_managerid,
    l4.primaryWorkEmail as level4_managerid,
    l5.primaryWorkEmail as level5_managerid,
    l6.primaryWorkEmail as level6_managerid,
    l7.primaryWorkEmail as level7_managerid,
    l8.primaryWorkEmail as level8_managerid,
    l9.primaryWorkEmail as level9_managerid,
    
    l1.name as level1_managerName,
    l2.name as level2_managerName,
    l3.name as level3_managerName,
    l4.name as level4_managerName,
    l5.name as level5_managerName,
    l6.name as level6_managerName,
    l7.name as level7_managerName,
    l8.name as level8_managerName,
    l9.name as level9_managerName
  from
    {original_tbl} l1 
    full outer join {original_tbl} l2 on lower(l2.primaryWorkEmail) = lower(l1.manager_email) 
    full outer join {original_tbl} l3 on lower(l3.primaryWorkEmail) = lower(l2.manager_email) 
    full outer join {original_tbl} l4 on lower(l4.primaryWorkEmail) = lower(l3.manager_email) 
    full outer join {original_tbl} l5 on lower(l5.primaryWorkEmail) = lower(l4.manager_email) 
    full outer join {original_tbl} l6 on lower(l6.primaryWorkEmail) = lower(l5.manager_email) 
    full outer join {original_tbl} l7 on lower(l7.primaryWorkEmail) = lower(l6.manager_email)
    full outer join {original_tbl} l8 on lower(l8.primaryWorkEmail) = lower(l7.manager_email)
    full outer join {original_tbl} l9 on lower(l9.primaryWorkEmail) = lower(l8.manager_email)
  where 
    l1.name is not null
),


user as (
  select
    user_name,
    user_id,
    concat (
      case
        when level1_managerid is not null then concat(level1_managerid, ';')
        else ''
      END,
      case
        when level2_managerid is not null then concat(level2_managerid, ';')
        else ''
      END,
      case
        when level3_managerid is not null then concat(level3_managerid, ';')
        else ''
      END,
      case
        when level4_managerid is not null then concat(level4_managerid, ';')
        else ''
      END,
      case
        when level5_managerid is not null then concat(level5_managerid, ';')
        else ''
      END,
      case
        when level6_managerid is not null then concat(level6_managerid, ';')
        else ''
      END,
      case
        when level7_managerid is not null then concat(level7_managerid, ';')
        else ''
      END,
      case
        when level8_managerid is not null then concat(level8_managerid, ';')
        else ''
      END,
      case
        when level9_managerid is not null then concat(level9_managerid, '')
        else ''
      END
    ) as manager_hierarchy_path,
    
    concat (
      case
        when level1_managerid is not null then concat(level1_managerName, ';')
        else ''
      END,
      case
        when level2_managerid is not null then concat(level2_managerName, ';')
        else ''
      END,
      case
        when level3_managerid is not null then concat(level3_managerName, ';')
        else ''
      END,
      case
        when level4_managerid is not null then concat(level4_managerName, ';')
        else ''
      END,
      case
        when level5_managerid is not null then concat(level5_managerName, ';')
        else ''
      END,
      case
        when level6_managerid is not null then concat(level6_managerName, ';')
        else ''
      END,
      case
        when level7_managerid is not null then concat(level7_managerName, ';')
        else ''
      END,
      case
        when level8_managerid is not null then concat(level8_managerName, ';')
        else ''
      END,
      case
        when level9_managerid is not null then concat(level9_managerName, '')
        else ''
      END
    ) as manager_hierarchy_path_name
  from
    manager_hierarchy_init
  where 
    user_name is not null
)

select
  user_name,
  user_id,
  concat_ws(';',array_distinct(split(lower(case when manager_hierarchy_path not like '%;' then concat(manager_hierarchy_path,';') else manager_hierarchy_path end),';'))) as manager_hierarchy_path,
  concat_ws(';',array_distinct(split(lower(case when manager_hierarchy_path_name not like '%;' then concat(manager_hierarchy_path_name,';') else manager_hierarchy_path_name end),';'))) as manager_hierarchy_path_name
from
  user
""").createOrReplaceTempView('hierarchy')

# COMMAND ----------

# DBTITLE 1,Workday Data Transformation Script
import time 

try:
  display(spark.sql(f"""
  replace table {original_tbl} using delta as
  select  
    wd.Name,
    wd.WorkdayID,
    wd.Worker_Type,
    wd.primaryWorkEmail,
    wd.Hire_Date,
    wd.Last_Promotion_Date,
    wd.Termination_Date,
    wd.Job_Profile_Prior_To_Last_Promotion_Date,
    wd.Business_Title_Prior_To_Last_Promotion_Date,
    wd.Cost_Center,
    wd.Location,
    wd.Location_Address_Country,
    wd.Job_Profile,
    wd.Job_Level,
    wd.businessTitle,
    wd.Manager_Level_01,
    wd.Manager_Level_02,
    wd.Manager_Level_03,
    wd.Manager,
    wd.Manager_Email,
    wd.Supervisory_Organization,
    wd.Supervisory_Organization_cleaned,
    wd.Time_Zone,
    wd.Time_Zone_GMT_Factor,
    wd.Status,
    wd.Original_Hire_Date,
    wd.Job_Profile_Start_Date,
    wd.Last_Job_Req_Event_Date,
    y.wd_id,
    z.manager_hierarchy_path,
    z.manager_hierarchy_path_name,
    case
      when wd.name = 'Tony Gilbert' then 'Sales Management'
      when (
        (lower(y.manager_hierarchy_path) like '%ron@databricks.com%' or lower(y.manager_hierarchy_path) like '%arsalan@databricks.com%')
        and lower(cost_center) like '%eng%'
      )
      or cost_center like '%404%' then 'SA'
      when (
        lower(Cost_Center) like '%sales managers%'
        OR (
          lower(Cost_Center) like '%account exec%'
          AND (
            (
              lower(Job_Profile) like '%director%'
              or lower(Job_Profile) like '%manager%'
            )
            AND (
              lower(businessTitle) like '%director%'
              or lower(businessTitle) like '%manager%'
            )
          )
        )
      )
      or cost_center like '%606%' -- hq
      then 'Sales Management'
      when (
        lower(y.manager_hierarchy_path) like '%ron@databricks.com%'
        or
        lower(z.manager_hierarchy_path) like '%ron@databricks.com%'
      )
      and (
        lower(cost_center) like '%acceleration%'
        or lower(cost_center) like '%enablement%'
        or lower(cost_center) like '%gtm%'
        or lower(businesstitle) like '%acceleration%'
        or lower(businesstitle) like '%enablement%'
        or lower(businesstitle) like '%gtm%'
      ) then 'GTM'
      when lower(Cost_Center) like '%account exec%'
      and (
        (
          lower(Job_Profile) not like '%director%'
          and lower(Job_Profile) not like '%manager%'
          and lower(Job_Profile) not like '%president%'
          and lower(Job_Profile) not like '%vp%'
        )
        or (
          lower(businessTitle) not like '%director%'
          and lower(businessTitle) not like '%manager%'
          and lower(businessTitle) not like '%president%'
          and lower(businessTitle) not like '%vp%'
        )
      ) then 'AE'
      when Cost_Center like '6%' and (lower(Cost_Center) like '%bdr%' or lower(businesstitle) like '%business dev%') then 'BDR'
      when Cost_Center like '6%' and (lower(Cost_Center) like '%sdr%' or lower(businesstitle) like '%sales dev%') then 'SDR'
      when lower(Cost_Center) like '%401%'
      or lower(businesstitle) like '%business deve%' then 'BD'
      when lower(Cost_Center) like '%402%' then 'BD SA'
      when lower(Cost_Center) like '%609%' then 'Sales Ops'
      when (
        lower(businessTitle) like '%strategic partner sales specialist%'
        or lower(Cost_Center) like '%403%'
        or lower(manager) like '%tony gilbert%'
      ) then 'Specialists'
      when lower(businesstitle) like '%customer%' and lower(businesstitle) like '%success%' then 'CS'
      when lower(businesstitle) like '%cse%' or lower(businesstitle) like '%rsa%' then 'CS'
      when lower(businesstitle) like '%resident%' then 'CS'
      when lower(businesstitle) like '%partner%' or lower(businesstitle) like '%channel%' then 'BD'
      when lower(businesstitle) like '%legal%' then 'Legal'
      when lower(businesstitle) like '%product%' or lower(businesstitle) like '%design%' then 'Product'
      when lower(businesstitle) like '%marketing%' then 'Marketing'
      when lower(businesstitle) like '%professional%' and lower(businesstitle) like '%service%' then 'PS'

      when lower(get(split(cost_center, ' '),1)) like '%professional%' and lower(get(split(cost_center, ' '),2)) like '%services%' then 'PS'
      when get(split(cost_center, ' '),1) like '%CS%' then 'CS'
      when get(split(cost_center, ' '),1) like '%SA%' then 'SA'

      when lower(y.manager_hierarchy_path) like '%david.meyer@databricks.com%' or lower(y.manager_hierarchy_path) like '%adam.conway@databricks.com%' or
           lower(z.manager_hierarchy_path) like '%david.meyer@databricks.com%' or lower(z.manager_hierarchy_path) like '%adam.conway@databricks.com%' then 'Product'
      when lower(y.manager_hierarchy_path) like '%amy.reichanadter@databricks.com%' or lower(z.manager_hierarchy_path) like '%amy.reichanadter@databricks.com%' then 'HR'
      when lower(y.manager_hierarchy_path) like '%dave.conte@databricks.com%' or lower(z.manager_hierarchy_path) like '%dave.conte@databricks.com%' then 'Finance'
      when lower(y.manager_hierarchy_path) like '%hatim@databricks.com%' or lower(z.manager_hierarchy_path) like '%hatim@databricks.com%' then 'CS'
      when lower(y.manager_hierarchy_path) like '%rick@databricks.com%' or lower(z.manager_hierarchy_path) like '%rick@databricks.com%' then 'Marketing'
      when lower(y.manager_hierarchy_path) like '%ron@databricks.com%' or lower(z.manager_hierarchy_path) like '%ron@databricks.com%' then 'Sales'
      when lower(y.manager_hierarchy_path) like '%vinod.marur@databricks.com%' or lower(z.manager_hierarchy_path) like '%vinod.marur@databricks.com%' then 'Engineering'

      when lower(wd.businessTitle) like '%engine%' then 'Engineering'
      when lower(wd.businessTitle) like '%customer%' then 'CS'
      when lower(wd.businessTitle) like '%recruit%' then 'HR'
      when lower(wd.businessTitle) like '%account exec%' then 'AE'
      when lower(wd.businessTitle) like '%solution%' and lower(wd.businessTitle) like '%arch%' then 'SA'

      when get(split(cost_center, ' '),1) like '%Engineer%' then 'Engineering'
      when get(split(cost_center, ' '),1) like '%Security%' then 'IT'
      when get(split(cost_center, ' '),1) = 'IT' then 'IT'
      when get(split(cost_center, ' '),1) like '%Education%' then 'Education'
      when get(split(cost_center, ' '),1) like '%HR%' then 'HR'
      when get(split(cost_center, ' '),1) like '%Recruit%' then 'HR'

      else 'NO CATEGORY'
    end as category,
    case
      when lower(y.manager_hierarchy_path) like '%david.meyer@databricks.com%' or lower(y.manager_hierarchy_path) like '%adam.conway@databricks.com%' or
           lower(z.manager_hierarchy_path) like '%david.meyer@databricks.com%' or lower(z.manager_hierarchy_path) like '%adam.conway@databricks.com%' then 'Product'
      when lower(y.manager_hierarchy_path) like '%amy.reichanadter@databricks.com%' or lower(z.manager_hierarchy_path) like '%amy.reichanadter@databricks.com%' then 'HR'
      when lower(y.manager_hierarchy_path) like '%dave.conte@databricks.com%' or lower(z.manager_hierarchy_path) like '%dave.conte@databricks.com%' then 'Finance'
      when lower(y.manager_hierarchy_path) like '%hatim@databricks.com%' or lower(z.manager_hierarchy_path) like '%hatim@databricks.com%' then 'Customer Success'
      when lower(y.manager_hierarchy_path) like '%rick@databricks.com%' or lower(z.manager_hierarchy_path) like '%rick@databricks.com%' then 'Marketing'
      when lower(y.manager_hierarchy_path) like '%ron@databricks.com%' or lower(y.manager_hierarchy_path) like '%arsalan@databricks.com%' or
           lower(z.manager_hierarchy_path) like '%ron@databricks.com%' or lower(z.manager_hierarchy_path) like '%arsalan@databricks.com%' then 'Sales'
      when lower(y.manager_hierarchy_path) like '%vinod.marur@databricks.com%' or lower(z.manager_hierarchy_path) like '%vinod.marur@databricks.com%' then 'Engineering'
    end as department
  from
    {original_tbl} wd
  full outer join (select wd_id,manager_hierarchy_path from main.field_learning_enablement.wd_sfdc_mapping_table) y on y.wd_id = wd.workdayId
  full outer join (select user_id,manager_hierarchy_path,manager_hierarchy_path_name from hierarchy) z on z.user_id = wd.workdayId
  where wd.name is not null
  """))

except:
  time.sleep(60)
  print('re-trying')
  
  display(spark.sql(f"""
  replace table {original_tbl} using delta as
  select  
    wd.Name,
    wd.WorkdayID,
    wd.Worker_Type,
    wd.primaryWorkEmail,
    wd.Hire_Date,
    wd.Last_Promotion_Date,
    wd.Termination_Date,
    wd.Job_Profile_Prior_To_Last_Promotion_Date,
    wd.Business_Title_Prior_To_Last_Promotion_Date,
    wd.Cost_Center,
    wd.Location,
    wd.Location_Address_Country,
    wd.Job_Profile,
    wd.Job_Level,
    wd.businessTitle,
    wd.Manager_Level_01,
    wd.Manager_Level_02,
    wd.Manager_Level_03,
    wd.Manager,
    wd.Manager_Email,
    wd.Supervisory_Organization,
    wd.Supervisory_Organization_cleaned,
    wd.Time_Zone,
    wd.Time_Zone_GMT_Factor,
    wd.Status,
    wd.Original_Hire_Date,
    wd.Job_Profile_Start_Date,
    wd.Last_Job_Req_Event_Date,
    y.wd_id,
    z.manager_hierarchy_path,
    z.manager_hierarchy_path_name,
    case
      when wd.name = 'Tony Gilbert' then 'Sales Management'
      when (
        (lower(y.manager_hierarchy_path) like '%ron@databricks.com%' or lower(y.manager_hierarchy_path) like '%arsalan@databricks.com%')
        and lower(cost_center) like '%eng%'
      )
      or cost_center like '%404%' then 'SA'
      when (
        lower(Cost_Center) like '%sales managers%'
        OR (
          lower(Cost_Center) like '%account exec%'
          AND (
            (
              lower(Job_Profile) like '%director%'
              or lower(Job_Profile) like '%manager%'
            )
            AND (
              lower(businessTitle) like '%director%'
              or lower(businessTitle) like '%manager%'
            )
          )
        )
      )
      or cost_center like '%606%' -- hq
      then 'Sales Management'
      when (
        lower(y.manager_hierarchy_path) like '%ron@databricks.com%'
        or
        lower(z.manager_hierarchy_path) like '%ron@databricks.com%'
      )
      and (
        lower(cost_center) like '%acceleration%'
        or lower(cost_center) like '%enablement%'
        or lower(cost_center) like '%gtm%'
        or lower(businesstitle) like '%acceleration%'
        or lower(businesstitle) like '%enablement%'
        or lower(businesstitle) like '%gtm%'
      ) then 'GTM'
      when lower(Cost_Center) like '%account exec%'
      and (
        (
          lower(Job_Profile) not like '%director%'
          and lower(Job_Profile) not like '%manager%'
          and lower(Job_Profile) not like '%president%'
          and lower(Job_Profile) not like '%vp%'
        )
        or (
          lower(businessTitle) not like '%director%'
          and lower(businessTitle) not like '%manager%'
          and lower(businessTitle) not like '%president%'
          and lower(businessTitle) not like '%vp%'
        )
      ) then 'AE'
      when Cost_Center like '6%' and (lower(Cost_Center) like '%bdr%' or lower(businesstitle) like '%business dev%') then 'BDR'
      when Cost_Center like '6%' and (lower(Cost_Center) like '%sdr%' or lower(businesstitle) like '%sales dev%') then 'SDR'
      when lower(Cost_Center) like '%401%'
      or lower(businesstitle) like '%business deve%' then 'BD'
      when lower(Cost_Center) like '%402%' then 'BD SA'
      when lower(Cost_Center) like '%609%' then 'Sales Ops'
      when (
        lower(businessTitle) like '%strategic partner sales specialist%'
        or lower(Cost_Center) like '%403%'
        or lower(manager) like '%tony gilbert%'
      ) then 'Specialists'
      when lower(businesstitle) like '%customer%' and lower(businesstitle) like '%success%' then 'CS'
      when lower(businesstitle) like '%cse%' or lower(businesstitle) like '%rsa%' then 'CS'
      when lower(businesstitle) like '%resident%' then 'CS'
      when lower(businesstitle) like '%partner%' or lower(businesstitle) like '%channel%' then 'BD'
      when lower(businesstitle) like '%legal%' then 'Legal'
      when lower(businesstitle) like '%product%' or lower(businesstitle) like '%design%' then 'Product'
      when lower(businesstitle) like '%marketing%' then 'Marketing'
      when lower(businesstitle) like '%professional%' and lower(businesstitle) like '%service%' then 'PS'

      when lower(get(split(cost_center, ' '),1)) like '%professional%' and lower(get(split(cost_center, ' '),2)) like '%services%' then 'PS'
      when get(split(cost_center, ' '),1) like '%CS%' then 'CS'
      when get(split(cost_center, ' '),1) like '%SA%' then 'SA'

      when lower(y.manager_hierarchy_path) like '%david.meyer@databricks.com%' or lower(y.manager_hierarchy_path) like '%adam.conway@databricks.com%' or
           lower(z.manager_hierarchy_path) like '%david.meyer@databricks.com%' or lower(z.manager_hierarchy_path) like '%adam.conway@databricks.com%' then 'Product'
      when lower(y.manager_hierarchy_path) like '%amy.reichanadter@databricks.com%' or lower(z.manager_hierarchy_path) like '%amy.reichanadter@databricks.com%' then 'HR'
      when lower(y.manager_hierarchy_path) like '%dave.conte@databricks.com%' or lower(z.manager_hierarchy_path) like '%dave.conte@databricks.com%' then 'Finance'
      when lower(y.manager_hierarchy_path) like '%hatim@databricks.com%' or lower(z.manager_hierarchy_path) like '%hatim@databricks.com%' then 'CS'
      when lower(y.manager_hierarchy_path) like '%rick@databricks.com%' or lower(z.manager_hierarchy_path) like '%rick@databricks.com%' then 'Marketing'
      when lower(y.manager_hierarchy_path) like '%ron@databricks.com%' or lower(z.manager_hierarchy_path) like '%ron@databricks.com%' then 'Sales'
      when lower(y.manager_hierarchy_path) like '%vinod.marur@databricks.com%' or lower(z.manager_hierarchy_path) like '%vinod.marur@databricks.com%' then 'Engineering'

      when lower(wd.businessTitle) like '%engine%' then 'Engineering'
      when lower(wd.businessTitle) like '%customer%' then 'CS'
      when lower(wd.businessTitle) like '%recruit%' then 'HR'
      when lower(wd.businessTitle) like '%account exec%' then 'AE'
      when lower(wd.businessTitle) like '%solution%' and lower(wd.businessTitle) like '%arch%' then 'SA'

      when get(split(cost_center, ' '),1) like '%Engineer%' then 'Engineering'
      when get(split(cost_center, ' '),1) like '%Security%' then 'IT'
      when get(split(cost_center, ' '),1) = 'IT' then 'IT'
      when get(split(cost_center, ' '),1) like '%Education%' then 'Education'
      when get(split(cost_center, ' '),1) like '%HR%' then 'HR'
      when get(split(cost_center, ' '),1) like '%Recruit%' then 'HR'

      else 'NO CATEGORY'
    end as category,
    case
      when lower(y.manager_hierarchy_path) like '%david.meyer@databricks.com%' or lower(y.manager_hierarchy_path) like '%adam.conway@databricks.com%' or
           lower(z.manager_hierarchy_path) like '%david.meyer@databricks.com%' or lower(z.manager_hierarchy_path) like '%adam.conway@databricks.com%' then 'Product'
      when lower(y.manager_hierarchy_path) like '%amy.reichanadter@databricks.com%' or lower(z.manager_hierarchy_path) like '%amy.reichanadter@databricks.com%' then 'HR'
      when lower(y.manager_hierarchy_path) like '%dave.conte@databricks.com%' or lower(z.manager_hierarchy_path) like '%dave.conte@databricks.com%' then 'Finance'
      when lower(y.manager_hierarchy_path) like '%hatim@databricks.com%' or lower(z.manager_hierarchy_path) like '%hatim@databricks.com%' then 'Customer Success'
      when lower(y.manager_hierarchy_path) like '%rick@databricks.com%' or lower(z.manager_hierarchy_path) like '%rick@databricks.com%' then 'Marketing'
      when lower(y.manager_hierarchy_path) like '%ron@databricks.com%' or lower(y.manager_hierarchy_path) like '%arsalan@databricks.com%' or
           lower(z.manager_hierarchy_path) like '%ron@databricks.com%' or lower(z.manager_hierarchy_path) like '%arsalan@databricks.com%' then 'Sales'
      when lower(y.manager_hierarchy_path) like '%vinod.marur@databricks.com%' or lower(z.manager_hierarchy_path) like '%vinod.marur@databricks.com%' then 'Engineering'
    end as department
  from
    {original_tbl} wd
  -- full outer join (select wd_id,manager_hierarchy_path from users.liam_clifford.master_wd_sfdc_mapping_table) y on y.wd_id = wd.workdayId
  -- LC BLOCKED OFF ABOVE 08.24.23 BECAUSE TABLE BELOW NEVER HAD FIELDS (AND liam.master_wd_sfdc_mapping_table was dropped due to HMS>UC MIGRATION)
  full outer join (select wd_id,manager_hierarchy_path from main.field_learning_enablement.wd_sfdc_mapping_table) y on y.wd_id = wd.workdayId
  full outer join (select user_id,manager_hierarchy_path,manager_hierarchy_path_name from hierarchy) z on z.user_id = wd.workdayId
  where wd.name is not null
  """))

# COMMAND ----------

# DBTITLE 1,Manager Hierarchy Query Extractor
df = spark.sql(f"""

select * from (

    with init as (
    select
        name,
        workdayID,
        primaryWorkEmail as email,
        Manager_Email,
        Manager,
        manager_hierarchy_path,
        split(manager_hierarchy_path, ';') as manager_path_array,
        split(manager_hierarchy_path_name, ';') as manager_path_array_name,
        case
          when position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) != 0 then position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) -1
        end as 6th_level,
        case
          when position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) != 0 then position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) -2
        end as 5th_level,
        case
          when position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) != 0 then position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) -3
        end as 4th_level,
        case
          when position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) != 0 then position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) -4
        end as 3rd_level,
        case
          when position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) != 0 then position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) -5
        end as 2nd_level,
        case
          when position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) != 0 then position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) -6
        end as 1st_level,
        case
          when position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) != 0 then position(';ali@databricks.com;', manager_hierarchy_path) - length(
            replace(
              substring(
                manager_hierarchy_path,
                0,
                position(';ali@databricks.com;', manager_hierarchy_path)
              ),
              ';',
              ''
            )
          ) -7
        end as 0_level,






        case
          when position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) != 0 then position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) -1
        end as 6th_level_name,
        case
          when position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) != 0 then position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) -2
        end as 5th_level_name,
        case
          when position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) != 0 then position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) -3
        end as 4th_level_name,
        case
          when position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) != 0 then position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) -4
        end as 3rd_level_name,
        case
          when position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) != 0 then position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) -5
        end as 2nd_level_name,
        case
          when position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) != 0 then position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) -6
        end as 1st_level_name,
        case
          when position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) != 0 then position('ali ghodsi;', manager_hierarchy_path_name) - length(
            replace(
              substring(
                manager_hierarchy_path_name,
                0,
                position('ali ghodsi;', manager_hierarchy_path_name)
              ),
              ';',
              ''
            )
          ) -7
        end as 0_level_name

    from {original_tbl}
    ),

    init_init as (

    select
        name,
        workdayID,
        manager_hierarchy_path,
        manager_path_array_name,
        case
          when lower(get(manager_path_array,6th_level)) != lower(Email) then get(manager_path_array,6th_level)
        end as 6th_level_manager,
        case
          when lower(get(manager_path_array,5th_level)) != lower(Email) then get(manager_path_array,5th_level)
        end as 5th_level_manager,
        case
          when lower(get(manager_path_array,4th_level)) != lower(Email) then get(manager_path_array,4th_level)
        end as 4th_level_manager,
        case
          when lower(get(manager_path_array,3rd_level)) != lower(Email) then get(manager_path_array,3rd_level)
        end as 3rd_level_manager,
        case
          when lower(get(manager_path_array,2nd_level)) != lower(Email) then get(manager_path_array,2nd_level)
        end as 2nd_level_manager,
        case
          when lower(get(manager_path_array,1st_level)) != lower(Email) then get(manager_path_array,1st_level)
        end as 1st_level_manager,
        case
          when lower(get(manager_path_array,0_level)) != lower(Email) then get(manager_path_array,0_level)
          else manager_email
        end as init_level_manager,


        case
          when lower(get(manager_path_array,6th_level)) != lower(Email) then get(manager_path_array_name,6th_level_name)
        end as 6th_level_manager_name,
        case
          when lower(get(manager_path_array,5th_level)) != lower(Email) then get(manager_path_array_name,5th_level_name)
        end as 5th_level_manager_name,
        case
          when lower(get(manager_path_array,4th_level)) != lower(Email) then get(manager_path_array_name,4th_level_name)
        end as 4th_level_manager_name,
        case
          when lower(get(manager_path_array,3rd_level)) != lower(Email) then get(manager_path_array_name,3rd_level_name)
        end as 3rd_level_manager_name,
        case
          when lower(get(manager_path_array,2nd_level)) != lower(Email) then get(manager_path_array_name,2nd_level_name)
        end as 2nd_level_manager_name,
        case
          when lower(get(manager_path_array,1st_level)) != lower(Email) then get(manager_path_array_name,1st_level_name)
        end as 1st_level_manager_name,
        case
          when lower(get(manager_path_array,0_level)) != lower(Email) then get(manager_path_array_name,0_level_name)
          else lower(manager)
        end as init_level_manager_name
    from init 
    )

    select distinct
     wd.*

    ,x.6th_level_manager
    ,x.5th_level_manager
    ,x.4th_level_manager
    ,x.3rd_level_manager
    ,x.2nd_level_manager
    ,x.1st_level_manager
    ,x.init_level_manager

    ,x.6th_level_manager_name
    ,x.5th_level_manager_name
    ,x.4th_level_manager_name
    ,x.3rd_level_manager_name
    ,x.2nd_level_manager_name
    ,x.1st_level_manager_name
    ,x.init_level_manager_name

    from init_init x
    join {original_tbl} wd
      on wd.workdayID=x.workdayID
  )

""")

dmt_v2(df=df
      ,uc_table=prod_table_name
      ,transformationType='create or replace'
      ,mergeType=None
      ,removeSpecialCharsFromCols =False
      ,doNotDropExistingTable=True
      ,partitionByField=None
      ,uc_catalog='main'
      ,uc_schema='field_learning_enablement'
      ,deltaLogRetentionDurationInDays=60
      ,skip_hms_check=True)

# COMMAND ----------

try:
    spark.sql("""
    with init as (
    select 
       wd.name
      ,wd.primaryWorkEmail
      ,wd.location
      ,wd.hire_date
      ,wd.businessTitle
      ,wd.manager
      ,wd.cost_center
      ,wd.WorkdayID as wd_id
      ,x.sfdc_id
      ,x.is_sdr_or_ae
      ,x.is_manager
      ,x.is_vp
      ,x.is_director
      ,x.wd_manager_hierarchy_path as manager_hierarchy_path
      -- ,case when TRY_CAST(x.max_wave1_completed_date_wd as date) is null then TRY_CAST(x.docebo_wave_1_completion_date as date) else TRY_CAST(x.max_wave1_completed_date_wd as date) end wave_1_date
      -- ,case when TRY_CAST(x.max_wave3_completed_date_wd as date) is null then TRY_CAST(x.docebo_wave_3_completion_date as date) else TRY_CAST(x.max_wave3_completed_date_wd as date) end wave_3_date
      ,jaro_winkler_similarity(lower(x.wd_email),lower(wd.primaryWorkEmail)) as jaro_winkler_similarity
    from
      users.liam_clifford.wd_r wd
      join (select 
                 * 
              from users.liam_clifford.employees_r 
             where 
            lower(sfdc_name) not like '%(old)%'
        and lower(sfdc_name) not like '%(tbh)%'
        and lower(sfdc_name) not like 'xx%'
        and lower(sfdc_name) not like 'zz%'
        and lower(sfdc_name) not like 'api%'
        and lower(sfdc_name) not like '% director%'
        and lower(sfdc_name) not like 'databricks%') x 
      where 
        (wd.status=true or lower(wd.primaryWorkEmail) in (select lower(email) from sheet_snap))
         and wd.worker_type in ('Employee')
    )
    select distinct * from init where jaro_winkler_similarity >=.975 order by jaro_winkler_similarity asc
    """).createOrReplaceTempView('wd_sfdc_table')
    display(spark.sql("""create or replace table users.liam_clifford.wd_sfdc_mapping_table using delta as select * from wd_sfdc_table"""))
    display(spark.sql("""optimize users.liam_clifford.wd_sfdc_mapping_table"""))
    display(spark.sql("""vacuum users.liam_clifford.wd_sfdc_mapping_table"""))
  except Exception as e:
    print(e)
    print('unable to update wd.mapping_table')

# COMMAND ----------

display(
    spark.sql(
        f"""create or replace table {partially_masked_tbl} using delta as 
        select * except (termination_date,last_promotion_date,Job_Level) 
        from users.liam_clifford.{prod_table_name}"""
    )
)

# COMMAND ----------

df = spark.sql(f"""
               select * except (termination_date,last_promotion_date,Job_Level) 
               from {focus_database_name}.{prod_table_name}
               
""")

# COMMAND ----------

display(
  df
    .filter(F.col("primaryWorkEmail").like("%leah%"))
)