# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      N/A  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      N/A \
# MAGIC **Target:**             blacklist_domains \
# MAGIC **Description:**     This notebook creates updates lab subscription end dates \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated when needed
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

import sys
from datetime import datetime, timedelta
from pprint import pprint
import requests
import json
from urllib.parse import quote_plus as urlencode
import re
from pyspark.sql import Row

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

sys.path.insert(0, focus_data_utils_path)

from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %run "/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

# MAGIC %run "/Users/nathan.zukoff@databricks.com/Docebo Auth"

# COMMAND ----------

headers, bearer_token = createHeaders('production')

# COMMAND ----------

# base_url = 'https://databrickssandbox.docebosaas.com'
base_url = 'https://databricks.docebosaas.com'

# COMMAND ----------

# DBTITLE 1,Subscription Records Fetcher
def get_subscription_records():
  subscriptions = []
  cont = True
  page = 1
  while cont:
    try:
      url = f"{base_url}/learn/v1/sub_record?page={page}"
      r = requests.get(url, headers=headers)
      if r.status_code == 200:
          data = r.json()['data']['items']
          subscriptions.extend(data)
          page += 1
          if page == r.json()['data']['total_page_count']+1:
            cont = False
    except Exception as e:
      print(e)
  return subscriptions

# COMMAND ----------

# DBTITLE 1,Subscription Records Retrieval
# all_subscriptions = get_subscription_records()

# COMMAND ----------

def convert_to_df(data):
  rows = [Row(**obj) for obj in data]

  # schema = spark.createDataFrame(rows).schema

  df = spark.createDataFrame(rows)

  return df

# COMMAND ----------

# DBTITLE 1,Subscription Records Fetcher
all_subscriptions = get_subscription_records()

# COMMAND ----------

all_subs = [{
  'name': item['name'], 
  'email': item['email'], 
  'sold_to': item['sold_to'], 
  'plan_name': item['plan_name'], 
  'start_date': item['start_date'], 
  'end_date': item['end_date'], 
  'learner_user_id': item['object_id'],
  'price': item['price'],
  'code': item['code']
  } for item in all_subscriptions]

# COMMAND ----------

all_subscriptions_df = convert_to_df(all_subs)

# COMMAND ----------

# DBTITLE 1,Databricks Labs Subscription Filter
labs_subscriptions = (
  all_subscriptions_df
    .filter(F.col("plan_name") == "Databricks Academy Labs Subscription")
)

# COMMAND ----------

labs_subscriptions_gold = add_gold_metadata(labs_subscriptions)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = labs_subscriptions_gold, 
  table_name = f'{focus_database_name}.academy_labs_users', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

