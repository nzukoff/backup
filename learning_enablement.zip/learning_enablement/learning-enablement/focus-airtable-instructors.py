# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for instructor utilzation from Airtable \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Workspace/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

# spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import requests

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

import pandas as pd


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

def convertToDF(data):
  """
    data is a list of objects
  """
  json_obj = {}
  
  json_obj['field'] = data

  df = pd.json_normalize(json_obj['field'])
  lst = list(df)
  df[lst] = df[lst].astype(str)

  spark_df = (
    spark
      .createDataFrame(df)
  )
  return spark_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### Instructors

# COMMAND ----------

airtable_pat = dbutils.secrets.get('ldr-airtable', 'airtable-token')

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Instructors?view=All%20Resources%20Logfood"
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

instructor_records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()


instructor_records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  instructor_records += response_json['records']

# COMMAND ----------

df = convertToDF(instructor_records)

# COMMAND ----------

df.createOrReplaceTempView('instructors')

# COMMAND ----------

instructor_df = spark.sql('''
with pre as (
select
  `id`,
  `createdTime`,
  `fields.Available hours` as available_hours,
  `fields.Daily Rate: Half-Day Class` as daily_rate_half_day_class,
  `fields.Instructor Email` as instructor_email,
  `fields.Certifications` as certifications,
  `fields.Instructor Name` as instructor_name,
  `fields.Region` as region,
  `fields.Country` as country,
  `fields.Languages` as languages,
  `fields.Home Timezone` as home_timezone,
  -- `fields.Notes` as notes,
  `fields.Interested Courses` as interested_courses,
  -- `fields.Phone Number` as phone_number,
  `fields.Mailing Address` as mailing_address,
  `fields.Instructor Schedule` as instructor_schedule,
  `fields.Status` as status,
  `fields.Instructor Skills` as instructor_skills,
  `fields.Organization Name` as organization_name,
  `fields.Instructor Type` as instructor_type,
  `fields.ATP Scheduling Contact` as atp_scheduling_contact,
  `fields.ATP or Internal` as atp_or_internal,
  `fields.Approved Courses` as approved_courses,
  `fields.Provider (from Schedule)` as provider_from_schedule,
  -- `fields.Agreements` as agreements,
  -- `fields.Documents (Agreeements, Resumes, Teach Back Forms, etc.)` as agreements,
  `fields.Teaching Timezones` as teaching_timezones,
  -- `fields.Instructor Onboarding Checklist` as instructor_onboarding_checklist,
  `fields.TA Schedule` as ta_schedule,
  `fields.ILT (Instructor+TA) Schedule` as ilt_schedule_instructor_ta,
  `fields.End Date (from ILT (Instructor+TA) Schedule)` as end_date_from_ilt_schedule_instructor_ta,
  `fields.Start Date (from ILT (Instructor+TA) Schedule)` as start_date_from_ilt_schedule_instructor_ta,
  `fields.Daily Rate: Public Class` as daily_rate_public_class,
  `fields.Daily Rate: Private Class` as daily_rate_private_class,
  `fields.Location` as location,
  -- `fields.Resume` as resume,
  `fields.Class Shadow` as class_shadow,
  `fields.Training Type (from Class Shadow)` as training_type_from_class_shadow,
  `fields.Provider (from Class Shadow)` as provider_from_class_shadow,
  `fields.Created Date (from Class Shadow)` as created_date_from_class_shadow,
  `fields.ILT Name (from Class Shadow)` as ilt_name_from_class_shadow,
  `fields.Citizenship` as citizenship,
  `fields.Champion Trainer Certified` as champion_trainer_certified,
  -- `fields.Onboarding Checklist` as onboarding_checklist,
  `fields.Onsite Instructor Expenses` as onsite_instructor_expenses
  -- `fields.SFDC Resource ID` as sfdc_resource_id
from instructors
)

select 
  id,
  createdTime, 
  case when available_hours in ('nan', 'NaN') then null else available_hours end as available_hours,
  case when daily_rate_half_day_class in ('nan', 'NaN') then null else daily_rate_half_day_class end as daily_rate_half_day_class,
  case when instructor_email in ('nan', 'NaN') then null else instructor_email end as instructor_email,
  case when certifications in ('nan', 'NaN') then null else certifications end as certifications,
  case when instructor_name in ('nan', 'NaN') then null else instructor_name end as instructor_name,
  case when region in ('nan', 'NaN') then null else region end as region,
  case when country in ('nan', 'NaN') then null else country end as country,
  case when languages in ('nan', 'NaN') then null else languages end as languages,
  case when home_timezone in ('nan', 'NaN') then null else home_timezone end as home_timezone,
  -- case when notes in ('nan', 'NaN') then null else notes end as notes,
  case when interested_courses in ('nan', 'NaN') then null else interested_courses end as interested_courses,
  -- case when phone_number in ('nan', 'NaN') then null else phone_number end as phone_number,
  case when mailing_address in ('nan', 'NaN') then null else mailing_address end as mailing_address,
  case when instructor_schedule in ('nan', 'NaN') then null else instructor_schedule end as instructor_schedule,
  case when status in ('nan', 'NaN') then null else status end as status,
  case when instructor_skills in ('nan', 'NaN') then null else instructor_skills end as instructor_skills,
  case when organization_name in ('nan', 'NaN') then null else organization_name end as organization_name,
  case when instructor_type in ('nan', 'NaN') then null else instructor_type end as instructor_type,
  case when atp_scheduling_contact in ('nan', 'NaN') then null else atp_scheduling_contact end as atp_scheduling_contact,
  case when atp_or_internal in ('nan', 'NaN') then null else atp_or_internal end as atp_or_internal,
  case when approved_courses in ('nan', 'NaN') then null else approved_courses end as approved_courses,
  case when provider_from_schedule in ('nan', 'NaN') then null else provider_from_schedule end as provider_from_schedule,
  -- case when agreements in ('nan', 'NaN') then null else agreements end as agreements,
  case when teaching_timezones in ('nan', 'NaN') then null else teaching_timezones end as teaching_timezones,
  -- case when instructor_onboarding_checklist in ('nan', 'NaN') then null else instructor_onboarding_checklist end as instructor_onboarding_checklist,
  case when ta_schedule in ('nan', 'NaN') then null else ta_schedule end as ta_schedule,
  case when ilt_schedule_instructor_ta in ('nan', 'NaN') then null else ilt_schedule_instructor_ta end as ilt_schedule_instructor_ta,
  case when end_date_from_ilt_schedule_instructor_ta in ('nan', 'NaN') then null else end_date_from_ilt_schedule_instructor_ta end as end_date_from_ilt_schedule_instructor_ta,
  case when start_date_from_ilt_schedule_instructor_ta in ('nan', 'NaN') then null else start_date_from_ilt_schedule_instructor_ta end as start_date_from_ilt_schedule_instructor_ta,
  case when daily_rate_public_class in ('nan', 'NaN') then null else daily_rate_public_class end as daily_rate_public_class,
  case when daily_rate_private_class in ('nan', 'NaN') then null else daily_rate_private_class end as daily_rate_private_class,
  case when location in ('nan', 'NaN') then null else location end as location,
  -- case when resume in ('nan', 'NaN') then null else resume end as resume,
  case when class_shadow in ('nan', 'NaN') then null else class_shadow end as class_shadow,
  case when training_type_from_class_shadow in ('nan', 'NaN') then null else training_type_from_class_shadow end as training_type_from_class_shadow,
  case when provider_from_class_shadow in ('nan', 'NaN') then null else provider_from_class_shadow end as provider_from_class_shadow,
  case when created_date_from_class_shadow in ('nan', 'NaN') then null else created_date_from_class_shadow end as created_date_from_class_shadow,
  case when ilt_name_from_class_shadow in ('nan', 'NaN') then null else ilt_name_from_class_shadow end as ilt_name_from_class_shadow,
  case when citizenship in ('nan', 'NaN') then null else citizenship end as citizenship,
  case when champion_trainer_certified in ('nan', 'NaN') then null else champion_trainer_certified end as champion_trainer_certified,
  -- case when onboarding_checklist in ('nan', 'NaN') then null else onboarding_checklist end as onboarding_checklist,
  case when onsite_instructor_expenses in ('nan', 'NaN') then null else onsite_instructor_expenses end as onsite_instructor_expenses
  -- case when sfdc_resource_id in ('nan', 'NaN') then null else sfdc_resource_id end as sfdc_resource_id
from pre
''')

# COMMAND ----------

instructor_df_gold = add_gold_metadata(instructor_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = instructor_df_gold, 
  table_name = f'{focus_database_name}.airtable_instructors', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)