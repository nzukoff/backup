# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md # Learners

# COMMAND ----------

# DBTITLE 1,Learner Data Aggregation Script
learners_df = spark.sql('''
  with learner_data as (
    select
      "Total Unique Learners" as metric,
      fiscalYear,
      fq2,
      case
        when audience in (
          "Partner",
          "Partner Other",
          "Microsoft",
          "Microsoft Other"
        ) then "Partner"
        else audience
      end as audience,
      updated_account_id,
      region_derived,
      business_unit,
      sales_subregion_level_1,
      count (distinct learner_user_id) as learners
    from
      main.field_learning_enablement.all_learners
    where
      dataset = "net new learners"
      and processDate =(
        select
          max(processDate)
        from
          main.field_learning_enablement.all_learners
      )
    group by
      all
  ),
  prep_set_1 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      audience as grain_lvl_1,
      "Overall" as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(learners) as total_learners
    from
      learner_data
    group by
      all
  ),
  prep_set_2 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Overall" as grain_lvl_1,
      "Overall" as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(learners) as total_learners
    from
      learner_data
    group by
      all
  ),
  prep_set_3 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Customer" as grain_lvl_1,
      business_unit as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(learners) as total_learners
    from
      learner_data
    where
      audience = "Customer"
    group by
      all
  ),
  prep_set_4 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Customer" as grain_lvl_1,
      business_unit as grain_lvl_2,
      sales_subregion_level_1 as grain_lvl_3,
      sum(learners) as total_learners
    from
      learner_data
    where
      audience = "Customer"
    group by
      all
  ),
  prep_set_5 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Partner" as grain_lvl_1,
      nvl(region_derived, "Unknown") as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(learners) as total_learners
    from
      learner_data
    where
      audience = "Partner"
    group by
      all
  ),
  learner_goals as (
    select
      *
    from
      main.field_learning_enablement.learning_enablement_okr_goals
    where
      fq2 >= "25-Q1"
      and metric = "Total Unique Learners"
      and processDate =(
        Select
          max(processDate)
        from
          main.field_learning_enablement.learning_enablement_okr_goals
      )
  ),
  goal_prep_set_1 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      audience as grain_lvl_1,
      "Overall" as grain_lvl_2,
      "Overall" as grain_lvl_3,
      goal as target
    from
      learner_goals
    where
      audience in (
        "Partner",
        "Customer",
        "Customer Other",
        "Employee"
      )
    and value="NA"
    group by
      all
  ),
  goal_prep_set_2 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      audience as grain_lvl_1,
      "Overall" as grain_lvl_2,
      "Overall" as grain_lvl_3,
      goal as target
    from
      learner_goals
    where
      audience in ("Overall")
    group by
      all
  ),
  goal_prep_set_3 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Customer" as grain_lvl_1,
      value as grain_lvl_2,
      "Overall" as grain_lvl_3,
      goal as target
    from
      learner_goals
    where
      audience in ("BU")
    group by
      all
  ),
  goal_prep_set_4 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Customer" as grain_lvl_1,
      case
        when value in ("DNB", "EDNB Verts","EE","EDNB ENT Tech","Startup") then "AMER Emerging"
        when value in ("CME", "LATAM", "MFG", "Retail") then "AMER Enterprise"
        when value in ("CAN", "PS", "FINS", "HLS") then "AMER Regulated Industries"
        when value in ("ANZ", "Asean + GCR", "India", "Japan", "Korea") then "APJ"
        when value in ("Central", "Northern", "SEMEA", "Emerging") then "EMEA"
      end as grain_lvl_2,

      
      value as grain_lvl_3,
      goal as target
    from
      learner_goals
    where
      audience in ("BU+1")
    group by
      all
  ),
  goal_prep_set_5 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Partner" as grain_lvl_1,
      value as grain_lvl_2,
      "Overall" as grain_lvl_3,
      goal as target
    from
      learner_goals
    where
      audience in ("Partner")
    and value<>"NA"
    group by
      all
  ),
  final_goals as (
    select
      *
    from
      goal_prep_set_1
    union all
    select
      *
    from
      goal_prep_set_2
    union all
    select
      *
    from
      goal_prep_set_3
    union all
    select
      *
    from
      goal_prep_set_4
      union all
    select
      *
    from
      goal_prep_set_5
  ),
  final_actuals as (
    select
      metric,
      fiscalyear,
      timeframe,
      grain_lvl_1,
      grain_lvl_2,
      grain_lvl_3,
      sum(total_learners) over (
        partition by grain_lvl_1
        order by
          timeframe
      ) as cumulative_learners
    from
      prep_Set_1
    group by
      1,
      2,
      3,
      4,
      5,
      6,
      total_learners
    union all
    select
      metric,
      fiscalyear,
      timeframe,
      grain_lvl_1,
      grain_lvl_2,
      grain_lvl_3,
      sum(total_learners) over (
        partition by grain_lvl_1
        order by
          timeframe
      ) as cumulative_learners
    from
      prep_Set_2
    group by
      1,
      2,
      3,
      4,
      5,
      6,
      total_learners
    union all
    select
      metric,
      fiscalyear,
      timeframe,
      grain_lvl_1,
      grain_lvl_2,
      grain_lvl_3,
      sum(total_learners) over (
        partition by grain_lvl_1,
        grain_lvl_2
        order by
          timeframe
      ) as cumulative_learners
    from
      prep_Set_3
    group by
      1,
      2,
      3,
      4,
      5,
      6,
      total_learners
    union all
    select
      metric,
      fiscalyear,
      timeframe,
      grain_lvl_1,
      grain_lvl_2,
      grain_lvl_3,
      sum(total_learners) over (
        partition by grain_lvl_1,
        grain_lvl_2,
        grain_lvl_3
        order by
          timeframe
      ) as cumulative_learners
    from
      prep_Set_4
    group by
      1,
      2,
      3,
      4,
      5,
      6,
      total_learners
    union all
    select
      metric,
      fiscalyear,
      timeframe,
      grain_lvl_1,
      grain_lvl_2,
      grain_lvl_3,
      sum(total_learners) over (
        partition by grain_lvl_1,
        grain_lvl_2,
        grain_lvl_3
        order by
          timeframe
      ) as cumulative_learners
    from
      prep_Set_5
    group by
      1,
      2,
      3,
      4,
      5,
      6,
      total_learners
  ),
  pre_final as (
    select
      nvl(a.metric, g.metric) as metric,
      nvl(a.fiscalYear, g.fiscalYear) as fiscalYear,
      nvl(a.timeframe, g.timeframe) as timeframe,
      nvl(a.grain_lvl_1, g.grain_lvl_1) as grain_lvl_1,
      nvl(a.grain_lvl_2, g.grain_lvl_2) as grain_lvl_2,
      nvl(a.grain_lvl_3, g.grain_lvl_3) as grain_lvl_3,
      (a.cumulative_learners) as cumulative_learners,
      nvl(g.target, 0) as target
    from
      final_actuals a full
      outer join final_goals g on a.metric = g.metric
      and a.fiscalyear = g.fiscalYear
      and a.timeframe = g.timeframe
      and a.grain_lvl_1 = g.grain_lvl_1
      and a.grain_lvl_2 = g.grain_lvl_2
      and a.grain_lvl_3 = g.grain_lvl_3
  )


  select
    p.* except(p.cumulative_learners, p.target)
    ,
    case
      when 
        (
        p.cumulative_learners is null
        and p.timeframe >=(
          select
            fiscal_year_quarter
          from
            main.it_core_dim.dim_dates
          where
            date = current_date :: date
        )
        )
      then 
      --  0
      last_value (p.cumulative_learners, true) over (
        partition by p.metric,
        p.grain_lvl_1,
        p.grain_lvl_2,
        p.grain_lvl_3
        order by
          timeframe 
  ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
      )
      else p.cumulative_learners
    end as cumulative_learners,
    p.target
  from
    pre_final p
                          


''')

# COMMAND ----------

learners_df.createOrReplaceTempView('learners')

# COMMAND ----------

# MAGIC %md # Paid Training

# COMMAND ----------

# DBTITLE 1,Training Revenue Reporting Query
paid_df = spark.sql('''
  with milestone_data as 
  (
    select
      m.milestone_target_fiscal_year_quarter,
      m.milestone_target_fiscal_year,
      m.milestone_target_date,
      m.milestone_id,
      m.milestone_revenue_type,
      m.class_generated_project_id,
      m.class_name,
      case
        when m.class_custom_id = 12710 then 11083
        when m.class_custom_id = 12708 then 11082
        when m.class_custom_id = 14132 then 14131
        when m.class_custom_id = 13219 then 12632
        else m.class_custom_id
      end as class_custom_id,
      m.class_format,
      m.course,
      m.provider,
      m.milestone_name,
      m.milestone_amount,
      m.gaap_milestone_amount,
      m.milestone_status,
      m.is_milestone_approved,
      m.include_milestone_in_financial,
      m.billing_event_status,
      m.project_id,
      m.project_name,
      m.project_region,
      m.account_name,
      m.billing_invoice_date,
      p.account_id,
      p.project_service_tier,
      p.project_Service_type,
      p.project_unscheduled_backlog,
      p.project_unused_success_credits,
      p.opportunity_id,
      p.parent_project_id,
      p.parent_project_name,
      p1.id, 
      p1.OpportunityID_CaseSafe__c,
      c.sales_business_unit,
      c.opportunity_region_level_1, 
      a.sales_subregion_level_1
    from
      main.gtm_data.core_professional_services_milestones m
      inner join main.gtm_data.core_professional_services_dim_project p on m.project_id = p.project_id
      and p.snapshot_date =(
        select
          max(snapshot_date)
        from
          main.gtm_data.core_professional_services_dim_project
      )
      left join main.sfdc_bronze.pse__proj__c p1 on m.project_id=p1.id and p1.processdate=(select max(processdate) from main.sfdc_bronze.pse__proj__c)
      left join main.gtm_data.core_opportunity_curated c on  p1.OpportunityID_CaseSafe__c=c.opportunity_id
      left join main.gtm_data.core_accounts_curated a on a.account_id = p.account_id
    where
      m.snapshot_date =(
        select
          max(snapshot_date)
        from
          main.gtm_data.core_professional_services_milestones
      )
      and m.practice_name = 'Training'
      and m.milestone_status = "Approved"
      and p.project_service_type not in ('SCP', 'BIF')
  )

  ,
  prep_set_1 as (
    select
      "Training Revenue Pre GAAP" as metric,
      milestone_target_fiscal_year as fiscalYear,
      milestone_target_fiscal_year_quarter as timeframe,
      "Overall" as grain_lvl_1,
      "Overall" as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(milestone_amount) as total_delivered_revenue_pre_gaap
    from
      milestone_data
    group by
      all
  )

  ,

  prep_set_2 as (
    select
      "Training Revenue Pre GAAP" as metric,
      milestone_target_fiscal_year as fiscalYear,
      milestone_target_fiscal_year_quarter as timeframe,
      sales_business_unit as grain_lvl_1,
      "Overall" as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(milestone_amount) as total_delivered_revenue_pre_gaap
    from
      milestone_data
    group by
      all
  )

  ,

  prep_set_3 as (
    select
      "Training Revenue Pre GAAP" as metric,
      milestone_target_fiscal_year as fiscalYear,
      milestone_target_fiscal_year_quarter as timeframe,
      sales_business_unit as grain_lvl_1,
      sales_subregion_level_1 as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(milestone_amount) as total_delivered_revenue_pre_gaap
    from
      milestone_data
    group by
      all
  )
  ,

  paid_training_goals
  as 
  (
  select * from main.field_learning_enablement.learning_enablement_okr_goals
  where fq2>="25-Q1"
  and metric="Training Revenue Pre GAAP"
  and processDate=(Select max(processDate) from main.field_learning_enablement.learning_enablement_okr_goals)
  )

  ,

  --goal_prep_set_1 as (
  --  select
  --    metric,
  --    fiscalYear,
  --    fq2 as timeframe,
  --    "Overall" as grain_lvl_1,
  --    "Overall" as grain_lvl_2,
  --    "Overall" as grain_lvl_3,
  --    sum(goal) as target
  --  from
  --    paid_training_goals
  --  where 1=1
  --  and audience="BU"
  --  and value = "Overall"
  --  group by
  --    all
  --)
--
  --,

  goal_prep_set_2 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      value as grain_lvl_1,
      "Overall" as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(goal) as target
    from
      paid_training_goals
    where 1=1
    and audience="BU"
    group by
      all
  )

  ,

  goal_prep_set_3 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      case 
        when value in ("DNB", "EDNB Verts","EE","EDNB ENT Tech","Startup") then "AMER Emerging"
        when value in ("CME", "LATAM", "MFG", "Retail") then "AMER Enterprise"
        when value in ("CAN", "PS", "FINS", "HLS") then "AMER Regulated Industries"
        when value in ("ANZ", "Asean + GCR", "India", "Japan", "Korea") then "APJ"
        when value in ("Central", "Northern", "SEMEA", "Emerging") then "EMEA"
        end as grain_lvl_1,
      value as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(goal) as target
    from
      paid_training_goals
    where 1=1
    and audience="BU+1"
    group by
      all
  )
  ,

  final_goals as 
  (
  --select * from goal_prep_set_1
  --union all 
  select * from goal_prep_set_2
  union all 
  select * from goal_prep_set_3
  )

  ,
  final_actuals as 
  (
  select * from prep_set_1
  union all 
  select * from prep_set_2
  union all 
  select * from prep_set_3
  )

  ,


  pre_final_overall as 
  (
  select 
    nvl(a.metric, g.metric) as metric,
    nvl(a.fiscalYear,g.fiscalYear) as fiscalYear,
    nvl(a.timeframe, g.timeframe) as timeframe,
    nvl(a.grain_lvl_1,g.grain_lvl_1) as grain_lvl_1,
    nvl(a.grain_lvl_2,g.grain_lvl_2) as grain_lvl_2,
    nvl(a.grain_lvl_3,g.grain_lvl_3) as grain_lvl_3,
    nvl(a.total_delivered_revenue_pre_gaap,0) as total_delivered_revenue_pre_gaap, 
    nvl(g.target,0) as target
  from final_actuals a 
  full outer join final_goals g 
  on a.metric=g.metric
  and a.fiscalyear=g.fiscalYear
  and a.timeframe=g.timeframe
  and a.grain_lvl_1=g.grain_lvl_1
  and a.grain_lvl_2=g.grain_lvl_2
  and a.grain_lvl_3=g.grain_lvl_3
  where 1=1
  )


  select * from 
  pre_final_overall

''')

# COMMAND ----------

# MAGIC %md # Active Certifications

# COMMAND ----------

# DBTITLE 1,Quarterly Certification Data Aggregator
certs_df = spark.sql('''
with qtr_end_dates 
    AS (
    select distinct qtr_end_date, fq2, processDate from main.field_learning_enablement.certifications_and_badges where processdate=(Select max(processdate) from main.field_learning_enablement.certifications_and_badges)
    and fq2>="FY'24 Q2"
    ) 
    ,

    processdates AS (

    select 
      case 
        when qtr_end_date<=current_date::date then qtr_end_date 
        -- else (select max(processdate) from main.field_learning_enablement.certifications_and_badges)
        else processDate
    end as processdates
    from qtr_end_dates 

    )



    ,

    cert_data as (
      select
        "Active Certifications" as metric,
        fiscalYear,
        processDate,
        case
          when audience in (
            "Partner",
            "Partner Other",
            "Microsoft",
            "Microsoft Other"
          ) then "Partner"
          else audience
        end as audience,
        updated_account_id,
        region_derived,
        business_unit,
        sales_subregion_level_1,
        count (learner_email_hash) as certs
      from
        main.field_learning_enablement.certifications_and_badges
      where
        credential_type = "Certification"
        and is_expired = "false"
        and processDate in (select processdates from processdates)
      group by
        all
    )
    ,
    prep_set_1 as (
      select
        processDate,
        metric,
        p.fiscal_year as fiscalYear,
        p.fiscal_year_quarter as timeframe,
        audience as grain_lvl_1,
        "Overall" as grain_lvl_2,
        "Overall" as grain_lvl_3,
        sum(certs) as total_certs
      from
        cert_data c
      inner join main.it_core_dim.dim_dates p on c.processdate = p.date
      group by
        all
    )
    ,
    prep_set_2 as (
      select
        processDate,
        metric,
        p.fiscal_year as fiscalYear,
        p.fiscal_year_quarter as timeframe,
        "Overall" as grain_lvl_1,
        "Overall" as grain_lvl_2,
        "Overall" as grain_lvl_3,
        sum(certs) as total_certs
      from
        cert_data c
      inner join main.it_core_dim.dim_dates p on c.processdate = p.date
      group by
        all
    )
    ,

    prep_set_3 as (
      select
        processDate,
        metric,
        p.fiscal_year as fiscalYear,
        p.fiscal_year_quarter as timeframe,
        "Customer" as grain_lvl_1,
        business_unit as grain_lvl_2,
        "Overall" as grain_lvl_3,
        sum(certs) as total_certs
      from
        cert_data c
      inner join main.it_core_dim.dim_dates p on c.processdate = p.date
      where audience="Customer"
      group by
        all
    )
    ,
    prep_set_4 as (
      select
        processDate,
        metric,
        p.fiscal_year as fiscalYear,
        p.fiscal_year_quarter as timeframe,
        "Customer" as grain_lvl_1,
        business_unit as grain_lvl_2,
        sales_subregion_level_1 as grain_lvl_3,
        sum(certs) as total_certs
      from
        cert_data c
      inner join main.it_core_dim.dim_dates p on c.processdate = p.date
      where audience="Customer"
      group by
        all
    )
    ,

    prep_set_5 as (
      select
        processDate,
        metric,
        p.fiscal_year as fiscalYear,
        p.fiscal_year_quarter as timeframe,
        "Partner" as grain_lvl_1,
        nvl(region_derived,"Unknown") as grain_lvl_2,
        "Overall" as grain_lvl_3,
        sum(certs) as total_certs
      from
        cert_data c
      inner join main.it_core_dim.dim_dates p on c.processdate = p.date
      where audience="Partner"
      group by
        all
    )

    ,


    cert_goals 
    as 
    (
    select * from main.field_learning_enablement.learning_enablement_okr_goals
    where fq2>="25-Q1"
    and metric="Active Certifications"
    and processDate=(Select max(processDate) from main.field_learning_enablement.learning_enablement_okr_goals)
    )

    ,

    goal_prep_set_1 as (
      select
        metric,
        fiscalYear,
        fq2 as timeframe,
        audience as grain_lvl_1,
        "Overall" as grain_lvl_2,
        "Overall" as grain_lvl_3,
        goal as target
      from
        cert_goals
      where
        audience in (
          "Partner",
          "Customer",
          "Customer Other",
          "Employee"
        )
      and value="NA"
      group by
        all
    ),
    goal_prep_set_2 as (
      select
        metric,
        fiscalYear,
        fq2 as timeframe,
        audience as grain_lvl_1,
        "Overall" as grain_lvl_2,
        "Overall" as grain_lvl_3,
        goal as target
      from
        cert_goals
      where
        audience in ("Overall")
      group by
        all
    ),
    goal_prep_set_3 as (
      select
        metric,
        fiscalYear,
        fq2 as timeframe,
        "Customer" as grain_lvl_1,
        value as grain_lvl_2,
        "Overall" as grain_lvl_3,
        goal as target
      from
        cert_goals
      where
        audience in ("BU")
      group by
        all
    ),
    goal_prep_set_4 as (
      select
        metric,
        fiscalYear,
        fq2 as timeframe,
        "Customer" as grain_lvl_1,
        case
          when value in ("DNB", "EDNB Verts","EE","EDNB ENT Tech","Startup") then "AMER Emerging"
          when value in ("CME", "LATAM", "MFG", "Retail") then "AMER Enterprise"
          when value in ("CAN", "PS", "FINS", "HLS") then "AMER Regulated Industries"
          when value in ("ANZ", "Asean + GCR", "India", "Japan", "Korea") then "APJ"
          when value in ("Central", "Northern", "SEMEA", "Emerging") then "EMEA"
        end as grain_lvl_2,

        
        value as grain_lvl_3,
        goal as target
      from
        cert_goals
      where
        audience in ("BU+1")
      group by
        all
    ),
    goal_prep_set_5 as (
      select
        metric,
        fiscalYear,
        fq2 as timeframe,
        "Partner" as grain_lvl_1,
        value as grain_lvl_2,
        "Overall" as grain_lvl_3,
        goal as target
      from
        cert_goals
      where
        audience in ("Partner")
      and value<>"NA"
      group by
        all
    )
    ,

    final_goals as 
    (
    select * from goal_prep_set_1
    union all 
    select * from goal_prep_set_2
    union all 
    select * from goal_prep_set_3
    union all 
    select * from goal_prep_set_4
    union all 
    select * from goal_prep_set_5
    )

    ,

    final_actuals as 
    (
    select
      processDate,
      metric,
      fiscalyear,
      timeframe,
      grain_lvl_1,
      grain_lvl_2,
      grain_lvl_3,
      total_certs
    from
      prep_Set_1
    group by
      1,2,3,4, 5, 6,7, total_certs
    union all 
    select
      processDate,
      metric,
      fiscalyear,
      timeframe,
      grain_lvl_1,
      grain_lvl_2,
      grain_lvl_3,
      total_certs
    from
      prep_Set_2
    group by
      1,2,3,4, 5, 6,7, total_certs
    union all 
    select
      processDate,
      metric,
      fiscalyear,
      timeframe,
      grain_lvl_1,
      grain_lvl_2,
      grain_lvl_3,
      total_certs
    from
      prep_Set_3
    group by
      1,2,3,4, 5, 6,7, total_certs
    union all
    select
      processDate,
      metric,
      fiscalyear,
      timeframe,
      grain_lvl_1,
      grain_lvl_2,
      grain_lvl_3,
      total_certs
    from
      prep_Set_4
    group by
      1,2,3,4, 5, 6,7, total_certs
    union all

    select
      processDate,
      metric,
      fiscalyear,
      timeframe,
      grain_lvl_1,
      grain_lvl_2,
      grain_lvl_3,
      total_certs
    from
      prep_Set_5
    group by
      1,2,3,4, 5, 6,7, total_certs
    )

    



    select 
      nvl(a.metric, g.metric) as metric,
      nvl(a.fiscalYear, g.fiscalYear) as fiscalYear,
      nvl(a.timeframe, g.timeframe) as timeframe,
      nvl(a.grain_lvl_1, g.grain_lvl_1) as grain_lvl_1,
      nvl(a.grain_lvl_2, g.grain_lvl_2) as grain_lvl_2,
      nvl(a.grain_lvl_3, g.grain_lvl_3) as grain_lvl_3,
      nvl(a.total_certs,0) as total_certs,
      nvl(g.target,0) as target
    from final_actuals a 
    full outer join final_goals g on a.metric=g.metric
    and a.fiscalyear=g.fiscalYear
    and a.timeframe=g.timeframe
    and a.grain_lvl_1=g.grain_lvl_1
    and a.grain_lvl_2=g.grain_lvl_2
    and a.grain_lvl_3=g.grain_lvl_3       
''')

# COMMAND ----------

# MAGIC %md # Fiscal Badges

# COMMAND ----------

# DBTITLE 1,Badge Data Aggregation Engine
badges_df = spark.sql('''
  with badge_data as (
    select
      "Fiscal Badges" as metric,
      fiscalYear,
      fq2,
      case
        when audience in (
          "Partner",
          "Partner Other",
          "Microsoft",
          "Microsoft Other"
        ) then "Partner"
        else audience
      end as audience,
      updated_account_id,
      region_derived,
      business_unit,
      sales_subregion_level_1,
      count (learner_email_hash) as badges
    from
      main.field_learning_enablement.certifications_and_badges
    where
      credential_type = "Badge"
      and is_expired = "false"
      and processDate = (select max(processDate) from main.field_learning_enablement.certifications_and_badges)
    group by
      all
  )


  ,
  prep_set_1 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      audience as grain_lvl_1,
      "Overall" as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(badges) as total_badges
    from
      badge_data
    group by
      all
  )
  ,

  prep_set_2 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Overall" as grain_lvl_1,
      "Overall" as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(badges) as total_badges
    from
      badge_data
    group by
      all
  )
  ,

  prep_set_3 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Customer" as grain_lvl_1,
      business_unit as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(badges) as total_badges
    from
      badge_data
    where audience="Customer"
    group by
      all
  )

  ,
  prep_set_4 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Customer" as grain_lvl_1,
      business_unit as grain_lvl_2,
      sales_subregion_level_1 as grain_lvl_3,
      sum(badges) as total_badges
    from
      badge_data
    where audience="Customer"
    group by
      all
  )


  ,

  prep_set_5 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Partner" as grain_lvl_1,
      nvl(region_derived,"Unknown") as grain_lvl_2,
      "Overall" as grain_lvl_3,
      sum(badges) as total_badges
    from
      badge_data
    where audience="Partner"
    group by
      all
  )

  ,


  badge_goals 
  as 
  (
  select * from main.field_learning_enablement.learning_enablement_okr_goals
  where fq2>="25-Q1"
  and metric="Fiscal Badges"
  and processDate=(Select max(processDate) from main.field_learning_enablement.learning_enablement_okr_goals)
  )

  ,

  goal_prep_set_1 as (
    select
      metric,
      fiscalYear,
      fq2 as timeframe,
      "Overall" as grain_lvl_1,
      "Overall" as grain_lvl_2,
      "Overall" as grain_lvl_3,
      goal as target
    from
      badge_goals
    where audience in ("Overall")
    group by
      all
  )

  ,

  final_goals as 
  (
  select * from goal_prep_set_1
  )

  ,

  final_actuals as 
  (
  select
    metric,
    fiscalyear,
    timeframe,
    grain_lvl_1,
    grain_lvl_2,
    grain_lvl_3,
    sum(total_badges) over (
      partition by grain_lvl_1, fiscalYear
      order by
        timeframe
    ) as total_badges
  from
    prep_Set_1
  group by
    1,2,3,4, 5, 6, total_badges
  union all 
  select
    metric,
    fiscalyear,
    timeframe,
    grain_lvl_1,
    grain_lvl_2,
    grain_lvl_3,
    sum(total_badges) over (
      partition by grain_lvl_1, fiscalYear
      order by
        timeframe
    ) as total_badges
  from
    prep_Set_2
  group by
    1,2,3,4, 5, 6, total_badges
  union all 
  select
    metric,
    fiscalyear,
    timeframe,
    grain_lvl_1,
    grain_lvl_2,
    grain_lvl_3,
    sum(total_badges) over (
      partition by grain_lvl_1, grain_lvl_2, fiscalYear
      order by
        timeframe
    ) as total_badges
  from
    prep_Set_3
  group by
    1,2,3,4, 5, 6, total_badges
  union all
  select
    metric,
    fiscalyear,
    timeframe,
    grain_lvl_1,
    grain_lvl_2,
    grain_lvl_3,
    sum(total_badges) over (
      partition by grain_lvl_1, grain_lvl_2, grain_lvl_3, fiscalYear
      order by
        timeframe
    ) as total_badges
  from
    prep_Set_4
  group by
    1,2,3,4, 5, 6, total_badges
  union all

  select
    metric,
    fiscalyear,
    timeframe,
    grain_lvl_1,
    grain_lvl_2,
    grain_lvl_3,
    sum(total_badges) over (
      partition by grain_lvl_1, grain_lvl_2, grain_lvl_3, fiscalYear
      order by
        timeframe
    ) as total_badges
  from
    prep_Set_5
  group by
    1,2,3,4, 5, 6, total_badges
  )

  ,
  pre_final as (
    select 
      nvl(a.metric, g.metric) as metric,
      nvl(a.fiscalYear, g.fiscalYear) as fiscalYear,
      nvl(a.timeframe, g.timeframe) as timeframe,
      nvl(a.grain_lvl_1, g.grain_lvl_1) as grain_lvl_1,
      nvl(a.grain_lvl_2, g.grain_lvl_2) as grain_lvl_2,
      nvl(a.grain_lvl_3, g.grain_lvl_3) as grain_lvl_3,
      a.total_badges, 
      nvl(g.target,0) as target
    from final_actuals a 
    full outer join final_goals g on a.metric=g.metric
    and a.fiscalyear=g.fiscalYear
    and a.timeframe=g.timeframe
    and a.grain_lvl_1=g.grain_lvl_1
    and a.grain_lvl_2=g.grain_lvl_2
    and a.grain_lvl_3=g.grain_lvl_3
  )

  select
    p.* except(p.total_badges, p.target)
    ,
    case
      when 
        (
        p.total_badges is null
        and p.timeframe >=(
          select
            fiscal_year_quarter
          from
            main.it_core_dim.dim_dates
          where
            date = current_date :: date
        )
        )
      then 
      last_value (p.total_badges, true) over (
        partition by p.metric,
        p.grain_lvl_1,
        p.grain_lvl_2,
        p.grain_lvl_3,
        fiscalYear
        order by
          timeframe 
  ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
      )
      else p.total_badges
    end as total_badges,
    p.target
  from
    pre_final p                  
''')

# COMMAND ----------

# MAGIC %md # T28d Producer Base

# COMMAND ----------

# DBTITLE 1,Monthly Users Statistics Summary
t28d_producer_base_df = spark.sql('''
select 
  date_trunc('month',date)::date as period,
  salesforce_account_id,
  sum(total_num_users_t28d) as login_users_t28d,
  sum(workload_num_users_t28d) as producers_t28d,
  sum(dbsql_num_users_t28d) as dbsql_users_t28d,
  sum(unity_catalog_num_users_t28d) as uc_users_t28d,
  sum(lakeview_num_users_t28d) as lakeview_users_t28d,
  sum(ds_ml_num_users_t28d) as dsml_users_t28d,
  sum(etl_num_users_t28d) as etl_users_t28d,
  sum(workflows_num_users_t28d) as workflows_users_t28d,
  sum(delta_num_users_t28d) as delta_users_t28d
  --sum(login_num_users_t28d) as total
  from
  main.data_product_features.customer_metrics
  where date>='2023-01-01'
--  and date <= date_trunc('month',now())
--  and (date = last_day(date_trunc('month',date)))

  group by all order by 1 desc                               
''')

# COMMAND ----------

t28d_producer_base_df.createOrReplaceTempView('t28d_producer_base')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Monthly Active Users

# COMMAND ----------

# DBTITLE 1,Engaged Users Monthly Report
# maus_base_df = spark.sql('''

#   with data as (
#     select DATE_TRUNC('month', date)::date AS month,
#           salesforce_account_id,
#           count(distinct IF(login_num_events > 0 OR total_dbus > 0, user_id, NULL)) as mau
#     from main.data_product_features.user_metrics
#     where is_customer
#     and DAYOFMONTH(date) <= 28
#       -- and DATE_TRUNC('month', date)::date="2024-02-01"
#     group by all
#     order by 1 desc
#   )

#   select 
#     d.*, 
#     c.business_unit, 
#     c.sales_subregion_level_1, 
#     c.sales_subregion_level_2, 
#     c.sales_subregion_level_3, 
#     c.account_name, 
#     c.account_status
#   from data d 
#   left join main.gtm_data.core_accounts_curated c on d.salesforce_account_id=c.account_id   
# ''')

# COMMAND ----------

# maus_base_df = spark.sql('''
#   with data as (
#     select DATE_TRUNC('month', date)::date AS month,
#           salesforce_account_id,
#           count(distinct IF(login_num_events > 0 OR total_dbus > 0, user_id, NULL)) as mau
#     from main.data_product_features.user_metrics
#     where is_customer
#     and DAYOFMONTH(date) <= 28
#     and salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
#     group by all
#     order by 1 desc
#   )
#   ,


#   min_month as 
#   (
#    select min(month) as start_month
#    from data 
#    where mau <>0
#   )
#   ,

#   accounts_prep_1 as 
#   (
#   select  salesforce_account_id as account_id, min(month) as first_month
#   from data 
#   where mau<>0
#   group by all 
#   )



# ,
#    accounts_prep_2 as 
#    (
#  select  updated_account_id as account_id, min(date_trunc("month",completed_date)::date) as first_month
#   from main.field_learning_enablement.all_learners
#   where audience="Customer"
#   and processdate =(select max(processDate) from main.field_learning_enablement.all_learners)
#   and all_learners.dataset="net new learners"
#   group by all 
#    )

#    ,

#  accounts as 
#  (
#    select distinct account_id, first_month
#    from accounts_prep_1
#    union 
#       select distinct account_id, first_month
#       from accounts_prep_2 
#  )


#   ,
  
#   accounts_months as (

#    select account_id, 
#    min(first_month) as start_month
#    from accounts
#    group by all
#   )
  
#   ,
#   timeframes as 
#   (
#    select distinct date as month
#    from main.it_core_dim.dim_dates
#   where is_month_start
#   and date<=current_date::date
#   )
  
#   ,

#   accounts_timeframes as 
#   (
#   select account_id, start_month, month
#   from accounts_months a
#   cross join timeframes where month>=start_month and month<=current_date::date
#   )



#   select 
#     a.account_id as salesforce_account_id,
#     a.month,
#     nvl(d.mau,0) as mau,
#     c.business_unit, 
#     c.sales_subregion_level_1, 
#     c.sales_subregion_level_2, 
#     c.sales_subregion_level_3, 
#     c.account_name, 
#     c.account_status
#   from accounts_timeframes a 
#   left join data d on a.account_id=d.salesforce_account_id and a.month=d.month
#   left join main.gtm_data.core_accounts_curated c on a.account_id=c.account_id   
#   order by all           
# ''')

# COMMAND ----------

maus_base_df = spark.sql('''
with t28_data as (
  select 
    DATE_TRUNC('month', date)::date AS month,
    salesforce_account_id,
    COUNT(DISTINCT case when login_num_events_t28d > 0 then user_id end) as mau,
    COUNT(DISTINCT case when login_num_events_t7d > 0 then user_id end) as wau,
    COUNT(DISTINCT case when login_num_events_t91d > 0 then user_id end) as qau,
    COUNT(DISTINCT case when login_num_events > 0 then user_id end) as dau
  from main.data_product_features.user_metrics
  where salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
  and date >= '2024-01-01'
  -- and DATE_DIFF(date, DATE_TRUNC('MONTH', date)) <= 27
  -- AND (DATE_DIFF(date, DATE_TRUNC('MONTH', date)) = 27 or date = current_date)
  -- AND (DAYOFMONTH(date) = 28 OR date = (SELECT MAX(date) FROM main.data_product_features.user_metrics))
  AND (DAYOFMONTH(date) = 28 OR date = (SELECT MAX(date) FROM main.data_product_features.user_metrics WHERE DAYOFMONTH(date)<=28))
  group by all
  order by 1 desc
)
, 
-- data as (
-- select 
--   d.*, 
--   t.t28_mau as t28_mau, 
--   t.wau as wau,
--   t.qau as qau,
--   t.dau as dau
-- from mau_data_old d 
-- left join t28_data t on d.month = t.month and d.salesforce_account_id = t.salesforce_account_id
-- )
data as (
select 
  -- d.*, 
  t.salesforce_account_id as salesforce_account_id, 
  t.month as month,
  nvl(t.mau, 0) as mau,
  -- nvl(t.t28_mau, 0) as t28_mau, 
  nvl(t.wau, 0) as wau,
  nvl(t.qau, 0) as qau,
  nvl(t.dau, 0) as dau
from t28_data t 
-- left join mau_data_old d on d.month = t.month and d.salesforce_account_id = t.salesforce_account_id

)
,

min_month as 
  (
   select min(month) as start_month
   from data 
   where mau <> 0
  )
  ,

  accounts_prep_1 as 
  (
  select  salesforce_account_id as account_id, min(month) as first_month
  from data 
  where mau <> 0
  group by all 
  )



,
   accounts_prep_2 as 
   (
 select  updated_account_id as account_id, min(date_trunc("month",completed_date)::date) as first_month
  from main.field_learning_enablement.all_learners
  where audience="Customer"
  and processdate =(select max(processDate) from main.field_learning_enablement.all_learners)
  and all_learners.dataset="net new learners"
  group by all 
   )

   ,

 accounts as 
 (
   select distinct account_id, first_month
   from accounts_prep_1
   union 
      select distinct account_id, first_month
      from accounts_prep_2 
 )


  ,
  
  accounts_months as (

   select account_id, 
   min(first_month) as start_month
   from accounts
   group by all
  )
  
  ,
  timeframes as 
  (
   select distinct date as month
   from main.it_core_dim.dim_dates
  where is_month_start
  and date<=current_date::date
  )
  
  ,

  accounts_timeframes as 
  (
  select account_id, start_month, month
  from accounts_months a
  cross join timeframes where month>=start_month and month<=current_date::date
  )



  select 
    a.account_id as salesforce_account_id,
    a.month,
    nvl(d.mau,0) as mau,
    -- nvl(d.t28_mau,0) as t28_mau,
    nvl(d.wau,0) as wau,
    nvl(d.qau,0) as qau,
    nvl(d.dau,0) as dau,
    c.business_unit, 
    c.sales_subregion_level_1, 
    c.sales_subregion_level_2, 
    c.sales_subregion_level_3, 
    c.account_name, 
    c.account_status
  from accounts_timeframes a 
  left join data d on a.account_id=d.salesforce_account_id and a.month=d.month
  left join main.gtm_data.core_accounts_curated c on a.account_id=c.account_id   
  order by all     
    
''')

# COMMAND ----------

maus_base_df.createOrReplaceTempView('maus_base')

# COMMAND ----------

# DBTITLE 1,Monthly Active Users Aggregation
mau_df = spark.sql('''
  with pre as (
  select
    -- o.*,
    -- c.sales_business_unit,
    -- c.sales_subregion_level_1,
    -- c.sales_subregion_level_2,
    -- c.sales_subregion_level_3,
    -- c.account_name,
    -- c.account_id,
    -- c.account_status,
    o.mau as mau,
    o.month as period,
    o.business_unit as sales_business_unit,
    o.sales_subregion_level_1,
    o.sales_subregion_level_2,
    d.is_fiscal_quarter_end,
    d.date as last_day_of_month,
    d.fiscal_quarter_end_date,
    d.fiscal_year as fiscalYear
  from
    maus_base o
    left join main.gtm_data.core_accounts_curated c on o.salesforce_account_id = c.account_id
    left join main.it_core_dim.dim_dates d on last_day(o.month) = d.date -- where o.salesforce_account_id="00161000005eOd1AAE"
),
final_overall_1 as (
  select
    period,
    last_day_of_month,
    is_fiscal_quarter_end,
    fiscal_quarter_end_date,
    fiscalYear,
    sum(mau) as mau
  from
    pre
  group by
    all
  order by
    all
)
,
final_overall_2 as (
  select
    period,
    last_day_of_month,
    fiscal_quarter_End_date,
    is_fiscal_quarter_end,
    fiscalYear,
    mau,
    lag(mau) over (
      order by
        period
    ) as prev_qtr_mau
  from
    final_overall_1
  where
    (
      is_fiscal_quarter_end is true
      or period = date_trunc('month', current_date)
    )
),
final_overall_3 as (
  select
    p.period,
    p.is_fiscal_quarter_end,
    p.last_day_of_month,
    p.fiscal_quarter_End_date,
    p.fiscalYear,
    q.prev_qtr_mau,
    "Overall" as grain_lvl_1,
    "Overall" as grain_lvl_2,
    "Overall" as grain_lvl_3,
    sum(p.mau) as mau
  from
    final_overall_1 p
    left join final_overall_2 q on p.fiscal_quarter_end_date = q.fiscal_quarter_end_date
  group by
    all
  order by
    all
),
final_bu_1 as (
  select
    period,
    last_day_of_month,
    is_fiscal_quarter_end,
    fiscal_quarter_end_date,
    fiscalYear,
    nvl(sales_business_unit, "NA") as sales_business_unit,
    sum(mau) as mau
  from
    pre
  group by
    all
  order by
    all
),
final_bu_2 as (
  select
    period,
    last_day_of_month,
    fiscal_quarter_End_date,
    is_fiscal_quarter_end,
    fiscalYear,
    mau,
    nvl(sales_business_unit, "NA") as sales_business_unit,
    lag(mau) over (
      partition by sales_business_unit
      order by
        period
    ) as prev_qtr_mau
  from
    final_bu_1
  where
    (
      is_fiscal_quarter_end is true
      or period = date_trunc('month', current_date)
    )
),
final_bu_3 as (
  select
    p.period,
    p.is_fiscal_quarter_end,
    p.last_day_of_month,
    p.fiscal_quarter_end_date,
    p.fiscalYear,
    q.prev_qtr_mau,
    nvl(p.sales_business_unit, "NA") as grain_lvl_1,
    "Overall" as grain_lvl_2,
    "Overall" as grain_lvl_3,
    sum(p.mau) as mau
  from
    final_bu_1 p
    left join final_bu_2 q on p.fiscal_quarter_end_date = q.fiscal_quarter_end_date
    and p.sales_business_unit = q.sales_business_unit
  group by
    all
  order by
    all
),
final_bu_plus_1 as (
  select
    period,
    last_day_of_month,
    is_fiscal_quarter_end,
    fiscal_quarter_end_date,
    fiscalYear,
    sales_business_unit,
    sales_subregion_level_1,
    sum(mau) as mau
  from
    pre
  group by
    all
  order by
    all
),
final_bu_plus_1_2 as (
  select
    period,
    last_day_of_month,
    fiscal_quarter_End_date,
    fiscalYear,
    is_fiscal_quarter_end,
    mau,
    sales_business_unit,
    sales_subregion_level_1,
    lag(mau) over (
      partition by sales_business_unit,
      sales_subregion_level_1
      order by
        period
    ) as prev_qtr_mau
  from
    final_bu_plus_1
  where
    (
      is_fiscal_quarter_end is true
      or period = date_trunc('month', current_date)
    )
),
final_bu_plus_1_3 as (
  select
    p.period,
    p.is_fiscal_quarter_end,
    p.last_day_of_month,
    p.fiscal_quarter_end_date,
    p.fiscalYear,
    q.prev_qtr_mau,
    p.sales_business_unit as grain_lvl_1,
    p.sales_subregion_level_1 as grain_lvl_2,
    "Overall" as grain_lvl_3,
    sum(p.mau) as mau
  from
    final_bu_plus_1 p
    left join final_bu_plus_1_2 q on p.fiscal_quarter_end_date = q.fiscal_quarter_end_date
    and p.sales_business_unit = q.sales_business_unit
    and p.sales_subregion_level_1 = q.sales_subregion_level_1
  group by
    all
  order by
    all
),
overall_t28d_producers_actuals as (
  select
    "MAU" as metric,
    *
  from
    final_overall_3
  union all
  select
    "MAU" as metric,
    *
  from
    final_bu_3
  union all
  select
    "MAU" as metric,
    *
  from
    final_bu_plus_1_3
),
producer_goals as (
  select
    *
  from
    main.field_learning_enablement.learning_enablement_okr_goals
  where
    fq2 >= "25-Q1"
    and metric = "MAU"
    and processDate =(
      Select
        max(processDate)
      from
        main.field_learning_enablement.learning_enablement_okr_goals
    )
),
goal_prep_set_1 as (
  select
    metric,
    fiscalyear,
    month as timeframe,
    "Overall" as grain_lvl_1,
    "Overall" as grain_lvl_2,
    "Overall" as grain_lvl_3,
    sum(goal) as target
  from
    producer_goals
  where
    audience = "Overall"
  group by
    all
),
goal_prep_set_2 as (
  select
    metric,
    fiscalyear,
    month as timeframe,
    nvl(value, "NA") as grain_lvl_1,
    "Overall" as grain_lvl_2,
    "Overall" as grain_lvl_3,
    sum(goal) as target
  from
    producer_goals
  where
    audience = "BU"
  group by
    all
),
goal_prep_set_3 as (
  select
    metric,
    fiscalyear,
    month as timeframe,
    case
      when value in ("DNB", "EDNB Verts","EE","EDNB ENT Tech","Startup") then "AMER Emerging"
      when value in ("CME", "LATAM", "MFG", "Retail") then "AMER Enterprise"
      when value in ("CAN", "PS", "FINS", "HLS") then "AMER Regulated Industries"
      when value in ("ANZ", "Asean + GCR", "India", "Japan", "Korea") then "APJ"
      when value in ("Central", "Northern", "SEMEA", "Emerging") then "EMEA"
    end as grain_lvl_1,
    value as grain_lvl_2,
    "Overall" as grain_lvl_3,
    sum(goal) as target
  from
    producer_goals
  where
    audience = "BU+1"
  group by
    all
),
overall_t28d_producers_goals as (
  select
    *
  from
    goal_prep_set_1
  union all
  select
    *
  from
    goal_prep_set_2
  union all
  select
    *
  from
    goal_prep_set_3
)
,

pre_final as 
(
select
  nvl(a.metric, b.metric) as metric,
  nvl(a.period, b.timeframe) as timeframe,
  nvl(a.fiscalYear, b.fiscalYear) as fiscalYear,
  a.is_Fiscal_quarter_end,
  a.last_day_of_month,
  a.fiscal_quarter_end_date,
  a.prev_qtr_mau,
  nvl(a.grain_lvl_1,b.grain_lvl_1) as grain_lvl_1,
  nvl(a.grain_lvl_2,b.grain_lvl_2) as grain_lvl_2,
  nvl(a.grain_lvl_3,b.grain_lvl_3) as grain_lvl_3,
  nvl(a.mau,0) as mau,
  nvl(b.target, 0) as target
from
  overall_t28d_producers_actuals a
  full outer join overall_t28d_producers_goals b 
  on a.metric = b.metric
  and a.period = b.timeframe
  and a.grain_lvl_1 = b.grain_lvl_1
  and a.grain_lvl_2 = b.grain_lvl_2
  and a.grain_lvl_3 = b.grain_lvl_3
)


select * from pre_final
''')

# COMMAND ----------

mau_df.createOrReplaceTempView('maus')

# COMMAND ----------

# MAGIC %md # Learner Penetration

# COMMAND ----------

# DBTITLE 1,Learner Penetration Analysis Query
learner_penetration_df = spark.sql('''
  with customer_learners as (
    select
      *
    from
      learners
    where
      1 = 1
      and grain_lvl_1 = "Customer"
  ),
  maus_pre as (
    select
      p.* except (metric),
      d.fiscal_year_quarter
    from
      maus p 
    inner join main.it_core_dim.dim_dates d on p.fiscal_quarter_end_date=d.date
    where
      (
        p.is_fiscal_quarter_end is true
        or p.timeframe = date_Trunc("month", current_date)
      )
  )
  ,
  learner_penetration_goals as (
    select * from main.field_learning_enablement.learning_enablement_okr_goals
    where fq2>="25-Q1"
    and metric="Learner to MAU"
    and processDate=(Select max(processDate) from main.field_learning_enablement.learning_enablement_okr_goals)
  )
  ,
  goal_prep_set_1 as 
  (
  select 
  metric,
  fiscalyear, 
  fq2 as timeframe, 
  "Overall" as grain_lvl_1,
  "Overall" as grain_lvl_2,
  "Overall" as grain_lvl_3,
  goal as target
  from learner_penetration_goals
  where audience="Overall"
  group by all 
  )

  ,
  goal_prep_set_2 as 
  (
  select 
  metric,
  fiscalyear, 
  fq2 as timeframe, 
  value as grain_lvl_1,
  "Overall" as grain_lvl_2,
  "Overall" as grain_lvl_3,
  sum(goal) as target
  from learner_penetration_goals
  where audience="BU"
  group by all 
  )

  ,

  goal_prep_set_3 as 
  (
  select 
  metric,
  fiscalyear, 
  fq2 as timeframe, 
  case 
    when value in ("DNB", "EDNB Verts","EE","EDNB ENT Tech","Startup") then "AMER Emerging"
    when value in ("CME", "LATAM", "MFG", "Retail") then "AMER Enterprise"
    when value in ("CAN", "PS", "FINS", "HLS") then "AMER Regulated Industries"
    when value in ("ANZ", "Asean + GCR", "India", "Japan", "Korea") then "APJ"
    when value in ("Central", "Northern", "SEMEA", "Emerging") then "EMEA"
  end as grain_lvl_1,

  value as grain_lvl_2,
  "Overall" as grain_lvl_3,
  sum(goal) as target
  from learner_penetration_goals
  where audience="BU+1"
  group by all 
  )
  ,

  overall_learner_penetration_goals as 
  (
  select * from goal_prep_set_1
  union all 
  select * from goal_prep_set_2
  union all 
  select * from goal_prep_set_3
  )
  ,
  pre as (
    select
      "Learner to MAU" as metric,
      t.*,
      c.cumulative_learners,
      round(c.cumulative_learners/t.prev_qtr_mau,3) as learner_penetration
    from
      maus_pre t 
        left join customer_learners c 
          on t.grain_lvl_1=c.grain_lvl_2 
          and t.grain_lvl_2=c.grain_lvl_3 
          and t.fiscal_year_quarter=c.timeframe
  )

  select 
    nvl(p.metric, t.metric) as metric,
    nvl(p.fiscalYear, t.fiscalYear) as fiscalYear,
    nvl(p.fiscal_year_quarter, t.timeframe) as timeframe,
    nvl(p.grain_lvl_1, t.grain_lvl_1) as grain_lvl_1,
    nvl(p.grain_lvl_2, t.grain_lvl_2) as grain_lvl_2,
    nvl(p.grain_lvl_3, t.grain_lvl_3) as grain_lvl_3,
    nvl(p.learner_penetration,0) as actuals,
    t.target
  from pre p
  full outer join overall_learner_penetration_goals t 
    on p.metric=t.metric 
    and p.fiscal_year_quarter=t.timeframe 
    and p.grain_lvl_1=t.grain_lvl_1 
    and p.grain_lvl_2=t.grain_lvl_2
    and p.grain_lvl_3=t.grain_lvl_3
''')

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Learner to MAU
# MAGIC

# COMMAND ----------

# DBTITLE 1,Learner Penetration Analysis Query
learner_maus_df = spark.sql('''
  with customer_learners as (
      select
        *
      from
        learners
      where
        1 = 1
        and grain_lvl_1 = "Customer"
    ),
    maus_pre as (
      select
        p.* except (metric),
        d.fiscal_year_quarter
      from
        maus p 
      inner join main.it_core_dim.dim_dates d on p.fiscal_quarter_end_date=d.date
      where
        (
          p.is_fiscal_quarter_end is true
          or p.timeframe = date_Trunc("month", current_date)
        )
    )
    ,
    learner_penetration_goals as (
      select * from main.field_learning_enablement.learning_enablement_okr_goals
      where fq2>="25-Q1"
      and metric="Learner to MAU"
      and processDate=(Select max(processDate) from main.field_learning_enablement.learning_enablement_okr_goals)
    )
    ,
    goal_prep_set_1 as 
    (
    select 
    metric,
    fiscalyear, 
    fq2 as timeframe, 
    "Overall" as grain_lvl_1,
    "Overall" as grain_lvl_2,
    "Overall" as grain_lvl_3,
    goal as target
    from learner_penetration_goals
    where audience="Overall"
    group by all 
    )

    ,
    goal_prep_set_2 as 
    (
    select 
    metric,
    fiscalyear, 
    fq2 as timeframe, 
    value as grain_lvl_1,
    "Overall" as grain_lvl_2,
    "Overall" as grain_lvl_3,
    sum(goal) as target
    from learner_penetration_goals
    where audience="BU"
    group by all 
    )


    ,

    goal_prep_set_3 as 
    (
    select 
    metric,
    fiscalyear, 
    fq2 as timeframe, 
    case 
      when value in ("DNB", "EDNB Verts","EE","EDNB ENT Tech","Startup") then "AMER Emerging"
      when value in ("CME", "LATAM", "MFG", "Retail") then "AMER Enterprise"
      when value in ("CAN", "PS", "FINS", "HLS") then "AMER Regulated Industries"
      when value in ("ANZ", "Asean + GCR", "India", "Japan", "Korea") then "APJ"
      when value in ("Central", "Northern", "SEMEA", "Emerging") then "EMEA"
    end as grain_lvl_1,

    value as grain_lvl_2,
    "Overall" as grain_lvl_3,
    sum(goal) as target
    from learner_penetration_goals
    where audience="BU+1"
    group by all 
    )

    ,

    overall_learner_penetration_goals as 
    (
    select * from goal_prep_set_1
    union all 
    select * from goal_prep_set_2
    union all 
    select * from goal_prep_set_3
    )
    ,
    pre as (
      select
        "Learner to MAU" as metric,
        t.*,
        c.cumulative_learners,
        round(c.cumulative_learners/t.prev_qtr_mau,3) as learner_penetration
      from
        maus_pre t 
          left join customer_learners c 
            on t.grain_lvl_1=c.grain_lvl_2 
            and t.grain_lvl_2=c.grain_lvl_3 
            and t.fiscal_year_quarter=c.timeframe
    )
    select * from pre

''')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Account Level Learner Penetration

# COMMAND ----------

account_learner_penetration = spark.sql('''
  with maus_pre as (
    select
    -- o.*,
    o.mau as mau,
    o.month as period,
    o.business_unit as sales_business_unit,
    o.sales_subregion_level_1,
    o.sales_subregion_level_2,
    o.sales_subregion_level_3,
    o.account_name,
    o.salesforce_account_id as account_id,
    o.account_status,
    d.is_fiscal_quarter_end,
    d.date as last_day_of_month,
    d.fiscal_quarter_end_date,
    d.fiscal_year as fiscalYear,
    d.fiscal_year_quarter as fq2
  from
    maus_base o
    left join main.gtm_data.core_accounts_curated c on o.salesforce_account_id = c.account_id
    left join main.it_core_dim.dim_dates d on last_day(o.month) = d.date
)

,
maus_2 as (
  select
    sales_business_unit,
    sales_subregion_level_1,
    sales_subregion_level_2,
    sales_subregion_level_3,
    account_name,
    account_id,
    account_status,
    period,
    last_day_of_month,
    is_fiscal_quarter_end,
    fiscal_quarter_end_date,
    fiscalYear,
    fq2,
    sum(mau) as mau
  from
    maus_pre
  group by
    all
  order by
    all
)

,
maus_3 as (
  select
    sales_business_unit,
    sales_subregion_level_1,
    sales_subregion_level_2,
    sales_subregion_level_3,
    account_name,
    account_id,
    account_status,
    period,
    last_day_of_month,
    fiscal_quarter_End_date,
    is_fiscal_quarter_end,
    fiscalYear,
    fq2,
    mau,
    lag(mau) over (
    partition by account_id
      order by
        period
    ) as prev_qtr_mau
  from
    maus_2
  where
    (
      is_fiscal_quarter_end is true
      or period = date_trunc('month', current_date)
    )
)
,
maus_final as (
  select
    p.sales_business_unit,
    p.sales_subregion_level_1,
    p.sales_subregion_level_2,
    p.sales_subregion_level_3,
    p.account_name,
    p.account_id,
    p.account_status,
    p.period,
    p.is_fiscal_quarter_end,
    p.last_day_of_month,
    p.fiscal_quarter_End_date,
    p.fiscalYear,
    p.fq2,
    q.prev_qtr_mau,
    sum(p.mau) as mau
  from
    maus_2 p
    left join maus_3 q on p.fiscal_quarter_end_date = q.fiscal_quarter_end_date and p.account_id = q.account_id
  group by
    all
  order by
    all
)
,
learners as (
  select
    updated_account_id,
    updated_account_name,
    -- completed_date :: date,
    -- audience,
    date_trunc('MONTH', completed_date)::date as learner_month,
    count (distinct learner_user_id) as learners
  from
    main.field_learning_enablement.all_learners
  where
    processdate =(
      select
        max(processdate)
      from
        main.field_learning_enablement.all_learners
    )
    and dataset = "net new learners"
    -- and audience ilike '%customer%'
    and audience = 'Customer'
  group by
    all
  order by
    all
) 

,

learners_cumulative as (
  select
    updated_account_id,
    updated_account_name,
    -- completed_date :: date,
    -- audience,
    learner_month,
    learners,
    sum(learners) over (partition by updated_account_id order by learner_month) as cumulative_learners
  from
    learners l
  group by
    all
  order by
    all
) 



, 
pre as (
select  
  nvl(l.updated_account_id,m.account_id) as account_id,
  nvl(l.updated_account_name, m.account_name) as account_name,
  nvl(l.learners, 0) as learners,
  l.cumulative_learners as cumulative_learners_pre,
  nvl(m.mau, 0) as mau,
  nvl(m.prev_qtr_mau, 0) as prev_qtr_mau,
  nvl(m.period,l.learner_month) as period
  
  from maus_final m
  full outer join learners_cumulative l on m.account_id=l.updated_account_id and m.period=l.learner_month
  order by period
)
,
pre_2 as (
  select 
    *,
      last_value (l.cumulative_learners_pre, true) over (
        partition by l.account_id
        order by
          period 
  ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
      )
    as cumulative_learners
    from
      pre l
)
,
final as (
  select 
    p.account_id,
    p.account_name,
    p.learners,
    nvl(p.cumulative_learners, 0) as cumulative_learners,
    p.mau,
    lag (p.mau) over (
          partition by p.account_id
          order by
            p.period 
        )
      as prev_month_mau,
    p.prev_qtr_mau,
    p.period,
    nvl(c.sales_business_unit, "Unknown") as sales_business_unit,
    nvl(c.sales_subregion_level_1, "Unknown") as sales_subregion_level_1,
    nvl(c.sales_subregion_level_2, "Unknown") as sales_subregion_level_2,
    nvl(c.sales_subregion_level_3, "Unknown") as sales_subregion_level_3 
  from pre_2 p 
  left join main.gtm_data.core_accounts_curated c on p.account_id = c.account_id
)
,
greenfield as (
  SELECT
    ca.account_id,
    CASE WHEN ba.accountspendtier__c = 'Greenfield'
        AND lower(ba.Owner_Role__c) not like '%unassigned%'
        AND ca.business_unit is not null
        AND ca.dbx in ('DB400','DB3000')   
            THEN 'Yes'
    ELSE 'No' 
    END as greenfield_account
    FROM main.gtm_data.core_accounts_curated ca
    LEFT JOIN main.sfdc_bronze.account ba 
      ON ca.account_id = ba.AccountID_CaseSafe__c
    AND ba.processDate IN (SELECT MAX(processDate) FROM main.sfdc_bronze.account)
)


select 
  f.*,
  g.greenfield_account
from final f
left join greenfield g on f.account_id=g.account_id
''')

# COMMAND ----------

account_learner_penetration.createOrReplaceTempView('account_learners_to_mau')

# COMMAND ----------

# MAGIC %md # Trained Accounts

# COMMAND ----------


trained_accounts_df = spark.sql('''
with snapshot_dates as (
  select date_trunc("MONTH", snapshot_date)::date as month, max(snapshot_date) as snapshot_date
  from main.gtm_data.core_accounts_curated_history
  where snapshot_date >= "2023-01-01" 
  group by all
  order by all
)

,
accounts as (
  select
    date_trunc('MONTH', snapshot_date)::date as snapshot_date,
    account_id,
    account_name,
    t3m_annualized
from main.gtm_data.core_accounts_curated_history
where snapshot_date in (select distinct snapshot_date from snapshot_dates)
and snapshot_date >= "2023-01-01" 
and t3m_annualized > 240000
)

,
data as (
  select
    t.*,
    m.period,
    m.mau,
    m.prev_month_mau,
    m.prev_qtr_mau,
    m.learners,
    m.cumulative_learners
  from
    accounts t
    left join account_learners_to_mau m on t.account_id = m.account_id
    and t.snapshot_date = m.period
  where 1=1
    -- t.account_id = "0013f000004TJsvAAG"
    and t.snapshot_date :: date <= (select current_date::date)
  order by
    all
)

select
  d.*,
  c.sales_business_unit,
  c.sales_subregion_level_1,
  c.sales_subregion_level_2,
  c.sales_subregion_level_3,
  t.fiscal_year as fiscalYear,
  t.fiscal_year_quarter as FQ2,
  case
    when 
      round(try_divide(d.cumulative_learners, d.prev_month_mau) * 100, 2) >= 12
       then 1
      else 0
    end
  as trained_flag,
  round(try_divide(d.cumulative_learners, d.prev_month_mau) * 100, 2) as learner_to_mau
from
  data d 
left join main.gtm_data.core_accounts_curated c on d.account_id=c.account_id
left join main.it_core_dim.dim_dates t on d.period = t.date 
order by account_id, period


''')

# COMMAND ----------

trained_accounts_df.createOrReplaceTempView('trained_accounts')

# COMMAND ----------

# MAGIC %md # Trained Accounts Actuals vs Target

# COMMAND ----------

# DBTITLE 1,Trained Accounts Analysis Script
trained_accounts_actuals_df = spark.sql('''
                                        
  with periods as (
    select distinct fq2, max(period) as period 
    from main.field_learning_enablement.trained_accounts
    where processDate = (select max(processDate) from main.field_learning_enablement.trained_accounts)
    and fiscalYear = 2025
    group by 1
  )
  ,
  pre as (
  select
    *
  from
    trained_accounts
  -- where period = (select max(period) from trained_accounts)
  where period in (select period from periods)
)

,

final_overall as (
  select
    p.period,
    p.fq2,
    p.fiscalYear,
    "Overall" as grain_lvl_1,
    "Overall" as grain_lvl_2,
    "Overall" as grain_lvl_3,
    round(sum(trained_flag)/count(account_id),2) as trained_accounts
  from
    pre p
  group by
    all
  order by
    all
),

final_bu as (
  select
    p.period,
    p.fq2,
    p.fiscalYear,
    p.sales_business_unit as grain_lvl_1,
    "Overall" as grain_lvl_2,
    "Overall" as grain_lvl_3,
    round(sum(trained_flag)/count(account_id),2) as trained_accounts
  from
    pre p
  group by
    all
  order by
    all
),

final_bu_plus_1 as (
  select
    p.period,
    p.fq2,
    p.fiscalYear,
    p.sales_business_unit as grain_lvl_1,
    p.sales_subregion_level_1 as grain_lvl_2,
    "Overall" as grain_lvl_3,
    round(sum(trained_flag)/count(account_id),2) as trained_accounts
  from
    pre p
  group by
    all
  order by
    all
),
overall_trained_accounts_actuals as (
  select
    "Trained Accounts" as metric,
    *
  from
    final_overall
  union all
  select
    "Trained Accounts" as metric,
    *
  from
    final_bu
  union all
  select
    "Trained Accounts" as metric,
    *
  from
    final_bu_plus_1
)

,

trained_accounts_goals as (
  select
    *
  from
    main.field_learning_enablement.learning_enablement_okr_goals
  where
    fq2 >= "25-Q1"
    and metric = "Trained Accounts"
    and processDate =(
      Select
        max(processDate)
      from
        main.field_learning_enablement.learning_enablement_okr_goals
    )
),
goal_prep_set_1 as (
  select
    metric,
    fiscalyear,
    fq2 as timeframe,
    "Overall" as grain_lvl_1,
    "Overall" as grain_lvl_2,
    "Overall" as grain_lvl_3,
    goal as target
  from
    trained_accounts_goals
  where
    audience = "Overall"
  group by
    all
),
goal_prep_set_2 as (
  select
    metric,
    fiscalyear,
    fq2 as timeframe,
    value as grain_lvl_1,
    "Overall" as grain_lvl_2,
    "Overall" as grain_lvl_3,
    goal as target
  from
    trained_accounts_goals
  where
    audience = "BU"
  group by
    all
),
goal_prep_set_3 as (
  select
    metric,
    fiscalyear,
    fq2 as timeframe,
    case
      when value in ("DNB", "EDNB Verts","EE","EDNB ENT Tech","Startup") then "AMER Emerging"
      when value in ("CME", "LATAM", "MFG", "Retail") then "AMER Enterprise"
      when value in ("CAN", "PS", "FINS", "HLS") then "AMER Regulated Industries"
      when value in ("ANZ", "Asean + GCR", "India", "Japan", "Korea") then "APJ"
      when value in ("Central", "Northern", "SEMEA", "Emerging") then "EMEA"
    end as grain_lvl_1,
    value as grain_lvl_2,
    "Overall" as grain_lvl_3,
    goal as target
  from
    trained_accounts_goals
  where
    audience = "BU+1"
  group by
    all
),
overall_trained_accounts_goals as (
  select
    *
  from
    goal_prep_set_1
  union all
  select
    *
  from
    goal_prep_set_2
  union all
  select
    *
  from
    goal_prep_set_3
)
,

pre_final as 
(
select
  nvl(a.metric, b.metric) as metric,
  nvl(a.fq2, b.timeframe) as timeframe,
  nvl(a.fiscalYear, b.fiscalYear) as fiscalYear,
  nvl(a.grain_lvl_1,b.grain_lvl_1) as grain_lvl_1,
  nvl(a.grain_lvl_2,b.grain_lvl_2) as grain_lvl_2,
  nvl(a.grain_lvl_3,b.grain_lvl_3) as grain_lvl_3,
  nvl(a.trained_accounts,0) as trained_accounts,
  nvl(b.target, 0) as target
from
  overall_trained_accounts_actuals a
  full outer join overall_trained_accounts_goals b 
  on a.metric = b.metric
  and a.fq2 = b.timeframe
  and a.grain_lvl_1 = b.grain_lvl_1
  and a.grain_lvl_2 = b.grain_lvl_2
  and a.grain_lvl_3 = b.grain_lvl_3
)


select * from pre_final

''')

# COMMAND ----------

# DBTITLE 1,Fiscal Quarter Learners Report
dim_dates = spark.read.table('main.it_core_dim.dim_dates')

unique_quarters = (
  dim_dates
    .select('fiscal_year_quarter', 'fiscal_quarter_start_date', 'fiscal_quarter_end_date')
    .distinct()
)

learners_df_final = (
  learners_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == learners_df.timeframe, 'left')
    .select(
        'metric',
        'fiscalYear',
        'timeframe',
        'grain_lvl_1',
        'grain_lvl_2',
        'grain_lvl_3',
        F.col('cumulative_learners').alias('actuals'),
        'target',
        F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
        F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
      
      )
)

certs_df_final = (
  certs_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == certs_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'grain_lvl_1',
      'grain_lvl_2',
      'grain_lvl_3',
      F.col('total_certs').alias('actuals'),
      'target',
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
    )
)

badges_df_final = (
  badges_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == badges_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'grain_lvl_1',
      'grain_lvl_2',
      'grain_lvl_3',
      F.col('total_badges').alias('actuals'),
      'target',
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
    )
)

paid_df_final = (
  paid_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == paid_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'grain_lvl_1',
      'grain_lvl_2',
      'grain_lvl_3',
      F.col('total_delivered_revenue_pre_gaap').alias('actuals'),
      'target',
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
    )
)

mau_df_final = (
  mau_df
    .join(dim_dates, dim_dates.date == mau_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'grain_lvl_1',
      'grain_lvl_2',
      'grain_lvl_3',
      F.col('mau').alias('actuals'),
      'target',
      F.col('month_start_date').alias('timeframe_start_date'),
      F.col('month_end_date').alias('timeframe_end_date')
    )
)

learner_penetration_df_final = (
  learner_penetration_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == learner_penetration_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'grain_lvl_1',
      'grain_lvl_2',
      'grain_lvl_3',
      'actuals',
      'target',
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
  )
)


trained_accounts_actuals_df_final = (
  trained_accounts_actuals_df
    .join(unique_quarters, unique_quarters.fiscal_year_quarter == trained_accounts_actuals_df.timeframe, 'left')
    .select(
      'metric',
      'fiscalYear',
      'timeframe',
      'grain_lvl_1',
      'grain_lvl_2',
      'grain_lvl_3',
      F.col('trained_accounts').alias('actuals'),
      'target',
      F.col('fiscal_quarter_start_date').alias('timeframe_start_date'),
      F.col('fiscal_quarter_end_date').alias('timeframe_end_date')
  )
)


# COMMAND ----------

# DBTITLE 1,Education Metrics Transformation
# learners_df_final = (
#   learners_df
#     .select(
#         'metric',
#         'fiscalYear',
#         'timeframe',
#         'grain_lvl_1',
#         'grain_lvl_2',
#         'grain_lvl_3',
#         F.col('cumulative_learners').alias('actuals'),
#         'target'
#       )
# )

# certs_df_final = (
#   certs_df
#     .select(
#       'metric',
#       'fiscalYear',
#       'timeframe',
#       'grain_lvl_1',
#       'grain_lvl_2',
#       'grain_lvl_3',
#       F.col('total_certs').alias('actuals'),
#       'target'
#     )
# )

# badges_df_final = (
#   badges_df
#     .select(
#       'metric',
#       'fiscalYear',
#       'timeframe',
#       'grain_lvl_1',
#       'grain_lvl_2',
#       'grain_lvl_3',
#       F.col('total_badges').alias('actuals'),
#       'target'
#     )
# )

# paid_df_final = (
#   paid_df
#     .select(
#       'metric',
#       'fiscalYear',
#       'timeframe',
#       'grain_lvl_1',
#       'grain_lvl_2',
#       'grain_lvl_3',
#       F.col('total_delivered_revenue_pre_gaap').alias('actuals'),
#       'target'
#     )
# )

# mau_df_final = (
#   mau_df
#     .select(
#       'metric',
#       'fiscalYear',
#       'timeframe',
#       'grain_lvl_1',
#       'grain_lvl_2',
#       'grain_lvl_3',
#       F.col('mau').alias('actuals'),
#       'target'
#     )
# )

# learner_penetration_df_final = (
#   learner_penetration_df
#     .select(
#       'metric',
#       'fiscalYear',
#       'timeframe',
#       'grain_lvl_1',
#       'grain_lvl_2',
#       'grain_lvl_3',
#       'actuals',
#       'target'
#   )
# )

# COMMAND ----------

all_df = (
  learners_df_final
    .union(certs_df_final)
    .union(badges_df_final)
    .union(mau_df_final)
    .union(paid_df_final)
    .union(learner_penetration_df_final)
    .union(trained_accounts_actuals_df_final)
)

# COMMAND ----------

# DBTITLE 1,Pyspark DataFrame Column Casting
from pyspark.sql.types import DoubleType

# timeframe_window = W.Window.orderBy("timeframe")

all_df = (
  all_df
    .select(
      'metric', 
      'fiscalYear', 
      'timeframe',
      'grain_lvl_1',
      'grain_lvl_2',
      'grain_lvl_3',
      'actuals',
      F.col('target').cast(DoubleType()),
      'timeframe_start_date',
      'timeframe_end_date'
    )
    # .withColumn('prev_timeframe_actuals', F.lag('actuals', 1).over(timeframe_window))

)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Use Case Based Learners

# COMMAND ----------

# DBTITLE 1,MAU and Learner Analysis Query
usecase_learners = spark.sql('''
 with pre as (
  select
    --o.*,
    --c.sales_business_unit,
    --c.sales_subregion_level_1,
    --c.sales_subregion_level_2,
    --c.sales_subregion_level_3,
    --c.account_name,
    --c.account_id,
    --c.account_status,
    o.mau as mau,
    o.month as period,
    o.business_unit as sales_business_unit,
    o.sales_subregion_level_1,
    o.sales_subregion_level_2,
    o.sales_subregion_level_3,
    o.account_name,
    o.salesforce_account_id,
    o.account_status,
    d.is_fiscal_quarter_end,
    d.date as last_day_of_month,
    d.fiscal_quarter_end_date,
    d.fiscal_year as fiscalYear
  from
    maus_base o
    left join main.gtm_data.core_accounts_curated c on o.salesforce_account_id = c.account_id
    left join main.it_core_dim.dim_dates d on last_day(o.month) = d.date 
),

final_overall_1 as (
  select
  salesforce_account_id,
    period,
    last_day_of_month,
    is_fiscal_quarter_end,
    fiscal_quarter_end_date,
    fiscalYear,
    sum(mau) as mau
  from
    pre
  group by
    all
  order by
    all
) 

,
final_overall_2 as (
  select
    salesforce_Account_id,
    period,
    last_day_of_month,
    fiscal_quarter_End_date,
    is_fiscal_quarter_end,
    fiscalYear,
    mau,
    nvl(lag(mau) over (
    partition by salesforce_Account_id
      order by
        period
    ),0) as prev_qtr_mau
  from
    final_overall_1
  where
    (
      is_fiscal_quarter_end is true
      or period = date_trunc('month', current_date)
    )
)
,
mau_data_base as (
  select * 
  from final_overall_2 
  where salesforce_account_id is not null
)

,
usecase_data as (
  select
    snapshot_date,
    dateadd(day, -30, snapshot_date) :: date as from_date_30d,
    dateadd(day, -60, snapshot_date) :: date as from_date_60d,
    dateadd(day, -90, snapshot_date) :: date as from_date_90d,
    dateadd(day, -120, snapshot_date) :: date as from_date_120d,
    dateadd(day, -180, snapshot_date) :: date as from_date_180d,
    *
  except(snapshot_date)
  from
    main.gtm_data.core_usecase
  where
    snapshot_date =(
      select
        max(snapshot_date)
      from
        main.gtm_data.core_usecase
    )
)
,

learners as (
  select
    updated_account_id,
    updated_account_name,
    completed_date :: date,
    audience,
    count (distinct learner_user_id) as learners
  from
    main.field_learning_enablement.all_learners
  where
    processdate =(
      select
        max(processdate)
      from
        main.field_learning_enablement.all_learners
    )
    and audience in ("Customer", "Partner")
    and dataset = "net new learners"
  group by
    all
  order by
    all
) 
,


mau_data as 
(
  select * from mau_data_base where period=(Select max(period) from mau_data_base)
)


select  
  nvl(l.audience,"Unknown") as audience,
  nvl(sum(case when l.completed_date between from_date_30d and  snapshot_date then learners end),0) as t30d_learners,
  nvl(sum(case when l.completed_date between from_date_60d and  snapshot_date then learners end),0) as t60d_learners,
  nvl(sum(case when l.completed_date between from_date_90d and  snapshot_date then learners end),0) as t90d_learners,
  nvl(sum(case when l.completed_date between from_date_120d and  snapshot_date then learners end),0) as t120d_learners,
  nvl(sum(case when l.completed_date between from_date_180d and  snapshot_date then learners end),0) as t180d_learners,
  nvl(sum(learners),0) as all_time_learners,
  m.mau as prev_month_mau,
  m.prev_qtr_mau as prev_quarter_mau,
  u.*
  from usecase_data u
  left join learners l on u.account_id=l.updated_account_id
  left join mau_data m on u.account_id=m.salesforce_Account_id
group by all

''')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # DSA Accounts

# COMMAND ----------

# DBTITLE 1,Revenue Scheduling Analysis Query
dsa_accounts_df = spark.sql('''
with cse_subs AS (
  SELECT
    account_id,
    sum(backlog_detail_time_revenue) + sum(backlog_detail_milestone_revenue) as revenue_scheduled,
    collect_set(project_Service_tier) as cse_sub_type
  FROM
    main.gtm_data.core_professional_services_scheduled_backlog
  WHERE
     snapshot_date = (Select max(snapshot_date) from main.gtm_data.core_professional_services_scheduled_backlog)
   AND practice_name in ("Professional Services")
   and core_professional_services_scheduled_backlog.project_stage not in ("Cancelled","Completed")
    and project_service_type in ('Customer Success Subscription',"Guided Success Subscription")
    and backlog_detail_end_fiscal_year_month >= (select distinct fiscal_year_month from main.it_core_dim.dim_dates where date=current_date::date)
  GROUP BY
    all 
    having (sum(backlog_detail_time_revenue) + sum(backlog_detail_milestone_revenue))<>0
),
learning_subs AS (
  SELECT
    account_id,
    sum(backlog_detail_time_revenue) + sum(backlog_detail_milestone_revenue) as revenue_scheduled,
    collect_Set(project_Service_tier) as learning_sub_type
  FROM
    main.gtm_data.core_professional_services_scheduled_backlog
  WHERE
     snapshot_date = (Select max(snapshot_date) from main.gtm_data.core_professional_services_scheduled_backlog)
    AND practice_name in ("Training")
    and project_service_type='Learning Subscription'
    and backlog_detail_end_fiscal_year_month >= (select distinct fiscal_year_month from main.it_core_dim.dim_dates where date=current_date::date)
  GROUP BY
    1
    having (sum(backlog_detail_time_revenue) + sum(backlog_detail_milestone_revenue))<>0
),
cses AS (
  select
    a.id as account_id,
    a.name as account_name,
    c.sales_business_unit,
    c.cse_tier,
    u.name as DSA_Name,
    u.email as dsa_email
  from
    main.sfdc_bronze.account a
    inner join main.gtm_data.core_accounts_curated c on a.id = c.account_id
    inner join main.sfdc_bronze.user u on a.cse_new__c = u.id
    and u.processdate =(
      Select
        max(processdate)
      from
        main.sfdc_bronze.user
    )
  where
    a.processDate =(
      Select
        max(processdate)
      from
        main.sfdc_bronze.account
    )
    and (u.name not ilike '%unassigned%')
    and nvl(CSE_New__c, 'None') <> 'None'
  union
  select
    a.id as account_id,
    a.name as account_name,
    c.sales_business_unit,
    c.cse_tier,case
      when u.name ilike '%unassigned%' then null
      else u.name
    end as DSA_Name,
    case
      when u.name ilike '%unassigned%' then null
      else u.email
    end as dsa_email
  from
    main.sfdc_bronze.account a
    inner join main.gtm_data.core_accounts_curated c on a.id = c.account_id
    left join main.sfdc_bronze.user u on a.cse_new__c = u.id
    and u.processdate =(
      Select
        max(processdate)
      from
        main.sfdc_bronze.user
    )
  where
    a.processDate =(
      Select
        max(processdate)
      from
        main.sfdc_bronze.account
    )
    and a.id in (
      select
        distinct account_id
      from
        cse_subs
    )
) -- select count(distinct account_id) from cses
,
cses_filters as (
  select
    c.*,
    w.businessTitle,
    w.cost_center,
    w.Supervisory_Organization_cleaned,
    w.status
  from
    cses c
    left join main.field_learning_enablement.workday w on nvl(lower(c.dsa_email), 'Unknown') = lower(w.primaryWorkEmail)
    and w.processdate =(
      Select
        max(processdate)
      from
        main.field_learning_enablement.workday
    )
),
cses_filtered as (
  select
    *
  from
    cses_filters
  where
    dsa_name is null
    or (
      cost_center in ('706 DSA', '714 Paid DSA', '705 Shared Technical Services',"404 Channel - Field Engineering")
      and 
      status
    )
),
pre as (
  select
    c.*,
    case
      when nvl(c1.account_id, 'Unknown') <> 'Unknown' then 1
      else 0
    end as cse_sub_flag,
    c1.cse_sub_type,
    case
      when nvl(l.account_id, 'Unknown') <> 'Unknown' then 1
      else 0
    end as learning_sub,
    l.learning_sub_type
  from
    cses_filtered c
    left join cse_subs c1 on c.account_id = c1.account_id
    left join learning_subs l on c.account_id = l.account_id
)
select
  account_id,
  account_name,
  sales_business_unit,
  dsa_name,
  dsa_email,
  cse_sub_flag,
  cse_sub_type,
  learning_sub,
  learning_sub_type
  -- ,cost_center
from
  pre
where account_id not in 
(
"0016100000d2oXCAAY",
"0014N00001iGXrfQAG",
"0018Y00002fpwbRQAQ"
)
order by
  2 
''')

# COMMAND ----------

dsa_accounts_df.createOrReplaceTempView('dsa_data')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Half Day Classes

# COMMAND ----------

# DBTITLE 1,Spark SQL Training Data Processor
ue_airtable_df = spark.sql('''
with data AS (
  select
    *,
    (datediff(end_Date, start_date)) + 1 as days,
    (split(time, "-")) as times,
    size((split(time, "-"))) as length
  from
    main.field_learning_enablement.training_operations_ilt_schedule_master
  where
    processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.training_operations_ilt_schedule_master
    ) 
) 
,
pre AS (
  select
    *,
    case
      when (
        length = 1
        or length = 2
      ) then trim(element_at(split(time, "-"), 1))
      else "NA"
    end as start_times,
    case
      when (length = 2) then trim(element_at(split(time, "-"), 2))
      else "NA"
    end as end_times 
  from
    data
),
final AS (
  select
    *,
    nvl(
      timestampdiff(
        MINUTE,
        to_timestamp(start_times, 'h:mma'),
        to_timestamp (end_times, 'h:mma')
      ) / 60,
      0
    ) as utilization_per_day_hours
  from
    pre
),
final_2 as (
  select
    *,
    case
      when size(split(instructor_email, ",")) > 1 then element_at (split(instructor_email, ","), 1)
      else instructor_email
    end as primary_instructor,
    date_trunc('month', end_date) :: date as util_month,
    replace(
      replace(replace(replace(ta_emails, "["), "]"), "'"),
      "'"
    ) as ta_emails_updated,
    size(
      split(replace(replace(ta_emails, "["), "]"), ",")
    ) as no_of_tas 
  from
    final
  where
    fy <> 'nan'
) 
,
final_3 as (
  select
    *,
    case
      when no_of_tas = 1
      and (
        ta_emails_updated = ""
        or ta_emails_updated = 'N/A'
      ) then 0
      else no_of_tas
    end as no_of_tas_updated
  from
    final_2
) 

,

pre_2 as 
(
  select
fiscal_year_quarter,
f.end_date,
case when (projects ilike '%get%started%' or academy_session_number='12344') then "onboarding" else "half_day" end as class_type,
training_type,
 case when (businesstitle ilike '%instructor%' or primaryworkemail in ("subramanian.iyer@databricks.com","david.harris@databricks.com")) then "Internal" else "External" end as bucket,
  academy_session_number,
  d.id as session_id,
  f.status,
  replace(
      replace(replace(replace(primary_instructor, "["), "]"), "'"),
      "'"
    ) as instructor_email_primary,
  w.businesstitle,
  w.Manager

from final_3 f
inner join main.it_core_dim.dim_dates d on f.end_date::date=d.date
left join main.it_training_silver.docebo_ilt_sessions d on f.academy_Session_number=d.code and d.processdate=(Select max(processdate) from main.it_training_silver.docebo_ilt_sessions)
left join main.field_learning_enablement.workday w on  replace(
      replace(replace(replace(f.primary_instructor, "["), "]"), "'"),
      "'"
    )=w.primaryWorkEmail
where provider = "User Enablement" 
  and line_of_business="User Enablement (Free)"
  and (end_date :: date >= '2023-05-01')
  and f.status not ilike  '%cancelled%'
  and academy_session_number<>0
)



select * from pre_2

                           
''')

# COMMAND ----------

# DBTITLE 1,Airtable Classes DataFrame Viewer
ue_airtable_df.createOrReplaceTempView('airtable_classes')

# COMMAND ----------

# DBTITLE 1,Half Day Enrollment Analysis
half_day_df = spark.sql('''
with accounts as (
  select
    distinct account_id,
    Account_Name,
    dsa_name,
    dsa_email
  from
    dsa_data
  where
    dsa_name is not null
),
pre as (
  select
    "Public ILT" as grouping,
    e.learner_user_id as attended_or_completed,
    e.updated_Account_id,
    a.account_id,
    a.dsa_name,
    e.completed_date,
    e.session_id,
    e.session_code,
    e.completed_fq2,
    e.ended_timestamp :: date as ended_timestamp,
    e.status,
    e.audience
  from
    main.field_learning_enablement.all_enrollments e
    left join accounts a on e.updated_account_id = a.account_id
  where 1=1
    -- status = 'completed'
    and course_type = 'classroom'
    and processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.all_enrollments
    )
    and (
      course_id in (
        1683, 
        1684, 
        1686, 
        1687, 
        1808, 
        1809, 
        1810,
        1971,
        2662,
        2666,
        2668,
        2673,
        2398,
        2593,
        2580,
        2381,
        2598,
        2585,
        2393,
        2591,
        2578,
        2403,
        2596,
        2582, 
        2609
      )
      or e.session_code in (
        select
          distinct academy_session_number
        from
          airtable_classes
        where
          class_type = 'half_day'
          and training_type = "Public"
      )
    )
  union all
  select
    "Private ILT" as grouping,
    e.learner_user_id as attended_or_completed,
    e.updated_Account_id,
    a.account_id,
    a.dsa_name,
    e.completed_date,
    e.session_id,
    e.session_code,
    e.completed_fq2,
    e.ended_timestamp :: date as ended_timestamp,
    e.status,
    e.audience
  from
    main.field_learning_enablement.all_enrollments e
    left join accounts a on e.updated_account_id = a.account_id
  where 1=1
    -- e.status = 'completed'
    and e.course_type = 'classroom'
    and e.processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.all_enrollments
    )
    and (
      e.session_code in (
        select
          distinct academy_session_number
        from
          airtable_classes
        where
          class_type = 'half_day'
          and training_type = "Private"
      )
    )
)
,
-- session_enrollments as (
--   select 
--     session_id, 
--     count(distinct case when status = 'completed' then learner_user_id end) as completed, 
--     count(distinct learner_user_id) as enrolled
--   from main.field_learning_enablement.ilt_enrollments
--   where processDate = (select max(processDate) from main.field_learning_enablement.ilt_enrollments)
--   group by 1
-- )
-- ,
learner_region as (
  select id, region_derived
  from main.field_learning_enablement.docebo_users
  where processDate = (select max(processDate) from main.field_learning_enablement.docebo_users)
)

select
  p.*,
  d.fiscal_year_quarter,
  d.calendar_year_month,
  s.course_name,
  s.course_code,
  s.session_name,
  l.region_derived,
  nvl(c.sales_business_unit, "Unknown") as sales_business_unit,
  nvl(c.sales_subregion_level_1, "Unknown") as sales_subregion_level_1,
  nvl(c.sales_subregion_level_2, "Unknown") as sales_subregion_level_2,
  nvl(c.sales_subregion_level_3, "Unknown") as sales_subregion_level_3,
  nvl(c.account_name, "Unknown") as account_name

from
  pre p
  inner join main.it_core_dim.dim_dates d on p.ended_timestamp = d.date
  left join main.it_training_silver.docebo_ilt_sessions s on p.session_id = s.id and s.processDate = (select max(processDate) from main.it_training_silver.docebo_ilt_sessions)
  -- left join session_enrollments e on p.session_id = e.session_id
  left join learner_region l on p.attended_or_completed = l.id
  left join main.gtm_data.core_accounts_curated c on p.updated_account_id = c.account_id
''')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Learner Treshold

# COMMAND ----------

# DBTITLE 1,Employee Learning Path Analysis
learner_threshold_df = spark.sql('''
with avg_time_pre_rank AS (
  select 
      id, 
      expected_time_to_complete_in_seconds,
      rank() over (partition by id order by expected_time_to_complete_in_seconds nulls last , category_code desc) as rank 
  from main.it_training_silver.docebo_courses
  where processDate = (select max(processDate) from main.it_training_silver.docebo_courses)

),

employee_data AS (
  select 
  --  department, 
  --  category, 
    `1st_level_manager`,
    `1st_level_manager_name`,
    `2nd_level_manager`, 
    `2nd_level_manager_name`,
    `3rd_level_manager`, 
    `3rd_level_manager_name`,
    `4th_level_manager`,
    `4th_level_manager_name`,
    `5th_level_manager`, 
    `5th_level_manager_name`,
    `6th_level_manager`,
    `6th_level_manager_name`,
    Supervisory_Organization_cleaned,
    primaryWorkEmail,
    sha2(primaryWorkEmail,256) as email_hash
  from main.field_learning_enablement.workday
  where processDate = (select max(processDate) from main.field_learning_enablement.workday)
  and worker_type='Employee'
  and Termination_Date is null
)
,

avg_time AS (
  select * from avg_time_pre_rank where rank=1
)
,

sp_enrollments as (
  select
    processdate,
    learner_user_id,
    learner_email,
    learner_email_hash,
    learner_email_domain,
    learner_alternate_email,
    learner_alternate_email_hash,
    learner_alternate_email_domain,
    learner_branch_code,
    account_id,
    account_name,
    ultimate_parent_account_id,
    ultimate_parent_account_name, 
    updated_account_id,
    updated_account_name,
    updated_ultimate_parent_account_id,
    updated_ultimate_parent_account_name, 
    audience,
    course_code,
    course_name,
    course_type,
    category_code,
    status,
    enrolled_timestamp :: date as enrolled_date,
    completed_timestamp :: date as completed_date,
    completed_timestamp,
    source,
    country_code, 
    country_name, 
    region, 
    d.fiscal_year_quarter as fq2,
    cast(d.calendar_month as INT) as month,
    cast(d.calendar_year as INT) as year,
    cast(d.fiscal_year as INT) as fiscalYear,
    d.fiscal_quarter_start_date as qtr_start_date,
    d.fiscal_quarter_end_date as qtr_end_date,
    t.expected_time_to_complete_in_seconds,
    match_method, 
    country_derived,
    region_derived
  from main.field_learning_enablement.self_paced_enrollments e
  inner join main.it_core_dim.dim_dates d on e.completed_timestamp::date=d.date 
  left join avg_time t on e.course_id = t.id
  where e.status in ('completed')
  and e.source = 'Learndot'
  and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
  and e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
  
  union all

  select     
    processdate,
    learner_user_id,
    learner_email,
    learner_email_hash,
    learner_email_domain,
    learner_alternate_email,
    learner_alternate_email_hash,
    learner_alternate_email_domain,
    learner_branch_code,
    account_id,
    account_name,
    ultimate_parent_account_id,
    ultimate_parent_account_name, 
    updated_account_id,
    updated_account_name,
    updated_ultimate_parent_account_id,
    updated_ultimate_parent_account_name, 
    audience,
    course_code,
    course_name,
    course_type,
    category_code,
    status,
    enrolled_timestamp :: date as enrolled_date,
    completed_timestamp :: date as completed_date,
    completed_timestamp,
    source,
    country_code, 
    country_name, 
    region, 
    d.fiscal_year_quarter as fq2,
    cast(d.calendar_month as INT) as month,
    cast(d.calendar_year as INT) as year,
    cast(d.fiscal_year as INT) as fiscalYear,
    d.fiscal_quarter_start_date as qtr_start_date,
    d.fiscal_quarter_end_date as qtr_end_date,
    t.expected_time_to_complete_in_seconds,
    match_method, 
    country_derived,
    region_derived
  from main.field_learning_enablement.self_paced_enrollments e
  inner join main.it_core_dim.dim_dates d on e.completed_timestamp::date=d.date
  left join avg_time t on e.course_id = t.id
  where e.status in ('completed')
  and e.source='Docebo'
  and e.category_code in ('PART','ACAD','FENG/CUSU','FENG')
  -- and e.course_id not in (723, 721, 724, 687, 1182)
  and (e.course_code ilike ('%-SLP%') or e.course_code ilike '%-ILTB-%')
  and e.course_code not ilike ('%DNR')
  and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
  and e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
),
ilt_enrollments_pre as (
  select 
    processdate,
    learner_user_id,
    learner_email,
    learner_email_hash,
    learner_email_domain,
    learner_alternate_email,
    learner_alternate_email_hash,
    learner_alternate_email_domain,
    learner_branch_code,
    account_id,
    account_name,
    ultimate_parent_account_id,
    ultimate_parent_account_name, 
    updated_account_id,
    updated_account_name,
    updated_ultimate_parent_account_id,
    updated_ultimate_parent_account_name, 
    audience,
    course_code,
    course_name,
    course_type,
    category_code,
    status,
    enrolled_timestamp :: date as enrolled_date,
    completed_timestamp :: date as completed_date,
    completed_timestamp,
    source,
    country_code, 
    country_name,
    region,
    d.fiscal_year_quarter as fq2,
    cast(d.calendar_month as INT) as month,
    cast(d.calendar_year as INT) as year,
    cast(d.fiscal_year as INT) as fiscalYear,
    d.fiscal_quarter_start_date as qtr_start_date,
    d.fiscal_quarter_end_date as qtr_end_date,
    3*60*60 as expected_time_to_complete_in_seconds,
    match_method, 
    country_derived,
    region_derived
  from main.field_learning_enablement.ilt_enrollments e
  inner join main.it_core_dim.dim_dates d on e.completed_timestamp::date=d.date
  where e.status in ('completed')
  and e.source = 'Learndot'
  and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
  and e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)

  union all
  
  select 
    processdate,
    learner_user_id,
    learner_email,
    learner_email_hash,
    learner_email_domain,
    learner_alternate_email,
    learner_alternate_email_hash,
    learner_alternate_email_domain,
    learner_branch_code,
    account_id,
    account_name,
    ultimate_parent_account_id,
    ultimate_parent_account_name, 
    updated_account_id,
    updated_account_name,
    updated_ultimate_parent_account_id,
    updated_ultimate_parent_account_name, 
    audience,
    course_code,
    course_name,
    course_type,
    category_code,
    status,
    enrolled_timestamp :: date as enrolled_date,
    completed_timestamp :: date as completed_date,
    completed_timestamp,
    source,
    country_code, 
    country_name, 
    region, 
    d.fiscal_year_quarter as fq2,
    cast(d.calendar_month as INT) as month,
    cast(d.calendar_year as INT) as year,
    cast(d.fiscal_year as INT) as fiscalYear,
    d.fiscal_quarter_start_date as qtr_start_date,
    d.fiscal_quarter_end_date as qtr_end_date,
    t.expected_time_to_complete_in_seconds,
    match_method, 
    country_derived,
    region_derived
  from main.field_learning_enablement.ilt_enrollments e
  inner join main.it_core_dim.dim_dates d on e.completed_timestamp::date=d.date
  left join avg_time t on e.course_id = t.id
  where e.status in ('completed')
  and e.category_code in ('PART','ACAD','FENG/CUSU','FENG', 'ACAD-ALL-ILT-PAID')
  and e.source = 'Docebo'
  and e.learner_branch_code in ('DBK_PRTNR','DBKS_ACDMY','DBK_MCSFT','DBK_EMP')
  and e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
),

ilt_enrollments_dedupe AS 
(
  select 
    *,
    rank() over (partition by i.learner_user_id, i.course_code, i.completed_timestamp order by i.category_code) as dedupe_rank
  from ilt_enrollments_pre i
)
,

ilt_enrollments_final AS (
  select * 
  from ilt_enrollments_dedupe 
  where dedupe_rank=1
)
,

sp_enrollments_dedupe as
(
  select 
    s.*, 
    rank() over (partition by s.learner_user_id, s.course_code, s.completed_timestamp order by s.category_code) as dedupe_rank 
  from sp_enrollments s
)
,

sp_enrollments_final as
(
  select * from sp_enrollments_dedupe where dedupe_rank=1
)
,

all_enrollments as
(
  select * from ilt_enrollments_final
  union all
  select * from sp_enrollments_final
)

,
rolling_totals as (
  select 
    completed_timestamp, 
    learner_user_id, 
    course_code, 
    category_code,
    expected_time_to_complete_in_seconds,
    sum(expected_time_to_complete_in_seconds) over (partition by learner_user_id order by completed_timestamp asc ROWS BETWEEN unbounded preceding AND CURRENT ROW) as rollingTotal 
  from all_enrollments e
  group by 1,2,3,4,5
)
,
all_enrollments_filtered as (
  select 
    s.*,
    t.rollingTotal
  from all_enrollments s 
  left join rolling_totals t
    on s.learner_user_id = t.learner_user_id
    and s.course_code = t.course_code
    and s.completed_timestamp = t.completed_timestamp
  -- where t.rollingTotal >= 3*60*60
)
,

learners as 
(
select distinct learner_user_id,fq2
from main.field_learning_enablement.all_learners
where dataset="net new learners"
and processDate=(select max(processDate) from main.field_learning_enablement.all_learners)
and audience ilike '%Customer%'
-- and fq2<="24-Q4"
and nvl(updated_account_id,'Unknown')<>'Unknown'
)

,

learners_enrollments as 
(
select * from all_enrollments_filtered where learner_user_id in (select learner_user_id from learners) --and status="completed"
)


,

pre as 
(
select *,
case when rollingTotal>=10800 then 1 else 0 end as learner_flag
 from learners_enrollments
-- where learner_user_id='16974'
-- where rollingTotal<10800
order by learner_user_id, rollingtotal
)
,

final as 
(
    select 
      *, 
      rank() over (partition by learner_user_id, learner_flag order by rollingTotal, completed_timestamp) as rank_sort 
    from pre
)
,

final_2 as 
(
select *
from final
where learner_flag=0 or (learner_flag = 1 and rank_sort = 1)
)

select * from final_2
''')

# COMMAND ----------

# MAGIC %sql 
# MAGIC
# MAGIC select *
# MAGIC from main.field_learning_enablement.learner_threshold
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.learner_threshold)

# COMMAND ----------

learner_threshold_df.createOrReplaceTempView('learner_threshold')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Program Table

# COMMAND ----------

# DBTITLE 1,Program Classification Query
program_table_df = spark.sql('''
with program_table as (
  select
    name,
    code,
    id,
    case
      when code in (
        "ACAD-CUST-ILT-v1-FREE-DAISADPA-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISBDLLM-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISDAD-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAIS23DED-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISPLA-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISDLP-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISeed-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISGCPPA-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISGAIF-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISIDSQL-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISMLP-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISPTAS-ACT",
        "ACAD-CUST-ILT-v1-FREE-DAISSTDD-ACT",
        "ACAD-CUST-ILT-v1-FREE-ADAIS23DED-ACT",
        "ACAD-CUST-ILT-v1-FREE-ITAS-ACT"
      ) then 'DAIS'
      when (name ilike '%DAIS 2024%' and code not ilike 'SLEN%') then 'DAIS 2024'
      when code in (
        "ACAD-ALL-SP-v1-FREE-DIPFWT-ACT",
        "ACAD-ALL-SP-v1-FREE-BDLLMWT-ACT",
        "ACAD-ALL-SP-v1-FREE-GSWDEWT-ACT",
        "ACAD-ALL-SP-v1-FREE-DAIWT-ACT"
      ) then 'DAIWT'
      when code in (
        "ACAD-CUST-BLND-v1-PAID-DAWDILE-ACT",
        "ACAD-CUST-BLND-v1-PAID-DEWDILE-ACT",
        "ACAD-CUST-BLND-v1-PAID-IPDSDEILE-ACT"
      ) then "ILF"
      -- when code in (
      --   "ACAD-CUST-ILT-v1-FREE-DWWRAW-ACT",
      --   -- "ACAD-CUST-ILT-v1-FREE-DAAWWDSPVT-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-DAAWWDS-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-PODLAP-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-DPWDLT-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-DSMDL-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-DGWUC-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-SSSDLT-ACT"
      -- ) then "Public Half-Day" -- rename to Public Half-Day Free
      -- when code in (
      --   "ACAD-CUST-ILT-v1-FREE-DGWUCPVT-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-DAAWWDSPVT-ACT",
      --   "ACAD-PART-ILT-PUBLIC-v1-FREE-CSTM-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-SSSDLTPVT-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-PODLAPPVT-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-DPWDLTPVT-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-DSMDLPVT-ACT",
      --   "ACAD-CUST-ILT-v1-FREE-DWWRAWPVT-ACT",
      --   "ACAD-PART-ILT-PUBLIC-v1-FREE-CSTM-ACT" -- Tailored workshops
      -- ) then "Private Half-Day" -- rename to Private Half-Day Free
      when code ilike '%ILTHDC%FREE%' then "Half-Day Free"
      when code ilike '%ILTHDC%PAID%' then "Half-Day Paid"
      when (
        code in (
          "ACAD-ALL-ILTPRV-v2-PAID-DEWD-ACT",
          "ACAD-ALL-ILTPUB-v2-PAID-DEWD-ACT",
          "ACAD-CUST-ILTPUB-v1-PAID-ASPWD-ACT",
          "ACAD-CUST-ILTPRV-v1-PAID-DAWD-ACT",
          "ACAD-ALL-ILTPRV-v1-PAID-OASOD-ACT",
          "ACAD-CUST-ILTPRV-v1-PAID-ASPWD-ACT",
          "ACAD-CUST-ILTPUB-v1-PAID-DAWD-ACT",
          "ACAD-CUST-ILTPUB-v1-PAID-IPDSDE-ACT",
          "ACAD-CUST-ILTPRV-v1-PAID-IPDSDE-ACT",
          "ACAD-ALL-ILTPUB-v1-PAID-OASOD-ACT",
          "ACAD-CUST-ILTPRV-v1-PAID-MLINPROD-ACT",
          "ACAD-CUST-ILTPUB-v1-PAID-SMLWAS-ACT",
          "ACAD-CUST-ILTPRV-v1-PAID-SMLWAS-ACT",
          "ACAD-CUST-ILTPUB-v1-PAID-MLINPROD-ACT",
          "ACAD-CUST-ILTPUB-v1-PAID-ADEWD-ACT",
          "ACAD-CUST-ILT-v1-PAID-LLMWDBPVT-ACT",
          "ACAD-CUST-ILT-v1-PAID-LLMWDB-ACT",
          "ACAD-ALL-ILTPRV-v1-PAID-DLWDB-ACT",
          "ACAD-ALL-ILTPUB-v1-PAID-DLWDB-ACT",
          "ACAD-CUST-ILTPRV-v1-PAID-ADEWD-ACT",
          "ACAD-CUST-ILT-v1-FREE-ONBDEDSPVT-ACT",
          "ACAD-PART-ILT-PUBLIC-v1-FREE-CSTM-ACT"
        )
      ) then "Paid" -- need to add OR session_id in one of the Paid Classes (that way we will capture the haf day paid, we need to move this classification above the half-day paid. 
      when (
        code in (
          "ACAD-ALL-SLP-v4-PAID-DAWD-ACT",
          "ACAD-PART-SLP-v4-DAWD-ACT",
          "ACAD-CUST-SLP-GSWDDE-ENG-V1",
          "ACAD-PART-SLP-GSWDDE-ENG-V1",
          "ACAD-ALL-SLP-ODL-v3-PAID-DEWDVCT-ACT",
          "ACAD-PART-SLP-DEWDVCT-v1",
          "ACAD-ALL-SLP-ODL-v3-PAID-ADEWDVCT-ACT",
          "ACAD-PART-SLP-ADEWD-v1",
          "ACAD-ALL-SLP-ODL-v3-PAID-ASPWD-ACT",
          "ACAD-PART-SLP-ASPWD-v1",
          "ACAD-CUST-SLP-GSWDML-ENG-V1",
          "ACAD-PART-SLP-GSWDML-ENG-V1",
          "ACAD-CUST-SLP-MLWD-ENG-V1",
          "ACAD-PART-DAL-MLWD-ENG-V1",
          "ACAD-CUST-SLP-DPML-ENG-v1",
          "ACAD-PART-SLP-DPML-ENG-v1",
          "ACAD-CUST-SLP-MLMDEV-ENG-V1",
          "ACAD-PART-SLP-MLMDEV-ENG-V1",
          "ACAD-CUST-SLP-MLMDEP-ENG-V1",
          "ACAD-PART-SLP-MLMDEP-ENG-V1",
          "ACAD-ALL-SLP-ODL-v1-PAID-DLWD-RET",
          "ACAD-PART-SLP-DLWD-v1-RET",
          "ACAD-CUST-SLP-ODL-V1-PDSDE",
          "ACAD-PART-SLP-PDSDE-v1",
          "ACAD-CUST-SLP-NCODA-ENG-v1",
          "ACAD-PART-SLP-NCODA-ENG-v1",
          "ACAD-CUST-SLP-NCOMS-ENG-v1",
          "ACAD-PART-SLP-NCOMS-ENG-v1"
        )
      ) then "Academy Labs Free"
    end as program
  from
    main.it_training_silver.docebo_courses
  where
    processDate = (
      select
        max(processDate)
      from
        main.it_training_silver.docebo_courses
    )
    and code in (
      "ACAD-CUST-ILT-v1-FREE-DAISADPA-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISBDLLM-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISDAD-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAIS23DED-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISPLA-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISDLP-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISeed-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISGCPPA-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISGAIF-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISIDSQL-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISMLP-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISPTAS-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAISSTDD-ACT",
      "ACAD-CUST-ILT-v1-FREE-ADAIS23DED-ACT",
      "ACAD-CUST-ILT-v1-FREE-ITAS-ACT",
      "ACAD-ALL-SP-v1-FREE-DIPFWT-ACT",
      "ACAD-ALL-SP-v1-FREE-BDLLMWT-ACT",
      "ACAD-ALL-SP-v1-FREE-GSWDEWT-ACT",
      "ACAD-ALL-SP-v1-FREE-DAIWT-ACT",
      "ACAD-CUST-BLND-v1-PAID-DAWDILE-ACT",
      "ACAD-CUST-BLND-v1-PAID-DEWDILE-ACT",
      "ACAD-CUST-BLND-v1-PAID-IPDSDEILE-ACT",
      "ACAD-CUST-ILT-v1-FREE-DWWRAW-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAAWWDS-ACT",
      "ACAD-CUST-ILT-v1-FREE-PODLAP-ACT",
      "ACAD-CUST-ILT-v1-FREE-DPWDLT-ACT",
      "ACAD-CUST-ILT-v1-FREE-DSMDL-ACT",
      "ACAD-CUST-ILT-v1-FREE-DGWUC-ACT",
      "ACAD-CUST-ILT-v1-FREE-SSSDLT-ACT",
      "ACAD-CUST-ILT-v1-FREE-DGWUCPVT-ACT",
      "ACAD-CUST-ILT-v1-FREE-DAAWWDSPVT-ACT",
      "ACAD-PART-ILT-PUBLIC-v1-FREE-CSTM-ACT",
      "ACAD-CUST-ILT-v1-FREE-SSSDLTPVT-ACT",
      "ACAD-CUST-ILT-v1-FREE-PODLAPPVT-ACT",
      "ACAD-CUST-ILT-v1-FREE-DPWDLTPVT-ACT",
      "ACAD-CUST-ILT-v1-FREE-DSMDLPVT-ACT",
      "ACAD-CUST-ILT-v1-FREE-DWWRAWPVT-ACT",
      "ACAD-ALL-ILTPRV-v2-PAID-DEWD-ACT",
      "ACAD-ALL-ILTPUB-v2-PAID-DEWD-ACT",
      "ACAD-CUST-ILTPUB-v1-PAID-ASPWD-ACT",
      "ACAD-CUST-ILTPRV-v1-PAID-DAWD-ACT",
      "ACAD-ALL-ILTPRV-v1-PAID-OASOD-ACT",
      "ACAD-CUST-ILTPRV-v1-PAID-ASPWD-ACT",
      "ACAD-CUST-ILTPUB-v1-PAID-DAWD-ACT",
      "ACAD-CUST-ILTPUB-v1-PAID-IPDSDE-ACT",
      "ACAD-CUST-ILTPRV-v1-PAID-IPDSDE-ACT",
      "ACAD-ALL-ILTPUB-v1-PAID-OASOD-ACT",
      "ACAD-CUST-ILTPRV-v1-PAID-MLINPROD-ACT",
      "ACAD-CUST-ILTPUB-v1-PAID-SMLWAS-ACT",
      "ACAD-CUST-ILTPRV-v1-PAID-SMLWAS-ACT",
      "ACAD-CUST-ILTPUB-v1-PAID-MLINPROD-ACT",
      "ACAD-CUST-ILTPUB-v1-PAID-ADEWD-ACT",
      "ACAD-CUST-ILT-v1-PAID-LLMWDBPVT-ACT",
      "ACAD-CUST-ILT-v1-PAID-LLMWDB-ACT",
      "ACAD-ALL-ILTPRV-v1-PAID-DLWDB-ACT",
      "ACAD-ALL-ILTPUB-v1-PAID-DLWDB-ACT",
      "ACAD-CUST-ILTPRV-v1-PAID-ADEWD-ACT",
      "ACAD-CUST-ILT-v1-FREE-ONBDEDSPVT-ACT",
      "ACAD-PART-ILT-PUBLIC-v1-FREE-CSTM-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-DWWRAWPV-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-PODLAP-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-DGWUC-ACT",
      "ACAD-CUST-CUST-ILTHDC-v1-PAID-DPML-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-MLMDEP-ENG",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-MLMDEVPV-ENG",
      "ACAD-CUST-ILTHDC-v1-PAID-MLO-ENG",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-SSSDLT-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-DSMDLPV-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-DAAWWDSPVT-ACT",
      "ACAD-ALL-ILTHDC-DAIS-v1-PAID-MLMDEV-ENG",
      "ACAD-ALL-ILTHDC-DAIS-v1-PAID-DPML-ENG",
      "ACAD-CUST-ILTHDC-v1-PAID-GAIAEG-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-MLMDEPPV-ENG",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-CUSTOMERGENAIPVT-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-DSMDL-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-MLOPV-ENG",
      "ACAD-CUST-ILTHDC-v1-PAID-GAIAD-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-SSSDLT-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-DAAWWDS-ACT",
      "ACAD-ALL-ILTHDC-DAIS-v1-PAID-MLO-ENG",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-DPWDLTPV-ACT",
      "ACAD-CUST-CUST-ILTHDC-v1-PAID-DPMLPV-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-DPWDLT-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-GAIADM-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-DGWUCPV-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-MLMDEV-ENG",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-PODLAPPV-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-DWWRAW-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-GAISD-ACT",
      "ACAD-ALL-ILTHDC-DAIS-v1-PAID-MLMDEP-ENG",
      "ACAD-CUST-ILTHDC-v1-PAID-DSADLT-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-DWWDW-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-BDPWDLTPV-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-DWWDW-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-BDPWDLT-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-DINWDL-ACT",
      "ACAD-CUST-ILTHDC-v1-PAID-DIWDL-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-PAID-DSWDLT-ACT",
      "ACAD-CUST-CUST-ILTHDC-v1-FREE-DPML-ACT",
      "ACAD-CUST-ILTHDC-PVT-v1-FREE-DPWDLT-ACT",
      "ACAD-CUST-ILTHDC-v1-FREE-DSMDL-ACT",
      "ACAD-CUST-ILTHDC-v1-FREE-DAAWWDS-ACT",
      "ACAD-CUST-ILTHDC-v1-FREE-DPWDLT-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DDP-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-FREAR-AM-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DWDW-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-CPTPTLLM-ACT",
      "ACAD-ALL-ILTHDC-DAIS-v1-PAID-MLMDEV-ENG",
      "ACAD-ALL-ILT-DAIS-v1-PAID-RAG-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DPO-ACT",
      "ACAD-ALL-ILTHDC-DAIS-v1-PAID-DPML-ENG",
      "ACAD-ALL-ILT-DAIS-v1-PAID-FTLLM-AM-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DMGUC-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-LLMEG-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-FREAR-PM-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-FTLLM-PM-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DIDL-ACT",
      "ACAD-CUST-IT-GENAIFUND-PTBR",
      "ACAD-ALL-ILT-DAIS-v1-PAID-LLMDM-ACT",
      "ACAD-ALL-ILTHDC-DAIS-v1-PAID-MLO-ENG",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DBF-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DAIWT-ACT-PTBR",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DDFP-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DAIWT-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-BDPDLT-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-MSLLM-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DSDLT-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-DAWD-ACT",
      "ACAD-ALL-ILTHDC-DAIS-v1-PAID-MLMDEP-ENG",
      "ACAD-ALL-ILT-DAIS-v1-PAID-FTLLM-ACT",
      "ACAD-ALL-ILT-DAIS-v1-PAID-FREAR-ACT",
      "ACAD-ALL-SLP-v4-PAID-DAWD-ACT",
      "ACAD-PART-SLP-v4-DAWD-ACT",
      "ACAD-CUST-SLP-GSWDDE-ENG-V1",
      "ACAD-PART-SLP-GSWDDE-ENG-V1",
      "ACAD-ALL-SLP-ODL-v3-PAID-DEWDVCT-ACT",
      "ACAD-PART-SLP-DEWDVCT-v1",
      "ACAD-ALL-SLP-ODL-v3-PAID-ADEWDVCT-ACT",
      "ACAD-PART-SLP-ADEWD-v1",
      "ACAD-ALL-SLP-ODL-v3-PAID-ASPWD-ACT",
      "ACAD-PART-SLP-ASPWD-v1",
      "ACAD-CUST-SLP-GSWDML-ENG-V1",
      "ACAD-PART-SLP-GSWDML-ENG-V1",
      "ACAD-CUST-SLP-MLWD-ENG-V1",
      "ACAD-PART-DAL-MLWD-ENG-V1",
      "ACAD-CUST-SLP-DPML-ENG-v1",
      "ACAD-PART-SLP-DPML-ENG-v1",
      "ACAD-CUST-SLP-MLMDEV-ENG-V1",
      "ACAD-PART-SLP-MLMDEV-ENG-V1",
      "ACAD-CUST-SLP-MLMDEP-ENG-V1",
      "ACAD-PART-SLP-MLMDEP-ENG-V1",
      "ACAD-ALL-SLP-ODL-v1-PAID-DLWD-RET",
      "ACAD-PART-SLP-DLWD-v1-RET",
      "ACAD-CUST-SLP-ODL-V1-PDSDE",
      "ACAD-PART-SLP-PDSDE-v1",
      "ACAD-CUST-SLP-NCODA-ENG-v1",
      "ACAD-PART-SLP-NCODA-ENG-v1",
      "ACAD-CUST-SLP-NCOMS-ENG-v1",
      "ACAD-PART-SLP-NCOMS-ENG-v1"
    )
)
select
  *
from
  program_table
''')

# COMMAND ----------

program_table_df.createOrReplaceTempView('program_table')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Learners by Program

# COMMAND ----------

learners_by_program_df = spark.sql('''

  with program_table as (
    select
      *
    from
      program_table
  ),
  learner_threshold as (
    select 
      *, 
      rank() over (partition by learner_user_id order by expected_time_to_complete_in_seconds desc, completed_timestamp desc) as course_rank, 
    case 
      when rank_sort = 1 
      and learner_flag = 1 
      then fq2 end as learner_fq2
    from main.field_learning_enablement.learner_threshold
    where processDate = (select max(processDate) from main.field_learning_enablement.learner_threshold)
  )
  ,
  learner_fq2s as (
    select learner_user_id, learner_fq2
    from learner_threshold
    where learner_fq2 is not null
  )
  ,
  fy_customer_learners as (
    select
      case
        when i.course_rank = 1
        and l.learner_fq2 = '25-Q1' then 'fy25_q1_learner'
        when i.course_rank = 1
        and l.learner_fq2 = '25-Q2' then 'fy25_q2_learner'
        when i.course_rank = 1
        and l.learner_fq2 = '25-Q3' then 'fy25_q3_learner'
        when i.course_rank = 1
        and l.learner_fq2 = '25-Q4' then 'fy25_q4_learner'
        when i.course_rank = 1
        and l.learner_fq2 ilike '24-%' then 'fy24_learner'
        when i.course_rank = 1
        and l.learner_fq2 ilike '23-%' then 'fy23_learner'
      end as fy_learner,
      -- p.program,
      case 
        when p.program = 'DAIS 2024' then 'DAIS 2024' 
        when p.program = '%half-day%' then 'Half-Day'
        when p.program = 'DAIS'  then 'DAIS' 
        when p.program = 'DAIWT' then 'DAIWT'
        when p.program = 'ILF' then 'ILF'
        when p.program = 'Academy Labs Free' then 'Academy Labs Free'
        when course_code ilike "%ILT%DLT%" then	"ILT - Delta Live Tables"
        when course_code ilike "%ILT%LLM%" then	"ILT - Large Language Models"
        when course_code ilike "%ILT%DAWD%" then	"ILT - Data Analysis with Databricks"
        when course_code ilike "%ILT%DDFP%" then	"ILT - Devops"
        when course_code ilike "%ILT%DDP%" then	"ILT - Data Privacy"
        when course_code ilike "%ILT%DIDL%" then	"ILT - Data Ingestion with Delta Lake"
        when course_code ilike "%ILT%DMGUC%" then	"ILT - Data Management and Governance with Unity Catalog"
        when course_code ilike "%ILT%DPO%" then	"ILT - Databricks Performance Optimization"
        when course_code ilike "%ILT%DWDW%" then	"ILT - Databricks Workflows"
        when course_code ilike "%ILT%FREAR%" then	"ILT - Fine-Tuning Embeddings and Advanced Retrieval"
        when course_code ilike "%ILT%RAG%" then	"ILT - Retrieval-Augmented Generation"
        when course_code ilike "%ILT%AFSID%" then	"ILT - Activating Financial Services Insights"
        when course_code ilike "%ILT%DEWD%" then	"ILT - Data Engineering with Databricks"
        when course_code ilike "%ILT%DLWDB%" then	"ILT - Deep Learning"
        when course_code ilike "%ILT%OASOD%" then	"ILT - Optimizing Apache Spark™ on Databricks"
        when course_code ilike "%ILT%ADEWD%" then	"ILT - Advanced Data Engineering with Databricks"
        when course_code ilike "%ILT%DPML%" then	"ILT - Data Preparation for Machine Learning"
        when course_code ilike "%ILT%GAI%" then	"ILT - Generative AI Application"
        when course_code ilike "%ILT%GSWDDE%" then	"ILT - Get Started with Databricks for Data Engineering"
        when course_code ilike "%ILT%GSWDML%" then	"ILT - Get Started with Databricks for Machine Learning"
        when course_code ilike "%ILT%GSWDPA%" then	"ILT - Get Started with Databricks Platform Administration"
        when course_code ilike "%ILT%MLMDEP%" then	"ILT - Machine Learning Model Deployment"
        when course_code ilike "%ILT%MLMDEV%" then	"ILT - Machine Learning Model Development"
        when course_code ilike "%ILT%MLO%" then	"ILT - Machine Learning Operations"
        when course_code ilike "%ILT%MLWD%" then	"ILT - Machine Learning with Databricks"
        when course_code ilike "%ILT%NCOVS%" then	"ILT - New Capability Overview: Vector Search"
        when course_code ilike "%ILT%SML%" then	"ILT - Scalable Machine Learning"
        when course_code ilike "%ILT%ASPWD%" then	"ILT - Apache Spark™ Programming with Databricks"
        when course_code ilike "%ILT%ADCI%" then	"ILT - Azure Databricks Cloud Integrations"
        when course_code ilike "%ILT%APWF%" then	"ILT - Automate Production Workflows"
        when course_code ilike "%ILT%ASDBSQL%" then	"ILT - Advanced SQL for Databricks SQL"
        when course_code ilike "%ILT%ASDEWDS%" then	"ILT - Access Shared Data Externally with Delta Sharing"
        when course_code ilike "%ILT%ASQLDB%" then	"ILT - Applications of SQL on Databricks"
        when course_code ilike "%ILT%FDBLP%" then	"ILT - Lakehouse Fundamentals"
        when course_code ilike "%ILT%LKFND%" then	"ILT - Lakehouse Fundamentals"
        when course_code ilike "%ILT%FODLP%" then	"ILT - Lakehouse Fundamentals"
        when course_code ilike "%ILT%ONBDBSQL%" then	"ILT - Get Started Data Analytics"
        when course_code ilike "%ILT%GSWDSEW%" then	"ILT - Get Started Data Engineering"
        when course_code ilike "%ILT%DAAWWDS%" then	"ILT - Data Analytics and Warehousing"
        when course_code ilike "%ILT%GSWDBSQL%" then	"ILT - Data Analytics and Warehousing"
        when course_code ilike "%ILT%ONBDEDS%" then	"ILT - Get Started Data Analysis"
        when course_code ilike "%ILT%GENAIFUND%" then	"ILT - Generative AI Fundamentals"
        when course_code ilike "%SLP%DLT%" then	"SLP - Delta Live Tables"
        when course_code ilike "%SLP%LLM%" then	"SLP - Large Language Models"
        when course_code ilike "%SLP%DAWD%" then	"SLP - Data Analysis with Databricks"
        when course_code ilike "%SLP%DDFP%" then	"SLP - Devops"
        when course_code ilike "%SLP%DDP%" then	"SLP - Data Privacy"
        when course_code ilike "%SLP%DIDL%" then	"SLP - Data Ingestion with Delta Lake"
        when course_code ilike "%SLP%DMGUC%" then	"SLP - Data Management and Governance with Unity Catalog"
        when course_code ilike "%SLP%DPO%" then	"SLP - Databricks Performance Optimization"
        when course_code ilike "%SLP%DWDW%" then	"SLP - Databricks Workflows"
        when course_code ilike "%SLP%FREAR%" then	"SLP - Fine-Tuning Embeddings and Advanced Retrieval"
        when course_code ilike "%SLP%RAG%" then	"SLP - Retrieval-Augmented Generation"
        when course_code ilike "%SLP%AFSID%" then	"SLP - Activating Financial Services Insights"
        when course_code ilike "%SLP%DEWD%" then	"SLP - Data Engineering with Databricks"
        when course_code ilike "%SLP%DLWDB%" then	"SLP - Deep Learning"
        when course_code ilike "%SLP%OASOD%" then	"SLP - Optimizing Apache Spark™ on Databricks"
        when course_code ilike "%SLP%ADEWD%" then	"SLP - Advanced Data Engineering with Databricks"
        when course_code ilike "%SLP%DPML%" then	"SLP - Data Preparation for Machine Learning"
        when course_code ilike "%SLP%GAI%" then	"SLP - Generative AI Application"
        when course_code ilike "%SLP%GSWDDE%" then	"SLP - Get Started with Databricks for Data Engineering"
        when course_code ilike "%SLP%GSWDML%" then	"SLP - Get Started with Databricks for Machine Learning"
        when course_code ilike "%SLP%GSWDPA%" then	"SLP - Get Started with Databricks Platform Administration"
        when course_code ilike "%SLP%MLMDEP%" then	"SLP - Machine Learning Model Deployment"
        when course_code ilike "%SLP%MLMDEV%" then	"SLP - Machine Learning Model Development"
        when course_code ilike "%SLP%MLO%" then	"SLP - Machine Learning Operations"
        when course_code ilike "%SLP%MLWD%" then	"SLP - Machine Learning with Databricks"
        when course_code ilike "%SLP%NCOVS%" then	"SLP - New Capability Overview: Vector Search"
        when course_code ilike "%SLP%SML%" then	"SLP - Scalable Machine Learning"
        when course_code ilike "%SLP%ASPWD%" then	"SLP - Apache Spark™ Programming with Databricks"
        when course_code ilike "%SLP%ADCI%" then	"SLP - Azure Databricks Cloud Integrations"
        when course_code ilike "%SLP%APWF%" then	"SLP - Automate Production Workflows"
        when course_code ilike "%SLP%ASDBSQL%" then	"SLP - Advanced SQL for Databricks SQL"
        when course_code ilike "%SLP%ASDEWDS%" then	"SLP - Access Shared Data Externally with Delta Sharing"
        when course_code ilike "%SLP%ASQLDB%" then	"SLP - Applications of SQL on Databricks"
        when course_code ilike "%SLP%FDBLP%" then	"SLP - Lakehouse Fundamentals"
        when course_code ilike "%SLP%LKFND%" then	"SLP - Lakehouse Fundamentals"
        when course_code ilike "%SLP%FODLP%" then	"SLP - Lakehouse Fundamentals"
        when course_code ilike "%SLP%ONBDBSQL%" then	"SLP - Get Started Data Analytics"
        when course_code ilike "%SLP%GSWDSEW%" then	"SLP - Get Started Data Engineering"
        when course_code ilike "%SLP%DAAWWDS%" then	"SLP - Data Analytics and Warehousing"
        when course_code ilike "%SLP%GSWDBSQL%" then	"SLP - Data Analytics and Warehousing"
        when course_code ilike "%SLP%ONBDEDS%" then	"SLP - Get Started Data Analysis"
        when course_code ilike "%SLP%GENAIFUND%" then	"SLP - Generative AI Fundamentals"
        when course_code ilike "%ILT%ONBDEDS%" then	"ILT - Get Started with Databricks for Data Engineering"
        when course_code ilike "%ILT%ONBDBSQL%" then	"ILT - Get Started with Data Analysis on Databricks"
        when course_code ilike "%ILT%DEWD%" then	"ILT - Data Engineering with Databricks"
        when course_code ilike "%ILT%ONBDML%" then	"ILT - Get Started with Machine Learning on Databricks"
        when course_code ilike "%ILT%ONBPADM%" then	"ILT - Get Started with Databricks Platform Administration"
        when course_code ilike "%ILTHDC%DAAWWDS%" then	"ILT - Data Analytics and Warehousing with Databricks"
        when course_code ilike "%ILT%ADEWD%" then	"ILT - Advanced Data Engineering with Databricks"
        when course_code ilike "%ILTHDC%ONBDEDS%" then	"ILT - Data Analytics and Warehousing with Databricks"
        when course_code ilike "%ILTHDC%DPWDLT%" then	"ILT - Data Pipelines with Delta Live Tables"
        when course_code ilike "%SLP%FODLP%" then	"SLP - Fundamentals of the Databricks Lakehouse Platform Accreditation"
        when course_code ilike "%SLP%DEWD%" then	"SLP - Data Engineering with Databricks"
        when course_code ilike "%SLP%DIPFPTBR%" then	"SLP - Databricks Fundamentals Accreditation"
        when course_code ilike "%SLP%ADEWD2%" then	"SLP - Advanced Data Engineering with Databricks"
        when course_code ilike "%SLP%LKFND%" then	"SLP - Fundamentals of the Databricks Lakehouse Platform"
        when course_code ilike "%SLP%ASPWD%" then	"SLP - Apache Spark™ Programming with Databricks"
        when course_code ilike "%SLP%GENAIACCRED%" then	"SLP - Generative AI Fundamentals Accreditation"
        when course_code ilike "%SLP%CODCAD%" then	"SLP - Certification Overview: Databricks Certified Associate Developer for Apache Spark Exam"
        when course_code ilike "%SLP%GSWDBSQL%" then	"SLP - Get Started with Data Analysis on Databricks"
        when course_code ilike "%SLP%DAWD%" then	"SLP - Data Analysis with Databricks SQL"
        when course_code ilike "%SLP%PDSDE%" then	"SLP - Introduction to Python for Data Science and Data Engineering"
        when course_code ilike "%SLP%MLINPROD%" then	"SLP - Machine Learning in Production (V2)"
        when course_code ilike "%ILTHDC%" then "Half-Day"
        when course_code ilike "%ILTB%" then "Blended Learning"
        when course_code ilike "%SLP%" then "Self Paced"
        when course_code ilike "%ILT%" then "Instructor Led"
        else p.program 
        end as program,
      i.*
    from
      learner_threshold i
      left join program_table p on i.course_code = p.code
      left join learner_fq2s l on i.learner_user_id = l.learner_user_id
  )
  -- select * from fy_customer_learners
  -- where program ilike '%half-day%'


  ,
  pre as (
    select
      l.fy_learner,
      l.program,
      i.*
    from
      learner_threshold i
      left join fy_customer_learners l on i.learner_user_id = l.learner_user_id
    where
      i.source <> "Learndot"
  ),
  counts as (
    select
      count(distinct learner_user_id) as total
    from
      fy_customer_learners
  )


  ,
  pre_2 as (
    select
      learner_user_id,
      nvl(program, "Other") as program,
      fy_learner,
      nvl(c.sales_business_unit, "Unknown") as sales_business_unit,
      nvl(c.sales_subregion_level_1, "Unknown") as sales_subregion_level_1,
      nvl(c.sales_subregion_level_2, "Unknown") as sales_subregion_level_2,
      nvl(c.sales_subregion_level_3, "Unknown") as sales_subregion_level_3,
      collect_set(course_name) course_names,
      collect_set(course_code) course_codes,
      size(collect_set(course_name)) as no_of_courses
    from
      pre p
    left join main.gtm_data.core_accounts_curated c on p.updated_account_id = c.account_id

    where
      fy_learner is not null
    group by
      all
  )
  ,
  data as (
  select
    learner_user_id, 
    program,
    case 
      when program in ('DAIS', 'DAIWT', 'ILF', "DAIS 2024") then 'Events'
      when program = 'Other' then 'BAU'
      when program ilike '%half-day%' then 'Half-Day'
      when program ilike '%SLP%' then 'Self Paced'
      when program ilike any ('%ILT%', '%Instructor Led%') then 'ILT'
      else program
      end as program_category,
    fy_learner,
    sales_business_unit,
    sales_subregion_level_1,
    sales_subregion_level_2,
    sales_subregion_level_3, 
    course_names,
    course_codes,
    no_of_courses
  from
    pre_2
  )

  select *
  from data 
  

  -- select 
  --   program_category, 
  --   program, 
  --   fy_learner, 
  --   count(distinct learner_user_id)
  -- from data 
  -- where fy_learner in ('fy24_learner', 'fy25_q1_learner', 'fy25_q2_learner')
  -- group by all
  -- order by 1,2,3

''')

# COMMAND ----------

# DBTITLE 1,Annual Learner Program Analysis
# learners_by_program_df = spark.sql('''
# with program_table as (
#   select
#     *
#   from
#     program_table
# ),
# fy_customer_learners as (
#   select
#     case
# --      when i.rank_sort = 1
# --      and i.learner_flag = 1
# --      and fq2 ilike '25-%' then 'fy25_learner'
#       when i.rank_sort = 1
#       and i.learner_flag = 1
#       and fq2 = '25-Q1' then 'fy25_q1_learner'
#       when i.rank_sort = 1
#       and i.learner_flag = 1
#       and fq2 = '25-Q2' then 'fy25_q2_learner'
#       when i.rank_sort = 1
#       and i.learner_flag = 1
#       and fq2 = '25-Q3' then 'fy25_q3_learner'
#       when i.rank_sort = 1
#       and i.learner_flag = 1
#       and fq2 = '25-Q4' then 'fy25_q4_learner'
#       when i.rank_sort = 1
#       and i.learner_flag = 1
#       and fq2 ilike '24-%' then 'fy24_learner'
#       when i.rank_sort = 1
#       and i.learner_flag = 1
#       and fq2 ilike '23-%' then 'fy23_learner'
#     end as fy_learner,
#     p.program,
#     i.*
#   from
#     learner_threshold i
#     left join program_table p on i.course_code = p.code
# ),
# pre as (
#   select
#     l.fy_learner,
#     l.program,
#     i.*
#   from
#     learner_threshold i
#     left join fy_customer_learners l on i.learner_user_id = l.learner_user_id
#   where
#     i.source <> "Learndot"
# ),
# counts as (
#   select
#     count(distinct learner_user_id) as total
#   from
#     fy_customer_learners
# ),
# pre_2 as (
#   select
#     learner_user_id,
#     nvl(program, "Other") as program,
#     fy_learner,
#     nvl(c.sales_business_unit, "Unknown") as sales_business_unit,
#     nvl(c.sales_subregion_level_1, "Unknown") as sales_subregion_level_1,
#     nvl(c.sales_subregion_level_2, "Unknown") as sales_subregion_level_2,
#     nvl(c.sales_subregion_level_3, "Unknown") as sales_subregion_level_3,
#     collect_set(course_name) course_names,
#     collect_set(course_code) course_codes,
#     size(collect_set(course_name)) as no_of_courses
#   from
#     pre p
#   left join main.gtm_data.core_accounts_curated c on p.updated_account_id = c.account_id

#   where
#     fy_learner is not null
#   group by
#     all
# )
# select
#   learner_user_id, 
#   program,
#   case 
#     when program in ('DAIS', 'DAIWT', 'ILF') then 'Events'
#     when program = 'Other' then 'BAU'
#     when program ilike '%half-day%' then 'Half-Day'
#     else program
#     end as program_category,
#   fy_learner,
#   sales_business_unit,
#   sales_subregion_level_1,
#   sales_subregion_level_2,
#   sales_subregion_level_3, 
#   course_names,
#   course_codes,
#   no_of_courses
# from
#   pre_2

#   -- get all milestones (paid) from the milestone table along with session ids, if the session id corresponds to a session for a course that is half-day then you know that that individual should get "paid" program classification. So we would have the learners and their session ids and join on these paid half-day session ids to identify if they should be "Paid" 
# ''')

# COMMAND ----------

# DBTITLE 1,Temp View Creation for Learners
learners_by_program_df.createOrReplaceTempView('learners_by_program')

# COMMAND ----------

# DBTITLE 1,Program Classification Query
learners_by_program_actual_target_df = spark.sql('''
with pre as (
select 
  case 
    when program in ('DAIS', 'DAIWT', 'ILF', 'DAIS 2024') then 'Events'
    -- when program = 'Other' then 'BAU'
    when program ilike any ('%ILT%', '%SLP%') then 'BAU'
    when program ilike '%half-day%' then 'Half-Day'
    when program = 'Academy Labs Free' then 'Academy Labs Free'
    else program
    end as program,
    learner_user_id, 
    fy_learner
from learners_by_program
)
,
by_program as (
select program, fy_learner, count(distinct learner_user_id) as actuals
from pre 
where fy_learner = 'fy25_q1_learner'
group by all
union all 
select program, fy_learner, count(distinct learner_user_id) as actuals
from pre 
where fy_learner = 'fy25_q2_learner'
group by all
union all 
select program, fy_learner, count(distinct learner_user_id) as actuals
from pre 
where fy_learner = 'fy25_q3_learner'
group by all
union all 
select program, fy_learner, count(distinct learner_user_id) as actuals
from pre 
where fy_learner = 'fy25_q4_learner'
group by all
union all 
select 'Total', fy_learner, count(distinct learner_user_id) as actuals
from pre 
where fy_learner ilike 'fy25%'
group by all
)

,
targets as (
select 
  0 as target, 'Events' as program, 'fy25_q1_learner' as fq2
  union all 
  select
  4207 as target, 'BAU' as program, 'fy25_q1_learner' as fq2
  union all 
  select
  907 as target, 'Paid' as program, 'fy25_q1_learner' as fq2
  union all 
  select
  1386 as target, 'Half-Day' as program, 'fy25_q1_learner' as fq2
  union all 
  select
  2320 as target, 'Academy Labs Free' as program, 'fy25_q1_learner' as fq2
  union all 
  select
  8820 as target, 'Total' as program, 'fy25_q1_learner' as fq2
  union all 
  select 
  1000 as target, 'Events' as program, 'fy25_q2_learner' as fq2
  union all 
  select
  6988 as target, 'BAU' as program, 'fy25_q2_learner' as fq2
  union all 
  select
  1507 as target, 'Paid' as program, 'fy25_q2_learner' as fq2
  union all 
  select
  2302 as target, 'Half-Day' as program, 'fy25_q2_learner' as fq2
  union all 
  select
  3853 as target, 'Academy Labs Free' as program, 'fy25_q2_learner' as fq2
  union all 
  select
  15651 as target, 'Total' as program, 'fy25_q2_learner' as fq2
  union all 
  select 
  500 as target, 'Events' as program, 'fy25_q3_learner' as fq2
  union all 
  select
  7629 as target, 'BAU' as program, 'fy25_q3_learner' as fq2
  union all 
  select
  1646 as target, 'Paid' as program, 'fy25_q3_learner' as fq2
  union all 
  select
  2513 as target, 'Half-Day' as program, 'fy25_q3_learner' as fq2
  union all 
  select
  4206 as target, 'Academy Labs Free' as program, 'fy25_q3_learner' as fq2
  union all 
  select
  16495 as target, 'Total' as program, 'fy25_q3_learner' as fq2
  union all 
  select 
  500 as target, 'Events' as program, 'fy25_q4_learner' as fq2
  union all 
  select
  6675 as target, 'BAU' as program, 'fy25_q4_learner' as fq2
  union all 
  select
  1440 as target, 'Paid' as program, 'fy25_q4_learner' as fq2
  union all 
  select
  2199 as target, 'Half-Day' as program, 'fy25_q4_learner' as fq2
  union all 
  select
  3680 as target, 'Academy Labs Free' as program, 'fy25_q4_learner' as fq2
  union all 
  select
  14494 as target, 'Total' as program, 'fy25_q4_learner' as fq2

)

select 
  t.program, 
  t.target, 
  case 
  when t.fq2 ilike 'fy25_q1%' then '25-Q1'
  when t.fq2 ilike 'fy25_q2%' then '25-Q2'
  when t.fq2 ilike 'fy25_q3%' then '25-Q3'
  when t.fq2 ilike 'fy25_q4%' then '25-Q4' 
  end as fq2,
  nvl(p.actuals,0) as actuals 
from targets t
left join by_program p
on t.program = p.program and t.fq2 = p.fy_learner
''')

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Users with Enrollments Funnel

# COMMAND ----------

# DBTITLE 1,Enrollment Cohort Query
users_with_enrollments_df = spark.sql('''
  with pre as (
    select
      d.calendar_year_month as year_month,
      d1.calendar_year_month as user_created_year_month,
      -- p.program,
      e.*
    from
      main.field_learning_enablement.all_enrollments e
    inner join main.it_core_dim.dim_dates d on e.enrolled_date::date = d.date
    inner join main.it_core_dim.dim_dates d1 on e.user_created_timestamp::date = d1.date
    -- left join program_table p on e.course_code = p.code
    where
      e.processdate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
      AND e.fiscalYear >= 2024
  ),
  cohort_data AS (
    select 
      user_created_year_month,
      year_month,
      learner_user_id,
      -- program,
      status
    from
      pre
    where 
      user_created_year_month ilike any ('2023%', '2024%')
      
  )

  select * from cohort_data
''')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Users Who Are Learners Funnel

# COMMAND ----------

# DBTITLE 1,Learner Cohort Query Analysis
users_learners_funnel_df = spark.sql('''
  with pre as (
    select
      d.calendar_year_month as year_month,
      d1.calendar_year_month as user_created_year_month,
      l.learner_user_id as learner_id,
      -- p.program,
      e.*
    from
      main.field_learning_enablement.all_enrollments e
    inner join main.it_core_dim.dim_dates d ON e.enrolled_date::date = d.date
    inner join main.it_core_dim.dim_dates d1 on e.user_created_timestamp::date = d1.date
    left join main.field_learning_enablement.all_learners l on e.learner_user_id = l.learner_user_id
    -- left join learners_by_program p on l.learner_user_id = p.learner_user_id
    and l.processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    and l.dataset = 'net new learners'
    where
      e.processdate = (select MAX(processDate) from main.field_learning_enablement.all_enrollments)
      and e.fiscalYear >= 2024
  ),
  cohort_data as (
    select 
      user_created_year_month,
      year_month,
      learner_user_id,
      learner_id
      -- program
    from
      pre
    where 
      user_created_year_month ilike any ('2023%', '2024%')
  )

  select * from cohort_data

''')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Unscheduled Success Credits Backlog

# COMMAND ----------

# DBTITLE 1,Professional Services Revenue Analysis
unscheduled_sc_df = spark.sql('''
  with 
  Training_revenue_FY23 AS (
    SELECT
      snapshot_date,
      account_id,
      sum(total_delivered_revenue) as Training_revenue_FY23
    FROM
      main.gtm_data.core_professional_services_delivered_revenue
    WHERE
      snapshot_date in (select max(snapshot_date) from main.gtm_data.core_professional_Services_delivered_revenue)
      AND delivered_fiscal_year_quarter in ("FY'23 Q1", "FY'23 Q2", "FY'23 Q3", "FY'23 Q4")
      AND practice_name in ("Training")
      and timecard_or_milestone_status in ("Approved") 
    GROUP BY
      1,2
  ),

  Training_revenue_FY24 AS (
    SELECT
      snapshot_date,
      account_id,
      sum(total_delivered_revenue) as Training_revenue_FY24
    FROM
      main.gtm_data.core_professional_services_delivered_revenue
    WHERE
      snapshot_date in (select max(snapshot_date) from main.gtm_data.core_professional_Services_delivered_revenue)
      AND delivered_fiscal_year_quarter in ("FY'24 Q1","FY'24 Q2","FY'24 Q3","FY'24 Q4")
      AND practice_name in ("Training")
      and timecard_or_milestone_status in ("Approved") 
    GROUP BY
      1,2
  )
  ,

  Training_revenue_FY25 AS (
    SELECT
      snapshot_date,
      account_id,
      sum(total_delivered_revenue) as Training_revenue_FY25
    FROM
      main.gtm_data.core_professional_services_delivered_revenue
    WHERE
      snapshot_date in (select max(snapshot_date) from main.gtm_data.core_professional_Services_delivered_revenue)
      AND delivered_fiscal_year_quarter in ("FY'25 Q1","FY'25 Q2","FY'25 Q3","FY'25 Q4")
      AND practice_name in ("Training")
      and timecard_or_milestone_status in ("Approved") 
    GROUP BY
      1,2
  )


  ,

  Training_revenue_scheduled AS (
    SELECT
      snapshot_date,
      account_id,
      sum(case when backlog_detail_end_fiscal_year="2024" then backlog_detail_time_revenue end) + sum(case when backlog_detail_end_fiscal_year="2024" then backlog_detail_milestone_revenue end) as fy24_Training_revenue_scheduled,
      sum(case when backlog_detail_end_fiscal_year="2025" then backlog_detail_time_revenue end) + sum(case when backlog_detail_end_fiscal_year="2025" then backlog_detail_milestone_revenue end) as fy25_Training_revenue_scheduled
    FROM
      main.gtm_data.core_professional_services_scheduled_backlog
    WHERE
      snapshot_date = (Select max(snapshot_date) from main.gtm_data.core_professional_services_scheduled_backlog)
      AND practice_name in ("Training")
    GROUP BY
      1,2
  ),


  learning_subscription_customers AS (
    SELECT
      account_id,
      sum(backlog_detail_time_revenue) + sum(backlog_detail_milestone_revenue) as revenue_scheduled
    FROM
      main.gtm_data.core_professional_services_scheduled_backlog
    WHERE
      snapshot_date = (Select max(snapshot_date) from main.gtm_data.core_professional_services_scheduled_backlog)
      AND practice_name in ("Training")
      and project_service_type='Learning Subscription'
      and backlog_detail_end_fiscal_year_month >= (select distinct fiscal_year_month from main.it_core_dim.dim_dates where date=current_date::date)
    GROUP BY
      1
      having (sum(backlog_detail_time_revenue) + sum(backlog_detail_milestone_revenue))<>0
  ),

  cse_subscription_customers AS (
    SELECT
      account_id,
      sum(backlog_detail_time_revenue) + sum(backlog_detail_milestone_revenue) as revenue_scheduled
    FROM
      main.gtm_data.core_professional_services_scheduled_backlog
    WHERE
      snapshot_date = (Select max(snapshot_date) from main.gtm_data.core_professional_services_scheduled_backlog)
    AND practice_name in ("Professional Services")
    and core_professional_services_scheduled_backlog.project_stage not in ("Cancelled","Completed")
      and project_service_type in ('Customer Success Subscription',"Guided Success Subscription")
      and backlog_detail_end_fiscal_year_month >= (select distinct fiscal_year_month from main.it_core_dim.dim_dates where date=current_date::date)
    GROUP BY
      all 
      having (sum(backlog_detail_time_revenue) + sum(backlog_detail_milestone_revenue))<>0
  )
  ,

  paid_ilt_customers AS (

  SELECT
      account_id,
      sum(total_delivered_revenue) as Paid_ILT_Revenue
    FROM
      main.gtm_data.core_professional_services_delivered_revenue
    WHERE
      snapshot_date in (select max(snapshot_date) from main.gtm_data.core_professional_Services_delivered_revenue)
      AND delivered_fiscal_year_quarter in ("FY'23 Q1", "FY'23 Q2", "FY'23 Q3", "FY'23 Q4","FY'24 Q1", "FY'24 Q2", "FY'24 Q3", "FY'24 Q4",
      "FY'25 Q1","FY'25 Q2","FY'25 Q3","FY'25 Q4")
      AND practice_name in ("Training")
      and project_Service_type='ILT (Instructor Led Training)'
      and timecard_or_milestone_status in ("Approved",'Commit')
    GROUP BY
      1
  )

  ,

  account_metadata as (
    select c.account_id, 
          c.account_name,
          c.account_executive,
          c.account_executive_user_id,
          c.last_solution_architect_engaged, 
          c.last_solution_architect_engaged_user_id,
          c.customer_type,
          c.business_unit, 
          c.sales_subregion_level_1,
          c.sales_subregion_level_2,
          c.sales_subregion_level_3,
          c.vertical
    from main.gtm_data.core_Accounts_curated c
    where snapshot_date=(Select max(snapshot_date) from main.gtm_data.core_Accounts_curated)
  )
  ,

  project_dim as
  (
  select u.name,u.email,p.* from main.gtm_data.core_professional_services_dim_project p
  left join main.sfdc_bronze.contact u on p.project_manager_id=u.id and u.processdate=(select max(processDate) from main.sfdc_bronze.contact)
  where snapshot_date=(select max(snapshot_date) from main.gtm_data.core_professional_services_dim_project)
  )


  ,

  user_success_credits as (
  select
      a.snapshot_date,
      a.project_id,
      a.opportunity_id,
      o.Primary_Contact__c,
      a.account_id,
      a.project_name,
      a.project_category,
      a.project_service_type,
      a.project_stage,
      p.project_billing_type, 
      p.project_sow_end_date,
      a.project_remaining_success_credits_value as unallocated_success_credits_value, 
      a.project_remaining_success_credits_quantity as unallocated_success_credits_quantity,
      current_date::date as cur_date,
      a.project_start_date,
      a.project_end_date,
    a.platform,
      o.name as opportunity_name, 
      o.type as opportunity_type, 
      o.Primary_Contact__c ,
      o.ps_owner__c as ps_owner,
      u.name as opportunity_owner,
      u.email as opportunity_owner_email,
      a.project_region,
      p.name as project_manager_name,
      p.email as project_manager_email
    from
      main.gtm_data.core_professional_Services_dim_project a
    left join project_dim p on a.project_id=p.project_id
    left join main.sfdc_bronze.opportunity o on a.opportunity_id=o.id and o.processDate=(select max(o.processDate) from main.sfdc_bronze.contact o)
    left join main.sfdc_bronze.user u on o.ownerid=u.id and u.processDate=(select max(u.processDate) from main.sfdc_bronze.contact u)
    where
      a.snapshot_date = (select max(snapshot_date) from main.gtm_data.core_professional_Services_dim_project)
      and a.project_service_tier = 'Master'
      and nvl(a.project_stage,'Unknown') not in ('Completed','Cancelled')
      and a.project_remaining_success_credits_quantity > 0 
      and a.opportunity_stage='Closed Won'
  )


  --Commenting out until status such as not started is added back
    -- select
    --   a.snapshot_date,
    --   a.project_id,
    --   a.opportunity_id,
    --   o.Primary_Contact__c,
    --   a.account_id,
    --   a.project_name,
    --   a.project_category,
    --   a.project_service_type,
    --   a.project_stage,
    --   p.project_billing_type, 
    --   p.project_sow_end_date,
    --   a.unallocated_success_credits_value, 
    --   a.unallocated_success_credits_quantity,
    --   current_date::date as cur_date,
    --   a.project_start_date,
    --   a.project_end_date,
    --  -- a.platform,
    --   o.name as opportunity_name, 
    --   o.type as opportunity_type, 
    --   o.Primary_Contact__c ,
    --   o.ps_owner__c as ps_owner,
    --   u.name as opportunity_owner,
    --   u.email as opportunity_owner_email,
    --   a.project_region,
    --   p.name as project_manager_name,
    --   p.email as project_manager_email
    -- from
    --   main.gtm_data.core_success_credits a
    -- left join project_dim p on a.project_id=p.project_id
    -- left join main.sfdc_bronze.opportunity o on a.opportunity_id=o.id and o.processDate=(select max(o.processDate) from main.sfdc_bronze.contact o)
    -- left join main.sfdc_bronze.user u on o.ownerid=u.id and u.processDate=(select max(u.processDate) from main.sfdc_bronze.contact u)
    -- where
    --   a.snapshot_date = (select max(snapshot_date) from main.gtm_data.core_success_credits)
    --   --and backlog_type='Unscheduled'
    --   --and backlog_type='Unscheduled Backlog'
    --   and a.project_service_tier = 'Master'
    --   and a.project_stage <> 'On Hold'
    --   and a.unallocated_success_credits_quantity > 0 --and account_id='00161000005gCW8AAM'
    --   -- and a.project_id='a4G8Y0000013t0yUAA'
    --   --a4G3f00000003f8EAA
  -- )

  ,
  dates_pre as (
    select date_add(fiscal_quarter_end_date, 1) as next_quarter_start
    from main.it_core_dim.dim_dates
    where date = current_date()
  )
  , 
  dates_pre_2 as (
    select fiscal_quarter_end_date as next_qtr_end_date, current_date() as date
    from main.it_core_dim.dim_dates 
    where date = (select next_quarter_start from dates_pre)
  )
  , 
  dates_pre_3 as (
    select d.*, n.next_qtr_end_date
    from main.it_core_dim.dim_dates d
    inner join dates_pre_2 n on d.date = n.date
  )
  ,
  pre as (
    select
      a.account_name,
      a.account_executive,
      a.last_solution_architect_engaged, 
      a.customer_type,
      a.business_unit, 
      a.sales_subregion_level_1,
      a.sales_subregion_level_2,
      a.sales_subregion_level_3,
      a.vertical,
      u.*,
      d1.fiscal_quarter_end_date as current_qtr_end_date,
      d1.next_qtr_end_date as next_qtr_end_date
      -- w1.wd_email as AE_email,
      -- w2.wd_email as Last_SA_email
    from
      user_success_credits u
      left join dates_pre_3 d1 on u.cur_date=d1.date
      left join account_metadata a on u.account_id = a.account_id
      -- left join users.liam_cliffor.list_of_workday_users_and_respective_sfdc_user_ids w1 on a.account_executive_user_id=w1.current_id
      -- left join users.liam_clifford.list_of_workday_users_and_respective_sfdc_user_ids w2 on a.last_solution_architect_engaged_user_id=w2.current_id 
  )


  ,
  pre_2 as
  (
  select
    a.snapshot_date,
    a.account_id,
    a.account_name,
    a.customer_type,
    a.vertical,
    a.business_unit,
    a.sales_subregion_level_1,
    a.sales_subregion_level_2,
    a.sales_subregion_level_3,
    a.account_executive,
    -- a.ae_email,
    a.last_solution_architect_engaged,
    -- a.Last_SA_email,
    r.Training_revenue_FY23,
    r1.Training_revenue_FY24,
    r2.Training_revenue_FY25,
    s.fy24_Training_revenue_scheduled,
    s.fy25_Training_revenue_scheduled,
    collect_list(project_manager_name) as project_manager_name_aggregate,
    collect_list(project_manager_email) as project_manager_email_aggregate,
    min (project_end_date) as earliest_expiration_date,
    collect_list(project_id) as project_ids_aggregate,
    collect_list(project_sow_end_date) as project_sow_end_dates,
    collect_list (project_name) as project_name_aggregate,
    sum(unallocated_success_credits_value) as unallocated_success_credits_value,
    sum(unallocated_success_credits_quantity) as unallocated_success_credits_quantity,
    nvl(sum(case when project_sow_end_date<=current_qtr_end_date then unallocated_success_credits_quantity end),0) as current_qtr_exp_credits_qty,
    nvl(sum(case when (project_sow_end_date>current_qtr_end_date and project_end_date<= next_qtr_end_date) then unallocated_success_credits_quantity end ),0) as next_qtr_exp_credits_qty,
    nvl(sum(case when project_sow_end_date> next_qtr_end_date then unallocated_success_credits_quantity end ),0) as future_qtr_exp_credits_qty,
    nvl(sum(case when project_sow_end_date<=current_qtr_end_date then unallocated_success_credits_value end),0) as current_qtr_exp_credits_value,
    nvl(sum(case when (project_sow_end_date>current_qtr_end_date and project_end_date<= next_qtr_end_date) then unallocated_success_credits_value end ),0) as next_qtr_exp_credits_value,
    nvl(sum(case when project_sow_end_date> next_qtr_end_date then unallocated_success_credits_value end ),0) as future_qtr_exp_credits_value,
    collect_list (opportunity_name) as opportunity_name_aggregate,
    collect_list (opportunity_id) as opportunity_id_aggregate,
    collect_list(ps_owner) as ps_owner_aggregate,
    collect_list (opportunity_type) as opportunity_type_aggregate,
    collect_list(opportunity_owner) as opportunity_owner_aggregate,
    collect_list(opportunity_owner_email) as opportunity_owner_emails_aggregate
  from
    pre a
    left join Training_revenue_FY23 r on a.account_id=r.account_id and a.snapshot_date::date=r.snapshot_date::date
    left join Training_revenue_FY24 r1 on a.account_id=r1.account_id and a.snapshot_date::date=r1.snapshot_date::date
      left join Training_revenue_FY25 r2 on a.account_id=r2.account_id and a.snapshot_date::date=r2.snapshot_date::date
    left join Training_revenue_scheduled s on a.account_id=s.account_id and a.snapshot_date::date=s.snapshot_date::date
    group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16
  )

  ,

  pre_Final as
  (
  select 
  p.*,
  case
        when unallocated_success_credits_quantity <= 50000 then '1. <50k'
        else '2. >50k'
      end as unallocated_success_credits_quantity_bucket ,
  case when l.account_id is not null then 1 else 0 end as learning_subscription_customer,
  case when c.account_id is not null then 1 else 0 end as cse_subscription_customer,
  case when i.account_id is not null then 1 else 0 end as paid_ilt_customer
  from pre_2 p
  left join learning_subscription_customers l on p.account_id=l.account_id
  left join cse_subscription_customers c on p.account_id=c.account_id
  left join paid_ilt_customers i on p.account_id=i.account_id
  )

  select * from pre_final 



''')

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Customer Onboarding Classes

# COMMAND ----------

# DBTITLE 1,Customer Onboarding Analysis Query
customer_onboarding_df = spark.sql('''
with accounts as (
  select
    distinct account_id,
    Account_Name,
    dsa_name,
    dsa_email
  from
    dsa_data
  where
    dsa_name is not null
),
pre as (
  select
    "Public ILT" as grouping,
    e.learner_user_id as attended_or_completed,
    e.updated_Account_id,
    e.updated_Account_name,
    a.account_id,
    a.dsa_name,
    e.completed_date,
    e.session_id,
    e.session_code,
    e.completed_fq2,
    e.ended_timestamp :: date as ended_timestamp,
    e.course_name,
    e.course_code,
    e.audience, 
    e.status
  from
    main.field_learning_enablement.all_enrollments e
    left join accounts a on e.updated_account_id = a.account_id
  where
    status = 'completed'
    and course_type = 'classroom'
    and processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.all_enrollments
    )
    and (
      course_id in (1509,1511,1512,1513,1629)
      or e.session_code in (
        select
          distinct academy_session_number
        from
          airtable_classes
        where
          class_type = 'onboarding'
          and training_type = "Public"
      )
    )
  union all
  select
    "Private ILT" as grouping,
    e.learner_user_id as attended_or_completed,
    e.updated_Account_id,
    e.updated_Account_name,
    a.account_id,
    a.dsa_name,
    e.completed_date,
    e.session_id,
    e.session_code,
    e.completed_fq2,
    e.ended_timestamp :: date as ended_timestamp,
    e.course_name,
    e.course_code,
    e.audience, 
    e.status
  from
    main.field_learning_enablement.all_enrollments e
    left join accounts a on e.updated_account_id = a.account_id
  where
    e.status = 'completed'
    and e.course_type = 'classroom'
    and e.processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.all_enrollments
    )
    and (
      e.session_code in (
        select
          distinct academy_session_number
        from
          airtable_classes
        where
          class_type = 'onboarding'
          and training_type = "Private"
      )
    )
  union all 
  select
    "eLearning" as grouping,
    e.learner_user_id as attended_or_completed,
    e.updated_Account_id,
    e.updated_Account_name,
    a.account_id,
    a.dsa_name,
    e.completed_date,
    null as session_id,
    null as session_code,
    e.completed_fq2,
    null as ended_timestamp,
    e.course_name,
    e.course_code,
    e.audience, 
    e.status
  from
    main.field_learning_enablement.all_enrollments e
    left join accounts a on e.updated_account_id = a.account_id
  where
    status = 'completed' 
    and course_type = 'elearning'
    and processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.all_enrollments
    )
    and course_id in (682,1342,1344,1460,1660) 

)
,

test as (
select
  p.* except (course_name, course_code, ended_timestamp),
  d.fiscal_year_quarter as session_end_fq2,
  case when d.fiscal_year_quarter is null then p.completed_fq2 else d.fiscal_year_quarter end as ended_fq2,
  d.calendar_year_month,
  case when s.course_name is null then p.course_name else s.course_name end as course_name,
  case when s.course_code is null then p.course_code else s.course_code end as course_code,
  case when p.ended_timestamp is null then p.completed_date else p.ended_timestamp end as ended_timestamp,
  -- s.course_name,
  -- s.course_code,
  nvl(c.sales_business_unit, "Unknown") as sales_business_unit,
  nvl(c.sales_subregion_level_1, "Unknown") as sales_subregion_level_1,
  nvl(c.sales_subregion_level_2, "Unknown") as sales_subregion_level_2,
  nvl(c.sales_subregion_level_3, "Unknown") as sales_subregion_level_3
from
  pre p
  left join main.it_core_dim.dim_dates d on p.ended_timestamp = d.date
  left join main.it_training_silver.docebo_ilt_sessions s on p.session_id = s.id and s.processDate = (select max(processDate) from main.it_training_silver.docebo_ilt_sessions)
  left join main.gtm_data.core_accounts_curated c on p.updated_account_id = c.account_id --corrected this join from joining on account_id to updated_account_id
  )

select *
from test

''')

# COMMAND ----------

# %md # Trained Accounts

# COMMAND ----------

# DBTITLE 1,High Value Accounts Analysis

# trained_accounts_df = spark.sql('''
# with snapshot_dates as (
#   select date_trunc("MONTH", snapshot_date)::date as month, max(snapshot_date) as snapshot_date
#   from main.gtm_data.core_accounts_curated_history
#   where snapshot_date >= "2023-01-01" 
#   group by all
#   order by all
# )

# ,
# accounts as (
#   select
#     date_trunc('MONTH', snapshot_date)::date as snapshot_date,
#     account_id,
#     account_name,
#     t3m_annualized
# from main.gtm_data.core_accounts_curated_history
# where snapshot_date in (select distinct snapshot_date from snapshot_dates)
# and snapshot_date >= "2023-01-01" 
# and t3m_annualized > 250000
# )

# ,
# data as (
#   select
#     t.*,
#     m.period,
#     m.mau,
#     m.prev_month_mau,
#     m.prev_qtr_mau,
#     m.learners,
#     m.cumulative_learners
#   from
#     accounts t
#     left join account_learners_to_mau m on t.account_id = m.account_id
#     and t.snapshot_date = m.period
#   where 1=1
#     -- t.account_id = "0013f000004TJsvAAG"
#     and t.snapshot_date :: date <= (select current_date::date)
#   order by
#     all
# )

# select
#   d.*,
#   c.sales_business_unit,
#   c.sales_subregion_level_1,
#   c.sales_subregion_level_2,
#   c.sales_subregion_level_3,
#   t.fiscal_year as fiscalYear,
#   t.fiscal_year_quarter as FQ2,
#   case
#     when 
#       round(try_divide(d.cumulative_learners, d.mau) * 100, 2) >= 12
#        then 1
#       else 0
#     end
#   as trained_flag,
#   round(try_divide(d.cumulative_learners, d.mau) * 100, 2) as learner_to_mau
# from
#   data d 
# left join main.gtm_data.core_accounts_curated c on d.account_id=c.account_id
# left join main.it_core_dim.dim_dates t on d.period = t.date 
# order by account_id, period


# ''')

# COMMAND ----------

# trained_accounts_df.createOrReplaceTempView('trained_accounts')

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # Gold Enhancement

# COMMAND ----------

# DBTITLE 1,Gold Metadata Enrichment Routine
all_df_gold = add_gold_metadata(all_df)
t28d_producer_base_df_gold = add_gold_metadata(t28d_producer_base_df)
learner_mau_df_gold = add_gold_metadata(learner_maus_df)
account_learner_penetration_gold = add_gold_metadata(account_learner_penetration)
usecase_learners_gold = add_gold_metadata(usecase_learners)
half_day_df_gold = add_gold_metadata(half_day_df)
dsa_accounts_df_gold = add_gold_metadata(dsa_accounts_df)

learner_threshold_df_gold = add_gold_metadata(learner_threshold_df)
learners_by_program_df_gold = add_gold_metadata(learners_by_program_df)
users_with_enrollments_df_gold = add_gold_metadata(users_with_enrollments_df)
users_learners_funnel_df_gold = add_gold_metadata(users_learners_funnel_df)

maus_df_gold = add_gold_metadata(maus_base_df)

unscheduled_sc_df_gold = add_gold_metadata(unscheduled_sc_df)
customer_onboarding_df_gold = add_gold_metadata(customer_onboarding_df)
learners_by_program_actual_target_df_gold = add_gold_metadata(learners_by_program_actual_target_df)

trained_accounts_df_gold = add_gold_metadata(trained_accounts_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_df_gold, 
  table_name = f'{focus_database_name}.fy25_goals_actuals', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = t28d_producer_base_df_gold, 
  table_name = f'{focus_database_name}.t28d_producer_base', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = learner_mau_df_gold, 
  table_name = f'{focus_database_name}.learners_to_mau', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = account_learner_penetration_gold, 
  table_name = f'{focus_database_name}.account_learners_to_mau', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = usecase_learners_gold, 
  table_name = f'{focus_database_name}.usecase_learners', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = dsa_accounts_df_gold, 
  table_name = f'{focus_database_name}.dsa_accounts', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = half_day_df_gold, 
  table_name = f'{focus_database_name}.half_day_classes', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = learner_threshold_df_gold, 
  table_name = f'{focus_database_name}.learner_threshold', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = learners_by_program_df_gold, 
  table_name = f'{focus_database_name}.learners_by_program', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = users_with_enrollments_df_gold, 
  table_name = f'{focus_database_name}.users_with_enrollments_funnel', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = users_learners_funnel_df_gold, 
  table_name = f'{focus_database_name}.users_learners_funnel', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = maus_df_gold, 
  table_name = f'{focus_database_name}.monthly_active_users', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = unscheduled_sc_df_gold, 
  table_name = f'{focus_database_name}.unscheduled_success_credits', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# DBTITLE 1,Customer Onboarding Delta Writer
write_delta_table(
  spark, 
  dataframe = customer_onboarding_df_gold, 
  table_name = f'{focus_database_name}.customer_onboarding', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = learners_by_program_actual_target_df_gold, 
  table_name = f'{focus_database_name}.learners_by_program_actuals_target', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = trained_accounts_df_gold, 
  table_name = f'{focus_database_name}.trained_accounts', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Customer OKRs

# COMMAND ----------

customer_okrs = spark.sql('''
with month_quarter as (
  select
    month_start_date as month,
    fiscal_year_quarter as fq2
  from
    main.it_core_dim.dim_dates
  where
    date = current_date :: date
),
goals_actuals as (
  select
    *
  from
    main.field_learning_enablement.fy25_goals_actuals
  where
    processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.fy25_goals_actuals
    )
),
revenue as (
  select
    metric,
    fiscalYear,
    timeframe,
    grain_lvl_1 as sales_business_unit,
    grain_lvl_2 as sales_subregion_level_1,
    actuals,
    target,
    processdate,
    timeframe_start_date,
    timeframe_end_date
  from
    goals_actuals
  where
    metric = "Training Revenue Pre GAAP"
    and grain_lvl_1 in (
      'AMER Emerging',
      'AMER Enterprise',
      'AMER Regulated Industries',
      'APJ',
      'EMEA',
      'Overall'
    )
),
certs as (
  select
    metric,
    fiscalYear,
    timeframe,
    grain_lvl_2 as sales_business_unit,
    grain_lvl_3 as sales_subregion_level_1,
    actuals,
    target,
    processdate,
    timeframe_start_date,
    timeframe_end_date
  from
    goals_actuals
  where
    metric = "Active Certifications"
    and grain_lvl_1 = "Customer"
    and grain_lvl_2 <> "Unknown"
)
,
mau as (
  select
    metric,
    fiscalYear,
    timeframe,
    grain_lvl_1 as sales_business_unit,
    grain_lvl_2 as sales_subregion_level_1,
    actuals,
    target,
    processdate,
    timeframe_start_date,
    timeframe_end_date
  from
    goals_actuals
  where
    metric = "MAU"
    and grain_lvl_1 in (
      'AMER Emerging',
      'AMER Enterprise',
      'AMER Regulated Industries',
      'APJ',
      'EMEA',
      'Overall'
    )
),
customer_learners as (
  select
    "Customer Learners" as metric,
    fiscalYear,
    timeframe,
    grain_lvl_2 as sales_business_unit,
    grain_lvl_3 as sales_subregion_level_1,
    actuals,
    target,
    processdate,
    timeframe_start_date,
    timeframe_end_date
  from
    goals_actuals
  where
    metric = "Total Unique Learners"
    and grain_lvl_1 = "Customer"
    and grain_lvl_2 <> "Unknown"
),
trained_accounts as (
  select
    metric,
    fiscalYear,
    timeframe,
    grain_lvl_1 as sales_business_unit,
    grain_lvl_2 as sales_subregion_level_1,
    actuals,
    target,
    processdate,
    timeframe_start_date,
    timeframe_end_date
  from
    goals_actuals
  where
    metric = "Trained Accounts"
    and grain_lvl_1 in (
      'AMER Emerging',
      'AMER Enterprise',
      'AMER Regulated Industries',
      'APJ',
      'EMEA',
      'Overall'
    )
),
final as (
  select
    *
  from
    revenue
  union all
  select
    *
  from
    certs
  union all
  select
    *
  from
    mau
  union all
  select
    *
  from
    customer_learners
  union all
  select
    *
  from
    trained_accounts
)
select
  *
from
  final 
''')

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = customer_okrs, 
  table_name = f'{focus_database_name}.customer_le_okrs', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Forecasts

# COMMAND ----------

try:
  sht = authGoogleSheet("TR Revenue Forecast - FY25")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')
  

try:
  worksheet = sht.worksheet("NEW Forecast Overview - FY25Q2")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')

workbook_id='1dhoq6AJAlr1UkFeHaRmsWj_hv8YJqrk_P8NYPncMxzw'
sheet_id='1176619674'

read_google_sheet(
  workbook_id=workbook_id,
  sheet_id=sheet_id,
  temp_view_name='revenue_forecast_raw',
  cell_range='A48:H70'
)

# COMMAND ----------

forecast_df = spark.sql('''
with pre as (select *
from main.it_core_dim.dim_dates
where
  (
    is_fiscal_quarter_end is true
    or date = date_format(date, 'yyyy-MM-01')
  )
  )
,
months as (
select *, lag(date) over (order by date) as prev_month from pre
where not is_fiscal_quarter_end
order by date
)
,
current_prev_month as (
select 
  date as month,
  prev_month
from months
where date = date_format(current_date, 'yyyy-MM-01')
)
,
quarters as (
  select *, lag(fiscal_year_quarter) over (order by date) as prev_quarter, lead(fiscal_year_quarter) over (order by date) as next_quarter, date_format(fiscal_quarter_end_date, 'yyyy-MM-01') as fiscal_quarter_month_start
  from pre
  where is_fiscal_quarter_end
)
,
current_prev_quarter as (
select 
  fiscal_year_quarter,
  prev_quarter,
  next_quarter
from quarters 
where date = (select fiscal_quarter_end_date from main.it_core_dim.dim_dates where date = current_date)
)
,
forecast_revenue as (
  select cast(replace(split(subtotal, ' ')[2],',','') as double) as forecast_revenue
  from revenue_forecast_raw
  where gaap_revenue = "Total Forecasted Revenue"
)
,
data as (
select 
  metric,
  timeframe,
  actuals,
   lag(actuals) over (
      order by
        metric, timeframe
    ) as prev_timeframe_actuals,
  target,
  round(actuals/target*100,0) as attainment,
  timeframe_start_date,
  timeframe_end_date
from main.field_learning_enablement.fy25_goals_actuals
where processDate = (select max(processDate) from main.field_learning_enablement.fy25_goals_actuals)
and grain_lvl_1 = "Overall"
and timeframe in (
    (select month from current_prev_month),
    (select prev_month from current_prev_month),
    (select fiscal_year_quarter from current_prev_quarter),
    (select prev_quarter from current_prev_quarter)
)
order by metric, timeframe
)
,
learners as (
select 
  * except (forecast),
  lag(actuals) over (
  order by
    metric, timeframe
) as prev_timeframe_actuals
from main.field_learning_enablement.fy25_goals_actuals
where processDate = (select max(processDate) from main.field_learning_enablement.fy25_goals_actuals)
and metric = "Total Unique Learners"
and timeframe in (
    (select fiscal_year_quarter from current_prev_quarter),
    (select prev_quarter from current_prev_quarter)
)
and grain_lvl_1 = "Customer"
and grain_lvl_2 = "Overall"
)
,
learner_forecast as (
  select 
    *,
  prev_timeframe_actuals + round((actuals-prev_timeframe_actuals)/(datediff(current_date, timeframe_start_date)+1)*(datediff(timeframe_end_date, timeframe_start_date)+1),0) as forecast
  from learners
  where timeframe in (
      (select fiscal_year_quarter from current_prev_quarter)
  )
)
,
prev_quarter_mau as (
  select sum(prev_qtr_mau) as prev_qtr_mau
  from main.field_learning_enablement.account_learners_to_mau
  where processDate = (select max(processDate) from main.field_learning_enablement.account_learners_to_mau)
  and period =  (select month from current_prev_month)
)
,
last_year_current_prev_month as (
select 
  date_format(date_add(MONTH, -13, month), 'yyyy-MM-01') as prev_year_month,
  date_format(date_add(MONTH, -11, month), 'yyyy-MM-01') as prev_year_prev_month,
  date_format(date_add(MONTH, -12, month), 'yyyy-MM-01') as prev_year_current_month
from current_prev_month
)
,
-- historical_mau_data as (
-- 
-- select month, sum(mau) as mau
-- from main.field_learning_enablement.monthly_active_users
-- where processDate = (select max(processDate) from main.field_learning_enablement.monthly_active_users)
-- and month in ((select prev_year_month from last_year_current_prev_month), (select prev_year_prev_month from -- last_year_current_prev_month))
-- group by all 
-- order by 1
-- )
-- ,
-- mau_growth as (
-- select (((select mau from historical_mau_data where month = (select prev_year_prev_month from -- last_year_current_prev_month))-(select mau from historical_mau_data where month = (select prev_year_month from -- last_year_current_prev_month)))/(select mau from historical_mau_data where month = (select prev_year_month from -- last_year_current_prev_month))) as historical_mau_growth
-- )
-- 
-- ,
historical_mau as 
(select month, sum(mau) as mau
from main.field_learning_enablement.monthly_active_users
where processDate = (select max(processDate) from main.field_learning_enablement.monthly_active_users)
and month >= (select prev_year_current_month from last_year_current_prev_month)
and month <> (select month from current_prev_month)
group by 1
order by 1
)
,
monthly_mau_growth as (
    select
        month,
        mau,
        lag(mau) over (order by month) as previous_mau,
        (mau - lag(mau) over (order by month)) / lag(mau) over (order by month) AS growth_rate
    from historical_mau
)
,
mau_growth as (
  select
    avg(growth_rate) as historical_mau_growth
  from monthly_mau_growth
  where previous_mau is not null
)

,
forecast_pre as (
select 
  d.metric,
  d.timeframe,
  d.actuals,
  case 
    when d.metric = 'Active Certifications'
    then d.prev_timeframe_actuals + round((d.actuals-d.prev_timeframe_actuals)/(datediff(current_date, d.timeframe_start_date)+1)*(datediff(d.timeframe_end_date, d.timeframe_start_date)+1),0) 
    when d.metric = 'Total Unique Learners'
    then d.prev_timeframe_actuals + round((d.actuals-d.prev_timeframe_actuals)/(datediff(current_date, d.timeframe_start_date)+1)*(datediff(d.timeframe_end_date, d.timeframe_start_date)+1),0) 
    when d.metric = 'Fiscal Badges'
    then d.prev_timeframe_actuals + round((d.actuals-d.prev_timeframe_actuals)/(datediff(current_date, d.timeframe_start_date)+1)*(datediff(d.timeframe_end_date, d.timeframe_start_date)+1),0) 
    when d.metric = "Learner to MAU"
    then round((select forecast from learner_forecast)/(select prev_qtr_mau from prev_quarter_mau),5)
    when d.metric = "Training Revenue Pre GAAP"
    then (select forecast_revenue from forecast_revenue)
    when d.metric = "MAU"
    then round(d.actuals + (d.actuals * (select historical_mau_growth from mau_growth)),0)
    end as forecast,
    d.target
  --  nq.target as next_quarter_target
from data d
--join next_quarter_goals nq on d.metric = nq.metric
where (d.timeframe = (select fiscal_year_quarter from current_prev_quarter) or d.timeframe = (select prev_month from current_prev_month))
order by metric
)
,
forecast as (
select 
  metric,
  case when metric = 'MAU'
  then (select month from current_prev_month)
  else timeframe 
  end as timeframe,
  forecast,
  "Overall" as grain_lvl_1
from forecast_pre
)

select 
  a.* except (a.forecast),
  f.forecast
from main.field_learning_enablement.fy25_goals_actuals a
left join forecast f on a.metric = f.metric and a.timeframe = f.timeframe and a.grain_lvl_1 = f.grain_lvl_1
where a.processDate = (select max(processDate) from main.field_learning_enablement.fy25_goals_actuals)

''')

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = forecast_df, 
  table_name = f'{focus_database_name}.fy25_goals_actuals', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

