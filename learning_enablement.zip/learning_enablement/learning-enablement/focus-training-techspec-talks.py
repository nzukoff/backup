# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for techspec talks training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Users/liam.clifford@databricks.com/Liam's Notebook - getMeetingInformation UDF"

# COMMAND ----------

# MAGIC %run "/Users/liam.clifford@databricks.com/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
# from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import json
import requests
from pprint import pprint
from urllib.parse import quote_plus as urlencode
import pandas as pd


warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# 2024-03-21 21:23 TechSpec Talk - DBSQL Attendance Report
# Also going to add Data governance google meet attendance
try:
  sht = authGoogleSheet("2024-03-21 21:23 TechSpec Talk - DBSQL Attendance Report")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')

  
try:
  worksheet = sht.worksheet("Attendees")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "2024-03-21 21:23 TechSpec Talk - DBSQL Attendance Report",
 "Attendees",
 "dbsql_techspec_talk_attendees",
 clean_column_names="true", 
 make_columns_unique="true"
)

dbsql_techspec_talk_attendees_df = (spark.sql("""select * from dbsql_techspec_talk_attendees"""))
# display(dbsql_techspec_talk_attendees_df)

# COMMAND ----------

today = datetime.today()
one_year_ago = today - timedelta(days=365)
one_year_ago_formatted = one_year_ago.strftime('%Y-%m-%d')

techspec_hosts = [
  # DBSQL/DW
  {
    'host': 'amogh.bayya@databricks.com',
    'meeting_id': '81097930598',
    'from_date': one_year_ago_formatted,
    'to_date': datetime.today().strftime('%Y-%m-%d'),
    'type': 'webinars'
  }
  ,
  {
    'host': 'amogh.bayya@databricks.com',
    'meeting_id': '86986416143',
    'from_date': one_year_ago_formatted,
    'to_date': datetime.today().strftime('%Y-%m-%d'),
    'type': 'meetings'
  }
  ,
  # CI&S
  {
    'host': 'amogh.bayya@databricks.com',
    'meeting_id': '89126510948',
    'from_date': one_year_ago_formatted,
    'to_date': datetime.today().strftime('%Y-%m-%d'),
    'type': 'meetings'
  }
  ,
  # DS&ML
  {
    'host': 'joseph@databricks.com',
    'meeting_id': '86204594093',
    'from_date': one_year_ago_formatted,
    'to_date': datetime.today().strftime('%Y-%m-%d'),
    'type': 'meetings'
  }
  ,
  # DE
  # https://databricks.zoom.us/j/85636230860?pwd=YzQrSm00WWlRMnhWcDZsM25zVFpTdz09
  {
    'host': 'steven.yu@databricks.com',
    'meeting_id': '85636230860',
    'from_date': one_year_ago_formatted,
    'to_date': datetime.today().strftime('%Y-%m-%d'),
    'type': 'meetings'
  }
  
]

# COMMAND ----------

meeting_details_dfs = []
meeting_participants_dfs = []

for host in techspec_hosts:
  getMeetingDetailsByMeetingIdV3(meeting_id=host['meeting_id'],type='meetings',fromDate=host['from_date'],toDate=host['to_date'])

  meeting_details = spark.sql("""select * from meeting_details""")
  meeting_participants = spark.sql("""select * from meeting_participants""")

  meeting_details_dfs.append(meeting_details)
  meeting_participants_dfs.append(meeting_participants)

# COMMAND ----------

details_schema = T.StructType([
  T.StructField('uuid', T.StringType(), True),
  T.StructField('id', T.StringType(), True),
  T.StructField('host_id', T.StringType(), True),
  T.StructField('type', T.StringType(), True),
  T.StructField('topic', T.StringType(), True),
  T.StructField('user_name', T.StringType(), True),
  T.StructField('user_email', T.StringType(), True),
  T.StructField('start_time', T.StringType(), True),
  T.StructField('end_time', T.StringType(), True),
  T.StructField('duration', T.StringType(), True),
  T.StructField('total_minutes', T.StringType(), True),
  T.StructField('participants_count', T.StringType(), True),
  T.StructField('tracking_fields', T.StringType(), True),
  T.StructField('dept', T.StringType(), True),
  T.StructField('webinars', T.StringType(), True)
])

participants_schema = T.StructType([
  T.StructField('id', T.StringType(), True),
  T.StructField('user_id', T.StringType(), True),
  T.StructField('name', T.StringType(), True),
  T.StructField('user_email', T.StringType(), True),
  T.StructField('join_time', T.StringType(), True),
  T.StructField('leave_time', T.StringType(), True),
  T.StructField('duration', T.StringType(), True),
  T.StructField('attentiveness_score', T.StringType(), True),
  T.StructField('failover', T.StringType(), True),
  T.StructField('status', T.StringType(), True),
  T.StructField('customer_key', T.StringType(), True),
  T.StructField('participant_user_id', T.StringType(), True),
  T.StructField('uuid', T.StringType(), True),
])

# COMMAND ----------

meeting_details_df = spark.createDataFrame([], details_schema)
meeting_participants_df = spark.createDataFrame([], participants_schema)
for df in meeting_details_dfs:
  meeting_details_df = meeting_details_df.union(df)
    
for df in meeting_participants_dfs:
  # display(df)
  meeting_participants_df = meeting_participants_df.unionByName(df, True)

# display(meeting_details_df)
# display(meeting_participants_df)

# COMMAND ----------

# Also need to add the data governance details in meeting_details table
google_meet_participants_df = spark.sql(
    """
select
  '' as id,
  '' as user_id,
  concat(e.first_name, " ", e.last_name) as name,
  email as user_email,
  concat(
    concat(
      split(
        date_format(to_timestamp(concat('2024-03-21 ',date_format(to_timestamp(e.time_joined, 'hh:mm a'), 'HH:mm')),'yyyy-MM-dd HH:mm'),'yyyy-MM-dd HH:mm:ss')," ") [0],'T'
    ),
    concat(
      split(
        date_format(to_timestamp(concat('2024-03-21 ',date_format(to_timestamp(e.time_joined, 'hh:mm a'), 'HH:mm')),'yyyy-MM-dd HH:mm'),'yyyy-MM-dd HH:mm:ss')," ") [1],'Z'
    )
  ) as join_time,
  concat(
    concat(
      split(date_format(to_timestamp(concat('2024-03-21 ',date_format(to_timestamp(e.time_exited, 'hh:mm a'), 'HH:mm')),'yyyy-MM-dd HH:mm'),'yyyy-MM-dd HH:mm:ss')," ") [0],'T'
    ),
    concat(
      split(date_format(to_timestamp(concat('2024-03-21 ',date_format(to_timestamp(e.time_exited, 'hh:mm a'), 'HH:mm')),'yyyy-MM-dd HH:mm'),'yyyy-MM-dd HH:mm:ss')," ") [1],'Z'
    )
  ) as leave_time,
  CASE
    WHEN contains(e.duration, 'hr')
    AND contains(e.duration, ' min') THEN (CAST(split(e.duration, ' hr') [0] AS INT) * 3600) + (
      CAST(
        split(split(e.duration, ' hr') [1], ' min') [0] AS INT
      ) * 60
    )
    WHEN contains(e.duration, 'hr') THEN CAST(split(e.duration, ' hr') [0] AS INT) * 3600
    WHEN contains(e.duration, ' min') THEN CAST(split(e.duration, ' min') [0] AS INT) * 60
    ELSE 0
  END AS duration,
  '' as attentiveness_score,
  'False' as failover,
  'in_meeting' as status,
  '' as customer_key,
  'nan' as participant_user_id,
  '' as uuid
from
  dbsql_techspec_talk_attendees e
  """
)
meeting_participants_df = meeting_participants_df.unionByName(
    google_meet_participants_df, True
)
# display(google_meet_participants_df)
display(meeting_participants_df.filter(col('name') == 'Brandon Cowen'))

# COMMAND ----------

meeting_details_df.createOrReplaceTempView('meeting_details')
meeting_participants_df.createOrReplaceTempView('meeting_participants')
spark.sql('''select * from meeting_details''')
# display(meeting_details_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Add the Google Meet meetings attendance data
# MAGIC slp: ((03/21/2024): TechSpec Talks - DBSQL - Azure PL GA / SEC + TCO Story, SQL Notebooks GA (Workflows, Params)) is a google meet
# MAGIC need to add a new column meeting type (google meet or zoom). Add the attendance data from the attendance sheet to the ilt of the google meet.???

# COMMAND ----------

techspec_df = spark.sql('''
  with techspec_events as ( 
    select 
      d.uuid,
      d.topic,
      start_time,
      to_date(start_time, "yyyy-MM-dd'T'HH:mm:ss'Z'") as event_date,
      end_time,
      participants_count as registered,
      sum (case when nvl(p.id, "Unknown") != "Unknown" then 1 else 0 end) as attended
    from meeting_details d
    left join meeting_participants p on d.uuid=p.uuid
    -- and p.duration >= 1200
    group by 1,2,3,4,5,6
    order by start_time
  )
  ,
  techspec_courses as (
    select 
      to_date(replace(replace(element_at(split(name, " "),1),'(',''), ')', ''), 'MM/dd/yy') as event_date,
      name,
      code
    from main.it_training_silver.docebo_courses
    where processDate = (select max(processDate) from main.it_training_silver.docebo_courses)
    and (name ilike '%TechSpec%'
    or name ilike '%ML SME Talk Session%')
  )
  ,
  sp_techspec_enrollment_dates as (
  select 
    *
  from main.field_learning_enablement.self_paced_enrollments
  where processDate = (select max(processDate) from main.field_learning_enablement.self_paced_enrollments)
  and course_name ilike '%TechSpec%'
  or course_name ilike '%ML SME Talk Session%'
  and status = 'completed'
  order by enrolled_timestamp 
  )

  ,
  sp_techspec as (
    select distinct
      course_name,
      course_code,
      count(learner_email_hash) as completed_sp
    from sp_techspec_enrollment_dates
    group by 1,2
  )

  select 
    -- i.name as course_name,
    case when trim(i.name) = 'Google Calendar Meeting (not synced)'
    then 'TechSpec Talks: DBSQL'
    else i.name end as course_name,
    i.code as course_code,
    e.topic,
    e.event_date,
    e.registered,
    e.attended,
    nvl(s.completed_sp,0) as completed_sp
  from techspec_events e
  left join techspec_courses i on e.event_date = i.event_date -- the courses that are not done using zoom, need to do full join
  left join sp_techspec s on i.code = s.course_code -- the courses that are not done using zoom, need to do full join
  order by e.event_date desc
''')
techspec_df.createOrReplaceTempView('techspec_df')

# COMMAND ----------


techspec_details_df = spark.sql('''     
  with sp_titles as (
      select distinct
      to_date(replace(replace(element_at(split(course_name, " "),1),'(',''), ')', ''), 'MM/dd/yy') as event_date,
      course_name
    from main.field_learning_enablement.self_paced_enrollments
    where processDate = (select max(processDate) from main.field_learning_enablement.self_paced_enrollments)
    and (course_name ilike '%TechSpec%'
    or course_name ilike '%ML SME Talk Session%')
  )
  ,
  ilt_event_dates as (
    select 
      to_date(start_time, "yyyy-MM-dd'T'HH:mm:ss'Z'") as event_date,
      *
    from meeting_details
  )         
    select
      d.id,
      d.host_id,
      d.type,
      d.topic,
      d.user_name,
      d.user_email as host_email,
      d.start_time,
      d.end_time,
      d.duration as event_duration,
      d.total_minutes,
      d.participants_count,
      d.tracking_fields,
      d.dept,
      d.webinars,
      d.event_date,
      -- p.user_id,
      p.name,
      p.user_email,
      min(p.join_time) as join_time,
      max(p.leave_time) as leave_time,
      max(p.leave_time) - min(p.join_time) as duration,
      case when p.duration > 300 then 1 else 0 end as attended,
      -- case when p.duration >= 1200 then 1 else 0 end as attended,
      p.attentiveness_score,
      p.failover,
      p.status,
      -- p.customer_key,
      --p.participant_user_id,
      case when array_contains(collect_list(distinct p.participant_user_id), 'nan')
      then replace(array_join(collect_list(distinct p.participant_user_id),''), 'nan', '')
      else array_join(collect_set(distinct p.participant_user_id),'')
      end AS participant_user_id,
      p.uuid,
      s.course_name,
      case when 
      d.topic = 'SME Session: ML' or topic = 'Unstructured talk at Databricks ML SME group' then 'Data Science and Machine Learning'
      when d.topic = '[bw] DIT SME Sync' then 'Data Engineering'
      when d.topic = 'Google Calendar Meeting (not synced)' or contains(d.topic,'DBSQL') then 'Data Warehousing'
      when d.topic = 'TechSpec Talks - Cloud Infra & Security' then 'Cloud Infrastructure and Security'
      end as l300_spec_domain

    from ilt_event_dates d
    left join meeting_participants p on d.uuid=p.uuid
    left join sp_titles s on d.event_date=s.event_date
    group by all
    order by event_date, name
''')

# COMMAND ----------

# display(techspec_details_df.filter((col("name") =="Brandon Cowen")))
                                  #  & (col("participant_user_id") != '')))
# display(techspec_details_df.filter(array_contains(col("name"), "Brandon Cowen")))
# display(techspec_details_df.filter(col("customer_key") != ""))

# COMMAND ----------

techspec_details_df.createOrReplaceTempView('techspec_ilt_details')

# COMMAND ----------

techspec_all_enrollments = spark.sql('''
WITH ilt_enrollments AS (
    select 
      d.id as learner_user_id,
      t.user_email as learner_email, 
      nvl(t.course_name, t.topic) as course_name,
      c.id as course_id, 
      c.code as course_code, 
      'classroom' as course_type, 
      case when sum(t.attended) > 0 then 'completed' else 'subscribed' end as status,
      to_timestamp(min(t.join_time), "yyyy-MM-dd'T'HH:mm:ss'Z'") as enrolled_timestamp,
      to_timestamp(max(t.leave_time), "yyyy-MM-dd'T'HH:mm:ss'Z'") as completed_timestamp,
      sum(t.duration) as total_duration
    from techspec_ilt_details  t 
    left join main.it_training_silver.docebo_courses c on t.course_name = c.name and c.processDate = (select max(processDate) from main.it_training_silver.docebo_courses) and (c.name ilike '%TechSpec%' or c.name ilike '%ML SME Talk Session%')
    left join main.field_learning_enablement.docebo_users d on t.user_email = d.email and d.processDate = (select max(processDate) from main.field_learning_enablement.docebo_users) and d.branch_code = 'DBK_EMP'
    group by learner_user_id, learner_email, t.course_name, course_id, course_code, topic
),
sp_enrollments AS (
    select 
      s.learner_user_id,
      s.learner_email, 
      s.course_name, 
      s.course_id, 
      s.course_code, 
      s.course_type, 
      s.status,
      s.enrolled_timestamp, 
      s.completed_timestamp,
      d.expected_time_to_complete_in_seconds as total_duration
    from main.field_learning_enablement.self_paced_enrollments s
    left join main.it_training_silver.docebo_courses d on s.course_name = d.name
    and d.processDate = (select max(processDate) from main.it_training_silver.docebo_courses)
    and (d.name ilike '%TechSpec%'
    or d.name ilike '%ML SME Talk Session%')
    where s.processDate = (select max(processDate) from main.field_learning_enablement.self_paced_enrollments)
    and (s.course_name ilike '%TechSpec%'
    or s.course_name ilike '%ML SME Talk Session%')
),
all_enrollments AS (
    SELECT
        learner_user_id,
        learner_email,
        course_name,
        course_id,
        course_code,
        course_type,
        status,
        enrolled_timestamp,
        completed_timestamp,
        total_duration
    FROM sp_enrollments
    UNION ALL
    SELECT
        learner_user_id,
        learner_email,
        course_name,
        course_id,
        course_code,
        course_type,
        status,
        enrolled_timestamp,
        completed_timestamp,
        total_duration
    FROM ilt_enrollments
)
SELECT
    learner_user_id,
    learner_email,
    case when trim(course_name) = 'Google Calendar Meeting (not synced)'
    then 'TechSpec Talks: DBSQL'
    else course_name end as course_name,
    course_id,
    course_code,
    case when array_contains(collect_list(status), 'completed') then 'completed'
    when array_contains(collect_list(status), 'in_progress') then 'in_progress' 
    else 'subscribed' end as status,
    array_join(collect_list(course_type), ' + ') AS course_type,
    MIN(enrolled_timestamp) as enrolled_timestamp,
    MAX(completed_timestamp) as completed_timetamp,
    SUM(total_duration) AS total_duration, -- Sum total_durations for records with the same course_id
    case when contains(course_name, "DBSQL") or contains(course_name, "Google Calendar Meeting (not synced)") then "Data Warehousing"
      when contains(course_name, "SME Session - ML") or contains(course_name, "SME Session: ML") or contains(course_name, 'ML SME Talk Session') then "Data Science and Machine Learning"
      when contains(course_name, "Cloud Infrastructure & Security") then "Cloud Infrastructure and Security"
      end as l300_domain
FROM all_enrollments
WHERE learner_user_id IS NOT NULL
GROUP BY learner_user_id, learner_email, course_name, course_id, course_code
ORDER BY course_name,learner_email
''')

# COMMAND ----------

techspec_gold = add_gold_metadata(techspec_df)
techspec_details_gold = add_gold_metadata(techspec_details_df)
techspec_all_enrollments_gold = add_gold_metadata(techspec_all_enrollments)

# COMMAND ----------

# display(techspec_details_gold)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = techspec_gold, 
  table_name = f'{focus_database_name}.techspec_summary', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = techspec_details_gold, 
  table_name = f'{focus_database_name}.techspec_details', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = techspec_all_enrollments_gold, 
  table_name = f'{focus_database_name}.techspec_all_enrollments', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

# %sql
# select * from main.field_learning_enablement.techspec_details
# where processDate = (select max(processDate) from main.field_learning_enablement.techspec_details)
# and l300_spec_domain = 'Data Warehousing'
# and host_email = 'amogh.bayya@databricks.com'

# COMMAND ----------

# %sql
# select * from main.field_learning_enablement.techspec_details
# where processDate = (select max(processDate) from main.field_learning_enablement.techspec_details)
# and name = 'Brandon Cowen'

# COMMAND ----------

