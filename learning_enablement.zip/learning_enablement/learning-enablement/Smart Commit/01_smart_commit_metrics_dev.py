# Databricks notebook source
# MAGIC %md
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] smart-commit-dashboard-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Lekshmi \
# MAGIC **Source(s):**      main.gtm_data.core_opportunity_curated, main.it_finance_silver.opp_bookings_billing_agg, main.gtm_data.core_accounts_curated  etc. \
# MAGIC **Target:**          main.field_learning_enablement.smart_commits_base \
# MAGIC **Description:**     This notebook creates the metrics associated with Smart Commit Dashboard \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Standard Libraries

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
import json
import requests
from pprint import pprint
from urllib.parse import quote_plus as urlencode
import pandas as pd

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W

# COMMAND ----------

# MAGIC %md
# MAGIC Parameters
# MAGIC Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values.
# MAGIC
# MAGIC Create as many as makes sense for your notebook
# MAGIC For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement
# MAGIC Once the parameter widgets are defined, import the parameter values to local variables using try/except

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

#focus_database_name='users.lekshmi_s'

# COMMAND ----------

query_final_table = """
WITH base_table as (
  SELECT 
    coc.start_date 
    ,coc.end_date 
    ,coc.commit_start_date
    ,coc.renewal_date
    ,coc.renewal_timeliness
    ,case when datediff(original_expected_renewal_date, close_date) >=0 then 1 else 0 end as on_time_renewal_flag -- verified
    ,coc.opportunity_id 
    ,coc.business_unit
    ,case when coc.opportunity_type in ('Azure – P3 Only','Azure P3-Only') then 'Azure P3-Only' else coc.opportunity_type end as opportunity_type
    ,acct.sales_subregion_level_1
    ,coc.amount as commit_amount
    ,coc.forecast_category
    ,coc.snapshot_date
    ,datediff(coc.end_date, coc.start_date) as commit_duration_days
    ,case when datediff(coc.end_date, coc.start_date) > 365 then 1 else 0 end as multi_year_commit_flag -- verified
    ,dd.fiscal_year_quarter as fiscal_year_quarter_on_signed_stage_date
    ,coc.signed_stage_date_stamp
  FROM main.gtm_data.core_opportunity_curated  coc
  LEFT JOIN main.it_core_dim.dim_dates dd
            on coc.signed_stage_date_stamp = dd.`date`
  INNER JOIN main.gtm_data.core_accounts_curated as acct
            on coc.account_id = acct.account_id 
  WHERE 1=1
    and coc.snapshot_date = (select max(coc.snapshot_date) from main.gtm_data.core_opportunity_curated coc)
    and opportunity_stage = "Closed Won"
    and opportunity_type in ('Renewal','Upsell', 'New Business', 'Azure P3-only', 'Churn','Azure P3-Only','Azure – P3 Only')
),

upfront_payments_base as (
  SELECT
    obba.*
    ,CASE 
      WHEN try_divide(obba.Bookings_Billed_Upfront_Within_30days,obba.Booking_Dollars)>=1 THEN 1
    ELSE 0  END as upfront_payments_flag
  FROM main.it_finance_silver.opp_bookings_billing_agg obba
  INNER JOIN base_table 
    ON base_table.opportunity_id = obba.opportunity_id
  WHERE 
    1=1 
    and process_date = 
    ( 
      SELECT max(process_date) 
      FROM main.it_finance_silver.opp_bookings_billing_agg                 
    )
    and lower(trim(obba.Opportunity_Stage)) = "closed won"
),

opp_product_base as 
  (SELECT 
    cop.account_name,
    cop.account_id,
    cop.opportunity_name,
    cop.opportunity_id,
    cop.close_date,
    cop.opportunity_close_fiscal_year_quarter,
    cop.business_unit,
    cop.opportunity_region_level_1,
    cop.opportunity_region_level_2,
    cop.opportunity_type,
    cop.opportunity_stage,
    cop.forecast_category,
    cop.product_family_derived,
    cop.total_price,
    cop.incremental_booking_total_forecast,
    current_dates.current_fiscal_quarter_start_date,
    true as include_oppty_in_attach_calc_ind
  ,SUM(
    Case
      WHEN product_family_derived IN ('License', 'Support') THEN total_price
      ELSE 0
    END
  ) AS Product_Total_Amount
  ,SUM(
    Case
      WHEN product_family_derived IN ('License', 'Support') THEN incremental_booking_total_forecast
      ELSE 0
    END
  ) AS Product_Bookings_value
  ,SUM(
    Case
      WHEN product_family_derived = 'Training' THEN incremental_booking_total_forecast
      ELSE 0
    END
  ) AS TR_Bookings_value
  FROM main.gtm_data.core_opportunity_product cop
  CROSS JOIN 
  (
    SELECT 
      date as current_date
      ,fiscal_quarter_start_date as current_fiscal_quarter_start_date
      ,fiscal_quarter_end_date as current_fiscal_quarter_end_date 
    FROM main.it_core_dim.dim_dates where date = current_date()
  ) current_dates
  WHERE 1=1
    and snapshot_date = (SELECT max(snapshot_date) FROM main.gtm_data.core_opportunity_product)
    and product_family in ('License', 'Support', 'Training')
    and opportunity_stage not in ('Closed Lost', 'Disqualified')
    and forecast_category not in ('Omitted')
  GROUP BY ALL
),
commits_with_training as(
select 
  account_name
  ,account_id
  ,opportunity_name
  ,opportunity_id
  ,close_date
  ,opportunity_close_fiscal_year_quarter
  ,business_unit
  --opportunity_region
  ,opportunity_region_level_1
  ,opportunity_region_level_2
  ,opportunity_type
  ,opportunity_stage
  ,forecast_category
  ,TR_Bookings_value
  ,Product_Total_Amount
  ,Product_Bookings_value
  ,include_oppty_in_attach_calc_ind
  ,case 
    when include_oppty_in_attach_calc_ind=true 
    then sum(TR_Bookings_value) over(partition by account_id) 
    else null 
  end as tr_account_qtr_bookings
  ,case 
    when ((sum(TR_Bookings_value) over(partition by account_id)) >0) and (include_oppty_in_attach_calc_ind=true) 
    then 1 
    else 0 
  end as account_has_tr_in_qtr_ind
  ,case 
    when include_oppty_in_attach_calc_ind=true 
    then sum(TR_Bookings_value) over(partition by opportunity_id) 
    else null 
  end as tr_opp_qtr_bookings
  ,case 
    when ((sum(TR_Bookings_value) over(partition by opportunity_id)) >0) and (include_oppty_in_attach_calc_ind=true) 
    then 1 
    else 0 
  end as opp_has_tr_in_qtr_ind
from opp_product_base 
),

learning_attached_base as (
  SELECT  
    cwt.opportunity_name
    ,cwt.opportunity_id
    ,cwt.close_date
    ,cwt.opp_has_tr_in_qtr_ind as learning_attached_flag
    ,cwt.tr_opp_qtr_bookings as learning_bookings_value
  FROM commits_with_training cwt
  INNER JOIN base_table base
  ON base.opportunity_id = cwt.opportunity_id
  WHERE 1=1 
)
----Final Table being created:
SELECT DISTINCT
  base.*
  ,coalesce(upb.upfront_payments_flag, 0) as upfront_payments_flag
  ,coalesce(la.learning_attached_flag, 0) as learning_attached_flag
  ,coalesce(la.learning_bookings_value, 0) as learning_bookings_value
  ,iff(upfront_payments_flag = 1 and learning_attached_flag = 1 and multi_year_commit_flag = 1 and on_time_renewal_flag =1, 1, 0) as smart_commit_flag
  ,'TBD' as extrenal_funding_attached_flag 
  ,1 as total_opp_id_count_flag
FROM base_table base
LEFT JOIN upfront_payments_base upb on base.opportunity_id = upb.opportunity_id 
LEFT JOIN learning_attached_base la on base.opportunity_id = la.opportunity_id  
"""
query_final_table=spark.sql(query_final_table)


# COMMAND ----------

write_delta_table(
  spark, 
  dataframe =query_final_table, 
  table_name=f'{focus_database_name}.smart_commits_base', 
)