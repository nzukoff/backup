# Databricks notebook source
# MAGIC %md
# MAGIC %md
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] smart-commit-dashboard-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      main.field_learning_enablement.smart_commits_base   \
# MAGIC **Target:**          main.field_learning_enablement.smart_commits_fy_agg_cube \
# MAGIC **Description:**     The following notebook creates an aggregate cube of all dimensions for Commit Amount and Opportunity Count. This will be leveraged in Smart Commit Dashboard. The final dataset is created as a union of commit_amount dataset and opportunity_count dataset which are distinguished using the column group_value (Commit Amount:group_value=0 , Opportunity Count:group_value=1)\
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
import json
import requests
from pprint import pprint
from urllib.parse import quote_plus as urlencode
import pandas as pd

from pyspark.sql.functions import sum as _sum
from pyspark.sql.functions import lit

# COMMAND ----------

focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

# COMMAND ----------

from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
#from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W

# COMMAND ----------

# MAGIC %md
# MAGIC Parameters Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values.
# MAGIC
# MAGIC Create as many as makes sense for your notebook For [param key/name], substitute the specific parameter name that you want, ex: target_database For [param value], susbtitute the actual value that you want to set that parameter to, ex: main.field_learning_enablement Once the parameter widgets are defined, import the parameter values to local variables using try/except

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

source_table='main.field_learning_enablement.smart_commits_base'
#source_table='users.lekshmi_s.smart_commits_base'
#focus_database_name='users.lekshmi_s'

# COMMAND ----------

# MAGIC %md
# MAGIC **OPPO_AMT**
# MAGIC The group_value=0

# COMMAND ----------

query_amt=f"""WITH all_combination_of_dimension AS (
SELECT distinct 
  business_unit
  ,sales_subregion_level_1
  ,oppo_type.opportunity_type
  ,fy_qr.fiscal_year_quarter_on_signed_stage_date
  ,fy_qr.fiscal_year_quarter_on_signed_stage_date_mod
FROM {source_table}
CROSS JOIN 
  (SELECT distinct opportunity_type FROM {source_table}) oppo_type
CROSS JOIN 
  (SELECT distinct fiscal_year_quarter_on_signed_stage_date
  ,SUBSTRING(fiscal_year_quarter_on_signed_stage_date, 7, 2)||SUBSTRING(fiscal_year_quarter_on_signed_stage_date, 0, 5) 
  fiscal_year_quarter_on_signed_stage_date_mod
  FROM {source_table}) fy_qr
  WHERE business_unit is not null
),

alldata AS (
SELECT
  *
FROM {source_table} 
WHERE fiscal_year_quarter_on_signed_stage_date is not null
),

aggregate_by_quarter  as (
SELECT 
  fiscal_year_quarter_on_signed_stage_date
  ,business_unit
  ,opportunity_type
  ,sales_subregion_level_1

  ,sum(case when multi_year_commit_flag=1 then NVL(commit_amount,0) else 0 end) multi_year_commit_curr
  ,sum(case when learning_attached_flag=1 then NVL(commit_amount,0) else 0 end) learning_attached_curr
  ,sum(case when upfront_payments_flag=1 then NVL(commit_amount,0) else 0 end )upfront_payments_curr
  ,sum(case when on_time_renewal_flag=1 then NVL(commit_amount,0) else 0 end)on_time_renewal_curr
  ,sum(case when smart_commit_flag=1 then NVL(commit_amount,0) else 0 end)smart_commit_curr 
  ,sum(NVL(commit_amount,0)) total_curr

 FROM alldata 
 WHERE fiscal_year_quarter_on_signed_stage_date is not null
 GROUP BY ALL
 )

,joined_data_with_all_combination_of_dimension as (
SELECT 
  all_combination_of_dimension.*
  ,aggregate_by_quarter.multi_year_commit_curr
  ,aggregate_by_quarter.learning_attached_curr
  ,aggregate_by_quarter.upfront_payments_curr
  ,aggregate_by_quarter.on_time_renewal_curr
  ,aggregate_by_quarter.smart_commit_curr
  ,aggregate_by_quarter.total_curr
FROM all_combination_of_dimension 
LEFT OUTER JOIN aggregate_by_quarter
ON 
  all_combination_of_dimension.fiscal_year_quarter_on_signed_stage_date=aggregate_by_quarter.fiscal_year_quarter_on_signed_stage_date
  and all_combination_of_dimension.business_unit=aggregate_by_quarter.business_unit
  and all_combination_of_dimension.sales_subregion_level_1=aggregate_by_quarter.sales_subregion_level_1
  and all_combination_of_dimension.opportunity_type=aggregate_by_quarter.opportunity_type
WHERE all_combination_of_dimension.fiscal_year_quarter_on_signed_stage_date is not null
)

,data_with_previous_values AS (
SELECT 
  fiscal_year_quarter_on_signed_stage_date
  ,fiscal_year_quarter_on_signed_stage_date_mod
  ,business_unit
  ,opportunity_type
  ,sales_subregion_level_1
  

  ,multi_year_commit_curr
  ,LAG(multi_year_commit_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) multi_year_commit_prev_qtr
  ,LAG(multi_year_commit_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) multi_year_commit_prev_year

  ,learning_attached_curr
  ,LAG(learning_attached_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) learning_attached_prev_qtr
  ,LAG(learning_attached_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) learning_attached_prev_year

  ,upfront_payments_curr
  ,LAG(upfront_payments_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) upfront_payments_prev_qtr
  ,LAG(upfront_payments_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) upfront_payments_prev_year

  ,on_time_renewal_curr
  ,LAG(on_time_renewal_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) on_time_renewal_prev_qtr
  ,LAG(on_time_renewal_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) on_time_renewal_prev_year


  ,smart_commit_curr
  ,LAG(smart_commit_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) smart_commit_prev_qtr
  ,LAG(smart_commit_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) smart_commit_prev_year

  ,total_curr
  ,LAG(total_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) total_prev_qtr
  ,LAG(total_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) total_prev_year

 FROM joined_data_with_all_combination_of_dimension 
 WHERE fiscal_year_quarter_on_signed_stage_date is not null
 )



SELECT DISTINCT
  fiscal_year_quarter_on_signed_stage_date
  ,fiscal_year_quarter_on_signed_stage_date_mod
  ,business_unit
  ,opportunity_type
  ,sales_subregion_level_1

  ,multi_year_commit_curr
  ,multi_year_commit_prev_qtr
  ,multi_year_commit_prev_year

  ,learning_attached_curr
  ,learning_attached_prev_qtr
  ,learning_attached_prev_year

  ,upfront_payments_curr
  ,upfront_payments_prev_qtr
  ,upfront_payments_prev_year

  ,on_time_renewal_curr
  ,on_time_renewal_prev_qtr
  ,on_time_renewal_prev_year

  ,smart_commit_curr
  ,smart_commit_prev_qtr
  ,smart_commit_prev_year

  ,total_curr
  ,total_prev_qtr
  ,total_prev_year

FROM data_with_previous_values 
"""
df_amt=spark.sql(query_amt)

# COMMAND ----------

# MAGIC %md
# MAGIC **Creating a cube of all combination of dimensions**

# COMMAND ----------


# Apply cube() to aggregate the data
df_cube_amt = df_amt.cube(
  "business_unit"
  ,"fiscal_year_quarter_on_signed_stage_date"
  ,"sales_subregion_level_1"
  ,"opportunity_type"
)\
.agg(\
  _sum("multi_year_commit_curr").alias("multi_year_commit_curr"), 
  _sum("multi_year_commit_prev_qtr").alias("multi_year_commit_prev_qtr"),
  _sum("multi_year_commit_prev_year").alias("multi_year_commit_prev_year"),

  _sum("learning_attached_curr").alias("learning_attached_curr"), 
  _sum("learning_attached_prev_qtr").alias("learning_attached_prev_qtr"),
  _sum("learning_attached_prev_year").alias("learning_attached_prev_year"),

  _sum("upfront_payments_curr").alias("upfront_payments_curr"),
  _sum("upfront_payments_prev_qtr").alias("upfront_payments_prev_qtr"),
  _sum("upfront_payments_prev_year").alias("upfront_payments_prev_year"),

  _sum("on_time_renewal_curr").alias("on_time_renewal_curr"),
  _sum("on_time_renewal_prev_qtr").alias("on_time_renewal_prev_qtr"),
  _sum("on_time_renewal_prev_year").alias("on_time_renewal_prev_year"), 

  _sum("smart_commit_curr").alias("smart_commit_curr"),
  _sum("smart_commit_prev_qtr").alias("smart_commit_prev_qtr"),
  _sum("smart_commit_prev_year").alias("smart_commit_prev_year"), 

  _sum("total_curr").alias("total_curr"),
  _sum("total_prev_qtr").alias("total_prev_qtr"),
  _sum("total_prev_year").alias("total_prev_year"))


df_cube_transformed_amt=\
df_cube_amt\
  .filter("fiscal_year_quarter_on_signed_stage_date is not null")\
  .withColumn("group_value",lit(0))\
  .withColumn("processDate", F.current_timestamp())\
  .na.fill('All')

# COMMAND ----------

# MAGIC %md
# MAGIC **OPPO_CNT** 
# MAGIC The group_value=1

# COMMAND ----------

query_cnt=f"""WITH all_combination_of_dimension AS (
SELECT distinct 
  business_unit
  ,sales_subregion_level_1
  ,oppo_type.opportunity_type
  ,fy_qr.fiscal_year_quarter_on_signed_stage_date
  ,fy_qr.fiscal_year_quarter_on_signed_stage_date_mod
FROM {source_table}
CROSS JOIN 
  (SELECT distinct opportunity_type FROM {source_table}) oppo_type
CROSS JOIN 
  (SELECT distinct fiscal_year_quarter_on_signed_stage_date
  ,SUBSTRING(fiscal_year_quarter_on_signed_stage_date, 7, 2)||SUBSTRING(fiscal_year_quarter_on_signed_stage_date, 0, 5) 
  fiscal_year_quarter_on_signed_stage_date_mod
  FROM {source_table}) fy_qr
  WHERE business_unit is not null
),

alldata AS (
SELECT
  *
FROM {source_table} 
WHERE fiscal_year_quarter_on_signed_stage_date is not null
),

aggregate_by_quarter  as (
SELECT 
  fiscal_year_quarter_on_signed_stage_date
  ,business_unit
  ,opportunity_type
  ,sales_subregion_level_1

  ,sum(multi_year_commit_flag) multi_year_commit_curr
  ,sum(learning_attached_flag) learning_attached_curr
  ,sum(upfront_payments_flag)  upfront_payments_curr
  ,sum(on_time_renewal_flag) on_time_renewal_curr
  ,sum(smart_commit_flag) smart_commit_curr
  ,count(on_time_renewal_flag) total_curr

 FROM alldata 
 WHERE fiscal_year_quarter_on_signed_stage_date is not null
 GROUP BY ALL
 )

,joined_data_with_all_combination_of_dimension as (
SELECT 
  all_combination_of_dimension.*
  ,aggregate_by_quarter.multi_year_commit_curr
  ,aggregate_by_quarter.learning_attached_curr
  ,aggregate_by_quarter.upfront_payments_curr
  ,aggregate_by_quarter.on_time_renewal_curr
  ,aggregate_by_quarter.smart_commit_curr
  ,aggregate_by_quarter.total_curr
FROM all_combination_of_dimension 
LEFT OUTER JOIN aggregate_by_quarter
ON 
  all_combination_of_dimension.fiscal_year_quarter_on_signed_stage_date=aggregate_by_quarter.fiscal_year_quarter_on_signed_stage_date
  and all_combination_of_dimension.business_unit=aggregate_by_quarter.business_unit
  and all_combination_of_dimension.sales_subregion_level_1=aggregate_by_quarter.sales_subregion_level_1
  and all_combination_of_dimension.opportunity_type=aggregate_by_quarter.opportunity_type
WHERE all_combination_of_dimension.fiscal_year_quarter_on_signed_stage_date is not null
)

 ,data_with_previous_values AS (
SELECT 
  fiscal_year_quarter_on_signed_stage_date
  ,fiscal_year_quarter_on_signed_stage_date_mod
  ,business_unit
  ,opportunity_type
  ,sales_subregion_level_1

  ,multi_year_commit_curr
  ,LAG(multi_year_commit_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) multi_year_commit_prev_qtr
  ,LAG(multi_year_commit_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) multi_year_commit_prev_year

  ,learning_attached_curr
  ,LAG(learning_attached_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) learning_attached_prev_qtr
  ,LAG(learning_attached_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) learning_attached_prev_year

  ,upfront_payments_curr
  ,LAG(upfront_payments_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) upfront_payments_prev_qtr
  ,LAG(upfront_payments_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) upfront_payments_prev_year

  ,on_time_renewal_curr
  ,LAG(on_time_renewal_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) on_time_renewal_prev_qtr
  ,LAG(on_time_renewal_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) on_time_renewal_prev_year

  ,smart_commit_curr
  ,LAG(smart_commit_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) smart_commit_prev_qtr
  ,LAG(smart_commit_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) smart_commit_prev_year

  ,total_curr
  ,LAG(total_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date) total_prev_qtr
  ,LAG(total_curr) OVER (PARTITION BY business_unit,opportunity_type,sales_subregion_level_1 ORDER BY fiscal_year_quarter_on_signed_stage_date_mod) total_prev_year

 FROM joined_data_with_all_combination_of_dimension 
 WHERE fiscal_year_quarter_on_signed_stage_date is not null
 )



SELECT DISTINCT
  fiscal_year_quarter_on_signed_stage_date
  ,fiscal_year_quarter_on_signed_stage_date_mod
  ,business_unit
  ,opportunity_type
  ,sales_subregion_level_1

  ,multi_year_commit_curr
  ,multi_year_commit_prev_qtr
  ,multi_year_commit_prev_year

  ,learning_attached_curr
  ,learning_attached_prev_qtr
  ,learning_attached_prev_year

  ,upfront_payments_curr
  ,upfront_payments_prev_qtr
  ,upfront_payments_prev_year

  ,on_time_renewal_curr
  ,on_time_renewal_prev_qtr
  ,on_time_renewal_prev_year

  ,smart_commit_curr
  ,smart_commit_prev_qtr
  ,smart_commit_prev_year

  ,total_curr
  ,total_prev_qtr
  ,total_prev_year

FROM data_with_previous_values 
"""
df_cnt=spark.sql(query_cnt)

# COMMAND ----------


# Apply cube() to aggregate the data
df_cube_cnt = df_cnt.cube(
  "business_unit"
  ,"fiscal_year_quarter_on_signed_stage_date"
  ,"sales_subregion_level_1"
  ,"opportunity_type"
)\
.agg(\
  _sum("multi_year_commit_curr").alias("multi_year_commit_curr"), 
  _sum("multi_year_commit_prev_qtr").alias("multi_year_commit_prev_qtr"),
  _sum("multi_year_commit_prev_year").alias("multi_year_commit_prev_year"),

  _sum("learning_attached_curr").alias("learning_attached_curr"), 
  _sum("learning_attached_prev_qtr").alias("learning_attached_prev_qtr"),
  _sum("learning_attached_prev_year").alias("learning_attached_prev_year"),

  _sum("upfront_payments_curr").alias("upfront_payments_curr"),
  _sum("upfront_payments_prev_qtr").alias("upfront_payments_prev_qtr"),
  _sum("upfront_payments_prev_year").alias("upfront_payments_prev_year"),

  _sum("on_time_renewal_curr").alias("on_time_renewal_curr"),
  _sum("on_time_renewal_prev_qtr").alias("on_time_renewal_prev_qtr"),
  _sum("on_time_renewal_prev_year").alias("on_time_renewal_prev_year"), 

  _sum("smart_commit_curr").alias("smart_commit_curr"),
  _sum("smart_commit_prev_qtr").alias("smart_commit_prev_qtr"),
  _sum("smart_commit_prev_year").alias("smart_commit_prev_year"), 

  _sum("total_curr").alias("total_curr"),
  _sum("total_prev_qtr").alias("total_prev_qtr"),
  _sum("total_prev_year").alias("total_prev_year"))

  

df_cube_transformed_cnt=\
df_cube_cnt\
  .filter("fiscal_year_quarter_on_signed_stage_date is not null")\
  .withColumn("group_value",lit(1))\
  .withColumn("processDate", F.current_timestamp())\
  .na.fill('All')

# COMMAND ----------

df_transformed_union=df_cube_transformed_amt.union(df_cube_transformed_cnt)
write_delta_table(
  spark, 
  dataframe =df_transformed_union , 
  table_name=f'{focus_database_name}.smart_commits_fy_agg_cube'
)