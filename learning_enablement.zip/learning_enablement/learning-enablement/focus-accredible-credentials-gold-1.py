# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

from pyspark.sql import DataFrame, Column
from typing import Optional, Sequence as Seq, Dict, Callable, Any

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC ######Env & Parameter Unit Tests
# MAGIC
# MAGIC **Code below has wrong indentation when uncommented**

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Define tables  (examples included below with comments; adjust as necessary)

# COMMAND ----------

#SFDC Tables

sfdc_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.account",  "processDate")

sfdc_accounts = (
  spark.read.table("main.sfdc_bronze.account")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

# Docebo Logfood data
silver_docebo_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_salesforce_account_email_domain_mapping",  "processDate")

salesforce_account_email_domain_mapping = (
  spark.read.table("main.it_training_silver.docebo_salesforce_account_email_domain_mapping")
    .filter(~F.col("account_name").isin('Individual LMS Account', 'Individual LMS Account(Generic)'))
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

gold_docebo_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.docebo_users_test",  "processDate")

docebo_users = (
  spark.read.table(f"{focus_database_name}.docebo_users_test")
    .filter(F.col("processDate") == gold_docebo_latest_process_date)
    .drop("processDate")
)

# Blacklisted domains

blacklist_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.blacklist_domains",  "processDate")


blacklist_domains = (
  spark.read.table(f"{focus_database_name}.blacklist_domains")
    .filter(F.col("processDate") == blacklist_latest_process_date)
)

blacklist = [domain["blacklist_domain"] for domain in blacklist_domains.collect()]

# Partner Domains

partner_domains_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.partner_domains_accounts",  "processDate")

partner_domains_df = (
  spark.read.table(f"{focus_database_name}.partner_domains_accounts")
    .filter(F.col("processDate") == partner_domains_latest_process_date)
    # .filter(F.col("email_domain") != "microsoft.com")
    .drop("processDate")
)

partner_domains = [domain["email_domain"] for domain in partner_domains_df.collect()]

# Accredible Data

silver_accredible_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.accredible_credentials",  "processDate")

credentials = (
  spark.read.table(f"main.it_training_silver.accredible_credentials")
    .filter(F.col("processDate") == silver_accredible_latest_process_date)
    .drop("processDate", "branch_code")
)

databricks_account_id = "0016100001FyvmIAAR"

microsoft_account_id = "00161000005eOdjAAE"
microsoft_account_name = "Microsoft"
microsoft_parent_account_id = "0014N00002BAYhLQAX"
microsoft_parent_account_name = "Microsoft Consulting Services"

# COMMAND ----------

#unit tests to make sure dfs are pulled correctly
assert unit_test_df_count(sfdc_accounts) > 0

# unit tests to make sure parameters are set up correctly
catalog, database = focus_database_name.split('.')
assert unit_test_valid_db(database, spark, catalog)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# unique mappings all accounts

account_window = W.Window.partitionBy("account_name").orderBy(F.desc("total_for_email_and_account"), "tiebreak")
domain_window = W.Window.partitionBy("email_domain_final").orderBy(F.desc("total_emails"), "tiebreak")

accounts_df = (
  sfdc_accounts
    .select(
      F.col("Id").alias("ultimate_parent_account_id"),
      F.col("Name").alias("ultimate_parent_account_name")
    )
)

account_names = (
  sfdc_accounts
    .select(
      F.col("Id").alias("account_id"),
      F.col("Name").alias("account_name"),
      F.col("ParentId").alias("ultimate_parent_account_id")
    )
    .join(accounts_df, "ultimate_parent_account_id", "left")
)

# mapping_2_all = (
#  salesforce_account_email_domain_mapping
#     # remove any accounts without email domains
#     .filter(F.col("email_domain").isNotNull())
#     # keep domains that appear more than 5 times 
#     .filter(F.col("total_for_email_and_account") >= 5)
#     # rank to find most common email domain per account
#     .groupBy(["email_domain", "account_id"])
#     .agg(F.sum("total_for_email_and_account").alias("total_emails"))
#     # rank to find most common domain for each account
#     .withColumn("tiebreak", F.monotonically_increasing_id())
#     .withColumn("rank", F.rank().over(domain_window))
#     .filter(F.col("rank") == 1)
#     .drop("total_emails", "tiebreak", "rank")
#     .join(account_names, "account_id", "left")
#     .select(
#       F.col("email_domain").alias("email_domain_final"), 
#       F.col("account_id"),
#       F.col("account_name"),
#       F.col("ultimate_parent_account_id"),
#       F.col("ultimate_parent_account_name"),
#     )
# )

mapping_2_all = (
  docebo_users
    .withColumn('email_domain_final', 
                F.when((F.col('email_domain').isin(blacklist)) & (~F.col('alternate_email_domain').isin(blacklist)), F.col('alternate_email_domain')).otherwise(F.col('email_domain')))
    .filter(F.col("account_name") != "Unknown")
    # .select('account_id', 'account_name', "email_domain_final", 'email_domain', 'alternate_email_domain')
    .filter(~F.col("email_domain_final").isin(blacklist))
    .groupBy(['account_id', "email_domain_final"]).agg(F.count(F.col('email_domain')).alias('total_emails'))
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(domain_window))
    .filter(F.col("rank") == 1)
    .drop("total_emails", "tiebreak", "rank")
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
    
)

mapping_2_databricks = (
  salesforce_account_email_domain_mapping  
    .filter(F.col("account_id") == databricks_account_id)
    .filter(F.col("email_domain") == "databricks.com")
    .orderBy(F.col("account_last_modified_timestamp").desc())
    .limit(1)
    .select("email_domain", "account_id")
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

# COMMAND ----------

email_window = W.Window.partitionBy("email_hash").orderBy(F.desc("last_updated_timestamp"), "tiebreak")
alt_email_window = W.Window.partitionBy("alternate_email_hash").orderBy(F.desc("last_updated_timestamp"), "tiebreak")


docebo_emails_accounts = (
  docebo_users
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(email_window))
    .filter(F.col("rank") == 1)
    .select(
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("branch_code"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

docebo_alt_emails_accounts = (
  docebo_users
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(alt_email_window))
    .filter(F.col("rank") == 1)
    .select(
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("branch_code"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

credentials_prim_accounts = (
  credentials
    .join(docebo_emails_accounts, credentials.learner_email_hash == docebo_emails_accounts.email_hash, "left")
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
      F.col("learner_name"),
      F.col("email").alias("learner_primary_email_check"),
      F.col("email_hash").alias("learner_primary_email_hash_check"),
      F.col("email_domain").alias("learner_primary_email_domain_check"),
      F.col("alternate_email").alias("learner_alternate_email_check"),
      F.col("alternate_email_hash").alias("learner_alternate_email_hash_check"),
      F.col("alternate_email_domain").alias("learner_alternate_email_domain_check"),
      F.col("learner_id"),
      F.col("branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_email_hash"),
      F.col("learner_email"),
      F.col("learner_email_domain"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
  
)
credentials_alt_accounts = (
  credentials_prim_accounts
    .filter(F.col("account_id").isNull())
    .drop(      
      "account_id",
      "account_name",
      "ultimate_parent_account_id",
      "ultimate_parent_account_name",
      "learner_primary_email_check",
      "learner_primary_email_hash_check",
      "learner_primary_email_domain_check",
      "learner_alternate_email_check",
      "learner_alternate_email_hash_check",
      "learner_alternate_email_domain_check",
      "branch_code",
      "country_code",
      "country_name",
      "region",
      "audience",
      "match_method"
     )
    .join(docebo_alt_emails_accounts, credentials_prim_accounts.learner_email_hash == docebo_alt_emails_accounts.alternate_email_hash, "left")
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
      F.col("learner_name"),
      F.col("email").alias("learner_primary_email_check"),
      F.col("email_hash").alias("learner_primary_email_hash_check"),
      F.col("email_domain").alias("learner_primary_email_domain_check"),
      F.col("alternate_email").alias("learner_alternate_email_check"),
      F.col("alternate_email_hash").alias("learner_alternate_email_hash_check"),
      F.col("alternate_email_domain").alias("learner_alternate_email_domain_check"),
      F.col("learner_id"),
      F.col("branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_email_hash"),
      F.col("learner_email"),
      F.col("learner_email_domain"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

credentials_accounts_matched = (
  credentials_prim_accounts
    .filter(F.col("account_id").isNotNull())
)

credentials_accounts = (
  credentials_accounts_matched
    .union(credentials_alt_accounts)
    .withColumn("learner_alternate_email_hash", 
                F.when(F.col("learner_email_hash") == F.col("learner_primary_email_hash_check"), F.col("learner_alternate_email_hash_check"))
                 .when(F.col("learner_email_hash") == F.col("learner_alternate_email_hash_check"), F.col("learner_primary_email_hash_check"))
             )
    .withColumn("learner_alternate_email", 
                F.when(F.col("learner_email") == F.col("learner_primary_email_check"), F.col("learner_alternate_email_check"))
                 .when(F.col("learner_email") == F.col("learner_alternate_email_check"), F.col("learner_primary_email_check"))
             )
    .withColumn("learner_alternate_email_domain", 
                F.when(F.col("learner_email_domain") == F.col("learner_primary_email_domain_check"), F.col("learner_alternate_email_domain_check"))
                 .when(F.col("learner_email_domain") == F.col("learner_alternate_email_domain_check"), F.col("learner_primary_email_domain_check"))
             )
    .select(
        F.col("approve"),
        F.col("complete"),
        F.col("credential_id"),
        F.col("credential_name"),
        F.col("expired_on"),
        F.col("is_expired"),
        F.col("group_id"),
        F.col("group_name"),
        F.col("issued_on"),
        F.col("learner_name"),
        F.col("learner_email"),
        F.col("learner_email_hash"),
        F.col("learner_email_domain"),
        F.col("learner_alternate_email"),
        F.col("learner_alternate_email_hash"),
        F.col("learner_alternate_email_domain"),
        F.col("learner_id"),
        F.col("branch_code"),
        F.col("account_id"),
        F.col("account_name"),
        F.col("ultimate_parent_account_id"),
        F.col("ultimate_parent_account_name"),
        F.col("learner_email_hash"),
        F.col("learner_email"),
        F.col("country_code"),
        F.col("country_name"),
        F.col("region"),
        F.col("audience"),
        F.col("match_method")
      )
      .withColumn("learner_email_domain_final", 
        F.when(~F.col("learner_email_domain").isin(blacklist), F.col("learner_email_domain"))
        .when(F.col("learner_email_domain").isin(blacklist) & ~F.col("learner_alternate_email_domain").isin(blacklist), F.col("learner_alternate_email_domain"))
        .otherwise(None)
      )
)

assert unit_test_df_count(credentials_accounts) == unit_test_df_count(credentials)

# COMMAND ----------

# display(
#   credentials_prim_accounts
#     .filter(F.col("credential_id") == "93913470")
# )

# COMMAND ----------

credentials_rematched = (
  credentials_accounts
    # .filter((F.col("account_name").isNull()) | (F.col("account_name") == "Unknown"))
    .filter(F.col("account_id").isNull())
    .drop(      
      "account_id",
      "account_name",
      "ultimate_parent_account_id",
      "ultimate_parent_account_name",
      "match_method"
     )
    .join(mapping_2_all, credentials_accounts.learner_email_domain_final == mapping_2_all.email_domain_final, "left")
    .withColumn('match_method', F.lit('docebo_users_mapping'))
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

credentials_matched = (
  credentials_accounts
    .filter(F.col("account_id").isNotNull())
    # .filter((F.col("account_name").isNotNull()) | (F.col("account_name") != "Unknown"))
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

all_credentials = (
  credentials_matched
    .union(credentials_rematched)
)

assert unit_test_df_count(all_credentials) == unit_test_df_count(credentials)

credentials_databricks = (
  all_credentials
    .filter(F.col("learner_email_domain") == "databricks.com")
    .drop(      
      "account_id",
      "account_name",
      "ultimate_parent_account_id",
      "ultimate_parent_account_name",
      "match_method"
     )
    .join(mapping_2_databricks, all_credentials.learner_email_domain == mapping_2_databricks.email_domain_final, "left")
    .withColumn('match_method', F.lit('hard_code_databricks'))
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("branch_code").alias("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)



credentials_not_databricks = (
  all_credentials
    .filter((F.col("learner_email_domain") != "databricks.com") | (F.col("learner_email_domain").isNull()))
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("branch_code").alias("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)


credentials_accounts_mappings = (
  credentials_databricks
    .union(credentials_not_databricks)
)


assert unit_test_df_count(credentials_accounts_mappings) == unit_test_df_count(credentials)

# COMMAND ----------

credentials_accounts_mappings_clean = (
  credentials_accounts_mappings
    .withColumnRenamed('ultimate_parent_account_id','ultimate_parent_account_id_raw')
    .withColumnRenamed('ultimate_parent_account_name','ultimate_parent_account_name_raw')
    .withColumn('ultimate_parent_account_id', F.coalesce('ultimate_parent_account_id_raw', 'account_id'))
    .withColumn('ultimate_parent_account_name', F.coalesce('ultimate_parent_account_name_raw', 'account_name'))
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

# assert unit_test_df_count(credentials_accounts_mappings_clean) == unit_test_df_count(credentials)

# COMMAND ----------

credentials_accounts_mappings_clean_2 = (
  credentials_accounts_mappings_clean
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", F.when((F.col("account_name") == "Unknown") | (F.col("account_id_pre").isNull()), F.lit("Unknown")).otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", F.when(F.col("account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", F.when(F.col("ultimate_parent_account_id_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", F.when(F.col("ultimate_parent_account_name_pre").isNull(), F.lit("Unknown")).otherwise(F.col("ultimate_parent_account_name_pre")))
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

# COMMAND ----------

customer_domains = partner_domains+['microsoft.com']+['databricks.com']

credentials_accounts_mappings_clean_audience = (
  credentials_accounts_mappings_clean_2
  .filter(F.col("audience").isNotNull())
  .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

credentials_accounts_mappings_clean_no_audience = (
  credentials_accounts_mappings_clean_2
  .filter(F.col("audience").isNull())
  .withColumn('learner_email_domain_pre', 
              F.when(F.col('learner_email_domain').isin(partner_domains), F.col('learner_email_domain'))
              .when(F.col('learner_alternate_email_domain').isin(partner_domains), F.col('learner_alternate_email_domain'))
              .when((F.col('learner_email_domain').isin(blacklist)) & (~F.col('learner_alternate_email_domain').isin(blacklist)), F.col('learner_alternate_email_domain'))
              .otherwise(F.col('learner_email_domain')))
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when((F.col('learner_email_domain_pre').isin(partner_domains)) & (F.col("account_name") == "Unknown"), "Partner Other")
                .when((F.col('learner_email_domain_pre').isin(partner_domains)) & (F.col("account_name") != "Unknown"), "Partner")
                .when((F.col('learner_email_domain_pre') == 'microsoft.com') & (F.col("account_name") == "Unknown"), "Microsoft Other")
                .when((F.col('learner_email_domain_pre') == 'microsoft.com') & (F.col("account_name") != "Unknown"), "Microsoft")
                .when((F.col('learner_email_domain_pre') == 'databricks.com') & (F.col("account_name") == "Unknown"), "Employee Other")
                .when((F.col('learner_email_domain_pre') == 'databricks.com') & (F.col("account_name") != "Unknown"), "Employee")
                .when((~F.col('learner_email_domain_pre').isin(customer_domains)) & (F.col("account_name") == "Unknown"), "Customer Other")
                .when((~F.col('learner_email_domain_pre').isin(customer_domains)) & (F.col("account_name") != "Unknown"), "Customer")
    )
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
)

credentials_accounts_mappings_clean_final = (
  credentials_accounts_mappings_clean_audience
    .union(credentials_accounts_mappings_clean_no_audience)
)

# COMMAND ----------

credentials_accounts_mappings_clean_final_audience = (
  credentials_accounts_mappings_clean_final
    .withColumnRenamed("audience", "audience_pre")
    .withColumn("audience", 
                F.when((F.col("audience_pre") == "Customer Other") & (F.col("learner_branch_code") == "DBK_PRTNR"), F.lit("Partner Other"))
                .when((F.col("audience_pre") == "Customer Other") & (F.col("learner_branch_code") == "DBK_EMP"), F.lit("Employee Other"))
                .when((F.col("audience_pre") == "Customer Other") & (F.col("learner_branch_code") == "DBK_MCSFT"), F.lit("Microsoft Other"))
                .when((F.col("audience_pre") == "Customer Other") & (F.col("learner_branch_code").isNull()), F.lit("Other"))
                .when((F.col("audience_pre") == "Partner Other") & (F.col("learner_branch_code").isNull()), F.lit("Other"))
                .otherwise(F.col("audience_pre")))
    .withColumnRenamed('match_method', 'match_method_check')
    .withColumn('match_method', F.when(F.col('account_name') == "Unknown", F.lit('no_match')).otherwise(F.col('match_method_check')))
    .select(
      F.col("approve"),
      F.col("complete"),
      F.col("credential_id"),
      F.col("credential_name"),
      F.col("expired_on"),
      F.col("is_expired"),
      F.col("group_id"),
      F.col("group_name"),
      F.col("issued_on"),
#       F.col("learner_name"),
#       F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
#       F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_id"),
      F.col("learner_branch_code"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("audience"),
      F.col("match_method")
    )
    
)

# COMMAND ----------

docebo_users_accounts_audience_msft_fix = (
  credentials_accounts_mappings_clean_final_audience
    .withColumnRenamed("account_id", "account_id_pre")
    .withColumn("account_id", 
        F.when((F.col("audience").like("%Microsoft%")), F.lit(microsoft_account_id))
          .otherwise(F.col("account_id_pre")))
    .withColumnRenamed("account_name", "account_name_pre")
    .withColumn("account_name", 
        F.when(F.col("audience").like("%Microsoft%"), F.lit(microsoft_account_name))
          .otherwise(F.col("account_name_pre")))
    .withColumnRenamed("ultimate_parent_account_id", "ultimate_parent_account_id_pre")
    .withColumn("ultimate_parent_account_id", 
        F.when(F.col("audience").like("%Microsoft%"), F.lit(microsoft_parent_account_id))
          .otherwise(F.col("ultimate_parent_account_id_pre")))
    .withColumnRenamed("ultimate_parent_account_name", "ultimate_parent_account_name_pre")
    .withColumn("ultimate_parent_account_name", 
        F.when(F.col("audience").like("%Microsoft%"), F.lit(microsoft_parent_account_name))
          .otherwise(F.col("ultimate_parent_account_name_pre")))
    .drop("account_id_pre", "account_name_pre", "ultimate_parent_account_id_pre", "ultimate_parent_account_name_pre")
)

# COMMAND ----------

# display(
#   docebo_users_accounts_audience_msft_fix
#     .filter(F.col("credential_id") == "79081860")
# )

# COMMAND ----------

credentials_accounts_mappings_clean_partition = add_gold_metadata(docebo_users_accounts_audience_msft_fix)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = credentials_accounts_mappings_clean_partition, 
  table_name = f'{focus_database_name}.accredible_credentials_test', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)