# Databricks notebook source
focus_database_name='main.field_learning_enablement'

# COMMAND ----------

# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

workbook_id='1mCEwRed8bc6vDQEmZg8TOSxyRuAo5b68zIcNTcfQnsw'
sheet_id='1771568511'

# COMMAND ----------

read_google_sheet(workbook_id=workbook_id,sheet_id=sheet_id,cell_range="A2:I250").createOrReplaceTempView('sales_badges')

# COMMAND ----------

query_final_table=spark.sql("select * from sales_badges")

# COMMAND ----------

write_instructions = (
        query_final_table.write.format("delta")
        .mode("overwrite")
        .option("overwriteSchema", True)
        .option("mergeSchema", True)
    )


write_instructions.saveAsTable('main.field_learning_enablement.sales_badges_final')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.field_learning_enablement.sales_badges_final limit 6

# COMMAND ----------

workbook_id='1mCEwRed8bc6vDQEmZg8TOSxyRuAo5b68zIcNTcfQnsw'
sheet_id='639657290'

# COMMAND ----------

read_google_sheet(workbook_id=workbook_id,sheet_id=sheet_id,cell_range="A2:I250").createOrReplaceTempView('brickbites_sheet')

# COMMAND ----------

query_final_table_brickbites=spark.sql("select * from brickbites_sheet")

# COMMAND ----------

from pyspark.sql.functions import col
from collections import Counter
import re

def clean_colname(name):
    name = name.strip()
    name = re.sub(r"[ \-/]+", "_", name)       
    name = re.sub(r"[^0-9a-zA-Z_]", "", name)  
    return name

cleaned_cols = [clean_colname(c) for c in query_final_table_brickbites.columns]
query_final_table_brickbites = query_final_table_brickbites.toDF(*cleaned_cols)

cols = query_final_table_brickbites.columns
col_counts = Counter(cols)
new_cols = []
seen = {}

for c in cols:
    if col_counts[c] > 1:
        seen[c] = seen.get(c, 0) + 1
        new_cols.append(f"{c}_{seen[c]}")
    else:
        new_cols.append(c)

if len(set(cols)) != len(cols):
    query_final_table_brickbites = query_final_table_brickbites.toDF(*new_cols)

desired_colnames = [
    "Credential_Name",
    "Accredible_Group_ID",
    "Active",
    "Internal_Label_How_it_shows_up_in_Partner_Academy",
    "Strategic_Priority",
    "Reinforcement_Category",
    "Learning_Path",
    "Link_to_Partner_Academy",
    "Course_ID"
]

current_colnames = query_final_table_brickbites.columns

if len(current_colnames) != len(desired_colnames):
    raise ValueError(
        f"Column count mismatch: {len(current_colnames)} current vs {len(desired_colnames)} desired"
    )

for old_col, new_col in zip(current_colnames, desired_colnames):
    query_final_table_brickbites = query_final_table_brickbites.withColumnRenamed(old_col, new_col)

write_instructions = (
    query_final_table_brickbites.write.format("delta")
    .mode("overwrite")
    .option("overwriteSchema", True)
    .option("mergeSchema", True)
)

write_instructions.saveAsTable("main.field_learning_enablement.sales_badges_brickbites_lookup")
