# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             L300 Reporting \
# MAGIC **Description:**     This notebook gives the data for the L300 Requirements Completion \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Users/nathan.zukoff@databricks.com/Reporting/Docebo/Docebo Functions"

# COMMAND ----------

# MAGIC %run "/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import *
import requests
import json
from urllib.parse import quote_plus as urlencode
from datetime import date

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md
# MAGIC 1. Check the __L200__ is completed or not (done)
# MAGIC 2. Check the __first_major__ (done) (many people have not selected the first_major)
# MAGIC 3. Check the __specialisation__ (done) (many people have not selected the first_major)
# MAGIC 4. Check the __certification__ is completed or not (in progress) (all certifications are not available at the moment)
# MAGIC 5. Check if the __Selling and Winning__ courses are completed or not (not started) (all selling winning courses will be completed by 29th)
# MAGIC 6. Check if they have submitted their __assignments__ (in progress) (getting the data from the reports)
# MAGIC 7. Check if their __checklists__ have been evaluated and approved/rejected or not (not started) (the checklist data will be available from Brian's tables)
# MAGIC 8. Check if they have completed their assigned __TechSpecTalks__ (in progress) 

# COMMAND ----------

# DBTITLE 1,Get Assignments Data
# l300_report_id = '812e451f-2109-4833-bdcc-db7d720cfe28'

# learner_assignment_data = getNewReportData(l300_report_id)

# assignments = []
# for learner in learner_assignment_data:
#   assignments.append({
#     "status": learner["Training Material Status"],
#     "score": learner["Training Material Score"],
#     "course_code": learner["Course code"],
#     "l300_step": learner["Training Material Title"].split(":")[0],
#     "title": learner["Training Material Title"].split(":")[1],
#     "email": learner["Email"].lower(),
#     "firstname": learner["First Name"],
#     "lastname": learner["Last Name"],
#     "username": learner["Username"].lower(),
#     "user_id": learner["User unique ID"]
#   })
# # display(assignments)
# l300_assignments_df = convertToDF(assignments)

# COMMAND ----------

# DBTITLE 1,Assignments DataFrame Temp View
# l300_assignments_df = sqlContext.createDataFrame(assignments, l300_assignments_schema)
# l300_assignments_df.createOrReplaceTempView('l300_assignments')


# COMMAND ----------

volume_path = "/Volumes/users/nathan_zukoff/docebo_data/"
csv_name = "L300_Assignments.csv"

# COMMAND ----------

l300_report_id = '812e451f-2109-4833-bdcc-db7d720cfe28'
l300_data_raw = getNewReportData_v2(l300_report_id, volume_path, csv_name)

# COMMAND ----------

display(l300_data_raw)

# COMMAND ----------

l300_data_raw.createOrReplaceTempView('l300_assignments_raw')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create or replace temp view l300_assignments as 
# MAGIC   select 
# MAGIC     `Training Material Status` as status,
# MAGIC     case 
# MAGIC       when `Training Material Score` = 'NaN' then null else `Training Material Score` end as score,
# MAGIC     `Course code` as course_code,
# MAGIC     split(`Training Material Title`, ":")[0] as l300_step,
# MAGIC     split(`Training Material Title`, ":")[1] as title,
# MAGIC     lower(`Email`) as email,
# MAGIC     `First Name` as firstname,
# MAGIC     `Last Name` as lastname,
# MAGIC     lower(`Username`) as username,
# MAGIC     `User unique ID` as user_id
# MAGIC   from l300_assignments_raw

# COMMAND ----------

# %sql
# -- select * from l300_assignments where score >= 0

# COMMAND ----------

emails_to_be_grandfathered = [
  {'specialization_major': 'Data Governance', 'primaryWorkEmail': 'gopala.raju@databricks.com'},
  {'specialization_major': 'Data Governance', 'primaryWorkEmail': 'liran.bareket@databricks.com'},
  {'specialization_major': 'Data Governance', 'primaryWorkEmail': 'lars.george@databricks.com'},
  {'specialization_major': 'Data Governance', 'primaryWorkEmail': 'douglas.moore@databricks.com'},
  {'specialization_major': 'Data Governance', 'primaryWorkEmail': 'ziyuan.qin@databricks.com'},
  {'specialization_major': 'Data Governance', 'primaryWorkEmail': 'dipankar.kushari@databricks.com'},
  {'specialization_major': 'Cloud Infrastructure & Security', 'primaryWorkEmail': 'gregory.wood@databricks.com'},
  {'specialization_major': 'Cloud Infrastructure & Security', 'primaryWorkEmail': 'bhavin.kukadia@databricks.com'},
  {'specialization_major': 'Cloud Infrastructure & Security', 'primaryWorkEmail': 'ganesh.rajagopal@databricks.com'},
  {'specialization_major': 'Cloud Infrastructure & Security', 'primaryWorkEmail': 'bruce.nelson@databricks.com'},
  {'specialization_major': 'Cloud Infrastructure & Security', 'primaryWorkEmail': 'mubashir.kazia@databricks.com'},
  {'specialization_major': 'Cloud Infrastructure & Security', 'primaryWorkEmail': 'andrew.weaver@databricks.com'},
  {'specialization_major': 'Cloud Infrastructure & Security', 'primaryWorkEmail': 'hari.selvarajan@databricks.com'},
  {'specialization_major': 'Cloud Infrastructure & Security', 'primaryWorkEmail': 'leo.mao@databricks.com'},
  {'specialization_major': 'Data Warehousing', 'primaryWorkEmail': 'franco.patano@databricks.com'},
  {'specialization_major': 'Data Warehousing', 'primaryWorkEmail': 'alan.choi@databricks.com'},
  {'specialization_major': 'Data Warehousing', 'primaryWorkEmail': 'scott.black@databricks.com'},
  {'specialization_major': 'Data Warehousing', 'primaryWorkEmail': 'shannon.barrow@databricks.com'},
  {'specialization_major': 'Data Warehousing', 'primaryWorkEmail': 'bilal.obeidat@databricks.com'},
  {'specialization_major': 'Data Warehousing', 'primaryWorkEmail': 'will.girten@databricks.com'},
  {'specialization_major': 'Data Warehousing', 'primaryWorkEmail': 'michael.okane@databricks.com'},
  {'specialization_major': 'Data Warehousing', 'primaryWorkEmail': 'andrey.mirskiy@databricks.com'},
  {'specialization_major': 'Data Warehousing', 'primaryWorkEmail': 'abhishek.dey@databricks.com'},
  {'specialization_major': 'Data Warehousing', 'primaryWorkEmail': 'leo.mao@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'joseph@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'rafi.kurlansik@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'tim.lortz@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'marshall.carter@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'layla.yang@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'sri.ghattamaneni@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'cara.phillips@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'peyman@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'tristen.wentling@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'Michael.Shtelma@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'jeanne.choo@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'maria.zervou@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'puneet.jain@databricks.com'},
  {'specialization_major': 'Data Science & ML', 'primaryWorkEmail': 'daniel.sparing@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'sajith.appukuttan@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'ricardo.portilla@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'daniel.tomes@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'steven.yu@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'joe.widen@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'ravi.gawai@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'ganesh@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'viren.patel@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'mike.cornell@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'angela.chu@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'josh.seidel@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'matt.slack@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'avnish.jain@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'shasidhar.eranti@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'prashanth.babu@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'alexey.ott@databricks.com'},
  {'specialization_major': 'Data Engineering', 'primaryWorkEmail': 'daniel.haviv@databricks.com'}
]

rows = [Row(**entry) for entry in emails_to_be_grandfathered]
emails_to_be_grandfathered_df = spark.createDataFrame(rows)
emails_to_be_grandfathered_df.createOrReplaceTempView('emails_to_be_grandfathered')

# COMMAND ----------

# DBTITLE 1,Gather all data and create df
l300_data_df = spark.sql(
"""
with workday as (
  select
    *
  from
    main.field_learning_enablement.workday
  where
    processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.workday
    )
    and Worker_Type = 'Employee'
    and status = 'true' --and (nvl(name, "Unknown") not in (select distinct manager from main.field_learning_enablement.workday wd where wd.Worker_Type='Employee'and wd.status = 'true' and wd.processDate = (select max(processDate) from main.field_learning_enablement.workday)) or primaryWorkEmail = 'pritesh.patel@databricks.com')
    and manager_hierarchy_path_name ilike any (
      '%jeff traylor%',
      '%david hackett%',
      '%jason martin%',
      '%toby balfre%',
      '%nicholas eayrs%',
      '%david totten%'
    )
    and manager_hierarchy_path_name not ilike ('%victor cheah%')
),
sfdc_users_rank as (
  select
    rank() over (
      partition by email
      order by
        CreatedDate desc
    ) as rank,
    * -- from main.sfdc_bronze.user
  from
    main.sfdc_bronze.user -- where processdate = (select max(processdate) from main.sfdc_bronze.user)
  where
    processdate = (
      select
        max(processdate)
      from
        main.sfdc_bronze.user
    )
),
sfdc_users as (
  select
    *
  from
    sfdc_users_rank
  where
    rank = 1
),
--l300_specialization_declarations as (
--  select primary_technical_specialization, field_engineering_user_email from l300_specialisations
--)
--,
users as (
  select
    w.* except(job_role),
    case
      when w.Job_Profile_Start_Date >= '2024-05-01'
      and w.tenure_in_months <= 3
      and w.Job_Profile in (
        'Resident Solutions Architect',
        'Specialist Solutions Architect',
        'Sr. Specialist Solutions Architect',
        'Sr. Resident Solutions Architect'
      ) then 9
      when w.Job_Profile_Start_Date >= '2024-05-01'
      and w.tenure_in_months <= 3 then 12
      else 9
    end as required_months_to_complete,
    case
      when w.Job_Profile in (
        'Resident Solutions Architect',
        'Sr. Resident Solutions Architect'
      ) then 'RSA'
      when w.Job_Profile in (
        'Specialist Solutions Architect',
        'Sr. Specialist Solutions Architect',
        'Lead Specialist Solutions Architect',
        'Principal Specialist Solutions Architect'
      ) then 'SSA'
      when w.Job_Profile in (
        'Delivery Solutions Architect',
        'Lead Delivery Solutions Architect',
        'Sr. Delivery Solutions Architect'
      ) then 'DSA'
      when w.Job_Profile in (
        'Solutions Architect',
        'Sr. Solutions Architect',
        'Lead Solutions Architect',
        'Principal Solutions Architect'
      ) then 'SA'
      else 'Other'
    end as job_role,
    case
      when w.Job_Profile_Start_Date >= '2024-05-01'
      and w.tenure_in_months <= 3 then 'New Hire'
      else 'Tenured Employee'
    end as tenure_status -- primary_technical_specialization
  from
    workday w
    left join sfdc_users u on w.primaryWorkEmail = u.email
    left join main.sfdc_bronze.field_engineering_users__c f on f.Field_Engineering_User__c = u.id
    and f.processdate = (
      select
        max(processdate)
      from
        main.sfdc_bronze.field_engineering_users__c
    ) -- left join l300_specialization_declarations d on w.primaryWorkEmail = d.field_engineering_user_email
  where
    w.job_profile in (
      'Solutions Architect',
      'Resident Solutions Architect',
      'Sr. Solutions Architect',
      'Delivery Solutions Architect',
      'Specialist Solutions Architect',
      'Lead Solutions Architect',
      'Lead Delivery Solutions Architect',
      'Principal Solutions Architect',
      'Lead Specialist Solutions Architect',
      'Sr. Delivery Solutions Architect',
      'Sr. Specialist Solutions Architect',
      'Principal Specialist Solutions Architect',
      'Sr. Resident Solutions Architect'
    )
    or w.primaryWorkEmail in (
      select distinct primaryWorkEmail from emails_to_be_grandfathered
    )
),
l300_certifications as (
  -- 2 certifications will be added in the future
  select
    primaryWorkEmail,
    credential_name,
    credential_id,
    complete,
    is_expired,
    issued_on
  from
    main.field_learning_enablement.certifications_and_badges
  where
    processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.certifications_and_badges
    )
    and (
      credential_name = "Databricks Certified Data Engineer Professional"
      or credential_name = "Databricks Certified Machine Learning Professional"
    )
    and primaryWorkEmail in (
      select
        primaryWorkEmail
      from
        users
    )
),
l200_cis_enablement_course as (
    select
    learner_email,
    enrolled_timestamp,
    completed_timestamp,
    status,
    course_name,
    course_code,
    course_id
  from
    main.field_learning_enablement.self_paced_enrollments
  where
    processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.self_paced_enrollments
    )
    and course_name = 'L200 Cloud Infrastructure & Security FE Enablement'
  ),
  l300_cis_lp_completion as ( 
    with lp_enrollments as (
        select * 
        from main.it_training_silver.docebo_learning_plan_enrollments e
        -- inner join users.ravi_gangumalla.sql_dates d on e.assigned_timestamp::date=d.date
        where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_enrollments)
        and learner_branch_code = 'DBK_EMP'
      )

      ,
    learning_plans as (
        select
          id as learning_plan_id,
          name as learning_plan_name,
          code as learning_plan_code,
          total_courses
        from main.it_training_silver.docebo_learning_plans 
        where processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plans)
        and code = 'FENG-TECHALL-SLP-L300CIS-V1'
    ),
      learning_plan_courses as (
        select 
          path_id,
          course_id,
          course_name,
          course_code
        from main.it_training_silver.docebo_learning_plan_courses e
        where e.processdate= (select max(processdate) from main.it_training_silver.docebo_learning_plan_courses)
      ),
      self_paced_enrollments as (
        select distinct
          course_id,
          course_name,
          learner_user_id,
          status as enrollment_status, 
          completed_timestamp
        from main.field_learning_enablement.self_paced_enrollments e
        where e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
        and learner_branch_code = 'DBK_EMP'
      )

      ,
      ilt_enrollments as (
        select distinct
          course_id,
          course_name,
          learner_user_id,
          status as enrollment_status, 
          completed_timestamp
        from main.field_learning_enablement.ilt_enrollments e
        where e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
        and learner_branch_code = 'DBK_EMP'
      )
      ,
      all_enrollments as ( 
        select
          course_id,
          course_name,
          learner_user_id,
          enrollment_status, 
          completed_timestamp
        from self_paced_enrollments
        union all 
        select
          course_id,
          course_name,
          learner_user_id,
          enrollment_status, 
          completed_timestamp
        from ilt_enrollments
      )
      ,
      all_lp as (
          select 
            e.learner_user_id,
            learner_email,
            learning_path_id, 
            learning_path_name,
            learning_path_code,
            assigned_timestamp,
            c.course_id,
            c.course_name,
            c.course_code,
            nvl(enrollment_status, "Not Enrolled") as enrollment_status,
            completed_timestamp
          from lp_enrollments e
          join learning_plans l on e.learning_path_id = l.learning_plan_id
          join learning_plan_courses c on e.learning_path_id = c.path_id 
          left join all_enrollments a on c.course_id = a.course_id and e.learner_user_id = a.learner_user_id
          order by c.course_name
        )

      ,

      email_path_completed_courses as (
        select 
          learner_email,
          learning_path_id,
          count(distinct course_id) as total_courses,
          sum(case when enrollment_status="completed" then 1 else 0 end) as completed_courses,
          -- collect_list(struct(course_name, enrollment_status)) as course_enrollment_status,
          collect_list(course_name) as lp_courses, 
          collect_list(course_code) as lp_course_codes
        from all_lp
        group by learner_email, learning_path_id
        -- order by course_enrollment_status.course_name
      )
      -- ,
    --   learner_email,
    -- enrolled_timestamp,
    -- completed_timestamp,
    -- status,
    -- course_name,
    -- course_code,
    -- course_id
      -- completed_lps as (
        select distinct 
          learner_email, 
          learning_path_id,
          case 
            when completed_courses = 0 then 'Not Started' 
            when completed_courses < total_courses then 'In Progress'
            when completed_courses = total_courses then 'Completed'
          end as lp_enrollment_status
        from email_path_completed_courses
  ),
l300_cert_status as (
  -- There would be addition of Lakehouse Architecture Certification [Q2] for Data Warehousing and Data Steward Associate Certification [Q3] for Data Governance
  select
    c.*,
    case when c.primaryWorkEmail in (select distinct primaryWorkEmail from emails_to_be_grandfathered)
      then nvl(l.specialization_major, e.specialization_major)
      else l.specialization_major
    end as specialization_major,
    case
      when (l.specialization_major = "Data Engineering" or e.specialization_major = "Data Engineering")
      and c.credential_name = "Databricks Certified Data Engineer Professional" then True
      when (l.specialization_major = "Data Science & ML" or e.specialization_major = "Data Science & ML")
      and c.credential_name = "Databricks Certified Machine Learning Professional" then True
      when (l.specialization_major = "Data Warehousing" or e.specialization_major = "Data Warehousing")
      and c.credential_name = "Databricks Certified Data Engineer Professional" then True
      when (l.specialization_major = "Data Governance" or e.specialization_major = "Data Governance")
      and c.credential_name = "Databricks Certified Data Engineer Professional" then True
      when l.specialization_major = "Data Platform Architecture"
      and c.credential_name = "Databricks Certified Data Engineer Professional" then True
      when e.specialization_major = "Cloud Infrastructure & Security" then True
      when l.specialization_major = "Cloud Infrastructure & Security"
      and s.status = 'Completed' and lp.lp_enrollment_status = 'Completed' then True
      else false
    end as l300_certification_status
  from
    l300_certifications c
    left join main.field_learning_enablement.l200_reporting l on l.primaryWorkEmail = c.primaryWorkEmail
    and l.processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.l200_reporting
    )
    left join l200_cis_enablement_course s on c.primaryWorkEmail = s.learner_email
    left join l300_cis_lp_completion lp on c.primaryWorkEmail = lp.learner_email
    left join emails_to_be_grandfathered e on c.primaryWorkEmail = e.primaryWorkEmail
),
assigments_completion as (
  select
    *
  from
    (
      select
        email,
        l300_step,
        status,
        firstname,
        lastname,
        user_id
      from
        l300_assignments
    ) pivot (
      max(nvl(status, 'Not Enrolled')) for l300_step in (
        'Step 1' as assignment_step_1_enrollment,
        'Step 2' as assignment_step_2_upload_assets
        -- 'Step 3' as assignment_step_3_checklist_1,
        -- 'Step 4' as assignment_step_4_checklist_2
      )
    )
) -- There would be addition of the checklists completion and evaluation.
,
enrollments as (
  select
    learner_email,
    status,
    enrolled_timestamp,
    completed_timestamp
  from
    main.field_learning_enablement.self_paced_enrollments
  where
    processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.self_paced_enrollments
    )
    and course_id = 2446
),
selling_and_winning_courses as (
  -- Add mapping to the certifications and selling and winning courses
  select
    *,
    case
      when course_id = 2550 then 'Data Engineering'
      when course_id = 2559 then 'Data Warehousing'
      else 'others'
    end as l300_snw_requirement
  from
    main.field_learning_enablement.self_paced_enrollments
  where
    processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.self_paced_enrollments
    )
    and learner_branch_code = 'DBK_EMP'
    and course_id in (2550, 2559) -- Will add other courses when those courses are ready
)

,
techspec_data as(
  with techspec_sessions as (
    select
      *,
      case
        when contains(topic, "DBSQL")
        or contains(topic, "Google Calendar Meeting (not synced)") then "Data Warehousing"
        when contains(course_name, "SME Session - ML")
        or contains(topic, "SME Session: ML")
        or contains(course_name, 'ML SME Talk Session') then "Data Science & ML"
        when contains(topic, "Cloud Infra & Security") then "Cloud Infrastructure and Security"
        when contains(topic, "DIT SME Sync") then "Data Engineering"
      end as l300_domain
    from
      main.field_learning_enablement.techspec_summary
    where
      processDate = (
        select
          max(processDate)
        from
          main.field_learning_enablement.techspec_summary
      ) -- There would be addition of Data Governance techspec talks
  ),
  total_sessions_data as (
    select
      l300_domain,
      count(*) as total_sessions
    from
      techspec_sessions
    group by
      l300_domain
  ),
  attended_sessions_data as (
    select
      learner_user_id,
      learner_email,
      l300_domain,
      count(*) as attended_sessions
    from
      main.field_learning_enablement.techspec_all_enrollments
    where
      processDate = (
        select
          max(processDate)
        from
          main.field_learning_enablement.techspec_all_enrollments
      )
    group by
      learner_user_id,
      learner_email,
      l300_domain
  )
  select
    a.*,
    t.total_sessions
  from
    attended_sessions_data a
    left join total_sessions_data t on t.l300_domain = a.l300_domain
  order by
    a.l300_domain,
    a.attended_sessions desc
),
final as (
  select
    distinct u.*,
    nvl(l.L200, false) as l200_completed_flag, -- check the L200 status
    l.first_major, -- check the first major
    l.specialization_major, -- check the specialization major
    l.Archetypes__c as archetype,
    l.Field_Engineering_User__c,
    l.sfdc_id,
    l.fe_users_name,
    l.fe_users_id,
    l.requirement,
    nvl(l.L100, false) as l100_completed_flag, -- L100 Completion Status
    e.status as enrollment_status,
    e.enrolled_timestamp as enrolled_timestamp,
    e.completed_timestamp as completed_timestamp,
    case
      when l.specialization_major is not null then 1
      else 0
    end as first_major_selected_flag,
    case
      when l.specialization_major = "Data Engineering" then "Data Engineering"
      when l.specialization_major = "Data Science & ML" then "Data Science and Machine Learning"
      when l.specialization_major = "Data Warehousing" then "Data Warehousing"
      when l.specialization_major = "Data Governance" then "Data Governance"
      when l.specialization_major = "Data Platform Architecture" then "Data Governance"
      when l.specialization_major = "Cloud Infrastructure & Security" then "Cloud Infrastructure and Security"
    end as l300_specialisation_major,
    -- specify the domain for the L300 certification
    c.credential_name as certification_credential_name,
    c.credential_id as certification_id,
    nvl(c.complete, false) as certification_completion,
    c.is_expired as certification_expiry,
    c.issued_on as certification_issued_on,
    nvl(c.l300_certification_status, false) as l300_certification_status,
    -- check the certification status
    s.status as selling_and_winning_completion_status,
    s.completed_timestamp as selling_and_winning_completed_timestamp,
    case
      when s.status = 'completed'
      and l300_specialisation_major = s.l300_snw_requirement then 1
      else 0
    end as selling_and_winning_completion_flag,
    -- check the selling and winning completion
    attended_sessions as attended_techspec_sessions,
    total_sessions as total_techspec_sessions,
    a.* except (a.email)
    -- 1. check the L300 certification status
    -- 2. check the selling and winning course completion (add mapping)
    -- 3. check the assigment status (check the completion status from the checklist notebook)
    -- 4. check the checklist approval status (check the data from brians data)
    -- 5. check the techspec talks status (add mapping) (no need to add this flag just the data is sufficient)
    -- 6. create a flag for l300_completion_status
  from
    users u
    left join main.field_learning_enablement.l200_reporting l on l.primaryWorkEmail = u.primaryWorkEmail
    and l.processDate = (
      select
        max(processDate)
      from
        main.field_learning_enablement.l200_reporting
    )
    left join l300_cert_status c on c.primaryWorkEmail = u.primaryWorkEmail
    and l300_certification_status is True
    left join assigments_completion a on lower(a.email) = lower(u.primaryWorkEmail)
    left join selling_and_winning_courses s on u.primaryWorkEmail = s.learner_email
    left join techspec_data t on u.primaryWorkEmail = t.learner_email
    and t.l300_domain = l.specialization_major
    left join enrollments e on u.primaryWorkEmail = e.learner_email
)


select
  *,
  case
    when assignment_step_1_enrollment = 'Completed'
    and assignment_step_2_upload_assets = 'Completed'
    -- and assignment_step_3_checklist_1 = 'Completed'
    -- and assignment_step_4_checklist_2 = 'Completed' 
    then true
    else false
  end as practical_applications_completion,
  case
    when l200_completed_flag = true
    and first_major_selected_flag = true
    and l300_certification_status = true
    and assignment_step_1_enrollment = 'Completed'
    and assignment_step_2_upload_assets = 'Completed'
    -- and assignment_step_3_checklist_1 = 'Completed'
    -- and assignment_step_4_checklist_2 = 'Completed'
    and selling_and_winning_completion_flag = 1 then true
    when f.primaryWorkEmail in (
      select primaryWorkEmail from emails_to_be_grandfathered
    ) and l300_certification_status = true then true
    else false
  end as L300_completion_status -- Need to add the flags for checklist approval, which will be available after brian's table is ready.
  -- Need to add the levels data, which will be available after Liam's table has level's data
from
  final f
  -- right join emails_to_be_grandfathered e on f.primaryWorkEmail = e.primaryWorkEmail
 """
)

# COMMAND ----------

l300_data_df.createOrReplaceTempView('l300_data')

# COMMAND ----------

l300_data_df_final = spark.sql('''
  select 
    Name,
    WorkdayID,
    Worker_Type,
    primaryWorkEmail,
    Hire_Date,
    --Last_Promotion_Date,
    Termination_Date,
  --  Job_Profile_Prior_To_Last_Promotion_Date,
  --  Business_Title_Prior_To_Last_Promotion_Date,
    Cost_Center,
    Location,
    Location_Address_Country,
    Job_Profile,
    businessTitle,
    Manager_Level_01,
    Manager_Level_02,
    Manager_Level_03,
    Manager,
    Manager_Email,
    Supervisory_Organization,
    Supervisory_Organization_cleaned,
    -- Time_Zone,
    --Time_Zone_GMT_Factor,
    Status,
    Original_Hire_Date,
    Job_Profile_Start_Date,
  --  Last_Job_Req_Event_Date,
  --  wd_id,
    manager_hierarchy_path,
    manager_hierarchy_path_name,
  --  category,
  --  department,
    6th_level_manager,
    5th_level_manager,
    4th_level_manager,
    3rd_level_manager,
    2nd_level_manager,
    1st_level_manager,
    init_level_manager,
    6th_level_manager_name,
    5th_level_manager_name,
    4th_level_manager_name,
    3rd_level_manager_name,
    2nd_level_manager_name,
    1st_level_manager_name,
    init_level_manager_name,
    email_hash,
    tenure_in_months,
    processDate,
    required_months_to_complete,
    job_role,
    tenure_status,
    l200_completed_flag,
    first_major,
    specialization_major,
    archetype,
    Field_Engineering_User__c,
    sfdc_id,
    fe_users_name,
    fe_users_id,
    requirement,
    l100_completed_flag,
    enrollment_status,
    enrolled_timestamp,
    completed_timestamp,
    first_major_selected_flag,
    l300_specialisation_major,
    certification_credential_name,
    certification_id,
    certification_completion,
    certification_expiry,
    certification_issued_on,
    l300_certification_status,
    selling_and_winning_completion_status,
    selling_and_winning_completed_timestamp,
    selling_and_winning_completion_flag,
    attended_techspec_sessions,
    total_techspec_sessions,
    -- email,
    firstname,
    lastname,
    cast(user_id as STRING) as user_id,
    assignment_step_1_enrollment,
    assignment_step_2_upload_assets,
    practical_applications_completion,
    L300_completion_status
  from l300_data
''')

# COMMAND ----------

# %sql
# with l300_certifications as (
#   -- 2 certifications will be added in the future
#   select
#     primaryWorkEmail,
#     collect_list(credential_name) as credential_name,
#     collect_list(credential_id) as credential_id,
#     collect_list(complete) as complete,
#     collect_list(is_expired) as is_expired,
#     collect_list(issued_on) as issued_on
#   from
#     main.field_learning_enablement.certifications_and_badges
#     -- right join emails_to_be_grandfathered e on c.primaryWorkEmail = e.primaryWorkEmail
#   where
#     processDate = (
#       select
#         max(processDate)
#       from
#         main.field_learning_enablement.certifications_and_badges
#     )
#     and (
#       credential_name = "Databricks Certified Data Engineer Professional"
#       or credential_name = "Databricks Certified Machine Learning Professional"
#     )
#     -- and c.primaryWorkEmail in (
#     --   select
#     --     primaryWorkEmail
#     --   from
#     --     emails_to_be_grandfathered
#     -- )
#     group by primaryWorkEmail
# )
# -- ,
# -- cis_course_completion as (
# --   -- Soon there would be another course for L300 CIS Course Completion
# --   select
# --     learner_email,
# --     enrolled_timestamp,
# --     completed_timestamp,
# --     status,
# --     course_name,
# --     course_code,
# --     course_id
# --   from
# --     main.field_learning_enablement.self_paced_enrollments
# --   where
# --     processDate = (
# --       select
# --         max(processDate)
# --       from
# --         main.field_learning_enablement.self_paced_enrollments
# --     )
# --     and course_name = 'L200 Cloud Infrastructure & Security FE Enablement'
# -- )
# -- l300_cert_status as (
#   -- There would be addition of Lakehouse Architecture Certification [Q2] for Data Warehousing and Data Steward Associate Certification [Q3] for Data Governance
#   select
#   distinct
#     e.primaryWorkEmail as email,
#     c.credential_name,
#     c.credential_id,
#     c.complete,
#     c.is_expired,
#     c.issued_on,
#     -- case when c.primaryWorkEmail in (select distinct primaryWorkEmail from emails_to_be_grandfathered)
#     --   then nvl(l.specialization_major, e.specialization_major)
#     --   else l.specialization_major
#     -- end as specialization_major,
#     case when nvl(l.specialization_major, e.specialization_major) = 'NA' then e.specialization_major
#     else nvl(l.specialization_major, e.specialization_major) end as specialization_major,
#     case
#       when (l.specialization_major = "Data Engineering" or e.specialization_major = "Data Engineering")
#       and array_contains(c.credential_name , "Databricks Certified Data Engineer Professional") then True
#       when (l.specialization_major = "Data Science & ML" or e.specialization_major = "Data Science & ML")
#       and array_contains(c.credential_name , "Databricks Certified Machine Learning Professional") then True
#       when (l.specialization_major = "Data Warehousing" or e.specialization_major = "Data Warehousing")
#       and array_contains(c.credential_name , "Databricks Certified Data Engineer Professional") then True
#       when (l.specialization_major = "Data Governance" or e.specialization_major = "Data Governance")
#       and array_contains(c.credential_name , "Databricks Certified Data Engineer Professional") then True
#       when l.specialization_major = "Data Platform Architecture"
#       and array_contains(c.credential_name , "Databricks Certified Data Engineer Professional") then True
#       when e.specialization_major = "Cloud Infrastructure & Security" then True
#       -- when l.specialization_major = "Cloud Infrastructure & Security" 
#       -- and s.status = 'Completed' then True
#       else false
#     end as l300_certification_status
#   from
#     emails_to_be_grandfathered e
#     left join l300_certifications c on c.primaryWorkEmail = e.primaryWorkEmail
#     left join main.field_learning_enablement.l200_reporting l on l.primaryWorkEmail = c.primaryWorkEmail
#     and l.processDate = (
#       select
#         max(processDate)
#       from
#         main.field_learning_enablement.l200_reporting
#     )
#     -- left join cis_course_completion s on c.primaryWorkEmail = s.learner_email
#     -- right join emails_to_be_grandfathered e on c.primaryWorkEmail = e.primaryWorkEmail

# COMMAND ----------

# DBTITLE 1,create gold df
l300_gold = add_gold_metadata(l300_data_df_final)

# COMMAND ----------

# %sql
# select * from main.field_learning_enablement.l200_reporting where processDate = '2024-06-19'
# and primaryWorkEmail = 'Michael.Shtelma@databricks.com'

# COMMAND ----------

# DBTITLE 1,create gold table
write_delta_table(
  spark, 
  dataframe = l300_gold, 
  table_name = f'{focus_database_name}.l300_reporting', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)