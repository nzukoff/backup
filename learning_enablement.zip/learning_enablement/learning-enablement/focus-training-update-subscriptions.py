# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      N/A  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      N/A \
# MAGIC **Target:**             blacklist_domains \
# MAGIC **Description:**     This notebook creates updates lab subscription end dates \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated when needed
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

import sys
from datetime import datetime, timedelta
from pprint import pprint
import requests
import json
from urllib.parse import quote_plus as urlencode
import re
from pyspark.sql import Row

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

sys.path.insert(0, focus_data_utils_path)

from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %run "/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

# MAGIC %run "/Users/nathan.zukoff@databricks.com/Docebo Auth"

# COMMAND ----------

headers, bearer_token = createHeaders('production')

# COMMAND ----------

# base_url = 'https://databrickssandbox.docebosaas.com'
base_url = 'https://databricks.docebosaas.com'

# COMMAND ----------

def get_all_coupons():
  coupons = []
  cont = True
  page = 1
  while cont:
    try:
      url = f"{base_url}/ecommerce/v1/coupon?current_page={page}"
      r = requests.get(url, headers=headers)
      if r.status_code == 200:
        data = r.json()['data']['items']
        coupons.extend(data)
        page += 1
        if page == r.json()['data']['total_page_count']+1:
          cont = False
      # pprint(r.json())
      # return r.json()["data"]
    except Exception as e:
      print(e)
  return coupons

# COMMAND ----------

def get_coupon(id):
  url = f"{base_url}/ecommerce/v1/coupon/{id}"

  try:
    r = requests.get(url, headers=headers)
    return r.json()["data"]
  except Exception as e:
    print(e)

# COMMAND ----------

def get_coupon_users(id):
  url = f"{base_url}/ecommerce/v1/coupon/{id}/users"

  try:
    r = requests.get(url, headers=headers)
    return r.json()["data"]
  except Exception as e:
    print(e)

# COMMAND ----------

# DBTITLE 1,Subscription Records Fetcher Function
# def get_subscription_records():
#   url = f"{base_url}/learn/v1/sub_record"

#   try:
#     r = requests.get(url, headers=headers)
#     # pprint(r.json())
#     return r.json()["data"]
#   except Exception as e:
#     print(e)

# COMMAND ----------

def get_subscription_records():
  subscriptions = []
  cont = True
  page = 1
  while cont:
    try:
      url = f"{base_url}/learn/v1/sub_record?page={page}"
      r = requests.get(url, headers=headers)
      if r.status_code == 200:
          data = r.json()['data']['items']
          subscriptions.extend(data)
          page += 1
          if page == r.json()['data']['total_page_count']+1:
            cont = False
    except Exception as e:
      print(e)
  return subscriptions

# COMMAND ----------

def update_subcription(subscription_info):
  url = f"{base_url}/learn/v1/sub_record/{subscription_info['record_id']}"

  sub_update = {
    'plan_id': subscription_info['plan_id'],
    'end_date': subscription_info['coupon_subscription_end_date'],
  }

  try:
    r = requests.put(url, headers=headers, json=sub_update)
    pprint(r.json())
    return r.json()["data"]
  except Exception as e:
    print(e)

# COMMAND ----------

def find_coupon_id(coupon_code):
  all_coupons = get_all_coupons()
  for coupon in all_coupons:
    if coupon['code'] == coupon_code:
      return coupon['id_coupon']

# COMMAND ----------

def find_subcription(coupon_user):
  # for sub in all_subscriptions['items']:
  for sub in all_subscriptions:
    if sub['sold_to_name'] == coupon_user['user_email']:
      return {
        'coupon_user_email': coupon_user['user_email'], 
        'coupon_user_id': coupon_user['user_id'], 
        'coupon_code': coupon_user['coupon_code'],
        'coupon_subscription_end_date': coupon_user['subscription_end_date'],
        'subscription_user': sub['sold_to_name'], 
        'record_id': sub['record_id'], 
        # 'end_date': sub['end_date'],
        'end_date': datetime.strptime(sub['end_date'], "%Y-%m-%d %H:%M:%S").strftime("%Y-%m-%d"),
        'plan_name': sub['plan_name'],
        'plan_id': sub['plan_id'],
        'object_id': sub['object_id']
        
      }

# COMMAND ----------

def convert_to_df(data):
  rows = [Row(**obj) for obj in data]

  # schema = spark.createDataFrame(rows).schema

  df = spark.createDataFrame(rows)

  return df

# COMMAND ----------

# get airtable data
airtable_pat = dbutils.secrets.get('ldr-airtable', 'airtable-token')
url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Training%20Request%20Queue?view=Subscriptions%20Requests"
at_headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

records = []
response = requests.request("GET", url, headers=at_headers)
response_json = response.json()

records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=at_headers)
  response_json = response.json()
  records += response_json['records']

data = []
for record in records:
  fields = record['fields']
  row = {
    'enrollment_name':fields.get('Enrollment Name [FF-PSA]', ''),
    'request_num':fields.get('Request #', ''),
    'submission_date':fields.get('Submission Date', ''),
    'requestor_type':fields.get('Requestor Type', ''),
    'requestor_name':fields.get('Requestor Name', ''),
    'requestor_email':fields.get('Requestor Email', ''),
    'more_than_one_learner':fields.get('More than one learner?', ''),
    'company_name':fields.get('Company Name', ''),
    'payment_type':fields.get('Payment Type', ''),
    'num_participants':fields.get('# Participants', ''),
    'enrollment_list':fields.get('Enrollment List', ''),
    'milestone_link':fields.get('[FF-PSA] Milestone Link', ''),
    'success_credits_used':fields.get('Amt. of Success Credits Used', ''),
    'tsus_consumed':fields.get('#TSUs Consumed', ''),
    'sfdc_project_or_opportunity':fields.get('[SFDC] Project or Opportunity ', ''),
    'notes':fields.get('Notes', ''),
    'num_users_on_vouchers':fields.get('[DOCEBO] # Uses on Vouchers', ''),
    'revenue_per_learner':fields.get('[FF-PSA] Revenue per Learner', ''),
    'databricks_academy_account':fields.get('Databricks Academy Account', ''),
    'milestone_amount_updated':fields.get('Milestone Amount (Updated)', ''),
    'request_type':fields.get('Request Type', ''),
    'status':fields.get('Status', ''),
    'revenue':fields.get('[FF-PSA] Revenue', ''),
    'revenue_per_learner':fields.get('[FF-PSA] Revenue per Learner', ''),
    'subscription_start_date':fields.get('Subscription Start Date', ''),
    'subscription_end_date':fields.get('Subscription End Date', ''),
    'learners_enrolled_flag':fields.get('[DOCEBO] Learners Enrolled?', ''),
    'num_uses_on_vouchers':fields.get('[DOCEBO] # Uses on Vouchers', ''),
    'coupon_code':fields.get('Subscription Coupon Code [License]', '')

  }
  data.append(row)


# COMMAND ----------

# find records that have coupons

airtable_coupons = []
for d in data:
  has_coupon = d.get('coupon_code', '')
  if has_coupon:
    if has_coupon != 'h36RPrne':
      airtable_coupons.append(d)

# COMMAND ----------

# DBTITLE 1,Coupon Users Subscription Tracker
# get coupon users and keep subscription end date

coupon_users = []
for coupon in airtable_coupons:
  id = find_coupon_id(coupon['coupon_code'])
  if id:
    coupon_info = get_coupon(id)
    coupon_users_raw = get_coupon_users(id)
    
    for user in coupon_users_raw['items']:
      coupon_users.append({
        'user_id': id,
        'user_email': user['email'],
        'subscription_end_date': coupon['subscription_end_date'],
        'coupon_code': coupon['coupon_code']
      })

print("COUPON USERS")
pprint(coupon_users)

# COMMAND ----------

all_subscriptions = get_subscription_records()

# COMMAND ----------

# get information about subscription

coupon_used_no_subscription = []
valid_subscriptions = []
for user in coupon_users:
  user_subscription = find_subcription(user)
  if user_subscription:
    valid_subscriptions.append(find_subcription(user))
  else:
    coupon_used_no_subscription.append(user)

# COMMAND ----------

# DBTITLE 1, 
subscription_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.subscription_updates",  "processDate")

updated_subscriptions_df = (
  spark.read.table(f"{focus_database_name}.subscription_updates")
    .filter(F.col("processDate") == subscription_latest_process_date)
)

updated_subscriptions = [{
  'coupon_user_email': sub["coupon_user_email"], 
  'coupon_user_id': sub["coupon_user_id"], 
  'coupon_code': sub["coupon_code"], 
  'coupon_subscription_end_date': sub["coupon_subscription_end_date"], 
  'subscription_user': sub["subscription_user"], 
  'record_id': sub["record_id"], 
  'end_date': sub["end_date"], 
  'plan_name': sub["plan_name"], 
  'plan_id': sub["plan_id"], 
  'object_id': sub['object_id']
  } for sub in updated_subscriptions_df.collect()]

# COMMAND ----------

pprint([c['coupon_code'] for c in updated_subscriptions])

# COMMAND ----------

finished_updates = []

for subscription in valid_subscriptions:
  if subscription:
    if subscription not in updated_subscriptions:
      if subscription['coupon_subscription_end_date'] == subscription['end_date']:
        print('coupon: ' + subscription['coupon_code'] +' for user '+ subscription['subscription_user'])
        print("End Date already set")
        finished_updates.append(subscription)
      else:
        update_subcription(subscription)
    else:
      print('Already set')

# COMMAND ----------

sub_df = convert_to_df(finished_updates)
no_sub_df = convert_to_df(coupon_used_no_subscription)

# COMMAND ----------

final_sub_df = add_gold_metadata(sub_df)
final_no_sub_df = add_gold_metadata(no_sub_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = final_sub_df, 
  table_name = f'{focus_database_name}.subscription_updates', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = final_no_sub_df, 
  table_name = f'{focus_database_name}.coupon_used_no_subscription', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)