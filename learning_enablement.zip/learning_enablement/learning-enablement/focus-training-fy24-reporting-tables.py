# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)


# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

try:
  sht = authGoogleSheet("Branch code master")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')
  
  
try:
  worksheet = sht.worksheet("branch_code")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "Branch code master",
 "branch_code",
 "branch_codes_master",
 clean_column_names="true", 
 make_columns_unique="true"
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### Learners Dataset

# COMMAND ----------

# DBTITLE 1,Employee Course Completion Report
learners_df = spark.sql('''
  with avg_time_pre_rank AS (
    select 
        id, 
        expected_time_to_complete_in_seconds,
        rank() over (partition by id order by expected_time_to_complete_in_seconds nulls last , category_code desc) as rank 
    from main.it_training_silver.docebo_courses
    where processDate = (select max(processDate) from main.it_training_silver.docebo_courses)

  ),

  employee_data AS (
    select 
    --  department, 
    --  category, 
      `1st_level_manager`,
      `1st_level_manager_name`,
      `2nd_level_manager`, 
      `2nd_level_manager_name`,
      `3rd_level_manager`, 
      `3rd_level_manager_name`,
      `4th_level_manager`,
      `4th_level_manager_name`,
      `5th_level_manager`, 
      `5th_level_manager_name`,
      `6th_level_manager`,
      `6th_level_manager_name`,
      Supervisory_Organization_cleaned,
      primaryWorkEmail,
      sha2(primaryWorkEmail,256) as email_hash
    from main.field_learning_enablement.workday
    where processDate = (select max(processDate) from main.field_learning_enablement.workday)
    and worker_type='Employee'
    and Termination_Date is null
  )
  ,

  avg_time AS (
    select * from avg_time_pre_rank where rank=1
  )
  ,

  sp_enrollments as (
    select
      processdate,
      learner_user_id,
      learner_email,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email,
      learner_alternate_email_hash,
      learner_alternate_email_domain,
      learner_branch_code,
      account_id,
      account_name,
      ultimate_parent_account_id,
      ultimate_parent_account_name, 
      updated_account_id,
      updated_account_name,
      updated_ultimate_parent_account_id,
      updated_ultimate_parent_account_name, 
      audience,
      course_code,
      course_name,
      course_type,
      category_code,
      null as session_id,
      null as session_name,
      status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      completed_timestamp,
      source,
      country_code, 
      country_name, 
      region, 
      d.fiscal_year_quarter as fq2,
      cast(d.calendar_month as INT) as month,
      cast(d.calendar_year as INT) as year,
      cast(d.fiscal_year as INT) as fiscalYear,
      d.fiscal_quarter_start_date as qtr_start_date,
      d.fiscal_quarter_end_date as qtr_end_date,
      t.expected_time_to_complete_in_seconds,
      match_method, 
      country_derived,
      region_derived,
      null as academy_session_number
    from main.field_learning_enablement.self_paced_enrollments e
    -- inner join users.ravi_gangumalla.sql_dates d on e.completed_timestamp::date=d.date 
    inner join main.it_core_dim.dim_dates d on e.completed_timestamp::date=d.date 
    left join avg_time t on e.course_id = t.id
    where e.status in ('completed')
    and e.source = 'Learndot'
    and e.learner_branch_code in (select branch_code from branch_codes_master)
    and e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
    
    union all

    select     
      processdate,
      learner_user_id,
      learner_email,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email,
      learner_alternate_email_hash,
      learner_alternate_email_domain,
      learner_branch_code,
      account_id,
      account_name,
      ultimate_parent_account_id,
      ultimate_parent_account_name, 
      updated_account_id,
      updated_account_name,
      updated_ultimate_parent_account_id,
      updated_ultimate_parent_account_name, 
      audience,
      course_code,
      course_name,
      course_type,
      category_code,
      null as session_id,
      null as session_name,
      status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      completed_timestamp,
      source,
      country_code, 
      country_name, 
      region, 
      d.fiscal_year_quarter as fq2,
      cast(d.calendar_month as INT) as month,
      cast(d.calendar_year as INT) as year,
      cast(d.fiscal_year as INT) as fiscalYear,
      d.fiscal_quarter_start_date as qtr_start_date,
      d.fiscal_quarter_end_date as qtr_end_date,
      t.expected_time_to_complete_in_seconds,
      match_method, 
      country_derived,
      region_derived,
      null as academy_session_number
    from main.field_learning_enablement.self_paced_enrollments e
    -- inner join users.ravi_gangumalla.sql_dates d on e.completed_timestamp::date=d.date
    inner join main.it_core_dim.dim_dates d on e.completed_timestamp::date=d.date 
    left join avg_time t on e.course_id = t.id
    where e.status in ('completed')
    and e.source='Docebo'
    -- and e.category_code in ('PART','ACAD','FENG/CUSU','FENG','PARS')
    and e.category_code in ('PART','ACAD','FENG/CUSU','FENG','SLEN')
    -- and e.course_id not in (723, 721, 724, 687, 1182)
    -- and e.course_code ilike ('%-SLP%')
    and (e.course_code ilike ('%-SLP%') or e.course_code ilike '%-ILTB-%' or e.course_code ilike '%SLEN%') 
    and e.course_code not ilike ('%DNR')
    and e.learner_branch_code in (select branch_code from branch_codes_master)
    and e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
  ),
  ilt_enrollments_pre as (
    select 
      processdate,
      learner_user_id,
      learner_email,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email,
      learner_alternate_email_hash,
      learner_alternate_email_domain,
      learner_branch_code,
      account_id,
      account_name,
      ultimate_parent_account_id,
      ultimate_parent_account_name, 
      updated_account_id,
      updated_account_name,
      updated_ultimate_parent_account_id,
      updated_ultimate_parent_account_name, 
      audience,
      course_code,
      course_name,
      course_type,
      category_code,
      e.session_id,
      e.session_name,
      status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      completed_timestamp,
      source,
      country_code, 
      country_name,
      region,
      d.fiscal_year_quarter as fq2,
      cast(d.calendar_month as INT) as month,
      cast(d.calendar_year as INT) as year,
      cast(d.fiscal_year as INT) as fiscalYear,
      d.fiscal_quarter_start_date as qtr_start_date,
      d.fiscal_quarter_end_date as qtr_end_date,
      3*60*60 as expected_time_to_complete_in_seconds,
      match_method, 
      country_derived,
      region_derived,
      academy_session_number
    from main.field_learning_enablement.ilt_enrollments e
    -- inner join users.ravi_gangumalla.sql_dates d on e.completed_timestamp::date=d.date
    inner join main.it_core_dim.dim_dates d on e.completed_timestamp::date=d.date 
    where e.status in ('completed')
    and e.source = 'Learndot'
    and e.learner_branch_code in (select branch_code from branch_codes_master)
    and e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)

    union all
    
    select 
      processdate,
      learner_user_id,
      learner_email,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email,
      learner_alternate_email_hash,
      learner_alternate_email_domain,
      learner_branch_code,
      account_id,
      account_name,
      ultimate_parent_account_id,
      ultimate_parent_account_name, 
      updated_account_id,
      updated_account_name,
      updated_ultimate_parent_account_id,
      updated_ultimate_parent_account_name, 
      audience,
      course_code,
      course_name,
      course_type,
      category_code,
      e.session_id,
      e.session_name,
      status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      completed_timestamp,
      source,
      country_code, 
      country_name, 
      region, 
      d.fiscal_year_quarter as fq2,
      cast(d.calendar_month as INT) as month,
      cast(d.calendar_year as INT) as year,
      cast(d.fiscal_year as INT) as fiscalYear,
      d.fiscal_quarter_start_date as qtr_start_date,
      d.fiscal_quarter_end_date as qtr_end_date,
      t.expected_time_to_complete_in_seconds,
      match_method, 
      country_derived,
      region_derived,
      academy_session_number
    from main.field_learning_enablement.ilt_enrollments e
    -- inner join users.ravi_gangumalla.sql_dates d on e.completed_timestamp::date=d.date
    inner join main.it_core_dim.dim_dates d on e.completed_timestamp::date=d.date 
    left join avg_time t on e.course_id = t.id
    where e.status in ('completed')
    and e.category_code in ('PART','ACAD','FENG/CUSU','FENG', 'ACAD-ALL-ILT-PAID', 'SLEN')
    and e.source = 'Docebo'
    and e.learner_branch_code in (select branch_code from branch_codes_master)
    and e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)

UNION ALL

  -- Uplimit block
  SELECT 
    processdate,
    learner_user_id,
    learner_email,
    learner_email_hash,
    learner_email_domain,
    learner_alternate_email,
    learner_alternate_email_hash,
    learner_alternate_email_domain,
    learner_branch_code,
    account_id,
    account_name,
    ultimate_parent_account_id,
    ultimate_parent_account_name, 
    updated_account_id,
    updated_account_name,
    updated_ultimate_parent_account_id,
    updated_ultimate_parent_account_name, 
    audience,
    course_code,
    course_name,
    course_type,
    category_code,
    e.session_id,
    e.session_name,
    status,
    enrolled_timestamp::date AS enrolled_date,
    completed_timestamp::date AS completed_date,
    completed_timestamp,
    source,
    country_code, 
    country_name,
    region,
    d.fiscal_year_quarter AS fq2,
    CAST(d.calendar_month AS INT) AS month,
    CAST(d.calendar_year AS INT) AS year,
    CAST(d.fiscal_year AS INT) AS fiscalYear,
    d.fiscal_quarter_start_date AS qtr_start_date,
    d.fiscal_quarter_end_date AS qtr_end_date,
    4*60*60 AS expected_time_to_complete_in_seconds, -- default fallback
    match_method, 
    country_derived,
    region_derived,
    academy_session_number
  FROM main.field_learning_enablement.ilt_enrollments e
  INNER JOIN main.it_core_dim.dim_dates d ON e.completed_timestamp::date = d.date 
  WHERE e.status = 'completed'
    AND e.source = 'Uplimit'
    AND e.processdate = (SELECT MAX(processdate) FROM main.field_learning_enablement.ilt_enrollments)

  ),

  ilt_enrollments_dedupe AS 
  (
    select 
      *,
      rank() over (partition by i.learner_user_id, i.course_code, i.session_name, i.completed_timestamp order by i.category_code) as dedupe_rank
    from ilt_enrollments_pre i
  )
  ,

  ilt_enrollments_final AS (
    select * 
    from ilt_enrollments_dedupe 
    where dedupe_rank=1
  )
  ,

  sp_enrollments_dedupe as
  (
    select 
      s.*, 
      rank() over (partition by s.learner_user_id, s.course_code, s.completed_timestamp order by s.category_code) as dedupe_rank 
    from sp_enrollments s
  )
  ,

  sp_enrollments_final as
  (
    select * from sp_enrollments_dedupe where dedupe_rank=1
  )
  ,

  all_enrollments as
  (
    select * from ilt_enrollments_final
    union all
    select * from sp_enrollments_final
  )

  ,
  rolling_totals as (
    select 
      completed_timestamp, 
      learner_user_id,
      course_code, 
      category_code,
      expected_time_to_complete_in_seconds,
      sum(expected_time_to_complete_in_seconds) over (partition by learner_user_id order by completed_timestamp asc ROWS BETWEEN unbounded preceding AND CURRENT ROW) as rollingTotal 
    from all_enrollments e
    group by 1,2,3,4,5
  )
  ,
  all_enrollments_filtered as (
    select 
      s.*,
      t.rollingTotal
    from all_enrollments s 
    left join rolling_totals t
      on s.learner_user_id = t.learner_user_id
      and s.course_code = t.course_code
      and s.completed_timestamp = t.completed_timestamp
    where t.rollingTotal >= 3*60*60
    and s.source != 'Uplimit'

    union all

    select 
      s.*,
      t.rollingTotal
    from all_enrollments s 
    left join rolling_totals t
      on s.learner_user_id = t.learner_user_id
      --and s.course_code = t.course_code
      and s.completed_timestamp = t.completed_timestamp
    where t.rollingTotal >= 3*60*60
    and s.source = 'Uplimit'
  )
  ,
  docebo_users_dedupe as (
    select 
      *, 
      rank() over (partition by u.email_hash order by u.created_timestamp desc) as dedupe_rank 
    from main.field_learning_enablement.docebo_users u
    where processDate = (select max(processdate) from main.field_learning_enablement.docebo_users)
    and email_hash is not null
  )
  ,
  docebo_users as (
    select email_hash, created_timestamp, country_derived, region_derived
    from docebo_users_dedupe d
    where d.dedupe_rank = 1
  )
  ,
  pre as (
    select
      processdate,
      learner_user_id,
      learner_email,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email,
      learner_alternate_email_hash,
      learner_alternate_email_domain,
      a.account_id,
      a.account_name,
      a.ultimate_parent_account_id,
      a.ultimate_parent_account_name, 
      a.updated_account_id,
      a.updated_account_name,
      a.updated_ultimate_parent_account_id,
      a.updated_ultimate_parent_account_name, 
      a.audience,
      learner_branch_code,
      course_code,
      course_name,
      course_type,
      category_code,
      session_id,
      session_name,
      status,
      enrolled_date,
      completed_date,
      completed_timestamp,
      source,
      fq2,
      month,
      year,
      fiscalYear,
      qtr_start_date,
      qtr_end_date,
      expected_time_to_complete_in_seconds,
      rollingTotal,
      country_code, 
      country_name, 
      region, 
      -- b.account_id,
      nvl(b.sales_business_unit, "Unknown") as business_unit,
      nvl(b.sales_subregion_level_1, "Unknown") as sales_subregion_level_1,
      nvl(b.sales_subregion_level_2, "Unknown") as sales_subregion_level_2,
      nvl(b.sales_subregion_level_3, "Unknown") as sales_subregion_level_3,
      match_method,
      u.country_derived,
      u.region_derived,
      -- case  
      --   when p.`Account ID` is not null then 1 else 0 end as partner_account_list_flag,
      dense_rank() over (partition by learner_user_id order by completed_timestamp, enrolled_date) as rank_learner,
      dense_rank() over (partition by learner_user_id, fiscalYear order by completed_timestamp, enrolled_date) as fiscal_rank -- needed to find the first time a learner crossed the threshold
      ,u.created_timestamp as user_created_timestamp,
      a.academy_session_number
    from all_enrollments_filtered a
    left join main.gtm_data.core_accounts_curated b on a.updated_account_id=b.account_id and b.snapshot_date = (select max(snapshot_date) from main.gtm_data.core_accounts_curated)
    left join docebo_users u on a.learner_email_hash = u.email_hash
    -- left join main.field_learning_enablement.partner_domains_priyanka p on left(a.ultimate_parent_account_id, 15) = p.`Account ID`
    )

  ,


  pre_final_net_new_learner as 
  (
  select *, dense_rank() over (partition by learner_user_id order by course_name) as rank_dedupe -- needed to dedupe scenarios where the same learner has completed a few courses at the exact same time to cross the learner threshold
  from pre where rank_learner = 1 
  )
  ,

  net_new_learners AS (
    select 
      'net new learners' as dataset,
      *
    from pre_final_net_new_learner where rank_dedupe=1
  )
  ,

  pre_final_fiscal_learner AS (
    select 
      *, 
      dense_rank() over (partition by fiscalYear, learner_user_id order by course_name) as rank_dedupe
    from pre where fiscal_rank=1
  )
  ,

  fiscal_learners AS (
    select 
      'fiscal learners' as dataset, 
      *
    from pre_final_fiscal_learner 
    where rank_dedupe=1
  )
  ,

  pre_final_dataset AS (
    select * from net_new_learners
    union all
    select * from fiscal_learners
  )
  ,

  final_dataset AS (

    select 
      f.*,
      --e.department, 
    --  e.category, 
      e.`1st_level_manager`,
      e.`1st_level_manager_name`,
      e.`2nd_level_manager`, 
      e.`2nd_level_manager_name`,
      e.`3rd_level_manager`, 
      e.`3rd_level_manager_name`,
      e.`4th_level_manager`,
      e.`4th_level_manager_name`,
      e.`5th_level_manager`, 
      e.`5th_level_manager_name`,
      e.`6th_level_manager`,
      e.`6th_level_manager_name`,
      e.Supervisory_Organization_cleaned,
      e.primaryWorkEmail
    from pre_final_dataset f
    left join employee_data e on f.learner_email_hash=e.email_hash and f.learner_branch_code='DBK_EMP' 
  )
  ,
  greenfield as (
    SELECT
      ca.account_id,
      CASE WHEN ba.accountspendtier__c = 'Greenfield'
          AND lower(ba.Owner_Role__c) not like '%unassigned%'
          AND ca.business_unit is not null
          AND ca.dbx in ('DB400','DB3000')   
              THEN 'Yes'
      ELSE 'No' 
      END as greenfield_account
      FROM main.gtm_data.core_accounts_curated ca
      LEFT JOIN main.sfdc_bronze.account ba 
        ON ca.account_id = ba.AccountID_CaseSafe__c
      AND ba.processDate IN (SELECT MAX(processDate) FROM main.sfdc_bronze.account)
  )

  select 
    f.*,
    g.greenfield_account
  from final_dataset f
  left join greenfield g on f.updated_account_id=g.account_id

''')

# COMMAND ----------

all_learners_gold = add_gold_metadata(learners_df)

# COMMAND ----------

# MAGIC %md ### Certifications Badge dataset

# COMMAND ----------

# DBTITLE 1,Employee Certifications and Badges Query
certs_badges_df = spark.sql('''
  with date_year AS (
    select distinct fiscal_year,current_date as date from main.it_core_dim.dim_dates where date::date=current_date
  )
  ,

  fiscal_year_end AS (
    select d.date, max(s.fiscal_year) as next_fiscal_year, max(s.fiscal_quarter_end_date) as fiscal_year_end_date from main.it_core_dim.dim_dates s inner join date_year d on s.fiscal_year=d.fiscal_year
    group by 1
  )
  ,
  employee_data AS (
    select 
     -- department, 
    --  category, 
      `1st_level_manager`,
      `1st_level_manager_name`,
      `2nd_level_manager`, 
      `2nd_level_manager_name`,
      `3rd_level_manager`, 
      `3rd_level_manager_name`,
      `4th_level_manager`,
      `4th_level_manager_name`,
      `5th_level_manager`, 
      `5th_level_manager_name`,
      `6th_level_manager`,
      `6th_level_manager_name`,
      Supervisory_Organization_cleaned,
      primaryWorkEmail,
      sha2(primaryWorkEmail,256) as email_hash
    from main.field_learning_enablement.workday
    where processDate = (select max(processDate) from main.field_learning_enablement.workday)
    and worker_type='Employee'
    and Termination_Date is null
  )
  ,
  badges as (
    select
      processdate,
      complete,
      credential_id,
      credential_name,
      expired_on :: date,
      is_expired,
      calculated_expired_on :: date,
      calculated_is_expired,
      group_id,
      group_name, 
      issued_on :: date,
      learner_id,
      learner_email_hash,
      learner_email_domain,
      learner_alternate_email_domain,
      learner_alternate_email_hash,
      learner_branch_code,
      b.account_id,
      b.account_name,
      b.ultimate_parent_account_id,
      ultimate_parent_account_name,
      updated_account_id,
      updated_account_name,
      updated_ultimate_parent_account_id,
      updated_ultimate_parent_account_name, 
      audience,
      d.fiscal_year_quarter as fq2,
      d.fiscal_quarter_start_date as qtr_start_date,
      d.fiscal_quarter_end_date as qtr_end_date,
      cast(d.fiscal_year as INT) as fiscalYear,
      d2.fiscal_year_quarter as current_fiscal_quarter,
      d2.fiscal_quarter_end_date as current_fiscal_quarter_end_date,
      f.fiscal_year_end_date,
      country_code,
      country_name,
      region,
      nvl(c.sales_business_unit, 'Unknown') as business_unit,
      nvl(c.sales_subregion_level_1, 'Unknown') as sales_subregion_level_1,
      nvl(c.sales_subregion_level_2, 'Unknown') as sales_subregion_level_2,
      nvl(c.sales_subregion_level_3, 'Unknown') as sales_subregion_level_3,
      nvl(c.dbx, 'Non-DBX') as dbx,
      match_method,
      country_derived,
      region_derived,
      case 
        when group_id in (
          '371215', 
          '364119', 
          '357057', 
          '353856', 
          '331743', 
          '229201', 
          '227965', 
          '227818', 
          '583499'
        )
        then "Certification"
        when group_id in (
          '296467',
          '405160',
          '473432', 
          '479290',
          '479297',
          '479298',
          '547441',
          '667100'
        ) then "Badge"
        when group_id in (
          --"473432",
          "526887",
          "679305",
          --"698774",
          "473387",
          "682370",
          "238118",
          "514772",
          "665841",
          "665836",
          "665839",
          "665838",
          "665837",
          "416015",
          "665834",
          "385601",
          "237937",
          "688634",
          "511547",
          "611713",
          "428755",
          "564495",
          "639408",
          "562532",
          "622072",
          "582711",
          "524251",
          "545340",
          "615200",
          "592281",
          "595574",
          "473415",
          "473403",
          "713941",
          "713198",
          "705063"
        ) then "Sales Badge"
        else "Other" end as credential_type,
        -- case  
        --   when p.`Account ID` is not null then 1 else 0 end as partner_account_list_flag,
      dense_rank() over (partition by processdate,learner_email_hash order by issued_on::date) as rank_learner
    from main.field_learning_enablement.accredible_credentials b
    inner join main.it_core_dim.dim_dates d on b.issued_on::date=d.date
    inner join main.it_core_dim.dim_dates d2 on current_date()::date=d2.date
    inner join fiscal_year_end f on current_date()::date=f.date
    left join main.gtm_data.core_accounts_curated c on b.updated_account_id=c.account_id and c.snapshot_date=(select max(snapshot_date) from main.gtm_data.core_accounts_curated)
    where b.processdate= (select max(processdate) from main.field_learning_enablement.accredible_credentials)
  )

  ,

  working AS (
    select 
      case 
        when expired_on::date>current_date::date 
        then date_diff(expired_on,current_date) 
        else 0 end as days_to_expiration, 
      b.*,
    --  e.department, 
    --  e.category, 
      e.`1st_level_manager`,
      e.`1st_level_manager_name`,
      e.`2nd_level_manager`, 
      e.`2nd_level_manager_name`,
      e.`3rd_level_manager`, 
      e.`3rd_level_manager_name`,
      e.`4th_level_manager`,
      e.`4th_level_manager_name`,
      e.`5th_level_manager`, 
      e.`5th_level_manager_name`,
      e.`6th_level_manager`,
      e.`6th_level_manager_name`,
      e.Supervisory_Organization_cleaned,
      e.primaryWorkEmail
    from badges b
    left join employee_data e on b.learner_email_hash=e.email_hash and b.learner_branch_code='DBK_EMP' 
  )

  select * 
  from working

''')

# COMMAND ----------

certs_badges_gold = add_gold_metadata(certs_badges_df)

# COMMAND ----------

# MAGIC %md ### All Enrollments

# COMMAND ----------

# DBTITLE 1,Consolidated Enrollment Analytics Query
all_enrollments_df = spark.sql('''
with avg_time_pre_rank AS (
    select 
        id, 
        expected_time_to_complete_in_seconds,
        rank() over (partition by id order by expected_time_to_complete_in_seconds nulls last , category_code desc) as rank 
    from main.it_training_silver.docebo_courses
    where processDate = (select max(processDate) from main.it_training_silver.docebo_courses)
  )
  ,
  avg_time AS (
    select * from avg_time_pre_rank where rank=1
  )
  ,
  sp_enrollments AS (
  select
     processdate,
     learner_user_id,
     learner_email,
     learner_email_hash,
     learner_email_domain,
     learner_alternate_email,
     learner_alternate_email_hash,
     learner_alternate_email_domain,
     learner_branch_code,
     account_id,
     account_name,
     ultimate_parent_account_id,
     ultimate_parent_account_name, 
     updated_account_id,
     updated_account_name,
     updated_ultimate_parent_account_id,
     updated_ultimate_parent_account_name, 
     audience,
     course_code,
     course_name,
     course_type,
     course_id,
     null as session_id,
     null as session_name,
     category_code,
     status,
     enrolled_timestamp :: date as enrolled_date,
     completed_timestamp :: date as completed_date,
     enrolled_timestamp,
     completed_timestamp,
     source,
     country_code, 
     country_name, 
     region, 
     d.fiscal_year_quarter as fq2,
     d2.fiscal_year_quarter as completed_fq2,
     cast(d.calendar_month as INT) as month,
     cast(d.calendar_year as INT) as year,
     cast(d.fiscal_year as INT) as fiscalYear,
     d.fiscal_quarter_start_date as qtr_start_date,
     d.fiscal_quarter_end_date as qtr_end_date,
     match_method,
    country_derived,
    region_derived,
    a.expected_time_to_complete_in_seconds,
    null as academy_session_number
   from main.field_learning_enablement.self_paced_enrollments e
   inner join main.it_core_dim.dim_dates d on e.enrolled_timestamp::date=d.date 
   left join main.it_core_dim.dim_dates d2 on e.completed_timestamp::date=d2.date 
   left join avg_time a on e.course_id=a.id
   where e.source = 'Learndot'
   and e.learner_branch_code in (select branch_code from branch_codes_master)
   and e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
   
   union all
 
   select     
     processdate,
     learner_user_id,
     learner_email,
     learner_email_hash,
     learner_email_domain,
     learner_alternate_email,
     learner_alternate_email_hash,
     learner_alternate_email_domain,
     learner_branch_code,
     account_id,
     account_name,
     ultimate_parent_account_id,
     ultimate_parent_account_name, 
     updated_account_id,
     updated_account_name,
     updated_ultimate_parent_account_id,
     updated_ultimate_parent_account_name, 
     audience,
     course_code,
     course_name,
     course_type,
     course_id,
     null as session_id,
     null as session_name,
     category_code,
     status,
     enrolled_timestamp :: date as enrolled_date,
     completed_timestamp :: date as completed_date,
     enrolled_timestamp,
     completed_timestamp,
     source,
     country_code,
     country_name,
     region,
     d.fiscal_year_quarter as fq2,
     d2.fiscal_year_quarter as completed_fq2,
     cast(d.calendar_month as INT) as month,
     cast(d.calendar_year as INT) as year,
     cast(d.fiscal_year as INT) as fiscalYear,
     d.fiscal_quarter_start_date as qtr_start_date,
     d.fiscal_quarter_end_date as qtr_end_date,
     match_method,
    country_derived,
    region_derived,
    a.expected_time_to_complete_in_seconds,
    null as academy_session_number
   from main.field_learning_enablement.self_paced_enrollments e
   inner join main.it_core_dim.dim_dates d on e.enrolled_timestamp::date=d.date 
   left join main.it_core_dim.dim_dates d2 on e.completed_timestamp::date=d2.date 
   left join avg_time a on e.course_id=a.id
   where e.source='Docebo'
   and e.category_code in ('PART','ACAD','FENG/CUSU','FENG', 'PARS', 'SLEN')
   and (e.course_code ilike ('%-SLP%') or e.course_code ilike '%-ILTB-%' or e.course_code ilike '%PARS%' or e.course_code ilike '%SLEN%')
   and e.course_code not ilike ('%DNR')
   and e.learner_branch_code in (select branch_code from branch_codes_master)
   and e.processdate= (select max(processdate) from main.field_learning_enablement.self_paced_enrollments)
  )
 ,
 
 ilt_enrollments AS (
   select 
     processdate,
     learner_user_id,
     learner_email,
     learner_email_hash,
     learner_email_domain,
     learner_alternate_email,
     learner_alternate_email_hash,
     learner_alternate_email_domain,
     learner_branch_code,
     account_id,
     account_name,
     ultimate_parent_account_id,
     ultimate_parent_account_name, 
     updated_account_id,
     updated_account_name,
     updated_ultimate_parent_account_id,
     updated_ultimate_parent_account_name, 
     audience,
     course_code,
     course_name,
     course_type,
     course_id,
     session_id,
     session_name,
     category_code,
     status,
     enrolled_timestamp :: date as enrolled_date,
     completed_timestamp :: date as completed_date,
     enrolled_timestamp,
     completed_timestamp,
     source,
     country_code, 
     country_name, 
     region, 
     d.fiscal_year_quarter as fq2,
     d2.fiscal_year_quarter as completed_fq2,
     cast(d.calendar_month as INT) as month,
     cast(d.calendar_year as INT) as year,
     cast(d.fiscal_year as INT) as fiscalYear,
     d.fiscal_quarter_start_date as qtr_start_date,
     d.fiscal_quarter_end_date as qtr_end_date,
     match_method,
    country_derived,
    region_derived,
    3*60*60 as expected_time_to_complete_in_seconds,
    academy_session_number
   from main.field_learning_enablement.ilt_enrollments e
   inner join main.it_core_dim.dim_dates d on e.enrolled_timestamp::date=d.date 
   left join main.it_core_dim.dim_dates d2 on e.completed_timestamp::date=d2.date 
   where e.source = 'Learndot'
   and e.learner_branch_code in (select branch_code from branch_codes_master)
   and e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
 union all
   
   select 
     processdate,
     learner_user_id,
     learner_email,
     learner_email_hash,
     learner_email_domain,
     learner_alternate_email,
     learner_alternate_email_hash,
     learner_alternate_email_domain,
     learner_branch_code,
     account_id,
     account_name,
     ultimate_parent_account_id,
     ultimate_parent_account_name, 
     updated_account_id,
     updated_account_name,
     updated_ultimate_parent_account_id,
     updated_ultimate_parent_account_name, 
     audience,
     course_code,
     course_name,
     course_type,
     course_id,
     session_id,
     session_name,
     category_code,
     status,
     enrolled_timestamp :: date as enrolled_date,
     completed_timestamp :: date as completed_date,
     enrolled_timestamp,
     completed_timestamp,
     source,
     country_code, 
     country_name, 
     region, 
     d.fiscal_year_quarter as fq2,
     d2.fiscal_year_quarter as completed_fq2,
     cast(d.calendar_month as INT) as month,
     cast(d.calendar_year as INT) as year,
     cast(d.fiscal_year as INT) as fiscalYear,
     d.fiscal_quarter_start_date as qtr_start_date,
     d.fiscal_quarter_end_date as qtr_end_date,
     match_method,
    country_derived,
    region_derived,
    a.expected_time_to_complete_in_seconds,
    academy_session_number
   from main.field_learning_enablement.ilt_enrollments e
   inner join main.it_core_dim.dim_dates d on e.enrolled_timestamp::date=d.date 
   left join main.it_core_dim.dim_dates d2 on e.completed_timestamp::date=d2.date 
   left join avg_time a on e.course_id=a.id
   where e.category_code in ('PART','ACAD','FENG/CUSU','FENG', 'PARS', 'ACAD-ALL-ILT-PAID','SLEN')
   and e.source = 'Docebo'
   and e.learner_branch_code in (select branch_code from branch_codes_master)
   and e.processdate= (select max(processdate) from main.field_learning_enablement.ilt_enrollments)


UNION ALL

   -- Uplimit source
   SELECT 
     processdate,
     learner_user_id,
     learner_email,
     learner_email_hash,
     learner_email_domain,
     learner_alternate_email,
     learner_alternate_email_hash,
     learner_alternate_email_domain,
     learner_branch_code,
     account_id,
     account_name,
     ultimate_parent_account_id,
     ultimate_parent_account_name, 
     updated_account_id,
     updated_account_name,
     updated_ultimate_parent_account_id,
     updated_ultimate_parent_account_name, 
     audience,
     course_code,
     course_name,
     course_type,
     course_id,
     session_id,
     session_name,
     category_code,
     status,
     enrolled_timestamp :: date AS enrolled_date,
     completed_timestamp :: date AS completed_date,
     enrolled_timestamp,
     completed_timestamp,
     source,
     country_code, 
     country_name, 
     region, 
     d.fiscal_year_quarter AS fq2,
     d2.fiscal_year_quarter AS completed_fq2,
     CAST(d.calendar_month AS INT) AS month,
     CAST(d.calendar_year AS INT) AS year,
     CAST(d.fiscal_year AS INT) AS fiscalYear,
     d.fiscal_quarter_start_date AS qtr_start_date,
     d.fiscal_quarter_end_date AS qtr_end_date,
     match_method,
     country_derived,
     region_derived,
     4*60*60 AS expected_time_to_complete_in_seconds,
     academy_session_number
   FROM main.field_learning_enablement.ilt_enrollments e
   INNER JOIN main.it_core_dim.dim_dates d ON e.enrolled_timestamp::date = d.date 
   LEFT JOIN main.it_core_dim.dim_dates d2 ON e.completed_timestamp::date = d2.date 
   WHERE e.source = 'Uplimit'
     AND e.processdate = (SELECT MAX(processdate) FROM main.field_learning_enablement.ilt_enrollments)

 )
 ,
  learner_enrollments as (
    select *
    from sp_enrollments
    union all
    select *
    from ilt_enrollments
  )
 ,

  employee_data AS (
    select 
    --  department, 
    --  category, 
      businessTitle,
      `1st_level_manager`,
      `1st_level_manager_name`,
      `2nd_level_manager`, 
      `2nd_level_manager_name`,
      `3rd_level_manager`, 
      `3rd_level_manager_name`,
      `4th_level_manager`,
      `4th_level_manager_name`,
      `5th_level_manager`, 
      `5th_level_manager_name`,
      `6th_level_manager`,
      `6th_level_manager_name`,
      Supervisory_Organization_cleaned,
      lower(d.primaryWorkEmail) as primaryWorkEmail,
      sha2(lower(d.primaryWorkEmail),256) as email_hash,
    --  sfdc_businessUnit,
      manager_hierarchy_path_name,
      manager_hierarchy_path,
      Manager
    -- from liam.wd d
    from main.field_learning_enablement.workday d
    --left join wd w on w.primaryWorkEmail = d.primaryWorkEmail
    where processDate = (select max(processDate) from main.field_learning_enablement.workday)
    and worker_type='Employee'
    and Termination_Date is null
  )
  ,
 
 ilt_sessions_dedupe as (
   select s.*,
   rank() over (partition by s.id order by s.course_category_code) as dedupe_rank 
   from main.it_training_silver.docebo_ilt_sessions s
   where s.processDate= (select max(processDate) from main.it_training_silver.docebo_ilt_sessions)
 )
 ,
 ilt_sessions as (
   select s.*
   from ilt_sessions_dedupe s
   where s.dedupe_rank = 1
 )
 ,
  docebo_users_dedupe as (
  select 
    *, 
    rank() over (partition by u.email_hash order by u.created_timestamp desc) as dedupe_rank 
  from main.field_learning_enablement.docebo_users u
  where processDate = (select max(processdate) from main.field_learning_enablement.docebo_users)
  and email_hash is not null
  )
  ,
  docebo_users as (
    select email_hash, created_timestamp, country_derived, region_derived
    from docebo_users_dedupe d
    where d.dedupe_rank = 1
  )
 , 
 final_pre as (
 select 
   e.processdate,
   e.learner_user_id,
   e.learner_email,
   e.learner_email_hash,
   e.learner_email_domain,
   e.learner_alternate_email,
   e.learner_alternate_email_hash,
   e.learner_alternate_email_domain,
   e.learner_branch_code,
   e.account_id,
   e.account_name,
   e.ultimate_parent_account_id,
   e.ultimate_parent_account_name, 
   e.updated_account_id,
   e.updated_account_name,
   e.updated_ultimate_parent_account_id,
   e.updated_ultimate_parent_account_name, 
   e.audience,
   e.course_code,
   e.course_name,
   e.course_type,
   e.course_id,
   e.session_id,
   e.session_name,
   e.category_code,
   e.status,
   e.enrolled_timestamp :: date as enrolled_date,
   e.completed_timestamp :: date as completed_date,
   e.enrolled_timestamp,
   e.completed_timestamp,
   e.source,
   e.country_code, 
   e.country_name, 
   e.region, 
   e.fq2,
   e.completed_fq2 as completed_fq2,
   e.month,
   e.year,
   e.fiscalYear,
   e.qtr_start_date,
   e.qtr_end_date,
   s.id,
   s.started_timestamp,
   s.ended_timestamp,
   nvl(s.code, academy_session_number) as session_code, 
   nvl(b.sales_business_unit, 'Unknown') as business_unit,
   nvl(b.sales_subregion_level_1, 'Unknown') as sales_subregion_level_1,
   nvl(b.sales_subregion_level_2, 'Unknown') as sales_subregion_level_2,
   nvl(b.sales_subregion_level_3, 'Unknown') as sales_subregion_level_3,
   d.*,
   case when nvl(e.status,'Unknown') in ('in_progress','completed','subscribed') then 1 else 0 end as registered_flag,
   case when nvl(e.status,'Unknown') in ('completed') then 1 else 0 end as attended_flag,
   nvl(e.match_method, 'no_match') as match_method,
   u.country_derived,
   u.region_derived,
   u.created_timestamp as user_created_timestamp,
   case when e.course_id in (723, 721, 724, 687, 1182) then 'Non-Technical' else 'Technical' end as content_type,
   e.expected_time_to_complete_in_seconds,
   academy_session_number
 from learner_enrollments e
 left join ilt_sessions s on e.session_id=s.id
 left join main.gtm_data.core_accounts_curated b on e.updated_account_id=b.account_id and b.snapshot_date = (select max(snapshot_date) from main.gtm_data.core_accounts_curated)
 left join employee_data d on e.learner_email_hash=d.email_hash and e.learner_branch_code='DBK_EMP'
 left join docebo_users u on e.learner_email_hash = u.email_hash
 )
   ,
  greenfield as (
    SELECT
      ca.account_id,
      CASE WHEN ba.accountspendtier__c = 'Greenfield'
          AND lower(ba.Owner_Role__c) not like '%unassigned%'
          AND ca.business_unit is not null
          AND ca.dbx in ('DB400','DB3000')   
              THEN 'Yes'
      ELSE 'No' 
      END as greenfield_account
      FROM main.gtm_data.core_accounts_curated ca
      LEFT JOIN main.sfdc_bronze.account ba 
        ON ca.account_id = ba.AccountID_CaseSafe__c
      AND ba.processDate IN (SELECT MAX(processDate) FROM main.sfdc_bronze.account)
  )

  select 
    f.*, 
    g.greenfield_account
  from final_pre f 
  left join greenfield g on f.updated_account_id=g.account_id

''')

# COMMAND ----------

all_enrollments_gold = add_gold_metadata(all_enrollments_df)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ###Get Certified

# COMMAND ----------

# DBTITLE 1,Employee Certification Dataframe Query
get_certified_df = spark.sql('''  
  with fe_cert_hc as (
  with final AS (
    select
      wd.hire_date,
      datediff(MONTH, hire_Date, current_date()) as tenure,
      wd.Name as workday_name,
      wd.job_profile_start_date,
      wd.job_profile,
      wd.1st_level_manager_name,
      wd.1st_level_manager,
      wd.2nd_level_manager_name,
      wd.2nd_level_manager,
      wd.3rd_level_manager_name,
      wd.3rd_level_manager,
      wd.4th_level_manager_name,
      wd.4th_level_manager,
      wd.5th_level_manager_name,
      wd.5th_level_manager,
      wd.6th_level_manager_name,
      wd.6th_level_manager,
      wd.manager_hierarchy_path,
      wd.manager_hierarchy_path_name,
      wd.businessTitle,
      wd.primaryWorkEmail,
      wd.Termination_Date,
      wd.status,
      wd.manager
    -- from
    --   liam.wd wd
    from main.field_learning_enablement.workday wd
    where processDate = (select max(processDate) from main.field_learning_enablement.workday)
    and Worker_Type='Employee'
    and status = 'true'
    and (nvl(name, "Unknown") not in (select distinct manager from main.field_learning_enablement.workday wd where wd.Worker_Type='Employee'and wd.status = 'true' and wd.processDate = (select max(processDate) from main.field_learning_enablement.workday)) or primaryWorkEmail = 'pritesh.patel@databricks.com')
    and manager_hierarchy_path_name ilike any (
      '%jeff traylor%',
      '%david hackett%',
      '%jason martin%',
      '%toby balfre%',
      '%nicholas eayrs%',
      '%david totten%'
      -- '%richard garris%'
    )
    and manager_hierarchy_path_name not ilike ('%victor cheah%')
  ),
  pre as (
    select
      *
    from
      final
    -- where
    --   status is true
      where businessTitle IN (
        'Solutions Architect',
        'Resident Solutions Architect',
        'Sr. Solutions Architect',
        'Delivery Solutions Architect',
        'Sr. Delivery Solutions Engineer',
        'Sr Delivery Solutions Engineer',
        'Senior Delivery Solutions Engineer',
        'Specialist Solutions Architect',
        'Sr. Solutions Consultant',
        'Solutions Consultant',
        'Sr. Specialist Solutions Architect',
        'Sr. Specialist Solutions Architect ',
        'Sr. Delivery Solutions Architect',
        'Sr. Solutions Engineer',
        'Senior Solution Engineer',
        'Sr Solutions Engineer',
        'Sr. Technical Services Engineer',
        'Sr. Technical Advisor, Financial Services',
        'Technical Services Engineer',
        'Sr Solutions Consultant',
        'Sr. Resident Solutions Architect',
        'Senior Solutions Engineer',
        'Senior Specialist Solutions Architect',
        'Senior Solutions Consultant',
        'Specialist Solutions Engineer',
        'Senior Specialist Solutions Engineer',
        'Senior Partner Solutions Engineer',
        'Cloud Technologist',
        'Technical Services Specialist',
        'Solutions Engineer',
        'Delivery Solutions Engineer',
        'Sr. Partner Solutions Architect',
        'Sr. Global Practice Tech Lead, Customer Success Engineering',
        -- 'Sr Engagement Manager',
        'Partner Solutions Architect',
        'Lead Specialist Solutions Architect',
        -- 'Engagement Manager',
        'Lead Solutions Architect',
        'Sr. Specialist Solutions Engineer',
        -- 'Sr. Engagement Manager',
        'Principal Specialist Solutions Architect',
        'Senior Strategic Solutions Architect',
        'Sr Solutions Architect',
        'Principal Solutions Architect',
        'Lead Resident Solutions Architect',
        'Practice Lead Resident Solutions Architect',
        'Senior Resident Solutions Architect',
        -- 'Senior Engagement Manager',
        'Sr. Specialist Solutons Architect',
        'Sr Specialist Solutions Architect',
        'Snr. Solutions Architect',
        'Lead Delivery Solutions Architect',
        'Lead Product Specialist Solution Architect - Data Engineering',
        'Resident Solution Architect',
        'Delivery Solution Architect',
        'Sr Resident Solutions Architect',
        'Lead Partner Solutions Architect',
        'Specialist Solutions Architect - Financial Services',
        'Specialist Solutions Architect - Data Science & Machine Learning',
        'Solution Architect',
        'Sr. Technical Solutions Engineer',
        'Solution Architect, ANZ',
        'Sr. Strategic Solutions Architect',
        'Senior Solutions Architect, Digital Native Business',
        'Sr Specialist Solutions Engineer',
        'Partner Solutions Architect, Lead for GSI',
        'Senior Solutions Architect',
        'Data & AI Strategist',
        'Senior Delivery Solutions Architect',
        'Sr Technical Services Engineer',
        'Lead Product Specialist Solutions Architect',
        'Sr Delivery Solutions Architect',
        'Specialist Solutions Architect - Data Engineering',
        'Sr. Specialist Solutions Engineer - Data Engineering',
        'Associate Customer Data Engineer',
        'Customer Data Engineer',
        'Sr. Customer Data Engineer',
        'Delivery Solutions Architect, Financial Services', 
        'Sr. Scale Solution Engineer'
        -- ,
        -- 'Specialist Solutions Architect, Field Engineering'
      ) 
  )
  select
    *,
    case
      when businessTitle in (
        'Lead Specialist Solutions Architect',
        --SSA
        'Principal Specialist Solutions Architect',
        --SSA
        'Specialist Solutions Architect',
        --SSA
        'Sr. Specialist Solutions Architect' --SSA
      ) then 0
      else case
        when tenure < 6 then 1
        else 0
      end
    end as exclude_flag
  from
    pre
  where
    1 = 1 
)
,

all_certs as (
  select
    *
  from
    main.field_learning_enablement.accredible_credentials
  where
    processdate = (
      Select
        max(processdate)
      from
        main.field_learning_enablement.accredible_credentials
    )
    and is_expired = 'false'
    and group_id in (
      '371215',
      '364119',
      '357057',
      '353856',
      '331743',
      '229201',
      '227965',
      '227818',
      '227970', --added by Janam on 6.9 to include 'Databricks Certified Data Scientist Professional'
      '583499') --added by Tilak to include 'Databricks Certified Generative AI Engineer Associate'
    -- and learner_branch_code = 'DBK_EMP'
)
,
data as (
  select
    f.hire_date,
    f.tenure,
    f.workday_name,
    f.job_profile,
    f.manager_hierarchy_path,
    f.manager_hierarchy_path_name,
    f.businessTitle,
    f.primaryWorkEmail,
    f.1st_level_manager_name,
    f.1st_level_manager,
    f.2nd_level_manager_name,
    f.2nd_level_manager,
    f.3rd_level_manager_name,
    f.3rd_level_manager,
    f.4th_level_manager_name,
    f.4th_level_manager,
    f.5th_level_manager_name,
    f.5th_level_manager,
    f.6th_level_manager_name,
    f.6th_level_manager,
    f.manager,
    collect_set(
      case
        when credential_name ilike '%data engineer%' then credential_name
      end
    ) as de_certs,
    size(
      collect_set(
        case
          when credential_name ilike '%data engineer%' then credential_name
        end
      )
    ) as de_certs_count,
    case
      when size(
        collect_set(
          case
            when credential_name ilike '%data engineer%' then credential_name
          end
        )
      ) > 0 then 1
      else 0
    end as de_certified_flag,
    collect_set(
      case
        when credential_name ilike '%data engineer%' then issued_on
      end
    ) as de_certs_dates,
    collect_set(
      case
        when (credential_name ilike '%machine learning%' or credential_name ilike '%data scientist%') then credential_name
      end
    ) as ml_certs,
    size(
      collect_set(
        case
          when (credential_name ilike '%machine learning%' or credential_name ilike '%data scientist%') then credential_name
        end
      )
    ) as ml_certs_count,
    case
      when size(
        collect_set(
          case
            when (credential_name ilike '%machine learning%' or credential_name ilike '%data scientist%') then credential_name
          end
        )
      ) > 0 then 1
      else 0
    end as ml_certified_flag,
    collect_set(
      case
        when (credential_name ilike '%machine learning%' or credential_name ilike '%data scientist%') then issued_on
      end
    ) as ml_certs_dates,
    collect_set(
      case
        when (credential_name ilike '%Generative AI%') then credential_name
      end
    ) as gen_ai_certs,
    size(
      collect_set(
        case
          when (credential_name ilike '%Generative AI%') then credential_name
        end
      )
    ) as gen_ai_certs_count,
    case
      when size(
        collect_set(
          case
            when (credential_name ilike '%Generative AI%') then credential_name
          end
        )
      ) > 0 then 1
      else 0
    end as gen_ai_certified_flag,
    collect_set(
      case
        when (credential_name ilike '%Generative AI%') then issued_on
      end
    ) as gen_ai_certs_dates,
    collect_set(
      case
        when nvl(group_id, 'Unknown') not in ('331743', '353856', '357057', '371215','227970','583499') then credential_name
      end
    ) as non_de_ml_certs,
    size(
      collect_set(
        case
          when nvl(group_id, 'Unknown') not in ('331743', '353856', '357057', '371215','227970','583499') then credential_name
        end
      )
    ) as non_de_ml_certs_count,
    case
      when size(
        collect_set(
          case
            when nvl(group_id, 'Unknown') not in ('331743', '353856', '357057', '371215','227970','583499') then credential_name
          end
        )
      ) > 0 then 1
      else 0
    end as non_de_ml_certified_flag
  from
    fe_cert_hc f
    left join all_certs c on (sha2(lower(f.primaryWorkEmail), 256) = c.learner_email_hash
    or sha2(lower(f.primaryWorkEmail), 256) = c.learner_alternate_email_hash)
  -- where
  --   1 = 1 
  group by
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8
    ,9,10,11,12,13,14,15,16,17,18,19,20,21
) 

,
final_data as (
select
  *,
  case
    when (nvl(manager_hierarchy_path_name, "Unknown") ilike '%jason%martin%'
    and de_certified_flag = 1) then 1
    when (nvl(manager_hierarchy_path_name, "Unknown") ilike '%john%young%'
    and (de_certified_flag = 1
    or ml_certified_flag = 1 or gen_ai_certified_flag = 1)) then 1
    when (nvl(manager_hierarchy_path_name, "Unknown") not ilike '%jason%martin%'
    and de_certified_flag = 1
    and (ml_certified_flag = 1 or gen_ai_certified_flag = 1)) then 1
  end as certified_flag,
  case
    when (nvl(manager_hierarchy_path_name, "Unknown") ilike '%jason%martin%'
    and de_certified_flag = 1) then array_min(de_certs_dates)
    when (nvl(manager_hierarchy_path_name, "Unknown") ilike '%john%young%'
    and (de_certified_flag = 1
    or ml_certified_flag = 1 or gen_ai_certified_flag = 1)) then array_min(transform(arrays_zip(ml_certs_dates, de_certs_dates, gen_ai_certs_dates), x -> least(x.ml_certs_dates, x.de_certs_dates, x.gen_ai_certs_dates)))
    when (nvl(manager_hierarchy_path_name, "Unknown") not ilike '%jason%martin%'
    and de_certified_flag = 1
    and (ml_certified_flag = 1 or gen_ai_certified_flag = 1)) then greatest(array_min(ml_certs_dates), array_min(de_certs_dates), array_min(gen_ai_certs_dates))
  end as certified_date
  ,
  case
    when nvl(manager_hierarchy_path_name, "Unknown") ilike '%john%young%' then 'DE Cert or ML or GenAI cert'
    when nvl(manager_hierarchy_path_name, "Unknown") ilike '%jason%martin%' then 'DE Cert'
    else 'DE and ML or GenAI Cert' end as requirement


from
  data 
  )
-- ,
-- all_data as (
  select 
    hire_date,
    tenure,
    workday_name,
    job_profile,
    manager_hierarchy_path,
    manager_hierarchy_path_name,
    1st_level_manager_name,
    1st_level_manager,
    2nd_level_manager_name,
    2nd_level_manager,
    3rd_level_manager_name,
    3rd_level_manager,
    4th_level_manager_name,
    4th_level_manager,
    5th_level_manager_name,
    5th_level_manager,
    6th_level_manager_name,
    6th_level_manager,
    manager,
    businessTitle,
    primaryWorkEmail,
    case when businesstitle ilike '%specialist%solution%' then 'Vida Ha'
    when businesstitle ilike '%delivery%solution%' then 'Nicholas Cochran'
    when (businesstitle ilike any ('%solution%architect%','%solution%engineer%') and businesstitle not ilike '%resident%' and businesstitle not ilike '%partner%' ) then 'Caryl Yuhas'
    when businesstitle ilike '%technical%services%'  then 'Rathna Sundaralingam'
    else 'Other' end as practice_lead,
    case when size(de_certs)=0 then array('None') else de_certs end as de_certs,
    de_certs_count,
    de_certified_flag,
    case when size(ml_certs)=0 then array('None') else ml_certs end as ml_certs,
    ml_certs_count,
    ml_certified_flag,
    case when size(gen_ai_certs)=0 then array('None') else gen_ai_certs end as gen_ai_certs,
    gen_ai_certs_count,
    gen_ai_certified_flag,
    case when size(non_de_ml_certs)=0 then array('None') else non_de_ml_certs end as non_de_ml_certs,
    non_de_ml_certs_count,
    non_de_ml_certified_flag,
    nvl(certified_flag,0) as certified_flag,
    -- cert_earliest_expiry_date,
    requirement,
    certified_date

  from final_data
''')

# COMMAND ----------

get_certified_gold = add_gold_metadata(get_certified_df)

# COMMAND ----------

get_certified_gold.createOrReplaceTempView('get_certified')

# COMMAND ----------

get_certified_manager_df = spark.sql('''
with fe_cert_hc as (
  with final AS (
    select
      wd.hire_date,
      datediff(MONTH, hire_Date, current_date()) as tenure,
      wd.Name as workday_name,
      wd.job_profile_start_date,
      wd.job_profile,
      wd.1st_level_manager_name,
      wd.1st_level_manager,
      wd.2nd_level_manager_name,
      wd.2nd_level_manager,
      wd.3rd_level_manager_name,
      wd.3rd_level_manager,
      wd.4th_level_manager_name,
      wd.4th_level_manager,
      wd.5th_level_manager_name,
      wd.5th_level_manager,
      wd.6th_level_manager_name,
      wd.6th_level_manager,
      wd.manager_hierarchy_path,
      wd.manager_hierarchy_path_name,
      wd.businessTitle,
      wd.primaryWorkEmail,
      wd.Termination_Date,
      wd.status,
      wd.manager
    -- from
    --   liam.wd wd
    from main.field_learning_enablement.workday wd
    where processDate = (select max(processDate) from main.field_learning_enablement.workday)
    and Worker_Type='Employee'
    and status = 'true'
    and (nvl(name, "Unknown") in (select distinct manager from main.field_learning_enablement.workday wd where wd.Worker_Type='Employee'and wd.status = 'true' and wd.processDate = (select max(processDate) from main.field_learning_enablement.workday)) or primaryWorkEmail = 'pritesh.patel@databricks.com')
    and manager_hierarchy_path_name ilike any (
      '%jeff traylor%',
      '%david hackett%',
      '%jason martin%',
      '%toby balfre%',
      '%nicholas eayrs%',
      '%david totten%'
      -- '%richard garris%'
    )
    and manager_hierarchy_path_name not ilike ('%victor cheah%')
  ),
  pre as (
    select
      *
    from
      final
  )
  select
    *,
    case
      when businessTitle in (
        'Lead Specialist Solutions Architect',
        --SSA
        'Principal Specialist Solutions Architect',
        --SSA
        'Specialist Solutions Architect',
        --SSA
        'Sr. Specialist Solutions Architect' --SSA
      ) then 0
      else case
        when tenure < 6 then 1
        else 0
      end
    end as exclude_flag
  from
    pre
  where
    1 = 1 
)
,

all_certs as (
  select
    *
  from
    main.field_learning_enablement.accredible_credentials
  where
    processdate = (
      Select
        max(processdate)
      from
        main.field_learning_enablement.accredible_credentials
    )
    and is_expired = 'false'
    and group_id in (
      '371215',
      '364119',
      '357057',
      '353856',
      '331743',
      '229201',
      '227965',
      '227818',
      '227970', --added by Janam on 6.9 to incldue 'Databricks Certified Data Scientist Professional'
      '583499') --added by Tilak to include 'Databricks Certified Generative AI Engineer Associate'
    -- and learner_branch_code = 'DBK_EMP'
),
data as (
  select
    f.hire_date,
    f.tenure,
    f.workday_name,
    f.job_profile,
    f.manager_hierarchy_path,
    f.manager_hierarchy_path_name,
    f.businessTitle,
    f.primaryWorkEmail,
    f.1st_level_manager_name,
    f.1st_level_manager,
    f.2nd_level_manager_name,
    f.2nd_level_manager,
    f.3rd_level_manager_name,
    f.3rd_level_manager,
    f.4th_level_manager_name,
    f.4th_level_manager,
    f.5th_level_manager_name,
    f.5th_level_manager,
    f.6th_level_manager_name,
    f.6th_level_manager,
    f.manager,
    collect_set(
      case
        when credential_name ilike '%data engineer%' then credential_name
      end
    ) as de_certs,
    size(
      collect_set(
        case
          when credential_name ilike '%data engineer%' then credential_name
        end
      )
    ) as de_certs_count,
    case
      when size(
        collect_set(
          case
            when credential_name ilike '%data engineer%' then credential_name
          end
        )
      ) > 0 then 1
      else 0
    end as de_certified_flag,
    collect_set(
      case
        when credential_name ilike '%data engineer%' then issued_on
      end
    ) as de_certs_dates,
    collect_set(
      case
        when (credential_name ilike '%machine learning%' or credential_name ilike '%data scientist%') then credential_name
      end
    ) as ml_certs,
    size(
      collect_set(
        case
          when (credential_name ilike '%machine learning%' or credential_name ilike '%data scientist%') then credential_name
        end
      )
    ) as ml_certs_count,
    case
      when size(
        collect_set(
          case
            when (credential_name ilike '%machine learning%' or credential_name ilike '%data scientist%') then credential_name
          end
        )
      ) > 0 then 1
      else 0
    end as ml_certified_flag,
    collect_set(
      case
        when (credential_name ilike '%machine learning%' or credential_name ilike '%data scientist%') then issued_on
      end
    ) as ml_certs_dates,
    collect_set(
      case
        when (credential_name ilike '%Generative AI%') then credential_name
      end
    ) as gen_ai_certs,
    size(
      collect_set(
        case
          when (credential_name ilike '%Generative AI%') then credential_name
        end
      )
    ) as gen_ai_certs_count,
    case
      when size(
        collect_set(
          case
            when (credential_name ilike '%Generative AI%') then credential_name
          end
        )
      ) > 0 then 1
      else 0
    end as gen_ai_certified_flag,
    collect_set(
      case
        when (credential_name ilike '%Generative AI%') then issued_on
      end
    ) as gen_ai_certs_dates,
    collect_set(
      case
        when nvl(group_id, 'Unknown') not in ('331743', '353856', '357057', '371215','227970', '583499') then credential_name
      end
    ) as non_de_ml_certs,
    size(
      collect_set(
        case
          when nvl(group_id, 'Unknown') not in ('331743', '353856', '357057', '371215','227970', '583499') then credential_name
        end
      )
    ) as non_de_ml_certs_count,
    case
      when size(
        collect_set(
          case
            when nvl(group_id, 'Unknown') not in ('331743', '353856', '357057', '371215','227970', '583499') then credential_name
          end
        )
      ) > 0 then 1
      else 0
    end as non_de_ml_certified_flag
  from
    fe_cert_hc f
    left join all_certs c on (sha2(lower(f.primaryWorkEmail), 256) = c.learner_email_hash
    or sha2(lower(f.primaryWorkEmail), 256) = c.learner_alternate_email_hash)
  -- where
  --   1 = 1 
  group by
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8
    ,9,10,11,12,13,14,15,16,17,18,19,20,21
) 

,
final_data as (
select
  *,
  case
    when (ml_certified_flag = 1 or
    de_certified_flag = 1 or gen_ai_certified_flag = 1) then 1
    else 0
  end as certified_flag,
  case
    when  (de_certified_flag = 1
    or ml_certified_flag = 1 or gen_ai_certified_flag = 1) then array_min(transform(arrays_zip(ml_certs_dates, de_certs_dates, gen_ai_certs_dates), x -> least(x.ml_certs_dates, x.de_certs_dates, x.gen_ai_certs_dates)))
  end as certified_date
  ,
  'DE or ML or GenAI Cert' as requirement

from
  data 
  )
  select 
    hire_date,
    tenure,
    workday_name,
    job_profile,
    manager_hierarchy_path,
    manager_hierarchy_path_name,
    1st_level_manager_name,
    1st_level_manager,
    2nd_level_manager_name,
    2nd_level_manager,
    3rd_level_manager_name,
    3rd_level_manager,
    4th_level_manager_name,
    4th_level_manager,
    5th_level_manager_name,
    5th_level_manager,
    6th_level_manager_name,
    6th_level_manager,
    manager,
    businessTitle,
    primaryWorkEmail,
    case when businesstitle ilike '%specialist%solution%' then 'Vida Ha'
    when businesstitle ilike '%delivery%solution%' then 'Nicholas Cochran'
    when (businesstitle ilike any ('%solution%architect%','%solution%engineer%') and businesstitle not ilike '%resident%' and businesstitle not ilike '%partner%' ) then 'Caryl Yuhas'
    when businesstitle ilike '%technical%services%'  then 'Rathna Sundaralingam'
    else 'Other' end as practice_lead,
    case when size(de_certs)=0 then array('None') else de_certs end as de_certs,
    de_certs_count,
    de_certified_flag,
    case when size(ml_certs)=0 then array('None') else ml_certs end as ml_certs,
    ml_certs_count,
    ml_certified_flag,
    case when size(gen_ai_certs)=0 then array('None') else gen_ai_certs end as gen_ai_certs,
    gen_ai_certs_count,
    gen_ai_certified_flag,
    case when size(non_de_ml_certs)=0 then array('None') else non_de_ml_certs end as non_de_ml_certs,
    non_de_ml_certs_count,
    non_de_ml_certified_flag,
    nvl(certified_flag,0) as certified_flag,
    -- cert_earliest_expiry_date,
    requirement,
    certified_date

  from final_data
                                     
''')

# COMMAND ----------

get_certified_manager_df.createOrReplaceTempView('get_certified_manager')

# COMMAND ----------

# DBTITLE 1,Employee Certification Tracker Query
get_certified_met_by_process_date_df = spark.sql('''
  with fe_cert_hc as (
    with final AS (
      select
        wd.hire_date,
        datediff(MONTH, hire_Date, current_date()) as tenure,
        wd.Name as workday_name,
        wd.job_profile_start_date,
        wd.job_profile,
        wd.1st_level_manager_name,
        wd.1st_level_manager,
        wd.2nd_level_manager_name,
        wd.2nd_level_manager,
        wd.3rd_level_manager_name,
        wd.3rd_level_manager,
        wd.4th_level_manager_name,
        wd.4th_level_manager,
        wd.5th_level_manager_name,
        wd.5th_level_manager,
        wd.6th_level_manager_name,
        wd.6th_level_manager,
        wd.manager_hierarchy_path,
        wd.manager_hierarchy_path_name,
        wd.businessTitle,
        wd.primaryWorkEmail,
        wd.Termination_Date,
        wd.status,
        wd.manager
      from
        main.field_learning_enablement.workday wd
      where
        Worker_Type = 'Employee'
        and processDate = (select max(processDate) from main.field_learning_enablement.workday)
        and status = 'true'
        and (nvl(name, "Unknown") not in (select distinct manager from main.field_learning_enablement.workday wd where wd.Worker_Type='Employee'and wd.status = 'true' and wd.processDate = (select max(processDate) from main.field_learning_enablement.workday)) or primaryWorkEmail = 'pritesh.patel@databricks.com')
        and manager_hierarchy_path_name ilike any (
          '%jeff traylor%',
          '%david hackett%',
          '%jason martin%',
          '%toby balfre%',
          '%nicholas eayrs%',
          '%david totten%' -- '%richard garris%'
        )
        and manager_hierarchy_path_name not ilike ('%victor cheah%')
    ),
    pre as (
      select
        *
      from
        final
      where
        businessTitle IN (
          'Solutions Architect',
          'Resident Solutions Architect',
          'Sr. Solutions Architect',
          'Delivery Solutions Architect',
          'Sr. Delivery Solutions Engineer',
          'Sr Delivery Solutions Engineer',
          'Senior Delivery Solutions Engineer',
          'Specialist Solutions Architect',
          'Sr. Solutions Consultant',
          'Solutions Consultant',
          'Sr. Specialist Solutions Architect',
          'Sr. Delivery Solutions Architect',
          'Sr. Solutions Engineer',
          'Senior Solution Engineer',
          'Sr Solutions Engineer',
          'Sr. Technical Services Engineer',
          'Sr. Technical Advisor, Financial Services',
          'Technical Services Engineer',
          'Sr Solutions Consultant',
          'Sr. Resident Solutions Architect',
          'Senior Solutions Engineer',
          'Senior Specialist Solutions Architect',
          'Senior Solutions Consultant',
          'Senior Specialist Solutions Engineer',
          'Senior Partner Solutions Engineer',
          'Cloud Technologist',
          'Technical Services Specialist',
          'Solutions Engineer',
          'Delivery Solutions Engineer',
          'Sr. Partner Solutions Architect',
          'Sr. Global Practice Tech Lead, Customer Success Engineering',
          -- 'Sr Engagement Manager',
          'Partner Solutions Architect',
          'Lead Specialist Solutions Architect',
          -- 'Engagement Manager',
          'Lead Solutions Architect',
          'Sr. Specialist Solutions Engineer',
          'Specialist Solutions Engineer',
          -- 'Sr. Engagement Manager',
          'Principal Specialist Solutions Architect',
          'Senior Strategic Solutions Architect',
          'Sr Solutions Architect',
          'Principal Solutions Architect',
          'Lead Resident Solutions Architect',
          'Practice Lead Resident Solutions Architect',
          'Senior Resident Solutions Architect',
          -- 'Senior Engagement Manager',
          'Sr. Specialist Solutons Architect',
          'Sr Specialist Solutions Architect',
          'Snr. Solutions Architect',
          'Lead Delivery Solutions Architect',
          'Lead Product Specialist Solution Architect - Data Engineering',
          'Resident Solution Architect',
          'Delivery Solution Architect',
          'Sr Resident Solutions Architect',
          'Lead Partner Solutions Architect',
          'Specialist Solutions Architect - Financial Services',
          'Specialist Solutions Architect - Data Science & Machine Learning',
          'Solution Architect',
          'Sr. Technical Solutions Engineer',
          'Solution Architect, ANZ',
          'Sr. Strategic Solutions Architect',
          'Senior Solutions Architect, Digital Native Business',
          'Sr Specialist Solutions Engineer',
          'Partner Solutions Architect, Lead for GSI',
          'Senior Solutions Architect',
          'Data & AI Strategist',
          'Senior Delivery Solutions Architect',
          'Lead Product Specialist Solutions Architect',
          'Sr Delivery Solutions Architect',
          'Specialist Solutions Architect - Data Engineering',
          'Sr. Specialist Solutions Engineer - Data Engineering',
          'Associate Customer Data Engineer',
          'Customer Data Engineer',
          'Sr. Customer Data Engineer',
          'Delivery Solutions Architect, Financial Services', 
          'Sr. Scale Solution Engineer'
          -- ,
          -- 'Specialist Solutions Architect, Field Engineering'
        )
    )
    select
      *,
      case
        when businessTitle in (
          'Lead Specialist Solutions Architect',
          --SSA
          'Principal Specialist Solutions Architect',
          --SSA
          'Specialist Solutions Architect',
          --SSA
          'Sr. Specialist Solutions Architect' --SSA
        ) then 0
        else case
          when tenure < 6 then 1
          else 0
        end
      end as exclude_flag
    from
      pre
    where
      1 = 1
  ),
  all_certs as (
    select
      *
    from
      main.field_learning_enablement.accredible_credentials
    where
      processdate >= '2023-05-07' 
      and is_expired = 'false'
      and group_id in (
        '371215',
        '364119',
        '357057',
        '353856',
        '331743',
        '229201',
        '227965',
        '227818',
        '227970',
        '583499'
      )
      -- and learner_branch_code = 'DBK_EMP'
  ),
  processDates as (
  select distinct processDate from all_certs
  ),

  processDate_hc_pre as (
    select
      processDate, count(*) as total_hc
      from main.field_learning_enablement.workday w
      inner join fe_cert_hc f on w.primaryWorkEmail = f.primaryWorkEmail
      where processDate>='2023-05-25'
      group by 1
      
  )
  ,
  processDate_hc as (
  select 
    p.processDate,
    case 
      when p.processDate < '2023-05-25' then 1152
      when p.processDate >= '2023-05-25' then h.total_hc
      end as total_hc
  from processDates p 
  left join processDate_hc_pre h on p.processDate = h.processDate
  )
  ,
  data as (
    select
      f.hire_date,
      f.tenure,
      f.workday_name,
      f.job_profile,
      f.manager_hierarchy_path,
      f.manager_hierarchy_path_name,
      f.businessTitle,
      f.primaryWorkEmail,
      f.1st_level_manager_name,
      f.1st_level_manager,
      f.2nd_level_manager_name,
      f.2nd_level_manager,
      f.3rd_level_manager_name,
      f.3rd_level_manager,
      f.4th_level_manager_name,
      f.4th_level_manager,
      f.5th_level_manager_name,
      f.5th_level_manager,
      f.6th_level_manager_name,
      f.6th_level_manager,
      f.manager,
      c.processDate,
      case
        when size(
          collect_set(
            case
              when credential_name ilike '%data engineer%' then credential_name
            end
          )
        ) > 0 then 1
        else 0
      end as de_certified_flag,
      case
        when size(
          collect_set(
            case
              when (credential_name ilike '%machine learning%' or credential_name ilike '%data scientist%') then credential_name
            end
          )
        ) > 0 then 1
        else 0
      end as ml_certified_flag,
      case
        when size(
          collect_set(
            case
              when (credential_name ilike '%Generative AI%') then credential_name
            end
          )
        ) > 0 then 1
        else 0
      end as gen_ai_certified_flag,
      array_sort(collect_set(
        case
          when credential_name ilike '%data engineer%' then struct(credential_name,issued_on)
        end
      ), (a, b) -> DATEDIFF(a.issued_on, b.issued_on)) as de_certs,
      array_sort(collect_set(
        case
          when (credential_name ilike '%machine learning%' or credential_name ilike '%data scientist%' or credential_name ilike '%Generative AI%') then struct(credential_name,issued_on)
        end
      ), (a, b) -> DATEDIFF(a.issued_on, b.issued_on)) as ml_certs,
      array_sort(collect_set(
        case
          when (credential_name ilike '%Generative AI%') then struct(credential_name,issued_on)
        end
      ), (a, b) -> DATEDIFF(a.issued_on, b.issued_on)) as gen_ai_certs
    from
      fe_cert_hc f
      inner join all_certs c on (
        sha2(lower(f.primaryWorkEmail), 256) = c.learner_email_hash
        or sha2(lower(f.primaryWorkEmail), 256) = c.learner_alternate_email_hash
      )
    group by
          1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22
  )


  ,
  pre_data as (
    select
      *,
      case
        when ml_certified_flag = 1 then to_date(ml_certs[0].issued_on) end as ml_first_issued_on,
      case
        when de_certified_flag = 1 then to_date(de_certs[0].issued_on) end as de_first_issued_on,
      case
        when gen_ai_certified_flag = 1 then to_date(ml_certs[0].issued_on) end as gen_ai_first_issued_on,
      case
        when (
          nvl(manager_hierarchy_path_name, "Unknown") ilike '%jason%martin%'
          and de_certified_flag = 1
        ) then 1
        when (nvl(manager_hierarchy_path_name, "Unknown") ilike '%john%young%'
          and (de_certified_flag = 1
          or ml_certified_flag = 1 or gen_ai_certified_flag = 1)) then 1
        when (
          nvl(manager_hierarchy_path_name, "Unknown") not ilike '%jason%martin%'
          and de_certified_flag = 1
          and (ml_certified_flag = 1 or gen_ai_certified_flag = 1)
        ) then 1
      end as certified_flag
    from
      data
  ) 

  ,
  final_data as (
    select
      hire_date,
      tenure,
      workday_name,
      job_profile,
      manager_hierarchy_path,
      manager_hierarchy_path_name,
      businessTitle,
      primaryWorkEmail,
      1st_level_manager_name,
      1st_level_manager,
      2nd_level_manager_name,
      2nd_level_manager,
      3rd_level_manager_name,
      3rd_level_manager,
      4th_level_manager_name,
      4th_level_manager,
      5th_level_manager_name,
      5th_level_manager,
      6th_level_manager_name,
      6th_level_manager,
      manager,
      processDate,
      certified_flag,
      ml_first_issued_on,
      de_first_issued_on,
      gen_ai_first_issued_on,
      case
        when certified_flag = 1 and nvl(manager_hierarchy_path_name, "Unknown") ilike '%jason%martin%' then de_first_issued_on 
        when certified_flag = 1 and nvl(manager_hierarchy_path_name, "Unknown") not ilike '%jason%martin%' then greatest(de_first_issued_on, ml_first_issued_on, gen_ai_first_issued_on)  
      end as issued_on,
      transform(ml_certs, x->x.credential_name) as ml_certs,
      transform(de_certs, x->x.credential_name) as de_certs,
      transform(gen_ai_certs, x->x.credential_name) as gen_ai_certs

    from
      pre_data
    where certified_flag = 1
  )

  select 
    hire_date,
    tenure,
    workday_name,
    job_profile,
    manager_hierarchy_path,
    manager_hierarchy_path_name,
    businessTitle,
    primaryWorkEmail,
    1st_level_manager_name,
    1st_level_manager,
    2nd_level_manager_name,
    2nd_level_manager,
    3rd_level_manager_name,
    3rd_level_manager,
    4th_level_manager_name,
    4th_level_manager,
    5th_level_manager_name,
    5th_level_manager,
    6th_level_manager_name,
    6th_level_manager,
    manager,
    p.total_hc,
    f.processDate as date_processed,
    certified_flag,
    issued_on,
    case when size(de_certs)=0 then array('None') else de_certs end as de_certs,
    case when size(ml_certs)=0 then array('None') else ml_certs end as ml_certs,
    case when size(gen_ai_certs)=0 then array('None') else gen_ai_certs end as gen_ai_certs,
    de_first_issued_on, 
    ml_first_issued_on,
    gen_ai_first_issued_on,
    d.is_month_end,
    d.is_fiscal_quarter_end,
    d.is_fiscal_year_end,
    case
      when d.day_of_week = 6 then true
      else false
    end as is_end_of_week
  from final_data f
  inner join main.it_core_dim.dim_dates d on f.issued_on = d.date
  left join processDate_hc p on p.processDate = f.processDate


''')

# COMMAND ----------

get_certified_met_by_process_date_gold = add_gold_metadata(get_certified_met_by_process_date_df)

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC ## Ongoing Learning Dataset

# COMMAND ----------

# DBTITLE 1,Manager Pathway Analysis Query
ongoing_learning_df = spark.sql('''
  with managers as (
    select
      distinct Manager_Email
    from
      -- users.liam_clifford.wd
      main.field_learning_enablement.workday
    where
      Status
      and worker_type = 'Employee'
      and manager_hierarchy_path_name ilike '%arsalan%'
      -- and primaryWorkEmail in (select distinct primaryWorkEmail from get_certified)
      and processdate = (select max(processDate) from main.field_learning_enablement.workday)
  ),
  pre as (
    select
      w.*,
      case
        when manager_hierarchy_path ilike '%aden.lai@databricks.com%' THEN "Aden Lai"
        when manager_hierarchy_path ilike '%ajay.singh@databricks.com%' THEN "Ajay Singh"
        when manager_hierarchy_path ilike '%chris.olenik@databricks.com%' THEN "Christopher Olenik"
        when manager_hierarchy_path ilike '%erick.mechler@databricks.com%' THEN "Erick Mechler"
        when manager_hierarchy_path ilike '%keita.nozaki@databricks.com%' THEN "Keita Nozaki"
        when manager_hierarchy_path ilike '%kunal.taneja@databricks.com%' THEN "Kunal Taneja"
        when manager_hierarchy_path ilike '%marcelo.sales@databricks.com%' THEN "Marcelo Sales"
        when manager_hierarchy_path ilike '%matthias.ingerfeld@databricks.com%' THEN "Matthias Ingerfeld"
        when manager_hierarchy_path ilike '%mary.downey@databricks.com%' THEN "Mary Downey"
        when manager_hierarchy_path ilike '%michael.riley@databricks.com%' THEN "Michael Riley"
        when manager_hierarchy_path ilike '%nathan.steiner@databricks.com%' THEN "Nathan Steiner"
        when manager_hierarchy_path ilike '%nicolas.maillard@databricks.com%' THEN "Nicolas Maillard"
        when manager_hierarchy_path ilike '%raela@databricks.com Raela%' THEN "Wang"
        when manager_hierarchy_path ilike '%ravi.dharnikota@databricks.com%' THEN "Ravi Dharnikota"
        when manager_hierarchy_path ilike '%richard.shaw@databricks.com%' THEN "Richard Shaw"
        when manager_hierarchy_path ilike '%steve.rigo@databricks.com%' THEN "Steve Rigo"
        when manager_hierarchy_path ilike '%alex.narkaj@databricks.com%' THEN "Alex Narkaj"
        when manager_hierarchy_path ilike '%brooke.wenig@databricks.com%' THEN "Brooke Wenig"
        when manager_hierarchy_path ilike '%john.young@databricks.com%' THEN "John Young"
        when manager_hierarchy_path ilike '%stuart.fenwick@databricks.com%' THEN "Stuart Fenwick"
        when manager_hierarchy_path ilike '%takehisa.ueda@databricks.com%' THEN "Takehisa Ueda"
        when manager_hierarchy_path ilike '%victor.cheah@databricks.com%' THEN "Victor Cheah"
        when manager_hierarchy_path ilike '%caryl.yuhas@databricks.com%' THEN "Caryl Yuhas"
        when manager_hierarchy_path ilike '%nick.cochran@databricks.com%' THEN "Nick Cochran"
        when manager_hierarchy_path ilike '%rathna.sundaralingam@databricks.com%' THEN "Rathna Sundaralingam"
        when manager_hierarchy_path ilike '%vida.ha@databricks.com%' THEN "Vida Ha"
        when manager_hierarchy_path ilike '%david.hackett@databricks.com%' THEN "David Hackett"
        when manager_hierarchy_path ilike '%david.totten@databricks.com%' THEN "David Totten"
        when manager_hierarchy_path ilike '%jeff.traylor@databricks.com%' THEN "Jeff Traylor"
        when manager_hierarchy_path ilike '%nick.eayrs@databricks.com%' THEN "Nicholas Eayrs"
        when manager_hierarchy_path ilike '%toby.balfre@databricks.com%' THEN "Toby Balfre"
        when manager_hierarchy_path ilike '%jason.martin@databricks.com%' THEN "Jason Martin"
        when manager_hierarchy_path ilike '%marcelo.sales%@atabricks.com%' THEN "Marcelo Sales"
        when manager_hierarchy_path ilike '%raela@databricks.com%' THEN "Raela Wang"
        when manager_hierarchy_path ilike '%kyoungwoon.chang@databricks.com%' THEN "Kyoungwoon Chang"
        when manager_hierarchy_path ilike '%jeff.traylor@databricks.com%' THEN "Jeff Traylor"
        end as fe_org_leader,
      case
        when w.primaryWorkEmail in (
          select
            Manager_Email
          from
            managers
        ) then 1
        else 0
      end as people_manager_flag
    from
      --users.liam_clifford.wd w -- left join managers m on w.manager=m.manager
      main.field_learning_enablement.workday w
    where
      Status
      and worker_type = 'Employee'
      and manager_hierarchy_path_name ilike '%arsalan%' -- group by 1
  ),
  avg_time_pre_rank AS (
    select
      id,
      expected_time_to_complete_in_seconds,
      rank() over (
        partition by id
        order by
          expected_time_to_complete_in_seconds nulls last,
          category_code desc
      ) as rank
    from
      main.it_training_silver.docebo_courses
    where
      processDate = (
        select
          max(processDate)
        from
          main.it_training_silver.docebo_courses
      )
  ),
  avg_time AS (
    select
      *
    from
      avg_time_pre_rank
    where
      rank = 1
  ),
  sp_enrollments AS (
    select
      processdate,
      learner_user_id,
      learner_email,
      audience,
      course_code,
      course_name,
      course_type,
      course_id,
      category_code,
      status as enrollment_status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      enrolled_timestamp,
      completed_timestamp,
      source,
      d.fiscal_year_quarter as fq2,
      d2.fiscal_year_quarter as completed_fq2,
      cast(d.calendar_month as INT) as month,
      cast(d.calendar_year as INT) as year,
      cast(d.fiscal_year as INT) as fiscalYear,
      d.fiscal_quarter_start_date as qtr_start_date,
      d.fiscal_quarter_end_date as qtr_end_date,
      t.expected_time_to_complete_in_seconds
    from
      main.field_learning_enablement.self_paced_enrollments e
      inner join main.it_core_dim.dim_dates d on e.enrolled_timestamp::date=d.date 
      left join main.it_core_dim.dim_dates d2 on e.completed_timestamp::date=d2.date 
      left join avg_time t on e.course_id = t.id
    where
      e.source = 'Docebo' --  and e.category_code in ('PART','ACAD','FENG/CUSU','FENG')
      and e.course_id not in (723, 721, 724, 687, 1182)
      -- and e.course_code ilike ('%-SLP-%')
      and e.course_code not ilike ('%DNR')
      and e.learner_branch_code in ('DBK_EMP')
      and e.processdate = (
        select
          max(processdate)
        from
          main.field_learning_enablement.self_paced_enrollments
      )
      -- and e.status = 'completed'
      and e.category_code != 'FENG-INVESTech'
  ),
  ilt_enrollments AS (
    select
      processdate,
      learner_user_id,
      learner_email,
      audience,
      course_code,
      course_name,
      course_type,
      course_id,
      category_code,
      status as enrollment_status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      enrolled_timestamp,
      completed_timestamp,
      source,
      d.fiscal_year_quarter as fq2,
      d2.fiscal_year_quarter as completed_fq2,
      cast(d.calendar_month as INT) as month,
      cast(d.calendar_year as INT) as year,
      cast(d.fiscal_year as INT) as fiscalYear,
      d.fiscal_quarter_start_date as qtr_start_date,
      d.fiscal_quarter_end_date as qtr_end_date,
      t.expected_time_to_complete_in_seconds
    from
      main.field_learning_enablement.ilt_enrollments e
      inner join main.it_core_dim.dim_dates d on e.enrolled_timestamp::date=d.date 
      left join main.it_core_dim.dim_dates d2 on e.completed_timestamp::date=d2.date 
      left join avg_time t on e.course_id = t.id --  where e.category_code in ('PART','ACAD','FENG/CUSU','FENG')
    where
      e.source = 'Docebo'
      and e.learner_branch_code in ('DBK_EMP')
      and e.processdate = (
        select
          max(processdate)
        from
          main.field_learning_enablement.ilt_enrollments
      )
      -- and e.status = 'completed'
      and e.course_name is not null

  ),
  invest_enrollments as (
    select
      processdate,
      learner_user_id,
      learner_email,
      'Employee' as audience,
      course_code,
      course_name,
      course_type,
      course_id,
      'INVEST' as category_code,
      status as enrollment_status,
      enrolled_timestamp :: date as enrolled_date,
      completed_timestamp :: date as completed_date,
      enrolled_timestamp,
      completed_timestamp,
      'Invest' as source,
      d.fiscal_year_quarter as fq2,
      d2.fiscal_year_quarter as completed_fq2,
      cast(d.calendar_month as INT) as month,
      cast(d.calendar_year as INT) as year,
      cast(d.fiscal_year as INT) as fiscalYear,
      d.fiscal_quarter_start_date as qtr_start_date,
      d.fiscal_quarter_end_date as qtr_end_date,
      1200 as expected_time_to_complete_in_seconds
    from
      main.field_learning_enablement.invest_tech_all_enrollments e
      inner join main.it_core_dim.dim_dates d on e.enrolled_timestamp::date=d.date 
      left join main.it_core_dim.dim_dates d2 on e.completed_timestamp::date=d2.date 
    where
      processDate = (
        select
          max(processDate)
        from
          main.field_learning_enablement.invest_tech_all_enrollments
      )
    -- and status = 'completed'
  ),
  learner_enrollments as (
    select
      *
    from
      sp_enrollments
    union all
    select
      *
    from
      ilt_enrollments
    union all
    select
      *
    from
      invest_enrollments
  ),
  all_enrollments as (
    select
      e.* except (e.processdate, e.processDate)
    from
      learner_enrollments e
      join pre p on e.learner_email = p.primaryWorkEmail
  )

  select
    * 
  from
    all_enrollments
  where learner_email in (select distinct primaryWorkEmail from get_certified)
  order by
    learner_email,
    course_name                           
                                
                                
''')

# COMMAND ----------

ongoing_learning_df_gold = add_gold_metadata(ongoing_learning_df)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Learning Day Dates

# COMMAND ----------

# learning_day_dates = spark.sql('''
#   with pre as 
#     (select 
#       case
#         when array_contains(recipientList, 'aden.lai@databricks.com') THEN "Aden Lai"
#         when array_contains(recipientList, 'ajay.singh@databricks.com') THEN "Ajay Singh"
#         when array_contains(recipientList, 'chris.olenik@databricks.com') THEN "Christopher Olenik"
#         when array_contains(recipientList, 'erick.mechler@databricks.com') THEN "Erick Mechler"
#         when array_contains(recipientList, 'keita.nozaki@databricks.com') THEN "Keita Nozaki"
#         when array_contains(recipientList, 'kunal.taneja@databricks.com') THEN "Kunal Taneja"
#         when array_contains(recipientList, 'marcelo.sales@databricks.com') THEN "Marcelo Sales"
#         when array_contains(recipientList, 'matthias.ingerfeld@databricks.com') THEN "Matthias Ingerfeld"
#         when array_contains(recipientList, 'mary.downey@databricks.com') THEN "Mary Downey"
#         when array_contains(recipientList, 'michael.riley@databricks.com') THEN "Michael Riley"
#         when array_contains(recipientList, 'nathan.steiner@databricks.com') THEN "Nathan Steiner"
#         when array_contains(recipientList, 'nicolas.maillard@databricks.com') THEN "Nicolas Maillard"
#         when array_contains(recipientList, 'raela@databricks.com Raela') THEN "Wang"
#         when array_contains(recipientList, 'ravi.dharnikota@databricks.com') THEN "Ravi Dharnikota"
#         when array_contains(recipientList, 'richard.shaw@databricks.com') THEN "Richard Shaw"
#         when array_contains(recipientList, 'steve.rigo@databricks.com') THEN "Steve Rigo"
#         when array_contains(recipientList, 'alex.narkaj@databricks.com') THEN "Alex Narkaj"
#         when array_contains(recipientList, 'brooke.wenig@databricks.com') THEN "Brooke Wenig"
#         when array_contains(recipientList, 'john.young@databricks.com') THEN "John Young"
#         when array_contains(recipientList, 'stuart.fenwick@databricks.com') THEN "Stuart Fenwick"
#         when array_contains(recipientList, 'takehisa.ueda@databricks.com') THEN "Takehisa Ueda"
#         when array_contains(recipientList, 'victor.cheah@databricks.com') THEN "Victor Cheah"
#         when array_contains(recipientList, 'caryl.yuhas@databricks.com') THEN "Caryl Yuhas"
#         when array_contains(recipientList, 'nick.cochran@databricks.com') THEN "Nick Cochran"
#         when array_contains(recipientList, 'rathna.sundaralingam@databricks.com') THEN "Rathna Sundaralingam"
#         when array_contains(recipientList, 'vida.ha@databricks.com') THEN "Vida Ha"
#         when array_contains(recipientList, 'david.hackett@databricks.com') THEN "David Hackett"
#         when array_contains(recipientList, 'david.totten@databricks.com') THEN "David Totten"
#         when array_contains(recipientList, 'jeff.traylor@databricks.com') THEN "Jeff Traylor"
#         when array_contains(recipientList, 'nick.eayrs@databricks.com') THEN "Nicholas Eayrs"
#         when array_contains(recipientList, 'toby.balfre@databricks.com') THEN "Toby Balfre"
#         when array_contains(recipientList, 'jason.martin@databricks.com') THEN "Jason Martin"
#         when array_contains(recipientList, 'fieldeng-org-marcelo.sales@databricks.com') THEN "Marcelo Sales"
#         when array_contains(recipientList, 'raela@databricks.com') THEN "Raela Wang"
#         when array_contains(recipientList, 'kyoungwoon.chang@databricks.com') THEN "Kyoungwoon Chang"
#         end as fe_org_leader,
#       case 
#         when array_contains(recipientList, 'aden.lai@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'ajay.singh@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'chris.olenik@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'erick.mechler@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'keita.nozaki@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'kunal.taneja@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'marcelo.sales@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'matthias.ingerfeld@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'mary.downey@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'michael.riley@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'nathan.steiner@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'nicolas.maillard@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'raela@databricks.com	Tech') then  "GM"
#         when array_contains(recipientList, 'ravi.dharnikota@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'richard.shaw@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'steve.rigo@databricks.com') then 	"Tech GM"
#         when array_contains(recipientList, 'alex.narkaj@databricks.com') then 	"PS"
#         when array_contains(recipientList, 'brooke.wenig@databricks.com') then 	"PS"
#         when array_contains(recipientList, 'john.young@databricks.com') then 	"PS"
#         when array_contains(recipientList, 'stuart.fenwick@databricks.com') then 	"PS"
#         when array_contains(recipientList, 'takehisa.ueda@databricks.com') then 	"PS"
#         when array_contains(recipientList, 'victor.cheah@databricks.com') then 	"PS"
#         when array_contains(recipientList, 'caryl.yuhas@databricks.com') then 	"Practice Lead"
#         when array_contains(recipientList, 'nick.cochran@databricks.com') then 	"Practice Lead"
#         when array_contains(recipientList, 'rathna.sundaralingam@databricks.com') then 	"Practice Lead"
#         when array_contains(recipientList, 'vida.ha@databricks.com') then 	"Practice Lead"
#         when array_contains(recipientList, 'david.hackett@databricks.com') then 	"BU Leader"
#         when array_contains(recipientList, 'david.totten@databricks.com') then 	"BU Leader"
#         when array_contains(recipientList, 'jeff.traylor@databricks.com') then 	"BU Leader"
#         when array_contains(recipientList, 'nick.eayrs@databricks.com') then 	"BU Leader"
#         when array_contains(recipientList, 'toby.balfre@databricks.com') then 	"BU Leader"
#         when array_contains(recipientList, 'jason.martin@databricks.com') then 	"BU Leader"
#         when array_contains(recipientList, 'fieldeng-org-marcelo.sales@databricks.com') THEN "Tech GM"
#         when array_contains(recipientList, 'raela@databricks.com') THEN "Tech GM"
#         when array_contains(recipientList, 'kyoungwoon.chang@databricks.com') THEN "Manager"
#         end as role,
#       *
#     from users.liam_clifford.technical_enablement_calendar_meetings_gold
#     where summary ilike 'Learning Days%'
# )

# select 
#   p.fe_org_leader,
#   p.role,
#   p.summary,
#   d.date, 
#   cast(d.calendar_year as INT) as year, 
#   cast(d.calendar_month as INT) as month,
#   d.month_name as monthName,
#   d.calendar_year_month as year_month,
#   cast(d.fiscal_year as INT) as fiscalYear,
#   d.fiscal_year_quarter as FQ2
# from pre p
# -- inner join users.ravi_gangumalla.sql_dates d on p.startDatetime::date=d.date
# inner join main.it_core_dim.dim_dates d on p.startDatetime::date=d.date
# order by d.date                           
                               
# ''')

# COMMAND ----------

# learning_day_dates_gold = add_gold_metadata(learning_day_dates)

# COMMAND ----------

# MAGIC %md # Flight School Enrollments

# COMMAND ----------

# DBTITLE 1,Employee Flight School Analytics
flight_school_df = spark.sql('''
                             
  with data AS (
    select 
      wd.hire_date,
      wd.original_hire_date,
      datediff(DAY,hire_Date, current_date()) as tenure,
      wd.Name as workday_name,
      wd.job_profile_start_date,
      wd.job_profile,
      wd.1st_level_manager_name,
      wd.1st_level_manager,
      wd.2nd_level_manager_name,
      wd.2nd_level_manager,
      wd.3rd_level_manager_name,
      wd.3rd_level_manager,
      wd.4th_level_manager_name,
      wd.4th_level_manager,
      wd.5th_level_manager_name,
      wd.5th_level_manager,
      wd.6th_level_manager_name,
      wd.6th_level_manager,
      wd.manager_hierarchy_path,
      wd.manager_hierarchy_path_name,
      wd.businessTitle,
      wd.primaryWorkEmail,
      wd.Termination_Date,
      wd.status as workday_status,
      wd.worker_type,
      u.title, 
      u.name as user_name, 
      u.UserRoleId,
      u.id as sfdc_user_id,
      u.email,
      rank() over (partition by wd.Name order by u.title nulls last) as rank_data
    -- from users.liam_clifford.wd wd
    from main.field_learning_enablement.workday wd
    left join main.sfdc_bronze.user u on lower(wd.primaryWorkEmail)=lower(u.email) and u.processdate=(select max(processdate) from main.sfdc_bronze.user)
    where wd.processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,

  pre as (
    select 
      *
    from data 
    where workday_status is true 
    and  Worker_Type = 'Employee'
    and manager_hierarchy_path_name ilike '%arsalan%'
    and   nvl(workday_name, "Unknown") not in (select distinct manager from 
    --users.liam_clifford.wd 
    main.field_learning_enablement.workday
    where Worker_Type='Employee'
  and workday_status = 'true')
    and (businesstitle ilike '%specialist%solution%'
    or (businesstitle ilike any ('%solution%architect%','%solution%engineer%', '%solution%consultant%', '%customer%data%engineer%') )) 
    and rank_data=1
  )

  ,
  final as
  (
    select 
      p.*, 
      s.*, 
      rank() over (partition by p.workday_name order by s.Primary_Technical_Specialization__c nulls last) as rank_sort
    from pre p
    left join main.sfdc_bronze.userrole ur on p.UserRoleId=ur.id and ur.processdate=(select max(processdate) from main.sfdc_bronze.userrole)
    left join main.sfdc_bronze.field_engineering_users__c s on p.sfdc_user_id=s.field_engineering_user__c and s.processDate=(select max(processDate) from main.sfdc_bronze.field_engineering_users__c)
  )
  ,
  flight_school as ( 
    select *
    from main.field_learning_enablement.ilt_enrollments
    where processDate = (select max(processDate) from main.field_learning_enablement.ilt_enrollments)
    and course_id = 1009
  )
  ,
  flight_school_emp as (
    select 
      e.*,
      f.*,
      f.status as enrollment_status,
      date_format(f.completed_timestamp, 'yyyy-MM-dd') as completed_date
    from final e
    left join flight_school f on lower(e.primaryworkemail) = lower(f.learner_email)
    where rank_sort=1
  )
  ,
  completed_flight_school_flag as ( 
    select 
      *,
      case when enrollment_status = 'completed' and datediff(DAY,hire_Date,completed_date) < 90 then 1 else 0 end as attended
    from flight_school_emp
    where enrollment_status = 'completed'
  )

  ,
  completed_flight_school as (
    select 
      f.*,
      nvl(c.attended,0) as attended_in_first_90_days
    from flight_school_emp f
    left join completed_flight_school_flag c on f.learner_email = c.learner_email
  )

  select 
    hire_date,
    original_hire_date,
    tenure,
    workday_name,
    job_profile_start_date,
    job_profile,
    1st_level_manager_name,
    1st_level_manager,
    2nd_level_manager_name,
    2nd_level_manager,
    3rd_level_manager_name,
    3rd_level_manager,
    4th_level_manager_name,
    4th_level_manager,
    5th_level_manager_name,
    5th_level_manager,
    6th_level_manager_name,
    6th_level_manager,
    manager_hierarchy_path,
    manager_hierarchy_path_name,
    businessTitle,
    primaryWorkEmail,
    Termination_Date,
    workday_status,
    worker_type,
    title,
    user_name,
    UserRoleId,
    sfdc_user_id,
    email,
    rank_data,
    CreatedById,
    CreatedDate,
    CurrencyIsoCode,
    Field_Engineering_User__c,
    Id,
    IsDeleted,
    LastModifiedById,
    LastModifiedDate,
    LastReferencedDate,
    LastViewedDate,
    Name,
    OwnerId,
    Primary_Technical_Specialization__c,
    SystemModstamp,
    Technical_Specialization_Accreditation__c,
    rank_sort,
    learner_user_id,
    learner_email_hash,
    learner_email_domain,
    learner_alternate_email_hash,
    learner_alternate_email_domain,
    account_id,
    account_name,
    ultimate_parent_account_id,
    ultimate_parent_account_name,
    learner_branch_code,
    course_id,
    course_code,
    course_name,
    course_type,
    category_id,
    category_code,
    author_user_id,
    author_email,
    status,
    enrolled_timestamp,
    completed_timestamp,
    score,
    evaluated_timestamp,
    session_id,
    session_name,
    waiting,
    source,
    learner_email,
    learner_alternate_email,
    country_code,
    country_name,
    region,
    -- processDate,
    audience,
    updated_account_id,
    updated_account_name,
    updated_ultimate_parent_account_id,
    updated_ultimate_parent_account_name,
    match_method,
    country_webassessor,
    region_webassessor,
    country_derived,
    region_derived,
    enrollment_status,
    completed_date,
    attended_in_first_90_days
  from completed_flight_school
''')

# COMMAND ----------

flight_school_gold = add_gold_metadata(flight_school_df)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Flight School Completions

# COMMAND ----------

# DBTITLE 1,Employee Flight School Analytics
flight_school_completions = spark.sql('''
  with data AS (
    select 
      wd.hire_date,
      wd.original_hire_date,
      datediff(DAY,hire_Date, current_date()) as tenure,
      datediff(DAY,hire_Date, '2023-10-31') as tenure_ao_q3,
      wd.Name as workday_name,
      wd.job_profile_start_date,
      wd.job_profile,
      wd.1st_level_manager_name,
      wd.1st_level_manager,
      wd.2nd_level_manager_name,
      wd.2nd_level_manager,
      wd.3rd_level_manager_name,
      wd.3rd_level_manager,
      wd.4th_level_manager_name,
      wd.4th_level_manager,
      wd.5th_level_manager_name,
      wd.5th_level_manager,
      wd.6th_level_manager_name,
      wd.6th_level_manager,
      wd.manager_hierarchy_path,
      wd.manager_hierarchy_path_name,
      wd.businessTitle,
      wd.primaryWorkEmail,
      wd.Termination_Date,
      wd.status as workday_status,
      wd.worker_type,
      wd.location,
      wd.Location_Address_Country,
      u.title, 
      u.name as user_name, 
      u.UserRoleId,
      u.id as sfdc_user_id,
      u.email,
      rank() over (partition by wd.Name order by u.title nulls last) as rank_data
    -- from users.liam_clifford.wd wd
    from main.field_learning_enablement.workday wd
    left join main.sfdc_bronze.user u on lower(wd.primaryWorkEmail)=lower(u.email) and u.processdate=(select max(processdate) from main.sfdc_bronze.user)
    where wd.processDate = (select max(processDate) from main.field_learning_enablement.workday)
  )
  ,

  pre as (
    select 
      *
    from data 
    where workday_status is true 
    and  Worker_Type = 'Employee'
    and manager_hierarchy_path_name ilike '%arsalan%'
    and   nvl(workday_name, "Unknown") not in (select distinct manager from 
    --users.liam_clifford.wd 
    main.field_learning_enablement.workday
    where Worker_Type='Employee'
  and status = 'true')
    and (businesstitle ilike '%specialist%solution%'
    or (businesstitle ilike any ('%solution%architect%','%solution%engineer%', '%solution%consultant%', '%customer%data%engineer%') )) 
    and rank_data=1
  )


  ,
  final as
  (
    select 
      p.*, 
      s.* except(processDate), 
      rank() over (partition by p.workday_name order by s.Primary_Technical_Specialization__c nulls last) as rank_sort
    from pre p
    left join main.sfdc_bronze.userrole ur on p.UserRoleId=ur.id and ur.processdate=(select max(processdate) from main.sfdc_bronze.userrole)
    left join main.sfdc_bronze.field_engineering_users__c s on p.sfdc_user_id=s.field_engineering_user__c and s.processDate=(select max(processDate) from main.sfdc_bronze.field_engineering_users__c)
  )

  ,
  flight_school as ( 
    select * except(processDate)
    from main.field_learning_enablement.ilt_enrollments
    where processDate = (select max(processDate) from main.field_learning_enablement.ilt_enrollments)
    and course_id = 1009
  )

  ,
  flight_school_emp as (
    select 
      e.*,
      f.*,
      f.status as enrollment_status,
      date_format(f.completed_timestamp, 'yyyy-MM-dd') as completed_date
    from final e
    left join flight_school f on lower(e.primaryworkemail) = lower(f.learner_email)
    where rank_sort=1
  )
  ,
  completed_flight_school_flag as ( 
    select 
      *,
      case when enrollment_status = 'completed' and datediff(DAY,hire_Date,completed_date) < 90 then 1 else 0 end as attended
    from flight_school_emp
    where enrollment_status = 'completed'
  )

  ,
  completed_flight_school as (
    select 
      f.*,
      nvl(c.attended,0) as attended_in_first_90_days
    from flight_school_emp f
    left join completed_flight_school_flag c on f.learner_email = c.learner_email
  )

  select 
    * 
  from completed_flight_school
  where 1=1
  and tenure > 90 
  and tenure <= 365
  and original_hire_date = hire_date
  and hire_date >= '2023-01-01'

 


''')

# COMMAND ----------

flight_school_completions_gold = add_gold_metadata(flight_school_completions)

# COMMAND ----------

# MAGIC %md 
# MAGIC
# MAGIC # L200

# COMMAND ----------

# DBTITLE 1,Specialization Form Integrator
try:
  sht = authGoogleSheet("Specialization Declaration Form (Responses)")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')
  
  
try:
  worksheet = sht.worksheet("Form Responses 1")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "Specialization Declaration Form (Responses)",
 "Form Responses 1",
 "specializations",
 clean_column_names="true", 
 make_columns_unique="true"
)


# COMMAND ----------

# DBTITLE 1,Temporary Exemption Emails
try:
  sht = authGoogleSheet("Technical Specialization Exemption (Responses)")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')
  
  
try:
  worksheet = sht.worksheet("Form Responses 1")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "Technical Specialization Exemption (Responses)",
 "Form Responses 1",
 "temp_exemptions",
 clean_column_names="true", 
 make_columns_unique="true"
)

# COMMAND ----------

# DBTITLE 1,Workday User Processing Script
l200_df = spark.sql('''
with 
workday as (
  select *
  from main.field_learning_enablement.workday
  where processDate = (select max(processDate) from main.field_learning_enablement.workday)
  and Worker_Type='Employee'
  and status = 'true'
  and (nvl(name, "Unknown") not in (select distinct manager from main.field_learning_enablement.workday wd where wd.Worker_Type='Employee'and wd.status = 'true' and wd.processDate = (select max(processDate) from main.field_learning_enablement.workday)) or primaryWorkEmail = 'pritesh.patel@databricks.com')
  and manager_hierarchy_path_name ilike any (
    '%jeff traylor%',
    '%david hackett%',
    '%jason martin%',
    '%toby balfre%',
    '%nicholas eayrs%',
    '%david totten%'
  )
  and manager_hierarchy_path_name not ilike ('%victor cheah%')
)
,
sfdc_users_rank as (
  select rank() over (partition by email order by CreatedDate desc) as rank, *
  -- from main.sfdc_bronze.user
  from main.sfdc_bronze.user
  -- where processdate = (select max(processdate) from main.sfdc_bronze.user)
  where processdate = (select max(processdate) from main.sfdc_bronze.user)
  
)
,
sfdc_users as (
  select *
  from sfdc_users_rank
  where rank = 1
)

,
fe_users as (
  select 
    u.email as sfdc_email,
    w.*,
    f.Field_Engineering_User__c,
    f.Primary_Technical_Specialization__c,
    f.Archetypes__c,
    u.id as sfdc_id,
    f.name as fe_users_name, 
    f.id as fe_users_id
  from workday w
  -- left join sfdc_users u on lower(w.primaryWorkEmail) = lower(u.email) 
  left join sfdc_users u on lower(w.primaryWorkEmail) = lower(u.username) 
  left join main.sfdc_bronze.field_engineering_users__c f on f.Field_Engineering_User__c = u.id and f.processdate = (select max(processdate) from main.sfdc_bronze.field_engineering_users__c)
  where w.businessTitle IN (
        'Solutions Architect',
        'Resident Solutions Architect',
        'Sr. Solutions Architect',
        'Delivery Solutions Architect',
        'Sr. Delivery Solutions Engineer',
        'Sr Delivery Solutions Engineer',
        'Senior Delivery Solutions Engineer',
        'Specialist Solutions Architect',
        'Sr. Solutions Consultant',
        'Solutions Consultant',
        'Sr. Specialist Solutions Architect',
        'Sr. Specialist Solutions Architect ',
        'Sr. Delivery Solutions Architect',
        'Sr. Solutions Engineer',
        'Senior Solution Engineer',
        'Sr Solutions Engineer',
        'Sr. Technical Services Engineer',
        'Sr. Technical Advisor, Financial Services',
        'Technical Services Engineer',
        'Sr Solutions Consultant',
        'Sr. Resident Solutions Architect',
        'Senior Solutions Engineer',
        'Senior Specialist Solutions Architect',
        'Senior Solutions Consultant',
        'Senior Specialist Solutions Engineer',
        'Senior Partner Solutions Engineer',
        'Cloud Technologist',
        'Technical Services Specialist',
        'Solutions Engineer',
        'Delivery Solutions Engineer',
        'Sr. Partner Solutions Architect',
        'Sr. Global Practice Tech Lead, Customer Success Engineering',
        -- 'Sr Engagement Manager',
        'Partner Solutions Architect',
        'Lead Specialist Solutions Architect',
        -- 'Engagement Manager',
        'Lead Solutions Architect',
        'Sr. Specialist Solutions Engineer',
        'Specialist Solutions Engineer',
        -- 'Sr. Engagement Manager',
        'Principal Specialist Solutions Architect',
        'Senior Strategic Solutions Architect',
        'Sr Solutions Architect',
        'Principal Solutions Architect',
        'Lead Resident Solutions Architect',
        'Practice Lead Resident Solutions Architect',
        'Senior Resident Solutions Architect',
        -- 'Senior Engagement Manager',
        'Sr. Specialist Solutons Architect',
        'Sr Specialist Solutions Architect',
        'Snr. Solutions Architect',
        'Lead Delivery Solutions Architect',
        'Lead Product Specialist Solution Architect - Data Engineering',
        'Resident Solution Architect',
        'Delivery Solution Architect',
        'Sr Resident Solutions Architect',
        'Lead Partner Solutions Architect',
        'Specialist Solutions Architect - Financial Services',
        'Specialist Solutions Architect - Data Science & Machine Learning',
        'Solution Architect',
        'Sr. Technical Solutions Engineer',
        'Solution Architect, ANZ',
        'Sr. Strategic Solutions Architect',
        'Senior Solutions Architect, Digital Native Business',
        'Sr Specialist Solutions Engineer',
        'Partner Solutions Architect, Lead for GSI',
        'Senior Solutions Architect',
        'Data & AI Strategist',
        'Senior Delivery Solutions Architect',
        'Sr Technical Services Engineer',
        'Lead Product Specialist Solutions Architect',
        'Sr Delivery Solutions Architect',
        'Specialist Solutions Architect - Data Engineering',
        'Sr. Specialist Solutions Engineer - Data Engineering',
        'Associate Customer Data Engineer',
        'Customer Data Engineer',
        'Sr. Customer Data Engineer'
        -- ,
        -- 'Specialist Solutions Architect, Field Engineering'
      ) 
)
,
flight_school_enrollments_rank as (
  select rank() over (partition by learner_email order by enrolled_timestamp desc) as rank, *
  from main.field_learning_enablement.ilt_enrollments
  where processDate = (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
  and course_id = 1009
)
,
flight_school_enrollments as (
  select *
  from flight_school_enrollments_rank
  where rank = 1
)
,
selling_winning as (
  select 
    learner_email, 
    max(completed_courses) as completed_courses,
    max(total_courses) as total_courses,
    max(lp_courses) as lp_courses,
    max(lp_enrollment_status) as lp_enrollment_status,
    max(lp_completed_timestamp) as lp_completed_timestamp
  from main.field_learning_enablement.selling_and_winning_learning_plan_details
  where processDate = (select max(processDate) from main.field_learning_enablement.selling_and_winning_learning_plan_details)
  group by all
)
,
level_info as (
  select
    u.*,
    g.requirement, 
    g.de_certified_flag,
    g.ml_certified_flag, 
    g.gen_ai_certified_flag,
    g.certified_flag, 
    g.certified_date,
    -- g.cert_earliest_expiry_date,
    l.completed_courses,
    l.total_courses,
    l.lp_courses,
    -- l.Selling_Winning_Overview,
    -- l.Selling_Winning_Generative_AI,
    -- l.Selling_Winning_Platform,
    -- l.Selling_Winning_Data_Engineering,
    -- l.Selling_Winning_Data_Governance,
    -- l.Selling_Winning_Data_Science_Machine_Learning,
    -- l.Selling_Winning_Data_Warehousing,
    round(l.completed_courses/l.total_courses * 100, 1) as percent_completed,
    nvl(l.lp_enrollment_status, 'Not Enrolled') as selling_and_winning_status,
    case when l.lp_enrollment_status = 'Completed' then l.lp_completed_timestamp end as lp_completed_timestamp,
    nvl(e.status, 'Not Enrolled') as flight_school_status,
    case when e.status = 'completed' then e.completed_timestamp end as flight_school_completed_timestamp
    from fe_users u
    left join main.field_learning_enablement.get_certified g on lower(u.primaryWorkEmail) = lower(g.primaryWorkEmail) and g.processDate = (select max(processDate) from main.field_learning_enablement.get_certified)
    left join selling_winning l on lower(u.primaryWorkEmail) = lower(l.learner_email)
    left join flight_school_enrollments e on lower(u.sfdc_email) = lower(e.learner_email) 
)
,
specialization_rank as (
  select 
    *, 
    rank() over (partition by email_address order by timestamp desc) as rank 
  from specializations
)
,
specialization as (
  select 
    *
  from specialization_rank 
  where rank = 1
)
,
exemptions as (
  select 
  case when lower(trim(email_of_the_ic_who_needs_exemption)) = 'will.block@databricks.com' then 'william.block@databricks.com'
  when lower(trim(email_of_the_ic_who_needs_exemption)) = 'homayoon@databricks.com' then 'homayoon.moradi@databricks.com'
  else lower(trim(email_of_the_ic_who_needs_exemption))
  end as email_of_the_ic_who_needs_exemption
  from temp_exemptions
)
,
-- Get the earliest expiry date and credential name on the basis of their required certifications for L200
expiry_dates as (
  select * from main.field_learning_enablement.accredible_credentials
  where processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
  and !is_expired
  and group_id in (
      '371215',
      '364119',
      '357057',
      '353856',
      '331743',
      '229201',
      '227965',
      '227818',
      '227970',
      '583499')
)
,
de_cert_expiry as (
  select  
    g.primaryWorkEmail,
    e.learner_email_hash,
    e.learner_alternate_email_hash,
    g.requirement,
    e.expired_on::date AS expiry_date,
    e.credential_name
  FROM main.field_learning_enablement.get_certified g
  LEFT JOIN expiry_dates e ON (
    sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
    OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
  )
  WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
    AND g.requirement = 'DE Cert' 
    AND e.credential_name ILIKE '%data engineer%'
),
de_cert_expiry_date as (
  SELECT 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  MIN(expiry_date) AS earliest_expiry_date,
  credential_name AS earliest_expiring_credential
FROM (
  SELECT 
    *,
    ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date) AS rn
  FROM de_cert_expiry
)
WHERE rn = 1
GROUP BY 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  credential_name
)
,
de_ml_gen_ai_cert_expiry as (
  select  
    g.primaryWorkEmail,
    e.learner_email_hash,
    e.learner_alternate_email_hash,
    g.requirement,
    e.expired_on::date AS expiry_date,
    e.credential_name
  FROM main.field_learning_enablement.get_certified g
  LEFT JOIN expiry_dates e ON (
    sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
    OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
  )
  WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
    AND g.requirement in ('DE Cert or ML or GenAI cert', 'DE and ML or GenAI Cert')
    AND (e.credential_name ILIKE '%data engineer%' or e.credential_name ilike '%machine learning%' or e.credential_name ilike '%data scientist%' or e.credential_name ilike '%Generative AI%')
),
de_ml_gen_ai_expiry_date as (
  SELECT 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  MIN(expiry_date) AS earliest_expiry_date,
  credential_name AS earliest_expiring_credential
  FROM (
    SELECT 
      *,
      ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date) AS rn
    FROM de_ml_gen_ai_cert_expiry
  )
  WHERE rn = 1
  GROUP BY 
    primaryWorkEmail,
    learner_email_hash,
    learner_alternate_email_hash,
    requirement,
    credential_name
)
,
earliest_expiry_dates as (
  select * from de_cert_expiry_date
  union all
  select * from de_ml_gen_ai_expiry_date
)
,
expired_certifications as (
  select * from main.field_learning_enablement.accredible_credentials
  where processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
  and is_expired
  and group_id in (
      '371215',
      '364119',
      '357057',
      '353856',
      '331743',
      '229201',
      '227965',
      '227818',
      '227970',
      '583499')
)
,
expired_de_cert as (
  select  
    g.primaryWorkEmail,
    e.learner_email_hash,
    e.learner_alternate_email_hash,
    g.requirement,
    e.expired_on::date AS expiry_date,
    e.credential_name
  FROM main.field_learning_enablement.get_certified g
  LEFT JOIN expired_certifications e ON (
    sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
    OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
  )
  WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
    AND g.requirement = 'DE Cert' 
    AND e.credential_name ILIKE '%data engineer%'
),
expired_de_cert_date as (
  SELECT 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  MAX(expiry_date) AS recently_expired_cert_date,
  MIN(expiry_date) AS oldest_expired_cert_date,
  credential_name AS recently_expired_cert
FROM (
  SELECT 
    *,
    ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date desc) AS rn
  FROM expired_de_cert
)
WHERE rn = 1
GROUP BY 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  credential_name
)
,
expired_de_ml_gen_ai_cert as (
  select  
    g.primaryWorkEmail,
    e.learner_email_hash,
    e.learner_alternate_email_hash,
    g.requirement,
    e.expired_on::date AS expiry_date,
    e.credential_name
  FROM main.field_learning_enablement.get_certified g
  LEFT JOIN expired_certifications e ON (
    sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
    OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
  )
  WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
    AND g.requirement in ('DE Cert or ML or GenAI cert', 'DE and ML or GenAI Cert')
    AND (e.credential_name ILIKE '%data engineer%' or e.credential_name ilike '%machine learning%' or e.credential_name ilike '%data scientist%' or e.credential_name ilike '%Generative AI%')
),
expired_de_ml_gen_ai_date as (
  SELECT 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  max(expiry_date) AS recently_expired_cert_date,
  MIN(expiry_date) AS oldest_expired_cert_date,
  credential_name AS recently_expired_cert
  FROM (
    SELECT 
      *,
      ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date desc) AS rn
    FROM expired_de_ml_gen_ai_cert
  )
  WHERE rn = 1
  GROUP BY 
    primaryWorkEmail,
    learner_email_hash,
    learner_alternate_email_hash,
    requirement,
    credential_name
)
,
recent_expired_dates as (
  select * from expired_de_cert_date
  union all
  select * from expired_de_ml_gen_ai_date
)
,
required_certs_expired as (
  select 
  g.*,
    case when (r.requirement = 'DE or ML or GenAI Cert' or r.requirement = 'DE Cert or ML or GenAI cert')
    and months_between(current_date(),oldest_expired_cert_date) < 6
    then 1 
    when r.requirement = 'DE Cert' 
    and months_between(current_date(),oldest_expired_cert_date) < 6
    then 1
    when r.requirement = 'DE and ML or GenAI Cert' 
    and months_between(current_date(),oldest_expired_cert_date) < 6
    then 1
    else 0
  end as grace_period_flag
  from recent_expired_dates r
  left join main.field_learning_enablement.get_certified g on g.primaryWorkEmail = r.primaryWorkEmail
  and g.certified_flag = 0
)
,
final as (
select
    l.*,
    case when (flight_school_status = 'completed' or tenure_in_months >= 12)  then true end as L100,
    case when flight_school_status = 'completed' then flight_school_completed_timestamp::date end as L100_date_completed,
    case when selling_and_winning_status = 'Completed' and (l.certified_flag = 1 or grace_period_flag = 1) then true end as L200,
    -- Grace Period 6 months from certification expiry date
    max(grace_period_flag) as grace_period_flag,
    -- Expiry date of cert that is going to expire the earliest
    earliest_expiry_date,
    -- credential name of the cert that is going to expire the earliest
    earliest_expiring_credential,
    recently_expired_cert_date,
    recently_expired_cert,
    -- case when temporary exemption.
    case when ((l.primaryWorkEmail in (select email_of_the_ic_who_needs_exemption from exemptions))
    and not (selling_and_winning_status = 'Completed' and l.certified_flag = 1)) then 1 else 0 end as temporary_exemption,
    case when selling_and_winning_status = 'Completed' and l.certified_flag = 1 then greatest(lp_completed_timestamp::date, l.certified_date::date) end L200_date_completed,
    s.what_is_your_preferred_major as first_major,
    s.what_is_your_second_choice_of_major as second_major,
    case when s.what_is_your_preferred_major is not null then
      case when l.Job_Profile ilike '%Delivery Solutions Architect%' then 'DSA'
      when l.Job_Profile ilike '%Resident Solutions Architect%' then 'RSA'
      when l.Job_Profile ilike '%Solutions Architect%' then 'SA' end
    else "" end as role_type,
    case when 
      s.what_is_your_preferred_major is not null then s.what_is_your_preferred_major
      when Primary_Technical_Specialization__c = 'Cloud Data Architecture'
      or Primary_Technical_Specialization__c = 'Platform' 
      then 'Cloud Infrastructure & Security'
      when Primary_Technical_Specialization__c = 'DS & ML' 
      then 'Data Science & ML'
      when Primary_Technical_Specialization__c = 'SQL & DW'
      then 'Data Warehousing'
      else Primary_Technical_Specialization__c
    end as specialization_major

from level_info l
left join specialization s on lower(l.primaryWorkEmail) = lower(s.email_address)
left join required_certs_expired e on lower(l.primaryWorkEmail) = lower(e.primaryWorkEmail)
left join earliest_expiry_dates d on lower(l.primaryWorkEmail) = lower(d.primaryWorkEmail)
left join recent_expired_dates r on lower(l.primaryWorkEmail) = lower(r.primaryWorkEmail)
group by all
)

select *, "IC" as employee_type
from final 
 ''')
 # -- where L100 
 # -- where L200


# COMMAND ----------

# MAGIC %sql
# MAGIC with 
# MAGIC workday as (
# MAGIC   select *
# MAGIC   from main.field_learning_enablement.workday
# MAGIC   where processDate = (select max(processDate) from main.field_learning_enablement.workday)
# MAGIC   and Worker_Type='Employee'
# MAGIC   and status = 'true'
# MAGIC   and (nvl(name, "Unknown") not in (select distinct manager from main.field_learning_enablement.workday wd where wd.Worker_Type='Employee'and wd.status = 'true' and wd.processDate = (select max(processDate) from main.field_learning_enablement.workday)) or primaryWorkEmail = 'pritesh.patel@databricks.com')
# MAGIC   and manager_hierarchy_path_name ilike any (
# MAGIC     '%jeff traylor%',
# MAGIC     '%david hackett%',
# MAGIC     '%jason martin%',
# MAGIC     '%toby balfre%',
# MAGIC     '%nicholas eayrs%',
# MAGIC     '%david totten%'
# MAGIC   )
# MAGIC   and manager_hierarchy_path_name not ilike ('%victor cheah%')
# MAGIC )
# MAGIC ,
# MAGIC sfdc_users_rank as (
# MAGIC   select rank() over (partition by email order by CreatedDate desc) as rank, *
# MAGIC   -- from main.sfdc_bronze.user
# MAGIC   from main.sfdc_bronze.user
# MAGIC   -- where processdate = (select max(processdate) from main.sfdc_bronze.user)
# MAGIC   where processdate = (select max(processdate) from main.sfdc_bronze.user)
# MAGIC   
# MAGIC )
# MAGIC ,
# MAGIC sfdc_users as (
# MAGIC   select *
# MAGIC   from sfdc_users_rank
# MAGIC   where rank = 1
# MAGIC )
# MAGIC
# MAGIC ,
# MAGIC fe_users as (
# MAGIC   select 
# MAGIC     u.email as sfdc_email,
# MAGIC     w.*,
# MAGIC     f.Field_Engineering_User__c,
# MAGIC     f.Primary_Technical_Specialization__c,
# MAGIC     f.Archetypes__c,
# MAGIC     u.id as sfdc_id,
# MAGIC     f.name as fe_users_name, 
# MAGIC     f.id as fe_users_id
# MAGIC   from workday w
# MAGIC   -- left join sfdc_users u on lower(w.primaryWorkEmail) = lower(u.email) 
# MAGIC   left join sfdc_users u on lower(w.primaryWorkEmail) = lower(u.username) 
# MAGIC   left join main.sfdc_bronze.field_engineering_users__c f on f.Field_Engineering_User__c = u.id and f.processdate = (select max(processdate) from main.sfdc_bronze.field_engineering_users__c)
# MAGIC   where w.businessTitle IN (
# MAGIC         'Solutions Architect',
# MAGIC         'Resident Solutions Architect',
# MAGIC         'Sr. Solutions Architect',
# MAGIC         'Delivery Solutions Architect',
# MAGIC         'Sr. Delivery Solutions Engineer',
# MAGIC         'Sr Delivery Solutions Engineer',
# MAGIC         'Senior Delivery Solutions Engineer',
# MAGIC         'Specialist Solutions Architect',
# MAGIC         'Sr. Solutions Consultant',
# MAGIC         'Solutions Consultant',
# MAGIC         'Sr. Specialist Solutions Architect',
# MAGIC         'Sr. Specialist Solutions Architect ',
# MAGIC         'Sr. Delivery Solutions Architect',
# MAGIC         'Sr. Solutions Engineer',
# MAGIC         'Senior Solution Engineer',
# MAGIC         'Sr Solutions Engineer',
# MAGIC         'Sr. Technical Services Engineer',
# MAGIC         'Sr. Technical Advisor, Financial Services',
# MAGIC         'Technical Services Engineer',
# MAGIC         'Sr Solutions Consultant',
# MAGIC         'Sr. Resident Solutions Architect',
# MAGIC         'Senior Solutions Engineer',
# MAGIC         'Senior Specialist Solutions Architect',
# MAGIC         'Senior Solutions Consultant',
# MAGIC         'Senior Specialist Solutions Engineer',
# MAGIC         'Senior Partner Solutions Engineer',
# MAGIC         'Cloud Technologist',
# MAGIC         'Technical Services Specialist',
# MAGIC         'Solutions Engineer',
# MAGIC         'Delivery Solutions Engineer',
# MAGIC         'Sr. Partner Solutions Architect',
# MAGIC         'Sr. Global Practice Tech Lead, Customer Success Engineering',
# MAGIC         -- 'Sr Engagement Manager',
# MAGIC         'Partner Solutions Architect',
# MAGIC         'Lead Specialist Solutions Architect',
# MAGIC         -- 'Engagement Manager',
# MAGIC         'Lead Solutions Architect',
# MAGIC         'Sr. Specialist Solutions Engineer',
# MAGIC         'Specialist Solutions Engineer',
# MAGIC         -- 'Sr. Engagement Manager',
# MAGIC         'Principal Specialist Solutions Architect',
# MAGIC         'Senior Strategic Solutions Architect',
# MAGIC         'Sr Solutions Architect',
# MAGIC         'Principal Solutions Architect',
# MAGIC         'Lead Resident Solutions Architect',
# MAGIC         'Practice Lead Resident Solutions Architect',
# MAGIC         'Senior Resident Solutions Architect',
# MAGIC         -- 'Senior Engagement Manager',
# MAGIC         'Sr. Specialist Solutons Architect',
# MAGIC         'Sr Specialist Solutions Architect',
# MAGIC         'Snr. Solutions Architect',
# MAGIC         'Lead Delivery Solutions Architect',
# MAGIC         'Lead Product Specialist Solution Architect - Data Engineering',
# MAGIC         'Resident Solution Architect',
# MAGIC         'Delivery Solution Architect',
# MAGIC         'Sr Resident Solutions Architect',
# MAGIC         'Lead Partner Solutions Architect',
# MAGIC         'Specialist Solutions Architect - Financial Services',
# MAGIC         'Specialist Solutions Architect - Data Science & Machine Learning',
# MAGIC         'Solution Architect',
# MAGIC         'Sr. Technical Solutions Engineer',
# MAGIC         'Solution Architect, ANZ',
# MAGIC         'Sr. Strategic Solutions Architect',
# MAGIC         'Senior Solutions Architect, Digital Native Business',
# MAGIC         'Sr Specialist Solutions Engineer',
# MAGIC         'Partner Solutions Architect, Lead for GSI',
# MAGIC         'Senior Solutions Architect',
# MAGIC         'Data & AI Strategist',
# MAGIC         'Senior Delivery Solutions Architect',
# MAGIC         'Sr Technical Services Engineer',
# MAGIC         'Lead Product Specialist Solutions Architect',
# MAGIC         'Sr Delivery Solutions Architect',
# MAGIC         'Specialist Solutions Architect - Data Engineering',
# MAGIC         'Sr. Specialist Solutions Engineer - Data Engineering',
# MAGIC         'Associate Customer Data Engineer',
# MAGIC         'Customer Data Engineer',
# MAGIC         'Sr. Customer Data Engineer'
# MAGIC         -- ,
# MAGIC         -- 'Specialist Solutions Architect, Field Engineering'
# MAGIC       ) 
# MAGIC )
# MAGIC ,
# MAGIC flight_school_enrollments_rank as (
# MAGIC   select rank() over (partition by learner_email order by enrolled_timestamp desc) as rank, *
# MAGIC   from main.field_learning_enablement.ilt_enrollments
# MAGIC   where processDate = (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
# MAGIC   and course_id = 1009
# MAGIC )
# MAGIC ,
# MAGIC flight_school_enrollments as (
# MAGIC   select *
# MAGIC   from flight_school_enrollments_rank
# MAGIC   where rank = 1
# MAGIC )
# MAGIC ,
# MAGIC selling_winning as (
# MAGIC   select 
# MAGIC     learner_email, 
# MAGIC     max(completed_courses) as completed_courses,
# MAGIC     max(total_courses) as total_courses,
# MAGIC     max(lp_courses) as lp_courses,
# MAGIC     max(lp_enrollment_status) as lp_enrollment_status,
# MAGIC     max(lp_completed_timestamp) as lp_completed_timestamp
# MAGIC   from main.field_learning_enablement.selling_and_winning_learning_plan_details
# MAGIC   where processDate = (select max(processDate) from main.field_learning_enablement.selling_and_winning_learning_plan_details)
# MAGIC   group by all
# MAGIC )
# MAGIC ,
# MAGIC level_info as (
# MAGIC   select
# MAGIC     u.*,
# MAGIC     g.requirement, 
# MAGIC     g.de_certified_flag,
# MAGIC     g.ml_certified_flag, 
# MAGIC     g.gen_ai_certified_flag,
# MAGIC     g.certified_flag, 
# MAGIC     g.certified_date,
# MAGIC     -- g.cert_earliest_expiry_date,
# MAGIC     l.completed_courses,
# MAGIC     l.total_courses,
# MAGIC     l.lp_courses,
# MAGIC     -- l.Selling_Winning_Overview,
# MAGIC     -- l.Selling_Winning_Generative_AI,
# MAGIC     -- l.Selling_Winning_Platform,
# MAGIC     -- l.Selling_Winning_Data_Engineering,
# MAGIC     -- l.Selling_Winning_Data_Governance,
# MAGIC     -- l.Selling_Winning_Data_Science_Machine_Learning,
# MAGIC     -- l.Selling_Winning_Data_Warehousing,
# MAGIC     round(l.completed_courses/l.total_courses * 100, 1) as percent_completed,
# MAGIC     nvl(l.lp_enrollment_status, 'Not Enrolled') as selling_and_winning_status,
# MAGIC     case when l.lp_enrollment_status = 'Completed' then l.lp_completed_timestamp end as lp_completed_timestamp,
# MAGIC     nvl(e.status, 'Not Enrolled') as flight_school_status,
# MAGIC     case when e.status = 'completed' then e.completed_timestamp end as flight_school_completed_timestamp
# MAGIC     from fe_users u
# MAGIC     left join main.field_learning_enablement.get_certified g on lower(u.primaryWorkEmail) = lower(g.primaryWorkEmail) and g.processDate = (select max(processDate) from main.field_learning_enablement.get_certified)
# MAGIC     left join selling_winning l on lower(u.primaryWorkEmail) = lower(l.learner_email)
# MAGIC     left join flight_school_enrollments e on lower(u.sfdc_email) = lower(e.learner_email) 
# MAGIC )
# MAGIC ,
# MAGIC specialization_rank as (
# MAGIC   select 
# MAGIC     *, 
# MAGIC     rank() over (partition by email_address order by timestamp desc) as rank 
# MAGIC   from specializations
# MAGIC )
# MAGIC ,
# MAGIC specialization as (
# MAGIC   select 
# MAGIC     *
# MAGIC   from specialization_rank 
# MAGIC   where rank = 1
# MAGIC )
# MAGIC ,
# MAGIC exemptions as (
# MAGIC   select 
# MAGIC   case when lower(trim(email_of_the_ic_who_needs_exemption)) = 'will.block@databricks.com' then 'william.block@databricks.com'
# MAGIC   when lower(trim(email_of_the_ic_who_needs_exemption)) = 'homayoon@databricks.com' then 'homayoon.moradi@databricks.com'
# MAGIC   else lower(trim(email_of_the_ic_who_needs_exemption))
# MAGIC   end as email_of_the_ic_who_needs_exemption
# MAGIC   from temp_exemptions
# MAGIC )
# MAGIC ,
# MAGIC -- Get the earliest expiry date and credential name on the basis of their required certifications for L200
# MAGIC expiry_dates as (
# MAGIC   select * from main.field_learning_enablement.accredible_credentials
# MAGIC   where processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
# MAGIC   and !is_expired
# MAGIC   and group_id in (
# MAGIC       '371215',
# MAGIC       '364119',
# MAGIC       '357057',
# MAGIC       '353856',
# MAGIC       '331743',
# MAGIC       '229201',
# MAGIC       '227965',
# MAGIC       '227818',
# MAGIC       '227970',
# MAGIC       '583499')
# MAGIC )
# MAGIC ,
# MAGIC de_cert_expiry as (
# MAGIC   select  
# MAGIC     g.primaryWorkEmail,
# MAGIC     e.learner_email_hash,
# MAGIC     e.learner_alternate_email_hash,
# MAGIC     g.requirement,
# MAGIC     e.expired_on::date AS expiry_date,
# MAGIC     e.credential_name
# MAGIC   FROM main.field_learning_enablement.get_certified g
# MAGIC   LEFT JOIN expiry_dates e ON (
# MAGIC     sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
# MAGIC     OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
# MAGIC   )
# MAGIC   WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
# MAGIC     AND g.requirement = 'DE Cert' 
# MAGIC     AND e.credential_name ILIKE '%data engineer%'
# MAGIC ),
# MAGIC de_cert_expiry_date as (
# MAGIC   SELECT 
# MAGIC   primaryWorkEmail,
# MAGIC   learner_email_hash,
# MAGIC   learner_alternate_email_hash,
# MAGIC   requirement,
# MAGIC   MIN(expiry_date) AS earliest_expiry_date,
# MAGIC   credential_name AS earliest_expiring_credential
# MAGIC FROM (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date) AS rn
# MAGIC   FROM de_cert_expiry
# MAGIC )
# MAGIC WHERE rn = 1
# MAGIC GROUP BY 
# MAGIC   primaryWorkEmail,
# MAGIC   learner_email_hash,
# MAGIC   learner_alternate_email_hash,
# MAGIC   requirement,
# MAGIC   credential_name
# MAGIC )
# MAGIC ,
# MAGIC de_ml_gen_ai_cert_expiry as (
# MAGIC   select  
# MAGIC     g.primaryWorkEmail,
# MAGIC     e.learner_email_hash,
# MAGIC     e.learner_alternate_email_hash,
# MAGIC     g.requirement,
# MAGIC     e.expired_on::date AS expiry_date,
# MAGIC     e.credential_name
# MAGIC   FROM main.field_learning_enablement.get_certified g
# MAGIC   LEFT JOIN expiry_dates e ON (
# MAGIC     sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
# MAGIC     OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
# MAGIC   )
# MAGIC   WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
# MAGIC     AND g.requirement in ('DE Cert or ML or GenAI cert', 'DE and ML or GenAI Cert')
# MAGIC     AND (e.credential_name ILIKE '%data engineer%' or e.credential_name ilike '%machine learning%' or e.credential_name ilike '%data scientist%' or e.credential_name ilike '%Generative AI%')
# MAGIC ),
# MAGIC de_ml_gen_ai_expiry_date as (
# MAGIC   SELECT 
# MAGIC   primaryWorkEmail,
# MAGIC   learner_email_hash,
# MAGIC   learner_alternate_email_hash,
# MAGIC   requirement,
# MAGIC   MIN(expiry_date) AS earliest_expiry_date,
# MAGIC   credential_name AS earliest_expiring_credential
# MAGIC   FROM (
# MAGIC     SELECT 
# MAGIC       *,
# MAGIC       ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date) AS rn
# MAGIC     FROM de_ml_gen_ai_cert_expiry
# MAGIC   )
# MAGIC   WHERE rn = 1
# MAGIC   GROUP BY 
# MAGIC     primaryWorkEmail,
# MAGIC     learner_email_hash,
# MAGIC     learner_alternate_email_hash,
# MAGIC     requirement,
# MAGIC     credential_name
# MAGIC )
# MAGIC ,
# MAGIC earliest_expiry_dates as (
# MAGIC   select * from de_cert_expiry_date
# MAGIC   union all
# MAGIC   select * from de_ml_gen_ai_expiry_date
# MAGIC )
# MAGIC ,
# MAGIC expired_certifications as (
# MAGIC   select * from main.field_learning_enablement.accredible_credentials
# MAGIC   where processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
# MAGIC   and is_expired
# MAGIC   and group_id in (
# MAGIC       '371215',
# MAGIC       '364119',
# MAGIC       '357057',
# MAGIC       '353856',
# MAGIC       '331743',
# MAGIC       '229201',
# MAGIC       '227965',
# MAGIC       '227818',
# MAGIC       '227970',
# MAGIC       '583499')
# MAGIC )
# MAGIC ,
# MAGIC expired_de_cert as (
# MAGIC   select  
# MAGIC     g.primaryWorkEmail,
# MAGIC     e.learner_email_hash,
# MAGIC     e.learner_alternate_email_hash,
# MAGIC     g.requirement,
# MAGIC     e.expired_on::date AS expiry_date,
# MAGIC     e.credential_name
# MAGIC   FROM main.field_learning_enablement.get_certified g
# MAGIC   LEFT JOIN expired_certifications e ON (
# MAGIC     sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
# MAGIC     OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
# MAGIC   )
# MAGIC   WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
# MAGIC     AND g.requirement = 'DE Cert' 
# MAGIC     AND e.credential_name ILIKE '%data engineer%'
# MAGIC ),
# MAGIC expired_de_cert_date as (
# MAGIC   SELECT 
# MAGIC   primaryWorkEmail,
# MAGIC   learner_email_hash,
# MAGIC   learner_alternate_email_hash,
# MAGIC   requirement,
# MAGIC   MAX(expiry_date) AS recently_expired_cert_date,
# MAGIC   MIN(expiry_date) AS oldest_expired_cert_date,
# MAGIC   credential_name AS recently_expired_cert
# MAGIC FROM (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date desc) AS rn
# MAGIC   FROM expired_de_cert
# MAGIC )
# MAGIC WHERE rn = 1
# MAGIC GROUP BY 
# MAGIC   primaryWorkEmail,
# MAGIC   learner_email_hash,
# MAGIC   learner_alternate_email_hash,
# MAGIC   requirement,
# MAGIC   credential_name
# MAGIC )
# MAGIC ,
# MAGIC expired_de_ml_gen_ai_cert as (
# MAGIC   select  
# MAGIC     g.primaryWorkEmail,
# MAGIC     e.learner_email_hash,
# MAGIC     e.learner_alternate_email_hash,
# MAGIC     g.requirement,
# MAGIC     e.expired_on::date AS expiry_date,
# MAGIC     e.credential_name
# MAGIC   FROM main.field_learning_enablement.get_certified g
# MAGIC   LEFT JOIN expired_certifications e ON (
# MAGIC     sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
# MAGIC     OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
# MAGIC   )
# MAGIC   WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
# MAGIC     AND g.requirement in ('DE Cert or ML or GenAI cert', 'DE and ML or GenAI Cert')
# MAGIC     AND (e.credential_name ILIKE '%data engineer%' or e.credential_name ilike '%machine learning%' or e.credential_name ilike '%data scientist%' or e.credential_name ilike '%Generative AI%')
# MAGIC ),
# MAGIC expired_de_ml_gen_ai_date as (
# MAGIC   SELECT 
# MAGIC   primaryWorkEmail,
# MAGIC   learner_email_hash,
# MAGIC   learner_alternate_email_hash,
# MAGIC   requirement,
# MAGIC   max(expiry_date) AS recently_expired_cert_date,
# MAGIC   MIN(expiry_date) AS oldest_expired_cert_date,
# MAGIC   credential_name AS recently_expired_cert
# MAGIC   FROM (
# MAGIC     SELECT 
# MAGIC       *,
# MAGIC       ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date desc) AS rn
# MAGIC     FROM expired_de_ml_gen_ai_cert
# MAGIC   )
# MAGIC   WHERE rn = 1
# MAGIC   GROUP BY 
# MAGIC     primaryWorkEmail,
# MAGIC     learner_email_hash,
# MAGIC     learner_alternate_email_hash,
# MAGIC     requirement,
# MAGIC     credential_name
# MAGIC )
# MAGIC ,
# MAGIC recent_expired_dates as (
# MAGIC   select * from expired_de_cert_date
# MAGIC   union all
# MAGIC   select * from expired_de_ml_gen_ai_date
# MAGIC )
# MAGIC ,
# MAGIC required_certs_expired as (
# MAGIC   select 
# MAGIC   g.*,
# MAGIC     case when (r.requirement = 'DE or ML or GenAI Cert' or r.requirement = 'DE Cert or ML or GenAI cert')
# MAGIC     and months_between(current_date(),oldest_expired_cert_date) < 6
# MAGIC     then 1 
# MAGIC     when r.requirement = 'DE Cert' 
# MAGIC     and months_between(current_date(),oldest_expired_cert_date) < 6
# MAGIC     then 1
# MAGIC     when r.requirement = 'DE and ML or GenAI Cert' 
# MAGIC     and months_between(current_date(),oldest_expired_cert_date) < 6
# MAGIC     then 1
# MAGIC     else 0
# MAGIC   end as grace_period_flag
# MAGIC   from recent_expired_dates r
# MAGIC   left join main.field_learning_enablement.get_certified g on g.primaryWorkEmail = r.primaryWorkEmail
# MAGIC   and g.certified_flag = 0
# MAGIC )
# MAGIC ,
# MAGIC final as (
# MAGIC select
# MAGIC     l.*,
# MAGIC     case when (flight_school_status = 'completed' or tenure_in_months >= 12)  then true end as L100,
# MAGIC     case when flight_school_status = 'completed' then flight_school_completed_timestamp::date end as L100_date_completed,
# MAGIC     case when selling_and_winning_status = 'Completed' and (l.certified_flag = 1 or grace_period_flag = 1) then true end as L200,
# MAGIC     -- Grace Period 6 months from certification expiry date
# MAGIC     max(grace_period_flag) as grace_period_flag,
# MAGIC     -- Expiry date of cert that is going to expire the earliest
# MAGIC     earliest_expiry_date,
# MAGIC     -- credential name of the cert that is going to expire the earliest
# MAGIC     earliest_expiring_credential,
# MAGIC     recently_expired_cert_date,
# MAGIC     recently_expired_cert,
# MAGIC     -- case when temporary exemption.
# MAGIC     case when ((l.primaryWorkEmail in (select email_of_the_ic_who_needs_exemption from exemptions))
# MAGIC     and not (selling_and_winning_status = 'Completed' and l.certified_flag = 1)) then 1 else 0 end as temporary_exemption,
# MAGIC     case when selling_and_winning_status = 'Completed' and l.certified_flag = 1 then greatest(lp_completed_timestamp::date, l.certified_date::date) end L200_date_completed,
# MAGIC     s.what_is_your_preferred_major as first_major,
# MAGIC     s.what_is_your_second_choice_of_major as second_major,
# MAGIC     case when s.what_is_your_preferred_major is not null then
# MAGIC       case when l.Job_Profile ilike '%Delivery Solutions Architect%' then 'DSA'
# MAGIC       when l.Job_Profile ilike '%Resident Solutions Architect%' then 'RSA'
# MAGIC       when l.Job_Profile ilike '%Solutions Architect%' then 'SA' end
# MAGIC     else "" end as role_type,
# MAGIC     case when 
# MAGIC       s.what_is_your_preferred_major is not null then s.what_is_your_preferred_major
# MAGIC       when Primary_Technical_Specialization__c = 'Cloud Data Architecture'
# MAGIC       or Primary_Technical_Specialization__c = 'Platform' 
# MAGIC       then 'Cloud Infrastructure & Security'
# MAGIC       when Primary_Technical_Specialization__c = 'DS & ML' 
# MAGIC       then 'Data Science & ML'
# MAGIC       when Primary_Technical_Specialization__c = 'SQL & DW'
# MAGIC       then 'Data Warehousing'
# MAGIC       else Primary_Technical_Specialization__c
# MAGIC     end as specialization_major
# MAGIC
# MAGIC from level_info l
# MAGIC left join specialization s on lower(l.primaryWorkEmail) = lower(s.email_address)
# MAGIC left join required_certs_expired e on lower(l.primaryWorkEmail) = lower(e.primaryWorkEmail)
# MAGIC left join earliest_expiry_dates d on lower(l.primaryWorkEmail) = lower(d.primaryWorkEmail)
# MAGIC left join recent_expired_dates r on lower(l.primaryWorkEmail) = lower(r.primaryWorkEmail)
# MAGIC group by all
# MAGIC )
# MAGIC
# MAGIC select *
# MAGIC from final where primaryWorkEmail = 'tejashree.kamthe@databricks.com'
# MAGIC  --''')
# MAGIC

# COMMAND ----------

l200_manager_df = spark.sql('''
with 
workday as (
  select *
  from main.field_learning_enablement.workday
  where processDate = (select max(processDate) from main.field_learning_enablement.workday)
  and Worker_Type='Employee'
  and status = 'true'
  and (nvl(name, "Unknown") in (select distinct manager from main.field_learning_enablement.workday wd where wd.Worker_Type='Employee'and wd.status = 'true' and wd.processDate = (select max(processDate) from main.field_learning_enablement.workday)) or primaryWorkEmail = 'pritesh.patel@databricks.com')
  and manager_hierarchy_path_name ilike any (
    '%jeff traylor%',
    '%david hackett%',
    '%jason martin%',
    '%toby balfre%',
    '%nicholas eayrs%',
    '%david totten%'
  )
  and manager_hierarchy_path_name not ilike ('%victor cheah%')
)
,
sfdc_users_rank as (
  select rank() over (partition by email order by CreatedDate desc) as rank, *
  -- from main.sfdc_bronze.user
  from main.sfdc_bronze.user
  -- where processdate = (select max(processdate) from main.sfdc_bronze.user)
  where processdate = (select max(processdate) from main.sfdc_bronze.user)
  
)
,
sfdc_users as (
  select *
  from sfdc_users_rank
  where rank = 1
)

,
fe_users as (
  select 
    u.email as sfdc_email,
    w.*,
    f.Field_Engineering_User__c,
    f.Primary_Technical_Specialization__c,
    f.Archetypes__c,
    u.id as sfdc_id,
    f.name as fe_users_name, 
    f.id as fe_users_id
  from workday w
  -- left join sfdc_users u on w.primaryWorkEmail = u.email 
  left join sfdc_users u on lower(w.primaryWorkEmail) = lower(u.username)
  left join main.sfdc_bronze.field_engineering_users__c f on f.Field_Engineering_User__c = u.id and f.processdate = (select max(processdate) from main.sfdc_bronze.field_engineering_users__c)
)
,
flight_school_enrollments_rank as (
  select rank() over (partition by learner_email order by enrolled_timestamp desc) as rank, *
  from main.field_learning_enablement.ilt_enrollments
  where processDate = (select max(processdate) from main.field_learning_enablement.ilt_enrollments)
  and course_id = 1009
)
,
flight_school_enrollments as (
  select *
  from flight_school_enrollments_rank
  where rank = 1
)
,
selling_winning as (
  select 
    learner_email, 
    max(completed_courses) as completed_courses,
    max(total_courses) as total_courses,
    max(lp_courses) as lp_courses,
    max(lp_enrollment_status) as lp_enrollment_status,
    max(lp_completed_timestamp) as lp_completed_timestamp
  from main.field_learning_enablement.selling_and_winning_learning_plan_details
  where processDate = (select max(processDate) from main.field_learning_enablement.selling_and_winning_learning_plan_details)
  group by all
)
,
level_info as (
  select
    u.*,
    g.requirement, 
    g.de_certified_flag,
    g.ml_certified_flag, 
    g.gen_ai_certified_flag,
    g.certified_flag, 
    g.certified_date,
    -- g.cert_earliest_expiry_date,
    l.completed_courses,
    l.total_courses,
    l.lp_courses,
    round(l.completed_courses/l.total_courses * 100, 1) as percent_completed,
    nvl(l.lp_enrollment_status, 'Not Enrolled') as selling_and_winning_status,
    case when l.lp_enrollment_status = 'Completed' then l.lp_completed_timestamp end as lp_completed_timestamp,
    nvl(e.status, 'Not Enrolled') as flight_school_status,
    case when e.status = 'completed' then e.completed_timestamp end as flight_school_completed_timestamp
    from fe_users u
    left join get_certified_manager g on lower(u.primaryWorkEmail) = lower(g.primaryWorkEmail)
    left join selling_winning l on lower(u.primaryWorkEmail) = lower(l.learner_email)
    left join flight_school_enrollments e on lower(u.sfdc_email) = lower(e.learner_email) 
)
,
exemptions as (
  select 
  case when lower(trim(email_of_the_ic_who_needs_exemption)) = 'will.block@databricks.com' then 'william.block@databricks.com'
  when lower(trim(email_of_the_ic_who_needs_exemption)) = 'homayoon@databricks.com' then 'homayoon.moradi@databricks.com'
  else lower(trim(email_of_the_ic_who_needs_exemption))
  end as email_of_the_ic_who_needs_exemption
  from temp_exemptions
)
,
expiry_dates as (
  select * from main.field_learning_enablement.accredible_credentials
  where processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
  and !is_expired
  and group_id in (
      '371215',
      '364119',
      '357057',
      '353856',
      '331743',
      '229201',
      '227965',
      '227818',
      '227970',
      '583499')
)
,
de_cert_expiry as (
  select  
    g.primaryWorkEmail,
    e.learner_email_hash,
    e.learner_alternate_email_hash,
    g.requirement,
    e.expired_on::date AS expiry_date,
    e.credential_name
  FROM main.field_learning_enablement.get_certified g
  LEFT JOIN expiry_dates e ON (
    sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
    OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
  )
  WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
    AND g.requirement = 'DE Cert' 
    AND e.credential_name ILIKE '%data engineer%'
),
de_cert_expiry_date as (
  SELECT 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  MIN(expiry_date) AS earliest_expiry_date,
  credential_name AS earliest_expiring_credential
FROM (
  SELECT 
    *,
    ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date) AS rn
  FROM de_cert_expiry
)
WHERE rn = 1
GROUP BY 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  credential_name
)
,
de_ml_gen_ai_cert_expiry as (
  select  
    g.primaryWorkEmail,
    e.learner_email_hash,
    e.learner_alternate_email_hash,
    g.requirement,
    e.expired_on::date AS expiry_date,
    e.credential_name
  FROM main.field_learning_enablement.get_certified g
  LEFT JOIN expiry_dates e ON (
    sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
    OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
  )
  WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
    AND g.requirement in ('DE Cert or ML or GenAI cert', 'DE and ML or GenAI Cert')
    AND (e.credential_name ILIKE '%data engineer%' or e.credential_name ilike '%machine learning%' or e.credential_name ilike '%data scientist%' or e.credential_name ilike '%Generative AI%')
),
de_ml_gen_ai_expiry_date as (
  SELECT 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  MIN(expiry_date) AS earliest_expiry_date,
  credential_name AS earliest_expiring_credential
  FROM (
    SELECT 
      *,
      ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date) AS rn
    FROM de_ml_gen_ai_cert_expiry
  )
  WHERE rn = 1
  GROUP BY 
    primaryWorkEmail,
    learner_email_hash,
    learner_alternate_email_hash,
    requirement,
    credential_name
)
,
earliest_expiry_dates as (
  select * from de_cert_expiry_date
  union all
  select * from de_ml_gen_ai_expiry_date
)
,
expired_certifications as (
  select * from main.field_learning_enablement.accredible_credentials
  where processDate = (select max(processDate) from main.field_learning_enablement.accredible_credentials)
  and is_expired
  and group_id in (
      '371215',
      '364119',
      '357057',
      '353856',
      '331743',
      '229201',
      '227965',
      '227818',
      '227970',
      '583499')
)
,
expired_de_cert as (
  select  
    g.primaryWorkEmail,
    e.learner_email_hash,
    e.learner_alternate_email_hash,
    g.requirement,
    e.expired_on::date AS expiry_date,
    e.credential_name
  FROM main.field_learning_enablement.get_certified g
  LEFT JOIN expired_certifications e ON (
    sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
    OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
  )
  WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
    AND g.requirement = 'DE Cert' 
    AND e.credential_name ILIKE '%data engineer%'
),
expired_de_cert_date as (
  SELECT 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  MAX(expiry_date) AS recently_expired_cert_date,
  MIN(expiry_date) AS oldest_expired_cert_date,
  credential_name AS recently_expired_cert
FROM (
  SELECT 
    *,
    ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date desc) AS rn
  FROM expired_de_cert
)
WHERE rn = 1
GROUP BY 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  credential_name
)
,
expired_de_ml_gen_ai_cert as (
  select  
    g.primaryWorkEmail,
    e.learner_email_hash,
    e.learner_alternate_email_hash,
    g.requirement,
    e.expired_on::date AS expiry_date,
    e.credential_name
  FROM main.field_learning_enablement.get_certified g
  LEFT JOIN expired_certifications e ON (
    sha2(lower(g.primaryWorkEmail), 256) = e.learner_email_hash
    OR sha2(lower(g.primaryWorkEmail), 256) = e.learner_alternate_email_hash
  )
  WHERE g.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.get_certified)
    AND g.requirement in ('DE Cert or ML or GenAI cert', 'DE and ML or GenAI Cert')
    AND (e.credential_name ILIKE '%data engineer%' or e.credential_name ilike '%machine learning%' or e.credential_name ilike '%data scientist%' or e.credential_name ilike '%Generative AI%')
),
expired_de_ml_gen_ai_date as (
  SELECT 
  primaryWorkEmail,
  learner_email_hash,
  learner_alternate_email_hash,
  requirement,
  max(expiry_date) AS recently_expired_cert_date,
  MIN(expiry_date) AS oldest_expired_cert_date,
  credential_name AS recently_expired_cert
  FROM (
    SELECT 
      *,
      ROW_NUMBER() OVER (PARTITION BY primaryWorkEmail ORDER BY expiry_date desc) AS rn
    FROM expired_de_ml_gen_ai_cert
  )
  WHERE rn = 1
  GROUP BY 
    primaryWorkEmail,
    learner_email_hash,
    learner_alternate_email_hash,
    requirement,
    credential_name
)
,
recent_expired_dates as (
  select * from expired_de_cert_date
  union all
  select * from expired_de_ml_gen_ai_date
)
,
required_certs_expired as (
  select 
  g.*,
    case when (r.requirement = 'DE or ML or GenAI Cert' or r.requirement = 'DE Cert or ML or GenAI cert')
    and months_between(current_date(),oldest_expired_cert_date) < 6
    then 1 
    when r.requirement = 'DE Cert' 
    and months_between(current_date(),oldest_expired_cert_date) < 6
    then 1
    when r.requirement = 'DE and ML or GenAI Cert' 
    and months_between(current_date(),oldest_expired_cert_date) < 6
    then 1
    else 0
  end as grace_period_flag
  from recent_expired_dates r
  left join main.field_learning_enablement.get_certified g on g.primaryWorkEmail = r.primaryWorkEmail
  and g.certified_flag = 0
)
,
final as (
select 
    l.*,
    case when (flight_school_status = 'completed' or tenure_in_months >= 12)  then true end as L100,
    case when flight_school_status = 'completed' then flight_school_completed_timestamp::date end as L100_date_completed,
    case when selling_and_winning_status = 'Completed' and (l.certified_flag = 1 or grace_period_flag = 1) then true end as L200,
    max(grace_period_flag) as grace_period_flag,
    earliest_expiry_date as earliest_future_expiry_date,
    earliest_expiring_credential,
    recently_expired_cert_date,
    recently_expired_cert,
    case when l.primaryWorkEmail in (select email_of_the_ic_who_needs_exemption from exemptions) then 1 else 0 end as temporary_exemption,
    case when selling_and_winning_status = 'Completed' and l.certified_flag = 1 then greatest(lp_completed_timestamp::date, l.certified_date::date) end L200_date_completed,
    'NA' as first_major,
    'NA' as second_major,
    'NA' as role_type,
    'NA' as specialization_major

from level_info l
left join required_certs_expired e on lower(l.primaryWorkEmail) = lower(e.primaryWorkEmail)
left join earliest_expiry_dates d on lower(l.primaryWorkEmail) = lower(d.primaryWorkEmail)
left join recent_expired_dates r on lower(l.primaryWorkEmail) = lower(r.primaryWorkEmail)
group by all
-- left join specialization s on l.primaryWorkEmail = s.email_address
)

select *, 'Manager' as employee_type
from final 
''')
# -- where L100 
# -- where L200


# COMMAND ----------

l200_final = (
  l200_df.unionAll(l200_manager_df)
)

# COMMAND ----------

l200_final.createOrReplaceTempView('l200_reporting')

# COMMAND ----------

l200_update_df = spark.sql('''
With spe_CTE as 
(
  select
  w.email
  ,null as Field_Engineering_User__c
  ,null as sfdc_id
  ,null as fe_users_name
  ,null as fe_users_id
  ,TRUE as L100
  ,FALSE as L200
  ,spe.processDate
  ,spe.learner_email as sfdc_email
  ,w.Name
  ,w.WorkdayID
  ,w.Worker_Type
  ,w.primaryWorkEmail
  ,w.Hire_Date
  ,null as Last_Promotion_Date
  ,w.Termination_Date
  ,null as Job_Profile_Prior_To_Last_Promotion_Date
  ,null as Business_Title_Prior_To_Last_Promotion_Date
  ,w.Cost_Center
  ,w.Location
  ,w.Location_Address_Country
  ,w.Job_Profile
  ,w.businessTitle
  ,w.Manager_Level_01
  ,w.Manager_Level_02
  ,w.Manager_Level_03
  ,w.Manager
  ,w.Manager_Email
  ,w.Supervisory_Organization
  ,w.Supervisory_Organization_cleaned
  ,null as Time_Zone
  ,null as Time_Zone_GMT_Factor
  ,w.Status
  ,w.Original_Hire_Date
  ,w.job_profile_start_date
  ,null as Last_Job_Req_Event_Date
  ,null as wd_id
  ,w.manager_hierarchy_path
  ,w.manager_hierarchy_path_name
  ,null as category
  ,null as department
  ,w.6th_level_manager
  ,w.5th_level_manager
  ,w.4th_level_manager
  ,w.3rd_level_manager
  ,w.2nd_level_manager
  ,w.1st_level_manager
  ,w.init_level_manager
  ,w.6th_level_manager_name
  ,w.5th_level_manager_name
  ,w.4th_level_manager_name
  ,w.3rd_level_manager_name
  ,w.2nd_level_manager_name
  ,w.1st_level_manager_name
  ,w.init_level_manager_name
  ,w.email_hash
  ,w.tenure_in_months
  ,"DE or ML or GenAI Cert" as requirement
  ,0 as de_certified_flag
  ,0 as ml_certified_flag
  ,0 as certified_flag
  ,null as certified_date
  ,7 as completed_courses
  ,7 as total_courses
  ,null as lp_courses
  ,null as Selling_Winning_Lakehouse_AI
  ,null as Selling_Winning_Lakehouse_Platform
  ,null as Selling_Winning_Data_Engineering
  ,null as Selling_Winning_Data_Governance
  ,null as Selling_Winning_Cloud_Architecture
  ,null as Selling_Winning_Data_Warehousing
  ,100 as percent_completed
  ,'Completed' as selling_and_winning_status
  ,spe.completed_timestamp as lp_completed_timestamp
  ,null as flight_school_status
  ,null as flight_school_completed_timestamp
  ,null as L100_date_completed
  ,to_date(spe.completed_timestamp) as L200_date_completed
  ,null as Selling_Winning_Overview
  ,null as Selling_Winning_Generative_AI
  ,null as Selling_Winning_Platform
  ,null as Selling_Winning_Data_Science_Machine_Learning
  ,"NA" as first_major
  ,"NA"as second_major
  ,"NA" as role_type
  ,case when w.org_size = 0 then 'IC' when w.org_size > 0 then 'Manager' else null end as employee_type
  ,null as Primary_Technical_Specialization__c
  ,"NA" as specialization_major
  ,null as Archetypes__c
  ,0 as gen_ai_certified_flag
  ,0 as temporary_exemption
  ,null as grace_period_flag
  ,null as earliest_expiry_date
  ,null as earliest_expiring_credential
  ,null as recently_expired_cert_date
  ,null as recently_expired_cert
  ,w.first_name
  ,w.last_name
  ,w.tenure_in_months_old
  ,w.job_role
  ,w.teamcategory
  ,w.is_manager
  ,w.is_director
  ,w.is_vp
  ,w.org_size
  ,w.profile_prior_to_promotion
  ,w.title_prior_to_promotion
  ,w.manager_workday_id
  ,w.AE_or_Non_AE
  ,w.L3
  ,w.L4
  ,w.L5
  ,w.L6
  ,w.L7
  ,w.L8
  ,w.L9
  ,w.L10
  ,w.L11
  ,w.name_L3
  ,w.name_L4
  ,w.manager_business_title
  ,w.employee_workday_id
  ,w.business_title
  ,w.direct_manager
  ,w.managerial_reporting_hierarchy_path
  ,w.L0
  ,w.L1
  ,w.L2
  from
  (select * from main.field_learning_enablement.self_paced_enrollments where course_code = 'ACAD-FENG-sp-v1-onboarding-s/w'
    and status = 'completed'
    and processDate = (select max(processDate) from main.field_learning_enablement.self_paced_enrollments) 
    ) spe
    left join
  (select * from Main.field_learning_enablement.workday where status = TRUE 
  and processDate = (select max(processDate) from Main.field_learning_enablement.workday)
  ) w
  on spe.learner_email = w.primaryWorkemail
  and spe.processDate = w.processDate
),

final_cte as
(
select 
l.email
,l.Field_Engineering_User__c
,l.sfdc_id
,l.fe_users_name
,l.fe_users_id
,l.L100
,case when spe_cte.selling_and_winning_status = 'Completed' and (l.certified_flag = 1 or l.grace_period_flag = 1) then true 
     else l.L200 end as L200
,l.processDate
,l.sfdc_email
,l.Name
,l.WorkdayID
,l.Worker_Type
,l.primaryWorkEmail
,l.Hire_Date
,null as Last_Promotion_Date
,l.Termination_Date
,null as Job_Profile_Prior_To_Last_Promotion_Date
,null as Business_Title_Prior_To_Last_Promotion_Date
,l.Cost_Center
,l.Location
,l.Location_Address_Country
,l.Job_Profile
,l.businessTitle
,l.Manager_Level_01
,l.Manager_Level_02
,l.Manager_Level_03
,l.Manager
,l.Manager_Email
,l.Supervisory_Organization
,l.Supervisory_Organization_cleaned
,null as Time_Zone
,null as Time_Zone_GMT_Factor
,l.Status
,l.Original_Hire_Date
,l.Job_Profile_Start_Date
,null as Last_Job_Req_Event_Date
,null as wd_id
,l.manager_hierarchy_path
,l.manager_hierarchy_path_name
,null as category
,null as department
,l.6th_level_manager
,l.5th_level_manager
,l.4th_level_manager
,l.3rd_level_manager
,l.2nd_level_manager
,l.1st_level_manager
,l.init_level_manager
,l.6th_level_manager_name
,l.5th_level_manager_name
,l.4th_level_manager_name
,l.3rd_level_manager_name
,l.2nd_level_manager_name
,l.1st_level_manager_name
,l.init_level_manager_name
,l.email_hash
,l.tenure_in_months
,l.requirement
,l.de_certified_flag
,l.ml_certified_flag
,l.certified_flag
,l.certified_date
,l.completed_courses
,l.total_courses
,l.lp_courses
,null as Selling_Winning_Lakehouse_AI
,null as Selling_Winning_Lakehouse_Platform
,null as Selling_Winning_Data_Engineering
,null as Selling_Winning_Data_Governance
,null as Selling_Winning_Cloud_Architecture
,null as Selling_Winning_Data_Warehousing
,l.percent_completed
,case 
when spe_cte.selling_and_winning_status = 'Completed' then 'Completed' else l.selling_and_winning_status end as selling_and_winning_status
,l.lp_completed_timestamp
,l.flight_school_status
,l.flight_school_completed_timestamp
,l.L100_date_completed
,l.L200_date_completed
,null as Selling_Winning_Overview
,null as Selling_Winning_Generative_AI
,null as Selling_Winning_Platform
,null as Selling_Winning_Data_Science_Machine_Learning
,l.first_major
,l.second_major
,l.role_type
,l.employee_type
,l.Primary_Technical_Specialization__c
,l.specialization_major
,l.Archetypes__c
,l.gen_ai_certified_flag
,l.temporary_exemption
,l.grace_period_flag
,l.earliest_expiry_date
,l.earliest_expiring_credential
,l.recently_expired_cert_date
,l.recently_expired_cert
,l.first_name
,l.last_name
,l.tenure_in_months_old
,l.job_role
,l.teamcategory
,l.is_manager
,l.is_director
,l.is_vp
,l.org_size
,l.profile_prior_to_promotion
,l.title_prior_to_promotion
,l.manager_workday_id
,l.AE_or_Non_AE
,l.L3
,l.L4
,l.L5
,l.L6
,l.L7
,l.L8
,l.L9
,l.L10
,l.L11
,l.name_L3
,l.name_L4
,l.manager_business_title
,l.employee_workday_id
,l.business_title
,l.direct_manager
,l.managerial_reporting_hierarchy_path
,l.L0
,l.L1
,l.L2
from 
(select * from l200_reporting 
) l
left join spe_cte
on l.primaryworkemail = spe_cte.primaryworkemail

union all

select s.* from spe_cte s
where primaryWorkEmail is not null 
and primaryWorkEmail not in (select distinct primaryWorkEmail from l200_reporting where primaryWorkEmail is not null 
)
)
select * from final_cte
 ''')

# COMMAND ----------

l200_gold = add_gold_metadata(l200_update_df)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Account Learners to MAUs - CEA Account KPIs

# COMMAND ----------

# DBTITLE 1,Learner Engagement Metrics Query
account_learners_to_maus = spark.sql('''
  with current_qtr as (
    select
      date,
      calendar_year_month,
      dateadd(month, -1, calendar_year_month)::date as previous_month, 
      fiscal_quarter_start_date,
      fiscal_quarter_end_date,
      prior_fiscal_quarter_end
    from
      main.it_core_dim.dim_dates
    where
      date = current_date
  )
  ,
  previous_qtr as (
    select
      distinct date_trunc('MM', fiscal_quarter_end_date)::date AS first_day_of_month
    from
      main.it_core_dim.dim_dates
    where
      fiscal_quarter_end_date = (
        select
          prior_fiscal_quarter_End
        from
          current_qtr
      )
  ),
  prev_qtr_fq2 as (
    select d.fiscal_year_quarter as fq2
    from previous_qtr q
    inner join main.it_core_dim.dim_dates d 
    on q.first_day_of_month = d.date
  )
  ,
  learners_all_time as (
  select
    updated_account_id,
    nvl(count(distinct learner_user_id), 0) as all_time_learners,
    nvl(
      count(
        distinct case
        when completed_date::date between dateadd(day,-91,current_date::date) and dateadd(day,-1,current_date::date)
         then learner_user_id
        end
      ),
      0
    ) as t90_learners,
    nvl(count(distinct case when fq2<=(select fq2 from prev_qtr_fq2) then learner_user_id end ),0) as previous_qtr_learners
  from
    main.field_learning_enablement.all_learners
  where
    processdate =(
      select
        max(processdate)
      from
        main.field_learning_enablement.all_learners
    )
    and dataset = "net new learners"
    and audience ilike '%Customer%' -- and updated_account_name ilike '%accenture%'
    and nvl(updated_account_id, 'Unknown') <> 'Unknown'
  group by
    1
),

    prev_qtr_maus as (
    with data as 
    (
      select m.salesforce_account_id as account_id,
      m.month,
      nvl(m.mau,0) as previous_qtr_maus
      from main.field_learning_enablement.monthly_active_users m 
      -- inner join previous_qtr q on m.month = q.month
      inner join previous_qtr q on m.month = q.first_day_of_month
      where m.processdate = (select max(processDate) from main.field_learning_enablement.monthly_active_users)
    )

    select * from data
    )
    ,
  
current_month_maus as (
  select 
    m.salesforce_account_id as account_id,
    -- m.month,
    nvl(m.mau,0) as current_month_maus
  from main.field_learning_enablement.monthly_active_users m 
  where processDate = (select max(processDate) from main.field_learning_enablement.monthly_active_users)
  and m.month = date_trunc('MONTH', now())::date
)
,
trailing_month_maus as (
  select 
    m.salesforce_account_id as account_id,
    m.month,
    nvl(m.mau,0) as trailing_month_maus
  from main.field_learning_enablement.monthly_active_users m 
  where processDate = (select max(processDate) from main.field_learning_enablement.monthly_active_users)
  --and m.month = dateadd(MONTH,-1, current_date)
  and m.month = date_trunc('month', dateadd(MONTH,-1, current_date))::date
)
,
account_list as (
  select
    nvl(m.account_id, l.updated_account_id) as account_id,
    nvl(m.previous_qtr_maus, 0) as previous_qtr_maus,
    nvl(l.all_time_learners, 0) as all_time_learners,
    nvl(l.t90_learners, 0) as t90_learners,
    nvl(l.previous_qtr_learners, 0) as previous_qtr_learners
  from
    prev_qtr_maus m full
    outer join learners_all_time l on m.account_id = l.updated_account_id
),
Training_revenue_FY23 AS (
  SELECT
    snapshot_date,
    account_id,
    sum(total_delivered_revenue) as Training_revenue_FY23
  FROM
    main.gtm_data.core_professional_services_delivered_revenue
  WHERE
    snapshot_date in (
      select
        max(snapshot_date)
      from
        main.gtm_data.core_professional_Services_delivered_revenue
    )
    AND delivered_fiscal_year_quarter in ("FY'23 Q1", "FY'23 Q2", "FY'23 Q3", "FY'23 Q4")
    AND practice_name in ("Training")
    AND timecard_or_milestone_status = 'Approved' -- and account_name='UBS Financial'
  GROUP BY
    1,
    2
),
Training_revenue_CFY AS (
  SELECT
    a.snapshot_date,
    a.account_id,
    sum(a.total_delivered_revenue) as current_year_revenue
  FROM
    main.gtm_data.core_professional_services_delivered_revenue a
  WHERE
    snapshot_date in (
      select
        max(snapshot_date)
      from
        main.gtm_data.core_professional_Services_delivered_revenue
    )
    AND delivered_fiscal_year in (
      select
        distinct fiscal_year
      from
        main.it_core_dim.dim_dates
      where
        date = current_date :: date
    )
    AND practice_name in ("Training")
    AND a.timecard_or_milestone_status = 'Approved' -- and account_name='UBS Financial'
    -- and account_name='Adobe Systems'
  GROUP BY
    1,
    2
),
Training_revenue_scheduled_CFY AS (
  SELECT
    snapshot_date,
    account_id,
    sum(backlog_detail_time_revenue) + sum(backlog_detail_milestone_revenue) as current_year_training_revenue_scheduled
  FROM
    main.gtm_data.core_professional_services_scheduled_backlog
  WHERE
    snapshot_date = (
      Select
        max(snapshot_date)
      from
        main.gtm_data.core_professional_services_scheduled_backlog
    )
    AND practice_name in ("Training")
    AND backlog_detail_end_fiscal_year in (
      select
        distinct fiscal_year
      from
        main.it_core_dim.dim_dates
      where
        date = current_date :: date
    )
  GROUP BY
    1,
    2
),
unscheduled_success_credits as (
  select
    *
  from
    users.janam_thakkar.unscheduled_backlog_training_fy24
) --get the current fiscal qtr


,

pre as 
(
select
  l1.all_time_learners,
  l1.t90_learners,
  l1.previous_qtr_learners,
  (l1.all_time_learners-l1.previous_qtr_learners)as qoq_learner_change,
  cast(round(l1.previous_qtr_maus,0) as double) as previous_qtr_maus,
  m.trailing_month_maus,
  nvl(c.current_month_maus,0) as current_month_maus,
  nvl(m.trailing_month_maus - l1.previous_qtr_maus,0) as qoq_mau_change,
  cfy.current_year_revenue,
  trs.current_year_training_revenue_scheduled,
  array_join(u.project_name_aggregate,",") as projects_w_unscheduled_success_credits,
  array_join(u.project_ids_aggregate,",") as projects_ids_w_unscheduled_success_credits,
  u.opportunity_id_aggregate as opps_w_unscheduled_success_credits,
  u.unallocated_success_credits_value,
  u.unallocated_success_credits_quantity,
  a.*
from
  account_list l1
  inner join main.gtm_data.core_Accounts_curated a on l1.account_id=a.account_id
  left join Training_revenue_CFY cfy on a.account_id = cfy.account_id
  left join trailing_month_maus m on a.account_id=m.account_id
  left join current_month_maus c on a.account_id=c.account_id
  left join Training_revenue_scheduled_CFY trs on a.account_id = trs.account_id
  left join unscheduled_success_credits u on a.account_id = u.account_id
)

select round((try_divide(qoq_learner_change,previous_qtr_learners)*100),2) as qoq_learner_change_pct,
round(try_divide(qoq_mau_change,previous_qtr_maus)*100,2) as qoq_mau_change_pct,* 
from pre

''')

# COMMAND ----------

account_learners_to_maus_gold = add_gold_metadata(account_learners_to_maus)

# COMMAND ----------

# DBTITLE 1,Spark Delta Table Writer
write_delta_table(
  spark, 
  dataframe = all_learners_gold, 
  table_name = f'{focus_database_name}.all_learners', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = certs_badges_gold, 
  table_name = f'{focus_database_name}.certifications_and_badges', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_enrollments_gold, 
  table_name = f'{focus_database_name}.all_enrollments', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = get_certified_gold, 
  table_name = f'{focus_database_name}.get_certified', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = get_certified_met_by_process_date_gold, 
  table_name = f'{focus_database_name}.get_certified_by_process_date', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = ongoing_learning_df_gold, 
  table_name = f'{focus_database_name}.ongoing_learning', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = learning_day_dates_gold, 
#   table_name = f'{focus_database_name}.learning_day_dates', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = flight_school_gold, 
  table_name = f'{focus_database_name}.flight_school_enrollments', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = flight_school_completions_gold, 
  table_name = f'{focus_database_name}.flight_school_completions', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = l200_gold, 
  table_name = f'{focus_database_name}.l200_reporting', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = account_learners_to_maus_gold, 
  table_name = f'{focus_database_name}.account_learners_to_maus_old', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = account_learners_to_maus_gold, 
  table_name = f'{focus_database_name}.cea_account_kpis', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Account Learners to MAUs Over Time

# COMMAND ----------

account_learners_to_maus_over_time = spark.sql('''
  with learners_all_time as (
    select
      updated_account_id,
      date_trunc('month',completed_date)::date as month, 
      nvl(count(distinct learner_user_id), 0) as learners
    from
      main.field_learning_enablement.all_learners
    where
      processdate =(
        select
          max(processdate)
        from
          main.field_learning_enablement.all_learners
      )
      and dataset = "net new learners"
      and audience ilike '%Customer%' -- and updated_account_name ilike '%accenture%'
      and nvl(updated_account_id, 'Unknown') <> 'Unknown'
    group by
      all
      order by all
  ),

   maus as 
   (
   select distinct m.salesforce_account_id as account_id, 
           m.month,
           nvl(m.num_users_t28d,0) as maus
   from main.field_learning_enablement.monthly_active_users m 
   where m.month is not null
   group by all
   order by all
 
   )
 
   ,

  pre as 
  (
  select nvl(m.account_id,l.updated_account_id) as account_id, 
        nvl(m.month, l.month)::date as month,
        nvl(maus,0) as maus,
        nvl(learners,0) as learners
  from maus m 
  full outer join learners_all_time l on m.account_id=l.updated_account_id and m.month=l.month
  order by 1,2
  )


  ,

  final as 
  (
  select *, sum(learners) over (partition by account_id order by month) as running_total_learners
  from pre
  group by all
  )

  ,


  final_2 as 
  (
  select 
  f.*, 
  c.* except (c.account_id)
  from final f 
  left join main.gtm_data.core_Accounts_curated c on f.account_id=c.account_id
  order by account_id, month
  )

  select * from final_2
        
                                               
''')

# COMMAND ----------

account_learners_to_maus_over_time_gold = add_gold_metadata(account_learners_to_maus_over_time)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = account_learners_to_maus_over_time_gold, 
  table_name = f'{focus_database_name}.account_learners_to_maus_over_time_old', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Opportunity Attach View
# MAGIC

# COMMAND ----------

opporunity_attach_df = spark.sql('''
  with learners_all_time as (
    select
      updated_account_id,
      count(distinct learner_user_id) as all_time_learners,
      count (
        distinct case
          when completed_date::date between dateadd(day,-91,current_date::date) and dateadd(day,-1,current_date::date)
          then learner_user_id
        end
      ) as t90_day_learners
    from
      main.field_learning_enablement.all_learners
    where
      processdate =(
        select
          max(processdate)
        from
          main.field_learning_enablement.all_learners
      )
      and dataset = "net new learners"
      and audience ilike '%Customer%' -- and updated_account_name ilike '%accenture%'
      and nvl(updated_account_id, 'Unknown') <> 'Unknown'
    group by
      1
  ),

   current_qtr as (
      select
        date,
        calendar_year_month,
        dateadd(month, -1, calendar_year_month)::date as previous_month, 
        fiscal_quarter_start_date,
        fiscal_quarter_end_date,
        prior_fiscal_quarter_end
      from
        main.it_core_dim.dim_dates
      where
        date = current_date
    )
  
  ,
  
  previous_qtr as (
      select
        distinct 
        --calendar_year_month as month,
        --fiscal_quarter_start_date,
        --fiscal_quarter_end_date,
        date_trunc('MM', fiscal_quarter_end_date)::date AS first_day_of_month
      from
        main.it_core_dim.dim_dates
      where
        fiscal_quarter_end_date = (
          select
            prior_fiscal_quarter_End
          from
            current_qtr
        )
    )
    
    
    -- select * from previous_qtr
    
    ,

    prev_qtr_maus as (
      select m.salesforce_account_id,
      m.month,
      nvl(m.mau,0) as previous_qtr_maus
      from main.field_learning_enablement.monthly_active_users m 
      -- inner join previous_qtr q on m.month = q.month
      inner join previous_qtr q on m.month = q.first_day_of_month
      where m.processdate=(Select max(processdate) from main.field_learning_enablement.monthly_active_users)
    )
  ,

  revenue as (
    select
      account_id,
      sum(case when delivered_fiscal_year= (select distinct fiscal_year from main.it_core_dim.dim_dates where date=current_date::date)
      then total_delivered_Revenue end
      )
      as cfy_delivered_revenue,
      sum(total_delivered_revenue) as total_delivered_revenue
    from
      main.gtm_data.core_professional_services_delivered_revenue
    where
      practice_name = "Training"
      and snapshot_date = (
        select
          max(snapshot_date)
        from
          main.gtm_data.core_professional_Services_delivered_revenue
      )
      and timecard_or_milestone_status in ("Approved") -- and status in
    group by
      1 
  ),
  scheduled_revenue as (
    SELECT
      account_id,
      sum(
        case
          when a.backlog_detail_end_fiscal_year_quarter = (Select distinct fiscal_year_quarter from main.it_core_dim.dim_dates where date=current_date::date) then a.backlog_detail_milestone_revenue
        end
      ) as cq_scheduled,
      sum(
        case
          when a.backlog_detail_end_fiscal_year_quarter > (Select distinct fiscal_year_quarter from main.it_core_dim.dim_dates where date=current_date::date) then a.backlog_detail_milestone_revenue
        end
      ) as future_scheduled
    FROM
      main.gtm_data.core_professional_services_scheduled_backlog a
    WHERE
      snapshot_date = (
        Select
          max(snapshot_date)
        from
          main.gtm_data.core_professional_services_scheduled_backlog
      )
      AND practice_name in ("Training") 
    GROUP BY
      1 
  )
  select
    a.opportunity_id as `Oppty_ID`,
    a.opportunity_name as `Oppty_Name`,
    a.close_date as `Oppty_Close_Date`,
    a.account_name as `Account_Name`,
    a.opportunity_stage as `Oppty_Stage`,
    a.forecast_category as `Fcst_Category`,
    a.oppty_contract_length as `Contract_Length_Months`,
    a.business_unit as `Business_Unit`,
    a.CSE_Subscription_Tier__c as `Account_DSA_Subscription_Tier`,
    a.implementation_partner_name as `Implementation_Partner_Name`,
    case
      when a.implementation_partner_name = "No Implementation Partner Involved" then "No"
      else "Yes"
    end as `Has_Implementation_Partner`,
    nvl(a.unused_success_credits_value, 0) as `Unused_Success_Credits_Value`,
    nvl(a.ps_bookings_incremental_booking, 0) as `Total_PS_Attach_Dollars`,
    nvl(a.success_credits_incremental_booking, 0) as `Success_Credits_Attach_Dollars`,
    nvl(a.dsa_incremental_booking, 0) as `DSA_Attach_Dollars`,
    nvl(a.training_incremental_booking, 0) as `Training_Attach_Dollars`,
    nvl(a.success_credits_incremental_booking, 0) as `Success_Credits_Incremental_Booking`,
    nvl(a.ps_bookings_incremental_booking, 0) + nvl(a.training_incremental_booking, 0) as `Total_Attach_Dollars`,
    a.total_opportunity_amount as `Total_Oppty_Amount`,
    nvl(a.incremental_booking_total_forecast, 0) as `Incremental_Booking_Dollars`,
    a.opportunity_subregion_level_1,
    a.opportunity_subregion_level_2,
    a.opportunity_subregion_level_3,
    a.opportunity_close_fiscal_year_month,
    a.opportunity_close_fiscal_year_quarter,
    a.opportunity_type,
    a.opportunity_owner,
    a.account_id,
    nvl(r.cfy_delivered_revenue, 0) as cfy_delivered_revenue,
    nvl(r.total_delivered_revenue, 0) as total_delivered_revenue_all_time,
    nvl(s.cq_scheduled, 0) as cq_scheduled,
    nvl(s.future_scheduled, 0) future_scheduled,
    (
      nvl(s.cq_scheduled, 0) + nvl(s.future_scheduled, 0)
    ) as total_scheduled,
    nvl(l.all_time_learners, 0) as all_time_learners,
    nvl(l.t90_day_learners, 0) as t90_day_learners,
    cast(nvl(m.previous_qtr_maus, 0) as double) as prev_qtr_maus,
    try_divide(l.all_time_learners, m.previous_qtr_maus) * 100 as learner_to_mau_ratio
  from
    main.gtm_data_internal.opportunity_product_attach_details a
    left join learners_all_time l on a.account_id = l.updated_account_id 
    left join prev_qtr_maus m on a.account_id = m.salesforce_account_id
    left join revenue r on a.account_id = r.account_id
    left join scheduled_revenue s on a.account_id = s.account_id
  where a.opportunity_stage not in ("Closed Lost", "Disqualified")
    and a.forecast_category not in ("Omitted")
  order by
    a.incremental_booking_total_forecast desc
''')

# COMMAND ----------

opporunity_attach_gold = add_gold_metadata(opporunity_attach_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = opporunity_attach_gold, 
  table_name = f'{focus_database_name}.opportunity_attach_view', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Milestone Data

# COMMAND ----------

milestone_df = spark.sql('''
with milestone_data as (
  select
    m.milestone_target_fiscal_year_quarter,
    m.milestone_target_fiscal_year,
    m.milestone_target_date,
    m.milestone_id,
    m.milestone_revenue_type,
    m.class_generated_project_id,
    m.class_name,
    case
      when m.class_custom_id = 12710 then 11083
      when m.class_custom_id = 12708 then 11082
      when m.class_custom_id = 14132 then 14131
      when m.class_custom_id = 13219 then 12632
      else m.class_custom_id
    end as class_custom_id,
    m.class_format,
    m.course,
    m.provider,
    m.milestone_name,
    m.milestone_amount,
    m.gaap_milestone_amount,
    m.milestone_status,
    m.is_milestone_approved,
    m.include_milestone_in_financial,
    m.billing_event_status,
    m.project_id,
    m.project_name,
    m.project_region,
    m.account_name,
    m.billing_invoice_date,
    p.account_id,
    -- m.business_unit,
    p.project_service_tier,
    p.project_Service_type,
    p.project_unscheduled_backlog,
    p.project_unused_success_credits,
    p.opportunity_id,
    p.parent_project_id,
    p.parent_project_name,
    a.sales_subregion_level_1,
    a.sales_subregion_level_2,
    a.sales_subregion_level_3,
    p1.id, 
    p1.OpportunityID_CaseSafe__c,
    -- c.sales_business_unit,
    -- p.business_unit as sales_business_unit, 
    a.sales_business_unit,
    c.opportunity_region_level_1
  from
    main.gtm_data.core_professional_services_milestones m
    inner join main.gtm_data.core_professional_services_dim_project p on m.project_id = p.project_id
    and p.snapshot_date =(
      select
        max(snapshot_date)
      from
        main.gtm_data.core_professional_services_dim_project
    )
    left join main.sfdc_bronze.pse__proj__c p1 on m.project_id=p1.id and p1.processdate=(select max(processdate) from main.sfdc_bronze.pse__proj__c)
    left join main.gtm_data.core_opportunity_curated c on  p1.OpportunityID_CaseSafe__c=c.opportunity_id
    left join main.gtm_data.core_accounts_curated a on a.account_id = p.account_id
  where
    m.snapshot_date =(
      select
        max(snapshot_date)
      from
        main.gtm_data.core_professional_services_milestones
    )
    and m.practice_name = 'Training'
    and m.milestone_status = "Approved"
    and p.project_service_type not in ('SCP', 'BIF')
  )
  -- milestone status - not in open and cancelled

  select * from milestone_data


''')

# COMMAND ----------

training_milestones_gold = add_gold_metadata(milestone_df)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = training_milestones_gold, 
  table_name = f'{focus_database_name}.training_milestones', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)