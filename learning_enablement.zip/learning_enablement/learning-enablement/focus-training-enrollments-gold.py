# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for training data \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "it_datamap_legacy/gsheet_utility/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
from pyspark.sql.functions import col, when

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

#SFDC Tables

sfdc_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.account",  "processDate")

sfdc_accounts = (
  spark.read.table("main.sfdc_bronze.account")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

sfdc_contacts = (
  spark.read.table("main.sfdc_bronze.contact")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

sfdc_leads = (
  spark.read.table("main.sfdc_bronze.lead")
    .filter(F.col("processDate") == sfdc_latest_process_date)
)

region_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.countryregionmap__c",  "processDate")

countries_regions = (
  spark.read.table("main.sfdc_bronze.countryregionmap__c")
  .filter(F.col("processDate") == region_latest_process_date)
  .select(
    # F.col("Name").alias("country_code"),
    F.col("Country__c").alias("country_name"),
    F.col("Region__c").alias("region")
  ).distinct()
)

# Docebo Logfood data
silver_docebo_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.docebo_self_paced_enrollments",  "processDate")

docebo_self_paced_enrollments = (
  spark.read.table("main.it_training_silver.docebo_self_paced_enrollments")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

docebo_ilt_enrollments = (
  spark.read.table("main.it_training_silver.docebo_ilt_enrollments")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

salesforce_account_email_domain_mapping = (
  spark.read.table("main.it_training_silver.docebo_salesforce_account_email_domain_mapping")
    .filter(~F.col("account_name").isin('Individual LMS Account', 'Individual LMS Account(Generic)', 'SFDC Test Customer', 'Databricks Partners Test'))
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

docebo_users = (
  spark.read.table("main.it_training_silver.docebo_users")
    .filter(F.col("processDate") == silver_docebo_latest_process_date)
    .drop("processDate")
)

# Blacklisted domains

blacklist_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.blacklist_domains",  "processDate")

blacklist_domains = (
  spark.read.table(f"{focus_database_name}.blacklist_domains")
    .filter(F.col("processDate") == blacklist_latest_process_date)
)

blacklist = [domain["blacklist_domain"] for domain in blacklist_domains.collect()]

historical_latest_process_date = get_latest_partition_value(spark, f"{focus_database_name}.historical_learndot_enrollments_self_paced",  "processDate")

# Learndot Historical ILT and Self Paced
ld_ilt = (
  spark.table(f"{focus_database_name}.historical_learndot_enrollments_ilt")
  .filter(F.col("processDate") == historical_latest_process_date)
    .drop("processDate")
)

ld_self_paced = (
  spark.table(f"{focus_database_name}.historical_learndot_enrollments_self_paced")
  .filter(F.col("processDate") == historical_latest_process_date)
    .drop("processDate")
)

# ld_latest_process_date = get_latest_partition_value(spark, "sfdc_ds.learndot__learndot_contact__c",  "processDate")

# ld_users = (
#   spark.table(f"sfdc_ds.learndot__learndot_contact__c")
#     .filter(F.col("processDate") == ld_latest_process_date)
#     .drop("processDate")
# )

# Updated Mappings

updated_docebo_users_process_date = get_latest_partition_value(spark, f"{focus_database_name}.docebo_users_test",  "processDate")

updated_docebo_users = (
  spark.table(f"{focus_database_name}.docebo_users_test")
    .filter(F.col("processDate") == updated_docebo_users_process_date)
    .select(
      'id', 
      'audience', 
      F.col('account_id').alias('updated_account_id'),
      F.col('account_name').alias('updated_account_name'),
      F.col('ultimate_parent_account_id').alias('updated_ultimate_parent_account_id'),
      F.col('ultimate_parent_account_name').alias('updated_ultimate_parent_account_name'),
      'match_method',
      'sfdc_contact_id',
      'sfdc_contact_type'
    )
)

updated_ilt_enrollments_process_date = get_latest_partition_value(spark, f"{focus_database_name}.ilt_enrollments_test",  "processDate")

updated_ilt_enrollments = (
  spark.table(f"{focus_database_name}.ilt_enrollments_test")
    .filter(F.col("processDate") == updated_ilt_enrollments_process_date)
      .select(
        'learner_user_id', 
        'course_id',
        'course_code',
        'enrolled_timestamp',
        'audience', 
        'status',
        F.col('account_id').alias('updated_account_id'),
        F.col('account_name').alias('updated_account_name'),
        F.col('ultimate_parent_account_id').alias('updated_ultimate_parent_account_id'),
        F.col('ultimate_parent_account_name').alias('updated_ultimate_parent_account_name'),
      'match_method'
      )
)

updated_self_paced_enrollments_process_date = get_latest_partition_value(spark, f"{focus_database_name}.self_paced_enrollments_test",  "processDate")

updated_self_paced_enrollments = (
  spark.table(f"{focus_database_name}.self_paced_enrollments_test")
    .filter(F.col("processDate") == updated_self_paced_enrollments_process_date)
    .select(
      'learner_user_id', 
      'course_id',
      'course_code',
      'enrolled_timestamp',
      'audience', 
      'status',
      F.col('account_id').alias('updated_account_id'),
      F.col('account_name').alias('updated_account_name'),
      F.col('ultimate_parent_account_id').alias('updated_ultimate_parent_account_id'),
      F.col('ultimate_parent_account_name').alias('updated_ultimate_parent_account_name'),
      'match_method'
    )
)

# Webassessor

webassessor_latest_process_date = get_latest_partition_value(spark, "main.it_training_silver.webassessor_users",  "processDate")

webassessor_users = (
  spark.table(f"main.it_training_silver.webassessor_users")
    .filter(F.col("processDate") == webassessor_latest_process_date)
    .drop("processDate")
)

# Partners (and Microsoft) were migrated from Learndot to Docebo on a different dates than other branches. We will need to filter enrollments based on branch and migration date

first_migration_branches = ["DBK_PRTNR", "DBK_MCSFT"]
first_migration_date = "2021-12-08"
second_migration_date = "2022-01-07"

databricks_account_id = "0016100001FyvmIAAR"

# COMMAND ----------

#unit tests to make sure dfs are pulled correctly
assert unit_test_df_count(sfdc_accounts) > 0

# unit tests to make sure parameters are set up correctly
catalog, database = focus_database_name.split('.')
assert unit_test_valid_db(database, spark, catalog)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

@udf("string")
def domainBlacklist(email_domain, alternate_email_domain):
  """ returns non blacklisted domains """
  if email_domain not in blacklist:
    domain = email_domain
  elif email_domain in blacklist and alternate_email_domain not in blacklist:
    domain = alternate_email_domain
  else:
    domain = None
  
  return domain

spark.udf.register("domainBlacklist", domainBlacklist)

@udf("string")
def learnerBranch(branch_name):
  """ returns mapped branch names """
  if branch_name == "Employee Academy":
    branch = "Databricks"
  elif branch_name == "Customer Academy":
    branch = "Academy"
  elif branch_name in ["Microsoft Academy", "Partner Academy"]:
    branch = "Partner"
  else:
    branch = None
  
  return branch

spark.udf.register("learnerBranch", learnerBranch)

# COMMAND ----------

# find correct email address to use per user (not blacklisted domains)

docebo_users_emails = (
  docebo_users
    .withColumn("email_domain_final", domainBlacklist("email_domain","alternate_email_domain"))
    .withColumn("learner_branch", learnerBranch("branch_name"))
)

assert unit_test_df_count(docebo_users) == unit_test_df_count(docebo_users_emails)

# COMMAND ----------

# unique mappings all domains
# use for partner branch

mapping_window = W.Window.partitionBy("email_domain").orderBy(F.desc("total_for_email_and_account"), "tiebreak")

accounts_df = (
  sfdc_accounts
    .select(
      F.col("Id").alias("ultimate_parent_account_id"),
      F.col("Name").alias("ultimate_parent_account_name")
    )
)

account_names = (
  sfdc_accounts
    .select(
      F.col("Id").alias("account_id"),
      F.col("ParentId").alias("ultimate_parent_account_id")
    )
    .join(accounts_df, "ultimate_parent_account_id", "left")
)

unique_partner_mappings = (
    salesforce_account_email_domain_mapping
    # filter for partner domains
    .filter(F.col("account_record_type") == "Partner")
    # keep only domains that appear more than 5 times
    .filter(F.col("total_for_email_and_account") >= 5)
    # filter out null domains
    .filter(F.col("email_domain").isNotNull())
    # find most common account for each domain
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(mapping_window))
    .filter(F.col("rank") == 1)
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

# COMMAND ----------

# unique mappings all accounts

account_window = W.Window.partitionBy("account_name").orderBy(F.desc("total_for_email_and_account"), "tiebreak")
domain_window = W.Window.partitionBy("email_domain").orderBy(F.desc("total_emails"), "tiebreak")

accounts_df = (
  sfdc_accounts
    .select(
      F.col("Id").alias("ultimate_parent_account_id"),
      F.col("Name").alias("ultimate_parent_account_name")
    )
)

account_names = (
  sfdc_accounts
    .select(
      F.col("Id").alias("account_id"),
      F.col("Name").alias("account_name"),
      F.col("ParentId").alias("ultimate_parent_account_id")
    )
    .join(accounts_df, "ultimate_parent_account_id", "left")
)

mapping_2_all = (
 salesforce_account_email_domain_mapping
    # remove any accounts without email domains
    .filter(F.col("email_domain").isNotNull())
    # keep domains that appear more than 5 times 
    .filter(F.col("total_for_email_and_account") >= 5)
    # rank to find most common email domain per account
    .groupBy(["email_domain", "account_id"])
    .agg(F.sum("total_for_email_and_account").alias("total_emails"))
    # rank to find most common domain for each account
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(domain_window))
    .filter(F.col("rank") == 1)
    .drop("total_emails", "tiebreak", "rank")
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

mapping_2_customer = (
 salesforce_account_email_domain_mapping
    # filter for only customer accounts
    .filter(F.col("account_record_type") == "Account")
    # keep domains that appear more than 5 times 
    .filter(F.col("total_for_email_and_account") >= 5)
    # remove any accounts without email domains
    .filter(F.col("email_domain").isNotNull())
    # rank to find most common email domain per account
    .groupBy(["email_domain", "account_id"])
    .agg(F.sum("total_for_email_and_account").alias("total_emails"))
    # rank to find most common domain for each account
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(domain_window))
    .filter(F.col("rank") == 1)
    .drop("total_emails", "tiebreak", "rank")
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

mapping_2_databricks = (
  salesforce_account_email_domain_mapping  
    # filter for databricks id
    .filter(F.col("account_id") == databricks_account_id)
    .filter(F.col("email_domain") == "databricks.com")
    # find most recent 
    .orderBy(F.col("account_last_modified_timestamp").desc())
    .limit(1)
    .select("email_domain", "account_id")
    .join(account_names, "account_id", "left")
    .select(
      F.col("email_domain").alias("email_domain_final"), 
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
    )
)

# COMMAND ----------

docebo_users_emails_academy = (
  docebo_users_emails
    .filter(F.col("learner_branch") == "Academy")
    # .filter(F.col("email_domain_final") != "databricks.com")
    .join(mapping_2_customer, "email_domain_final", "left")
)

docebo_users_emails_partner = (
  docebo_users_emails
    .filter(F.col("learner_branch") == "Partner")
    .join(unique_partner_mappings, "email_domain_final", "left")
)

docebo_users_emails_databricks = (
  docebo_users_emails
    .filter(F.col("learner_branch") == "Databricks")
    .join(mapping_2_databricks, "email_domain_final", "left")
)

docebo_users_emails_no_branch = (
  docebo_users_emails
    .filter(F.col("learner_branch").isNull())
    .join(mapping_2_all, "email_domain_final", "left")
)

docebo_users_accounts = (
  docebo_users_emails_academy
    .union(docebo_users_emails_partner)
    .union(docebo_users_emails_databricks)
    .union(docebo_users_emails_no_branch)
)

assert unit_test_df_count(docebo_users) == unit_test_df_count(docebo_users_accounts)

# COMMAND ----------

docebo_users_gold = (
  docebo_users_accounts
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("alternate_email_2"),
      F.col("alternate_email_2_hash"),
      F.col("alternate_email_2_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
    )
)

# COMMAND ----------

docebo_learner_ids_accounts = (
  docebo_users_accounts
    .select(
      F.col("id").alias("learner_user_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),      
    )
)

# COMMAND ----------

# partners and non partners were migrated at different times

docebo_self_paced_enrollments_partner = (
  docebo_self_paced_enrollments
    .filter(F.col("learner_branch_code").isin(first_migration_branches))
    .filter(F.col("enrolled_timestamp") >= first_migration_date)
)

docebo_self_paced_enrollments_not_partner = (
  docebo_self_paced_enrollments
    .filter(~F.col("learner_branch_code").isin(first_migration_branches))
    .filter(F.col("enrolled_timestamp") >= second_migration_date)
)

docebo_self_paced = (
  docebo_self_paced_enrollments_partner
    .union(docebo_self_paced_enrollments_not_partner)
)

docebo_ilt_enrollments_partner = (
  docebo_ilt_enrollments
    .filter(F.col("learner_branch_code").isin(first_migration_branches))
    .filter(F.col("enrolled_timestamp") >= first_migration_date)
)

docebo_ilt_enrollments_not_partner = (
  docebo_ilt_enrollments
    .filter(~F.col("learner_branch_code").isin(first_migration_branches))
    .filter(F.col("enrolled_timestamp") >= second_migration_date)
)

docebo_ilt = (
  docebo_ilt_enrollments_partner
    .union(docebo_ilt_enrollments_not_partner)
)

# COMMAND ----------

# enrollments with accounts

docebo_self_paced_enrollments_accounts = (
  docebo_self_paced
    .join(docebo_learner_ids_accounts, "learner_user_id", "left")
    .withColumn("source", F.lit("Docebo"))
    
)

docebo_ilt_enrollments_accounts = (
  docebo_ilt
    .join(docebo_learner_ids_accounts, "learner_user_id", "left")
    .withColumn("source", F.lit("Docebo"))
 
)

# COMMAND ----------

docebo_self_paced_enrollments_union_prep = (
  docebo_self_paced_enrollments_accounts
    .withColumn("learner_alternate_2_email", F.lit(None))
    .withColumn("learner_alternate_email_2_hash", F.lit(None))
    .withColumn("learner_alternate_email_2_domain", F.lit(None))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
    )
)

docebo_ilt_enrollments_union_prep = (
  docebo_ilt_enrollments_accounts
  .withColumn("audience_pre", F.lit(None))
  .withColumn("academy_session_number", F.lit(None))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      # F.col("learner_alternate_email_2").alias('learner_alternate_2_email'),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"), 
      F.col("learner_alternate_email_2_domain"),
      F.col("learner_branch_code"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("audience_pre"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("academy_session_number")
    )
)

# COMMAND ----------

def find_non_blacklist_domains_ld(df):
  blacklist = [domain["blacklist_domain"] for domain in blacklist_domains.collect()]
  
  return (
    df
    .withColumnRenamed("learner_email_domain", "learner_email_domain_temp")
    .withColumn("learner_email_domain", 
      F.when(~F.col("learner_email_domain_temp").isin(blacklist), F.col("learner_email_domain_temp"))
       .otherwise(None)
               )
    .drop("learner_email_domain_temp")
  )

# COMMAND ----------

ld_self_paced_non_blacklist = find_non_blacklist_domains_ld(ld_self_paced)
ld_ilt_non_blacklist = find_non_blacklist_domains_ld(ld_ilt)

# COMMAND ----------

ld_country_info = (
  docebo_users
    .select("email_hash", "country_code", "country_name")
)

# COMMAND ----------

# ld self paced enrollments with accounts

ld_self_paced_academy = (
  ld_self_paced_non_blacklist
    .filter(F.col("learner_branch") == "Academy")
    .join(mapping_2_customer, ld_self_paced_non_blacklist.learner_email_domain == mapping_2_customer.email_domain_final, "left")
)

ld_self_paced_partner = (
  ld_self_paced_non_blacklist
    .filter(F.col("learner_branch").isin(["Partner", "Microsoft"]))
    # .filter(F.col("learner_branch") == "Partner")
    .join(unique_partner_mappings, ld_self_paced_non_blacklist.learner_email_domain == unique_partner_mappings.email_domain_final, "left")
)

ld_self_paced_databricks = (
  ld_self_paced_non_blacklist
    .filter(F.col("learner_branch") == "Databricks")
    .join(mapping_2_databricks, ld_self_paced_non_blacklist.learner_email_domain == mapping_2_databricks.email_domain_final, "left")
)

ld_self_paced_no_branch = (
  ld_self_paced_non_blacklist
    .filter(F.col("learner_branch").isNull())
    .join(mapping_2_all, ld_self_paced_non_blacklist.learner_email_domain == mapping_2_all.email_domain_final, "left")
)

ld_self_paced_enrollments_accounts = (
  ld_self_paced_academy
    .union(ld_self_paced_partner)
    .union(ld_self_paced_databricks)
    .union(ld_self_paced_no_branch)
    .withColumn("source", F.lit("Learndot"))
)

ld_self_paced_enrollments_accounts_country = (
  ld_self_paced_enrollments_accounts
    .join(ld_country_info, ld_country_info.email_hash == ld_self_paced_enrollments_accounts.learner_email_hash, "left")
)

# ld ilt enrollments with accounts

ld_ilt_academy = (
  ld_ilt_non_blacklist
    .filter(F.col("learner_branch") == "Academy")
    .join(mapping_2_customer, ld_ilt_non_blacklist.learner_email_domain == mapping_2_customer.email_domain_final, "left")
)

ld_ilt_partner = (
  ld_ilt_non_blacklist
    .filter(F.col("learner_branch").isin(["Partner", "Microsoft"]))
    # .filter(F.col("learner_branch") == "Partner")
    .join(unique_partner_mappings, ld_ilt_non_blacklist.learner_email_domain == unique_partner_mappings.email_domain_final, "left")
)

ld_ilt_databricks = (
  ld_ilt_non_blacklist
    .filter(F.col("learner_branch") == "Databricks")
    .join(mapping_2_databricks, ld_ilt_non_blacklist.learner_email_domain == mapping_2_databricks.email_domain_final, "left")
)

ld_ilt_no_branch = (
  ld_ilt_non_blacklist
    .filter(F.col("learner_branch").isNull())
    .join(mapping_2_all, ld_ilt_non_blacklist.learner_email_domain == mapping_2_all.email_domain_final, "left")
)

ld_ilt_enrollments_accounts = (
  ld_ilt_academy
    .union(ld_ilt_partner)
    .union(ld_ilt_databricks)
    .union(ld_ilt_no_branch)
    .withColumn("source", F.lit("Learndot"))
)

ld_ilt_enrollments_accounts_country = (
  ld_ilt_enrollments_accounts
    .join(ld_country_info, ld_country_info.email_hash == ld_ilt_enrollments_accounts.learner_email_hash, "left")
)

# COMMAND ----------

ld_self_paced_enrollments_union_prep = (
  ld_self_paced_enrollments_accounts_country
    .withColumn("learner_alternate_2_email", F.lit(None))
    .withColumn("learner_alternate_email_2_hash", F.lit(None))
    .withColumn("learner_alternate_email_2_domain", F.lit(None))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_branch_code"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("author_email"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
    )
)

ld_ilt_enrollments_union_prep = (
  ld_ilt_enrollments_accounts_country
  .withColumn("learner_alternate_2_email", F.lit(None))
  .withColumn("learner_alternate_email_2_hash", F.lit(None))
  .withColumn("learner_alternate_email_2_domain", F.lit(None))
  .withColumn("audience_pre", F.lit(None))
  .withColumn("academy_session_number", F.lit(None))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("learner_branch_code"),
      F.col("session_id"),
      F.col("status"),
      F.col("waiting"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("evaluated_timestamp"),
      F.col("score"),
      F.col("session_name"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("category_code"),
      F.col("category_id"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("source"),
      F.col("audience_pre"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("academy_session_number")
    )
)

# COMMAND ----------

uplimit_latest_process_date = get_latest_partition_value(spark, "main.field_learning_enablement.uplimit_user_enrollments_bronze",  "processDate")

# Uplimit ILT 
uplimit_ilt_df = (
  spark.table("main.field_learning_enablement.uplimit_user_enrollments_bronze")
  .filter(F.col("processDate") == uplimit_latest_process_date)
  .filter(
      F.col("SessionName").contains("DAIS") | F.col("SessionName").contains("(PV)") | F.col("SessionName").contains("(Event - SUP)") |
      F.col("SessionName").contains("(Uplimit Only)")
  )
  .drop("processDate")
)

uplimit_ilt_df.createOrReplaceTempView("uplimit_ilt")


# COMMAND ----------

uplimit_dedupe = spark.sql('''
      WITH ranked_enrollments AS (
      SELECT *,
      ROW_NUMBER() OVER (PARTITION BY Email, Course, EnrollmentCreatedAt ORDER BY EnrollmentCreatedAt DESC) AS rn
      FROM uplimit_ilt
      )
      SELECT re.*,
      uu.email_hash,
      uu.email_domain,
      uu.branch_code,
      uu.user_id,
      uu.country,
      uu.country_code,
      uu.account_id,
      uu.account_name,
      uu.ultimate_parent_account_id,
      uu.ultimate_parent_account_name,
      uu.branch_name,
      uu.audience as audience_pre,
      'Uplimit' as source,
      CASE 
            WHEN re.CompletionStatus = 'COMPLETED' THEN 'completed'
            WHEN re.CompletionStatus = 'PENDING' THEN 'subscribed'
            WHEN re.CompletionStatus = 'PAST_DUE' THEN 'subscribed'
            ELSE re.CompletionStatus
      END AS status
      FROM ranked_enrollments re 
      INNER JOIN main.field_learning_enablement.uplimit_users uu
      ON re.Email = uu.Email and uu.processDate = (select max(processDate) from main.field_learning_enablement.uplimit_users)
      WHERE re.rn = 1
''')

# COMMAND ----------

# Align docebo_ilt_enrollments_union_prep (df2) to match df1 (ld_ilt_enrollments_union_prep)
uplimit_ilt_cleaned_data = (
    uplimit_dedupe
    .withColumn("learner_user_id", abs(hash(col("user_id"))).cast("BIGINT"))
    .withColumn("learner_email", col("Email"))
    .withColumn("learner_email_hash", col("email_hash"))
    .withColumn("learner_email_domain", col("email_domain"))
    .withColumn("learner_alternate_email", lit(None).cast("string"))
    .withColumn("learner_alternate_email_hash", lit(None).cast("string"))
    .withColumn("learner_alternate_email_domain", lit(None).cast("string"))
    .withColumn("learner_alternate_2_email", lit(None).cast("string"))
    .withColumn("learner_alternate_email_2_hash", lit(None).cast("string"))
    .withColumn("learner_alternate_email_2_domain", lit(None).cast("string"))
    .withColumn("learner_branch_code", col("branch_code"))
    .withColumn("status", col("status"))
    .withColumn("waiting", lit(None).cast("BIGINT"))
    #Need to check
    .withColumn("enrolled_timestamp", col("EnrollmentCreatedAt").cast("TIMESTAMP"))
    .withColumn("completed_timestamp", col("EnrollmentCompletedAt").cast("TIMESTAMP"))
    .withColumn("evaluated_timestamp", lit(None).cast("TIMESTAMP"))
    .withColumn("score", lit(None).cast("double"))
    .withColumn("session_name", col("SessionName"))
    .withColumn("course_id", col("CourseId").cast("BIGINT"))
    .withColumn("course_code", lit(None).cast("string"))
    .withColumn("course_name", col("Course"))
    .withColumn("academy_session_number", col("AcademySessionNumber"))
    #Hard coded to classroom
    .withColumn("course_type", lit(None).cast("string"))
    .withColumn("author_user_id", lit(None).cast("BIGINT"))
    .withColumn("author_email", lit(None).cast("string"))
    .withColumn("category_code", lit(None).cast("string"))
    .withColumn("category_id", lit(None).cast("BIGINT"))
    .withColumn("account_id", col("account_id"))
    .withColumn("account_name", col("account_name"))
    .withColumn("ultimate_parent_account_id", col("ultimate_parent_account_id"))
    .withColumn("ultimate_parent_account_name", col("ultimate_parent_account_name"))
    .withColumn("source", col("source"))
    .withColumn("country_code", col("country_code"))
    .withColumn("country_name", col("country"))
    .withColumn("session_id", col("SessionId").cast("BIGINT"))
    .withColumn("audience", col("audience_pre"))
    .select(  
        "learner_user_id",
        "learner_email",
        "learner_email_hash",
        "learner_email_domain",
        "learner_alternate_email",
        "learner_alternate_email_hash",
        "learner_alternate_email_domain",
        "learner_alternate_2_email",
        "learner_alternate_email_2_hash",
        "learner_alternate_email_2_domain",
        "learner_branch_code",
        "session_id",
        "status",
        "waiting",
        "enrolled_timestamp",
        "completed_timestamp",
        "evaluated_timestamp",
        "score",
        "session_name",
        "course_id",
        "course_code",
        "course_name",
        "academy_session_number",
        "course_type",
        "author_user_id",
        "author_email",
        "category_code",
        "category_id",
        "account_id",
        "account_name",
        "ultimate_parent_account_id",
        "ultimate_parent_account_name",
        "source",
        "audience_pre",
        "country_code",
        "country_name",
    )
)


# COMMAND ----------

all_self_paced_enrollments = (
  ld_self_paced_enrollments_union_prep
    .union(docebo_self_paced_enrollments_union_prep)
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      #F.col("audience_pre"),
      F.col("country_code"),
      F.col("country_name"),
    )
)

all_ilt_enrollments_v1 = (
  ld_ilt_enrollments_union_prep
    .union(docebo_ilt_enrollments_union_prep)
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("audience_pre"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("academy_session_number")
    )
)

all_ilt_enrollments = (
  all_ilt_enrollments_v1
    .unionByName(uplimit_ilt_cleaned_data)
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("audience_pre"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("academy_session_number")
    )
)

# COMMAND ----------

docebo_users_gold_cleaned_accounts = (
  docebo_users_gold
    .withColumnRenamed('ultimate_parent_account_id','ultimate_parent_account_id_raw')
    .withColumnRenamed('ultimate_parent_account_name','ultimate_parent_account_name_raw')
    .withColumn('ultimate_parent_account_id', F.coalesce('ultimate_parent_account_id_raw', 'account_id'))
    .withColumn('ultimate_parent_account_name', F.coalesce('ultimate_parent_account_name_raw', 'account_name'))
    .join(countries_regions, "country_name", "left")
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("alternate_email_2"),
      F.col("alternate_email_2_hash"),
      F.col("alternate_email_2_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)


# COMMAND ----------

all_self_paced_enrollments_cleaned_accounts = (
  all_self_paced_enrollments
    .withColumnRenamed('ultimate_parent_account_id','ultimate_parent_account_id_raw')
    .withColumnRenamed('ultimate_parent_account_name','ultimate_parent_account_name_raw')
    .withColumn('ultimate_parent_account_id', F.coalesce('ultimate_parent_account_id_raw', 'account_id'))
    .withColumn('ultimate_parent_account_name', F.coalesce('ultimate_parent_account_name_raw', 'account_name'))
    .join(countries_regions, "country_name", "left")
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)  


all_ilt_enrollments_cleaned_accounts = (
  all_ilt_enrollments
    .withColumnRenamed('ultimate_parent_account_id','ultimate_parent_account_id_raw')
    .withColumnRenamed('ultimate_parent_account_name','ultimate_parent_account_name_raw')
    .withColumn('ultimate_parent_account_id', F.coalesce('ultimate_parent_account_id_raw', 'account_id'))
    .withColumn('ultimate_parent_account_name', F.coalesce('ultimate_parent_account_name_raw', 'account_name'))
    .join(countries_regions, "country_name", "left")
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("learner_alternate_2_email"),
      F.col("learner_alternate_email_2_hash"),
      F.col("learner_alternate_email_2_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("audience_pre"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("academy_session_number")
    )
)

# COMMAND ----------

docebo_users_gold_cleaned_accounts_alt_emails = (
  docebo_users_gold_cleaned_accounts
    .withColumnRenamed('alternate_email', 'alternate_email_check')
    .withColumnRenamed('alternate_email_hash', 'alternate_email_hash_check')
    .withColumnRenamed('alternate_email_domain', 'alternate_email_domain_check')
    .withColumn('alternate_email', F.when(F.col('branch_code') == "DBK_EMP", F.col('alternate_email_2')).otherwise(F.col('alternate_email_check')))
    .withColumn('alternate_email_hash', F.when(F.col('branch_code') == "DBK_EMP", F.col('alternate_email_2_hash')).otherwise(F.col('alternate_email_hash_check')))
    .withColumn('alternate_email_domain', F.when(F.col('branch_code') == "DBK_EMP", F.col('alternate_email_2_domain')).otherwise(F.col('alternate_email_domain_check')))
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)


# COMMAND ----------

all_self_paced_enrollments_cleaned_accounts_alt_emails = (
  all_self_paced_enrollments_cleaned_accounts
    .withColumnRenamed('learner_alternate_email', 'learner_alternate_email_check')
    .withColumnRenamed('learner_alternate_email_hash', 'learner_alternate_email_hash_check')
    .withColumnRenamed('learner_alternate_email_domain', 'learner_alternate_email_domain_check')
    .withColumn('learner_alternate_email', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_2_email')).otherwise(F.col('learner_alternate_email_check')))
    .withColumn('learner_alternate_email_hash', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_email_2_hash')).otherwise(F.col('learner_alternate_email_hash_check')))
    .withColumn('learner_alternate_email_domain', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_email_2_domain')).otherwise(F.col('learner_alternate_email_domain_check')))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region")
    )
)

# COMMAND ----------

all_ilt_enrollments_cleaned_accounts_alt_emails = (
  all_ilt_enrollments_cleaned_accounts
    .withColumnRenamed('learner_alternate_email', 'learner_alternate_email_check')
    .withColumnRenamed('learner_alternate_email_hash', 'learner_alternate_email_hash_check')
    .withColumnRenamed('learner_alternate_email_domain', 'learner_alternate_email_domain_check')
    .withColumn('learner_alternate_email', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_2_email')).otherwise(F.col('learner_alternate_email_check')))
    .withColumn('learner_alternate_email_hash', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_email_2_hash')).otherwise(F.col('learner_alternate_email_hash_check')))
    .withColumn('learner_alternate_email_domain', F.when(F.col('learner_branch_code') == "DBK_EMP", F.col('learner_alternate_email_2_domain')).otherwise(F.col('learner_alternate_email_domain_check')))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("audience_pre"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col("academy_session_number")
    )
)



# COMMAND ----------

contact_dedupe_window = W.Window.partitionBy("Email").orderBy(F.desc("LastModifiedDate"), "tiebreak")
lead_dedupe_window = W.Window.partitionBy("Email").orderBy(F.desc("LastModifiedDate"), "tiebreak")
lead_contact_dedupe_window = W.Window.partitionBy("Email").orderBy(F.desc("account_id"),F.desc("LastModifiedDate"), "tiebreak")

sfdc_contact_dedupe = (
  sfdc_contacts
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(contact_dedupe_window))
    .filter(F.col("rank") == "1")
    .drop("tiebreak", "rank")
    .select(F.col("Email").alias('email'), F.col("Id").alias('sfdc_contact_id'), F.col("AccountId").alias('account_id'), F.col('LastModifiedDate'))
    .withColumn('sfdc_contact_type', F.lit('contact'))
    # ContactID_CaseSafe__c
)

sfdc_lead_dedupe = (
  sfdc_leads
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(lead_dedupe_window))
    .filter(F.col("rank") == "1")
    .drop("tiebreak", "rank")
    # .select(F.col("Email").alias('email'), F.col("Matched_SF_Account__c").alias('account_id'), F.col('LastModifiedDate'))
    .select(F.col("Email").alias('email'), F.col("Id").alias('sfdc_contact_id'), F.col("LeanData__Reporting_Matched_Account__c").alias('account_id'), F.col('LastModifiedDate'))
    .withColumn('sfdc_contact_type', F.lit('lead'))
)

sfdc_lead_contact_dedupe = (
  sfdc_contact_dedupe
    .union(sfdc_lead_dedupe)
    .withColumn("tiebreak", F.monotonically_increasing_id())
    .withColumn("rank", F.rank().over(lead_contact_dedupe_window))
    .filter(F.col("rank") == "1")
    .drop("tiebreak", "rank")
)

sfdc_lead_contact = (
  sfdc_lead_contact_dedupe
    .withColumn('email_hash', F.sha2(F.col('email'), 256))
    .select(F.col('account_id').alias('sfdc_account_id'), 'sfdc_contact_id')
)


# COMMAND ----------

docebo_users_gold_updated_accounts = (
  docebo_users_gold_cleaned_accounts_alt_emails
    .join(updated_docebo_users, 'id', 'left')
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('sfdc_contact_id').alias('sfdc_lead_or_contact_id'), 
      F.col('sfdc_contact_type')
    )
)

# COMMAND ----------

docebo_users_gold_updated_accounts_match = (
  docebo_users_gold_updated_accounts
    .join(sfdc_lead_contact, docebo_users_gold_updated_accounts.sfdc_lead_or_contact_id == sfdc_lead_contact.sfdc_contact_id, 'left')
    .withColumn('sfdc_and_updated_account_match', 
                F.when(F.col('updated_account_id') == F.col('sfdc_account_id'),1)
                .when(F.col('sfdc_lead_or_contact_id') == "unknown", F.lit('unknown'))
                .otherwise(0))
    .withColumnRenamed('sfdc_lead_or_contact_id', 'sfdc_lead_or_contact_id_pre')
    .withColumn('sfdc_lead_or_contact_id',
                F.when(F.col('updated_account_id') == F.col('sfdc_account_id'), F.col('sfdc_lead_or_contact_id_pre'))
                .otherwise(F.lit('unknown'))
                )
    .withColumnRenamed('sfdc_contact_type', 'sfdc_contact_type_pre')
    .withColumn('sfdc_contact_type',
                F.when(F.col('updated_account_id') == F.col('sfdc_account_id'), F.col('sfdc_contact_type_pre'))
                .otherwise(F.lit('unknown'))
                )
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('sfdc_lead_or_contact_id'), 
      F.col('sfdc_contact_type'),
      F.col('sfdc_and_updated_account_match')
    )
)

# COMMAND ----------

webassessor_users_countries_prim = (
  webassessor_users.select('email_hash', 'address_country', 'address_region').distinct()
)

webassessor_users_countries_alt = (
  webassessor_users.select(F.col('email_hash').alias('alternate_email_hash'), 'address_country', 'address_region').distinct()
)

docebo_users_webassessor_1 = (
  docebo_users_gold_updated_accounts_match
    .join(webassessor_users_countries_prim, 'email_hash', 'left')
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('sfdc_lead_or_contact_id'), 
      F.col('sfdc_contact_type'),
      F.col('sfdc_and_updated_account_match'),
      F.col('address_country').alias('country_webassessor'),
      F.col('address_region').alias('region_webassessor')
    )
    
)

docebo_users_webassessor_match_1 = (
  docebo_users_webassessor_1
  .filter(F.col("country_webassessor").isNotNull())
)

docebo_users_webassessor_match_2 = (
  docebo_users_webassessor_1
  .filter(F.col("country_webassessor").isNull())
  .drop('country_webassessor')
  .join(webassessor_users_countries_alt, 'alternate_email_hash', 'left')
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('sfdc_lead_or_contact_id'), 
      F.col('sfdc_contact_type'),
      F.col('sfdc_and_updated_account_match'),
      F.col('address_country').alias('country_webassessor'),
      F.col('address_region').alias('region_webassessor')
    )
)

docebo_users_gold_updated_accounts_match_webassessor = (
  docebo_users_webassessor_match_1
    .union(docebo_users_webassessor_match_2)
)

docebo_users_gold_updated_accounts_match_webassessor = (
  docebo_users_gold_updated_accounts_match_webassessor
    .withColumn('country_derived_pre', F.coalesce(F.col('country_webassessor'), F.col('country_name')))
    .withColumn('country_derived', F.coalesce(F.col('country_derived_pre'), F.lit('Unknown')))
    .withColumn('region_derived_pre', F.coalesce(F.col('region_webassessor'), F.col('region')))
    .withColumn('region_derived', F.coalesce(F.col('region_derived_pre'), F.lit('Unknown')))
    .select(
      F.col("id"),
      F.col("uuid"),
      F.col("first_name"),
      F.col("last_name"),
      F.col("email"),
      F.col("email_hash"),
      F.col("email_domain"),
      F.col("alternate_email"),
      F.col("alternate_email_hash"),
      F.col("alternate_email_domain"),
      F.col("username"),
      F.col("username_hash"),
      F.col("email_verified"),
      F.col("valid"),
      F.col("created_timestamp"),
      F.col("last_updated_timestamp"),
      F.col("suspended_timestamp"),
      F.col("last_login"),
      F.col("branch_code"),
      F.col("branch_name"),
      F.col("level"),
      F.col("timezone"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('sfdc_lead_or_contact_id'), 
      F.col('sfdc_contact_type'),
      F.col('sfdc_and_updated_account_match'),
      F.col('country_webassessor'),
      F.col('region_webassessor'),
      F.col('country_derived'),
      F.col('region_derived')
    )
)

# COMMAND ----------

current_ilt_enrollments_join_column = (
  all_ilt_enrollments_cleaned_accounts_alt_emails
    .withColumn('course_identifier', F.when(F.col('course_id').isNull(), F.col('course_code')).otherwise(F.col('course_id')))
    .withColumn('enrollment_id', F.regexp_replace(F.concat(F.col('learner_user_id'), F.lit('-') , F.col('course_identifier'), F.lit('-') , F.col('enrolled_timestamp'), F.lit('-') , F.col('status')), " ", "-"))
)


updated_ilt_enrollments_join_column = (
  updated_ilt_enrollments
    .withColumn('course_identifier', F.when(F.col('course_id').isNull(), F.col('course_code')).otherwise(F.col('course_id')))
    .withColumn('enrollment_id', F.regexp_replace(F.concat(F.col('learner_user_id'), F.lit('-') , F.col('course_identifier'), F.lit('-') , F.col('enrolled_timestamp'), F.lit('-') , F.col('status')), " ", "-"))
    .select(
      'enrollment_id', 
      'audience', 
      'updated_account_id', 
      'updated_account_name', 
      'updated_ultimate_parent_account_id', 
      'updated_ultimate_parent_account_name',
      'match_method')
    .distinct()
)

all_ilt_enrollments_gold_v1 = (
  current_ilt_enrollments_join_column
    .join(updated_ilt_enrollments_join_column, 'enrollment_id', 'left')
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col("audience_pre"),
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col("academy_session_number")
    )
)

uplimit_enrollments = (
  all_ilt_enrollments_gold_v1
  .filter(F.col('source') == 'Uplimit')
  .withColumn('updated_account_id', F.col('account_id'))
  .withColumn('updated_account_name', F.col('account_name'))
  .withColumn('updated_ultimate_parent_account_id', F.col('account_id'))
  .withColumn('updated_ultimate_parent_account_name', F.col('account_name'))
  .withColumn('audience', F.coalesce("audience_pre", "audience"))
)

other_enrollments = (
  all_ilt_enrollments_gold_v1
  .filter(F.col('source') != 'Uplimit')
)

all_ilt_enrollments_gold = (
  uplimit_enrollments.unionByName(other_enrollments)
  .select(
    F.col("learner_user_id"),
    F.col("learner_email"),
    F.col("learner_email_hash"),
    F.col("learner_email_domain"),
    F.col("learner_alternate_email"),
    F.col("learner_alternate_email_hash"),
    F.col("learner_alternate_email_domain"),
    F.col("account_id"),
    F.col("account_name"),
    F.col("ultimate_parent_account_id"),
    F.col("ultimate_parent_account_name"),
    F.col("learner_branch_code"),
    F.col("course_id"),
    F.col("course_code"),
    F.col("course_name"),
    F.col("course_type"),
    F.col("category_id"),
    F.col("category_code"),
    F.col("author_user_id"),
    F.col("author_email"),
    F.col("status"),
    F.col("enrolled_timestamp"),
    F.col("completed_timestamp"),
    F.col("score"),
    F.col("evaluated_timestamp"),
    F.col("session_id"),
    F.col("session_name"),
    F.col("waiting"),
    F.col("source"),
    F.col("country_code"),
    F.col("country_name"),
    F.col("region"),
    F.col('audience'),
    F.col('audience_pre'), 
    F.col('updated_account_id'),
    F.col('updated_account_name'),
    F.col('updated_ultimate_parent_account_id'),
    F.col('updated_ultimate_parent_account_name'),
    F.col('match_method'),
    F.col('academy_session_number')
  )
)


# COMMAND ----------

webassessor_users_countries_prim = (
  webassessor_users.select(F.col('email_hash').alias('learner_email_hash'), 'address_country', 'address_region').distinct()
)

webassessor_users_countries_alt = (
  webassessor_users.select(F.col('email_hash').alias('learner_alternate_email_hash'), 'address_country', 'address_region').distinct()
)

all_ilt_enrollments_gold_1 = (
  all_ilt_enrollments_gold
    .join(webassessor_users_countries_prim, 'learner_email_hash', 'left')
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('address_country').alias('country_webassessor'),
      F.col('address_region').alias('region_webassessor'),
      F.col('academy_session_number')
    )
    
)

all_ilt_enrollments_webassessor_match_1 = (
  all_ilt_enrollments_gold_1
  .filter(F.col("country_webassessor").isNotNull())
)

all_ilt_enrollments_webassessor_match_2 = (
  all_ilt_enrollments_gold_1
  .filter(F.col("country_webassessor").isNull())
  .drop('country_webassessor')
  .join(webassessor_users_countries_alt, 'learner_alternate_email_hash', 'left')
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('address_country').alias('country_webassessor'),
      F.col('address_region').alias('region_webassessor'),
      F.col("academy_session_number")
    )
)

all_ilt_enrollments_match_webassessor = (
  all_ilt_enrollments_webassessor_match_1
    .union(all_ilt_enrollments_webassessor_match_2)
)

all_ilt_enrollments_gold_updated_accounts_match_webassessor = (
  all_ilt_enrollments_match_webassessor
    .withColumn('country_derived_pre', F.coalesce(F.col('country_webassessor'), F.col('country_name')))
    .withColumn('country_derived', F.coalesce(F.col('country_derived_pre'), F.lit('Unknown')))
    .withColumn('region_derived_pre', F.coalesce(F.col('region_webassessor'), F.col('region')))
    .withColumn('region_derived', F.coalesce(F.col('region_derived_pre'), F.lit('Unknown')))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("evaluated_timestamp"),
      F.col("session_id"),
      F.col("session_name"),
      F.col("waiting"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('country_webassessor'),
      F.col('region_webassessor'),
      F.col('country_derived'),
      F.col('region_derived'),
      F.col("academy_session_number")
    )
)

# COMMAND ----------

current_self_paced_enrollments_join_column = (
  all_self_paced_enrollments_cleaned_accounts_alt_emails
    .withColumn('course_identifier', F.when(F.col('course_id').isNull(), F.col('course_code')).otherwise(F.col('course_id')))
    .withColumn('enrollment_id', F.regexp_replace(F.concat(F.col('learner_user_id'), F.lit('-') , F.col('course_identifier'), F.lit('-') , F.col('enrolled_timestamp'), F.lit('-') , F.col('status')), " ", "-"))
)


updated_self_paced_enrollments_join_column = (
  updated_self_paced_enrollments
    .withColumn('course_identifier', F.when(F.col('course_id').isNull(), F.col('course_code')).otherwise(F.col('course_id')))
    .withColumn('enrollment_id', F.regexp_replace(F.concat(F.col('learner_user_id'), F.lit('-') , F.col('course_identifier'), F.lit('-') , F.col('enrolled_timestamp'), F.lit('-') , F.col('status')), " ", "-"))
    .select(
      'enrollment_id', 
      'audience', 
      'updated_account_id', 
      'updated_account_name', 
      'updated_ultimate_parent_account_id', 
      'updated_ultimate_parent_account_name',
      'match_method'
    ).distinct()
)

all_self_paced_enrollments_gold = (
  current_self_paced_enrollments_join_column
    .join(updated_self_paced_enrollments_join_column, 'enrollment_id', 'left')
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method')
    )
)

# COMMAND ----------

webassessor_users_countries_prim = (
  webassessor_users.select(F.col('email_hash').alias('learner_email_hash'), 'address_country', 'address_region').distinct()
)

webassessor_users_countries_alt = (
  webassessor_users.select(F.col('email_hash').alias('learner_alternate_email_hash'), 'address_country', 'address_region').distinct()
)

all_self_paced_enrollments_gold_1 = (
  all_self_paced_enrollments_gold
    .join(webassessor_users_countries_prim, 'learner_email_hash', 'left')
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('address_country').alias('country_webassessor'),
      F.col('address_region').alias('region_webassessor')
    )
    
)

all_self_paced_enrollments_webassessor_match_1 = (
  all_self_paced_enrollments_gold_1
  .filter(F.col("country_webassessor").isNotNull())
)

all_self_paced_enrollments_webassessor_match_2 = (
  all_self_paced_enrollments_gold_1
  .filter(F.col("country_webassessor").isNull())
  .drop('country_webassessor')
  .join(webassessor_users_countries_alt, 'learner_alternate_email_hash', 'left')
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('address_country').alias('country_webassessor'),
      F.col('address_region').alias('region_webassessor')
    )
)

all_self_paced_enrollments_match_webassessor = (
  all_self_paced_enrollments_webassessor_match_1
    .union(all_self_paced_enrollments_webassessor_match_2)
)

all_self_paced_enrollments_gold_updated_accounts_match_webassessor = (
  all_self_paced_enrollments_match_webassessor
    .withColumn('country_derived_pre', F.coalesce(F.col('country_webassessor'), F.col('country_name')))
    .withColumn('country_derived', F.coalesce(F.col('country_derived_pre'), F.lit('Unknown')))
    .withColumn('region_derived_pre', F.coalesce(F.col('region_webassessor'), F.col('region')))
    .withColumn('region_derived', F.coalesce(F.col('region_derived_pre'), F.lit('Unknown')))
    .select(
      F.col("learner_user_id"),
      F.col("learner_email"),
      F.col("learner_email_hash"),
      F.col("learner_email_domain"),
      F.col("learner_alternate_email"),
      F.col("learner_alternate_email_hash"),
      F.col("learner_alternate_email_domain"),
      F.col("account_id"),
      F.col("account_name"),
      F.col("ultimate_parent_account_id"),
      F.col("ultimate_parent_account_name"),
      F.col("learner_branch_code"),
      F.col("course_id"),
      F.col("course_code"),
      F.col("course_name"),
      F.col("course_type"),
      F.col("category_id"),
      F.col("category_code"),
      F.col("author_user_id"),
      F.col("author_email"),
      F.col("status"),
      F.col("enrolled_timestamp"),
      F.col("completed_timestamp"),
      F.col("score"),
      F.col("source"),
      F.col("country_code"),
      F.col("country_name"),
      F.col("region"),
      F.col('audience'), 
      F.col('updated_account_id'),
      F.col('updated_account_name'),
      F.col('updated_ultimate_parent_account_id'),
      F.col('updated_ultimate_parent_account_name'),
      F.col('match_method'),
      F.col('country_webassessor'),
      F.col('region_webassessor'),
      F.col('country_derived'),
      F.col('region_derived')
    )
)

# COMMAND ----------

# all_ilt_enrollments_cleaned_accounts_partition = add_gold_metadata(all_ilt_enrollments_cleaned_accounts_alt_emails)
# all_self_paced_enrollments_cleaned_accounts_partition = add_gold_metadata(all_self_paced_enrollments_cleaned_accounts_alt_emails)
# docebo_users_gold_cleaned_accounts_partition = add_gold_metadata(docebo_users_gold_cleaned_accounts_alt_emails)

# COMMAND ----------

docebo_users_gold_updated_accounts_match_webassessor.createOrReplaceTempView('docebo_users_pre')

# COMMAND ----------

docebo_users_greenfield_df = spark.sql('''
  with docebo_users as (
    select *
    from docebo_users_pre
  )
  ,
  greenfield as (
    SELECT
      ca.account_id,
      CASE WHEN ba.accountspendtier__c = 'Greenfield'
          AND lower(ba.Owner_Role__c) not like '%unassigned%'
          AND ca.business_unit is not null
          AND ca.dbx in ('DB400','DB3000')   
              THEN 'Yes'
      ELSE 'No' 
      END as greenfield_account
      FROM main.gtm_data.core_accounts_curated ca
      LEFT JOIN main.sfdc_bronze.account ba 
        ON ca.account_id = ba.AccountID_CaseSafe__c
      AND ba.processDate IN (SELECT MAX(processDate) FROM main.sfdc_bronze.account)
  )
  


  select 
    d.* except (account_name, account_id, updated_account_name, updated_account_id),
    g.greenfield_account,
    nvl(b.sales_business_unit, "Unknown") as business_unit,
    nvl(b.sales_subregion_level_1, "Unknown") as sales_subregion_level_1,
    nvl(b.sales_subregion_level_2, "Unknown") as sales_subregion_level_2,
    nvl(b.sales_subregion_level_3, "Unknown") as sales_subregion_level_3, 
    c.fiscal_year_quarter as fq2,
    CASE 
        WHEN email_domain LIKE '%nab.com.au%' OR alternate_email_domain LIKE '%nab.com.au%' 
        THEN 'NAB'
        ELSE d.updated_account_name
    END as updated_account_name,
    CASE 
        WHEN email_domain LIKE '%nab.com.au%' OR alternate_email_domain LIKE '%nab.com.au%' 
        THEN 'NAB'
        ELSE d.account_name
    END as account_name,
    CASE 
        WHEN email_domain LIKE '%nab.com.au%' OR alternate_email_domain LIKE '%nab.com.au%' 
        THEN '0016100000Y5d0pAAB'
        ELSE d.updated_account_id
    END as updated_account_id,
    CASE 
        WHEN email_domain LIKE '%nab.com.au%' OR alternate_email_domain LIKE '%nab.com.au%' 
        THEN '0016100000Y5d0pAAB'
        ELSE d.account_id
    END as account_id
  from docebo_users d
  left join main.gtm_data.core_accounts_curated b on d.updated_account_id=b.account_id and b.snapshot_date = (select max(snapshot_date) from main.gtm_data.core_accounts_curated)
  left join greenfield g on d.updated_account_id=g.account_id
  left join main.it_core_dim.dim_dates c on d.created_timestamp::date = c.date
''')

# COMMAND ----------

try:
  sht = authGoogleSheet("Timezone mapping")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')
  
  
try:
  worksheet = sht.worksheet("timezone_country")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


readGoogleSheet(
 "Timezone mapping",
 "timezone_country",
 "mapping_data",
 clean_column_names="true", 
 make_columns_unique="true"
)


# COMMAND ----------

region_latest_process_date = get_latest_partition_value(spark, "main.sfdc_bronze.countryregionmap__c",  "processDate")

countries_regions = (
  spark.read.table("main.sfdc_bronze.countryregionmap__c")
  .filter(F.col("processDate") == region_latest_process_date)
  .select(
    # F.col("Name").alias("country_code"),
    F.col("Country__c").alias("country_name"),
    F.col("Region__c").alias("region")
  ).distinct()
).createOrReplaceTempView("countries_regions")

# COMMAND ----------

mapping_data_df = spark.sql('''
                            select mp.*, cr.region
                            from countries_regions cr
                            left join mapping_data mp on mp.country_name = cr.country_name
                            ''')

# COMMAND ----------

docebo_users_gold_enriched = (
    docebo_users_greenfield_df.alias("d")
    .join(mapping_data_df.alias("m"), col("d.timezone") == col("m.time_zone"), "left")
    .withColumn(
        "country_derived",
        when(
            (col("d.country_name").isNull()) | (col("d.country_name") == "Unknown"),
            col("m.country_name")
        ).otherwise(col("d.country_name"))
    ).withColumn(
        "region_derived",
        when(
            (col("d.region_derived").isNull()) | (col("d.region_derived") == "Unknown"),
            col("m.region")
        ).otherwise(col("d.region_derived"))
    )
    .select("d.*", "country_derived", "region_derived")
)

# COMMAND ----------

docebo_users_gold_enriched = (
    docebo_users_gold_enriched
    .withColumn(
        "country_derived",
        when(col("country_derived").isNull(), lit("Unknown")).otherwise(col("country_derived"))
    )
    .withColumn(
        "region_derived",
        when(col("region_derived").isNull(), lit("Unknown")).otherwise(col("region_derived"))
    )
)


# COMMAND ----------

all_ilt_enrollments_cleaned_accounts_partition = add_gold_metadata(all_ilt_enrollments_gold_updated_accounts_match_webassessor)
all_self_paced_enrollments_cleaned_accounts_partition = add_gold_metadata(all_self_paced_enrollments_gold_updated_accounts_match_webassessor)
docebo_users_gold_cleaned_accounts_partition = add_gold_metadata(docebo_users_gold_enriched)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_ilt_enrollments_cleaned_accounts_partition, 
  table_name = f'{focus_database_name}.ilt_enrollments', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = all_self_paced_enrollments_cleaned_accounts_partition, 
  table_name = f'{focus_database_name}.self_paced_enrollments', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = docebo_users_gold_cleaned_accounts_partition, 
  table_name = f'{focus_database_name}.docebo_users', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'"
)