# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for instructor utilzation from Airtable \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Workspace/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import requests

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

import pandas as pd


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

def convertToDF(data):
  """
    data is a list of objects
  """
  json_obj = {}
  
  json_obj['field'] = data

  df = pd.json_normalize(json_obj['field'])
  lst = list(df)
  df[lst] = df[lst].astype(str)

  spark_df = (
    spark
      .createDataFrame(df)
  )
  return spark_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

# MAGIC %md ### FY24 Instructors

# COMMAND ----------

airtable_pat = dbutils.secrets.get('ldr-airtable', 'airtable-token')

# COMMAND ----------

# url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Instructors?view=All%20Resources"
# headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

# fy24_instructor_records = []
# response = requests.request("GET", url, headers=headers)
# response_json = response.json()


# fy24_instructor_records += response_json['records']
# while 'offset' in response_json:
#   response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
#   response_json = response.json()
#   fy24_instructor_records += response_json['records']

# fy24_instructor_data = []
# for record in fy24_instructor_records:
#   fields = record['fields']
#   if 'Instructor Email' in fields:
#     instructor = {
#       'id': record['id'],
#       'email': fields['Instructor Email'],
#       'organization_name': fields.get('Organization Name', ''),
#       'location_country': fields.get('Country', '')
#     }
#     fy24_instructor_data.append(instructor)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### FY24 Base

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/ILT%20Schedule?view=%5BMASTER-ALL%5D%20Public%20%2B%20Private%20%7C%20ILT%20Schedule"
# headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()

# pprint(response_json)

records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  records += response_json['records']


# COMMAND ----------

records_df = convertToDF(records)
records_df.createOrReplaceTempView('fy24_records_raw')

# COMMAND ----------

fy24_df = spark.sql('''
select 
`id` as id,
`createdTime` as createdtime,
`fields.Language` as language,
`fields.Academy Session #` as academy_session_num,
-- `fields.Start Date [FORM].error` as start_date_form_error,
-- `fields.End Date [FORM].error` as end_date_form_error,
-- `fields.Instructor Led Training / Project Name.error` as instructor_led_training_project_name_error,
-- `fields.Month.error` as month_error,
-- `fields.Quarter.error` as quarter_error,
-- `fields.Quarter + FY.error` as quarter_and_fy_error,
`fields.# Enrollments` as num_enrollments,
-- `fields.Year.specialValue` as year_specialvalue,
-- `fields.ILT Name [FORM].error` as ilt_name_form_error,
-- `fields.Week # - End Date.error` as week_num_end_date_error,
-- `fields.FY.error` as fy_error,
`fields.[SFDC] PR Name: Region + Timezone` as sfdc_pr_name_region_and_timezone,
-- `fields.Course Times.error` as course_times_error,
-- `fields.Course Dates.error` as course_dates_error,
`fields.Created By.id` as created_by_id,
`fields.Created By.email` as created_by_email,
`fields.Created By.name` as created_by_name,
-- `fields.[SFDC] Name: Date.error` as sfdc_name_date_error,
-- `fields.Class Time.error` as class_time_error,
-- `fields.StartDoW.error` as startdow_error,
`fields.DB Zoom? [Control Reporting]` as db_zoom_control_reporting,
-- `fields.Cohort Start Date.error` as cohort_start_date_error,
`fields.ILT Readiness` as ilt_readiness,
`fields.LOB (Line of Business)` as lob_line_of_business,
-- `fields.Docebo - End Time.error` as docebo_end_time_error,
-- `fields.Docebo - Start Time.error` as docebo_start_time_error,
-- `fields.ILT Duration (Days).specialValue` as ilt_duration_days_specialvalue,
-- `fields.ILT Duration (Hours).error` as ilt_duration_hours_error,
-- `fields.Monday Hours.error` as monday_hours_error,
-- `fields.Tuesday Hours.error` as tuesday_hours_error,
-- `fields.Wednesday Hours.error` as wednesday_hours_error,
-- `fields.Thursday Hours.error` as thursday_hours_error,
-- `fields.Friday Hours.error` as friday_hours_error,
-- `fields.HDUs.error` as hdus_error,
-- `fields.home zone.error` as home_zone_error,
`fields.Created Date` as created_date,
`fields.Revenue: SKUs` as revenue_skus,
`fields.Revenue: Credit Card` as revenue_credit_card,
`fields.Total Revenue` as total_revenue,
`fields.Calculation` as calculation,
`fields.Projects` as projects,
`fields.Training Type` as training_type,
`fields.[SFDC] Project Manager` as sfdc_project_manager,
`fields.Provider (2)` as provider_2,
`fields.Course/Project` as course_project,
`fields.Course Name` as course_name,
`fields.Course Abbreviation (from Course/Project)` as course_abbreviation_from_course_project,
`fields.Course Duration (Days)` as course_duration_days,
`fields.Course Duration (Hours)` as course_duration_hours,
`fields.Course Type` as course_type,
`fields.Provider` as provider,
`fields.Audience` as audience,
`fields.[SFDC] Blanket Opportunity CaseID` as sfdc_blanket_opportunity_caseid,
`fields.Modality` as modality,
`fields.Region` as region,
`fields.Start Date` as start_date,
`fields.End Date` as end_date,
`fields.Instructor` as instructor,
`fields.Project Type` as project_type,
`fields.Onsite Instructor Expenses` as onsite_instructor_expenses,
`fields.Instructor + TA Assignments` as instructor_and_ta_assignments,
`fields.Start Date [FORM]` as start_date_form,
`fields.End Date [FORM]` as end_date_form,
`fields.Instructor Led Training / Project Name` as instructor_led_training_project_name,
`fields.Month` as month,
`fields.Quarter` as quarter,
`fields.Quarter + FY` as quarter_and_fy,
`fields.Year` as year,
`fields.ILT Name [FORM]` as ilt_name_form,
`fields.Week # - End Date` as week_num___end_date,
`fields.FY` as fy,
`fields.Course Times` as course_times,
`fields.Course Dates` as course_dates,
`fields.[SFDC] Name: Date` as sfdc_name_date,
`fields.[Automation] End Date - Core Series` as automation_end_date_core_series,
`fields.Class Time` as class_time,
`fields.StartDoW` as startdow,
`fields.Cohort Start Date` as cohort_start_date,
`fields.Available Hours` as available_hours,
`fields.Docebo - End Time` as docebo_end_time,
`fields.Docebo - Start Time` as docebo_start_time,
`fields.ILT Duration (Days)` as ilt_duration_days,
`fields.ILT Duration (Hours)` as ilt_duration_hours,
`fields.Monday Hours` as monday_hours,
`fields.Tuesday Hours` as tuesday_hours,
`fields.Wednesday Hours` as wednesday_hours,
`fields.Thursday Hours` as thursday_hours,
`fields.Friday Hours` as friday_hours,
`fields.HDUs` as hdus,
`fields.ATP or Internal (from Instructor)` as atp_or_internal_from_instructor,
`fields.ATP or Internal (Text)` as atp_or_internal_text,
`fields.ATPxFTE` as atpxfte,
`fields.Home Timezone (from Instructor)` as home_timezone_from_instructor,
`fields.home zone` as home_zone,
`fields.Timezone` as timezone,
`fields.Academy Class Creation` as academy_class_creation,
`fields.[SFDC] Project ID + ID Chain` as sfdc_project_id_and_id_chain,
`fields.Academy Session URL (internal)` as academy_session_url_internal,
`fields.[CLOUDLABS] Workspace Provisioned?` as cloudlabs_workspace_provisioned,
`fields.[CLOUDLABS-AZURE] Workspace Signup Link` as cloudlabs_azure_workspace_signup_link,
`fields.[RESOURCES] Meeting Link` as resources_meeting_link,
`fields.[RESOURCES] Survey Link` as resources_survey_link,
`fields.[RESOURCES] Survey Results` as resources_survey_results,
`fields.Company Name` as company_name,
`fields.Status` as status,
`fields.[SFDC] Project URL` as sfdc_project_url,
`fields.[CLOUDLABS-AZURE] Workspace Activation Code` as cloudlabs_azure_workspace_activation_code,
`fields.[FF-PSA] Long_Project ID` as ff_psa_long_project_id,
`fields.Current Registrations` as current_registrations,
`fields.Last Modified` as last_modified,
`fields.[SFDC] PR Region` as sfdc_pr_region,
`fields.[METRICS] Docebo Creation Date` as metrics_docebo_creation_date,
`fields.[METRICS] Meeting Link Creation` as metrics_meeting_link_creation,
`fields.[METRICS] Survey Link Creation` as metrics_survey_link_creation,
`fields.[RESOURCES] Slack Link` as resources_slack_link,
`fields.[METRICS] Slack Creation` as metrics_slack_creation,
`fields.TA` as ta,
`fields.ATP or Internal (from TA)` as atp_or_internal_from_ta,
`fields.Training Request Queue` as training_request_queue,
`fields.Revenue: Milestone Amount` as revenue_milestone_amount,
`fields.Company Contact Name` as company_contact_name,
`fields.[OPS] Slack Setup` as ops_slack_setup,
`fields.Attendance Checked (Private Only)` as attendance_checked_private_only,
`fields.Notes` as notes,
`fields.Company Contact Email` as company_contact_email,
`fields.Roster` as roster,
`fields.Calendar Invite` as calendar_invite,
`fields.Send Survey Results?` as send_survey_results,
`fields.[CLOUDLABS-AZURE] Workspace URL` as cloudlabs_azure_workspace_url,
`fields.[CLOUDLABS-AZURE] Request ID` as cloudlabs_azure_request_id,
`fields.Preferred Video Conference Tool` as preferred_video_conference_tool,
`fields.Meeting Platform` as meeting_platform,
`fields.Onsite Location` as onsite_location,
`fields.Payment Type (from Training Request Queue)` as payment_type_from_training_request_queue,
`fields.Slack Access?` as slack_access,
`fields.[SFDC] Short_Project ID` as sfdc_short_project_id,
`fields.Landing Page` as landing_page,
`fields.[SFDC] Milestone ID` as sfdc_milestone_id,
`fields.Location Address` as location_address,
`fields.Completed Customer Onsite Prep Sheet` as completed_customer_onsite_prep_sheet,
`fields.[Attachment] Customer Onsite Prep Sheet` as attachment_customer_onsite_prep_sheet,
`fields.Customer Onsite Prep Sheet` as customer_onsite_prep_sheet,
`fields.Account Based Training` as account_based_training,
`fields.[SFDC] Budget ID` as sfdc_budget_id,
`fields.SFDC <> Airtable Projects` as sfdc_airtable_projects,
`fields.SFDC <> Airtable Projects copy` as sfdc_airtable_projects_copy,
`fields.Docebo Check` as docebo_check,
`fields.Cohort Duration` as cohort_duration,
`fields.Instructors` as instructors,
`fields.Public Facing (Academy)` as public_facing_academy,
`fields.[Uplimit] Enrollment Count` as uplimit_enrollment_count,
`fields.Enrollment date` as enrollment_date,
`fields.TA confirmed` as ta_confirmed,
`fields.No Shuffle` as no_shuffle,
`fields.Shuffle Finalized` as shuffle_finalized
from fy24_records_raw
''')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### FY23 Instructors

# COMMAND ----------

# url = "https://api.airtable.com/v0/app2xcFKwnbjBWatZ/Instructors?view=All%20Instructors"
# # headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
# headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

# fy23_instructor_records = []
# response = requests.request("GET", url, headers=headers)
# response_json = response.json()

# fy23_instructor_records += response_json['records']
# while 'offset' in response_json:
#   response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
#   response_json = response.json()
#   fy23_instructor_records += response_json['records']

# fy23_instructor_data = []
# for record in fy23_instructor_records:
#   fields = record['fields']
#   instructor = {
#     'id': record['id'],
#     'email': fields['Instructor Email']
#   }
#   fy23_instructor_data.append(instructor)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### FY23 Base

# COMMAND ----------

url = "https://api.airtable.com/v0/app2xcFKwnbjBWatZ/ILT%20Schedule?view=MASTER%20-%20ALL%20TRAINING%20"
# headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

records = []
response = requests.request("GET", url, headers=headers)
response_json = response.json()

records += response_json['records']
while 'offset' in response_json:
  response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
  response_json = response.json()
  records += response_json['records']



# COMMAND ----------

df = convertToDF(records)
df.createOrReplaceTempView('fy23_records_raw')

# COMMAND ----------

fy23_df = spark.sql('''
select 
`id` as id,
`createdTime` as createdtime,
`fields.[FORM] Start Date.error` as form_start_date_error,
`fields.ILT Name.error` as ilt_name_error,
`fields.Month.error` as month_error,
`fields.Quarter.error` as quarter_error,
`fields.Quarter + FY.error` as quarter_and_fy_error,
`fields.[FORM] End Date.error` as form_end_date_error,
`fields.# Enrollments` as num_enrollments,
`fields.Year.specialValue` as year_specialvalue,
`fields.Created Date` as created_date,
`fields.[FORM] ILT Name.error` as form_ilt_name_error,
`fields.FY.error` as fy_error,
`fields.[FF-PSA] Opportunity CaseID.error` as ff_psa_opportunity_caseid_error,
`fields.[FF-PSA] Name: Region + Timezone` as ff_psa_name_region_and_timezone,
`fields.[FF-PSA] Name (1).error` as ff_psa_name_1_error,
`fields.Time.error` as time_error,
`fields.Dates.error` as dates_error,
`fields.[CALENDAR] Start Date/Time - GMT.error` as calendar_start_date_time_gmt_error,
`fields.[CALENDAR] Start Date - Timezone.error` as calendar_start_date_timezone_error,
`fields.[CALENDAR] End Date/Time - GMT.error` as calendar_end_date_time_gmt_error,
`fields.Week # - End Date.error` as week_num_end_date_error,
`fields.Task Week.error` as task_week_error,
`fields.Revenue - Public (Non CC)` as revenue_public_non_cc,
`fields.Revenue (CC)` as revenue_cc,
`fields.Total Revenue` as total_revenue,
`fields.Provider` as provider,
`fields.Projects` as projects,
`fields.Region` as region,
`fields.Start Date` as start_date,
`fields.End Date` as end_date,
`fields.Timezone` as timezone,
`fields.[DOCEBO] Class Created?` as docebo_class_created,
`fields.Instructor` as instructor,
`fields.[SFDC] Project ID + ID Chain` as sfdc_project_id_and_id_chain,
`fields.[RESOURCES] Meeting Link` as resources_meeting_link,
`fields.Training Type` as training_type,
`fields.Status` as status,
`fields.[FORM] Start Date` as form_start_date,
`fields.[DOCEBO] Session Code` as docebo_session_code,
`fields.ILT Name` as ilt_name,
`fields.Month` as month,
`fields.Quarter` as quarter,
`fields.Quarter + FY` as quarter_and_fy,
`fields.[FORM] End Date` as form_end_date,
`fields.Year` as year,
`fields.Last Modified` as last_modified,
`fields.[FORM] ILT Name` as form_ilt_name,
`fields.ATP or Internal (from Instructor)` as atp_or_internal_from_instructor,
`fields.FY` as fy,
`fields.[FF-PSA] Project Region` as ff_psa_project_region,
`fields.[FF-PSA] Name (1)` as ff_psa_name_1,
`fields.Time` as time,
`fields.Dates` as dates,
`fields.[CALENDAR] GMT Offset` as calendar_gmt_offset,
`fields.[CALENDAR] Start Date/Time - GMT` as calendar_start_date_time_gmt,
`fields.Airtable Time Zone` as airtable_time_zone,
`fields.[CALENDAR] Start Date - Timezone` as calendar_start_date_timezone,
`fields.[CALENDAR] End Date/Time - GMT` as calendar_end_date_time_gmt,
`fields.Week # - End Date` as week_num_end_date,
`fields.Task Week` as task_week,
`fields.[COMPANY] Name` as company_name,
`fields.[SFDC] Project URL` as sfdc_project_url,
`fields.Modality` as modality,
`fields.[FF-PSA] Opportunity CaseID` as ff_psa_opportunity_caseid,
`fields.[FF-PSA] Name: Course Name Abbreviation` as ff_psa_name_course_name_abbreviation,
`fields.[SFDC] Project Long ID` as sfdc_project_long_id,
`fields.[PRIVATE] Training Request Enrollments` as private_training_request_enrollments,
`fields.TA` as ta,
`fields.[CLOUDLABS-AZURE] Workspace Signup Link` as cloudlabs_azure_workspace_signup_link,
`fields.[RESOURCES] Slack Link` as resources_slack_link,
`fields.[RESOURCES] Survey Link` as resources_survey_link,
`fields.[RESOURCES] Survey Results` as resources_survey_results,
`fields.[CLOUDLABS-AZURE] Workspace Activation Code` as cloudlabs_azure_workspace_activation_code,
`fields.[CLOUDLABS] Workspace Provisioned?` as cloudlabs_workspace_provisioned,
`fields.[CLOUDLABS-AZURE] Workspace URL` as cloudlabs_azure_workspace_url,
`fields.[LOCATION] Address` as location_address,
`fields.[CLOUDLABS-AZURE] Request ID` as cloudlabs_azure_request_id,
`fields.[AWS] Workspace URL` as aws_workspace_url,
`fields.Workspace URL (from Workspace URL)` as workspace_url_from_workspace_url,
`fields.Notes` as notes,
`fields.[DOCEBO] Session URL (internal)` as docebo_session_url_internal,
`fields.Project Type` as project_type,
`fields.[COMPANY] Contact Name` as company_contact_name,
`fields.[COMPANY] Contact Email` as company_contact_email,
`fields.[PUBLIC] Training Request Queue` as public_training_request_queue,
`fields.[FF-PSA] Revenue (from [PUBLIC] Training Request Queue)` as ff_psa_revenue_from_public_training_request_queue,
`fields.[OPS] Slack Setup` as ops_slack_setup,
`fields.Roster` as roster,
`fields.Calendar Invitation (Private Only)` as calendar_invitation_private_only,
`fields.[PRIVATE] Training Request Queue` as private_training_request_queue,
`fields.Which is your preferred video conference platform? Our default tool is Zoom (test access here). If you would like to use MSFT Teams, you will need to set up your own Teams meeting and share that information with us. (from [PRIVATE] Training Request Queue)` as preferred_video_conference_platform,
`fields.We provision temporary enterprise Databricks workspaces for the duration of the training course. This way, every user has the same permission levels and Databricks covers the cost of DBUs/VMs for the training. (from [PRIVATE] Training Request Queue)` as provision_temporary_enterprise_databricks_workspaces,
`fields.Slack Access? (from [PRIVATE] Training Request Queue)` as slack_access_from_private_training_request_queue,
`fields.DNUWe provision temporary enterprise Databricks workspaces for the duration of the training course. This way, every user has the same permission levels and Databricks covers the cost of DBUs/VMs for the training. Which cloud do you prefer for training?` as dnuwe_provision_temporary_enterprise_databricks_workspaces_for_the_duration_of_the_training_course,
`fields.Send Survey Results?` as send_survey_results,
`fields.Preferred Video Conference Tool (from [PRIVATE] Training Request Queue)` as preferred_video_conference_tool_from_private_training_request_queue,
`fields.Location (from [PRIVATE] Training Request Queue)` as location_from_private_training_request_queue,
`fields.Onsite Instructor Expenses` as onsite_instructor_expenses,
`fields.Customer Onsite Prep Sheet` as customer_onsite_prep_sheet,
`fields.Completed Customer Onsite Prep Sheet` as completed_customer_onsite_prep_sheet,
`fields.[Attachment] Customer Onsite Prep Sheet` as attachment_customer_onsite_prep_sheet,
`fields.Attendance Checked (Private Only)` as attendance_checked_private_only,
`fields.All Enrollments` as all_enrollments,
`fields.Username (from All Enrollments)` as username_from_all_enrollments,
`fields.Revenue (from Revenue (CC)) (from All Enrollments)` as revenue_from_revenue_cc_from_all_enrollments,
`fields.Collaborator.id` as collaborator_id,
`fields.Collaborator.email` as collaborator_email,
`fields.Collaborator.name` as collaborator_name
from fy23_records_raw
''')

# COMMAND ----------

fy23_df_gold = add_gold_metadata(fy23_df)

# COMMAND ----------

fy24_df_gold = add_gold_metadata(fy24_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #Instructor Skills Data

# COMMAND ----------

# url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/Instructor%20Skills%20&%20Credentials?view=Instructor%20Skills%20(By%20Instructor)"
# # headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
# headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

# records = [] 
# response = requests.request("GET", url, headers=headers)
# response_json = response.json()
# # print(response_json)

# records += response_json['records']
# while 'offset' in response_json:
#   response = requests.request("GET", url+f"&offset={response_json['offset']}", headers=headers)
#   response_json = response.json()
#   records += response_json['records']
# # pprint(records)

# COMMAND ----------



# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = fy23_df_gold, 
  table_name = f'{focus_database_name}.airtable_ilt_schedule_master_fy23', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)

# COMMAND ----------

write_delta_table(
  spark, 
  dataframe = fy24_df_gold, 
  table_name = f'{focus_database_name}.airtable_ilt_schedule_master', 
  partition_column=partition_column,
  replace_where=f"processDate = '{partition_date}'",
)