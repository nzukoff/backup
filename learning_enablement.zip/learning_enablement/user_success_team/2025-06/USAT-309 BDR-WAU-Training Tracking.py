# Databricks notebook source
# MAGIC %md
# MAGIC **BDR/WAU/Training Tracking**
# MAGIC
# MAGIC Request received from Suna [USAT-309 BDR/WAU/Training Tracking](https://databricks.atlassian.net/browse/USAT-309)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get the data from the Excel file
# MAGIC Excel sheet with the list of accounts to include [AEB BDR LNA Campaign List](https://docs.google.com/spreadsheets/d/1ka63c8l9SpREzZPHxBhr2ndxWDigAxL8d93DG2o-MQ0/edit?usp=sharing)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC **Steps:**
# MAGIC * create a cell and run %run "/Users/liam.clifford@databricks.com/Liam's Notebook - readGoogleSheet UDF"
# MAGIC * share spreadsheet with service-liam-clifford@project-liam-clifford.iam.gserviceaccount.com as editor
# MAGIC * enter the name of the spreadsheet and the sheet you want to pull data from in the try blocks
# MAGIC * add the workbook id which can be found after /d/ in the sheet url
# MAGIC * for reading from:
# MAGIC   * add the sheet id which can be found in the url after gid=
# MAGIC   * create a temp view name that can be used to query the data from a temp view 
# MAGIC   * specify the cell range you want to pull data from
# MAGIC   * select * from the temp view name to see the data
# MAGIC * for writing to
# MAGIC   * create a dataframe of the data you want to write 
# MAGIC   * create values for the SHEET_NAME and WORKBOOK_ID variables
# MAGIC   * enter the sheet name, workbook id, and dataframe in the refresh_data_in_sheet function
# MAGIC   * specify which row and column to write to

# COMMAND ----------

# MAGIC %run "../../learning-enablement/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

try:
  sht = authGoogleSheet("AEB BDR LNA Campaign List ")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')
  

try:
  worksheet = sht.worksheet("Updated List - 6/2")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')

workbook_id='1ka63c8l9SpREzZPHxBhr2ndxWDigAxL8d93DG2o-MQ0'
sheet_id='349438873'

read_google_sheet(
  workbook_id=workbook_id,
  sheet_id=sheet_id,
  temp_view_name='vw_lna_campaign_list',
  cell_range='A1:L113'
)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   *
# MAGIC FROM 
# MAGIC   vw_lna_campaign_list

# COMMAND ----------

# MAGIC %md
# MAGIC ## Adding metrics to the data
# MAGIC - Metrics
# MAGIC   - LNA yes or no
# MAGIC   - WAU usage now vs then
# MAGIC     - Last 90 vs next 30 
# MAGIC   - New New Learners
# MAGIC     - 3 hours or more of learning material

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding LNA yes or no
# MAGIC The following fields were added as example to measure the impact and get the net new learners.
# MAGIC
# MAGIC The plan is to modify with the data when the campaign happens for each account.

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _vw_lna_accounts
# MAGIC AS
# MAGIC WITH _lna
# MAGIC AS(
# MAGIC   SELECT a.customer_id as account_id, lna
# MAGIC   FROM main.field_learning_enablement.customer_level_metrics a
# MAGIC   GROUP BY ALL
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   a.accountid_casesafe AS account_id, 
# MAGIC   a.account_name,
# MAGIC   nvl(l.lna, 'No') AS lna, 
# MAGIC   'example session' AS session_name,
# MAGIC   '2025-05-01' AS start_date,
# MAGIC   '2025-05-15' AS end_date 
# MAGIC FROM 
# MAGIC   vw_lna_campaign_list AS a
# MAGIC LEFT JOIN _lna AS l
# MAGIC   ON a.accountid_casesafe = l.account_id;
# MAGIC
# MAGIC SELECT * FROM _vw_lna_accounts;

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding Net New Learners
# MAGIC Identifying the net new learners by each account on the period the account have

# COMMAND ----------

df_sessions = spark.sql("""
  WITH _nnl
  AS(
    select learner_user_id, course_code, completed_date, updated_account_id AS account_id
    from main.field_learning_enablement.all_learners
    where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    and dataset = 'net new learners'
  )

  SELECT
    l.*,
    COUNT(n.learner_user_id) AS net_new_learners
  FROM
    _vw_lna_accounts AS l
  LEFT JOIN 
    _nnl AS n 
  ON 
  l.account_id = n.account_id AND n.completed_date BETWEEN l.start_date AND l.end_date
  GROUP BY ALL""") 

display(df_sessions)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Measure the impact

# COMMAND ----------

# MAGIC %md
# MAGIC ### Define account level impact

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

def get_campaign_impact(df_sessions, metrics_to_measure, weeks_to_analyze):
    # Get the event period_baseline
    # Check if df_sessions has session_date or start_date and end_date columns
    if "session_date" in df_sessions.columns:
        period_baseline = ["session_date", "session_date"]
    elif "start_date" in df_sessions.columns and "end_date" in df_sessions.columns:    
        period_baseline = ["start_date", "end_date"]    
    else:
        raise ValueError("df_sessions must have either 'session_date' or both 'start_date' and 'end_date' columns")

    # Configurable parameters
    period_holiday = ["2024-11-24", "2025-01-05"]

    # -- Step 1: Create week offsets
    week_offsets = list(range(-weeks_to_analyze, weeks_to_analyze + 1))
    week_rows = [(offset,) for offset in week_offsets]
    df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

    # -- Step 2: Cross join sessions with week offsets
    df_expanded = df_sessions.crossJoin(df_week_offsets)

    # Calculate weekly date ranges
    df_expanded = df_expanded \
        .withColumn("week_start",
                    F.when(F.col("week_offset") == 0, F.expr(f"date_add(to_date({period_baseline[0]}), (7 * int(week_offset)) - 7)"))
                    .when((F.col("week_offset") < 0) & (F.expr(f"date_add(date_sub(to_date({period_baseline[0]}), 7), 7 * int(week_offset))").between(period_holiday[0], period_holiday[1])), 
                        F.expr(f"date_add(to_date('{period_holiday[0]}'), 7 * int(week_offset))"))
                    .when(F.col("week_offset") < 0, F.expr(f"date_add(date_sub(to_date({period_baseline[0]}), 7), 7 * int(week_offset))"))

                    .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date({period_baseline[1]}), (7 * int(week_offset)) - 6)"))) \
        .withColumn("week_end", F.expr(f"date_add(week_start, 6)")) \
        .withColumn("week_label", 
                    F.when(F.col("week_offset") == 0, f"0_wk")
                    .otherwise(
                        F.concat(
                            F.abs(F.col("week_offset")).cast("string"),
                            F.when(F.col("week_offset") > 0, f"_wk_post")
                            .otherwise(f"_wk_prev")
                        )
                    )).drop("week_offset")    

    # Adding the date range for the 90-day average baseline
    df_90_day_baseline = df_sessions \
        .withColumn("week_start", F.expr(f"date_sub(to_date({period_baseline[0]}), 90)")) \
        .withColumn("week_end", F.expr(f"date_sub(to_date({period_baseline[1]}), 1)")) \
        .withColumn("week_label", F.lit(f"90_day_prev"))

    df_expanded = df_expanded.union(df_90_day_baseline)  

    # Prepare datasets
    df_wau = spark.table("main.field_learning_enablement.fact_daily_mau") 
    df_wau = df_wau.groupBy("date", "customer_id").agg(*[F.sum(metric).alias(metric) for metric in metrics_to_measure])

    # -- Step 3: Join with WAU data and aggregate by week
    df_result = df_expanded.join(
        df_wau,
        (df_wau.customer_id == df_expanded.account_id) &
        (df_wau.date >= df_expanded.week_start) &
        (df_wau.date <= df_expanded.week_end),
        how="left"
    )

    df_result = df_result.groupBy(*df_sessions.columns, "week_label").agg(
        *[F.mean(metric).alias(f"{metric}") for metric in metrics_to_measure]      
    )

    # -- Step 4: Unpivot metric_mean columns to rows
    stack_expr = f"stack({len(metrics_to_measure)},"+ ", ".join([f"'{metric}', {metric}" for metric in metrics_to_measure]) + ") as (metric, value)"

    df_result = df_result.selectExpr(
        *df_sessions.columns, "week_label",
        stack_expr
    ).withColumn("week_label", F.concat(F.col("week_label"), F.lit("_"), F.col("metric"))).drop("metric")


    # -- Step 5: Pivot week labels into columns
    # Define the custom order for week labels
    custom_order = (
    [f"90_day_prev_{metric}" for metric in metrics_to_measure] +
    [f"{i}_wk_prev_{metric}" for i in range(weeks_to_analyze, 0, -1) for metric in metrics_to_measure] +
    [f"0_wk_{metric}" for metric in metrics_to_measure] +
    [f"{i}_wk_post_{metric}" for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]
    )
    
    # Perform the pivot with custom sorting
    df_result = (
        df_result
        .groupBy(*df_sessions.columns)
        .pivot("week_label", custom_order)
        .agg(F.sum("value"))
    )#.na.fill(0)

    # -- Step 6: Creating array for calculations of DiD for each week and metric
    did_expr = (
        [(f"wk{i}_prev_growth_{metric}", f"0_wk_{metric} - {i}_wk_prev_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure] + 
        [(f"wk{i}_post_growth_{metric}", f"{i}_wk_post_{metric} - 0_wk_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure] +
        [(f"wk{i}_growth_{metric}", f"{i}_wk_post_{metric} - 90_day_prev_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure] + 
        [(f"wk{i}_difference_in_difference_{metric}", f"wk{i}_post_growth_{metric} - wk{i}_prev_growth_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]        
    )

    for col_name, expression_str in did_expr:
        df_result = df_result.withColumn(col_name, F.expr(expression_str))

    # Step 7: Calculate IQR for wk1 difference-in-difference    
    # Calculating the percentile for each week and metric. Filtering the records equals to zero from the threshold calculation   
    percentiles_exp = (
        [f"percentile_approx(IF(wk{i}_difference_in_difference_{metric} != 0, wk{i}_difference_in_difference_{metric}, NULL), 0.25) AS wk{i}_q1_{metric}" 
         for i in range(1, weeks_to_analyze + 1) 
         for metric in metrics_to_measure] +
        [f"percentile_approx(IF(wk{i}_difference_in_difference_{metric} != 0, wk{i}_difference_in_difference_{metric}, NULL), 0.75) AS wk{i}_q3_{metric}" 
         for i in range(1, weeks_to_analyze + 1) 
         for metric in metrics_to_measure]
    )

    percentiles = df_result.groupBy("session_name").agg(*[F.expr(e) for e in percentiles_exp])

    # Calculating the lower and upper bounds for each week and metric
    # IQR = F.col("Q3") - F.col("Q1")
    # lower_bound = F.col("Q1") - 1.5 * IQR
    # upper_bound = F.col("Q3") + 1.5 * IQR
    iqr_expr = (
        [f"wk{i}_q1_{metric} - 1.5 * (wk{i}_q3_{metric} - wk{i}_q1_{metric}) AS wk{i}_lower_bound_{metric}" 
         for i in range(1, weeks_to_analyze + 1) 
         for metric in metrics_to_measure] +
        [f"wk{i}_q3_{metric} + 1.5 * (wk{i}_q3_{metric} - wk{i}_q1_{metric}) AS wk{i}_upper_bound_{metric}" 
         for i in range(1, weeks_to_analyze + 1) 
         for metric in metrics_to_measure]        
    )

    iqr = percentiles.selectExpr("session_name", *iqr_expr)

    df_result = df_result.join(iqr, on="session_name", how="left")

    # Step 8: Add outlier flag
    outlier_exp = (
        [(
            f"wk{i}_outlier_flag_{metric}", 
            f"""CASE 
                WHEN wk{i}_difference_in_difference_{metric} IS NULL THEN 'n/a'
                WHEN wk{i}_difference_in_difference_{metric} < wk{i}_lower_bound_{metric} THEN 'drop' 
                WHEN wk{i}_difference_in_difference_{metric} > wk{i}_upper_bound_{metric} THEN 'high_impact' 
                ELSE 'normal' END"""
          )for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]
    )

    for col_name, expression_str in outlier_exp:
        df_result = df_result.withColumn(col_name, F.expr(expression_str))

    # df_result = df_result.withColumn(
    #     f"wk{i}_outlier_flag",
    #     F.when(F.col(f"wk{i}_difference_in_difference_{metric_column}").isNull(), F.lit("n/a"))
    #     .when(F.col(f"wk{i}_difference_in_difference_{metric_column}") < lower_bound, F.lit("drop"))
    #     .when(F.col(f"wk{i}_difference_in_difference_{metric_column}") > upper_bound, F.lit("high_impact"))
    #     .otherwise(F.lit("normal"))
    # ).drop("Q1", "Q3")

    return df_result

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get account impact

# COMMAND ----------

metrics_to_measure = ["wau_human"]

df_result = get_campaign_impact(df_sessions, metrics_to_measure = metrics_to_measure, weeks_to_analyze = 4)

display(df_result)