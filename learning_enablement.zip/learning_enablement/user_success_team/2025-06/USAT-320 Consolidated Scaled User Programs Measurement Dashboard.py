# Databricks notebook source
# MAGIC %md
# MAGIC **Consolidated Scaled User Programs Measurement Dashboard**
# MAGIC
# MAGIC Part 1
# MAGIC ---
# MAGIC Consolidate [AIBI program](https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01ef8b1cf03614f18ca191ab4aac0bf4/published?o=2548836972759138) & the [user enablement overview](https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01eeb55263f11568bc7ad85275e872d3/published?o=2548836972759138) & [APJ events](https://docs.google.com/spreadsheets/d/1P1QTjn7fdiWyAIO95iaPpFJ3yvovhXesJl31ZUCdmK0/edit?gid=0#gid=0) to all the tracked in one place.
# MAGIC
# MAGIC **Metrics:**
# MAGIC - Completions
# MAGIC - Net new learners
# MAGIC - hWAU (90D pre/30d post)
# MAGIC - Lakeview hWAU Growth
# MAGIC - Genie hWAU Growth
# MAGIC - DBSQL hWAU Growth
# MAGIC
# MAGIC Part 2
# MAGIC ---
# MAGIC Add new AMER program launching that will replace hybrid learning days and DI days = self paced workshops [Nadia’s leading]
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Part 1: Consolidate the Programs

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Impact functions definition

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Account level impact

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

def get_campaign_impact(df_sessions, metrics_to_measure, weeks_to_analyze):
    # Get the event period_baseline
    # Check if df_sessions has session_date or start_date and end_date columns
    if "session_date" in df_sessions.columns:
        period_baseline = ["session_date", "session_date"]
    elif "start_date" in df_sessions.columns and "end_date" in df_sessions.columns:    
        period_baseline = ["start_date", "end_date"]    
    else:
        raise ValueError("df_sessions must have either 'session_date' or both 'start_date' and 'end_date' columns")

    # Configurable parameters
    period_holiday = ["2024-11-24", "2025-01-05"]

    # -- Step 1: Create week offsets
    week_offsets = list(range(-weeks_to_analyze, weeks_to_analyze + 1))
    week_rows = [(offset,) for offset in week_offsets]
    df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

    # -- Step 2: Cross join sessions with week offsets
    df_expanded = df_sessions.crossJoin(df_week_offsets)

    # Calculate weekly date ranges
    df_expanded = df_expanded \
        .withColumn("week_start",
                    F.when(F.col("week_offset") == 0, F.expr(f"date_add(to_date({period_baseline[0]}), (7 * int(week_offset)) - 7)"))
                    .when((F.col("week_offset") < 0) & (F.expr(f"date_add(date_sub(to_date({period_baseline[0]}), 7), 7 * int(week_offset))").between(period_holiday[0], period_holiday[1])), 
                        F.expr(f"date_add(to_date('{period_holiday[0]}'), 7 * int(week_offset))"))
                    .when(F.col("week_offset") < 0, F.expr(f"date_add(date_sub(to_date({period_baseline[0]}), 7), 7 * int(week_offset))"))

                    .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date({period_baseline[1]}), (7 * int(week_offset)) - 6)"))) \
        .withColumn("week_end", F.expr(f"date_add(week_start, 6)")) \
        .withColumn("week_label", 
                    F.when(F.col("week_offset") == 0, f"0_wk")
                    .otherwise(
                        F.concat(
                            F.abs(F.col("week_offset")).cast("string"),
                            F.when(F.col("week_offset") > 0, f"_wk_post")
                            .otherwise(f"_wk_prev")
                        )
                    )).drop("week_offset")    

    # Adding the date range for the 90-day average baseline
    df_90_day_baseline = df_sessions \
        .withColumn("week_start", F.expr(f"date_sub(to_date({period_baseline[0]}), 90)")) \
        .withColumn("week_end", F.expr(f"date_sub(to_date({period_baseline[1]}), 1)")) \
        .withColumn("week_label", F.lit(f"90_day_prev"))

    df_expanded = df_expanded.union(df_90_day_baseline)  

    # Prepare datasets
    df_wau = spark.table("main.field_learning_enablement.fact_daily_mau") 
    df_wau = df_wau.groupBy("date", "customer_id").agg(*[F.sum(metric).alias(metric) for metric in metrics_to_measure])

    # -- Step 3: Join with WAU data and aggregate by week
    df_result = df_expanded.join(
        df_wau,
        (df_wau.customer_id == df_expanded.account_id) &
        (df_wau.date >= df_expanded.week_start) &
        (df_wau.date <= df_expanded.week_end),
        how="left"
    )

    df_result = df_result.groupBy(*df_sessions.columns, "week_label").agg(
        *[F.mean(metric).alias(f"{metric}") for metric in metrics_to_measure]      
    )

    # -- Step 4: Unpivot metric_mean columns to rows
    stack_expr = f"stack({len(metrics_to_measure)},"+ ", ".join([f"'{metric}', {metric}" for metric in metrics_to_measure]) + ") as (metric, value)"

    df_result = df_result.selectExpr(
        *df_sessions.columns, "week_label",
        stack_expr
    ).withColumn("week_label", F.concat(F.col("week_label"), F.lit("_"), F.col("metric"))).drop("metric")


    # -- Step 5: Pivot week labels into columns
    # Define the custom order for week labels
    custom_order = (
    [f"90_day_prev_{metric}" for metric in metrics_to_measure] +
    [f"{i}_wk_prev_{metric}" for i in range(weeks_to_analyze, 0, -1) for metric in metrics_to_measure] +
    [f"0_wk_{metric}" for metric in metrics_to_measure] +
    [f"{i}_wk_post_{metric}" for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]
    )
    
    # Perform the pivot with custom sorting
    df_result = (
        df_result
        .groupBy(*df_sessions.columns)
        .pivot("week_label", custom_order)
        .agg(F.sum("value"))
    )#.na.fill(0)

    # -- Step 6: Creating array for calculations of DiD for each week and metric
    did_expr = (
        [(f"wk{i}_prev_growth_{metric}", f"0_wk_{metric} - {i}_wk_prev_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure] + 
        [(f"wk{i}_post_growth_{metric}", f"{i}_wk_post_{metric} - 0_wk_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure] +        
        [(f"wk{i}_difference_in_difference_{metric}", f"wk{i}_post_growth_{metric} - wk{i}_prev_growth_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure] + 
        # [(f"wk{i}_growth_{metric}", f"{i}_wk_post_{metric} - 90_day_prev_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]
        [(f"wk{i}_growth_{metric}", f"{i}_wk_post_{metric} - IF(end_date >= '2025-02-01', 0_wk_{metric}, 90_day_prev_{metric})") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]
    )

    for col_name, expression_str in did_expr:
        df_result = df_result.withColumn(col_name, F.expr(expression_str))

    # Step 7: Calculate IQR for wk1 difference-in-difference    
    # Calculating the percentile for each week and metric. Filtering the records equals to zero from the threshold calculation   
    percentiles_exp = (
        [f"percentile_approx(IF(wk{i}_difference_in_difference_{metric} != 0, wk{i}_difference_in_difference_{metric}, NULL), 0.25) AS wk{i}_q1_{metric}" 
         for i in range(1, weeks_to_analyze + 1) 
         for metric in metrics_to_measure] +
        [f"percentile_approx(IF(wk{i}_difference_in_difference_{metric} != 0, wk{i}_difference_in_difference_{metric}, NULL), 0.75) AS wk{i}_q3_{metric}" 
         for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure] #+
        # [f"percentile_approx(IF(wk1_difference_in_difference_wau_human != 0, try_divide(completions, abs(wk1_growth_wau_human)), NULL), 0.50) AS completions_vs_wk1_growth_wau_human"]
    )

    percentiles = df_result.groupBy("session_name").agg(*[F.expr(e) for e in percentiles_exp])

    # Calculating the lower and upper bounds for each week and metric
    # IQR = F.col("Q3") - F.col("Q1")
    # lower_bound = F.col("Q1") - 1.5 * IQR
    # upper_bound = F.col("Q3") + 1.5 * IQR
    iqr_expr = (
        [f"wk{i}_q1_{metric} - 1.5 * (wk{i}_q3_{metric} - wk{i}_q1_{metric}) AS wk{i}_lower_bound_{metric}" 
         for i in range(1, weeks_to_analyze + 1) 
         for metric in metrics_to_measure] +
        [f"wk{i}_q3_{metric} + 1.5 * (wk{i}_q3_{metric} - wk{i}_q1_{metric}) AS wk{i}_upper_bound_{metric}" 
         for i in range(1, weeks_to_analyze + 1) 
         for metric in metrics_to_measure]        
    )

    iqr = percentiles.selectExpr("session_name", *iqr_expr)

    df_result = df_result.join(iqr, on="session_name", how="left")

    # Step 8: Add outlier flag
    outlier_exp = (
        [(
            f"wk{i}_outlier_flag_{metric}", 
            f"""CASE 
                WHEN wk{i}_difference_in_difference_{metric} IS NULL THEN 'n/a'
                WHEN wk{i}_difference_in_difference_{metric} < wk{i}_lower_bound_{metric} THEN 'drop' 
                WHEN wk{i}_difference_in_difference_{metric} > wk{i}_upper_bound_{metric} THEN 'high_impact' 
                ELSE 'normal' END"""
          )for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]
    )

    for col_name, expression_str in outlier_exp:
        df_result = df_result.withColumn(col_name, F.expr(expression_str))

    # Step 9: Add control filters to exclude records depending of the need
    rules = [        
        ("account_name = 'Databricks'", "Databricks"),
        ("account_name in('Generic/Public Business Subscription Account', 'Generic Account')", "Generic Accounts"),
        ("account_id = 'Unknown'", "Unknown Accounts"),
        ("account_id IS NULL", "Unknown Accounts")
    ]    

    case_statement = "CASE " + " ".join([f"WHEN {condition} THEN '{label}'" for condition, label in rules]) + " ELSE 'Untagged Accounts' END"
    df_result = df_result.withColumn("control_filter", F.expr(case_statement))

    return df_result

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Account level impact by metrics

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

def get_campaign_impact(df_sessions, metrics_to_measure, weeks_to_analyze):
    # Get the event period_baseline
    # Check if df_sessions has session_date or start_date and end_date columns
    if "session_date" in df_sessions.columns:
        period_baseline = ["session_date", "session_date"]
    elif "start_date" in df_sessions.columns and "end_date" in df_sessions.columns:    
        period_baseline = ["start_date", "end_date"]    
    else:
        raise ValueError("df_sessions must have either 'session_date' or both 'start_date' and 'end_date' columns")

    # Configurable parameters
    period_holiday = ["2024-11-24", "2025-01-05"]

    # -- Step 1: Create week offsets
    week_offsets = list(range(-weeks_to_analyze, weeks_to_analyze + 1))
    week_rows = [(offset,) for offset in week_offsets]
    df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

    # -- Step 2: Cross join sessions with week offsets
    df_expanded = df_sessions.crossJoin(df_week_offsets)

    # Calculate weekly date ranges
    df_expanded = df_expanded \
        .withColumn("week_start",
                    F.when(F.col("week_offset") == 0, F.expr(f"date_add(to_date({period_baseline[0]}), (7 * int(week_offset)) - 7)"))
                    .when((F.col("week_offset") < 0) & (F.expr(f"date_add(date_sub(to_date({period_baseline[0]}), 7), 7 * int(week_offset))").between(period_holiday[0], period_holiday[1])), 
                        F.expr(f"date_add(to_date('{period_holiday[0]}'), 7 * int(week_offset))"))
                    .when(F.col("week_offset") < 0, F.expr(f"date_add(date_sub(to_date({period_baseline[0]}), 7), 7 * int(week_offset))"))

                    .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date({period_baseline[1]}), (7 * int(week_offset)) - 6)"))) \
        .withColumn("week_end", F.expr(f"date_add(week_start, 6)")) \
        .withColumn("week_label", 
                    F.when(F.col("week_offset") == 0, f"0_wk")
                    .otherwise(
                        F.concat(
                            F.abs(F.col("week_offset")).cast("string"),
                            F.when(F.col("week_offset") > 0, f"_wk_post")
                            .otherwise(f"_wk_prev")
                        )
                    )).drop("week_offset")    

    # Adding the date range for the 90-day average baseline
    df_90_day_baseline = df_sessions \
        .withColumn("week_start", F.expr(f"date_sub(to_date({period_baseline[0]}), 90)")) \
        .withColumn("week_end", F.expr(f"date_sub(to_date({period_baseline[1]}), 1)")) \
        .withColumn("week_label", F.lit(f"90_day_prev"))

    df_expanded = df_expanded.union(df_90_day_baseline)  

    # Prepare datasets
    df_wau = spark.table("main.field_learning_enablement.fact_daily_mau") 
    df_wau = df_wau.groupBy("date", "customer_id").agg(*[F.sum(metric).alias(metric) for metric in metrics_to_measure])

    # -- Step 3: Join with WAU data and aggregate by week
    df_result = df_expanded.join(
        df_wau,
        (df_wau.customer_id == df_expanded.account_id) &
        (df_wau.date >= df_expanded.week_start) &
        (df_wau.date <= df_expanded.week_end),
        how="left"
    )

    df_result = df_result.groupBy(*df_sessions.columns, "week_label").agg(
        *[F.mean(metric).alias(f"{metric}") for metric in metrics_to_measure]      
    )

    # -- Step 4: Unpivot metric_mean columns to rows
    df_result.createOrReplaceTempView("_df_result")
    unpivot_query = f"SELECT * FROM _df_result UNPIVOT(value for metric IN ({', '.join([f'{metric}' for metric in metrics_to_measure])}))"
    df_result = spark.sql(unpivot_query).withColumn("metric", F.concat(F.col("week_label"), F.lit("_"), F.col("metric"))).drop("week_label")

    # -- Step 5: Pivot week labels into columns
    # Define the custom order for week labels
    custom_order = (
    [f"90_day_prev_{metric}" for metric in metrics_to_measure] +
    [f"{i}_wk_prev_{metric}" for i in range(weeks_to_analyze, 0, -1) for metric in metrics_to_measure] +
    [f"0_wk_{metric}" for metric in metrics_to_measure] +
    [f"{i}_wk_post_{metric}" for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]
    )
    
    # Perform the pivot with custom sorting
    df_result = (
        df_result
        .groupBy(*df_sessions.columns)
        .pivot("metric", custom_order)
        .agg(F.sum("value"))
    )#.na.fill(0)

    # -- Step 6: Creating array for calculations of DiD for each week and metric
    did_expr = (
        [(f"wk{i}_prev_growth_{metric}", f"0_wk_{metric} - {i}_wk_prev_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure] + 
        [(f"wk{i}_post_growth_{metric}", f"{i}_wk_post_{metric} - 0_wk_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure] +        
        [(f"wk{i}_difference_in_difference_{metric}", f"wk{i}_post_growth_{metric} - wk{i}_prev_growth_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure] + 
        # [(f"wk{i}_growth_{metric}", f"{i}_wk_post_{metric} - 90_day_prev_{metric}") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]
        [(f"wk{i}_growth_{metric}", f"{i}_wk_post_{metric} - IF(end_date >= '2025-02-01', 0_wk_{metric}, 90_day_prev_{metric})") for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]
    )

    for col_name, expression_str in did_expr:
        df_result = df_result.withColumn(col_name, F.expr(expression_str))

    # List all columns from df_result but exclude the ones same as df_sessions
    df_result_columns_to_pivot = [col for col in df_result.columns if col not in set(df_sessions.columns)]    
    
    df_result.createOrReplaceTempView("_df_result")
    unpivot_query = f"SELECT * FROM _df_result UNPIVOT(value for metric IN ({', '.join([f'{column}' for column in df_result_columns_to_pivot])}))"
    df_result = spark.sql(unpivot_query)

    # # Step 7: Calculate IQR for wk1 difference-in-difference    
    # # Calculating the percentile for each week and metric. Filtering the records equals to zero from the threshold calculation   
    # percentiles_exp = (
    #     [f"percentile_approx(IF(wk{i}_difference_in_difference_{metric} != 0, wk{i}_difference_in_difference_{metric}, NULL), 0.25) AS wk{i}_q1_{metric}" 
    #      for i in range(1, weeks_to_analyze + 1) 
    #      for metric in metrics_to_measure] +
    #     [f"percentile_approx(IF(wk{i}_difference_in_difference_{metric} != 0, wk{i}_difference_in_difference_{metric}, NULL), 0.75) AS wk{i}_q3_{metric}" 
    #      for i in range(1, weeks_to_analyze + 1) 
    #      for metric in metrics_to_measure] +
    #     [f"percentile_approx(IF(wk1_difference_in_difference_wau_human != 0, try_divide(completions, abs(wk1_growth_wau_human)), NULL), 0.50) AS completions_vs_wk1_growth_wau_human"]
    # )

    # percentiles = df_result.groupBy("session_name").agg(*[F.expr(e) for e in percentiles_exp])

    # # Calculating the lower and upper bounds for each week and metric
    # # IQR = F.col("Q3") - F.col("Q1")
    # # lower_bound = F.col("Q1") - 1.5 * IQR
    # # upper_bound = F.col("Q3") + 1.5 * IQR
    # iqr_expr = (
    #     [f"wk{i}_q1_{metric} - 1.5 * (wk{i}_q3_{metric} - wk{i}_q1_{metric}) AS wk{i}_lower_bound_{metric}" 
    #      for i in range(1, weeks_to_analyze + 1) 
    #      for metric in metrics_to_measure] +
    #     [f"wk{i}_q3_{metric} + 1.5 * (wk{i}_q3_{metric} - wk{i}_q1_{metric}) AS wk{i}_upper_bound_{metric}" 
    #      for i in range(1, weeks_to_analyze + 1) 
    #      for metric in metrics_to_measure]        
    # )

    # iqr = percentiles.selectExpr("session_name", "completions_vs_wk1_growth_wau_human", *iqr_expr)

    # df_result = df_result.join(iqr, on="session_name", how="left")

    # # Step 8: Add outlier flag
    # outlier_exp = (
    #     [(
    #         f"wk{i}_outlier_flag_{metric}", 
    #         f"""CASE 
    #             WHEN wk{i}_difference_in_difference_{metric} IS NULL THEN 'n/a'
    #             WHEN wk{i}_difference_in_difference_{metric} < wk{i}_lower_bound_{metric} THEN 'drop' 
    #             WHEN wk{i}_difference_in_difference_{metric} > wk{i}_upper_bound_{metric} THEN 'high_impact' 
    #             ELSE 'normal' END"""
    #       )for i in range(1, weeks_to_analyze + 1) for metric in metrics_to_measure]
    # )

    # for col_name, expression_str in outlier_exp:
    #     df_result = df_result.withColumn(col_name, F.expr(expression_str))

    # # Step 9: Add control filters to exclude records depending of the need
    # rules = [        
    #     ("account_name = 'Databricks'", "Databricks"),
    #     ("account_name in('Generic/Public Business Subscription Account', 'Generic Account')", "Generic Accounts"),
    #     ("account_id = 'Unknown'", "Unknown Accounts"),
    #     ("account_id IS NULL", "Unknown Accounts")
    # ]    

    # case_statement = "CASE " + " ".join([f"WHEN {condition} THEN '{label}'" for condition, label in rules]) + " ELSE 'Untagged Accounts' END"
    # df_result = df_result.withColumn("control_filter", F.expr(case_statement))

    return df_result

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Learning Festival Q1 FY25 - Q3 FY25

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Source Data

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival_completions_Q1_Q3_FY25
# MAGIC AS
# MAGIC -- Learning Festival Q1 - Q3
# MAGIC with nnl as(
# MAGIC   select learner_user_id, course_code, completed_date
# MAGIC   from main.field_learning_enablement.all_learners
# MAGIC   where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
# MAGIC   and dataset = 'net new learners')
# MAGIC SELECT 
# MAGIC   course_type,
# MAGIC   session_name,
# MAGIC   start_date,
# MAGIC   end_date,  
# MAGIC   account_id,
# MAGIC   account_name,  
# MAGIC   COUNT(completed_date) AS completions,
# MAGIC   COUNT(learner_date) AS net_new_learners
# MAGIC FROM(
# MAGIC   select 
# MAGIC     ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2,
# MAGIC     'Learning Festival' as course_type,
# MAGIC     CASE
# MAGIC       WHEN ae.completed_timestamp between '2024-02-29T00:00:00UTC+14' and '2024-03-14T00:00:00UTC-12' THEN 'Learning Festival - Q1 FY25' 
# MAGIC       WHEN ae.completed_timestamp between '2024-07-10T00:00:00UTC+14' and '2024-07-25T00:00:00UTC-12' THEN 'Learning Festival - Q2 FY25' 
# MAGIC       WHEN ae.completed_timestamp between '2024-10-10T00:00:00UTC+14' and '2024-11-01T00:00:00UTC-12' THEN 'Learning Festival - Q3 FY25' END AS session_name,
# MAGIC     CASE
# MAGIC       WHEN ae.completed_timestamp between '2024-02-29T00:00:00UTC+14' and '2024-03-14T00:00:00UTC-12' THEN '2024-02-29' 
# MAGIC       WHEN ae.completed_timestamp between '2024-07-10T00:00:00UTC+14' and '2024-07-25T00:00:00UTC-12' THEN '2024-07-10' 
# MAGIC       WHEN ae.completed_timestamp between '2024-10-10T00:00:00UTC+14' and '2024-11-01T00:00:00UTC-12' THEN '2024-10-10' END AS start_date,
# MAGIC     CASE
# MAGIC       WHEN ae.completed_timestamp between '2024-02-29T00:00:00UTC+14' and '2024-03-14T00:00:00UTC-12' THEN '2024-03-14' 
# MAGIC       WHEN ae.completed_timestamp between '2024-07-10T00:00:00UTC+14' and '2024-07-25T00:00:00UTC-12' THEN '2024-07-25' 
# MAGIC       WHEN ae.completed_timestamp between '2024-10-10T00:00:00UTC+14' and '2024-11-01T00:00:00UTC-12' THEN '2024-11-01' END AS end_date,
# MAGIC       ae.updated_account_id AS account_id,
# MAGIC       ae.updated_account_name AS account_name
# MAGIC   from main.field_learning_enablement.all_enrollments ae
# MAGIC   left join nnl
# MAGIC   on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC   where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC   and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
# MAGIC   and ae.course_id in (
# MAGIC       1266, -- DEWD
# MAGIC       2268, -- ADEWD
# MAGIC       2307, -- DAWD
# MAGIC       2906, -- DAWD 2024
# MAGIC       2417, -- MLWD
# MAGIC       1522, -- MLIP
# MAGIC       2267, -- GAIEWD 2023
# MAGIC       2726 -- GAIEWD 2024
# MAGIC   )
# MAGIC   and 
# MAGIC   (
# MAGIC       ae.completed_timestamp between '2024-02-29T00:00:00UTC+14' and '2024-03-14T00:00:00UTC-12' -- Q1 FY25
# MAGIC       or 
# MAGIC       ae.completed_timestamp between '2024-07-10T00:00:00UTC+14' and '2024-07-25T00:00:00UTC-12' -- Q2 FY25
# MAGIC       or
# MAGIC       ae.completed_timestamp between '2024-10-10T00:00:00UTC+14' and '2024-11-01T00:00:00UTC-12' -- Q3 FY25
# MAGIC   )
# MAGIC ) AS X
# MAGIC GROUP BY ALL;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Learning Festival Q4 FY25
# MAGIC ###### References
# MAGIC - [Databricks Learning Festival (Virtual): 15 January - 31 January 2025](https://community.databricks.com/t5/events/databricks-learning-festival-virtual-15-january-31-january-2025/ec-p/103467)
# MAGIC - [User Enablement - Virtual Learning Festival Q4 FY25](https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01efb09b3db1156fb287a3701d05a8b4/published?o=2548836972759138)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Source Data

# COMMAND ----------

# DBTITLE 1,completions
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival_completions_Q4_FY25
# MAGIC AS
# MAGIC with q4lf as (
# MAGIC --DEWD Completions
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag)= 4 then 'DEWD' else null end as course_completed,
# MAGIC date(max(completed_timestamp)) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   2963, -- Data Ingestion
# MAGIC   1365, -- Workloads
# MAGIC   2971, -- Data Pipelines
# MAGIC   3144 -- Governance with UC
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and course_completed_date between '2025-01-14' and '2025-02-01'
# MAGIC
# MAGIC -- MLWD Completions
# MAGIC union
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag) = 4 then 'MLWD' else null end as course_completed,
# MAGIC max(completed_date) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   2343, -- Data Prep for ML
# MAGIC   2390, -- ML Model Dev
# MAGIC   2395, -- ML Model Dep
# MAGIC   2400 -- ML Ops
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and course_completed_date between '2025-01-14' and '2025-02-01'
# MAGIC
# MAGIC -- GenAI Course Completions
# MAGIC union 
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag) = 4 then 'GENAI' else null end as course_completed,
# MAGIC max(completed_date) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   2706, -- Gen AI Solution Development
# MAGIC   2716, -- Gen AI Application Developmment
# MAGIC   2717, -- Gen AI Application Evaluation & Governance
# MAGIC   2713 -- Gen AI Application Deployment & Monitoring
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and course_completed_date between '2025-01-14' and '2025-02-01'
# MAGIC
# MAGIC -- Advanced ML Module Completions
# MAGIC union 
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag) = 2 then 'GENAI' else null end as course_completed,
# MAGIC max(completed_date) as completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   3417, -- ML At Scale
# MAGIC   3508 -- Advanced MLOPs
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) =2
# MAGIC and completed_date between '2025-01-01' and '2025-02-01'
# MAGIC
# MAGIC -- Full Course Completions
# MAGIC union
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Full Course' as modality,
# MAGIC case 
# MAGIC   when course_id = 1266 and attended_flag = 1 then 'DEWD' 
# MAGIC   when course_id = 2268 and attended_flag = 1 then 'ADEWD'
# MAGIC   when course_id IN (2307, 2906) and attended_flag = 1 then 'DAWD'
# MAGIC   when course_id  = 2417 and attended_flag = 1 then 'MLWD'
# MAGIC   when course_id = 1522 and attended_flag = 1 then 'MLIP'
# MAGIC   when course_id IN (2267, 2726) and attended_flag = 1 then 'GENAI' 
# MAGIC end as course_completed,
# MAGIC completed_date
# MAGIC from main.field_learning_enablement.all_enrollments
# MAGIC     where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC     and all_enrollments.learner_branch_code not in (
# MAGIC     'DBK_EMP' -- Exclude internal employee enrollments
# MAGIC     )
# MAGIC     and all_enrollments.course_id in (
# MAGIC     1266, -- DEWD
# MAGIC     2268, -- ADEWD
# MAGIC     2307, -- DAWD
# MAGIC     2906, -- DAWD 2024
# MAGIC     2417, -- MLWD
# MAGIC     1522, -- MLIP
# MAGIC     2267, -- GAIEWD23
# MAGIC     2726 -- GAIWD24
# MAGIC     )
# MAGIC     and attended_flag = 1
# MAGIC     and completed_timestamp between '2025-01-15T00:00:00UTC+14' and '2025-02-01T00:00:00UTC-12')
# MAGIC
# MAGIC select q4lf.*, 
# MAGIC du.first_name,
# MAGIC du.last_name, 
# MAGIC du.email,
# MAGIC du.alternate_email, 
# MAGIC du.updated_account_id, 
# MAGIC du.updated_account_name,
# MAGIC du.business_unit,
# MAGIC du.sales_subregion_level_1,
# MAGIC du.sales_subregion_level_2,
# MAGIC du.sales_subregion_level_3,
# MAGIC du.country_name,
# MAGIC du.region,
# MAGIC du.country_derived, 
# MAGIC du.region_derived,
# MAGIC case when du.business_unit != 'Unknown' then du.business_unit else du.region_derived end as kathryn_region
# MAGIC from q4lf
# MAGIC join main.field_learning_enablement.docebo_users du 
# MAGIC on q4lf.learner_user_id = du.id
# MAGIC and du.processDate = (select max(processDate) from main.field_learning_enablement.docebo_users)
# MAGIC and q4lf.course_completed_date BETWEEN '2025-01-14' and '2025-02-01';
# MAGIC
# MAGIC
# MAGIC -- SELECT * FROM _learning_festival_completions_Q4_FY25;

# COMMAND ----------

# DBTITLE 1,net_new_learners
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival_net_new_learners_Q4_FY25
# MAGIC AS
# MAGIC with nnl as(
# MAGIC     select learner_user_id, course_code, completed_date
# MAGIC     from main.field_learning_enablement.all_learners
# MAGIC     where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
# MAGIC     and dataset = 'net new learners'
# MAGIC )
# MAGIC
# MAGIC -- Learning Festival
# MAGIC select 
# MAGIC ae.learner_user_id, 
# MAGIC ae.updated_account_id,
# MAGIC ae.updated_account_name , 
# MAGIC ae.course_id, 
# MAGIC ae.course_code, 
# MAGIC case 
# MAGIC     when ae.course_id in (1266, 2963, 1365, 2971, 3144) then 'DEWD'
# MAGIC     when ae.course_id = 2268 then 'ADEWD'
# MAGIC     when ae.course_id in (2307, 2906) then 'DAWD'
# MAGIC     when ae.course_id in (2417, 2343, 2390, 2395, 2400) then 'MLWD'
# MAGIC     when ae.course_id IN(1522, 3417, 3508) then 'MLIP'
# MAGIC     when ae.course_id in (2267, 2726, 2706,2716,2717,2713) then 'GENAI'
# MAGIC end as course_completed,
# MAGIC ae.enrolled_date, 
# MAGIC ae.completed_date, 
# MAGIC ae.attended_flag, 
# MAGIC ae.completed_fq2, 
# MAGIC nnl.completed_date as learner_date, 
# MAGIC 'Learning Festival' as course_type, 
# MAGIC ae.business_unit, 
# MAGIC IFNULL(ae.sales_subregion_level_1,'Unknown'), 
# MAGIC IFNULL(ae.sales_subregion_level_2,'Unknown'),
# MAGIC IFNULL(ae.sales_subregion_level_3,'Unknown'), 
# MAGIC case when business_unit != 'Unknown' then business_unit else region_derived end as kathryn_region
# MAGIC from main.field_learning_enablement.all_enrollments ae
# MAGIC join nnl
# MAGIC on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
# MAGIC and ae.course_id in (
# MAGIC     -- Full Courses
# MAGIC     1266, -- DEWD
# MAGIC     2268, -- ADEWD
# MAGIC     2307, -- DAWD
# MAGIC     2906, -- DAWD 2024
# MAGIC     2417, -- MLWD
# MAGIC     1522, -- MLIP
# MAGIC     2267, -- GAIEWD 2023
# MAGIC     2726, -- GAIEWD 2024
# MAGIC     -- DE Modules
# MAGIC     2963, -- Data Ingestion
# MAGIC     1365, -- Workloads
# MAGIC     2971, -- DLT
# MAGIC     3144, -- Governance
# MAGIC     -- MLWD Modules
# MAGIC     2343, -- Data Prep
# MAGIC     2390, -- ML Model Dev
# MAGIC     2395, -- ML Model Dep
# MAGIC     2400, --ML Ops
# MAGIC     -- Gen AI
# MAGIC     2706, -- Gen AI Solution Dev
# MAGIC     2716, -- Gen AI App Dev
# MAGIC     2717, -- Gen AI App Eval
# MAGIC     2713, -- Gen AI App Deployment
# MAGIC     -- AMLWD Modules
# MAGIC     3417, -- ML at Scale
# MAGIC     3508 -- Advanced MLOPs
# MAGIC )
# MAGIC and ae.completed_timestamp between '2025-01-15T00:00:00UTC+14' and '2025-02-01T00:00:00UTC-12'; -- Q4 FY25
# MAGIC
# MAGIC -- SELECT * FROM _learning_festival_net_new_learners_Q4_FY25;

# COMMAND ----------

# DBTITLE 1,learning_festival
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival_Q4_FY25
# MAGIC AS
# MAGIC WITH _nnl AS(
# MAGIC   SELECT   
# MAGIC     updated_account_id, updated_account_name, COUNT(learner_date) AS net_new_learners
# MAGIC   FROM _learning_festival_net_new_learners_Q4_FY25   
# MAGIC   GROUP BY ALL     
# MAGIC ), _completions AS(
# MAGIC   SELECT         
# MAGIC     updated_account_id, updated_account_name, COUNT(course_completed_date) AS completions
# MAGIC   FROM _learning_festival_completions_Q4_FY25
# MAGIC   GROUP BY ALL
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   'Learning Festival' AS course_type,
# MAGIC   'Learning Festival - Q4 FY25' AS session_name,
# MAGIC   CAST('2025-01-15' AS DATE) AS start_date,
# MAGIC   CAST('2025-01-31' AS DATE) AS end_date,    
# MAGIC   nvl(T1.updated_account_id, T2.updated_account_id) AS account_id,
# MAGIC   nvl(T1.updated_account_name, T2.updated_account_name) AS account_name,  
# MAGIC   COALESCE(T1.completions, 0) AS completions,
# MAGIC   COALESCE(T2.net_new_learners, 0) AS net_new_learners
# MAGIC FROM 
# MAGIC   _completions AS T1
# MAGIC FULL JOIN _nnl AS T2 USING(updated_account_id);
# MAGIC
# MAGIC -- SELECT * FROM _learning_festival_Q4_FY25;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Learning Festival Q1 FY26
# MAGIC ###### References
# MAGIC - [Virtual Learning Festival: 9 April - 30 April](https://community.databricks.com/t5/events/virtual-learning-festival-9-april-30-april/ec-p/111620#M2286)
# MAGIC - [User Enablement - Virtual Learning Festival Q1 FY26](https://adb-2548836972759138.18.azuredatabricks.net/sql/dashboardsv3/01effa9194411caaa836831517ff1ae7/datasets/c3c6f779?o=2548836972759138)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Source Data

# COMMAND ----------

# DBTITLE 1,completions
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival_completions_Q1_FY26
# MAGIC AS
# MAGIC with q4lf as (
# MAGIC --DEWD Completions
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag)= 4 then 'DEWD' else null end as learning_pathway,
# MAGIC date(max(completed_timestamp)) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   2963, -- Data Ingestion
# MAGIC   1365, -- Workloads
# MAGIC   2971, -- Data Pipelines
# MAGIC   3144 -- Governance with UC
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and max(completed_timestamp) between '2025-04-09T00:00:00UTC+14' and '2025-05-01T00:00:00UTC-12'
# MAGIC
# MAGIC -- MLWD Completions
# MAGIC union
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag) = 4 then 'MLWD' else null end as learning_pathway,
# MAGIC max(completed_date) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   2343, -- Data Prep for ML
# MAGIC   2390, -- ML Model Dev
# MAGIC   2395, -- ML Model Dep
# MAGIC   2400 -- ML Ops
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and max(completed_timestamp) between '2025-04-09T00:00:00UTC+14' and '2025-05-01T00:00:00UTC-12'
# MAGIC
# MAGIC -- GenAI Course Completions
# MAGIC union 
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag) = 4 then 'GENAI' else null end as learning_pathway,
# MAGIC max(completed_date) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   2706, -- Gen AI Solution Development
# MAGIC   2716, -- Gen AI Application Developmment
# MAGIC   2717, -- Gen AI Application Evaluation & Governance
# MAGIC   2713 -- Gen AI Application Deployment & Monitoring
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and max(completed_timestamp) between '2025-04-09T00:00:00UTC+14' and '2025-05-01T00:00:00UTC-12'
# MAGIC
# MAGIC -- Advanced ML Module Completions
# MAGIC union 
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag) = 2 then 'MLIP' else null end as learning_pathway,
# MAGIC max(completed_date) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   3417, -- ML At Scale
# MAGIC   3508 -- Advanced MLOPs
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) =2
# MAGIC and max(completed_timestamp) between '2025-04-09T00:00:00UTC+14' and '2025-05-01T00:00:00UTC-12'
# MAGIC
# MAGIC --ADEWD Completions
# MAGIC union
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag)= 4 then 'ADEWD' else null end as learning_pathway,
# MAGIC date(max(completed_timestamp)) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC     2972, -- Streaming and DLT
# MAGIC     3767, -- Data Privacy
# MAGIC     2967, -- Perf Optimization  
# MAGIC     3489 -- Automated Deployment with DABs
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and max(completed_timestamp) between '2025-04-09T00:00:00UTC+14' and '2025-05-01T00:00:00UTC-12'
# MAGIC
# MAGIC -- Full Course Completions
# MAGIC union
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Full Course' as modality,
# MAGIC case 
# MAGIC   when course_id = 1266 and attended_flag = 1 then 'DEWD' 
# MAGIC   when course_id = 2268 and attended_flag = 1 then 'ADEWD'
# MAGIC   when course_id IN (2307, 2906) and attended_flag = 1 then 'DAWD'
# MAGIC   when course_id  = 2417 and attended_flag = 1 then 'MLWD'
# MAGIC   when course_id = 1522 and attended_flag = 1 then 'MLIP'
# MAGIC   when course_id IN (2267, 2726) and attended_flag = 1 then 'GENAI' 
# MAGIC end as learning_pathway,
# MAGIC completed_date
# MAGIC from main.field_learning_enablement.all_enrollments
# MAGIC     where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC     and all_enrollments.learner_branch_code not in (
# MAGIC     'DBK_EMP' -- Exclude internal employee enrollments
# MAGIC     )
# MAGIC     and all_enrollments.course_id in (
# MAGIC     1266, -- DEWD
# MAGIC     2268, -- ADEWD
# MAGIC     2307, -- DAWD
# MAGIC     2906, -- DAWD 2024
# MAGIC     2417, -- MLWD
# MAGIC     1522, -- MLIP
# MAGIC     2267, -- GAIEWD23
# MAGIC     2726 -- GAIWD24
# MAGIC     )
# MAGIC     and attended_flag = 1
# MAGIC     and completed_timestamp between '2025-04-09T00:00:00UTC+14' and '2025-05-01T00:00:00UTC-12'
# MAGIC )
# MAGIC select q4lf.*, 
# MAGIC du.audience,
# MAGIC du.first_name,
# MAGIC du.last_name, 
# MAGIC du.email,
# MAGIC du.alternate_email, 
# MAGIC du.updated_account_id, 
# MAGIC du.updated_account_name,
# MAGIC cac.dbx,
# MAGIC du.business_unit,
# MAGIC du.sales_subregion_level_1,
# MAGIC du.sales_subregion_level_2,
# MAGIC du.sales_subregion_level_3,
# MAGIC du.country_name,
# MAGIC du.region,
# MAGIC du.country_derived, 
# MAGIC du.region_derived,
# MAGIC case when du.business_unit != 'Unknown' then du.business_unit else du.region_derived end as kathryn_region
# MAGIC from q4lf
# MAGIC join main.field_learning_enablement.docebo_users du 
# MAGIC on q4lf.learner_user_id = du.id
# MAGIC and du.processDate = (select max(processDate) from main.field_learning_enablement.docebo_users)
# MAGIC left join main.gtm_data.core_accounts_curated cac
# MAGIC on du.updated_account_id = cac.account_id;
# MAGIC
# MAGIC
# MAGIC -- SELECT * FROM _learning_festival_completions_Q1_FY26

# COMMAND ----------

# DBTITLE 1,net_new_learners
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival_net_new_learners_Q1_FY26
# MAGIC AS
# MAGIC with nnl as(
# MAGIC     select learner_user_id, course_code, completed_date
# MAGIC     from main.field_learning_enablement.all_learners
# MAGIC     where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
# MAGIC     and dataset = 'net new learners'
# MAGIC )
# MAGIC
# MAGIC -- Learning Festival
# MAGIC select 
# MAGIC ae.audience,
# MAGIC ae.learner_user_id, 
# MAGIC ae.updated_account_id,
# MAGIC ae.updated_account_name , 
# MAGIC cac.dbx,
# MAGIC ae.course_id, 
# MAGIC ae.course_code, 
# MAGIC ae.course_name,
# MAGIC case 
# MAGIC     when ae.course_id in (1266, 2963, 1365, 2971, 3144) then 'DEWD'
# MAGIC     when ae.course_id in (2268, 2967, 2972, 3767, 3489) then 'ADEWD'
# MAGIC     when ae.course_id in (2307, 2906) then 'DAWD'
# MAGIC     when ae.course_id in (2417, 2343, 2390, 2395, 2400) then 'MLWD'
# MAGIC     when ae.course_id in (1522, 3417, 3508) then 'MLIP'
# MAGIC     when ae.course_id in (2267, 2726, 2706,2716,2717,2713) then 'GENAI'
# MAGIC end as learning_pathway,
# MAGIC ae.enrolled_date, 
# MAGIC ae.completed_date, 
# MAGIC ae.attended_flag, 
# MAGIC ae.completed_fq2, 
# MAGIC nnl.completed_date as learner_date, 
# MAGIC 'Learning Festival' as course_type, 
# MAGIC ae.business_unit, 
# MAGIC IFNULL(ae.sales_subregion_level_1,'Unknown'), 
# MAGIC IFNULL(ae.sales_subregion_level_2,'Unknown'),
# MAGIC IFNULL(ae.sales_subregion_level_3,'Unknown'), 
# MAGIC case when ae.business_unit != 'Unknown' then ae.business_unit else region_derived end as kathryn_region
# MAGIC from main.field_learning_enablement.all_enrollments ae
# MAGIC join nnl
# MAGIC on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC left join main.gtm_data.core_accounts_curated cac
# MAGIC on ae.updated_account_id = cac.account_id
# MAGIC where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
# MAGIC and ae.course_id in (
# MAGIC     -- Full Courses
# MAGIC     1266, -- DEWD
# MAGIC     2268, -- ADEWD
# MAGIC     2307, -- DAWD
# MAGIC     2906, -- DAWD 2024
# MAGIC     2417, -- MLWD
# MAGIC     1522, -- MLIP
# MAGIC     2267, -- GAIEWD 2023
# MAGIC     2726, -- GAIEWD 2024
# MAGIC     -- DEWD Modules
# MAGIC     2963, -- Data Ingestion
# MAGIC     1365, -- Workloads
# MAGIC     2971, -- DLT
# MAGIC     3144, -- Governance
# MAGIC     -- ADEWD Modules
# MAGIC     2972, -- Streaming and DLT
# MAGIC     3767, -- Data Privacy
# MAGIC     2967, -- Perf Optimization  
# MAGIC     3489, -- Automated Deployment with DABs
# MAGIC     -- MLWD Modules
# MAGIC     2343, -- Data Prep
# MAGIC     2390, -- ML Model Dev
# MAGIC     2395, -- ML Model Dep
# MAGIC     2400, --ML Ops
# MAGIC     -- Gen AI
# MAGIC     2706, -- Gen AI Solution Dev
# MAGIC     2716, -- Gen AI App Dev
# MAGIC     2717, -- Gen AI App Eval
# MAGIC     2713, -- Gen AI App Deployment
# MAGIC     -- AMLWD Modules
# MAGIC     3417, -- ML at Scale
# MAGIC     3508 -- Advanced MLOPs
# MAGIC )
# MAGIC and ae.completed_timestamp between '2025-04-09T00:00:00UTC+14' and '2025-05-01T00:00:00UTC-12'; -- Q1 FY26
# MAGIC
# MAGIC -- SELECT * FROM _learning_festival_net_new_learners_Q1_FY26

# COMMAND ----------

# DBTITLE 1,learning_festival
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival_Q1_FY26
# MAGIC AS
# MAGIC WITH _nnl AS(
# MAGIC   SELECT   
# MAGIC     updated_account_id, updated_account_name, COUNT(learner_date) AS net_new_learners
# MAGIC   FROM _learning_festival_net_new_learners_Q1_FY26   
# MAGIC   GROUP BY ALL     
# MAGIC ), _completions AS(
# MAGIC   SELECT         
# MAGIC     updated_account_id, updated_account_name, COUNT(course_completed_date) AS completions
# MAGIC   FROM _learning_festival_completions_Q1_FY26
# MAGIC   GROUP BY ALL
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   'Learning Festival' AS course_type,
# MAGIC   'Learning Festival - Q1 FY26' AS session_name,
# MAGIC   CAST('2025-04-09' AS DATE) AS start_date,
# MAGIC   CAST('2025-04-30' AS DATE) AS end_date,    
# MAGIC   nvl(T1.updated_account_id, T2.updated_account_id) AS account_id,
# MAGIC   nvl(T1.updated_account_name, T2.updated_account_name) AS account_name,  
# MAGIC   COALESCE(T1.completions, 0) AS completions,
# MAGIC   COALESCE(T2.net_new_learners, 0) AS net_new_learners
# MAGIC FROM 
# MAGIC   _completions AS T1
# MAGIC FULL JOIN _nnl AS T2 USING(updated_account_id);
# MAGIC
# MAGIC -- SELECT * FROM _learning_festival_Q1_FY26;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Learning Festival Q2 FY26
# MAGIC ###### References
# MAGIC - [Q2 FY26 VLF One-Slider [FINAL]](https://docs.google.com/presentation/d/1nZSp4n921GQ4Ad45sSdWOyq2idiBVutrhOt4f-fAInM/edit?usp=sharing)
# MAGIC - [DAIS 2025 Virtual Learning Festival: 11 June - 02 July 2025](https://community.databricks.com/t5/events/dais-2025-virtual-learning-festival-11-june-02-july-2025/ec-p/119323#M3413)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Source Data

# COMMAND ----------

# DBTITLE 1,completions
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival_completions_Q2_FY26
# MAGIC AS
# MAGIC with q4lf as (
# MAGIC -- LEARNING PATHWAY 1: ASSOCIATE DATA ENGINEERING  
# MAGIC -- DEWD Completions
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag)= 4 then 'DEWD' else null end as learning_pathway,
# MAGIC date(max(completed_timestamp)) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   2963, -- Data Ingestion
# MAGIC   1365, -- Workloads
# MAGIC   2971, -- Data Pipelines
# MAGIC   3144 -- Governance with UC
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and max(completed_timestamp) between '2025-06-11T00:00:00UTC+14' and '2025-07-02T00:00:00UTC-12'
# MAGIC
# MAGIC -- LEARNING PATHWAY 2: PROFESSIONAL DATA ENGINEERING
# MAGIC -- ADEWD Completions
# MAGIC union
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag)= 4 then 'ADEWD' else null end as learning_pathway,
# MAGIC date(max(completed_timestamp)) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC     2972, -- Streaming and DLT
# MAGIC     3767, -- Data Privacy
# MAGIC     2967, -- Perf Optimization  
# MAGIC     3489 -- Automated Deployment with DABs
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and max(completed_timestamp) between '2025-06-11T00:00:00UTC+14' and '2025-07-02T00:00:00UTC-12'
# MAGIC
# MAGIC -- LEARNING PATHWAY 3: DATA ANALYSTS
# MAGIC union
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag)= 4 then 'DAWD' else null end as learning_pathway,
# MAGIC date(max(completed_timestamp)) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC     3707, -- AI/BI for Data Analysts
# MAGIC     3928 -- SQL Analytics on Databricks
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and max(completed_timestamp) between '2025-06-11T00:00:00UTC+14' and '2025-07-02T00:00:00UTC-12'
# MAGIC
# MAGIC -- LEARNING PATHWAY 4: ASSOCIATE ML PRACTITIONERS
# MAGIC -- MLWD Completions
# MAGIC union
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag) = 4 then 'MLWD' else null end as learning_pathway,
# MAGIC max(completed_date) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   2343, -- Data Prep for ML
# MAGIC   2390, -- ML Model Dev
# MAGIC   2395, -- ML Model Dep
# MAGIC   2400 -- ML Ops
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and max(completed_timestamp) between '2025-06-11T00:00:00UTC+14' and '2025-07-02T00:00:00UTC-12'
# MAGIC
# MAGIC -- LEARNING PATHWAY 5: PROFESSIONAL ML PRACTITIONERS
# MAGIC -- Advanced ML Module Completions
# MAGIC union 
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag) = 2 then 'MLIP' else null end as learning_pathway,
# MAGIC max(completed_date) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   3417, -- ML At Scale
# MAGIC   3508 -- Advanced MLOPs
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) =2
# MAGIC and max(completed_timestamp) between '2025-06-11T00:00:00UTC+14' and '2025-07-02T00:00:00UTC-12'
# MAGIC
# MAGIC -- LEARNING PATHWAY 6:  GENERATIVE AI ENGINEERING
# MAGIC -- GenAI Course Completions
# MAGIC union 
# MAGIC select 
# MAGIC learner_user_id,
# MAGIC 'Modules' as modality,
# MAGIC case when sum(attended_flag) = 4 then 'GENAI' else null end as learning_pathway,
# MAGIC max(completed_date) as course_completed_date
# MAGIC from main.field_learning_enablement.all_enrollments 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC and course_id in (
# MAGIC   2706, -- Gen AI Solution Development
# MAGIC   2716, -- Gen AI Application Developmment
# MAGIC   2717, -- Gen AI Application Evaluation & Governance
# MAGIC   2713 -- Gen AI Application Deployment & Monitoring
# MAGIC )
# MAGIC and all_enrollments.learner_branch_code != 'DBK_EMP'
# MAGIC group by 1
# MAGIC having sum(attended_flag) = 4
# MAGIC and max(completed_timestamp) between '2025-06-11T00:00:00UTC+14' and '2025-07-02T00:00:00UTC-12'
# MAGIC
# MAGIC -- -- Full Course Completions
# MAGIC -- union
# MAGIC -- select 
# MAGIC -- learner_user_id,
# MAGIC -- 'Full Course' as modality,
# MAGIC -- case 
# MAGIC --   when course_id = 1266 and attended_flag = 1 then 'DEWD' 
# MAGIC --   when course_id = 2268 and attended_flag = 1 then 'ADEWD'
# MAGIC --   when course_id IN (2307, 2906) and attended_flag = 1 then 'DAWD'
# MAGIC --   when course_id  = 2417 and attended_flag = 1 then 'MLWD'
# MAGIC --   when course_id = 1522 and attended_flag = 1 then 'MLIP'
# MAGIC --   when course_id IN (2267, 2726) and attended_flag = 1 then 'GENAI' 
# MAGIC -- end as learning_pathway,
# MAGIC -- completed_date
# MAGIC -- from main.field_learning_enablement.all_enrollments
# MAGIC --     where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
# MAGIC --     and all_enrollments.learner_branch_code not in (
# MAGIC --     'DBK_EMP' -- Exclude internal employee enrollments
# MAGIC --     )
# MAGIC --     and all_enrollments.course_id in (
# MAGIC --     1266, -- DEWD
# MAGIC --     2268, -- ADEWD
# MAGIC --     2307, -- DAWD
# MAGIC --     2906, -- DAWD 2024
# MAGIC --     2417, -- MLWD
# MAGIC --     1522, -- MLIP
# MAGIC --     2267, -- GAIEWD23
# MAGIC --     2726 -- GAIWD24
# MAGIC --     )
# MAGIC --     and attended_flag = 1
# MAGIC --     and completed_timestamp between '2025-06-11T00:00:00UTC+14' and '2025-07-02T00:00:00UTC-12'
# MAGIC )
# MAGIC select q4lf.*, 
# MAGIC du.audience,
# MAGIC du.first_name,
# MAGIC du.last_name, 
# MAGIC du.email,
# MAGIC du.alternate_email, 
# MAGIC du.updated_account_id, 
# MAGIC du.updated_account_name,
# MAGIC cac.dbx,
# MAGIC du.business_unit,
# MAGIC du.sales_subregion_level_1,
# MAGIC du.sales_subregion_level_2,
# MAGIC du.sales_subregion_level_3,
# MAGIC du.country_name,
# MAGIC du.region,
# MAGIC du.country_derived, 
# MAGIC du.region_derived,
# MAGIC case when du.business_unit != 'Unknown' then du.business_unit else du.region_derived end as kathryn_region
# MAGIC from q4lf
# MAGIC join main.field_learning_enablement.docebo_users du 
# MAGIC on q4lf.learner_user_id = du.id
# MAGIC and du.processDate = (select max(processDate) from main.field_learning_enablement.docebo_users)
# MAGIC left join main.gtm_data.core_accounts_curated cac
# MAGIC on du.updated_account_id = cac.account_id;
# MAGIC
# MAGIC
# MAGIC -- SELECT * FROM _learning_festival_completions_Q1_FY26

# COMMAND ----------

# DBTITLE 1,net_new_learners
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival_net_new_learners_Q2_FY26
# MAGIC AS
# MAGIC with nnl as(
# MAGIC     select learner_user_id, course_code, completed_date
# MAGIC     from main.field_learning_enablement.all_learners
# MAGIC     where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
# MAGIC     and dataset = 'net new learners'
# MAGIC )
# MAGIC
# MAGIC -- Learning Festival
# MAGIC select 
# MAGIC ae.audience,
# MAGIC ae.learner_user_id, 
# MAGIC ae.updated_account_id,
# MAGIC ae.updated_account_name , 
# MAGIC cac.dbx,
# MAGIC ae.course_id, 
# MAGIC ae.course_code, 
# MAGIC ae.course_name,
# MAGIC case 
# MAGIC     when ae.course_id in (1266, 2963, 1365, 2971, 3144) then 'DEWD'
# MAGIC     when ae.course_id in (2268, 2967, 2972, 3767, 3489) then 'ADEWD'
# MAGIC     when ae.course_id in (2307, 2906) then 'DAWD'
# MAGIC     when ae.course_id in (2417, 2343, 2390, 2395, 2400) then 'MLWD'
# MAGIC     when ae.course_id in (1522, 3417, 3508) then 'MLIP'
# MAGIC     when ae.course_id in (2267, 2726, 2706,2716,2717,2713) then 'GENAI'
# MAGIC end as learning_pathway,
# MAGIC ae.enrolled_date, 
# MAGIC ae.completed_date, 
# MAGIC ae.attended_flag, 
# MAGIC ae.completed_fq2, 
# MAGIC nnl.completed_date as learner_date, 
# MAGIC 'Learning Festival' as course_type, 
# MAGIC ae.business_unit, 
# MAGIC IFNULL(ae.sales_subregion_level_1,'Unknown'), 
# MAGIC IFNULL(ae.sales_subregion_level_2,'Unknown'),
# MAGIC IFNULL(ae.sales_subregion_level_3,'Unknown'), 
# MAGIC case when ae.business_unit != 'Unknown' then ae.business_unit else region_derived end as kathryn_region
# MAGIC from main.field_learning_enablement.all_enrollments ae
# MAGIC join nnl
# MAGIC on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC left join main.gtm_data.core_accounts_curated cac
# MAGIC on ae.updated_account_id = cac.account_id
# MAGIC where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
# MAGIC and ae.course_id in (
# MAGIC     -- Full Courses
# MAGIC     1266, -- DEWD
# MAGIC     2268, -- ADEWD
# MAGIC     2307, -- DAWD
# MAGIC     2906, -- DAWD 2024
# MAGIC     2417, -- MLWD
# MAGIC     1522, -- MLIP
# MAGIC     2267, -- GAIEWD 2023
# MAGIC     2726, -- GAIEWD 2024
# MAGIC     -- DEWD Modules
# MAGIC     2963, -- Data Ingestion
# MAGIC     1365, -- Workloads
# MAGIC     2971, -- DLT
# MAGIC     3144, -- Governance
# MAGIC     -- ADEWD Modules
# MAGIC     2972, -- Streaming and DLT
# MAGIC     3767, -- Data Privacy
# MAGIC     2967, -- Perf Optimization  
# MAGIC     3489, -- Automated Deployment with DABs
# MAGIC     -- MLWD Modules
# MAGIC     2343, -- Data Prep
# MAGIC     2390, -- ML Model Dev
# MAGIC     2395, -- ML Model Dep
# MAGIC     2400, --ML Ops
# MAGIC     -- Gen AI
# MAGIC     2706, -- Gen AI Solution Dev
# MAGIC     2716, -- Gen AI App Dev
# MAGIC     2717, -- Gen AI App Eval
# MAGIC     2713, -- Gen AI App Deployment
# MAGIC     -- AMLWD Modules
# MAGIC     3417, -- ML at Scale
# MAGIC     3508 -- Advanced MLOPs
# MAGIC )
# MAGIC and ae.completed_timestamp between '2025-06-11T00:00:00UTC+14' and '2025-07-02T00:00:00UTC-12'; -- Q2 FY26
# MAGIC
# MAGIC -- SELECT * FROM _learning_festival_net_new_learners_Q1_FY26

# COMMAND ----------

# DBTITLE 1,learning_festival
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival_Q2_FY26
# MAGIC AS
# MAGIC WITH _nnl AS(
# MAGIC   SELECT   
# MAGIC     updated_account_id, updated_account_name, COUNT(learner_date) AS net_new_learners
# MAGIC   FROM _learning_festival_net_new_learners_Q2_FY26
# MAGIC   GROUP BY ALL     
# MAGIC ), _completions AS(
# MAGIC   SELECT         
# MAGIC     updated_account_id, updated_account_name, COUNT(course_completed_date) AS completions
# MAGIC   FROM _learning_festival_completions_Q2_FY26
# MAGIC   GROUP BY ALL
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   'Learning Festival' AS course_type,
# MAGIC   'Learning Festival - Q2 FY26' AS session_name,
# MAGIC   CAST('2025-06-11' AS DATE) AS start_date,
# MAGIC   CAST('2025-06-02' AS DATE) AS end_date,  
# MAGIC   nvl(T1.updated_account_id, T2.updated_account_id) AS account_id,
# MAGIC   nvl(T1.updated_account_name, T2.updated_account_name) AS account_name,  
# MAGIC   COALESCE(T1.completions, 0) AS completions,
# MAGIC   COALESCE(T2.net_new_learners, 0) AS net_new_learners
# MAGIC FROM 
# MAGIC   _completions AS T1
# MAGIC FULL JOIN _nnl AS T2 USING(updated_account_id);
# MAGIC
# MAGIC SELECT * FROM _learning_festival_Q2_FY26;

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Source Data

# COMMAND ----------

# MAGIC %md
# MAGIC ##### AIBI Campaign
# MAGIC

# COMMAND ----------

# %sql
# -- =============================================
# -- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
# -- Create date: 2025-01-09
# -- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
# -- =============================================
# CREATE OR REPLACE TEMPORARY VIEW _aibi_campaign AS
#   with nnl as(
#       select learner_user_id, course_code, completed_date
#       from main.field_learning_enablement.all_learners
#       where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
#       and dataset = 'net new learners'
#   )  
#   SELECT    
#     'AI/BI Campaign' AS course_type,    
#     T1.session_name,
#     T1.session_date AS start_date,
#     T1.session_date AS end_date,    
#     T1.account_id,
#     T1.account_name,    
#     SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS completions,
#     SUM(CASE WHEN T1.learner_date IS NOT NULL THEN 1 END) AS net_new_learners
#   FROM(
#     SELECT 
#       T1.session_code,
#       TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name,
#       CAST(T1.ended_timestamp AS DATE) AS session_date,
#       T1.updated_account_id AS account_id,
#       T1.updated_account_name AS account_name,      
#       T1.completed_date,
#       T3.completed_date AS learner_date
#     FROM 
#         main.field_learning_enablement.all_enrollments AS T1
#     INNER JOIN
#       main.field_learning_enablement.training_operations_ilt_schedule_master AS T2
#     ON 
#       T1.session_code = T2.academy_session_number
#     LEFT JOIN 
#       nnl AS T3
#     ON 
#       T1.learner_user_id = T3.learner_user_id
#       AND T1.course_code = T3.course_code
#     WHERE 
#       T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)    
#       AND T2.processDate = (SELECT max(processDate) FROM main.field_learning_enablement.training_operations_ilt_schedule_master)
#       AND (T2.project_type = 'AI/BI Training Program' AND T2.status not ilike 'cancel%')      
#   ) AS T1
#   LEFT JOIN  
#     main.gtm_data.core_accounts_curated AS a USING (account_id)
#   GROUP BY ALL;

# -- SELECT * FROM _aibi_campaign
# -- ORDER BY 1, 4;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### APJ Events
# MAGIC ###### References
# MAGIC Considering the Start Date and End Date for the first 9 events on this spreadsheet [[MASTER] Integrated Training Event Calendar
# MAGIC ](https://docs.google.com/spreadsheets/d/1P1QTjn7fdiWyAIO95iaPpFJ3yvovhXesJl31ZUCdmK0/edit?gid=0#gid=0)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Source Data

# COMMAND ----------

from pyspark.sql import Row

data = [
    Row(Status="Completed", UE_Event_ID="250219APLF", Event_Name="Databricks Asia-Pacific Learning Festival", UE_Owner="Sunwoo Park", Stakeholder_POC="June Tan", Fiscal_Quarter="Q1", Start_Date="19 Feb 2025", End_Date="20 Feb 2025", Time="11:30-13:30 (SGT) - Day 1; 10:30-15:00 (SGT) - Day 2", Modality="Virtual", Hands_On="Mixed", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects, Partners", Session_ID="7433, 7617, 7618, 7619, 7620"),
    Row(Status="Completed", UE_Event_ID="250305APIC", Event_Name="Intelligent Data Warehousing: AI/BI for Self-Service Analytics", UE_Owner="Sunwoo Park", Stakeholder_POC="June Tan", Fiscal_Quarter="Q1", Start_Date="5 Mar 2025", End_Date="5 Mar 2025", Time="11:00-15:00 (SGT)", Modality="Virtual", Hands_On="No Lab", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects, Partners", Session_ID="7824"),
    Row(Status="Completed", UE_Event_ID="250319ANDI", Event_Name="Databricks Data Intelligence Day Melbourne Australia 2025", UE_Owner="Sunwoo Park", Stakeholder_POC="Renate Leknes", Fiscal_Quarter="Q1", Start_Date="19 Mar 2025", End_Date="19 Mar 2025", Time="13:00-17:00 (AET)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects", Session_ID="7960, 7961"),
    Row(Status="Completed", UE_Event_ID="250327ANDI", Event_Name="Databricks Data Intelligence Day Sydney Australia 2025", UE_Owner="Sunwoo Park", Stakeholder_POC="Renate Leknes", Fiscal_Quarter="Q1", Start_Date="27 Mar 2025", End_Date="27 Mar 2025", Time="13:00-17:00 (AET)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects", Session_ID="7962, 7963"),
    Row(Status="Completed", UE_Event_ID="250327APIC", Event_Name="Intelligent Data Warehousing: AI/BI for Self-Service Analytics (Korean)", UE_Owner="Sunwoo Park", Stakeholder_POC="Eunwoo Kim", Fiscal_Quarter="Q1", Start_Date="27 Mar 2025", End_Date="27 Mar 2025", Time="13:00-17:00 (KST)", Modality="Virtual", Hands_On="No Lab", Content_Language="Korean", Delivery_Language="Korean", Target_Audience="Customers, Prospects, Partners", Session_ID="7993"),
    Row(Status="Completed", UE_Event_ID="250404INDI", Event_Name="Databricks Data Intelligence Day Bangalore India 2025", UE_Owner="Sunwoo Park", Stakeholder_POC="Sanjana Dayanidhi", Fiscal_Quarter="Q1", Start_Date="4 Apr 2025", End_Date="4 Apr 2025", Time="09:30-13:30 (IST)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects", Session_ID="8170"),
    Row(Status="Completed", UE_Event_ID="250408APIC", Event_Name="Intelligent Data Warehousing: AI/BI for Self-Service Analytics", UE_Owner="Himanshu Vajani", Stakeholder_POC="June Tan", Fiscal_Quarter="Q1", Start_Date="8 Apr 2025", End_Date="8 Apr 2025", Time="11:00-15:00 (SGT)", Modality="Virtual", Hands_On="No Lab", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects, Partners", Session_ID="7823"),
    Row(Status="Completed", UE_Event_ID="250409AGDI", Event_Name="Databricks Data Intelligence Day Hong Kong 2025", UE_Owner="Sunwoo Park", Stakeholder_POC="Denise Wee", Fiscal_Quarter="Q1", Start_Date="9 Apr 2025", End_Date="9 Apr 2025", Time="13:00-16:00 (HKT)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects", Session_ID="7880"),
    Row(Status="Completed", UE_Event_ID="250409GLLF", Event_Name="Databricks Virtual Learning Festival (Global Quarterly)", UE_Owner="Sunwoo Park", Stakeholder_POC="Jim Anderson", Fiscal_Quarter="Q1", Start_Date="9 Apr 2025", End_Date="30 Apr 2025", Time="On Demand", Modality="Virtual", Hands_On="No Lab", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects, Partners", Session_ID="-"),
    Row(Status="Completed", UE_Event_ID="250422JPBC", Event_Name="Databricks Novice Hands-On Bootcamp (Japanese)", UE_Owner="Sunwoo Park", Stakeholder_POC="Kaori Ishige", Fiscal_Quarter="Q1", Start_Date="22 Apr 2025", End_Date="22 Apr 2025", Time="10:00-17:00 (JST)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="Japanese", Target_Audience="Customers", Session_ID="8466, 8467, 8680"),
    Row(Status="Completed", UE_Event_ID="250425INDI", Event_Name="Databricks Data Intelligence Day Mumbai India 2025", UE_Owner="Sunwoo Park", Stakeholder_POC="Sanjana Dayanidhi", Fiscal_Quarter="Q1", Start_Date="25 Apr 2025", End_Date="25 Apr 2025", Time="09:30-13:30 (IST)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects", Session_ID="8013"),
    Row(Status="Completed", UE_Event_ID="250429KRDI", Event_Name="Databricks Data Intelligence Day Seoul Korea 2025", UE_Owner="Sunwoo Park", Stakeholder_POC="Eunwoo Kim", Fiscal_Quarter="Q1", Start_Date="29 Apr 2025", End_Date="29 Apr 2025", Time="11:45-15:00 (KST)", Modality="In Person", Hands_On="Hands On", Content_Language="Korean", Delivery_Language="Korean", Target_Audience="Customers, Prospects", Session_ID="8307"),
    Row(Status="Completed", UE_Event_ID="250501AUIM", Event_Name="Optus Data + AI Immersion Day", UE_Owner="Sunwoo Park", Stakeholder_POC="Chuong Vu", Fiscal_Quarter="Q2", Start_Date="1 May 2025", End_Date="1 May 2025", Time="09:00-17:00 (AET)", Modality="In Person", Hands_On="Mixed", Content_Language="English", Delivery_Language="English", Target_Audience="Customers", Session_ID="8236, 8237"),
    Row(Status="Completed", UE_Event_ID="250508JPAS", Event_Name="AI/BI for Self-Service Analytics (Japanese)", UE_Owner="Anshul Khera & Himanshu Vajani", Stakeholder_POC="Kaori Ishige", Fiscal_Quarter="Q2", Start_Date="8 May 2025", End_Date="8 May 2025", Time="13:00-17:00 (JST)", Modality="Virtual", Hands_On="No Lab", Content_Language="Japanese", Delivery_Language="Japanese", Target_Audience="Customers, Prospects, Partners", Session_ID="8221"),
    Row(Status="Completed", UE_Event_ID="250514APSC", Event_Name="Smart Business Insights Challenge: AI/BI for Self-Service Analytics", UE_Owner="Himanshu Vajani", Stakeholder_POC="June Tan", Fiscal_Quarter="Q2", Start_Date="14 May 2025", End_Date="14 May 2025", Time="11:00-15:00 (SGT)", Modality="Virtual", Hands_On="No Lab", Content_Language="English", Delivery_Language="English", Target_Audience="Customers", Session_ID="8385"),
    Row(Status="Completed", UE_Event_ID="250520AUBC", Event_Name="Databricks Novice Hands-On Bootcamp (ANZ Brisbane)", UE_Owner="Anshul Khera", Stakeholder_POC="Renate Leknes", Fiscal_Quarter="Q2", Start_Date="20 May 2025", End_Date="20 May 2025", Time="08:00-17:00 (AET)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers", Session_ID="9477, 9482, 9483"),
    Row(Status="Completed", UE_Event_ID="250520NZBC", Event_Name="Databricks Novice Hands-On Bootcamp (ANZ Auckland)", UE_Owner="Anshul Khera", Stakeholder_POC="Renate Leknes", Fiscal_Quarter="Q2", Start_Date="20 May 2025", End_Date="20 May 2025", Time="08:00-17:00 (AET)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers", Session_ID="9469, 9472, 9481"),
    Row(Status="Completed", UE_Event_ID="250521GCGD", Event_Name="Get Started Day (Mandarin Chinese)", UE_Owner="Himanshu Vajani", Stakeholder_POC="Nadia Elsayed", Fiscal_Quarter="Q2", Start_Date="21 May 2025", End_Date="21 May 2025", Time="10:30-14:30 (SGT)", Modality="Virtual", Hands_On="No Lab", Content_Language="English", Delivery_Language="Mandarin Chinese", Target_Audience="Customers, Prospects, Partners", Session_ID="8140"),
    Row(Status="Completed", UE_Event_ID="250522AUBC", Event_Name="Databricks Novice Hands-On Bootcamp (ANZ Perth)", UE_Owner="Anshul Khera", Stakeholder_POC="Renate Leknes", Fiscal_Quarter="Q2", Start_Date="22 May 2025", End_Date="22 May 2025", Time="08:00-17:00 (AET)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers", Session_ID="9470, 9473, 9474"),
    Row(Status="Completed", UE_Event_ID="250522KRBC", Event_Name="Databricks Novice Hands-On Bootcamp (Korean)", UE_Owner="Anshul Khera", Stakeholder_POC="Eunwoo Kim", Fiscal_Quarter="Q2", Start_Date="22 May 2025", End_Date="22 May 2025", Time="13:00-17:00 (KST)", Modality="In Person", Hands_On="Hands On", Content_Language="Korean", Delivery_Language="Korean", Target_Audience="Customers", Session_ID="9446, 9447"),
    Row(Status="Completed", UE_Event_ID="250527APSC", Event_Name="Smart Business Insights Challenge: AI/BI for Self-Service Analytics", UE_Owner="Himanshu Vajani", Stakeholder_POC="June Tan", Fiscal_Quarter="Q2", Start_Date="27 May 2025", End_Date="27 May 2025", Time="11:00-15:00 (SGT)", Modality="Virtual", Hands_On="No Lab", Content_Language="English", Delivery_Language="English", Target_Audience="Customers", Session_ID="8386"),
    Row(Status="Completed", UE_Event_ID="250527JPBC", Event_Name="Databricks Data+AI Foundations Bootcamp (Japanese)", UE_Owner="Himanshu Vajani", Stakeholder_POC="Kaori Ishige", Fiscal_Quarter="Q2", Start_Date="27 May 2025", End_Date="27 May 2025", Time="10:00-17:00 (JST)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="Japanese", Target_Audience="Customers", Session_ID="9538"),
    Row(Status="Completed", UE_Event_ID="250603INBB", Event_Name="India In-Account Scale Training - Novartis", UE_Owner="Anshul Khera", Stakeholder_POC="Vlad Marin", Fiscal_Quarter="Q2", Start_Date="3 Jun 2025", End_Date="5 Jun 2025", Time="11:00-19:00 (IST)", Modality="Hybrid", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers", Session_ID="9504, 9505, 9506, 9507"),
    Row(Status="Completed", UE_Event_ID="250604SGBC", Event_Name="Singapore Public Healthcare Data Day", UE_Owner="Himanshu Vajani", Stakeholder_POC="Lynn Tian Lin", Fiscal_Quarter="Q2", Start_Date="4 Jun 2025", End_Date="4 Jun 2025", Time="10:30-16:00 (SGT)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers", Session_ID="9452, 9707"),
]

df = spark.createDataFrame(data)

## Get event data
from pyspark.sql import functions as f

event_sessions = df
event_sessions = event_sessions.withColumn(
  "Session_id", f.split(event_sessions["Session_id"], ",")).withColumn(
  "Session_id", f.expr("transform(Session_id, x -> try_cast(trim(x) as bigint))")).withColumn(
  "Start_Date", f.to_date(f.col("Start_Date"), "d MMM yyyy")).withColumn(
  "End_Date", f.to_date(f.col("End_Date"), "d MMM yyyy")
)

## Get session data
df_all_enrollments = spark.sql(""" 
  with nnl as(
    select learner_user_id, course_code
    from main.field_learning_enablement.all_learners
    where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    and dataset = 'net new learners')

    SELECT ae.*, nnl.learner_user_id AS new_learner_id FROM main.field_learning_enablement.all_enrollments ae 
    LEFT JOIN nnl ON ae.learner_user_id = nnl.learner_user_id AND ae.course_code = nnl.course_code
    WHERE ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
""")

df_all_enrollments = df_all_enrollments.select("updated_account_id", "updated_account_name", "session_id", "learner_user_id", "completed_date", "new_learner_id")

## Join the event and session data
apj_events = event_sessions.withColumn(
  "session_id", f.explode(f.col("Session_id"))
).join(df_all_enrollments, on="session_id", how="left")

apj_events = apj_events.groupby(
  f.lit("APJ Events").alias("course_type"),
  f.col("Event_Name").alias("session_name"), 
  "start_date", "end_date", 
  f.col("updated_account_id").alias("account_id"), 
  f.col("updated_account_name").alias("account_name")
).agg(  
  f.countDistinct(f.when(f.col("completed_date").isNotNull(), f.col("learner_user_id"))).alias("completions"),
  f.countDistinct("new_learner_id").alias("net_new_learners"))

apj_events = apj_events.groupby(
  "course_type", 
  "account_id", 
  "account_name",
  f.date_trunc("month", f.col("end_date")).alias("month"),
).agg(
  f.sum("completions").alias("completions"),
  f.sum("net_new_learners").alias("net_new_learners"),  
  f.min("start_date").alias("start_date"),
  f.max("end_date").alias("end_date"),
  f.concat_ws(", ", f.collect_set("session_name")).alias("session_name")
).drop("month")

apj_events = apj_events.select("course_type", "session_name", "start_date", "end_date", "account_id", "account_name", "completions", "net_new_learners")

apj_events.createOrReplaceTempView("_apj_events")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Get Started Days events Impact
# MAGIC
# MAGIC Request received from Suna
# MAGIC
# MAGIC Replicating the same analysis done for APJ but now for the Get Started Days campaign
# MAGIC
# MAGIC Considering the dates for the Get Started Days shown on this dashboard [Databricks Get Started Days](https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01efce705dc9175898be331d9e3d9fd1/published?o=2548836972759138)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Source Data

# COMMAND ----------

# %sql
# CREATE OR REPLACE TEMPORARY VIEW _get_started_days
# AS
# with nnl as(
#   select learner_user_id, course_code
#   from main.field_learning_enablement.all_learners
#   where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
#   and dataset = 'net new learners')
# , _get_started_days
# AS(
#   select     
#     en.*, lab.id_coupon, lab.code, lab.transactionID, lab.subscription_trans_id, lab.coupon_used_date, lab.valid_from, lab.valid_to, hour(en.enrolled_timestamp) as enrolled_hour, timediff(hour, en.enrolled_timestamp,  en.started_timestamp) as time_before_session,
#     concat('Databricks Get Started Day | ', date_format(en.session_date, 'MMM dd yyyy'), ' | ', en.session_region) AS session_name_cleaned,
#     nnl.learner_user_id AS new_learner_id
#   from main.team_field_user_enablement.vw_ue_enrolments_ilt en
#   left join nnl ON en.learner_user_id = nnl.learner_user_id AND en.course_code = nnl.course_code
#   left join (
#       select * from main.team_field_user_enablement.vw_coupon_usage
#       where code ilike 'ACAD-FREE-GS-LAB-%') lab
#   on en.learner_user_id = lab.userID
#   where en.course_id = 3125
# )

# SELECT
#   "Get Started Days" course_type,
#   session_name_cleaned AS session_name,
#   session_date AS start_date,
#   session_date AS end_date,
#   updated_account_id AS account_id,
#   updated_account_name AS account_name,  
#   COUNT(completed_date) AS completions,
#   COUNT(new_learner_id) AS net_new_learners
# FROM
#   _get_started_days AS en
# WHERE
#   date_trunc('month', session_date) >= date_trunc('month', add_months(current_date(), -5))
# GROUP BY ALL;

# -- SELECT * FROM _get_started_days;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### UE Programs
# MAGIC ###### References
# MAGIC - [User Enablement - Virtual Learning Festival Q4 FY25](https://adb-2548836972759138.18.azuredatabricks.net/sql/dashboardsv3/01eeb55263f11568bc7ad85275e872d3/datasets/c5fe88ab?o=2548836972759138)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _ue_programs
# MAGIC AS
# MAGIC with nnl as(
# MAGIC   select learner_user_id, course_code, completed_date
# MAGIC   from main.field_learning_enablement.all_learners
# MAGIC   where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
# MAGIC   and dataset = 'net new learners')
# MAGIC
# MAGIC SELECT 
# MAGIC   course_type,
# MAGIC   session_name,
# MAGIC   session_date AS start_date,
# MAGIC   session_date AS end_date,
# MAGIC   -- date_trunc('month', session_date) AS session_date_month,
# MAGIC   -- CASE WHEN COUNT(DISTINCT session_name) > 1 THEN 'Multiple sessions' ELSE concat_ws(', ', collect_set(session_name)) END AS session_name,  
# MAGIC   -- concat_ws(', ', collect_set(session_name)) AS session_name,
# MAGIC   -- min(session_date) AS start_date,
# MAGIC   -- max(session_date) AS end_date,
# MAGIC
# MAGIC   account_id,
# MAGIC   account_name,  
# MAGIC   COUNT(completed_date) AS completions,
# MAGIC   COUNT(learner_date) AS net_new_learners
# MAGIC FROM(
# MAGIC   -- AI/BI Campaign / Onboarding & HDC ILT / private workshops / Get Started Days
# MAGIC   SELECT
# MAGIC     learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2,
# MAGIC     CASE
# MAGIC       -- AI/BI Campaign
# MAGIC       WHEN a.project_type = 'AI/BI Training Program' AND a.status not ilike 'cancel%' THEN 'AI/BI Campaign' 
# MAGIC       -- Get Started Days
# MAGIC       WHEN a.course_id = 3125 THEN 'Get Started Days'
# MAGIC       -- Onboarding & HDC ILT
# MAGIC       WHEN a.training_type = 'Public' AND a.course_type IN ('Half-Day', 'Onboarding') THEN a.course_type
# MAGIC       -- private workshops
# MAGIC       WHEN a.training_type = 'Private' and provider = 'User Enablement' THEN 'Workshop'
# MAGIC     END AS course_type,    
# MAGIC     CASE
# MAGIC       WHEN a.course_id = 3125 THEN concat('Databricks Get Started Day | ', date_format(a.session_date, 'MMM dd yyyy'), ' | ', a.session_region)
# MAGIC       ELSE TRIM(SPLIT_PART(a.session_name, '|', 3)) END AS session_name,
# MAGIC     cast(substr(a.session_date, 1, 10) as date) AS session_date,
# MAGIC     a.updated_account_id AS account_id,
# MAGIC     a.updated_account_name AS account_name    
# MAGIC   FROM 
# MAGIC     main.team_field_user_enablement.vw_ue_enrolments_ilt AS a
# MAGIC   WHERE 
# MAGIC     session_date >= '2024-02-01'  
# MAGIC     AND(
# MAGIC       (a.training_type = 'Public' AND a.course_type IN ('Half-Day', 'Onboarding'))
# MAGIC       OR(a.training_type = 'Private' and provider = 'User Enablement')
# MAGIC       OR(a.course_id = 3125)      
# MAGIC     )
# MAGIC   union
# MAGIC   
# MAGIC   -- self-paced onboarding
# MAGIC   SELECT 
# MAGIC     learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2,
# MAGIC     'Self-Paced' as course_type,
# MAGIC     'Self-Paced' AS session_name,
# MAGIC     MAX(completed_date)OVER(PARTITION BY account_id, date_trunc('MM', completed_date)) AS session_date,
# MAGIC     account_id,
# MAGIC     account_name
# MAGIC   FROM main.team_field_user_enablement.vw_ue_enrolments_sp a
# MAGIC   where completed_date >= '2024-02-01'  
# MAGIC   union
# MAGIC
# MAGIC   -- Summit / World Tour
# MAGIC   select
# MAGIC     ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2,
# MAGIC     'DAIS' as course_type,
# MAGIC     'DAIS' AS session_name,
# MAGIC     '2024-06-13' AS session_date,
# MAGIC     ae.updated_account_id AS account_id,
# MAGIC     ae.updated_account_name AS account_name  
# MAGIC   from main.field_learning_enablement.all_enrollments ae
# MAGIC   left join nnl
# MAGIC   on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC   where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC   and ae.course_name like '%DAIS 2024%'
# MAGIC   and ae.completed_date >= '2024-02-01'
# MAGIC   union
# MAGIC
# MAGIC   -- DAIWT
# MAGIC   select 
# MAGIC     ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2,
# MAGIC     'DAIWT' as course_type,
# MAGIC     'DAIWT' AS session_name,
# MAGIC     MAX(ae.completed_date)OVER(PARTITION BY updated_account_id, date_trunc('MM', ae.completed_date)) AS session_date,
# MAGIC     ae.updated_account_id AS account_id,
# MAGIC     ae.updated_account_name AS account_name
# MAGIC   from main.field_learning_enablement.all_enrollments ae
# MAGIC   left join nnl
# MAGIC   on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC   where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC   and ae.course_name like '%DAIWT 2024%'
# MAGIC   and ae.completed_date >= '2024-02-01'
# MAGIC   union
# MAGIC
# MAGIC   -- Databricks Academy Labs
# MAGIC   select 
# MAGIC     ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2,
# MAGIC     'Academy Labs' as course_type,
# MAGIC     'Academy Labs' AS session_name,
# MAGIC     MAX(ae.completed_date)OVER(PARTITION BY updated_account_id, date_trunc('MM', ae.completed_date)) AS session_date,
# MAGIC     ae.updated_account_id AS account_id,
# MAGIC     ae.updated_account_name AS account_name
# MAGIC   from main.field_learning_enablement.all_enrollments ae
# MAGIC   left join nnl
# MAGIC   on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC   where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC   and ae.completed_date >= '2024-02-01'
# MAGIC   and ae.course_code IN (
# MAGIC       select distinct course_code from main.it_training_silver.docebo_subscription_enrollments
# MAGIC       where processDate = (select max(processDate) from main.it_training_silver.docebo_subscription_enrollments)
# MAGIC       and subscription_plan_code = 'DB-ACAD-LABS-SUB-PLAN'
# MAGIC   )
# MAGIC   union
# MAGIC
# MAGIC   -- EMEA Bootcamps
# MAGIC   select
# MAGIC     ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2,
# MAGIC     'EMEA Bootcamps' as course_type,
# MAGIC     'EMEA Bootcamps' AS session_name,
# MAGIC     MAX(ae.completed_date)OVER(PARTITION BY updated_account_id, date_trunc('MM', ae.completed_date)) AS session_date,
# MAGIC     ae.updated_account_id AS account_id,
# MAGIC     ae.updated_account_name AS account_name
# MAGIC   from main.field_learning_enablement.all_enrollments ae
# MAGIC   left join nnl
# MAGIC   on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC   where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC     and ae.course_id IN(
# MAGIC       3544,
# MAGIC       -- Fundamentals
# MAGIC       3793,
# MAGIC       -- Generative AI
# MAGIC       3930 -- Data Warehousing
# MAGIC     )
# MAGIC
# MAGIC ) AS X
# MAGIC GROUP BY ALL;
# MAGIC
# MAGIC -- SELECT * FROM _ue_programs WHERE account_id = '0016100000QKcK9AAL' AND course_type = 'Onboarding';

# COMMAND ----------

# MAGIC %sql
# MAGIC with x
# MAGIC AS(
# MAGIC with nnl as(
# MAGIC     select learner_user_id, course_code, completed_date
# MAGIC     from main.field_learning_enablement.all_learners
# MAGIC     where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
# MAGIC     and dataset = 'net new learners'
# MAGIC )
# MAGIC
# MAGIC   -- Onboarding & HDC ILT
# MAGIC   select learner_user_id, course_code, course_name,  enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') as sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') as sales_subregion_level_2
# MAGIC   from main.team_field_user_enablement.vw_ue_enrolments_ilt
# MAGIC   where session_date >= '2024-02-01'
# MAGIC   and training_type = 'Public'
# MAGIC   and course_type IN ('Half-Day', 'Onboarding')
# MAGIC   union
# MAGIC
# MAGIC   --private workshops
# MAGIC   select learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, 'Workshop' as course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2
# MAGIC   from main.team_field_user_enablement.vw_ue_enrolments_ilt
# MAGIC   where session_date>= '2024-02-01'
# MAGIC   and training_type = 'Private'
# MAGIC   and provider = 'User Enablement'
# MAGIC   union
# MAGIC
# MAGIC   -- self-paced onboarding
# MAGIC   select learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, 'Self-Paced' as course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2
# MAGIC   from main.team_field_user_enablement.vw_ue_enrolments_sp
# MAGIC   where completed_date >= '2024-02-01'  
# MAGIC   union
# MAGIC
# MAGIC   -- summit
# MAGIC   select ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'DAIS' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
# MAGIC   from main.field_learning_enablement.all_enrollments ae
# MAGIC   left join nnl
# MAGIC   on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC   where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC   and ae.course_name like '%DAIS 2024%'
# MAGIC   and ae.completed_date >= '2024-02-01'
# MAGIC   union  
# MAGIC
# MAGIC   -- World Tour
# MAGIC   select ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'DAIWT' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
# MAGIC   from main.field_learning_enablement.all_enrollments ae
# MAGIC   left join nnl
# MAGIC   on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC   where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC   and ae.course_name like '%DAIWT 2024%'
# MAGIC   and ae.completed_date >= '2024-02-01'
# MAGIC   union
# MAGIC   -- Databricks Academy Labs
# MAGIC   
# MAGIC   select ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'Academy Labs' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
# MAGIC   from main.field_learning_enablement.all_enrollments ae
# MAGIC   left join nnl
# MAGIC   on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC   where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC   and ae.completed_date >= '2024-02-01'
# MAGIC   and ae.course_code IN (
# MAGIC       select distinct course_code from main.it_training_silver.docebo_subscription_enrollments
# MAGIC       where processDate = (select max(processDate) from main.it_training_silver.docebo_subscription_enrollments)
# MAGIC       and subscription_plan_code = 'DB-ACAD-LABS-SUB-PLAN'
# MAGIC   )
# MAGIC   union
# MAGIC   -- EMEA Bootcamps
# MAGIC   select * from main.team_field_user_enablement.vw_emea_bootcamps  
# MAGIC   union
# MAGIC
# MAGIC   -- Learning Festival Q1 - Q3
# MAGIC   select ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'Learning Festival' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
# MAGIC   from main.field_learning_enablement.all_enrollments ae
# MAGIC   left join nnl
# MAGIC   on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC   where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC   and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
# MAGIC   and ae.course_id in (
# MAGIC       1266, -- DEWD
# MAGIC       2268, -- ADEWD
# MAGIC       2307, -- DAWD
# MAGIC       2906, -- DAWD 2024
# MAGIC       2417, -- MLWD
# MAGIC       1522, -- MLIP
# MAGIC       2267, -- GAIEWD 2023
# MAGIC       2726 -- GAIEWD 2024
# MAGIC   )
# MAGIC   and 
# MAGIC   (
# MAGIC       ae.completed_timestamp between '2024-02-29T00:00:00UTC+14' and '2024-03-14T00:00:00UTC-12' -- Q1 FY25
# MAGIC       or 
# MAGIC       ae.completed_timestamp between '2024-07-10T00:00:00UTC+14' and '2024-07-25T00:00:00UTC-12' -- Q2 FY25
# MAGIC       or
# MAGIC       ae.completed_timestamp between '2024-10-10T00:00:00UTC+14' and '2024-11-01T00:00:00UTC-12' -- Q3 FY25
# MAGIC   )  
# MAGIC )
# MAGIC
# MAGIC select course_type, count(completed_date), count(learner_date) from x group by course_type

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Merge accounts into table

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Get account level impact

# COMMAND ----------

# DBTITLE 1,Merge programs
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _programs
# MAGIC AS
# MAGIC SELECT * FROM _learning_festival_completions_Q1_Q3_FY25 UNION
# MAGIC SELECT * FROM _learning_festival_Q4_FY25 UNION 
# MAGIC SELECT * FROM _learning_festival_Q1_FY26 UNION 
# MAGIC SELECT * FROM _learning_festival_Q2_FY26 UNION 
# MAGIC SELECT * FROM _ue_programs UNION 
# MAGIC SELECT * FROM _apj_events;  

# COMMAND ----------

# DBTITLE 1,Get the initial metrics
import pyspark.sql.functions as F

df_sessions_metrics = spark.sql("SELECT * FROM _programs UNPIVOT INCLUDE NULLS(value for metric IN (completions, net_new_learners))")

df_sessions = spark.sql("SELECT * EXCEPT (completions, net_new_learners) FROM _programs")

display(df_sessions_metrics)

# COMMAND ----------

# DBTITLE 1,Get impact measurement
metrics_to_measure = ["wau_human", "dbsql_wau"]

df_result = get_campaign_impact(df_sessions, metrics_to_measure = metrics_to_measure, weeks_to_analyze = 4)

display(df_result)

# COMMAND ----------

df_result.createOrReplaceTempView("_vw_campaign_impact")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.field_learning_enablement.fact_campaign_impact
# MAGIC AS
# MAGIC SELECT  
# MAGIC   case
# MAGIC     when lpad(month(end_date), 2, '0') = '01' then year(end_date)
# MAGIC     else year(end_date) + 1
# MAGIC   end AS end_date_fiscalYear,
# MAGIC   concat(
# MAGIC     "FY'",
# MAGIC     substr(end_date_fiscalYear, 3, 2),
# MAGIC     ' ',
# MAGIC     case
# MAGIC       when lpad(month(end_date), 2, '0') in ('02', '03', '04') then 'Q1'
# MAGIC       when lpad(month(end_date), 2, '0') in ('05', '06', '07') then 'Q2'
# MAGIC       when lpad(month(end_date), 2, '0') in ('08', '09', '10') then 'Q3'
# MAGIC       when lpad(month(end_date), 2, '0') in ('11', '12', '01') then 'Q4'
# MAGIC     end
# MAGIC   ) AS end_date_fq2,
# MAGIC   a.business_unit AS bu,
# MAGIC   a.sales_subregion_level_1 AS bu_1,
# MAGIC   a.sales_subregion_level_2 AS bu_2,
# MAGIC   a.sales_subregion_level_3 AS bu_3,  
# MAGIC   a.sa_manager,
# MAGIC   a.account_executive AS account_executive,
# MAGIC   a.sales_manager as ae_manager,
# MAGIC   ci.*
# MAGIC FROM
# MAGIC   _vw_campaign_impact AS ci
# MAGIC LEFT JOIN 
# MAGIC   main.gtm_data.core_accounts_curated AS a
# MAGIC ON 
# MAGIC   ci.account_id = a.account_id
# MAGIC WHERE 
# MAGIC   ci.start_date <= (SELECT MAX(start_date) FROM _vw_campaign_impact WHERE 1_wk_post_wau_human IS NOT NULL);
# MAGIC
# MAGIC ALTER TABLE main.field_learning_enablement.fact_campaign_impact
# MAGIC CLUSTER BY (end_date);
# MAGIC
# MAGIC OPTIMIZE main.field_learning_enablement.fact_campaign_impact;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Manual campaign checking

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   * 
# MAGIC FROM 
# MAGIC   main.metric_store.fct_user_kpis_per_customer
# MAGIC WHERE
# MAGIC   customer_id = '0016100001Xna30AAB'  	