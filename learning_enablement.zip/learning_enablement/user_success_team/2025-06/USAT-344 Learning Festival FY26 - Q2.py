# Databricks notebook source
# MAGIC %md
# MAGIC **Courses taken by self-paced learners**
# MAGIC
# MAGIC Request received from Suna [USAT-344 Learning Festival FY26 - Q2](https://databricks.atlassian.net/browse/USAT-344)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Learning Festival Q2 FY26
# MAGIC ###### References
# MAGIC - [Q2 FY26 VLF One-Slider [FINAL]](https://docs.google.com/presentation/d/1nZSp4n921GQ4Ad45sSdWOyq2idiBVutrhOt4f-fAInM/edit?usp=sharing)
# MAGIC - [DAIS 2025 Virtual Learning Festival: 11 June - 02 July 2025](https://community.databricks.com/t5/events/dais-2025-virtual-learning-festival-11-june-02-july-2025/ec-p/119323#M3413)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Consolidate Campaigns

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC date(to_utc_timestamp('2025-01-15T00:00:00+14:00', 'UTC')) as start_date_utc,
# MAGIC date(to_utc_timestamp('2025-02-01T00:00:00-12:00', 'UTC')) as end_date_utc

# COMMAND ----------

lf_modules = [
  [        
      'DEWD', 'Modules', [ ## LEARNING PATHWAY 1: ASSOCIATE DATA ENGINEERING
        [('2025-01-15T00:00:00UTC+14', '2025-02-01T00:00:00UTC-12'), 'Learning Festival - Q4 FY25'],
        [('2025-04-09T00:00:00UTC+14', '2025-05-01T00:00:00UTC-12'), 'Learning Festival - Q1 FY26'], 
        [('2025-06-11T00:00:00UTC+14', '2025-07-02T00:00:00UTC-12'), 'Learning Festival - Q2 FY26']
      ],
      (
        2963, ## Data Ingestion
        1365, ## Workloads
        2971, ## Data Pipelines
        3144  ## Governance with UC
      )
  ],
  [        
      'MLWD', 'Modules', [ ## LEARNING PATHWAY 4: ASSOCIATE ML PRACTITIONERS
        [('2025-01-15T00:00:00UTC+14', '2025-02-01T00:00:00UTC-12'), 'Learning Festival - Q4 FY25'],
        [('2025-04-09T00:00:00UTC+14', '2025-05-01T00:00:00UTC-12'), 'Learning Festival - Q1 FY26'], 
        [('2025-06-11T00:00:00UTC+14', '2025-07-02T00:00:00UTC-12'), 'Learning Festival - Q2 FY26']
      ],
      (
        2343, ## Data Prep for ML
        2390, ## ML Model Dev
        2395, ## ML Model Dep
        2400  ## ML Ops
      )
  ],
  [        
      'GENAI', 'Modules', [ ## LEARNING PATHWAY 6:  GENERATIVE AI ENGINEERING
        [('2025-01-15T00:00:00UTC+14', '2025-02-01T00:00:00UTC-12'), 'Learning Festival - Q4 FY25'],
        [('2025-04-09T00:00:00UTC+14', '2025-05-01T00:00:00UTC-12'), 'Learning Festival - Q1 FY26'], 
        [('2025-06-11T00:00:00UTC+14', '2025-07-02T00:00:00UTC-12'), 'Learning Festival - Q2 FY26']
      ],
      (
        2706, ## Gen AI Solution Development
        2716, ## Gen AI Application Developmment
        2717, ## Gen AI Application Evaluation & Governance
        2713  ## Gen AI Application Deployment & Monitoring
      )
  ],
  [        
      'MLIP', 'Modules', [ ## LEARNING PATHWAY 5: PROFESSIONAL ML PRACTITIONERS (Asking Jim for Q4 FY25)
        [('2025-01-15T00:00:00UTC+14', '2025-02-01T00:00:00UTC-12'), 'Learning Festival - Q4 FY25'],
        [('2025-04-09T00:00:00UTC+14', '2025-05-01T00:00:00UTC-12'), 'Learning Festival - Q1 FY26'], 
        [('2025-06-11T00:00:00UTC+14', '2025-07-02T00:00:00UTC-12'), 'Learning Festival - Q2 FY26']
      ],
      (
        3417, ## ML At Scale
        3508  ## Advanced MLOPs
      )
  ],
  [        
      'ADEWD', 'Modules', [ ## LEARNING PATHWAY 2: PROFESSIONAL DATA ENGINEERING        
        [('2025-04-09T00:00:00UTC+14', '2025-05-01T00:00:00UTC-12'), 'Learning Festival - Q1 FY26'], 
        [('2025-06-11T00:00:00UTC+14', '2025-07-02T00:00:00UTC-12'), 'Learning Festival - Q2 FY26']
      ],
      (
        2972, ## Streaming and DLT
        3767, ## Data Privacy
        2967, ## Perf Optimization  
        3489  ## Automated Deployment with DABs
      )
  ],
  [        
      'DAWD', 'Modules', [ ## LEARNING PATHWAY 3: DATA ANALYSTS
        [('2025-06-11T00:00:00UTC+14', '2025-07-02T00:00:00UTC-12'), 'Learning Festival - Q2 FY26']
      ],
      (
        3707, ## AI/BI for Data Analysts
        3928  ## SQL Analytics on Databricks
      )
  ],
  [        
      'DAWD', 'Full Course', [
        [('2025-01-15T00:00:00UTC+14', '2025-02-01T00:00:00UTC-12'), 'Learning Festival - Q4 FY25'],
        [('2025-04-09T00:00:00UTC+14', '2025-05-01T00:00:00UTC-12'), 'Learning Festival - Q1 FY26'],
      ],
      (
        1266, ## DEWD
        2268, ## ADEWD
        2307, ## DAWD
        2906, ## DAWD 2024
        2417, ## MLWD
        1522, ## MLIP
        2267, ## GAIEWD23
        2726  ## GAIWD24
      )
  ]
]

# COMMAND ----------

def get_campaigns_completions(modules):    
  if modules[1] == "Full Course":
    query_case = " ".join([f"WHEN completed_timestamp BETWEEN '{dates[0][0]}' AND '{dates[0][1]}' THEN '{dates[1]}'" for dates in modules[2]])
    query_start_date = " ".join([f"WHEN completed_timestamp BETWEEN '{dates[0][0]}' AND '{dates[0][1]}' THEN '{dates[0][0]}'" for dates in modules[2]])
    
    

    query= f"""
      select
      CASE {query_case} END AS session_name,
      CASE {query_start_date} END AS start_date,
      DATEDIFF(completed_timestamp, start_date) as event_day,
      updated_account_id AS account_id,
      updated_account_name AS account_name,
      learner_user_id,    
      '{modules[1]}' as modality,
      case
        when course_id = 1266 and attended_flag = 1 then 'DEWD' 
        when course_id = 2268 and attended_flag = 1 then 'ADEWD'
        when course_id IN (2307, 2906) and attended_flag = 1 then 'DAWD'
        when course_id  = 2417 and attended_flag = 1 then 'MLWD'
        when course_id = 1522 and attended_flag = 1 then 'MLIP'
        when course_id IN (2267, 2726) and attended_flag = 1 then 'GENAI' 
      end as course_completed,
      completed_date
      from main.field_learning_enablement.all_enrollments
      where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
      and all_enrollments.learner_branch_code not in ('DBK_EMP') -- Exclude internal employee enrollments
      and course_id in {modules[3]}
      and attended_flag = 1        
      """
    query_dates = "OR ".join([f"completed_timestamp BETWEEN '{dates[0][0]}' AND '{dates[0][1]}'" for dates in modules[2]])  
  else:    
    query_case = " ".join(["WHEN " + (f"date(max(completed_timestamp)) BETWEEN DATE(to_utc_timestamp('{dates[0][0]}', 'UTC')) AND DATE(to_utc_timestamp('{dates[0][1]}', 'UTC'))" if dates[1]=="Learning Festival - Q4 FY25" else f"max(completed_timestamp) BETWEEN '{dates[0][0]}' AND '{dates[0][1]}'" ) + f" THEN '{dates[1]}'" for dates in modules[2]])
    
    query_start_date = " ".join(["WHEN " + (f"date(max(completed_timestamp)) BETWEEN to_utc_timestamp('{dates[0][0]}', 'UTC') AND to_utc_timestamp('{dates[0][1]}', 'UTC')" if dates[1]=="Learning Festival - Q4 FY25" else f"max(completed_timestamp) BETWEEN '{dates[0][0]}' AND '{dates[0][1]}'" ) + f" THEN '{dates[0][0]}'" for dates in modules[2]])

    query= f"""
      SELECT 
      CASE {query_case} END AS session_name,
      CASE {query_start_date} END AS start_date,
      DATEDIFF(date(max(completed_timestamp)), start_date) as event_day,
      updated_account_id AS account_id,
      updated_account_name AS account_name,
      learner_user_id,    
      '{modules[1]}' as modality,
      case when sum(attended_flag)= {len(modules[3])} then '{modules[0]}' else null end as course_completed,
      date(max(completed_timestamp)) as course_completed_date
      from main.field_learning_enablement.all_enrollments 
      where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
      and course_id in {modules[3]}
      and all_enrollments.learner_branch_code != 'DBK_EMP'
      group by all
      having sum(attended_flag) = {len(modules[3])}"""
    query_dates = "OR ".join([(f"date(max(completed_timestamp)) BETWEEN DATE(to_utc_timestamp('{dates[0][0]}', 'UTC')) AND DATE(to_utc_timestamp('{dates[0][1]}', 'UTC'))" if dates[1]=="Learning Festival - Q4 FY25" else f"max(completed_timestamp) BETWEEN '{dates[0][0]}' AND '{dates[0][1]}'") for dates in modules[2]])  

  query = f"{query} AND ({query_dates})"
  query = spark.sql(query)

  return query

# COMMAND ----------

modules = None
for module in lf_modules:    
  # print(get_campaigns_completions(module))
  if modules is None:
    modules = get_campaigns_completions(module)
  else:
    modules = modules.union(get_campaigns_completions(module))

# COMMAND ----------

from pyspark.sql import Window
from pyspark.sql.functions import count

x = modules.groupBy("session_name", "start_date", "event_day", "course_completed").agg(f.count("course_completed_date").alias("completions")).orderBy("start_date")
x = x.withColumn("cumulative_completions", f.sum("completions").over(Window.partitionBy("session_name").orderBy("event_day")))

display(x)

# COMMAND ----------

def get_campaigns_net_new_learners(modules):    
  query_case = " ".join([f"WHEN completed_timestamp BETWEEN '{dates[0][0]}' AND '{dates[0][1]}' THEN '{dates[1]}'" for dates in modules[2]])
  query_start_date = " ".join([f"WHEN completed_timestamp BETWEEN '{dates[0][0]}' AND '{dates[0][1]}' THEN '{dates[0][0]}'" for dates in modules[2]])
  
  query= f"""
    with nnl as(
      select learner_user_id, course_code
      from main.field_learning_enablement.all_learners
      where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
      and dataset = 'net new learners')
    select
    CASE {query_case} END AS session_name,
    CASE {query_start_date} END AS start_date,
    DATEDIFF(completed_timestamp, start_date) as event_day,
    updated_account_id AS account_id,
    updated_account_name AS account_name,
    ae.learner_user_id,    
    '{modules[1]}' as modality,
    case 
        when ae.course_id in (1266, 2963, 1365, 2971, 3144) then 'DEWD'
        when ae.course_id = 2268 then 'ADEWD'
        when ae.course_id in (2307, 2906) then 'DAWD'
        when ae.course_id in (2417, 2343, 2390, 2395, 2400) then 'MLWD'
        when ae.course_id IN(1522, 3417, 3508) then 'MLIP'
        when ae.course_id in (2267, 2726, 2706,2716,2717,2713) then 'GENAI'        
    end as course_completed,
    completed_date
    from main.field_learning_enablement.all_enrollments ae
    join nnl on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
    where processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
    and ae.learner_branch_code not in ('DBK_EMP') -- Exclude internal employee enrollments
    and course_id in {modules[3]}
    and attended_flag = 1        
    """
  query_dates = "OR ".join([f"completed_timestamp BETWEEN '{dates[0][0]}' AND '{dates[0][1]}'" for dates in modules[2]])    

  query = f"{query} AND ({query_dates})"
  query = spark.sql(query)

  return query

# COMMAND ----------

from pyspark.sql import Window
from pyspark.sql.functions import count

modules = None
for module in lf_modules:    
  # print(get_campaigns_net_new_learners(module))
  if modules is None:
    modules = get_campaigns_net_new_learners(module)
  else:
    modules = modules.union(get_campaigns_net_new_learners(module))

x = modules.groupBy("session_name", "event_day", "course_completed").agg(f.count("completed_date").alias("net_new_learners")).orderBy("event_day")
x = x.withColumn("cumulative_net_new_learners", f.sum("net_new_learners").over(Window.partitionBy("session_name").orderBy("event_day")))

display(x)

# COMMAND ----------

# MAGIC %sql
# MAGIC with nnl as(
# MAGIC     select learner_user_id, course_code, completed_date
# MAGIC     from main.field_learning_enablement.all_learners
# MAGIC     where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
# MAGIC     and dataset = 'net new learners'
# MAGIC )
# MAGIC
# MAGIC -- Learning Festival
# MAGIC select 
# MAGIC ae.learner_user_id, 
# MAGIC ae.updated_account_id,
# MAGIC ae.updated_account_name , 
# MAGIC ae.course_id, 
# MAGIC ae.course_code, 
# MAGIC case 
# MAGIC     when ae.course_id in (1266, 2963, 1365, 2971, 3144) then 'DEWD'
# MAGIC     when ae.course_id = 2268 then 'ADEWD'
# MAGIC     when ae.course_id in (2307, 2906) then 'DAWD'
# MAGIC     when ae.course_id in (2417, 2343, 2390, 2395, 2400) then 'MLWD'
# MAGIC     when ae.course_id IN(1522, 3417, 3508) then 'MLIP'
# MAGIC     when ae.course_id in (2267, 2726, 2706,2716,2717,2713) then 'GENAI'
# MAGIC end as course_completed,
# MAGIC ae.enrolled_date, 
# MAGIC ae.completed_date, 
# MAGIC ae.attended_flag, 
# MAGIC ae.completed_fq2, 
# MAGIC nnl.completed_date as learner_date, 
# MAGIC 'Learning Festival' as course_type, 
# MAGIC ae.business_unit, 
# MAGIC IFNULL(ae.sales_subregion_level_1,'Unknown'), 
# MAGIC IFNULL(ae.sales_subregion_level_2,'Unknown'),
# MAGIC IFNULL(ae.sales_subregion_level_3,'Unknown'), 
# MAGIC case when business_unit != 'Unknown' then business_unit else region_derived end as kathryn_region
# MAGIC from main.field_learning_enablement.all_enrollments ae
# MAGIC join nnl
# MAGIC on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
# MAGIC and ae.course_id in (
# MAGIC     -- Full Courses
# MAGIC     1266, -- DEWD
# MAGIC     2268, -- ADEWD
# MAGIC     2307, -- DAWD
# MAGIC     2906, -- DAWD 2024
# MAGIC     2417, -- MLWD
# MAGIC     1522, -- MLIP
# MAGIC     2267, -- GAIEWD 2023
# MAGIC     2726, -- GAIEWD 2024
# MAGIC     -- DE Modules
# MAGIC     2963, -- Data Ingestion
# MAGIC     1365, -- Workloads
# MAGIC     2971, -- DLT
# MAGIC     3144, -- Governance
# MAGIC     -- MLWD Modules
# MAGIC     2343, -- Data Prep
# MAGIC     2390, -- ML Model Dev
# MAGIC     2395, -- ML Model Dep
# MAGIC     2400, --ML Ops
# MAGIC     -- Gen AI
# MAGIC     2706, -- Gen AI Solution Dev
# MAGIC     2716, -- Gen AI App Dev
# MAGIC     2717, -- Gen AI App Eval
# MAGIC     2713, -- Gen AI App Deployment
# MAGIC     -- AMLWD Modules
# MAGIC     3417, -- ML at Scale
# MAGIC     3508 -- Advanced MLOPs
# MAGIC )
# MAGIC and ae.completed_timestamp between '2025-01-15T00:00:00UTC+14' and '2025-02-01T00:00:00UTC-12'; -- Q4 FY25
# MAGIC
# MAGIC -- SELECT * FROM _learning_festival_net_new_learners_Q4_FY25;