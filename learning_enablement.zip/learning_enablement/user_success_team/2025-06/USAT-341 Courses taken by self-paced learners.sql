-- Databricks notebook source
-- MAGIC %md
-- MAGIC **Courses taken by self-paced learners**
-- MAGIC
-- MAGIC Request received from Suna [USAT-341 Courses taken by self-paced learners](https://databricks.atlassian.net/browse/USAT-341)

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _ue_programs
AS
with nnl as(
  select learner_user_id, course_code, completed_date
  from main.field_learning_enablement.all_learners
  where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
  and dataset = 'net new learners')

SELECT 
  course_type,
  course_code,
  course_id,
  course_name,
  session_name,
  -- session_date AS start_date,
  -- session_date AS end_date,  
  date_trunc('month', session_date) AS session_date_month,
  -- CASE WHEN COUNT(DISTINCT session_name) > 1 THEN 'Multiple sessions' ELSE concat_ws(', ', collect_set(session_name)) END AS session_name,  
  -- concat_ws(', ', collect_set(session_name)) AS session_name,
  min(session_date) AS start_date,
  max(session_date) AS end_date,

  account_id,
  account_name,  
  COUNT(completed_date) AS completions,
  COUNT(learner_date) AS net_new_learners
FROM(
  -- AI/BI Campaign / Onboarding & HDC ILT / private workshops / Get Started Days
  SELECT
    course_id,
    learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2,
    CASE
      -- AI/BI Campaign
      WHEN a.project_type = 'AI/BI Training Program' AND a.status not ilike 'cancel%' THEN 'AI/BI Campaign' 
      -- Get Started Days
      WHEN a.course_id = 3125 THEN 'Get Started Days'
      -- Onboarding & HDC ILT
      WHEN a.training_type = 'Public' AND a.course_type IN ('Half-Day', 'Onboarding') THEN a.course_type
      -- private workshops
      WHEN a.training_type = 'Private' and provider = 'User Enablement' THEN 'Workshop'
    END AS course_type,    
    CASE
      WHEN a.course_id = 3125 THEN concat('Databricks Get Started Day | ', date_format(a.session_date, 'MMM dd yyyy'), ' | ', a.session_region)
      ELSE TRIM(SPLIT_PART(a.session_name, '|', 3)) END AS session_name,
    cast(substr(a.session_date, 1, 10) as date) AS session_date,
    a.updated_account_id AS account_id,
    a.updated_account_name AS account_name    
  FROM 
    main.team_field_user_enablement.vw_ue_enrolments_ilt AS a
  WHERE 
    session_date >= '2024-02-01'  
    AND(
      (a.training_type = 'Public' AND a.course_type IN ('Half-Day', 'Onboarding'))
      OR(a.training_type = 'Private' and provider = 'User Enablement')
      OR(a.course_id = 3125)      
    )
  union
  
  -- self-paced onboarding
  SELECT 
    course_id,
    learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2,
    'Self-Paced' as course_type,
    'Self-Paced' AS session_name,
    MAX(completed_date)OVER(PARTITION BY account_id, date_trunc('MM', completed_date)) AS session_date,
    account_id,
    account_name
  FROM main.team_field_user_enablement.vw_ue_enrolments_sp a
  where completed_date >= '2024-02-01'  
  union

  -- Summit / World Tour
  select
    course_id,
    ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2,
    'DAIS' as course_type,
    'DAIS' AS session_name,
    '2024-06-13' AS session_date,
    ae.updated_account_id AS account_id,
    ae.updated_account_name AS account_name  
  from main.field_learning_enablement.all_enrollments ae
  left join nnl
  on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
  where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
  and ae.course_name like '%DAIS 2024%'
  and ae.completed_date >= '2024-02-01'
  union

  -- DAIWT
  select 
    course_id,
    ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2,
    'DAIWT' as course_type,
    'DAIWT' AS session_name,
    MAX(ae.completed_date)OVER(PARTITION BY updated_account_id, date_trunc('MM', ae.completed_date)) AS session_date,
    ae.updated_account_id AS account_id,
    ae.updated_account_name AS account_name
  from main.field_learning_enablement.all_enrollments ae
  left join nnl
  on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
  where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
  and ae.course_name like '%DAIWT 2024%'
  and ae.completed_date >= '2024-02-01'
  union

  -- Databricks Academy Labs
  select 
    course_id,
    ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2,
    'Academy Labs' as course_type,
    'Academy Labs' AS session_name,
    MAX(ae.completed_date)OVER(PARTITION BY updated_account_id, date_trunc('MM', ae.completed_date)) AS session_date,
    ae.updated_account_id AS account_id,
    ae.updated_account_name AS account_name
  from main.field_learning_enablement.all_enrollments ae
  left join nnl
  on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
  where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
  and ae.completed_date >= '2024-02-01'
  and ae.course_code IN (
      select distinct course_code from main.it_training_silver.docebo_subscription_enrollments
      where processDate = (select max(processDate) from main.it_training_silver.docebo_subscription_enrollments)
      and subscription_plan_code = 'DB-ACAD-LABS-SUB-PLAN'
  )
  union

  -- EMEA Bootcamps
  select
    course_id,
    ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2,
    'EMEA Bootcamps' as course_type,
    'EMEA Bootcamps' AS session_name,
    MAX(ae.completed_date)OVER(PARTITION BY updated_account_id, date_trunc('MM', ae.completed_date)) AS session_date,
    ae.updated_account_id AS account_id,
    ae.updated_account_name AS account_name
  from main.field_learning_enablement.all_enrollments ae
  left join nnl
  on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
  where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
    and ae.course_id IN(
      3544,
      -- Fundamentals
      3793,
      -- Generative AI
      3930 -- Data Warehousing
    )

) AS X
GROUP BY ALL;

SELECT 
  DISTINCT course_type, session_name, course_id, course_code, course_name  
FROM 
  _ue_programs 
WHERE 
  course_name IN(SELECT DISTINCT course_name FROM _ue_programs WHERE course_type = 'Self-Paced')