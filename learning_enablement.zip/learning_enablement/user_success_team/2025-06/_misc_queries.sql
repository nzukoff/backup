-- Databricks notebook source
select distinct
  -- ae.learner_user_id, 
  ae.course_code, ae.course_name--,
  -- ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2,
  -- 'DAIS' as course_type,
  -- 'DAIS' AS session_name,
  -- '2024-06-13' AS session_date,
  -- ae.updated_account_id AS account_id,
  -- ae.updated_account_name AS account_name  
from main.field_learning_enablement.all_enrollments ae
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.course_name like '%DAIS%'
and ae.completed_date >= '2024-02-01'

-- COMMAND ----------

SELECT
  * 
FROM 
  field_sts_metrics.silver_shared_stsasq 
WHERE 
  support_type = 'Launch Accelerator';

-- COMMAND ----------

SELECT 
  updated_account_id,
  updated_account_name,
  course_id,
  course_name,
  enrolled_date,
  completed_date,
  learner_user_id,
  learner_email
FROM 
  main.field_learning_enablement.all_enrollments
WHERE
  processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.all_enrollments)
  and learner_email = 'joel.ramirez@databricks.com'

-- COMMAND ----------

select * from main.fin_live_gold.sfdc_hierarchy_mapping where email='manfred.carvajalmurillo@databricks.com'


-- COMMAND ----------

SELECT DISTINCT 
  T1.OwnerId, 
  T1.Owner_Email__c,
  T2.Name,  
  T1.Last_SA_Engaged__c,
  T3.Email,
  T3.Name
FROM 
  main.sfdc_bronze.account AS T1
INNER JOIN
  main.sfdc_bronze.user AS T2
ON T1.OwnerId = T2.Id
INNER JOIN
  main.sfdc_bronze.user AS T3
ON T1.Last_SA_Engaged__c = T3.Id
WHERE   
  T2.Name = 'Manfred Carvajal Murillo'
  AND T1.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.account)


-- COMMAND ----------

SELECT DISTINCT
  c.account_executive_user_id,
  c.account_executive, 
  u1.Email AS account_executive_email,
  c.last_solution_architect_engaged_user_id,
  c.last_solution_architect_engaged,  
  u2.Email AS last_solution_architect_engaged_email
FROM
  main.gtm_data.core_accounts_curated c
LEFT JOIN
  main.sfdc_bronze.user u1
ON c.account_executive_user_id = u1.Id
LEFT JOIN
  main.sfdc_bronze.user u2
ON c.last_solution_architect_engaged_user_id = u2.Id
WHERE
  c.account_executive = 'Manfred Carvajal Murillo'