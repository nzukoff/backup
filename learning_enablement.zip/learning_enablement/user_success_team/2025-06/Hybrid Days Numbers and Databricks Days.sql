-- Databricks notebook source
-- MAGIC %md
-- MAGIC **Hybrid Days Numbers and Databricks Days**
-- MAGIC
-- MAGIC Request received from Nadia to validate the numbers shown on the following slide [Self-paced enablement Deck](https://docs.google.com/presentation/d/1nSrDHFssy_eNHs-On8jzz1qqw8ananseeZyiJuXvz3g/edit?slide=id.g3584663e23d_0_0#slide=id.g3584663e23d_0_0)
-- MAGIC
-- MAGIC She confirmed the numbers for Hybrid Days are from the following dashboard [DW U6/5 MAU Growth AI/BI Campaign](https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01ef8b1cf03614f18ca191ab4aac0bf4/published/pages/2bdfe352?o=2548836972759138)
-- MAGIC
-- MAGIC The numbers shown for the Databricks Days were pulled by Jim [Databricks Day Planning Guide](https://docs.google.com/document/d/1038MJB6-1RgzOHSP4__NF1iYBhERhyI8Yq1pqoWABFw/edit?tab=t.0)
-- MAGIC
-- MAGIC It is needed to confirm the query and source to identify the events related those days

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Hybrid Days

-- COMMAND ----------

WITH
_nnl as( -- Net New Learners
  SELECT 
    learner_user_id, 
    course_code, 
    completed_date
  FROM 
    main.field_learning_enablement.all_learners
  WHERE 
    processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    AND dataset = 'net new learners'
)
SELECT
  ae.processDate,
  u.program,
  STRING(u.id_coupon) AS id_coupon,  
  u.airtable_account_name AS session_name,
  u.event_date AS session_date,
  ae.updated_account_id AS account_id,
  ae.enrolled_date,
  ae.completed_date, 
  _nnl.learner_user_id
FROM
  main.team_field_user_enablement.vw_coupon_usage u
LEFT JOIN
  main.it_training_silver.docebo_subscription_enrollments e
ON
  e.transaction_id = u.subscription_trans_id
  AND e.learner_user_id = u.userID
  AND e.processDate = (SELECT max(processDate) FROM main.it_training_silver.docebo_subscription_enrollments)
LEFT JOIN
  main.field_learning_enablement.all_enrollments ae
ON
  ae.course_id = e.course_id
  AND ae.learner_user_id = e.learner_user_id
  AND ae.enrolled_date between u.subStartDAre and u.SubEndDate
  AND ae.processDate = (SELECT max(processDate) FROM main.field_learning_enablement.all_enrollments)
LEFT JOIN
  _nnl 
ON 
  ae.learner_user_id = _nnl.learner_user_id
  AND ae.course_code = _nnl.course_code         
WHERE
  u.program = 'Hybrid Days' 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Databricks Days

-- COMMAND ----------

SELECT DISTINCT project_type FROM main.field_learning_enablement.training_operations_ilt_schedule_master

-- COMMAND ----------

-- WIP
SELECT DISTINCT u.program--, * 
FROM main.team_field_user_enablement.vw_coupon_usage u