-- Databricks notebook source
SELECT 
    customer_id,
    account_name, 
    bu, 
    bu_1, 
    bu_2, 
    bu_3,
    sa_manager,
    account_executive,
    ae_manager,
    tagging,
    SUM(mau) AS mau,
    SUM(mau_human) AS mau_human,
    SUM(wau) AS wau,
    SUM(wau_human) AS wau_human
  FROM 
    main.field_learning_enablement.silver_monthly_mau AS T1
  WHERE
    T1.month = (SELECT MAX(month) FROM main.field_learning_enablement.silver_monthly_mau)
  GROUP BY ALL

-- COMMAND ----------

SELECT 
  MAX(date)
FROM 
    main.data_product_features.customer_metrics c
LIMIT 10

-- COMMAND ----------

SELECT DISTINCT
  account_status
FROM
  main.gtm_data.core_accounts_curated

-- COMMAND ----------

SELECT 
    date_trunc('month',date)::date as month,
    account_status,
    sum(dbsql_num_users_t28d) as SQL,
    sum(unity_catalog_num_users_t28d) as UC,
    sum(lakeview_num_users_t28d) as Lakeview,
    sum(ds_ml_num_users_t28d) as DSML,
    sum(etl_num_users_t28d) as ETL,
    sum(delta_num_users_t28d) as Delta
FROM 
    main.data_product_features.customer_metrics c
LEFT JOIN 
    main.gtm_data.core_accounts_curated as a 
ON 
    c.customer_id = a.account_id 
WHERE 
    date BETWEEN DATE_TRUNC('month', ADD_MONTHS(CURRENT_DATE(), -12)) AND DATE_ADD(DATE_TRUNC('month', CURRENT_DATE()), -1)
    AND DAYOFMONTH(date) = 28 
    --AND account_status != 'Prospect'
GROUP BY ALL
ORDER BY 1

-- COMMAND ----------

SELECT
  T1.account_executive
  , T1.sales_manager
  , T2.AE
  , T2.AE_Manager
  , T2.accountId
FROM 
  main.gtm_data.core_accounts_curated T1
LEFT JOIN 
  main.field_usage_dashboard.global_data T2
ON
  T1.account_id = T2.accountId
WHERE T1.sales_manager <> T2.AE_Manager

-- COMMAND ----------

select 
  a.Id as account_id,
  a.Name as account_name,
  u.Name as xdr_name
from main.sfdc_bronze.account a
join main.sfdc_bronze.user u
on a.AccountLevelXDROverride__c = u.Id and u.processDate = (select max(processDate) from main.sfdc_bronze.user)
where a.processDate = (select max(processDate) from main.sfdc_bronze.account)

-- COMMAND ----------

SELECT 
  a.business_unit AS bu
  , a.sales_subregion_level_1 AS bu_1
  , a.sales_subregion_level_2 AS bu_2
  , a.sales_subregion_level_3 AS bu_3
  , a.account_name AS account_name
  , a.sa_manager
  , a.account_executive AS account_executive
  , a.sales_manager as ae_manager  
FROM
  main.gtm_data.core_accounts_curated a