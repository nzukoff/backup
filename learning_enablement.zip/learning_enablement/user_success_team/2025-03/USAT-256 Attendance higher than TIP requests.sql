-- Databricks notebook source
-- MAGIC %md
-- MAGIC ### Request to identify the reason of attendance higher than requests
-- MAGIC **Attendance higher than TIP requests**: 
-- MAGIC
-- MAGIC How is attendance higher than TIP requests? Is this due to how we are aggregating it?
-- MAGIC
-- MAGIC this is what Zach is reporting based on the dashboard https://docs.google.com/spreadsheets/d/1BrQDiIGdbiOwHT0EcY7jEY71rkuVx2-6/edit?gid=648787532#gid=648787532 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 1. Exploration

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1.1. Identify source of the discrepancy

-- COMMAND ----------

/*

The TIP requests refer to the number of requests for coupons.
@Suna Leloglu (FE Enablement) will confirm if the TIP requests should be changed to use one of the following alternatives:

- Number of requests for coupons
- Number of coupons requested

*/

SELECT 
  requested_coupons,
  distributed_coupons,
  not_used_coupons,
  used_coupons,
  attended
FROM 
  main.team_field_user_enablement.vw_coupon_requests
WHERE
  request_number = '2924'  

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Request to include the AI/BI Campaign on TIP
-- MAGIC
-- MAGIC Three metrics to include on TIP
-- MAGIC
-- MAGIC TIP 
-- MAGIC - Count of unique accounts that made a TIP request. This will be included when we are summarizing. Metric to include on the request to create a summary view.
-- MAGIC
-- MAGIC
-- MAGIC TIP Requests
-- MAGIC - Sum of coupons requested on by TIP Request. vw_coupon_requests[requested_coupons]. The table also contains the [approved_coupons] and [distributed_coupons].
-- MAGIC
-- MAGIC TIP Attended
-- MAGIC - Sum of total of attended by TIP request + Sum of total of attended by AI/BI Campaign ILT Program session
-- MAGIC - Attended by TIP request = vw_coupon_requests[attended]
-- MAGIC - Attended by AI/BI Campaign = main.field_learning_enablement.fact_campaign_analysis[event_attendees]

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1.1. Explore the Requests numbers

-- COMMAND ----------

SELECT
      cu.program,
      --v.id,
      cu.request_number,
      --v.request_type, v.account_name,
      --v.coupon_start_date, v.coupon_end_date,
      --cast (v.coupons as bigint) as coupons,
      --count(1) as matched_count,
      cast(
        sum(
          case
            when cu.userId is not null then 1
            else 0
          end
        ) as bigint
      ) as used_coupons,
      cast(ifnull(sum(cu.attended_flag), 0) as bigint) as attended,
      cast(
        sum(
          case
            when cu.expiration_status = 'Expired' then 1
            else 0
          end
        ) as bigint
      ) as expired,
      cast(
        sum(
          case
            when cu.expiration_status = 'Not Expired' then 1
            else 0
          end
        ) as bigint
      ) as not_expired,
      cu.*
    from
      main.team_field_user_enablement.vw_coupon_usage cu
    where
      cu.program like 'Training Investment%' --and v.id is not null
      AND account_id = '0016100000cF3AMAA0'
    group by ALL 


-- COMMAND ----------

-- peter.lane@ama-assn.org
SELECT
  all_enrollments.account_id,
  all_enrollments.updated_account_id,
  *
FROM main.field_learning_enablement.all_enrollments
WHERE
  processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.all_enrollments)
  -- -- AND all_enrollments.updated_account_id = '0016100000cF3AMAA0'    
  -- AND all_enrollments.course_code = 'ACAD-CUST-ILTPUB-PAID-DIWDL-v2'
  -- AND all_enrollments.learner_email = 'brent.roth@ama-assn.org'
  AND (course_code, learner_email)
    IN(
      SELECT course_code, username
      FROM main.team_field_user_enablement.vw_coupon_usage cu
      WHERE cu.program like 'Training Investment%' AND account_id = '0016100000cF3AMAA0'    
    )  

-- COMMAND ----------

  SELECT 
    account_id AS account_id_tip, 
    MAX(created_date) AS lastest_tip_requested_date, 
    COUNT(DISTINCT request_number) AS tip_num_requests, 
    sum(requested_coupons) AS tip_requested_coupons, 
    sum(used_coupons) AS tip_used_coupons, 
    SUM(attended) AS tip_attended
  FROM 
    main.team_field_user_enablement.vw_coupon_requests
  WHERE 
    status not in ('Cancelled','Rejected')
  GROUP BY ALL

-- COMMAND ----------

  SELECT
    T1.account_id,
    SUM(T1.event_registrations) AS event_registrations,
    SUM(T1.event_attendees) AS event_attendees
  FROM 
    main.field_learning_enablement.fact_campaign_analysis AS T1
  WHERE
    T1.program = 'ILT' -- Filtering by AI/BI Campaign Analysis
  GROUP BY ALL

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1.2. Confirmation that 1k AI/BI Training Program is not included on the TIP coupon numbers

-- COMMAND ----------

SELECT course_code, username, session_id, session_code
FROM main.team_field_user_enablement.vw_coupon_usage cu
WHERE cu.program like 'Training Investment%' 
AND session_code
IN(
  SELECT academy_session_number AS session_code
  FROM main.field_learning_enablement.training_operations_ilt_schedule_master
  WHERE processDate = (SELECT max(processDate) FROM main.field_learning_enablement.training_operations_ilt_schedule_master)
    AND (training_operations_ilt_schedule_master.project_type = '1k AI/BI Training Program' AND status not ilike 'cancel%')
)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1.3. Merging AI/BI Program and TIP

-- COMMAND ----------

  SELECT 
    account_id AS account_id_tip, 
    MAX(created_date) AS lastest_tip_requested_date, 
    COUNT(DISTINCT request_number) AS tip_num_requests, 
    sum(requested_coupons) AS tip_requested_coupons, 
    sum(used_coupons) AS tip_used_coupons, 
    SUM(attended) AS tip_attended
  FROM 
    main.team_field_user_enablement.vw_coupon_requests
  WHERE 
    status not in ('Cancelled','Rejected')
  GROUP BY ALL

-- COMMAND ----------

  SELECT 
    account_id AS account_id_tip, 
    MAX(created_date) AS lastest_tip_requested_date, 
    COUNT(DISTINCT request_number) AS tip_num_requests, 
    sum(requested_coupons) AS tip_requested_coupons, 
    sum(used_coupons) AS tip_used_coupons, 
    SUM(attended) AS tip_attended
  FROM 
    main.team_field_user_enablement.vw_coupon_requests
  WHERE 
    status not in ('Cancelled','Rejected')
    AND account_id = '0016100001fQSWCAA4'
  GROUP BY ALL

-- COMMAND ----------

WITH _tip_data
AS (
  SELECT 
    account_id AS account_id_tip, 
    MAX(created_date) AS lastest_tip_requested_date, 
    COUNT(DISTINCT request_number) AS tip_num_requests, 
    sum(requested_coupons) AS tip_requested_coupons, 
    sum(used_coupons) AS tip_used_coupons, 
    SUM(attended) AS tip_attended
  FROM 
    main.team_field_user_enablement.vw_coupon_requests
  WHERE 
    status not in ('Cancelled','Rejected')
    -- AND account_id = '0016100001fQSWCAA4'
  GROUP BY ALL
), _enrollment_data
AS(
  SELECT             
    T1.updated_account_id AS account_id,                    
    COUNT(T1.enrolled_date) AS registrations,
    COUNT(T1.completed_date) AS attendees      
  FROM 
      main.field_learning_enablement.all_enrollments AS T1
  WHERE 
    T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)    
    AND (course_code, learner_email)
      IN(
        SELECT course_code, username
        FROM main.team_field_user_enablement.vw_coupon_usage cu
        WHERE cu.program like 'Training Investment%'
      )   
  GROUP BY ALL
)

SELECT 
  t.account_id_tip,
  t.lastest_tip_requested_date,
  t.tip_num_requests,
  t.tip_requested_coupons,
  t.tip_used_coupons,
  t.tip_attended,
  e.registrations,
  e.attendees
FROM 
  _tip_data t
JOIN 
  _enrollment_data e
ON 
  t.account_id_tip = e.account_id



-- COMMAND ----------

SELECT             
  T1.updated_account_id AS account_id,                  
  CAST(T1.ended_timestamp AS DATE) AS session_date,      
  COUNT(T1.enrolled_date) AS registrations,
  COUNT(T1.completed_date) AS attendees      
FROM 
    main.field_learning_enablement.all_enrollments AS T1
INNER JOIN
  main.field_learning_enablement.training_operations_ilt_schedule_master AS T2 
ON
  T1.session_code = T2.academy_session_number
  AND T2.processDate = (SELECT max(processDate) FROM main.field_learning_enablement.training_operations_ilt_schedule_master)
  AND T2.project_type = '1k AI/BI Training Program' 
  AND T2.status not ilike 'cancel%'
WHERE 
  T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)
GROUP BY ALL