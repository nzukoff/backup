# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ## Read from google sheets

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Steps:
# MAGIC * create a cell and run %run "/Users/liam.clifford@databricks.com/Liam's Notebook - readGoogleSheet UDF"
# MAGIC * share spreadsheet with service-liam-clifford@project-liam-clifford.iam.gserviceaccount.com as editor
# MAGIC * enter the name of the spreadsheet and the sheet you want to pull data from in the try blocks
# MAGIC * add the workbook id which can be found after /d/ in the sheet url
# MAGIC * for reading from:
# MAGIC   * add the sheet id which can be found in the url after gid=
# MAGIC   * create a temp view name that can be used to query the data from a temp view 
# MAGIC   * specify the cell range you want to pull data from
# MAGIC   * select * from the temp view name to see the data
# MAGIC * for writing to
# MAGIC   * create a dataframe of the data you want to write 
# MAGIC   * create values for the SHEET_NAME and WORKBOOK_ID variables
# MAGIC   * enter the sheet name, workbook id, and dataframe in the refresh_data_in_sheet function
# MAGIC   * specify which row and column to write to

# COMMAND ----------

# MAGIC %run "../../learning-enablement/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

try:
  sht = authGoogleSheet("APJ_Top_100_Accounts_Program")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')
  

try:
  worksheet = sht.worksheet("List of Key Accounts")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')

workbook_id='1oUd0XGJA8Ym76SjaclS-xe4DdfYUq7u7JAtGlZMQhZ0'
sheet_id='1234995319'

read_google_sheet(
  workbook_id=workbook_id,
  sheet_id=sheet_id,
  temp_view_name='apj_top_100_accounts_program',
  cell_range='A1:E134'
)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from apj_top_100_accounts_program

# COMMAND ----------

# data = [
#     ("ANZ", "Atlassian Pty Ltd.", "00161000005eOcaAAE", "$10,536,126", "Top 100"),
#     ("ANZ", "NAB", "0016100000Y5d0pAAB", "$4,821,297", "Top 100"),
#     ("India", "InMobi", "0016100001BM9r2AAD", "$4,014,522", "Top 100"),
#     ("India", "Tata Sons Limited", "0014N00002BBfJwQAL", "$3,163,049", "Top 100"),
#     ("ANZ", "Australian Energy Market Operator", "0016100001G26JQAAZ", "$3,080,945", "Top 100"),
#     ("ANZ", "Sportsbet", "00161000010EmZoAAK", "$2,993,559", "Top 100"),
#     ("Asean + GCR", "AIA Group", "0016100001XnZilAAF", "$2,941,152", "Top 100"),
#     ("India", "Meesho", "0016100001VciauAAB", "$2,898,144", "Top 100"),
#     ("India", "Bajaj Finance Limited", "0016100001cgPP9AAM", "$2,798,387", "Top 100"),
#     ("Asean + GCR", "SCBX", "0018Y000036dh9kQAA", "$2,629,543", "Top 100"),
#     ("Asean + GCR", "Prudential PLC", "0018Y00002vR6I1QAK", "$2,622,244", "Top 100"),
#     ("India", "Boomerang Commerce, Inc. dba CommerceIQ", "0016100001OCDinAAH", "$2,523,674", "Top 100"),
#     ("India", "Dream11", "0016100000agWmcAAE", "$2,469,342", "Top 100"),
#     ("Asean + GCR", "GrabTaxi", "0016100001ar8FoAAI", "$2,378,986", "Top 100"),
#     ("Korea", "KRAFTON", "0013f0000042i6KAAQ", "$2,359,341", "Top 100"),
#     ("Asean + GCR", "Charoen Pokphand Group Co.,Ltd. (CP Group)", "0013f000008orN4AAI", "$2,148,987", "Top 100"),
#     ("India", "Flipkart India", "0016100001F1KuJAAV", "$2,136,362", "Top 100"),
#     ("India", "Freshworks", "0016100001TPJd7AAH", "$1,991,027", "Top 100"),
#     ("ANZ", "QBE Insurance Group", "0016100001SQUNAAA5", "$1,987,856", "Top 100"),
#     ("Japan", "SoftBank Corp.", "0016100001TPLKRAA5", "$1,596,541", "Top 100"),
#     ("ANZ", "Alinta Energy", "0016100001fQSNjAAO", "$1,538,231", "Top 100"),
#     ("Asean + GCR", "Kasikorn Bank", "0016100001XmXE1AAN", "$1,479,998", "Top 100"),
#     ("Asean + GCR", "Singtel", "0016100001G26LGAAZ", "$1,447,150", "Top 100"),
#     ("Asean + GCR", "PETRONAS", "0016100001apFyRAAU", "$1,418,612", "Top 100"),
#     ("Korea", "LG Corporation", "0016100001G26JgAAJ", "$1,260,040", "Top 100"),
#     ("ANZ", "Coles Group", "0016100001ZVVizAAH", "$1,253,282", "Top 100"),
#     ("ANZ", "Optiver APJ", "0014N00002D7djPQAR", "$1,252,777", "Top 100"),
#     ("India", "Zepto", "0013f00000AibADAAZ", "$1,223,837", "Top 100"),
#     ("ANZ", "Victoria Government", "0018Y00002fr86gQAA", "$1,159,362", "Top 100"),
#     ("ANZ", "Singtel Optus Pty Limited", "0016100000Y5F98AAF", "$1,115,224", "Top 100"),
#     ("India", "ICICI Bank", "0016100001XnYlhAAF", "$1,089,514", "Top 100"),
#     ("Japan", "Mitsubishi Corporation", "0013f0000063rqLAAQ", "$1,070,201", "Top 100"),
#     ("India", "HDFC Bank", "0016100001fQSTMAA4", "$1,045,359", "Top 100"),
#     ("Asean + GCR", "Maya Philippines Inc", "0014N00001tNYQPQA4", "$1,040,981", "Top 100"),
#     ("India", "Hotstar", "0016100001WoYiFAAV", "$1,039,513", "Top 100"),
#     ("ANZ", "SEEK", "0016100000UOFaNAAX", "$1,037,185", "Top 100"),
#     ("Korea", "Samsung Group", "0018Y00002lq8JaQAI", "$1,028,608", "Top 100"),
#     ("India", "CRED", "0014N00001tOLgHQAW", "$1,001,955", "Top 100"),
#     ("ANZ", "Telstra", "0016100000Rrk0qAAB", "$993,415", "Top 100"),
#     ("India", "IndusInd Bank", "0013f000004PwhkAAC", "$982,782", "Top 100"),
#     ("ANZ", "Tabcorp", "0016100000B5MlzAAF", "$980,203", "Top 100"),
#     ("India", "Bundl Technologies Pvt Ltd (Swiggy)", "0016100001dRvkEAAS", "$874,059", "Top 100"),
#     ("Japan", "Tokio Marine Holdings", "0016100001QcnSFAAZ", "$840,510", "Top 100"),
#     ("Asean + GCR", "Trend Micro", "0016100000Zcov9AAB", "$836,472", "Top 100"),
#     ("Asean + GCR", "Khazanah Nasional Berhad", "0013f000004THDiAAO", "$806,013", "Top 100"),
#     ("India", "Navi Technologies Limited", "0014N00002D7uBcQAJ", "$783,298", "Top 100"),
#     ("ANZ", "Australian Government", "0013f000002nGKPAA2", "$778,599", "Top 100"),
#     ("India", "Reliance Group", "0018Y00002kwiPrQAI", "$761,675", "Top 100"),
#     ("Korea", "MUSINSA", "0013f000004TBH3AAO", "$749,918", "Top 100"),
#     ("Korea", "HYPERCONNECT", "0013f0000043SbRAAU", "$747,545", "Top 100"),
#     ("Asean + GCR", "Anker Innovations LTD", "0013f00000656HiAAI", "$746,980", "Top 100"),
#     ("Korea", "NEXON Korea Corporation", "0016100000Y4HgUAAV", "$712,502", "Top 100"),
#     ("ANZ", "Rio Tinto", "0016100001dRdepAAC", "$703,467", "Top 100"),
#     ("ANZ", "Suncorp Group", "0016100001Qc3aaAAB", "$699,279", "Top 100"),
#     ("Japan", "Seiyu", "0013f0000064u50AAA", "$699,274", "Top 100"),
#     ("India", "Play Games24x7", "0016100001XmwORAAZ", "$690,817", "Top 100"),
#     ("Asean + GCR", "L'Oréal China", "0013f0000063jbgAAA", "$667,148", "Top 100"),
#     ("ANZ", "Essential Energy", "0016100001G26JoAAJ", "$655,678", "Top 100"),
#     ("India", "Pocket FM", "0013f000009fQhoAAE", "$650,666", "Top 100"),
#     ("Japan", "Rakuten Bank, Ltd.", "0013f00000AiB52AAF", "$650,286", "Top 100"),
#     ("India", "ShareChat", "0014N00001ipPx4QAE", "$645,985", "Top 100"),
#     ("Asean + GCR", "Standard Chartered Bank", "0013f0000044JkNAAU", "$644,153", "Top 100"),
#     ("India", "TVS Motor Company", "0014N00001tQNH2QAO", "$636,744", "Top 100"),
#     ("ANZ", "Virtual Gaming Worlds", "0016100001TNEqpAAH", "$625,585", "Top 100"),
#     ("Asean + GCR", "Mercedes Benz Group China", "0013f0000065MtQAAU", "$620,494", "Top 100"),
#     ("Asean + GCR", "Tigontech Co., Ltd.", "0013f0000064VnYAAU", "$609,040", "Top 100"),
#     ("India", "Angel One", "0016100001cgWHMAA2", "$608,541", "Top 100"),
#     ("Asean + GCR", "FWD Group", "0014N00001gamOaQAI", "$593,787", "Top 100"),
#     ("Asean + GCR", "FunPlus", "0016100001fQSSuAAO", "$589,096", "Top 100"),
#     ("Korea", "WEVERSE COMPANY Inc.", "0013f000005RTyAAAW", "$585,311", "Top 100"),
#     ("ANZ", "Energy Australia", "0016100001fQSRfAAO", "$569,797", "Top 100"),
#     ("ANZ", "Bupa AU", "0016100001G26JSAAZ", "$559,701", "Top 100"),
#     ("Asean + GCR", "Procter & Gamble China", "0013f000005SaY0AAK", "$558,388", "Top 100"),
#     ("Asean + GCR", "EXP Gaming Co., Ltd.", "0018Y00002kxK3AQAU", "$557,026", "Top 100"),
#     ("ANZ", "Flight Centre Travel Group", "0016100001VcvCDAAZ", "$552,867", "Top 100"),
#     ("ANZ", "AusNet Services", "0016100001Iwo7PAAR", "$549,782", "Top 100"),
#     ("Asean + GCR", "SM Retail", "0013f000004TATYAA4", "$547,496", "Top 100"),
#     ("Japan", "Renesas Electronics Corporation", "0016100001TPK1SAAX", "$545,602", "Top 100"),
#     ("Asean + GCR", "Inchcape Digital Limited", "0016100001aqwCGAAY", "$536,806", "Top 100"),
#     ("Asean + GCR", "Lenovo", "0013f0000063oGYAAY", "$523,805", "Top 100"),
#     ("Asean + GCR", "MEDIACORP PTE LTD", "0016100001G26JTAAZ", "$522,830", "Top 100"),
#     ("ANZ", "Great Southern Bank", "0013f00000650JpAAI", "$520,096", "Top 100"),
#     ("ANZ", "Seven West Media", "0016100001LiGmdAAF", "$493,266", "Top 100"),
#     ("Korea", "Shinsegae", "0018Y00002yEAsJQAW", "$492,167", "Top 100"),
#     ("Asean + GCR", "Techcombank (TCB)", "0013f000004T8fIAAS", "$490,205", "Top 100"),
#     ("ANZ", "Future Fund", "0014N00001g7zkTQAQ", "$488,164", "Top 100"),
#     ("ANZ", "RAC Insurance Pty Ltd", "00161000015HqsSAAS", "$484,473", "Top 100"),
#     ("Asean + GCR", "Haier China", "0013f0000063mEwAAI", "$469,572", "Top 100"),
#     ("ANZ", "Ausgrid", "0016100001WR8W2AAL", "$465,316", "Top 100"),
#     ("India", "Uniphore", "0014N00001iH9I0QAK", "$465,256", "Top 100"),
#     ("Asean + GCR", "AU Optronics Corporation", "0016100001fQSONAA4", "$462,718", "Top 100"),
#     ("Asean + GCR", "The Hong Kong Jockey Club", "0018Y00002kx9iyQAA", "$458,000", "Top 100"),
#     ("ANZ", "EASYGO ENTERTAINMENT PTY LTD", "001Vp000003Nk8gIAC", "$455,792", "Top 100"),
#     ("ANZ", "Monash University", "0016100001XnZeFAAV", "$455,156", "Top 100"),
#     ("Japan", "Toyota Motor Corporation", "0016100001fQSavAAG", "$452,162", "Top 100"),
#     ("Japan", "Recruit", "0016100001fQSY7AAO", "$451,390", "Top 100"),
#     ("ANZ", "Fonterra Co-operative Group", "0016100001VcuQ4AAJ", "$450,118", "Top 100"),
#     ("ANZ", "Toyota Finance Australia Limited", "0014N000027OxhRQAS", "$444,096", "Top 100"),
#     ("Korea", "Devsisters", "0013f0000043yLFAAY", "$440,376", "Top 100"),
#     ("ANZ", "Origin Energy", "0016100000y7fc0AAA", "$438,624", "Top 100"),
#     ("Japan", "PERSOL HOLDINGS CO.", "0014N00001g8LWNQA2", "$437,000", "Top 100"),
#     ("India", "CoinDCX", "0013f000008oM1uAAE", "$433,902", "Top 100"),
#     ("Japan", "LY Corporation", "0014N00001g8LZWQA2", "$428,167", "Top 100"),
#     ("Asean + GCR", "Foris Limited (Crypto.com)", "0014N000027PEy9QAG", "$423,583", "Top 100"),
#     ("Japan", "AXA Life Japan", "0014N00001zEzEmQAK", "$414,519", "Top 100"),
#     ("ANZ", "Zip Co", "0016100001AUFUpAAP", "$408,336", "Top 100"),
#     ("Asean + GCR", "Tencent Group", "0018Y00002zIp0HQAS", "$426,883", "Other Priority Accts"),
#     ("ANZ", "Virgin Australia", "0016100001XnZquAAF", "$411,451", "Other Priority Accts"),
#     ("ANZ", "South32", "0016100001F01EzAAJ", "$396,272", "Other Priority Accts"),
#     ("ANZ", "APA Group", "0016100001fQSO8AAO", "$355,611", "Other Priority Accts"),
#     ("ANZ", "Bank of Queensland", "0016100001dRDSFAA4", "$322,772", "Other Priority Accts"),
#     ("Asean + GCR", "Central Provident Fund Board (CPF) Singapore", "0013f0000064m3UAAQ", "$345,906", "Other Priority Accts"),
#     ("Asean + GCR", "Far Eastern Group", "0013f000005SXkFAAW", "$424,009", "Other Priority Accts"),
#     ("Asean + GCR", "TMBThanachart Bank (TTB)", "0016100001XnairAAB", "$407,172", "Other Priority Accts"),
#     ("Asean + GCR", "Ford Automobile Co., Ltd China", "0013f000009fyqIAAQ", "$353,700", "Other Priority Accts"),
#     ("Asean + GCR", "PLDT-Smart", "0016100001fQSXgAAO", "$5,596", "Other Priority Accts"),
#     ("Asean + GCR", "Kiatnakin Phatra Bank Public Company Limited", "0013f000004TD2pAAG", "$363,586", "Other Priority Accts"),
#     ("Japan", "AEON", "0014N00001woLolQAE", "$360,657", "Other Priority Accts"),
#     ("Japan", "ITOCHU Corporation", "0014N00002D8lM0QAJ", "$147,123", "Other Priority Accts"),
#     ("Japan", "TOKYO GAS CO.,LTD", "0016100001fQSatAAG", "$297,686", "Other Priority Accts"),
#     ("Japan", "NTT Group", "0016100001XnYhQAAV", "$303,756", "Other Priority Accts"),
#     ("Japan", "KDDI", "0016100001fQSUiAAO", "$113,527", "Other Priority Accts"),
#     ("Japan", "Panasonic Corporation", "0016100001fQSXRAA4", "$93,776", "Other Priority Accts"),
#     ("Japan", "AGC Inc.", "0014N00001iGRyAQAW", "$184,179", "Other Priority Accts"),
#     ("Japan", "Mitsubishi UFJ Financial Group, Inc.", "0016100001fQSWCAA4", "$231,226", "Other Priority Accts"),
#     ("Japan", "FAST RETAILING CO., LTD.", "0016100001fQSSKAA4", "$35,321", "Other Priority Accts"),
#     ("Japan", "KUBOTA", "0013f000005S4nbAAC", "$252,507", "Other Priority Accts"),
#     ("Japan", "Adinte", "0014N00002D8VCqQAN", "$250,851", "Other Priority Accts"),
#     ("Japan", "Shueisha", "0018Y00002m3upYQAQ", "$301,063", "Other Priority Accts"),
#     ("Japan", "Rakuten Group, Inc.", "0016100001TPJgtAAH", "$14,221", "Other Priority Accts"),
#     ("Japan", "Mitsui & Co", "0016100001XnYrkAAF", "$155,343", "Other Priority Accts"),
#     ("Japan", "Net One Systems Co., Ltd.", "0018Y00002scKE4QAM", "$206,092", "Other Priority Accts"),
#     ("Korea", "KT Cloud", "0016100001BJa81AAD", "$315,392", "Other Priority Accts")
# ]

# columns = ["BU+1", "Deployable Account", "Deployable Account ID", "FY25 Top 100", "Tagging"]

# df = spark.createDataFrame(data, columns)
# df.createOrReplaceTempView("apj_top_100_accounts_program")
# display(df)a