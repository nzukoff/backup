-- Databricks notebook source
SELECT 
  T1.date    
  , SUM(IFF(login_num_events_t28d > 0, 1, 0)) AS mau
FROM 
  main.data_product_features.user_metrics AS T1
WHERE 
  T1.ds = (SELECT MAX(date) FROM main.data_product_features.user_metrics WHERE DAYOFMONTH(date)<=28)
  AND salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')    
GROUP BY ALL    

-- COMMAND ----------

WITH _mau_definition
AS (
    SELECT 
        date_trunc('MONTH', T1.date)::DATE AS month         
        , SUM(IFF(login_num_events_t28d > 0, 1, 0)) AS mau
    FROM 
        main.data_product_features.user_metrics AS T1
    WHERE 
        T1.ds = (SELECT MAX(date) FROM main.data_product_features.user_metrics WHERE DAYOFMONTH(date)<=28)
        AND salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')    
    GROUP BY ALL    
),_mau_learning
AS (
    SELECT        
        u.month
        , SUM(u.MAU) mau        
    FROM 
        main.field_learning_enablement.monthly_active_users as u
    WHERE 
        u.processDate = (select max(processDate) from main.field_learning_enablement.monthly_active_users)
    GROUP BY ALL
), _mau_usat
AS (
    SELECT
      T1.month,
      SUM(mau) AS mau,
      SUM(wau)
    FROM
      main.field_learning_enablement.fact_daily_mau AS T1
    WHERE
      (DAYOFMONTH(date) = 28 OR date = (SELECT MAX(date) FROM main.field_learning_enablement.fact_daily_mau WHERE DAYOFMONTH(date)<=28))
    GROUP BY ALL
)
SELECT 
    *
FROM(
    SELECT
        T1.month,
        T1.mau AS `mau_L&E_Dash`,
        T2.mau AS mau_usat,
        T3.mau AS mau_definition
    FROM
        _mau_learning T1
    LEFT JOIN
        _mau_usat T2 USING(month)
    LEFT JOIN
        _mau_definition T3 USING(month)
    WHERE
        DATE_TRUNC('month', T1.month)::date >= DATEADD(MONTH, -1, current_timestamp()::DATE)    
) AS X