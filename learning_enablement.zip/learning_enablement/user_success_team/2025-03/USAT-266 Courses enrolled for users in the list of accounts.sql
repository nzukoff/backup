-- Databricks notebook source
-- MAGIC %md
-- MAGIC **Courses enrolled for users in the list of accounts**: 
-- MAGIC
-- MAGIC **Description**
-- MAGIC
-- MAGIC - What are the courses these teams have enrolled into/ what date/ how many users?
-- MAGIC
-- MAGIC
-- MAGIC **What are your expectations?  What would you like to see accomplished?**
-- MAGIC - A table with list of accounts & the courses the users in the accounts were enrolled in and dates.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### 0. Feedback shared - Source [Fast Feedback from Trial Users](https://docs.google.com/spreadsheets/d/1JnWcD88rETKDixwpmigSIGhG3VUiJSCH4M4KAj5QjqU/edit?usp=sharing)

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _feedback AS
SELECT * FROM VALUES
('1093246551255193', 'FEEDBACK-14067', 'Feedback for DBSQLX.CatalogExplorer > catalog-explorer-new-landing-page: I''m not able to open the', 'I''m not able to open the dbfs for accessing the file', '["fast-feedback-DBSQLX_CatalogExplorer"]', '2025-03-15T00:07:57.294Z'),
('109631415969487', 'FEEDBACK-12547', 'Feedback for Fast Feedback > top-nav-feedback-link: UnsupportedOperationException: Public DBFS root is disabled.', 'UnsupportedOperationException: Public DBFS root is disabled. Access is denied on path: /mnt', '["fast-feedback-Storage_ObjectStoragePlatform"]', '2024-12-30T13:05:45.680Z'),
('1860373362999555', 'FEEDBACK-13851', 'Feedback for Fast Feedback > top-nav-feedback-link: I cant find the DBFS enabling', 'I cant find the DBFS enabling at all :(', '["fast-feedback-Storage_ObjectStoragePlatform"]', '2025-03-06T01:06:37.791Z'),
('2555410227895942', 'FEEDBACK-14264', 'Feedback for Fast Feedback > top-nav-feedback-link: I am new user of Databrick,', 'I am new user of Databrick, I found it extremely user unfriendly even with reading files. I just want to read a csv file, which upload into DBFS directory. However, the access denied. I tried to enable it in setting but it is not showing in my setting section to enable it. So what is the matter with you guys if you want to expand your user base with Databricks? It is extremely confused. I even tried with Extension on VS Code, same shit, extremely confused for new user.', '["fast-feedback-Storage_ObjectStoragePlatform"]', '2025-03-23T12:04:56.940Z'),
('3105969936238547', 'FEEDBACK-14129', 'Feedback for Fast Feedback > top-nav-feedback-link: iam unable yo access dbfs kindly', 'iam unable yo access dbfs kindly assist me', '["fast-feedback-Storage_ObjectStoragePlatform"]', '2025-03-18T12:09:35.684Z'),
('916686881159719', 'FEEDBACK-12744', 'Feedback for Workspace.Assistant > single-assistant: how can i enable dbfs so', 'how can i enable dbfs so i can move my parquet file from my workspace to dbfs', '["fast-feedback-Workspace_Assistant"]', '2025-01-15T01:06:21.357Z'),
('916686881159719', 'FEEDBACK-12727', 'Feedback for Workspace.Assistant > auto-fix: UnsupportedOperationException: Public DBFS root is disabled.', 'UnsupportedOperationException: Public DBFS root is disabled. Access is denied on path: REDACTED_LOCAL_PART@gmail.com/U.parquet\n File <command-1884928162884170>, line 2\n  1 # Copy files from workspace to DBFS\n ----> 2 dbutils.fs.cp(""dbfs:REDACTED_LOCAL_PART@gmail.com/U.parquet"", ""dbfs:/FileStore/tables/U.parquet"")\n  3 dbutils.fs.cp(""dbfs:REDACTED_LOCAL_PART@gmail.com/H.parquet"", ""dbfs:/FileStore/tables/H.parquet"")\n File /databricks/python/lib/python3.10/site-packages/pyspark/errors/exceptions/captured.py:230, in capture_sql_exception.<locals>.deco(*a, **kw)\n  226 converted = convert_exception(e.java_exception)\n  227 if not isinstance(converted, UnknownException):\n  228  # Hide where the exception came from that shows a non-Pythonic\n  229  # JVM exception message.\n --> 230  raise converted from None\n  231 else:\n  232  raise', '["fast-feedback-Workspace_Assistant"]', '2025-01-14T01:05:54.130Z')
AS t(workspace_id, key, summary, description, labels, created);

SELECT * FROM _feedback;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### 1. List of accounts

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _accounts AS
SELECT 
  t.*,
  f.* EXCEPT (workspace_id) 
FROM VALUES
  ('4ef038f7-2ee1-447b-b97a-48c52e589d78', '2555410227895942'),
  ('82794b78-92d8-4507-a09f-8ebb0071c4ab', '109631415969487'),
  ('c6561b79-5d56-4f74-a33a-c4f0f7ea7175', '916686881159719'),
  ('f0bbf4fa-e182-4159-ab34-b5ae887927c0', '2927714714637763'),
  ('cb2c156e-2cb9-4169-b347-0c52dacfccdb', '3105969936238547'),
  ('6b07161d-8be2-4923-8c8e-d25ac21e65fa', '2067656794046442'),
  ('114339f9-7242-4719-a511-d36c0804adb2', '1093246551255193'),
  ('4e777fae-47c2-472a-a24b-61d7529e74e3', '2321262916744997'),
  ('fc2793c4-352f-4ffb-b9a7-63abd9bc09d2', '1860373362999555')
AS t(account_id, workspace_id)
LEFT JOIN 
  _feedback AS f
ON 
  t.workspace_id = f.workspace_id;

SELECT * FROM _accounts;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### 2. Get the salesforce_account_id of each account

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _accounts_w_salesforce_id
AS
SELECT   
  a.workspace_id,
  a.key AS feedback_key,  
  a.created::DATE AS feedback_date,
  a.description AS feedback_text,
  w.salesforce_account_id AS account_id,
  w.salesforce_account_name AS account_name  
FROM 
  _accounts AS a
LEFT JOIN
  main.certified.workspaces_latest AS w
ON 
  a.workspace_id = w.workspace_id
GROUP BY ALL;

SELECT * FROM _accounts_w_salesforce_id;
  

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### 2. List of courses enrolled by the accounts

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 2.1. Get list of courses

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _courses_taken
AS
SELECT    
  ae.updated_account_id AS account_id,  
  ae.enrolled_date,
  ae.course_id,
  ae.course_name
FROM
  main.field_learning_enablement.all_enrollments AS ae
WHERE
  processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)    
  AND ae.enrolled_date > DATEADD(month, -3, current_date())  
  AND ae.updated_account_id IN(SELECT DISTINCT account_id FROM _accounts_w_salesforce_id)
GROUP BY ALL;

SELECT * FROM _courses_taken;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql import SparkSession
-- MAGIC from pyspark.sql.functions import col, max, row_number
-- MAGIC from pyspark.sql.window import Window
-- MAGIC
-- MAGIC ## Save the views to a Python dataframe
-- MAGIC feedback_df = spark.sql("SELECT * FROM _accounts_w_salesforce_id")
-- MAGIC course_df = spark.sql("SELECT * FROM _courses_taken")
-- MAGIC
-- MAGIC # Convert date columns to date type
-- MAGIC feedback_df = feedback_df.withColumn("feedback_date", col("feedback_date").cast("date"))
-- MAGIC course_df = course_df.withColumn("enrolled_date", col("enrolled_date").cast("date"))
-- MAGIC
-- MAGIC # Create aliases to avoid ambiguity
-- MAGIC feedback_df = feedback_df.alias("f")
-- MAGIC course_df = course_df.alias("c")
-- MAGIC
-- MAGIC # Create a window partitioned by account_id, ordering enrollments before the feedback date
-- MAGIC window_spec = Window.partitionBy("f.account_id").orderBy(col("c.enrolled_date").desc())
-- MAGIC
-- MAGIC # Join feedback with courses where course was enrolled before feedback date
-- MAGIC final_df = feedback_df.join(
-- MAGIC     course_df,
-- MAGIC     (col("f.account_id") == col("c.account_id")) & 
-- MAGIC     (col("c.enrolled_date") <= col("f.feedback_date")),
-- MAGIC     "left"
-- MAGIC )
-- MAGIC
-- MAGIC # Define a window function to rank courses by enrollment date (closest first)
-- MAGIC window_spec = Window.partitionBy("feedback_key").orderBy(col("enrolled_date").desc())
-- MAGIC
-- MAGIC # Assign row numbers based on how close the enrollment date is to the feedback date
-- MAGIC final_df = final_df.withColumn("rank", row_number().over(window_spec))
-- MAGIC
-- MAGIC # Filter to keep only the top 2 closest courses per feedback
-- MAGIC final_df = final_df.filter(col("rank") <= 2).select("f.workspace_id", "f.feedback_key", "f.account_id", "f.feedback_date", "f.feedback_text", "c.course_id", "c.course_name", "c.enrolled_date")
-- MAGIC
-- MAGIC final_df.createOrReplaceTempView("_final_df")

-- COMMAND ----------

SELECT 
  a.*,
  f.course_id,
  f.course_name,
  f.enrolled_date
FROM 
  _accounts_w_salesforce_id AS a
LEFT JOIN
  _final_df AS f USING(feedback_key) 


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### 3. Survey results from courses taken by accounts

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 3.1. Self-paced courses

-- COMMAND ----------

SELECT 
  *
FROM 
  main.field_learning_enablement.qualtrics_self_paced_survey_details AS sd
WHERE 
  processDate = (select max(processDate) from main.field_learning_enablement.qualtrics_self_paced_survey_details)  
  AND (sd.course_code, sd.course_id) IN (SELECT DISTINCT course_code, course_id FROM _courses_taken)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 3.2. ILT courses

-- COMMAND ----------

SELECT 
  *
FROM 
  main.field_learning_enablement.qualtrics_ilt_survey_details AS sd
WHERE 
  processDate = (select max(processDate) from main.field_learning_enablement.qualtrics_ilt_survey_details)
  AND session_id IN(SELECT DISTINCT session_id FROM _courses_taken)