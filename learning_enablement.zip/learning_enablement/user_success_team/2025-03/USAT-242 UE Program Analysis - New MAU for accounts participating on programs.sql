-- Databricks notebook source
CREATE OR REPLACE TEMP VIEW _ue_enrolments_ilt 
AS
with nnl as(
    select learner_user_id, course_code, completed_date
    from main.field_learning_enablement.all_learners
    where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    and dataset = 'net new learners'
)


-- Onboarding & HDC ILT
select 
  updated_account_id,
  updated_account_name,
  learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') as sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') as sales_subregion_level_2
from main.team_field_user_enablement.vw_ue_enrolments_ilt
where session_date >= '2024-02-01'
and training_type = 'Public'
and course_type IN ('Half-Day', 'Onboarding')
union

-- self-paced onboarding
select 
  account_id,
  account_name,
  learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, 'Self-Paced' as course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.team_field_user_enablement.vw_ue_enrolments_sp
where completed_date >= '2024-02-01'
union

--private workshops
select 
  updated_account_id,
  updated_account_name,
  learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, 'Workshop' as course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.team_field_user_enablement.vw_ue_enrolments_ilt
where session_date>= '2024-02-01'
and training_type = 'Private'
and provider = 'User Enablement'
union

-- summit
select 
  ae.updated_account_id,
  ae.updated_account_name,
  ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'DAIS' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.course_name like '%DAIS 2024%'
and ae.completed_date >= '2024-02-01'
union


-- World Tour
select 
  ae.updated_account_id,
  ae.updated_account_name,
  ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'DAIWT' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.course_name like '%DAIWT 2024%'
and ae.completed_date >= '2024-02-01'
union

-- Learning Festival Q1 - Q3
select 
  ae.updated_account_id,
  ae.updated_account_name,
  ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'Learning Festival' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
and ae.course_id in (
    1266, -- DEWD
    2268, -- ADEWD
    2307, -- DAWD
    2906, -- DAWD 2024
    2417, -- MLWD
    1522, -- MLIP
    2267, -- GAIEWD 2023
    2726 -- GAIEWD 2024
)
and 
(
    ae.completed_timestamp between '2024-02-29T00:00:00UTC+14' and '2024-03-14T00:00:00UTC-12' -- Q1 FY25
    or 
    ae.completed_timestamp between '2024-07-10T00:00:00UTC+14' and '2024-07-25T00:00:00UTC-12' -- Q2 FY25
    or
    ae.completed_timestamp between '2024-10-10T00:00:00UTC+14' and '2024-11-01T00:00:00UTC-12' -- Q3 FY25
)
union
-- Databricks Academy Labs
 
select 
  ae.updated_account_id,
  ae.updated_account_name,
  ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'Academy Labs' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.completed_date >= '2024-02-01'
and ae.course_code IN (
    select distinct course_code from main.it_training_silver.docebo_subscription_enrollments
    where processDate = (select max(processDate) from main.it_training_silver.docebo_subscription_enrollments)
    and subscription_plan_code = 'DB-ACAD-LABS-SUB-PLAN'
)

-- union
-- -- Learning Festival Q4
-- select * from main.team_field_user_enablement.q4_learning_festival

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _ue_nnl_mau
AS
WITH _nnl
AS (
  SELECT
    T1.course_type,
    date_trunc('MONTH', T1.completed_date)::DATE AS completed_month,
    T1.completed_date,
    T1.updated_account_id,
    T1.updated_account_name,
    T1.sales_region,
    COUNT(T1.learner_date) AS net_new_learners
  FROM
    _ue_enrolments_ilt AS T1
  GROUP BY ALL
  HAVING COUNT(T1.learner_date) > 0
), _mau
AS(
  SELECT
    T1.date,  
    T1.customer_id,
    SUM(T1.mau) AS mau,
    SUM(IFF(T1.date = T1.min_date, T1.mau, 0)) AS new_mau
  FROM
    main.field_learning_enablement.fact_daily_mau AS T1  
  GROUP BY ALL
)
SELECT
  *
FROM
  _nnl AS T1
LEFT JOIN 
  _mau AS T2
ON
  T1.updated_account_id = T2.customer_id
  AND T1.completed_date = T2.date;

SELECT 
  *
FROM
  _ue_nnl_mau;

-- COMMAND ----------

SELECT 
  T1.course_type,
  IFF(T1.sales_region LIKE '%AMER%', 'AMER', T1.sales_region) AS sales_region,
  T1.completed_month,
  date_format(T1.completed_month, 'MMMM') AS month_name,
  SUM(net_new_learners) AS net_new_learners,
  SUM(new_mau) AS new_mau
FROM
  _ue_nnl_mau AS T1
WHERE  
  T1.completed_month <= '2024-12-01' 
GROUP BY ALL;