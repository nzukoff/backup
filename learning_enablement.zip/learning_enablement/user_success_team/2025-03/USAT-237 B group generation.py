# Databricks notebook source
# DBTITLE 1,Base data
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _campaign_accounts
# MAGIC AS
# MAGIC WITH _initial
# MAGIC AS (
# MAGIC     SELECT
# MAGIC         account_id AS customer_id,
# MAGIC         MIN(session_date) AS first_session_date 
# MAGIC     FROM
# MAGIC         main.field_learning_enablement.fact_campaign_analysis 
# MAGIC     GROUP BY ALL
# MAGIC ), _monthly_mau
# MAGIC AS(
# MAGIC   SELECT
# MAGIC     T1.customer_id, 
# MAGIC     T1.month,
# MAGIC     IFF(T2.customer_id IS NOT NULL, 'A', 'B') AS Group,  
# MAGIC     SUM(T1.mau) AS mau,
# MAGIC     SUM(T1.wau) AS wau,    
# MAGIC     SUM(T1.total_dollars_t28d) total_dollars,
# MAGIC     SUM(T1.lakeview_dollars) AS lakeview_dollars
# MAGIC   FROM 
# MAGIC       main.field_learning_enablement.fact_mau_users AS T1
# MAGIC   LEFT JOIN
# MAGIC       _initial AS T2
# MAGIC   ON 
# MAGIC       T1.customer_id = T2.customer_id          
# MAGIC   WHERE
# MAGIC       T1.month < '2024-09-01'
# MAGIC       AND T1.month >= DATEADD(month, -3, '2024-09-01')
# MAGIC       AND T1.bu = 'AMER Enterprise & Emerging'      
# MAGIC   GROUP BY ALL
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     *,
# MAGIC     mau_1 - mau_3 AS mau_monthly_growth_rate,    
# MAGIC     total_dollars_1 - total_dollars_3 AS total_dollars_monthly_growth_rate,
# MAGIC     lakeview_dollars_1 - lakeview_dollars_3 AS lakeview_dollars_monthly_growth_rate
# MAGIC FROM(
# MAGIC     SELECT
# MAGIC         T1.customer_id AS AccountID,      
# MAGIC         T1.group,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -1, '2024-09-01') THEN T1.mau END), 0) AS mau_1,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -2, '2024-09-01') THEN T1.mau END), 0) AS mau_2,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -3, '2024-09-01') THEN T1.mau END), 0) AS mau_3,
# MAGIC         AVG(T1.mau) AS avg_mau_last_3,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -1, '2024-09-01') THEN T1.wau END), 0) AS wau_1,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -2, '2024-09-01') THEN T1.wau END), 0) AS wau_2,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -3, '2024-09-01') THEN T1.wau END), 0) AS wau_3,
# MAGIC         AVG(T1.wau) AS avg_wau_last_3,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -1, '2024-09-01') THEN T1.total_dollars END), 0) AS total_dollars_1,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -2, '2024-09-01') THEN T1.total_dollars END), 0) AS total_dollars_2,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -3, '2024-09-01') THEN T1.total_dollars END), 0) AS total_dollars_3,
# MAGIC         AVG(T1.total_dollars) AS avg_total_dollars_last_3,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -1, '2024-09-01') THEN T1.lakeview_dollars END), 0) AS lakeview_dollars_1,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -2, '2024-09-01') THEN T1.lakeview_dollars END), 0) AS lakeview_dollars_2,
# MAGIC         NVL(SUM(CASE WHEN T1.month = DATEADD(month, -3, '2024-09-01') THEN T1.lakeview_dollars END), 0) AS lakeview_dollars_3,
# MAGIC         AVG(T1.lakeview_dollars) AS avg_lakeview_dollars_last_3
# MAGIC     FROM 
# MAGIC         _monthly_mau T1
# MAGIC     GROUP BY ALL
# MAGIC ) AS T1;

# COMMAND ----------

data = spark.table('_campaign_accounts')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## First test (discarted)

# COMMAND ----------

# MAGIC %md
# MAGIC We’ll tackle the A/B test setup in 6 key steps:
# MAGIC
# MAGIC ##### 1. Data Preparation:
# MAGIC - Load and clean the data (MAU, WAU, and consumption for all accounts, both participants and non-participants).
# MAGIC - Calculate the 3-month average MAU growth for clustering.
# MAGIC
# MAGIC ##### 2. Clustering (Group B Selection):
# MAGIC - Use k-means or another clustering method to group accounts by MAU growth.
# MAGIC - Identify non-participants that match the growth patterns of participants.
# MAGIC
# MAGIC ##### 3. Matching Accounts:
# MAGIC - Pair each participant with multiple non-participants based on cluster proximity.
# MAGIC - Ensure a reasonable match ratio (3:1 or 5:1).
# MAGIC
# MAGIC ##### 4. Pre-Campaign Validation:
# MAGIC - Compare pre-campaign metrics (MAU, WAU, consumption) between Group A and Group B to check balance.
# MAGIC - Use statistical tests (like SMD) to confirm similarity.
# MAGIC
# MAGIC ##### 5. Post-Campaign Analysis:
# MAGIC - Calculate post-campaign changes for both groups.
# MAGIC - Use statistical tests (t-tests, DiD) to measure the campaign's impact.
# MAGIC
# MAGIC ##### 6. Visualization and Reporting:
# MAGIC - Create clear visualizations showing the differences.
# MAGIC - Summarize findings in a way that highlights the campaign's effect.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Preparation:
# MAGIC
# MAGIC Load and clean the data (MAU, WAU, and consumption for all accounts, both participants and non-participants).
# MAGIC Calculate the 3-month average MAU growth for clustering.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Clustering (Group B Selection):
# MAGIC
# MAGIC Use k-means or another clustering method to group accounts by MAU growth.\
# MAGIC Identify non-participants that match the growth patterns of participants.

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Initialize Spark session
spark = SparkSession.builder.appName("LearningCampaignAnalysis").getOrCreate()

# Filter only non-participants (Group B)
non_participants = data.filter(col("Group") == "B")

# Select relevant features for clustering
non_participants = non_participants.select("AccountID", "avg_MAU_last_3")

# Handle nulls for clustering
non_participants = non_participants.na.drop(subset=["avg_MAU_last_3"])

# Convert Spark DataFrame to Pandas DataFrame for sklearn
non_participants_pd = non_participants.toPandas()

# Standardize the avg_MAU_last_3 column
scaler = StandardScaler()
non_participants_pd['scaled_avg_MAU_last_3'] = scaler.fit_transform(non_participants_pd[['avg_MAU_last_3']])

# Elbow method to find optimal k
cost = []
k_values = range(2, 11)

for k in k_values:
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(non_participants_pd[['scaled_avg_MAU_last_3']])
    cost.append((k, kmeans.inertia_))

# Convert cost data to Pandas DataFrame
cost_df = pd.DataFrame(cost, columns=['k', 'cost'])

# Plot the elbow curve
plt.figure(figsize=(8, 5))
plt.plot(cost_df['k'], cost_df['cost'], marker='o')
plt.title('Elbow Method For Optimal k')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Cost (Sum of Squared Distances)')
plt.show()

# COMMAND ----------

# K-means clustering with k = 4
kmeans = KMeans(n_clusters=4, random_state=42)
non_participants_pd['cluster'] = kmeans.fit_predict(non_participants_pd[['scaled_avg_MAU_last_3']])

# Convert back to Spark DataFrame
clustered_non_participants = spark.createDataFrame(non_participants_pd)

# Show cluster assignments
# clustered_non_participants.select("AccountID", "avg_MAU_last_3", "cluster").show(10)
display(clustered_non_participants)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Matching Accounts:
# MAGIC
# MAGIC - Pair each participant with multiple non-participants based on cluster proximity.
# MAGIC - Ensure a reasonable match ratio (3:1 or 5:1).

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, abs, row_number
from pyspark.sql.window import Window
import pandas as pd

# Load participants (Group A) and clustered non-participants (Group B)
participants = data.filter(col("Group") == "A").select("AccountID", "avg_MAU_last_3")
clustered_non_participants = clustered_non_participants.select("AccountID", "avg_MAU_last_3", "cluster")

# Add cluster labels to participants by finding closest cluster centers
participants_pd = participants.toPandas()
participants_pd['cluster'] = kmeans.predict(scaler.transform(participants_pd[['avg_MAU_last_3']]))
participants = spark.createDataFrame(participants_pd)

# Join participants with non-participants by cluster
joined_data = participants.join(clustered_non_participants, on='cluster', how='inner')

display(joined_data)

# # Calculate absolute difference in MAU
# joined_data = joined_data.withColumn("MAU_diff", abs(col("avg_MAU_last_3") - col("avg_MAU_last_3")))

# # Rank non-participants by closest MAU for each participant
# window = Window.partitionBy("AccountID").orderBy(col("MAU_diff"))
# ranked_matches = joined_data.withColumn("rank", row_number().over(window))

# # Filter top 3 matches per participant
# matched_pairs = ranked_matches.filter(col("rank") <= 3)


# # Show sample of matched pairs
# matched_pairs.select("AccountID", "avg_MAU_last_3", "cluster", "rank").show(1)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Pre-Campaign Validation:
# MAGIC
# MAGIC - Compare pre-campaign metrics (MAU, WAU, consumption) between Group A and Group B to check balance.
# MAGIC - Use statistical tests (like SMD) to confirm similarity.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Post-Campaign Analysis:
# MAGIC
# MAGIC - Calculate post-campaign changes for both groups.
# MAGIC - Use statistical tests (t-tests, DiD) to measure the campaign's impact.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Visualization and Reporting:
# MAGIC
# MAGIC - Create clear visualizations showing the differences.
# MAGIC - Summarize findings in a way that highlights the campaign's effect.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Second test - Active

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Proposed Approach
# MAGIC - Calculate MAU growth for both groups:
# MAGIC - Ensure both participants and non-participants have their 3-month average MAU growth calculated.
# MAGIC
# MAGIC ##### Pair participants with non-participants based on MAU growth proximity:
# MAGIC - For each participant, find the three non-participants with the closest MAU growth rates.
# MAGIC - This ensures a direct 1:3 match focused on growth similarity, not just cluster membership.
# MAGIC
# MAGIC ##### Ensure all participants are matched:
# MAGIC - The output should guarantee that each participant appears with exactly three non-participant matches — not a reduced subset based on cluster sizes.

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, rand

# Initialize Spark session
spark = SparkSession.builder.appName("LearningCampaignAnalysis").getOrCreate()

# Filter participants (Group A) and non-participants (Group B)
participants = data.filter(col("Group") == "A")
non_participants = data.filter(col("Group") == "B")

# Convert participants and non-participants to Pandas DataFrames for easier distance calculations
participants_pd = participants.select("AccountID", "avg_MAU_last_3").toPandas()
non_participants_pd = non_participants.select("AccountID", "avg_MAU_last_3").toPandas()

# Prepare an empty list to store matches
matches = []

# Iterate over each participant to find the closest non-participants based on percentage difference
for _, participant in participants_pd.iterrows():
    participant_id = participant['AccountID']
    participant_avg_MAU_last_3 = participant['avg_MAU_last_3']
    
    # Calculate percentage difference for each non-participant
    non_participants_pd['percentage_diff'] = np.abs((non_participants_pd['avg_MAU_last_3'] - participant_avg_MAU_last_3) / participant_avg_MAU_last_3)
    
    # Randomize tie-breaking by shuffling non-participants
    non_participants_pd = non_participants_pd.sample(frac=1, random_state=42)
    
    # Get top N closest non-participants
    top_matches = non_participants_pd.nsmallest(1, 'percentage_diff')
    
    # Store matches
    for _, match in top_matches.iterrows():
        matches.append((participant_id, match['AccountID'], participant_avg_MAU_last_3, match['avg_MAU_last_3'], match['percentage_diff']))
    
    # Remove matched non-participants to prevent re-use
    non_participants_pd = non_participants_pd[~non_participants_pd['AccountID'].isin(top_matches['AccountID'])]

# Convert matches to a Spark DataFrame
matches_df = spark.createDataFrame(matches, ["ParticipantID", "NonParticipantID", "Participant_avg_MAU_last_3", "NonParticipant_avg_MAU_last_3", "Percentage_Diff"])


matches_df.createOrReplaceTempView("matches_view")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     *
# MAGIC FROM
# MAGIC     matches_view

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Adding new variables to the analysis

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, rand


# Sample DataFrames: participants and non_participants
# Assuming the DataFrames have the necessary columns including the new variables

# Weights for each variable
mau_weight = 0.4
avg_dollars_weight = 0.1
dollars_growth_weight = 0.2
lakeview_dollars_growth_weight =  0.2

# Calculate pairwise distance using all three variables with equal weight
def calculate_distance(participant, non_participant):
    mau_diff = np.abs(participant['mau_monthly_growth_rate'] - non_participant['mau_monthly_growth_rate'])
    dollars_growth_diff = np.abs(participant['total_dollars_monthly_growth_rate'] - non_participant['total_dollars_monthly_growth_rate'])
    avg_dollars_diff = np.abs(participant['avg_total_dollars_last_3'] - non_participant['avg_total_dollars_last_3'])
    lakeview_dollars_growth_diff = np.abs(participant['lakeview_dollars_monthly_growth_rate'] - non_participant['lakeview_dollars_monthly_growth_rate'])
    
    # Calculate combined distance
    return (
        mau_diff * mau_weight + 
        dollars_growth_diff * dollars_growth_weight + 
        avg_dollars_diff * avg_dollars_weight + 
        lakeview_dollars_growth_diff * lakeview_dollars_growth_weight) / 4

# Matching logic with 1:3 ratio
def match_participants_to_non_participants(participants, non_participants, ratio=1):
    matches = []
    non_participants = non_participants.sample(frac=1).reset_index(drop=True)  # Shuffle to break ties randomly
    used_non_participants = set()
    
    for _, participant in participants.iterrows():
        # Calculate distances for each non-participant
        non_participants['distance'] = non_participants.apply(lambda np: calculate_distance(participant, np), axis=1)
        
        # Filter out already matched non-participants
        available_non_participants = non_participants[~non_participants['AccountID'].isin(used_non_participants)]
        
        # Get top N closest non-participants
        closest_matches = available_non_participants.nsmallest(ratio, 'distance')
        
        # Record matches
        for _, match in closest_matches.iterrows():
            matches.append({
                'ParticipantID': participant['AccountID'],
                'NonParticipantID': match['AccountID'],
                'Participant_MAU_Growth': participant['mau_monthly_growth_rate'],
                'NonParticipant_MAU_Growth': match['mau_monthly_growth_rate'],
                'Participant_Dollars_Growth': participant['total_dollars_monthly_growth_rate'],
                'NonParticipant_Dollars_Growth': match['total_dollars_monthly_growth_rate'],
                'Participant_Lakeview_Dollars_Growth': participant['lakeview_dollars_monthly_growth_rate'],
                'NonParticipant_Lakeview_Dollars_Growth': match['lakeview_dollars_monthly_growth_rate'],                
                'Participant_Avg_Dollars': participant['avg_total_dollars_last_3'],
                'NonParticipant_Avg_Dollars': match['avg_total_dollars_last_3'],
                'Distance': match['distance']
            })
            used_non_participants.add(match['AccountID'])
    
    return pd.DataFrame(matches)

# Sample DataFrames: participants and non_participants
# Filter participants (Group A) and non-participants (Group B)
participants = data.filter(col("Group") == "A")
non_participants = data.filter(col("Group") == "B")

# Convert participants and non-participants to Pandas DataFrames for easier distance calculations
participants = participants.toPandas()
non_participants = non_participants.toPandas()

# Example usage
matches_df = match_participants_to_non_participants(participants, non_participants)

matches_df = spark.createDataFrame(matches_df, 
                                   ['ParticipantID', 'NonParticipantID', 
                                    'Participant_MAU_Growth', 'NonParticipant_MAU_Growth', 
                                    'Participant_Dollars_Growth', 'NonParticipant_Dollars_Growth', 
                                    'Participant_Lakeview_Dollars_Growth', 'NonParticipant_Lakeview_Dollars_Growth', 
                                    'Participant_Avg_Dollars', 'NonParticipant_Avg_Dollars', 
                                    'Distance'])
matches_df.createOrReplaceTempView("matches_view_v2")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     *
# MAGIC FROM
# MAGIC     matches_view_v2
# MAGIC
# MAGIC /*
# MAGIC 0016100001fR5W6AAK	001Vp000003vmxhIAA
# MAGIC 001Vp000002PTgtIAG	0016100001cgMqmAAE
# MAGIC */

# COMMAND ----------

# MAGIC %md
# MAGIC #### A/B manual testing

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   * 
# MAGIC FROM 
# MAGIC   _campaign_accounts
# MAGIC WHERE
# MAGIC   AccountID in('0016100001fR5W6AAK', '', '001Vp000003vmxhIAA')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     account_id AS customer_id,
# MAGIC     MIN(session_date) AS first_session_date 
# MAGIC FROM
# MAGIC     main.field_learning_enablement.fact_campaign_analysis 
# MAGIC WHERE 
# MAGIC   account_id = '0016100001fR5W6AAK'
# MAGIC GROUP BY ALL

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   T1.customer_id,
# MAGIC   T1.date,
# MAGIC   SUM(T1.mau) AS mau
# MAGIC FROM
# MAGIC   main.field_learning_enablement.fact_daily_mau T1
# MAGIC WHERE
# MAGIC   T1.date BETWEEN '2024-11-25' AND '2024-11-27'
# MAGIC   AND T1.customer_id in('0016100001fR5W6AAK', '', '001Vp000003vmxhIAA')
# MAGIC GROUP BY ALL
# MAGIC ORDER BY 1, 2 DESC 

# COMMAND ----------

# MAGIC %md
# MAGIC #### A/B testing

# COMMAND ----------

# MAGIC %sql
# MAGIC   SELECT
# MAGIC       *
# MAGIC   FROM
# MAGIC     matches_view_v2 
# MAGIC   WHERE
# MAGIC     ParticipantID IN ('0016100000d0VedAAE')

# COMMAND ----------

# DBTITLE 1,Results of Participants vs Nonparticipants
# MAGIC %sql
# MAGIC -- =============================================
# MAGIC -- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
# MAGIC -- Create date: 2025-01-09
# MAGIC -- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
# MAGIC -- =============================================
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
# MAGIC SELECT
# MAGIC   academy_session_number AS session_code
# MAGIC FROM
# MAGIC   main.field_learning_enablement.training_operations_ilt_schedule_master
# MAGIC WHERE
# MAGIC   processDate = (SELECT max(processDate) FROM main.field_learning_enablement.training_operations_ilt_schedule_master)
# MAGIC   AND training_operations_ilt_schedule_master.project_type = '1k AI/BI Training Program'
# MAGIC   AND status not ilike 'cancel%';
# MAGIC
# MAGIC /*
# MAGIC
# MAGIC */
# MAGIC
# MAGIC WITH _event_registrations
# MAGIC AS (  
# MAGIC   -- =============================================
# MAGIC   -- Description: This CTE calculates the event registrations and attendees for each account, along with the session details.  
# MAGIC   -- =============================================
# MAGIC   SELECT
# MAGIC     T1.account_id
# MAGIC     , T1.session_code
# MAGIC     , T1.session_name
# MAGIC     , T1.session_date
# MAGIC   FROM(
# MAGIC     SELECT 
# MAGIC       T1.updated_account_id AS account_id,
# MAGIC       T1.session_code,
# MAGIC       TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name,
# MAGIC       CAST(T1.ended_timestamp AS DATE) AS session_date
# MAGIC     FROM 
# MAGIC         main.field_learning_enablement.all_enrollments AS T1
# MAGIC     INNER JOIN
# MAGIC       _account_sessions AS T2 USING(session_code)    
# MAGIC     WHERE 
# MAGIC       T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)        
# MAGIC   ) AS T1
# MAGIC   GROUP BY ALL 
# MAGIC )
# MAGIC   SELECT
# MAGIC     T1.session_code,
# MAGIC     T1.session_date,
# MAGIC     T1.session_name,
# MAGIC     T1.account_id,   
# MAGIC     T2.account_name,
# MAGIC     T2.business_unit AS bu,
# MAGIC     T2.sales_subregion_level_1 AS bu_1,
# MAGIC     T2.sales_subregion_level_2 AS bu_2,
# MAGIC     T2.sales_subregion_level_3 AS bu_3,    
# MAGIC     T1.participant,
# MAGIC     MAX(T1.date) max_mau_date,
# MAGIC     ROUND(AVG(T1.mau_pre_event)) AS mau_pre_event,   
# MAGIC     SUM(T1.mau_01d_post_event) AS mau_post_event,
# MAGIC     SUM(T1.mau_01d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_01d_growth,
# MAGIC     SUM(T1.mau_07d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_07d_growth,
# MAGIC     SUM(T1.mau_14d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_14d_growth,
# MAGIC     SUM(T1.mau_30d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_30d_growth
# MAGIC   FROM(
# MAGIC     SELECT
# MAGIC       T3.session_code,
# MAGIC       T3.session_date,
# MAGIC       T3.session_name,
# MAGIC       T1.date,
# MAGIC       T1.customer_id AS account_id,
# MAGIC       IFF(T1.customer_id=T2.ParticipantID, 'Participant', 'NonParticipant') AS participant,
# MAGIC       SUM(CASE WHEN T1.date >= DATE_SUB(T3.session_date, 90) AND T1.date < T3.session_date THEN T1.mau END) AS mau_pre_event,
# MAGIC       SUM(CASE WHEN T1.date = DATE_ADD(T3.session_date, 01) THEN T1.mau END) AS mau_01d_post_event,
# MAGIC       SUM(CASE WHEN T1.date = DATE_ADD(T3.session_date, 07) THEN T1.mau END) AS mau_07d_post_event,
# MAGIC       SUM(CASE WHEN T1.date = DATE_ADD(T3.session_date, 14) THEN T1.mau END) AS mau_14d_post_event,
# MAGIC       SUM(CASE WHEN T1.date = DATE_ADD(T3.session_date, 30) THEN T1.mau END) AS mau_30d_post_event
# MAGIC     FROM
# MAGIC       matches_view_v2 AS T2
# MAGIC     INNER JOIN
# MAGIC       main.field_learning_enablement.fact_daily_mau AS T1
# MAGIC     ON
# MAGIC       T1.customer_id IN(T2.ParticipantID, T2.NonParticipantID)
# MAGIC     INNER JOIN
# MAGIC       _event_registrations T3
# MAGIC     ON 
# MAGIC       T2.ParticipantID = T3.account_id
# MAGIC     GROUP BY ALL
# MAGIC   ) AS T1    
# MAGIC   LEFT JOIN
# MAGIC     main.gtm_data.core_accounts_curated as T2 USING(account_id)
# MAGIC   GROUP BY ALL  

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Checking an example account for session_code 26769

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC from _sqldf
# MAGIC where session_code = '26769'

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     *
# MAGIC FROM
# MAGIC     matches_view_v2
# MAGIC WHERE
# MAGIC   ParticipantID = '0016100000d0VedAAE'

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   * 
# MAGIC FROM 
# MAGIC   _campaign_accounts
# MAGIC WHERE
# MAGIC   AccountID in('0016100000d0VedAAE', '', '0016100001XnXApAAN')