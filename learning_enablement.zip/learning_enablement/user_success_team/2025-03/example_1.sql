-- Databricks notebook source
CREATE TEMPORARY VIEW _example AS SELECT 1

-- COMMAND ----------

SELECT * FROM _example

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- =============================================
SELECT DISTINCT
    identifier('mau_' || :days_attribution || 'd_growth') AS mau_growth        
    , identifier('wau_' || :days_attribution || 'd_growth') AS wau_growth    
    , identifier('wau_human_' || :days_attribution || 'd_growth') AS wau_human_growth    
    , identifier('dbsql_users_' || :days_attribution || 'd_growth') AS dbsql_users_growth    
    , identifier('genie_users_' || :days_attribution || 'd_growth') AS genie_users_growth    
    , identifier('lakeview_users_' || :days_attribution || 'd_growth') AS lakeview_growth    
    , *
FROM 
    main.field_learning_enablement.fact_campaign_analysis AS T1