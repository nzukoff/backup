-- Databricks notebook source
select
      m.milestone_target_fiscal_year_quarter,
      m.milestone_target_fiscal_year,
      m.milestone_target_date,
      m.milestone_id,
      m.milestone_revenue_type,
      m.class_generated_project_id,
      m.class_name,
      case
        when m.class_custom_id = 12710 then 11083
        when m.class_custom_id = 12708 then 11082
        when m.class_custom_id = 14132 then 14131
        when m.class_custom_id = 13219 then 12632
        else m.class_custom_id
      end as class_custom_id,
      m.class_format,
      m.course,
      m.provider,
      m.milestone_name,
      m.milestone_amount,
      m.gaap_milestone_amount,
      m.milestone_status,
      m.is_milestone_approved,
      m.include_milestone_in_financial,
      m.billing_event_status,
      m.project_id,
      m.project_name,
      m.project_region,
      m.account_name,
      m.billing_invoice_date,
      p.account_id,
      p.project_service_tier,
      p.project_Service_type,
      p.project_unscheduled_backlog,
      p.project_unused_success_credits,
      p.opportunity_id,
      p.parent_project_id,
      p.parent_project_name,
      p1.id, 
      p1.OpportunityID_CaseSafe__c,
      c.sales_business_unit,
      c.opportunity_region_level_1, 
      a.sales_subregion_level_1
    from
      main.gtm_data.core_professional_services_milestones m
      inner join main.gtm_data.core_professional_services_dim_project p on m.project_id = p.project_id
      and p.snapshot_date =(
        select
          max(snapshot_date)
        from
          main.gtm_data.core_professional_services_dim_project
      )
      left join main.sfdc_bronze.pse__proj__c p1 on m.project_id=p1.id and p1.processdate=(select max(processdate) from main.sfdc_bronze.pse__proj__c)
      left join main.gtm_data.core_opportunity_curated c on  p1.OpportunityID_CaseSafe__c=c.opportunity_id
      left join main.gtm_data.core_accounts_curated a on a.account_id = p.account_id
    where
      m.snapshot_date =(
        select
          max(snapshot_date)
        from
          main.gtm_data.core_professional_services_milestones
      )
      and m.practice_name = 'Training'
      and m.milestone_status = "Approved"
      and p.project_service_type not in ('SCP', 'BIF')

-- COMMAND ----------

SELECT
  date,
  bu,
  SUM(wau) AS WAU
FROM
  main.field_learning_enablement.fact_mau_users
WHERE
  date = (SELECT MAX(date) FROM main.field_learning_enablement.fact_mau_users)  
GROUP BY ALL;

-- COMMAND ----------

SELECT         
  T1.date
  , a.business_unit
  , SUM(IFF(login_num_events_t28d > 0, 1, 0)) AS mau    
  , SUM(IFF(login_num_events_t7d > 0, 1, 0)) AS wau
FROM 
  main.data_product_features.user_metrics AS T1
LEFT JOIN 
  main.gtm_data.core_accounts_curated a
  ON T1.customer_id = a.account_id
WHERE 
  salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
  AND T1.date = (SELECT MAX(date) FROM main.data_product_features.user_metrics AS T1)
GROUP BY ALL;