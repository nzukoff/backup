# Databricks notebook source
# MAGIC %run ./example_1

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM _example

# COMMAND ----------

from databricks.sdk import WorkspaceClient

client = WorkspaceClient()
workspace_id = client.get_workspace_id()
print(workspace_id)

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH _issue_summary
# MAGIC AS(
# MAGIC   SELECT
# MAGIC     CAST(i.key AS STRING) AS key, 
# MAGIC     CAST(field_id AS STRING) AS field_id,  
# MAGIC     ifh.value
# MAGIC   FROM 
# MAGIC     main.data_jira_bronze.issue_field_history ifh  
# MAGIC   JOIN
# MAGIC     main.data_jira_bronze.issue i on ifh.issue_id = i.id  
# MAGIC   WHERE
# MAGIC     is_active = 'true'
# MAGIC     AND i.key LIKE ('USAT%')
# MAGIC     AND ifh.field_id  = 'summary'
# MAGIC ), issue_details
# MAGIC AS(
# MAGIC   SELECT 
# MAGIC     s.key,
# MAGIC     s.value AS summary,  
# MAGIC     CASE sct.name WHEN 'Backlog' THEN 1 WHEN 'Selected for Development' THEN 2 WHEN 'In Progress' THEN 3 WHEN 'Testing' THEN 4 WHEN 'Done' THEN 5 ELSE 0 END AS status_id,
# MAGIC     sct.name AS status,
# MAGIC     i.priority AS priority_id,  
# MAGIC     p.name AS priority,  
# MAGIC     i.issue_type AS issue_type_id,
# MAGIC     it.name AS issue_type,
# MAGIC     i.id,
# MAGIC     i.parent_id,  
# MAGIC     u.name AS assignee,  
# MAGIC     i.updated,
# MAGIC     i.created
# MAGIC   FROM 
# MAGIC     _issue_summary AS s
# MAGIC   INNER JOIN
# MAGIC     main.data_jira_bronze.issue AS i USING(key)
# MAGIC   INNER JOIN
# MAGIC     main.data_jira_bronze.status AS sct ON i.status = sct.id
# MAGIC   INNER JOIN
# MAGIC     main.data_jira_bronze.priority AS p ON i.priority = p.id
# MAGIC   INNER JOIN
# MAGIC     main.data_jira_bronze.issue_type AS it ON i.issue_type = it.id
# MAGIC   LEFT JOIN
# MAGIC     main.data_jira_bronze.user AS u ON i.assignee = u.id  
# MAGIC )
# MAGIC
# MAGIC SELECT   
# MAGIC   p.key AS parent_key,
# MAGIC   p.summary AS parent_summary,
# MAGIC   p.status_id AS parent_status_id,
# MAGIC   p.status AS parent_status,
# MAGIC   p.priority_id AS parent_priority_id,
# MAGIC   p.priority AS parent_priority,
# MAGIC   p.issue_type_id AS parent_issue_type_id,
# MAGIC   p.issue_type AS parent_issue_type,
# MAGIC   p.id AS parent_id,
# MAGIC   p.assignee AS parent_assignee,
# MAGIC   p.updated AS parent_updated,
# MAGIC   p.created AS parent_created,
# MAGIC   nvl(c.key, p.key) AS child_key,
# MAGIC   nvl(c.summary, p.summary) AS child_summary,
# MAGIC   nvl(c.status_id, p.status_id) AS child_status_id,
# MAGIC   nvl(c.status, p.status) AS child_status,
# MAGIC   nvl(c.priority_id, p.priority_id) AS child_priority_id,
# MAGIC   nvl(c.priority, p.priority) AS child_priority,
# MAGIC   nvl(c.issue_type_id, p.issue_type_id) AS child_issue_type_id,
# MAGIC   nvl(c.issue_type, p.issue_type) AS child_issue_type,
# MAGIC   nvl(c.id, p.id) AS child_id,
# MAGIC   nvl(c.assignee, p.assignee) AS child_assignee,
# MAGIC   nvl(c.updated, p.updated) AS child_updated,
# MAGIC   nvl(c.created, p.created) AS child_created
# MAGIC FROM
# MAGIC   issue_details AS p
# MAGIC LEFT JOIN
# MAGIC   issue_details AS c
# MAGIC ON
# MAGIC   p.id = c.parent_id
# MAGIC WHERE 
# MAGIC   p.parent_id IS NULL
# MAGIC   AND c.key = 'USAT-106'
# MAGIC ORDER BY 
# MAGIC   p.status_id

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   id, *
# MAGIC from 
# MAGIC   main.data_jira_bronze.status_category;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   id, *
# MAGIC from 
# MAGIC   main.data_jira_bronze.issue_type
# MAGIC WHERE 
# MAGIC   id = 17248;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   id, key, *
# MAGIC from 
# MAGIC   main.data_jira_bronze.issue
# MAGIC WHERE 
# MAGIC   key like '%USAT-244%';