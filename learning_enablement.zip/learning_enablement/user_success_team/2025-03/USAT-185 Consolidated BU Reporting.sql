-- Databricks notebook source
CREATE OR REPLACE TEMPORARY VIEW _bu_report 
AS
( 
WITH mau_wau
AS ( 
SELECT customer_id, account_name, bu, bu_1, bu_2, bu_3, SUM(mau) mau, 
SUM(CASE WHEN user_type = 'Human' THEN mau ELSE 0 END) as mau_human,
SUM(wau) wau,
SUM(CASE WHEN user_type = 'Human' THEN wau ELSE 0 END) as wau_human
FROM main.field_learning_enablement.fact_mau_users
WHERE date = (SELECT MAX(date) FROM main.field_learning_enablement.fact_mau_users)
--AND customer_id = '0013f0000063WxFAAU'
GROUP BY 1, 2, 3, 4, 5, 6
),

product_usage
AS ( 
 SELECT 
    customer_id customer_id_p,
    sum(dbsql_num_users_t28d) as SQL_user,
    sum(dbsql_dollars) as total_sql_dollars,
    sum(unity_catalog_num_users_t28d) as UC_users,
    sum(unity_catalog_dollars) as unity_catalog_dollars,
    sum(lakeview_num_users_t28d) as Lakeview_users,
    sum(lakeview_dollars) as lakeview_dollars,
    sum(ds_ml_num_users_t28d) as DSML_users,
    sum(ds_ml_dollars) as ds_ml_dollars,
    sum(etl_num_users_t28d) as ETL_users,
    sum(etl_dollars) as etl_dollars,
    sum(delta_num_users_t28d) as Delta_users,
    sum(delta_dollars) as delta_dollars
FROM 
  main.data_product_features.customer_metrics
   WHERE date = (SELECT MAX(date) FROM main.data_product_features.customer_metrics)
    GROUP BY 1
),

lna
as(
  SELECT a.orgID as account_id, a.account_name, max(a.recordedDate) as last_survey_date, count(distinct responseId) as lna_responses
        FROM main.team_field_user_enablement.silver_user_recommendation a
        WHERE RecordedDate = (SELECT MAX(RecordedDate) FROM main.team_field_user_enablement.silver_user_recommendation b
                            WHERE a.email = b.email
                            )
        and a.orgID is not NULL
        group by a.orgID, a.account_name
),

learners
AS(
  SELECT 
    updated_account_id AS account_id,
    (SUM(pa_learner) + SUM(da_learner)+ SUM(de_learner) + SUM(ds_learner) + SUM(other_learner)) AS All_Time_learners,
    100* (SUM(CASE WHEN training_value = 'FREE' THEN 1 ELSE 0 END) / All_Time_learners) AS pct_from_free_learners,
    100* (SUM(CASE WHEN training_value = 'PAID' THEN 1 ELSE 0 END) / All_Time_learners) AS pct_from_paid_learners
FROM main.team_field_user_enablement.vw_ue_learner_by_topic
GROUP BY ALL
),

-- Revenue ARR
account_arr AS(
    SELECT 
        DISTINCT account_id,
        arr
    FROM main.team_field_user_enablement.vw_ue_account_targeting 
),

/* Returns Remaining Success Credit Value for Projects with <30K SCs expiring in next 180days */
 remaining_sc_for_training_180d AS (
    select 
Account_ID,
SUM(remaining_success_credits_value) projects_sub_30k_SC_expiring_next_180d_dollars
from main.team_field_user_enablement.ce_backlog
where Service_Type = 'Success Credits'
and Expiring_in_day < 180
and Available_Budget < 30000
and Remaining_Success_Credits_Value > 0
group by 1
),

--trained accounts 
trained_accounts AS (
    SELECT
        distinct account_id,
              trained_flag
    FROM main.team_field_user_enablement.trained_accounts
    WHERE snapshot_date = (select max(snapshot_date) from main.team_field_user_enablement.trained_accounts)
    ),

-- TIP: Training Investment Program
tip as
(
SELECT account_id account_id_tip, MAX(created_date) lastest_tip_requested_date, 
COUNT(DISTINCT request_number) tip_num_requests, sum(requested_coupons) as tip_requested_coupons, sum(used_coupons) as tip_used_coupons, SUM(attended) tip_attended
FROM main.team_field_user_enablement.vw_coupon_requests
WHERE status not in ('Cancelled','Rejected')
GROUP BY 1
)

SELECT m.*, st.account_spend_tier, 
CASE WHEN lna.last_survey_date IS NOT NULL THEN 'Yes' ELSE 'No' END LNA, lna.lna_responses,
CASE WHEN trained_flag = 1 THEN 'Yes' ELSE 'No' END trained_account,
All_Time_learners, pct_from_free_learners, pct_from_paid_learners, 
arr  training_revenue, 
IFNULL(projects_sub_30k_SC_expiring_next_180d_dollars, 0) unused_success_credits,
CASE WHEN t.account_id_tip IS NOT NULL THEN 'Yes' ELSE 'No' END tip_requested,
t.lastest_tip_requested_date, t.tip_num_requests, t.tip_requested_coupons, t.tip_used_coupons, t.tip_attended,
p.*
FROM mau_wau m
LEFT JOIN product_usage p
  ON m.customer_id = p.customer_id_p
LEFT JOIN main.fin_snap.sfdc_hierarchy_mapping_snap st
  ON m.customer_id = st.sfdc_account_id
LEFT JOIN lna
  ON m.customer_id = lna.account_id
LEFT JOIN learners l
  ON m.customer_id = l.account_id
--WHERE lna.last_survey_date IS NOT NULL 
LEFT JOIN account_arr arr
  ON m.customer_id = arr.account_id
LEFT JOIN remaining_sc_for_training_180d rsc
  ON m.customer_id = rsc.Account_ID
LEFT JOIN trained_accounts ta
  ON m.customer_id = ta.account_id
LEFT JOIN tip t
  ON m.customer_id = t.account_id_tip
ORDER BY m.customer_id, mau DESC
);

SELECT * FROM _bu_report;

-- COMMAND ----------

SELECT
  bu,
  SUM(tip_num_requests),
  SUM(tip_attended)
FROM
  main.field_self_service.bu_report
GROUP BY ALL

-- COMMAND ----------

SELECT
  distributed_coupons, 
  used_coupons,
  attended,
  *
FROM
  main.team_field_user_enablement.vw_coupon_requests AS T1
WHERE 
  T1.account_id in('0016100001DxI5VAAV', '00161000006hMNCAA2')

-- COMMAND ----------

SELECT * 
FROM 
  main.field_learning_enablement.training_milestones 
WHERE 
  processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.training_milestones)

-- COMMAND ----------

SELECT
  T1.business_unit,
  T1.account_id,
  COUNT(DISTINCT request_number) AS num_requests,
  SUM(attended) AS attended
FROM
  main.team_field_user_enablement.vw_coupon_requests AS T1
GROUP BY ALL
