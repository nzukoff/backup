# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _segmentation_analysis
# MAGIC AS
# MAGIC WITH _segmentation_data
# MAGIC AS (
# MAGIC   SELECT
# MAGIC     account_id AS customer_id,
# MAGIC     account_segment AS tam,
# MAGIC     arr_tshirt_size AS current_penetration,
# MAGIC     try_cast(employee_count as int) AS num_employees
# MAGIC   FROM
# MAGIC     main.gtm_data.core_accounts_curated
# MAGIC ), _mau_data
# MAGIC AS (
# MAGIC   SELECT
# MAGIC     T1.month,
# MAGIC     T1.date,
# MAGIC     T1.customer_id,
# MAGIC     SUM(T1.mau) AS mau,
# MAGIC     SUM(T1.wau) AS wau,
# MAGIC     SUM(T1.total_dollars_t28d) AS total_dollars_t28d
# MAGIC   FROM
# MAGIC     main.field_learning_enablement.fact_mau_users AS T1
# MAGIC   WHERE
# MAGIC     T1.date = (SELECT MAX(T1.date) FROM main.field_learning_enablement.fact_mau_users AS T1)
# MAGIC   GROUP BY ALL
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   T1.tam,
# MAGIC   T1.current_penetration,    
# MAGIC   COUNT(customer_id) AS customers, 
# MAGIC   SUM(T1.num_employees) AS total_num_employees,
# MAGIC   SUM(T2.mau) AS total_mau,
# MAGIC   SUM(T2.wau) AS total_wau,
# MAGIC   SUM(T2.total_dollars_t28d) AS total_dollars_t28d
# MAGIC FROM
# MAGIC   _mau_data T2
# MAGIC LEFT JOIN _segmentation_data AS T1 USING(customer_id)
# MAGIC GROUP BY ALL;
# MAGIC
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   _segmentation_analysis;

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Steps:
# MAGIC * create a cell and run %run "/Users/liam.clifford@databricks.com/Liam's Notebook - readGoogleSheet UDF"
# MAGIC * share spreadsheet with service-liam-clifford@project-liam-clifford.iam.gserviceaccount.com as editor
# MAGIC * enter the name of the spreadsheet and the sheet you want to pull data from in the try blocks
# MAGIC * add the workbook id which can be found after /d/ in the sheet url
# MAGIC * for reading from:
# MAGIC   * add the sheet id which can be found in the url after gid=
# MAGIC   * create a temp view name that can be used to query the data from a temp view 
# MAGIC   * specify the cell range you want to pull data from
# MAGIC   * select * from the temp view name to see the data
# MAGIC * for writing to
# MAGIC   * create a dataframe of the data you want to write 
# MAGIC   * create values for the SHEET_NAME and WORKBOOK_ID variables
# MAGIC   * enter the sheet name, workbook id, and dataframe in the refresh_data_in_sheet function
# MAGIC   * specify which row and column to write to

# COMMAND ----------

# MAGIC %run "/Users/liam.clifford@databricks.com/Liam's Notebook - readGoogleSheet UDF"

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Write to google sheets

# COMMAND ----------

metrics_df = spark.sql('''
  SELECT
    *
  FROM
    _segmentation_analysis 
  ORDER BY 1, 2
''')

# COMMAND ----------

try:
  sht = authGoogleSheet("segmentation_analysis")
except:
  print('Workbook not shared w/ service account user. Check spelling of inputted spreadsheet title or share it w/ service account user.')

try:
  worksheet = sht.worksheet(f"segmentation_analysis")
except Exception as e: 
  print('%s' % 'Worksheet Not Found: ')


SHEET_NAME = 'segmentation_data'
WORKBOOK_ID = '1Qgr6VQTAbStR24dKzRn1wpAKwgMpDwEftihWu0GznOk'

refresh_data_in_sheet(
    sheet_name_or_id=SHEET_NAME,
    spark_df=metrics_df,
    workbook_id=WORKBOOK_ID,
    row_number_to_push_into=1,
    column_letter_to_push_into='A'
)