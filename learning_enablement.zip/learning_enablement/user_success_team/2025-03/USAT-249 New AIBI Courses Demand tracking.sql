-- Databricks notebook source
-- MAGIC %md
-- MAGIC **New AIBI Courses Demand tracking**: Demand uptick. There are new courses that launched for AIBI we want to show how the demand uptick is for these new classes. Is there already dashboard we can track?
-- MAGIC
-- MAGIC New AIBI courses, wrapped in training investment program so accounts will be able to request instructor led sessions for free.
-- MAGIC
-- MAGIC - More technical: “AI/BI for Data Analysts” half day class  -> labs, SP/ILT -> instructor readiness follow up. When to transition to this? Sandra timelines 
-- MAGIC
-- MAGIC - Business Users: “AI/BI for Self-service analytics” -> reprise demo, Only SP.
-- MAGIC
-- MAGIC Registration, attendees, completions
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 1. Exploration

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####1.1. Identifying the course_code and sessions_id related to the new courses

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###### 1.1. Get programs related to new courses

-- COMMAND ----------

SELECT
  project_type, -- INTELLIGENCE DATAWAREHOUSING
  academy_session_number AS session_code,  
  form_ilt_name,
  status,
  region AS session_region
FROM
  main.field_learning_enablement.training_operations_ilt_schedule_master
WHERE
  processDate = (SELECT max(processDate) FROM main.field_learning_enablement.training_operations_ilt_schedule_master)
  AND 
  (
    (academy_session_number IN(53804, 54129)) -- Adding manually this session https://databricks.atlassian.net/browse/USAT-254
  )

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###### 1.2. Get list of new courses

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _ai_bi_new_courses
AS
SELECT
  ae.course_id,
  ae.session_code,
  ae.course_code,
  ae.course_name,  
  ae.course_type,  
  ae.enrolled_date,
  ae.completed_date,
  CAST(ae.ended_timestamp AS DATE) AS session_date,
  COUNT(ae.enrolled_date) AS registrations,
  COUNT(ae.completed_date) AS attendees
  -- ae.learner_user_id
FROM 
  main.field_learning_enablement.all_enrollments AS ae
WHERE
  processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.all_enrollments)  
  -- AND (ae.course_id IN(3643, 3478))
  AND course_name IN ('AI/BI for Data Analysts', 'Databricks AI/BI for Self-Service Analytics')
GROUP BY ALL;

SELECT * FROM _ai_bi_new_courses;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####1.2. Checking if there are UE Programs related to the enrollments identified

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###### 2.1. Get the list of UE Programs

-- COMMAND ----------

-- Program overview used as reference from this dashboard
-- https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01eeb55263f11568bc7ad85275e872d3/published?o=2548836972759138

CREATE OR REPLACE TEMPORARY VIEW _ue_program_overview
AS
with nnl as(
    select learner_user_id, course_code, completed_date
    from main.field_learning_enablement.all_learners
    where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    and dataset = 'net new learners'
)


-- Onboarding & HDC ILT
select learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') as sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') as sales_subregion_level_2
from main.team_field_user_enablement.vw_ue_enrolments_ilt
where session_date >= '2024-02-01'
and training_type = 'Public'
and course_type IN ('Half-Day', 'Onboarding')
union

-- self-paced onboarding
select learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, 'Self-Paced' as course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.team_field_user_enablement.vw_ue_enrolments_sp
where completed_date >= '2024-02-01'
union

--private workshops
select learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, 'Workshop' as course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.team_field_user_enablement.vw_ue_enrolments_ilt
where session_date>= '2024-02-01'
and training_type = 'Private'
and provider = 'User Enablement'
union

-- summit
select ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'DAIS' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.course_name like '%DAIS 2024%'
and ae.completed_date >= '2024-02-01'
union


-- World Tour
select ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'DAIWT' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.course_name like '%DAIWT 2024%'
and ae.completed_date >= '2024-02-01'
union

-- Learning Festival Q1 - Q3
select ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'Learning Festival' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
and ae.course_id in (
    1266, -- DEWD
    2268, -- ADEWD
    2307, -- DAWD
    2906, -- DAWD 2024
    2417, -- MLWD
    1522, -- MLIP
    2267, -- GAIEWD 2023
    2726 -- GAIEWD 2024
)
and 
(
    ae.completed_timestamp between '2024-02-29T00:00:00UTC+14' and '2024-03-14T00:00:00UTC-12' -- Q1 FY25
    or 
    ae.completed_timestamp between '2024-07-10T00:00:00UTC+14' and '2024-07-25T00:00:00UTC-12' -- Q2 FY25
    or
    ae.completed_timestamp between '2024-10-10T00:00:00UTC+14' and '2024-11-01T00:00:00UTC-12' -- Q3 FY25
)
union
-- Databricks Academy Labs
 
select ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'Academy Labs' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.completed_date >= '2024-02-01'
and ae.course_code IN (
    select distinct course_code from main.it_training_silver.docebo_subscription_enrollments
    where processDate = (select max(processDate) from main.it_training_silver.docebo_subscription_enrollments)
    and subscription_plan_code = 'DB-ACAD-LABS-SUB-PLAN'
)

union
-- Learning Festival Q4
select * from main.team_field_user_enablement.q4_learning_festival;

SELECT * FROM _ue_program_overview;



-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###### 2.2. Relate the UE programs with AI/BI courses

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _ai_bi_new_courses_with_ue_course_type
AS
WITH _ue_programs_summarized
AS (
  SELECT 
    course_code,
    course_name, 
    course_type,
    COUNT(enrolled_date) AS registrations,
    COUNT(completed_date) AS attendees
  FROM
    _ue_program_overview
  GROUP BY ALL
)

SELECT 
  c.*,
  ue.course_type AS ue_program_course_type
FROM 
  _ai_bi_new_courses AS c
LEFT JOIN
  _ue_programs_summarized AS ue
ON 
  c.course_code = ue.course_code;

SELECT * FROM _ai_bi_new_courses_with_ue_course_type;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###### 2.3. List of programs related to 1k AI/BI Training Program

-- COMMAND ----------

SELECT
  project_type,
  academy_session_number AS session_code,  
  form_ilt_name,
  status,
  region AS session_region
FROM
  main.field_learning_enablement.training_operations_ilt_schedule_master
WHERE
  processDate = (SELECT max(processDate) FROM main.field_learning_enablement.training_operations_ilt_schedule_master)
  AND 
  (
    (training_operations_ilt_schedule_master.project_type = '1k AI/BI Training Program' AND status not ilike 'cancel%')  
    OR (academy_session_number = 53804) -- Adding manually this session https://databricks.atlassian.net/browse/USAT-254
  )

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####1.3. Adding Data from Nadia

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###### 3.1. Data from Nadia

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW temp_course_data AS
SELECT * FROM VALUES
  ('FENG-TECH-SLP-FREE-AIBIFDA-v1', 3708, 'DB Employees - internal', 'Self-paced'),
  ('ACAD-ALL-SLP-FREE-AIBIFDA-v1', 3707, 'whitelisted customer (no prospects)', 'Self-paced'),
  ('ACAD-CUST-SLP-PAID-AIBIFDA-v1', 3702, 'academy labs sub', 'Self-paced'),
  ('ACAD-PART-SLP-PAID-AIBIFDA-v1', 3701, 'partner academy labs', 'Self-paced'),
  ('ACAD-CUST-ILTPUB-PAID-AIBIFDA-v1', 3643, 'public ILT', 'ILT'),
  ('ACAD-CUST-ILTPVT-PAID-AIBIFDA-v1', 3642, 'private ILT', 'ILT')
AS temp_course_data(course_code, code, for, course_type);

SELECT * FROM temp_course_data;

-- COMMAND ----------

SELECT
  T1.*,
  T2.for,
  T2.course_type
FROM
  _ai_bi_new_courses_with_ue_course_type AS T1
LEFT JOIN 
  temp_course_data AS T2 USING(course_code)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 2. Measure the impact of the courses

-- COMMAND ----------


-- CREATE OR REPLACE TABLE ${focus_database_name}.fact_campaign_analysis
-- AS
WITH _nnl as( -- Net New Learners
  SELECT 
    learner_user_id, 
    course_code, 
    completed_date
  FROM 
    main.field_learning_enablement.all_learners
  WHERE 
    processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    AND dataset = 'net new learners'
), _event_registrations
AS (  
  -- =============================================
  -- Description: This CTE calculates the event registrations and attendees for each account, along with the session details.  
  -- =============================================
  SELECT
    T1.processDate
    , T1.account_id
    , T1.course_type 
    , T1.course_id
    , T1.session_code    
    , T1.session_name 
    , T1.course_name
    , T1.session_date
    , COUNT(DISTINCT T1.session_code) AS account_sessions
    , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
    , SUM(CASE WHEN T1.learner_user_id IS NOT NULL THEN 1 END) AS event_net_new_learners
  FROM(
    SELECT 
      ae.processDate,
      ae.course_type,
      ae.course_id,      
      ae.session_code,      
      TRIM(SPLIT_PART(ae.session_name, '|', 3)) AS session_name,
      ae.course_name,
      CAST(ae.ended_timestamp AS DATE) AS session_date,
      ae.updated_account_id AS account_id,
      ae.enrolled_date,
      ae.completed_date,     
      T3.learner_user_id
    FROM 
        main.field_learning_enablement.all_enrollments AS ae
    LEFT JOIN
      _nnl AS T3 USING(learner_user_id, course_code)
    WHERE 
      ae.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)
      AND ae.course_name IN ('AI/BI for Data Analysts', 'Databricks AI/BI for Self-Service Analytics')
  ) AS T1
  GROUP BY ALL 
), _mau_data
AS (
  SELECT
    T1.session_code
    , T1.account_id   
    , MAX(T1.date) max_mau_date 
    , ROUND(AVG(T1.mau_pre_event)) AS mau_pre_event   
    , SUM(T1.mau_01d_post_event) AS mau_post_event
    , SUM(T1.mau_01d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_01d_growth
    , SUM(T1.mau_07d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_07d_growth
    , SUM(T1.mau_14d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_14d_growth
    , SUM(T1.mau_30d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_30d_growth

    , SUM(T1.total_dollars_01d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_01d_growth
    , SUM(T1.total_dollars_07d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_07d_growth
    , SUM(T1.total_dollars_14d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_14d_growth
    , SUM(T1.total_dollars_30d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_30d_growth

    , SUM(T1.wau_01d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_01d_growth
    , SUM(T1.wau_07d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_07d_growth
    , SUM(T1.wau_14d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_14d_growth
    , SUM(T1.wau_30d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_30d_growth

    , SUM(T1.dbsql_users_01d_post_event) - nvl(ROUND(AVG(T1.dbsql_users_pre_event)), 0) AS dbsql_users_01d_growth
    , SUM(T1.dbsql_users_07d_post_event) - nvl(ROUND(AVG(T1.dbsql_users_pre_event)), 0) AS dbsql_users_07d_growth
    , SUM(T1.dbsql_users_14d_post_event) - nvl(ROUND(AVG(T1.dbsql_users_pre_event)), 0) AS dbsql_users_14d_growth
    , SUM(T1.dbsql_users_30d_post_event) - nvl(ROUND(AVG(T1.dbsql_users_pre_event)), 0) AS dbsql_users_30d_growth

    , SUM(T1.dbsql_dollars_01d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_01d_growth
    , SUM(T1.dbsql_dollars_07d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_07d_growth
    , SUM(T1.dbsql_dollars_14d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_14d_growth
    , SUM(T1.dbsql_dollars_30d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_30d_growth    

    , SUM(T1.genie_users_01d_post_event) - nvl(ROUND(AVG(T1.genie_users_pre_event)), 0) AS genie_users_01d_growth
    , SUM(T1.genie_users_07d_post_event) - nvl(ROUND(AVG(T1.genie_users_pre_event)), 0) AS genie_users_07d_growth
    , SUM(T1.genie_users_14d_post_event) - nvl(ROUND(AVG(T1.genie_users_pre_event)), 0) AS genie_users_14d_growth
    , SUM(T1.genie_users_30d_post_event) - nvl(ROUND(AVG(T1.genie_users_pre_event)), 0) AS genie_users_30d_growth

    , SUM(T1.genie_dollars_01d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_01d_growth
    , SUM(T1.genie_dollars_07d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_07d_growth
    , SUM(T1.genie_dollars_14d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_14d_growth
    , SUM(T1.genie_dollars_30d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_30d_growth

    , SUM(T1.lakeview_users_01d_post_event) - nvl(ROUND(AVG(T1.lakeview_users_pre_event)), 0) AS lakeview_users_01d_growth
    , SUM(T1.lakeview_users_07d_post_event) - nvl(ROUND(AVG(T1.lakeview_users_pre_event)), 0) AS lakeview_users_07d_growth
    , SUM(T1.lakeview_users_14d_post_event) - nvl(ROUND(AVG(T1.lakeview_users_pre_event)), 0) AS lakeview_users_14d_growth
    , SUM(T1.lakeview_users_30d_post_event) - nvl(ROUND(AVG(T1.lakeview_users_pre_event)), 0) AS lakeview_users_30d_growth

    , SUM(T1.lakeview_dollars_01d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_01d_growth
    , SUM(T1.lakeview_dollars_07d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_07d_growth
    , SUM(T1.lakeview_dollars_14d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_14d_growth
    , SUM(T1.lakeview_dollars_30d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_30d_growth    
  FROM(
    SELECT
      T1.session_code
      , T2.date
      , T2.customer_id AS account_id      
      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.mau END) AS mau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.mau END) AS mau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.mau END) AS mau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.mau END) AS mau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.mau END) AS mau_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.total_dollars_t28d END) AS total_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.total_dollars_t28d END) AS total_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.total_dollars_t28d END) AS total_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.total_dollars_t28d END) AS total_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.total_dollars_t28d END) AS total_dollars_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.wau END) AS wau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.wau END) AS wau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.wau END) AS wau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.wau END) AS wau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.wau END) AS wau_30d_post_event

      , ROUND(SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.dbsql_users END)) AS dbsql_users_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.dbsql_users END) AS dbsql_users_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.dbsql_users END) AS dbsql_users_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.dbsql_users END) AS dbsql_users_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.dbsql_users END) AS dbsql_users_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.genie_users END) AS genie_users_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.genie_users END) AS genie_users_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.genie_users END) AS genie_users_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.genie_users END) AS genie_users_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.genie_users END) AS genie_users_30d_post_event
      
      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.genie_dollars END) AS genie_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.genie_dollars END) AS genie_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.genie_dollars END) AS genie_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.genie_dollars END) AS genie_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.genie_dollars END) AS genie_dollars_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.lakeview_users END) AS lakeview_users_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.lakeview_users END) AS lakeview_users_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.lakeview_users END) AS lakeview_users_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.lakeview_users END) AS lakeview_users_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.lakeview_users END) AS lakeview_users_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.lakeview_dollars END) AS lakeview_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.lakeview_dollars END) AS lakeview_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.lakeview_dollars END) AS lakeview_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.lakeview_dollars END) AS lakeview_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.lakeview_dollars END) AS lakeview_dollars_30d_post_event
    FROM
      main.field_learning_enablement.fact_daily_mau AS T2
    INNER JOIN
      _event_registrations T1
    ON 
      T2.customer_id = T1.account_id
    GROUP BY ALL
  ) AS T1    
  GROUP BY ALL  
)

SELECT
  T1.processDate
  , T1.session_code  
  , T1.course_type
  , T1.course_id
  , T1.session_name
  , T1.course_name
  , DATE(T1.session_date) AS session_date
  , T1.max_mau_date
  , T1.account_id
  , CASE WHEN T1.account_sessions > 1 THEN T1.account_id END AS accounts_with_multiple_sessions  
  , T2.account_name  
  , T2.business_unit AS bu
  , T2.sales_subregion_level_1 AS bu_1
  , T2.sales_subregion_level_2 AS bu_2
  , T2.sales_subregion_level_3 AS bu_3
  , COUNT(DISTINCT T1.account_id) AS accounts  
  
  , nvl(SUM(T1.event_registrations), 0) AS event_registrations
  , nvl(SUM(T1.event_attendees), 0) AS event_attendees    
  , nvl(SUM(T1.event_net_new_learners), 0) AS event_net_new_learners      

  , SUM(T1.mau_pre_event) AS mau_pre_event  
  , SUM(T1.mau_post_event) AS mau_post_event

  , SUM(T1.mau_01d_growth) AS mau_01d_growth 
  , SUM(T1.mau_07d_growth) AS mau_07d_growth 
  , SUM(T1.mau_14d_growth) AS mau_14d_growth 
  , SUM(T1.mau_30d_growth) AS mau_30d_growth 

  , SUM(T1.total_dollars_01d_growth) AS total_dollars_01d_growth 
  , SUM(T1.total_dollars_07d_growth) AS total_dollars_07d_growth 
  , SUM(T1.total_dollars_14d_growth) AS total_dollars_14d_growth 
  , SUM(T1.total_dollars_30d_growth) AS total_dollars_30d_growth 

  , SUM(T1.mau_07d_net_growth) AS mau_07d_net_growth 
  , SUM(T1.mau_14d_net_growth) AS mau_14d_net_growth 
  , SUM(T1.mau_30d_net_growth) AS mau_30d_net_growth 

  , SUM(T1.wau_01d_growth) AS wau_01d_growth
  , SUM(T1.wau_07d_growth) AS wau_07d_growth
  , SUM(T1.wau_14d_growth) AS wau_14d_growth
  , SUM(T1.wau_30d_growth) AS wau_30d_growth

  , SUM(T1.dbsql_users_01d_growth) AS dbsql_users_01d_growth 
  , SUM(T1.dbsql_users_07d_growth) AS dbsql_users_07d_growth 
  , SUM(T1.dbsql_users_14d_growth) AS dbsql_users_14d_growth 
  , SUM(T1.dbsql_users_30d_growth) AS dbsql_users_30d_growth 

  , SUM(T1.dbsql_dollars_01d_growth) AS dbsql_dollars_01d_growth 
  , SUM(T1.dbsql_dollars_07d_growth) AS dbsql_dollars_07d_growth 
  , SUM(T1.dbsql_dollars_14d_growth) AS dbsql_dollars_14d_growth 
  , SUM(T1.dbsql_dollars_30d_growth) AS dbsql_dollars_30d_growth  

  , SUM(T1.genie_users_01d_growth) AS genie_users_01d_growth 
  , SUM(T1.genie_users_07d_growth) AS genie_users_07d_growth 
  , SUM(T1.genie_users_14d_growth) AS genie_users_14d_growth 
  , SUM(T1.genie_users_30d_growth) AS genie_users_30d_growth 

  , SUM(T1.genie_dollars_01d_growth) AS genie_dollars_01d_growth 
  , SUM(T1.genie_dollars_07d_growth) AS genie_dollars_07d_growth 
  , SUM(T1.genie_dollars_14d_growth) AS genie_dollars_14d_growth 
  , SUM(T1.genie_dollars_30d_growth) AS genie_dollars_30d_growth 

  , SUM(T1.lakeview_users_01d_growth) AS lakeview_users_01d_growth 
  , SUM(T1.lakeview_users_07d_growth) AS lakeview_users_07d_growth 
  , SUM(T1.lakeview_users_14d_growth) AS lakeview_users_14d_growth 
  , SUM(T1.lakeview_users_30d_growth) AS lakeview_users_30d_growth 

  , SUM(T1.lakeview_dollars_01d_growth) AS lakeview_dollars_01d_growth 
  , SUM(T1.lakeview_dollars_07d_growth) AS lakeview_dollars_07d_growth 
  , SUM(T1.lakeview_dollars_14d_growth) AS lakeview_dollars_14d_growth 
  , SUM(T1.lakeview_dollars_30d_growth) AS lakeview_dollars_30d_growth
FROM(
  SELECT   
    T1.processDate
    , T1.account_id
    , T1.course_type  
    , T1.course_id  
    , T1.session_code    
    , T1.session_name
    , T1.course_name
    , T1.session_date
    
    , SUM(T1.account_sessions) OVER(PARTITION BY T1.account_id) AS account_sessions

    , T1.event_registrations
    , T1.event_attendees
    , T1.event_net_new_learners

    , T2.max_mau_date

    , T2.mau_pre_event
    , T2.mau_post_event
    
    , T2.mau_01d_growth
    , T2.mau_07d_growth
    , T2.mau_14d_growth
    , T2.mau_30d_growth

    , T2.total_dollars_01d_growth
    , T2.total_dollars_07d_growth
    , T2.total_dollars_14d_growth
    , T2.total_dollars_30d_growth

    , nvl(T2.mau_07d_growth, 0) - nvl(T2.mau_01d_growth, 0) AS mau_07d_net_growth 
    , nvl(T2.mau_14d_growth, 0) - nvl(T2.mau_07d_growth, 0) AS mau_14d_net_growth 
    , nvl(T2.mau_30d_growth, 0) - nvl(T2.mau_14d_growth, 0) AS mau_30d_net_growth

    , T2.wau_01d_growth
    , T2.wau_07d_growth
    , T2.wau_14d_growth
    , T2.wau_30d_growth

    , T2.dbsql_users_01d_growth
    , T2.dbsql_users_07d_growth
    , T2.dbsql_users_14d_growth
    , T2.dbsql_users_30d_growth

    , T2.dbsql_dollars_01d_growth
    , T2.dbsql_dollars_07d_growth
    , T2.dbsql_dollars_14d_growth
    , T2.dbsql_dollars_30d_growth

    , T2.genie_users_01d_growth
    , T2.genie_users_07d_growth
    , T2.genie_users_14d_growth
    , T2.genie_users_30d_growth

    , T2.genie_dollars_01d_growth
    , T2.genie_dollars_07d_growth
    , T2.genie_dollars_14d_growth
    , T2.genie_dollars_30d_growth  

    , T2.lakeview_users_01d_growth
    , T2.lakeview_users_07d_growth
    , T2.lakeview_users_14d_growth
    , T2.lakeview_users_30d_growth

    , T2.lakeview_dollars_01d_growth
    , T2.lakeview_dollars_07d_growth
    , T2.lakeview_dollars_14d_growth
    , T2.lakeview_dollars_30d_growth
  FROM 
    _event_registrations T1
  LEFT JOIN 
    _mau_data T2 USING(account_id, session_code)
) AS T1
LEFT JOIN
  main.gtm_data.core_accounts_curated as T2 USING(account_id)
WHERE 
  T1.account_id <> '0016100000ZcnkGAAR' -- EXCLUDING DATABRICKS ACCOUNT
GROUP BY ALL

-- COMMAND ----------

WITH _nnl as( -- Net New Learners
  SELECT 
    learner_user_id, 
    course_code, 
    completed_date
  FROM 
    main.field_learning_enablement.all_learners
  WHERE 
    processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    AND dataset = 'net new learners'
) 
-- =============================================
-- Description: This CTE calculates the event registrations and attendees for each account, along with the session details.  
-- =============================================
SELECT
  T1.processDate
  , T1.account_id
  , T1.course_type 
  , T1.course_id
  , T1.session_code    
  , T1.session_name 
  , T1.course_name
  , T1.session_date
  , COUNT(DISTINCT T1.session_code) AS account_sessions
  , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
  , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
  , SUM(CASE WHEN T1.learner_user_id IS NOT NULL THEN 1 END) AS event_net_new_learners
FROM(
  SELECT 
    ae.processDate,
    ae.course_type,
    ae.course_id,      
    ae.session_code,      
    TRIM(SPLIT_PART(ae.session_name, '|', 3)) AS session_name,
    ae.course_name,
    CAST(ae.ended_timestamp AS DATE) AS session_date,
    ae.updated_account_id AS account_id,
    ae.enrolled_date,
    ae.completed_date,     
    T3.learner_user_id
  FROM 
      main.field_learning_enablement.all_enrollments AS ae
  INNER JOIN
    _nnl AS T3 USING(learner_user_id, course_code)
  WHERE 
    ae.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)
    AND ae.course_name IN ('AI/BI for Data Analysts')
) AS T1
GROUP BY ALL 