-- Databricks notebook source
WITH nnl as(
  SELECT
    learner_user_id,
    course_code,
    completed_date
  FROM
    main.field_learning_enablement.all_learners
  WHERE
    processDate = (SELECT max(processDate) FROM main.field_learning_enablement.all_learners)
    AND dataset = 'net new learners'
) -- Learning Festival
SELECT
  date_Trunc('month', ae.completed_timestamp)::DATE AS completed_month,
  ae.updated_account_id,
  ae.updated_account_name,
  COUNT(ae.learner_user_id) nnl
FROM
  main.field_learning_enablement.all_enrollments ae
  join nnl on ae.learner_user_id = nnl.learner_user_id
  AND ae.course_code = nnl.course_code
WHERE
  ae.processDate = (SELECT max(processDate) FROM main.field_learning_enablement.all_enrollments)
  AND ae.learner_branch_code not in('DBK_EMP') -- Exclude internal employee enrollments
  AND
  (
    (
      ae.course_id IN (
        1266, -- DEWD
        2268, -- ADEWD
        2307, -- DAWD
        2906, -- DAWD 2024
        2417, -- MLWD
        1522, -- MLIP
        2267, -- GAIEWD 2023
        2726 -- GAIEWD 2024
      ) AND ae.completed_timestamp BETWEEN '2024-10-10T00:00:00UTC+14' AND '2024-11-01T00:00:00UTC-12' -- Q3 FY25
    )
    OR 
    (
      ae.course_id IN (
        -- Full Courses
        1266,    -- DEWD
        2268,    -- ADEWD
        2307,    -- DAWD
        2906,    -- DAWD 2024
        2417,    -- MLWD
        1522,
        -- MLIP
        2267,    -- GAIEWD 2023
        2726,    -- GAIEWD 2024
        -- DE Modules
        2963,    -- Data Ingestion
        1365,    -- Workloads
        2971,    -- DLT
        3144,    -- Governance
        -- MLWD Modules
        2343,    -- Data Prep
        2390,    -- ML Model Dev
        2395,    -- ML Model Dep
        2400,    --ML Ops
        -- Gen AI
        2706,    -- Gen AI Solution Dev
        2716,    -- Gen AI App Dev
        2717,    -- Gen AI App Eval
        2713,    -- Gen AI App Deployment
        -- AMLWD Modules
        3417,    -- ML at Scale
        3508     -- Advanced MLOPs
      ) AND ae.completed_timestamp between '2025-01-15T00:00:00UTC+14' AND '2025-02-01T00:00:00UTC-12' -- Q4 FY25
    )
  )  
GROUP BY ALL

-- COMMAND ----------

WITH nnl as(
    select learner_user_id, course_code, completed_date, course_name
    from main.field_learning_enablement.all_learners
    where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    and dataset = 'net new learners'
)

-- Learning Festival

SELECT 
  date_Trunc('month', ae.completed_timestamp)::DATE AS completed_month,
  ae.updated_account_id,
  ae.updated_account_name,
  COUNT(ae.learner_user_id) nnl
FROM 
  main.field_learning_enablement.all_enrollments ae
LEFT JOIN
  nnl
ON
  ae.learner_user_id = nnl.learner_user_id and 
  ae.course_code = nnl.course_code
WHERE
  ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
  and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
  and ae.course_id in (
    1266, -- DEWD
    2268, -- ADEWD
    2307, -- DAWD
    2906, -- DAWD 2024
    2417, -- MLWD
    1522, -- MLIP
    2267, -- GAIEWD 2023
    2726 -- GAIEWD 2024
  ) and ae.completed_timestamp between '2024-10-10T00:00:00UTC+14' and '2024-11-01T00:00:00UTC-12' -- Q3 FY25
GROUP BY ALL

-- COMMAND ----------

WITH nnl as(
  SELECT
    learner_user_id,
    course_code,
    completed_date
  FROM
    main.field_learning_enablement.all_learners
  WHERE
    processDate = (SELECT max(processDate) FROM main.field_learning_enablement.all_learners)
    AND dataset = 'net new learners'
) -- Learning Festival
SELECT
  date_Trunc('month', ae.completed_timestamp)::DATE AS completed_month,
  ae.updated_account_id,
  ae.updated_account_name,
  COUNT(ae.learner_user_id) nnl
FROM
  main.field_learning_enablement.all_enrollments ae
  join nnl on ae.learner_user_id = nnl.learner_user_id
  AND ae.course_code = nnl.course_code
WHERE
  ae.processDate = (SELECT max(processDate) FROM main.field_learning_enablement.all_enrollments)
  AND ae.learner_branch_code not in('DBK_EMP') -- Exclude internal employee enrollments
  AND ae.course_id in (
    -- Full Courses
    1266,    -- DEWD
    2268,    -- ADEWD
    2307,    -- DAWD
    2906,    -- DAWD 2024
    2417,    -- MLWD
    1522,
    -- MLIP
    2267,    -- GAIEWD 2023
    2726,    -- GAIEWD 2024
    -- DE Modules
    2963,    -- Data Ingestion
    1365,    -- Workloads
    2971,    -- DLT
    3144,    -- Governance
    -- MLWD Modules
    2343,    -- Data Prep
    2390,    -- ML Model Dev
    2395,    -- ML Model Dep
    2400,    --ML Ops
    -- Gen AI
    2706,    -- Gen AI Solution Dev
    2716,    -- Gen AI App Dev
    2717,    -- Gen AI App Eval
    2713,    -- Gen AI App Deployment
    -- AMLWD Modules
    3417,    -- ML at Scale
    3508     -- Advanced MLOPs
  )
  AND ae.completed_timestamp between '2025-01-15T00:00:00UTC+14' AND '2025-02-01T00:00:00UTC-12' -- Q4 FY25
GROUP BY ALL

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _ue_programs_enrollments
AS
with nnl as(
    select learner_user_id, course_code, completed_date
    from main.field_learning_enablement.all_learners
    where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    and dataset = 'net new learners'
)


-- Onboarding & HDC ILT
select learner_user_id, course_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, course_type, business_unit, IFNULL(sales_subregion_level_1,'Unknown'), IFNULL(sales_subregion_level_2,'Unknown'), updated_account_id
from main.team_field_user_enablement.vw_ue_enrolments_ilt
where session_date >= '2024-02-01'
and training_type = 'Public'
and course_type IN ('Half-Day', 'Onboarding')
union

-- self-paced onboarding
select learner_user_id, course_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, 'Self-Paced' as course_type, business_unit, IFNULL(sales_subregion_level_1,'Unknown'), IFNULL(sales_subregion_level_2,'Unknown'), account_id
from main.team_field_user_enablement.vw_ue_enrolments_sp
where completed_date >= '2024-02-01'
union

--private workshops
select learner_user_id, course_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, 'Workshop' as course_type, business_unit, IFNULL(sales_subregion_level_1,'Unknown'), IFNULL(sales_subregion_level_2,'Unknown'), updated_account_id
from main.team_field_user_enablement.vw_ue_enrolments_ilt
where session_date>= '2024-02-01'
and training_type = 'Private'
and provider = 'User Enablement'
union

-- summit
select ae.learner_user_id, ae.course_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'DAIS' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown'), IFNULL(ae.sales_subregion_level_2,'Unknown'), updated_account_id
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.course_name like '%DAIS 2024%'
and ae.completed_date >= '2024-02-01'
union


-- World Tour
select ae.learner_user_id, ae.course_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'DAIWT' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown'), IFNULL(ae.sales_subregion_level_2,'Unknown'), updated_account_id
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.course_name like '%DAIWT 2024%'
and ae.completed_date >= '2024-02-01'
union

-- Learning Festival
select ae.learner_user_id, ae.course_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'Learning Festival' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown'), IFNULL(ae.sales_subregion_level_2,'Unknown'), updated_account_id
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
and ae.course_id in (
    1266, -- DEWD
    2268, -- ADEWD
    2307, -- DAWD
    2906, -- DAWD 2024
    2417, -- MLWD
    1522, -- MLIP
    2267, -- GAIEWD 2023
    2726 -- GAIEWD 2024
)
and 
(
    ae.completed_timestamp between '2024-02-29T00:00:00UTC+14' and '2024-03-14T00:00:00UTC-12' -- Q1 FY25
    or 
    ae.completed_timestamp between '2024-07-10T00:00:00UTC+14' and '2024-07-25T00:00:00UTC-12' -- Q2 FY25
    or
    ae.completed_timestamp between '2024-10-10T00:00:00UTC+14' and '2024-11-01T00:00:00UTC-12' -- Q3 FY25
)
union
-- Databricks Academy Labs
 
select ae.learner_user_id, ae.course_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'Academy Labs' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown'), IFNULL(ae.sales_subregion_level_2,'Unknown'), updated_account_id
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.completed_date >= '2024-02-01'
and ae.course_code IN (
    select distinct course_code from main.it_training_silver.docebo_subscription_enrollments
    where processDate = (select max(processDate) from main.it_training_silver.docebo_subscription_enrollments)
    and subscription_plan_code = 'DB-ACAD-LABS-SUB-PLAN'
);

-- COMMAND ----------

SELECT * FROM _ue_programs_enrollments

-- COMMAND ----------

WITH _ue_programs_enrollments AS (
  SELECT
    date_Trunc('month', T1.completed_date) AS completed_month,
    T1.updated_account_id AS customer_id,
    T1.course_type
  FROM
    _ue_programs_enrollments T1
), _new_mau
AS (
  SELECT
    T1.month,
    T1.customer_id,
    COUNT(DISTINCT T1.user_id) AS new_mau
  FROM
    main.field_self_service.silver_monthly_mau T1
  WHERE
    T1.month >= '2024-02-01'
    AND T1.user_status = 'New' 
    AND T1.customer_id IN (SELECT DISTINCT customer_id FROM _ue_programs_enrollments)
  GROUP BY ALL
)

SELECT DISTINCT
  T1.*,  
  T2.course_type
FROM 
  _new_mau AS T1
INNER JOIN
  _ue_programs_enrollments AS T2
ON 
  T1.month = T2.completed_month
  AND T1.customer_id = T2.customer_id
WHERE 
  T1.month >= '2024-08-01'
ORDER BY T1.customer_id, T1.month