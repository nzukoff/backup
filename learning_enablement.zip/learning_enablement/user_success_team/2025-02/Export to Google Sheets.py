# Databricks notebook source
# MAGIC %md
# MAGIC #### 2. Install Required Libraries

# COMMAND ----------

# MAGIC %pip install pandas google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client