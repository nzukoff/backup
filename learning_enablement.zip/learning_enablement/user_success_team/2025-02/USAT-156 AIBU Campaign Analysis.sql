-- Databricks notebook source
-- MAGIC %md
-- MAGIC ......................................................................................... \
-- MAGIC ......................................................................................... \
-- MAGIC **Request Name:**    Measuring the growth considering 1d before and after the event  \
-- MAGIC **Description:**     Calculate the growth after the session using as baseline the MAU number before the session_date, and comparing against the MAU after the session_date \
-- MAGIC **Jira Ticket:**     [USAT-152](https://databricks.atlassian.net/browse/USAT-152) \
-- MAGIC **SLA:**     No SLA \
-- MAGIC ......................................................................................... \
-- MAGIC ......................................................................................... 
-- MAGIC
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### USAT-211 - Add  DBSQL usage, jobs usage, genie usage pre/post event. + WAU

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### USAT-217 - Adding new filters: session_date filtering by range, session_region and BU+2

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
SELECT
  project_type,
  academy_session_number AS session_code,  
  form_ilt_name,
  status,
  region AS session_region
FROM
  main.field_learning_enablement.training_operations_ilt_schedule_master
WHERE
  processDate = (
    SELECT
      max(processDate)
    FROM
      main.field_learning_enablement.training_operations_ilt_schedule_master
  )
  AND training_operations_ilt_schedule_master.project_type = '1k AI/BI Training Program'
  AND status not ilike 'cancel%';

/*

*/
CREATE OR REPLACE TABLE ${focus_database_name}.fact_campaign_analysis
AS
WITH _nnl as( -- Net New Learners
  SELECT 
    learner_user_id, 
    course_code, 
    completed_date
  FROM 
    main.field_learning_enablement.all_learners
  WHERE 
    processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    AND dataset = 'net new learners'
), _event_registrations
AS (  
  -- =============================================
  -- Description: This CTE calculates the event registrations and attendees for each account, along with the session details.  
  -- =============================================
  SELECT
    T1.processDate
    , T1.account_id      
    , T1.program 
    , T1.session_code
    , T1.session_region
    , T1.session_name 
    , T1.session_date
    , COUNT(DISTINCT T1.session_code) AS account_sessions
    , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
    , SUM(CASE WHEN T1.learner_user_id IS NOT NULL THEN 1 END) AS event_net_new_learners
  FROM(
    SELECT 
      T1.processDate,
      'ILT' AS program,
      T1.session_code,
      T2.session_region,
      TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name,
      CAST(T1.ended_timestamp AS DATE) AS session_date,
      T1.updated_account_id AS account_id,
      T1.enrolled_date,
      T1.completed_date,     
      T3.learner_user_id
    FROM 
        main.field_learning_enablement.all_enrollments AS T1
    INNER JOIN
      _account_sessions AS T2 USING(session_code)
    LEFT JOIN
      _nnl AS T3 USING(learner_user_id, course_code)
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)      

    UNION ALL

    SELECT
      ae.processDate,
      u.program,
      STRING(u.id_coupon) AS session_code,
      NULL AS session_region,
      u.airtable_account_name AS session_name,
      u.event_date AS session_date,
      ae.updated_account_id AS account_id,
      ae.enrolled_date,
      ae.completed_date, 
      _nnl.learner_user_id
    FROM
      main.team_field_user_enablement.vw_coupon_usage u
    LEFT JOIN
      main.it_training_silver.docebo_subscription_enrollments e
    ON
      e.transaction_id = u.subscription_trans_id
      AND e.learner_user_id = u.userID
      AND e.processDate = (SELECT max(processDate) FROM main.it_training_silver.docebo_subscription_enrollments)
    LEFT JOIN
      main.field_learning_enablement.all_enrollments ae
    ON
      ae.course_id = e.course_id
      AND ae.learner_user_id = e.learner_user_id
      AND ae.enrolled_date between u.subStartDAre and u.SubEndDate
      AND ae.processDate = (SELECT max(processDate) FROM main.field_learning_enablement.all_enrollments)
    LEFT JOIN
      _nnl 
    ON 
      ae.learner_user_id = _nnl.learner_user_id
      AND ae.course_code = _nnl.course_code         
    WHERE
      u.program = 'Hybrid Days'      
  ) AS T1
  GROUP BY ALL 
), _mau_data
AS (
  SELECT
    T1.session_code
    , T1.account_id   
    , MAX(T1.date) max_mau_date 
    , ROUND(AVG(T1.mau_pre_event)) AS mau_pre_event   
    , SUM(T1.mau_01d_post_event) AS mau_post_event
    , SUM(T1.mau_01d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_01d_growth
    , SUM(T1.mau_07d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_07d_growth
    , SUM(T1.mau_14d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_14d_growth
    , SUM(T1.mau_30d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_30d_growth

    , SUM(T1.total_dollars_01d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_01d_growth
    , SUM(T1.total_dollars_07d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_07d_growth
    , SUM(T1.total_dollars_14d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_14d_growth
    , SUM(T1.total_dollars_30d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_30d_growth

    , SUM(T1.wau_01d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_01d_growth
    , SUM(T1.wau_07d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_07d_growth
    , SUM(T1.wau_14d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_14d_growth
    , SUM(T1.wau_30d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_30d_growth

    , SUM(T1.dbsql_users_01d_post_event) - nvl(ROUND(AVG(T1.dbsql_users_pre_event)), 0) AS dbsql_users_01d_growth
    , SUM(T1.dbsql_users_07d_post_event) - nvl(ROUND(AVG(T1.dbsql_users_pre_event)), 0) AS dbsql_users_07d_growth
    , SUM(T1.dbsql_users_14d_post_event) - nvl(ROUND(AVG(T1.dbsql_users_pre_event)), 0) AS dbsql_users_14d_growth
    , SUM(T1.dbsql_users_30d_post_event) - nvl(ROUND(AVG(T1.dbsql_users_pre_event)), 0) AS dbsql_users_30d_growth

    , SUM(T1.dbsql_dollars_01d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_01d_growth
    , SUM(T1.dbsql_dollars_07d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_07d_growth
    , SUM(T1.dbsql_dollars_14d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_14d_growth
    , SUM(T1.dbsql_dollars_30d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_30d_growth    

    , SUM(T1.genie_users_01d_post_event) - nvl(ROUND(AVG(T1.genie_users_pre_event)), 0) AS genie_users_01d_growth
    , SUM(T1.genie_users_07d_post_event) - nvl(ROUND(AVG(T1.genie_users_pre_event)), 0) AS genie_users_07d_growth
    , SUM(T1.genie_users_14d_post_event) - nvl(ROUND(AVG(T1.genie_users_pre_event)), 0) AS genie_users_14d_growth
    , SUM(T1.genie_users_30d_post_event) - nvl(ROUND(AVG(T1.genie_users_pre_event)), 0) AS genie_users_30d_growth

    , SUM(T1.genie_dollars_01d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_01d_growth
    , SUM(T1.genie_dollars_07d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_07d_growth
    , SUM(T1.genie_dollars_14d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_14d_growth
    , SUM(T1.genie_dollars_30d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_30d_growth

    , SUM(T1.lakeview_users_01d_post_event) - nvl(ROUND(AVG(T1.lakeview_users_pre_event)), 0) AS lakeview_users_01d_growth
    , SUM(T1.lakeview_users_07d_post_event) - nvl(ROUND(AVG(T1.lakeview_users_pre_event)), 0) AS lakeview_users_07d_growth
    , SUM(T1.lakeview_users_14d_post_event) - nvl(ROUND(AVG(T1.lakeview_users_pre_event)), 0) AS lakeview_users_14d_growth
    , SUM(T1.lakeview_users_30d_post_event) - nvl(ROUND(AVG(T1.lakeview_users_pre_event)), 0) AS lakeview_users_30d_growth

    , SUM(T1.lakeview_dollars_01d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_01d_growth
    , SUM(T1.lakeview_dollars_07d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_07d_growth
    , SUM(T1.lakeview_dollars_14d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_14d_growth
    , SUM(T1.lakeview_dollars_30d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_30d_growth    
  FROM(
    SELECT
      T1.session_code
      , T2.date
      , T2.customer_id AS account_id      
      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.mau END) AS mau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.mau END) AS mau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.mau END) AS mau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.mau END) AS mau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.mau END) AS mau_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.total_dollars_t28d END) AS total_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.total_dollars_t28d END) AS total_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.total_dollars_t28d END) AS total_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.total_dollars_t28d END) AS total_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.total_dollars_t28d END) AS total_dollars_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.wau END) AS wau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.wau END) AS wau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.wau END) AS wau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.wau END) AS wau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.wau END) AS wau_30d_post_event

      , ROUND(SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.dbsql_users END)) AS dbsql_users_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.dbsql_users END) AS dbsql_users_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.dbsql_users END) AS dbsql_users_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.dbsql_users END) AS dbsql_users_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.dbsql_users END) AS dbsql_users_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.genie_users END) AS genie_users_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.genie_users END) AS genie_users_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.genie_users END) AS genie_users_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.genie_users END) AS genie_users_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.genie_users END) AS genie_users_30d_post_event
      
      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.genie_dollars_t28d END) AS genie_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.genie_dollars_t28d END) AS genie_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.genie_dollars_t28d END) AS genie_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.genie_dollars_t28d END) AS genie_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.genie_dollars_t28d END) AS genie_dollars_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.lakeview_users END) AS lakeview_users_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.lakeview_users END) AS lakeview_users_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.lakeview_users END) AS lakeview_users_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.lakeview_users END) AS lakeview_users_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.lakeview_users END) AS lakeview_users_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.lakeview_dollars_t28d END) AS lakeview_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.lakeview_dollars_t28d END) AS lakeview_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.lakeview_dollars_t28d END) AS lakeview_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.lakeview_dollars_t28d END) AS lakeview_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.lakeview_dollars_t28d END) AS lakeview_dollars_30d_post_event
    FROM
      ${focus_database_name}.fact_daily_mau AS T2
    INNER JOIN
      _event_registrations T1
    ON 
      T2.customer_id = T1.account_id
    GROUP BY ALL
  ) AS T1    
  GROUP BY ALL  
)

SELECT
  T1.processDate
  , T1.session_code
  , T1.session_region
  , T1.program
  , T1.session_name
  , DATE(T1.session_date) AS session_date
  , T1.max_mau_date
  , T1.account_id
  , CASE WHEN T1.account_sessions > 1 THEN T1.account_id END AS accounts_with_multiple_sessions  
  , T2.account_name
  , T2.business_unit AS bu
  , T2.sales_subregion_level_1 AS bu_1
  , T2.sales_subregion_level_2 AS bu_2
  , T2.sales_subregion_level_3 AS bu_3
  , COUNT(DISTINCT T1.account_id) AS accounts  
  
  , nvl(SUM(T1.event_registrations), 0) AS event_registrations
  , nvl(SUM(T1.event_attendees), 0) AS event_attendees    
  , nvl(SUM(T1.event_net_new_learners), 0) AS event_net_new_learners      

  , SUM(T1.mau_pre_event) AS mau_pre_event  
  , SUM(T1.mau_post_event) AS mau_post_event

  , SUM(T1.mau_01d_growth) AS mau_01d_growth 
  , SUM(T1.mau_07d_growth) AS mau_07d_growth 
  , SUM(T1.mau_14d_growth) AS mau_14d_growth 
  , SUM(T1.mau_30d_growth) AS mau_30d_growth 

  , SUM(T1.total_dollars_01d_growth) AS total_dollars_01d_growth 
  , SUM(T1.total_dollars_07d_growth) AS total_dollars_07d_growth 
  , SUM(T1.total_dollars_14d_growth) AS total_dollars_14d_growth 
  , SUM(T1.total_dollars_30d_growth) AS total_dollars_30d_growth 

  , SUM(T1.mau_07d_net_growth) AS mau_07d_net_growth 
  , SUM(T1.mau_14d_net_growth) AS mau_14d_net_growth 
  , SUM(T1.mau_30d_net_growth) AS mau_30d_net_growth 

  , SUM(T1.wau_01d_growth) AS wau_01d_growth
  , SUM(T1.wau_07d_growth) AS wau_07d_growth
  , SUM(T1.wau_14d_growth) AS wau_14d_growth
  , SUM(T1.wau_30d_growth) AS wau_30d_growth

  , SUM(T1.dbsql_users_01d_growth) AS dbsql_users_01d_growth 
  , SUM(T1.dbsql_users_07d_growth) AS dbsql_users_07d_growth 
  , SUM(T1.dbsql_users_14d_growth) AS dbsql_users_14d_growth 
  , SUM(T1.dbsql_users_30d_growth) AS dbsql_users_30d_growth 

  , SUM(T1.dbsql_dollars_01d_growth) AS dbsql_dollars_01d_growth 
  , SUM(T1.dbsql_dollars_07d_growth) AS dbsql_dollars_07d_growth 
  , SUM(T1.dbsql_dollars_14d_growth) AS dbsql_dollars_14d_growth 
  , SUM(T1.dbsql_dollars_30d_growth) AS dbsql_dollars_30d_growth  

  , SUM(T1.genie_users_01d_growth) AS genie_users_01d_growth 
  , SUM(T1.genie_users_07d_growth) AS genie_users_07d_growth 
  , SUM(T1.genie_users_14d_growth) AS genie_users_14d_growth 
  , SUM(T1.genie_users_30d_growth) AS genie_users_30d_growth 

  , SUM(T1.genie_dollars_01d_growth) AS genie_dollars_01d_growth 
  , SUM(T1.genie_dollars_07d_growth) AS genie_dollars_07d_growth 
  , SUM(T1.genie_dollars_14d_growth) AS genie_dollars_14d_growth 
  , SUM(T1.genie_dollars_30d_growth) AS genie_dollars_30d_growth 

  , SUM(T1.lakeview_users_01d_growth) AS lakeview_users_01d_growth 
  , SUM(T1.lakeview_users_07d_growth) AS lakeview_users_07d_growth 
  , SUM(T1.lakeview_users_14d_growth) AS lakeview_users_14d_growth 
  , SUM(T1.lakeview_users_30d_growth) AS lakeview_users_30d_growth 

  , SUM(T1.lakeview_dollars_01d_growth) AS lakeview_dollars_01d_growth 
  , SUM(T1.lakeview_dollars_07d_growth) AS lakeview_dollars_07d_growth 
  , SUM(T1.lakeview_dollars_14d_growth) AS lakeview_dollars_14d_growth 
  , SUM(T1.lakeview_dollars_30d_growth) AS lakeview_dollars_30d_growth
FROM(
  SELECT   
    T1.processDate
    , T1.account_id
    , T1.program    
    , T1.session_code
    , T1.session_region
    , T1.session_name
    , T1.session_date
    
    , SUM(T1.account_sessions) OVER(PARTITION BY T1.account_id) AS account_sessions

    , T1.event_registrations
    , T1.event_attendees
    , T1.event_net_new_learners

    , T2.max_mau_date

    , T2.mau_pre_event
    , T2.mau_post_event
    
    , T2.mau_01d_growth
    , T2.mau_07d_growth
    , T2.mau_14d_growth
    , T2.mau_30d_growth

    , T2.total_dollars_01d_growth
    , T2.total_dollars_07d_growth
    , T2.total_dollars_14d_growth
    , T2.total_dollars_30d_growth

    , nvl(T2.mau_07d_growth, 0) - nvl(T2.mau_01d_growth, 0) AS mau_07d_net_growth 
    , nvl(T2.mau_14d_growth, 0) - nvl(T2.mau_07d_growth, 0) AS mau_14d_net_growth 
    , nvl(T2.mau_30d_growth, 0) - nvl(T2.mau_14d_growth, 0) AS mau_30d_net_growth

    , T2.wau_01d_growth
    , T2.wau_07d_growth
    , T2.wau_14d_growth
    , T2.wau_30d_growth

    , T2.dbsql_users_01d_growth
    , T2.dbsql_users_07d_growth
    , T2.dbsql_users_14d_growth
    , T2.dbsql_users_30d_growth

    , T2.dbsql_dollars_01d_growth
    , T2.dbsql_dollars_07d_growth
    , T2.dbsql_dollars_14d_growth
    , T2.dbsql_dollars_30d_growth

    , T2.genie_users_01d_growth
    , T2.genie_users_07d_growth
    , T2.genie_users_14d_growth
    , T2.genie_users_30d_growth

    , T2.genie_dollars_01d_growth
    , T2.genie_dollars_07d_growth
    , T2.genie_dollars_14d_growth
    , T2.genie_dollars_30d_growth  

    , T2.lakeview_users_01d_growth
    , T2.lakeview_users_07d_growth
    , T2.lakeview_users_14d_growth
    , T2.lakeview_users_30d_growth

    , T2.lakeview_dollars_01d_growth
    , T2.lakeview_dollars_07d_growth
    , T2.lakeview_dollars_14d_growth
    , T2.lakeview_dollars_30d_growth
  FROM 
    _event_registrations T1
  LEFT JOIN 
    _mau_data T2 USING(account_id, session_code)
) AS T1
LEFT JOIN
  main.gtm_data.core_accounts_curated as T2 USING(account_id)
WHERE 
  T1.account_id <> '0016100000ZcnkGAAR' -- EXCLUDING DATABRICKS ACCOUNT
GROUP BY ALL

-- COMMAND ----------

SELECT 
  date_trunc('MONTH', T1.date)::date as month  
  , T1.date
  , T1.customer_id        
  , T1.customer_name  
  , SUM(CASE WHEN lakeview_num_events_t28d > 0 THEN 1 END) as lakeview_users
  , SUM(lakeview_dollars_t28d) AS lakeview_dollars_t28d  
FROM 
  main.data_product_features.user_metrics AS T1
WHERE 
  salesforce_account_id = '00161000011ZEd7AAG'
  AND ds BETWEEN DATE_SUB('2024-12-12', 90) AND DATE_ADD('2024-12-12', 01)  
GROUP BY ALL;