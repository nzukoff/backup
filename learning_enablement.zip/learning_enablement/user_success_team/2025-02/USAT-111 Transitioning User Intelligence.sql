-- Databricks notebook source
-- DBTITLE 1,Top 10 Accounts by Avg. $DBUs per users
--  Expected valid values for :table_to_query are main.field_learning_enablement.user_consumption and main.field_learning_enablement.fact_mau_users
-- 
--

WITH _initial
AS (
    SELECT 
        customer_id,
        CASE :metric_to_sort
            WHEN 'consumption' THEN try_divide(sum(identifier(iff(:metric_to_sort = 'consumption', 'dbu_dollars', 'mau'))), sum(mau))
            ELSE sum(identifier(iff(:metric_to_sort = 'consumption', 'dbu_dollars', :metric_to_sort))) END 
        AS sorting_metric
    FROM 
        identifier(:table_to_query)
    WHERE 
        relative_month_period = :month_period
    GROUP BY ALL
    ORDER BY sorting_metric DESC
    LIMIT 10
)

SELECT 
    T1.relative_month_period,
    T1.month,
    T1.bu,
    T1.bu_1,
    T1.bu_2,
    T1.bu_3,    
    T1.account_name,    
    CASE :metric_to_sort
        WHEN 'consumption' THEN try_divide(sum(identifier(iff(:metric_to_sort = 'consumption', 'dbu_dollars', 'mau'))), sum(mau))
        ELSE sum(identifier(iff(:metric_to_sort = 'consumption', 'dbu_dollars', :metric_to_sort))) END 
    AS sorting_metric
FROM 
    identifier(:table_to_query) AS T1
INNER JOIN _initial AS T2 USING (customer_id)
GROUP BY ALL
ORDER BY T1.month DESC, sorting_metric DESC;