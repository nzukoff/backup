# Databricks notebook source
# MAGIC %md
# MAGIC **Learning Festival - Difference in Difference Measurement**
# MAGIC
# MAGIC Request received from Suna for generating the difference in difference analysis for the Virtual Learning Festival.
# MAGIC
# MAGIC Due to limitations on the data, we will proceed with calculating the impact for the Virtual Learning Festival Q4 FY25 
# MAGIC
# MAGIC Using the following dashboard as reference: [User Enablement - Virtual Learning Festival Q4 FY25](https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01efb09b3db1156fb287a3701d05a8b4/published?o=2548836972759138)
# MAGIC
# MAGIC The impact will be measured comparing 
# MAGIC - Average numbers on each week before the event against the average on the event period
# MAGIC - Average numbers on each week post the event against the average on the event period
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### 1- Get the Learning Festival participants.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### References
# MAGIC - [Databricks Learning Festival (Virtual): 15 January - 31 January 2025](https://community.databricks.com/t5/events/databricks-learning-festival-virtual-15-january-31-january-2025/ec-p/103467)
# MAGIC - [User Enablement - Virtual Learning Festival Q4 FY25](https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01efb09b3db1156fb287a3701d05a8b4/published?o=2548836972759138)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival
# MAGIC AS
# MAGIC WITH _partner
# MAGIC AS (
# MAGIC   SELECT 
# MAGIC     * 
# MAGIC   FROM 
# MAGIC     main.field_learning_enablement.partner_domains_accounts
# MAGIC   WHERE 
# MAGIC     processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.partner_domains_accounts)
# MAGIC ), _initial
# MAGIC AS (
# MAGIC -- Learning Festival
# MAGIC SELECT
# MAGIC   ae.updated_ultimate_parent_account_id,
# MAGIC   ae.updated_account_id,
# MAGIC   ae.learner_user_id, 
# MAGIC   ae.updated_account_name , 
# MAGIC   CASE
# MAGIC       when ae.course_id in (1266, 2963, 1365, 2971, 3144) then 'DEWD'
# MAGIC       when ae.course_id = 2268 then 'ADEWD'
# MAGIC       when ae.course_id in (2307, 2906) then 'DAWD'
# MAGIC       when ae.course_id in (2417, 2343, 2390, 2395, 2400) then 'MLWD'
# MAGIC       when ae.course_id IN(1522, 3417, 3508) then 'MLIP'
# MAGIC       when ae.course_id in (2267, 2726, 2706,2716,2717,2713) then 'GENAI'
# MAGIC   END AS course_completed,
# MAGIC   ae.enrolled_date,
# MAGIC   ae.completed_date,
# MAGIC   'Learning Festival' as course_type
# MAGIC FROM 
# MAGIC   main.field_learning_enablement.all_enrollments ae
# MAGIC WHERE
# MAGIC   ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC   AND ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
# MAGIC   AND ae.course_id in (
# MAGIC     -- Full Courses
# MAGIC     1266, -- DEWD
# MAGIC     2268, -- ADEWD
# MAGIC     2307, -- DAWD
# MAGIC     2906, -- DAWD 2024
# MAGIC     2417, -- MLWD
# MAGIC     1522, -- MLIP
# MAGIC     2267, -- GAIEWD 2023
# MAGIC     2726, -- GAIEWD 2024
# MAGIC     -- DE Modules
# MAGIC     2963, -- Data Ingestion
# MAGIC     1365, -- Workloads
# MAGIC     2971, -- DLT
# MAGIC     3144, -- Governance
# MAGIC     -- MLWD Modules
# MAGIC     2343, -- Data Prep
# MAGIC     2390, -- ML Model Dev
# MAGIC     2395, -- ML Model Dep
# MAGIC     2400, --ML Ops
# MAGIC     -- Gen AI
# MAGIC     2706, -- Gen AI Solution Dev
# MAGIC     2716, -- Gen AI App Dev
# MAGIC     2717, -- Gen AI App Eval
# MAGIC     2713, -- Gen AI App Deployment
# MAGIC     -- AMLWD Modules
# MAGIC     3417, -- ML at Scale
# MAGIC     3508 -- Advanced MLOPs
# MAGIC   )
# MAGIC   and ae.completed_timestamp between '2025-01-15T00:00:00UTC+14' and '2025-02-01T00:00:00UTC-12' -- Q4 FY25
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   updated_ultimate_parent_account_id AS parent_account_id,
# MAGIC   updated_account_id AS account_id,
# MAGIC   updated_account_name AS account_name,  
# MAGIC   IFF(T2.ultimate_parent_account_id IS NULL, 1, 0) AS is_partner,
# MAGIC   COUNT(enrolled_date) AS enrollments,
# MAGIC   COUNT(completed_date) AS completions
# MAGIC FROM 
# MAGIC   _initial AS T1
# MAGIC LEFT JOIN 
# MAGIC   _partner AS T2 
# MAGIC ON 
# MAGIC   T1.updated_ultimate_parent_account_id = T2.ultimate_parent_account_id
# MAGIC GROUP BY ALL;
# MAGIC
# MAGIC SELECT * FROM _learning_festival;

# COMMAND ----------

# MAGIC %md
# MAGIC #### 2- Measure of the impact by weekly average on each participant account

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Difference in difference by each participant

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

# Configurable parameters
period_baseline = ("2025-01-15", "2025-02-01")
weeks_to_analyze = 6
metric_column = 'wau_human'

# Prepare datasets
df_wau = spark.table("main.field_learning_enablement.fact_daily_mau")
df_wau = df_wau.filter(df_wau.account_name != "Databricks")
df_wau = df_wau.groupBy("date", "customer_id").agg(F.sum(metric_column).alias(metric_column))

df_sessions = spark.sql("SELECT * FROM _learning_festival")

# -- Step 1: Create week offsets
week_offsets = list(range(-weeks_to_analyze, weeks_to_analyze + 1))
week_rows = [(offset,) for offset in week_offsets]
df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

# -- Step 2: Cross join sessions with week offsets
df_expanded = df_sessions.crossJoin(df_week_offsets)

# Calculate weekly date ranges
df_expanded = df_expanded \
  .withColumn("week_start",
              F.when(F.col("week_offset") == 0, F.lit(period_baseline[0]))
              .when(F.col("week_offset") < 0, F.expr(f"date_add(to_date('{period_baseline[0]}'), 7 * int(week_offset))"))
              .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date('{period_baseline[1]}'), (7 * int(week_offset)) - 6)"))) \
  .withColumn("week_end", 
              F.when(F.col("week_offset") == 0, F.lit(period_baseline[1]))
              .when(F.col("week_offset") < 0, F.expr(f"date_add(to_date('{period_baseline[0]}'), (7 * int(week_offset)) + 6)"))
              .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date('{period_baseline[1]}'), 7 * int(week_offset))"))) \
  .withColumn("week_label", 
              F.when(F.col("week_offset") == 0, f"0_wk_{metric_column}")
              .otherwise(
                  F.concat(
                      F.abs(F.col("week_offset")).cast("string"),
                      F.when(F.col("week_offset") > 0, f"_wk_post_{metric_column}")
                      .otherwise(f"_wk_prev_{metric_column}")
                  )
              ))

# -- Step 3: Join with WAU data and aggregate by week
df_result = df_expanded.join(
    df_wau,
    (df_wau.customer_id == df_expanded.account_id) &
    (df_wau.date >= df_expanded.week_start) &
    (df_wau.date <= df_expanded.week_end),
    how="left"
)

df_result = df_result.groupBy("account_id", "account_name", "is_partner", "enrollments", "completions", "week_label", "week_offset").agg(
    F.coalesce(F.mean(metric_column), F.lit(0)).alias(f"{metric_column}_mean")
)#.filter(F.col(f"{metric_column}_mean") > 0)

# -- Step 4: Pivot week labels into columns
# Define the custom order for week labels
custom_order = (
    [f"{i}_wk_prev_{metric_column}" for i in range(weeks_to_analyze, 0, -1)] +
    [f"0_wk_{metric_column}"] +
    [f"{i}_wk_post_{metric_column}" for i in range(1, weeks_to_analyze + 1)]
)

# Perform the pivot with custom sorting
df_result = (
    df_result
    .groupBy("account_id", "account_name", "is_partner", "enrollments", "completions")
    .pivot("week_label", custom_order)
    .agg(F.sum(f"{metric_column}_mean"))
).na.fill(0)


# -- Step 7: Adding flag
# Sum across all WAU columns
df_result = df_result.withColumn(
    "total_usage_across_weeks",
    sum(F.col(c).cast("double") for c in custom_order)
)

# Flag if all usage is 0 or null
df_result = df_result.withColumn(
    "no_usage_in_all_weeks",
    F.col("total_usage_across_weeks") == 0
).drop("total_usage_across_weeks").filter(F.col("no_usage_in_all_weeks") == False)

# -- Step 8: Adding difference of difference
# Add difference_in_difference_wau for each week
for i in range(1, weeks_to_analyze + 1):
    df_result = df_result.withColumn(        
        f"wk{i}_prev_growth_{metric_column}",
        F.col(f"0_wk_{metric_column}") - F.col(f"{i}_wk_prev_{metric_column}")
    ).withColumn(        
        f"wk{i}_post_growth_{metric_column}",
        F.col(f"{i}_wk_post_{metric_column}") - F.col(f"0_wk_{metric_column}")
    ).withColumn(
        f"wk{i}_difference_in_difference_{metric_column}",
        F.col(f"wk{i}_post_growth_{metric_column}") - F.col(f"wk{i}_prev_growth_{metric_column}")
    ).withColumn(
        f"wk{i}_abs_growth_{metric_column}",
        F.col(f"{i}_wk_post_{metric_column}") - F.col(f"{i}_wk_prev_{metric_column}")
    )

# Step 9: Calculate IQR for wk1 difference-in-difference
# Filtering the records equals to zero from the threshold calculation
for i in range(1, weeks_to_analyze + 1):
  summary_stats = df_result.filter(F.col(f"wk{i}_difference_in_difference_{metric_column}") != 0).select(f"wk{i}_difference_in_difference_{metric_column}").summary("25%", "75%").toPandas()
  Q1 = float(summary_stats.loc[summary_stats["summary"] == "25%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
  Q3 = float(summary_stats.loc[summary_stats["summary"] == "75%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
  IQR = Q3 - Q1
  lower_bound = Q1 - 1.5 * IQR
  upper_bound = Q3 + 1.5 * IQR

  # Step 8: Add outlier flag
  df_result = df_result.withColumn(
      f"wk{i}_outlier_flag",
      F.when(F.col(f"wk{i}_difference_in_difference_{metric_column}") < F.lit(lower_bound), F.lit("drop"))
      .when(F.col(f"wk{i}_difference_in_difference_{metric_column}") > F.lit(upper_bound), F.lit("high_impact"))
      .otherwise(F.lit("normal"))
  )

# df_accounts_data = spark.table("main.gtm_data.core_accounts_curated")
# df_result = df_result.join(df_accounts_data,["account_id", "account_name"],how="left")

display(df_result)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Overall metrics

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType
import pandas as pd
from scipy import stats

df = df_result

# Extract the difference-in-difference columns
wk_diff_cols = [f"wk{i}_difference_in_difference_{metric_column}" for i in range(1, weeks_to_analyze + 1)]

# Select relevant columns and convert to Pandas
df_diff = df.select(*wk_diff_cols)
pdf = df_diff.toPandas()

# Function to categorize p-value
def categorize_p_value(p):
    if p < 0.001:
        return "Very strong evidence"
    elif p < 0.01:
        return "Strong evidence"
    elif p < 0.05:
        return "Moderate evidence"
    elif p < 0.1:
        return "Weak evidence"
    else:
        return "No evidence"

# Perform t-test for each week
results = []
for col in wk_diff_cols:
    values = pdf[col].dropna()

    # One-sample t-test against mean = 0
    t_stat, p_val = stats.ttest_1samp(values, popmean=0)

    results.append({
        "week": col,
        "n_obs": len(values),
        "event_period": f"{period_baseline[0]} to {period_baseline[1]}",
        "mean_difference_in_difference": values.mean(),
        "std_dev": values.std(ddof=1),
        "t_score": t_stat,
        "p_value": p_val,
        "evidence_strength": categorize_p_value(p_val)
    })

# Convert to Spark DataFrame to display in Databricks
display(spark.createDataFrame(pd.DataFrame(results)))

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Overall metrics w/o outliers

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType
import pandas as pd
from scipy import stats

# Select relevant columns and convert to Pandas
pdf = df_result.toPandas()

# Function to categorize p-value
def categorize_p_value(p):
    if p < 0.001:
        return "Very strong evidence"
    elif p < 0.01:
        return "Strong evidence"
    elif p < 0.05:
        return "Moderate evidence"
    elif p < 0.1:
        return "Weak evidence"
    else:
        return "No evidence"

# Perform t-test for each week
results = []
for i in range(1, weeks_to_analyze + 1):    
    pdf_no_outliers = pdf[pdf[f"wk{i}_outlier_flag"]== "normal"]    
    values = pdf_no_outliers[f"wk{i}_difference_in_difference_{metric_column}"]

    # One-sample t-test against mean = 0
    t_stat, p_val = stats.ttest_1samp(values, popmean=0)

    results.append({
        "week": f"wk{i}_difference_in_difference_{metric_column}",
        "n_obs": len(values),
        "mean_difference_in_difference": values.mean(),
        "std_dev": values.std(ddof=1),
        "t_score": t_stat,
        "p_value": p_val,
        "evidence_strength": categorize_p_value(p_val)
    })

# Convert to Spark DataFrame to display in Databricks
display(spark.createDataFrame(pd.DataFrame(results)))

# COMMAND ----------

# MAGIC %md
# MAGIC #### 3- Measure of daily weekly average impact

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

# Configurable parameters
period_baseline = ("2025-01-15", "2025-02-01")
weeks_to_analyze = 6
metric_column = 'wau_human'

# Prepare datasets
df_wau = spark.table("main.field_learning_enablement.fact_daily_mau")
# df_wau = df_wau.filter(df_wau.customer_id.isin (["0016100001IuPMzAAN", "0016100000gLdzsAAC", "0016100000Y4X6vAAF", 
#                                                  "0014N000020ofDiQAI", "0016100001BItCyAAL", "0016100001BM0vMAAT", "0016100000U5DmQAAV"]))
df_wau = df_wau.groupBy("date", "customer_id").agg(F.sum(metric_column).alias(metric_column))

df_sessions = spark.sql("SELECT * FROM _learning_festival")
# df_sessions = df_sessions.filter(df_sessions.account_id.isin (["0016100001IuPMzAAN", "0016100000gLdzsAAC", "0016100000Y4X6vAAF", 
#                                                                "0014N000020ofDiQAI", "0016100001BItCyAAL", "0016100001BM0vMAAT", "0016100000U5DmQAAV"]))

# -- Step 1: Create week offsets
week_offsets = list(range(-weeks_to_analyze, weeks_to_analyze + 1))
week_rows = [(offset,) for offset in week_offsets]
df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

# -- Step 2: Cross join sessions with week offsets
df_expanded = df_sessions.crossJoin(df_week_offsets)

# Calculate weekly date ranges
df_expanded = df_expanded \
  .withColumn("week_start",
              F.when(F.col("week_offset") == 0, F.lit(period_baseline[0]))
              .when(F.col("week_offset") < 0, F.expr(f"date_add(to_date('{period_baseline[0]}'), 7 * int(week_offset))"))
              .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date('{period_baseline[1]}'), (7 * int(week_offset)) - 6)"))) \
  .withColumn("week_end", 
              F.when(F.col("week_offset") == 0, F.lit(period_baseline[1]))
              .when(F.col("week_offset") < 0, F.expr(f"date_add(to_date('{period_baseline[0]}'), (7 * int(week_offset)) + 6)"))
              .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date('{period_baseline[1]}'), 7 * int(week_offset))"))) \
  .withColumn("week_label", 
              F.when(F.col("week_offset") == 0, f"0_wk_{metric_column}")
              .otherwise(
                  F.concat(
                      F.abs(F.col("week_offset")).cast("string"),
                      F.when(F.col("week_offset") > 0, f"_wk_post_{metric_column}")
                      .otherwise(f"_wk_prev_{metric_column}")
                  )
              ))

# -- Step 3: Join with WAU data and aggregate by week
df_expanded = df_expanded.join(
    df_wau,
    (df_wau.customer_id == df_expanded.account_id) &
    (df_wau.date >= df_expanded.week_start) &
    (df_wau.date <= df_expanded.week_end),
    how="left"
)

df_result = df_expanded.groupBy("account_id", "account_name", "enrollments", "completions", "week_label", "week_offset").agg(
    F.coalesce(F.mean(metric_column), F.lit(0)).alias(f"{metric_column}_mean")
)#.filter(F.col(f"{metric_column}_mean") > 0)

# -- Step 4: Pivot week labels into columns
# Define the custom order for week labels
custom_order = (
    [f"{i}_wk_prev_{metric_column}" for i in range(weeks_to_analyze, 0, -1)] +
    [f"0_wk_{metric_column}"] +
    [f"{i}_wk_post_{metric_column}" for i in range(1, weeks_to_analyze + 1)]
)

# Perform the pivot with custom sorting
df_result = (
    df_result
    .groupBy("account_id", "account_name", "enrollments", "completions")
    .pivot("week_label", custom_order)
    .agg(F.sum(f"{metric_column}_mean"))
).na.fill(0)


# -- Step 7: Adding flag
# Sum across all WAU columns
df_result = df_result.withColumn(
    "total_usage_across_weeks",
    sum(F.col(c).cast("double") for c in custom_order)
)

# Flag if all usage is 0 or null
df_result = df_result.withColumn(
    "no_usage_in_all_weeks",
    F.col("total_usage_across_weeks") == 0
).drop("total_usage_across_weeks").filter(F.col("no_usage_in_all_weeks") == False)

# -- Step 8: Adding difference of difference
# Add difference_in_difference_wau for each week
for i in range(1, weeks_to_analyze + 1):
    df_result = df_result.withColumn(        
        f"wk{i}_prev_growth_{metric_column}",
        F.col(f"0_wk_{metric_column}") - F.col(f"{i}_wk_prev_{metric_column}")
    ).withColumn(        
        f"wk{i}_post_growth_{metric_column}",
        F.col(f"{i}_wk_post_{metric_column}") - F.col(f"0_wk_{metric_column}")
    ).withColumn(
        f"wk{i}_difference_in_difference_{metric_column}",
        F.col(f"wk{i}_post_growth_{metric_column}") - F.col(f"wk{i}_prev_growth_{metric_column}")
    ).withColumn(
        f"wk{i}_abs_growth_{metric_column}",
        F.col(f"{i}_wk_post_{metric_column}") - F.col(f"{i}_wk_prev_{metric_column}")
    )

# Step 9: Calculate IQR for wk1 difference-in-difference
# Filtering the records equals to zero from the threshold calculation
for i in range(1, weeks_to_analyze + 1):
  summary_stats = df_result.filter(F.col(f"wk{i}_difference_in_difference_{metric_column}") != 0).select(f"wk{i}_difference_in_difference_{metric_column}").summary("25%", "75%").toPandas()
  Q1 = float(summary_stats.loc[summary_stats["summary"] == "25%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
  Q3 = float(summary_stats.loc[summary_stats["summary"] == "75%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
  IQR = Q3 - Q1
  lower_bound = Q1 - 1.5 * IQR
  upper_bound = Q3 + 1.5 * IQR

  # Step 8: Add outlier flag
  df_result = df_result.withColumn(
      f"wk{i}_outlier_flag",
      F.when(F.col(f"wk{i}_difference_in_difference_{metric_column}") < F.lit(lower_bound), F.lit("drop"))
      .when(F.col(f"wk{i}_difference_in_difference_{metric_column}") > F.lit(upper_bound), F.lit("high_impact"))
      .otherwise(F.lit("normal"))
  )

# df_accounts_data = spark.table("main.gtm_data.core_accounts_curated")
# df_result = df_result.join(df_accounts_data,["account_id", "account_name"],how="left")

display(df_result)

# COMMAND ----------

display(df_expanded)

# COMMAND ----------

# DBTITLE 1,Trends
display(df_expanded)

# COMMAND ----------

# MAGIC %md
# MAGIC ### USAT-299 Changing "week zero" logic

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1: Seasonality Adjustment (Holiday Correction)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Validated stability of pre-holiday vs. post-holiday trends

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Structural Behavior Change Detection

# COMMAND ----------

# MAGIC %md
# MAGIC ✨ If distributions look very similar and p-values are high → no big structural change. You can feel safer using pre-holiday trends.
# MAGIC
# MAGIC 🔥 If distributions look different and p-values are low → warning! Behavior has changed post-holiday, and you need to adjust your baseline.

# COMMAND ----------

from pyspark.sql import functions as F, types as T
import matplotlib.pyplot as plt
import seaborn as sns

# Configurable parameters
metric_column = 'wau_human'

# Prepare datasets
df_wau = spark.table("main.field_learning_enablement.fact_daily_mau")
df_wau = df_wau.groupBy("date", "customer_id", "bu").agg(F.sum(metric_column).alias(metric_column))

df_sessions = spark.sql("SELECT * FROM _learning_festival")

accounts_to_evaluate = df_sessions.select("account_id").distinct().groupBy().agg(F.collect_list("account_id").alias("accounts")).first()["accounts"]
df = df_wau.filter(F.col("customer_id").isin(accounts_to_evaluate))


# # 1. Prepare periods
oct_nov = df.filter((F.col("date") >= "2024-10-01") & (F.col("date") <= "2024-11-30"))
nov = df.filter((F.col("date") >= "2024-11-01") & (F.col("date") <= "2024-11-30"))
jan5_14 = df.filter((F.col("date") >= "2025-01-05") & (F.col("date") <= "2025-01-14"))
nov24_jan5 = df.filter((F.col("date") >= "2024-11-24") & (F.col("date") <= "2025-01-05"))

# 2. Calculate average metric per account in each period
oct_nov_values = oct_nov.groupBy("customer_id", "bu").agg(F.avg(metric_column).alias(f"avg_{metric_column}")).withColumn("period", F.lit("Oct-Nov"))
jan5_14_values = jan5_14.groupBy("customer_id", "bu").agg(F.avg(metric_column).alias(f"avg_{metric_column}")).withColumn("period", F.lit("Jan5-14"))
nov_values = nov.groupBy("customer_id", "bu").agg(F.avg(metric_column).alias(f"avg_{metric_column}")).withColumn("period", F.lit("Nov"))
nov24_jan5_values = nov24_jan5.groupBy("customer_id", "bu").agg(F.avg(metric_column).alias(f"avg_{metric_column}")).withColumn("period", F.lit("Nov24-Jan5"))

# 3. Merge for plotting
df_wau = oct_nov_values.union(jan5_14_values).union(nov_values).union(nov24_jan5_values)

display(df_wau)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Kolmogorov-Smirnov (KS) Test and nn-Whitney U Test

# COMMAND ----------

from scipy.stats import ks_2samp, mannwhitneyu

# 1. Prepare the series
oct_nov_value = oct_nov_values.select(F.col(f"avg_{metric_column}")).groupBy().agg(F.collect_list(F.col(f"avg_{metric_column}")).alias("avg")).first()["avg"]
jan5_14_value = jan5_14_values.select(F.col(f"avg_{metric_column}")).groupBy().agg(F.collect_list(F.col(f"avg_{metric_column}")).alias("avg")).first()["avg"]

# 2. Run tests
ks_stat, ks_pvalue = ks_2samp(oct_nov_value, jan5_14_value)
mw_stat, mw_pvalue = mannwhitneyu(oct_nov_value, jan5_14_value, alternative='two-sided')

# A non-parametric statistical test used to compare two cumulative distribution functions (CDFs), determining if they are likely drawn from the same underlying distribution
print(f"Kolmogorov-Smirnov Test p-value: {ks_pvalue:.4f}")

# A non-parametric test used to compare the medians of two independent groups
print(f"Mann-Whitney U Test p-value: {mw_pvalue:.4f}")

# Interpretation
print("Using both visual analysis (boxplots) and statistical tests (KS test p = 0.53), we found no significant difference in platform usage behavior between October–November and January 5–14. This gives us confidence to use pre-holiday periods as a stable baseline in campaign impact analysis.")

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Confidence Intervals for Platform Usage Means
# MAGIC If the intervals overlap considerably, the means are likely similar.
# MAGIC
# MAGIC 🧠 What it means:
# MAGIC - The means between the two periods are not far apart, but the confidence intervals don’t fully overlap — in fact, the post-holiday CI dips noticeably lower.
# MAGIC - However, they still touch between 173.31 and 176.00, so they are not clearly distinct.
# MAGIC - This tells us: there’s mild evidence of a difference in means, but not enough to be statistically persuasive — we would not reject the idea that the true underlying means might be the same.

# COMMAND ----------

import math

def get_summary_with_ci(df, label, metric_column):
    stats = df.select(F.avg(metric_column).alias("mean"),
                      F.stddev(metric_column).alias("stddev"),
                      F.count(metric_column).alias("n")).collect()[0]
    
    mean = stats["mean"]
    stddev_val = stats["stddev"]
    n = stats["n"]
    
    margin = 1.96 * (stddev_val / math.sqrt(n))
    
    return {
        "label": label,
        "mean": mean,
        "stddev": stddev_val,
        "n": n,
        "ci_low": mean - margin,
        "ci_high": mean + margin
    }

results = []

ci_pre = get_summary_with_ci(oct_nov, "Pre-Holiday", metric_column)
results.append(ci_pre)

ci_post = get_summary_with_ci(jan5_14, "Post-Holiday", metric_column)
results.append(ci_post)

schema = T.StructType([
    T.StructField("label", T.StringType(), True), T.StructField("mean", T.DoubleType(), True),    
    T.StructField("stddev", T.DoubleType(), True), T.StructField("n", T.DoubleType(), True),    
    T.StructField("ci_low", T.DoubleType(), True), T.StructField("ci_high", T.DoubleType(), True)
])

results_df = spark.createDataFrame(results, schema)
display(results_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Cohen’s d (Effect Size)
# MAGIC
# MAGIC 📏 What it means:
# MAGIC - This is extremely close to zero, suggesting that the practical effect size is negligible.
# MAGIC - It means the difference between pre- and post-holiday average WAU is tiny relative to the variability across accounts.
# MAGIC - Even though the CIs look modestly different, the standardized magnitude of that difference is trivial.

# COMMAND ----------

def compute_cohens_d(summary1, summary2):
    mean1, std1, n1 = summary1["mean"], summary1["stddev"], summary1["n"]
    mean2, std2, n2 = summary2["mean"], summary2["stddev"], summary2["n"]
    
    pooled_std = math.sqrt(((n1 - 1) * std1**2 + (n2 - 1) * std2**2) / (n1 + n2 - 2))
    d = (mean1 - mean2) / pooled_std
    return d

cohens_d = compute_cohens_d(ci_post, ci_pre)
print(f"Cohen's d = {cohens_d:.3f}")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Group accounts based on trend similarity

# COMMAND ----------

# MAGIC %md
# MAGIC 🧭 Rule-Based Classification vs. Clustering
# MAGIC
# MAGIC 🔍 1. Rule-Based Classification (a.k.a. transparent logic)
# MAGIC
# MAGIC ✅ Pros:
# MAGIC
# MAGIC - Easy to explain and audit.
# MAGIC - You control the criteria.
# MAGIC - Good when you already have a sense of what “typical” looks like.
# MAGIC
# MAGIC ❌ Cons:
# MAGIC
# MAGIC - Thresholds can be arbitrary or overly rigid.
# MAGIC - Might miss more nuanced groupings.
# MAGIC
# MAGIC 🔍 2. Clustering-Based Grouping (e.g., K-means or Gaussian Mixture)
# MAGIC
# MAGIC ✅ Pros:
# MAGIC
# MAGIC - Captures subtle patterns you might not notice.
# MAGIC - More flexible and data-driven.
# MAGIC
# MAGIC ❌ Cons:
# MAGIC
# MAGIC - Requires standardization and tuning (e.g., choosing k).
# MAGIC - Harder to interpret at first glance.
# MAGIC - May overfit noise if not validated.

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Rule-Based Classification

# COMMAND ----------

import numpy as np
import pandas as pd
from pyspark.sql.window import Window

def rule_based_classification(df):
  # Assign numeric day index per account (required for slope calc)
  window_spec = Window.partitionBy("customer_id").orderBy("date")
  df = df.withColumn("day_index", F.row_number().over(window_spec))

  # Aggregate metrics to derive slope, mean, stddev
  agg = df.groupBy("customer_id").agg(
      F.avg(metric_column).alias(f"mean_{metric_column}"),
      F.stddev_samp(metric_column).alias("volatility"),
  )

  # Collect data to compute slope and r_squared manually
  df_pd = df.select("customer_id", "day_index", metric_column).toPandas()

  # Compute slope and r^2 per account
  trend_metrics = []
  for customer_id, group in df_pd.groupby("customer_id"):
      x = group["day_index"].values
      y = group[metric_column].values
      slope, intercept = F.np.polyfit(x, y, 1)
      y_pred = slope * x + intercept
      ss_res = np.sum((y - y_pred)**2)
      ss_tot = np.sum((y - np.mean(y))**2)
      r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
      trend_metrics.append((customer_id, float(slope), float(r_squared)))

  trend_df = pd.DataFrame(trend_metrics, columns=["customer_id", "slope", "r_squared"])

  # Merge with volatility and mean_wau
  agg_pd = agg.toPandas()
  final_df = pd.merge(agg_pd, trend_df, on="customer_id")  
  final_df = spark.createDataFrame(final_df)
    
  # Calculate Q1 and Q3 for slope
  slope_q1, slope_q3 = final_df.approxQuantile("slope", [0.25, 0.75], 0.01)

  # Calculate Q3 for volatility
  volatility_q3 = final_df.approxQuantile("volatility", [0.75], 0.01)[0]

  # Compute volatility median
  volatility_median = final_df.approxQuantile("volatility", [0.5], 0.01)[0]

  # Adding trend label
  classified_df = final_df.withColumn(
    "trend_label",
    F.when(F.col("slope") > slope_q3, "Upward")
    .when(F.col("slope") < slope_q1, "Downward")
    .when(F.col("volatility") > volatility_q3, "Volatile")    
    .when(F.col("volatility") <= volatility_median, "Flat")
    .otherwise("Ambiguous"))

  return classified_df
  

df_to_clasify = df.filter((F.col("date") >= "2024-11-01") & (F.col("date") <= "2024-11-24"))
rb_classification_before_holiday = rule_based_classification(df_to_clasify).withColumn("period", F.lit("Before Holiday"))

df_to_clasify = df.filter((F.col("date") >= "2025-01-05") & (F.col("date") <= "2025-01-14"))
rb_classification_after_holiday = rule_based_classification(df_to_clasify).withColumn("period", F.lit("Before Campaign"))

rb_classification = rb_classification_before_holiday.union(rb_classification_after_holiday)

display(rb_classification)


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Get the avg participation on each group

# COMMAND ----------

df_sessions_w_groups = df_sessions.join(rb_classification_after_holiday, df_sessions.account_id == rb_classification_after_holiday.customer_id, how="left")
display(df_sessions_w_groups)

# COMMAND ----------

accounts = df_sessions_w_groups.filter(F.col("trend_label").isNull()).select("account_id").distinct().groupBy().agg(F.collect_list("account_id").alias("accounts")).first()["accounts"]


display(df.filter((F.col("customer_id").isin(accounts)) & (F.col("date") >= "2024-11-01")))

# COMMAND ----------

display(df_to_clasify.join(rb_classification, df_to_clasify.customer_id == rb_classification.customer_id, how="left").filter(F.col("trend_label")=="Upward"))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2: Functions definition

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Define account level impact

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

def get_campaign_impact(df_sessions, metric_column, weeks_to_analyze):
    # Configurable parameters
    period_baseline = ["2025-01-15", "2025-02-01"]  
    period_holiday = ["2024-11-24", "2025-01-05"]  

    # Prepare datasets
    df_wau = spark.table("main.field_learning_enablement.fact_daily_mau")
    df_wau = df_wau.filter(df_wau.account_name != "Databricks")
    df_wau = df_wau.groupBy("date", "customer_id").agg(F.sum(metric_column).alias(metric_column))

    # -- Step 1: Create week offsets
    week_offsets = list(range(-weeks_to_analyze, weeks_to_analyze + 1))
    week_rows = [(offset,) for offset in week_offsets]
    df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

    # -- Step 2: Cross join sessions with week offsets
    df_expanded = df_sessions.crossJoin(df_week_offsets)

    # Calculate weekly date ranges
    df_expanded = df_expanded \
    .withColumn("week_start",
                F.when(F.col("week_offset") == 0, F.expr(f"date_add(to_date('{period_baseline[0]}'), (7 * int(week_offset)) - 7)"))
                # # Holiday Adjustment
                .when(F.col("week_offset") < 0, F.expr(f"date_add(to_date('{period_holiday[0]}'), 7 * int(week_offset))"))
                
                # # No Holiday Adjustment
                # .when(F.col("week_offset") < 0, F.expr(f"date_add(date_sub(to_date('{period_baseline[0]}'), 7), 7 * int(week_offset))"))

                .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date('{period_baseline[1]}'), (7 * int(week_offset)) - 6)"))) \
    .withColumn("week_end", F.expr(f"date_add(week_start, 6)")) \
    .withColumn("week_label", 
                F.when(F.col("week_offset") == 0, f"0_wk_{metric_column}")
                .otherwise(
                    F.concat(
                        F.abs(F.col("week_offset")).cast("string"),
                        F.when(F.col("week_offset") > 0, f"_wk_post_{metric_column}")
                        .otherwise(f"_wk_prev_{metric_column}")
                    )
                )).drop("week_offset")
    
# Adding the date range for the 90-day average baseline
    df_90_day_baseline = df_sessions \
        .withColumn("week_start", F.expr(f"date_sub(to_date('{period_baseline[0]}'), 90)")) \
        .withColumn("week_end", F.expr(f"date_sub(to_date('{period_baseline[1]}'), 1)")) \
        .withColumn("week_label", F.lit(f"90_day_prev_{metric_column}"))

    df_expanded = df_expanded.union(df_90_day_baseline)                

    # -- Step 3: Join with WAU data and aggregate by week
    df_result = df_expanded.join(
        df_wau,
        (df_wau.customer_id == df_expanded.account_id) &
        (df_wau.date >= df_expanded.week_start) &
        (df_wau.date <= df_expanded.week_end),
        how="left"
    )

    df_result = df_result.groupBy("account_id", "account_name", "completions", "week_label").agg(
        F.coalesce(F.mean(metric_column), F.lit(0)).alias(f"{metric_column}_mean")
    )#.filter(F.col(f"{metric_column}_mean") > 0)

    # -- Step 4: Pivot week labels into columns
    # Define the custom order for week labels
    custom_order = (
        [f"90_day_prev_{metric_column}"] +
        [f"{i}_wk_prev_{metric_column}" for i in range(weeks_to_analyze, 0, -1)] +
        [f"0_wk_{metric_column}"] +
        [f"{i}_wk_post_{metric_column}" for i in range(1, weeks_to_analyze + 1)]
    )

    # Perform the pivot with custom sorting
    df_result = (
        df_result
        .groupBy("account_id", "account_name", "completions")
        .pivot("week_label", custom_order)
        .agg(F.sum(f"{metric_column}_mean"))
    ).na.fill(0)


    # -- Step 7: Filter out the accounts with no usage in all weeks
    # Sum across all WAU columns
    df_result = df_result.withColumn(
        "total_usage_across_weeks",
        sum(F.col(c).cast("double") for c in custom_order)
    ).filter(F.col("total_usage_across_weeks") > 0).drop("total_usage_across_weeks")

    # -- Step 8: Adding difference of difference
    # Add difference_in_difference_wau for each week
    for i in range(1, weeks_to_analyze + 1):
        df_result = df_result.withColumn(        
            f"wk{i}_prev_growth_{metric_column}",
            F.col(f"0_wk_{metric_column}") - F.col(f"{i}_wk_prev_{metric_column}")
        ).withColumn(        
            f"wk{i}_post_growth_{metric_column}",
            F.col(f"{i}_wk_post_{metric_column}") - F.col(f"0_wk_{metric_column}")
        ).withColumn(
            f"wk{i}_difference_in_difference_{metric_column}",
            F.col(f"wk{i}_post_growth_{metric_column}") - F.col(f"wk{i}_prev_growth_{metric_column}")
        ).withColumn(
            f"wk{i}_growth_{metric_column}",
            F.col(f"{i}_wk_post_{metric_column}") - F.col(f"90_day_prev_{metric_column}")
        )

    # Step 9: Calculate IQR for wk1 difference-in-difference
    # Filtering the records equals to zero from the threshold calculation
    for i in range(1, weeks_to_analyze + 1):
        summary_stats = df_result.filter(F.col(f"wk{i}_difference_in_difference_{metric_column}") != 0).select(f"wk{i}_difference_in_difference_{metric_column}").summary("25%", "75%").toPandas()
        Q1 = float(summary_stats.loc[summary_stats["summary"] == "25%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
        Q3 = float(summary_stats.loc[summary_stats["summary"] == "75%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        # Step 8: Add outlier flag
        df_result = df_result.withColumn(
            f"wk{i}_outlier_flag",
            F.when(F.col(f"wk{i}_difference_in_difference_{metric_column}") < F.lit(lower_bound), F.lit("drop"))
            .when(F.col(f"wk{i}_difference_in_difference_{metric_column}") > F.lit(upper_bound), F.lit("high_impact"))
            .otherwise(F.lit("normal"))
        )

    return df_result

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Define the overall impact

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType
import pandas as pd
from scipy import stats

def get_overall_campaign_impact(df_result, exclude_outliers, metric_column, weeks_to_analyze):
  period_baseline = ["2025-01-15", "2025-02-01"]  

  # Function to categorize p-value
  def categorize_p_value(p):
      if p < 0.001:
          return "Very strong evidence"
      elif p < 0.01:
          return "Strong evidence"
      elif p < 0.05:
          return "Moderate evidence"
      elif p < 0.1:
          return "Weak evidence"
      else:
          return "No evidence"

  # Perform t-test for each week
  overall_metrics = None
  for i in range(1, weeks_to_analyze + 1):    
    # Step 10: Add Overall Metrics
    if exclude_outliers == "Yes":
        df_result_filtered = df_result.filter(F.col(f"wk{i}_outlier_flag")== "normal")
    else:
        df_result_filtered = df_result

    values = [row[f"wk{i}_difference_in_difference_{metric_column}"] for 
            row in df_result_filtered.select(f"wk{i}_difference_in_difference_{metric_column}").collect()]
    # One-sample t-test against mean = 0
    t_stat, p_val = stats.ttest_1samp(values, popmean=0)

    overall_metrics_results = df_result_filtered.groupby(        
        F.lit(metric_column).alias("metric"),
        F.lit(f"wk{i}_impact").alias("week"),
    ).agg(        
        F.count("account_id").alias("n_obs"),
        F.avg(f"wk{i}_prev_growth_{metric_column}").alias("avg_prev_growth"),
        F.avg(f"wk{i}_post_growth_{metric_column}").alias("avg_post_growth"),
        F.avg(f"wk{i}_difference_in_difference_{metric_column}").alias("avg_difference_in_difference"),
        F.avg(f"wk{i}_growth_{metric_column}").alias("avg_growth"),
        F.sum(f"wk{i}_growth_{metric_column}").alias("total_growth"),
        F.lit(t_stat).alias("t_score"),
        F.lit(p_val).alias("p_value"),
        F.lit(categorize_p_value(p_val)).alias("evidence_strength")
    )

    if overall_metrics is None:
        overall_metrics = overall_metrics_results
    else:
        overall_metrics = overall_metrics.union(overall_metrics_results)    

  # Convert to Spark DataFrame to display in Databricks
  return overall_metrics

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Get account level impact

# COMMAND ----------

df_sessions = spark.sql("SELECT * FROM _learning_festival")

df_sessions_filtered = df_sessions.filter(F.col("completions")>1)

df_result = get_campaign_impact(df_sessions_filtered, metric_column = "wau_human", weeks_to_analyze = 6)

display(df_result)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Get Overall impact

# COMMAND ----------

df_sessions_filtered = df_sessions.filter(F.col("completions")>1)

df_result = get_campaign_impact(df_sessions_filtered, metric_column = "wau_human", weeks_to_analyze = 6)

overall_impact = get_overall_campaign_impact(df_result, exclude_outliers = "Yes", metric_column = "wau_human", weeks_to_analyze = 6)

display(overall_impact)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Get Multiple Metrics Overall impact

# COMMAND ----------

import pyspark.sql.functions as F

metrics_to_measure = ["wau_human", "lakeview_wau", "dbsql_wau"]
df_final = None

for metric in metrics_to_measure:  
  df_sessions_filtered = df_sessions.filter(F.col("completions")>1)
  df_result = get_campaign_impact(df_sessions_filtered, metric_column = metric, weeks_to_analyze = 6)
  overall_impact = get_overall_campaign_impact(df_result, exclude_outliers = "Yes", metric_column = metric, weeks_to_analyze = 6)

  overall_impact = overall_impact.withColumn("metric", F.lit(metric))

  if df_final is not None:
    df_final = df_final.union(overall_impact)
  else:
    df_final = overall_impact

df_pivoted = df_final.groupBy("metric").pivot("week").agg(
    F.first(F.concat(
        F.format_number(F.col("avg_difference_in_difference"), 6),
        F.lit("(p-value: "), 
        F.format_number(F.col("p_value"), 6), 
        F.lit(")")
    ))
)

display(df_pivoted)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Upward accounts impact

# COMMAND ----------

from pyspark.sql import functions as F

trend_labels = [row["trend_label"] for row in 
                df_sessions_w_groups.select("trend_label").distinct().filter(F.col("trend_label").isNotNull()).sort("trend_label").collect()]

for trend_label in trend_labels:
  df_sessions_to_analyze = df_sessions_w_groups.filter(F.col("trend_label")==trend_label)
  
  df_result = get_campaign_impact(df_sessions_to_analyze, metric_column = "wau_human", weeks_to_analyze = 5)
  overall_impact = get_overall_campaign_impact(df_result, exclude_outliers = "Yes", metric_column = "wau_human", weeks_to_analyze = 5)

  overall_impact = overall_impact.withColumn("trend_label", F.lit(trend_label))

  if 'df_final' in locals():
    df_final = df_final.union(overall_impact)
  else:
    df_final = overall_impact

display(df_final)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding Learning Festival Q1 FY26
# MAGIC ##### References
# MAGIC - [Virtual Learning Festival: 9 April - 30 April](https://community.databricks.com/t5/events/virtual-learning-festival-9-april-30-april/ec-p/111620#M2286)
# MAGIC - [User Enablement - Virtual Learning Festival Q1 FY26](https://adb-2548836972759138.18.azuredatabricks.net/sql/dashboardsv3/01effa9194411caaa836831517ff1ae7/datasets/c3c6f779?o=2548836972759138)

# COMMAND ----------

# DBTITLE 1,Learning Festival Q1 FY26
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _learning_festival
# MAGIC AS
# MAGIC WITH _initial
# MAGIC AS (
# MAGIC   with nnl as(
# MAGIC       select learner_user_id, course_code, completed_date
# MAGIC       from main.field_learning_enablement.all_learners
# MAGIC       where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
# MAGIC       and dataset = 'net new learners'
# MAGIC   )
# MAGIC   -- Learning Festival
# MAGIC   select 
# MAGIC   ae.audience,
# MAGIC   ae.learner_user_id, 
# MAGIC   ae.updated_account_id,
# MAGIC   ae.updated_account_name , 
# MAGIC   cac.dbx,
# MAGIC   ae.course_id, 
# MAGIC   ae.course_code, 
# MAGIC   ae.course_name,
# MAGIC   case 
# MAGIC       when ae.course_id in (1266, 2963, 1365, 2971, 3144) then 'DEWD'
# MAGIC       when ae.course_id in (2268, 2967, 2972, 3767, 3489) then 'ADEWD'
# MAGIC       when ae.course_id in (2307, 2906) then 'DAWD'
# MAGIC       when ae.course_id in (2417, 2343, 2390, 2395, 2400) then 'MLWD'
# MAGIC       when ae.course_id in (1522, 3417, 3508) then 'MLIP'
# MAGIC       when ae.course_id in (2267, 2726, 2706,2716,2717,2713) then 'GENAI'
# MAGIC   end as learning_pathway,
# MAGIC   ae.enrolled_date, 
# MAGIC   ae.completed_date, 
# MAGIC   ae.attended_flag, 
# MAGIC   ae.completed_fq2, 
# MAGIC   nnl.completed_date as learner_date, 
# MAGIC   'Learning Festival' as course_type, 
# MAGIC   ae.business_unit, 
# MAGIC   IFNULL(ae.sales_subregion_level_1,'Unknown'), 
# MAGIC   IFNULL(ae.sales_subregion_level_2,'Unknown'),
# MAGIC   IFNULL(ae.sales_subregion_level_3,'Unknown'), 
# MAGIC   case when ae.business_unit != 'Unknown' then ae.business_unit else region_derived end as kathryn_region
# MAGIC   from main.field_learning_enablement.all_enrollments ae
# MAGIC   left join nnl
# MAGIC   on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
# MAGIC   left join main.gtm_data.core_accounts_curated cac
# MAGIC   on ae.updated_account_id = cac.account_id
# MAGIC   where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC   and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
# MAGIC   and ae.course_id in (
# MAGIC       -- Full Courses
# MAGIC       1266, -- DEWD
# MAGIC       2268, -- ADEWD
# MAGIC       2307, -- DAWD
# MAGIC       2906, -- DAWD 2024
# MAGIC       2417, -- MLWD
# MAGIC       1522, -- MLIP
# MAGIC       2267, -- GAIEWD 2023
# MAGIC       2726, -- GAIEWD 2024
# MAGIC       -- DEWD Modules
# MAGIC       2963, -- Data Ingestion
# MAGIC       1365, -- Workloads
# MAGIC       2971, -- DLT
# MAGIC       3144, -- Governance
# MAGIC       -- ADEWD Modules
# MAGIC       2972, -- Streaming and DLT
# MAGIC       3767, -- Data Privacy
# MAGIC       2967, -- Perf Optimization  
# MAGIC       3489, -- Automated Deployment with DABs
# MAGIC       -- MLWD Modules
# MAGIC       2343, -- Data Prep
# MAGIC       2390, -- ML Model Dev
# MAGIC       2395, -- ML Model Dep
# MAGIC       2400, --ML Ops
# MAGIC       -- Gen AI
# MAGIC       2706, -- Gen AI Solution Dev
# MAGIC       2716, -- Gen AI App Dev
# MAGIC       2717, -- Gen AI App Eval
# MAGIC       2713, -- Gen AI App Deployment
# MAGIC       -- AMLWD Modules
# MAGIC       3417, -- ML at Scale
# MAGIC       3508 -- Advanced MLOPs
# MAGIC   )
# MAGIC   and ae.completed_timestamp between '2025-04-09T00:00:00UTC+14' and '2025-05-01T00:00:00UTC-12' -- Q1 FY26
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   updated_account_id AS account_id,
# MAGIC   updated_account_name AS account_name,  
# MAGIC   COUNT(completed_date) AS completions,
# MAGIC   COUNT(learner_date) AS net_new_learners
# MAGIC FROM 
# MAGIC   _initial AS T1
# MAGIC GROUP BY ALL;
# MAGIC
# MAGIC SELECT * FROM _learning_festival;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Get Multiple Metrics Overall impact

# COMMAND ----------

import pyspark.sql.functions as F

df_sessions = spark.sql("SELECT * FROM _learning_festival")
df_sessions_grouped = df_sessions.agg(F.sum("completions").alias("completions"), F.sum("net_new_learners").alias("net_new_learners"))
metrics_to_measure = ["wau_human", "lakeview_wau", "dbsql_wau"]
df_final = None

for metric in metrics_to_measure:  
  df_sessions_filtered = df_sessions.filter(F.col("net_new_learners")>1)
  df_result = get_campaign_impact(df_sessions_filtered, metric_column = metric, weeks_to_analyze = 2, period_baseline=["2025-04-09", "2025-04-30"])
  # df_result = df_result.filter(F.col(f"wk1_difference_in_difference_{metric}") >= -109)

  overall_impact = get_overall_campaign_impact(df_result, exclude_outliers = "Yes", metric_column = metric, weeks_to_analyze = 2, period_baseline=["2025-04-09", "2025-04-30"])

  if df_final is not None:
    df_final = df_final.union(overall_impact)
  else:
    df_final = overall_impact

# Step for adding the session completions and net_new_learners
df_final = df_sessions_grouped.crossJoin(df_final)

display(df_final)

# COMMAND ----------

df_result = get_campaign_impact(df_sessions_filtered, metric_column = "wau_human", weeks_to_analyze = 2, period_baseline=["2025-04-09", "2025-04-30"])

display(df_result)

# COMMAND ----------

df_pivoted = df_final.groupBy("metric").pivot("week").agg(
    F.first(F.concat(
        F.format_number(F.col("avg_difference_in_difference"), 6),
        F.lit("(p-value: "), 
        F.format_number(F.col("p_value"), 6), 
        F.lit(")")
    ))
)

display(df_pivoted)