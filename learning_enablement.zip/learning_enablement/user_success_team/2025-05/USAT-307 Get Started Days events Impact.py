# Databricks notebook source
# MAGIC %md
# MAGIC **Get Started Days events Impact**
# MAGIC
# MAGIC Request received from Suna
# MAGIC
# MAGIC Replicating the same analysis done for APJ but now for the Get Started Days campaign
# MAGIC
# MAGIC We will need to replicate the analysis done here [USAT-303 APJ Scaled User events Impact](https://adb-2548836972759138.18.azuredatabricks.net/editor/notebooks/2553478035319597?o=2548836972759138)
# MAGIC
# MAGIC Considering the dates for the Get Started Days shown on this dashboard [Databricks Get Started Days](https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01efce705dc9175898be331d9e3d9fd1/published?o=2548836972759138)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Get the participant accounts for each event

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get the event and session data

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW event_sessions_list
# MAGIC AS
# MAGIC with _get_started_days
# MAGIC AS(
# MAGIC   select     
# MAGIC     en.*, lab.id_coupon, lab.code, lab.transactionID, lab.subscription_trans_id, lab.coupon_used_date, lab.valid_from, lab.valid_to, hour(en.enrolled_timestamp) as enrolled_hour, timediff(hour, en.enrolled_timestamp,  en.started_timestamp) as time_before_session,
# MAGIC   concat('Databricks Get Started Day | ', date_format(en.session_date, 'MMM dd yyyy'), ' | ', en.session_region) AS session_name_cleaned
# MAGIC   from main.team_field_user_enablement.vw_ue_enrolments_ilt en
# MAGIC   left join (
# MAGIC       select * from main.team_field_user_enablement.vw_coupon_usage
# MAGIC       where code ilike 'ACAD-FREE-GS-LAB-%') lab
# MAGIC   on en.learner_user_id = lab.userID
# MAGIC   where en.course_id = 3125
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   session_id,
# MAGIC   session_name_cleaned AS session_name,
# MAGIC   session_date,
# MAGIC   updated_account_id AS account_id,
# MAGIC   updated_account_name AS account_name,
# MAGIC   COUNT(enrolled_date) AS enrollments,
# MAGIC   COUNT(completed_date) AS completions
# MAGIC FROM
# MAGIC   _get_started_days AS en
# MAGIC WHERE
# MAGIC   date_trunc('month', session_date) = date_trunc('month', add_months(current_date(), -2))
# MAGIC GROUP BY ALL;
# MAGIC
# MAGIC SELECT * FROM event_sessions_list;

# COMMAND ----------

event_sessions_list = spark.sql("select * from event_sessions_list")

# COMMAND ----------

# MAGIC %md
# MAGIC # Function definition to get the DiD and Abs Growth

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get account level impact

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

def get_campaign_impact(df_sessions, metric_column, weeks_to_analyze):
  # # Configurable parameters
  # period_baseline = ("2025-01-15", "2025-02-01")
  # weeks_to_analyze = 6
  # metric_column = 'wau_human'

  # Get the event period_baseline
  # Check if df_sessions has session_date or start_date and end_date columns
  first_row = df_sessions.first()
  if "session_date" in df_sessions.columns:
    period_baseline = [first_row["session_date"], first_row["session_date"]]
  elif "start_date" in df_sessions.columns and "end_date" in df_sessions.columns:    
    period_baseline = [first_row["Start_Date"], first_row["End_Date"]]    
  else:
      raise ValueError("df_sessions must have either 'session_date' or both 'start_date' and 'end_date' columns")

  # Prepare datasets
  df_wau = spark.table("main.field_learning_enablement.fact_daily_mau")
  df_wau = df_wau.filter(df_wau.account_name != "Databricks")
  df_wau = df_wau.groupBy("date", "customer_id").agg(F.sum(metric_column).alias(metric_column))

  # -- Step 1: Create week offsets
  week_offsets = list(range(-weeks_to_analyze, weeks_to_analyze + 1))
  week_rows = [(offset,) for offset in week_offsets]
  df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

  # -- Step 2: Cross join sessions with week offsets
  df_expanded = df_sessions.crossJoin(df_week_offsets)

  # Calculate weekly date ranges
  df_expanded = df_expanded \
    .withColumn("week_start",
                F.when(F.col("week_offset") == 0, F.lit(period_baseline[0]))
                .when(F.col("week_offset") < 0, F.expr(f"date_add(to_date('{period_baseline[0]}'), 7 * int(week_offset))"))
                .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date('{period_baseline[1]}'), (7 * int(week_offset)) - 6)"))) \
    .withColumn("week_end", 
                F.when(F.col("week_offset") == 0, F.lit(period_baseline[1]))
                .when(F.col("week_offset") < 0, F.expr(f"date_add(to_date('{period_baseline[0]}'), (7 * int(week_offset)) + 6)"))
                .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date('{period_baseline[1]}'), 7 * int(week_offset))"))) \
    .withColumn("week_label", 
                F.when(F.col("week_offset") == 0, f"0_wk_{metric_column}")
                .otherwise(
                    F.concat(
                        F.abs(F.col("week_offset")).cast("string"),
                        F.when(F.col("week_offset") > 0, f"_wk_post_{metric_column}")
                        .otherwise(f"_wk_prev_{metric_column}")
                    )
                ))

  # -- Step 3: Join with WAU data and aggregate by week
  df_result = df_expanded.join(
      df_wau,
      (df_wau.customer_id == df_expanded.account_id) &
      (df_wau.date >= df_expanded.week_start) &
      (df_wau.date <= df_expanded.week_end),
      how="left"
  )

  df_result = df_result.groupBy("account_id", "account_name", "enrollments", "completions", "week_label", "week_offset").agg(
      F.coalesce(F.mean(metric_column), F.lit(0)).alias(f"{metric_column}_mean")
  )#.filter(F.col(f"{metric_column}_mean") > 0)

  # -- Step 4: Pivot week labels into columns
  # Define the custom order for week labels
  custom_order = (
      [f"{i}_wk_prev_{metric_column}" for i in range(weeks_to_analyze, 0, -1)] +
      [f"0_wk_{metric_column}"] +
      [f"{i}_wk_post_{metric_column}" for i in range(1, weeks_to_analyze + 1)]
  )

  # Perform the pivot with custom sorting
  df_result = (
      df_result
      .groupBy("account_id", "account_name", "enrollments", "completions")
      .pivot("week_label", custom_order)
      .agg(F.sum(f"{metric_column}_mean"))
  ).na.fill(0)


  # -- Step 7: Adding flag
  # Sum across all WAU columns
  df_result = df_result.withColumn(
      "total_usage_across_weeks",
      sum(F.col(c).cast("double") for c in custom_order)
  )

  # Flag if all usage is 0 or null
  df_result = df_result.withColumn(
      "no_usage_in_all_weeks",
      F.col("total_usage_across_weeks") == 0
  ).drop("total_usage_across_weeks").filter(F.col("no_usage_in_all_weeks") == False)

  # -- Step 8: Adding difference of difference
  # Add difference_in_difference_wau for each week
  for i in range(1, weeks_to_analyze + 1):
      df_result = df_result.withColumn(        
          f"wk{i}_prev_growth_{metric_column}",
          F.col(f"0_wk_{metric_column}") - F.col(f"{i}_wk_prev_{metric_column}")
      ).withColumn(        
          f"wk{i}_post_growth_{metric_column}",
          F.col(f"{i}_wk_post_{metric_column}") - F.col(f"0_wk_{metric_column}")
      ).withColumn(
          f"wk{i}_difference_in_difference_{metric_column}",
          F.col(f"wk{i}_post_growth_{metric_column}") - F.col(f"wk{i}_prev_growth_{metric_column}")
      ).withColumn(
          f"wk{i}_abs_growth_{metric_column}",
          F.col(f"{i}_wk_post_{metric_column}") - F.col(f"wk{i}_prev_growth_{metric_column}")
      ).withColumn(
          f"wk{i}_after_session_growth_{metric_column}",
          F.col(f"{i}_wk_post_{metric_column}") - F.col(f"0_wk_{metric_column}")
      )

  # Step 9: Calculate IQR for wk1 difference-in-difference
  # Filtering the records equals to zero from the threshold calculation
  for i in range(1, weeks_to_analyze + 1):
    summary_stats = df_result.filter(F.col(f"wk{i}_difference_in_difference_{metric_column}") != 0).select(f"wk{i}_difference_in_difference_{metric_column}").summary("25%", "75%").toPandas()
    Q1 = float(summary_stats.loc[summary_stats["summary"] == "25%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
    Q3 = float(summary_stats.loc[summary_stats["summary"] == "75%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    # Step 8: Add outlier flag
    df_result = df_result.withColumn(
        f"wk{i}_outlier_flag",
        F.when(F.col(f"wk{i}_difference_in_difference_{metric_column}") < F.lit(lower_bound), F.lit("drop"))
        .when(F.col(f"wk{i}_difference_in_difference_{metric_column}") > F.lit(upper_bound), F.lit("high_impact"))
        .otherwise(F.lit("normal"))
    )

  return df_result

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get the overall impact

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType
import pandas as pd
from scipy import stats

def get_overall_campaign_impact(df_result, exclude_outliers, metric_column, weeks_to_analyze):
  # Get the event period_baseline
  # Check if df_sessions has session_date or start_date and end_date columns
  first_row = df_sessions.first()
  if "session_date" in df_sessions.columns:
    period_baseline = [first_row["session_date"], first_row["session_date"]]
  elif "start_date" in df_sessions.columns and "end_date" in df_sessions.columns:    
    period_baseline = [first_row["Start_Date"], first_row["End_Date"]]    
  else:
      raise ValueError("df_sessions must have either 'session_date' or both 'start_date' and 'end_date' columns")

  # Select relevant columns and convert to Pandas
  pdf = df_result.toPandas()

  # Function to categorize p-value
  def categorize_p_value(p):
      if p < 0.001:
          return "Very strong evidence"
      elif p < 0.01:
          return "Strong evidence"
      elif p < 0.05:
          return "Moderate evidence"
      elif p < 0.1:
          return "Weak evidence"
      else:
          return "No evidence"

  # Perform t-test for each week
  results = []
  for i in range(1, weeks_to_analyze + 1):    
    if exclude_outliers == "Yes":
      pdf = pdf[pdf[f"wk{i}_outlier_flag"]== "normal"]    
    values = pdf[f"wk{i}_difference_in_difference_{metric_column}"]

    # One-sample t-test against mean = 0
    t_stat, p_val = stats.ttest_1samp(values, popmean=0)

    abs_growth_avg = pdf[f"wk{i}_abs_growth_{metric_column}"].mean()
    after_session_growth_avg = pdf[f"wk{i}_after_session_growth_{metric_column}"].mean()

    results.append({
        "week": f"wk{i}_difference_in_difference_{metric_column}",
        "n_obs": len(values),
        "event_period": f"{period_baseline[0]} to {period_baseline[1]}",
        "mean_difference_in_difference": values.mean(),
        "mean_after_session_growth": after_session_growth_avg,
        "mean_abs_growth": abs_growth_avg,        
        "t_score": t_stat,
        "p_value": p_val,
        "evidence_strength": categorize_p_value(p_val)
    })

  # Convert to Spark DataFrame to display in Databricks
  return spark.createDataFrame(pd.DataFrame(results))

# COMMAND ----------

# MAGIC %md
# MAGIC # Get the campaign impact

# COMMAND ----------

from pyspark.sql import functions as F

event_list = [row["session_name"] for row in event_sessions_list.select('session_name').distinct().sort('session_name').collect()]

for session_name in event_list:
  df_sessions = event_sessions_list.filter(F.col("session_name")==session_name)

  df_result = get_campaign_impact(df_sessions, metric_column = "wau_human", weeks_to_analyze = 5)

  overall_impact = get_overall_campaign_impact(df_result, exclude_outliers = "Yes", metric_column = "wau_human", weeks_to_analyze = 5)
  overall_impact = overall_impact.withColumn("session_name", F.lit(session_name))

  if 'final_df' in locals():
    final_df = final_df.union(overall_impact)
  else:
    final_df = overall_impact

display(final_df)