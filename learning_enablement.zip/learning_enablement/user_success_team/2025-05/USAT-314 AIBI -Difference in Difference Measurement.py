# Databricks notebook source
# MAGIC %md
# MAGIC **AIBI -Difference in Difference Measurement**: 
# MAGIC
# MAGIC **Description**
# MAGIC
# MAGIC Request received from Suna. Reference file [AIBI -Difference in Difference Measurement](https://docs.google.com/spreadsheets/d/1kKxovj-PMylkyXKy7HqpJ9fQWMVKQ-WItDHpwA5kKEw/edit?usp=sharing)
# MAGIC
# MAGIC
# MAGIC For the AIBI Campaign we want to do a difference in difference analysis. 
# MAGIC
# MAGIC Can we get a dump of the data at the session code & account granularity for
# MAGIC - 12_wk_pre_MAU
# MAGIC - 9_wk_pre_MAU
# MAGIC - 6_wk_pre_MAU
# MAGIC - 3_wk_pre_MAU
# MAGIC - 0_wk_MAU
# MAGIC - 3_wk_post_MAU
# MAGIC - 6_wk_post_MAU
# MAGIC - 9_wk_post_MAU
# MAGIC - 12_wk_post_MAU
# MAGIC
# MAGIC **Prev session difference:** 0_wk_MAU - 12_wk_pre_MAU
# MAGIC
# MAGIC **Post session difference:** 12_wk_post_MAU - 0_wk_MAU
# MAGIC
# MAGIC **Difference in difference**: [Post session difference] - [Post session difference]

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1: Merge the event and customer data

# COMMAND ----------

# sesionality
# sessions with less 10 attendees, 
# how well the session was attended, 
# how big the account is
# Instead of looking MAU, lets look the product lift
# This event impact ont he short temp against the long term
# Three weeks is big for the impact, instead of looking on

# each column will be weeks, referring to the WAU at product line. Human WAU
# Adding product lines
# Add attendance to column Some of the sessions have low attendance. Removing the 
# Adding employee number for that account

# For enterprise it has better results than emerging, account information

# COMMAND ----------

# MAGIC %sql
# MAGIC -- =============================================
# MAGIC -- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
# MAGIC -- Create date: 2025-01-09
# MAGIC -- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
# MAGIC -- =============================================
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
# MAGIC   SELECT    
# MAGIC     T1.session_code
# MAGIC     , T1.session_name
# MAGIC     , T1.account_id
# MAGIC     , T1.account_name
# MAGIC     , T1.session_date
# MAGIC     , a.business_unit AS bu
# MAGIC     , a.account_segment AS tam
# MAGIC     , a.arr_tshirt_size AS current_penetration
# MAGIC     , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
# MAGIC     , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
# MAGIC   FROM(
# MAGIC     SELECT 
# MAGIC       T1.session_code,
# MAGIC       TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name,
# MAGIC       CAST(T1.ended_timestamp AS DATE) AS session_date,
# MAGIC       T1.updated_account_id AS account_id,
# MAGIC       T1.updated_account_name AS account_name,
# MAGIC       T1.enrolled_date,
# MAGIC       T1.completed_date
# MAGIC     FROM 
# MAGIC         main.field_learning_enablement.all_enrollments AS T1
# MAGIC     INNER JOIN
# MAGIC       main.field_learning_enablement.training_operations_ilt_schedule_master AS T2
# MAGIC     ON 
# MAGIC       T1.session_code = T2.academy_session_number
# MAGIC     WHERE 
# MAGIC       T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)    
# MAGIC       AND T2.processDate = (SELECT max(processDate) FROM main.field_learning_enablement.training_operations_ilt_schedule_master)
# MAGIC       AND (T2.project_type = 'AI/BI Training Program' AND T2.status not ilike 'cancel%')      
# MAGIC   ) AS T1
# MAGIC   LEFT JOIN  
# MAGIC     main.gtm_data.core_accounts_curated AS a USING (account_id)
# MAGIC   GROUP BY ALL;
# MAGIC
# MAGIC
# MAGIC SELECT * FROM _account_sessions
# MAGIC ORDER BY 1, 4;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Adding partner flag to the account sessions data

# COMMAND ----------

df_sessions = spark.sql("""
  WITH _partner_list
  AS (
    SELECT DISTINCT ultimate_parent_account_id FROM main.field_learning_enablement.partner_domains_accounts
    WHERE processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.partner_domains_accounts)    
  )                       
  SELECT 
    T1.*,
    IFF(T2.ultimate_parent_account_id IS NOT NULL, 'Yes', 'No') AS is_partner
  FROM 
    _account_sessions T1
  LEFT JOIN
    _partner_list as T2
  ON 
    T1.account_id = T2.ultimate_parent_account_id  
  WHERE 
    session_date <= '2025-04-01' --AND session_code <> '26769'    
    AND account_id NOT IN(      
      '0016100000ZcnkGAAR'  -- Databricks
    )    
""") 

df_sessions.count()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2: Functions definition

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Define account level impact

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

def get_campaign_impact(df_sessions, metric_column, weeks_to_analyze):
    # Get the event period_baseline
    # Check if df_sessions has session_date or start_date and end_date columns
    first_row = df_sessions.first()
    if "session_date" in df_sessions.columns:
        period_baseline = [first_row["session_date"], first_row["session_date"]]
    elif "start_date" in df_sessions.columns and "end_date" in df_sessions.columns:    
        period_baseline = [first_row["Start_Date"], first_row["End_Date"]]    
    else:
        raise ValueError("df_sessions must have either 'session_date' or both 'start_date' and 'end_date' columns")

    # Configurable parameters
    period_holiday = ["2024-11-24", "2025-01-05"]

    # Prepare datasets
    df_wau = spark.table("main.field_learning_enablement.fact_daily_mau") 
    df_wau = df_wau.groupBy("date", "customer_id").agg(F.sum(metric_column).alias(metric_column))

    # -- Step 1: Create week offsets
    week_offsets = list(range(-weeks_to_analyze, weeks_to_analyze + 1))
    week_rows = [(offset,) for offset in week_offsets]
    df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

    # -- Step 2: Cross join sessions with week offsets
    df_expanded = df_sessions.crossJoin(df_week_offsets)

    # Calculate weekly date ranges
    df_expanded = df_expanded \
        .withColumn("week_start",
                    F.when(F.col("week_offset") == 0, F.expr(f"date_add(session_date, (7 * int(week_offset)) - 7)"))                                        
                    .when(F.col("week_offset") < 0, 
                        # Holiday Adjustment
                        F.when(F.col("session_date") == "2025-01-14", F.expr(f"date_add(to_date('{period_holiday[0]}'), 7 * int(week_offset))")).otherwise(F.expr(f"date_add(date_sub(session_date, 7), 7 * int(week_offset))"))
                        
                        # No Holiday Adjustment
                        #   F.expr(f"date_add(date_sub(session_date, 7), 7 * int(week_offset))")
                    )                                        
                    .when(F.col("week_offset") > 0, F.expr(f"date_add(session_date, (7 * int(week_offset)) - 6)"))) \
        .withColumn("week_end", F.expr(f"date_add(week_start, 6)")) \
        .withColumn("week_label", 
                    F.when(F.col("week_offset") == 0, f"0_wk_{metric_column}")
                    .otherwise(
                        F.concat(
                            F.abs(F.col("week_offset")).cast("string"),
                            F.when(F.col("week_offset") > 0, f"_wk_post_{metric_column}")
                            .otherwise(f"_wk_prev_{metric_column}")
                        )
                    )).drop("week_offset")

# Adding the date range for the 90-day average baseline
    df_90_day_baseline = df_sessions \
        .withColumn("week_start", F.expr(f"date_sub(to_date('{period_baseline[0]}'), 90)")) \
        .withColumn("week_end", F.expr(f"date_sub(to_date('{period_baseline[1]}'), 1)")) \
        .withColumn("week_label", F.lit(f"90_day_prev_{metric_column}"))

    df_expanded = df_expanded.union(df_90_day_baseline)


    # -- Step 3: Join with WAU data and aggregate by week
    df_result = df_expanded.join(
        df_wau,
        (df_wau.customer_id == df_expanded.account_id) &
        (df_wau.date >= df_expanded.week_start) &
        (df_wau.date <= df_expanded.week_end),
        how="left"
    )

    df_result = df_result.groupBy("account_id", "account_name", "session_date", "event_registrations", "event_attendees", "week_label").agg(
        F.coalesce(F.mean(metric_column), F.lit(0)).alias(f"{metric_column}_mean")
    )

    # -- Step 4: Pivot week labels into columns
    # Define the custom order for week labels
    custom_order = (
        [f"90_day_prev_{metric_column}"] +
        [f"{i}_wk_prev_{metric_column}" for i in range(weeks_to_analyze, 0, -1)] +
        [f"0_wk_{metric_column}"] +
        [f"{i}_wk_post_{metric_column}" for i in range(1, weeks_to_analyze + 1)]
    )

    # Perform the pivot with custom sorting
    df_result = (
        df_result
        .groupBy("account_id", "account_name", "session_date", "event_registrations", "event_attendees")
        .pivot("week_label", custom_order)
        .agg(F.sum(f"{metric_column}_mean"))
    ).na.fill(0)


    # -- Step 7: Filter out the accounts with no usage in all weeks
    # Sum across all WAU columns
    df_result = df_result.withColumn(
        "total_usage_across_weeks",
        sum(F.col(c).cast("double") for c in custom_order)
    ).filter(F.col("total_usage_across_weeks") > 0).drop("total_usage_across_weeks")

    # -- Step 8: Adding difference of difference
    # Add difference_in_difference_wau for each week
    for i in range(1, weeks_to_analyze + 1):
        df_result = df_result.withColumn(        
            f"wk{i}_prev_growth_{metric_column}",
            F.col(f"0_wk_{metric_column}") - F.col(f"{i}_wk_prev_{metric_column}")
        ).withColumn(        
            f"wk{i}_post_growth_{metric_column}",
            F.col(f"{i}_wk_post_{metric_column}") - F.col(f"0_wk_{metric_column}")
        ).withColumn(
            f"wk{i}_difference_in_difference_{metric_column}",
            F.col(f"wk{i}_post_growth_{metric_column}") - F.col(f"wk{i}_prev_growth_{metric_column}")
        ).withColumn(
            f"wk{i}_growth_{metric_column}",
            F.col(f"{i}_wk_post_{metric_column}") - F.col(f"90_day_prev_{metric_column}")
        )

    # Step 9: Calculate IQR for wk1 difference-in-difference
    # Filtering the records equals to zero from the threshold calculation
    for i in range(1, weeks_to_analyze + 1):
        summary_stats = df_result.filter(F.col(f"wk{i}_difference_in_difference_{metric_column}") != 0).select(f"wk{i}_difference_in_difference_{metric_column}").summary("25%", "75%").toPandas()
        Q1 = float(summary_stats.loc[summary_stats["summary"] == "25%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
        Q3 = float(summary_stats.loc[summary_stats["summary"] == "75%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        # Step 8: Add outlier flag
        df_result = df_result.withColumn(
            f"wk{i}_outlier_flag",
            F.when(F.col(f"wk{i}_difference_in_difference_{metric_column}") < F.lit(lower_bound), F.lit("drop"))
            .when(F.col(f"wk{i}_difference_in_difference_{metric_column}") > F.lit(upper_bound), F.lit("high_impact"))
            .otherwise(F.lit("normal"))
        )

    return df_result

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Define the overall impact

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType
import pandas as pd
from scipy import stats

def get_overall_campaign_impact(df_result, exclude_outliers, metric_column, weeks_to_analyze):
  # Select relevant columns and convert to Pandas
  pdf = df_result.toPandas()

  # Function to categorize p-value
  def categorize_p_value(p):
      if p < 0.001:
          return "Very strong evidence"
      elif p < 0.01:
          return "Strong evidence"
      elif p < 0.05:
          return "Moderate evidence"
      elif p < 0.1:
          return "Weak evidence"
      else:
          return "No evidence"

  # Perform t-test for each week
  results = []
  for i in range(1, weeks_to_analyze + 1):    
    if exclude_outliers == "Yes":
      pdf = pdf[pdf[f"wk{i}_outlier_flag"]== "normal"]    
    values = pdf[f"wk{i}_difference_in_difference_{metric_column}"]

    # One-sample t-test against mean = 0
    t_stat, p_val = stats.ttest_1samp(values, popmean=0)

    prev_session_avg_growth = pdf[f"wk{i}_prev_growth_{metric_column}"].mean()
    post_session_avg_growth = pdf[f"wk{i}_post_growth_{metric_column}"].mean()

    avg_growth = pdf[f"wk{i}_growth_{metric_column}"].mean()
    total_growth = pdf[f"wk{i}_growth_{metric_column}"].sum()

    results.append({
        "week": f"wk{i}_impact",
        "n_obs": len(values),        
        "avg_prev_growth": prev_session_avg_growth,
        "avg_post_growth": post_session_avg_growth,
        "avg_difference_in_difference": values.mean(),
        "avg_growth": avg_growth,
        "total_growth": total_growth,        
        "t_score": t_stat,
        "p_value": p_val,
        "evidence_strength": categorize_p_value(p_val)
    })

  # Convert to Spark DataFrame to display in Databricks
  return spark.createDataFrame(pd.DataFrame(results))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3: Campaign Impact

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Get the impact by account

# COMMAND ----------

df_sessions_filtered = df_sessions.filter(F.col("event_attendees") > 1)

df_result = get_campaign_impact(df_sessions_filtered, metric_column = "wau_human", weeks_to_analyze = 5)

display(df_result)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT date, sum(wau_human) hwau FROM main.field_learning_enablement.fact_daily_mau where customer_id = "0016100001DzqppAAB" and date >= '2024-11-01' group by all

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Get the overall impact

# COMMAND ----------

df_result_filtered = df_result#.filter(F.col("wk1_difference_in_difference_wau_human") > -204)

overall_impact = get_overall_campaign_impact(df_result_filtered, exclude_outliers = "No", metric_column = "wau_human", weeks_to_analyze = 5)
display(overall_impact)

# /*
# 7.7862950058072
# 0.8145567169957405
# */

# COMMAND ----------

df_result = get_campaign_impact(df_sessions_filtered, metric_column = "dbsql_wau", weeks_to_analyze = 5)
df_result_filtered = df_result#.filter(F.col("wk1_difference_in_difference_dbsql_wau") > -180.85714285714312)


overall_impact = get_overall_campaign_impact(df_result_filtered, exclude_outliers = "No", metric_column = "dbsql_wau", weeks_to_analyze = 5)

display(overall_impact)

# COMMAND ----------

df_result = get_campaign_impact(df_sessions_filtered, metric_column = "lakeview_wau", weeks_to_analyze = 5)
overall_impact = get_overall_campaign_impact(df_result, exclude_outliers = "No", metric_column = "lakeview_wau", weeks_to_analyze = 5)

display(overall_impact)