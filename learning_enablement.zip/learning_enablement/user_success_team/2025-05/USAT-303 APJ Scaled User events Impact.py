# Databricks notebook source
# MAGIC %md
# MAGIC **APJ Scaled User events Impact**
# MAGIC
# MAGIC Request received from Suna
# MAGIC
# MAGIC Hi Abraham, Can we look at the APJ user events next after the global learning festival. By pre/post impact then by DID. (same way we are looking at the AIBI program.
# MAGIC
# MAGIC We will need to replicate the analysis done here [AIBI -Difference in Difference Measurement](https://docs.google.com/spreadsheets/d/1kKxovj-PMylkyXKy7HqpJ9fQWMVKQ-WItDHpwA5kKEw/edit?gid=1470435658#gid=1470435658)
# MAGIC
# MAGIC Considering the Start Date and End Date for the first 9 events on this spreadsheet [[MASTER] Integrated Training Event Calendar
# MAGIC ](https://docs.google.com/spreadsheets/d/1P1QTjn7fdiWyAIO95iaPpFJ3yvovhXesJl31ZUCdmK0/edit?gid=0#gid=0)
# MAGIC
# MAGIC - Databricks Asia-Pacific Learning Festival
# MAGIC - Intelligent Data Warehousing: AI/BI for Self-Service Analytics
# MAGIC - Databricks Data Intelligence Day Melbourne Australia 2025
# MAGIC - Databricks Data Intelligence Day Sydney Australia 2025
# MAGIC - Intelligent Data Warehousing: AI/BI for Self-Service Analytics (Korean)
# MAGIC - Databricks Data Intelligence Day Bangalore India 2025
# MAGIC - Intelligent Data Warehousing: AI/BI for Self-Service Analytics
# MAGIC - Databricks Data Intelligence Day Hong Kong 2025

# COMMAND ----------

from pyspark.sql import Row

data = [
    Row(Status="Completed", UE_Event_ID="250219APLF", Event_Name="Databricks Asia-Pacific Learning Festival", UE_Owner="Sunwoo Park", Stakeholder_POC="June Tan", Fiscal_Quarter="Q1", Start_Date="19 Feb 2025", End_Date="20 Feb 2025", Time="11:30-13:30 (SGT) - Day 1; 10:30-15:00 (SGT) - Day 2", Modality="Virtual", Hands_On="Mixed", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects, Partners", Session_ID="7433, 7617, 7618, 7619, 7620"),
    Row(Status="Completed", UE_Event_ID="250305APIC", Event_Name="Intelligent Data Warehousing: AI/BI for Self-Service Analytics", UE_Owner="Sunwoo Park", Stakeholder_POC="June Tan", Fiscal_Quarter="Q1", Start_Date="5 Mar 2025", End_Date="5 Mar 2025", Time="11:00-15:00 (SGT)", Modality="Virtual", Hands_On="No Lab", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects, Partners", Session_ID="7824"),
    Row(Status="Completed", UE_Event_ID="250319ANDI", Event_Name="Databricks Data Intelligence Day Melbourne Australia 2025", UE_Owner="Sunwoo Park", Stakeholder_POC="Renate Leknes", Fiscal_Quarter="Q1", Start_Date="19 Mar 2025", End_Date="19 Mar 2025", Time="13:00-17:00 (AET)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects", Session_ID="7960, 7961"),
    Row(Status="Completed", UE_Event_ID="250327ANDI", Event_Name="Databricks Data Intelligence Day Sydney Australia 2025", UE_Owner="Sunwoo Park", Stakeholder_POC="Renate Leknes", Fiscal_Quarter="Q1", Start_Date="27 Mar 2025", End_Date="27 Mar 2025", Time="13:00-17:00 (AET)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects", Session_ID="7962, 7963"),
    Row(Status="Completed", UE_Event_ID="250327APIC", Event_Name="Intelligent Data Warehousing: AI/BI for Self-Service Analytics (Korean)", UE_Owner="Sunwoo Park", Stakeholder_POC="Eunwoo Kim", Fiscal_Quarter="Q1", Start_Date="27 Mar 2025", End_Date="27 Mar 2025", Time="13:00-17:00 (KST)", Modality="Virtual", Hands_On="No Lab", Content_Language="Korean", Delivery_Language="Korean", Target_Audience="Customers, Prospects, Partners", Session_ID="7993"),
    Row(Status="Completed", UE_Event_ID="250404INDI", Event_Name="Databricks Data Intelligence Day Bangalore India 2025", UE_Owner="Sunwoo Park", Stakeholder_POC="Sanjana Dayanidhi", Fiscal_Quarter="Q1", Start_Date="4 Apr 2025", End_Date="4 Apr 2025", Time="09:30-13:30 (IST)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects", Session_ID="8170"),
    Row(Status="Completed", UE_Event_ID="250408APIC", Event_Name="Intelligent Data Warehousing: AI/BI for Self-Service Analytics", UE_Owner="Himanshu Vajani", Stakeholder_POC="June Tan", Fiscal_Quarter="Q1", Start_Date="8 Apr 2025", End_Date="8 Apr 2025", Time="11:00-15:00 (SGT)", Modality="Virtual", Hands_On="No Lab", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects, Partners", Session_ID="7823"),
    Row(Status="Completed", UE_Event_ID="250409AGDI", Event_Name="Databricks Data Intelligence Day Hong Kong 2025", UE_Owner="Sunwoo Park", Stakeholder_POC="Denise Wee", Fiscal_Quarter="Q1", Start_Date="9 Apr 2025", End_Date="9 Apr 2025", Time="13:00-16:00 (HKT)", Modality="In Person", Hands_On="Hands On", Content_Language="English", Delivery_Language="English", Target_Audience="Customers, Prospects", Session_ID="7880")
]

df = spark.createDataFrame(data)
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Get the participant accounts for each event

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get event data

# COMMAND ----------

from pyspark.sql import functions as f

event_sessions = df
event_sessions = event_sessions.withColumn(
  "Session_id", f.split(event_sessions["Session_id"], ",")).withColumn(
  "Session_id", f.expr("transform(Session_id, x -> trim(x))")).withColumn(
  "Start_Date", f.to_date(f.col("Start_Date"), "d MMM yyyy")).withColumn(
  "End_Date", f.to_date(f.col("End_Date"), "d MMM yyyy")
)
# display(event_sessions)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get session data

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   -- learner_user_id,
# MAGIC   -- learner_email,
# MAGIC   COUNT(enrolled_date), 
# MAGIC   COUNT(completed_date), 
# MAGIC   COUNT(DISTINCT learner_user_id),
# MAGIC   COUNT(DISTINCT CASE WHEN completed_date IS NOT NULL THEN learner_user_id END)
# MAGIC FROM main.field_learning_enablement.all_enrollments ae 
# MAGIC WHERE ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
# MAGIC AND ae.session_id IN(7433, 7617, 7618, 7619, 7620)
# MAGIC -- AND ae.learner_email IS NULL
# MAGIC -- AND ae.learner_email IN('priya1cvr.pb@gmail.com', 'biswajeetm156@gmail.com')
# MAGIC GROUP BY ALL

# COMMAND ----------

df_all_enrollments = spark.sql(""" 
                              with nnl as(
                                select learner_user_id, course_code
                                from main.field_learning_enablement.all_learners
                                where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
                                and dataset = 'net new learners')

                                SELECT ae.*, nnl.learner_user_id AS new_learner_id FROM main.field_learning_enablement.all_enrollments ae 
                                LEFT JOIN nnl ON ae.learner_user_id = nnl.learner_user_id AND ae.course_code = nnl.course_code
                                WHERE ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
                              """)

df_all_enrollments = df_all_enrollments.select("updated_account_id", "updated_account_name", "session_id", "learner_user_id", "completed_date", "new_learner_id")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Join the event and session data

# COMMAND ----------

event_sessions_list = event_sessions.withColumn(
  "session_id", f.explode(f.col("Session_id"))
).join(df_all_enrollments, on="session_id")

event_sessions_list = event_sessions_list.groupby("Event_Name", "Start_Date", "End_Date", 
                                                  f.col("updated_account_id").alias("account_id"), 
                                                  f.col("updated_account_name").alias("account_name")).agg(
  f.countDistinct("learner_user_id").alias("enrollments"), 
  f.countDistinct(f.when(f.col("completed_date").isNotNull(), f.col("learner_user_id"))).alias("completions"),
  f.countDistinct("new_learner_id").alias("new_learners"))
display(event_sessions_list)

# COMMAND ----------

display(event_sessions_list.filter(f.col("Event_Name").isin("Databricks Asia-Pacific Learning Festival")))

# COMMAND ----------

# MAGIC %md
# MAGIC # Function definition to get the DiD and Abs Growth

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get account level impact

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

def get_campaign_impact(df_sessions, metric_column, weeks_to_analyze):
    # # Configurable parameters
    # period_baseline = ("2025-01-15", "2025-02-01")
    # weeks_to_analyze = 6
    # metric_column = 'wau_human'

    # Get the event period_baseline
    first_row = df_sessions.first()
    period_baseline = [first_row["Start_Date"], first_row["End_Date"]]

    # Prepare datasets
    df_wau = spark.table("main.field_learning_enablement.fact_daily_mau")
    df_wau = df_wau.filter(df_wau.account_name != "Databricks")
    df_wau = df_wau.groupBy("date", "customer_id").agg(F.sum(metric_column).alias(metric_column))

    # -- Step 1: Create week offsets
    week_offsets = list(range(-weeks_to_analyze, weeks_to_analyze + 1))
    week_rows = [(offset,) for offset in week_offsets]  

    df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

    # -- Step 2: Cross join sessions with week offsets
    df_expanded = df_sessions.crossJoin(df_week_offsets)

    # Calculate weekly date ranges
    df_expanded = df_expanded \
        .withColumn("week_start",
                    F.when(F.col("week_offset") == 0, F.lit(period_baseline[0]))
                    .when(F.col("week_offset") < 0, F.expr(f"date_add(to_date('{period_baseline[0]}'), 7 * int(week_offset))"))
                    .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date('{period_baseline[1]}'), (7 * int(week_offset)) - 6)"))) \
        .withColumn("week_end", 
                    F.when(F.col("week_offset") == 0, F.lit(period_baseline[1]))
                    .when(F.col("week_offset") < 0, F.expr(f"date_add(to_date('{period_baseline[0]}'), (7 * int(week_offset)) + 6)"))
                    .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date('{period_baseline[1]}'), 7 * int(week_offset))"))) \
        .withColumn("week_label", 
                    F.when(F.col("week_offset") == 0, f"0_wk_{metric_column}")
                    .otherwise(
                        F.concat(
                            F.abs(F.col("week_offset")).cast("string"),
                            F.when(F.col("week_offset") > 0, f"_wk_post_{metric_column}")
                            .otherwise(f"_wk_prev_{metric_column}")
                        )
                    )).drop("week_offset")

    # Adding the date range for the 90-day average baseline
    df_90_day_baseline = df_sessions \
        .withColumn("week_start", F.expr(f"date_sub(to_date('{period_baseline[0]}'), 90)")) \
        .withColumn("week_end", F.expr(f"date_sub(to_date('{period_baseline[1]}'), 1)")) \
        .withColumn("week_label", F.lit(f"90_day_prev_{metric_column}"))

    df_expanded = df_expanded.union(df_90_day_baseline)


    # -- Step 3: Join with WAU data and aggregate by week
    df_result = df_expanded.join(
        df_wau,
        (df_wau.customer_id == df_expanded.account_id) &
        (df_wau.date >= df_expanded.week_start) &
        (df_wau.date <= df_expanded.week_end),
        how="left"
    )

    df_result = df_result.groupBy("account_id", "account_name", "enrollments", "completions", "week_label").agg(
        F.coalesce(F.mean(metric_column), F.lit(0)).alias(f"{metric_column}_mean")
    )#.filter(F.col(f"{metric_column}_mean") > 0)

    # -- Step 4: Pivot week labels into columns
    # Define the custom order for week labels
    custom_order = (
        [f"90_day_prev_{metric_column}"] +
        [f"{i}_wk_prev_{metric_column}" for i in range(weeks_to_analyze, 0, -1)] +
        [f"0_wk_{metric_column}"] +
        [f"{i}_wk_post_{metric_column}" for i in range(1, weeks_to_analyze + 1)]
    )

    # Perform the pivot with custom sorting
    df_result = (
        df_result
        .groupBy("account_id", "account_name", "enrollments", "completions")
        .pivot("week_label", custom_order)
        .agg(F.sum(f"{metric_column}_mean"))
    ).na.fill(0)


    # -- Step 7: Adding flag
    # Sum across all WAU columns
    df_result = df_result.withColumn(
        "total_usage_across_weeks",
        sum(F.col(c).cast("double") for c in custom_order)
    )

    # Flag if all usage is 0 or null
    df_result = df_result.withColumn(
        "no_usage_in_all_weeks",
        F.col("total_usage_across_weeks") == 0
    ).drop("total_usage_across_weeks").filter(F.col("no_usage_in_all_weeks") == False)

    # -- Step 8: Adding difference of difference
    # Add difference_in_difference_wau for each week
    for i in range(1, weeks_to_analyze + 1):
        df_result = df_result.withColumn(        
            f"wk{i}_prev_growth_{metric_column}",
            F.col(f"0_wk_{metric_column}") - F.col(f"{i}_wk_prev_{metric_column}")
        ).withColumn(        
            f"wk{i}_post_growth_{metric_column}",
            F.col(f"{i}_wk_post_{metric_column}") - F.col(f"0_wk_{metric_column}")
        ).withColumn(
            f"wk{i}_difference_in_difference_{metric_column}",
            F.col(f"wk{i}_post_growth_{metric_column}") - F.col(f"wk{i}_prev_growth_{metric_column}")
        ).withColumn(
            f"wk{i}_growth_{metric_column}",
            F.col(f"{i}_wk_post_{metric_column}") - F.col(f"90_day_prev_{metric_column}")
        )

    # Step 9: Calculate IQR for wk1 difference-in-difference
    # Filtering the records equals to zero from the threshold calculation
    for i in range(1, weeks_to_analyze + 1):
        summary_stats = df_result.filter(F.col(f"wk{i}_difference_in_difference_{metric_column}") != 0).select(f"wk{i}_difference_in_difference_{metric_column}").summary("25%", "75%").toPandas()
        Q1 = float(summary_stats.loc[summary_stats["summary"] == "25%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
        Q3 = float(summary_stats.loc[summary_stats["summary"] == "75%", f"wk{i}_difference_in_difference_{metric_column}"].values[0])
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        # Step 8: Add outlier flag
        df_result = df_result.withColumn(
            f"wk{i}_outlier_flag",
            F.when(F.col(f"wk{i}_difference_in_difference_{metric_column}") < F.lit(lower_bound), F.lit("drop"))
            .when(F.col(f"wk{i}_difference_in_difference_{metric_column}") > F.lit(upper_bound), F.lit("high_impact"))
            .otherwise(F.lit("normal"))
        )

    return df_result

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get the overall impact

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType
import pandas as pd
from scipy import stats

def get_overall_campaign_impact(df_result, exclude_outliers, metric_column, weeks_to_analyze):
  # Get the event period_baseline
  first_row = df_sessions.first()
  period_baseline = [first_row["Start_Date"], first_row["End_Date"]]

  # Select relevant columns and convert to Pandas
  pdf = df_result.toPandas()

  # Function to categorize p-value
  def categorize_p_value(p):
      if p < 0.001:
          return "Very strong evidence"
      elif p < 0.01:
          return "Strong evidence"
      elif p < 0.05:
          return "Moderate evidence"
      elif p < 0.1:
          return "Weak evidence"
      else:
          return "No evidence"

  # Perform t-test for each week
  results = []
  for i in range(1, weeks_to_analyze + 1):    
    if exclude_outliers == "Yes":
      pdf = pdf[pdf[f"wk{i}_outlier_flag"]== "normal"]    
    values = pdf[f"wk{i}_difference_in_difference_{metric_column}"]

    # One-sample t-test against mean = 0
    t_stat, p_val = stats.ttest_1samp(values, popmean=0)

    prev_session_avg_growth = pdf[f"wk{i}_prev_growth_{metric_column}"].mean()
    post_session_avg_growth = pdf[f"wk{i}_post_growth_{metric_column}"].mean()

    avg_growth = pdf[f"wk{i}_growth_{metric_column}"].mean()
    total_growth = pdf[f"wk{i}_growth_{metric_column}"].sum()

    results.append({
        "week": f"wk{i}_impact",
        "n_obs": len(values),
        "event_period": f"{period_baseline[0]} to {period_baseline[1]}",
        "avg_prev_growth": prev_session_avg_growth,
        "avg_post_growth": post_session_avg_growth,
        "avg_difference_in_difference": values.mean(),
        "avg_growth": avg_growth,
        "total_growth": total_growth,        
        "t_score": t_stat,
        "p_value": p_val,
        "evidence_strength": categorize_p_value(p_val)
    })

  # Convert to Spark DataFrame to display in Databricks
  return spark.createDataFrame(pd.DataFrame(results))

# COMMAND ----------

# MAGIC %md
# MAGIC # Get the campaign impact

# COMMAND ----------

# MAGIC %md
# MAGIC ## Databricks Asia-Pacific Learning Festival

# COMMAND ----------

# MAGIC %md
# MAGIC ### Account level impact

# COMMAND ----------

# get_campaign_impact(df_sessions, metric_column, weeks_to_analyze)

df_sessions = event_sessions_list.filter(f.col("Event_Name")=="Databricks Asia-Pacific Learning Festival")

df_result = get_campaign_impact(df_sessions, metric_column = "wau_human", weeks_to_analyze = 5)

display(df_result)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Overall level impact

# COMMAND ----------

overall_impact = get_overall_campaign_impact(df_result, metric_column = "wau_human", weeks_to_analyze = 5, exclude_outliers = "Yes")
display(overall_impact)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Databricks Data Intelligence Day Bangalore India 2025

# COMMAND ----------

event_list = [row["Event_Name"] for row in event_sessions_list.select('Event_Name').distinct().sort('Event_Name').collect()]
event_name = event_list[1]

df_sessions = event_sessions_list.filter(f.col("Event_Name")==event_name)

df_result = get_campaign_impact(df_sessions, metric_column = "wau_human", weeks_to_analyze = 5)

overall_impact = get_overall_campaign_impact(df_result, exclude_outliers = "Yes", metric_column = "wau_human", weeks_to_analyze = 5)
overall_impact = overall_impact.withColumn("Event_Name", F.lit(event_name))

display(overall_impact)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Databricks Data Intelligence Day Hong Kong 2025

# COMMAND ----------

event_list = [row["Event_Name"] for row in event_sessions_list.select('Event_Name').distinct().sort('Event_Name').collect()]
event_name = event_list[2]

df_sessions = event_sessions_list.filter(f.col("Event_Name")==event_name)

df_result = get_campaign_impact(df_sessions, metric_column = "wau_human", weeks_to_analyze = 5)

overall_impact = get_overall_campaign_impact(df_result, exclude_outliers = "Yes", metric_column = "wau_human", weeks_to_analyze = 5)
overall_impact = overall_impact.withColumn("Event_Name", F.lit(event_name))

display(overall_impact)

# COMMAND ----------

# MAGIC %md
# MAGIC ## All the APJ Events

# COMMAND ----------

event_list = event_sessions_list.groupby('Event_Name').agg(
  F.sum('enrollments').alias('enrollments'), 
  F.sum('completions').alias('completions'), 
  F.sum('new_learners').alias('new_learners'))
display(event_list)

# COMMAND ----------

for row in event_list.collect():
  df_sessions = event_sessions_list.filter(f.col("Event_Name")==row["Event_Name"])

  df_result = get_campaign_impact(df_sessions, metric_column = "wau_human", weeks_to_analyze = 5)  

  overall_impact = get_overall_campaign_impact(df_result, exclude_outliers = "Yes", metric_column = "wau_human", weeks_to_analyze = 5)
  overall_impact = overall_impact\
    .withColumn("Event_Name", F.lit(row["Event_Name"]))\
    .withColumn("enrollments", F.lit(row["enrollments"]))\
    .withColumn("completions", F.lit(row["completions"]))\
    .withColumn("new_learners", F.lit(row["new_learners"]))

  if 'final_df' in locals():
    final_df = final_df.union(overall_impact)
  else:
    final_df = overall_impact

display(final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Updated logic

# COMMAND ----------

# MAGIC %md
# MAGIC ### Updated Account level impact

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

def get_campaign_impact(df_sessions, metric_column, weeks_to_analyze, exclude_outliers):        
    # Prepare datasets
    df_wau = spark.table("main.field_learning_enablement.fact_daily_mau")
    df_wau = df_wau.filter(df_wau.account_name != "Databricks")
    df_wau = df_wau.groupBy("date", "customer_id").agg(F.sum(metric_column).alias(metric_column))

    # -- Step 1: Create week offsets
    week_offsets = list(range(-weeks_to_analyze, weeks_to_analyze + 1))
    week_rows = [(offset,) for offset in week_offsets]
    df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

    # -- Step 2: Cross join sessions with week offsets
    df_expanded = df_sessions.crossJoin(df_week_offsets)

    # Calculate weekly date ranges
    df_expanded = df_expanded \
    .withColumn("week_start",
                F.when(F.col("week_offset") == 0, F.expr(f"date_add(to_date(Start_Date), (7 * int(week_offset)) - 7)"))
                # # Holiday Adjustment
                # .when(F.col("week_offset") < 0, F.expr(f"date_add(to_date(Start_Date), 7 * int(week_offset))"))
                
                # No Holiday Adjustment
                .when(F.col("week_offset") < 0, F.expr(f"date_add(date_sub(to_date(Start_Date), 7), 7 * int(week_offset))"))

                .when(F.col("week_offset") > 0, F.expr(f"date_add(to_date(End_Date), (7 * int(week_offset)) - 6)"))) \
    .withColumn("week_end", F.expr(f"date_add(week_start, 6)")) \
    .withColumn("week_label", 
                F.when(F.col("week_offset") == 0, f"0_wk_{metric_column}")
                .otherwise(
                    F.concat(
                        F.abs(F.col("week_offset")).cast("string"),
                        F.when(F.col("week_offset") > 0, f"_wk_post_{metric_column}")
                        .otherwise(f"_wk_prev_{metric_column}")
                    )
                )).drop("week_offset")
    
# # Adding the date range for the 90-day average baseline
    df_90_day_baseline = df_sessions \
        .withColumn("week_start", F.expr(f"date_sub(to_date(Start_Date), 90)")) \
        .withColumn("week_end", F.expr(f"date_sub(to_date(End_Date), 1)")) \
        .withColumn("week_label", F.lit(f"90_day_prev_{metric_column}"))

    df_expanded = df_expanded.union(df_90_day_baseline)                

    # -- Step 3: Join with WAU data and aggregate by week
    df_result = df_expanded.join(
        df_wau,
        (df_wau.customer_id == df_expanded.account_id) &
        (df_wau.date >= df_expanded.week_start) &
        (df_wau.date <= df_expanded.week_end),
        how="left"
    )

    df_result = df_result.groupBy("event_name", "start_date", "end_date", "account_id", "account_name", "enrollments", "completions", "week_label").agg(
        F.coalesce(F.mean(metric_column), F.lit(0)).alias(f"{metric_column}_mean")
    )#.filter(F.col(f"{metric_column}_mean") > 0)

    # -- Step 4: Pivot week labels into columns
    # Define the custom order for week labels
    custom_order = (
        [f"90_day_prev_{metric_column}"] +
        [f"{i}_wk_prev_{metric_column}" for i in range(weeks_to_analyze, 0, -1)] +
        [f"0_wk_{metric_column}"] +
        [f"{i}_wk_post_{metric_column}" for i in range(1, weeks_to_analyze + 1)]
    )

    # Perform the pivot with custom sorting
    df_result = (
        df_result
        .groupBy("event_name", "start_date", "end_date","account_id", "account_name", "enrollments", "completions")
        .pivot("week_label", custom_order)
        .agg(F.sum(f"{metric_column}_mean"))
    ).na.fill(0)


    # -- Step 7: Filter out the accounts with no usage in all weeks
    # Sum across all WAU columns
    df_result = df_result.withColumn(
        "total_usage_across_weeks",
        sum(F.col(c).cast("double") for c in custom_order)
    ).filter(F.col("total_usage_across_weeks") > 0).drop("total_usage_across_weeks")

    # -- Step 8: Adding difference of difference
    # Add difference_in_difference_wau for each week
    overall_metrics = None    
    
    # Function to categorize p-value
    def categorize_p_value(p):
        if p < 0.001:
            return "Very strong evidence"
        elif p < 0.01:
            return "Strong evidence"
        elif p < 0.05:
            return "Moderate evidence"
        elif p < 0.1:
            return "Weak evidence"
        else:
            return "No evidence"


    for i in range(1, weeks_to_analyze + 1):
        df_result = df_result.withColumn(        
            f"wk{i}_prev_growth_{metric_column}",
            F.col(f"0_wk_{metric_column}") - F.col(f"{i}_wk_prev_{metric_column}")
        ).withColumn(        
            f"wk{i}_post_growth_{metric_column}",
            F.col(f"{i}_wk_post_{metric_column}") - F.col(f"0_wk_{metric_column}")
        ).withColumn(
            f"wk{i}_difference_in_difference_{metric_column}",
            F.col(f"wk{i}_post_growth_{metric_column}") - F.col(f"wk{i}_prev_growth_{metric_column}")
        ).withColumn(
            f"wk{i}_growth_{metric_column}",
            F.col(f"{i}_wk_post_{metric_column}") - F.col(f"90_day_prev_{metric_column}")
        )

    # Step 9: Calculate IQR for wk1 difference-in-difference
    # Filtering the records equals to zero from the threshold calculation    
        percentiles = df_result.filter(F.col(f"wk{i}_difference_in_difference_{metric_column}") != 0)\
            .approxQuantile(f"wk{i}_difference_in_difference_{metric_column}", [0.25, 0.75], 0.01)
        
        Q1, Q3 = percentiles

        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        # Step 8: Add outlier flag
        df_result = df_result.withColumn(
            f"wk{i}_outlier_flag",
            F.when(F.col(f"wk{i}_difference_in_difference_{metric_column}") < F.lit(lower_bound), F.lit("drop"))
            .when(F.col(f"wk{i}_difference_in_difference_{metric_column}") > F.lit(upper_bound), F.lit("high_impact"))
            .otherwise(F.lit("normal"))
        )
        
        # Step 10: Add Overall Metrics
        if exclude_outliers == "Yes":
            df_result_filtered = df_result.filter(F.col(f"wk{i}_outlier_flag")== "normal")
        else:
            df_result_filtered = df_result
        
        values = [row[f"wk{i}_difference_in_difference_{metric_column}"] for 
                row in df_result.select(f"wk{i}_difference_in_difference_{metric_column}").collect()]
        # One-sample t-test against mean = 0
        t_stat, p_val = stats.ttest_1samp(values, popmean=0)            

        overall_metrics_results = df_result.groupby(
            "event_name",
            F.lit(f"wk{i}_impact").alias("week"),
            F.concat("start_date", F.lit(" to "), "end_date").alias("event_period"),      
        ).agg(      
            F.count("account_id").alias("n_obs"),
            F.avg(f"wk{i}_prev_growth_{metric_column}").alias("avg_prev_growth"),
            F.avg(f"wk{i}_post_growth_{metric_column}").alias("avg_post_growth"),
            F.avg(f"wk{i}_difference_in_difference_{metric_column}").alias("avg_difference_in_difference"),
            F.avg(f"wk{i}_growth_{metric_column}").alias("avg_growth"),
            F.sum(f"wk{i}_growth_{metric_column}").alias("total_growth"),
            F.lit(t_stat).alias("t_score"),
            F.lit(p_val).alias("p_value"),
            F.lit(categorize_p_value(p_val)).alias("evidence_strength")
        )

        if overall_metrics is None:
            overall_metrics = overall_metrics_results
        else:
            overall_metrics = overall_metrics.union(overall_metrics_results)


    return overall_metrics

# COMMAND ----------

# MAGIC %md
# MAGIC ### Updated Overall level impact

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType
import pandas as pd
from scipy import stats

def get_overall_campaign_impact(df_result, exclude_outliers, metric_column, weeks_to_analyze):
  # period_baseline = ["2025-01-15", "2025-02-01"]  
  # Get the event period_baseline

  # Select relevant columns and convert to Pandas
  # pdf = df_result.toPandas()

  # Function to categorize p-value
  def categorize_p_value(p):
      if p < 0.001:
          return "Very strong evidence"
      elif p < 0.01:
          return "Strong evidence"
      elif p < 0.05:
          return "Moderate evidence"
      elif p < 0.1:
          return "Weak evidence"
      else:
          return "No evidence"
        
  results = None
  for i in range(1, weeks_to_analyze + 1):    
    if exclude_outliers == "Yes":
      pdf_filtered = df_result.filter(F.col(f"wk{i}_outlier_flag")== "normal")
    else:
      pdf_filtered = df_result
      
    values = [row[f"wk{i}_difference_in_difference_{metric_column}"] for 
              row in df_result.select(f"wk{i}_difference_in_difference_{metric_column}").collect()]

    # One-sample t-test against mean = 0
    t_stat, p_val = stats.ttest_1samp(values, popmean=0)    

    overall_metrics = df_result.groupby(
      "event_name",
      F.lit(f"wk{i}_impact").alias("week"),
      F.concat("start_date", F.lit(" to "), "end_date").alias("event_period"),      
    ).agg(      
      F.count("account_id").alias("n_obs"),
      F.avg(f"wk{i}_prev_growth_{metric_column}").alias("avg_prev_growth"),
      F.avg(f"wk{i}_post_growth_{metric_column}").alias("avg_post_growth"),
      F.avg(f"wk{i}_difference_in_difference_{metric_column}").alias("avg_difference_in_difference"),
      F.avg(f"wk{i}_growth_{metric_column}").alias("avg_growth"),
      F.sum(f"wk{i}_growth_{metric_column}").alias("total_growth"),
      F.lit(t_stat).alias("t_score"),
      F.lit(p_val).alias("p_value"),
      F.lit(categorize_p_value(p_val)).alias("evidence_strength")
    )

    # prev_session_avg_growth = df_result.agg(F.avg(f"wk{i}_prev_growth_{metric_column}")).collect()[0][0]
    # post_session_avg_growth = df_result.agg(F.avg(f"wk{i}_post_growth_{metric_column}")).collect()[0][0]

    # avg_growth = df_result.agg(F.avg(f"wk{i}_growth_{metric_column}")).collect()[0][0]
    # total_growth = df_result.agg(F.sum(f"wk{i}_growth_{metric_column}")).collect()[0][0]

    # avg_impact = df_result.agg(F.avg(f"wk{i}_difference_in_difference_{metric_column}")).collect()[0][0]

    if results is None:
      results = overall_metrics
    else:
      results = results.union(overall_metrics)

    # results.append({
    #     "week": f"wk{i}_impact",
    #     "n_obs": df_result.count(),      
    # #     # "event_period": f"{period_baseline[0]} to {period_baseline[1]}",  
    #     "avg_prev_growth": overall_metrics[0][0],
    #     "avg_post_growth": overall_metrics[0][1],
    #     "avg_difference_in_difference": overall_metrics[0][2],
    #     "avg_growth": overall_metrics[0][3],
    #     "total_growth": overall_metrics[0][4],        
    #     "t_score": t_stat,
    #     "p_value": p_val,
    #     "evidence_strength": categorize_p_value(p_val)
    # })

  # Convert to Spark DataFrame to display in Databricks
  return df_result

# COMMAND ----------

df_sessions = event_sessions_list.filter(f.col("Event_Name")=="Databricks Data Intelligence Day Bangalore India 2025")
df_sessions_filtered = df_sessions.filter(F.col("completions")>1)

df_result = get_campaign_impact(df_sessions_filtered, metric_column = "wau_human", weeks_to_analyze = 5)  

display(df_result)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Updated All APJ Events

# COMMAND ----------

event_list = event_sessions_list.groupby('Event_Name').agg(
  F.sum('enrollments').alias('enrollments'), 
  F.sum('completions').alias('completions'), 
  F.sum('new_learners').alias('new_learners'),
  F.countDistinct("account_id").alias("accounts_with_enrolments"),
  F.countDistinct(F.when(F.col("completions") > 0, F.col("account_id"))).alias("accounts_with_completions"),
  F.countDistinct(F.when(F.col("completions") > 1, F.col("account_id"))).alias("accounts_with_more_than_one_completions"))
display(event_list)

# COMMAND ----------

df_clean_up = event_list.select("Event_Name", F.col("accounts_with_enrolments").alias("accounts"), F.lit("Accounts with enrollments").alias("criteria"))\
  .union(event_list.select("Event_Name", F.col("accounts_with_completions").alias("accounts"), F.lit("Accounts with completions").alias("criteria")))\
  .union(event_list.select("Event_Name", F.col("accounts_with_more_than_one_completions").alias("accounts"), F.lit("Accounts more than 1 completion").alias("criteria")))

df_sessions_filtered = event_sessions_list.filter(F.col("completions")>1)
df_result = get_campaign_impact(df_sessions_filtered, metric_column = "wau_human", weeks_to_analyze = 5)

# df_clean_up = df_clean_up.union(
#   spark.createDataFrame( 
#     [(row["Event_Name"], df_result.count(), "Excluding accounts without usage on all the weeks analyzed")], 
#     ["Event_Name", "accounts", "criteria"]))

# df_clean_up = df_clean_up.union(
#   spark.createDataFrame(
#     [(row["Event_Name"], overall_impact.count(), "Excluding outliers")], 
#     ["Event_Name", "accounts", "criteria"]))


display(df_result)

# COMMAND ----------

df_sessions_filtered = event_sessions_list.filter(F.col("completions")>1)
df_result = get_campaign_impact(df_sessions_filtered, metric_column = "wau_human", weeks_to_analyze = 5, exclude_outliers = "No")

display(df_result)

# COMMAND ----------

df_sessions_filtered = event_sessions_list.filter((F.col("completions")>1) & (F.col("Event_Name") == "Databricks Asia-Pacific Learning Festival"))
df_result, overall_impact = get_campaign_impact(df_sessions_filtered, metric_column = "wau_human", weeks_to_analyze = 5, exclude_outliers = "No")


display(df_result)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Individual analysis

# COMMAND ----------

df_sessions = event_sessions_list.filter(f.col("Event_Name")=="Databricks Data Intelligence Day Bangalore India 2025")

df_result = get_campaign_impact(df_sessions, metric_column = "wau_human", weeks_to_analyze = 5)

display(df_result)

# COMMAND ----------

overall_impact = get_overall_campaign_impact(df_result, exclude_outliers = "Yes", metric_column = "wau_human", weeks_to_analyze = 5)

display(overall_impact)