-- Databricks notebook source
SELECT
  T1.month
  , T1.customer_id
  , SUM(T1.mau_users_churn) * -1 AS churn
  , SUM(T1.mau_users_net_new) AS net_new
  , SUM(T1.mau) AS mau
FROM
  main.field_self_service.fact_mau_users AS T1
WHERE
  T1.month = '2024-12-01'  
GROUP BY ALL
HAVING SUM(T1.mau_users_churn) < 0
AND SUM(T1.mau) = 0