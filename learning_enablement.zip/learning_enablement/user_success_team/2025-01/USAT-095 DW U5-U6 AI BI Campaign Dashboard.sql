-- Databricks notebook source
-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
SELECT 
  CASE
    WHEN event_name IN('Treinamento Databricks Brasil', 'Treinamento Databricks Brasil Dez', 'Entrenamiento Databricks en Español') THEN 'Banco Bradesco'
    WHEN event_name IN('Emerging Enterprise') THEN 'Curinos' ELSE event_name END company
  , event_name
  , session_code 
  , CAST(session_date AS DATE) AS session_date

FROM VALUES
  ('AB-InBev', 26769, '2024-11-04 8:00'),
  ('Treinamento Databricks Brasil', 35276, '2024-11-26 9:00'),
  ('Entrenamiento Databricks en Español', 35490, '2024-11-26 10:00'),
  ('P&G', 36631, '2024-12-05 8:00'),
  ('Samsara', 46178, '2024-12-11 9:00'),
  ('Emerging Enterprise', 43125, '2024-12-11 12:00'),
  ('Treinamento Databricks Brasil Dez', 43501, '2024-12-12 8:00'),
  ('Retail', 43554, '2024-12-18 13:00'),
  ('HP', 51294, '2025-01-14 8:00'),
  ('Frontier Communications', 46755, '2025-01-17 13:00'),
  ('Tractor Supply Company', 45412, '2025-01-21 12:00'),
  ('Santander', 51991, '2025-01-30 8:00'),
  ('Red Ventures', 50922, '2025-01-30 9:00')
AS _account_sessions(event_name, session_code, session_date);

SELECT * FROM _account_sessions;

-- COMMAND ----------

-- =============================================
-- Title:        
-- Create date: 2025-01-09
-- Description: 
-- =============================================
-- CREATE OR REPLACE TEMPORARY VIEW _event_data AS
WITH _event_registrations
AS (
  SELECT
    X.dimension    
    , X.account_id
    , SUM(CASE WHEN X.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN X.completed_date IS NOT NULL THEN 1 END) AS event_attendees
  FROM(
    SELECT 
      CASE :dimension
        WHEN 'event_name' THEN T2.event_name
        WHEN 'company' THEN T2.company
        WHEN 'account_id' THEN T1.account_id
        WHEN 'parent_account_name' THEN T1.ultimate_parent_account_name
        WHEN 'account_name' THEN T1.updated_account_name
        ELSE '' END as dimension   
      , CAST(T1.ended_timestamp AS DATE) AS session_date
      , T1.updated_account_id AS account_id      
      , T1.enrolled_date
      , T1.completed_date          
    FROM 
        main.field_learning_enablement.all_enrollments AS T1
    INNER JOIN
      _account_sessions AS T2 USING(session_code)
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1) 
      AND T1.enrolled_date > '2024-10-11'          
  ) AS X
  GROUP BY ALL
), _learners
AS (
  SELECT
    X.account_id
    , X.account_name
    , SUM(X.baseline_learners) AS baseline_learners
    , SUM(X.current_learners) AS current_learners
  FROM(
    SELECT 
      T1.updated_account_id AS account_id
      , T1.updated_account_name AS account_name    
      , T1.learner_email_hash    
      , MAX(CASE WHEN T1.completed_date < '2024-10-30' THEN 1 END) AS baseline_learners
      , MAX(CASE WHEN T1.learner_email_hash IS NOT NULL THEN 1 END) AS current_learners
    FROM 
      main.field_learning_enablement.all_learners T1
    WHERE 
      T1.processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
      AND T1.updated_account_id IN (SELECT DISTINCT T1.account_id FROM _event_registrations T1)  
      AND T1.dataset IN ("net new learners","fiscal learners")            
    GROUP BY ALL
  ) AS X
  GROUP BY ALL
), _event_data
AS (
  SELECT  
    T1.dimension
    , nvl(T1.account_id, T2.account_id) AS account_id    
    , SUM(T2.baseline_learners) AS baseline_learners
    , SUM(T2.current_learners) AS current_learners
    , SUM(T1.event_registrations) AS event_registrations
    , SUM(T1.event_attendees) AS event_attendees
  FROM
    _event_registrations AS T1
  FULL JOIN
    _learners AS T2 USING(account_id)
  GROUP BY ALL
), _mau_data
AS (
  SELECT  
    T1.customer_id AS account_id
    , ROUND(AVG(CASE WHEN month BETWEEN '2024-08-01' and '2024-10-01' THEN mau ELSE NULL END)) AS baseline_mau
    , SUM(CASE WHEN month_order = 1 THEN mau ELSE NULL END) AS current_mau
    , SUM(CASE WHEN month_order = 1 THEN mau_new ELSE NULL END) AS new_mau
  FROM(
    SELECT
      row_number() OVER(PARTITION BY T1.customer_id ORDER BY T1.month DESC) AS month_order
      , T1.month
      , T1.customer_id
      , SUM(T1.mau) AS mau
      , SUM(T1.mau_users_new) AS mau_new      
    FROM
      main.field_self_service.fact_mau_users T1          
    GROUP BY 
      T1.month
      , T1.customer_id
  ) AS T1  
  GROUP BY
    T1.customer_id
)

SELECT   
  a.dimension  
  -- , ac.ultimate_parent_account_id AS parent_account_id
  -- , ac.ultimate_parent_account AS parent_account_name  
  -- , ac.business_unit AS bu
  -- , a.account_id
  -- , ac.account_name  

  , nvl(SUM(md.baseline_mau), 0) AS baseline_mau
  , nvl(SUM(a.baseline_learners), 0) AS baseline_learners

  , nvl(SUM(md.current_mau), 0) AS current_mau 
  , nvl(SUM(a.current_learners), 0) AS current_learners  

  , nvl(SUM(a.event_registrations), 0) AS event_registrations
  , nvl(SUM(a.event_attendees), 0) AS event_attendees  
  -- , SUM(md.new_mau) AS new_mau  
FROM 
  _event_data a
LEFT JOIN 
  _mau_data md USING(account_id)
LEFT JOIN
  main.gtm_data.core_accounts_curated as ac USING(account_id)
GROUP BY ALL