-- Databricks notebook source
-- MAGIC %md
-- MAGIC ......................................................................................... \
-- MAGIC ......................................................................................... \
-- MAGIC **Request Name:**    Measuring the growth considering 1d before and after the event  \
-- MAGIC **Description:**     Calculate the growth after the session using as baseline the MAU number before the session_date, and comparing against the MAU after the session_date \
-- MAGIC **Jira Ticket:**     [USAT-152](https://databricks.atlassian.net/browse/USAT-152) \
-- MAGIC **SLA:**     No SLA \
-- MAGIC ......................................................................................... \
-- MAGIC ......................................................................................... 
-- MAGIC
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 1- USAT-152

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
SELECT 
  CASE
    WHEN event_name IN('Treinamento Databricks Brasil', 'Treinamento Databricks Brasil Dez', 'Entrenamiento Databricks en Español') THEN 'Banco Bradesco'
    WHEN event_name IN('Emerging Enterprise') THEN 'Curinos' ELSE event_name END company
  , event_name
  , session_code   
FROM VALUES
  ('AB-InBev', '26769'),
  ('Treinamento Databricks Brasil', '35276'),
  ('Entrenamiento Databricks en Español', '35490'),
  ('P&G', '36631'),
  ('Samsara', '46178'),
  ('Emerging Enterprise', '43125'),
  ('Treinamento Databricks Brasil Dez', '43501'),
  ('Retail', '43554'),
  ('HP', '51294'),
  ('Frontier Communications', '46755'),
  ('Tractor Supply Company', '45412'),
  ('Santander', '51991'),
  ('Red Ventures', '50922')
AS _account_sessions(event_name, session_code);

/*

*/
WITH _event_registrations
AS (  
  SELECT
    T1.dimension_3    
    , T1.account_id
    , CASE
        WHEN T1.session_date = first_session_date THEN DATE_ADD(T1.session_date, -2) 
        WHEN T1.session_date = last_session_date THEN DATE_ADD(T1.session_date, 2) 
      END AS session_date
    , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
  FROM(
    SELECT 
      CASE :dimension_3
        WHEN 'Event Name' THEN T2.event_name
        WHEN 'Company' THEN T2.company
        WHEN 'Account Id' THEN T1.account_id
        WHEN 'Parent Account' THEN T1.ultimate_parent_account_name
        WHEN 'Account Name' THEN T1.updated_account_name
        ELSE '' END as dimension_3   
      , T1.session_code
      , SPLIT_PART(T1.session_name, ' | ', 3) AS session_name
      , CAST(T1.ended_timestamp AS DATE) AS session_date
      , MIN(CAST(T1.ended_timestamp AS DATE)) OVER(PARTITION BY T1.updated_account_id) AS first_session_date
      , MAX(CAST(T1.ended_timestamp AS DATE)) OVER(PARTITION BY T1.updated_account_id) AS last_session_date
      , T1.updated_account_id AS account_id      
      , T1.enrolled_date
      , T1.completed_date
    FROM 
        main.field_learning_enablement.all_enrollments AS T1
    INNER JOIN
      _account_sessions AS T2 USING(session_code)
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1) 
      AND T1.enrolled_date > '2024-10-11'      
  ) AS T1
  GROUP BY ALL  
)

, _learners
AS (
  SELECT
    X.account_id
    , X.account_name
    , SUM(X.baseline_learners) AS baseline_learners
    , SUM(X.current_learners) AS current_learners
  FROM(
    SELECT 
      T1.updated_account_id AS account_id
      , T1.updated_account_name AS account_name    
      , T1.learner_email_hash    
      , MAX(CASE WHEN T1.completed_date < '2024-10-30' THEN 1 END) AS baseline_learners
      , MAX(CASE WHEN T1.learner_email_hash IS NOT NULL THEN 1 END) AS current_learners
    FROM 
      main.field_learning_enablement.all_learners T1
    WHERE 
      T1.processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
      AND T1.updated_account_id IN (SELECT DISTINCT T1.account_id FROM _event_registrations T1)  
      AND T1.dataset IN ("net new learners","fiscal learners")            
    GROUP BY ALL
  ) AS X
  GROUP BY ALL
), _event_data
AS (
  SELECT  
    T1.dimension_3
    , nvl(T1.account_id, T2.account_id) AS account_id    
    , SUM(T2.baseline_learners) AS baseline_learners
    , SUM(T2.current_learners) AS current_learners
    , SUM(T1.event_registrations) AS event_registrations
    , SUM(T1.event_attendees) AS event_attendees
  FROM
    _event_registrations AS T1
  FULL JOIN
    _learners AS T2 USING(account_id)
  GROUP BY ALL
)
, _mau_data
AS (
  SELECT
    T1.account_id
    , SUM(T1.mau_pre_event) AS mau_pre_event
    , SUM(T1.mau_post_event) AS mau_post_event
    , SUM(CASE WHEN T1.mau_pre_event = 0 THEN T1.mau_post_event ELSE 0 END) AS new_mau_post_event
  FROM(
    SELECT
      T1.account_id
      , T1.user_id
      , SUM(CASE WHEN T1.date = T1.first_session_date THEN mau ELSE 0 END) AS mau_pre_event
      , SUM(CASE WHEN T1.date = T1.last_session_date THEN mau ELSE 0 END) AS mau_post_event
    FROM(
      SELECT DISTINCT
        T2.customer_id AS account_id
        , T2.date
        , MIN(T2.date) OVER(PARTITION BY T2.customer_id) AS first_session_date
        , MAX(T2.date) OVER(PARTITION BY T2.customer_id) AS last_session_date
        , T2.user_id
        , IFF(T2.login_num_events_t28d > 0, 1, 0) AS mau  
      FROM
        main.data_product_features.user_metrics AS T2
      INNER JOIN
        _event_registrations T1      
      ON 
        T2.ds = T1.session_date
        AND T2.customer_id = T1.account_id             
    ) AS T1
    GROUP BY ALL
  ) AS T1
  GROUP BY ALL
)

SELECT   
  a.dimension_3  
  , ac.ultimate_parent_account AS parent_account_name  
  , ac.business_unit AS bu  
  
  , COUNT(DISTINCT a.account_id) AS accounts
  , nvl(SUM(a.event_registrations), 0) AS event_registrations
  , nvl(SUM(a.event_attendees), 0) AS event_attendees  

  , TRY_DIVIDE(SUM(md.mau_post_event), SUM(md.mau_pre_event)) - 1 AS mau_growth 

  , nvl(SUM(md.mau_post_event), 0) AS mau_post_event 
  , nvl(SUM(md.mau_pre_event), 0) AS mau_pre_event
  , nvl(SUM(md.new_mau_post_event), 0) AS new_mau_post_event  

  , nvl(SUM(a.baseline_learners), 0) AS baseline_learners
  , nvl(SUM(a.current_learners), 0) AS current_learners  
  
FROM 
  _event_data a
LEFT JOIN 
  _mau_data md USING(account_id)
LEFT JOIN
  main.gtm_data.core_accounts_curated as ac USING(account_id)
GROUP BY ALL

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 2- USAT-203 DW U5/U6 AI BI Campaign Dashboard V2

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
SELECT 
  CASE
    WHEN event_name IN('Treinamento Databricks Brasil', 'Treinamento Databricks Brasil Dez', 'Entrenamiento Databricks en Español') THEN 'Banco Bradesco'
    WHEN event_name IN('Emerging Enterprise') THEN 'Curinos' ELSE event_name END company
  , event_name
  , session_code   
FROM VALUES
  ('AB-InBev', '26769'),
  ('Treinamento Databricks Brasil', '35276'),
  ('Entrenamiento Databricks en Español', '35490'),
  ('P&G', '36631'),
  ('Samsara', '46178'),
  ('Emerging Enterprise', '43125'),
  ('Treinamento Databricks Brasil Dez', '43501'),
  ('Retail', '43554'),
  ('HP', '51294'),
  ('Frontier Communications', '46755'),
  ('Tractor Supply Company', '45412'),
  ('Santander', '51991'),
  ('Red Ventures', '50922')
AS _account_sessions(event_name, session_code);

/*

*/
WITH _event_registrations
AS (  
  -- =============================================
  -- Description: This CTE calculates the event registrations and attendees for each account, along with the session details.  
  -- =============================================
  SELECT
    T1.account_id    
    , T1.company
    , T1.session_code
    , T1.session_name
    , T1.session_date
    , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
  FROM(
    SELECT 
      T1.session_code
      , TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name      
      , CAST(T1.ended_timestamp AS DATE) AS session_date
      , T1.updated_account_id AS account_id      
      , T1.enrolled_date
      , T1.completed_date
      , T2.company
    FROM 
        main.field_learning_enablement.all_enrollments AS T1
    INNER JOIN
      _account_sessions AS T2 USING(session_code)
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)             
  ) AS T1
  GROUP BY ALL  
), _event_account_sessions
AS (
  -- =============================================
  -- Description: CTE created to get the dates to calculate the MAU before and after the event.   
  -- is_baseline is used to identify if the date is to calculate the MAU before and after the event.
  -- =============================================
  SELECT
    T1.account_id
    , T1.session_code
    , DATE_SUB(MIN(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison
    , 1 AS is_baseline
  FROM
    _event_registrations AS T1   
  GROUP BY ALL
  UNION
  SELECT
    T1.account_id
    , T1.session_code
    , DATE_ADD(MAX(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison
    , 0 AS is_baseline
  FROM
    _event_registrations AS T1   
  GROUP BY ALL
), _mau_data
AS (
    SELECT
      T1.session_code
      , T1.account_id      
      , SUM(CASE WHEN T1.is_baseline = 1 THEN mau ELSE 0 END) AS mau_pre_event
      , SUM(CASE WHEN T1.is_baseline = 0 THEN mau ELSE 0 END) AS mau_post_event
    FROM(
      SELECT
        T1.session_code
        , T2.customer_id AS account_id
        , T2.date        
        , T2.user_id
        , IFF(T2.login_num_events_t28d > 0, 1, 0) AS mau
        , T1.is_baseline
      FROM
        main.data_product_features.user_metrics AS T2
      INNER JOIN
        _event_account_sessions T1      
      ON 
        T2.ds = T1.date_comparison
        AND T2.customer_id = T1.account_id              
    ) AS T1    
    GROUP BY ALL  
), _learners
AS (
  SELECT
    T1.account_id    
    , SUM(T1.baseline_learners) AS baseline_learners
    , SUM(T1.current_learners) AS current_learners
  FROM(
    SELECT
      T1.updated_account_id AS account_id      
      , T1.learner_email_hash    
      , MAX(CASE WHEN T1.completed_date < '2024-10-30' THEN 1 END) AS baseline_learners
      , MAX(CASE WHEN T1.learner_email_hash IS NOT NULL THEN 1 END) AS current_learners
    FROM 
      main.field_learning_enablement.all_learners T1
    WHERE 
      T1.processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
      AND T1.updated_account_id IN (SELECT DISTINCT T1.account_id FROM _event_registrations T1)  
      AND T1.dataset IN ("net new learners","fiscal learners")
    GROUP BY ALL
  ) AS T1
  GROUP BY ALL
)

SELECT
  T1.session_code
  , T1.session_name
  , T1.session_date    
  
  , CASE :account_enabled WHEN 1 THEN T1.account_id END AS account_id
  , CASE :account_enabled WHEN 1 THEN T1.account_name END AS account_name
  , CASE :account_enabled WHEN 1 THEN T1.account_name END AS account_name
  , CASE :account_enabled WHEN 1 THEN T1.account_name END AS account_name

  , COUNT(DISTINCT T1.account_id) AS accounts
  , COUNT(DISTINCT CASE WHEN account_sessions > 1 THEN T1.account_id END) AS accounts_with_multiple_sessions


  , TRY_DIVIDE(SUM(T1.mau_post_event), SUM(T1.mau_pre_event)) - 1 AS mau_growth 
  , nvl(SUM(T1.event_registrations), 0) AS event_registrations
  , nvl(SUM(T1.event_attendees), 0) AS event_attendees    

  , nvl(SUM(T1.mau_pre_event), 0) AS mau_pre_event  
  , nvl(SUM(T1.mau_post_event), 0) AS mau_post_event   

  , nvl(SUM(T1.baseline_learners), 0) AS baseline_learners
  , nvl(SUM(T1.current_learners), 0) AS current_learners  
FROM(
  SELECT   
    T1.account_id
    , T4.account_name
    , T4.business_unit AS bu
    , 
    , T1.session_code
    , T1.session_name
    , T1.session_date      
      
    , COUNT(T1.session_code) OVER(PARTITION BY T1.account_id) AS account_sessions

    , nvl(SUM(T1.event_registrations), 0) AS event_registrations
    , nvl(SUM(T1.event_attendees), 0) AS event_attendees    

    , nvl(SUM(T2.mau_pre_event), 0) AS mau_pre_event  
    , nvl(SUM(T2.mau_post_event), 0) AS mau_post_event 

    , nvl(SUM(T3.baseline_learners), 0) AS baseline_learners
    , nvl(SUM(T3.current_learners), 0) AS current_learners  
  FROM 
    _event_registrations T1
  LEFT JOIN 
    _mau_data T2 USING(account_id, session_code)
  LEFT JOIN 
    _learners T3 USING(account_id)
  LEFT JOIN
    main.gtm_data.core_accounts_curated as T4 USING(account_id)
  GROUP BY ALL
) AS T1
GROUP BY ALL

-- COMMAND ----------

SELECT
      T1.account_id      
      , SUM(CASE WHEN T1.date = '2024-12-17' THEN mau ELSE 0 END) AS mau_pre_event
      , SUM(CASE WHEN T1.date = '2024-12-19' THEN mau ELSE 0 END) AS mau_post_event
    FROM(
      SELECT
        T2.customer_id AS account_id
        , T2.date        
        , T2.user_id
        , IFF(T2.login_num_events_t28d > 0, 1, 0) AS mau        
      FROM
        main.data_product_features.user_metrics AS T2          
      WHERE
        t2.ds > '2024-12-15'        
        AND T2.customer_id IN
          (
            '0016100001TPKyQAAX',
            '0018Y00002yHDF1QAO',
            '0016100001XnYKMAA3',
            '0013f000004RagAAAS',
            '0016100001dr02wAAA',
            '0016100001TPJsfAAH',
            '0016100001EyalJAAR',
            '0016100001DxujWAAR',
            '0016100001BKwCqAAL',
            '0013f000009dsU1AAI'
          )

    ) AS T1
    GROUP BY ALL  

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### USAT-191 - Get Accounts w/ multiple sessions

-- COMMAND ----------

SELECT
  month,
  sum(mau)
FROM
  main.field_self_service.fact_mau_users
GROUP BY ALL

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
SELECT 
  CASE
    WHEN event_name IN('Treinamento Databricks Brasil', 'Treinamento Databricks Brasil Dez', 'Entrenamiento Databricks en Español') THEN 'Banco Bradesco'
    WHEN event_name IN('Emerging Enterprise') THEN 'Curinos' ELSE event_name END company
  , event_name
  , session_code   
FROM VALUES
  ('AB-InBev', '26769'),
  ('Treinamento Databricks Brasil', '35276'),
  ('Entrenamiento Databricks en Español', '35490'),
  ('P&G', '36631'),
  ('Samsara', '46178'),
  ('Emerging Enterprise', '43125'),
  ('Treinamento Databricks Brasil Dez', '43501'),
  ('Retail', '43554'),
  ('HP', '51294'),
  ('Frontier Communications', '46755'),
  ('Tractor Supply Company', '45412'),
  ('Santander', '51991'),
  ('Red Ventures', '50922')
AS _account_sessions(event_name, session_code);

SELECT
  COUNT(DISTINCT T1.account_id) AS accounts
  , COUNT(DISTINCT CASE WHEN sessions > 1 THEN T1.account_id END) AS accounts_multiple_sessions
FROM(
  SELECT
    T1.account_id        
    , COUNT(DISTINCT T1.session_code) AS sessions
  FROM(
    SELECT 
      T1.session_code
      , TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name      
      , CAST(T1.ended_timestamp AS DATE) AS session_date
      , T1.updated_account_id AS account_id      
      , T1.enrolled_date
      , T1.completed_date
      , T2.company
    FROM 
        main.field_learning_enablement.all_enrollments AS T1
    INNER JOIN
      _account_sessions AS T2 USING(session_code)
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)             
  ) AS T1
  GROUP BY ALL  
) AS T1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### USAT-190 - + Hybrid events (Martin & Jim's dashboard)

-- COMMAND ----------

SELECT
  ae.session_code      
  , TRIM(SPLIT_PART(ae.session_name, '|', 3)) AS session_name      
  , CAST(ae.ended_timestamp AS DATE) AS session_date
  , ae.updated_account_id AS account_id      
  , ae.enrolled_date
  , ae.completed_date   
  , e.*
  --, u.*
  -- u.airtable_account_name,
  -- u.id_coupon,
  -- u.code,
  -- u.valid_from,
  -- u.valid_to,
  , u.userID
  -- u.username,
  -- u.transactionID,
  -- u.subscription_trans_id,
  -- u.subStartDAre as Subscription_start,
  -- u.SubEndDate as Subscription_end,
  -- e.course_id,
  -- e.course_code,
  -- e.course_name,
  -- ae.course_id as enroll_course_id,
  -- ae.enrolled_date,
  -- ae.status,
  -- ae.completed_date
FROM
  main.team_field_user_enablement.vw_coupon_usage u
LEFT JOIN 
  main.it_training_silver.docebo_subscription_enrollments e 
ON 
  e.transaction_id = u.subscription_trans_id
  AND e.learner_user_id = u.userID
  AND e.processDate = (select max(processDate) from main.it_training_silver.docebo_subscription_enrollments)
LEFT JOIN 
  main.field_learning_enablement.all_enrollments ae ON ae.course_id = e.course_id
  AND ae.learner_user_id = e.learner_user_id
  AND ae.enrolled_date between u.subStartDAre
  and u.SubEndDate
  AND ae.processDate = (select max(processDate) from main.field_learning_enablement.all_enrollments)
WHERE
  u.program = 'Hybrid Days'
  AND u.id_coupon = 26949

-- COMMAND ----------

  SELECT DISTINCT
    date_trunc('MONTH', T1.date)::date as month
    , T1.date
    , min(date_trunc('MONTH', T1.date)::date) over(partition by T1.user_id)::date as min_month
    , T1.customer_id
    , T1.user_id AS user_id
    , IFF(login_num_events_t28d > 0, 1, 0) AS mau
    , IFF(login_num_events_t28d > 0 AND total_dollars_t28d > 0, 1, 0) AS mau_producers
    , IFF(login_num_events_t7d > 0 AND total_dollars_t7d > 0, 1, 0) AS wau_producers
    , CASE 
        WHEN total_dollars_t28d > 1000 THEN 'Very high usage (>1k)' 
        WHEN total_dollars_t28d > 100 THEN 'High usage (100-1000)' 
        WHEN total_dollars_t28d > 10 THEN 'Medium usage (10-100)'
        WHEN total_dollars_t28d > 0 THEN 'Low usage (0-10)'
        WHEN total_dollars_t28d = 0 THEN 'No usage (0)' END AS segmentation_by_size
    , total_dollars_t7d
    , total_dollars_t28d
    , login_num_events_t7d
    , login_num_events_t28d
  FROM 
    main.data_product_features.user_metrics AS T1
  WHERE 
    
    salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')    
    AND date >= '2024-01-01'
    AND (DAYOFMONTH(date) = 28 OR date = (SELECT MAX(date) FROM main.data_product_features.user_metrics WHERE DAYOFMONTH(date)<=28))

-- COMMAND ----------

SELECT 
  T1.session_code      
  , TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name      
  , CAST(T1.ended_timestamp AS DATE) AS session_date
  , T1.updated_account_id AS account_id      
  , T1.enrolled_date
  , T1.completed_date        
  , T1.learner_email
  , T1.course_name
FROM 
    main.field_learning_enablement.all_enrollments AS T1
WHERE 
  T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)      
  AND (T1.learner_email = 'abraham.fuertes@databricks.com')

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### USAT-204 - Calculate overall numbers removing the duplication

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
-- breakdown_data = 'Overall' the query will return the overall event registrations and attendees. 
-- breakdown_data = 'Account' the query will return the event registrations and attendees at Account level. 
-- breakdown_data parameter has other value the query will return the session registrations and attendees at Event level.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
SELECT 
  event_name
  , session_code   
FROM VALUES
  ('AB-InBev', '26769'),
  ('Treinamento Databricks Brasil', '35276'),
  ('Entrenamiento Databricks en Español', '35490'),
  ('P&G', '36631'),
  ('Samsara', '46178'),
  ('Emerging Enterprise', '43125'),
  ('Treinamento Databricks Brasil Dez', '43501'),
  ('Retail', '43554'),
  ('HP', '51294'),
  ('Frontier Communications', '46755'),
  ('Tractor Supply Company', '45412'),
  ('Santander', '51991'),
  ('Red Ventures', '50922')
AS _account_sessions(event_name, session_code);

/*

*/
WITH _nnl as( -- Net New Learners
  SELECT 
    learner_user_id, 
    course_code, 
    completed_date
  FROM 
    main.field_learning_enablement.all_learners
  WHERE 
    processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    AND dataset = 'net new learners'
), _event_registrations
AS (  
  -- =============================================
  -- Description: This CTE calculates the event registrations and attendees for each account, along with the session details.  
  -- =============================================
  SELECT
    T1.account_id      
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_code ELSE 'Overall' END AS session_code
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_name END AS session_name
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_date END AS session_date
    , DATE_SUB(MIN(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison_min
    , DATE_ADD(MAX(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison_max          

    , COUNT(DISTINCT T1.session_code) AS account_sessions
    , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
    , SUM(CASE WHEN T1.learner_user_id IS NOT NULL THEN 1 END) AS event_net_new_learners
  FROM(
    SELECT 
      T1.session_code      
      , TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name      
      , CAST(T1.ended_timestamp AS DATE) AS session_date
      , T1.updated_account_id AS account_id      
      , T1.enrolled_date
      , T1.completed_date      
      , T3.learner_user_id
    FROM 
        main.field_learning_enablement.all_enrollments AS T1
    INNER JOIN
      _account_sessions AS T2 USING(session_code)
    LEFT JOIN
      _nnl AS T3 USING(learner_user_id, course_code)
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)      
      AND (:session_code = 'All' OR :session_code = T1.session_code)
  ) AS T1
  GROUP BY ALL 
), _mau_data
AS (
  SELECT
    T1.session_code
    , T1.account_id      
    , SUM(T1.mau_post_event) AS mau_post_event
    , SUM(T1.mau_pre_event) AS mau_pre_event    
    , SUM(T1.mau_post_event) - nvl(SUM(T1.mau_pre_event), 0) AS mau_growth
  FROM(
    SELECT
      T1.session_code
      , T2.customer_id AS account_id
      , T2.date        
      , T2.user_id
      , CASE WHEN T2.date = T1.date_comparison_max THEN T2.mau END mau_post_event
      , CASE WHEN T2.date = T1.date_comparison_min THEN T2.mau END mau_pre_event              
    FROM
      main.field_self_service.fact_daily_mau AS T2
    INNER JOIN
      _event_registrations T1      
    ON 
      T2.customer_id = T1.account_id
    WHERE
      T2.date IN(T1.date_comparison_min, T1.date_comparison_max)
  ) AS T1    
  GROUP BY ALL  
)

SELECT
  T1.session_code
  , T1.session_name
  , T1.session_date    
  , CASE :breakdown_data WHEN 'Account' THEN T1.account_id END AS account_id
  , CASE :breakdown_data WHEN 'Account' THEN T1.account_name END AS account_name
  , COUNT(DISTINCT T1.account_id) AS accounts
  , COUNT(DISTINCT CASE WHEN account_sessions > 1 THEN T1.account_id END) AS accounts_with_multiple_sessions  
  
  , nvl(SUM(T1.event_registrations), 0) AS event_registrations
  , nvl(SUM(T1.event_attendees), 0) AS event_attendees    
  , nvl(SUM(T1.event_net_new_learners), 0) AS event_net_new_learners    
  , nvl(SUM(T1.event_attendees)/SUM(T1.event_registrations), 0) AS percentage_attendees    

  , SUM(T1.mau_pre_event) AS mau_pre_event  
  , SUM(T1.mau_post_event) AS mau_post_event
  , SUM(T1.mau_growth) AS mau_growth 
FROM(
  SELECT   
    T1.account_id
    , T4.account_name
    , T1.session_code
    , T1.session_name
    , T1.session_date
    
    , SUM(T1.account_sessions) OVER(PARTITION BY T1.account_id) AS account_sessions

    , T1.event_registrations
    , T1.event_attendees
    , T1.event_net_new_learners

    , T2.mau_pre_event
    , T2.mau_post_event
    , T2.mau_growth
  FROM 
    _event_registrations T1
  LEFT JOIN 
    _mau_data T2 USING(account_id, session_code)
  LEFT JOIN
    main.gtm_data.core_accounts_curated as T4 USING(account_id)
  -- WHERE
  --   (:BU = 'All' OR T4.business_unit = :BU)
  --   AND (:BU_1 = 'All' OR T4.sales_subregion_level_1 = :BU_1)    
  --   AND (:account_name = 'All' OR T4.account_name = :account_name)
) AS T1
GROUP BY ALL

-- COMMAND ----------



SELECT
      T2.customer_id AS account_id
      , T2.date        
      , T2.user_id
      , T2.*
    FROM
      main.field_self_service.fact_daily_mau AS T2    
    WHERE
      T2.customer_id = '0013f000005SHkkAAG'
      


-- COMMAND ----------

  SELECT 
    date_trunc('MONTH', T1.date)::date as month
    , T1.date
    , T1.customer_id
    , min(date_trunc('MONTH', T1.date)::date) over(partition by T1.user_id)::date as min_month    
    , T1.user_id AS user_id
    , sum(IFF(login_num_events_t28d > 0, 1, 0)) AS mau
    , sum(IFF(login_num_events_t28d > 0 AND total_dollars_t28d > 0, 1, 0)) AS mau_producers
    , sum(IFF(login_num_events_t7d > 0 AND total_dollars_t7d > 0, 1, 0)) AS wau_producers
    , sum(total_dollars_t7d) AS total_dollars_t7d
    , sum(total_dollars_t28d) AS total_dollars_t28d
    , sum(login_num_events_t7d) AS login_num_events_t7d
    , sum(login_num_events_t28d) AS login_num_events_t28d
  FROM 
    main.data_product_features.user_metrics AS T1
  WHERE 
    salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')    
    AND date >= '2024-01-01'    
    AND T1.customer_id = '0013f000005SHkkAAG'
  GROUP BY ALL

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
SELECT 
  CASE
    WHEN event_name IN('Treinamento Databricks Brasil', 'Treinamento Databricks Brasil Dez', 'Entrenamiento Databricks en Español') THEN 'Banco Bradesco'
    WHEN event_name IN('Emerging Enterprise') THEN 'Curinos' ELSE event_name END company
  , event_name
  , session_code   
FROM VALUES
  ('AB-InBev', '26769'),
  ('Treinamento Databricks Brasil', '35276'),
  ('Entrenamiento Databricks en Español', '35490'),
  ('P&G', '36631'),
  ('Samsara', '46178'),
  ('Emerging Enterprise', '43125'),
  ('Treinamento Databricks Brasil Dez', '43501'),
  ('Retail', '43554'),
  ('HP', '51294'),
  ('Frontier Communications', '46755'),
  ('Tractor Supply Company', '45412'),
  ('Santander', '51991'),
  ('Red Ventures', '50922')
AS _account_sessions(event_name, session_code);

/*

*/
WITH _event_registrations
AS (  
  -- =============================================
  -- Description: This CTE calculates the event registrations and attendees for each account, along with the session details.  
  -- =============================================
  SELECT
    T1.account_id    
    , COUNT(DISTINCT T1.session_code) AS account_sessions
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_code ELSE 'Overall' END AS session_code
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_name ELSE 'Overall' END AS session_name
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_date ELSE 'Overall' END AS session_date
    , DATE_SUB(MIN(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison_min
    , DATE_ADD(MAX(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison_max      
    , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
  FROM(
    SELECT 
      T1.session_code
      , TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name      
      , CAST(T1.ended_timestamp AS DATE) AS session_date
      , T1.updated_account_id AS account_id      
      , T1.enrolled_date
      , T1.completed_date      
    FROM 
        main.field_learning_enablement.all_enrollments AS T1
    INNER JOIN
      _account_sessions AS T2 USING(session_code)
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)      
  ) AS T1
  GROUP BY ALL  
)
SELECT
  T1.session_code
  , T1.account_id      
  , SUM(CASE WHEN T1.date = T1.date_comparison_min THEN mau ELSE 0 END) AS mau_pre_event
  , SUM(CASE WHEN T1.date = T1.date_comparison_max THEN mau ELSE 0 END) AS mau_post_event
FROM(
  SELECT
    T1.session_code
    , T2.customer_id AS account_id
    , T2.date        
    , T2.user_id
    , IFF(T2.login_num_events_t28d > 0, 1, 0) AS mau    
    , T1.date_comparison_min
    , T1.date_comparison_max
  FROM
    main.data_product_features.user_metrics AS T2
  INNER JOIN
    _event_registrations T1      
  ON 
    T2.customer_id = T1.account_id
  WHERE
    T2.ds IN(T1.date_comparison_min, T1.date_comparison_max)
) AS T1    
GROUP BY ALL

--00161000005eOizAAE

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### USAT-203 - DW U5/U6 AI BI Campaign Dashboard V2

-- COMMAND ----------

WITH 
mau_baseline as
(
SELECT salesforce_account_id, account_name, ROUND(AVG(MAU),0) mau_baseline
FROM main.field_learning_enablement.monthly_active_users
WHERE processDate = (
    SELECT max(processDate) 
    FROM main.field_learning_enablement.monthly_active_users
)
AND month BETWEEN '2024-08-01' and '2024-10-01'
GROUP BY 1, 2
),

current_mau AS 
(
SELECT date, customer_id, salesforce_account_name, total_num_users_t28d MAU
FROM main.data_product_features.customer_metrics
WHERE date = (SELECT MAX(date) FROM main.data_product_features.customer_metrics) 
),

-- DA MAU baseline
da_mau_baseline
(
SELECT customer_id, AVG(num_users) da_mau_baseline
FROM main.field_self_service.persona
WHERE month BETWEEN '2024-08-01' and '2024-10-01'
AND persona = 'Data Analyst'
GROUP BY 1
),

-- Learners
learners_baseline as
(
SELECT account_id, account_name,  AVG(learners) as learners_baseline 
from main.field_learning_enablement.account_learners_to_mau
WHERE processDate = (select max(processDate) from main.field_learning_enablement.account_learners_to_mau)
AND period BETWEEN '2024-08-01' and '2024-10-01'
GROUP BY 1, 2
),

current_learners AS
(
select account_id, account_name, SUM(learners) as current_learners
from main.field_learning_enablement.account_learners_to_mau
WHERE processDate = (select max(processDate) from main.field_learning_enablement.account_learners_to_mau)
AND period = date_trunc('month', current_date())
GROUP BY 1, 2
),

-- DA lerners
da_learners_baseline as
(
  SELECT account_id, account_name, SUM(DA_learners)/3 as da_learners_baseline
FROM
(
SELECT DATE(DATE_TRUNC( 'MONTH', completed_date)) month,
    updated_account_id AS account_id,
    updated_account_name AS account_name,
    SUM(da_learner) AS DA_learners
FROM main.team_field_user_enablement.vw_ue_learner_by_topic
WHERE completed_date BETWEEN '2024-08-01' and '2024-10-30'
GROUP BY ALL
)
GROUP BY ALL
),

-- Lakeview users
lakeview_users_baseline as
( 
SELECT customer_id, AVG(SQL) sql_users, AVG(Lakeview) AI_BI_users
FROM (
SELECT date_trunc('month',date)::date as month, customer_id,
sum(dbsql_num_users_t28d) as SQL,
sum(lakeview_num_users_t28d) as Lakeview
from main.data_product_features.customer_metrics c 
WHERE date BETWEEN '2024-08-01' and '2024-10-30'
AND dayofmonth(date) = 28
GROUP BY 1, 2
ORDER BY 2, 1
)
GROUP BY 1
),

-- ASQ
asq as 
(
select 
a.id,
a.Account__c,  a.Name, a.Title__c,
a.Request_Type__c, a.Support_Type__c, ASQ_Origin__c, Status__c, End_Date__c
 FROM main.sfdc_bronze.approvalrequest__c a
    WHERE processDate = (select max(processDate) from  main.sfdc_bronze.approvalrequest__c)
    AND a.IsDeleted = 'false'
    AND a.CreatedDate >  to_date('2024-09-25', 'yyyy-MM-dd')  
    --AND Request_Type__c = 'Enablement'
    --AND a.Support_type__c = 'Other(Enablement)'
     AND a.Title__c like '1K AI/BI MAU Growth Campaign'
),

base_table as 
(
-- 
--SELECT COUNT(accounts)
--FROM (
SELECT  ac.account_id, a.*, mb.mau_baseline , cm.MAU current_mau, da_mau_baseline, learners_baseline, current_learners, da_learners_baseline, AI_BI_users, COUNT(asq.id) ASQ  
FROM main.field_self_service.dwh_uc6_5_accounts a
LEFT JOIN main.gtm_data.core_accounts_curated as ac 
    on a.Accounts = ac.account_name
LEFT JOIN mau_baseline mb
ON ac.account_id = mb.salesforce_account_id
LEFT JOIN current_mau cm
  ON ac.account_id = cm.customer_id
LEFT JOIN da_mau_baseline da_mau 
  ON ac.account_id = da_mau.customer_id
LEFT JOIN learners_baseline lb
  ON ac.account_id = lb.account_id
LEFT JOIN current_learners cl
  ON ac.account_id = cl.account_id
LEFT JOIN da_learners_baseline  dalb
  ON ac.account_id = dalb.account_id
LEFT JOIN lakeview_users_baseline 
  ON ac.account_id = lakeview_users_baseline.customer_id
LEFT JOIN asq 
  ON ac.account_id = asq.Account__c
WHERE ac.account_status != 'Prospect' 
AND  `Delivery Date` IS NOT NULL
--AND `a`.`Accounts` = 'Takeda Pharmaceuticals - USA'
--)
GROUP BY ALL
)

SELECT 
    a.BU,
    COUNT(a.Accounts ) AS Count_of_Accounts, 
    COUNT(CASE WHEN a.`CEA Reached out` = 'Yes' THEN 1 ELSE NULL END) AS Reached,
    COUNT(CASE WHEN a.`Account Committed` = 'Yes' THEN 1 ELSE NULL END ) as `Account Committed`,
     COUNT(CASE WHEN a.`Account Set Up ASQ` = 'Yes' THEN 1 ELSE NULL END ) as `ASQ`,
    --SUM(ASQ) ASQ,
    SUM(mau_baseline) AS MAU_Baseline, 
    SUM(current_mau) AS Current_MAU,
    SUM(learners_baseline) AS Learners_Baseline,
    SUM(current_learners) AS Current_Learners
FROM 
   base_table a
   GROUP BY 1
UNION
SELECT 
    'Total' BU,
    COUNT(a.Accounts ) AS Count_of_Accounts, 
    COUNT(CASE WHEN a.`CEA Reached out` = 'Yes' THEN 1 ELSE NULL END) AS Reached,
    COUNT(CASE WHEN a.`Account Committed` = 'Yes' THEN 1 ELSE NULL END ) as `Account Committed`,
     COUNT(CASE WHEN a.`Account Set Up ASQ` = 'Yes' THEN 1 ELSE NULL END ) as `ASQ`,
    --SUM(ASQ) ASQ,
    SUM(mau_baseline) AS MAU_Baseline, 
    SUM(current_mau) AS Current_MAU,
    SUM(learners_baseline) AS Learners_Baseline,
    SUM(current_learners) AS Current_Learners
FROM 
   base_table a
   GROUP BY 1
ORDER BY 1   
--Account Set Up ASQ  
--Account Set Up ASQ

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### USAT-175 - Additional info needed - net new learners

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
-- breakdown_data = 'Overall' the query will return the overall event registrations and attendees. 
-- breakdown_data = 'Account' the query will return the event registrations and attendees at Account level. 
-- breakdown_data parameter has other value the query will return the session registrations and attendees at Event level.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
SELECT 
  event_name
  , session_code   
FROM VALUES
  ('AB-InBev', '26769'),
  ('Treinamento Databricks Brasil', '35276'),
  ('Entrenamiento Databricks en Español', '35490'),
  ('P&G', '36631'),
  ('Samsara', '46178'),
  ('Emerging Enterprise', '43125'),
  ('Treinamento Databricks Brasil Dez', '43501'),
  ('Retail', '43554'),
  ('HP', '51294'),
  ('Frontier Communications', '46755'),
  ('Tractor Supply Company', '45412'),
  ('Santander', '51991'),
  ('Red Ventures', '50922')
AS _account_sessions(event_name, session_code);

/*

*/
WITH _nnl as( -- Net New Learners
  SELECT 
    learner_user_id, 
    course_code, 
    completed_date
  FROM 
    main.field_learning_enablement.all_learners
  WHERE 
    processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    AND dataset = 'net new learners'
), _event_registrations
AS (  
  -- =============================================
  -- Description: This CTE calculates the event registrations and attendees for each account, along with the session details.  
  -- =============================================
  SELECT
    T1.account_id      
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_code ELSE 'Overall' END AS session_code
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_name END AS session_name
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_date END AS session_date
    , DATE_SUB(MIN(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison_min
    , DATE_ADD(MAX(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison_max          

    , COUNT(DISTINCT T1.session_code) AS account_sessions
    , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
    , SUM(CASE WHEN T1.learner_user_id IS NOT NULL THEN 1 END) AS event_net_new_learners
  FROM(
    SELECT 
      T1.session_code      
      , TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name      
      , CAST(T1.ended_timestamp AS DATE) AS session_date
      , T1.updated_account_id AS account_id      
      , T1.enrolled_date
      , T1.completed_date      
      , T3.learner_user_id
    FROM 
        main.field_learning_enablement.all_enrollments AS T1
    INNER JOIN
      _account_sessions AS T2 USING(session_code)
    LEFT JOIN
      _nnl AS T3 USING(learner_user_id, course_code)
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)      
      AND (:session_code = 'All' OR :session_code = T1.session_code)
  ) AS T1
  GROUP BY ALL 
), _mau_data
AS (
  SELECT
    T1.session_code
    , T1.account_id      
    , SUM(CASE WHEN T1.date = T1.date_comparison_min THEN mau END) AS mau_pre_event
    , SUM(CASE WHEN T1.date = T1.date_comparison_max THEN mau END) AS mau_post_event
  FROM(
    SELECT
      T1.session_code
      , T2.customer_id AS account_id
      , T2.date        
      , T2.user_id
      , T2.mau AS mau    
      , T1.date_comparison_min
      , T1.date_comparison_max
    FROM
      main.field_self_service.fact_daily_mau AS T2
    INNER JOIN
      _event_registrations T1      
    ON 
      T2.customer_id = T1.account_id
    WHERE
      T2.date IN(T1.date_comparison_min, T1.date_comparison_max)
  ) AS T1    
  GROUP BY ALL
)

SELECT
  T1.session_code
  , T1.session_name
  , T1.session_date    
  , CASE :breakdown_data WHEN 'Account' THEN T1.account_id END AS account_id
  , CASE :breakdown_data WHEN 'Account' THEN T1.account_name END AS account_name
  , COUNT(DISTINCT T1.account_id) AS accounts
  , COUNT(DISTINCT CASE WHEN account_sessions > 1 THEN T1.account_id END) AS accounts_with_multiple_sessions  
  
  , nvl(SUM(T1.event_registrations), 0) AS event_registrations
  , nvl(SUM(T1.event_attendees), 0) AS event_attendees    
  , nvl(SUM(T1.event_net_new_learners), 0) AS event_net_new_learners    
  , nvl(SUM(T1.event_attendees)/SUM(T1.event_registrations), 0) AS percentage_attendees    

  , SUM(T1.mau_pre_event) AS mau_pre_event  
  , SUM(T1.mau_post_event) AS mau_post_event
  , SUM(T1.mau_post_event) - SUM(T1.mau_pre_event) AS mau_growth 
FROM(
  SELECT   
    T1.account_id
    , T4.account_name
    , T1.session_code
    , T1.session_name
    , T1.session_date
    
    , SUM(T1.account_sessions) OVER(PARTITION BY T1.account_id) AS account_sessions

    , T1.event_registrations
    , T1.event_attendees
    , T1.event_net_new_learners

    , T2.mau_pre_event
    , T2.mau_post_event
  FROM 
    _event_registrations T1
  LEFT JOIN 
    _mau_data T2 USING(account_id, session_code)
  LEFT JOIN
    main.gtm_data.core_accounts_curated as T4 USING(account_id)
  -- WHERE
  --   (:BU = 'All' OR T4.business_unit = :BU)
  --   AND (:BU_1 = 'All' OR T4.sales_subregion_level_1 = :BU_1)    
  --   AND (:account_name = 'All' OR T4.account_name = :account_name)
) AS T1
GROUP BY ALL

-- COMMAND ----------

with _nnl as( -- Net New Learners
    SELECT 
      learner_user_id, 
      course_code, 
      completed_date
    FROM 
      main.field_learning_enablement.all_learners
    WHERE 
      processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
      AND dataset = 'net new learners'
)

SELECT
    -- T1.account_id      
    CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_code ELSE 'Overall' END AS session_code
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_name END AS session_name
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_date END AS session_date
    , DATE_SUB(MIN(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison_min
    , DATE_ADD(MAX(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison_max          

    , COUNT(DISTINCT T1.session_code) AS account_sessions
    , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
    , SUM(CASE WHEN T1.learner_user_id IS NOT NULL THEN 1 END) AS event_net_new_learners
  FROM(
    SELECT 
      T1.session_code      
      , TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name      
      , CAST(T1.ended_timestamp AS DATE) AS session_date
      , T1.updated_account_id AS account_id      
      , T1.enrolled_date
      , T1.completed_date      
      , T3.learner_user_id   
    FROM 
        main.field_learning_enablement.all_enrollments AS T1
    INNER JOIN
      _account_sessions AS T2 USING(session_code)
    LEFT JOIN
      _nnl AS T3 USING(learner_user_id, course_code)
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)      
      AND (:session_code = 'All' OR :session_code = T1.session_code)
      AND T1.session_code = 51991
  ) AS T1
  GROUP BY ALL 

-- COMMAND ----------

/*

*/
WITH _event_registrations
AS (  
  -- =============================================
  -- Description: This CTE calculates the event registrations and attendees for each account, along with the session details.  
  -- =============================================
  SELECT
    T1.account_id      
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_code ELSE 'Overall' END AS session_code
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_name END AS session_name
    , CASE WHEN :breakdown_data <> 'Overall' THEN T1.session_date END AS session_date
    , DATE_SUB(MIN(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison_min
    , DATE_ADD(MAX(T1.session_date), try_cast(:days_attribution AS INT)) AS date_comparison_max          

    , COUNT(DISTINCT T1.session_code) AS account_sessions
    , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
  FROM(
    SELECT 
      T1.session_code      
      , TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name      
      , CAST(T1.ended_timestamp AS DATE) AS session_date
      , T1.updated_account_id AS account_id      
      , T1.enrolled_date
      , T1.completed_date      
    FROM 
        main.field_learning_enablement.all_enrollments AS T1          
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)      
      AND (T1.session_code = 51991)
  ) AS T1
  GROUP BY ALL 
)
-- SELECT
--   T1.session_code
--   , T1.account_id      
--   , SUM(CASE WHEN T1.date = T1.date_comparison_min THEN mau ELSE 0 END) AS mau_pre_event
--   , SUM(CASE WHEN T1.date = T1.date_comparison_max THEN mau ELSE 0 END) AS mau_post_event
-- FROM(
  SELECT
    T1.session_code
    , T2.customer_id AS account_id
    , T2.date        
    , T2.user_id
    , T2.mau AS mau    
    , T1.date_comparison_min
    , T1.date_comparison_max
  FROM
    main.field_self_service.fact_daily_mau AS T2
  INNER JOIN
    _event_registrations T1      
  ON 
    T2.customer_id = T1.account_id
  -- WHERE
  --   T2.date IN(T1.date_comparison_min, T1.date_comparison_max)
-- ) AS T1    
-- GROUP BY ALL



-- COMMAND ----------

SELECT 
    date,
    sum(dbsql_num_users_t28d) as SQL,
    sum(unity_catalog_num_users_t28d) as UC,
    sum(lakeview_num_users_t28d) as Lakeview,
    sum(ds_ml_num_users_t28d) as DSML,
    sum(etl_num_users_t28d) as ETL,
    sum(delta_num_users_t28d) as Delta
FROM 
    main.data_product_features.customer_metrics c
GROUP BY 1