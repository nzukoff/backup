-- Databricks notebook source
WITH _churn
AS (
  SELECT
      T1.month
      , T1.customer_id
      , T1.user_segmentation
      , SUM(T1.mau) AS mau
      , SUM(T1.mau_users_churn) AS mau_users_churn
      , SUM(T1.mau_producers) AS mau_producers
      , SUM(T1.net_new) AS net_new
      , LAG(SUM(T1.mau_producers)) OVER (PARTITION BY customer_id, user_segmentation ORDER BY month) AS prev_mau_producers
    FROM(
      SELECT
        T1.month
        , T1.customer_id
        , CASE WHEN :`Include User Segmentation` = 'Yes' THEN T1.user_segmentation ELSE '' END AS user_segmentation    
        , T1.mau AS mau
        , T1.mau_users_churn AS mau_users_churn
        , T1.mau_producers     
        , T1.mau_users_net_new AS net_new
      FROM
        main.field_self_service.fact_mau_users AS T1
      WHERE 
        -- T1.customer_id = '0013f000002nATdAAM'
        T1.customer_id = '0013f000003o5FvAAI'
    ) AS T1
    GROUP BY month, customer_id, user_segmentation  
)


SELECT
  *
FROM
  _churn AS T1
WHERE 
  T1.mau_users_churn < 0

-- COMMAND ----------

-- =============================================
-- Title: Churn Analysis
-- Create date: 2025-01-15
-- Description: This query creates a temporary view vw_mau_monthly that selects distinct monthly user activity data from the user_metrics table. 
-- 'Include User Segmentation' = 'Yes' Includes break down the numbers by each value of user_segmentation but set consumption by zero. Consumption is only available at customer level.
-- =============================================

WITH _churn
AS (
  SELECT
      T1.month
      , T1.customer_id
      , T1.user_segmentation
      , SUM(T1.mau) AS mau
      , SUM(T1.mau_users_churn) AS churn
      , SUM(T1.mau_producers) AS mau_producers
      , SUM(T1.net_new) AS net_new
      , LAG(SUM(T1.mau_producers)) OVER (PARTITION BY customer_id, user_segmentation ORDER BY month) AS prev_mau_producers
    FROM(
      SELECT
        T1.month
        , T1.customer_id
        , CASE WHEN :`Include User Segmentation` = 'Yes' THEN T1.user_segmentation ELSE '' END AS user_segmentation    
        , T1.mau AS mau
        , T1.mau_users_churn AS mau_users_churn
        , T1.mau_producers     
        , T1.mau_users_net_new AS net_new
      FROM
        main.field_self_service.fact_mau_users AS T1
      WHERE 
        T1.customer_id = '0013f0000063nVJAAY'
    ) AS T1
    GROUP BY month, customer_id, user_segmentation
), _consumption
AS (
  SELECT
    *,
    try_divide((dbu_dollars - prev_month_dbu_dollars), prev_month_dbu_dollars) * 100 AS dbu_dollars_growth
  FROM(
    SELECT 
      month
      , customer_id
      , dbu_dollars
      , LAG(dbu_dollars) OVER (PARTITION BY customer_id ORDER BY month) AS prev_month_dbu_dollars
    FROM 
      main.field_self_service.user_consumption  
    WHERE 
      :`Include User Segmentation` = 'No'
  ) AS T1
)
SELECT
  a.account_name
  , a.business_unit  
  , T1.customer_id
  , T1.user_segmentation
  , T1.month  
  , T1.churn
  , T1.net_new 
  , T1.mau 
  , T1.mau_producers
  , T1.prev_mau_producers
  , nvl(try_divide((T1.mau_producers - T1.prev_mau_producers), T1.prev_mau_producers), 0) AS mau_producers_growth
  , T2.dbu_dollars
  , T2.prev_month_dbu_dollars
  , nvl(T2.dbu_dollars_growth, 0) AS dbu_dollars_growth
FROM 
  _churn AS T1
LEFT JOIN 
  _consumption AS T2 USING (customer_id, month)
LEFT JOIN 
    main.gtm_data.core_accounts_curated as a
ON 
    T1.customer_id = a.account_id 
WHERE 1=1  
  AND ((:month_selected = 'All' AND T1.month = '2024-12-01') OR T1.month = try_cast(:month_selected AS DATE))
  AND (:BU = 'All' OR a.business_unit = :BU)
  AND (:BU_1 = 'All' OR a.sales_subregion_level_1 = :BU_1)
  AND (:BU_2 = 'All' OR a.sales_subregion_level_2 = :BU_2)
  AND (:BU_3 = 'All' OR a.sales_subregion_level_3 = :BU_3)
  AND (:account_name = 'All' OR a.account_name = :account_name)
QUALIFY
  SUM(T1.churn) OVER(PARTITION BY T1.month, T1.customer_id) < 0

-- COMMAND ----------

SELECT
  *,
  (dbu_dollars - prev_month_dbu_dollars) / prev_month_dbu_dollars AS dbu_dollars_growth
FROM(
  SELECT 
    month,
    customer_id,
    dbu_dollars,
    LAG(dbu_dollars) OVER (PARTITION BY customer_id ORDER BY month) AS prev_month_dbu_dollars
  FROM 
    main.field_self_service.user_consumption
  WHERE 
    customer_id = '001Vp000000TuuuIAC'    
) AS X
WHERE X.month = '2024-12-01'

-- COMMAND ----------

-- DBTITLE 1,churn_segmentation
SELECT
  *,
  try_divide((mau_producers - prev_mau_producers), prev_mau_producers) AS mau_producers_growth
FROM(
    SELECT
      T1.month,
      T1.customer_id,
      T1.user_segmentation,
      T1.mau,
      T1.mau_producers,
      T1.mau_users_churn * -1 AS churn,
      T1.mau_users_net_new AS net_new,
      LAG(T1.mau_producers) OVER (PARTITION BY customer_id, user_segmentation, customer_spend_category ORDER BY month) AS prev_mau_producers
    FROM
      main.field_self_service.fact_mau_users AS T1
) AS T1  
WHERE
  T1.month = '2024-12-01'
  AND T1.churn IS NOT NULL


-- COMMAND ----------

-- =============================================
-- Title:      Get user_summary data related to the user
-- Create date: 2024-10-10
-- Description: This query is used to customer_spend_category and user_segmentation from user_summary
-- The query returns the data for the user with the most recent date on each month. 
-- This is due the user can change the spend category on the same month.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW vw_user_summary
AS
SELECT 
  date_Trunc('month', T1.date)::date as month,
  T1.date,
  T1.user_id,
  T1.customer_spend_category,
  T1.user_segmentation
FROM 
  main.data_product_intelligence.user_summary T1
WHERE
  --T1.date >= DATEADD(MONTH, -10, current_timestamp()::DATE)  
  T1.date >= '2024-01-01'
QUALIFY 
  ROW_NUMBER() OVER (PARTITION BY date_Trunc('month', T1.date), T1.user_id ORDER BY T1.date DESC) = 1

-- COMMAND ----------

-- =============================================
-- Title:      Total MAU definition by month
-- Create date: 2024-09-10
-- Description: This query creates a temporary view vw_mau_monthly that selects distinct monthly user activity data from the user_metrics table. 
-- It filters for customers, ensures the date is within the last 10 months, and excludes specific Salesforce account IDs. 
-- The view includes the month, the earliest month of activity for each user, the customer ID, and the user ID.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW vw_mau_monthly
AS  
  SELECT DISTINCT
    date_trunc('MONTH', T1.date)::date as month
    , min(date_trunc('MONTH', T1.date)::date) over(partition by T1.user_id)::date as min_month
    , T1.customer_id
    , T1.user_id AS user_id
    , IFF(login_num_events_t28d > 0, 1, 0) AS mau
    , IFF(login_num_events_t28d > 0 AND total_dollars_t28d > 0, 1, 0) AS mau_producers
    , IFF(login_num_events_t7d > 0 AND total_dollars_t7d > 0, 1, 0) AS wau_producers
    , CASE 
        WHEN total_dollars_t28d > 1000 THEN 'Very high usage (>1k)' 
        WHEN total_dollars_t28d > 100 THEN 'High usage (100-1000)' 
        WHEN total_dollars_t28d > 10 THEN 'Medium usage (10-100)'
        WHEN total_dollars_t28d > 0 THEN 'Low usage (0-10)'
        WHEN total_dollars_t28d = 0 THEN 'No usage (0)' END AS segmentation_by_size
    , total_dollars_t7d
    , total_dollars_t28d
    , login_num_events_t7d
    , login_num_events_t28d
  FROM 
    main.data_product_features.user_metrics AS T1
  LEFT JOIN 
    main.gtm_data.core_accounts_curated as T2
  ON 
    T1.customer_id = T2.account_id 
  WHERE 
    salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')    
    AND date >= '2024-01-01'
    AND (DAYOFMONTH(date) = 28 OR date = (SELECT MAX(date) FROM main.data_product_features.user_metrics WHERE DAYOFMONTH(date)<=28))

-- COMMAND ----------

  SELECT
    T1.month,    
    T2.user_segmentation,
    SUM(T1.mau) AS mau,
    SUM(T1.mau_producers) AS mau_producers
  FROM 
    vw_mau_monthly AS T1
  LEFT JOIN
    vw_user_summary AS T2
    ON T1.month = T2.month
    AND T1.user_id = T2.user_id
  WHERE
    T1.month = '2024-12-01'
  GROUP BY ALL

-- COMMAND ----------

SELECT
  T1.date
  , date_trunc('MONTH', T1.date)::date as month
  , min(date_trunc('MONTH', T1.date)::date) over(partition by T1.user_id)::date as min_month
  , T1.customer_id
  , T1.user_id AS user_id
  , IFF(login_num_events_t28d > 0, 1, 0) AS mau
FROM 
  main.data_product_features.user_metrics AS T1
LEFT JOIN 
  main.gtm_data.core_accounts_curated as T2
ON 
  T1.customer_id = T2.account_id 
WHERE 
  salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')    
  AND date >= '2024-01-01'
  AND (DAYOFMONTH(date) = 28 OR date = (SELECT MAX(date) FROM main.data_product_features.user_metrics))

  AND date_trunc('MONTH', T1.date)::date = '2024-12-01'
  AND T1.user_id = '00023bb852638184a4418ae6189767edec0b4ff48a141a890bca950554a8fb29'

-- COMMAND ----------

SELECT
  T1.month,
  T1.user_segmentation,
  *
  -- sum(T1.mau) AS mau
FROM 
  main.field_self_service.fact_mau_users T1
WHERE 
  T1.month = '2024-12-01'
  AND T1.customer_id = '0016100001TOyWsAAL'
-- GROUP BY ALL

-- COMMAND ----------

WITH _churn
AS (
  SELECT
    T1.customer_id,
    SUM(T1.mau_users_churn) * -1 AS churn,
    SUM(T1.mau_users_net_new) AS net_new,
    SUM(T1.mau) AS mau
  FROM
    main.field_self_service.fact_mau_users AS T1
  WHERE
    month = '2024-12-01'  
  GROUP BY ALL
  HAVING SUM(T1.mau_users_churn) < 0
), _consumption
AS (
  SELECT
    *,
    try_divide((dbu_dollars - prev_month_dbu_dollars), prev_month_dbu_dollars) AS dbu_dollars_growth
  FROM(
    SELECT 
      month,
      customer_id,
      dbu_dollars,
      LAG(dbu_dollars) OVER (PARTITION BY customer_id ORDER BY month) AS prev_month_dbu_dollars
    FROM 
      main.field_self_service.user_consumption  
  ) AS X
  WHERE X.month = '2024-12-01'
)
SELECT
  a.account_name
  , T2.*
  , T1.churn
  , T1.net_new 
  , T1.mau 
FROM 
  _churn AS T1
LEFT JOIN 
  _consumption AS T2 USING (customer_id)
LEFT JOIN 
    main.gtm_data.core_accounts_curated as a
ON 
    T1.customer_id = a.account_id 
WHERE
    (:BU = 'All' OR a.business_unit = :BU)
    AND (:BU_1 = 'All' OR a.sales_subregion_level_1 = :BU_1)
    AND (:BU_2 = 'All' OR a.sales_subregion_level_2 = :BU_2)
    AND (:BU_3 = 'All' OR a.sales_subregion_level_3 = :BU_3)
    AND (:account_name = 'All' OR a.account_name = :account_name)