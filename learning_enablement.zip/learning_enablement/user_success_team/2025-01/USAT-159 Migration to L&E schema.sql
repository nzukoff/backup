-- Databricks notebook source
-- MAGIC %md
-- MAGIC ......................................................................................... \
-- MAGIC ......................................................................................... \
-- MAGIC **Request Name:**    Migration to L&E schema  \
-- MAGIC **Description:**     As part of the efforts to consolidate and sync the Learning and Enablement reports, the user success team will move the production tables to the schema main.field_learning_enablement \
-- MAGIC **Jira Ticket:**     [USAT-159](https://databricks.atlassian.net/browse/USAT-159) \
-- MAGIC **SLA:**     No SLA \
-- MAGIC ......................................................................................... \
-- MAGIC ......................................................................................... 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 1- Cloning tables

-- COMMAND ----------

SHOW TABLES IN main.field_self_service;

-- COMMAND ----------

DESCRIBE HISTORY main.field_self_service.silver_monthly_mau

-- COMMAND ----------

CREATE OR REPLACE TABLE main.field_learning_enablement.silver_monthly_mau CLONE main.field_self_service.silver_monthly_mau;

-- COMMAND ----------

DESCRIBE HISTORY main.field_learning_enablement.silver_monthly_mau

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 2- Change owner

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 2.1- Reference notebook shared by Nathan [Migrate Tables to SP](https://adb-2548836972759138.18.azuredatabricks.net/editor/notebooks/3983238949303888?o=2548836972759138) and [doc](https://docs.google.com/document/d/1t-uqElAo5F8jbsLonDkm_zqofc8JMWvnXdjik3eXtwM/edit?tab=t.0)

-- COMMAND ----------

DESCRIBE EXTENDED main.field_learning_enablement.silver_monthly_mau

-- COMMAND ----------

USE CATALOG main;
USE SCHEMA field_learning_enablement;
ALTER TABLE silver_monthly_mau SET OWNER TO `1e5fa543-88de-4532-8050-0f298b5458f2`

-- COMMAND ----------

DESCRIBE EXTENDED main.field_learning_enablement.silver_monthly_mau