-- Databricks notebook source
-- MAGIC %md
-- MAGIC

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
SELECT 
  CASE
    WHEN event_name IN('Treinamento Databricks Brasil', 'Treinamento Databricks Brasil Dez', 'Entrenamiento Databricks en Español') THEN 'Banco Bradesco'
    WHEN event_name IN('Emerging Enterprise') THEN 'Curinos' ELSE event_name END company
  , event_name
  , session_code   
FROM VALUES
  ('AB-InBev', '26769'),
  ('Treinamento Databricks Brasil', '35276'),
  ('Entrenamiento Databricks en Español', '35490'),
  ('P&G', '36631'),
  ('Samsara', '46178'),
  ('Emerging Enterprise', '43125'),
  ('Treinamento Databricks Brasil Dez', '43501'),
  ('Retail', '43554'),
  ('HP', '51294'),
  ('Frontier Communications', '46755'),
  ('Tractor Supply Company', '45412'),
  ('Santander', '51991'),
  ('Red Ventures', '50922')
AS _account_sessions(event_name, session_code);

SELECT
  T1.session_code
  , T1.event_name
  , T1.session_date
   , T1.account_id
  , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
  , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
FROM(
  SELECT 
    CAST(T1.ended_timestamp AS DATE) AS session_date    
    , T1.session_code
    , T2.event_name
    , T1.updated_account_id AS account_id      
    , T1.enrolled_date
    , T1.completed_date          
  FROM 
      main.field_learning_enablement.all_enrollments AS T1
  INNER JOIN
    _account_sessions AS T2 USING(session_code)
  WHERE 
    T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1) 
    AND T1.enrolled_date > '2024-10-11'          
) AS T1
--  WHERE
--   T1.session_code = '43554'
  --  T1.account_id = '0016100001fR5C6AAK'
GROUP BY ALL

-- COMMAND ----------

SELECT
  *
FROM(
  SELECT DISTINCT
    T1.date    
    , T1.customer_id
    , T1.user_id AS user_id
    , SUM(IFF(login_num_events_t28d > 0, 1, 0)) AS mau
    , SUM(IFF(login_num_events_t28d > 0 AND total_dollars_t28d > 0, 1, 0)) AS mau_producers
  FROM 
    main.data_product_features.user_metrics AS T1
  WHERE 
    T1.customer_id = '0016100001EyalJAAR'
    AND salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')    
    AND date >= '2024-01-01'
  GROUP BY ALL
  QUALIFY
    min(T1.date) over(partition by T1.user_id)::date = T1.date
) AS T1
-- WHERE
--   T1.date = '2024-12-18'


/*
   Vocareum, Inc. customer ID = 0018Y00002r4UG5QAM
*/

-- COMMAND ----------

SELECT
  T1.month
  , T1.customer_id
  , SUM(T1.mau) AS MAU
FROM
  main.field_self_service.fact_mau_users AS T1
WHERE
  T1.customer_id = '0018Y00002r4UG5QAM'
GROUP BY ALL