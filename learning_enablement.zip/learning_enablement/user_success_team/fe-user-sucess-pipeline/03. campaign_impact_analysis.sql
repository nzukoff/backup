-- Databricks notebook source
-- MAGIC %md
-- MAGIC ####Env Setup
-- MAGIC
-- MAGIC * Set Spark configuration
-- MAGIC * Clean up all residual widgets
-- MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
-- MAGIC * Add in any additional environment setup pieces that you need for your notebook
-- MAGIC * Set up parameters

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard libraries
-- MAGIC import sys
-- MAGIC from datetime import datetime, timedelta

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard widgets - do not change
-- MAGIC dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
-- MAGIC dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
-- MAGIC dbutils.widgets.text("partition_column", "processDate")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #pass parameter values to variables
-- MAGIC try:    
-- MAGIC     focus_database_name = dbutils.widgets.get("focus_database_name")
-- MAGIC     partition_date = dbutils.widgets.get("partition_date")
-- MAGIC     partition_column = dbutils.widgets.get("partition_column")
-- MAGIC except:
-- MAGIC     print("Please check the parameters passed are valid")
-- MAGIC     raise Exception

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1 - Main process

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: 
-- This query creates a temporary view and a table to analyze account sessions and their impact on various metrics.
-- 
-- The first part of the query creates a temporary view `_account_sessions` that extracts session details from the 
-- `training_operations_ilt_schedule_master` table for the '1k AI/BI Training Program' project type, excluding canceled sessions.
-- 
-- The second part of the query creates a table `${focus_database_name}.fact_campaign_analysis` using multiple CTEs:
-- 
-- 1. `_nnl`: Extracts net new learners from the `all_learners` table.
-- 
-- 2. `_event_registrations`: Combines data from `all_enrollments`, `_account_sessions`, and `_nnl` to calculate event registrations, 
--    attendees, and net new learners for each account and session.
-- 
-- 3. `_mau_data`: Aggregates metrics such as MAU (Monthly Active Users), WAU (Weekly Active Users), and revenue growth before and after 
--    the event from the `fact_daily_mau` table, joined with `_event_registrations`.
-- 
-- The final SELECT statement aggregates and joins data from `_event_registrations` and `_mau_data` to populate the 
-- `${focus_database_name}.fact_campaign_analysis` table with detailed metrics for each account and session, including growth metrics 
-- for various user and revenue categories.
-- 
-- The query also excludes the Databricks account from the results.
-- =============================================

-- COMMAND ----------

-- =============================================
-- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
-- Create date: 2025-01-09
-- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
SELECT
  project_type,
  academy_session_number AS session_code,  
  form_ilt_name,
  status,
  region AS session_region
FROM
  main.field_learning_enablement.training_operations_ilt_schedule_master
WHERE
  processDate = (SELECT max(processDate) FROM main.field_learning_enablement.training_operations_ilt_schedule_master)
  AND 
  (
    (training_operations_ilt_schedule_master.project_type = 'AI/BI Training Program' AND status not ilike 'cancel%')  
    OR (academy_session_number = 53804) -- Adding manually this session https://databricks.atlassian.net/browse/USAT-254
  )
  ;

/*

*/
CREATE OR REPLACE TABLE ${focus_database_name}.fact_campaign_analysis
AS
WITH _account_tagging
AS(
  SELECT DISTINCT
    customer_id,
    tagging
  FROM
    ${focus_database_name}.silver_monthly_mau AS T3  
), _nnl as( -- Net New Learners
  SELECT 
    learner_user_id, 
    course_code, 
    completed_date
  FROM 
    main.field_learning_enablement.all_learners
  WHERE 
    processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    AND dataset = 'net new learners'
), _event_registrations
AS (  
  -- =============================================
  -- Description: This CTE calculates the event registrations and attendees for each account, along with the session details.  
  -- =============================================
  SELECT
    T1.processDate
    , T1.account_id
    , T1.program 
    , T1.session_code
    , T1.session_region
    , T1.session_name 
    , T1.session_date
    , COUNT(DISTINCT T1.session_code) AS account_sessions
    , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
    , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
    , SUM(CASE WHEN T1.learner_user_id IS NOT NULL THEN 1 END) AS event_net_new_learners
  FROM(
    SELECT 
      T1.processDate,
      'ILT' AS program,
      T1.session_code,
      T2.session_region,
      TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name,
      CAST(T1.ended_timestamp AS DATE) AS session_date,
      T1.updated_account_id AS account_id,
      T1.enrolled_date,
      T1.completed_date,     
      T3.learner_user_id
    FROM 
        main.field_learning_enablement.all_enrollments AS T1
    INNER JOIN
      _account_sessions AS T2 USING(session_code)
    LEFT JOIN
      _nnl AS T3 USING(learner_user_id, course_code)
    WHERE 
      T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)      

    UNION ALL

    SELECT
      ae.processDate,
      u.program,
      STRING(u.id_coupon) AS session_code,
      NULL AS session_region,
      u.airtable_account_name AS session_name,
      u.event_date AS session_date,
      ae.updated_account_id AS account_id,
      ae.enrolled_date,
      ae.completed_date, 
      _nnl.learner_user_id
    FROM
      main.team_field_user_enablement.vw_coupon_usage u
    LEFT JOIN
      main.it_training_silver.docebo_subscription_enrollments e
    ON
      e.transaction_id = u.subscription_trans_id
      AND e.learner_user_id = u.userID
      AND e.processDate = (SELECT max(processDate) FROM main.it_training_silver.docebo_subscription_enrollments)
    LEFT JOIN
      main.field_learning_enablement.all_enrollments ae
    ON
      ae.course_id = e.course_id
      AND ae.learner_user_id = e.learner_user_id
      AND ae.enrolled_date between u.subStartDAre and u.SubEndDate
      AND ae.processDate = (SELECT max(processDate) FROM main.field_learning_enablement.all_enrollments)
    LEFT JOIN
      _nnl 
    ON 
      ae.learner_user_id = _nnl.learner_user_id
      AND ae.course_code = _nnl.course_code         
    WHERE
      u.program = 'Hybrid Days'      
  ) AS T1
  GROUP BY ALL 
), _mau_data
AS (
  SELECT
    T1.session_code
    , T1.account_id   
    , MAX(T1.date) max_mau_date 
    , ROUND(AVG(T1.mau_pre_event)) AS mau_pre_event   
    , SUM(T1.mau_01d_post_event) AS mau_post_event
    , SUM(T1.mau_01d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_01d_growth
    , SUM(T1.mau_07d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_07d_growth
    , SUM(T1.mau_14d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_14d_growth
    , SUM(T1.mau_30d_post_event) - nvl(ROUND(AVG(T1.mau_pre_event)), 0) AS mau_30d_growth

    , SUM(T1.total_dollars_01d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_01d_growth
    , SUM(T1.total_dollars_07d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_07d_growth
    , SUM(T1.total_dollars_14d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_14d_growth
    , SUM(T1.total_dollars_30d_post_event) - nvl(ROUND(AVG(T1.total_dollars_pre_event)), 0) AS total_dollars_30d_growth

    , SUM(T1.wau_01d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_01d_growth
    , SUM(T1.wau_07d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_07d_growth
    , SUM(T1.wau_14d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_14d_growth
    , SUM(T1.wau_30d_post_event) - nvl(ROUND(AVG(T1.wau_pre_event)), 0) AS wau_30d_growth

    , SUM(T1.wau_human_01d_post_event) - nvl(ROUND(AVG(T1.wau_human_pre_event)), 0) AS wau_human_01d_growth
    , SUM(T1.wau_human_07d_post_event) - nvl(ROUND(AVG(T1.wau_human_pre_event)), 0) AS wau_human_07d_growth
    , SUM(T1.wau_human_14d_post_event) - nvl(ROUND(AVG(T1.wau_human_pre_event)), 0) AS wau_human_14d_growth
    , SUM(T1.wau_human_30d_post_event) - nvl(ROUND(AVG(T1.wau_human_pre_event)), 0) AS wau_human_30d_growth
    
    , SUM(T1.dbsql_mau_01d_post_event) - nvl(ROUND(AVG(T1.dbsql_mau_pre_event)), 0) AS dbsql_mau_01d_growth
    , SUM(T1.dbsql_mau_07d_post_event) - nvl(ROUND(AVG(T1.dbsql_mau_pre_event)), 0) AS dbsql_mau_07d_growth
    , SUM(T1.dbsql_mau_14d_post_event) - nvl(ROUND(AVG(T1.dbsql_mau_pre_event)), 0) AS dbsql_mau_14d_growth
    , SUM(T1.dbsql_mau_30d_post_event) - nvl(ROUND(AVG(T1.dbsql_mau_pre_event)), 0) AS dbsql_mau_30d_growth

    , SUM(T1.dbsql_wau_01d_post_event) - nvl(ROUND(AVG(T1.dbsql_wau_pre_event)), 0) AS dbsql_wau_01d_growth
    , SUM(T1.dbsql_wau_07d_post_event) - nvl(ROUND(AVG(T1.dbsql_wau_pre_event)), 0) AS dbsql_wau_07d_growth
    , SUM(T1.dbsql_wau_14d_post_event) - nvl(ROUND(AVG(T1.dbsql_wau_pre_event)), 0) AS dbsql_wau_14d_growth
    , SUM(T1.dbsql_wau_30d_post_event) - nvl(ROUND(AVG(T1.dbsql_wau_pre_event)), 0) AS dbsql_wau_30d_growth    

    , SUM(T1.dbsql_dollars_01d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_01d_growth
    , SUM(T1.dbsql_dollars_07d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_07d_growth
    , SUM(T1.dbsql_dollars_14d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_14d_growth
    , SUM(T1.dbsql_dollars_30d_post_event) - nvl(ROUND(AVG(T1.dbsql_dollars_pre_event)), 0) AS dbsql_dollars_30d_growth    

    , SUM(T1.genie_mau_01d_post_event) - nvl(ROUND(AVG(T1.genie_mau_pre_event)), 0) AS genie_mau_01d_growth
    , SUM(T1.genie_mau_07d_post_event) - nvl(ROUND(AVG(T1.genie_mau_pre_event)), 0) AS genie_mau_07d_growth
    , SUM(T1.genie_mau_14d_post_event) - nvl(ROUND(AVG(T1.genie_mau_pre_event)), 0) AS genie_mau_14d_growth
    , SUM(T1.genie_mau_30d_post_event) - nvl(ROUND(AVG(T1.genie_mau_pre_event)), 0) AS genie_mau_30d_growth

    , SUM(T1.genie_wau_01d_post_event) - nvl(ROUND(AVG(T1.genie_wau_pre_event)), 0) AS genie_wau_01d_growth
    , SUM(T1.genie_wau_07d_post_event) - nvl(ROUND(AVG(T1.genie_wau_pre_event)), 0) AS genie_wau_07d_growth
    , SUM(T1.genie_wau_14d_post_event) - nvl(ROUND(AVG(T1.genie_wau_pre_event)), 0) AS genie_wau_14d_growth
    , SUM(T1.genie_wau_30d_post_event) - nvl(ROUND(AVG(T1.genie_wau_pre_event)), 0) AS genie_wau_30d_growth

    , SUM(T1.genie_dollars_01d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_01d_growth
    , SUM(T1.genie_dollars_07d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_07d_growth
    , SUM(T1.genie_dollars_14d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_14d_growth
    , SUM(T1.genie_dollars_30d_post_event) - nvl(ROUND(AVG(T1.genie_dollars_pre_event)), 0) AS genie_dollars_30d_growth

    , SUM(T1.lakeview_mau_01d_post_event) - nvl(ROUND(AVG(T1.lakeview_mau_pre_event)), 0) AS lakeview_mau_01d_growth
    , SUM(T1.lakeview_mau_07d_post_event) - nvl(ROUND(AVG(T1.lakeview_mau_pre_event)), 0) AS lakeview_mau_07d_growth
    , SUM(T1.lakeview_mau_14d_post_event) - nvl(ROUND(AVG(T1.lakeview_mau_pre_event)), 0) AS lakeview_mau_14d_growth
    , SUM(T1.lakeview_mau_30d_post_event) - nvl(ROUND(AVG(T1.lakeview_mau_pre_event)), 0) AS lakeview_mau_30d_growth

    , SUM(T1.lakeview_wau_01d_post_event) - nvl(ROUND(AVG(T1.lakeview_wau_pre_event)), 0) AS lakeview_wau_01d_growth
    , SUM(T1.lakeview_wau_07d_post_event) - nvl(ROUND(AVG(T1.lakeview_wau_pre_event)), 0) AS lakeview_wau_07d_growth
    , SUM(T1.lakeview_wau_14d_post_event) - nvl(ROUND(AVG(T1.lakeview_wau_pre_event)), 0) AS lakeview_wau_14d_growth
    , SUM(T1.lakeview_wau_30d_post_event) - nvl(ROUND(AVG(T1.lakeview_wau_pre_event)), 0) AS lakeview_wau_30d_growth

    , SUM(T1.lakeview_dollars_01d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_01d_growth
    , SUM(T1.lakeview_dollars_07d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_07d_growth
    , SUM(T1.lakeview_dollars_14d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_14d_growth
    , SUM(T1.lakeview_dollars_30d_post_event) - nvl(ROUND(AVG(T1.lakeview_dollars_pre_event)), 0) AS lakeview_dollars_30d_growth    
  FROM(
    SELECT
      T1.session_code
      , T2.date
      , T2.customer_id AS account_id      
      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.mau END) AS mau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.mau END) AS mau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.mau END) AS mau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.mau END) AS mau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.mau END) AS mau_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.total_dollars_t28d END) AS total_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.total_dollars_t28d END) AS total_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.total_dollars_t28d END) AS total_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.total_dollars_t28d END) AS total_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.total_dollars_t28d END) AS total_dollars_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.wau END) AS wau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.wau END) AS wau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.wau END) AS wau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.wau END) AS wau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.wau END) AS wau_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.wau_human END) AS wau_human_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.wau_human END) AS wau_human_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.wau_human END) AS wau_human_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.wau_human END) AS wau_human_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.wau_human END) AS wau_human_30d_post_event

      , ROUND(SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.dbsql_mau END)) AS dbsql_mau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.dbsql_mau END) AS dbsql_mau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.dbsql_mau END) AS dbsql_mau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.dbsql_mau END) AS dbsql_mau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.dbsql_mau END) AS dbsql_mau_30d_post_event

      , ROUND(SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.dbsql_wau END)) AS dbsql_wau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.dbsql_wau END) AS dbsql_wau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.dbsql_wau END) AS dbsql_wau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.dbsql_wau END) AS dbsql_wau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.dbsql_wau END) AS dbsql_wau_30d_post_event      

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.dbsql_dollars_t28d END) AS dbsql_dollars_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.genie_mau END) AS genie_mau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.genie_mau END) AS genie_mau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.genie_mau END) AS genie_mau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.genie_mau END) AS genie_mau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.genie_mau END) AS genie_mau_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.genie_wau END) AS genie_wau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.genie_wau END) AS genie_wau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.genie_wau END) AS genie_wau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.genie_wau END) AS genie_wau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.genie_wau END) AS genie_wau_30d_post_event      
      
      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.genie_dollars END) AS genie_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.genie_dollars END) AS genie_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.genie_dollars END) AS genie_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.genie_dollars END) AS genie_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.genie_dollars END) AS genie_dollars_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.lakeview_mau END) AS lakeview_mau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.lakeview_mau END) AS lakeview_mau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.lakeview_mau END) AS lakeview_mau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.lakeview_mau END) AS lakeview_mau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.lakeview_mau END) AS lakeview_mau_30d_post_event

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.lakeview_wau END) AS lakeview_wau_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.lakeview_wau END) AS lakeview_wau_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.lakeview_wau END) AS lakeview_wau_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.lakeview_wau END) AS lakeview_wau_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.lakeview_wau END) AS lakeview_wau_30d_post_event      

      , SUM(CASE WHEN T2.date >= DATE_SUB(T1.session_date, 90) AND T2.date < T1.session_date THEN T2.lakeview_dollars END) AS lakeview_dollars_pre_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 01) THEN T2.lakeview_dollars END) AS lakeview_dollars_01d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 07) THEN T2.lakeview_dollars END) AS lakeview_dollars_07d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 14) THEN T2.lakeview_dollars END) AS lakeview_dollars_14d_post_event
      , SUM(CASE WHEN T2.date = DATE_ADD(T1.session_date, 30) THEN T2.lakeview_dollars END) AS lakeview_dollars_30d_post_event
    FROM
      ${focus_database_name}.fact_daily_mau AS T2
    INNER JOIN
      _event_registrations T1
    ON 
      T2.customer_id = T1.account_id
    GROUP BY ALL
  ) AS T1    
  GROUP BY ALL  
)

SELECT
  T1.processDate
  , T1.session_code
  , T1.session_region
  , T1.program
  , T1.session_name
  , DATE(T1.session_date) AS session_date
  , T1.max_mau_date
  , T1.account_id
  , CASE WHEN T1.account_sessions > 1 THEN T1.account_id END AS accounts_with_multiple_sessions  
  , T2.account_name
  , nvl(T3.tagging, 'Not Tagged') AS tagging
  , T2.business_unit AS bu
  , T2.sales_subregion_level_1 AS bu_1
  , T2.sales_subregion_level_2 AS bu_2
  , T2.sales_subregion_level_3 AS bu_3
  , T2.sa_manager
  , T2.account_executive AS account_executive
  , T2.sales_manager as ae_manager
  , COUNT(DISTINCT T1.account_id) AS accounts  
  
  , nvl(SUM(T1.event_registrations), 0) AS event_registrations
  , nvl(SUM(T1.event_attendees), 0) AS event_attendees    
  , nvl(SUM(T1.event_net_new_learners), 0) AS event_net_new_learners      

  , SUM(T1.mau_pre_event) AS mau_pre_event  
  , SUM(T1.mau_post_event) AS mau_post_event

  , SUM(T1.mau_01d_growth) AS mau_01d_growth 
  , SUM(T1.mau_07d_growth) AS mau_07d_growth 
  , SUM(T1.mau_14d_growth) AS mau_14d_growth 
  , SUM(T1.mau_30d_growth) AS mau_30d_growth 

  , SUM(T1.total_dollars_01d_growth) AS total_dollars_01d_growth 
  , SUM(T1.total_dollars_07d_growth) AS total_dollars_07d_growth 
  , SUM(T1.total_dollars_14d_growth) AS total_dollars_14d_growth 
  , SUM(T1.total_dollars_30d_growth) AS total_dollars_30d_growth 

  , SUM(T1.mau_07d_net_growth) AS mau_07d_net_growth 
  , SUM(T1.mau_14d_net_growth) AS mau_14d_net_growth 
  , SUM(T1.mau_30d_net_growth) AS mau_30d_net_growth 

  , SUM(T1.wau_01d_growth) AS wau_01d_growth
  , SUM(T1.wau_07d_growth) AS wau_07d_growth
  , SUM(T1.wau_14d_growth) AS wau_14d_growth
  , SUM(T1.wau_30d_growth) AS wau_30d_growth

  , SUM(T1.wau_human_01d_growth) AS wau_human_01d_growth
  , SUM(T1.wau_human_07d_growth) AS wau_human_07d_growth
  , SUM(T1.wau_human_14d_growth) AS wau_human_14d_growth
  , SUM(T1.wau_human_30d_growth) AS wau_human_30d_growth

  , SUM(T1.dbsql_mau_01d_growth) AS dbsql_mau_01d_growth 
  , SUM(T1.dbsql_mau_07d_growth) AS dbsql_mau_07d_growth 
  , SUM(T1.dbsql_mau_14d_growth) AS dbsql_mau_14d_growth 
  , SUM(T1.dbsql_mau_30d_growth) AS dbsql_mau_30d_growth 

  , SUM(T1.dbsql_wau_01d_growth) AS dbsql_wau_01d_growth 
  , SUM(T1.dbsql_wau_07d_growth) AS dbsql_wau_07d_growth 
  , SUM(T1.dbsql_wau_14d_growth) AS dbsql_wau_14d_growth 
  , SUM(T1.dbsql_wau_30d_growth) AS dbsql_wau_30d_growth 

  , SUM(T1.dbsql_dollars_01d_growth) AS dbsql_dollars_01d_growth 
  , SUM(T1.dbsql_dollars_07d_growth) AS dbsql_dollars_07d_growth 
  , SUM(T1.dbsql_dollars_14d_growth) AS dbsql_dollars_14d_growth 
  , SUM(T1.dbsql_dollars_30d_growth) AS dbsql_dollars_30d_growth  

  , SUM(T1.genie_mau_01d_growth) AS genie_mau_01d_growth 
  , SUM(T1.genie_mau_07d_growth) AS genie_mau_07d_growth 
  , SUM(T1.genie_mau_14d_growth) AS genie_mau_14d_growth 
  , SUM(T1.genie_mau_30d_growth) AS genie_mau_30d_growth 

  , SUM(T1.genie_wau_01d_growth) AS genie_wau_01d_growth 
  , SUM(T1.genie_wau_07d_growth) AS genie_wau_07d_growth 
  , SUM(T1.genie_wau_14d_growth) AS genie_wau_14d_growth 
  , SUM(T1.genie_wau_30d_growth) AS genie_wau_30d_growth 

  , SUM(T1.genie_dollars_01d_growth) AS genie_dollars_01d_growth 
  , SUM(T1.genie_dollars_07d_growth) AS genie_dollars_07d_growth 
  , SUM(T1.genie_dollars_14d_growth) AS genie_dollars_14d_growth 
  , SUM(T1.genie_dollars_30d_growth) AS genie_dollars_30d_growth 

  , SUM(T1.lakeview_mau_01d_growth) AS lakeview_mau_01d_growth 
  , SUM(T1.lakeview_mau_07d_growth) AS lakeview_mau_07d_growth 
  , SUM(T1.lakeview_mau_14d_growth) AS lakeview_mau_14d_growth 
  , SUM(T1.lakeview_mau_30d_growth) AS lakeview_mau_30d_growth 

  , SUM(T1.lakeview_wau_01d_growth) AS lakeview_wau_01d_growth 
  , SUM(T1.lakeview_wau_07d_growth) AS lakeview_wau_07d_growth 
  , SUM(T1.lakeview_wau_14d_growth) AS lakeview_wau_14d_growth 
  , SUM(T1.lakeview_wau_30d_growth) AS lakeview_wau_30d_growth 

  , SUM(T1.lakeview_dollars_01d_growth) AS lakeview_dollars_01d_growth 
  , SUM(T1.lakeview_dollars_07d_growth) AS lakeview_dollars_07d_growth 
  , SUM(T1.lakeview_dollars_14d_growth) AS lakeview_dollars_14d_growth 
  , SUM(T1.lakeview_dollars_30d_growth) AS lakeview_dollars_30d_growth
FROM(
  SELECT   
    T1.processDate
    , T1.account_id
    , T1.program    
    , T1.session_code
    , T1.session_region
    , T1.session_name
    , T1.session_date
    
    , SUM(T1.account_sessions) OVER(PARTITION BY T1.account_id) AS account_sessions

    , T1.event_registrations
    , T1.event_attendees
    , T1.event_net_new_learners

    , T2.max_mau_date

    , T2.mau_pre_event
    , T2.mau_post_event
    
    , T2.mau_01d_growth
    , T2.mau_07d_growth
    , T2.mau_14d_growth
    , T2.mau_30d_growth

    , T2.total_dollars_01d_growth
    , T2.total_dollars_07d_growth
    , T2.total_dollars_14d_growth
    , T2.total_dollars_30d_growth

    , nvl(T2.mau_07d_growth, 0) - nvl(T2.mau_01d_growth, 0) AS mau_07d_net_growth 
    , nvl(T2.mau_14d_growth, 0) - nvl(T2.mau_07d_growth, 0) AS mau_14d_net_growth 
    , nvl(T2.mau_30d_growth, 0) - nvl(T2.mau_14d_growth, 0) AS mau_30d_net_growth

    , T2.wau_01d_growth
    , T2.wau_07d_growth
    , T2.wau_14d_growth
    , T2.wau_30d_growth

    , T2.wau_human_01d_growth
    , T2.wau_human_07d_growth
    , T2.wau_human_14d_growth
    , T2.wau_human_30d_growth

    , T2.dbsql_mau_01d_growth
    , T2.dbsql_mau_07d_growth
    , T2.dbsql_mau_14d_growth
    , T2.dbsql_mau_30d_growth

    , T2.dbsql_wau_01d_growth
    , T2.dbsql_wau_07d_growth
    , T2.dbsql_wau_14d_growth
    , T2.dbsql_wau_30d_growth

    , T2.dbsql_dollars_01d_growth
    , T2.dbsql_dollars_07d_growth
    , T2.dbsql_dollars_14d_growth
    , T2.dbsql_dollars_30d_growth

    , T2.genie_mau_01d_growth
    , T2.genie_mau_07d_growth
    , T2.genie_mau_14d_growth
    , T2.genie_mau_30d_growth

    , T2.genie_wau_01d_growth
    , T2.genie_wau_07d_growth
    , T2.genie_wau_14d_growth
    , T2.genie_wau_30d_growth

    , T2.genie_dollars_01d_growth
    , T2.genie_dollars_07d_growth
    , T2.genie_dollars_14d_growth
    , T2.genie_dollars_30d_growth  

    , T2.lakeview_mau_01d_growth
    , T2.lakeview_mau_07d_growth
    , T2.lakeview_mau_14d_growth
    , T2.lakeview_mau_30d_growth

    , T2.lakeview_wau_01d_growth
    , T2.lakeview_wau_07d_growth
    , T2.lakeview_wau_14d_growth
    , T2.lakeview_wau_30d_growth

    , T2.lakeview_dollars_01d_growth
    , T2.lakeview_dollars_07d_growth
    , T2.lakeview_dollars_14d_growth
    , T2.lakeview_dollars_30d_growth
  FROM 
    _event_registrations T1
  LEFT JOIN 
    _mau_data T2 USING(account_id, session_code)
) AS T1
LEFT JOIN
  main.gtm_data.core_accounts_curated as T2 USING(account_id)
LEFT JOIN
  _account_tagging AS T3
ON
  T1.account_id = T3.customer_id
WHERE 
  T1.account_id <> '0016100000ZcnkGAAR' -- EXCLUDING DATABRICKS ACCOUNT
GROUP BY ALL

-- COMMAND ----------

ALTER TABLE ${focus_database_name}.fact_campaign_analysis
CLUSTER BY (session_date);

-- COMMAND ----------

OPTIMIZE ${focus_database_name}.fact_daily_mau;