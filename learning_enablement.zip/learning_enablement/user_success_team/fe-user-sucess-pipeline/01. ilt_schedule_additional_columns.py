# Databricks notebook source
# MAGIC %md
# MAGIC Here are a few basic details that should be added to all the notebooks: \
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... \
# MAGIC **DAG Name:**      [DEV] data-focus-training-dag  \
# MAGIC **Team Name:**       FOCUS  \
# MAGIC **Sub-function:**   Training and Enablement  \
# MAGIC **Owner:**           Nathan Zukoff \
# MAGIC **Source(s):**      Source_table_1, source_table_2, etc. \
# MAGIC **Target:**             Target_table_name \
# MAGIC **Description:**     This notebook creates gold tables for instructor utilzation from Airtable \
# MAGIC **Jira Ticket:**     No Jira ticket \
# MAGIC **SLA:**     Tables should be updated daily 
# MAGIC
# MAGIC ......................................................................................... \
# MAGIC ......................................................................................... 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Spark config, widgets, library import, utilities import

# COMMAND ----------

# MAGIC %run "/Workspace/Users/nathan.zukoff@databricks.com/Reporting/My functions"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
dbutils.widgets.removeAll()

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import requests

warnings.filterwarnings("ignore")

# COMMAND ----------

#do not remove
focus_data_utils_path = "/dbfs/csops/focus-databricks/"
sys.path.insert(0, focus_data_utils_path)

#establish logging patterns
# logging.basicConfig(format='%(asctime)-15s %(message)s')
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

# COMMAND ----------

#do not remove; these will be handy
from focus_databricks.common.date_utils import *
from focus_databricks.koda.table_utils import *
from focus_databricks.koda.dataframe_utils import *

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W
from pyspark.sql import HiveContext as HC

import pandas as pd


# COMMAND ----------

# MAGIC %md
# MAGIC ###### Parameters
# MAGIC  Use dbutils.widgets to create parameter text boxes at the top of the notebook. We will use these boxes to manage our parameter values. 
# MAGIC  * Create as many as makes sense for your notebook
# MAGIC  * For [param key/name], substitute the specific parameter name that you want, ex: target_database
# MAGIC  * For [param value], susbtitute the actual value that you want to set that parameter to, ex: focus_dev
# MAGIC  
# MAGIC  Once the parameter widgets are defined, import the parameter values to local variables using try/except
# MAGIC

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# utility methods

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
  """
  Add desired gold metadata to a DataFrame, prior to writing it
  to the Delta gold table.
  
  Returns a DataFrame
  """
  # df2 = df.withColumn(partition_column, F.lit(partition_date))
  df2 = df.withColumn(partition_column, F.to_date(F.lit(partition_date)))
  return (df2)

def convertToDF(data):
  """
    data is a list of objects
  """
  json_obj = {}
  
  json_obj['field'] = data

  df = pd.json_normalize(json_obj['field'])
  lst = list(df)
  df[lst] = df[lst].astype(str)

  spark_df = (
    spark
      .createDataFrame(df)
  )
  return spark_df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Content

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Business logic  (intentionally not including a lot in this section, as it will vary depending on what you need to accomplish)

# COMMAND ----------

airtable_pat = dbutils.secrets.get('ldr-airtable', 'airtable-token')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### FY25 Base

# COMMAND ----------

url = "https://api.airtable.com/v0/appNCMjJ2yMKUrTbo/ILT%20Schedule?view=%5BMASTER-ALL%5D%20Public%20%2B%20Private%20%7C%20ILT%20Schedule"
# headers = {'authorization': 'Bearer keyHKkQelgy3j92CL', "Content-Type": "application/json"}
headers = {'authorization': f'Bearer {airtable_pat}', "Content-Type": "application/json"}

records2 = []
response2 = requests.request("GET", url, headers=headers)
response_json2 = response2.json()

# pprint(response_json)

records2 += response_json2['records']
while 'offset' in response_json2:
  response2 = requests.request("GET", url+f"&offset={response_json2['offset']}", headers=headers)
  response_json2 = response2.json()
  records2 += response_json2['records']

fy25data = []
for record in records2:
  fields = record['fields']
  row = {
    'num_enrollments': fields.get('# Enrollments', ''),
    'atp_or_internal_text': fields.get('ATP or Internal (Text)', ''),
    'atp_or_internal_instructor': fields.get('ATP or Internal (from Instructor)', ''),
    'atp_or_internal_ta': fields.get('ATP or Internal (from TA)', ''),
    'atp_or_fte': fields.get('ATPxFTE', ''), #new field
    'academy_session_number': fields.get('Academy Session #',''),
    'account_based_training': fields.get('Account Based Training', ''),
    'attendance_checked_private': fields.get('Attendance Checked (Private Only)', ''),
    'audience': fields.get('Audience', ''),
    'available_hours': fields.get('Available Hours',''), #new field
    'class_time': fields.get('Class Time', ''),
    'completed_customer_onsite_prep_sheet': fields.get('Completed Customer Onsite Prep Sheet', ''),
    'course_duration_hours': fields.get('Course Duration (Hours)', ''), #new field
    'cohort_start_date': fields.get('Cohort Start Date',''), #new field
    'course_abbreviation_from_course_or_project': fields.get('Course Abbreviation (from Course/Project)',''), #new field
    'course_dates': fields.get('Course Dates',''), #new field
    'course_duration_days': fields.get('Course Duration (Days)',''), #new field
    'course_name': fields.get('Course Name',''), #new field
    'course_times': fields.get('Course Times',''), #new field
    'course_type': fields.get('Course Type',''), #new field
    'course_or_project': fields.get('Course/Project',''), #new field
    # 'created_by_email': fields['Created By'].get('email', ''),
    # 'created_by_name': fields.get['Created By'].get('name', ''),
    # 'created_by_id': fields.get['Created By'].get('id', ''), #new field
    # 'created_date': fields.get('Created Date', ''),
    'customer_onsite_prep_sheet': fields.get('Customer Onsite Prep Sheet', ''),
    'db_zoom_control_reporting': fields.get('DB Zoom? [Control Reporting]'), #new field
    'docebo_end_time': fields.get('Docebo - End Time', ''),
    'docebo_start_time': fields.get('Docebo - Start Time', ''),
    'end_date': fields.get('End Date', ''),
    'form_end_date': fields.get('End Date [FORM]', ''), #field_changed
    'fy': fields.get('FY', ''),
    'monday_hours': fields.get('Monday Hours', ''),
    'tuesday_hours': fields.get('Tuesday Hours', ''),
    'wednesday_hours': fields.get('Wednesday Hours', ''),
    'thursday_hours': fields.get('Thursday Hours', ''),
    'friday_hours': fields.get('Friday Hours', ''),
    'half_day_units': fields.get('HDUs', ''),
    'ilt_duration_in_days': fields.get('ILT Duration (Days)', ''),
    'ilt_duration_in_hours': fields.get('ILT Duration (Hours)', ''),
    'form_ilt_name': fields.get('ILT Name [FORM]', ''),
    'ilt_readiness': fields.get('ILT Readiness'),
    'instructor': fields.get('Instructor', ''),
    'instructor_and_ta_assignments': fields.get('Instructor + TA Assignments', ''),
    'landing_page': fields.get('Landing Page', ''),
    'last_modified': fields.get('Last Modified', ''),
    'instructor_led_training_project_name': fields.get('Instructor Led Training / Project Name', ''),
    'line_of_business': fields.get('LOB (Line of Business)',''),
    'language': fields.get('Language',''),
    'meeting_platform': fields.get('Meeting Platform', ''),
    'modality': fields.get('Modality', ''),
    'month': fields.get('Month', ''),
    'notes': fields.get('Notes', ''),
    'onsite_instructor_expenses': fields.get('Onsite Instructor Expenses', ''),
    'ops_slack_setup': fields.get('[OPS] Slack Setup', ''),
    'project_type': fields.get('Project Type', ''),
    'projects': fields.get('Projects', ''),
    'provider': fields.get('Provider', ''),
    'provider_2': fields.get('Provider (2)', ''),
    'quarter': fields.get('Quarter', ''),
    'quarter_fy': fields.get('Quarter + FY', ''),
    'revenue_credit_card': fields.get('Revenue: Credit Card', ''),
    'revenue_skus': fields.get('Revenue: SKUs', ''),
    'roster': fields.get('Roster', ''),
    'sfdc_airtable_projects': fields.get('SFDC <> Airtable Projects', ''),
    'send_survey_results': fields.get('Send Survey Results?', ''),
    'start_date': fields.get('Start Date', ''),
    'status': fields.get('Status', ''),
    'tas': fields.get('TA', ''),
    'form_start_date': fields.get('Start Date [FORM]', ''),
    'StartDoW': fields.get('StartDoW',''),
    'total_revenue': fields.get('Total Revenue', ''),
    'training_type': fields.get('Training Type', ''),
    'week_num_end_date': fields.get('Week # - End Date', ''),
    'preferred_video_conference_tool': fields.get('Preferred Video Conference Tool', ''),
    'year': fields.get('Year', ''),
    'end_date_core_series': fields.get('[Automation] End Date - Core Series', ''),
    'sfdc_blanket_opporunity_case_id': fields.get('[SFDC] Blanket Opportunity CaseID', ''),
    'sfdc_name_date': fields.get('[SFDC] Name: Date', ''),
    'sfdc_pr_name_region_timezone': fields.get('[SFDC] PR Name: Region + Timezone', ''),
    'sfdc_pr_region': fields.get('[SFDC] PR Region', ''),
    'sfdc_project_id_chain': fields.get('[SFDC] Project ID + ID Chain', ''),
    'sfdc_project_manager': fields.get('[SFDC] Project Manager', ''),
    'sfdc_project_url': fields.get('[SFDC] Project URL', ''),
    'sfdc_short_project_id': fields.get('[SFDC] Short_Project ID', ''),
    'region': fields.get('Region', ''),
    'timezone': fields.get('Timezone', ''),
    'academy_class_creation': fields.get('Academy Class Creation', ''),
    'academy_session_url_internal': fields.get('Academy Session URL (internal)', ''),
    'cloudlabs_workspace_provisioned': fields.get('[CLOUDLABS] Workspace Provisioned?', ''),
    'cloudlabs_azure_workspace_signup_link': fields.get('[CLOUDLABS-AZURE] Workspace Signup Link', ''),
    'cloudlabs_azure_workspace_activation_link': fields.get('[CLOUDLABS-AZURE] Workspace Activation Code', ''),
    'cloudlabs_azure_workspace_url': fields.get('[CLOUDLABS-AZURE] Workspace URL', ''),
    'cloudlabs_azure_request_id': fields.get('[CLOUDLABS-AZURE] Request ID', ''),
    'resources_meeting_link': fields.get('[RESOURCES] Meeting Link', ''),
    'resources_slack_link': fields.get('[RESOURCES] Slack Link', ''),
    'resources_survey_link': fields.get('[RESOURCES] Survey Link', ''),
    'resources_survey_results': fields.get('[RESOURCES] Survey Results', ''),
    'company_name': fields.get('Company Name', ''),
    'ff_psa_long_project_id': fields.get('[FF-PSA] Long_Project ID', ''),
    'current_registrations': fields.get('Current Registrations', ''),
    'metrics_docebo_creation_date': fields.get('[METRICS] Docebo Creation Date', ''),
    'metrics_meeting_link_creation': fields.get('[METRICS] Meeting Link Creation', ''),
    'metrics_survey_link_creation': fields.get('[METRICS] Survey Link Creation', ''),
    'metrics_slack_creation': fields.get('[METRICS] Slack Creation', ''),


  }
  fy25data.append(row)

for d in fy25data:
  d['instructor_email'] = [ins['email'] for ins in fy24_instructor_data if ins['id'] in d['instructor']]
  d['instructor_location_or_country'] = [ins['location_country'] for ins in fy24_instructor_data if ins['id'] in d['instructor']]
  d['ta_emails'] = [ins['email'] for ins in fy24_instructor_data if ins['id'] in d['tas']]
  d['instructor_and_ta_assignment_emails'] = [ins['email'] for ins in fy24_instructor_data if ins['id'] in d['instructor_and_ta_assignments']]
  d['instructor_organization_name'] = [ins['organization_name'] for ins in fy24_instructor_data if ins['id'] in d['instructor']]
fy25base = convertToDF(fy25data)
fy25base.createOrReplaceTempView('fy25base')

# COMMAND ----------

instructor_utilization = spark.sql('''
  select 
    num_enrollments,
    atp_or_internal_instructor,
    atp_or_internal_ta,
    atp_or_internal_text, --1
    atp_or_fte, --2
    account_based_training,
    attendance_checked_private,
    audience,
    available_hours, --3
    -- calendar_invitation_private_only, --4
    -- class_duration_days, --5
    -- class_duration_hours, --6
    class_time,
    completed_customer_onsite_prep_sheet,
    customer_onsite_prep_sheet, 
    course_duration_hours, --8
    course_duration_days, --9
    cohort_start_date, --10
    course_abbreviation_from_course_or_project, --11
    course_dates, --12
    course_name, --13
    course_times, --14
    course_type, --15
    course_or_project, --16
    db_zoom_control_reporting, --17
    -- dates, --59
    docebo_end_time,
    docebo_start_time,
    end_date,
    fy,
    half_day_units, --IMP
    monday_hours, --18
    tuesday_hours, --19
    wednesday_hours, --20
    thursday_hours, --21
    friday_hours, --22
    -- goal_utilization, --23
    ilt_duration_in_days, --24
    ilt_duration_in_hours, --25
    -- ilt_name, --26
    landing_page,
    last_modified,
    language, --27
    -- location_from_private_training_request_queue, --28
    modality,
    month,
    notes,
    -- onsite_instructor_expenses,
    -- payment_type_from_training_request_queue, --58
    preferred_video_conference_tool,
    project_type,
    projects,
    provider,
    provider_2,
    quarter,
    quarter_fy,
    region,
    revenue_skus, --30
    -- revenue_from_revenue_cc_from_all_enrollments, --31
    revenue_credit_card,
    -- revenue_pre_purchased_credits, --32
    -- roster,
    -- sfdc_airtable_projects,
    send_survey_results,
    -- slack_access, --33
    start_date,
    status,
    -- time, --34
    timezone,
    total_revenue,
    training_type,
    -- username_from_all_enrollments, --39
    -- temp_enterprise_workspaces, --40
    week_num_end_date,
    -- which_preferred_video_conference_platform, --35
    -- workspace_url, --36
    year,
    -- aws_workspace_anticipated_deleted_date, --59
    -- aws_workspace_url,
    end_date_core_series,
    academy_class_creation, --37
    academy_session_url_internal, --38
    cloudlabs_azure_request_id,
    cloudlabs_azure_workspace_activation_link,
    cloudlabs_azure_workspace_signup_link,
    cloudlabs_azure_workspace_url,
    cloudlabs_workspace_provisioned,
    -- company_contanct_email, --42
    -- company_contanct_name, --43
    company_name,
    -- docebo_class_created, --44
    -- docebo_session_code, --/--45
    -- docebo_session_url_internal, --41
    -- ff_psa_budget_id, 46
    ff_psa_long_project_id,
    -- ff_psa_milestone_id, --47
    -- ff_psa_revenue, --48
    form_end_date,
    form_ilt_name,
    form_start_date,
    -- location_address, --49
    -- lookup_ilt_name, --50
    -- ops_slack_setup,
    -- private_training_request_queue,
    -- public_training_request_queue,
    resources_meeting_link,
    resources_slack_link,
    resources_survey_link,
    resources_survey_results,
    sfdc_blanket_opporunity_case_id,
    sfdc_name_date,
    -- sfdc_pr_name_course_name_abbreviation, --51
    sfdc_pr_name_region_timezone,
    sfdc_pr_region,
    sfdc_project_id_chain,
    sfdc_project_manager,
    sfdc_project_url,
    sfdc_short_project_id,
    -- tray_io_session_name, --52
    meeting_platform,
    line_of_business,
    academy_session_number,
    instructor_email,
    ta_emails,
    instructor_and_ta_assignment_emails,
    instructor_organization_name,
    instructor_location_or_country,
    current_registrations, -- 53
    metrics_docebo_creation_date, --54
    metrics_meeting_link_creation, --55
    metrics_survey_link_creation, --56
    metrics_slack_creation, --57
    'FY24' as airtable_base
  from fy25base
''')


# COMMAND ----------

display(instructor_utilization)

# COMMAND ----------

# instructor_utilization_gold = add_gold_metadata(instructor_utilization)

# COMMAND ----------

# write_delta_table(
#   spark, 
#   dataframe = instructor_utilization_gold, 
#   table_name = f'{focus_database_name}.training_operations_ilt_schedule_master', 
#   partition_column=partition_column,
#   replace_where=f"processDate = '{partition_date}'",
# )