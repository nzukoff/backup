-- Databricks notebook source
-- MAGIC %md
-- MAGIC | **Field**      | **Description** |
-- MAGIC | ----------- | ----------- |
-- MAGIC | **Name**      | 02. fact_mau_users |
-- MAGIC | **Team**      | User Success       |
-- MAGIC | **Organisation**   | Learning & Enablement        |
-- MAGIC | **Owner**   | abraham.fuertes@databricks.com        |
-- MAGIC | **Purpose**   | This notebook is used to explore the data on the source tables for generating the metrics needed |
-- MAGIC | **Source(s)**  | silver_monthly_mau |
-- MAGIC | **Target:**    | fact_mau_users |           

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####Env Setup
-- MAGIC
-- MAGIC * Set Spark configuration
-- MAGIC * Clean up all residual widgets
-- MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
-- MAGIC * Add in any additional environment setup pieces that you need for your notebook
-- MAGIC * Set up parameters

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard libraries
-- MAGIC import sys
-- MAGIC from datetime import datetime, timedelta
-- MAGIC import logging
-- MAGIC import warnings
-- MAGIC from pprint import pprint
-- MAGIC # from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
-- MAGIC import json
-- MAGIC import requests
-- MAGIC from urllib.parse import quote_plus as urlencode
-- MAGIC import pandas as pd
-- MAGIC
-- MAGIC warnings.filterwarnings("ignore")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard widgets - do not change
-- MAGIC dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
-- MAGIC dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
-- MAGIC dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
-- MAGIC dbutils.widgets.text("partition_column", "processDate")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #pass parameter values to variables
-- MAGIC try:
-- MAGIC     focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
-- MAGIC     focus_database_name = dbutils.widgets.get("focus_database_name")
-- MAGIC     partition_date = dbutils.widgets.get("partition_date")
-- MAGIC     partition_column = dbutils.widgets.get("partition_column")
-- MAGIC except:
-- MAGIC     print("Please check the parameters passed are valid")
-- MAGIC     raise Exception

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1 - Main process

-- COMMAND ----------

-- =============================================
-- Title:      Total courses enrolled
-- Create date: 2024-09-10
-- Description: This query identifies churned users by comparing monthly records and creates a temporary view combining churned and active users for a specific customer.
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW vw_monthly_mau
AS
WITH _churn
AS (
  SELECT
    DATEADD(MONTH, 1, T1.month)::date AS month,
    'Churn' AS user_status,
    T1.* EXCEPT(T1.month, T1.user_status)    
  FROM 
    ${focus_database_name}.silver_monthly_mau T1
  LEFT JOIN 
    ${focus_database_name}.silver_monthly_mau T2
    ON T1.user_id = T2.user_id
      AND DATEADD(MONTH, 1, T1.month) = T2.month
  WHERE 
    T2.user_id IS NULL
    AND DATEADD(MONTH, 1, T1.month)::date < date_trunc('MONTH', current_timestamp())::DATE
)

SELECT 
  T1.*
FROM 
  _churn T1
UNION
SELECT 
  T1.month,
  T1.user_status,
  T1.* EXCEPT(T1.month, T1.user_status)    
FROM 
  ${focus_database_name}.silver_monthly_mau T1

-- COMMAND ----------

-- =============================================
-- Title: Monthly Active Users (MAU) aggregated
-- Create date: 
-- Description: This query aggregates Monthly Active Users (MAU) data, creating a table with various user metrics for each month and customer.
-- =============================================
CREATE OR REPLACE TABLE ${focus_database_name}.fact_mau_users
AS
  WITH _init
  AS (
    SELECT 
      T1.month,
      T1.date,
      T1.customer_id,
      T1.tagging,
      T1.bu,
      T1.bu_1,
      T1.bu_2,
      T1.bu_3,
      T1.account_name,
      T1.sa_manager,
      T1.account_executive,
      T1.ae_manager,
      T1.customer_spend_category,
      T1.user_segmentation,
      T1.user_status,
      T1.segmentation_by_size,
      T1.user_type,
      SUM(T1.total_dollars_t7d) AS total_dollars_t7d,
      SUM(T1.total_dollars_t28d) AS total_dollars_t28d,
      SUM(T1.login_num_events_t7d) AS login_num_events_t7d,
      SUM(T1.login_num_events_t28d) AS login_num_events_t28d,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.mau) AS mau_users,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.mau_producers) AS mau_producers,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.mau_api) AS mau_api,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.mau_data_analyst) AS mau_data_analyst,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.mau_human) AS mau_human,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.mau_service_principal) AS mau_service_principal,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.wau) AS wau_users,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.wau_producers) AS wau_producers,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.wau_human) AS wau_human,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.wau_service_principal) AS wau_service_principal,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.total_dollars_t28d_human) AS total_dollars_human,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.total_dollars_t28d_service_principal) AS total_dollars_service_principal,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.dbsql_mau) AS dbsql_mau,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.dbsql_dollars) AS dbsql_dollars,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.uc_mau) AS uc_mau,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.uc_dollars) AS uc_dollars,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.lakeview_mau) AS lakeview_mau,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.lakeview_dollars) AS lakeview_dollars,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.ds_ml_mau) AS ds_ml_mau,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.ds_ml_dollars) AS ds_ml_dollars,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.etl_mau) AS etl_mau,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.etl_dollars) AS etl_dollars,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.delta_mau) AS delta_mau,
      CASE WHEN T1.user_status = 'Churn' THEN -1 ELSE 1 END * SUM(T1.delta_dollars) AS delta_dollars
    FROM 
      vw_monthly_mau T1
    GROUP BY ALL
  )
  SELECT 
    CASE T1.month
      WHEN DATE_TRUNC('month', MAX(T1.month)OVER()) THEN 'Current month'
      WHEN DATE_TRUNC('month', DATEADD(MONTH, -1, MAX(T1.month)OVER())) THEN 'Last month'
      ELSE 'Others'
    END AS relative_month_period
    , T1.month   
    , T1.date 
    , T1.customer_id
    , T1.tagging
    , T1.bu 
    , T1.bu_1
    , T1.bu_2
    , T1.bu_3
    , T1.account_name
    , T1.sa_manager
    , T1.account_executive
    , T1.ae_manager    
    , T1.customer_spend_category
    , T1.user_segmentation     
    , T1.segmentation_by_size   
    , T1.user_type
    , NVL(SUM(CASE WHEN T1.user_status <>'Churn' THEN T1.mau_users ELSE 0 END), 0) AS mau
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.mau_human end), 0) as mau_human
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.mau_service_principal end), 0) as mau_service_principal
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.mau_api end), 0) as mau_api
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.mau_data_analyst end), 0) as mau_data_analyst
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.mau_producers end), 0) as mau_producers
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.wau_users end), 0) as wau    
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.wau_producers end), 0) as wau_producers
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.wau_human end), 0) as wau_human
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.wau_service_principal end), 0) as wau_service_principal
    , NVL(SUM(case when t1.user_status = 'New' then t1.mau_users end), 0) as mau_users_new
    , NVL(SUM(case when t1.user_status = 'Resurrected' then t1.mau_users end), 0) as mau_users_res
    , NVL(SUM(case when t1.user_status = 'Existing' then t1.mau_users end), 0) as mau_users_existing
    , NVL(SUM(case when t1.user_status = 'Churn' then t1.mau_users end), 0) as mau_users_churn
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.mau_users end), 0) as mau_users_current
    , NVL(SUM(case when t1.user_status <>'Existing' then t1.mau_users end), 0) as mau_users_net_new
    , NVL(SUM(CASE WHEN T1.user_status <> 'Churn' THEN T1.total_dollars_t7d ELSE 0 END), 0) AS total_dollars_t7d
    , NVL(SUM(CASE WHEN T1.user_status <>'Churn' THEN T1.total_dollars_t28d ELSE 0 END), 0) AS total_dollars_t28d
    , NVL(SUM(CASE WHEN T1.user_status <>'Churn' THEN T1.login_num_events_t7d ELSE 0 END), 0) AS login_num_events_t7d
    , NVL(SUM(CASE WHEN T1.user_status <>'Churn' THEN T1.login_num_events_t28d ELSE 0 END), 0) AS login_num_events_t28d
    , NVL(SUM(CASE WHEN T1.user_status <>'Churn' THEN T1.total_dollars_human ELSE 0 END), 0) AS total_dollars_human
    , NVL(SUM(CASE WHEN T1.user_status <>'Churn' THEN T1.total_dollars_service_principal ELSE 0 END), 0) AS total_dollars_service_principal
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.dbsql_mau end), 0) as dbsql_mau
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.dbsql_dollars end), 0) as dbsql_dollars
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.uc_mau end), 0) as uc_mau
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.uc_dollars end), 0) as uc_dollars
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.lakeview_mau end), 0) as lakeview_mau
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.lakeview_dollars end), 0) as lakeview_dollars
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.ds_ml_mau end), 0) as ds_ml_mau
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.ds_ml_dollars end), 0) as ds_ml_dollars
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.etl_mau end), 0) as etl_mau
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.etl_dollars end), 0) as etl_dollars
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.delta_mau end), 0) as delta_mau
    , NVL(SUM(case when t1.user_status <>'Churn' then t1.delta_dollars end), 0) as delta_dollars
  FROM 
    _init t1
  GROUP BY ALL;

-- COMMAND ----------

ALTER TABLE ${focus_database_name}.fact_mau_users
CLUSTER BY (month);

-- COMMAND ----------

OPTIMIZE ${focus_database_name}.fact_mau_users;

-- COMMAND ----------

WITH _mau_definition
AS (
    SELECT 
        date_trunc('MONTH', T1.date)::DATE AS month         
        , SUM(IFF(login_num_events_t28d > 0, 1, 0)) AS mau
    FROM 
        main.data_product_features.user_metrics AS T1
    WHERE 
        T1.ds = (SELECT MAX(date) FROM main.data_product_features.user_metrics WHERE DAYOFMONTH(date)<=28)
        AND salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')    
    GROUP BY ALL    
),_mau_learning
AS (
    SELECT        
        u.month
        , SUM(u.MAU) mau        
    FROM 
        main.field_learning_enablement.monthly_active_users as u
    WHERE 
        u.processDate = (select max(processDate) from main.field_learning_enablement.monthly_active_users)
    GROUP BY ALL
), _mau_usat
AS (
    SELECT
      T1.month,
      SUM(mau) AS mau,
      SUM(wau)
    FROM
      main.field_learning_enablement.fact_daily_mau AS T1
    WHERE
      (DAYOFMONTH(date) = 28 OR date = (SELECT MAX(date) FROM main.field_learning_enablement.fact_daily_mau WHERE DAYOFMONTH(date)<=28))
    GROUP BY ALL
)
SELECT 
    *
FROM(
    SELECT
        T1.month,
        T1.mau AS `mau_L&E_Dash`,
        T2.mau AS mau_usat,
        T3.mau AS mau_definition
    FROM
        _mau_learning T1
    LEFT JOIN
        _mau_usat T2 USING(month)
    LEFT JOIN
        _mau_definition T3 USING(month)
    WHERE
        DATE_TRUNC('month', T1.month)::date >= DATEADD(MONTH, -1, current_timestamp()::DATE)    
) AS X