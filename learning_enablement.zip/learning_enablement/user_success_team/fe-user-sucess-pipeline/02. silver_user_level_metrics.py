# Databricks notebook source
# MAGIC %md
# MAGIC | **Field**      | **Description** |
# MAGIC | ----------- | ----------- |
# MAGIC | **Name**      | 02. silver_monthly_mau |
# MAGIC | **Team**      | User Success       |
# MAGIC | **Organisation**   | Learning & Enablement        |
# MAGIC | **Owner**   | abraham.fuertes@databricks.com        |
# MAGIC | **Purpose**   | This notebook is used to explore the data on the source tables for generating the metrics needed |
# MAGIC | **Source(s)**  | user_metrics, user_summary, core_accounts_curated |
# MAGIC | **Target:**    | silver_monthly_mau |            

# COMMAND ----------

# MAGIC %md
# MAGIC ####Env Setup
# MAGIC
# MAGIC * Set Spark configuration
# MAGIC * Clean up all residual widgets
# MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
# MAGIC * Add in any additional environment setup pieces that you need for your notebook
# MAGIC * Set up parameters

# COMMAND ----------

#standard libraries
import sys
from datetime import datetime, timedelta
import logging
import warnings
from pprint import pprint
# from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
import json
import requests
from urllib.parse import quote_plus as urlencode
import pandas as pd

warnings.filterwarnings("ignore")

# COMMAND ----------

#standard widgets - do not change
dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
dbutils.widgets.text("focus_database_name", "main.field_self_service")
dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
dbutils.widgets.text("partition_column", "processDate")

# COMMAND ----------

#pass parameter values to variables
try:
    focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
    focus_database_name = dbutils.widgets.get("focus_database_name")
    partition_date = dbutils.widgets.get("partition_date")
    partition_column = dbutils.widgets.get("partition_column")
except:
    print("Please check the parameters passed are valid")
    raise Exception

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1 - Main process

# COMMAND ----------

# DBTITLE 1,generating temp view apj_top_100_accounts_program
# MAGIC %run "../2025-03/USAT-243 APJ Top 100"

# COMMAND ----------

# MAGIC %sql
# MAGIC -- =============================================
# MAGIC -- Title:      Total MAU definition by month
# MAGIC -- Create date: 2024-09-10
# MAGIC -- Description: This query creates a temporary view vw_mau_monthly that selects distinct monthly user activity data from the user_metrics table. 
# MAGIC -- It filters for customers, ensures the date is within the last 10 months, and excludes specific Salesforce account IDs. 
# MAGIC -- The view includes the month, the earliest month of activity for each user, the customer ID, and the user ID.
# MAGIC -- =============================================
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _accts_tagging
# MAGIC AS
# MAGIC WITH _apj_mapping
# MAGIC AS(
# MAGIC   SELECT 
# MAGIC     deployable_account_id AS account_id,
# MAGIC     "APJ - " || tagging AS tagging
# MAGIC   FROM 
# MAGIC     apj_top_100_accounts_program
# MAGIC ), _amer_industries_mapping
# MAGIC AS(
# MAGIC   SELECT 
# MAGIC     account_id,
# MAGIC     "AMER - Industries Tag Accts" AS tagging 
# MAGIC   FROM 
# MAGIC     main.gtm_data.core_accounts_curated 
# MAGIC   WHERE 
# MAGIC     details like "%AMERINDMM%"
# MAGIC )
# MAGIC
# MAGIC SELECT * FROM _apj_mapping
# MAGIC UNION
# MAGIC SELECT * FROM _amer_industries_mapping

# COMMAND ----------

# DBTITLE 1,Get user_summary data related to the user
# MAGIC %sql
# MAGIC -- =============================================
# MAGIC -- Title:      Get user_summary data related to the user
# MAGIC -- Create date: 2024-10-10
# MAGIC -- Description: This query is used to customer_spend_category and user_segmentation from user_summary
# MAGIC -- The query returns the data for the user with the most recent date on each month. 
# MAGIC -- This is due the user can change the spend category on the same month.
# MAGIC -- =============================================
# MAGIC CREATE OR REPLACE TEMPORARY VIEW vw_user_summary
# MAGIC AS
# MAGIC SELECT 
# MAGIC   date_Trunc('month', T1.date)::date as month,
# MAGIC   T1.date,
# MAGIC   T1.user_id,
# MAGIC   T1.customer_spend_category,
# MAGIC   T1.user_segmentation
# MAGIC FROM 
# MAGIC   main.data_product_intelligence.user_summary T1
# MAGIC WHERE
# MAGIC   --T1.date >= DATEADD(MONTH, -10, current_timestamp()::DATE)  
# MAGIC   T1.date >= '2024-01-01'
# MAGIC QUALIFY 
# MAGIC   ROW_NUMBER() OVER (PARTITION BY date_Trunc('month', T1.date), T1.user_id ORDER BY T1.date DESC) = 1

# COMMAND ----------

# DBTITLE 0,Total MAU definition by month
# MAGIC %sql
# MAGIC -- =============================================
# MAGIC -- Title:      Total MAU definition by month
# MAGIC -- Create date: 2024-09-10
# MAGIC -- Description: This query creates a temporary view vw_mau_monthly that selects distinct monthly user activity data from the user_metrics table. 
# MAGIC -- It filters for customers, ensures the date is within the last 10 months, and excludes specific Salesforce account IDs. 
# MAGIC -- The view includes the month, the earliest month of activity for each user, the customer ID, and the user ID.
# MAGIC -- =============================================
# MAGIC CREATE OR REPLACE TEMPORARY VIEW vw_mau_monthly
# MAGIC AS  
# MAGIC   SELECT
# MAGIC     date_trunc('MONTH', T1.date)::date as month,
# MAGIC     T1.date,
# MAGIC     min(date_trunc('MONTH', T1.date)::date) over(partition by T1.user_id)::date as min_month,
# MAGIC     T1.customer_id,
# MAGIC     T1.bu,
# MAGIC     T1.bu_1,
# MAGIC     T1.bu_2,
# MAGIC     T1.bu_3,   
# MAGIC     T1.account_name,  
# MAGIC     T1.sa_manager,
# MAGIC     T1.account_executive,
# MAGIC     T1.ae_manager,    
# MAGIC     T1.user_id AS user_id,
# MAGIC     T1.user_type,
# MAGIC     T1.mau,
# MAGIC     T1.mau_producers,
# MAGIC     T1.mau_human,
# MAGIC     T1.mau_service_principal,    
# MAGIC     T1.wau,
# MAGIC     T1.wau_producers,
# MAGIC     T1.wau_human,
# MAGIC     T1.wau_service_principal,    
# MAGIC     T1.segmentation_by_size,
# MAGIC     T1.total_dollars_t7d,
# MAGIC     T1.total_dollars_t28d,
# MAGIC     T1.total_dollars_t28d_human,
# MAGIC     T1.total_dollars_t28d_service_principal,    
# MAGIC     T1.login_num_events_t7d,
# MAGIC     T1.login_num_events_t28d,
# MAGIC     T1.dbsql_mau,
# MAGIC     T1.dbsql_dollars_t28d AS dbsql_dollars,
# MAGIC     T1.uc_mau,
# MAGIC     T1.uc_dollars,
# MAGIC     T1.lakeview_mau,
# MAGIC     T1.lakeview_dollars,
# MAGIC     T1.ds_ml_mau,
# MAGIC     T1.ds_ml_dollars,
# MAGIC     T1.etl_mau,
# MAGIC     T1.etl_dollars,
# MAGIC     T1.delta_mau,
# MAGIC     T1.delta_dollars
# MAGIC   FROM 
# MAGIC     ${focus_database_name}.fact_daily_mau AS T1
# MAGIC   WHERE 
# MAGIC     (DAYOFMONTH(date) = 28 OR date = (SELECT MAX(date) FROM ${focus_database_name}.fact_daily_mau WHERE DAYOFMONTH(date)<=28))

# COMMAND ----------

# DBTITLE 1,Total courses enrolled
# MAGIC %sql
# MAGIC -- =============================================
# MAGIC -- Title:      Total courses enrolled
# MAGIC -- Create date: 2024-09-10
# MAGIC -- Description: This query selects distinct monthly user activity data from the user_metrics table. 
# MAGIC -- It filters for customers, ensures the date is within the last 10 months, and excludes specific Salesforce account IDs.
# MAGIC -- The column tenure_3_months that indicates if the user has been active in the previous 3 months and 
# MAGIC -- The column user_status that categorizes the user as 'New', 'Resurrected', or 'Existing' based on their activity.
# MAGIC -- =============================================
# MAGIC
# MAGIC CREATE OR REPLACE TEMPORARY VIEW vw_silver_monthly_mau
# MAGIC AS
# MAGIC -- MAU Definition
# MAGIC --
# MAGIC WITH _initial
# MAGIC AS (
# MAGIC   SELECT
# MAGIC     T1.month,
# MAGIC     T1.date,
# MAGIC     T1.min_month,    
# MAGIC     T1.customer_id,   
# MAGIC     T1.bu,
# MAGIC     T1.bu_1,
# MAGIC     T1.bu_2,
# MAGIC     T1.bu_3,   
# MAGIC     T1.account_name,  
# MAGIC     T1.sa_manager,
# MAGIC     T1.account_executive,
# MAGIC     T1.ae_manager,
# MAGIC     T1.user_id,
# MAGIC     T1.segmentation_by_size,
# MAGIC     T1.total_dollars_t7d,
# MAGIC     T1.total_dollars_t28d,
# MAGIC     T1.total_dollars_t28d_human,
# MAGIC     T1.total_dollars_t28d_service_principal,        
# MAGIC     T1.login_num_events_t7d,
# MAGIC     T1.login_num_events_t28d,
# MAGIC     T1.mau,
# MAGIC     T1.mau_producers,
# MAGIC     T1.mau_human,
# MAGIC     T1.mau_service_principal,    
# MAGIC     T1.wau,
# MAGIC     T1.wau_producers,
# MAGIC     T1.wau_human,
# MAGIC     T1.wau_service_principal,    
# MAGIC     T2.customer_spend_category, 
# MAGIC     T2.user_segmentation, 
# MAGIC     CASE WHEN T2.user_segmentation = 'API user' THEN T1.mau end as mau_api,
# MAGIC     CASE WHEN T2.user_segmentation = 'Data Analyst' THEN T1.mau end as mau_data_analyst,
# MAGIC     T1.user_type,    
# MAGIC     T1.dbsql_mau,
# MAGIC     T1.dbsql_dollars,
# MAGIC     T1.uc_mau,
# MAGIC     T1.uc_dollars,
# MAGIC     T1.lakeview_mau,
# MAGIC     T1.lakeview_dollars,
# MAGIC     T1.ds_ml_mau,
# MAGIC     T1.ds_ml_dollars,
# MAGIC     T1.etl_mau,
# MAGIC     T1.etl_dollars,
# MAGIC     T1.delta_mau,
# MAGIC     T1.delta_dollars,
# MAGIC     IFF(T3.account_id IS NOT NULL, T3.tagging, 'Not Tagged') AS tagging
# MAGIC   FROM 
# MAGIC     vw_mau_monthly AS T1
# MAGIC   LEFT JOIN
# MAGIC     vw_user_summary AS T2
# MAGIC     ON T1.month = T2.month
# MAGIC     AND T1.user_id = T2.user_id
# MAGIC   LEFT JOIN
# MAGIC     _accts_tagging AS T3
# MAGIC     ON T1.customer_id = T3.account_id  
# MAGIC ), cte_monthly_mau
# MAGIC AS (
# MAGIC   SELECT
# MAGIC     *,
# MAGIC     LAG(month, 1) OVER (PARTITION BY user_id ORDER BY month) = DATE_ADD(month, -1, month) AS active_last_1month,
# MAGIC     LAG(month, 2) OVER (PARTITION BY user_id ORDER BY month) = DATE_ADD(month, -2, month) AS active_last_2month,
# MAGIC     LAG(month, 3) OVER (PARTITION BY user_id ORDER BY month) = DATE_ADD(month, -3, month) AS active_last_3month 
# MAGIC   FROM 
# MAGIC     _initial
# MAGIC )
# MAGIC SELECT 
# MAGIC   month,  
# MAGIC   date,
# MAGIC   min_month,
# MAGIC   customer_id,
# MAGIC   bu,
# MAGIC   bu_1,
# MAGIC   bu_2,
# MAGIC   bu_3,   
# MAGIC   sa_manager,
# MAGIC   account_executive,
# MAGIC   ae_manager,
# MAGIC   account_name,    
# MAGIC   customer_spend_category,
# MAGIC   user_id, 
# MAGIC   user_segmentation,
# MAGIC   if(active_last_1month AND active_last_2month AND active_last_3month, 'Yes', 'No') AS tenure_3_months,
# MAGIC   CASE
# MAGIC     WHEN month = min_month THEN 'New'
# MAGIC     WHEN NOT(active_last_1month) THEN 'Resurrected'
# MAGIC     ELSE 'Existing'
# MAGIC   END AS user_status,
# MAGIC   nvl(mau, 0) AS mau,   
# MAGIC   nvl(mau_producers, 0) AS mau_producers,    
# MAGIC   nvl(wau, 0) AS wau, 
# MAGIC   nvl(wau_producers, 0) AS wau_producers,
# MAGIC   nvl(wau_human, 0) AS wau_human,     
# MAGIC   nvl(wau_service_principal, 0) AS wau_service_principal,      
# MAGIC   segmentation_by_size,
# MAGIC   nvl(total_dollars_t7d, 0) AS total_dollars_t7d,
# MAGIC   nvl(total_dollars_t28d, 0) AS total_dollars_t28d,
# MAGIC   nvl(login_num_events_t7d, 0) AS login_num_events_t7d,
# MAGIC   nvl(login_num_events_t28d, 0) AS login_num_events_t28d,  
# MAGIC   nvl(mau_api, 0) AS mau_api, 
# MAGIC   nvl(mau_data_analyst, 0) AS mau_data_analyst, 
# MAGIC   nvl(mau_human, 0) AS mau_human, 
# MAGIC   nvl(mau_service_principal, 0) AS mau_service_principal, 
# MAGIC   nvl(total_dollars_t28d_human, 0) AS total_dollars_t28d_human,
# MAGIC   nvl(total_dollars_t28d_service_principal, 0) AS total_dollars_t28d_service_principal,
# MAGIC   nvl(dbsql_mau, 0) AS dbsql_mau,
# MAGIC   nvl(dbsql_dollars, 0) AS dbsql_dollars,
# MAGIC   nvl(uc_mau, 0) AS uc_mau,
# MAGIC   nvl(uc_dollars, 0) AS uc_dollars,
# MAGIC   nvl(lakeview_mau, 0) AS lakeview_mau,
# MAGIC   nvl(lakeview_dollars, 0) AS lakeview_dollars,
# MAGIC   nvl(ds_ml_mau, 0) AS ds_ml_mau,
# MAGIC   nvl(ds_ml_dollars, 0) AS ds_ml_dollars,
# MAGIC   nvl(etl_mau, 0) AS etl_mau,
# MAGIC   nvl(etl_dollars, 0) AS etl_dollars,
# MAGIC   nvl(delta_mau, 0) AS delta_mau,
# MAGIC   nvl(delta_dollars, 0) AS delta_dollars,
# MAGIC   user_type,
# MAGIC   tagging
# MAGIC FROM 
# MAGIC   cte_monthly_mau m

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE ${focus_database_name}.silver_monthly_mau
# MAGIC AS
# MAGIC SELECT * FROM vw_silver_monthly_mau;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   *
# MAGIC FROM
# MAGIC   ${focus_database_name}.silver_monthly_mau T1
# MAGIC WHERE
# MAGIC   user_id = '9ba901332b7701392b1c2738da0ee1b863586f37404f88d15b827eae532a2931'

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   month,
# MAGIC   user_status,  
# MAGIC   sum(mau)
# MAGIC FROM
# MAGIC   ${focus_database_name}.silver_monthly_mau T1
# MAGIC WHERE
# MAGIC   T1.user_segmentation IS NULL
# MAGIC GROUP BY ALL
# MAGIC ORDER BY month DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   date_Trunc('month', T1.date)::date as month,
# MAGIC   T1.date,
# MAGIC   T1.user_id,
# MAGIC   T1.customer_spend_category,
# MAGIC   T1.user_segmentation
# MAGIC FROM 
# MAGIC   main.data_product_intelligence.user_summary T1
# MAGIC WHERE
# MAGIC   --T1.date >= DATEADD(MONTH, -10, current_timestamp()::DATE)  
# MAGIC   T1.date >= '2024-01-01'
# MAGIC   AND T1.user_id = '9ba901332b7701392b1c2738da0ee1b863586f37404f88d15b827eae532a2931'
# MAGIC QUALIFY 
# MAGIC   ROW_NUMBER() OVER (PARTITION BY date_Trunc('month', T1.date), T1.user_id ORDER BY T1.date DESC) = 1