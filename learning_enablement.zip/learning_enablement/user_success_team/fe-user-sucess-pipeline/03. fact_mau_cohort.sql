-- Databricks notebook source
-- MAGIC %md
-- MAGIC | **Field**      | **Description** |
-- MAGIC | ----------- | ----------- |
-- MAGIC | **Name**      | 03. fact_mau_cohort |
-- MAGIC | **Team**      | User Success       |
-- MAGIC | **Organisation**   | Learning & Enablement        |
-- MAGIC | **Owner**   | abraham.fuertes@databricks.com        |
-- MAGIC | **Purpose**   | This notebook is used to explore the data on the source tables for generating the metrics needed |
-- MAGIC | **Source(s)**  | silver_monthly_mau |
-- MAGIC | **Target:**    | fact_mau_cohort |           

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####Env Setup
-- MAGIC
-- MAGIC * Set Spark configuration
-- MAGIC * Clean up all residual widgets
-- MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
-- MAGIC * Add in any additional environment setup pieces that you need for your notebook
-- MAGIC * Set up parameters

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard libraries
-- MAGIC import sys
-- MAGIC from datetime import datetime, timedelta
-- MAGIC import logging
-- MAGIC import warnings
-- MAGIC from pprint import pprint
-- MAGIC # from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
-- MAGIC import json
-- MAGIC import requests
-- MAGIC from urllib.parse import quote_plus as urlencode
-- MAGIC import pandas as pd
-- MAGIC
-- MAGIC warnings.filterwarnings("ignore")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard widgets - do not change
-- MAGIC dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
-- MAGIC dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
-- MAGIC dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
-- MAGIC dbutils.widgets.text("partition_column", "processDate")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #pass parameter values to variables
-- MAGIC try:
-- MAGIC     focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
-- MAGIC     focus_database_name = dbutils.widgets.get("focus_database_name")
-- MAGIC     partition_date = dbutils.widgets.get("partition_date")
-- MAGIC     partition_column = dbutils.widgets.get("partition_column")
-- MAGIC except:
-- MAGIC     print("Please check the parameters passed are valid")
-- MAGIC     raise Exception

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1 - Main process

-- COMMAND ----------

-- =============================================
-- Title:      
-- Create date: 2024-09-10
-- Description: 
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW vw_monthly_jcurve
AS
WITH n_cohort
AS(
  SELECT explode(sequence(0, 6)) AS month_compare
)
SELECT
  T1.month
  , T1.min_month
  , T2.month_compare
  , T1.customer_id
  , T1.user_id  
  , T1.mau
  , T1.tenure_3_months
  , T1.user_status
FROM ${focus_database_name}.silver_monthly_mau AS T1
CROSS JOIN n_cohort AS T2

INNER JOIN ${focus_database_name}.silver_monthly_mau AS T3
  ON T1.month = DATEADD(MONTH, -T2.month_compare, T3.month)
  AND T1.user_id = T3.user_id

-- COMMAND ----------

CREATE OR REPLACE TABLE ${focus_database_name}.fact_mau_cohort
AS
-- =============================================
-- Title: Monthly MAU Cohort Analysis
-- Create date: 2024-09-10
-- Description: This query creates a table for Monthly MAU Cohort Analysis by aggregating user data from the vw_monthly_jcurve view.
-- =============================================
  SELECT
    T1.month AS cohort
    , T1.customer_id AS customer_id
    , T1.month_compare as mau_comparison    
    , SUM(T1.mau) as current_mau
    , SUM(DISTINCT CASE WHEN T1.user_status = 'New' THEN T1.mau END) as new_MAU
    , SUM(DISTINCT CASE WHEN T1.tenure_3_months = 'Yes' THEN T1.mau END) as tenure_3_month_mau
  FROM vw_monthly_jcurve T1  
  GROUP BY T1.month, T1.month_compare, T1.customer_id
  ORDER BY 1, 3

-- COMMAND ----------

ALTER TABLE ${focus_database_name}.fact_mau_cohort
CLUSTER BY (customer_id);

-- COMMAND ----------

OPTIMIZE ${focus_database_name}.fact_mau_cohort;