-- Databricks notebook source
-- MAGIC %md
-- MAGIC | **Field**      | **Description** |
-- MAGIC | ----------- | ----------- |
-- MAGIC | **Name**      | fact_daily_mau |
-- MAGIC | **Team**      | User Success       |
-- MAGIC | **Organisation**   | Learning & Enablement        |
-- MAGIC | **Owner**   | abraham.fuertes@databricks.com        |
-- MAGIC | **Purpose**   | This notebook is used to explore the data on the source tables for generating the metrics needed |
-- MAGIC | **Source(s)**  | user_metrics |
-- MAGIC | **Target:**    | fact_daily_mau |            

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####Env Setup
-- MAGIC
-- MAGIC * Set Spark configuration
-- MAGIC * Clean up all residual widgets
-- MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
-- MAGIC * Add in any additional environment setup pieces that you need for your notebook
-- MAGIC * Set up parameters

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard libraries
-- MAGIC import sys
-- MAGIC from datetime import datetime, timedelta
-- MAGIC import logging
-- MAGIC import warnings
-- MAGIC from pprint import pprint
-- MAGIC # from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
-- MAGIC import json
-- MAGIC import requests
-- MAGIC from urllib.parse import quote_plus as urlencode
-- MAGIC import pandas as pd
-- MAGIC
-- MAGIC warnings.filterwarnings("ignore")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard widgets - do not change
-- MAGIC dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
-- MAGIC dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
-- MAGIC dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
-- MAGIC dbutils.widgets.text("partition_column", "processDate")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #pass parameter values to variables
-- MAGIC try:
-- MAGIC     focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
-- MAGIC     focus_database_name = dbutils.widgets.get("focus_database_name")
-- MAGIC     partition_date = dbutils.widgets.get("partition_date")
-- MAGIC     partition_column = dbutils.widgets.get("partition_column")
-- MAGIC except:
-- MAGIC     print("Please check the parameters passed are valid")
-- MAGIC     raise Exception

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1 - Main process

-- COMMAND ----------

CREATE OR REPLACE TABLE ${focus_database_name}.fact_daily_mau
AS  
  SELECT 
    date_trunc('MONTH', T1.date)::date as month
    , min(T1.date) over(partition by T1.user_id)::date as min_date
    , min(date_trunc('MONTH', T1.date)::date) over(partition by T1.user_id)::date as min_month
    , T1.date
    , T1.customer_id
    , a.business_unit AS bu
    , a.sales_subregion_level_1 AS bu_1
    , a.sales_subregion_level_2 AS bu_2
    , a.sales_subregion_level_3 AS bu_3
    , a.account_name AS account_name
    , a.sa_manager
    , a.account_executive AS account_executive
    , a.sales_manager as ae_manager
    , T1.user_id AS user_id
    , CASE 
        WHEN login_user_type = 'USER' THEN 'Human' 
        WHEN login_user_type = 'SERVICE_PRINCIPAL' THEN 'Service Principal' END AS user_type
    , CASE 
        WHEN total_dollars_t28d > 1000 THEN 'Very high usage (>1k)' 
        WHEN total_dollars_t28d > 100 THEN 'High usage (100-1000)' 
        WHEN total_dollars_t28d > 10 THEN 'Medium usage (10-100)'
        WHEN total_dollars_t28d > 0 THEN 'Low usage (0-10)'
        WHEN total_dollars_t28d = 0 THEN 'No usage (0)' END AS segmentation_by_size
    , IFF(login_num_events_t28d > 0, 1, 0) AS mau
    , CASE WHEN user_type = 'Human' THEN mau end as mau_human
    , CASE WHEN user_type = 'Service Principal' THEN mau end as mau_service_principal
    , IFF(login_num_events_t28d > 0 AND total_dollars_t28d > 0, 1, 0) AS mau_producers
    , IFF(login_num_events_t7d > 0, 1, 0) AS wau
    , CASE WHEN user_type = 'Human' THEN wau end as wau_human
    , CASE WHEN user_type = 'Service Principal' THEN wau end as wau_service_principal
    , IFF(login_num_events_t7d > 0 AND total_dollars_t7d > 0, 1, 0) AS wau_producers
    , total_dollars_t7d AS total_dollars_t7d
    , total_dollars_t28d AS total_dollars_t28d
    , CASE WHEN user_type = 'Human' THEN total_dollars_t28d end as total_dollars_t28d_human
    , CASE WHEN user_type = 'Service Principal' THEN total_dollars_t28d end as total_dollars_t28d_service_principal
    , login_num_events_t7d AS login_num_events_t7d
    , login_num_events_t28d AS login_num_events_t28d
    , CASE WHEN dbsql_num_workloads_t7d > 0 THEN 1 END as dbsql_wau
    , CASE WHEN dbsql_num_workloads_t28d > 0 THEN 1 END as dbsql_mau
    , dbsql_dollars_t7d AS dbsql_dollars_t7d
    , dbsql_dollars_t28d AS dbsql_dollars_t28d    
    , CASE WHEN unity_catalog_num_workloads_t7d > 0 THEN 1 END as uc_wau
    , CASE WHEN unity_catalog_num_workloads_t28d > 0 THEN 1 END as uc_mau
    , unity_catalog_dollars_t7d AS uc_dollars_t7d
    , unity_catalog_dollars_t28d AS uc_dollars
    , CASE WHEN lakeview_num_events_t7d > 0 THEN 1 END as lakeview_wau
    , CASE WHEN lakeview_num_events_t28d > 0 THEN 1 END as lakeview_mau
    , lakeview_dollars_t7d AS lakeview_dollars_t7d
    , lakeview_dollars_t28d AS lakeview_dollars    
    , CASE WHEN ds_ml_num_workloads_t7d > 0 THEN 1 END as ds_ml_wau
    , CASE WHEN ds_ml_num_workloads_t28d > 0 THEN 1 END as ds_ml_mau
    , ds_ml_dollars_t7d AS ds_ml_dollars_t7d
    , ds_ml_dollars_t28d AS ds_ml_dollars    
    , CASE WHEN etl_dbus_t7d > 0 THEN 1 END as etl_wau
    , CASE WHEN etl_dbus_t28d > 0 THEN 1 END as etl_mau
    , etl_dollars_t7d AS etl_dollars_t7d
    , etl_dollars_t28d AS etl_dollars    
    , CASE WHEN delta_num_workloads_t7d > 0 THEN 1 END as delta_wau
    , CASE WHEN delta_num_workloads_t28d > 0 THEN 1 END as delta_mau
    , delta_dollars_t7d AS delta_dollars_t7d
    , delta_dollars_t28d AS delta_dollars    
    , CASE WHEN genie_num_workloads_t7d > 0 THEN 1 END as genie_wau
    , CASE WHEN genie_num_workloads_t28d > 0 THEN 1 END as genie_mau
    , genie_dollars_t7d AS genie_dollars_t7d
    , genie_dollars_t28d AS genie_dollars    
  FROM 
    main.data_product_features.user_metrics AS T1
  LEFT JOIN 
    main.gtm_data.core_accounts_curated a
  ON T1.customer_id = a.account_id  
  WHERE 
    salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
    AND ds >= DATE_TRUNC('month', ADD_MONTHS(CURRENT_DATE(), -10));

-- COMMAND ----------

ALTER TABLE ${focus_database_name}.fact_daily_mau
CLUSTER BY (date, customer_id);

-- COMMAND ----------

OPTIMIZE ${focus_database_name}.fact_daily_mau;

-- COMMAND ----------

SELECT
  T1.date,
  SUM(mau),
  SUM(wau)
FROM
  ${focus_database_name}.fact_daily_mau AS T1
GROUP BY ALL;

-- COMMAND ----------

SELECT SUM(T1.mau), T1.month
FROM 
  main.field_learning_enablement.monthly_active_users T1
WHERE
  T1.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.monthly_active_users)
GROUP BY ALL;

-- COMMAND ----------


SELECT 
  date_trunc('MONTH', T1.date)::date as month  
  , T1.date    
  , SUM(IFF(login_num_events_t7d > 0, 1, 0)) AS wau
  , SUM(CASE WHEN login_user_type = 'USER' AND login_num_events_t7d > 0 THEN 1 end) as wau_human    
FROM 
  main.data_product_features.user_metrics AS T1
WHERE (DAYOFMONTH(date) = 28 OR date = (SELECT MAX(date) FROM ${focus_database_name}.fact_daily_mau WHERE DAYOFMONTH(date)<=28))  
GROUP BY ALL