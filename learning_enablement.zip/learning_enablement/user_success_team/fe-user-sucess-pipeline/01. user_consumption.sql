-- Databricks notebook source
-- MAGIC %md
-- MAGIC | **Field**      | **Description** |
-- MAGIC | ----------- | ----------- |
-- MAGIC | **Name**      | 06. user_consumption |
-- MAGIC | **Team**      | User Success       |
-- MAGIC | **Organisation**   | Learning & Enablement        |
-- MAGIC | **Owner**   | abraham.fuertes@databricks.com        |
-- MAGIC | **Purpose**   | This notebook is used to explore the data on the source tables for generating the metrics needed |
-- MAGIC | **Source(s)**  | core_account_consumption_measures_monthly |
-- MAGIC | **Target:**    | user_consumption |           

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####Env Setup
-- MAGIC
-- MAGIC * Set Spark configuration
-- MAGIC * Clean up all residual widgets
-- MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
-- MAGIC * Add in any additional environment setup pieces that you need for your notebook
-- MAGIC * Set up parameters

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard libraries
-- MAGIC import sys
-- MAGIC from datetime import datetime, timedelta
-- MAGIC import logging
-- MAGIC import warnings
-- MAGIC from pprint import pprint
-- MAGIC # from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
-- MAGIC import json
-- MAGIC import requests
-- MAGIC from urllib.parse import quote_plus as urlencode
-- MAGIC import pandas as pd
-- MAGIC
-- MAGIC warnings.filterwarnings("ignore")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard widgets - do not change
-- MAGIC dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
-- MAGIC dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
-- MAGIC dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
-- MAGIC dbutils.widgets.text("partition_column", "processDate")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #pass parameter values to variables
-- MAGIC try:
-- MAGIC     focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
-- MAGIC     focus_database_name = dbutils.widgets.get("focus_database_name")
-- MAGIC     partition_date = dbutils.widgets.get("partition_date")
-- MAGIC     partition_column = dbutils.widgets.get("partition_column")
-- MAGIC except:
-- MAGIC     print("Please check the parameters passed are valid")
-- MAGIC     raise Exception

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1 - Main process

-- COMMAND ----------

CREATE OR REPLACE TABLE ${focus_database_name}.user_consumption
AS
WITH consumption 
AS (  
  SELECT 
    month_start_date,
    account_id,
    sub_business_unit BU_1,
    SUM(dbu_dollars_mtd) dbu_dollars,
    SUM(dbu_quantity_mtd) dbu
  from
    main.gtm_data.core_account_consumption_measures_monthly
  WHERE 
    month_start_date >= DATE_TRUNC('month', ADD_MONTHS(CURRENT_DATE(), -10))
  GROUP BY ALL
  ORDER BY ALL
), mau
AS (
  SELECT 
    month, 
    customer_id, 
    SUM(mau) AS mau,
    SUM(mau_human) AS mau_human,
    SUM(wau) AS wau,
    SUM(wau_human) AS wau_human
  FROM 
    ${focus_database_name}.fact_mau_users  
  GROUP BY ALL
)

SELECT
  CASE month_start_date
    WHEN DATE_TRUNC('month', CURRENT_DATE()) THEN 'Current month'
    WHEN DATE_TRUNC('month', DATEADD(MONTH, -1, CURRENT_DATE())) THEN 'Last month'
    ELSE 'Others' END AS relative_month_period,
  nvl(c.month_start_date, m.month) month, 
  nvl(c.account_id, m.customer_id) as customer_id, 
  a.business_unit AS bu,
  a.sales_subregion_level_1 AS bu_1,
  a.sales_subregion_level_2 AS bu_2,
  a.sales_subregion_level_3 AS bu_3,
  a.account_name AS account_name,
  SUM(dbu) dbu,
  SUM(dbu_dollars) dbu_dollars,
  SUM(mau) mau,
  SUM(mau_human) mau_human,
  SUM(wau) wau,
  SUM(wau_human) wau_human
FROM 
  consumption c
LEFT JOIN mau AS m
  ON c.month_start_date = m.month
  AND c.account_id = m.customer_id
LEFT JOIN 
    main.gtm_data.core_accounts_curated as a 
ON
  nvl(c.account_id, m.customer_id) = a.account_id
WHERE 
    a.account_status != 'Prospect'
GROUP BY ALL;

SELECT 
  * 
FROM 
  ${focus_database_name}.user_consumption

-- COMMAND ----------

SELECT * 
FROM main.field_learning_enablement.user_consumption
WHERE month = '2025-03-01';