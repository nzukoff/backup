-- Databricks notebook source
-- MAGIC %md
-- MAGIC | **Field**      | **Description** |
-- MAGIC | ----------- | ----------- |
-- MAGIC | **Name**      | 06. user_consumption |
-- MAGIC | **Team**      | User Success       |
-- MAGIC | **Organisation**   | Learning & Enablement        |
-- MAGIC | **Owner**   | abraham.fuertes@databricks.com        |
-- MAGIC | **Purpose**   | The customer_level_metrics table is designed to aggregate and consolidate various metrics and attributes related to customers with MAU data |
-- MAGIC | **Source(s)**  | core_account_consumption_measures_monthly |
-- MAGIC | **Target:**    | customer_level_metrics |           

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####Env Setup
-- MAGIC
-- MAGIC * Set Spark configuration
-- MAGIC * Clean up all residual widgets
-- MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
-- MAGIC * Add in any additional environment setup pieces that you need for your notebook
-- MAGIC * Set up parameters

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard libraries
-- MAGIC import sys
-- MAGIC from datetime import datetime, timedelta
-- MAGIC import logging
-- MAGIC import warnings
-- MAGIC from pprint import pprint
-- MAGIC # from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
-- MAGIC import json
-- MAGIC import requests
-- MAGIC from urllib.parse import quote_plus as urlencode
-- MAGIC import pandas as pd
-- MAGIC
-- MAGIC warnings.filterwarnings("ignore")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard widgets - do not change
-- MAGIC dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
-- MAGIC dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
-- MAGIC dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
-- MAGIC dbutils.widgets.text("partition_column", "processDate")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #pass parameter values to variables
-- MAGIC try:
-- MAGIC     focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
-- MAGIC     focus_database_name = dbutils.widgets.get("focus_database_name")
-- MAGIC     partition_date = dbutils.widgets.get("partition_date")
-- MAGIC     partition_column = dbutils.widgets.get("partition_column")
-- MAGIC except:
-- MAGIC     print("Please check the parameters passed are valid")
-- MAGIC     raise Exception

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1 - Main process

-- COMMAND ----------

CREATE OR REPLACE TABLE ${focus_database_name}.customer_level_metrics
AS
WITH _mau_wau
AS (
  SELECT 
    customer_id,
    account_name, 
    bu, 
    bu_1, 
    bu_2, 
    bu_3,
    sa_manager,
    account_executive,
    ae_manager,
    tagging,
    SUM(mau) AS mau,
    SUM(mau_human) AS mau_human,
    SUM(wau) AS wau,
    SUM(wau_human) AS wau_human
  FROM 
    ${focus_database_name}.silver_monthly_mau AS T1
  WHERE
    T1.month = (SELECT MAX(month) FROM ${focus_database_name}.silver_monthly_mau)
  GROUP BY ALL
), _product_usage
AS (
  SELECT 
    date_trunc('month',date)::date as month,
    c.customer_id,    
    sum(dbsql_num_users_t28d) as dbsql_users,
    sum(dbsql_dollars) as dbsql_dollars,
    sum(unity_catalog_num_users_t28d) as uc_users,
    sum(unity_catalog_dollars) as uc_dollars,
    sum(lakeview_num_users_t28d) as lakeview_users,
    sum(lakeview_dollars) as lakeview_dollars,
    sum(ds_ml_num_users_t28d) as ds_ml_users,
    sum(ds_ml_dollars) as ds_ml_dollars,
    sum(etl_num_users_t28d) as etl_users,
    sum(etl_dollars) as etl_dollars,
    sum(delta_num_users_t28d) as delta_users,
    sum(delta_dollars) as delta_dollars
  FROM 
    main.data_product_features.customer_metrics c
  WHERE 
    c.date = (SELECT MAX(date) FROM main.data_product_features.customer_metrics)
  GROUP BY ALL
), _lna
as(
  SELECT 
    a.orgID as account_id, 
    a.account_name, 
    max(a.recordedDate) as last_survey_date, 
    count(distinct responseId) as lna_responses
  FROM 
    main.team_field_user_enablement.silver_user_recommendation a
  WHERE 
    RecordedDate = (SELECT MAX(RecordedDate) FROM main.team_field_user_enablement.silver_user_recommendation b WHERE a.email = b.email)
    and a.orgID is not NULL
  GROUP BY ALL
), _learners
AS(
  SELECT 
    updated_account_id AS account_id,
    (SUM(pa_learner) + SUM(da_learner)+ SUM(de_learner) + SUM(ds_learner) + SUM(other_learner)) AS All_Time_learners,
    100* (SUM(CASE WHEN training_value = 'FREE' THEN 1 ELSE 0 END) / All_Time_learners) AS pct_from_free_learners,
    100* (SUM(CASE WHEN training_value = 'PAID' THEN 1 ELSE 0 END) / All_Time_learners) AS pct_from_paid_learners
  FROM 
    main.team_field_user_enablement.vw_ue_learner_by_topic
  GROUP BY ALL
), _account_arr -- Revenue ARR
AS(
  SELECT DISTINCT
      account_id,
      arr
  FROM 
    main.team_field_user_enablement.vw_ue_account_targeting 
), _remaining_sc_for_training_180d -- Returns Remaining Success Credit Value for Projects with <30K SCs expiring in next 180days
AS (
  SELECT
    Account_ID,
    SUM(remaining_success_credits_value) projects_sub_30k_SC_expiring_next_180d_dollars
  FROM
    main.team_field_user_enablement.ce_backlog
  WHERE
    Service_Type = 'Success Credits'
    and Expiring_in_day < 180
    and Available_Budget < 30000
    and Remaining_Success_Credits_Value > 0
  GROUP BY ALL
), _trained_accounts --trained accounts
AS (
  SELECT distinct 
    account_id,
    trained_flag
  FROM 
    main.team_field_user_enablement.trained_accounts
  WHERE 
    snapshot_date = (select max(snapshot_date) from main.team_field_user_enablement.trained_accounts)
), _tip -- TIP: Training Investment Program
AS (
  SELECT 
    account_id AS account_id_tip, 
    MAX(created_date) AS lastest_tip_requested_date, 
    COUNT(DISTINCT request_number) AS tip_num_requests, 
    sum(requested_coupons) AS tip_requested_coupons, 
    sum(used_coupons) AS tip_used_coupons, 
    SUM(attended) AS tip_attended
  FROM 
    main.team_field_user_enablement.vw_coupon_requests
  WHERE 
    status not in ('Cancelled','Rejected')
  GROUP BY ALL
), _employee_count
AS (
  SELECT 
    id AS account_id,
    max(e.NumberOfEmployees) as num_employees
  FROM
    sfdc_bronze.account e
  LEFT JOIN 
    main.gtm_data.core_accounts_curated as a 
    ON e.id = a.account_id 
  WHERE 
    e.NumberOfEmployees > 0 
  GROUP BY ALL
), _ai_bi_campaign
AS (
  SELECT
    T1.account_id,
    SUM(T1.event_registrations) AS event_registrations,
    SUM(T1.event_attendees) AS event_attendees
  FROM 
    main.field_learning_enablement.fact_campaign_analysis AS T1
  GROUP BY ALL
)

SELECT
  m.*,
  p.* EXCEPT (customer_id),
  CASE WHEN lna.last_survey_date IS NOT NULL THEN 'Yes' ELSE 'No' END LNA, 
  lna.lna_responses,
  l.All_Time_learners, 
  l.pct_from_free_learners, 
  l.pct_from_paid_learners,   
  arr.arr  AS training_revenue, 
  CASE WHEN ta.trained_flag = 1 THEN 'Yes' ELSE 'No' END trained_account,
  IFNULL(rsc.projects_sub_30k_SC_expiring_next_180d_dollars, 0) unused_success_credits,
  CASE WHEN t.account_id_tip IS NOT NULL THEN 'Yes' ELSE 'No' END tip_requested,
  t.lastest_tip_requested_date, 
  t.tip_num_requests, 
  t.tip_requested_coupons, 
  t.tip_used_coupons, 
  t.tip_attended,
  ec.num_employees,
  st.account_spend_tier  
FROM
  _mau_wau m
LEFT JOIN _product_usage p USING (customer_id)
LEFT JOIN _lna AS lna
  ON m.customer_id = lna.account_id
LEFT JOIN _learners l
  ON m.customer_id = l.account_id
LEFT JOIN _account_arr arr
  ON m.customer_id = arr.account_id
LEFT JOIN _remaining_sc_for_training_180d rsc
  ON m.customer_id = rsc.Account_ID
LEFT JOIN _trained_accounts ta
  ON m.customer_id = ta.account_id
LEFT JOIN _tip t
  ON m.customer_id = t.account_id_tip
LEFT JOIN _employee_count ec
  ON m.customer_id = ec.account_id
LEFT JOIN main.fin_snap.sfdc_hierarchy_mapping_snap st
  ON m.customer_id = st.sfdc_account_id
ORDER BY m.customer_id, mau DESC;

SELECT 
  * 
FROM 
  ${focus_database_name}.customer_level_metrics T1

-- COMMAND ----------

ALTER TABLE ${focus_database_name}.customer_level_metrics
CLUSTER BY (customer_id);

-- COMMAND ----------

OPTIMIZE ${focus_database_name}.customer_level_metrics;