-- Databricks notebook source
-- MAGIC %md
-- MAGIC **Identifying WAU Drivers**: 
-- MAGIC
-- MAGIC **Description**
-- MAGIC
-- MAGIC Hi team, Heads up there will be a WAU deep dive with Arsalan week of April 7, Can we make a plan on looking at WAU drivers. I'll put some time on our cal this week to discuss. (edited) 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### USAT-269 Check for more accounts with a high increase in WAU growth in the current month

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Results shared by Gabriel on the following Notebook 
-- MAGIC [WAU actual vs target & Drivers](https://adb-2548836972759138.18.azuredatabricks.net/editor/notebooks/4384892907823868?o=2548836972759138#command/4384892910062949)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### USAT-271 Measure the impact on the WAU 1d/7d after the account participates in the learning festival or the AI/BI Campaign

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 1. Get the list of daily WAU for March and February by Account
-- MAGIC - **Feburary measured period:** Feb 1st to Feb 28th
-- MAGIC - **March measured period:** Mar 1st to Mar 31st

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df = spark.sql("""
-- MAGIC   SELECT
-- MAGIC     T1.bu,
-- MAGIC     T1.customer_id AS account_id,    
-- MAGIC     T1.date,
-- MAGIC     T1.account_name,
-- MAGIC     T1.account_executive AS ae,
-- MAGIC     a.last_solution_architect_engaged AS sa,
-- MAGIC     SUM(T1.wau_human) AS wau_human
-- MAGIC   FROM
-- MAGIC     main.field_learning_enablement.fact_daily_mau AS T1
-- MAGIC   LEFT JOIN 
-- MAGIC     main.gtm_data.core_accounts_curated as a 
-- MAGIC   ON
-- MAGIC     T1.customer_id = a.account_id
-- MAGIC   WHERE 
-- MAGIC     T1.date BETWEEN '2025-02-01' AND '2025-03-31'
-- MAGIC   GROUP BY ALL
-- MAGIC """)
-- MAGIC
-- MAGIC display(df)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 2. Calculate the growth of the average of the daily wau between the two months

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql.window import Window
-- MAGIC from pyspark.sql import functions as F
-- MAGIC
-- MAGIC # Assuming df contains columns: account_id, account_name, date, wau_human
-- MAGIC
-- MAGIC # Filter data for February and March
-- MAGIC feb_df = df.filter((F.month("date") == 2)).groupby("bu", "account_id", "account_name", "ae", "sa").agg(F.mean("wau_human").alias("feb_mean_wau"))
-- MAGIC
-- MAGIC mar_df = df.filter((F.month("date") == 3)).groupby("bu", "account_id", "account_name", "ae", "sa").agg(F.mean("wau_human").alias("mar_mean_wau"))
-- MAGIC
-- MAGIC # Join February and March data
-- MAGIC wau_growth_df = feb_df.join(mar_df, ["bu", "account_id", "account_name", "ae", "sa"]).withColumn(
-- MAGIC     "growth", F.col("mar_mean_wau") - F.col("feb_mean_wau")
-- MAGIC ).withColumn(    
-- MAGIC     "pct_growth", F.expr("try_divide(growth, feb_mean_wau) * 100")
-- MAGIC )
-- MAGIC
-- MAGIC # Define window specification
-- MAGIC window_spec = Window.partitionBy("bu").orderBy(F.desc("growth"))
-- MAGIC
-- MAGIC # Add rank column
-- MAGIC wau_growth_df = wau_growth_df.withColumn("rank", F.rank().over(Window.partitionBy("bu").orderBy(F.desc("growth"))))
-- MAGIC
-- MAGIC # Filter by top-10 growing accounts
-- MAGIC wau_growth_df = wau_growth_df.filter(F.col("rank") <= 10)
-- MAGIC
-- MAGIC # Removing unnecessary columns
-- MAGIC wau_growth_df = wau_growth_df.drop("rank", "feb_mean_wau", "mar_mean_wau")
-- MAGIC
-- MAGIC # Show top-growing accounts
-- MAGIC display(wau_growth_df)
-- MAGIC
-- MAGIC # Insert results into a temporary view
-- MAGIC wau_growth_df.createOrReplaceTempView("wau_growth_temp_view")

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### 3. Get the Learning Festival and AI/BI participating accounts

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 3.1 AI/BI Campaign

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _ai_bi
AS
  SELECT
    *
  FROM
    main.field_learning_enablement.fact_campaign_analysis
  WHERE
    program = 'ILT'  
    AND account_id IN (SELECT DISTINCT account_id FROM wau_growth_temp_view);

SELECT * FROM _ai_bi;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 3.2 Learning Festival. Reference from [User Enablement - Virtual Learning Festival Q4 FY25](https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01efb09b3db1156fb287a3701d05a8b4/published?o=2548836972759138)

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _learning_festival
AS
WITH _initial
AS (
-- Learning Festival
SELECT
  ae.updated_account_id,
  ae.learner_user_id, 
  ae.updated_account_name , 
  CASE
      when ae.course_id in (1266, 2963, 1365, 2971, 3144) then 'DEWD'
      when ae.course_id = 2268 then 'ADEWD'
      when ae.course_id in (2307, 2906) then 'DAWD'
      when ae.course_id in (2417, 2343, 2390, 2395, 2400) then 'MLWD'
      when ae.course_id IN(1522, 3417, 3508) then 'MLIP'
      when ae.course_id in (2267, 2726, 2706,2716,2717,2713) then 'GENAI'
  END AS course_completed,
  ae.enrolled_date,
  ae.completed_date,
  'Learning Festival' as course_type
FROM 
  main.field_learning_enablement.all_enrollments ae
WHERE
  ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
  AND ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
  AND ae.course_id in (
    -- Full Courses
    1266, -- DEWD
    2268, -- ADEWD
    2307, -- DAWD
    2906, -- DAWD 2024
    2417, -- MLWD
    1522, -- MLIP
    2267, -- GAIEWD 2023
    2726, -- GAIEWD 2024
    -- DE Modules
    2963, -- Data Ingestion
    1365, -- Workloads
    2971, -- DLT
    3144, -- Governance
    -- MLWD Modules
    2343, -- Data Prep
    2390, -- ML Model Dev
    2395, -- ML Model Dep
    2400, --ML Ops
    -- Gen AI
    2706, -- Gen AI Solution Dev
    2716, -- Gen AI App Dev
    2717, -- Gen AI App Eval
    2713, -- Gen AI App Deployment
    -- AMLWD Modules
    3417, -- ML at Scale
    3508 -- Advanced MLOPs
  )
  and ae.completed_timestamp between '2025-01-15T00:00:00UTC+14' and '2025-02-01T00:00:00UTC-12' -- Q4 FY25
)

SELECT
  updated_account_id AS account_id,
  updated_account_name AS account_name,
  MAX(completed_date) AS max_completed_date,
  COUNT(completed_date) AS completions
FROM 
  _initial
WHERE
  updated_account_id IN (SELECT DISTINCT account_id FROM wau_growth_temp_view)
GROUP BY ALL;

SELECT * FROM _learning_festival ORDER BY 1, 3;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 3.3 Get the Learning Festival Impact

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql import functions as f
-- MAGIC
-- MAGIC def get_session_metrics(df, df_daily_mau, metric_column, period, timeframe):
-- MAGIC     if timeframe == 'wk':
-- MAGIC       period = [(number * 7, number) for number in period]
-- MAGIC     elif timeframe == 'days':
-- MAGIC        period = [(number, number) for number in period]
-- MAGIC     else: 
-- MAGIC       return "No valid timeframe. (wk or days)"    
-- MAGIC
-- MAGIC     # Get the metric aggregated by account on each day
-- MAGIC     df_daily_data = df_daily_mau.groupBy("date", "customer_id").agg(f.sum(metric_column).alias(metric_column))
-- MAGIC     df_final = df.select("account_id", "account_name", "max_completed_date").dropDuplicates()
-- MAGIC
-- MAGIC     # Get the baseline metric        
-- MAGIC     df_final = df_final.join(df_daily_data, (df_final.account_id == df_daily_data.customer_id) & 
-- MAGIC                              (f.date_sub(df_final.max_completed_date, 90) <= df_daily_data.date) & (df_final.max_completed_date > df_daily_data.date), "left").drop("customer_id")
-- MAGIC                              
-- MAGIC     df_final = df_final.groupBy("account_id", "account_name", "max_completed_date").agg(f.avg(metric_column).alias(f"90_days_avg_prev_{metric_column}") )
-- MAGIC
-- MAGIC     # # Get the current date metric value
-- MAGIC     df_final = df_final.join(df_daily_data, (df.account_id == df_daily_data.customer_id) & (df.max_completed_date == df_daily_data.date)).withColumn(
-- MAGIC           f"0_{timeframe}_{metric_column}", f.col(metric_column)).drop("customer_id", "date", metric_column)  
-- MAGIC     
-- MAGIC     # # Get the post session dates metric values
-- MAGIC     period = sorted(period)
-- MAGIC     for offset, number in period:    
-- MAGIC         df_final = df_final.join(df_daily_data, (df_final.account_id == df_daily_data.customer_id) & (f.date_add(df_final.max_completed_date, offset) == df_daily_data.date), "left").withColumn(
-- MAGIC           f"{number}_{timeframe}_post_{metric_column}", f.col(metric_column)).drop("customer_id", "date", metric_column).withColumn(
-- MAGIC           f"{metric_column}_{number}_{timeframe}_growth",  f.col(f"{number}_{timeframe}_post_{metric_column}") - f.col(f"90_days_avg_prev_{metric_column}"))
-- MAGIC             
-- MAGIC     return df_final
-- MAGIC
-- MAGIC df = spark.sql("SELECT * FROM _learning_festival")
-- MAGIC df_daily_mau = spark.sql("SELECT * FROM main.field_learning_enablement.fact_daily_mau")
-- MAGIC
-- MAGIC analysis_df = get_session_metrics(df, df_daily_mau, "wau_human", [1, 7], 'days')
-- MAGIC display(analysis_df)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 3.4 Get all UE programs. Reference from [User Enablement Program Summary Dashboard](https://adb-2548836972759138.18.azuredatabricks.net/dashboardsv3/01eeb55263f11568bc7ad85275e872d3/published?o=2548836972759138)

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW _ue_programs
AS
with nnl as(
    select learner_user_id, course_code, completed_date
    from main.field_learning_enablement.all_learners
    where processDate = (select max(processDate) from main.field_learning_enablement.all_learners)
    and dataset = 'net new learners'
)
-- Onboarding & HDC ILT
select 
  updated_account_id,
  updated_account_name,

learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') as sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') as sales_subregion_level_2
from main.team_field_user_enablement.vw_ue_enrolments_ilt
where session_date >= '2024-02-01'
and training_type = 'Public'
and course_type IN ('Half-Day', 'Onboarding')
union

-- self-paced onboarding
select 
  account_id,
  account_name,

learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, 'Self-Paced' as course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.team_field_user_enablement.vw_ue_enrolments_sp
where completed_date >= '2024-02-01'
union

--private workshops
select 
  updated_account_id,
  updated_account_name,

learner_user_id, course_code, course_name, enrolled_date, completed_date, attended_flag, completed_fq2, learner_date, 'Workshop' as course_type, sales_region, IFNULL(sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.team_field_user_enablement.vw_ue_enrolments_ilt
where session_date>= '2024-02-01'
and training_type = 'Private'
and provider = 'User Enablement'
union

-- summit
select 
  updated_account_id,
  updated_account_name,

ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'DAIS' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.course_name like '%DAIS 2024%'
and ae.completed_date >= '2024-02-01'
union


-- World Tour
select 
  updated_account_id,
  updated_account_name,

ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'DAIWT' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.course_name like '%DAIWT 2024%'
and ae.completed_date >= '2024-02-01'
union

-- Learning Festival Q1 - Q3
select 
  updated_account_id,
  updated_account_name,

ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'Learning Festival' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.learner_branch_code not in( 'DBK_EMP') -- Exclude internal employee enrollments
and ae.course_id in (
    1266, -- DEWD
    2268, -- ADEWD
    2307, -- DAWD
    2906, -- DAWD 2024
    2417, -- MLWD
    1522, -- MLIP
    2267, -- GAIEWD 2023
    2726 -- GAIEWD 2024
)
and 
(
    ae.completed_timestamp between '2024-02-29T00:00:00UTC+14' and '2024-03-14T00:00:00UTC-12' -- Q1 FY25
    or 
    ae.completed_timestamp between '2024-07-10T00:00:00UTC+14' and '2024-07-25T00:00:00UTC-12' -- Q2 FY25
    or
    ae.completed_timestamp between '2024-10-10T00:00:00UTC+14' and '2024-11-01T00:00:00UTC-12' -- Q3 FY25
)
union
-- Databricks Academy Labs
 
select 
  updated_account_id,
  updated_account_name,

ae.learner_user_id, ae.course_code, ae.course_name, ae.enrolled_date, ae.completed_date, ae.attended_flag, ae.completed_fq2, nnl.completed_date as learner_date, 'Academy Labs' as course_type, ae.business_unit, IFNULL(ae.sales_subregion_level_1,'Unknown') sales_subregion_level_1, IFNULL(ae.sales_subregion_level_2,'Unknown') sales_subregion_level_2
from main.field_learning_enablement.all_enrollments ae
left join nnl
on ae.learner_user_id = nnl.learner_user_id and ae.course_code = nnl.course_code
where ae.processDate = (select max(processDate) from  main.field_learning_enablement.all_enrollments)
and ae.completed_date >= '2024-02-01'
and ae.course_code IN (
    select distinct course_code from main.it_training_silver.docebo_subscription_enrollments
    where processDate = (select max(processDate) from main.it_training_silver.docebo_subscription_enrollments)
    and subscription_plan_code = 'DB-ACAD-LABS-SUB-PLAN'
);


SELECT
  course_type,
  updated_account_id AS account_id,
  updated_account_name AS account_name,
  MAX(completed_date) AS max_completed_date
FROM 
  _ue_programs 
WHERE 
  completed_date IS NOT NULL AND completed_date BETWEEN '2025-02-01' AND '2025-03-31'
  AND updated_account_id IN (SELECT DISTINCT account_id FROM wau_growth_temp_view)
GROUP BY 1, 2, 3, MONTH(completed_date);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 3.5 Get UE programs impact.

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from pyspark.sql import functions as f
-- MAGIC
-- MAGIC def get_session_metrics(df, df_daily_mau, metric_column, period, timeframe):
-- MAGIC     if timeframe == 'wk':
-- MAGIC       period = [(number * 7, number) for number in period]
-- MAGIC     elif timeframe == 'days':
-- MAGIC        period = [(number, number) for number in period]
-- MAGIC     else: 
-- MAGIC       return "No valid timeframe. (wk or days)"    
-- MAGIC
-- MAGIC     # Get the metric aggregated by account on each day
-- MAGIC     df_daily_data = df_daily_mau.groupBy("date", "customer_id").agg(f.sum(metric_column).alias(metric_column))
-- MAGIC     df_final = df.select("course_type", "account_id", "account_name", "max_completed_date").dropDuplicates()
-- MAGIC
-- MAGIC     # Get the baseline metric        
-- MAGIC     df_final = df_final.join(df_daily_data, (df_final.account_id == df_daily_data.customer_id) & 
-- MAGIC                              (f.date_sub(df_final.max_completed_date, 90) <= df_daily_data.date) & (df_final.max_completed_date > df_daily_data.date), "left").drop("customer_id")
-- MAGIC                              
-- MAGIC     df_final = df_final.groupBy("course_type", "account_id", "account_name", "max_completed_date").agg(f.avg(metric_column).alias(f"90_days_avg_prev_{metric_column}") )
-- MAGIC
-- MAGIC     # # Get the current date metric value
-- MAGIC     df_final = df_final.join(df_daily_data, (df.account_id == df_daily_data.customer_id) & (df.max_completed_date == df_daily_data.date)).withColumn(
-- MAGIC           f"0_{timeframe}_{metric_column}", f.col(metric_column)).drop("customer_id", "date", metric_column)  
-- MAGIC     
-- MAGIC     # # Get the post session dates metric values
-- MAGIC     period = sorted(period)
-- MAGIC     for offset, number in period:    
-- MAGIC         df_final = df_final.join(df_daily_data, (df_final.account_id == df_daily_data.customer_id) & (f.date_add(df_final.max_completed_date, offset) == df_daily_data.date), "left").withColumn(
-- MAGIC           f"{number}_{timeframe}_post_{metric_column}", f.col(metric_column)).drop("customer_id", "date", metric_column).withColumn(
-- MAGIC           f"{metric_column}_{number}_{timeframe}_growth",  f.col(f"{number}_{timeframe}_post_{metric_column}") - f.col(f"90_days_avg_prev_{metric_column}"))
-- MAGIC             
-- MAGIC     return df_final
-- MAGIC
-- MAGIC df = spark.sql("SELECT * FROM _sqldf")
-- MAGIC df_daily_mau = spark.sql("SELECT * FROM main.field_learning_enablement.fact_daily_mau")
-- MAGIC
-- MAGIC analysis_df = get_session_metrics(df, df_daily_mau, "wau_human", [1, 7], 'days')
-- MAGIC display(analysis_df)