-- Databricks notebook source
-- MAGIC %md
-- MAGIC **Query on how to pull SA and AE**: 
-- MAGIC
-- MAGIC **Description**
-- MAGIC
-- MAGIC Request received from Suna
-- MAGIC
-- MAGIC Hi,  did you have a query from before on how to pull SA/AE ? Have the following customers to reach out to but the list can get bigger later.
-- MAGIC + Comcast
-- MAGIC + Aplace For Mom
-- MAGIC + CoStar Group
-- MAGIC + DigiCert
-- MAGIC + Discovery
-- MAGIC + Adobe

-- COMMAND ----------

SELECT
  T1.account_id
  , T1.account_name
  , T1.account_executive  
  , T1.last_solution_architect_engaged    
FROM 
  main.gtm_data.core_accounts_curated T1
WHERE 
  T1.account_name LIKE SOME ('Comcast', 'A Place for Mom', 'CoStar Group', 'DigiCert', 'Discovery', 'Adobe%')
  AND T1.account_status <> 'Prospect'

-- COMMAND ----------

SELECT DISTINCT
  T1.account_executive
  , T1.sales_manager
  , T2.AE
  , T2.AE_Manager
  , T2.accountId
  , T2.SA
FROM 
  main.gtm_data.core_accounts_curated T1
LEFT JOIN 
  main.field_usage_dashboard.global_data T2
ON
  T1.account_id = T2.accountId
WHERE 
  T1.account_name = 'Comcast'