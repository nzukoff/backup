# Databricks notebook source
# MAGIC %md
# MAGIC **AIBI -Difference in Difference Measurement**: 
# MAGIC
# MAGIC **Description**
# MAGIC
# MAGIC Request received from Suna. Reference file [AIBI -Difference in Difference Measurement](https://docs.google.com/spreadsheets/d/1kKxovj-PMylkyXKy7HqpJ9fQWMVKQ-WItDHpwA5kKEw/edit?usp=sharing)
# MAGIC
# MAGIC
# MAGIC For the AIBI Campaign we want to do a difference in difference analysis. 
# MAGIC
# MAGIC Can we get a dump of the data at the session code & account granularity for
# MAGIC - 12_wk_pre_MAU
# MAGIC - 9_wk_pre_MAU
# MAGIC - 6_wk_pre_MAU
# MAGIC - 3_wk_pre_MAU
# MAGIC - 0_wk_MAU
# MAGIC - 3_wk_post_MAU
# MAGIC - 6_wk_post_MAU
# MAGIC - 9_wk_post_MAU
# MAGIC - 12_wk_post_MAU
# MAGIC
# MAGIC **Prev session difference:** 0_wk_MAU - 12_wk_pre_MAU
# MAGIC
# MAGIC **Post session difference:** 12_wk_post_MAU - 0_wk_MAU
# MAGIC
# MAGIC **Difference in difference**: [Post session difference] - [Post session difference]

# COMMAND ----------

# MAGIC %md
# MAGIC #### 1. Merge the event and customer data

# COMMAND ----------

# MAGIC %sql
# MAGIC -- =============================================
# MAGIC -- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
# MAGIC -- Create date: 2025-01-09
# MAGIC -- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
# MAGIC -- =============================================
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
# MAGIC   SELECT    
# MAGIC     T1.session_code
# MAGIC     , T1.session_name
# MAGIC     , T1.account_id
# MAGIC     , T1.account_name
# MAGIC     , T1.session_date
# MAGIC   FROM(
# MAGIC     SELECT 
# MAGIC       T1.session_code,
# MAGIC       TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name,
# MAGIC       CAST(T1.ended_timestamp AS DATE) AS session_date,
# MAGIC       T1.updated_account_id AS account_id,
# MAGIC       T1.updated_account_name AS account_name      
# MAGIC     FROM 
# MAGIC         main.field_learning_enablement.all_enrollments AS T1
# MAGIC     INNER JOIN
# MAGIC       main.field_learning_enablement.training_operations_ilt_schedule_master AS T2
# MAGIC     ON 
# MAGIC       T1.session_code = T2.academy_session_number
# MAGIC     WHERE 
# MAGIC       T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)    
# MAGIC       AND T2.processDate = (SELECT max(processDate) FROM main.field_learning_enablement.training_operations_ilt_schedule_master)
# MAGIC       AND (T2.project_type = 'AI/BI Training Program' AND T2.status not ilike 'cancel%')      
# MAGIC   ) AS T1
# MAGIC   GROUP BY ALL;
# MAGIC
# MAGIC
# MAGIC SELECT * FROM _account_sessions
# MAGIC ORDER BY 1, 4;

# COMMAND ----------

# MAGIC %md
# MAGIC #### 2. Get the measure values previos and before the session date

# COMMAND ----------

from pyspark.sql import functions as f

def get_session_metrics(df, df_daily_mau, metric_column, period, timeframe):
    if timeframe == 'wk':
      period = [(number * 7, number) for number in period]
    elif timeframe == 'days':
       period = [(number, number) for number in period]
    else: 
      return "No valid timeframe. (wk or days)"

    # Get the metric aggregated by account on each day
    df_daily_data = df_daily_mau.groupBy("date", "customer_id").agg(f.sum(metric_column).alias(metric_column))
    df_final = df.select("session_code", "account_id", "account_name", "session_date").dropDuplicates()

    # Get the previous session dates metric values
    period = sorted(period, reverse=True)
    for offset, number in period:
        df_final = df_final.join(df_daily_data, (df_final.account_id == df_daily_data.customer_id) & (f.date_sub(df_final.session_date, offset) == df_daily_data.date), "left").withColumn(
          f"{number}_{timeframe}_prev_{metric_column}", f.col(metric_column)).drop("customer_id", "date", "mau")      

    # Get the current date metric value
    df_final = df_final.join(df_daily_data, (df.account_id == df_daily_data.customer_id) & (df.session_date == df_daily_data.date)).withColumn(
          f"0_{timeframe}_{metric_column}", f.col(metric_column)).drop("customer_id", "date", "mau")  
    
    # Get the post session dates metric values
    period = sorted(period)
    for offset, number in period:    
        df_final = df_final.join(df_daily_data, (df_final.account_id == df_daily_data.customer_id) & (f.date_add(df_final.session_date, offset) == df_daily_data.date), "left").withColumn(
          f"{number}_{timeframe}_post_{metric_column}", f.col(metric_column)).drop("customer_id", "date", "mau")  
        
    # Get metric difference
    df_final = df_final.withColumn(
      f"prev_session_difference_{metric_column}", f.col(f"0_{timeframe}_{metric_column}") -  f.col(f"{period[-1][1]}_{timeframe}_prev_{metric_column}")
    ).withColumn(
      f"post_session_difference_{metric_column}", f.col(f"{period[-1][1]}_{timeframe}_post_{metric_column}") - f.col(f"0_{timeframe}_{metric_column}")
    ).withColumn(
      f"difference_in_difference_{metric_column}", f.col(f"post_session_difference_{metric_column}") - f.col(f"prev_session_difference_{metric_column}")
    )    
        
    return df_final

df = spark.sql("SELECT * FROM _account_sessions")
df_daily_mau = spark.sql("SELECT * FROM main.field_learning_enablement.fact_daily_mau")

analysis_df = get_session_metrics(df, df_daily_mau, "mau", [12, 9, 3, 6], 'wk')
display(analysis_df)

# COMMAND ----------

# sesionality
# sessions with less 10 attendees, 
# how well the session was attended, 
# how big the account is
# Instead of looking MAU, lets look the product lift
# This event impact ont he short temp against the long term
# Three weeks is big for the impact, instead of looking on

# each column will be weeks, referring to the WAU at product line. Human WAU
# Adding product lines
# Add attendance to column Some of the sessions have low attendance. Removing the 
# Adding employee number for that account

# For enterprise it has better results than emerging, account information

# COMMAND ----------

# MAGIC %md
# MAGIC #### 3. Next steps
# MAGIC - Break down columns into weeks MAU.
# MAGIC
# MAGIC - WAU/hWAU/Lakeview WAU/DBSQL WAU
# MAGIC
# MAGIC - Add attendance as a column
# MAGIC
# MAGIC - Account information: BU, TAM, Current penetration

# COMMAND ----------

# MAGIC %md
# MAGIC ##### [RUN FIRST] 3.1. Adding attendees column

# COMMAND ----------

# MAGIC %sql
# MAGIC -- =============================================
# MAGIC -- Title:      Account sessions for Data Analytics and Warehousing with Databricks  
# MAGIC -- Create date: 2025-01-09
# MAGIC -- Description: This query is returning the accounts with their respective session_code. This information was pulled from air_table.
# MAGIC -- =============================================
# MAGIC CREATE OR REPLACE TEMPORARY VIEW _account_sessions AS
# MAGIC   SELECT    
# MAGIC     T1.session_code
# MAGIC     , T1.session_name
# MAGIC     , T1.account_id
# MAGIC     , T1.account_name
# MAGIC     , T1.session_date
# MAGIC     , a.business_unit AS bu
# MAGIC     , a.account_segment AS tam
# MAGIC     , a.arr_tshirt_size AS current_penetration
# MAGIC     , SUM(CASE WHEN T1.enrolled_date IS NOT NULL THEN 1 END) AS event_registrations
# MAGIC     , SUM(CASE WHEN T1.completed_date IS NOT NULL THEN 1 END) AS event_attendees
# MAGIC   FROM(
# MAGIC     SELECT 
# MAGIC       T1.session_code,
# MAGIC       TRIM(SPLIT_PART(T1.session_name, '|', 3)) AS session_name,
# MAGIC       CAST(T1.ended_timestamp AS DATE) AS session_date,
# MAGIC       T1.updated_account_id AS account_id,
# MAGIC       T1.updated_account_name AS account_name,
# MAGIC       T1.enrolled_date,
# MAGIC       T1.completed_date
# MAGIC     FROM 
# MAGIC         main.field_learning_enablement.all_enrollments AS T1
# MAGIC     INNER JOIN
# MAGIC       main.field_learning_enablement.training_operations_ilt_schedule_master AS T2
# MAGIC     ON 
# MAGIC       T1.session_code = T2.academy_session_number
# MAGIC     WHERE 
# MAGIC       T1.processDate = (SELECT MAX(T1.processDate) FROM main.field_learning_enablement.all_enrollments T1)    
# MAGIC       AND T2.processDate = (SELECT max(processDate) FROM main.field_learning_enablement.training_operations_ilt_schedule_master)
# MAGIC       AND (T2.project_type = 'AI/BI Training Program' AND T2.status not ilike 'cancel%')      
# MAGIC   ) AS T1
# MAGIC   LEFT JOIN  
# MAGIC     main.gtm_data.core_accounts_curated AS a USING (account_id)
# MAGIC   GROUP BY ALL;
# MAGIC
# MAGIC
# MAGIC SELECT * FROM _account_sessions
# MAGIC ORDER BY 1, 4;

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3.2. Adding BU, TAM and Current Penetration

# COMMAND ----------

df_daily_mau = spark.sql("""
  SELECT
    T1.* 
  FROM 
    main.field_learning_enablement.fact_daily_mau AS T1
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3.3. Adding new fields to the function

# COMMAND ----------

from pyspark.sql import functions as f

def get_session_metrics(df, df_daily_mau, metric_column, period, timeframe):
    if timeframe == 'wk':
      period = [(number * 7, number) for number in period]
    elif timeframe == 'days':
       period = [(number, number) for number in period]
    else: 
      return "No valid timeframe. (wk or days)"

    # Get the metric aggregated by account on each day
    df_daily_data = df_daily_mau.groupBy("date", "customer_id").agg(f.sum(metric_column).alias(metric_column))
    df_final = df

    # Get the previous session dates metric values
    period = sorted(period, reverse=True)
    for offset, number in period:
        df_final = df_final.join(df_daily_data, (df_final.account_id == df_daily_data.customer_id) & (f.date_sub(df_final.session_date, offset) == df_daily_data.date), "left").withColumn(
          f"{number}_{timeframe}_prev_{metric_column}", f.col(metric_column)).drop("customer_id", "date", metric_column)

    # Get the current date metric value
    df_final = df_final.join(df_daily_data, (df.account_id == df_daily_data.customer_id) & (df.session_date == df_daily_data.date)).withColumn(
          f"0_{timeframe}_{metric_column}", f.col(metric_column)).drop("customer_id", "date", metric_column)  
    
    # Get the post session dates metric values
    period = sorted(period)
    for offset, number in period:    
        df_final = df_final.join(df_daily_data, (df_final.account_id == df_daily_data.customer_id) & (f.date_add(df_final.session_date, offset) == df_daily_data.date), "left").withColumn(
          f"{number}_{timeframe}_post_{metric_column}", f.col(metric_column)).drop("customer_id", "date", metric_column)  
        
    # Get metric difference
    for offset, number in period: 
      df_final = df_final.withColumn(
        f"prev_session_difference_{metric_column}", f.col(f"0_{timeframe}_{metric_column}") -  f.col(f"{period[-1][1]}_{timeframe}_prev_{metric_column}")
      ).withColumn(
        f"post_session_difference_{metric_column}", f.col(f"{period[-1][1]}_{timeframe}_post_{metric_column}") - f.col(f"0_{timeframe}_{metric_column}")
      ).withColumn(
        f"difference_in_difference_{metric_column}", f.col(f"post_session_difference_{metric_column}") - f.col(f"prev_session_difference_{metric_column}")
      )    
        
    return df_final

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 3.4. Break down columns into weeks MAU and WAU/hWAU/Lakeview WAU/DBSQL WAU

# COMMAND ----------

# mau/wau
# hWAU = wau_human
# Lakeview WAU = lakeview_wau
# DBSQL WAU = dbsql_wau


df = spark.sql("""
  SELECT 
    * 
  FROM 
    _account_sessions 
  WHERE 
    session_date <= '2025-03-01' AND session_code <> '26769' AND account_id NOT IN(
      '0016100000gLdzsAAC',
      '0016100000ZcnkGAAR'
    )
""")

analysis_df = get_session_metrics(df, df_daily_mau, "wau_human", [4, 3, 2, 1, 5, 6], 'wk')
display(analysis_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### 4. Alternative exploration to measure the impact by weekly average
# MAGIC
# MAGIC To measure the impact of session attendance on platform usage (WAU) at the account-session level, using pre/post comparisons around each session date.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 4.1. Adding partner flag to the account sessions data

# COMMAND ----------

df_sessions = spark.sql("""
  WITH _partner_list
  AS (
    SELECT DISTINCT ultimate_parent_account_id FROM main.field_learning_enablement.partner_domains_accounts
    WHERE processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.partner_domains_accounts)    
  )                       
  SELECT 
    T1.*,
    IFF(T2.ultimate_parent_account_id IS NOT NULL, 'Yes', 'No') AS is_partner
  FROM 
    _account_sessions T1
  LEFT JOIN
    _partner_list as T2
  ON 
    T1.account_id = T2.ultimate_parent_account_id  
  WHERE 
    session_date <= '2025-03-01' --AND session_code <> '26769'    
    AND account_id NOT IN(
      '0016100000gLdzsAAC', -- Accenture (HQ)
      '0016100000ZcnkGAAR'  -- Databricks
    )    
""") 

df_sessions.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 4.2. Get the main dataset

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

# Configurable parameters
pre_weeks = 6
post_weeks = 6
metric_column = 'wau_human'
holiday_start = datetime(2024, 11, 28)
holiday_end = datetime(2025, 1, 5)

# Prepare datasets
df_wau = spark.table("main.field_learning_enablement.fact_daily_mau")
df_wau = df_wau.groupBy("date", "customer_id").agg(F.sum(metric_column).alias(metric_column))

# -- Step 1: Create week offsets
week_offsets = list(range(-pre_weeks, post_weeks + 1))
week_rows = [(offset,) for offset in week_offsets]
df_week_offsets = spark.createDataFrame(week_rows, ["week_offset"])

# -- Step 2: Cross join sessions with week offsets
df_expanded = df_sessions.crossJoin(df_week_offsets)

# Calculate weekly date ranges
df_expanded = (
    df_expanded
    .withColumn("week_start", F.expr("date_add(session_date, 7 * (int(week_offset) - 1) + 1)"))
    .withColumn("week_end", F.expr("date_add(session_date, 7 * int(week_offset))"))
    .withColumn("week_label", 
        F.when(F.col("week_offset") == 0, f"0_wk_{metric_column}")
        .otherwise(
            F.concat(
                F.abs(F.col("week_offset")).cast("string"),
                F.when(F.col("week_offset") > 0, f"_wk_post_{metric_column}")
                .otherwise(f"_wk_prev_{metric_column}")
            )
        )
    )
)

# -- Step 3: Join with WAU data and aggregate by week
df_wau_filtered = df_wau.select("customer_id", "date", metric_column)

df_joined = df_expanded.join(
    df_wau_filtered,
    (df_wau_filtered.customer_id == df_expanded.account_id) &
    (df_wau_filtered.date >= df_expanded.week_start) &
    (df_wau_filtered.date <= df_expanded.week_end),
    how="left"
)

df_result = df_joined.groupBy("account_id", "account_name", "is_partner", "session_date", "session_code", "event_registrations", "event_attendees", "bu", "tam", "current_penetration","week_label", "week_offset").agg(
    F.coalesce(F.mean(metric_column), F.lit(0)).alias(f"{metric_column}_mean")
)#.filter(F.col(f"{metric_column}_mean") > 0)

# -- Step 4: Pivot week labels into columns
# Define the custom order for week labels
custom_order = (
    [f"{i}_wk_prev_{metric_column}" for i in range(pre_weeks, 0, -1)] +
    [f"0_wk_{metric_column}"] +
    [f"{i}_wk_post_{metric_column}" for i in range(1, post_weeks + 1)]
)

# Perform the pivot with custom sorting
df_result = (
    df_result
    .groupBy("account_id", "account_name", "is_partner", "session_date", "session_code", "event_registrations", "event_attendees", "bu", "tam", "current_penetration")
    .pivot("week_label", custom_order)
    .agg(F.sum(f"{metric_column}_mean"))
).na.fill(0)


# # -- Step 5: Calculate pre/post averages and absolute change
# # pre_cols = [f"{i}_wk_prev_{metric_column}" for i in range(1, pre_weeks + 1)]
# # post_cols = [f"{i}_wk_post_{metric_column}" for i in range(1, post_weeks + 1)]

# # df_result = df_result \
# #     .withColumn("pre_period_avg", sum(F.col(c) for c in pre_cols) / pre_weeks) \
# #     .withColumn("post_period_avg", sum(F.col(c) for c in post_cols) / post_weeks) \
# #     .withColumn("absolute_change", F.col("post_period_avg") - F.col("pre_period_avg"))


# -- Step 6: Add caution flag for holiday overlap
holiday_dates_expr = f"array({','.join([f'date_add(session_date, {7 * i})' for i in range(1, post_weeks + 1)])})"

df_result = df_result \
    .withColumn("caution_dates", F.expr(holiday_dates_expr)) \
    .withColumn("holiday_overlap", F.expr(f"filter(caution_dates, x -> x >= date('{holiday_start}') AND x <= date('{holiday_end}'))")) \
    .withColumn("caution_due_to_holiday", F.size("holiday_overlap") > 0) \
    .drop("holiday_overlap", "caution_dates")

# -- Step 7: Adding flag
# Sum across all WAU columns
df_result = df_result.withColumn(
    "total_usage_across_weeks",
    sum(F.col(c).cast("double") for c in custom_order)
)

# Flag if all usage is 0 or null
df_result = df_result.withColumn(
    "no_usage_in_all_weeks",
    F.col("total_usage_across_weeks") == 0
).drop("total_usage_across_weeks")

# -- Step 8: Adding difference of difference
# Add difference_in_difference_wau for each week
# i = 1
for i in range(1, post_weeks + 1):
    df_result = df_result.withColumn(        
        f"wk{i}_prev_growth_{metric_column}",
        F.col(f"0_wk_{metric_column}") - F.col(f"{i}_wk_prev_{metric_column}")
    ).withColumn(        
        f"wk{i}_post_growth_{metric_column}",
        F.col(f"{i}_wk_post_{metric_column}") - F.col(f"0_wk_{metric_column}")
    ).withColumn(
        f"wk{i}_difference_in_difference_{metric_column}",
        F.col(f"wk{i}_post_growth_{metric_column}") - F.col(f"wk{i}_prev_growth_{metric_column}")
    )

# Step 9: Calculate IQR for wk1 difference-in-difference
# Filtering the records equals to zero from the threshold calculation
summary_stats = df_result.filter(F.col(f"wk1_difference_in_difference_{metric_column}") != 0).select(f"wk1_difference_in_difference_{metric_column}").summary("25%", "75%").toPandas()
Q1 = float(summary_stats.loc[summary_stats["summary"] == "25%", f"wk1_difference_in_difference_{metric_column}"].values[0])
Q3 = float(summary_stats.loc[summary_stats["summary"] == "75%", f"wk1_difference_in_difference_{metric_column}"].values[0])
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

# Broadcast thresholds to Spark
thresholds = spark.createDataFrame(
    [(lower_bound, upper_bound)], ["lower_bound", "upper_bound"]
)

df_result = df_result.crossJoin(thresholds)

# Step 8: Add outlier flag
df_result = df_result.withColumn(
    "wk1_outlier_flag",
    F.when(F.col(f"wk1_difference_in_difference_{metric_column}") < F.col("lower_bound"), F.lit("drop"))
     .when(F.col(f"wk1_difference_in_difference_{metric_column}") > F.col("upper_bound"), F.lit("high_impact"))
     .otherwise(F.lit("normal"))
)

display(df_result)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT date, customer_id, account_name, sum(wau) as wau FROM main.field_learning_enablement.fact_daily_mau WHERE customer_id='0014N000020ofDiQAI' group by all;

# COMMAND ----------

display(df_joined.filter(F.col("account_id") == '0014N000020ofDiQAI'))

# COMMAND ----------

# Import necessary libraries
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import DoubleType
import pandas as pd
from scipy import stats

df_result = df_result.filter(F.col("event_attendees") > 0)

# -- Parameters --
metric_column = 'wau_human'
include_zeros = True  # Set to False to exclude 0 values
max_weeks = 6  # Change this to analyze more weeks

# Extract the difference-in-difference columns
wk_diff_cols = [f"wk{i}_difference_in_difference_{metric_column}" for i in range(1, post_weeks + 1)]

# Select relevant columns and convert to Pandas
df_diff = df_result.select(*wk_diff_cols)
pdf = df_diff.toPandas()

# Function to categorize p-value
def categorize_p_value(p):
    if p < 0.001:
        return "Very strong evidence"
    elif p < 0.01:
        return "Strong evidence"
    elif p < 0.05:
        return "Moderate evidence"
    elif p < 0.1:
        return "Weak evidence"
    else:
        return "No evidence"

# Perform t-test for each week
results = []
for col in wk_diff_cols:
    values = pdf[col].dropna()

    # One-sample t-test against mean = 0
    t_stat, p_val = stats.ttest_1samp(values, popmean=0)

    results.append({
        "week": col,
        "n_obs": len(values),
        "mean_difference_in_difference": values.mean(),
        "std_dev": values.std(ddof=1),
        "t_score": t_stat,
        "p_value": p_val,
        "evidence_strength": categorize_p_value(p_val)
    })

# Convert to Spark DataFrame to display in Databricks
display(spark.createDataFrame(pd.DataFrame(results)))