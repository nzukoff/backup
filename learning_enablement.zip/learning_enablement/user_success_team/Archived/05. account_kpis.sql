-- Databricks notebook source
-- MAGIC %md
-- MAGIC | **Field**      | **Description** |
-- MAGIC | ----------- | ----------- |
-- MAGIC | **Name**      | 05. account_kpis |
-- MAGIC | **Team**      | User Success       |
-- MAGIC | **Organisation**   | Learning & Enablement        |
-- MAGIC | **Owner**   | abraham.fuertes@databricks.com        |
-- MAGIC | **Purpose**   | This notebook is used to explore the data on the source tables for generating the metrics needed |
-- MAGIC | **Source(s)**  | sfdc_bronze.pse__proj__c |
-- MAGIC | **Target:**    |  |           

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####Env Setup
-- MAGIC
-- MAGIC * Set Spark configuration
-- MAGIC * Clean up all residual widgets
-- MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
-- MAGIC * Add in any additional environment setup pieces that you need for your notebook
-- MAGIC * Set up parameters

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard libraries
-- MAGIC import sys
-- MAGIC from datetime import datetime, timedelta
-- MAGIC import logging
-- MAGIC import warnings
-- MAGIC from pprint import pprint
-- MAGIC # from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
-- MAGIC import json
-- MAGIC import requests
-- MAGIC from urllib.parse import quote_plus as urlencode
-- MAGIC import pandas as pd
-- MAGIC
-- MAGIC warnings.filterwarnings("ignore")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard widgets - do not change
-- MAGIC dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
-- MAGIC dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
-- MAGIC dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
-- MAGIC dbutils.widgets.text("partition_column", "processDate")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #pass parameter values to variables
-- MAGIC try:
-- MAGIC     focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
-- MAGIC     focus_database_name = dbutils.widgets.get("focus_database_name")
-- MAGIC     partition_date = dbutils.widgets.get("partition_date")
-- MAGIC     partition_column = dbutils.widgets.get("partition_column")
-- MAGIC except:
-- MAGIC     print("Please check the parameters passed are valid")
-- MAGIC     raise Exception

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1 - Main process

-- COMMAND ----------

-- =============================================
-- Title: Active learning subscriptions
-- Create date: 2024-10-30
-- Description: Getting the active learning subscriptions linked to accounts
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW active_learning_subs
AS
WITH _active_learning_subs
AS (
  SELECT
    o.AccountId as account_id,
    o.PRM_Account_Name__c as account_name,
    o.Id as Opportunity_Id,
    o.Name as Opportunity_Name,
    p.Id as subscription_id,
    p.pse__Stage__c,
    p.Service_Tier__c as Service_Tier,
    p.Total_Seats_in_ILT_Subscription__c as Total_Training_Subscription_Units,
    p.Subscription_Delivered_Seats__c as Delivered_Training_Subscription_Units,
    p.Subscription_Scheduled_Seats__c as Scheduled_Training_Subscription_Units,
    p.Subscription_Unscheduled_Seats__c as Unscheduled_Training_Subscription_Units,    
    p.pse__Start_Date__c as Start_Date,
    p.pse__End_Date__c as End_Date    
  FROM 
    main.sfdc_bronze.pse__proj__c p 
  LEFT JOIN
    main.sfdc_bronze.opportunity o
  ON
    p.pse__Opportunity__c = o.Id
  LEFT JOIN
    main.sfdc_bronze.`user` u 
  ON
    p.OwnerId = u.Id
  WHERE 
    p.processDate = (select max(processDate) from main.sfdc_bronze.pse__proj__c)
    AND o.processDate = (select max(processDate) from main.sfdc_bronze.opportunity)
    AND u.processDate = (select max(processDate) from main.sfdc_bronze.`user`)
    AND p.Subscription_Unscheduled_Seats__c >= 0.5
    AND p.Service_Tier__c like 'Learning Subscription%'
    AND p.pse__Stage__c not in ('Cancelled', 'Completed')    
)
SELECT 
  T1.account_id,
  T1.account_name,
  COUNT(T1.subscription_id) AS active_learning_subscription,
  SUM(T1.Unscheduled_Training_Subscription_Units) AS unscheduled_training_subscription_units  
FROM 
  _active_learning_subs T1
GROUP BY ALL

-- COMMAND ----------

-- =============================================
-- Title: Success credits
-- Create date: 2024-10-30
-- Description: 
-- =============================================
CREATE OR REPLACE TEMPORARY VIEW sucess_credits
AS
WITH _success_credits
AS (
  SELECT
    T2.account_id,
    SUM(T2.total_success_credits_quanitty) AS total_success_credits_quantity,
    SUM(T2.used_success_credits_quantity) AS used_success_credits_quantity,
    SUM(T2.unallocated_success_credits_quantity) AS unallocated_success_credits_quantity
  FROM
    main.gtm_data.core_success_credits AS T2
  WHERE
    T2.snapshot_date = (SELECT MAX(snapshot_date) FROM main.gtm_data.core_success_credits)    
  GROUP BY ALL
)

SELECT
  T1.account_id,
  T1.account_name,
  T2.total_success_credits_quantity,
  T2.used_success_credits_quantity,
  T2.unallocated_success_credits_quantity
FROM
  main.field_learning_enablement.cea_account_kpis AS T1
INNER JOIN
  _success_credits AS T2
ON
  T1.account_id = T2.account_id
WHERE
  T1.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.cea_account_kpis)    
  AND T1.account_name = 'T-Mobile'

-- COMMAND ----------

-- =============================================
-- Title: account_kpis
-- Create date: 2024-10-30
-- Description: This table was created using as reference main.field_learning_enablement.cea_account_kpis
-- Not all the kpis needed are on this table so we are merging data from another tables
-- =============================================
SELECT
  nvl(T1.account_name, T2.account_name) AS account_name,
  nvl(T1.account_id, T2.account_id) AS account_id,  
  nvl(T1.total_success_credits_quantity, 0) AS total_success_credits_quantity,
  nvl(T1.used_success_credits_quantity, 0) AS used_success_credits_quantity,
  nvl(T1.unallocated_success_credits_quantity, 0) AS unallocated_success_credits_quantity,
  nvl(T2.active_learning_subscription, 0) AS active_learning_subscription,
  nvl(T2.unscheduled_training_subscription_units, 0) AS unscheduled_training_subscription_units
FROM
  sucess_credits T1
FULL JOIN
  active_learning_subs T2
ON 
  T1.account_id = T2.account_id

-- COMMAND ----------

-- select
--     a.snapshot_date,
--     a.project_id,
--     a.account_id,     
--     a.project_remaining_success_credits_quantity as unallocated_success_credits_quantity
--   from
--     main.gtm_data.core_professional_Services_dim_project a  
--   where
--     a.snapshot_date = (select max(snapshot_date) from main.gtm_data.core_professional_Services_dim_project)    
--     and a.project_service_tier = 'Master'
--     and nvl(a.project_stage,'Unknown') not in ('Completed','Cancelled')
--     and a.project_remaining_success_credits_quantity > 0 --and account_id='00161000005gCW8AAM'
--     and a.opportunity_stage='Closed Won'
--     and a.account_id = '0016100001F0UgBAAV'

-- COMMAND ----------

  -- SELECT
  --   T2.account_id,    
  --   T2.project_id,
  --   T2.total_success_credits_quanitty,
  --   T2.used_success_credits_quantity,
  --   T2.unallocated_success_credits_quantity
  -- FROM
  --   main.gtm_data.core_success_credits AS T2
  -- WHERE
  --   T2.snapshot_date = (SELECT MAX(snapshot_date) FROM main.gtm_data.core_success_credits)    
  --   and T2.account_id = '0016100001F0UgBAAV'  

-- COMMAND ----------

-- SELECT
--   unallocated_success_credits_quantity
-- FROM
--   main.field_learning_enablement.cea_account_kpis AS T1
-- WHERE
--   account_id = '0016100001F0UgBAAV'  
--   AND T1.processDate = (SELECT MAX(processDate) FROM main.field_learning_enablement.cea_account_kpis)