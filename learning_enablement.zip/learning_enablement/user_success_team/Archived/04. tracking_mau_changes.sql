-- Databricks notebook source
-- MAGIC %md
-- MAGIC | **Field**      | **Description** |
-- MAGIC | ----------- | ----------- |
-- MAGIC | **Name**      | 04. tracking_mau_changes |
-- MAGIC | **Team**      | User Success       |
-- MAGIC | **Organisation**   | Learning & Enablement        |
-- MAGIC | **Owner**   | abraham.fuertes@databricks.com        |
-- MAGIC | **Purpose**   | This notebook is used to explore the data on the source tables for generating the metrics needed |
-- MAGIC | **Source(s)**  |  |
-- MAGIC | **Target:**    | tracking_mau_changes |           

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####Env Setup
-- MAGIC
-- MAGIC * Set Spark configuration
-- MAGIC * Clean up all residual widgets
-- MAGIC * Import libraries that you need; we've already included a few commonly-used ones for your convenience
-- MAGIC * Add in any additional environment setup pieces that you need for your notebook
-- MAGIC * Set up parameters

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard libraries
-- MAGIC import sys
-- MAGIC from datetime import datetime, timedelta
-- MAGIC import logging
-- MAGIC import warnings
-- MAGIC from pprint import pprint
-- MAGIC # from helper_functions import unit_test_valid_date, unit_test_valid_db, unit_test_df_count
-- MAGIC import json
-- MAGIC import requests
-- MAGIC from urllib.parse import quote_plus as urlencode
-- MAGIC import pandas as pd
-- MAGIC
-- MAGIC warnings.filterwarnings("ignore")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #standard widgets - do not change
-- MAGIC dbutils.widgets.text("focus_data_utils_path", "/dbfs/csops/focus-databricks/")
-- MAGIC dbutils.widgets.text("focus_database_name", "main.field_learning_enablement")
-- MAGIC dbutils.widgets.text("partition_date", datetime.now().strftime("%Y-%m-%d"))
-- MAGIC dbutils.widgets.text("partition_column", "processDate")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #pass parameter values to variables
-- MAGIC try:
-- MAGIC     focus_data_utils_path = dbutils.widgets.get("focus_data_utils_path")
-- MAGIC     focus_database_name = dbutils.widgets.get("focus_database_name")
-- MAGIC     partition_date = dbutils.widgets.get("partition_date")
-- MAGIC     partition_column = dbutils.widgets.get("partition_column")
-- MAGIC except:
-- MAGIC     print("Please check the parameters passed are valid")
-- MAGIC     raise Exception

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1 - Main process

-- COMMAND ----------

--DESCRIBE HISTORY main.field_self_service.silver_monthly_mau;
--SELECT * FROM main.field_self_service.silver_monthly_mau T1 limit 100

CREATE OR REPLACE TEMPORARY VIEW dt_silver_monthly_mau_history
AS
SELECT MAX(version) AS max_version FROM (DESCRIBE HISTORY ${focus_database_name}.silver_monthly_mau);

-- COMMAND ----------

-- MAGIC %python
-- MAGIC latest_1ktable = spark.sql("""
-- MAGIC     select 
-- MAGIC       *
-- MAGIC     from 
-- MAGIC       dt_silver_monthly_mau_history
-- MAGIC     limit 1
-- MAGIC """).collect()[0]["max_version"]
-- MAGIC
-- MAGIC ##
-- MAGIC ## Latest version definition
-- MAGIC ##
-- MAGIC query = f"""
-- MAGIC   SELECT 
-- MAGIC     {latest_1ktable} AS version,
-- MAGIC     * 
-- MAGIC   FROM 
-- MAGIC     main.field_self_service.silver_monthly_mau 
-- MAGIC   VERSION AS OF 
-- MAGIC     {latest_1ktable}"""
-- MAGIC
-- MAGIC # Export to SQL:
-- MAGIC df = spark.sql(query)
-- MAGIC df.createOrReplaceTempView("latest_version")
-- MAGIC
-- MAGIC ##
-- MAGIC ## Previous version definition
-- MAGIC ##
-- MAGIC query = f"""
-- MAGIC   SELECT 
-- MAGIC     {latest_1ktable-1} AS version,
-- MAGIC     * 
-- MAGIC   FROM 
-- MAGIC     main.field_self_service.silver_monthly_mau 
-- MAGIC   VERSION AS OF 
-- MAGIC     {latest_1ktable-1}"""
-- MAGIC
-- MAGIC # Export to SQL:
-- MAGIC df = spark.sql(query)
-- MAGIC df.createOrReplaceTempView("previous_version")

-- COMMAND ----------

-- =============================================
-- Title:      Merge Monthly User Activity
-- Create date: 2024-10-10
-- Description: This query merges the distinct monthly user activity data from the temporary view into the silver_monthly_mau table. 
-- It inserts new records that do not already exist in the target table and deletes records from the target table that do not exist in the temporary view.
-- =============================================
CREATE OR REPLACE TABLE ${focus_database_name}.tracking_mau_changes
AS
  SELECT 
    current_date::date AS insert_date,
    COALESCE(lv.month, pv.month) AS month,
    COALESCE(lv.min_month, pv.min_month) AS min_month,
    COALESCE(lv.customer_id, pv.customer_id) AS customer_id,
    COALESCE(lv.user_id, pv.user_id) AS user_id,
    COALESCE(lv.tenure_3_months, pv.tenure_3_months) AS tenure_3_months,
    COALESCE(lv.user_status, pv.user_status) AS user_status,
    CASE 
      WHEN lv.user_id IS NULL THEN 'Deleted'
      WHEN pv.user_id IS NULL THEN 'Inserted'    
      WHEN lv.user_status <> pv.user_status THEN 'Updated'
    END AS change_type
  FROM 
    latest_version lv
  FULL OUTER JOIN 
    previous_version pv
  ON 
    lv.user_id = pv.user_id 
    AND lv.month = pv.month
  WHERE 
    lv.user_id IS NULL 
    OR pv.user_id IS NULL
    OR lv.user_status <> pv.user_status

-- COMMAND ----------

/*WITH _prev_logic
AS(
  select
    DATE_TRUNC('month', date)::date AS month,
    count(distinct IF(login_num_events > 0 OR total_dbus > 0, user_id, NULL)) as mau
  from 
    main.data_product_features.user_metrics
  where 
    is_customer
    AND DAYOFMONTH(date) <= 28
    AND salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
  GROUP BY ALL
)
, _new_logic
AS(
  SELECT 
      DATE_TRUNC('month', date)::date AS month,
      user_id,
      COUNT(DISTINCT case when login_num_events_t28d > 0 then user_id end) as mau
  FROM 
    main.data_product_features.user_metrics
  WHERE 
    user_id = '0623b5519d7ac26664933b05708ebdcc47b98b28a3e6d0e882106eea723008f4'
    --salesforce_account_id not in ('0013f0000063xxLAAQ', '0013f000005RwT9AAK')
    AND DATE_TRUNC('month', date)::date >= DATEADD(MONTH, -10, current_timestamp()::DATE)
  GROUP BY ALL
)
, mau_logic
AS (
  SELECT 
      monthly_active_users.month,  
      sum(monthly_active_users.mau) mau
  FROM
    main.field_learning_enablement.monthly_active_users 
  WHERE
    processDate = (select max(processDate) from main.field_learning_enablement.monthly_active_users )
    AND DATE_TRUNC('month', month)::date >= DATEADD(MONTH, -3, current_timestamp()::DATE)
  GROUP BY ALL
)

SELECT
* 
FROM mau_logic
*/
