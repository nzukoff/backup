import sys
import warnings
from datetime import datetime
import logging
warnings.filterwarnings("ignore")

logging.basicConfig(format='%(asctime)-15s %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class DatabricksPartitionSensor:
    """ Class for Databricks Partition Sensor for Delta tables"""

    def __init__(self,
                 database_name,
                 table_name,
                 partition_column,
                 partition,
                 *args,
                 **kwargs):
        self.database_name = database_name
        self.table_name = table_name
        self.partition_column = partition_column
        if not partition:
            self.partition = datetime.now().strftime("%Y-%m-%d")
        else:
            self.partition = partition
        self.spark = kwargs['spark']
        self.dbutils = self.__get_dbutils()

    def __get_query(self):
        query = """SELECT COUNT(*) FROM {database_name}.{table_name} WHERE {partition_column}='{partition}'""".format(
            database_name=self.database_name,
            table_name=self.table_name,
            partition_column=self.partition_column,
            partition=self.partition)
        return query

    def __get_dbutils(self):
        try:
            from pyspark.dbutils import DBUtils
            dbutils = DBUtils(self.spark)
        except ImportError:
            import IPython
            dbutils = IPython.get_ipython().user_ns["dbutils"]
        return dbutils

    def poke(self):
        print("Poking the table {0}.{1} for the partition {0}/{1}/{2}={3} ".format(self.database_name,
                                                                                   self.table_name,
                                                                                   self.partition_column,
                                                                                   self.partition))
        try:
            num_records = self.spark.sql(self.__get_query()).head()[0]
            if num_records > 0:
                print("Partition {0}/{1}/{2}={3} found with {4} records".format(self.database_name,
                                                                                self.table_name,
                                                                                self.partition_column,
                                                                                self.partition,
                                                                                num_records))
        except:
            print("Partition {0}/{1}/{2}={3} not found".format(self.database_name,
                                                               self.table_name,
                                                               self.partition_column,
                                                               self.partition))
            raise
