import sys
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, '/dbfs/csops/focus-databricks/')

from datetime import datetime
import logging

logging.basicConfig(format='%(asctime)-15s %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import window as W

def find_outliers(df, column_list):
    for column in column_list:
        Q1 = df.approxQuantile(column, [0.25], relativeError=0)
        Q3 = df.approxQuantile(column, [0.75], relativeError=0)
        IQR = Q3[0] - Q1[0]
        less_Q1 =  Q1[0] - 1.5 * IQR
        more_Q3 =  Q3[0] + 1.5 * IQR
        isOutlierCol = 'is_outlier_{}'.format(column)
        df = df.withColumn(isOutlierCol, F.when((df[column] > more_Q3) | (df[column] < less_Q1), True).otherwise(False))
    return df
