import time
from delta.tables import *
from datetime import date, datetime
import logging

logging.basicConfig(format="%(asctime)-15s %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def write_delta_table(
    spark,
    dataframe,
    table_name,
    format="delta",
    mode="overwrite",
    overwrite_schema="true",
    merge_schema="true",
    optimize=True,
    partition_column=None,
    zorder=None,
    replace_where=None,
    location=None,
):

    num_rows = dataframe.count()
    logger_statement = """Written the dataframe. Please look at the stats:
                          Details:
                          - Table Name: {0} 
                          - Total time spent: {1} minutes
                          - Write Options:
                            - format: {2}
                            - mode: {3}
                            - optimize: {4}
                            - zorder: {5}
                            - partition by: {6}
                            - replace where: {7}
                            - location: {8}
                            - Schema Options:
                                - overwrite schema: {9}
                                - merge schema: {10}
                          - Written rows:  {11}
                       """
    logger.info("Writting the table {0}".format(table_name))
    start_time = time.time()
    write_instructions = (
        dataframe.write.format(format)
        .mode(mode)
        .option("overwriteSchema", overwrite_schema)
        .option("mergeSchema", merge_schema)
    )

    if partition_column is not None:
        write_instructions = write_instructions.partitionBy(partition_column)

    if replace_where is not None:
        write_instructions = write_instructions.option("replaceWhere", replace_where)

    write_instructions.saveAsTable(table_name)
    write_time = time.time()

    if optimize:
        logger.info("Running optimize the delta table now")
        start = time.time()
        optimize_instructions = "OPTIMIZE " + table_name
        if replace_where is not None:
            logger.info("Replacing the delta table according to where clause now")
            optimize_instructions += " WHERE " + replace_where
            if zorder:
                optimize_instructions += " ZORDER BY " + zorder
                spark.sql(optimize_instructions)
        logger.info(
            "Optimized in {} minutes.".format(
                str(round((time.time() - write_time) / 60, 1))
            )
        )

    logger.info(
        logger_statement.format(
            table_name,
            round((write_time - start_time) / 60, 1),
            format,
            mode,
            optimize,
            zorder,
            partition_column,
            replace_where,
            location,
            overwrite_schema,
            merge_schema,
            num_rows,
        )
    )


def get_latest_partition_value(spark, table_name, partition_column_name):
    partition_value = (
        spark.sql(
            """SELECT MAX({partition_column_name}) 
                                   FROM {table_name} 
                                   WHERE {partition_column_name} IS NOT NULL""".format(
                table_name=table_name, partition_column_name=partition_column_name
            )
        )
        .head()[0]
        .strftime("%Y-%m-%d")
    )
    logger.info(
        "For table {0}, Here is the latest partition value {2} for {1} partition column".format(
            table_name, partition_column_name, partition_value
        )
    )
    return partition_value


def get_latest_string_partition_value(spark, table_name, partition_column_name):
    partition_value = spark.sql(
        """SELECT MAX({partition_column_name}) 
                                   FROM {table_name} 
                                   WHERE {partition_column_name} IS NOT NULL""".format(
            table_name=table_name, partition_column_name=partition_column_name
        )
    ).head()[0]
    logger.info(
        "For table {0}, Here is the latest partition value {2} for {1} partition column".format(
            table_name, partition_column_name, partition_value
        )
    )
    return partition_value


def __get_merge_condition(upsert_on_column, base_table_alias, dataframe_alias):
    if len(upsert_on_column) > 1:
        merge_condition_list = list(
            map(
                lambda upsert_column: "{base_table_alias}.{upsert_column} = {dataframe_alias}.{upsert_column}".format(
                    base_table_alias=base_table_alias,
                    dataframe_alias=dataframe_alias,
                    upsert_column=upsert_column,
                ),
                upsert_on_column,
            )
        )
        merge_condition = " AND ".join(merge_condition_list)
    elif len(upsert_on_column) == 1:
        merge_condition = "{base_table_alias}.{upsert_on_column} = {dataframe_alias}.{upsert_on_column}".format(
            base_table_alias=base_table_alias,
            dataframe_alias=dataframe_alias,
            upsert_on_column=upsert_on_column[0],
        )
    else:
        merge_condition = None
    return merge_condition


def __get_upsert_statement(param, dataframe_alias):
    statement = {}
    if not param:
        return None
    if isinstance(param, list):
        for p in param:
            statement[p] = "{0}.{1}".format(dataframe_alias, p)
    elif isinstance(param, dict):
        for p in param:
            statement[p] = "{0}.{1}".format(dataframe_alias, param[p])
    else:
        return None
    return statement


def upsert_delta_table(
    spark, table_name, dataframe, upsert_on_column=[], update=None, insert=None
):
    if spark.catalog.tableExists(table_name):
        spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
        logger.info("Please ensure that the table and dataframe schema matches")
        base_table = DeltaTable.forName(spark, table_name)
        base_table_alias = "primary"
        dataframe_alias = "secondary"
        num_rows = dataframe.count()
        merge_condition = __get_merge_condition(
            upsert_on_column, base_table_alias, dataframe_alias
        )

        logger.info("Merge condition to be used: " + str(merge_condition))
        start_time = time.time()
        upsert_instructions = base_table.alias(base_table_alias).merge(
            dataframe.alias(dataframe_alias), merge_condition
        )

        update_condition = __get_upsert_statement(update, dataframe_alias)
        logger.info("Update statement to be used: " + str(update_condition))

        insert_condition = __get_upsert_statement(insert, dataframe_alias)
        logger.info("Insert statement to be used: " + str(insert_condition))

        if not update_condition:
            logger.info(
                "No update statement to be used, that means everything will be updated"
            )
            upsert_instructions = upsert_instructions.whenMatchedUpdateAll()
        else:
            upsert_instructions = upsert_instructions.whenMatchedUpdate(
                set=update_condition
            )

        if not insert_condition:
            upsert_instructions = upsert_instructions.whenNotMatchedInsertAll()
        else:

            upsert_instructions = upsert_instructions.whenNotMatchedInsert(
                values=insert_condition
            )

        upsert_instructions.execute()
        end_time = time.time()
        logger.info("Upserting finished successfully")
        logger_statement = """Written the dataframe. Please look at the stats:
                            Details:
                            - Table Name: {0} 
                            - Total time spent: {1} minutes
                            - Upsert Options:
                                - format: {2}
                                - Upsert on: {3}
                                - Update: {4}
                                - Insert: {5}
                            - Written rows:  {6}
                        """.format(
            table_name,
            str(round((end_time - start_time) / 60, 1)),
            "delta",
            merge_condition,
            update,
            insert,
            num_rows,
        )
        logger.info(logger_statement)
    else:
        logger.info(
            "Table {0} doesn't exist, please use write_delta_table functionality to create the table".format(
                table_name
            )
        )