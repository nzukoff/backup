import gspread
from oauth2client.service_account import ServiceAccountCredentials
from gspread_dataframe import get_as_dataframe, set_with_dataframe
import pandas as pd
import numpy as np
import logging
import json
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession
 

logging.basicConfig(format='%(asctime)-15s %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

SCOPE = ['https://www.googleapis.com/auth/drive', 
         'https://spreadsheets.google.com/feeds']

class GoogleDriveHelper:

    def __init__(self):
        self.client = None
        if self.client is None:
            self.client = self.get_client()
        logger.info("Google Drive Helper class initiated with the client")
    
    @staticmethod
    def __get_db_utils(spark):
        dbutils = None
        if spark.conf.get("spark.databricks.service.client.enabled") == "true":
            from pyspark.dbutils import DBUtils
            dbutils = DBUtils(spark)
        else:
            import IPython
            dbutils = IPython.get_ipython().user_ns["dbutils"]
        return dbutils
    
    def get_client(self):
        spark = SparkSession.builder.getOrCreate()
        dbutils = self.__get_db_utils(spark)
        
        account_credential_dict = {}
        for secrets in dbutils.secrets.list("focus"):
            if "google_service_account" in secrets.key:
                key = secrets.key
                if "private_key" in key and '_id' not in key:
                    value = dbutils.secrets.get(scope="focus", key=key).replace('\\n', '\n')
                else:
                    value = dbutils.secrets.get(scope="focus", key=key).replace('\\n', '\n')
                account_credential_dict[key[23:]] = value
        account_credential_dict = json.loads(json.dumps(account_credential_dict))
        credentials = ServiceAccountCredentials.from_json_keyfile_dict(account_credential_dict, SCOPE)
        client = gspread.authorize(credentials)
        return client

    def read_google_spreadsheet(self, file_name):
        logger.info("Reading the file {}".format(file_name))
        spreadsheet = self.client.open(file_name)
        return spreadsheet
    
    def pick_worksheet(self, spreadsheet, worksheet_name):
        worksheet = spreadsheet.worksheet(worksheet_name)
        logger.info("Opened {0} worksheet".format(worksheet_name))
        return worksheet
    
    def get_worksheet_as_dataframe(self, spreadsheet_name, worksheet_name):
        spreadsheet = self.read_google_spreadsheet(spreadsheet_name)
        worksheet = self.pick_worksheet(spreadsheet, worksheet_name)
        df = get_as_dataframe(worksheet, 
                              parse_dates=True, 
                              evaluate_formulas=True)
        logger.info("Loaded the data as a dataframe of share {0}x{1}".format(df.shape[0], df.shape[1]))
        return df

    def remove_old_data(self, spreadsheet_name, worksheet_name, worksheet_range):
        try:
            spreadsheet = self.read_google_spreadsheet(spreadsheet_name)
            spreadsheet.values_clear("{0}!{1}".format(worksheet_name, worksheet_range))
            logger.info("Cleared the data from {0} in {} worksheet of {2} google sheet".format(worksheet_range, worksheet_name, spreadsheet_name))
            return True
        except:
            return False
        
    def write_dataframe_to_worksheet(self, dataframe, spreadsheet_name, worksheet_name):
        spreadsheet = self.read_google_spreadsheet(spreadsheet_name)
        worksheet = self.pick_worksheet(spreadsheet, worksheet_name)
        logger.info("Writing the data as a dataframe of share {0}x{1}".format(dataframe.shape[0], dataframe.shape[1]))
        set_with_dataframe(worksheet, dataframe)
        logger.info("Worksheet {} written".format(worksheet_name))
        




