from datetime import datetime, timedelta
from dateutil.relativedelta import *
import logging

logging.basicConfig(format='%(asctime)-15s %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def subtract_days_from_date(date, days_to_subtract):
    formatted_date = datetime.strptime(str(date), '%Y-%m-%d')
    new_date = formatted_date - timedelta(days=days_to_subtract)
    logger.info("We are subtracting {0} days from {1}, here is the new date {2}".format(days_to_subtract, date, new_date))
    return datetime.strftime(new_date, '%Y-%m-%d')


def subtract_months_from_date(date, months_to_substract):
    formatted_date = datetime.strptime(str(date), '%Y-%m-%d')
    new_date = formatted_date+relativedelta(months=-months_to_substract)
    logger.info("We are subtracting {0} months from {1}, here is the new date {2}".format(months_to_substract, date, new_date))
    return datetime.strftime(new_date, '%Y-%m-%d') 


