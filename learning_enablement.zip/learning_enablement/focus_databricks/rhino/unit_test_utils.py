import time
from delta.tables import *
from datetime import date, datetime
import logging

logging.basicConfig(format="%(asctime)-15s %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class UnitTestBareMetal(object):
    def __init__(self):
        self.unit_test_type = "Python"

    @staticmethod
    def unit_test_date_format_check(date, format):
        try:
            assert (
                bool(datetime.strptime(str(date), format)) == True
            ), "Date doesn't match with the format"
        except:
            raise


class UnitTestDataFrame(object):
    def __init__(self):
        self.unit_test_type = "Dataframe"

    @staticmethod
    def unit_test_column_null_check(dataframe, column_name):
        try:
            result = (
                dataframe.select(column_name)
                .filter(
                    """{0} LIKE 'None' 
                       OR {0} LIKE 'NULL' 
                       OR {0} = ''
                       OR {0} IS NULL""".format(
                        column_name
                    )
                )
            )
            assert result.count() == 0, "Column contains nulls"
        except:
            raise

    @staticmethod
    def unit_test_count_check(dataframe):
        try:
            assert dataframe.count() > 0, "Dataframe is empty"
        except:
            raise
    
    @staticmethod
    def unit_test_primary_key_duplication_check(dataframe, primary_key):
        try:
            if isinstance(primary_key, list):
                assert dataframe.count() == dataframe.select(*primary_key).distinct().count(), "Duplicate values found in the dataframe"
            if isinstance(primary_key, str):
                assert dataframe.count() == dataframe.select(primary_key).distinct().count(), "Duplicate values found in the dataframe"
        except:
            raise

class UnitTestDataObject(object):
    def __init__(self):
        self.unit_test_type = "Data Object"
        
    @staticmethod
    def unit_test_database_exists(spark, database_name):
        try:
            assert (
                spark.catalog.databaseExists(database_name) == True
            ), "Database doesn't exist"
        except:
            raise

    @staticmethod
    def unit_test_table_exists(spark, table_name):
        try:
            assert spark.catalog.tableExists(table_name) == True, "Table doesn't exist"
        except:
            raise

class UnitTestCases(UnitTestBareMetal, UnitTestDataFrame, UnitTestDataObject):
    def __init__(self):
        pass




