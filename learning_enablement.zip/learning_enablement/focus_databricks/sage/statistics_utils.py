import os
import sys
import math
import random
import itertools
import re
import logging
import numpy as np
import pandas as pd
from scipy.stats import *
import matplotlib.pyplot as plt
from statsmodels.stats.multicomp import *

plt.style.use('ggplot')
pd.set_option('display.max_columns', 200)
pd.set_option('display.max_colwidth', 400)
pd.set_option('display.float_format', lambda x: '%.3f' % x)

logging.basicConfig(format='%(asctime)-15s %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

from focus_databricks.sage.exploratory_utils import *
from focus_databricks.sage.data_type_utils import *

def pearsonTest(x, y):
    corr, p = pearsonr(x, y)
    return corr, p

def spearmanTest(x, y):
    corr, p = spearmanr(x, y)
    return corr, p

def kendallTauTest(x, y):
    corr, p = kendalltau(x, y)
    return corr, p

def chiSquaredContingencyTest(observed, correction=True):
    stat, p, dof, expected = chi2_contingency(observed, correction)
    return stat, p, dof, expected

def shapiroWilkTest(data):
    stat, p = shapiro(data)
    return stat, p

def dAgostinok2Test(data):
    stat, p = normaltest(data)
    return stat, p

def andersonDarlingTest(data):
    result = anderson(data)
    return result
  
def cramersV(x, y):
    return cramers_v(x, y)
  
def conditionalEntropy(x, y):
    return conditional_entropy(x, y)

def theilsU(x, y):
    return theils_u(x, y)
  
def prepareDataChiSquareTest(df, column1, column2):
    tab_ = pd.crosstab(df[column1], df[column2], margins=True)
    tab_size = tab_.shape
    observed = tab_.iloc[0:tab_size[0]-1, 0:tab_size[1]-1]
    return observed

def normality_test(mode="shapiro", data=None):
    if data is None:
        print("Please provide data in right format")
        return
    if mode == "shapiro":
        return shapiroWilkTest(data)
    elif mode == "k2":
        return dAgostinok2Test(data)
    elif mode == "anderson":
        return andersonDarlingTest(data)


def correlation_test(mode="pearson", x=None, y=None):
    if x is None or y is None:
        print("Please provide data in right format")
        return
    print("Statistical tests that you can use to check if two samples are related.")
    if mode == "pearson":
        print("Linear Relationship Test")
        return pearsonTest(x, y)
    elif mode == "spearman":
        print("Monotonic Relationship Test")
        return spearmanTest(x, y)
    elif mode == "kendall":
        print("Monotonic Relationship Test")
        return kendalltau(x, y)
    elif mode == "chi":
        print("Tests whether two categorical variables are related or independent.")
        return chiSquaredContingencyTest(x, True)
    elif mode == "cramer":
        print("Calculates Cramer's V statistic for categorical-categorical association. "
              "This is a symmetric coefficient: V(x,y) = V(y,x)")
        return cramersV(x, y)
    elif mode == "theil":
        print("""Calculates Theil's U statistic (Uncertainty coefficient) for categorical-categorical association.
        This is the uncertainty of x given y: value is on the range of [0,1] - where 0 means y provides no information 
        about x, and 1 means y provides full information about x. This is an asymmetric coefficient: U(x,y) != U(y,x)""")
        return theilsU(x, y)
    elif mode == "cratio":
        print("""Calculates the Correlation Ratio (sometimes marked by the greek letter Eta) for categorical-continuous association.
        Answers the question - given a continuous value of a measurement, is it possible to know which category is it
        associated with? Value is in the range [0,1], where 0 means a category cannot be determined by a continuous measurement, and 1 means
        a category can be determined with absolute certainty.""")
        return correlation_ratio(x, y)
    elif mode == "pointbiserial":
        return pointbiserialr(x, y)


def tStatistics(sample, confidence_level=95):
    np.random.seed(786)
    sample = convert(sample, "dataframe")
    sample_size = sample.shape[0]
    sample_mean = sample.mean()
    getQuantile = 1 - (1 - (confidence_level / 100)) / 2 # For two tail
    t_critical = t.ppf(q=getQuantile,
                             df=sample_size-1)

    print("t-critical value: ", t_critical)

    sample_stdev = sample.std()
    sigma = sample_stdev / math.sqrt(sample_size)
    margin_of_error = t_critical * sigma

    confidence_interval = t.interval(alpha = (confidence_level / 100),
                                           df= sample_size - 1,
                                           loc = sample_mean,
                                           scale = sigma)

    print("Confidence interval: ", confidence_interval)
    return t_critical, sample_mean, confidence_interval


def zStatistics(sample, population, confidence_level=95):
    np.random.seed(786)
    sample = convert(sample, "dataframe")
    sample_size = sample.shape[0]
    sample_mean = sample.mean()

    population = convert(population, "dataframe")
    getQuantile = 1 - (1 - (confidence_level / 100)) / 2
    z_critical = norm.ppf(q=getQuantile)  # Get the z-critical value*

    print("z-critical value: ", z_critical)

    pop_stdev = population.std()
    margin_of_error = z_critical * (pop_stdev / math.sqrt(sample_size))
    confidence_interval = (sample_mean - margin_of_error,
                           sample_mean + margin_of_error)

    print("Confidence interval: ", confidence_interval)
    return z_critical, sample_mean, confidence_interval


def oneSampleTTest(sample, population_mean, confidence_level=95, help=False):
    if help:
        print("""Tests whether the means of two independent samples are significantly different.
        Assumptions:
        * Observations in each sample are independent and identically distributed (iid).
        * Observations in each sample are normally distributed.
        * Observations in each sample have the same variance.
        
        Interpretation:
        H0: the means of the samples are equal.
        H1: the means of the samples are unequal.
        """)
    sample = convert(sample, "dataframe")
    sample_size = sample.shape[0]
    sigma = sample.std() / math.sqrt(sample_size)

    confidence_interval = t.interval((confidence_level / 100),
                                           df=sample_size -1,
                                           loc=sample.mean(),
                                           scale=sigma)

    return ttest_1samp(a=sample, popmean=population_mean), confidence_interval


def twoSampleTTest(sample1, sample2, equal_var=True, help=False):
    if help:
        print("""A two-sample t-test investigates whether the means of two independent data samples differ from one another. 
            In a two-sample test, the null hypothesis is that the means of both groups are the same. 
            Unlike the one sample-test where we test against a known population parameter, 
            the two sample test only involves sample means.""")
    return ttest_ind(a=sample1,
                     b=sample2,
                     equal_var=equal_var)


def pairedTTest(before, after, help=False):
    if help:
        print("""The basic two sample t-test is designed for testing differences between independent groups. 
        In some cases, you might be interested in testing differences between samples of the same group at different 
        points in time. 
        For instance, a hospital might want to test whether a weight-loss drug works by checking the weights 
        of the same group patients before and after treatment. 
        A paired t-test lets you check whether the means of samples from the same group differ.""")
    return ttest_rel(a=before, b=after)


def typeErrorDetails():
    print("""The result of a statistical hypothesis test and the corresponding decision of whether to 
    reject or accept the null hypothesis is not infallible. A test provides evidence for or against the null hypothesis
    and then you decide whether to accept or reject it based on that evidence, but the evidence may lack the strength 
    to arrive at the correct conclusion. 
    Incorrect conclusions made from hypothesis tests fall in one of two categories: type I error and type II error.
    * Type I error describes a situation where you reject the null hypothesis when it is actually true. 
    This type of error is also known as a "false positive" or "false hit". 
    The type 1 error rate is equal to the significance level α, so setting a higher confidence level 
    (and therefore lower alpha) reduces the chances of getting a false positive.
    * Type II error describes a situation where you fail to reject the null hypothesis when it is actually false.
     Type II error is also known as a "false negative" or "miss". 
     The higher your confidence level, the more likely you are to make a type II error.""")


def estimatePopulationProportion(sample, class_, confidence_level=0.95, help=False):
    if help:
        print("""
        random.seed(10)
        population_races = (["white"]*100000) + (["black"]*50000) +\
                       (["hispanic"]*50000) + (["asian"]*25000) +\
                       (["other"]*25000)

        demo_sample = random.sample(population_races, 1000)   # Sample 1000 values

        for race in set(demo_sample):
            print( race + " proportion estimate:" )
            print( demo_sample.count(race)/1000 )

        We can also make a confidence interval for a point estimate of a population proportion. 
        In this case, the margin of error equals:
        z∗√p(1−p)/n
        Where z is the z-critical value for our confidence level, 
        p is the point estimate of the population proportion and n is the sample size.""")

    if class_ is None:
        print("Please select a class to estimate")

    getQuantile = 1 - (1 - (confidence_level / 100)) / 2
    z_critical = norm.ppf(getQuantile)

    sample = convert(sample, "dataframe")
    n = sample.shape[0]
    pointEstimate = sample.count(class_) / n

    margin_of_error = z_critical * math.sqrt((pointEstimate * (1 - pointEstimate)) / n)

    confidence_interval = (pointEstimate - margin_of_error,
                           pointEstimate + margin_of_error)

    return confidence_interval


def oneWayAnova(df, cont, cat, help=False):
    if help:
        print("""The t-test works well when dealing with two groups, but sometimes we want to compare more than two groups at the same time. 
            For example, if we wanted to test whether voter age differs based on some categorical variable like race, 
            we have to compare the means of each level or group the variable. We could carry out a separate t-test for each pair of groups, 
            but when you conduct many tests you increase the chances of false positives. 
            The analysis of variance or ANOVA is a statistical inference test that lets you compare multiple groups at the same time.
            The one-way ANOVA tests whether the mean of some numeric variable differs across the levels of one categorical variable. 
            It essentially answers the question: do any of the group means differ from one another?
            In the case of the ANOVA, you use the "f-distribution".
            The test result suggests the groups don't have the same sample means in this case, since the p-value is significant 
            at a 99% confidence level. We know that it is the white voters who differ because we set it up that way in the code,
            but when testing real data, you may not know which group(s) caused the the test to throw a positive result. 
            To check which groups differ after getting a positive ANOVA result, you can perform a follow up test or "post-hoc test".
            One post-hoc test is to perform a separate t-test for each pair of groups. You can perform a t-test between all pairs using by running each pair.
            Ex: The p-values for each pairwise t-test suggest mean of white voters is likely different from the other groups, 
            since the p-values for each t-test involving the white group is below 0.05. Using unadjusted pairwise t-tests 
            can overestimate significance, however, because the more comparisons you make, 
            the more likely you are to come across an unlikely result due to chance. 
            We can adjust for this multiple comparison problem by dividing the statistical significance level by 
            the number of comparisons made. In this case, if we were looking for a significance level of 5%, we'd be 
            looking for p-values of 0.05/10 = 0.005 or less. 
            This simple adjustment for multiple comparisons is known as the Bonferroni correction.
            The Bonferroni correction is a conservative approach to account for the multiple comparisons problem 
            that may end up rejecting results that are actually significant.
            Another common post hoc-test is Tukey's test.
            """)
    df = convert(df, "dataframe")
    groups = df.groupby(cat).groups
    categories = list(groups.keys())
    df_ = []
    for c in categories:
        temp = pd.DataFrame(df.iloc[groups[c]][cont])
        df_.append(temp)
    return f_oneway(*df_)


def postHocTest(df, cont, cat):
    df = convert(df, "dataframe")
    groups = df.groupby(cat).groups
    categories = list(groups.keys())
    import itertools
    L = 2
    for subset in itertools.combinations(categories, L):
        print(str(subset[0]) + " vs " + str(subset[1]))
        print(twoSampleTTest(df.iloc[groups[subset[0]]][cont], df.iloc[groups[subset[1]]][cont]))


def tukeyTest(df, cont, cat, significance_level=0.05):
    tukey = pairwise_tukeyhsd(endog=df[cont],
                              groups=df[cat],
                              alpha=significance_level)

    tukey.plot_simultaneous()
    # plt.vlines(x=49.57, ymin=-0.5, ymax=4.5, color="red")

    tukey.summary()
    

def get_regression_coefficient_weights(result_summary, alpha = 0.05, significance = True):
    results_df = result_summary.tables[1].iloc[:, [0,3]].reset_index()
    results_df.columns = ["feature", "coeficient", "p-value"]
    results_df = results_df[results_df["feature"] != "const"]
    if significance:
        results_df = results_df[results_df["p-value"] < alpha]
    min_coef = results_df["coeficient"].min()
    max_coef = results_df["coeficient"].max()
    min_weight = 1
    max_weight = 10
    results_df["coeficient_standardized"] = (results_df["coeficient"] - min_coef)/ (max_coef - min_coef)
    results_df["coeficient_scaled"] = results_df["coeficient_standardized"] * (max_weight - min_weight) + min_weight
    results_df["coeficient_scaled"] = results_df["coeficient_scaled"].apply(np.ceil)
    return results_df[["feature", "coeficient_scaled"]]
