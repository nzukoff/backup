import math
import numpy as np
import pandas as pd
import seaborn as sns
import logging
import scipy.stats as ss
import matplotlib.pyplot as plt
from collections import Counter
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

plt.style.use('ggplot')
pd.set_option('display.max_columns', 200)
pd.set_option('display.max_colwidth', 400)
pd.set_option('display.float_format', lambda x: '%.3f' % x)

logging.basicConfig(format='%(asctime)-15s %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

from focus_databricks.sage.data_type_utils import *
from focus_databricks.sage.plot_helper_utils import *
from focus_databricks.sage.statistics_utils import *

def get_variables(df, columns_excluded=[]):
    column_list = [cols for cols in df.columns if cols not in columns_excluded]
    continuous = [cols for cols in df._get_numeric_data().columns if cols not in columns_excluded]
    categorical = [_ for _ in column_list if _ not in continuous]
    for cols in categorical:
        df[cols] = pd.Categorical(df[cols])
    return column_list, continuous, categorical
  

def continuous_variable_density_analysis(df, column):
    print("Points Spread")
    print(df[column].describe())
    print("Distribution: %s" % str(column))
    plotDensity(df, column)


def continuous_variable_distribution_analysis(df, column, target=None):
    print("Points Spread")
    print(df[column].describe())
    print("Histogram: %s" % str(column))
    plotHistogram(df, column, target)


def continuous_variable_outliers_analysis(df, column, target=None):
    print("Points Spread")
    print(df[column].describe())
    print("Plotting Box plot for: %s" % str(column))
    plotWhiskersBoxPlot(df, column, target)


def continuous_variable_pair_analysis(df, target=None):
    plotPairs(df, target)


def continuous_variables_spread(df, column1, column2):
    plotScatter(df, column1, column2,
                title= str(column1) + " vs " + str(column2),
                xlabel=str(column1), ylabel=str(column2))


def continuous_variables_spread_by_target(df, column1, column2, target):
    plotScatterByTarget(df, column1, column2, target,
                        title= str(column1) + " vs " + str(column2),
                        xlabel=str(column1), ylabel=str(column2))


def continuous_variables_complete_analysis(df, columns_excluded=[]):
    all_, cont, cat = get_variables(df)
    for cols in columns_excluded:
        cont.remove(cols)
    import itertools
    L = 2
    for subset in itertools.combinations(cont, L):
        continuous_variables_scatter_plot(df, subset[0], subset[1])


def continuous_variables_complete_analysis_by_target(df, columns_excluded=[], target=None):
    all_, cont, cat = get_variables(df)
    for cols in columns_excluded:
        cont.remove(cols)
    import itertools
    L = 2
    for subset in itertools.combinations(cont, L):
        continuous_variables_scatter_plot_by_target(df, subset[0], subset[1], target=target)


def continuous_variable_normality_test(df, column):
    result = dict()
    for t in ["shapiro", "k2", "anderson"]:
        result[t] = normality_test(data=df[column], mode=t)
        print(t + " test results:", result[t])
    return result


def all_continuous_variable_normality_test(df, columns_excluded = []):
    print("Tests whether a data sample has a Gaussian distribution.")
    shapiro_ = dict()
    k2_ = dict()
    anderson_ = dict()
    all_, cont, cat = get_variables(df)
    for var in cont:
        if var not in columns_excluded:
            print("Testing normality for ", var)
            result = continuous_variable_normality_test(df, var)
            shapiro_[var] = result['shapiro'][1]
            k2_[var] = result['k2'][1]
            anderson_[var] = result['anderson']
            print()
    plotBar(shapiro_.keys(), shapiro_.values(), title="P-value For Shapiro Wilk Normality Test", xlabel='Variables', ylabel='P-value')
    plotBar(k2_.keys(), k2_.values(), title="P-value For K2 Normality Test", xlabel='Variables', ylabel='P-value')


def categorial_variable_statistics(df, column):
    print("Total Unique Classes", df[column].cat.categories)
    plotCategoricalBarPlot(df, column)


def categorial_variables_stacked_analysis(df, column1, column2):
    plot2CategoricaStackedBar(df, column1, column2)


def categorial_variables_analysis_by_target(df, columns_excluded=[], target=None):
    if target is None:
        print("Please provide Y column")
        return

    all_, cont, cat = get_variables(df, columns_excluded)
    for cols in cat:
        if cols not in columns_excluded:
            twoCategoricalAnalysis(df, cols, target)


def categorical_variable_complete_analysis(df, columns_excluded=[], target=None):
    all_, cont, cat = get_variables(df, columns_excluded)
    for cols in columns_excluded + [target]:
        cat.remove(cols)
    import itertools
    L = 2
    for subset in itertools.combinations(cat, L):
        print(subset[0], subset[1])
        twoCategoricalAnalysis(df, subset[0], subset[1])


def continuous_categorical_density_analysis(df, columns_excluded=[]):
    all_, cont, cat = get_variables(df, columns_excluded)
    import itertools
    for subset in itertools.product(cont, cat):
        plotStackedDensity(df, subset[0], subset[1])


def correlationAnalysisContinuousBase(df, column, columns_excluded=[]):
    all_, cont, cat = get_variables(df, columns_excluded)
    labels = []
    values = []
    for col in cont:
        labels.append(col)
        values.append(np.corrcoef(df[col].values, df[column].values)[0,1])
    plotBar(labels, values, title="Correlation for Continuous Variables", xlabel="Variables", ylabel="Correlation coefficient")


def continuous_varibale_correlation_analysis(df, columns_excluded=[]):
    all_, cont, cat = get_variables(df, columns_excluded)
    labels = []
    pearvalues = []
    spearvalues = []
    kendallvalues = []
    L = 2
    sets = itertools.combinations(cat, L)
    for subset in sets:
        labels.append(subset)
        pearvalues.append(correlation_test(mode="pearson", x = df[subset[0]].values, y=df[subset[1]].values))
        spearvalues.append(correlation_test(mode="spearman", x=df[subset[0]].values, y=df[subset[1]].values))
        kendallvalues.append(correlation_test(mode="kendall", x=df[subset[0]].values, y=df[subset[1]].values))
    plotBar(labels, pearvalues, title="Pearson Correlation for Continuous Variables",
            xlabel="Variables", ylabel="Correlation coefficient")
    plotBar(labels, spearvalues, title="Spearman Correlation for Continuous Variables",
            xlabel="Variables", ylabel="Correlation coefficient")
    plotBar(labels, kendallvalues, title="Kendall Correlation for Continuous Variables",
            xlabel="Variables", ylabel="Correlation coefficient")


def continuous_varibale_correlation_analysis_by_target(df, target, columns_excluded=[]):
    all_, cont, cat = get_variables(df, columns_excluded)
    labels = []
    pearvalues = []
    spearvalues = []
    kendallvalues = []
    for col in cont:
        labels.append(col)
        pearvalues.append(correlation_test(mode="pearson", x = df[col].values, y=df[target].values))
        spearvalues.append(correlation_test(mode="spearman", x=df[col].values, y=df[target].values))
        kendallvalues.append(correlation_test(mode="kendall", x=df[col].values, y=df[target].values))
    plotBar(labels, pearvalues, title="Pearson Correlation for Continuous Variables",
            xlabel="Variables", ylabel="Correlation coefficient")
    plotBar(labels, spearvalues, title="Spearman Correlation for Continuous Variables",
            xlabel="Variables", ylabel="Correlation coefficient")
    plotBar(labels, kendallvalues, title="Kendall Correlation for Continuous Variables",
            xlabel="Variables", ylabel="Correlation coefficient")


def continuous_categorical_correlation_analysis_v1(df, columns_excluded=[]):
    all_, cont, cat = get_variables(df, columns_excluded)
    L = 2
    sets = itertools.combinations(cat, L)
    labels = []
    cvalues = []
    tvalues = []
    for subset in sets:
        labels.append(subset)
        cvalues.append(correlation_test("cramer", subset[0], subset[1]))
        tvalues.append(correlation_test("theil", subset[0], subset[1]))
    plotBar(labels, cvalues, title="Cramer's V Correlation for Categorical Variables", xlabel="Variables",
            ylabel="Correlation coefficient")
    plotBar(labels, tvalues, title="Theil's U Correlation for Categorical Variables", xlabel="Variables",
            ylabel="Correlation coefficient")


def categorical_correlation_analysis_by_target(df, target, columns_excluded=[]):
    all_, cont, cat = get_variables(df, columns_excluded)
    labels = []
    cvalues = []
    tvalues = []
    for col in cat:
        labels.append(col)
        cvalues.append(correlation_test("cramer", df[col], df[target]))
        tvalues.append(correlation_test("theil", df[col], df[target]))
    plotBar(labels, cvalues, title="Cramer's V Correlation for Categorical Variables", xlabel="Variables",
            ylabel="Correlation coefficient")
    plotBar(labels, tvalues, title="Theil's U Correlation for Categorical Variables", xlabel="Variables",
            ylabel="Correlation coefficient")


def continuous_categorical_correlation_analysis_v2(df, columns_excluded=[]):
    all_, cont, cat = get_variables(df, columns_excluded)
    labels = []
    cvalues = []
    pointvalues = []
    pointPValues = []
    for subset in itertools.product(cat, cont):
        labels.append(subset)
        cvalues.append(correlation_test("cratio", df[subset[0]], df[subset[1]]))
        pbs = correlation_test("pointbiserial", df[subset[1]], df[subset[0]])
        pointvalues.append(pbs[0])
        pointPValues.append(pbs[1])
    plotBar(labels, cvalues, title="Correlation Ratio", xlabel="Variables",
            ylabel="Correlation coefficient")
    plotBar(labels, pointvalues, title="Point Biserial Statistics R value", xlabel="Variables",
            ylabel="Correlation coefficient")
    plotBar(labels, pointPValues, title="Point Biserial Statistics p-value", xlabel="Variables",
            ylabel="P-value")


def reduce_dimensionality(X, num_components=2, solver='randomized'):
    pca=PCA(n_components=num_components, svd_solver=solver)
    return pca.fit_transform(X)


def conditional_entropy(x, y):
    """
    Calculates the conditional entropy of x given y: S(x|y)
    Wikipedia: https://en.wikipedia.org/wiki/Conditional_entropy
    :param x: list / NumPy ndarray / Pandas Series
        A sequence of measurements
    :param y: list / NumPy ndarray / Pandas Series
        A sequence of measurements
    :return: float
    """
    # entropy of x given y
    y_counter = Counter(y)
    xy_counter = Counter(list(zip(x,y)))
    total_occurrences = sum(y_counter.values())
    entropy = 0.0
    for xy in xy_counter.keys():
        p_xy = xy_counter[xy] / total_occurrences
        p_y = y_counter[xy[1]] / total_occurrences
        entropy += p_xy * math.log(p_y/p_xy)
    return entropy


def cramers_v(x, y):
    """
    Calculates Cramer's V statistic for categorical-categorical association.
    Uses correction from Bergsma and Wicher, Journal of the Korean Statistical Society 42 (2013): 323-328.
    This is a symmetric coefficient: V(x,y) = V(y,x)
    Original function taken from: https://stackoverflow.com/a/46498792/5863503
    Wikipedia: https://en.wikipedia.org/wiki/Cram%C3%A9r%27s_V
    :param x: list / NumPy ndarray / Pandas Series
        A sequence of categorical measurements
    :param y: list / NumPy ndarray / Pandas Series
        A sequence of categorical measurements
    :return: float
        in the range of [0,1]
    """
    confusion_matrix = pd.crosstab(x,y)
    chi2 = ss.chi2_contingency(confusion_matrix)[0]
    n = confusion_matrix.sum().sum()
    phi2 = chi2/n
    r,k = confusion_matrix.shape
    phi2corr = max(0, phi2-((k-1)*(r-1))/(n-1))
    rcorr = r-((r-1)**2)/(n-1)
    kcorr = k-((k-1)**2)/(n-1)
    return np.sqrt(phi2corr/min((kcorr-1),(rcorr-1)))


def theils_u(x, y):
    """
    Calculates Theil's U statistic (Uncertainty coefficient) for categorical-categorical association.
    This is the uncertainty of x given y: value is on the range of [0,1] - where 0 means y provides no information about
    x, and 1 means y provides full information about x.
    This is an asymmetric coefficient: U(x,y) != U(y,x)
    Wikipedia: https://en.wikipedia.org/wiki/Uncertainty_coefficient
    :param x: list / NumPy ndarray / Pandas Series
        A sequence of categorical measurements
    :param y: list / NumPy ndarray / Pandas Series
        A sequence of categorical measurements
    :return: float
        in the range of [0,1]
    """
    s_xy = conditional_entropy(x,y)
    x_counter = Counter(x)
    total_occurrences = sum(x_counter.values())
    p_x = list(map(lambda n: n/total_occurrences, x_counter.values()))
    s_x = ss.entropy(p_x)
    if s_x == 0:
        return 1
    else:
        return (s_x - s_xy) / s_x


def correlation_ratio(categories, measurements):
    """
    Calculates the Correlation Ratio (sometimes marked by the greek letter Eta) for categorical-continuous association.
    Answers the question - given a continuous value of a measurement, is it possible to know which category is it
    associated with?
    Value is in the range [0,1], where 0 means a category cannot be determined by a continuous measurement, and 1 means
    a category can be determined with absolute certainty.
    Wikipedia: https://en.wikipedia.org/wiki/Correlation_ratio
    :param categories: list / NumPy ndarray / Pandas Series
        A sequence of categorical measurements
    :param measurements: list / NumPy ndarray / Pandas Series
        A sequence of continuous measurements
    :return: float
        in the range of [0,1]
    """
    categories = convert(categories, 'array')
    measurements = convert(measurements, 'array')
    fcat, _ = pd.factorize(categories)
    cat_num = np.max(fcat)+1
    y_avg_array = np.zeros(cat_num)
    n_array = np.zeros(cat_num)
    for i in range(0,cat_num):
        cat_measures = measurements[np.argwhere(fcat == i).flatten()]
        n_array[i] = len(cat_measures)
        y_avg_array[i] = np.average(cat_measures)
    y_total_avg = np.sum(np.multiply(y_avg_array,n_array))/np.sum(n_array)
    numerator = np.sum(np.multiply(n_array,np.power(np.subtract(y_avg_array,y_total_avg),2)))
    denominator = np.sum(np.power(np.subtract(measurements,y_total_avg),2))
    if numerator == 0:
        eta = 0.0
    else:
        eta = numerator/denominator
    return eta


def associations(dataset, nominal_columns=None, mark_columns=False, theil_u=False, plot=True,
                          return_results = False, **kwargs):
    """
    Calculate the correlation/strength-of-association of features in data-set with both categorical (eda_tools) and
    continuous features using:
     - Pearson's R for continuous-continuous cases
     - Correlation Ratio for categorical-continuous cases
     - Cramer's V or Theil's U for categorical-categorical cases
    :param dataset: NumPy ndarray / Pandas DataFrame
        The data-set for which the features' correlation is computed
    :param nominal_columns: string / list / NumPy ndarray
        Names of columns of the data-set which hold categorical values. Can also be the string 'all' to state that all
        columns are categorical, or None (default) to state none are categorical
    :param mark_columns: Boolean (default: False)
        if True, output's columns' names will have a suffix of '(nom)' or '(con)' based on there type (eda_tools or
        continuous), as provided by nominal_columns
    :param theil_u: Boolean (default: False)
        In the case of categorical-categorical feaures, use Theil's U instead of Cramer's V
    :param plot: Boolean (default: True)
        If True, plot a heat-map of the correlation matrix
    :param return_results: Boolean (default: False)
        If True, the function will return a Pandas DataFrame of the computed associations
    :param kwargs:
        Arguments to be passed to used function and methods
    :return: Pandas DataFrame
        A DataFrame of the correlation/strength-of-association between all features
    """

    dataset = convert(dataset, 'dataframe')
    columns = dataset.columns
    if nominal_columns is None:
        nominal_columns = list()
    elif nominal_columns == 'all':
        nominal_columns = columns
    corr = pd.DataFrame(index=columns, columns=columns)
    for i in range(0,len(columns)):
        for j in range(i,len(columns)):
            if i == j:
                corr[columns[i]][columns[j]] = 1.0
            else:
                if columns[i] in nominal_columns:
                    if columns[j] in nominal_columns:
                        if theil_u:
                            corr[columns[j]][columns[i]] = theils_u(dataset[columns[i]],dataset[columns[j]])
                            corr[columns[i]][columns[j]] = theils_u(dataset[columns[j]],dataset[columns[i]])
                        else:
                            cell = cramers_v(dataset[columns[i]],dataset[columns[j]])
                            corr[columns[i]][columns[j]] = cell
                            corr[columns[j]][columns[i]] = cell
                    else:
                        cell = correlation_ratio(dataset[columns[i]], dataset[columns[j]])
                        corr[columns[i]][columns[j]] = cell
                        corr[columns[j]][columns[i]] = cell
                else:
                    if columns[j] in nominal_columns:
                        cell = correlation_ratio(dataset[columns[j]], dataset[columns[i]])
                        corr[columns[i]][columns[j]] = cell
                        corr[columns[j]][columns[i]] = cell
                    else:
                        cell, _ = ss.pearsonr(dataset[columns[i]], dataset[columns[j]])
                        corr[columns[i]][columns[j]] = cell
                        corr[columns[j]][columns[i]] = cell
    corr.fillna(value=np.nan, inplace=True)
    if mark_columns:
        marked_columns = ['{} (nom)'.format(col) if col in nominal_columns else '{} (con)'.format(col) for col in columns]
        corr.columns = marked_columns
        corr.index = marked_columns
    if plot:
        plt.figure(figsize=kwargs.get('figsize',None))
        sns.heatmap(corr, annot=kwargs.get('annot',True), fmt=kwargs.get('fmt','.2f'))
        plt.show()
    if return_results:
        return corr


def numerical_encoding(dataset, nominal_columns='all', drop_single_label=False, drop_fact_dict=True):
    """
    Encoding a data-set with mixed data (numerical and categorical) to a numerical-only data-set,
    using the following logic:
    - categorical with only a single value will be marked as zero (or dropped, if requested)
    - categorical with two values will be replaced with the result of Pandas `factorize`
    - categorical with more than two values will be replaced with the result of Pandas `get_dummies`
    - numerical columns will not be modified
    :param dataset: NumPy ndarray / Pandas DataFrame
        The data-set to encode
    :param nominal_columns: sequence / string
        A sequence of the nominal (categorical) columns in the dataset. If string, must be 'all' to state that
        all columns are nominal. If None, nothing happens. Default: 'all'
    :param drop_single_label: Boolean (default: False)
        If True, nominal columns with a only a single value will be dropped.
    :param drop_fact_dict: Boolean (default: True)
        If True, the return value will be the encoded DataFrame alone. If False, it will be a tuple of
        the DataFrame and the dictionary of the binary factorization (originating from pd.factorize)
    :return: DataFrame or (DataFrame, dict)
        If drop_fact_dict is True, returns the encoded DataFrame. else, returns a tuple of the encoded DataFrame and
        dictionary, where each key is a two-value column, and the value is the original labels, as supplied by
        Pandas `factorize`. Will be empty if no two-value columns are present in the data-set
    """
    dataset = convert(dataset, 'dataframe')
    if nominal_columns is None:
        return dataset
    elif nominal_columns == 'all':
        nominal_columns = dataset.columns
    converted_dataset = pd.DataFrame()
    binary_columns_dict = dict()
    for col in dataset.columns:
        if col not in nominal_columns:
            converted_dataset.loc[:,col] = dataset[col]
        else:
            unique_values = pd.unique(dataset[col])
            if len(unique_values) == 1 and not drop_single_label:
                converted_dataset.loc[:,col] = 0
            elif len(unique_values) == 2:
                converted_dataset.loc[:,col], binary_columns_dict[col] = pd.factorize(dataset[col])
            else:
                dummies = pd.get_dummies(dataset[col],prefix=col)
                converted_dataset = pd.concat([converted_dataset,dummies],axis=1)
    if drop_fact_dict:
        return converted_dataset
    else:
        return converted_dataset, binary_columns_dict
      

def get_features_after_auto_correlation_fix(df):
    vif_data = pd.DataFrame()
    vif_data["feature"] = df.columns
    vif_data["VIF"] = [variance_inflation_factor(df.values, i) for i in range(len(df.columns))]
    features_to_be_used = vif_data[vif_data["VIF"] < 10]["feature"].values
    return features_to_be_used


