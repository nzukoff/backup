import os
import sys
import math
import itertools
import re
import logging
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import scikitplot as skplt
import plotly.graph_objs as go
from plotly.offline import init_notebook_mode, plot, iplot

plt.style.use('ggplot')
pd.set_option('display.max_columns', 200)
pd.set_option('display.max_colwidth', 400)
pd.set_option('display.float_format', lambda x: '%.3f' % x)

logging.basicConfig(format='%(asctime)-15s %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


from focus_databricks.sage.data_type_utils import *


def get_random_color():
    return "rgb(" + str(np.random.randint(0, 256)) + ", " + str(np.random.randint(0, 256)) + ", " + str(np.random.randint(0, 256)) + ")"


def get_random_matplot_color():
    colors = ['red','green', 'blue', 'orange', 'black', 'yellow']
    return colors[np.random.randint(0, len(colors))]



figSize = (10, 10)

def plotXY(x, y, title="Plot", xlabel='x', ylabel ='y', marker='o', color='r'):
    plt.plot(x,
             y,
             marker=marker,
             color=color,
             markersize=1,
          )
    plt.xlabel(xlabel, fontsize=10)
    plt.ylabel(ylabel, fontsize=10)
    plt.title(title)
    plt.show()

def plotBar(label, y, title="Bar Plot", xlabel= 'x', ylabel='y'):
    index = np.arange(len(label))
    plt.bar(index, y)
    plt.xlabel(xlabel, fontsize=10)
    plt.ylabel(ylabel, fontsize=10)
    plt.xticks(index, label, fontsize=10, rotation=30)
    plt.title(title)
    plt.show()


def plotPairs(df, hue=None):
    sns.pairplot(df, hue=hue, diag_kind='kde')


def plotScatter(df, x, y, title= "Scatter Plot", xlabel= 'x', ylabel='y'):
    df.plot(kind='scatter', x=x, y=y, title=title)
    plt.xlabel(xlabel, fontsize=12)
    plt.ylabel(ylabel, fontsize=12)
    plt.show()


def plotScatterByTarget(df, column1, column2, target, title="Scatter Plot by Class", xlabel= 'x', ylabel='y'):
    if target is None:
        print("Please provide the target variable")
        return
    fig, ax = plt.subplots()
    for c, df in df.groupby(target):
        ax.scatter(df[column1], df[column2], label=c)
    ax.legend()
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)


def plotDensity(df, column, linestyle='dashed'):
    linestyles = linestyle
    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111)
    ax.set_title('Density Distribution')

    ymax = df[column].max()

    df[column].plot(kind="density")

    plt.vlines(df[column].mean(),
               ymin=0,
               ymax=ymax,
               linewidth=2.0,
               linestyles=linestyles,
               label='Mean',
               colors='orange')

    plt.vlines(df[column].median(),
               ymin=0,
               ymax=ymax,
               linewidth=2.0,
               linestyles=linestyles,
               label='Median',
               color="red")

    ax.set_xlabel(str(column))
    ax.set_ylabel('Density')
    ax.legend(loc='best')
    plt.show()


def plotStackedDensity(df, column, target):
    if target is None:
        print("Please provide the target variable")
        return
    fig, ax = plt.subplots()
    for cut in df[target].unique():
        s = df[df[target] == cut][column]
        s.plot.kde(ax=ax, label=cut)
        ax.set_xlabel(str(column))
        ax.set_ylabel('Density')
    ax.legend(loc='best')
    plt.show()


def plotHistogram(df, column, target=None):
    df.hist(column=column, by=target)


def plotWhiskersBoxPlot(df, column, target=None):
    df.boxplot(column=[column], by=target)


def plotCategoricalBarPlot(df, column):
    df.groupby(column).size().plot(kind='bar', title= str(column) + "  Summary", y= str(column))


def plot2CategoricaStackedBar(df, column1, column2):
    df_table = pd.crosstab(df[column1], df[column2])
    df_table.plot(kind="bar",
                 figsize = figSize,
                 stacked=True)


def plotNullValuesAnalysis(df):
    labels = []
    values = []
    percentage_value = []
    print(df.apply(lambda x: sum(x.isnull()), axis=0))
    for col in df.columns:
        labels.append(col)
        values.append(df[col].isnull().sum())
        percentage_value.append(df[col].isnull().sum() / df.shape[0])
    data = [go.Bar(x=values,
                   y=labels,
                   orientation='h',
                   name='Null Values'
                   ),
            go.Bar(x=percentage_value,
                   y=labels,
                   orientation='h',
                   name='percentage of null'
                   )
            ]

    layout = go.Layout(
        barmode='group',
        title='Null Values in Features'
    )
    iplot({
            "data": data,
            "layout": layout
        })
    plt.show()

def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')


def plotConfusionMatrix(y_true, y_pred, true_labels=None, pred_labels=None, title=None, normalized=True):
    skplt.metrics.plot_confusion_matrix(y_true,
                                        y_pred,
                                        true_labels=true_labels,
                                        pred_labels=pred_labels,
                                        title=title,
                                        normalize=normalized)
    plt.show()


def plotPRCurve(y_true, y_pred_proba, title='Precision-Recall Curve'):
    skplt.metrics.plot_precision_recall_curve(y_true,
                                              y_pred_proba,
                                              title=title)
    plt.show()


def plotPR(y_true, y_pred_proba, title='Precision-Recall Curve', plot_micro=True, classes_to_plot=None,):
    skplt.metrics.plot_precision_recall(y_true,
                                        y_pred_proba,
                                        title=title,
                                        plot_micro=plot_micro,
                                        classes_to_plot=classes_to_plot)
    plt.show()


def plotROC(y_true, y_pred_proba, title='ROC Curves', plot_micro=True, plot_macro=True, classes_to_plot=None):
    skplt.metrics.plot_roc(y_true,
                           y_pred_proba,
                           title=title,
                           plot_micro=plot_micro,
                           plot_macro=plot_macro,
                           classes_to_plot=classes_to_plot)
    plt.show()


def plotKSStatistics(y_true, y_pred_proba, title='KS Statistic Plot'):
    skplt.metrics.plot_ks_statistic(y_true,
                                    y_pred_proba,
                                    title=title)
    plt.show()


def plot_elbow_plot(kIdx, K, avgWithinSS):
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.plot(K, avgWithinSS, 'b*-')
    ax.plot(K[kIdx - 1],
            avgWithinSS[kIdx - 1],
            marker='o',
            markersize=12,
            markeredgewidth=2,
            markeredgecolor='r',
            markerfacecolor='None')
    plt.grid(True)
    plt.xlabel('Number of clusters')
    plt.ylabel('Average within-cluster sum of squares')
    plt.title('Elbow for KMeans clustering')
    plt.show()


def plotElbowPlot(kmeans, X, title='Elbow Plot', clusters = range(1, 50), show_cluster_time=True):
    skplt.cluster.plot_elbow_curve(kmeans,
                                   X,
                                   title=title,
                                   cluster_ranges=clusters,
                                   n_jobs=1,
                                   show_cluster_time=show_cluster_time)
    plt.show()


def plotSilhouette(X, cluster_labels, title='Silhouette Analysis', metric='euclidean', copy=True):
    skplt.metrics.plot_silhouette(X,
                                  cluster_labels,
                                  title,
                                  metric,
                                  copy)
    plt.show()


def plotCaliberationCurve(y_true, y_pred_proba_list, classifier_names, n_bins=10, title='Calibration plots (Reliability Curves)'):
    '''rf = RandomForestClassifier()
    lr = LogisticRegression()
    nb = GaussianNB()
    svm = LinearSVC()
    rf_probas = rf.fit(X_train, y_train).predict_proba(X_test)
    lr_probas = lr.fit(X_train, y_train).predict_proba(X_test)
    nb_probas = nb.fit(X_train, y_train).predict_proba(X_test)
    svm_scores = svm.fit(X_train, y_train).decision_function(X_test)
    probas_list = [rf_probas, lr_probas, nb_probas, svm_scores]
    clf_names = ['Random Forest', 'Logistic Regression','Gaussian Naive Bayes', 'Support Vector Machine']'''
    skplt.metrics.plot_calibration_curve(y_true,
                                         y_pred_proba_list,
                                         classifier_names,
                                         n_bins,
                                         title)
    plt.show()


def plotBinaryCumulativeGain(y_true, y_pred_proba, title='Cumulative Gains Curve'):
    skplt.metrics.plot_cumulative_gain(y_true, y_pred_proba, title)
    plt.show()


def plotBinaryLiftCurve(y_true, y_pred_proba, title='Lift Curve'):
    skplt.metrics.plot_lift_curve(y_true, y_pred_proba, title)
    plt.show()


def plotLearningCurve(classifier, X, y, title='Learning Curve', cv=10, shuffle=False, random_state=None,
                      train_sizes=None, n_jobs=1, scoring=None):
    skplt.estimators.plot_learning_curve(classifier,
                                         X,
                                         y,
                                         title,
                                         cv,
                                         shuffle,
                                         random_state,
                                         train_sizes,
                                         n_jobs,
                                         scoring)
    plt.show()


def plot_feature_importances_(classifier, feature_names, title='Feature Importance', max_num_features=20, order='descending'):
    print("Please remember that this function is only for classifiers with feature_importances_ attribute")
    skplt.estimators.plot_feature_importances(classifier, title, feature_names, max_num_features, order)
    plt.show()


def plotCatBoostFeatureImportance(classifier, feature_names, num=30):
    sortx = [x for _, x in
             sorted(zip(classifier.get_feature_importance(fstr_type="FeatureImportance"), feature_names))]
    sorty = sorted(classifier.get_feature_importance(fstr_type="FeatureImportance"))

    ct_feature_importance = go.Bar(x=sortx[num * -1:],
                                   y=sorty[num * -1:],
                                   name='Catboost Feature Importances'
                                   )
    iplot({
        "data": [ct_feature_importance],
        "layout": go.Layout(
            title="Feature Importance   : Top %s Features" % str(num),
            xaxis=dict(title='Features'),
        )
    })
    plt.show()


def plotPCAVariance(pca, title='PCA Component Explained Variances', target_explained_variance=0.75,):
    skplt.decomposition.plot_pca_component_variance(pca, title, target_explained_variance)
    plt.show()


def plot2DProjection(pca, X, y, title='Data 2-D Projection', biplot=False, feature_labels=None):
    skplt.decomposition.plot_pca_2d_projection(pca, X, y, title, biplot, feature_labels)
    plt.show()


def plotWordCloud(wc):
    plt.figure(figsize=(40, 20), facecolor='k')
    plt.axis("off")
    plt.imshow(wc)


def plotInterval(y_mean, y_intervals, actual_mean=None):
    print("Have you run the experiment(t-statistic or z-statistic N times and save mean and confidence intervals into a list and passed it to function?")
    plt.figure(figsize=(10, 10))
    y_mean = convert(y_mean, "list")
    plt.errorbar(x=np.arange(0.1, len(y_mean), 1),
                 y=y_mean,
                 yerr=[(top - bot) / 2 for top, bot in y_intervals],
                 fmt='o')
    if actual_mean is not None:
        plt.hlines(xmin=0, xmax=len(y_mean),
                   y=actual_mean,
                   linewidth=2.0,
                   color="red")
    plt.show()
