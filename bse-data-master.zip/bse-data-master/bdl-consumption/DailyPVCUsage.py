# Databricks notebook source
import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def distributeDailyRevShareDollars(revShareDollars, daysinmonth):
  return revShareDollars/daysinmonth

@udf("double")
def distributeDailyInteractiveDBUs(InteractiveDBUs, daysinmonth):
  return InteractiveDBUs/daysinmonth

@udf("double")
def distributeDailyAutomatedDBUs(AutomatedDBUs, daysinmonth):
  return AutomatedDBUs/daysinmonth

@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  if platform == "azure":
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  return (cumDBDollars > RevShareCommit + 0.999) or (usage_date > endDate)

@udf("double")
def pctBurn(platform, aggOrder, ListCommit, RevShareCommit, cumListDollars, cumRevShareDollars, cumListForecastDollars, cumRevShareForecastDollars):
  pctBurn = 0.0
  if not 'MTM' in aggOrder:
    if platform == 'azure':
      return 0 if ListCommit==0 else ((cumListDollars + cumListForecastDollars) / ListCommit) * 100
    if platform == 'aws':
      return 0 if RevShareCommit==0 else ((cumRevShareDollars + cumRevShareForecastDollars) / RevShareCommit) * 100
  return pctBurn

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"

# COMMAND ----------

backup_pvc = spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc_pvc")
backup_pvc.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/backup_usagec_agg_order_daily_adhoc_pvc")

# COMMAND ----------

pvc_df = spark.sql("""
with pubsec (
select *
from finance.pubsec_usage
),
common_accs (
select distinct f.accountid
from finance.pubsec_usage f
join finance.pvc_usage pvc on f.accountid = pvc.accountid
),

pvc_withoutcommon (
select pvc.*
from finance.pvc_usage pvc
left join common_accs com on pvc.accountId = com.accountId
where com.accountId is null
)

select *
from pvc_withoutcommon
union 
select *
from pubsec
""")

# COMMAND ----------

pvc_df.count()

# COMMAND ----------

dbuCols = ["dbu", "type"]
#pvc_df = spark.sql("select * from finance.pvc_usage ")
pvc_df = pvc_df.withColumnRenamed("accountID", "accountId")\
               .withColumnRenamed("dbuDollars", "revShareDollars")\
               .withColumn("type", lower(col("type")))\
               .withColumn("InteractiveDBUs", coalesce(interactive_dbus(*dbuCols), lit(0)))\
               .withColumn("AutomatedDBUs", coalesce(automated_dbus(*dbuCols), lit(0)))

# COMMAND ----------

display(pvc_df)

# COMMAND ----------

date_df = spark.sql("select date, year, month, daysinmonth from bdw.bi_dates")

# COMMAND ----------

pvc_date = pvc_df.join(date_df, (pvc_df.year==date_df.year) & (pvc_df.month==date_df.month))\
                 .drop(date_df.year)\
                 .drop(date_df.month)

dropColumns = ["ctc_flag", "year", "month", "ownerID", "OwnerName", "region", "l1Segment", "l2Segment", "l3Segment", "platform", "fiscalYear", "fiscalQtr", "type", "dbuPrice", "dbu", "adoptionYear", "adoptionMonth"]
pvc_date = pvc_date.withColumnRenamed("date", "usage_date")\
                   .drop(*dropColumns)

pvc_usage = pvc_date.withColumn("revShareDollars", round(distributeDailyRevShareDollars("revShareDollars", "daysinmonth"),2) )\
                   .withColumn("InteractiveDBUs", round(distributeDailyInteractiveDBUs("InteractiveDBUs", "daysinmonth"),2) )\
                   .withColumn("AutomatedDBUs", round(distributeDailyAutomatedDBUs("AutomatedDBUs", "daysinmonth"),2) )\
                   .drop("daysinmonth")\
                   .withColumn("listDollars", col("RevShareDollars"))\
                   .withColumn("custDollars", col("RevShareDollars"))

orderByColumns = ['accountID','accountName','usage_date']
pvc_usage = pvc_usage.orderBy(*orderByColumns)
pvc_usage.createOrReplaceTempView("pvc_usage")

# COMMAND ----------

pvc_orders = spark.read.format("delta").load("/mnt/bse-dev/bi_aggorders_pvc")
pvc_orders.createOrReplaceTempView("pvc_orders")

# COMMAND ----------

pvc_novl_contracts = spark.sql("""
with pvc_accounts (
select distinct accountId 
from finance.pvc_usage
),
nextAggOrders (
select agg.*,
       coalesce(lead(agg.startDate) over(partition by agg.sfdcAccountID order by agg.startDate), date_add(agg.endDate, 1)) nextStartDate
from pvc_orders agg
join pvc_accounts m on agg.sfdcAccountID == m.accountId
where platform = 'aws'
and agg.aggOrder not like 'MTM%'
order by agg.sfdcAccountID, agg.startDate 
),

cleanAggOrders (
select *,
       case when datediff(nextStartDate, endDate)=1 then 0
            when nextStartDate >= endDate then 0
            else 1
       end as overLapFlag
from nextAggOrders
)

select sfdcAccountID,
       sum(overLapFlag) totalSum
from cleanAggOrders
group by sfdcAccountID
having totalSum = 0
""")
pvc_novl_contracts = pvc_novl_contracts.drop("totalSum")
display(pvc_novl_contracts)

# COMMAND ----------

pvc_orders_granular_query = """
with initial_usage_orders (
select ug.*,
       agg.platform,
       agg.aggOrder,
       agg.SubscriptionID,
       agg.scope,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase ListCommit,
       agg.ActualPartnerCommit DiscountedCommit,
       agg.DBShareCommit RevShareCommit,
       case when count(usage_date) over(partition by accountID, accountName, usage_date, revShareDollars, InteractiveDBUs, AutomatedDBUs) > 1 then 'true'
            else 'false'
       end as usageFlag,
       case when scope = 'shared'  then 'false'
            else 'true'
       end as scopeFlag
from pvc_usage ug
join pvc_orders agg on ug.accountID = agg.sfdcAccountID 
                         and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where agg.platform = 'aws'
order by usage_date
)

select *
from initial_usage_orders
where (usageFlag='true' and scopeFlag='true') or (usageFlag='false' and scopeFlag='false')
order by usage_date
"""

pvc_orders_granular_df = spark.sql(pvc_orders_granular_query)
dropColumns = ["usageFlag", "scopeFlag"]
pvc_orders_granular_df = pvc_orders_granular_df.drop(*dropColumns)

# COMMAND ----------

pvc_orders_granular_df.createOrReplaceTempView("pvc_orders_combined")

# COMMAND ----------

pvc_orders_granular_df.join(pvc_novl_contracts, pvc_orders_granular_df.accountId==pvc_novl_contracts.sfdcAccountID).count()

# COMMAND ----------

clean_pvc_usage = spark.sql("""
with ranked_orders(
select *,
       row_number() over(partition by accountID, accountName, usage_date, revShareDollars, InteractiveDBUs, AutomatedDBUs, scope order by startDate) rno
from pvc_orders_combined
)
select *
from ranked_orders
where rno = 1
""")
clean_pvc_usage = clean_pvc_usage.drop(clean_pvc_usage.rno)

# COMMAND ----------

orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

# apmoller = prod_daily.filter( (prod_daily.platform=='azure') & (prod_daily.accountID=='0016100001G26HxAAJ')).orderBy(*orderByColumns) 
# apmoller = prod_daily.filter( (prod_daily.platform=='aws') & (prod_daily.accountID=='0016100001IuqSSAAZ')).orderBy(*orderByColumns)

clean_pvc_usage = clean_pvc_usage.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                       .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                       .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                       .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                       .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2)) 

burstColumns = ["cumListDollars", "listCommit", "endDate", "usage_date", "cumDBDollars", "RevShareCommit", "platform"]
clean_pvc_usage = clean_pvc_usage.withColumn("IsBurst", isBurst(*burstColumns))

# COMMAND ----------

clean_pvc_usage.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_prod_daily_intermediate")

# COMMAND ----------

dropColumns = ['cumListDollars', 'cumCustDollars', 'cumDBDollars', 'cumInteractiveDBUs', 'cumAutomatedDBUs', 'IsBurst']
clean_pvc_usage_updated = spark.sql("select * from bdw.usagec_prod_daily_intermediate")\
                        .drop(*dropColumns)

clean_pvc_usage_updated = clean_pvc_usage_updated.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                 .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                 .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                 .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                 .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))

# COMMAND ----------

groupbyColumnsWithoutSKU = ["accountId", "accountName", "platform", "aggOrder", "usage_date", "ListCommit","DiscountedCommit", "RevShareCommit"]

clean_pvc_updated_withoutSKU = clean_pvc_usage_updated.groupBy(*groupbyColumnsWithoutSKU)\
                                              .agg(\
                                                    round(sum("listDollars"),4).alias("listDollars"),\
                                                    round(sum("custDollars"),4).alias("custDollars"),\
                                                    round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                    round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                    round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs")                                                                   
                                               )

orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)


clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                           .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                           .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                           .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                           .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2)) 

clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumnRenamed("cumDBDollars", "cumRevShareDollars")
clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumn("consumptionType", consumptionType("aggOrder"))

# COMMAND ----------

# change: added _intermediate to the location
clean_pvc_updated_withoutSKU.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_agg_order_daily_adhoc_pvc_intermediate")

# COMMAND ----------

# DBTITLE 1,Adhoc Delta Add
clean_pvc_usage_updated = spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc_pvc_intermediate")
clean_pvc_usage_updated = clean_pvc_usage_updated.drop("cumListDollars", "cumCustDollars", "cumRevShareDollars", "cumInteractiveDBUs", "cumAutomatedDBUs", 
                                                       "cumDeltaRevShareDollars", "cumDeltaInteractiveDBUs", "cumDeltaAutomatedDBUs","consumptionType")

# COMMAND ----------

clean_pvc_updated_withoutSKU = clean_pvc_usage_updated.withColumn("DeltaRevShareDollars", lit(0.0))\
                                                      .withColumn("DeltaInteractiveDBUs", lit(0.0))\
                                                      .withColumn("DeltaAutomatedDBUs", lit(0.0))\
                                                      .withColumn("SQLAnalyticsDBUs", lit(0.0))\
                                                      .withColumn("SQLRevShareDollars", lit(0.0))\
                                                      .withColumn("StandardDBUs", lit(0.0))\
                                                      .withColumn("PremiumDBUs", lit(0.0))\
                                                      .withColumn("StandardDBUs", lit(0.0))\
                                                      .withColumn("EnterpriseDBUs", lit(0.0))\
                                                      .withColumn("StandardRevShareDollars", lit(0.0))\
                                                      .withColumn("PremiumRevShareDollars", lit(0.0))\
                                                      .withColumn("EnterpriseRevShareDollars", lit(0.0))\
                                                      .withColumn("MoonCakeDBUs", lit(0.0))\
                                                      .withColumn("MoonCakeDeltaDBUs", lit(0.0))\
                                                      .withColumn("MoonCakeDBUDollars", lit(0.0))\
                                                      .withColumn("MoonCakeDeltaDBUDollars", lit(0.0))

orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)


clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                           .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                           .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                           .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                           .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                           .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                           .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                           .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                           .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                           .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumnRenamed("cumDBDollars", "cumRevShareDollars")
clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumn("consumptionType", consumptionType("aggOrder"))

# COMMAND ----------

print(clean_pvc_updated_withoutSKU.count()) 
clean_pvc_updated_withoutSKU.createOrReplaceTempView("pvc_daily")

# COMMAND ----------

clean_pvc_updated_withoutSKU.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_agg_order_daily_adhoc_pvc")

# COMMAND ----------

# MAGIC %sql
# MAGIC select fiscalYear, fiscalQuarter,
# MAGIC        sum(revShareDollars)
# MAGIC from pvc_daily pvc
# MAGIC join bdw.bi_dates dt on pvc.usage_date = dt.date 
# MAGIC where dt.fiscalYear >= 2021
# MAGIC group by 1,2
# MAGIC order by 1 desc, 2 

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))