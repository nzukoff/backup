# Databricks notebook source
import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

#todo : update burst
@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def sql_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType in ('SQL', 'virtual') else 0

@udf("double")
def sql_dollars(dbu_quantity, skuType, dbuRevSharePrice):
  if dbuRevSharePrice is None:
    return 0.0
  return (dbu_quantity * dbuRevSharePrice) if skuType in ('SQL', 'virtual') else 0.0

# @udf("boolean")
# def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  

#   if platform == "azure":
#       return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
#   isBurst = False  
#   if platform == 'aws':
#     if (cumDBDollars > RevShareCommit + 0.999):
#       if (usage_date > endDate):
#         isBurst = True
#     else:
#       if (usage_date > endDate):
#         isBurst = True
#   return isBurst

@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  if platform == "azure":
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  return (usage_date > endDate)

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"

@udf("string")
def forecastType(subscriptionId, contract_type):
  forecastType = 'MTM'
  if subscriptionId == 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = "SharedCommit"
  if subscriptionId != 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = 'SingleCommit'
  
  return forecastType

@udf("string")
def entitlementTier(usage_sku):
  
  entitlementTier = "NA"
  if "enterprise" in usage_sku:
    entitlementTier = "Enterprise"
  elif "premium" in usage_sku:
    entitlementTier = "Premium"
  else:
    entitlementTier = "Standard"
  
  return entitlementTier

@udf("double")
def standardDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Standard" else 0.0

@udf("double")
def premiumDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Premium" else 0.0  

@udf("double")
def enterpriseDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Enterprise" else 0.0  

@udf("double")
def moonCakeDBUs(deployedRegion, dbu_quantity):
  if deployedRegion is None:
    return 0.0
  return dbu_quantity if 'china' in deployedRegion else 0.0

@udf("double")
def moonCakeDeltaDBUs(deployedRegion, delta_dbu_quantity):
  if deployedRegion is None:
    return 0.0
  return delta_dbu_quantity if 'china' in deployedRegion else 0.0

# COMMAND ----------

#todo: mapping columns names to the original RI report/ AWS commits (Sandeep suggestion)
#issue-tracker: for unit testing
#announce tables on slack
#pvc usage into granular-data

# COMMAND ----------

# note: /mnt/bse-dev/usagec_prod_daily_granular_adhoc --> unprocessed aws usage
prod_daily = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_granular")
# prod_daily = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_granular_adhoc")
dates_df = spark.sql("select * from bdw.bi_dates")
product_df = spark.sql("""
select distinct meterSubCategory skuType, 
                meterName 
from bdw.bi_product_dim 
where meterCategory = 'workloads'
and meterSubCategory in ('automated', 'interactive')

union 

select distinct meterSubCategory skuType, 
                meterName 
from bdw.bi_product_dim 
where meterCategory = 'workloads'
and meterSubCategory not in ('automated', 'interactive')
and meterName like '%sql%'
""")


prod_daily = prod_daily.withColumn("dbuRevSharePrice", col("dbuRevSharePrice").cast("double"))


# COMMAND ----------

#prod_daily.cache()
# product_df.cache()
# dates_df.cache()
prod_daily.count()

# COMMAND ----------

# add month, dollars
prod_daily = prod_daily.withColumn("month", date_format(prod_daily.usage_date, 'yyyy-MM'))\
                       .withColumn("listDollars", round(col("listPrice")*col("dbu_quantity"), 6))\
                       .withColumn("custDollars", round(col("dbuCustPrice")*col("dbu_quantity"), 6))\
                       .withColumn("revShareDollars", round(col("dbuRevSharePrice")*col("dbu_quantity"), 6))\
                       .withColumn("DeltaRevShareDollars", round(col("dbuRevSharePrice")*col("delta_dbu_quantity"), 6))

prod_daily = prod_daily.withColumnRenamed("cloudPartnerPurchase", "ListCommit")\
                       .withColumnRenamed("ActualPartnerCommit", "DiscountedCommit")\
                       .withColumnRenamed("DBShareCommit", "RevShareCommit")

# COMMAND ----------

# add sku-type
prod_daily = prod_daily.join(product_df, prod_daily.usage_sku == product_df.meterName)\
                       .drop(product_df.meterName)

# add interactive/automated dbus
prod_daily = prod_daily.withColumn("InteractiveDBUs", coalesce(interactive_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("AutomatedDBUs", coalesce(automated_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaInteractiveDBUs", coalesce(interactive_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaAutomatedDBUs", coalesce(automated_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLAnalyticsDBUs", coalesce(sql_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLRevShareDollars", round(sql_dollars("dbu_quantity", "skuType", "dbuRevSharePrice"), 6))\
                       .withColumn("EntitlementTier", entitlementTier("usage_sku"))\
                       .withColumn("StandardDBUs", standardDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("PremiumDBUs", premiumDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("EnterpriseDBUs", enterpriseDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("StandardRevShareDollars", round(col("dbuRevSharePrice")*col("StandardDBUs"), 6))\
                       .withColumn("PremiumRevShareDollars", round(col("dbuRevSharePrice")*col("PremiumDBUs"), 6))\
                       .withColumn("EnterpriseRevShareDollars", round(col("dbuRevSharePrice")*col("EnterpriseDBUs"), 6))

prod_daily = prod_daily.withColumn("MoonCakeDBUs", moonCakeDBUs("deployedRegion", "dbu_quantity"))\
                       .withColumn("MoonCakeDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDBUs"), 6))\
                       .withColumn("MoonCakeDeltaDBUs", moonCakeDeltaDBUs("deployedRegion", "delta_dbu_quantity"))\
                       .withColumn("MoonCakeDeltaDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDeltaDBUs"), 6))

# COMMAND ----------

prod_daily.count()

# COMMAND ----------

dateSelectColumns = ["date", "isMonthEnd", "year_month"]
datesFiltered = dates_df.select(*dateSelectColumns)\
                        .filter(dates_df.isMonthEnd==1)\
                        .drop(dates_df.isMonthEnd)\
                        .withColumnRenamed("date", "month_end_date")


prod_daily = prod_daily.join(datesFiltered, prod_daily.month==datesFiltered.year_month)\
                                      .drop(datesFiltered.year_month)

prod_daily = prod_daily.drop(prod_daily.month)

# COMMAND ----------

orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]

# COMMAND ----------

rowAzureAccounts = spark.sql("select sfdcAccountId, collect_set(scope) scope from bdw.bi_aggorders where platform = 'azure' and scope!= 'shared' group by 1").collect()

from collections import defaultdict
account_map = {}
account_list = defaultdict(list)
for row in rowAzureAccounts:
  if row.sfdcAccountId not in account_map and row.sfdcAccountId is not None:
    account_map[row.sfdcAccountId] = row.scope
    scope = ''.join(row.scope)
    account_list[scope].append(row.sfdcAccountId)
  else:
    print("duplicate", row.sfdcAccountId)

# COMMAND ----------

def run_notebook(notebook_name):
  try:
    return dbutils.notebook.run(notebook_name, 3600)
  except Exception as e:
    raise e

# COMMAND ----------

def getAzureUpdateQuery(accountId, aggOrder):
    return """
    update bdw.usagec_prod_daily_intermediate 
    set aggOrder = 'MTMAzure{0}',
        ListCommit = 0,
        DiscountedCommit = 0,
        RevShareCommit = 0,
        Scope = 'shared'
    where isBurst = 1
    and aggOrder = "{1}"
    """.format(accountId, aggOrder)
  
def getSharedAWSUpdateQuery(accountId, aggOrder):
    return """
    update bdw.usagec_prod_daily_intermediate 
    set aggOrder = 'MTMAWS{0}',
        ListCommit = 0,
        DiscountedCommit = 0,
        RevShareCommit = 0,
        Scope = 'shared'
    where isBurst = 1
    and aggOrder = "{1}"
    """.format(accountId, aggOrder)


def write_to_daily_intermediate(apmoller):
  
    # optimize dynamically
    # todo: change cumDBDollars to cumRevShareDollars
    orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
    partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
    usage_window = Window.partitionBy(*partitionByColumns)\
                         .orderBy("usage_date")\
                         .rowsBetween(Window.unboundedPreceding, Window.currentRow)

    apmoller = apmoller.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                       .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                       .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                       .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                       .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                       .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                       .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                       .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                       .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                       .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

    burstColumns = ["cumListDollars", "listCommit", "endDate", "usage_date", "cumDBDollars", "RevShareCommit", "platform"]
    apmoller = apmoller.withColumn("IsBurst", isBurst(*burstColumns))
    
    write_mode = "overwrite"
    apmoller.write.option("overwriteSchema", "true").format("delta").mode(write_mode).save("/mnt/bse-dev/usagec_prod_daily_intermediate")
    
    
def write_to_adhoc_daily(write_mode):
  
  dropColumns = ['cumListDollars', 'cumCustDollars', 'cumDBDollars', 'cumInteractiveDBUs', 'cumAutomatedDBUs', 'IsBurst']
  apmoller_updated = spark.sql("select * from bdw.usagec_prod_daily_intermediate")\
                          .drop(*dropColumns)

  orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
  partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]

  usage_window = Window.partitionBy(*partitionByColumns)\
                       .orderBy("usage_date")\
                       .rowsBetween(Window.unboundedPreceding, Window.currentRow)

  apmoller_updated = apmoller_updated.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                     .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                     .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                     .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                     .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                     .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                     .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                     .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                     .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                     .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))
  

  groupbyColumnsWithoutSKU = ["accountId", "accountName", "platform", "aggOrder", "usage_date", "ListCommit","DiscountedCommit", "RevShareCommit"]

  apmoller_updated_withoutSKU = apmoller_updated.groupBy(*groupbyColumnsWithoutSKU)\
                                                .agg(\
                                                      round(sum("listDollars"),4).alias("listDollars"),\
                                                      round(sum("custDollars"),4).alias("custDollars"),\
                                                      round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                      round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                      round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                      round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                      round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                      round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                      round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                      round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                      round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                      round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                      round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                      round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                      round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                      round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                      round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                      round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                      round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                      round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars")                                   
                                                    )


  apmoller_updated_withoutSKU = apmoller_updated_withoutSKU.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                           .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                           .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                           .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                           .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                           .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                           .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                           .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                           .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                           .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

  apmoller_updated_withoutSKU = apmoller_updated_withoutSKU.withColumnRenamed("cumDBDollars", "cumRevShareDollars")
  apmoller_updated_withoutSKU = apmoller_updated_withoutSKU.withColumn("consumptionType", consumptionType("aggOrder"))
  
  apmoller_updated.write.option("overwriteSchema", "true").format("delta").mode(write_mode).save("/mnt/bse-dev/usagec_prod_daily_modified_adhoc")
  apmoller_updated_withoutSKU.write.option("overwriteSchema", "true").format("delta").mode(write_mode).save("/mnt/bse-dev/usagec_agg_order_daily_adhoc")

# COMMAND ----------

# DBTITLE 1,Multi Shared 
multi_shared_accounts_df = spark.sql("""
select sfdcAccountID,
       count(aggOrder) cnt
from bdw.bi_aggorders
where platform = "azure"
and scope = "Shared"
group by 1
having cnt > 1
order by 2 desc
""")
multi_shared_accounts_df = multi_shared_accounts_df.drop('cnt')

apmoller = prod_daily.filter(prod_daily.platform=='azure')\
                     .join(multi_shared_accounts_df, prod_daily.accountID==multi_shared_accounts_df.sfdcAccountID)\
                     .drop(multi_shared_accounts_df.sfdcAccountID)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)

# COMMAND ----------

apmoller.select("accountID").distinct().count()

# COMMAND ----------

queries = ["""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100001BMXgcAAH',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-03-28',
    endDate = '2023-03-07'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001BMXgcAAH-2019-12-28'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100001ceMOHAA2-2020-07-10',
    ListCommit = 500000,
    DiscountedCommit = 400000,
    RevShareCommit = 340000,
    startDate = '2020-07-10',
    endDate = '2020-07-11',
    Scope = 'Shared'
where isBurst = 1
and usage_date > "2020-07-13"
and aggOrder = 'SharedAzure-0016100001ceMOHAA2-2019-12-30'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100001SRebmAAD',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-05-29',
    endDate = '2023-05-28'
where isBurst = 1
and usage_date < "2020-07-06"
and aggOrder = 'SharedAzure-0016100001SRebmAAD-2019-12-03'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100001SRebmAAD-2020-07-06',
    ListCommit = 50000,
    DiscountedCommit = 46000,
    RevShareCommit = 39100,
    startDate = '2020-07-10',
    endDate = '2020-07-11',
    Scope = 'Shared'
where isBurst = 1
and usage_date >= "2020-07-06"
and aggOrder = 'SharedAzure-0016100001SRebmAAD-2019-12-03'
""",


"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100001D4VoPAAV',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-01-31',
    endDate = '2023-01-30'
where isBurst = 1
and usage_date < "2020-05-06"
and aggOrder = 'SharedAzure-0016100001D4VoPAAV-2019-12-12'
""",


"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100001D4VoPAAV-2020-05-06',
    ListCommit = 2000000,
    DiscountedCommit = 1340000,
    RevShareCommit = 1139000,
    startDate = '2020-05-06',
    endDate = '2021-05-06',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001D4VoPAAV-2019-12-12'
""",


"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100000U5DvcAAF-2020-07-13',
    ListCommit = 1000000,
    DiscountedCommit = 730000,
    RevShareCommit = 620500,
    startDate = '2020-07-13',
    endDate = '2021-07-13',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100000U5DvcAAF-2019-12-27'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0014N00001g7s1AQAQ',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2019-04-23',
    endDate = '2024-04-21'
where isBurst = 1
and usage_date < "2020-03-31"
and aggOrder = 'SharedAzure-0014N00001g7s1AQAQ-2019-09-30'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0014N00001g7s1AQAQ-2020-03-31',
    ListCommit = 100000,
    DiscountedCommit = 89000,
    RevShareCommit = 75650,
    startDate = '2020-03-31',
    endDate = '2021-03-31',
    Scope = 'Shared'
where isBurst = 1
and usage_date >= "2020-03-31"
and aggOrder = 'SharedAzure-0014N00001g7s1AQAQ-2019-09-30'
""",


"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100000U5DrkAAF',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-09-20',
    endDate = '2023-09-19'
where isBurst = 1
and usage_date < "2020-06-01"
and aggOrder = 'SharedAzure-0016100000U5DrkAAF-2019-12-27'
""",
"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100000U5DrkAAF-2020-06-01',
    ListCommit = 350000,
    DiscountedCommit = 287000,
    RevShareCommit = 243950,
    startDate = '2020-06-01',
    endDate = '2021-06-01',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100000U5DrkAAF-2019-12-27'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100001Qcv5IAAR',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-11-16',
    endDate = '2023-09-19'
where isBurst = 1
and usage_date < "2020-06-03"
and aggOrder = 'SharedAzure-0016100001Qcv5IAAR-2019-11-28'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100001Qcv5IAAR-2020-06-03',
    ListCommit = 500000,
    DiscountedCommit = 400000,
    RevShareCommit = 340000,
    startDate = '2020-06-03',
    endDate = '2021-06-03',
    Scope = 'Shared'
where isBurst = 1
and usage_date >= "2020-06-03"
and aggOrder = 'SharedAzure-0016100001Qcv5IAAR-2019-11-28'
""",
"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100001cgIbvAAE',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-07-26',
    endDate = '2023-07-25'
where isBurst = 1
and usage_date < "2020-05-29"
and aggOrder = 'SharedAzure-0016100001cgIbvAAE-2019-12-16'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100001cgIbvAAE-2020-05-29',
    ListCommit = 100000,
    DiscountedCommit = 89000,
    RevShareCommit = 75650,
    startDate = '2020-05-29',
    endDate = '2021-05-29',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001cgIbvAAE-2019-12-16'
""",
"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure00161000014ranaAAA',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-07-26',
    endDate = '2023-07-25'
where isBurst = 1
and usage_date < "2020-08-19"
and aggOrder = 'SharedAzure-00161000014ranaAAA-2019-08-23'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-00161000014ranaAAA-2020-08-19',
    ListCommit = 200000,
    DiscountedCommit = 172000,
    RevShareCommit = 146200,
    startDate = '2020-08-19',
    endDate = '2021-08-19',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-00161000014ranaAAA-2019-08-23'
""",


"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0014N00001g8CvNQAU',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2019-06-06',
    endDate = '2024-06-04'
where isBurst = 1
and usage_date < "2020-09-03"
and aggOrder = 'SharedAzure-0014N00001g8CvNQAU-2020-02-19'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0014N00001g8CvNQAU-2020-09-03',
    ListCommit = 100000,
    DiscountedCommit = 89000,
    RevShareCommit = 75650,
    startDate = '2020-09-03',
    endDate = '2021-09-03',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0014N00001g8CvNQAU-2020-02-19'
""",


"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100000QKkOoAAL-2019-12-11',
    ListCommit = 2000000,
    DiscountedCommit = 1340000,
    RevShareCommit = 1139000,
    startDate = '2019-12-11',
    endDate = '2020-12-10',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SingleAzure-3e6a222a-e9a4-4a3a-bc52-ee646e2dcffd-2020-03-31'
""",
           
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100000QKkOoAAL-2020-05-22',
    ListCommit = 2000000,
    DiscountedCommit = 1340000,
    RevShareCommit = 1139000,
    startDate = '2019-12-11',
    endDate = '2020-12-10',
    Scope = 'Shared'
where isBurst = 1
and usage_date >= '2020-09-17'
and aggOrder = 'SharedAzure-0016100000QKkOoAAL-2019-12-11'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100000RsHsgAAF-2020-05-29',
    ListCommit = 4000000,
    DiscountedCommit = 2680000,
    RevShareCommit = 2278000,
    startDate = '2020-05-29',
    endDate = '2021-05-29',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100000RsHsgAAF-2019-07-30'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100001BIyGXAA1',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2019-06-03',
    endDate = '2024-06-01'
where isBurst = 1
and usage_date < "2020-03-31"
and aggOrder = 'SharedAzure-0016100001BIyGXAA1-2019-12-27'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100001BIyGXAA1-2020-03-31',
    ListCommit = 1500000,
    DiscountedCommit = 1050000,
    RevShareCommit = 892500,
    startDate = '2020-03-31',
    endDate = '2021-03-31',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001BIyGXAA1-2019-12-27'
""",

"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100001BIyGXAA1-2020-06-26',
    ListCommit = 5000000,
    DiscountedCommit = 3149994,
    RevShareCommit = 2677496,
    startDate = '2020-06-26',
    endDate = '2021-06-26',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001BIyGXAA1-2020-03-31'
and usage_date > "2020-06-26"
""",
"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0014N00001iqqJLQAY',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-09-19',
    endDate = '2023-09-19'
where isBurst = 1
and usage_date < "2020-09-14"
and aggOrder = 'SharedAzure-0014N00001iqqJLQAY-2020-03-13'
""", 
            
"""update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0014N00001iqqJLQAY-2020-09-14',
    ListCommit = 100000,
    DiscountedCommit = 89000,
    RevShareCommit = 75650,
    startDate = '2020-09-14',
    endDate = '2021-09-13',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-0014N00001iqqJLQAY-2020-03-13'
and usage_date >= "2020-09-14"
""",
            
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure00161000005eOkTAAU',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-02-07',
    endDate = '2023-02-06'
where isBurst = 1
and usage_date < "2020-09-25"
and aggOrder = 'SharedAzure-00161000005eOkTAAU-2019-10-29'
""",
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-00161000005eOkTAAU-2020-09-25',
    ListCommit = 2500000,
    DiscountedCommit = 1675000,
    RevShareCommit = 1423750,
    startDate = '2020-09-25',
    endDate = '2021-09-24',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-00161000005eOkTAAU-2019-10-29'
and usage_date >= "2020-09-25"
""",

"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100000U5DryAAF',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-04-11',
    endDate = '2023-04-10'
where isBurst = 1
and usage_date < "2020-09-25"
and aggOrder = 'SharedAzure-0016100000U5DryAAF-2019-09-27'
""",
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100000U5DryAAF-2020-09-25',
    ListCommit = 500000,
    DiscountedCommit = 400000,
    RevShareCommit = 340000,
    startDate = '2020-09-25',
    endDate = '2021-09-24',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-0016100000U5DryAAF-2019-09-27'
and usage_date >= "2020-09-25"
""",

"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100000U5DtuAAF',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2019-07-24',
    endDate = '2024-07-22'
where isBurst = 1
and usage_date < "2020-09-28"
and aggOrder = 'SharedAzure-0016100000U5DtuAAF-2019-09-27'
""",
            
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100000U5DtuAAF-2020-09-28',
    ListCommit = 500000,
    DiscountedCommit = 328000,
    RevShareCommit = 278800,
    startDate = '2020-09-28',
    endDate = '2021-09-27',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-0016100000U5DtuAAF-2019-09-27'
and usage_date >= "2020-09-28"
""",

"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100000U5DuHAAV',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-05-30',
    endDate = '2023-05-29'
where isBurst = 1
and usage_date < "2020-09-25"
and aggOrder = 'SharedAzure-0016100000U5DuHAAV-2019-12-20'
""",
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100000U5DuHAAV-2020-09-25',
    ListCommit = 400000,
    DiscountedCommit = 333000,
    RevShareCommit = 283050,
    startDate = '2020-09-25',
    endDate = '2021-09-24',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100000U5DuHAAV-2019-12-20'
and usage_date >= "2020-09-25"
""",
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100001BKwEqAAL',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-07-20',
    endDate = '2023-07-19'
where isBurst = 1
and usage_date < "2020-09-28"
and aggOrder = 'SharedAzure-0016100001BKwEqAAL-2019-09-30'
""",
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100001BKwEqAAL-2020-09-28',
    ListCommit = 350000,
    DiscountedCommit = 287000,
    RevShareCommit = 243950,
    startDate = '2020-09-28',
    endDate = '2021-09-27',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-0016100001BKwEqAAL-2019-09-30'
and usage_date >= "2020-09-28"
""",
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100001XnYhuAAF',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-10-24',
    endDate = '2023-10-23'
where isBurst = 1
and usage_date < "2020-09-28"
and aggOrder = 'SharedAzure-0016100001XnYhuAAF-2019-09-17'
""",
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SharedAzure-0016100001XnYhuAAF-2020-09-28',
    ListCommit = 350000,
    DiscountedCommit = 287000,
    RevShareCommit = 243950,
    startDate = '2020-09-28',
    endDate = '2021-09-27',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-0016100001XnYhuAAF-2019-09-17'
and usage_date >= "2020-09-28"
"""
] 

# COMMAND ----------

for query in queries:
  spark.sql(query)

# COMMAND ----------

write_to_adhoc_daily("overwrite")

# COMMAND ----------

print(spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").count())
print(spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").count())

# COMMAND ----------

# DBTITLE 1,Shared 1
rowsprocessed = spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").select("accountId").distinct().collect()
azureaccountsProcessed = [row.accountId for row in rowsprocessed]
# azure shared only
shared_only = set(account_list['Shared']).difference(set(azureaccountsProcessed))
shared_only_query = """
select distinct sfdcAccountId
from bdw.bi_aggorders
where platform = 'azure'
and sfdcAccountId in {0}""".format(tuple(shared_only))
shared_accounts_df = spark.sql(shared_only_query)

apmoller = prod_daily.filter(prod_daily.platform=='azure')\
                     .join(shared_accounts_df, prod_daily.accountID==shared_accounts_df.sfdcAccountId)\
                     .drop(shared_accounts_df.sfdcAccountId)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)

# COMMAND ----------

spark.sql("select distinct accountId from bdw.usagec_prod_daily_intermediate").count()

# COMMAND ----------

sharedAccountsBurstRows = spark.sql("select distinct accountId, aggOrder from bdw.usagec_prod_daily_intermediate where isBurst = 1 and aggOrder not like 'MTMAzure%'").collect()
for row in sharedAccountsBurstRows:
  print("processing...", row.accountId)
  updateQuery = getAzureUpdateQuery(row.accountId, row.aggOrder)
  spark.sql(updateQuery)

# COMMAND ----------

write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").count())
print(spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").count())

# COMMAND ----------

# DBTITLE 1,Single
rowsprocessed = spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").select("accountId").distinct().collect()
azureaccountsProcessed = [row.accountId for row in rowsprocessed]
# azure single only
parallel_exclude = ['0016100000cF2TtAAK']
single_only = set(account_list['Single']).difference(set(azureaccountsProcessed + parallel_exclude))
single_only_query = """
select distinct sfdcAccountId
from bdw.bi_aggorders
where platform = 'azure'
and sfdcAccountId in {0}""".format(tuple(single_only))
single_only_df = spark.sql(single_only_query)

apmoller = prod_daily.filter(prod_daily.platform=='azure')\
                     .join(single_only_df, prod_daily.accountID==single_only_df.sfdcAccountId)\
                     .drop(single_only_df.sfdcAccountId)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)

# COMMAND ----------

sharedAccountsBurstRows = spark.sql("select distinct accountId, aggOrder from bdw.usagec_prod_daily_intermediate where isBurst = 1 and aggOrder not like 'MTMAzure%'").collect()
for row in sharedAccountsBurstRows:
  print("processing...", row.accountId)
  updateQuery = getAzureUpdateQuery(row.accountId, row.aggOrder)
  spark.sql(updateQuery)

# COMMAND ----------

write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").count())
print(spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").count())

# COMMAND ----------

# DBTITLE 1,Shared-Single
#len(account_list['Single'] + account_list['SharedSingle'] + account_list['Shared'])
#shared_single_only
rowsprocessed = spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").select("accountId").distinct().collect()
azureaccountsProcessed = [row.accountId for row in rowsprocessed]

parallel_exclude = ['0016100000cF2TtAAK']
shared_single_only = set(account_list['SharedSingle'] + parallel_exclude).difference(set(azureaccountsProcessed))
print(shared_single_only)

shared_single_only_query = """
select distinct sfdcAccountId
from bdw.bi_aggorders
where platform = 'azure'
and sfdcAccountId in {0}""".format(tuple(shared_single_only))

shared_single_only_df = spark.sql(shared_single_only_query)

apmoller = prod_daily.filter(prod_daily.platform=='azure')\
                     .join(shared_single_only_df, prod_daily.accountID==shared_single_only_df.sfdcAccountId)\
                     .drop(shared_single_only_df.sfdcAccountId)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)
# '0016100000cF2TtAAK', '00161000019RwocAAC', '0016100000ZbzS9AAJ', '0016100000VnnNnAAJ', '0016100001TPfNIAA1', '0016100001BMXgcAAH'

# COMMAND ----------

# DBTITLE 1,queries
import time
queries2 = [
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100000ZbzS9AAJ',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-01-03',
    endDate = '2023-01-02'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100000ZbzS9AAJ-2020-05-01'
""",
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SingleAzure-0f30bd24-665b-44a2-96c7-15d3322c3ab6-2020-09-23',
    ListCommit = 150000,
    DiscountedCommit = 128250,
    RevShareCommit = 109013,
    startDate = '2020-09-23',
    endDate = '2021-09-22',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001TPfNIAA1-2020-03-09'
""",
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100001BMXgcAAH',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-03-28',
    endDate = '2023-03-07'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001BMXgcAAH-2019-12-28'
""",
  
"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'MTMAzure0016100000cF2TtAAK',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-04-27',
    endDate = '2023-04-26'
where isBurst = 1
and aggOrder = 'SingleAzure-45c1c272-b31e-4c6b-a4ef-22dc7ccdbb73-2019-12-18'
and usage_date < "2020-05-07"
""",

"""
update bdw.usagec_prod_daily_intermediate 
set aggOrder = 'SingleAzure-45c1c272-b31e-4c6b-a4ef-22dc7ccdbb73-2020-05-07',
    ListCommit = 25000,
    DiscountedCommit = 23500,
    RevShareCommit = 19975,
    startDate = '2020-05-07',
    endDate = '2021-05-07'
where isBurst = 1
and aggOrder = 'SingleAzure-45c1c272-b31e-4c6b-a4ef-22dc7ccdbb73-2019-12-18'
"""
]

for query in queries2:
  spark.sql(query)
  time.sleep(10)

# COMMAND ----------

write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").count())
print(spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").count())

# COMMAND ----------

# DBTITLE 1,MTM
mtm_accounts_df = spark.sql("""
select sfdcAccountID,
       count(aggOrder) cnt
from bdw.bi_aggorders
where platform = "azure"
and scope in ("Shared", "shared", "Single")
and sfdcAccountID is not null
group by 1
having cnt = 1
order by 2 desc
""")
mtm_accounts_df = mtm_accounts_df.drop("cnt")
mtm_accounts = [row.sfdcAccountID for row in mtm_accounts_df.select("sfdcAccountID").distinct().collect()]

only_mtm_accounts = set(mtm_accounts).difference(set(account_list['Single'] + account_list['SharedSingle'] + account_list['Shared']))
print(len(only_mtm_accounts))

only_mtm_accounts_query = """
select distinct sfdcAccountId
from bdw.bi_aggorders
where platform = 'azure'
and sfdcAccountId in {0}""".format(tuple(only_mtm_accounts))
only_mtm_accounts = spark.sql(only_mtm_accounts_query)

apmoller = prod_daily.filter(prod_daily.platform=='azure')\
                     .join(only_mtm_accounts, prod_daily.accountID==only_mtm_accounts.sfdcAccountId)\
                     .drop(only_mtm_accounts.sfdcAccountId)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)
write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").count())
print(spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").count())

# COMMAND ----------

# DBTITLE 1,AWS novl
# done: change the join
processed = spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc")
uploaded_accounts = processed.filter(processed.platform == 'aws').select("accountId").distinct()
#spark.sql("select distinct accountId from bdw.usagec_aggorder_daily where platform = 'aws'")

# non overlapping consecutive contracts - aws
aws_novl_contracts = spark.sql("""
with aws_accounts_morethan1 (

select sfdcAccountID,
       count(aggOrder) cnt
from bdw.bi_aggorders
where platform = "aws"
and scope in ("aws-defined")
group by 1
order by 2 desc

),
nextAggOrders (
select agg.*,
       coalesce(lead(agg.startDate) over(partition by agg.sfdcAccountID order by agg.startDate), date_add(agg.endDate, 1)) nextStartDate
from bdw.bi_aggorders agg
join aws_accounts_morethan1 m on agg.sfdcAccountID == m.sfdcAccountID
where platform = 'aws'
and agg.aggOrder not like 'MTM%'
order by agg.sfdcAccountID, agg.startDate 
),

cleanAggOrders (
select *,
       case when datediff(nextStartDate, endDate)=1 then 0
            when nextStartDate > endDate then 0
            else 1
       end as overLapFlag
from nextAggOrders
)

select sfdcAccountID,
       sum(overLapFlag) totalSum
from cleanAggOrders
group by sfdcAccountID
having totalSum = 0
""")
aws_novl_contracts = aws_novl_contracts.drop("totalSum")
aws_novl_contracts = aws_novl_contracts.join(uploaded_accounts, aws_novl_contracts.sfdcAccountID==uploaded_accounts.accountId, 'left')\
                             .filter(uploaded_accounts.accountId.isNull())\
                             .drop(uploaded_accounts.accountId)

trueParallelContracts = spark.read.format("delta").load("/mnt/bse-dev/parallel_contracts_clean").select("sfdcAccountId").distinct()
# trueParallelContracts = trueParallelContracts.withColumnRenamed("sfdcAccountId", "accountId")
# aws_novl = aws_novl.join(trueParallelContracts, aws_novl.sfdcAccountID==trueParallelContracts.accountId, 'left')\
#                              .filter(trueParallelContracts.accountId.isNull())\
#                              .drop(trueParallelContracts.accountId)
# pvc_exclude = ['00161000005eOinAAE', '0016100000d1P6mAAE', '00161000016vS8lAAE']
aws_novl_accounts = [row.sfdcAccountID for row in aws_novl_contracts.collect()]
tp_accounts = [row.sfdcAccountId for row in trueParallelContracts.collect()] #+ pvc_exclude

aws_novl_only = list(set(aws_novl_accounts).difference(set(tp_accounts)))

aws_novl_only_query = """
select distinct sfdcAccountId
from bdw.bi_aggorders
where platform = 'aws'
and sfdcAccountId in {0}""".format(tuple(aws_novl_only))

aws_novl = spark.sql(aws_novl_only_query)

apmoller = prod_daily.filter(prod_daily.platform=='aws')\
                     .join(aws_novl, prod_daily.accountID==aws_novl.sfdcAccountId)\
                     .drop(aws_novl.sfdcAccountId)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)
write_to_adhoc_daily("append")

# COMMAND ----------

aws_novl.count()

# COMMAND ----------

print(spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").count())
print(spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").count())

# COMMAND ----------

# DBTITLE 1,include parallel processing from other-notebook
import json
job_status = run_notebook("DailyParallelListProcessingAWS")
if json.loads(job_status)['status'] == 'OK':
  print(spark.sql("select * from bdw.usagec_prod_daily_intermediate").count())
else:
  raise Exception("error while processing Parallel Contracts")

# COMMAND ----------

write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").count())
print(spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").count())

# COMMAND ----------

# aws payg
missingPAYG = spark.sql("""
      with commitPayGAccs (
      select accountID,
             count(distinct ctc_flag) cnt
      from finance.finance_usage_pricing
      where platform = "aws"
      group by 1
      having cnt > 1
      ),
      onlyPayGAccounts (
      select sfdcAccountID,
             count(AggOrder) cnt
      from bdw.bi_aggorders
      where platform = "aws"
      group by 1
      having cnt = 1
      )
      select o.sfdcAccountID
      from onlyPayGAccounts o
      join commitPayGAccs c on o.sfdcAccountID = c.accountID
""").collect()
missingPAYG = [row.sfdcAccountID for row in missingPAYG]

payg_accounts = spark.sql("""select distinct accountID
from finance.finance_usage_pricing
where platform = "aws"
and ctc_flag = 0
and accountID is not null""").collect()

UNMAPPED_ACCOUNTS = ["0013f000005RwT9AAK", "0013f0000063xxQAAQ", "0013f0000063xxLAAQ"]
payg_accounts = [row.accountID for row in payg_accounts] + UNMAPPED_ACCOUNTS

commit_accounts = spark.sql("""select distinct accountID
from finance.finance_usage_pricing
where platform = "aws"
and ctc_flag = 1
and accountID is not null""").collect()

commit_accounts = [row.accountID for row in commit_accounts]

processed = spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc")
uploaded_accounts = processed.filter(processed.platform == 'aws').select("accountId").distinct().collect()
uploaded_accounts = [row.accountId for row in uploaded_accounts]

payg_minus_commit = list(set(payg_accounts).difference(set(commit_accounts))) + missingPAYG
notuploaded_payg = list(set(payg_minus_commit).difference(set(uploaded_accounts)))
commitButNotUploaded = list(set(commit_accounts).difference(set(uploaded_accounts)))

#PVC_EXCLUDE = ['00161000005eOinAAE', '0016100000d1P6mAAE', '00161000016vS8lAAE']
totalAccountsToBePAYG = set(notuploaded_payg + commitButNotUploaded) #.difference(set(PVC_EXCLUDE))

payg_orders = """
select distinct sfdcAccountID
from bdw.bi_aggorders
where platform = "aws"
and sfdcAccountID in {0}""".format(tuple(totalAccountsToBePAYG))

mtm_aws = spark.sql(payg_orders)

apmoller = prod_daily.filter(prod_daily.platform=='aws')\
                     .join(mtm_aws, prod_daily.accountID==mtm_aws.sfdcAccountID)\
                     .drop(mtm_aws.sfdcAccountID)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)
write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").count()) 
print(spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").count()) 

# COMMAND ----------

ADHOC_DAILY_USAGE_LOC = "/mnt/bse-dev/usagec_prod_daily_modified_adhoc"
ADHOC_DAILY_AGGORDER_LOC = "/mnt/bse-dev/usagec_agg_order_daily_adhoc"

# COMMAND ----------

# DBTITLE 1,GCP novl
gcp_novl_contracts = spark.sql("""
with accounts_morethan1 (

select sfdcAccountID,
       count(aggOrder) cnt
from bdw.bi_aggorders
where platform = "gcp"
and scope in ("gcp-defined")
group by 1
order by 2 desc

),
nextAggOrders (
select agg.*,
       coalesce(lead(agg.startDate) over(partition by agg.sfdcAccountID order by agg.startDate), date_add(agg.endDate, 1)) nextStartDate
from bdw.bi_aggorders agg
join accounts_morethan1 m on agg.sfdcAccountID == m.sfdcAccountID
where platform = 'gcp'
and agg.aggOrder not like 'MTM%'
order by agg.sfdcAccountID, agg.startDate 
),

cleanAggOrders (
select *,
       case when datediff(nextStartDate, endDate)=1 then 0
            when nextStartDate > endDate then 0
            else 1
       end as overLapFlag
from nextAggOrders
)

select sfdcAccountID,
       sum(overLapFlag) totalSum
from cleanAggOrders
group by sfdcAccountID
having totalSum = 0
""")
gcp_novl_contracts = gcp_novl_contracts.drop("totalSum")
gcp_novl_accounts = [row.sfdcAccountID for row in gcp_novl_contracts.collect()]


gcp_novl_only = tuple(list(set(gcp_novl_accounts)))

if len(gcp_novl_only) == 1:
  tuple_gcp_novl_only = '("{0}")'.format(gcp_novl_only[0])
else:
  tuple_gcp_novl_only = gcp_novl_only
  
gcp_novl_only_query = """
select distinct sfdcAccountId
from bdw.bi_aggorders
where platform = 'gcp'
and sfdcAccountId in {0}""".format(tuple_gcp_novl_only)  

gcp_novl = spark.sql(gcp_novl_only_query)

gcp_novl_usage = prod_daily.filter(prod_daily.platform=='gcp')\
                     .join(gcp_novl, prod_daily.accountID==gcp_novl.sfdcAccountId)\
                     .drop(gcp_novl.sfdcAccountId)\
                     .orderBy(*orderByColumns)

# COMMAND ----------

write_to_daily_intermediate(gcp_novl_usage)
write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").count()) 
print(spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").count()) 

# COMMAND ----------

# DBTITLE 1,GCP MTM
missingPAYG = spark.sql("""
      with commitPayGAccs (
      select accountID,
             count(distinct ctc_flag) cnt
      from finance.finance_usage_pricing
      where platform = "gcp"
      group by 1
      having cnt > 1
      ),
      onlyPayGAccounts (
      select sfdcAccountID,
             count(AggOrder) cnt
      from bdw.bi_aggorders
      where platform = "gcp"
      group by 1
      having cnt = 1
      )
      select o.sfdcAccountID
      from onlyPayGAccounts o
      join commitPayGAccs c on o.sfdcAccountID = c.accountID
""").collect()
missingPAYG = [row.sfdcAccountID for row in missingPAYG]

payg_accounts = spark.sql("""select distinct accountID
from finance.finance_usage_pricing
where platform = "gcp"
and ctc_flag = 0
and accountID is not null""").collect()

UNMAPPED_ACCOUNT = ["0013f000005RwT9AAK"]
payg_accounts = [row.accountID for row in payg_accounts] + UNMAPPED_ACCOUNT

commit_accounts = spark.sql("""select distinct accountID
from finance.finance_usage_pricing
where platform = "gcp"
and ctc_flag = 1
and accountID is not null""").collect()

commit_accounts = [row.accountID for row in commit_accounts]

processed = spark.read.format("delta").load(ADHOC_DAILY_AGGORDER_LOC)
uploaded_accounts = processed.filter(processed.platform == 'gcp').select("accountId").distinct().collect()
uploaded_accounts = [row.accountId for row in uploaded_accounts]

payg_minus_commit = list(set(payg_accounts).difference(set(commit_accounts))) + missingPAYG
notuploaded_payg = list(set(payg_minus_commit).difference(set(uploaded_accounts)))
commitButNotUploaded = list(set(commit_accounts).difference(set(uploaded_accounts)))

#PVC_EXCLUDE = ['00161000005eOinAAE', '0016100000d1P6mAAE', '00161000016vS8lAAE']
totalAccountsToBePAYG = set(notuploaded_payg + commitButNotUploaded) #.difference(set(PVC_EXCLUDE))

payg_orders = """
select distinct sfdcAccountID
from bdw.bi_aggorders
where platform = "gcp"
and sfdcAccountID in {0}""".format(tuple(totalAccountsToBePAYG))

mtm_gcp = spark.sql(payg_orders)

apmoller = prod_daily.filter(prod_daily.platform=='gcp')\
                     .join(mtm_gcp, prod_daily.accountID==mtm_gcp.sfdcAccountID)\
                     .drop(mtm_gcp.sfdcAccountID)\
                     .orderBy(*orderByColumns)

# COMMAND ----------

write_to_daily_intermediate(apmoller)
write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc").count()) 
print(spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").count())

# COMMAND ----------

daily_df = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").dropDuplicates()
daily_df.count()
daily_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_prod_daily")

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))