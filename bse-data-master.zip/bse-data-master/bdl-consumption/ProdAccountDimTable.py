# Databricks notebook source
import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

account_dim_query = """
select a.id AccountID,
       a.Name AccountName,
       a.Region__c AccountRegion,
       a.Sub_Region__c AccountSubRegion,
       a.Account_Status__c Account_Status,
       a.CSE__c CSEOld,
       u2.Name CSENewName,
       u.Name as AEName,
       a.BRAG_Status__c BRAGStatus,
       a.SCP_Status__c SCPStatus,
       a.Top_25__c isTop25,
       u.Territory_Name__c AccountOwnerTerritoryName,
       a.Owner_Role__c OwnerRole,
       a.Segment__c AccountSegment,
       a.Databricks_Vertical_Map__c DatabricksVerticalMap,
       a.Account_CS_Tier__c AccountCSTier,
       a.Last_SA_Engaged__c LastSAEngaged
from sfdc_ds.account a 
left join sfdc_ds.user u on u.Id = a.OwnerId and a.processDate = u.processDate
left join sfdc_ds.user u2 on u2.Id = a.CSE_New__c and a.processDate = u2.processDate
where a.processDate = (select max(processDate) from sfdc_ds.account)
"""
account_dim_df = spark.sql(account_dim_query)

# COMMAND ----------

total_count = account_dim_df.count()

# COMMAND ----------

user_query = """
select Id UserId,
       Name UserName
from sfdc_ds.user
where processDate = (select max(processDate) from sfdc_ds.user)
"""
user_df = spark.sql(user_query)

# COMMAND ----------

account_dim_df = account_dim_df.join(user_df, account_dim_df.LastSAEngaged==user_df.UserId, 'left')\
                               .drop(user_df.UserId)\
                               .withColumnRenamed("UserName", "LastSAEngagedName")
account_dim_count = account_dim_df.count()

# COMMAND ----------

print("totals", total_count, account_dim_count)
# if total_count == account_dim_count:
#   account_dim_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/bi_account_dim")
# else:
#   print("counts dont match: check the job")
#   raise Exception("count mismatch")
