# Databricks notebook source
import json

# COMMAND ----------

def run_consumption_notebook(notebook_name, timeout=7200):
  try:
    return dbutils.notebook.run(notebook_name, timeout)
  except Exception as e:
    raise e

# COMMAND ----------

#stage-1
order_build_status = run_consumption_notebook("DailyUsageBuild")
if json.loads(order_build_status)['status'] == 'OK':
  rollups_status = run_consumption_notebook("DailyRollups")
  if json.loads(rollups_status)['status'] == 'OK':
    print("consumption orders built")
  else:
    raise Exception("orders build failed")

# COMMAND ----------

#stage-2
consumption_status = run_consumption_notebook("ConsumptionForecast")
if json.loads(consumption_status)['status'] == 'OK':
  pvc_usage_status = run_consumption_notebook("DailyPVCUsage")
  if json.loads(pvc_usage_status)['status'] == 'OK':
    pvc_consumption_status = run_consumption_notebook("PVCConsumptionForecast")
    if json.loads(pvc_consumption_status)['status'] == 'OK':
      aggregationsStatus = run_consumption_notebook("Aggregations")
      if json.loads(aggregationsStatus)['status'] == 'OK':
        addBurstStatus = run_consumption_notebook("AddBurstDaily")
        if json.loads(addBurstStatus)['status'] == 'OK':
            print("rollups completed")
        else:
            raise Exception("rollups failed")

# COMMAND ----------

#stage-3
dailyPopMetricsStatus = run_consumption_notebook("DailyPoPMetrics")
if json.loads(dailyPopMetricsStatus)['status'] == 'OK':
  print("ready to be pushed to SFDC")
else:
  raise Exception("PoPMetrics failed")

# COMMAND ----------

run_consumption_notebook("ProdSFDCPush", 0)