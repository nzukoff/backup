# Databricks notebook source
import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def sql_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType in ('SQL', 'virtual') else 0

@udf("double")
def sql_dollars(dbu_quantity, skuType, dbuRevSharePrice):
  return (dbu_quantity * dbuRevSharePrice) if skuType in ('SQL', 'virtual') else 0.0

@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  if platform == "azure":
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  return (cumDBDollars > RevShareCommit + 0.999) or (usage_date > endDate)

@udf("double")
def pctBurn(platform, aggOrder, ListCommit, RevShareCommit, cumListDollars, cumRevShareDollars, cumListForecastDollars, cumRevShareForecastDollars):
  pctBurn = 0.0
  if not 'MTM' in aggOrder:
    if platform == 'azure':
      return 0 if ListCommit==0 else ((cumListDollars + cumListForecastDollars) / ListCommit) * 100
    if platform == 'aws':
      return 0 if RevShareCommit==0 else ((cumRevShareDollars + cumRevShareForecastDollars) / RevShareCommit) * 100
  return pctBurn

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"
  
@udf("string")
def forecastType(subscriptionId, contract_type):
  forecastType = 'MTM'
  if subscriptionId == 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = "SharedCommit"
  if subscriptionId != 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = 'SingleCommit'
  
  return forecastType

@udf("string")
def consumptionTypeForecast(aggOrder):
  consumptionTypeForecast = "MTM"
  if "Shared" in aggOrder:
    consumptionTypeForecast = "SharedCommit"
  if "Single" in aggOrder:
    consumptionTypeForecast = aggOrder
  if "AWS" in aggOrder:
    consumptionTypeForecast = "Commit"    
    
  
  return consumptionTypeForecast

# COMMAND ----------

dates_df = spark.sql("select * from bdw.bi_dates")
pvcDaily = spark.read.format("delta").load("/mnt/bse-dev/pvc_usagec_aggorder_daily_gold")
sasDaily = spark.read.format("delta").load("/mnt/bse-dev/usagec_aggorder_daily_gold_adhoc")
dailyUsage = sasDaily.union(pvcDaily)

aggOrderConsumpCastDailyDedup = dailyUsage.dropDuplicates(['accountId', 'aggOrder', 'platform', 'usage_date', 'revShareDollars', 'revShareForecastDollars'])
aggOrderConsumpCastDaily = aggOrderConsumpCastDailyDedup.dropDuplicates(['accountId', 'aggOrder', 'usage_date', 'revShareDollars', 'revShareForecastDollars'])

# COMMAND ----------

orderByColumns = ["accountID", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)


aggOrderConsumpCastDaily  =  aggOrderConsumpCastDaily.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                     .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                     .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                     .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                     .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                     .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                                                     .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                                                     .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                                                     .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                                                     .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                                                     .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                     .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                     .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                     .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                     .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                                                     .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                                                     .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

aggOrderConsumpCastDaily.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_aggorder_daily_gold_adhoc")

# COMMAND ----------

aggOrderConsumpCastDaily = aggOrderConsumpCastDaily.join(dates_df.select("date", "month_end_date"), aggOrderConsumpCastDaily.usage_date==dates_df.date)\
                                                   .drop(dates_df.date)

aggOrderAggColumns = ["accountId", "accountName", "platform", "aggOrder", "month_end_date"]
aggOrderMonthly =  aggOrderConsumpCastDaily.groupBy(*aggOrderAggColumns)\
                                           .agg(\
                                                 round(max("ListCommit"),4).alias("ListCommit"),\
                                                 round(max("DiscountedCommit"),4).alias("DiscountedCommit"),\
                                                 round(max("RevShareCommit"),4).alias("RevShareCommit"),\
                                                 round(sum("listDollars"),4).alias("listDollars"),\
                                                 round(sum("custDollars"),4).alias("custDollars"),\
                                                 round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                 round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                 round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                 round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                 round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                 round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                 round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                 round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                 round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                 round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                 round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                 round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                 round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                 round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                 round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars"),\
                                                 round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                 round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                 round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                 round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                 round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                 round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                 round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                 round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                 round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                 round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars")                                                
                                               )
aggOrderMonthly = aggOrderMonthly.orderBy("accountId", "accountName", "platform", "aggOrder","month_end_date")

partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("month_end_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

aggOrderMonthly = aggOrderMonthly.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                 .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                 .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                                 .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                 .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                 .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                                 .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                                 .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                                 .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                                 .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                                 .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                 .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                 .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                 .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                 .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                                 .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                                 .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

pvc_orders = spark.read.format("delta").load("/mnt/bse-dev/bi_aggorders_pvc")
pvc_orders.createOrReplaceTempView("pvc_orders")

pvc_aggOrders_df = spark.sql("""
select aggOrder,
       sfdcAccountId,
       startDate,
       endDate,
       cloudPartnerPurchase ListCommit,
       ActualPartnerCommit DiscountedCommit,
       DBShareCommit RevShareCommit
from pvc_orders
""")

overlapping_contracts = spark.read.format("delta").load("/mnt/bse-dev/parallel_contracts_clean")
overlapping_contracts = overlapping_contracts.withColumn("platform", lit("aws"))
overlapping_contracts.createOrReplaceTempView("process_parallel_contracts")

aggOrders_df = spark.sql("""
with processed_parallel_accounts(
select distinct sfdcAccountId as accountId, platform from process_parallel_contracts
)
select aggOrder,
       sfdcAccountId,
       startDate,
       endDate,
       cloudPartnerPurchase ListCommit,
       ActualPartnerCommit DiscountedCommit,
       DBShareCommit RevShareCommit
from bdw.bi_aggorders agg
left join processed_parallel_accounts ppc on agg.sfdcAccountId = ppc.accountId and agg.platform = ppc.platform
where ppc.accountId is null

union 

select aggOrder,
       sfdcAccountId,
       startDate,
       endDate,
       ListCommit,
       DiscountedCommit,
       RevShareCommit
from process_parallel_contracts
""")

aggOrders_df = aggOrders_df.union(pvc_aggOrders_df)

# COMMAND ----------

aggOrdersdedup_df = aggOrders_df.dropDuplicates(["aggOrder"])

# COMMAND ----------

print(aggOrderMonthly.count())
aggOrderMonthlyExtended = aggOrderMonthly.join(aggOrdersdedup_df.select("aggOrder", "startDate", "endDate"), aggOrderMonthly.aggOrder==aggOrdersdedup_df.aggOrder)\
                                       .drop(aggOrdersdedup_df.aggOrder)
print(aggOrderMonthlyExtended.count())



aggOrderMonthlyExtended = aggOrderMonthlyExtended.orderBy("accountID", "accountName", "platform", "aggOrder", "month_end_date")
pctBurnColumns = ["platform", "aggOrder", "ListCommit", "RevShareCommit", "cumListDollars", "cumRevShareDollars", "cumListForecastDollars", "cumRevShareForecastDollars"]
aggOrderMonthlyMetrics = aggOrderMonthlyExtended.withColumn("pctBurn", round(pctBurn(*pctBurnColumns),2))

# COMMAND ----------

aggOrderMonthlyMetrics.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_aggorder_monthly_gold")

# COMMAND ----------

# DBTITLE 1,Platform Daily & Monthly 
platformDailyColumns = ["accountId", "accountName", "platform", "usage_date"]
consumptionPlatformDaily = aggOrderConsumpCastDaily.groupBy(*platformDailyColumns)\
                                                   .agg(\
                                                         max("ListCommit").alias('ListCommit'),\
                                                         max("DiscountedCommit").alias('DiscountedCommit'),\
                                                         max("RevShareCommit").alias('RevShareCommit'),\
                                                         round(sum("listDollars"),4).alias("listDollars"),\
                                                         round(sum("custDollars"),4).alias("custDollars"),\
                                                         round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                         round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                         round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                         round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                         round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                         round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                         round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                         round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                         round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                         round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                         round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                         round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                         round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                         round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                         round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars"),\
                                                         round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                         round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                         round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                         round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                         round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                         round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                         round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                         round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                         round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                         round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars")                                 
                                                       )

consumptionPlatformDaily = consumptionPlatformDaily.orderBy("accountId", "accountName", "platform", "usage_date")

orderByColumns = ["accountID", "accountName", "platform", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)


consumptionPlatformDailyCum  =   consumptionPlatformDaily.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                         .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                         .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                         .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                         .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                         .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                         .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                         .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                                                         .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

consumptionPlatformDailyCum = consumptionPlatformDailyCum.orderBy(*orderByColumns)

# COMMAND ----------

consumptionPlatformDailyCum.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_platform_daily_gold")

# COMMAND ----------

consumptionPlatformDaily = consumptionPlatformDaily.join(dates_df.select("date", "month_end_date"), consumptionPlatformDaily.usage_date==dates_df.date)\
                                                   .drop(dates_df.date)

platAggColumns = ["accountId", "accountName", "platform", "month_end_date"]
platMonthly =  consumptionPlatformDaily.groupBy(*platAggColumns)\
                                           .agg(\
                                                 round(max("ListCommit"),4).alias("ListCommit"),\
                                                 round(max("DiscountedCommit"),4).alias("DiscountedCommit"),\
                                                 round(max("RevShareCommit"),4).alias("RevShareCommit"),\
                                                 round(sum("listDollars"),4).alias("listDollars"),\
                                                 round(sum("custDollars"),4).alias("custDollars"),\
                                                 round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                 round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                 round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                 round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                 round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                 round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                 round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                 round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                 round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                 round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                 round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                 round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                 round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                 round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                 round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars"),\
                                                 round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                 round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                 round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                 round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                 round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                 round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                 round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                 round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                 round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                 round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars")                                                
                                               )
platMonthly = platMonthly.orderBy("accountId", "accountName", "platform", "month_end_date")

partitionByColumns = ["accountID", "accountName", "platform"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("month_end_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

platMonthlyCum =  platMonthly.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                             .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                             .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                             .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                             .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                             .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

platMonthlyCum.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_platform_monthly_gold")

# COMMAND ----------

# DBTITLE 1,Account Monthly
accAggColumns = ["accountId", "accountName", "month_end_date"]
accMonthly =  platMonthly.groupBy(*accAggColumns)\
                                           .agg(\
                                                 round(sum("listDollars"),4).alias("listDollars"),\
                                                 round(sum("custDollars"),4).alias("custDollars"),\
                                                 round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                 round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                 round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                 round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                 round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                 round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                 round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                 round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                 round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                 round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                 round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                 round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                 round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                 round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                 round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars"),\
                                                 round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                 round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                 round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                 round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                 round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                 round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                 round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                 round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                 round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                 round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars")         
                                               )
accMonthly = accMonthly.orderBy("accountId", "accountName", "month_end_date")

partitionByColumns = ["accountID", "accountName"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("month_end_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

accMonthlyCum =    accMonthly.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                             .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                             .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                             .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                             .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                             .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

accMonthlyCum.createOrReplaceTempView("AccountMonthly")
# account_workspace_users_monthly = spark.sql("""
# with account_workspaces (
# select aws.Id AccountId,
#        wk.Id workspaceSFDCId
# from sfdc_ds.account aws
# join sfdc_ds.workspace__c wk on aws.Id = wk.account__c and aws.processDate = wk.processDate
# where aws.processDate = (select max(processDate) from sfdc_ds.account)
# ),

# workspace_logins (
# select wk.AccountId,
#        usr.workspace__c,
#        usr.email__c,
#        cast(max(usr.last_login_time__c) as date) max_last_login_time
# from sfdc_ds.workspace_user__c usr
# join account_workspaces wk on usr.workspace__c = wk.workspaceSFDCId
# where processDate >= '2020-01-01'
# and is_removed__c = 0
# group by 1,2,3
# )

# select AccountId,
#        dt.month_end_date,
#        count(*) workspace_users_count
# from workspace_logins wl
# join bdw.bi_dates dt on wl.max_last_login_time = dt.date
# where max_last_login_time >= '2020-01-01' 
# and email__c not like '%databricks.com'
# group by 1,2
# order by 3 desc
# """)
# account_workspace_users_monthly.createOrReplaceTempView("account_workspace_users_monthly")


account_workspace_users_monthly = spark.sql("""
with account_workspaces (
select aws.Id AccountId,
       wk.Id workspaceSFDCId
from sfdc_ds.account aws
join sfdc_ds.workspace__c wk on aws.Id = wk.account__c and aws.processDate = wk.processDate
where aws.processDate = (select max(processDate) from sfdc_ds.account)
),
 
workspace_logins (
select wk.AccountId,
       dt.month_end_date,
       usr.email__c,
       cast(max(usr.last_login_time__c) as date) max_last_login_time
from sfdc_ds.workspace_user__c usr
join account_workspaces wk on usr.workspace__c = wk.workspaceSFDCId
join bdw.bi_dates dt on usr.processDate = dt.date
where processDate >= '2020-01-01'
and is_removed__c = 0
group by 1,2,3
)
 
select accountId,
       dt.month_end_date,
       count(distinct email__c) workspace_users_count
from workspace_logins wl
join bdw.bi_dates dt on wl.max_last_login_time = dt.date
where max_last_login_time >= '2020-01-01' 
and email__c not like '%databricks.com'
group by 1,2
""")
account_workspace_users_monthly.createOrReplaceTempView("account_workspace_users_monthly")

account_monthly_extended = spark.sql("""
select am.*,
       coalesce(wk.workspace_users_count,0) workspace_users_count
from AccountMonthly am
left join account_workspace_users_monthly wk on am.accountId = wk.AccountId and am.month_end_date = wk.month_end_date
""")

account_monthly_extended.createOrReplaceTempView("usagec_account_monthly")

# COMMAND ----------

ae_cse_forecast = spark.sql("""
with 

base (
select case when RecordTypeId = "0123f000000XdPlAAK" then uc.Account__c
            when RecordTypeId = "0123f000000XdPkAAK" then ucm.Account__c
            else "other"
       end as accountId,       
       dt.month_end_date,
       RecordTypeId,
       case when RecordTypeId = "0123f000000XdPlAAK" then "cse"
            when RecordTypeId = "0123f000000XdPkAAK" then "ae"
            else "other"
       end as forecastType,
       Forecast__c AEForecastDBU,
       (Forecast__c * Effective_Rate__c) AEForecastDBUDollars,   
       Effective_Rate__c EffectiveRate,       
       case when RecordTypeId = "0123f000000XdPlAAK" then Forecast__c
            else 0
       end as CSEBaseLineForecastDBU,

       case when RecordTypeId = "0123f000000XdPlAAK" then (Forecast__c * Effective_Rate__c) 
            else 0
       end as CSEBaseLineForecastDBUDollars,
       Best_Case__c CSEUpsideDBU,
       CSE_Upside__c CSEUpsideDBUDollars
       
from sfdc_ds.usecase_morr__c ucm
left join sfdc_ds.usecase__c uc on ucm.Use_Case__c = uc.Id and ucm.processDate = uc.processDate
join bdw.bi_dates dt on ucm.Date__c = dt.date
where ucm.processDate = (select max(processDate) from sfdc_ds.usecase_morr__c)
),

final (
select accountId,
       month_end_date,
       forecastType,
       sum(CSEBaseLineForecastDBU) CSEBaseLineForecastDBU,
       round(sum(CSEBaseLineForecastDBUDollars),2) CSEBaseLineForecastDBUDollars,
       sum(CSEUpsideDBU) CSEUpsideDBU,
       round(sum(CSEUpsideDBUDollars),2) CSEUpsideDBUDollars,
       case when forecastType = 'ae' then round(sum(AEForecastDBU),2)
            else 0
       end as AEForecastDBU,
       case when forecastType = 'ae' then round(sum(AEForecastDBUDollars),2)
            else 0
       end as AEForecastDBUDollars      
from base 
group by 1,2,3
order by accountId, month_end_date desc  
)


select accountId,
       month_end_date,
       sum(CSEBaseLineForecastDBU) CSEBaseLineForecastDBU,
       round(sum(CSEBaseLineForecastDBUDollars),2) CSEBaseLineForecastDBUDollars,
       sum(CSEUpsideDBU) CSEUpsideDBU,
       round(sum(CSEUpsideDBUDollars),2) CSEUpsideDBUDollars,
       round(sum(AEForecastDBU),2) AEForecastDBU,
       round(sum(AEForecastDBUDollars),2) AEForecastDBUDollars      
from final 
group by 1,2
order by accountId, month_end_date desc
""")
print(ae_cse_forecast.count())
ae_cse_forecast.createOrReplaceTempView("aecse_forecast")

accmonthly_cseaeforecast = spark.sql("""
select acc.*,
       coalesce(CSEBaseLineForecastDBU, 0) CSEBaseLineForecastDBU,
       coalesce(CSEBaseLineForecastDBUDollars, 0) CSEBaseLineForecastDBUDollars,
       coalesce(CSEUpsideDBU, 0) CSEUpsideDBU,
       coalesce(CSEUpsideDBUDollars, 0) CSEUpsideDBUDollars,
       coalesce(AEForecastDBU, 0) AEForecastDBU,
       coalesce(AEForecastDBUDollars, 0) AEForecastDBUDollars      
from usagec_account_monthly acc
left join aecse_forecast af on acc.accountId = af.accountId and acc.month_end_date = af.month_end_date
""")

# COMMAND ----------

accmonthly_cseaeforecast.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_account_monthly_gold")

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))