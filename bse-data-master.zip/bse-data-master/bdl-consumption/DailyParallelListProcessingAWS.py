# Databricks notebook source
import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

#todo : update burst
@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def sql_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType in ('SQL', 'virtual') else 0

@udf("double")
def sql_dollars(dbu_quantity, skuType, dbuRevSharePrice):
  return (dbu_quantity * dbuRevSharePrice) if skuType in ('SQL', 'virtual') else 0.0

# @udf("boolean")
# def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  

#   if platform == "azure":
#       return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
#   isBurst = False  
#   if platform == 'aws':
#     if (cumDBDollars > RevShareCommit + 0.999):
#       if (usage_date > endDate):
#         isBurst = True
#     else:
#       if (usage_date > endDate):
#         isBurst = True
#   return isBurst

@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  if platform == "azure":
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  return (usage_date > endDate)

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"

@udf("string")
def forecastType(subscriptionId, contract_type):
  forecastType = 'MTM'
  if subscriptionId == 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = "SharedCommit"
  if subscriptionId != 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = 'SingleCommit'
  
  return forecastType

@udf("string")
def entitlementTier(usage_sku):
  
  entitlementTier = "NA"
  if "enterprise" in usage_sku:
    entitlementTier = "Enterprise"
  elif "premium" in usage_sku:
    entitlementTier = "Premium"
  else:
    entitlementTier = "Standard"
  
  return entitlementTier

@udf("double")
def standardDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Standard" else 0.0

@udf("double")
def premiumDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Premium" else 0.0  

@udf("double")
def enterpriseDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Enterprise" else 0.0  

@udf("double")
def moonCakeDBUs(deployedRegion, dbu_quantity):
  if deployedRegion is None:
    return 0.0
  return dbu_quantity if 'china' in deployedRegion else 0.0

@udf("double")
def moonCakeDeltaDBUs(deployedRegion, delta_dbu_quantity):
  if deployedRegion is None:
    return 0.0
  return delta_dbu_quantity if 'china' in deployedRegion else 0.0

# COMMAND ----------

overlapping_contracts = spark.read.format("csv").option("header", "true").load("/mnt/bse-dev/process_overlapping_parallel_contracts_04192021.csv")
overlapping_contracts = overlapping_contracts.withColumn("endDate", col("endDate").cast("date"))\
                                             .withColumn("startDate", col("startDate").cast("date"))\
                                             .withColumn("cloudPartnerPurchase", col("cloudPartnerPurchase").cast("double"))\
                                             .withColumn("ActualPartnerCommit", col("ActualPartnerCommit").cast("double"))\
                                             .withColumn("DBShareCommit", col("DBShareCommit").cast("double"))\
                                             .withColumn("dbuCustPriceDiscount", col("dbuCustPriceDiscount").cast("float"))
overlapping_contracts.createOrReplaceTempView("overlapping_contracts")

# COMMAND ----------

# %sql
# select *
# from overlapping_contracts
# --where aggOrder not like 'MTM%'
# order by sfdcAccountID, startDate

# COMMAND ----------

clean_unprocessed = overlapping_contracts.select("sfdcAccountID").distinct()
clean_unprocessed.createOrReplaceTempView("clean_unprocessed")

aws_usage_granular_df = spark.sql("""
select accountID,
       accountName,
       date usage_date,
       lower(sku) usage_sku,
       round(DBU,4) dbu_quantity,
       workspaceSFDCID,
       platform,
       listPrice,
       dbuPrice dbuRevSharePrice,
       discountPrice dbuCustPrice,
       round(deltaDBU,4) delta_dbu_quantity,
       clusterId
from finance.dbu_dollars f
join clean_unprocessed cu on f.accountID = cu.sfdcAccountID
where platform = 'aws'
order by date desc
""")

wksp_query = """
  select distinct
         swk.workspaceId__c workspaceId,
         coalesce(swk.azureSubscriptionId__c, 'noSubscriptionID') SubscriptionID,
         swk.Id workspaceIdSFDC
  from sfdc_ds.workspace__c swk
  where swk.processDate = (select max(processDate) from sfdc_ds.workspace__c)
"""
wksp_df = spark.sql(wksp_query)

aws_usage_granular_df = aws_usage_granular_df.join(wksp_df, aws_usage_granular_df.workspaceSFDCID==wksp_df.workspaceIdSFDC)\
                                             .drop(wksp_df.workspaceIdSFDC)\
                                             .drop(wksp_df.SubscriptionID)

aws_usage_granular_df.createOrReplaceTempView("aws_usage_granular")

aws_orders_granular_query = """
with initial_usage_orders (
select ug.*,
       agg.aggOrder,
       agg.SubscriptionID,
       agg.scope,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit,
       case when count(usage_date) over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, clusterId, dbu_quantity) > 1 then 'true'
            else 'false'
       end as usageFlag,
       case when scope = 'shared'  then 'false'
            else 'true'
       end as scopeFlag
from aws_usage_granular ug
join overlapping_contracts agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
                         and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where ug.platform = 'aws'
order by usage_date
)
select *
from initial_usage_orders
where (usageFlag='true' and scopeFlag='true') or (usageFlag='false' and scopeFlag='false')
"""

aws_orders_granular_df = spark.sql(aws_orders_granular_query)
dropColumns = ["usageFlag", "scopeFlag", "clusterId"]
aws_orders_granular_df = aws_orders_granular_df.drop(*dropColumns)

aws_orders_granular_df = aws_orders_granular_df.select(*sorted(aws_orders_granular_df.columns))

# COMMAND ----------

aws_usage_granular_df.count()

# COMMAND ----------

aws_orders_granular_df.count()

# COMMAND ----------

aws_orders_granular_df.select("accountId").distinct().count()

# COMMAND ----------

aws_orders_granular_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_prod_daily_granular_adhoc")

# COMMAND ----------

prod_daily = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_granular_adhoc")
prod_daily = prod_daily.withColumn("dbuRevSharePrice", col("dbuRevSharePrice").cast("double"))
# prod_daily = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_granular_adhoc")
dates_df = spark.sql("select * from bdw.bi_dates")

product_df = spark.sql("""
select distinct meterSubCategory skuType, 
                meterName 
from bdw.bi_product_dim 
where meterCategory = 'workloads'
and meterSubCategory in ('automated', 'interactive')

union 

select distinct meterSubCategory skuType, 
                meterName 
from bdw.bi_product_dim 
where meterCategory = 'workloads'
and meterSubCategory not in ('automated', 'interactive')
and meterName like '%sql%'
""")


# add month, dollars
prod_daily = prod_daily.withColumn("month", date_format(prod_daily.usage_date, 'yyyy-MM'))\
                       .withColumn("listDollars", round(col("listPrice")*col("dbu_quantity"), 6))\
                       .withColumn("custDollars", round(col("dbuCustPrice")*col("dbu_quantity"), 6))\
                       .withColumn("revShareDollars", round(col("dbuRevSharePrice")*col("dbu_quantity"), 6))\
                       .withColumn("DeltaRevShareDollars", round(col("dbuRevSharePrice")*col("delta_dbu_quantity"), 6))

prod_daily = prod_daily.withColumnRenamed("cloudPartnerPurchase", "ListCommit")\
                       .withColumnRenamed("ActualPartnerCommit", "DiscountedCommit")\
                       .withColumnRenamed("DBShareCommit", "RevShareCommit")


# add sku-type
prod_daily = prod_daily.join(product_df, prod_daily.usage_sku == product_df.meterName)\
                       .drop(product_df.meterName)

# add interactive/automated dbus
prod_daily = prod_daily.withColumn("InteractiveDBUs", coalesce(interactive_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("AutomatedDBUs", coalesce(automated_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaInteractiveDBUs", coalesce(interactive_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaAutomatedDBUs", coalesce(automated_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLAnalyticsDBUs", coalesce(sql_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLRevShareDollars", round(sql_dollars("dbu_quantity", "skuType", "dbuRevSharePrice"), 6))\
                       .withColumn("EntitlementTier", entitlementTier("usage_sku"))\
                       .withColumn("StandardDBUs", standardDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("PremiumDBUs", premiumDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("EnterpriseDBUs", enterpriseDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("StandardRevShareDollars", round(col("dbuRevSharePrice")*col("StandardDBUs"), 6))\
                       .withColumn("PremiumRevShareDollars", round(col("dbuRevSharePrice")*col("PremiumDBUs"), 6))\
                       .withColumn("EnterpriseRevShareDollars", round(col("dbuRevSharePrice")*col("EnterpriseDBUs"), 6))

prod_daily = prod_daily.withColumn("MoonCakeDBUs", moonCakeDBUs("deployedRegion", "dbu_quantity"))\
                       .withColumn("MoonCakeDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDBUs"), 6))\
                       .withColumn("MoonCakeDeltaDBUs", moonCakeDeltaDBUs("deployedRegion", "delta_dbu_quantity"))\
                       .withColumn("MoonCakeDeltaDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDeltaDBUs"), 6))

dateSelectColumns = ["date", "isMonthEnd", "year_month"]
datesFiltered = dates_df.select(*dateSelectColumns)\
                        .filter(dates_df.isMonthEnd==1)\
                        .drop(dates_df.isMonthEnd)\
                        .withColumnRenamed("date", "month_end_date")


prod_daily = prod_daily.join(datesFiltered, prod_daily.month==datesFiltered.year_month)\
                                      .drop(datesFiltered.year_month)

prod_daily = prod_daily.drop(prod_daily.month)

# COMMAND ----------

# optimize dynamically
# todo: change cumDBDollars to cumRevShareDollars
orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

apmoller = prod_daily.orderBy(*orderByColumns)
apmoller = apmoller.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                   .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                   .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                   .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                   .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                   .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                   .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                   .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                   .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                   .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

burstColumns = ["cumListDollars", "listCommit", "endDate", "usage_date", "cumDBDollars", "RevShareCommit", "platform"]
apmoller = apmoller.withColumn("IsBurst", isBurst(*burstColumns))

# COMMAND ----------

apmoller.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_prod_daily_intermediate")

# COMMAND ----------

apmoller.count()

# COMMAND ----------

# DBTITLE 1,Remaining Parallel Accounts
rem_parallel_contracts = spark.read.format("csv").option("header", "true").load("/mnt/bse-dev/trueOverlappingOrdersCleanedv7.csv")
rem_parallel_contracts = rem_parallel_contracts.withColumn("endDate", col("endDate").cast("date"))\
                                               .withColumn("startDate", col("startDate").cast("date"))\
                                               .withColumn("cloudPartnerPurchase", col("cloudPartnerPurchase").cast("double"))\
                                               .withColumn("ActualPartnerCommit", col("ActualPartnerCommit").cast("double"))\
                                               .withColumn("DBShareCommit", col("DBShareCommit").cast("double"))
rem_parallel_contracts.createOrReplaceTempView("remaining_parallel_accounts")

# COMMAND ----------

display(rem_parallel_contracts)

# COMMAND ----------

aws_usage_granular_df = spark.sql("""
with parallel_accounts (
select distinct sfdcAccountID from remaining_parallel_accounts
)
select accountID,
       accountName,
       date usage_date,
       lower(sku) usage_sku,
       round(DBU,4) dbu_quantity,
       workspaceSFDCID,
       platform,
       listPrice,
       dbuPrice dbuRevSharePrice,
       discountPrice dbuCustPrice,
       round(deltaDBU,4) delta_dbu_quantity
from finance.finance_usage_pricing fup
join parallel_accounts pc on fup.accountID = pc.sfdcAccountID
where platform = 'aws'
order by date desc
""")
wksp_query = """
  select distinct
         swk.workspaceId__c workspaceId,
         coalesce(swk.azureSubscriptionId__c, 'noSubscriptionID') SubscriptionID,
         swk.Id workspaceIdSFDC
  from sfdc_ds.workspace__c swk
  where swk.processDate = (select max(processDate) from sfdc_ds.workspace__c)
"""
wksp_df = spark.sql(wksp_query)
aws_usage_granular = aws_usage_granular_df.join(wksp_df, aws_usage_granular_df.workspaceSFDCID==wksp_df.workspaceIdSFDC)\
                                             .drop(wksp_df.workspaceIdSFDC)\
                                             .drop(wksp_df.SubscriptionID)
aws_usage_granular.createOrReplaceTempView("aws_usage_granularV2")
print(aws_usage_granular_df.count())
print(aws_usage_granular.count())

# COMMAND ----------

aws_orders_granular_V2 = spark.sql("""
with initial_usage_orders (
select ug.*,
       agg.aggOrder,
       agg.SubscriptionID,
       agg.scope,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit
from aws_usage_granularV2 ug
join remaining_parallel_accounts agg on ug.accountID = agg.sfdcAccountID 
                                     and ug.platform = agg.platform 
                                     and ug.workspaceId = agg.workspaceId
                                     and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where ug.platform = 'aws'
order by usage_date
)
select *
from initial_usage_orders
"""
)
aws_orders_granular_V2 = aws_orders_granular_V2.select(*sorted(aws_orders_granular_V2.columns))
aws_orders_granular_V2.count()

# COMMAND ----------

mtm_usage_orders = spark.sql("""
with missing_usage_orders (
select ug.*,
       concat('MTMAWS', ug.accountId) aggOrder,
       'MTMSubscriptionID' SubscriptionID,
       'shared' scope
from aws_usage_granularV2 ug
left join remaining_parallel_accounts agg on ug.accountID = agg.sfdcAccountID 
                                     and ug.platform = agg.platform 
                                     and ug.workspaceId = agg.workspaceId
                                     and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where ug.platform = 'aws'
and agg.aggOrder is null and agg.sfdcAccountID is null and agg.startDate is null
order by usage_date
),
parallel_accounts (
select distinct sfdcAccountID from remaining_parallel_accounts
),
mtmorders (
select aggOrder,
       startDate,
       endDate,
       cloudPartnerPurchase,
       ActualPartnerCommit,
       DBShareCommit       
from bdw.bi_aggorders agg
join parallel_accounts pc on agg.sfdcAccountId = pc.sfdcAccountID
where agg.aggOrder like 'MTMAWS%'
)

select m.*,
       mtm.startDate,
       mtm.endDate,
       mtm.cloudPartnerPurchase,
       mtm.ActualPartnerCommit,
       mtm.DBShareCommit
from missing_usage_orders m
join mtmorders mtm on m.aggOrder = mtm.aggOrder
order by accountId, usage_date desc
""")
mtm_usage_orders = mtm_usage_orders.select(*sorted(mtm_usage_orders.columns))

# COMMAND ----------

rem_aws_orders_granular_V2 = aws_orders_granular_V2.union(mtm_usage_orders)

# COMMAND ----------

rem_aws_orders_granular_V2.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_prod_daily_granular_adhoc")

# COMMAND ----------

prod_daily = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_granular_adhoc")
prod_daily = prod_daily.withColumn("dbuRevSharePrice", col("dbuRevSharePrice").cast("double"))
# prod_daily = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_granular_adhoc")
dates_df = spark.sql("select * from bdw.bi_dates")
product_df = spark.sql("""
select distinct meterSubCategory skuType, 
                meterName 
from bdw.bi_product_dim 
where meterCategory = 'workloads'
and meterSubCategory in ('automated', 'interactive')

union 

select distinct meterSubCategory skuType, 
                meterName 
from bdw.bi_product_dim 
where meterCategory = 'workloads'
and meterSubCategory not in ('automated', 'interactive')
and meterName like '%sql%'
""")

# add month, dollars
prod_daily = prod_daily.withColumn("month", date_format(prod_daily.usage_date, 'yyyy-MM'))\
                       .withColumn("listDollars", round(col("listPrice")*col("dbu_quantity"), 6))\
                       .withColumn("custDollars", round(col("dbuCustPrice")*col("dbu_quantity"), 6))\
                       .withColumn("revShareDollars", round(col("dbuRevSharePrice")*col("dbu_quantity"), 6))\
                       .withColumn("DeltaRevShareDollars", round(col("dbuRevSharePrice")*col("delta_dbu_quantity"), 6))

prod_daily = prod_daily.withColumnRenamed("cloudPartnerPurchase", "ListCommit")\
                       .withColumnRenamed("ActualPartnerCommit", "DiscountedCommit")\
                       .withColumnRenamed("DBShareCommit", "RevShareCommit")


# add sku-type
prod_daily = prod_daily.join(product_df, prod_daily.usage_sku == product_df.meterName)\
                       .drop(product_df.meterName)

# add interactive/automated dbus
prod_daily = prod_daily.withColumn("InteractiveDBUs", coalesce(interactive_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("AutomatedDBUs", coalesce(automated_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaInteractiveDBUs", coalesce(interactive_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaAutomatedDBUs", coalesce(automated_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLAnalyticsDBUs", coalesce(sql_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLRevShareDollars", round(sql_dollars("dbu_quantity", "skuType", "dbuRevSharePrice"), 6))\
                       .withColumn("EntitlementTier", entitlementTier("usage_sku"))\
                       .withColumn("StandardDBUs", standardDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("PremiumDBUs", premiumDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("EnterpriseDBUs", enterpriseDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("StandardRevShareDollars", round(col("dbuRevSharePrice")*col("StandardDBUs"), 6))\
                       .withColumn("PremiumRevShareDollars", round(col("dbuRevSharePrice")*col("PremiumDBUs"), 6))\
                       .withColumn("EnterpriseRevShareDollars", round(col("dbuRevSharePrice")*col("EnterpriseDBUs"), 6))

prod_daily = prod_daily.withColumn("MoonCakeDBUs", moonCakeDBUs("deployedRegion", "dbu_quantity"))\
                       .withColumn("MoonCakeDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDBUs"), 6))\
                       .withColumn("MoonCakeDeltaDBUs", moonCakeDeltaDBUs("deployedRegion", "delta_dbu_quantity"))\
                       .withColumn("MoonCakeDeltaDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDeltaDBUs"), 6))

dateSelectColumns = ["date", "isMonthEnd", "year_month"]
datesFiltered = dates_df.select(*dateSelectColumns)\
                        .filter(dates_df.isMonthEnd==1)\
                        .drop(dates_df.isMonthEnd)\
                        .withColumnRenamed("date", "month_end_date")


prod_daily = prod_daily.join(datesFiltered, prod_daily.month==datesFiltered.year_month)\
                                      .drop(datesFiltered.year_month)

prod_daily = prod_daily.drop(prod_daily.month)

# optimize dynamically
# todo: change cumDBDollars to cumRevShareDollars
orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

apmoller = prod_daily.orderBy(*orderByColumns)
apmoller = apmoller.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                   .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                   .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                   .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                   .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                   .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                   .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                   .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                   .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                   .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

burstColumns = ["cumListDollars", "listCommit", "endDate", "usage_date", "cumDBDollars", "RevShareCommit", "platform"]
apmoller = apmoller.withColumn("IsBurst", isBurst(*burstColumns))

# COMMAND ----------

apmoller.write.option("overwriteSchema", "true").format("delta").mode("append").save("/mnt/bse-dev/usagec_prod_daily_intermediate")

# COMMAND ----------

spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_intermediate").count()

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))