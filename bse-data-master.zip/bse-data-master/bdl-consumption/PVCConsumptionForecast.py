# Databricks notebook source
import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def sql_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType in ('SQL', 'virtual') else 0

@udf("double")
def sql_dollars(dbu_quantity, skuType, dbuRevSharePrice):
  return (dbu_quantity * dbuRevSharePrice) if skuType in ('SQL', 'virtual') else 0.0

@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  if platform == "azure":
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  return (cumDBDollars > RevShareCommit + 0.999) or (usage_date > endDate)

@udf("double")
def pctBurn(platform, aggOrder, ListCommit, RevShareCommit, cumListDollars, cumRevShareDollars, cumListForecastDollars, cumRevShareForecastDollars):
  pctBurn = 0.0
  if not 'MTM' in aggOrder:
    if platform == 'azure':
      return 0 if ListCommit==0 else ((cumListDollars + cumListForecastDollars) / ListCommit) * 100
    if platform == 'aws':
      return 0 if RevShareCommit==0 else ((cumRevShareDollars + cumRevShareForecastDollars) / RevShareCommit) * 100
  return pctBurn

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"
  
@udf("string")
def forecastType(subscriptionId, contract_type):
  forecastType = 'MTM'
  if subscriptionId == 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = "SharedCommit"
  if subscriptionId != 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = 'SingleCommit'
  
  return forecastType

@udf("string")
def consumptionTypeForecast(aggOrder):
  consumptionTypeForecast = "MTM"
  if "Shared" in aggOrder:
    consumptionTypeForecast = "SharedCommit"
  if "Single" in aggOrder:
    consumptionTypeForecast = aggOrder
  if "AWS" in aggOrder:
    consumptionTypeForecast = "Commit"    
    
  
  return consumptionTypeForecast

# COMMAND ----------

# pvc_orders = spark.read.format("delta").load("/mnt/bse-dev/bi_aggorders_pvc")
# display(pvc_orders.orderBy("sfdcAccountID", "startDate"))

# COMMAND ----------

dates_df = spark.sql("select * from bdw.bi_dates")
# usagec_agg_order_daily - load from location directly
dropCumColumns = ["accountName","cumListDollars", "cumCustDollars", "cumRevShareDollars", "cumInteractiveDBUs", 
                  "cumAutomatedDBUs", "cumDeltaRevShareDollars", "cumDeltaInteractiveDBUs", "cumDeltaAutomatedDBUs",
                  "cumSQLAnalyticsDBUs", "cumSQLRevShareDollars"]
# aggOrderDaily = spark.read.format("delta").load("/mnt/bse-dev/backup_agg_order_daily")
# aggOrderDaily = spark.read.format("delta").load("/mnt/bse-dev/aws_usagec_agg_order_daily")

aggOrderDaily = spark.read.format("delta").load("/mnt/bse-dev/usagec_agg_order_daily_adhoc_pvc")
aggOrderDaily = aggOrderDaily.drop(*dropCumColumns)

account_dim = spark.sql("select distinct AccountID, AccountName from bdw.bi_account_dim")

# COMMAND ----------

allMaxUsageDates = aggOrderDaily.groupBy("accountId", "platform")\
                                .agg(max("usage_date").alias("maxUsageDate"))

#allMaxUsageDates.write.format("delta").mode("append").save("/mnt/bse-dev/usagec_maxdates")

# COMMAND ----------

aggOrderDaily.count()

# COMMAND ----------

# shared:  for Shared take the max usage date for each account , if the maxUsageDate < current_date(), then exclude it
# single:  for Single, take max usage date for each account, if there maxUsageDate < then, exclude it and if there are more than one such orders, then keep all of them
# MTM: Generate blanket consumptionType dollars 

date_df = spark.sql("select date from bdw.bi_dates where date > date_sub(current_date(), 365) and date < date_add(current_date(), 365)")
maxUsageDateAggOrder = aggOrderDaily.filter(aggOrderDaily.consumptionType != 'MTM')\
                                    .groupBy("accountId", "platform", "aggOrder")\
                                    .agg(max("usage_date").alias("maxUsageDate"))

maxDates = date_df.join(maxUsageDateAggOrder, date_df.date == maxUsageDateAggOrder.maxUsageDate)

# COMMAND ----------

aggOrderDaily = aggOrderDaily.withColumn("listForecastDollars", lit(0))\
                             .withColumn("custForecastDollars", lit(0))\
                             .withColumn("revShareForecastDollars", lit(0))\
                             .withColumn("InteractiveForecastDBUs", lit(0))\
                             .withColumn("AutomatedForecastDBUs", lit(0))\
                             .withColumn("SQLAnalyticsForecastDBUs", lit(0))\
                             .withColumn("SQLRevShareForecastDollars", lit(0))

# COMMAND ----------

pvc_orders = spark.read.format("delta").load("/mnt/bse-dev/bi_aggorders_pvc")
pvc_orders.createOrReplaceTempView("pvc_orders")

aggOrders_df = spark.sql("""
select aggOrder,
       sfdcAccountId,
       startDate,
       endDate,
       cloudPartnerPurchase ListCommit,
       ActualPartnerCommit DiscountedCommit,
       DBShareCommit RevShareCommit
from pvc_orders
""")

aggOrderDailyExtended = aggOrderDaily.join(aggOrders_df.select("aggOrder", "startDate", "endDate"), aggOrderDaily.aggOrder==aggOrders_df.aggOrder)\
                                     .drop(aggOrders_df.aggOrder)
aggOrderDailyExtended.count()

# COMMAND ----------

maxDates = maxDates.withColumn("consumptionTypeForecast", consumptionTypeForecast("aggOrder"))\
                   .withColumnRenamed("date", "usage_date")

# COMMAND ----------

aggOrderWindow = Window.partitionBy("accountId", "consumptionTypeForecast", "platform")\
                       .orderBy(col("usage_date").desc())
maxDatesPruned = maxDates.withColumn("rno", row_number().over(aggOrderWindow))\
                         .filter(col("rno")==1)\
                         .drop("rno", "maxUsageDate")

maxDatesPrunedExtended = maxDatesPruned.join(aggOrders_df, (maxDatesPruned.accountId==aggOrders_df.sfdcAccountId) & (maxDatesPruned.aggOrder==aggOrders_df.aggOrder))\
                                       .drop(aggOrders_df.sfdcAccountId)\
                                       .drop(aggOrders_df.aggOrder)\
                                       .drop(maxDatesPruned.consumptionTypeForecast)

maxDatesPrunedExtended.createOrReplaceTempView("maxUsageDateAggOrder")
display(maxDatesPrunedExtended.orderBy("accountId", "aggOrder"))

# COMMAND ----------

aggOrderDaily = aggOrderDaily.drop("consumptionType")
aggOrderDailyExtended = aggOrderDailyExtended.drop("consumptionType")

# COMMAND ----------

forecastCommitDaily = spark.sql("""
select f.accountId,
       f.platform,
       m.aggOrder,
       f.date usage_date,
       m.ListCommit,
       m.DiscountedCommit,
       m.RevShareCommit,       
       0 listDollars,
       0 custDollars,
       0 revShareDollars,
       0 InteractiveDBUs,
       0 AutomatedDBUs, 
       0 DeltaRevShareDollars,
       0 DeltaInteractiveDBUs,
       0 DeltaAutomatedDBUs, 
       0 SQLAnalyticsDBUs,
       0 SQLRevShareDollars,  
       0 StandardDBUs,
       0 PremiumDBUs,       
       0 EnterpriseDBUs,       
       0 StandardRevShareDollars,
       0 PremiumRevShareDollars,       
       0 EnterpriseRevShareDollars, 
       0 MoonCakeDBUs,
       0 MoonCakeDeltaDBUs,
       0 MoonCakeDBUDollars,
       0 MoonCakeDeltaDBUDollars,       
       round(f.DBUListSpend,2) listForecastDollars,
       round(f.DBUCustSpend,2) custForecastDollars,
       round(f.DBURevShareSpend, 2) revShareForecastDollars,
       round(f.interactive_dbus, 2) InteractiveForecastDBUs,
       round(f.automated_dbus, 2) AutomatedForecastDBUs,  
       round(f.sql_dbus, 2) SQLAnalyticsForecastDBUs,
       0 SQLRevShareForecastDollars,        
       m.startDate,
       m.endDate
from usagedashboard.account_usage_and_forecast f
join maxUsageDateAggOrder m on f.accountId = m.accountId and f.platform = m.platform and lower(f.orderId) = lower(m.aggOrder)
where date > m.usage_date 
order by f.accountId, f.platform, m.aggOrder, f.date
""")


forecastMTMDaily = spark.sql("""
with MTMOrders (
select aggOrder,
       platform,
       sfdcAccountId,
       sfdcAccountName,
       startDate,
       endDate
from pvc_orders
where aggOrder like 'MTM%'
)
select f.accountId,
       f.platform,
       m.aggOrder,
       f.date usage_date,
       0 ListCommit,
       0 DiscountedCommit,
       0 RevShareCommit,       
       0 listDollars,
       0 custDollars,
       0 revShareDollars,
       0 InteractiveDBUs,
       0 AutomatedDBUs, 
       0 DeltaRevShareDollars,
       0 DeltaInteractiveDBUs,
       0 DeltaAutomatedDBUs, 
       0 SQLAnalyticsDBUs,
       0 SQLRevShareDollars,
       0 StandardDBUs,
       0 PremiumDBUs,       
       0 EnterpriseDBUs,       
       0 StandardRevShareDollars,
       0 PremiumRevShareDollars,       
       0 EnterpriseRevShareDollars,   
       0 MoonCakeDBUs,
       0 MoonCakeDeltaDBUs,
       0 MoonCakeDBUDollars,
       0 MoonCakeDeltaDBUDollars,       
       round(f.DBUListSpend,2) listForecastDollars,
       round(f.DBUCustSpend,2) custForecastDollars,
       round(f.DBURevShareSpend, 2) revShareForecastDollars,
       round(f.interactive_dbus, 2) InteractiveForecastDBUs,
       round(f.automated_dbus, 2) AutomatedForecastDBUs, 
       round(f.sql_dbus, 2) SQLAnalyticsForecastDBUs,
       0 SQLRevShareForecastDollars,        
       m.startDate,
       m.endDate
from usagedashboard.account_usage_and_forecast f
join MTMOrders m on f.accountId = m.sfdcAccountId and f.platform = m.platform and lower(f.orderId) = lower(m.aggOrder)
where date > current_date()
order by f.accountId, f.platform, m.aggOrder, f.date
""")

# COMMAND ----------


missingForecastDaily = spark.sql("""

with pvc_accounts (
select distinct sfdcAccountId
from pvc_orders
),

pvc_forecast_orders (
select distinct f.orderId pvcFcstOrder, f.accountId
from usagedashboard.account_usage_and_forecast f 
join pvc_accounts pvc on f.accountId = pvc.sfdcAccountId
where f.date > current_date()
and f.orderId not like 'MTM%'
),

missingPvcOrders (
select pvcFcstOrder, 
       pvc.accountId, 
       agg.startDate, 
       agg.endDate, 
       coalesce(agg.cloudPartnerPurchase, 0) ListCommit,
       coalesce(agg.ActualPartnerCommit,0) DiscountedCommit,
       coalesce(agg.DBShareCommit, 0) RevShareCommit,
       agg.Platform platform
from pvc_forecast_orders pvc
left join maxUsageDateAggOrder m on lower(pvc.pvcFcstOrder) = lower(m.aggOrder)
left join bdw.bi_aggorders agg on lower(pvc.pvcFcstOrder) = lower(agg.aggOrder)
where m.aggOrder is null
)

select f.accountId,
       f.platform,
       m.pvcFcstOrder aggOrder,
       f.date usage_date,
       m.ListCommit,
       m.DiscountedCommit,
       m.RevShareCommit,       
       0 listDollars,
       0 custDollars,
       0 revShareDollars,
       0 InteractiveDBUs,
       0 AutomatedDBUs, 
       0 DeltaRevShareDollars,
       0 DeltaInteractiveDBUs,
       0 DeltaAutomatedDBUs, 
       0 SQLAnalyticsDBUs,
       0 SQLRevShareDollars,
       0 StandardDBUs,
       0 PremiumDBUs,       
       0 EnterpriseDBUs,       
       0 StandardRevShareDollars,
       0 PremiumRevShareDollars,       
       0 EnterpriseRevShareDollars,  
       0 MoonCakeDBUs,
       0 MoonCakeDeltaDBUs,
       0 MoonCakeDBUDollars,
       0 MoonCakeDeltaDBUDollars,       
       round(f.DBUListSpend,2) listForecastDollars,
       round(f.DBUCustSpend,2) custForecastDollars,
       round(f.DBURevShareSpend, 2) revShareForecastDollars,
       round(f.interactive_dbus, 2) InteractiveForecastDBUs,
       round(f.automated_dbus, 2) AutomatedForecastDBUs,  
       0 SQLAnalyticsForecastDBUs,
       0 SQLRevShareForecastDollars,       
       m.startDate,
       m.endDate
from usagedashboard.account_usage_and_forecast f
join missingPvcOrders m on f.accountId = m.accountId and lower(f.orderId) = lower(m.pvcFcstOrder)
where f.date > '2021-03-31' 
order by f.accountId, f.platform, m.pvcFcstOrder, f.date
""")

missingForecastDaily.count()

# COMMAND ----------

forecastDaily = forecastCommitDaily.union(forecastMTMDaily) 
forecastDaily = missingForecastDaily.union(forecastDaily)
forecastDaily.count()

# COMMAND ----------

aggOrderConsumpCast = aggOrderDailyExtended.union(forecastDaily)

# add month_end_date to Daily
aggOrderConsumpCastDaily = aggOrderConsumpCast.join(dates_df.select("date", "month_end_date"), aggOrderConsumpCast.usage_date==dates_df.date)\
                                         .drop(dates_df.date)
aggOrderConsumpCastDaily = aggOrderConsumpCastDaily.orderBy("accountId", "platform", "aggOrder", "usage_date")

# COMMAND ----------

orderByColumns = ["accountID", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)


aggOrderConsumpCastDailyCum  =   aggOrderConsumpCastDaily.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                         .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                         .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                         .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                         .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                         .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                         .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                         .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                                                         .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

aggOrderConsumpCastDailyCum = aggOrderConsumpCastDailyCum.withColumn("consumptionType", consumptionType("aggOrder"))\
                                                         .drop("month_end_date")

# COMMAND ----------

aggOrderConsumpCastDailyCum = aggOrderConsumpCastDailyCum.orderBy(*orderByColumns)

# COMMAND ----------

pctBurnColumns = ["platform", "aggOrder", "ListCommit", "RevShareCommit", "cumListDollars", "cumRevShareDollars", "cumListForecastDollars", "cumRevShareForecastDollars"]
aggOrderConsumpCastDailyCumMetrics = aggOrderConsumpCastDailyCum.withColumn("pctBurn", round(pctBurn(*pctBurnColumns),2))

# COMMAND ----------

aggOrderConsumpCastDailyCumMetricsJoin = aggOrderConsumpCastDailyCumMetrics.join(account_dim, aggOrderConsumpCastDailyCumMetrics.accountId == account_dim.AccountID)\
                                               .drop(account_dim.AccountID)

aggOrderConsumpCastDailyCumMetricsJoin = aggOrderConsumpCastDailyCumMetricsJoin.withColumnRenamed("AccountName", "accountName")

# COMMAND ----------

#aggOrderConsumpCastDailyCumMetricsJoin.createOrReplaceTempView("aggorder_daily")

# COMMAND ----------

#aggOrderConsumpCastDailyCumMetricsJoin.write.option("overwriteSchema", "true").format("delta").mode("append").save("/mnt/bse-dev/usagec_aggorder_daily_gold_adhoc")

aggOrderConsumpCastDailyCumMetricsJoin.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/pvc_usagec_aggorder_daily_gold")

# COMMAND ----------

# daily_df = spark.sql("select * from bdw.usagec_aggorder_daily version")
# daily_df = daily_df.drop('actualBurstDate', 'expectedBurstDate')
# daily_df.createOrReplaceTempView("daily")

# COMMAND ----------

#set(daily_df.columns).difference(set(aggOrderConsumpCastDailyCumMetricsJoin.columns))

# COMMAND ----------

# pvc_daily = spark.read.format("delta").load("/mnt/bse-dev/pvc_usagec_aggorder_daily_gold")
# pvc_daily.createOrReplaceTempView("pvc_daily")

# COMMAND ----------

# %sql
# select *
# from pvc_daily
# where accountId like '00161000016vS8lAAE%'
# --and usage_date >= '2020-05-01' and usage_date <= '2020-07-31'
# order by usage_date

# COMMAND ----------

# %sql
# select *
# from daily
# where accountId like '00161000016vS8lAAE%'
# --and usage_date >= '2020-05-01' and usage_date <= '2020-07-31'
# order by usage_date

# COMMAND ----------

# %sql
# select distinct 
#        d.accountId,
#        p.accountId,
#        d.accountName
# from daily d
# join pvc_daily p on d.accountId = p.accountId

# COMMAND ----------

# %sql
# select *
# from finance.pvc_usage
# -- with all_usage(
# -- select *
# -- from pvc_daily

# -- union all

# -- select *
# -- from daily
# -- )

# -- select *
# -- from all_usage
# -- where accountId like '00161000016vS8lAAE%'
# -- and usage_date >= '2020-05-01' and usage_date <= '2020-07-31'
# -- order by usage_date

# COMMAND ----------

# %sql
# create table bdw.usagec_aggorder_daily
# using delta
# location "/mnt/bse-dev/usagec_aggorder_daily_gold"

# COMMAND ----------

# DBTITLE 1,AggOrder Monthly
aggOrderConsumpCastDailyCumMetricsJoin = aggOrderConsumpCastDailyCumMetricsJoin.join(dates_df.select("date", "month_end_date"), aggOrderConsumpCastDailyCumMetricsJoin.usage_date==dates_df.date)\
                                                   .drop(dates_df.date)

aggOrderAggColumns = ["accountId", "accountName", "platform", "aggOrder", "month_end_date"]
aggOrderMonthly =  aggOrderConsumpCastDailyCumMetricsJoin.groupBy(*aggOrderAggColumns)\
                                           .agg(\
                                                 round(max("ListCommit"),4).alias("ListCommit"),\
                                                 round(max("DiscountedCommit"),4).alias("DiscountedCommit"),\
                                                 round(max("RevShareCommit"),4).alias("RevShareCommit"),\
                                                 round(sum("listDollars"),4).alias("listDollars"),\
                                                 round(sum("custDollars"),4).alias("custDollars"),\
                                                 round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                 round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                 round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                 round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                 round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                 round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                 round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                 round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                 round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                 round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                 round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                 round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                 round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                 round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                 round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars")\
                                               )
aggOrderMonthly = aggOrderMonthly.orderBy("accountId", "accountName", "platform", "aggOrder","month_end_date")

partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("month_end_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

aggOrderMonthly = aggOrderMonthly.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                         .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                         .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                         .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                         .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                         .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                         .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                         .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                         .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                         .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                         .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                         .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                         .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                         .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                         .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                         .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                         .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

aggOrderMonthlyExtended = aggOrderMonthly.join(aggOrders_df.select("aggOrder", "startDate", "endDate"), aggOrderMonthly.aggOrder==aggOrders_df.aggOrder)\
                                       .drop(aggOrders_df.aggOrder)
aggOrderMonthlyExtended.count()

# COMMAND ----------

aggOrderMonthlyExtended = aggOrderMonthlyExtended.orderBy("accountID", "accountName", "platform", "aggOrder", "month_end_date")

# COMMAND ----------

pctBurnColumns = ["platform", "aggOrder", "ListCommit", "RevShareCommit", "cumListDollars", "cumRevShareDollars", "cumListForecastDollars", "cumRevShareForecastDollars"]
aggOrderMonthlyMetrics = aggOrderMonthlyExtended.withColumn("pctBurn", round(pctBurn(*pctBurnColumns),2))

# COMMAND ----------

#aggOrderMonthlyMetrics.write.option("overwriteSchema", "true").format("delta").mode("append").save("/mnt/bse-dev/usagec_aggorder_monthly_gold")

# COMMAND ----------

# %sql
# create table bdw.usagec_aggorder_monthly
# using delta
# location "/mnt/bse-dev/usagec_aggorder_monthly_gold"

# COMMAND ----------

# DBTITLE 1,Platform Daily and Monthly
platformDailyColumns = ["accountId", "accountName", "platform", "usage_date"]
consumptionPlatformDaily = aggOrderConsumpCastDailyCumMetricsJoin.groupBy(*platformDailyColumns)\
                                                   .agg(\
                                                         max("ListCommit").alias('ListCommit'),\
                                                         max("DiscountedCommit").alias('DiscountedCommit'),\
                                                         max("RevShareCommit").alias('RevShareCommit'),\
                                                         round(sum("listDollars"),4).alias("listDollars"),\
                                                         round(sum("custDollars"),4).alias("custDollars"),\
                                                         round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                         round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                         round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                         round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                         round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                         round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                         round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                         round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                         round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                         round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                         round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                         round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                         round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                         round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                         round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars")\
                                                       )

consumptionPlatformDaily = consumptionPlatformDaily.orderBy("accountId", "accountName", "platform", "usage_date")

orderByColumns = ["accountID", "accountName", "platform", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)


consumptionPlatformDailyCum  =   consumptionPlatformDaily.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                         .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                         .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                         .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                         .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                         .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                         .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                         .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                                                         .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

consumptionPlatformDailyCum = consumptionPlatformDailyCum.orderBy(*orderByColumns)

# COMMAND ----------

#consumptionPlatformDailyCum.write.option("overwriteSchema", "true").format("delta").mode("append").save("/mnt/bse-dev/usagec_platform_daily_gold")

# COMMAND ----------

# %sql
# create table bdw.usagec_platform_daily
# using delta
# location "/mnt/bse-dev/usagec_platform_daily_gold"

# COMMAND ----------

# DBTITLE 1,plat-monthly
consumptionPlatformDaily = consumptionPlatformDaily.join(dates_df.select("date", "month_end_date"), consumptionPlatformDaily.usage_date==dates_df.date)\
                                                   .drop(dates_df.date)

platAggColumns = ["accountId", "accountName", "platform", "month_end_date"]
platMonthly =  consumptionPlatformDaily.groupBy(*platAggColumns)\
                                           .agg(\
                                                 round(max("ListCommit"),4).alias("ListCommit"),\
                                                 round(max("DiscountedCommit"),4).alias("DiscountedCommit"),\
                                                 round(max("RevShareCommit"),4).alias("RevShareCommit"),\
                                                 round(sum("listDollars"),4).alias("listDollars"),\
                                                 round(sum("custDollars"),4).alias("custDollars"),\
                                                 round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                 round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                 round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                 round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                 round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                 round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                 round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                 round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                 round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                 round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                 round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                 round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                 round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                 round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                 round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars")\
                                               )
platMonthly = platMonthly.orderBy("accountId", "accountName", "platform", "month_end_date")

partitionByColumns = ["accountID", "accountName", "platform"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("month_end_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

platMonthlyCum =  platMonthly.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                             .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                             .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                             .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                             .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                             .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

#platMonthlyCum.write.option("overwriteSchema", "true").format("delta").mode("append").save("/mnt/bse-dev/usagec_platform_monthly_gold")

# COMMAND ----------

# %sql
# create table bdw.usagec_platform_monthly
# using delta
# location "/mnt/bse-dev/usagec_platform_monthly_gold"

# COMMAND ----------

# DBTITLE 1,Account Monthly
accAggColumns = ["accountId", "accountName", "month_end_date"]
accMonthly =  platMonthly.groupBy(*accAggColumns)\
                                           .agg(\
                                                 round(sum("listDollars"),4).alias("listDollars"),\
                                                 round(sum("custDollars"),4).alias("custDollars"),\
                                                 round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                 round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                 round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                 round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                 round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                 round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                 round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                 round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                 round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                 round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                 round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                 round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                 round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                 round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                 round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars")\
                                               )
accMonthly = accMonthly.orderBy("accountId", "accountName", "month_end_date")

partitionByColumns = ["accountID", "accountName"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("month_end_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

accMonthlyCum =    accMonthly.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                             .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                             .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                             .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                             .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                             .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

account_monthly_extended = accMonthlyCum.withColumn("workspace_users_count", lit(0))\
                                        .withColumn("workspace_users_count", col("workspace_users_count").cast("long"))

# COMMAND ----------

account_monthly_extended.count()

# COMMAND ----------

#account_monthly_extended.write.option("overwriteSchema", "true").format("delta").mode("append").save("/mnt/bse-dev/usagec_account_monthly_gold")

# COMMAND ----------

# %sql
# create table bdw.usagec_account_monthly
# using delta
# location "/mnt/bse-dev/usagec_account_monthly_gold"

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))