# Databricks notebook source
import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

aws_usage_granular_df = spark.sql("""
select accountID,
       accountName,
       date usage_date,
       lower(sku) usage_sku,
       round(DBU,4) dbu_quantity,
       workspaceSFDCID,
       platform,
       listPrice,
       dbuPrice dbuRevSharePrice,
       discountPrice dbuCustPrice,
       round(deltaDBU,4) delta_dbu_quantity,
       clusterId
from finance.finance_usage_pricing
where platform in ('aws', 'gcp')
order by date desc
""")

azure_usage_granular_df = spark.sql("""
select accountID,
       accountName,
       coalesce(lower(azureSubID), 'noSubscriptionID') SubscriptionID,
       date usage_date,
       lower(sku) usage_sku,
       round(DBU,4) dbu_quantity,
       workspaceSFDCID,
       platform,
       listPrice,
       dbuPrice dbuRevSharePrice,
       discountPrice dbuCustPrice,
       round(deltaDBU,4) delta_dbu_quantity,
       clusterId       
from finance.finance_usage_pricing
where platform = 'azure'
order by date desc
""")

# COMMAND ----------

print(aws_usage_granular_df.count())
print(aws_usage_granular_df.dropDuplicates().count())

# COMMAND ----------

print(azure_usage_granular_df.count())
print(azure_usage_granular_df.filter(azure_usage_granular_df.accountID.isNotNull()).count())

# COMMAND ----------

# DBTITLE 1,workspaceSFID-workspaceID mapping
wksp_query = """
  select distinct
         swk.workspaceId__c workspaceId,
         coalesce(swk.azureSubscriptionId__c, 'noSubscriptionID') SubscriptionID,
         swk.deployedRegion__c deployedRegion,         
         swk.Id workspaceIdSFDC
  from sfdc_ds.workspace__c swk
  where swk.processDate = (select max(processDate) from sfdc_ds.workspace__c)
"""
wksp_df = spark.sql(wksp_query)
#display(wksp_df)

# COMMAND ----------

aws_usage_granular_df = aws_usage_granular_df.join(wksp_df, aws_usage_granular_df.workspaceSFDCID==wksp_df.workspaceIdSFDC)\
                                             .drop(wksp_df.workspaceIdSFDC)\
                                             .drop(wksp_df.SubscriptionID)
aws_usage_granular_df.count()

# COMMAND ----------

aws_usage_granular_df.createOrReplaceTempView("aws_usage_granular")

# COMMAND ----------

azure_usage_granular_df = azure_usage_granular_df.join(wksp_df, azure_usage_granular_df.workspaceSFDCID==wksp_df.workspaceIdSFDC)\
                                                 .drop(wksp_df.workspaceIdSFDC)\
                                                 .drop(wksp_df.SubscriptionID)
azure_usage_granular_df.count() 

# COMMAND ----------

# DBTITLE 1,AWS Order-Build up
aws_orders_granular_query = """
with initial_usage_orders (
select ug.*,
       agg.aggOrder,
       agg.SubscriptionID,
       agg.scope,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit,
       case when count(usage_date) over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, dbu_quantity, clusterId) > 1 then 'true'
            else 'false'
       end as usageFlag,
       case when scope = 'shared'  then 'false'
            else 'true'
       end as scopeFlag
from aws_usage_granular ug
join bdw.bi_aggorders agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
                         and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where ug.platform in ('aws', 'gcp')
order by usage_date
)
select *
from initial_usage_orders
where (usageFlag='true' and scopeFlag='true') or (usageFlag='false' and scopeFlag='false')
"""

aws_orders_granular_df = spark.sql(aws_orders_granular_query)
dropColumns = ["usageFlag", "scopeFlag"]
aws_orders_granular_df = aws_orders_granular_df.drop(*dropColumns)

# COMMAND ----------

aws_orders_granular_df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC AWS:
# MAGIC For an account-platform, get min(usage_date) and then, lookup for a contract for the date, until the end of the contract. 
# MAGIC                 exception: for the parallel contracts, use workspaceId to separate the contracts
# MAGIC                 In all other cases, it should be tagged as MTM/PAYG.
# MAGIC                 
# MAGIC Azure:
# MAGIC For an account-platform, get min(usage_date), 1. look for Single scoped order for the workspace and tag it if it exists                                                                  2. If not, then, look for Shared scoped subscription and tag if it doesnt exceed Quantity(MDS)
# MAGIC                                       in all other cases, it should be tagged as MTM/PAYG

# COMMAND ----------

# DBTITLE 1,Azure orders buildup
agg_azure_orders_df = spark.sql("""select SubscriptionID aggSubscriptionID, platform aggPlatform, sfdcAccountID, aggOrder, scope, startDate,  
                                          coalesce(usageBurstDate, endDate) endDate, cloudPartnerPurchase, ActualPartnerCommit,DBShareCommit
                                   from bdw.bi_aggorders
                                   where platform = 'azure'
                               """)
azure_usage_orders_df = azure_usage_granular_df.join(agg_azure_orders_df, (azure_usage_granular_df.accountID == agg_azure_orders_df.sfdcAccountID)\
                                                                  & (azure_usage_granular_df.platform == agg_azure_orders_df.aggPlatform)\
                                                                  & (azure_usage_granular_df.SubscriptionID == agg_azure_orders_df.aggSubscriptionID)\
                                                                  & ((azure_usage_granular_df.usage_date >= agg_azure_orders_df.startDate)\
                                                                     & (azure_usage_granular_df.usage_date <= agg_azure_orders_df.endDate)),\
                                                                  'left')

# COMMAND ----------

azure_usage_orders_df.count()

# COMMAND ----------

#display(azure_usage_granular_df.filter((azure_usage_granular_df.accountID=='0014N00001g7s1AQAQ') & (azure_usage_granular_df.usage_date >= "2020-01-16")).orderBy("usage_date"))

# COMMAND ----------

#display(agg_azure_orders_df.filter(agg_azure_orders_df.sfdcAccountID=='0014N00001g8CvNQAU'))

# COMMAND ----------

#display(azure_usage_orders_df.filter((azure_usage_orders_df.accountID=='0014N00001g7s1AQAQ') & (azure_usage_orders_df.usage_date >= "2020-01-16")).orderBy("usage_date"))

# COMMAND ----------

azure_single_orders_df = azure_usage_orders_df.filter((azure_usage_orders_df.aggSubscriptionID.isNotNull()))

# COMMAND ----------

azure_single_orders_df.count()

# COMMAND ----------

dropColumns = ["aggSubscriptionID", "aggPlatform", "sfdcAccountID", "aggOrder", "scope", "startDate", "endDate", 
               "cloudPartnerPurchase", "ActualPartnerCommit", "DBShareCommit"]
azure_only_shared_orders_df = azure_usage_orders_df.filter(azure_usage_orders_df.aggSubscriptionID.isNull())\
                                              .drop(*dropColumns)
azure_only_shared_orders_df.createOrReplaceTempView("azure_shared_usage")

# COMMAND ----------

# %sql
# select ug.*,
#        agg.aggOrder,
#        agg.scope,
#        agg.startDate,
#        agg.endDate,
#        agg.cloudPartnerPurchase,
#        agg.ActualPartnerCommit,
#        agg.DBShareCommit
# from azure_shared_usage ug
# join bdw.bi_aggorders agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
#                          and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
# where agg.scope != 'Single'
# and agg.sfdcAccountID = '0014N00001g7s1AQAQ'
# and ug.usage_date = '2020-01-18'
# order by usage_date, dbu_quantity

# COMMAND ----------

# %sql
# with initial_usage_orders (
# select ug.*,
#        agg.aggOrder,
#        agg.scope,
#        agg.startDate,
#        coalesce(agg.usageBurstDate, agg.endDate) endDate,
#        agg.cloudPartnerPurchase,
#        agg.ActualPartnerCommit,
#        agg.DBShareCommit,
#        case when count(usage_date) over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, dbu_quantity) > 1 then 'true'
#             else 'false'
#        end as usageFlag,
#        case when scope = 'shared'  then 'false'
#             else 'true'
#        end as scopeFlag
# from azure_shared_usage ug
# join bdw.bi_aggorders agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
#                          and ug.usage_date >= agg.startDate and ug.usage_date <= coalesce(agg.usageBurstDate, agg.endDate)
# where agg.scope != 'Single'
# and agg.sfdcAccountID = '0014N00001g7s1AQAQ'
# and ug.usage_date = '2020-03-31'
# order by usage_date, dbu_quantity
# )

# select *,
#        row_number() over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, dbu_quantity, scope order by startDate desc) rank_order
# from initial_usage_orders
# where (usageFlag='true' and scopeFlag='true') or 
#       (usageFlag='false' and scopeFlag='false')


# COMMAND ----------

"""
-- partition: if there is same usage for more than once for the same date, then it must be both PAYG/MTM, Shared-Commit
--            in which case, put a usageFlag 'true' indicating there is 'Shared-commit', else it's just 'PAYG/MTM'

-- Rank them if same usage is tagged to 'Shared-Commit' by startDate, and then take earliest Shared-Order
-- todo: Make sure Quantity(MDS) takes precedence and transition to next Shared-Commit, if earlier Shared-Order burned down completely
"""

clean_azure_shared_orders_df = spark.sql("""
with initial_usage_orders (
select ug.*,
       agg.aggOrder,
       agg.scope,
       agg.startDate,
       coalesce(usageBurstDate, endDate) endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit,
       case when count(usage_date) over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, dbu_quantity, clusterId, dbuRevSharePrice) > 1 then 'true'
            else 'false'
       end as usageFlag,
       case when scope = 'shared'  then 'false'
            else 'true'
       end as scopeFlag
from azure_shared_usage ug
join bdw.bi_aggorders agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
                         and ug.usage_date >= agg.startDate and ug.usage_date <= coalesce(agg.usageBurstDate, agg.endDate)
where agg.scope != 'Single'
order by usage_date
),

ranked_usage_orders (
select *,
       row_number() over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, dbu_quantity, clusterId, scope order by startDate) rank_order
from initial_usage_orders
where (usageFlag='true' and scopeFlag='true') or (usageFlag='false' and scopeFlag='false')
)

select *
from ranked_usage_orders
where rank_order = 1
""")

# COMMAND ----------

clean_azure_shared_orders_df.count()

# COMMAND ----------

singleOrderDropColumns = ["aggSubscriptionID", "aggPlatform", "sfdcAccountID"]
azure_single_df = azure_single_orders_df.drop(*singleOrderDropColumns)

sharedOrderDropColumns = ["usageFlag", "scopeFlag", "rank_order"]
azure_shared_df = clean_azure_shared_orders_df.drop(*sharedOrderDropColumns)

# COMMAND ----------

azure_combined_orders_df = azure_shared_df.union(azure_single_df)

# COMMAND ----------

azure_combined_orders_df.createOrReplaceTempView("azure_combined_orders")
clean_azure_usage_df = spark.sql("""
with ranked_orders(
select *,
       row_number() over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, dbu_quantity, clusterId, scope order by startDate) rno
from azure_combined_orders
)
select *
from ranked_orders
where rno = 1
""")
clean_azure_usage_df = clean_azure_usage_df.drop(clean_azure_usage_df.rno).drop(clean_azure_usage_df.clusterId)

# COMMAND ----------

clean_azure_usage_df.count() #4625581

# COMMAND ----------

aws_orders_granular_df.createOrReplaceTempView("aws_usage_orders")

clean_aws_usage_df = spark.sql("""
with ranked_orders(
select *,
       row_number() over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, dbu_quantity, dbuRevSharePrice, clusterId, scope order by startDate) rno
from aws_usage_orders
)
select *
from ranked_orders
where rno = 1
""")
clean_aws_usage_df = clean_aws_usage_df.drop(clean_aws_usage_df.rno).drop(clean_aws_usage_df.clusterId)

# COMMAND ----------

clean_aws_usage_df = clean_aws_usage_df.select(*sorted(clean_aws_usage_df.columns))
clean_azure_usage_df = clean_azure_usage_df.select(*sorted(clean_azure_usage_df.columns))
order_usage_granular_df = clean_azure_usage_df.union(clean_aws_usage_df)
print(order_usage_granular_df.count())

# COMMAND ----------

@udf('string')
def unmappedAggOrder(platform, accountId):
  
  if platform == 'azure':
    aggorder = 'MTMAzure' + accountId
  elif platform == 'aws':
    aggorder = 'MTMAWS' + accountId
  else:
    aggorder = 'MTMGCP' + accountId
    
  return aggorder

@udf('string')
def unmappedAccount(region):
  
  if region == 'APJ':
    accountId = '0013f0000063xxQAAQ'
  elif region == 'EMEA':
    accountId = '0013f0000063xxLAAQ'
  else:
    accountId = '0013f000005RwT9AAK'
  
  return accountId

unmapped_finance_usage = spark.sql("""
select accountId,
       'Unmapped Workspace' accountName, 
       date usage_date,
       lower(sku) usage_sku,
       round(DBU,4) dbu_quantity,
       workspaceSFDCID,
       f.workspaceId,
       f.platform,
       listPrice,
       dbuPrice dbuRevSharePrice,
       discountPrice dbuCustPrice,
       round(deltaDBU,4) delta_dbu_quantity,
       'MTMSubscriptionID' SubscriptionID,
       'shared' scope,
       cast('2018-01-01' as date) startDate,
       cast('2024-12-31' as date) endDate,
       cast(0 as double) cloudPartnerPurchase,
       cast(0 as double) ActualPartnerCommit,
       cast(0 as double) DBShareCommit
from finance.finance_usage_pricing f 
where f.accountId is null
and f.platform in ('aws', 'azure', 'gcp')
order by f.date desc
""")

current_wksp_snap = spark.sql("""
select wk.workspaceId__c,
       wk.deployedRegion__c deployedRegion
from sfdc_ds.workspace__c wk
where processDate = (select max(processDate) from sfdc_ds.workspace__c)
""")

region_dim = spark.sql("select deployedRegion, region from bdw.bi_region_dim")

unmapped_usage = unmapped_finance_usage.join(current_wksp_snap, unmapped_finance_usage.workspaceId == current_wksp_snap.workspaceId__c, 'left')\
                                       .drop(current_wksp_snap.workspaceId__c)

unmapped_usage = unmapped_usage.join(region_dim, unmapped_usage.deployedRegion == region_dim.deployedRegion, 'left')\
                                   .drop(region_dim.deployedRegion)

unmapped_usage = unmapped_usage.withColumn("accountId", unmappedAccount("region"))\
                               .withColumn("aggOrder", unmappedAggOrder("platform", "accountId"))\
                               .drop("region")\
                               .withColumnRenamed("accountId", "accountID")

unmapped_usage = unmapped_usage.select(*sorted(unmapped_usage.columns))
order_usage_granular_df = order_usage_granular_df.union(unmapped_usage)
print(order_usage_granular_df.count())

# COMMAND ----------

order_usage_granular_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_prod_daily_granular")

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))