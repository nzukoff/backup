# Databricks notebook source
dbutils.library.installPyPI("simple-salesforce")

# COMMAND ----------

from simple_salesforce import Salesforce
import pandas as pd
import numpy as np

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

from datetime import datetime

# COMMAND ----------

def get_creds(prefix):
  """
  params:
         prefix - 'uat' for uat, 'lfsf' for prod
  returns:
         list of user_name, password, security_token, client_id, client_secret
  """
  username = dbutils.secrets.get('api-creds', prefix+'_username')
  password = dbutils.secrets.get('api-creds', prefix+'_password')
  security_token = dbutils.secrets.get('api-creds', prefix+'_security_token')
  client_id = dbutils.secrets.get('api-creds', prefix+'_client_id')
  client_secret = dbutils.secrets.get('api-creds', prefix+'_client_secret')
  return [username, password, security_token, client_id, client_secret]


def get_sfdc_connection(creds, domain):
  """
  params:
         creds - connection credentials
         domain - 'test' for uat, 'databricks.my' for prod
  returns:
         sfdc connection object
  """
  return Salesforce(username=creds[0], \
                    password=creds[1], \
                    security_token=creds[2], \
                    domain=domain)


def get_dataframe(query, environement_prefix, domain):

    """
    calls get_creds, get_sfdc_connection functions
    uses salesforce's soql query api 
    params: query, environement_prefix, domain
    returns: pandas dataframe
    """
  
    creds = get_creds(environement_prefix)
    sf = get_sfdc_connection(creds, domain)
    
    list_data_records = []
    data = sf.query(query)
    list_data_records = data['records']
    prev_counter = 0
    cur_counter = 0
    while 'nextRecordsUrl' in data.keys():
        next_record = data['nextRecordsUrl'].split('/')[-1]
        data = sf.query_more(next_record)
        list_data_records += data['records']
        if cur_counter-prev_counter >= 50000:
          prev_counter = cur_counter
          sf = get_sfdc_connection(creds, domain) # connection reset
        cur_counter = len(list_data_records)
    return pd.DataFrame(list_data_records).drop(columns='attributes')
  
  
import numpy as np
import pandas as pd
from pyspark.sql.types import *
pandas_spark_types_map = {
                    np.int8: ByteType(),
                    np.uint8: ShortType(),
                    np.int16: ShortType(),
                    np.uint16: IntegerType(),
                    np.int32: IntegerType(),
                    np.int64: LongType(),
                    np.float32: FloatType(),
                    np.float64: DoubleType(),
                    np.string_: StringType(),
                    np.str_: StringType(),
                    np.unicode_: StringType(),
                    np.bool_: BooleanType(),
                    np.object_: StringType()
                }

def build_spark_schema(numpy_dtypes):
    """
    takes pandas dtypes and converts to Spark Schema
    parms: numpy_dtypes, pandas_spark_types_map
    returns: Pyspark Schema
    """
    return StructType([StructField(col_name, pandas_spark_types_map[col_type.type], True) for col_name, col_type in numpy_dtypes.iteritems()])

# COMMAND ----------

# DBTITLE 1,PoP Metrics
# <D><AccountId>:<AggOrder>:<YYYYMMDD>
@udf("String")
def popUniqueId(accountId, platform):
  return accountId + ":" + platform

pop_rename_column_map = {
  "accountId" : "Account_Id__c",
  "AutomatedForecastDBUs" : "AutomatedForecastDBU__c",
  "AutomatedDBUs": "Automated_DBUs__c",
  "cumAutomatedDBUs": "CumAutomatedDBU__c",
  "cumAutomatedForecastDBUs" : "CumAutomatedFcstDBU__c",
  "cumCustDollars" : "CumCustDollars__c",
  "cumCustForecastDollars" : "CumCustFcstDollars__c",
  "cumInteractiveDBUs" : "CumInteractiveDBU__c",
  "cumInteractiveForecastDBUs" : "CumInteractiveFcstDBU__c",
  "cumListDollars" : "CumListDollars__c",
  "cumListForecastDollars" : "CumListFcstDollars__c",
  "cumRevShareDollars" : "CumRevShareDollars__c",
  "cumRevShareForecastDollars" : "CumRevShareFcstDollars__c",
  "custForecastDollars" : "CustForecastDollars__c",
  "custDollars" : "Cust_Dollars__c",
  "DiscountedCommit": "Discounted_Commit__c",
  "InteractiveForecastDBUs" : "InteractiveForecastDBU__c",
  "InteractiveDBUs" : "Interactive_DBUs__c",
  "listForecastDollars" : "ListForecastDollars__c",
  "ListCommit" : "List_Commit__c",
  "listDollars" : "List_Dollars__c",
  "platform" : "Platform__c",
  "revShareForecastDollars" : "RevShareForecastDollars__c",
  "RevShareCommit" : "RevShare_Commit__c",
  "revShareDollars" : "RevShare_Dollars__c",
  "RevShareLastWeek" : "RevShareLastWeek__c",
  "RevShareCurrentWeek" : "RevShareCurrentWeek__c",
  "RevShareNextWeek" : "RevShareFsctNextWeek__c",
  "RevShareLastMonth" : "RevShareLastMonth__c",
  "RevShareCurrentMonth" : "RevShareCurrentMonth__c",
  "RevShareNextMonth" : "RevShareFcstNextMonth__c",
  "RevShareLastQtr" : "RevShareLastQtr__c",
  "RevShareCurrentQtr" : "RevShareCurrentQtr__c",
  "RevShareNextQtr" : "RevShareFcstNextQtr__c",
  "RevShareDollarsQTD": "RevShareDollarsQTD__c",
  "RevShareDollarsMTD": "RevShareDollarsMTD__c",
  "RevShareDollarsWTD": "RevShareDollarsWTD__c",  
  "month_end_date" : "Usage_Date__c",
  "DeltaRevShareDollars": "DeltaRevShareDollars__c",
  "DeltaAutomatedDBUs": "DeltaAutomatedDBU__c",
  "DeltaInteractiveDBUs": "DeltaInteractiveDBU__c",
  "cumDeltaAutomatedDBUs":"cumDeltaAutomatedDBUs__c",
  "cumDeltaInteractiveDBUs":"cumDeltaInteractiveDBUs__c",
  "cumDeltaRevShareDollars":"cumDeltaRevShareDollars__c",  
  "T3MRevShareDollars": "T3MRevShareDollars__c",
  "T3MEnterpriseDBUs":"T3MEnterpriseDBU__c",
  "T3MPremiumDBUs":"T3MPremiumDBU__c",
  "T3MStandardDBUs":"T3MStandarsDBU__c",
  "T3MEnterpriseRevShareDollars":"T3MEnterpriseRevShare__c",
  "T3MPremiumRevShareDollars":"T3MPremiumRevShare__c",
  "T3MStandardRevShareDollars":"T3MStandardRevShare__c",  
  "SQLAnalyticsDBUs":"SQLAnalyticsDBU__c",
  "SQLAnalyticsForecastDBUs":"SQLAnalyticsFcstDBU__c",
  "SQLRevShareDollars":"SQLRevShareDollars__c",
  "SQLRevShareForecastDollars":"SQLRevShareFcstDollars__c",
  "cumSQLAnalyticsDBUs":"CumSQLAnalyticsDBU__c",
  "cumSQLAnalyticsForecastDBUs":"CumSQLAnalyticsFcstDBU__c",
  "cumSQLRevShareDollars":"CumSQLRevShareDollars__c",
  "cumSQLRevShareForecastDollars":"CumSQLRevShareFcstDollars__c",
  "Unique_Id__c":"Unique_Id__c"
}

# COMMAND ----------

popdf = spark.sql("""
select *
from bdw.usagec_popmetrics
""")

popdf = popdf.withColumn("SQLAnalyticsForecastDBUs", col("SQLAnalyticsForecastDBUs").cast("double"))\
             .withColumn("SQLRevShareForecastDollars", col("SQLRevShareForecastDollars").cast("double"))\
             .withColumn("cumSQLAnalyticsForecastDBUs", col("cumSQLAnalyticsForecastDBUs").cast("double"))\
             .withColumn("cumSQLRevShareForecastDollars", col("cumSQLRevShareForecastDollars").cast("double"))

popdf = popdf.drop("accountName")
popdf = popdf.dropDuplicates()


popdf = popdf.withColumn("Unique_Id__c", popUniqueId("accountId", "platform"))\
             .withColumn("month_end_date", col("month_end_date").cast("string"))\
             .drop("accountName")
pop = popdf.toPandas()
pop = pop.replace({np.nan: 0.0})

pop = pop[sorted(pop_rename_column_map.keys())]
pop = pop.rename(columns = pop_rename_column_map)
pop['RecordTypeId'] = pop.apply(lambda row: "0123f000000XdGcAAK", axis=1)
pop = pop.reindex(sorted(pop.columns), axis=1)
upsert_pop = pop.copy()

pop_upsert_data = [val for val in upsert_pop.T.to_dict().values()]
print(upsert_pop.shape)

# COMMAND ----------

creds = get_creds('lfsf')
sf = get_sfdc_connection(creds, 'databricks.my')
sf.bulk.Consumption__c.upsert(data=pop_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)
#sf.bulk.Consumption__c.upsert(pop_upsert_data, 'Unique_Id__c')

# COMMAND ----------

# DBTITLE 1,Daily Map
# <D><AccountId>:<AggOrder>:<YYYYMMDD>
@udf("String")
def dailyUniqueId(accountId, aggOrder, usage_date):
  return "D:" + accountId + ":" + aggOrder + ":" + str(usage_date)

daily_rename_column_map = {
  "accountId" : "Account_Id__c",
  "aggOrder" : "AggOrder__c",
  "AutomatedForecastDBUs" : "AutomatedForecastDBU__c",
  "AutomatedDBUs": "Automated_DBUs__c",
  "consumptionType": "ConsumptionType__c",
  "cumAutomatedDBUs": "CumAutomatedDBU__c",
  "cumAutomatedForecastDBUs" : "CumAutomatedFcstDBU__c",
  "cumCustDollars" : "CumCustDollars__c",
  "cumCustForecastDollars" : "CumCustFcstDollars__c",
  "cumInteractiveDBUs" : "CumInteractiveDBU__c",
  "cumInteractiveForecastDBUs" : "CumInteractiveFcstDBU__c",
  "cumListDollars" : "CumListDollars__c",
  "cumListForecastDollars" : "CumListFcstDollars__c",
  "cumRevShareDollars" : "CumRevShareDollars__c",
  "cumRevShareForecastDollars" : "CumRevShareFcstDollars__c",
  "custForecastDollars" : "CustForecastDollars__c",
  "custDollars" : "Cust_Dollars__c",
  "DiscountedCommit": "Discounted_Commit__c",
  "endDate" : "End_Date__c",
  "InteractiveForecastDBUs" : "InteractiveForecastDBU__c",
  "InteractiveDBUs" : "Interactive_DBUs__c",
  "listForecastDollars" : "ListForecastDollars__c",
  "ListCommit" : "List_Commit__c",
  "listDollars" : "List_Dollars__c",
  "pctBurn" : "PercBurn__c",
  "platform" : "Platform__c",
  "revShareForecastDollars" : "RevShareForecastDollars__c",
  "RevShareCommit" : "RevShare_Commit__c",
  "revShareDollars" : "RevShare_Dollars__c",
  "startDate" : "Start_Date__c",
  "usage_date" : "Usage_Date__c",
  "actualBurstDate" : "ActualBurstDate__c",
  "expectedBurstDate" : "ExpectedBurstDate__c",
  "DeltaRevShareDollars": "DeltaRevShareDollars__c",
  "DeltaAutomatedDBUs": "DeltaAutomatedDBU__c",
  "DeltaInteractiveDBUs": "DeltaInteractiveDBU__c",
  "cumDeltaAutomatedDBUs":"cumDeltaAutomatedDBUs__c",
  "cumDeltaInteractiveDBUs":"cumDeltaInteractiveDBUs__c",
  "cumDeltaRevShareDollars":"cumDeltaRevShareDollars__c",
  "SQLAnalyticsDBUs":"SQLAnalyticsDBU__c",
  "SQLAnalyticsForecastDBUs":"SQLAnalyticsFcstDBU__c",
  "SQLRevShareDollars":"SQLRevShareDollars__c",
  "SQLRevShareForecastDollars":"SQLRevShareFcstDollars__c",
  "cumSQLAnalyticsDBUs":"CumSQLAnalyticsDBU__c",
  "cumSQLAnalyticsForecastDBUs":"CumSQLAnalyticsFcstDBU__c",
  "cumSQLRevShareDollars":"CumSQLRevShareDollars__c",
  "cumSQLRevShareForecastDollars":"CumSQLRevShareFcstDollars__c",
  "Unique_Id__c":"Unique_Id__c"
}

# COMMAND ----------

# rowCommitAccounts = spark.sql("select distinct accountId from bdw.usagec_aggorder_daily where consumptionType = 'Commit'").collect()
# commitAccountIds = [row.accountId for row in rowCommitAccounts]
# print(len(commitAccountIds))
# commitAccounts = spark.sql("select distinct accountId from bdw.usagec_aggorder_daily where consumptionType = 'Commit'")
# commitAccounts.createOrReplaceTempView("commitAccounts")

# COMMAND ----------

# def upsert_account(accountId,daily_rename_column_map):
#     df = spark.sql("""
#     select d.*
#     from bdw.usagec_aggorder_daily d
#     where accountId = "{0}"
#     """.format(accountId)
#     )
#     df = df.withColumn("Unique_Id__c", dailyUniqueId("accountId", "aggOrder", "usage_date"))\
#            .withColumn("usage_date", col("usage_date").cast("string"))\
#            .withColumn("startDate", col("startDate").cast("string"))\
#            .withColumn("endDate", col("endDate").cast("string"))
#     daily_df = df.toPandas()
#     daily_df = daily_df.rename(columns = daily_rename_column_map)
#     daily_df['RecordTypeId'] = daily_df.apply(lambda row: "0123f000000XdGaAAK", axis=1)
#     daily_df = daily_df.reindex(sorted(daily_df.columns), axis=1)
#     upsert_daily = daily_df.drop(columns = ["accountName"])
#     upsert_data = [val for val in upsert_daily.T.to_dict().values()]
#     creds = get_creds('lfsf')
#     sf = get_sfdc_connection(creds, 'databricks.my')
#     sf.bulk.Consumption__c.upsert(upsert_data, 'Unique_Id__c')

from datetime import datetime

def commit_upsert(chunk_counter, size):
    maxLimit = upsert_commit_daily.shape[0]
    while chunk_counter < maxLimit:
      commit_upsert_data = [val for val in upsert_commit_daily[chunk_counter:chunk_counter+size].T.to_dict().values()]
      creds = get_creds('lfsf')
      sf = get_sfdc_connection(creds, 'databricks.my')
      try:
          sf.bulk.Consumption__c.upsert(commit_upsert_data, 'Unique_Id__c')
          print('processed: ', chunk_counter, '....', datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
      except:
          print("could not process", chunk_counter)
      chunk_counter += size

# COMMAND ----------

# DBTITLE 1,Remaining Accounts
from datetime import datetime

def mtm_upsert(chunk_counter, size):
    maxLimit = upsert_mtm_daily.shape[0]
    while chunk_counter < maxLimit:
      mtm_upsert_data = [val for val in upsert_mtm_daily[chunk_counter:chunk_counter+size].T.to_dict().values()]
      creds = get_creds('lfsf')
      sf = get_sfdc_connection(creds, 'databricks.my')
      try:
        sf.bulk.Consumption__c.upsert(mtm_upsert_data, 'Unique_Id__c')
        print('processed: ', chunk_counter, '....', datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
      except:
        print("could not process chunk", chunk_counter)
      chunk_counter += size

# COMMAND ----------

# DBTITLE 1,Platform Monthly
@udf("String")
def platMonthlyUniqueId(accountId, platform, month_end_date):
  return accountId + ":" + platform + ":" + str(month_end_date)

platmonthly_rename_column_map = {
  "accountId" : "Account_Id__c",
  "AutomatedForecastDBUs" : "AutomatedForecastDBU__c",
  "AutomatedDBUs": "Automated_DBUs__c",
  "cumAutomatedDBUs": "CumAutomatedDBU__c",
  "cumAutomatedForecastDBUs" : "CumAutomatedFcstDBU__c",
  "cumCustDollars" : "CumCustDollars__c",
  "cumCustForecastDollars" : "CumCustFcstDollars__c",
  "cumInteractiveDBUs" : "CumInteractiveDBU__c",
  "cumInteractiveForecastDBUs" : "CumInteractiveFcstDBU__c",
  "cumListDollars" : "CumListDollars__c",
  "cumListForecastDollars" : "CumListFcstDollars__c",
  "cumRevShareDollars" : "CumRevShareDollars__c",
  "cumRevShareForecastDollars" : "CumRevShareFcstDollars__c",
  "custForecastDollars" : "CustForecastDollars__c",
  "custDollars" : "Cust_Dollars__c",
  "DiscountedCommit": "Discounted_Commit__c",
  "InteractiveForecastDBUs" : "InteractiveForecastDBU__c",
  "InteractiveDBUs" : "Interactive_DBUs__c",
  "listForecastDollars" : "ListForecastDollars__c",
  "ListCommit" : "List_Commit__c",
  "listDollars" : "List_Dollars__c",
  "platform" : "Platform__c",
  "revShareForecastDollars" : "RevShareForecastDollars__c",
  "RevShareCommit" : "RevShare_Commit__c",
  "revShareDollars" : "RevShare_Dollars__c",
  "month_end_date" : "Usage_Date__c",
  "Unique_Id__c": "Unique_Id__c",
  "DeltaRevShareDollars": "DeltaRevShareDollars__c",
  "DeltaAutomatedDBUs": "DeltaAutomatedDBU__c",
  "DeltaInteractiveDBUs": "DeltaInteractiveDBU__c",
  "MoonCakeDBUs":"MoonCakeDBU__c",
  "MoonCakeDBUDollars":"MoonCakeDBUDollars__c",  
  "MoonCakeDeltaDBUs":"MoonCakeDeltaDBU__c",  
  "MoonCakeDeltaDBUDollars":"MoonCakeDeltaDBUDollars__c",  
  "cumDeltaAutomatedDBUs":"cumDeltaAutomatedDBUs__c",
  "cumDeltaInteractiveDBUs":"cumDeltaInteractiveDBUs__c",
  "cumDeltaRevShareDollars":"cumDeltaRevShareDollars__c",
  "SQLAnalyticsDBUs":"SQLAnalyticsDBU__c",
  "SQLAnalyticsForecastDBUs":"SQLAnalyticsFcstDBU__c",
  "SQLRevShareDollars":"SQLRevShareDollars__c",
  "SQLRevShareForecastDollars":"SQLRevShareFcstDollars__c",
  "cumSQLAnalyticsDBUs":"CumSQLAnalyticsDBU__c",
  "cumSQLAnalyticsForecastDBUs":"CumSQLAnalyticsFcstDBU__c",
  "cumSQLRevShareDollars":"CumSQLRevShareDollars__c",
  "cumSQLRevShareForecastDollars":"CumSQLRevShareFcstDollars__c"  
}

# COMMAND ----------

platmonthly_df = spark.sql("""
select *
from bdw.usagec_platform_monthly
""")
print(platmonthly_df.columns)
platmonthly_df = platmonthly_df.withColumn("Unique_Id__c", platMonthlyUniqueId("accountId", "platform", "month_end_date"))\
                               .withColumn("month_end_date", col("month_end_date").cast("string"))
platmonthly_df = platmonthly_df.toPandas()
platmonthly_df = platmonthly_df.replace({np.nan: None})

platmonthly_df = platmonthly_df[sorted(platmonthly_rename_column_map.keys())]
platmonthly = platmonthly_df[list(platmonthly_rename_column_map.keys())]
platmonthly = platmonthly.rename(columns = platmonthly_rename_column_map)
platmonthly['RecordTypeId'] = platmonthly.apply(lambda row: "0123f000000XdGbAAK", axis=1)
platmonthly = platmonthly.reindex(sorted(platmonthly.columns), axis=1)
upsert_platmonthly = platmonthly.copy()

platmonthly_upsert_data = [val for val in upsert_platmonthly.T.to_dict().values()]

# COMMAND ----------

creds = get_creds('lfsf')
sf = get_sfdc_connection(creds, 'databricks.my')
sf.bulk.Consumption__c.upsert(data=platmonthly_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)

# COMMAND ----------

# DBTITLE 1,Account Monthly
@udf("String")
def accMonthlyUniqueId(accountId, month_end_date):
  return accountId + ":" + str(month_end_date)

accmonthly_rename_column_map = {
  "accountId" : "Account_Id__c",
  "AutomatedForecastDBUs" : "AutomatedForecastDBU__c",
  "AutomatedDBUs": "Automated_DBUs__c",
  "cumAutomatedDBUs": "CumAutomatedDBU__c",
  "cumAutomatedForecastDBUs" : "CumAutomatedFcstDBU__c",
  "cumCustDollars" : "CumCustDollars__c",
  "cumCustForecastDollars" : "CumCustFcstDollars__c",
  "cumInteractiveDBUs" : "CumInteractiveDBU__c",
  "cumInteractiveForecastDBUs" : "CumInteractiveFcstDBU__c",
  "cumListDollars" : "CumListDollars__c",
  "cumListForecastDollars" : "CumListFcstDollars__c",
  "cumRevShareDollars" : "CumRevShareDollars__c",
  "cumRevShareForecastDollars" : "CumRevShareFcstDollars__c",
  "custForecastDollars" : "CustForecastDollars__c",
  "custDollars" : "Cust_Dollars__c",
  "InteractiveForecastDBUs" : "InteractiveForecastDBU__c",
  "InteractiveDBUs" : "Interactive_DBUs__c",
  "listForecastDollars" : "ListForecastDollars__c",
  "listDollars" : "List_Dollars__c",
  "revShareForecastDollars" : "RevShareForecastDollars__c",
  "revShareDollars" : "RevShare_Dollars__c",
  "month_end_date" : "Usage_Date__c",
  "Unique_Id__c": "Unique_Id__c",
  "workspace_users_count":"active_users__c",
  "DeltaRevShareDollars": "DeltaRevShareDollars__c",
  "DeltaAutomatedDBUs": "DeltaAutomatedDBU__c",
  "DeltaInteractiveDBUs": "DeltaInteractiveDBU__c",
  "MoonCakeDBUs":"MoonCakeDBU__c",
  "MoonCakeDBUDollars":"MoonCakeDBUDollars__c",  
  "MoonCakeDeltaDBUs":"MoonCakeDeltaDBU__c",  
  "MoonCakeDeltaDBUDollars":"MoonCakeDeltaDBUDollars__c",  
  "cumDeltaAutomatedDBUs":"cumDeltaAutomatedDBUs__c",
  "cumDeltaInteractiveDBUs":"cumDeltaInteractiveDBUs__c",
  "cumDeltaRevShareDollars":"cumDeltaRevShareDollars__c",
  "SQLAnalyticsDBUs":"SQLAnalyticsDBU__c",
  "SQLAnalyticsForecastDBUs":"SQLAnalyticsFcstDBU__c",
  "SQLRevShareDollars":"SQLRevShareDollars__c",
  "SQLRevShareForecastDollars":"SQLRevShareFcstDollars__c",
  "cumSQLAnalyticsDBUs":"CumSQLAnalyticsDBU__c",
  "cumSQLAnalyticsForecastDBUs":"CumSQLAnalyticsFcstDBU__c",
  "cumSQLRevShareDollars":"CumSQLRevShareDollars__c",
  "cumSQLRevShareForecastDollars":"CumSQLRevShareFcstDollars__c",
  "AEForecastDBU":"AE_Forecast_DBU__c",
  "AEForecastDBUDollars":"AE_Forecast_Dollars__c",
  "CSEBaseLineForecastDBU":"UCBaselineDBU__c",
  "CSEBaseLineForecastDBUDollars":"UCBaselineDollars__c",  
  "CSEUpsideDBU":"UCUpsideDBU__c",
  "CSEUpsideDBUDollars":"UCUpsideDollars__c"    
}

# COMMAND ----------

accmonthly_df = spark.sql("""
select *
from bdw.usagec_account_monthly 
""")
print(accmonthly_df.columns)
accmonthly_df = accmonthly_df.withColumn("Unique_Id__c", accMonthlyUniqueId("accountId", "month_end_date"))\
                             .withColumn("month_end_date", col("month_end_date").cast("string"))
accmonthly_df = accmonthly_df.toPandas()
accmonthly_df = accmonthly_df.replace({np.nan: None})

accmonthly_df = accmonthly_df[sorted(accmonthly_rename_column_map.keys())]
accmonthly = accmonthly_df[list(accmonthly_rename_column_map.keys())]
accmonthly = accmonthly.rename(columns = accmonthly_rename_column_map)
accmonthly['RecordTypeId'] = accmonthly.apply(lambda row: "0123f000000XdGYAA0", axis=1)
accmonthly = accmonthly.reindex(sorted(accmonthly.columns), axis=1)
upsert_accmonthly = accmonthly.copy()

accmonthly_upsert_data = [val for val in upsert_accmonthly.T.to_dict().values()]

# COMMAND ----------

creds = get_creds('lfsf')
sf = get_sfdc_connection(creds, 'databricks.my')
sf.bulk.Consumption__c.upsert(data=accmonthly_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)

# COMMAND ----------

# DBTITLE 1,cleans up any non-uniqueId records
acc_consumption_soql_query = """
SELECT Id, Account_Id__c, Usage_Date__c, Unique_Id__c, RevShareForecastDollars__c FROM Consumption__c WHERE RecordTypeId = '0123f000000XdGYAA0'
"""

acc_consumption_df = get_dataframe(acc_consumption_soql_query, 'lfsf', 'databricks.my')
acc_consumption_schema = build_spark_schema(acc_consumption_df.dtypes)
spark_acc_consumption_df = spark.createDataFrame(acc_consumption_df, acc_consumption_schema)
spark_acc_consumption_df.createOrReplaceTempView("sfdc_account_monthly")

removeIds = [ {'Id':row.Id} for row in spark.sql("""
with toberemoved (
select *,
       concat(Account_Id__c, concat(":", Usage_Date__c)) newUniqueId,
       case when Unique_Id__c == concat(Account_Id__c, concat(":", Usage_Date__c)) then false
            else true
       end as badRecFlag
from sfdc_account_monthly
)

select Id
from toberemoved
where badRecFlag = 1
""").collect()]

print(len(removeIds))
if len(removeIds) > 0:
  creds = get_creds('lfsf')
  sf = get_sfdc_connection(creds, 'databricks.my')
  sf.bulk.Consumption__c.delete(removeIds, batch_size=3000, use_serial=True)
  
  
outDatedAccountMonthlyIds = [ {'Id':row.Id} for row in spark.sql("""
select sfdc.Id
from sfdc_account_monthly sfdc
left join bdw.usagec_account_monthly uam on sfdc.Account_Id__c = uam.accountId and sfdc.Usage_Date__c = uam.month_end_date
where uam.accountId is null and uam.month_end_date is null
order by sfdc.Account_Id__c, sfdc.Usage_Date__c
""").collect()]

print(len(outDatedAccountMonthlyIds))

if len(outDatedAccountMonthlyIds) > 0:
  creds = get_creds('lfsf')
  sf = get_sfdc_connection(creds, 'databricks.my')
  sf.bulk.Consumption__c.delete(outDatedAccountMonthlyIds, batch_size=3000, use_serial=True)

# COMMAND ----------

upsert_df = spark.sql("""
select *
from bdw.usagec_account_monthly
where month_end_date < current_date()
and revShareForecastDollars > 0
""")
upsert_df = upsert_df.withColumn("revShareForecastDollars", lit(0.0))

upsert_df = upsert_df.withColumn("Unique_Id__c", accMonthlyUniqueId("accountId", "month_end_date"))\
                     .withColumn("month_end_date", col("month_end_date").cast("string"))
upsert_df = upsert_df.toPandas()

upsertaccmonthly = upsert_df[list(accmonthly_rename_column_map.keys())]
upsertaccmonthly = upsertaccmonthly.rename(columns = accmonthly_rename_column_map)
upsertaccmonthly['RecordTypeId'] = upsertaccmonthly.apply(lambda row: "0123f000000XdGYAA0", axis=1)
upsertaccmonthly = upsertaccmonthly.reindex(sorted(upsertaccmonthly.columns), axis=1)

upsertaccmonthly_data = [val for val in upsertaccmonthly.T.to_dict().values()]

print(len(upsertaccmonthly_data))

creds = get_creds('lfsf')
sf = get_sfdc_connection(creds, 'databricks.my')
sf.bulk.Consumption__c.upsert(data=upsertaccmonthly_data, external_id_field='Unique_Id__c', batch_size=3000)

# COMMAND ----------

# DBTITLE 1,Commit Daily Upsert
commitAccounts = spark.sql("select distinct accountId from bdw.usagec_aggorder_daily where consumptionType = 'Commit'")
commitAccounts.createOrReplaceTempView("commitAccounts")

# COMMAND ----------

commit_df = spark.sql("""
    select d.*
    from bdw.usagec_aggorder_daily d
    join commitAccounts ca on d.accountId = ca.accountId
    where d.usage_date > '2018-12-31' 
    """)
commit_df = commit_df.withColumn("Unique_Id__c", dailyUniqueId("accountId", "aggOrder", "usage_date"))\
                     .withColumn("usage_date", col("usage_date").cast("string"))\
                     .withColumn("startDate", col("startDate").cast("string"))\
                     .withColumn("endDate", col("endDate").cast("string"))\
                     .withColumn("actualBurstDate", col("actualBurstDate").cast("string"))\
                     .withColumn("expectedBurstDate", col("expectedBurstDate").cast("string"))

# COMMAND ----------

commit_daily_df = commit_df.toPandas()
commit_daily_df = commit_daily_df.replace({np.nan: None})

commit_daily_df = commit_daily_df[sorted(daily_rename_column_map.keys())]
commit_daily_df = commit_daily_df.rename(columns = daily_rename_column_map)
commit_daily_df['RecordTypeId'] = commit_daily_df.apply(lambda row: "0123f000000XdGaAAK", axis=1)
commit_daily_df = commit_daily_df.reindex(sorted(commit_daily_df.columns), axis=1)
print(commit_daily_df.shape)

# COMMAND ----------

commit_upsert_data = [val for val in commit_daily_df.T.to_dict().values()]

# COMMAND ----------

creds = get_creds('lfsf')
sf = get_sfdc_connection(creds, 'databricks.my')
sf.bulk.Consumption__c.upsert(data=commit_upsert_data, external_id_field='Unique_Id__c', batch_size=5000)

# COMMAND ----------

# DBTITLE 1,MTM upsert
mtm_df = spark.sql("""
    select d.*
    from bdw.usagec_aggorder_daily d
    left join commitAccounts ca on d.accountId = ca.accountId
    where d.usage_date > '2018-12-31' 
    and ca.accountId is null
    """)
mtm_df = mtm_df.withColumn("Unique_Id__c", dailyUniqueId("accountId", "aggOrder", "usage_date"))\
               .withColumn("usage_date", col("usage_date").cast("string"))\
               .withColumn("startDate", col("startDate").cast("string"))\
               .withColumn("endDate", col("endDate").cast("string"))

# COMMAND ----------

mtm_daily_df = mtm_df.toPandas()
mtm_daily_df = mtm_daily_df.replace({np.nan: None})

mtm_daily_df = mtm_daily_df[sorted(daily_rename_column_map.keys())]
mtm_daily_df = mtm_daily_df.rename(columns = daily_rename_column_map)
mtm_daily_df['RecordTypeId'] = mtm_daily_df.apply(lambda row: "0123f000000XdGaAAK", axis=1)
mtm_daily_df = mtm_daily_df.reindex(sorted(mtm_daily_df.columns), axis=1)
print(mtm_daily_df.shape)

# COMMAND ----------

mtm_upsert_data = [val for val in mtm_daily_df.T.to_dict().values()]
print(len(mtm_upsert_data))

# COMMAND ----------

creds = get_creds('lfsf')
sf = get_sfdc_connection(creds, 'databricks.my')
sf.bulk.Consumption__c.upsert(data=mtm_upsert_data, external_id_field='Unique_Id__c', batch_size=5000)

# COMMAND ----------

# DBTITLE 1,clean popmetrics
pop_consumption_soql_query = """
SELECT Id, Account_Id__c, Platform__c, Unique_Id__c, RevShareLastQtr__c, RevShareDollarsQTD__c, RevShareDollarsMTD__c, Usage_Date__c FROM Consumption__c WHERE RecordTypeId = '0123f000000XdGcAAK'
"""

pop_consumption_df = get_dataframe(pop_consumption_soql_query, 'lfsf', 'databricks.my')
pop_consumption_schema = build_spark_schema(pop_consumption_df.dtypes)
spark_pop_consumption_df = spark.createDataFrame(pop_consumption_df, pop_consumption_schema)
spark_pop_consumption_df.createOrReplaceTempView("sfdc_popmetrics")

outDatedPoPMetricsIds = [ {'Id':row.Id} for row in spark.sql("""
select sfdc.Id
from sfdc_popmetrics sfdc
left join bdw.usagec_popmetrics pop on sfdc.Account_Id__c = pop.accountId and sfdc.Platform__c = pop.platform and sfdc.usage_date__c = pop.month_end_date
where pop.accountId is null and pop.platform is null and pop.month_end_date is null
and sfdc.Account_Id__c is not null
and (RevShareLastQtr__c > 0 or RevShareDollarsQTD__c > 0 or RevShareDollarsMTD__c > 0)
order by sfdc.Account_Id__c
""").collect()]

print(len(outDatedPoPMetricsIds))

if len(outDatedPoPMetricsIds) > 0:
  creds = get_creds('lfsf')
  sf = get_sfdc_connection(creds, 'databricks.my')
  sf.bulk.Consumption__c.delete(outDatedPoPMetricsIds, batch_size=3000, use_serial=True)

# COMMAND ----------

# DBTITLE 1,Daily Clean up
consumption_soql_query = """
SELECT Id, Account_Id__c,AggOrder__c, Usage_Date__c FROM Consumption__c WHERE RecordTypeId = '0123f000000XdGaAAK' and Usage_Date__c > 2020-10-01 and Usage_Date__c < 2021-12-31
"""
consumption_df = get_dataframe(consumption_soql_query, 'lfsf', 'databricks.my')

# COMMAND ----------

consumption_schema = build_spark_schema(consumption_df.dtypes)
spark_consumption_df = spark.createDataFrame(consumption_df, consumption_schema)
current_consumption_df = spark.sql("select distinct accountId, aggOrder, usage_date from bdw.usagec_aggorder_daily")
tobeRemoved_df = spark_consumption_df.join(current_consumption_df, (spark_consumption_df.Account_Id__c == current_consumption_df.accountId) &\
                                                                   (spark_consumption_df.AggOrder__c == current_consumption_df.aggOrder) &\
                                                                   (spark_consumption_df.Usage_Date__c == current_consumption_df.usage_date), 'left')
removeIds = tobeRemoved_df.filter(tobeRemoved_df.aggOrder.isNull())
cleanup_ids = [{'Id':row.Id} for row in removeIds.select("Id").collect()]
print(len(cleanup_ids))

# COMMAND ----------

creds = get_creds('lfsf')
sf = get_sfdc_connection(creds, 'databricks.my')
sf.bulk.Consumption__c.delete(cleanup_ids, batch_size=3000, use_serial=True)

# COMMAND ----------

#send email
# import smtplib
# from email.mime.text import MIMEText
# from email.mime.application import MIMEApplication
# from email.mime.multipart import MIMEMultipart
# server = smtplib.SMTP('smtp.gmail.com:587')
# server.ehlo()
# server.starttls()
# mygmail = dbutils.secrets.get('mycreds', 'gmail')
# pswd = dbutils.secrets.get('mycreds', 'pwd')
# server.login(mygmail, pswd)

# sender = mygmail
# recipients = ["rk.aduri@databricks.com", "manu.shetty@databricks.com", "cory@databricks.com", "karan.shah@databricks.com"]
# msg = MIMEMultipart()
# msg['Subject'] = 'prod push completed'
# msg['From'] = sender
# msg['To'] = ", ".join(recipients)
# msg.attach(MIMEText('PoP Metrics, Daily Updated, Added Delta'))
# server.sendmail(sender, recipients, msg.as_string())
# server.close()

# COMMAND ----------

# DBTITLE 1,Clean up
# cleanup_soql = """
# SELECT Id FROM Consumption__c WHERE RecordTypeId = '0123C000000RJ64QAG'
# """
# cleanup_df = get_dataframe(cleanup_soql, 'databricks.my', 'lfsf')
# cleanup_ids = [val for val in cleanup_df.T.to_dict().values()]
# creds = get_creds('uat')
# sf = get_sfdc_connection(creds, 'test')
# sf.bulk.Consumption__c.delete(cleanup_ids,use_serial=True)

# COMMAND ----------

# consumption_soql_query = """
# SELECT Id, Account_Id__c,AggOrder__c, Usage_Date__c FROM Consumption__c WHERE RecordTypeId = '0123f000000XdGaAAK' and Usage_Date__c > 2020-11-01 and Usage_Date__c < 2021-12-31
# """

# # recordType_soql_query = """
# # SELECT BusinessProcessId,CreatedById,CreatedDate,Description,DeveloperName,Id,IsActive,LastModifiedById,LastModifiedDate,Name,NamespacePrefix,SobjectType,SystemModstamp FROM RecordType WHERE SobjectType = 'Consumption__c'
# # """

# COMMAND ----------

# # ---daily---> "D:" + accountId + ":" + aggOrder + ":" + str(usage_date)
# #recordType_df = get_dataframe(recordType_soql_query, 'lfsf', 'databricks.my')

# consumption_df = get_dataframe(consumption_soql_query, 'lfsf', 'databricks.my')
# consumption_schema = build_spark_schema(consumption_df.dtypes)
# spark_consumption_df = spark.createDataFrame(consumption_df, consumption_schema)

# COMMAND ----------

# existing_consumption_daily = spark_consumption_df.distinct()
# print(spark_consumption_df.count(), existing_consumption_daily.count())

# COMMAND ----------

# current_consumption_df = spark.sql("select distinct accountId, aggOrder, usage_date from bdw.usagec_aggorder_daily")
# print(current_consumption_df.count())

# COMMAND ----------

# tobeRemoved_df = spark_consumption_df.join(current_consumption_df, (spark_consumption_df.Account_Id__c == current_consumption_df.accountId) &\
#                                                                    (spark_consumption_df.AggOrder__c == current_consumption_df.aggOrder) &\
#                                                                    (spark_consumption_df.Usage_Date__c == current_consumption_df.usage_date), 'left')
# removeIds = tobeRemoved_df.filter(tobeRemoved_df.aggOrder.isNull())
# removeIds.count()

# COMMAND ----------

#cleanup_ids = [{'Id':row.Id} for row in removeIds.select("Id").collect()]

# COMMAND ----------

# creds = get_creds('lfsf')
# sf = get_sfdc_connection(creds, 'databricks.my')
# sf.bulk.Consumption__c.delete(cleanup_ids, batch_size=3000, use_serial=True)

# COMMAND ----------

# chunk = 0
# while chunk < len(cleanup_ids):
#     print("processing: ", chunk)
#     if chunk + 2999 > len(cleanup_ids):
#       right_limit = len(cleanup_ids)-1
#     else:
#       right_limit = chunk + 2999
#     batch_cleanup_ids = cleanup_ids[chunk:right_limit]
#     creds = get_creds('lfsf')
#     sf = get_sfdc_connection(creds, 'databricks.my')
#     sf.bulk.Consumption__c.delete(batch_cleanup_ids,use_serial=True)
#     chunk += 3000