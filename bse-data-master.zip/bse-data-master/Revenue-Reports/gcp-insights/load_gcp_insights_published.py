# Databricks notebook source
# MAGIC %run "./config_revenue_report_automation"

# COMMAND ----------


maxdate = spark.sql (f''' select max(createDate) from  {target_database}.gcp_insights_raw''' ).collect()[0][0] 

print(maxdate)

# COMMAND ----------

Deletelastfile = (f'''
DELETE FROM {target_database}.gcp_insights_monthly WHERE   
MonthEndDate in (select distinct  last_day(date(date)) from  {target_database}.gcp_insights_raw where createDate = '{maxdate}') ''' )

sql(Deletelastfile)


# COMMAND ----------

insert_gcp_insights_pub = f'''

INSERT INTO {target_database}.gcp_insights_monthly
Select 
last_day(date(date)) as MonthEndDate, 
date	,
company	,
domain	,
external_account_id	,
account_id	,
country	,
state_or_province	,
postal_code	,
sku_id	,
sku_description	,
cast(usage as double) usage	,
unit	,
currency	,
cast(charges as double)	charges,
cast(due_vendor	as double) due_vendor,
cast(trial_use	as double) trial_use,
cast(num_vms	as double) num_vms,
cast(num_cpus as double)	num_cpus,
cast(ram_mb	as double) ram_mb ,
cast(num_gpus	as double) num_gpus,
gpu_types	,
earliest	,
latest	,
machine_spec_sum	,
quote_id	,
quote_creator	,
payment_type	,
cast(withheld as double) withheld	,
cast(released	as double) released,
cast(abandoned	as double) abandoned,
probation_start	,
probation_end	,
internal_note	,
payment_schedule	,
cast(prepay_credits	as double) prepay_credits,
cast(start_date as date) start_date 	,
cast(end_date as date)	 end_date ,
cast(private_offer_acceptance_date as date) private_offer_acceptance_date ,	
cast(private_offer_total_contract_value	 as double) private_offer_total_contract_value,
cast(order_start_date as date) order_start_date	,
cast(order_end_date	as date) order_end_date ,
processed_file	,
createDate	

FROM {target_database}.gcp_insights_raw raw
WHERE raw.createDate = '{maxdate}' '''

sql(insert_gcp_insights_pub)

