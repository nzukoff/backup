# Databricks notebook source
from dataclasses import dataclass

@dataclass(frozen=True)
class defineconfig:
  name: str
  parquet_dir: str
  database: str
#  database_sfdc : str
  revenue_report_s3_bucket: str
  revenue_s3_access_key_secret: str
  revenue_s3_secret_key_secret: str
  gcp_insights_file_folder :str
  archive_folder: str
  target_database: str
  target_tablename: str
  target_tablename_final : str
  filename: str
  process_date_column: str
  current_user_column: str
  

# COMMAND ----------

ri_config =  { 'prod' : {
  'name' : 'Production',
  'parquet_dir' : 'dbfs:/mnt/bse-dev/revenue_gcp_insights/production',
  'database':'bdw',
 # 'database_sfdc' : 'sfdc_prod',
  'revenue_report_s3_bucket':'revenue-files-automation-bucket',
  'revenue_s3_access_key_secret':'ri-report-extract-s3-access-key',
  'revenue_s3_secret_key_secret':'ri-report-extract-s3-secret-key',
  'gcp_insights_file_folder':'gcp_insights',
  'archive_folder':'processed_gcp_insights',
  'target_database': 'bdw',
  'target_tablename': 'gcp_insights_raw',
  'target_tablename_final' : 'gcp_insights_monthly',
  'filename': 'Monthly Insights.tsv',
  'process_date_column': 'createDate',
  'current_user_column': 'processUser'
} ,

'dev' : {
  'name':'Dev',
  'parquet_dir': 'dbfs:/mnt/bse-dev/revenue_gcp_insights/dev',
  #parquet_dir:'dbfs:/mnt/bse-dev/netsuite-suite-analytics/production',
  'database':'bdw_dev',
  'revenue_report_s3_bucket':'revenue-files-automation-bucket',
  'revenue_s3_access_key_secret':'ri-report-extract-s3-access-key',
  'revenue_s3_secret_key_secret':'ri-report-extract-s3-secret-key',
  'gcp_insights_file_folder':'gcp_insights',
  'archive_folder':'processed_gcp_insights',
  'target_database': 'bdw_dev',
  'target_tablename': 'gcp_insights_raw',
  'target_tablename_final' : 'gcp_insights_monthly',
  'filename': 'Monthly Insights.tsv',
  'process_date_column': 'createDate',
  'current_user_column': 'processUser'
} }

# COMMAND ----------

ENV = dbutils.widgets.get("env") #dev

try:
  setconfig = defineconfig(
                        ri_config[ENV]['name'],
                        ri_config[ENV]['parquet_dir'],
                        ri_config[ENV]['database'],
                       # ri_config[ENV]['database_sfdc'],
                        ri_config[ENV]['revenue_report_s3_bucket'],
                        ri_config[ENV]['revenue_s3_access_key_secret'],
                        ri_config[ENV]['revenue_s3_secret_key_secret'],
                        ri_config[ENV]['gcp_insights_file_folder'],
                        ri_config[ENV]['archive_folder'],
                        ri_config[ENV]['target_database'],
                        ri_config[ENV]['target_tablename'],
                        ri_config[ENV]['target_tablename_final'],
                        ri_config[ENV]['filename'],
                        ri_config[ENV]['process_date_column'],
                        ri_config[ENV]['current_user_column']
                      )
except Exception:
  raise Exception(f'Configurations are not defined for {ENV}')

# COMMAND ----------

# MAGIC %python
# MAGIC from typing import Callable, Optional, Sequence
# MAGIC from pyspark.sql import DataFrame
# MAGIC from pyspark.sql.functions import col, lit
# MAGIC from datetime import datetime, date
# MAGIC from dataclasses import dataclass, field
# MAGIC 
# MAGIC 
# MAGIC #setconfig =   dev #dbutils.widgets.get("env_ri") #dev
# MAGIC #CONFIG = PRODUCTION
# MAGIC 
# MAGIC #filename_pre = setconfig.filename
# MAGIC SECRET_SCOPE = 'azure-automation'
# MAGIC revenue_report_extract_s3_access_key = dbutils.secrets.get(SECRET_SCOPE, setconfig.revenue_s3_access_key_secret)
# MAGIC revenue_report_extract_s3_secret_key = dbutils.secrets.get(SECRET_SCOPE, setconfig.revenue_s3_secret_key_secret)
# MAGIC #s3_extract_ri_filepth = f's3a://{revenue_report_extract_s3_access_key}:{setconfig.revenue_report_s3_bucket}@{setconfig.revenue_report_s3_bucket}/{setconfig.file_folder}/{setconfig.filename}'
# MAGIC 
# MAGIC 
# MAGIC metadata_process_date_column= setconfig.process_date_column
# MAGIC metadata_current_user_column = setconfig.current_user_column
# MAGIC #filename = 'report.xlsx'
# MAGIC gcp_insights_file_folder = setconfig.gcp_insights_file_folder
# MAGIC target_tablename = setconfig.target_tablename
# MAGIC target_database = setconfig.target_database
# MAGIC table_parquet_dir=setconfig.parquet_dir 
# MAGIC archive_FilePath = f's3a://{revenue_report_extract_s3_access_key}:{setconfig.revenue_report_s3_bucket}@{setconfig.revenue_report_s3_bucket}/{setconfig.archive_folder}'
# MAGIC archive_folder = setconfig.archive_folder
# MAGIC filename = setconfig.filename
# MAGIC revenue_report_s3_bucket = setconfig.revenue_report_s3_bucket
# MAGIC target_tablename_final = setconfig.target_tablename_final

# COMMAND ----------

import boto3
import boto3
def list_of_files(folder) :

  s3 = boto3.resource('s3',aws_access_key_id=revenue_report_extract_s3_access_key, aws_secret_access_key=revenue_report_extract_s3_secret_key)
  my_bucket = s3.Bucket(revenue_report_s3_bucket)
  files_in_s3 = [f.key.split(folder + "/")[1] for f in my_bucket.objects.filter(Prefix=folder).all()  ]
  files_in_s3 = [i for i in files_in_s3 if i != '']
  return files_in_s3

# COMMAND ----------

# MAGIC %python
# MAGIC def read_excel_into_df(FilePath) :
# MAGIC   return sqlContext.read.format("com.crealytics.spark.excel") \
# MAGIC           .option("header", "true") \
# MAGIC           .load(FilePath)

# COMMAND ----------

# MAGIC %python
# MAGIC def read_tsv_into_df(FilePath) :
# MAGIC   
# MAGIC   return spark.read.csv(FilePath, header=True)

# COMMAND ----------

#archive files with the parms
import boto3
def copy_to_archive_boto(bucket,access_key,secret_key, file_folder,archive_folder) :

  s3 = boto3.resource('s3',aws_access_key_id=access_key, aws_secret_access_key=secret_key)
  my_bucket = s3.Bucket(bucket)
  todays_date = datetime.today().strftime('%Y-%m-%d')
  files_in_s3 = [f.key.split(file_folder + "/")[1] for f in my_bucket.objects.filter(Prefix=file_folder).all()  ]
  files_in_s3 = [i for i in files_in_s3 if i != '']
  for filename in files_in_s3 : 
    print ('copyting file' + filename )
    copy_source = { 'Bucket': bucket , 'Key': f'{file_folder}/{filename}' }
    #copy_source = { 'Bucket': revenue_report_s3_bucket , 'Key': filename}
    new_filename =f'{todays_date}_{filename}'
    target =  f'{archive_folder}/{new_filename}'
    my_bucket.copy(copy_source, target)
    print(f'copied over {new_filename} to the folder {archive_folder} ')
    print (f'now deleting the original file  {file_folder}/{filename}' )
    s3.Object(bucket, f'{file_folder}/{filename}' ).delete()
    print (f'delete successful for {file_folder}/{filename}' )

# COMMAND ----------

# MAGIC %python
# MAGIC 
# MAGIC import os
# MAGIC def copy_to_archive(src_path,dst_path):
# MAGIC     sh_command = f'aws s3 cp {src_path} {dst_path}'
# MAGIC     print(sh_command)
# MAGIC     os.system(sh_command)
# MAGIC     print('done executing')

# COMMAND ----------

# MAGIC %python
# MAGIC 
# MAGIC import os
# MAGIC def copy_to_archive(src_path,dst_path):
# MAGIC     sh_command = f'aws s3 cp {src_path} {dst_path}'
# MAGIC     print(sh_command)
# MAGIC     os.system(sh_command)
# MAGIC     print('done executing')

# COMMAND ----------

from datetime import datetime



def add_audit_attributes(df ):
  """
  Add process date and current user

  """
  now = datetime.utcnow().date()
  a =spark.sql('''select current_user''').collect()[0]
  user = a[0]
  
  df2 = (df
    .withColumn(metadata_process_date_column, lit(now))
    #.withColumn(metadata_current_user_column, lit(user))

    )
  
  return (df2, now)


# COMMAND ----------

def dbfs_file_exists(folder: str, filename: str) -> bool:
  """
  Determines whether a file (or folder) exists under a specific
  DBFS directory. Use this instead of testing the FUSE path,
  because the FUSE path's existence isn't always reliable.
  """
  
  exists = False
  for fi in dbutils.fs.ls(folder):
    name = fi.name
    if name[-1] == '/':
      name = name[0:-1]

    if name == filename:
      exists = True
      break

  return exists


# COMMAND ----------

from pyspark.sql import functions as F
def df_column_whitespace(df) :
  new_column_name_list= list(map(lambda x: x.replace(" ", "_").replace(":","").replace(" ","").replace("(","").replace(")","").replace("$","dollar"), df.columns))
  renamed_df = df.toDF(*new_column_name_list)
  #renamed_df = df.select([F.col(col).alias(col.replace(' ', '_')) for col in df.columns])
  return renamed_df

# COMMAND ----------

def run_load_tsv (filename,filepath) :
  full_table_name = f'{target_database}.{target_tablename}'
  parquet_file = f'{target_tablename}.parquet'
  parquet_path = f'{table_parquet_dir}/{parquet_file}'

  #processing 
  print('Reading file  ' + filename + ' from ' + filepath )
  df_raw = read_tsv_into_df(filepath)
  df = df_column_whitespace(df_raw)

  spark_df = df.withColumn("processed_file", lit(filename))
  final_df,createdate = add_audit_attributes(spark_df)
  print('dataframe created and now loading/updating into table ' + full_table_name )
  #display(final_df)
  #final_df = df_column_whitespace(final_df_with_metadata)
  #print(parquet_file)
  #print(parquet_path)
  if not dbfs_file_exists(table_parquet_dir, parquet_file):

    print (f'Creating {parquet_file}')
    (final_df
      .write
      .mode("overwrite")
      .format("delta")
      .partitionBy("processed_file")
      .save(parquet_path))
    sql(f'DROP TABLE IF EXISTS {full_table_name}')
    sql(f'CREATE TABLE {full_table_name} USING DELTA LOCATION "{parquet_path}"')

  else:
    date_str = createdate.strftime('%Y-%m-%d')
    print (f'Updating data in {full_table_name} for {createdate}')
    (final_df
      .write
      .mode('overwrite')
      .format('delta')
      .option('mergeSchema', 'false')
      .option('replaceWhere', f"processed_file= '{filename}'")
      .save(parquet_path))
  
  print('loaded/updated the table '+ full_table_name +  ' with the file '  + filename )

#filename_final  = f'{process_date}_{filename}'
#archivepath_final = f'{archive_FilePath}/{filename_final}'
#print(f'Copying current file to the processed path')
#copy_to_archive(s3_extract_ri_filepath,archivepath_final)
#print(f'done copying current file to the processed path')

#if not dbfs_file_exists(parquet_path, parquet_file):
 # sql(f'DROP TABLE IF EXISTS {full_table_name}')
