# Databricks notebook source
# MAGIC %run "./config_revenue_report_automation"

# COMMAND ----------

full_table_name = f'{target_database}.{target_tablename}'
parquet_file = f'{target_tablename}.parquet'
parquet_path = f'{table_parquet_dir}/{parquet_file}'

files = list_of_files(gcp_insights_file_folder)
#table = target_tablename_monthly
if len(files) == 0 :
  print('no files to be processed today')
else :
  for each in files :
    filepath =  f's3a://{revenue_report_extract_s3_access_key}:{revenue_report_extract_s3_secret_key}@{setconfig.revenue_report_s3_bucket}/{setconfig.gcp_insights_file_folder}/{each}'
    #print(each)
    run_load_tsv(each,filepath)

    



# COMMAND ----------

#copying files 
files = list_of_files(gcp_insights_file_folder)
if len(files) == 0 :
  print('no files in the quarterly bucket folder to be copied over today ')
else :
  print('all files  loaded for gcp insights  - now moving gcp insights file to archive')
copy_to_archive_boto (revenue_report_s3_bucket,revenue_report_extract_s3_access_key,revenue_report_extract_s3_secret_key, gcp_insights_file_folder, archive_folder)

# COMMAND ----------


