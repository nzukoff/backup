# Databricks notebook source
# MAGIC %sql
# MAGIC            
# MAGIC CREATE TABLE bdw.gcp_insights_monthly (
# MAGIC   MonthEndDate DATE,
# MAGIC   date STRING,
# MAGIC   company STRING,
# MAGIC   domain STRING,
# MAGIC   external_account_id STRING,
# MAGIC   account_id STRING,
# MAGIC   country STRING,
# MAGIC   state_or_province STRING,
# MAGIC   postal_code STRING,
# MAGIC   sku_id STRING,
# MAGIC   sku_description STRING,
# MAGIC   usage DOUBLE,
# MAGIC   unit STRING,
# MAGIC   currency STRING,
# MAGIC   charges DOUBLE,
# MAGIC   due_vendor DOUBLE,
# MAGIC   trial_use DOUBLE,
# MAGIC   num_vms DOUBLE,
# MAGIC   num_cpus DOUBLE,
# MAGIC   ram_mb DOUBLE,
# MAGIC   num_gpus DOUBLE,
# MAGIC   gpu_types STRING,
# MAGIC   earliest STRING,
# MAGIC   latest STRING,
# MAGIC   machine_spec_sum STRING,
# MAGIC   quote_id STRING,
# MAGIC   quote_creator STRING,
# MAGIC   payment_type STRING,
# MAGIC   withheld DOUBLE,
# MAGIC   released DOUBLE,
# MAGIC   abandoned DOUBLE,
# MAGIC   probation_start STRING,
# MAGIC   probation_end STRING,
# MAGIC   internal_note STRING,
# MAGIC   payment_schedule STRING,
# MAGIC   prepay_credits DOUBLE,
# MAGIC   start_date DATE,
# MAGIC   end_date DATE,
# MAGIC   private_offer_acceptance_date DATE,
# MAGIC   private_offer_total_contract_value DOUBLE,
# MAGIC   order_start_date DATE,
# MAGIC   order_end_date DATE,
# MAGIC   processed_file STRING,
# MAGIC   createDate DATE)
# MAGIC USING delta
# MAGIC PARTITIONED BY (MonthEndDate)
# MAGIC LOCATION 'dbfs:/mnt/bdw/gcp_insights_monthly'
# MAGIC TBLPROPERTIES (
# MAGIC   'Type' = 'EXTERNAL',
# MAGIC   'delta.minReaderVersion' = '1',
# MAGIC   'delta.minWriterVersion' = '2')

# COMMAND ----------

dbutils.fs.rm('dbfs:/mnt/bdw/gcp_insights_monthly',True) 
