# Databricks notebook source
# MAGIC %run ./it_ops_jira_config

# COMMAND ----------

# MAGIC %run ./it_jira_etl_utils

# COMMAND ----------

current_date = datetime.now()
formatted_current_date = current_date.strftime("%Y-%m-%d")

silver_start_time = sql("select current_timestamp() as cleanup_start_time ").first()['cleanup_start_time']

# COMMAND ----------

from pyspark.sql.functions import explode, col, when, lit, max, first,  coalesce, size, isnull
from pyspark.sql.window import Window

# Reading Bronze Data
df_bronze = spark.read.table(f"{unity_catalog}.{unity_schema}.jira_it_bronze")
max_ts = df_bronze.agg(max("processed_timestamp").alias("max_ts")).collect()[0]["max_ts"]
df = df_bronze.where(col("processed_timestamp") == max_ts)

# Adding few required transformed fields
df = df.withColumn('epic', when(col('type') == 'Epic', lit(True)).otherwise(lit(False)))
df = df.withColumn('sprint_count', size("sprints"))
df = df.withColumn('resolved', when(col('resolutiondate').isNull(), lit(True)).otherwise(lit(False)))

# Adding Active Sprint field
df_exploded = df.withColumn("sprint_struct", explode("sprints"))
df_with_active_flag = df_exploded.withColumn(
    "is_sprint_active",
    when(
        (col("sprint_struct.state") == "active"), 
        lit(True)
    ).otherwise(lit(False))
).drop("sprint_struct")

columns_to_group_by = [col_name for col_name in df_with_active_flag.columns if col_name != "is_sprint_active"]
df_aggregated = df_with_active_flag.groupBy(*columns_to_group_by) \
  .agg(
      max(col("is_sprint_active")).alias("current_sprint_flag")
  ).select("key", "current_sprint_flag")


df_joined = df.join(df_aggregated, on='key', how='left')

df_joined = df_joined.withColumn("current_sprint_flag", coalesce(col("current_sprint_flag"), lit(False)))

# COMMAND ----------

from pyspark.sql.functions import col, when, size, array_contains

# Adding Project and Board fields
df_joined  = df_joined.withColumn("parent_board",col("board")) 
df_joined = df_joined\
            .withColumn(
                "board",
                when(
                    col("board") == "ITGTM", 
                    lit("ITGTM-Other")
                ).otherwise(col("board"))
            ).withColumn(
                "board",
                when(
                    (col("board") == "ITGTM-Other") & array_contains(col("components"), "FieldOps"), 
                    lit("ITGTM-FieldOps")
                ).otherwise(col("board"))
            ).withColumn(
                "board",
                when(
                    (col("board") == "ITGTM-Other") & array_contains(col("components"), "FEMops"), 
                    lit("ITGTM-Mops")
                ).otherwise(col("board"))
            )


# COMMAND ----------

# Adding start date of current sprint
df_active_sprints = df_exploded.withColumn(
    "current_sprint_start_date",
    when(col("sprint_struct.state") == "active", col("sprint_struct.startDate"))
).select("key", "current_sprint_start_date")

windowSpec = Window.partitionBy("key")

df_with_start_date = df_active_sprints.withColumn(
    "current_sprint_start_date",
    max("current_sprint_start_date").over(windowSpec)
).dropDuplicates(["key"])


df_final = df_joined.join(df_with_start_date, on="key", how="left")
display(df_final)

# COMMAND ----------

from pyspark.sql.functions import when, current_date, datediff, lit, array_contains, lower

# Adding Aging Flag
df_with_aging = df_final.withColumn(
    "aging_flag",
    when(
        (col("board") == "BSEDATA") &
        (col("type") != "Epic") &
        (col("status").isin("Refine", "To Do")) 
        &(col("current_sprint_flag") == False)
        &(datediff(col("current_sprint_start_date"), col("created")) > 70)
        &(lower(col("project")) == "run")
        ,lit(True)
    ).when(
        (col("board") == "ITGTM-Other") &
        (col("type").isin("Bug", "Story", "Task")) &
        (col("status").isin("Refine", "To Do")) 
        &(col("current_sprint_flag") == False)
        &(lower(col("project")) == "run")
        ,lit(True)
    ).when(
        (col("board") == "ITGTM-FieldOps") &
        (col("type").isin("Bug", "Story", "Task")) &
        (col("status").isin("Refine", "To Do")) &
        (array_contains(col("components"), "KTLO")) 
        &(col("current_sprint_flag") == False)
        &(lower(col("project")) == "run")
        ,lit(True)
    ).when(
        (col("board") == "ITGTM-Mops") &
        (col("type").isin("Bug", "Story", "Task")) &
        (col("status").isin("Refine", "TO DO")) 
        &(col("current_sprint_flag") == False)
        &(lower(col("project")) == "run")
        ,lit(True)
    ).when(
        (col("board") == "ITCON") &
        (col("type").isin("Bug", "Story", "Task")) &
        (col("status").isin("Refine", "TO DO")) 
        &(col("current_sprint_flag") == False)
        &(datediff(col("current_sprint_start_date"), col("created")) > 70)
        ,lit(True)
    ).when(
        (col("board") == "BSECPQ") &
        (col("type").isin("Bug", "Story")) &
        (~col("status").isin("Done")) 
        &(col("current_sprint_flag") == False)
        &(datediff(col("current_sprint_start_date"), col("created")) > 70)
        &(lower(col("project")) == "run")
        ,lit(True)
    ).when(
        (col("board") == "BAR") &
        (col("type") != "Epic") &
        (~col("status").isin("Done", "Rejected", "Completed")) 
        &(col("current_sprint_flag") == False)
        &(datediff(col("current_sprint_start_date"), col("created")) > 70)
        ,lit(True)
    ).when(
        (col("board") == "MOIT") &
        (col("type") != "Epic") &
        (~col("status").isin("Done")) 
        &(col("current_sprint_flag") == False)
        &(datediff(col("current_sprint_start_date"), col("created")) > 70)
        ,lit(True)
    ).when(
        (col("board") == "ITLLM") &
        (col("type").isin("Bug", "Story", "Task")) &
        col("status").isin("Refine", "To Do") &
        (array_contains(col("components"), "KTLO"))
        &(col("current_sprint_flag") == False)
        &(datediff(col("current_sprint_start_date"), col("created")) > 70)
        ,lit(True)
    ).when(
        (col("board") == "BSECS") &
        (col("type").isin("Bug", "Story", "Task")) &
        col("status").isin("Refine", "To Do") &
        (array_contains(col("components"), "KTLO"))
        &(col("current_sprint_flag") == False)
        &(datediff(col("current_sprint_start_date"), col("created")) > 70)
        ,lit(True)
    ).otherwise(lit(False))
)


# COMMAND ----------

from pyspark.sql.functions import when, col, lit

# Adding Backlog Flag
df_with_backlog_flag = df_with_aging.withColumn(
    "backlog_flag",
    when(
        (col("board") == "BSEDATA") &
        (col("type") != "Epic") &
        (~col("status").isin("Done", "Cannot Do")) &
        (col("current_sprint_flag") == False),
        lit(True)
    ).when(
        ((col("board") == "ITGTM-Other") | (col("board") == "ITGTM-FieldOps") | (col("board") == "ITGTM-Mops")) &
        (col("type") != "Epic") &
        (~col("status").isin("Done", "Cancelled")) &
        (col("current_sprint_flag") == False),
        lit(True)
    ).when(
        (col("board") == "ITCON") &
        (col("type") != "Epic") &
        (~col("status").isin("Done", "Cancelled")) &
        (col("current_sprint_flag") == False),
        lit(True)
    ).when(
        (col("board") == "BSECPQ") &
        (col("type") != "Epic") &
        (~col("status").isin("Done")) &
        (col("current_sprint_flag") == False),
        lit(True)
    ).when(
        (col("board") == "BAR") &
        (col("type") != "Epic") &
        (~col("status").isin("Completed", "Rejected", "Open Defect", "Resolved Defect")) &
        (col("current_sprint_flag") == False),
        lit(True)
    ).when(
        (col("board") == "MOIT") &
        (col("type") != "Epic") &
        (~col("status").isin("Resolved")) &
        (col("current_sprint_flag") == False),
        lit(True)
    ).when(
        (col("board") == "ITLLM") &
        (col("type") != "Epic") &
        (~col("status").isin("Done", "Cancelled")) &
        (col("current_sprint_flag") == False),
        lit(True)
    ).when(
        (col("board") == "BSECS") &
        (col("type") != "Epic") &
        (~col("status").isin("Done", "Cancelled")) &
        (col("current_sprint_flag") == False),
        lit(True)
    ).otherwise(lit(False))
)

# COMMAND ----------

# Adding Opemn tickets Flag
df_with_open_ticket_flag = df_with_backlog_flag.withColumn(
    "open_ticket_flag",
    when(
        (col("board") == "BSEDATA") &
        (~col("status").isin("Cannot Do", "Done")),
        lit(True)
    ).when(
        ((col("board") == "ITGTM-Other") | (col("board") == "ITGTM-FieldOps") | (col("board") == "ITGTM-Mops")) &
        (~col("status").isin("Cancelled", "Done")),
        lit(True)
    ).when(
        (col("board") == "ITCON") &
        (~col("status").isin("Cancelled", "Done")),
        lit(True)
    ).when(
        (col("board") == "BSECPQ") &
        (~col("status").isin("Done")),
        lit(True)
    ).when(
        (col("board") == "BAR") &
        (~col("status").isin("Rejected", "Completed")),
        lit(True)
    ).when(
        (col("board") == "MOIT") &
        (~col("status").isin("Resolved")),
        lit(True)
    ).when(
        (col("board") == "ITLLM") &
        (~col("status").isin("Cancelled", "Done")),
        lit(True)
    ).when(
        (col("board") == "BSECS") &
        (~col("status").isin("Cancelled", "Done")),
        lit(True)
    ).otherwise(lit(False))
)


# COMMAND ----------

from pyspark.sql.functions import current_date, datediff

# Adding Open days Flag
df_with_days_open = df_with_open_ticket_flag.withColumn(
    "days_open",
    datediff(current_date(), col("created"))
)


# COMMAND ----------

from pyspark.sql.functions import current_date, datediff

# Adding Last updated Flag
df_with_days_since_last_update = df_with_days_open.withColumn(
    "days_since_last_update",
    datediff(current_date(), col("updated"))
)


# COMMAND ----------

from pyspark.sql.functions import when, col

# Adding Days open groups
df_with_days_open_group = df_with_days_since_last_update.withColumn(
    "days_open_group",
    when(col("days_open") <= 14, "0 - 2 weeks")
    .when((col("days_open") > 14) & (col("days_open") <= 28), "2 - 4 weeks")
    .when((col("days_open") > 28) & (col("days_open") <= 42), "5 - 6 weeks")
    .when((col("days_open") > 42) & (col("days_open") <= 56), "7 - 8 weeks")
    .when((col("days_open") > 56) & (col("days_open") <= 70), "9 - 10 weeks")
    .otherwise("10+ weeks")
)


# COMMAND ----------

from pyspark.sql.functions import when, col

# Adding Last updated groups
df_with_last_update_group = df_with_days_open_group.withColumn(
    "last_update_group",
    when(col("days_since_last_update") <= 14, "0 - 2 weeks")
    .when((col("days_since_last_update") > 14) & (col("days_open") <= 28), "2 - 4 weeks")
    .when((col("days_since_last_update") > 28) & (col("days_open") <= 42), "5 - 6 weeks")
    .when((col("days_since_last_update") > 42) & (col("days_open") <= 56), "7 - 8 weeks")
    .when((col("days_since_last_update") > 56) & (col("days_open") <= 70), "9 - 10 weeks")
    .otherwise("10+ weeks")
)


# COMMAND ----------

# DBTITLE 1,Add spilover flag
df_with_spillover_flag = df_with_last_update_group.withColumn(
    "spillover_flag",
    when((col("sprint_count") > 1) & (col("current_sprint_flag") == True), True)
    .otherwise(False)
)

# COMMAND ----------

epics_df = df_with_spillover_flag.filter(col("epic") == True).select("key", "summary")

df_with_parent_epic = df_with_spillover_flag.alias("tickets").join(
    epics_df.alias("epics"), 
    col("tickets.parent") == col("epics.key"), 
    "left"
).select(
    col("tickets.*"), 
    col("epics.key").alias("parent_epic_key"), 
    col("epics.summary").alias("parent_epic")
)

display(df_with_parent_epic)

# COMMAND ----------

active_workers_df = spark.table("main.workday.active_workers").filter(
    col("effective_date") == spark.table("main.workday.active_workers").agg({"effective_date": "max"}).collect()[0][0]
)

df_with_assignee_info = df_with_parent_epic.alias("tickets").join(
    active_workers_df.alias("workers"),
    col("workers.email") == col("tickets.reporter_email"),
    "left"
).select("*")

display(df_with_assignee_info)

# COMMAND ----------

df_with_manager = spark.sql("""WITH hierarchy AS (
  SELECT
    email,
    L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11
  FROM
    main.data_opex.workday_hierarchy
),
non_null_values AS (
  SELECT
    email,
    L11 AS manager
  FROM
    hierarchy
  WHERE
    L11 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L10 AS manager
  FROM
    hierarchy
  WHERE
    L10 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L9 AS manager
  FROM
    hierarchy
  WHERE
    L9 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L8 AS manager
  FROM
    hierarchy
  WHERE
    L8 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L7 AS manager
  FROM
    hierarchy
  WHERE
    L7 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L6 AS manager
  FROM
    hierarchy
  WHERE
    L6 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L5 AS manager
  FROM
    hierarchy
  WHERE
    L5 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L4 AS manager
  FROM
    hierarchy
  WHERE
    L4 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L3 AS manager
  FROM
    hierarchy
  WHERE
    L3 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L2 AS manager
  FROM
    hierarchy
  WHERE
    L2 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L1 AS manager
  FROM
    hierarchy
  WHERE
    L1 IS NOT NULL
  UNION ALL
  SELECT
    email,
    L0 AS manager
  FROM
    hierarchy
  WHERE
    L0 IS NOT NULL
), 
managers as (
  SELECT
    email,
    manager
  FROM (
    SELECT
      email,
      manager,
      ROW_NUMBER() OVER (PARTITION BY email ORDER BY email) AS row_num
    FROM
      non_null_values
  )
  WHERE
    row_num = 2
)
select * from managers --where manager in ('aman.gupta@databricks.com', 'romit.jadhwani@databricks.com')""")

# COMMAND ----------

df_with_direct_manager = df_with_assignee_info.alias("tickets").join(
    df_with_manager.alias("managers"),
    col("tickets.assignee_email") == col("managers.email"),
    "left"
).select(
    col("tickets.*"),
    col("managers.manager").alias("manager_email")
)

display(df_with_direct_manager.select("assignee_email","manager_email").distinct())

# COMMAND ----------

# Overwriting silver
df_with_direct_manager.createOrReplaceTempView("it_tickets_all")
issuesCount = df_with_direct_manager.count()
display(sql("select * from it_tickets_all"))

display("Overwrite - jira_it_silver")

display(spark.sql(f"""
CREATE OR REPLACE TABLE {unity_catalog}.{unity_schema}.jira_it_silver as
SELECT * FROM it_tickets_all;
"""))

# COMMAND ----------



# COMMAND ----------

display(sql(f"select * from {unity_catalog}.{unity_schema}.jira_it_silver"))

# COMMAND ----------

update_checkpoint(issuesCount, 'jira_it_silver_etl', 'jira_it_silver', job_start_time = silver_start_time)

# COMMAND ----------

display(spark.sql(f"select * from {unity_catalog}.{unity_schema}.base_checkpoint order by last_refresh_ts_UTC desc limit 10"))

# COMMAND ----------


