# Databricks notebook source
# MAGIC %run ./it_ops_jira_config

# COMMAND ----------

# MAGIC %run ./it_jira_etl_utils

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql.functions import col, lit, when, size

def append_it_issues(issues, processed_time):
    spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
    df = spark.createDataFrame(issues, schema=it_jira_schema)
    df = df.withColumn('processed_timestamp', lit(processed_time))

    df.createOrReplaceTempView("it_tickets_tmp_all")
    
    sql("select *, row_number() over (partition by key order by updated desc) as RN from it_tickets_tmp_all").createOrReplaceTempView('it_tickets_tmp_rn')
    dups = sql("select count(*) as cnt from it_tickets_tmp_rn where RN>1").first()['cnt']
    if dups > 0:
        display("Displaying duplicates ...")
        display(sql("select * from it_tickets_tmp_rn where key in (select distinct key from it_tickets_tmp_rn where RN>1) "))

    sql("select * from it_tickets_tmp_rn where RN=1").drop("RN").createOrReplaceTempView('it_tickets_tmp')
    display(sql("select * from it_tickets_tmp"))
    # display("Overwrite - jira_it_bronze")
    # spark.sql(f"""CREATE OR REPLACE TABLE {unity_catalog}.{unity_schema}.jira_it_bronze
    #           SELECT * FROM it_tickets_tmp
    #           """)
    display("Append - jira_it_bronze")
    spark.sql(f"""INSERT INTO TABLE {unity_catalog}.{unity_schema}.jira_it_bronze
              SELECT * FROM it_tickets_tmp
              """)

# COMMAND ----------

current_date = datetime.now()
formatted_current_date = current_date.strftime("%Y-%m-%d")

cleanup_start_time = sql("select current_timestamp() as cleanup_start_time ").first()['cleanup_start_time']

projects = ", ".join(it_projects)

jql = f"project in ({projects})"

display(f"JQL - {jql}")

# COMMAND ----------

issuesCount = get_max_count(jql)
display(f"Total issues count received from source - {issuesCount}")

# COMMAND ----------

issues_list, issues_raw_list,failed_keys_within_batch, failed_batch  = fetch_issues_from_jira(jql, parse_it_jira_issue, True)

# COMMAND ----------

append_it_issues(issues_list, cleanup_start_time)

# COMMAND ----------

update_checkpoint(issuesCount, 'jira_it_bronze_etl', 'jira_it_bronze', job_start_time = cleanup_start_time)

# COMMAND ----------

#logging failed keys
log_failed_keys(failed_keys_within_batch, 'rejected_jira_keys')

#checking if there are any failed offsets even after retries
failed_batch_check(failed_batch)

# COMMAND ----------

display(spark.sql(f"select * from {unity_catalog}.{unity_schema}.jira_it_bronze order by processed_timestamp desc limit 10"))

# COMMAND ----------

display(spark.sql(f"select * from {unity_catalog}.{unity_schema}.base_checkpoint order by last_refresh_ts_UTC desc limit 10"))

# COMMAND ----------


