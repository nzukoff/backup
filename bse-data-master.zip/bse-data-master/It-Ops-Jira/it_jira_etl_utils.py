# Databricks notebook source
!pip install jira==3.5.2
!pip install pytz==2021.3

# COMMAND ----------

import ast
import json
import re
import math
import time
from datetime import datetime, timedelta

import pandas
import pytz
from jira import JIRA
from concurrent.futures import ThreadPoolExecutor, ALL_COMPLETED
from pyspark.sql.functions import current_timestamp, lit
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    DoubleType,
    TimestampType,
    DateType,
    ArrayType,
    LongType,
    IntegerType,
)

# COMMAND ----------

it_projects = ['BSECPQ', 'BAR', 'BSEDATA', 'ITCON', 'ITGTM', 'MOIT', 'BSECS', 'ITLLM']

# COMMAND ----------

def chunk_list(input_list, chunk_size):
    for i in range(0, len(input_list), chunk_size):
        yield input_list[i:i + chunk_size]

# COMMAND ----------

it_jira_secret_scope = 'it-jira-ops-service'

jira_api_token = dbutils.secrets.get(it_jira_secret_scope, "jira_api_token")
jira_user = dbutils.secrets.get(it_jira_secret_scope, "jira_username")
jira_host = dbutils.secrets.get(it_jira_secret_scope, "jira_host")
options = {"server": jira_host}
jira = JIRA(options, basic_auth=(jira_user, jira_api_token))

# COMMAND ----------

def get_max_count(jql):
    issuesCount = jira.search_issues(jql, startAt=0, maxResults=0, json_result=True)["total"]
    return issuesCount

# COMMAND ----------

def fetch_issues_from_jira(jql, parse_type, make_dump=False):
    def fetch_and_update_tickets(start_at):
        time.sleep(0.5)
        block_size = 100
        all_issues = {}
        all_issues_raw = {}

        try:
            tickets = jira.search_issues(jql, startAt=start_at, maxResults=block_size)
            print("start_at", start_at)
            for ticket in tickets:
                try:
                    all_issues[ticket.key] = parse_type(ticket)
                    if make_dump:
                        all_issues_raw[ticket.key] = parse_issue_raw_dump(ticket)
                except Exception as e:
                    print(f"error {e} for issue {ticket.key}")
                    failed_keys_within_batch.append((ticket.key, str(e)))

            issues_list.extend(list(all_issues.values()))
            issues_raw_list.extend(list(all_issues_raw.values()))
        except:
            print("exception occurred at ", start_at)
            time.sleep(1)
            failed_batch.append(start_at)

    issuesCount = get_max_count(jql)
    totalBatches = math.ceil(issuesCount / 100)
    apiParam = [i * 100 for i in range(totalBatches)]
    pool_size = 5
    failed_batch = []
    issues_list = []
    issues_raw_list = []
    failed_keys_within_batch = []

    with ThreadPoolExecutor(max_workers=pool_size) as pool:
        futures = [pool.submit(fetch_and_update_tickets, x) for x in apiParam]
        for future in futures:
            future.result()

    print(f"Total issues processed - ", len(issues_list))

    # creating a new list for the retry of failed offsets
    retry_failed_batch = []
    retry_failed_batch.extend(failed_batch)  # copying the list for retry
    failed_batch.clear()  # clearing as it will populate again by the fetch_and_update_tickets function if any failed offsets are there
    if retry_failed_batch:
        # retrying for failed offset
        print(f"Retring for failed offsets JQL - {retry_failed_batch}")
        with ThreadPoolExecutor(max_workers=pool_size) as pool:
            futures = [
                pool.submit(fetch_and_update_tickets, x) for x in retry_failed_batch
            ]
            for future in futures:
                future.result()
        print(f"Total issues processed including retry run - len({issues_list})")

    return issues_list, issues_raw_list, failed_keys_within_batch, failed_batch

# COMMAND ----------

def incremental_range(pipeline_name):

    lastUpdatedfrom = sql(
        f"select date_format(max(jql_lastUpdatedTo) - INTERVAL '10' minutes,'yyyy-MM-dd HH:mm') lastUpdatedfrom from {unity_catalog}.{unity_schema}.base_checkpoint where pipeline_name='{pipeline_name}' "
    ).first()["lastUpdatedfrom"]

    lastUpdatedTo = sql(
        "select date_format(from_utc_timestamp(current_timestamp(), 'PST'),'yyyy-MM-dd HH:mm') lastUpdatedTo "
    ).first()["lastUpdatedTo"]

    return lastUpdatedfrom, lastUpdatedTo

# COMMAND ----------

def update_checkpoint(issuesCount, pipeline_name, table_name, lastUpdatedFrom=None, lastUpdatedTo=None, job_start_time=None):

    if lastUpdatedFrom and lastUpdatedTo:
        sql(
            f"insert into {unity_catalog}.{unity_schema}.base_checkpoint select '{pipeline_name}' as pipeline_name,'{table_name}' as table_name,cast('{lastUpdatedFrom}'||':00' as timestamp) as jql_lastUpdatedfrom,cast('{lastUpdatedTo}'||':00' as timestamp) as jql_lastUpdatedTo, '{issuesCount}' as affected_rows, to_utc_timestamp('{lastUpdatedTo}'||':00','PST') as last_refresh_ts_UTC"
        )
    else:
        sql(
            f"insert into {unity_catalog}.{unity_schema}.base_checkpoint select '{pipeline_name}' as pipeline_name,'{table_name}' as table_name, null as jql_lastUpdatedfrom, null as jql_lastUpdatedTo, '{issuesCount}' as affected_rows, '{job_start_time}' as last_refresh_ts_UTC"
        )

    print("Added the delta entry in base_checkpoint table.")

# COMMAND ----------

it_jira_schema = StructType(
    [
        StructField("key", StringType(), True),
        StructField("project", StringType(), True),
        StructField("board", StringType(), True),
        StructField("type", StringType(), True),
        StructField("parent", StringType(), True),
        StructField("created", TimestampType(), True),
        StructField("updated", TimestampType(), True),
        StructField("summary", StringType(), True),
        StructField(
            "sprints",
            ArrayType(
                StructType(
                    [
                        StructField("completeDate", TimestampType(), True),
                        StructField("name", StringType(), True),
                        StructField("startDate", TimestampType(), True),
                        StructField("state", StringType(), True),
                    ]
                ),
                True,
            ),
            True,
        ),
        StructField("components", ArrayType(StringType(), True), True),
        StructField("assignee", StringType(), True),
        StructField("assignee_email", StringType(), True),
        StructField("dev_assignee", StringType(), True),
        StructField("dev_assignee_email", StringType(), True),
        StructField("reporter", StringType(), True),
        StructField("status", StringType(), True),
        StructField("resolutiondate", TimestampType(), True),
        StructField("story_points", DoubleType(), True),
        StructField("reporter_email", StringType(), True),
        StructField("labels", ArrayType(StringType(), True), True),
        StructField("acceptance_criteria", StringType(), True),
    ]
)



def parse_project(issue):
    new_project_field = issue.raw["fields"].get("customfield_19517")
    if new_project_field:
        return new_project_field.get("value")
    
    projects = issue.fields.customfield_15605 or []
    if len(projects) > 0:
        return projects[0].value
    

def parse_components(issue):
    components = issue.fields.components or []
    return [
        str(c.name) for c in components
    ]
    
def parse_labels(issue):
    labels = issue.fields.labels or []
    return [
        str(c) for c in labels
    ]

def parse_it_jira_issue(ticket):
    def get_key(obj, *keys):
        if obj is None:
            return obj
        for key in keys:
            if key in obj.raw:
                return obj.raw[key]
        return None

    def get_keys(obj, default, *keys):
        v = obj
        for key in keys:
            if v is None:
                return default
            v = v.get(key)
        return v
    # def parse_dev_assignee():
    #     customfield_18700
    return {
        "key": ticket.key,
        "project": parse_project(ticket),
        "board": ticket.fields.project.key,
        "type": ticket.fields.issuetype.name,
        "parent": ticket.fields.customfield_10008,#ticket.fields.parent.key if hasattr(ticket.fields, "parent") else None,
        "created": parse_date(ticket.fields.created),
        "updated": parse_date(ticket.fields.updated),
        "summary": ticket.fields.summary,
        "sprints": parse_sprint(ticket) or [],
        "components": parse_components(ticket) or [],
        "assignee": ticket.fields.assignee.displayName if hasattr(ticket.fields, "assignee") and ticket.fields.assignee else None,
        "assignee_email": getattr(ticket.fields.assignee, "emailAddress", None),
        "dev_assignee": ticket.fields.customfield_18700.displayName if hasattr(ticket.fields, "customfield_18700") and ticket.fields.customfield_18700 else None,
        "dev_assignee_email":ticket.fields.customfield_18700.emailAddress if hasattr(ticket.fields, "customfield_18700") and ticket.fields.customfield_18700 else None,
        "reporter": ticket.fields.reporter.displayName if ticket.fields.reporter else None,
        "status": ticket.fields.status.name,
        "resolutiondate": parse_date(ticket.fields.resolutiondate),
        "story_points": ticket.fields.customfield_10004,
        "reporter_email": getattr(ticket.fields.reporter, "emailAddress", None),
        "labels": parse_labels(ticket) or [],
        "acceptance_criteria": ticket.fields.customfield_14278,
    }

# COMMAND ----------

def parse_issue_raw_dump(issue):
    return {
        "key": issue.key,
        "created": parse_date(issue.fields.created),
        "updated": parse_date(issue.fields.updated),
        "data": issue.raw,
    }


jira_schema_raw_dump = StructType(
    [
        StructField("key", StringType(), True),
        StructField("updated", TimestampType(), True),
        StructField("created", TimestampType(), True),
        StructField("data", StringType(), True),
    ]
)

# COMMAND ----------

def parse_date(date_str):
    return datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S.%f%z") if date_str else None
  
def parse_sprint(i):
    sprints = i.fields.customfield_10007 or []
    return [
        {
            "name": s.name,
            "state": s.state,
            "startDate": parse_date(s.__dict__.get("startDate")),
            "completeDate": parse_date(s.__dict__.get("completeDate")),
        }
        for s in sprints
    ]

# COMMAND ----------

def log_failed_keys(failed_keys_within_batch, reject_keys_table):
    if failed_keys_within_batch:
        print(f"writing failed keys to {reject_keys_table}")
        df_failed = spark.createDataFrame(failed_keys_within_batch, ["key", "error"])
        df_failed = df_failed.withColumn("processTimestamp", current_timestamp())
        df_failed.write.mode("append").saveAsTable(
            f"{unity_catalog}.{unity_schema}.{reject_keys_table}"
        )

# COMMAND ----------

def failed_batch_check(failed_batch):
    if failed_batch:
        print(f"Failed to fetch all the tickets for the given offsets - {failed_batch} ")
        print("Please backfill")
        raise Exception(f"Failed to fetch all the tickets of the run.")
