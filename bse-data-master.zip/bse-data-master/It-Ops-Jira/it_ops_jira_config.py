# Databricks notebook source
from dataclasses import dataclass

@dataclass(frozen=True)
class defineconfig:
  name: str
  unity_catalog: str
  unity_schema: str


# COMMAND ----------

# Config params
ta_config =  { 'prod' : {
  'name' : 'Production',
  'unity_catalog' : 'main',
  'unity_schema' : 'it_data_ops_jira',
} ,

'staging' : {
  'name' : 'Staging',
  'unity_catalog' : 'integration',
  'unity_schema' : 'it_data_ops_jira',
} }

# COMMAND ----------

ENV =    dbutils.widgets.get("env").lower() 

try:
  setconfig = defineconfig(
                        ta_config[ENV]['name'],
                        ta_config[ENV]['unity_catalog'],
                        ta_config[ENV]['unity_schema'],
                      )
except Exception as e:
  print(e)
  raise Exception(f'Configurations are not defined for {ENV}')

# COMMAND ----------

name = setconfig.name            
unity_catalog = setconfig.unity_catalog
unity_schema = setconfig.unity_schema
