# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_participant  
# MAGIC
# MAGIC Description: The xc_participant table contains data on participants in the commission system, including their personal information, employment details, and commission-related information. This table is significant to the business as it serves as a central repository for participant data, allowing for accurate and efficient commission calculations and payouts. The data in this table includes participant IDs, names, regions, hire and termination dates, job titles, and commission eligibility status, among other fields.
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Xactly JDBC Driver
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC   - **Table Name** : xc_participant
# MAGIC   - **Description** : Contains Xactly xc_participant raw data loaded after type casting attributes to support data types compatible with logFood.
# MAGIC   - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC
# MAGIC - **Silver Table**
# MAGIC   - **Schema Name** : fin_commissions_silver
# MAGIC   - **Table Name** : xc_participant
# MAGIC   - **Description** : Additional fiscal attributes added using HIRE_DATE
# MAGIC   - **Additional Columns** : FISCAL_WEEK, FISCAL_MONTH, FISCAL_QUARTER, FISCAL_YEAR, PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC   - **Other Table Dependencies** : it_core_dim.bi_dates

# COMMAND ----------

from datetime import datetime, timedelta
from pyspark.sql.functions import col, to_date
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_participant'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_participant'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT CAST(PARTICIPANT_ID as DECIMAL(38,0)) PARTICIPANT_ID,
          CAST(VERSION as DECIMAL(38,0)) VERSION,
          NAME,
          DESCR,
          REGION,
          PARTICIPANT_TYPE,
          PREFIX,
          FIRST_NAME,
          MIDDLE_NAME,
          LAST_NAME,
          EMPLOYEE_ID,
          CAST(SALARY as DECIMAL(38,8)) SALARY,
          CAST(SALARY_UNIT_TYPE_ID as DECIMAL(38,0)) SALARY_UNIT_TYPE_ID,
          CAST(HIRE_DATE as string) HIRE_DATE,
          CAST(TERMINATION_DATE as string) TERMINATION_DATE,
          CAST(PERSONAL_TARGET as DECIMAL(38,8)) PERSONAL_TARGET,
          CAST(PR_TARGET_UNIT_TYPE_ID as DECIMAL(38,0)) PR_TARGET_UNIT_TYPE_ID,
          CAST(NATIVE_CUR_UNIT_TYPE_ID as DECIMAL(38,0)) NATIVE_CUR_UNIT_TYPE_ID,
          IS_ACTIVE,
          CAST(USER_ID as DECIMAL(38,0)) USER_ID,
          CAST(CREATED_DATE as string) CREATED_DATE,
          CAST(CREATED_BY_ID as DECIMAL(38,0)) CREATED_BY_ID,
          CREATED_BY_NAME,
          CAST(MODIFIED_DATE as string) MODIFIED_DATE,
          CAST(MODIFIED_BY_ID as DECIMAL(38,0)) MODIFIED_BY_ID,
          MODIFIED_BY_NAME,
          Commission_Eligible,
          Department,
          Segment,
          District,
          Work_Location,
          Job_Title,
          OTE_Pay_Mix,
          Subsidiary,
          SA_Segment,
          SA_Region,
          Workday_ID,
          ADP_ID,
          SFDC_Role,
          CAST("GTM_Vertical/Horizontal_Mapping" AS string) GTM_Vertical___Horizontal_Mapping,
          Country,
          Draw,
          FX_Rate,
          Stop_Credit,
          Draw_Recoverable,
          CAST(OTE as float) OTE,
          CAST(LOA_Start_Date AS string) LOA_Start_Date,
          CAST(LOA_End_Date AS string) LOA_End_Date,
          CAST(Hire_Date_Plan_Doc AS string) Hire_Date_Plan_Doc,
          CAST(Plan_Effective_Start_Date AS string) Plan_Effective_Start_Date,
          CAST(BCR_Effective_Start_Date AS string) BCR_Effective_Start_Date,
          CAST(OTE_UnitTypeId as DECIMAL(38,0)) OTE_UnitTypeId,
          CAST(PAYMENT_CUR_UNIT_TYPE_ID as DECIMAL(38,0)) PAYMENT_CUR_UNIT_TYPE_ID,
          CAST(SOURCE_ID as DECIMAL(38,0)) SOURCE_ID,
          CAST(EMP_STATUS_ID as DECIMAL(38,0)) EMP_STATUS_ID,
          CAST(EFFECTIVE_START_DATE AS string) EFFECTIVE_START_DATE,
          CAST(EFFECTIVE_END_DATE AS string) EFFECTIVE_END_DATE,
          IS_MASTER,
          CAST(BUSINESS_GROUP_ID as DECIMAL(38,0)) BUSINESS_GROUP_ID,
          OBJ_BONUS_TARGET,
          CAST(OBJ_BONUS_TARGET_UNITTYPE_ID as DECIMAL(38,0)) OBJ_BONUS_TARGET_UNITTYPE_ID,
          OBJ_PAYMENT_CAP_PERCENT,
          IS_OBJ_ACTIVE,
          CAST(PRORATED_SALARY as DECIMAL(38,8)) PRORATED_SALARY,
          CAST(PRORATED_PERSONAL_TARGET as DECIMAL(38,8)) PRORATED_PERSONAL_TARGET,
          CAST(VERSION_REASON_ID as DECIMAL(38,0)) VERSION_REASON_ID,
          CAST(VERSION_SUB_REASON_ID as DECIMAL(38,0)) VERSION_SUB_REASON_ID

    FROM XACTLY.xc_participant

)'''

df_participant = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

# COMMAND ----------

bronze_df_participant, process_date = add_audit_attributes(df_participant)
bronze_df_participant = bronze_df_participant.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_participant
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM {target_catalog}.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_participant = df_participant.withColumn('HIRE_DATE_UPD', to_date(col('HIRE_DATE')))
df_participant_upd = df_participant.join(df_dates,df_participant.HIRE_DATE_UPD ==  df_dates.date,"left")
df_participant_upd = df_participant_upd.drop('HIRE_DATE_UPD','date')

# COMMAND ----------

final_df_participant, process_date = add_audit_attributes(df_participant_upd)
final_df_participant = final_df_participant.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_participant.columns:
    final_df_participant = final_df_participant.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_participant
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))

# COMMAND ----------


