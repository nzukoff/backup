# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import lit, udf
from pyspark.sql.types import StringType
from contextlib import contextmanager
from typing import Iterator
from contextlib import nullcontext
from logging import Logger

# COMMAND ----------

# MAGIC %run "./sales_intelligence_config"

# COMMAND ----------

target_tablename = 'xc_commissions_extended'
snapshot_tablename = 'xc_commissions_extended_history'
staging_tablename = 'xc_commissions_extended_staging'

# COMMAND ----------

def get_fiscal_year():
    current_date = datetime.now()
    current_year = current_date.year
    fiscal_year = current_year if current_date.month >= 3 else current_year - 1
    return f'FY{str(fiscal_year + 1)[-2:]}'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Snapshot Table

# COMMAND ----------

#Extract the data in xc_commissions_extended which contains the latest data

full_raw_table_name_snap = f'{target_catalog}.{target_silver_schema}.{snapshot_tablename}'
df_snap = sql(f''' SELECT * FROM main.{target_gold_schema}.{target_tablename} ''')

# COMMAND ----------

df_snap = df_snap.drop("PROCESS_DATE","PROCESS_USER")

# COMMAND ----------

final_df_snap, processDate = add_audit_attributes(df_snap)
final_df_snap = final_df_snap.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_snap.createOrReplaceTempView("SNAPSHOT_TABLE")

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {processDate}')

(final_df_snap
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Final Table

# COMMAND ----------

df_commissions_extended = spark.sql(f''' 
                  WITH CTE AS (
                      SELECT 
                            cr.CREDIT_ID,
                            cr.CREDIT_TYPE_NAME,
                            cr.PERIOD_NAME,
                            cm.ITEM_CODE,
                            cr.ORDER_ITEM_ID,
                            cr.ORDER_CODE,
                            cm.PARTICIPANT_NAME,
                            cr.AMOUNT as CREDIT_AMOUNT,
                            TRIM(')' FROM SUBSTRING(cm.PARTICIPANT_NAME, INSTR(cm.PARTICIPANT_NAME, '(')+1, LEN(cm.PARTICIPANT_NAME)-INSTR(cm.PARTICIPANT_NAME, '('))) SFDC_ID,
                            cm.PARTICIPANT_ID,
                            cm.POSITION_ID as comm_POSITION_ID,
                            cm.POSITION_NAME,
                            'N/A' as COMMISSION_AMOUNT,
                            'N/A' as AMOUNT_DISPLAY_SYMBOL,
                            'N/A' as RATE_TABLE_TIER,
                            'N/A' as RATE_AMOUNT,
                            -- cm.AMOUNT TEST_COMMISSION_AMOUNT,
                            -- cm.AMOUNT_DISPLAY_SYMBOL,
                            -- cm.RATE_TABLE_TIER,
                            -- cm.RATE_AMOUNT,
                            cm.QUOTA_NAME,
                            cm.QUOTA_PERIOD_TYPE_NAME,
                            cm.EARNING_GROUP_NAME,
                            cm.ATTAINMENT_VALUE,
                            ci.COMP_ORDER_ITEM_ID,
                            CAST(ci.INCENTIVE_DATE as DATE) INCENTIVE_DATE,
                            ci.PRODUCT_NAME,
                            ci.CUSTOMER_NAME,
                            ci.Billing_Schedule,
                            ci.Opportunity_Name,
                            ci.Platform_Type,
                            ci.Type,
                            ci.AMOUNT as COMP_ORDER_ITEM_AMOUNT,
                            ut.NAME as ITEM_AMOUNT_UNIT, 
                            ot.NAME as ORDER_TYPE,
                            cr.PLAN_NAME

                            FROM main.fin_commissions_silver.xc_comp_order_item ci 
                            INNER JOIN main.fin_commissions_silver.xc_credit cr
                              ON (ci.COMP_ORDER_ITEM_ID = cr.ORDER_ITEM_ID AND
                                  ci.ITEM_CODE = cr.ITEM_CODE)

                            LEFT JOIN main.fin_commissions_silver.xc_commission cm
                              ON (cr.ORDER_ITEM_ID = cm.ORDER_ITEM_ID AND 
                                  cr.ITEM_CODE = cm.ITEM_CODE AND 
                                  cr.PARTICIPANT_NAME = cm.PARTICIPANT_NAME AND 
                                  cr.AMOUNT = cm.CREDIT_AMOUNT AND 
                                  cr.CREDIT_TYPE_NAME = cm.EARNING_GROUP_NAME AND
                                  cr.ORDER_CODE = cr.ORDER_CODE)

                            LEFT JOIN main.fin_commissions_silver.xc_unit_type ut
                              ON ut.UNIT_TYPE_ID = CAST(ci.AMOUNT_UNIT_TYPE_ID AS DECIMAL(38,0))
                              
                            LEFT JOIN main.fin_commissions_silver.xc_order_type ot
                              ON ot.ORDER_TYPE_ID = ci.ORDER_TYPE_ID

                            WHERE (ci.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_comp_order_item)) AND
                                  (ut.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_unit_type)) AND
                                  (ot.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_order_type)) AND
                                  (cr.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_credit)) AND
                                  (cm.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_commission)) AND

                                  cr.CREDIT_TYPE_NAME IN ('Commissionable Incremental Consumption',
                                                          'Total Commit', 
                                                          'Count New Logo Commit', 
                                                          'Count New Customer Consumption',
                                                          'T2 Commissionable Incremental Consumption',
                                                          'Activated Customer Count Consumption',
                                                          'U2 Opportunities',
                                                          'Product Consumption',
                                                          'Tier 2 Product Consumption',
                                                          'Product Consumption DBSQL',
                                                          'Product Consumption GenAI',
                                                          'Product Consumption UC',
                                                          'Technical Certified Individuals',
                                                          'Activated Logo Commit',
                                                          'Activated Logo DB4K Commit',
                                                          'Activated Logo Consumption',
                                                          'Activated Logo DB4K Consumption')
                  )

                  SELECT DISTINCT
                        ct.*, 
                        us.username,
                        xp.FISCAL_WEEK,
                        xp.FISCAL_MONTH,
                        xp.FISCAL_QUARTER,
                        xp.FISCAL_HALF_YEAR,
                        xp.FISCAL_YEAR,
                        xp.DATE as PERIOD_DATE 

                  FROM CTE ct 
                  LEFT JOIN main.sfdc_bronze.user us
                    ON ct.SFDC_ID = us.ID
                  JOIN main.fin_commissions_silver.xc_period xp
                    ON ct.PERIOD_NAME = xp.NAME

                  WHERE us.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.user) AND 
                        xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_period)
                                    
                                    ''')

df_commissions_extended.createOrReplaceTempView('commissions_extended')

# COMMAND ----------

df_updated = spark.sql(f''' 
                       WITH CTE AS (
                          SELECT DISTINCT pa.POSITION_NAME,
                                          p.POSITION_ID as pos_POSITION_ID,  
                                          p.EFFECTIVE_START_DATE, 
                                          p.EFFECTIVE_END_DATE

                          FROM main.fin_commissions_silver.xc_pos_part_assignment pa
                          LEFT JOIN main.fin_commissions_silver.xc_position p 
                            ON pa.position_id = p.position_id

                          WHERE pa.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_part_assignment)  AND p.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_position) 
                        ),

                        CTE2 AS (
                        SELECT DISTINCT ce.*,
                                        ct.pos_POSITION_ID,
                                        ct.EFFECTIVE_START_DATE, 
                                        ct.EFFECTIVE_END_DATE
                        FROM commissions_extended ce 
                          LEFT JOIN CTE ct
                            ON (
                                  ce.POSITION_NAME = ct.POSITION_NAME 
                                  AND ce.PERIOD_DATE >= ct.EFFECTIVE_START_DATE 
                                  AND ce.PERIOD_DATE <= ct.EFFECTIVE_END_DATE
                                )
                        )
                        
                          SELECT DISTINCT ct.* 
                          FROM CTE2 ct 
                          JOIN main.fin_commissions_silver.xc_period xp
                            ON ct.PERIOD_DATE = xp.START_DATE

                          WHERE (SUBSTRING(xp.START_DATE, 0, 7) = substring(xp.END_DATE, 0, 7)) AND
                                xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_period)
                       
                       ''')
                       
df_updated = df_updated.drop('comm_POSITION_ID')
df_updated = df_updated.withColumnRenamed('pos_POSITION_ID', 'POSITION_ID')
df_updated.createOrReplaceTempView('df_temp1')

# COMMAND ----------

df_FINAL = spark.sql(f''' 
    SELECT dt.*,
       pt.TITLE_NAME as Title,
       tg.`group` as Title_Group
       
    FROM df_temp1 dt 
      LEFT JOIN main.fin_commissions_silver.xc_pos_title_assignment pt
              ON dt.POSITION_ID = pt.POSITION_ID
      LEFT JOIN main.fin_commissions_silver.Title_Group_Map tg
              ON pt.TITLE_NAME = tg.distinct_title

    WHERE pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_title_assignment) AND
          tg.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.Title_Group_Map)
  ''')
     
df_FINAL.createOrReplaceTempView("FINAL_DF")

# COMMAND ----------

final_df_commissions_extended, process_date = add_audit_attributes(df_FINAL)
final_df_commissions_extended = final_df_commissions_extended.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_commissions_extended.createOrReplaceTempView("GOLD_TABLE")

# COMMAND ----------

# Distinct fiscal year flowing from data
distinct_DV_values = [row["FISCAL_YEAR"] for row in final_df_commissions_extended.select("FISCAL_YEAR").distinct().collect()]
distinct_DV_values

# COMMAND ----------

condition = "FISCAL_YEAR IN (" + ", ".join([f"'{value}'" for value in distinct_DV_values]) + ")"
condition

# COMMAND ----------

staging_full_table_name = f'{target_catalog}.fin_commissions_silver.{staging_tablename}'
print(f'Updating data in {staging_full_table_name} for {process_date}')

date_str = process_date.strftime("%Y-%m-%d")
(
    final_df_commissions_extended
      .write
      .mode('overwrite')
      .format('delta')
      .option('mergeSchema', 'true')
      .partitionBy('FISCAL_YEAR')
      .option("replaceWhere", condition)
      .saveAsTable(staging_full_table_name)
)

# COMMAND ----------

df_staging_read = spark.sql(f''' SELECT * FROM {target_catalog}.fin_commissions_silver.{staging_tablename} ''')

# COMMAND ----------

full_table_name = f'{target_catalog}.{target_gold_schema}.{target_tablename}'
print(f'Updating data in {full_table_name} for {process_date}')

date_str = process_date.strftime("%Y-%m-%d")
(
    df_staging_read
        .write
        .mode('overwrite')
        .format('delta')
        .option('overwriteSchema', 'true')
        .partitionBy('FISCAL_YEAR')
        .saveAsTable(full_table_name)
)
