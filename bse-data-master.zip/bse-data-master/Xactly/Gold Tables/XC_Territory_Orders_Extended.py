# Databricks notebook source
from pyspark.sql.functions import col, to_date, date_format, upper
from datetime import datetime
from pyspark.sql.functions import lit, udf
from pyspark.sql.types import StringType
from contextlib import contextmanager
from typing import Iterator
from contextlib import nullcontext
from logging import Logger

# COMMAND ----------

# MAGIC %run "./sales_intelligence_config"

# COMMAND ----------

# DBTITLE 1,Extended Territory Orders Snapshot
target_tablename = 'xc_territory_orders_extended'
snapshot_tablename = 'xc_territory_orders_extended_history'
staging_tablename = 'xc_territory_orders_extended_staging'

# COMMAND ----------

def get_fiscal_year():
    current_date = datetime.now()
    current_year = current_date.year
    fiscal_year = current_year if current_date.month >= 3 else current_year - 1
    return f'FY{str(fiscal_year + 1)[-2:]}'

# COMMAND ----------

# MAGIC %md
# MAGIC #### Silver Snapshot Table

# COMMAND ----------

#Extract the data in xc_participant_extended which contains the latest data

full_raw_table_name_snap = f'{target_catalog}.{target_silver_schema}.{snapshot_tablename}'
df_snap = sql(f''' SELECT * FROM main.{target_gold_schema}.{target_tablename} ''')

# COMMAND ----------

df_snap = df_snap.drop("PROCESS_DATE","PROCESS_USER")

# COMMAND ----------

final_df_snap, processDate = add_audit_attributes(df_snap)
final_df_snap = final_df_snap.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_snap.createOrReplaceTempView("SNAPSHOT_TABLE")

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {processDate}')

(final_df_snap
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Final Table

# COMMAND ----------

# DBTITLE 1,House Account Territory Mapping
###### Data Sources
# 1. xc_pos_relations and xc_pos_rel_type
#- Relationship_Name: SDR, Partner, Region, RegionT2
#- Relationship_Effective_Start and End_Date
#- From_Position: House Account	
####  To_Position: Position Name	

# 2. xc_region_territory_lookup
#### Assignments: Same as From_Position i.e. House Account
#### Territory

#### Logic
# Each participant (position name) is associated with a house account and their relationship is defined in relationship_name column.
# Extract all territories mapped to a house account for each participant (position name)

df_Relations_Rel_Type = spark.sql(f''' 
  
  SELECT 
        pr.TO_POS_ID, 
        pr.TO_POS_NAME,
        pr.FROM_POS_ID,
        pr.FROM_POS_NAME,
        pt.NAME as RELATIONSHIP_NAME, 
        rt.Territory,
        TO_DATE(pt.EFFECTIVE_START_DATE, 'yyyy-M-dd') PERIOD_START_DATE,
        TO_DATE(pt.EFFECTIVE_END_DATE, 'yyyy-M-dd') PERIOD_END_DATE,
        --pr.FISCAL_YEAR,
        RANK() OVER (PARTITION BY pr.TO_POS_NAME ORDER BY TO_DATE(pt.EFFECTIVE_START_DATE, 'yyyy-M-dd') DESC) rnk

  FROM main.fin_commissions_silver.xc_pos_relations pr 
    LEFT JOIN main.fin_commissions_silver.xc_pos_rel_type pt
      ON pr.POS_REL_TYPE_ID = pt.POS_REL_TYPE_ID

    LEFT JOIN main.fin_commissions_silver.latest_pos_part_mapping pm
      ON pr.FROM_POS_NAME = pm.POSITION_NAME   

    LEFT JOIN main.fin_commissions_silver.xc_region_territory_lookup rt
      ON pm.SFDC_ID = rt.Assignments

  WHERE pr.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_relations) 
    AND pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_rel_type)
    AND rt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_region_territory_lookup)

    AND TO_DATE(pt.EFFECTIVE_START_DATE, 'yyyy-M-dd') <= TO_DATE(rt.Effective_End, 'M/d/yyyy')
    AND TO_DATE(pt.EFFECTIVE_END_DATE, 'yyyy-M-dd') >= TO_DATE(rt.Effective_Start, 'M/d/yyyy')
''')

df_Relations_Rel_Type.createOrReplaceTempView("Relations_Rel_Type")

# COMMAND ----------

# DBTITLE 1,Incremental Consumption Data Merge
###### Data Sources

# xc_comp_order_item and xc_order_type
#- Relationship_Name: SDR, Partner, Region, RegionT2
#- Relationship_Effective_Start and End_Date
#- From_Position: House Account	
#- To_Position: Position Name	

df_Comp_Order_Order_Type = spark.sql(f'''
  
  SELECT 
        ot.NAME ORDER_TYPE_NAME, 
        co.INCENTIVE_DATE,
        co.CUSTOMER_NAME, 
        co.ORDER_CODE,
        co.ITEM_CODE,
        co.Territory, 
        co.BATCH_NAME,
        CASE
          WHEN co.Total_Comm_DLT_Incremental_Consumption IS NULL THEN 0 
          ELSE co.Total_Comm_DLT_Incremental_Consumption
        END AS Total_Comm_DLT_Incremental_Consumption,

        CASE
          WHEN co.Total_Comm_Delta_Incremental_Consumption IS NULL THEN 0 
          ELSE co.Total_Comm_Delta_Incremental_Consumption
        END AS Total_Comm_Delta_Incremental_Consumption,

        CASE
          WHEN co.Total_Comm_ISV_Incremental_Consumption IS NULL THEN 0 
          ELSE co.Total_Comm_ISV_Incremental_Consumption
        END AS Total_Comm_ISV_Incremental_Consumption,

        CASE
          WHEN co.Total_Comm_SQL_Incremental_Consumption IS NULL THEN 0 
          ELSE co.Total_Comm_SQL_Incremental_Consumption
        END AS Total_Comm_SQL_Incremental_Consumption,

        CASE
          WHEN co.Total_Comm_UC_Incremental_Consumption IS NULL THEN 0 
          ELSE co.Total_Comm_UC_Incremental_Consumption
        END AS Total_Comm_UC_Incremental_Consumption,

        CASE 
          WHEN co.Total_Comm_GenAI_Incremental_Consumption IS NULL THEN 0 
          ELSE co.Total_Comm_GenAI_Incremental_Consumption
        END AS Total_Comm_GenAI_Incremental_Consumption,

        CASE
          WHEN co.Total_Comm_GenAI_MCT_Incremental_Consumption IS NULL THEN 0
          ELSE co.Total_Comm_GenAI_MCT_Incremental_Consumption
        END AS Total_Comm_GenAI_MCT_Incremental_Consumption,

        CASE
          WHEN co.Total_Comm_GenAI_NonMCT_Incremental_Consumption IS NULL THEN 0
          ELSE co.Total_Comm_GenAI_NonMCT_Incremental_Consumption
        END AS Total_Comm_GenAI_NonMCT_Incremental_Consumption,

        CASE
          WHEN co.Total_Comm_Incremental_Consumption IS NULL THEN 0 
          ELSE co.Total_Comm_Incremental_Consumption
        END AS Total_Comm_Incremental_Consumption,

        -- FY26 Products 
        CASE
          WHEN co.Total_Comm_LakeflowConnect_Incremental_Consumption IS NULL THEN 0 
          ELSE co.Total_Comm_LakeflowConnect_Incremental_Consumption
        END AS Total_Comm_LakeflowConnect_Incremental_Consumption,

        CASE
          WHEN co.Total_Comm_LakeflowPipeline_Incremental_Consumption IS NULL THEN 0 
          ELSE co.Total_Comm_LakeflowPipeline_Incremental_Consumption
        END AS Total_Comm_LakeflowPipeline_Incremental_Consumption
        
  FROM main.fin_commissions_silver.xc_comp_order_item co
    JOIN main.fin_commissions_silver.xc_order_type ot
      ON co.ORDER_TYPE_ID = ot.ORDER_TYPE_ID

  WHERE co.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_comp_order_item) 
    AND ot.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_order_type)

    AND lower(co.BATCH_NAME) NOT LIKE '%overlay%' AND (co.BATCH_NAME) NOT LIKE '%GSS%' 
    AND ot.NAME = 'Incremental Consumption'
    AND co.Rollup_Flag <> 1
''')

df_Comp_Order_Order_Type.createOrReplaceTempView("Comp_Order_Order_Type")

# COMMAND ----------

# DBTITLE 1,Territory Relationship Analysis Query
df_Comp_Order_Relations = spark.sql(f'''
  
  SELECT DISTINCT 
    rt.TO_POS_ID POSITION_ID,
    rt.TO_POS_NAME POSITION_NAME, 
    rt.FROM_POS_ID HOUSE_ACCOUNT_ID,
    rt.FROM_POS_NAME HOUSE_ACCOUNT_NAME,
    rt.RELATIONSHIP_NAME,    
    rt.PERIOD_START_DATE RELATION_START_DATE,
    rt.PERIOD_END_DATE RELATION_END_DATE,
    --rt.FISCAL_YEAR,
    rt.rnk,
    co.*

  FROM Relations_Rel_Type rt 
  JOIN Comp_Order_Order_Type co
    ON rt.Territory = co.Territory

  WHERE co.INCENTIVE_DATE >= rt.PERIOD_START_DATE AND 
        co.INCENTIVE_DATE <= rt.PERIOD_END_DATE
''')

df_Comp_Order_Relations.createOrReplaceTempView("Comp_Order_Relations")

# COMMAND ----------

# DBTITLE 1,Participant Position Relation Extract
df_CO_Relations_Participant = spark.sql(f''' 
                                   
  SELECT DISTINCT
        pa.PARTICIPANT_ID,
        pa.PARTICIPANT_NAME,
        TRIM(')' FROM SUBSTRING(pa.PARTICIPANT_NAME, INSTR(pa.PARTICIPANT_NAME, '(')+1, LEN(pa.PARTICIPANT_NAME)-INSTR(pa.PARTICIPANT_NAME, '('))) SFDC_ID,
        pr.*,
        p.EFFECTIVE_START_DATE POSITION_START_DATE, 
        p.EFFECTIVE_END_DATE POSITION_END_DATE

  FROM Comp_Order_Relations pr
  LEFT JOIN main.fin_commissions_silver.xc_pos_part_assignment pa 
    ON pr.POSITION_NAME = pa.position_name 
  LEFT JOIN main.fin_commissions_silver.xc_position p 
    ON pa.position_id = p.position_id

  WHERE p.effective_start_date <= date_sub(getdate(), dayofmonth(getdate())) 
    AND p.effective_end_date >= trunc(date_sub(getdate(), dayofmonth(getdate())), 'MM')
    
    AND pa.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_part_assignment) 
    AND p.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_position)
''')

df_CO_Relations_Participant.createOrReplaceTempView("CO_Relations_Participant")

# COMMAND ----------

df_CO_Rel_Part_SFDC = spark.sql(f'''
  
  SELECT rp.*,
         us.username
  FROM CO_Relations_Participant rp 
  LEFT JOIN main.sfdc_bronze.user us
      ON rp.SFDC_ID = us.ID

  WHERE us.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.user)
''')

df_CO_Rel_Part_SFDC.createOrReplaceTempView("CO_Rel_Part_SFDC")

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER,
                            fiscal_half_year as FISCAL_HALF,
                            fy_year as FISCAL_YEAR
                     FROM main.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

# DBTITLE 1,Incentive Period Transformation Pipeline
df_CO_Rel_Part_SFDC = df_CO_Rel_Part_SFDC.withColumn('INCENTIVE_DATE_UPD', to_date(col('INCENTIVE_DATE')))
df_Final = df_CO_Rel_Part_SFDC.join(df_dates, df_CO_Rel_Part_SFDC.INCENTIVE_DATE ==  df_dates.date,"inner")
df_Final = df_Final.withColumn('PERIOD_NAME', date_format(df_Final['INCENTIVE_DATE_UPD'], 'MMM-yyyy'))
df_Final = df_Final.withColumn('PERIOD_NAME', upper(df_Final['PERIOD_NAME']).alias('PERIOD_NAME'))
df_Final = df_Final.drop('date','INCENTIVE_DATE_UPD')

df_Final.createOrReplaceTempView("Pre_Output")

# COMMAND ----------

# DBTITLE 1,Incremental Consumption Uplift Calculation
df_Final = spark.sql('''
SELECT
  *,

  CASE WHEN FISCAL_HALF = 'FY24-H1' THEN Total_Comm_DLT_Incremental_Consumption * 0.25
       WHEN FISCAL_HALF = 'FY24-H2' THEN Total_Comm_DLT_Incremental_Consumption * 0.25
      --  WHEN FISCAL_YEAR IN ('FY25','FY26') THEN 0
    ELSE 0
  END AS Total_Comm_DLT_Incremental_Consumption_Uplift,

  ----------
  
  CASE WHEN FISCAL_HALF = 'FY24-H1' THEN Total_Comm_Delta_Incremental_Consumption * 0.15
    --    WHEN FISCAL_HALF = 'FY24-H2' THEN Total_Comm_Delta_Incremental_Consumption * 0
    --    WHEN FISCAL_YEAR IN ('FY25','FY26') THEN 0
    ELSE 0
  END AS Total_Comm_Delta_Incremental_Consumption_Uplift,

  ----------
  
  CASE WHEN FISCAL_HALF = 'FY24-H1' THEN Total_Comm_SQL_Incremental_Consumption * 0.25
       WHEN FISCAL_HALF = 'FY24-H2' THEN Total_Comm_SQL_Incremental_Consumption * 0.5
       WHEN FISCAL_YEAR = 'FY25' THEN Total_Comm_SQL_Incremental_Consumption * 0.25
    --    WHEN FISCAL_YEAR = 'FY26' THEN 0
    ELSE 0
  END AS Total_Comm_SQL_Incremental_Consumption_Uplift,

  ----------

  CASE 
       WHEN FISCAL_HALF = 'FY24-H2' THEN Total_Comm_UC_Incremental_Consumption * 1
       WHEN FISCAL_YEAR = 'FY25' THEN Total_Comm_UC_Incremental_Consumption * 0.5
    --    WHEN FISCAL_YEAR = 'FY26' THEN 0
    ELSE 0
  END AS Total_Comm_UC_Incremental_Consumption_Uplift,

  -----------

  CASE 
       WHEN FISCAL_HALF = 'FY25-H1' OR FISCAL_MONTH = 'FY25-07' THEN Total_Comm_GenAI_Incremental_Consumption * 0.5
       WHEN FISCAL_YEAR = 'FY26' THEN Total_Comm_GenAI_Incremental_Consumption * 0.25
    ELSE 0
  END AS Total_Comm_GenAI_Incremental_Consumption_Uplift,

  -----------

  CASE 
       WHEN FISCAL_YEAR = 'FY25' THEN Total_Comm_GenAI_MCT_Incremental_Consumption * 0.25
       WHEN FISCAL_YEAR = 'FY26' THEN Total_Comm_GenAI_MCT_Incremental_Consumption
    ELSE 0
  END AS Total_Comm_GenAI_MCT_Incremental_Consumption_Uplift,

  -----------

  CASE 
       WHEN FISCAL_YEAR = 'FY25' THEN Total_Comm_GenAI_NonMCT_Incremental_Consumption * 0.75
    ELSE 0
  END AS Total_Comm_GenAI_NonMCT_Incremental_Consumption_Uplift,

  -----------

  CASE 
       WHEN FISCAL_YEAR = 'FY26' THEN Total_Comm_LakeflowConnect_Incremental_Consumption * 0.25
    ELSE 0
  END AS Total_Comm_LakeflowConnect_Incremental_Consumption_Uplift,

  -----------

  CASE 
       WHEN FISCAL_YEAR = 'FY26' THEN Total_Comm_LakeflowPipeline_Incremental_Consumption * 0.25
    ELSE 0
  END AS Total_Comm_LakeflowPipeline_Incremental_Consumption_Uplift

   
FROM Pre_Output
''')

df_Final.createOrReplaceTempView('Final_Output')

# COMMAND ----------

final_df_territory_extended, process_date = add_audit_attributes(df_Final)
final_df_territory_extended = final_df_territory_extended.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_territory_extended.createOrReplaceTempView("GOLD_TABLE")

# COMMAND ----------

# Distinct fiscal year flowing from data
distinct_DV_values = [row["FISCAL_YEAR"] for row in final_df_territory_extended.select("FISCAL_YEAR").distinct().collect()]
distinct_DV_values

# COMMAND ----------

# DBTITLE 1,Dynamic Fiscal Year Condition Generator
condition = "FISCAL_YEAR IN (" + ", ".join([f"'{value}'" for value in distinct_DV_values]) + ")"
condition

# COMMAND ----------

# staging_full_table_name = f'{target_catalog}.fin_commissions_silver.{staging_tablename}'
# print(f'Updating data in {staging_full_table_name} for {process_date}')

# existing_territory_extended_schema = spark.table(staging_full_table_name).schema
# final_df_territory_extended_updated = final_df_territory_extended.select(*[col(field.name).cast(field.dataType).alias(field.name) for field in existing_territory_extended_schema])

# (final_df_territory_extended_updated.write
#                                     .mode('overwrite')
#                                     .format('delta')
#                                     .option('mergeSchema', 'true')
#                                     .partitionBy('FISCAL_YEAR')
#                                     .option("replaceWhere", condition)
#                                     .saveAsTable(staging_full_table_name)
# )

# COMMAND ----------

staging_full_table_name = f'{target_catalog}.fin_commissions_silver.{staging_tablename}'
print(f'Updating data in {staging_full_table_name} for {process_date}')

# Get the target schema
existing_territory_extended_schema = spark.table(staging_full_table_name).schema
existing_columns = set(field.name for field in existing_territory_extended_schema)

# Create the select list: 
# 1. Cast existing columns
# 2. Add new columns
final_df_territory_extended_updated = final_df_territory_extended.select(
    *[col(field.name).cast(field.dataType).alias(field.name) for field in existing_territory_extended_schema],
    *[col(col_name) for col_name in final_df_territory_extended.columns if col_name not in existing_columns]
)

# Write the DataFrame back with schema merging enabled
(final_df_territory_extended_updated
    .write
    .mode('overwrite')
    .format('delta')
    .option('mergeSchema', 'true')
    .partitionBy('FISCAL_YEAR')
    .option("replaceWhere", condition)
    .saveAsTable(staging_full_table_name)
)

# COMMAND ----------

df_staging_read = spark.sql(f''' SELECT * FROM {target_catalog}.fin_commissions_silver.{staging_tablename} ''')

# COMMAND ----------

# DBTITLE 1,Delta Table Overwrite and Partitioning
full_table_name = f'{target_catalog}.{target_gold_schema}.{target_tablename}'
print(f'Updating data in {full_table_name} for {process_date}')

(df_staging_read.write
                .mode('overwrite')
                .format('delta')
                .option('overwriteSchema', 'true')
                .partitionBy('FISCAL_YEAR')
                .saveAsTable(full_table_name)
)
