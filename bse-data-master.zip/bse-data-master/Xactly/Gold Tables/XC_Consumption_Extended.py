# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import lit, udf
from pyspark.sql.types import StringType
from contextlib import contextmanager
from typing import Iterator
from contextlib import nullcontext
from logging import Logger

# COMMAND ----------

# MAGIC %run "./sales_intelligence_config"

# COMMAND ----------

target_tablename = 'xc_consumption_extended'
snapshot_tablename = 'xc_consumption_extended_history'
staging_tablename = 'xc_consumption_extended_staging'

# COMMAND ----------

def get_fiscal_year():
    current_date = datetime.now()
    current_year = current_date.year
    fiscal_year = current_year if current_date.month >= 3 else current_year - 1
    return f'FY{str(fiscal_year + 1)[-2:]}'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Snapshot Table

# COMMAND ----------

#Extract the data in xc_consumption_extended which contains the latest data

full_raw_table_name_snap = f'{target_catalog}.{target_silver_schema}.{snapshot_tablename}'
df_snap = sql(f''' SELECT * FROM main.{target_gold_schema}.{target_tablename} ''')

# COMMAND ----------

df_snap = df_snap.drop("PROCESS_DATE","PROCESS_USER")

# COMMAND ----------

final_df_snap, processDate = add_audit_attributes(df_snap)
final_df_snap = final_df_snap.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_snap.createOrReplaceTempView("SNAPSHOT_TABLE")

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {processDate}')

(final_df_snap
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Final Table

# COMMAND ----------

df_consumption_extended = spark.sql(f''' 
                                    WITH CTE AS (
                                      SELECT cr.PARTICIPANT_ID,
                                            cr.PARTICIPANT_NAME,
                                            cr.POSITION_ID,
                                            cr.POSITION_NAME,
                                            cr.CUSTOMER_NAME,
                                            TRIM(')' FROM SUBSTRING(cr.PARTICIPANT_NAME, INSTR(cr.PARTICIPANT_NAME, '(')+1, LEN(cr.PARTICIPANT_NAME)-INSTR(cr.PARTICIPANT_NAME, '('))) SFDC_ID,
                                            cr.INCENTIVE_DATE,
                                            cr.PERIOD_NAME MONTH_YEAR,
                                            SUBSTRING(cr.INCENTIVE_DATE, 0, 7) INC_MONTH_YEAR,
                                            cr.AMOUNT,
                                            cr.CREDIT_TYPE_NAME,
                                            cr.ORDER_CODE
                                                  
                                            FROM main.fin_commissions_silver.xc_credit cr

                                            WHERE cr.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_credit)
                                             
                                    ), 
                                    baseIncr AS
                                    (
                                      SELECT PARTICIPANT_ID,
                                             PARTICIPANT_NAME,
                                             POSITION_ID,
                                             POSITION_NAME,
                                             CUSTOMER_NAME,
                                             MONTH_YEAR,
                                             INC_MONTH_YEAR,
                                             ORDER_CODE,
                                             SFDC_ID,
                                             SUM(AMOUNT) BaseIncrementalConsumption
                                      FROM CTE
                                      WHERE CREDIT_TYPE_NAME = 'Base Incremental Consumption'     
                                      GROUP BY PARTICIPANT_ID,
                                                PARTICIPANT_NAME,
                                                POSITION_ID,
                                                SFDC_ID,
                                                POSITION_NAME,
                                                CUSTOMER_NAME,
                                                ORDER_CODE,
                                                MONTH_YEAR,
                                                INC_MONTH_YEAR
                                    ),
                                    commIncr AS
                                    (
                                      SELECT PARTICIPANT_ID,
                                             PARTICIPANT_NAME,
                                             POSITION_ID,
                                             POSITION_NAME,
                                             CUSTOMER_NAME,
                                             SFDC_ID,
                                             ORDER_CODE,
                                             INC_MONTH_YEAR,
                                             MONTH_YEAR,
                                             SUM(AMOUNT) CommIncrementalConsumption
                                      FROM CTE
                                      WHERE CREDIT_TYPE_NAME = 'Commissionable Incremental Consumption'     
                                      GROUP BY PARTICIPANT_ID,
                                                PARTICIPANT_NAME,
                                                POSITION_ID,
                                                SFDC_ID,
                                                ORDER_CODE,
                                                POSITION_NAME,
                                                CUSTOMER_NAME,
                                                MONTH_YEAR,
                                                INC_MONTH_YEAR
                                    )

                                    SELECT DISTINCT
                                           BI.PARTICIPANT_ID,
                                           BI.PARTICIPANT_NAME,
                                           BI.POSITION_ID,
                                           BI.POSITION_NAME,
                                           BI.CUSTOMER_NAME,
                                           BI.MONTH_YEAR,
                                           BI.SFDC_ID,
                                           BI.BaseIncrementalConsumption,
                                           CI.CommIncrementalConsumption, 
                                           ic.AccountBaseline, 
                                           ic.AccountConsumption as TotalConsumption, 
                                           us.username,
                                           xp.FISCAL_WEEK,
                                           xp.FISCAL_MONTH,
                                           xp.FISCAL_QUARTER,
                                           xp.FISCAL_HALF_YEAR,
                                           xp.FISCAL_YEAR,
                                           xp.DATE PERIOD_DATE 

                                    FROM main.it_consumption_silver.incremental_consumption_ae ic 

                                      JOIN baseIncr BI
                                        ON ic.AEId = BI.SFDC_ID 
                                          AND ic.AccountId = BI.ORDER_CODE 
                                          AND SUBSTRING(ic.month_end_date,0,7) = BI.INC_MONTH_YEAR

                                      JOIN commIncr CI
                                        ON ic.AEId = CI.SFDC_ID 
                                          AND ic.AccountId = CI.ORDER_CODE 
                                          AND SUBSTRING(ic.month_end_date,0,7) = CI.INC_MONTH_YEAR

                                      JOIN main.sfdc_bronze.user us
                                        ON BI.SFDC_ID = us.ID

                                      JOIN main.fin_commissions_silver.xc_period xp
                                        ON BI.MONTH_YEAR = xp.NAME and CI.MONTH_YEAR = xp.NAME

                                    WHERE us.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.user)
                                      AND xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_period)
                                    ''')

df_consumption_extended.createOrReplaceTempView('consumption_extended')

# COMMAND ----------

df_updated = spark.sql(f''' 
                       WITH CTE AS (
                          SELECT DISTINCT pa.POSITION_NAME, 
                                          p.EFFECTIVE_START_DATE, 
                                          p.EFFECTIVE_END_DATE

                          FROM main.fin_commissions_silver.xc_pos_part_assignment pa
                          LEFT JOIN main.fin_commissions_silver.xc_position p 
                            ON pa.position_id = p.position_id

                          WHERE pa.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_part_assignment) AND
                                p.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_position) 
                        ),

                        CTE2 AS (
                        SELECT DISTINCT ce.*, ct.EFFECTIVE_START_DATE, ct.EFFECTIVE_END_DATE
                        FROM consumption_extended ce 
                          LEFT JOIN CTE ct
                            ON (
                                  ce.POSITION_NAME = ct.POSITION_NAME 
                                  AND ce.PERIOD_DATE >= ct.EFFECTIVE_START_DATE 
                                  AND ce.PERIOD_DATE <= ct.EFFECTIVE_END_DATE
                                )
                        )
                        
                          SELECT DISTINCT ct.* 
                          FROM CTE2 ct 
                          JOIN main.fin_commissions_silver.xc_period xp
                            ON ct.PERIOD_DATE = xp.START_DATE

                          WHERE (SUBSTRING(xp.START_DATE, 0, 7) = substring(xp.END_DATE, 0, 7)) AND
                                xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_period)
                       
                       ''')

df_updated.createOrReplaceTempView('df_updated')

# COMMAND ----------

final_df_consumption_extended, process_date = add_audit_attributes(df_updated)
final_df_consumption_extended = final_df_consumption_extended.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_consumption_extended.createOrReplaceTempView("GOLD_TABLE")

# COMMAND ----------

# Distinct fiscal year flowing from data
distinct_DV_values = [row["FISCAL_YEAR"] for row in final_df_consumption_extended.select("FISCAL_YEAR").distinct().collect()]
distinct_DV_values

# COMMAND ----------

condition = "FISCAL_YEAR IN (" + ", ".join([f"'{value}'" for value in distinct_DV_values]) + ")"
condition

# COMMAND ----------

staging_full_table_name = f'{target_catalog}.fin_commissions_silver.{staging_tablename}'
print (f'Updating data in {staging_full_table_name} for {process_date}')

(final_df_consumption_extended.write
                              .mode('overwrite')
                              .format('delta')
                              .option('mergeSchema', 'true')
                              .partitionBy('FISCAL_YEAR')
                              .option("replaceWhere", condition)
                              .saveAsTable(staging_full_table_name)
)

# COMMAND ----------

df_staging_read = spark.sql(f''' SELECT * FROM {target_catalog}.fin_commissions_silver.{staging_tablename} ''')

# COMMAND ----------

full_table_name = f'{target_catalog}.{target_gold_schema}.{target_tablename}'
print (f'Updating data in {full_table_name} for {process_date}')

(df_staging_read.write
                .mode('overwrite')
                .format('delta')
                .option('overwriteSchema', 'true')
                .partitionBy('FISCAL_YEAR')
                .saveAsTable(full_table_name)
)
