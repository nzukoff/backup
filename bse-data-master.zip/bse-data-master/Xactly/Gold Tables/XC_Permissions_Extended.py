# Databricks notebook source
# MAGIC %run "./sales_intelligence_config"

# COMMAND ----------

target_tablename = 'xc_permissions_extended'
snapshot_tablename = 'xc_permissions_extended_history'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Snapshot Table

# COMMAND ----------

#Extract the data in xc_permissions_extended which contains the latest data

full_raw_table_name_snap = f'{target_catalog}.{target_silver_schema}.{snapshot_tablename}'
df_snap = sql(f''' SELECT * FROM {target_catalog}.{target_gold_schema}.{target_tablename} ''')

# COMMAND ----------

df_snap = df_snap.drop("PROCESS_DATE","PROCESS_USER")

# COMMAND ----------

final_df_snap, processDate = add_audit_attributes(df_snap)
final_df_snap = final_df_snap.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_snap.createOrReplaceTempView("SNAPSHOT_TABLE")

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {processDate}')

(final_df_snap
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold Final Table

# COMMAND ----------

df_permissions = spark.sql(f''' 
                           select
                                cpq_manager_hierarchy.AEId,
                                cpq_manager_hierarchy.AEName,
                                cpq_manager_hierarchy.M1Name,
                                cpq_manager_hierarchy.M2Name,
                                cpq_manager_hierarchy.M3Name,
                                cpq_manager_hierarchy.M4Name,
                                cpq_manager_hierarchy.M5Name,
                                cpq_manager_hierarchy.CROMinus1Name,
                                cpq_manager_hierarchy.CROMinus2Name,
                                cpq_manager_hierarchy.CROMinus3Name,
                                ae.Username_Ae,
                                M1.Username_M1,
                                M2.Username_M2,
                                M3.Username_M3,
                                M4.Username_M4,
                                M5.Username_M5,
                                regexp_replace(concat(
                                  Username_Ae,
                                  ",",
                                  Username_M1,
                                  ",",
                                  Username_M2,
                                  ",",
                                  Username_M3,
                                  ",",
                                  Username_M4,
                                  ",",
                                  Username_M5
                                ),"@databricks.com","") permitted_user_names,
                                "1" view_all_users_join_key
                              FROM
                                main.it_cpq_silver.cpq_manager_hierarchy
                                inner join (
                                  select
                                    Id,
                                    Name,
                                    Username Username_Ae
                                  from
                                    main.sfdc_bronze.user
                                  where
                                    processDate = (
                                      select
                                        max(processDate)
                                      from
                                       main.sfdc_bronze.user
                                    )
                                ) ae on aeid = ae.id
                                inner join (
                                  select
                                    Id,
                                    Name,
                                    Username Username_M1
                                  from
                                    main.sfdc_bronze.user
                                  where
                                    processDate = (
                                      select
                                        max(processDate)
                                      from
                                        main.sfdc_bronze.user
                                    )
                                ) M1 on M1id = M1.id
                                inner join (
                                  select
                                    Id,
                                    Name,
                                    Username Username_M2
                                  from
                                    main.sfdc_bronze.user
                                  where
                                    processDate = (
                                      select
                                        max(processDate)
                                      from
                                        main.sfdc_bronze.user
                                    )
                                ) M2 on M2id = M2.id
                                inner join (
                                  select
                                    Id,
                                    Name,
                                    Username Username_M3
                                  from
                                    main.sfdc_bronze.user
                                  where
                                    processDate = (
                                      select
                                        max(processDate)
                                      from
                                        main.sfdc_bronze.user
                                    )
                                ) M3 on M3id = M3.id
                                inner join (
                                  select
                                    Id,
                                    Name,
                                    Username Username_M4
                                  from
                                    main.sfdc_bronze.user
                                  where
                                    processDate = (
                                      select
                                        max(processDate)
                                      from
                                        main.sfdc_bronze.user
                                    )
                                ) M4 on M4id = M4.id
                                inner join (
                                  select
                                    Id,
                                    Name,
                                    Username Username_M5
                                  from
                                    main.sfdc_bronze.user
                                  where
                                    processDate = (
                                      select
                                        max(processDate)
                                      from
                                        main.sfdc_bronze.user
                                    )
                                ) M5 on M5id = M5.id
                           ''')

df_permissions.createOrReplaceTempView('permissions_extended')

# COMMAND ----------

final_df_permissions, process_date = add_audit_attributes(df_permissions)
final_df_permissions = final_df_permissions.withColumn('FISCAL_YEAR', lit('FY24'))
final_df_permissions_extended = final_df_permissions.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_permissions_extended.createOrReplaceTempView("GOLD_TABLE")

# COMMAND ----------

full_table_name = f'{target_catalog}.{target_gold_schema}.{target_tablename}'

(final_df_permissions_extended
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .saveAsTable(full_table_name))

# COMMAND ----------


