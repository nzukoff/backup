# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import lit, udf
from pyspark.sql.types import StringType
from contextlib import contextmanager
from typing import Iterator
from contextlib import nullcontext
from logging import Logger

# COMMAND ----------

# MAGIC %run "./sales_intelligence_config"

# COMMAND ----------

target_tablename = 'xc_quota_assignment_extended'
snapshot_tablename = 'xc_quota_assignment_extended_history'
staging_tablename = 'xc_quota_assignment_extended_staging'

# COMMAND ----------

def get_fiscal_year(date_str):
    date = datetime.strptime(date_str, '%Y-%m-%d')
    fiscal_year = date.year if date.month >= 2 else date.year - 1
    fiscal_year += 1
    return f"FY{str(fiscal_year)[-2:]}"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Snapshot Table

# COMMAND ----------

#Extract the data in xc_quota_assignment_extended which contains the latest data

full_raw_table_name_snap = f'{target_catalog}.{target_silver_schema}.{snapshot_tablename}'
df_snap = sql(f''' SELECT * FROM main.{target_gold_schema}.{target_tablename} ''')

# COMMAND ----------

df_snap = df_snap.drop("PROCESS_DATE","PROCESS_USER")

# COMMAND ----------

final_df_snap, processDate = add_audit_attributes(df_snap)
final_df_snap = final_df_snap.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_snap.createOrReplaceTempView("SNAPSHOT_TABLE")

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {processDate}')

(final_df_snap
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Final Table

# COMMAND ----------

df_quota_assignment_extended = spark.sql(f'''
              WITH CTE AS (
                  SELECT
                    pp.position_id,
                    pp.position_name,
                    pp.participant_name,
                    TRIM(')' FROM SUBSTRING(pp.PARTICIPANT_NAME, INSTR(pp.PARTICIPANT_NAME, '(')+1, LEN(pp.PARTICIPANT_NAME)-INSTR(pp.PARTICIPANT_NAME, '('))) SFDC_ID,
                    q.name,
                    q.classification_name,
                    q.classification_type,
                    qa.assignment_type,
                    qa.assignment_name,
                    pta.title_name,
                    p.start_date,
                    pr.end_date,
                    qa.description,
                    q.quota_value_unit_type_name,
                    q.quota_period_name,
                    qa.amount,
                    --qa.annual_prorated_oti,
                    'N/A' as annual_prorated_oti,
                    qa.annual_prorated_oti_unit_type_id,
                    qa.duration,
                    --qa.effective_oti,
                    'N/A' as effective_oti, 
                    qa.effective_oti_unit_type_id,
                    --qa.h_one_prorated_oti,
                    'N/A' as h_one_prorated_oti,
                    qa.h_one_prorated_oti_unit_type_id,
                    'N/A' as h_two_prorated_oti,
                    --qa.h_two_prorated_oti,
                    qa.h_two_prorated_oti_unit_type_id,
                    qa.oti_weight,
                    qa.oti_weight_unit_type_id,
                    qa.payout_frequency,
                    case when qa.ASSIGNMENT_TYPE = '2.0' then 'Position'
                        when qa.ASSIGNMENT_TYPE = '1.0' then 'Title'
                        when qa.ASSIGNMENT_TYPE = '0.0' then 'Plan' end as assignment_type_name

                    FROM main.fin_commissions_silver.xc_quota_assignment qa

                    JOIN main.fin_commissions_silver.xc_period p 
                      ON qa.effective_start_period_id = p.period_id

                    JOIN main.fin_commissions_silver.xc_period pr 
                      ON qa.effective_end_period_id = pr.period_id

                    JOIN main.fin_commissions_silver.xc_quota q 
                      ON qa.quota_id = q.quota_id

                    JOIN main.fin_commissions_silver.latest_pos_part_mapping pp
                        ON qa.assignment_name = pp.POSITION_NAME 

                    JOIN main.fin_commissions_silver.xc_pos_title_assignment pta   
                      ON pp.position_id = pta.position_id
                      
                    WHERE qa.amount != 0
                    AND (DATE(p.start_date)>'2023-02-01')

                    AND qa.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_quota_assignment)
                    AND p.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_period  )
                    AND pr.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_period  )
                    AND q.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_quota  )
                    AND pp.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.latest_pos_part_mapping)  
                    AND pta.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_pos_title_assignment ) 

                    AND q.name IN (
                                  'Count New Logo Commit',
                                  'Tier 2 Commissionable Incremental Consumption',   
                                  'Commissionable Incremental Consumption',
                                  'Total Commit',
                                  'Partner Base Commissionable Incremental Consumption',
                                  'Partner New Total Commit',
                                  'Count New Customer Consumption',
                                  'Activated Customer Count Consumption',
                                  'U2 Opportunities',
                                  'Product Consumption',
                                  'Tier 2 Product Consumption',
                                  'Product Consumption DBSQL',
                                  'Product Consumption GenAI',
                                  'Product Consumption UC',
                                  'Technical Certified Individuals',
                                  'Activated Logo',
                                  'Activated Logo DB4K')
              )

              SELECT DISTINCT ct.*, 
                              us.username
              FROM CTE ct 
              JOIN main.sfdc_bronze.user us
                ON ct.SFDC_ID = us.ID
              WHERE us.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.user)
                                        
                                         ''')

# COMMAND ----------

fiscal_year_udf = udf(get_fiscal_year, StringType())

df_quota_assignment_extended = df_quota_assignment_extended.withColumn("FISCAL_YEAR", fiscal_year_udf(df_quota_assignment_extended["start_date"]))
df_quota_assignment_extended.createOrReplaceTempView('quota_assignment_extended')

# COMMAND ----------

final_df_quota_assignment_extended, process_date = add_audit_attributes(df_quota_assignment_extended)
final_df_quota_assignment_extended = final_df_quota_assignment_extended.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_quota_assignment_extended.createOrReplaceTempView("GOLD_TABLE")

# COMMAND ----------

# Distinct fiscal year flowing from data
distinct_DV_values = [row["FISCAL_YEAR"] for row in final_df_quota_assignment_extended.select("FISCAL_YEAR").distinct().collect()]
distinct_DV_values

# COMMAND ----------

condition = "FISCAL_YEAR IN (" + ", ".join([f"'{value}'" for value in distinct_DV_values]) + ")"
condition

# COMMAND ----------

staging_full_table_name = f'{target_catalog}.fin_commissions_silver.{staging_tablename}'
print(f'Updating data in {staging_full_table_name} for {process_date}')

(final_df_quota_assignment_extended.write
                                   .mode('overwrite')
                                   .format('delta')
                                   .option('mergeSchema', 'true')
                                   .partitionBy('FISCAL_YEAR')
                                   .option("replaceWhere", condition)
                                   .saveAsTable(staging_full_table_name)
)

# COMMAND ----------

df_staging_read = spark.sql(f''' SELECT * FROM {target_catalog}.fin_commissions_silver.{staging_tablename} ''')

# COMMAND ----------

full_table_name = f'{target_catalog}.{target_gold_schema}.{target_tablename}'
print(f'Updating data in {full_table_name} for {process_date}')

(df_staging_read.write
                .mode('overwrite')
                .format('delta')
                .option('overwriteSchema', 'true')
                .partitionBy('FISCAL_YEAR')
                .saveAsTable(full_table_name)
)
