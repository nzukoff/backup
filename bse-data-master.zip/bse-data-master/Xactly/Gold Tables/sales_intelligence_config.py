# Databricks notebook source
from typing import Callable, Optional, Sequence
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit
from datetime import datetime, date
from dataclasses import dataclass, field

# COMMAND ----------

from dataclasses import dataclass

@dataclass(frozen=True)
class defineconfig:
  name: str
  target_catalog: str
  target_bronze_schema: str
  target_silver_schema: str
  target_gold_schema: str
  process_date_column: str

# COMMAND ----------

dbutils.widgets.text("environment", 'prod')
ENV = dbutils.widgets.get("environment")

# COMMAND ----------

ri_config =  { 
'prod' : {
  'name' : 'Production',
  'target_catalog': 'main',
  'target_bronze_schema': 'fin_commissions_bronze',
  'target_silver_schema': 'fin_commissions_silver',
  'target_gold_schema': 'fin_commissions_gold',
  'process_date_column': 'processDate'
} ,

'dev' : {
  'name' : 'Dev',
  'target_catalog': 'integration',
  'target_bronze_schema': 'fin_commissions_bronze',
  'target_silver_schema': 'fin_commissions_silver',
  'target_gold_schema': 'fin_commissions_gold',
  'process_date_column': 'processDate'
} }

# COMMAND ----------

try:
  setconfig = defineconfig(
                        ri_config[ENV]['name'],
                        ri_config[ENV]['target_catalog'],
                        ri_config[ENV]['target_bronze_schema'],
                        ri_config[ENV]['target_silver_schema'],
                        ri_config[ENV]['target_gold_schema'],
                        ri_config[ENV]['process_date_column']
                      )
except Exception:
  raise Exception(f'Configurations are not defined for {ENV}')

# COMMAND ----------

target_catalog = setconfig.target_catalog
target_bronze_schema = setconfig.target_bronze_schema
target_silver_schema = setconfig.target_silver_schema
target_gold_schema = setconfig.target_gold_schema
metadata_process_date_column= setconfig.process_date_column

# COMMAND ----------

from datetime import datetime, timedelta
def add_audit_attributes(df ):
  """
  Add process date and current user

  """
  now = datetime.utcnow().date()
  
  df2 = (df
    .withColumn(metadata_process_date_column, lit(now))
    )
  
  return (df2, now)

# COMMAND ----------

def df_column_whitespace(df) :
  new_column_name_list= list(map(lambda x: x.replace(" ", "_").replace(":","").replace(" ","").replace("(","").replace(")","").replace("$","dollar"), df.columns))
  renamed_df = df.toDF(*new_column_name_list)
  return renamed_df

# COMMAND ----------


