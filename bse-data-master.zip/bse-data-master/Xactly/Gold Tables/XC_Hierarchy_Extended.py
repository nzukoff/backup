# Databricks notebook source
from pyspark.sql.functions import substring, length, col, concat_ws, regexp_replace, expr
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
from datetime import datetime

# COMMAND ----------

# MAGIC %run "./sales_intelligence_config"

# COMMAND ----------

target_tablename = 'xc_hierarchy_extended'
snapshot_tablename = 'xc_hierarchy_extended_history'

# COMMAND ----------

# MAGIC %md
# MAGIC #### Snapshot Table

# COMMAND ----------

#Extract the data in xc_hierarchy_extended which contains the latest data

full_raw_table_name_snap = f'{target_catalog}.{target_silver_schema}.{snapshot_tablename}'
df_snap = sql(f''' SELECT * FROM {target_catalog}.{target_gold_schema}.{target_tablename} ''')

# COMMAND ----------

df_snap = df_snap.drop("PROCESS_DATE","PROCESS_USER")

# COMMAND ----------

final_df_snap, processDate = add_audit_attributes(df_snap)
final_df_snap = final_df_snap.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_snap.createOrReplaceTempView("SNAPSHOT_TABLE")

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {processDate}')

(final_df_snap
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Final Table

# COMMAND ----------

Reporter_Reportee = spark.sql(f'''
      WITH CTE AS 
      (
        SELECT DISTINCT
        ph.TO_POS_ID AEId, 
        ph.TO_POS_NAME AEName,
        ph.FROM_POS_ID M1Id, 
        ph.FROM_POS_NAME M1Name,
        MIN(pht.EFFECTIVE_START_DATE) EFFECTIVE_START_DATE,
        MAX(pht.EFFECTIVE_END_DATE) EFFECTIVE_END_DATE
        
      FROM {target_catalog}.fin_commissions_silver.xc_pos_hierarchy ph 
        JOIN {target_catalog}.fin_commissions_silver.xc_pos_hierarchy_type pht
          ON ph.POS_HIERARCHY_TYPE_ID = pht.POS_HIERARCHY_TYPE_ID

      WHERE 
          ph.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_pos_hierarchy)
      AND pht.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_pos_hierarchy_type)

      GROUP BY ph.TO_POS_ID, ph.TO_POS_NAME, ph.FROM_POS_ID, ph.FROM_POS_NAME
    ),

    ranked_cte AS (
      SELECT *, 
          RANK() OVER (PARTITION BY AEId ORDER BY EFFECTIVE_START_DATE DESC) rnk
      FROM CTE
    ),

    latest_hierarchy AS (
    SELECT 
          AEId,
          AEName, 
          M1Id,
          M1Name,
          EFFECTIVE_START_DATE, 
          EFFECTIVE_END_DATE
    FROM ranked_cte
    WHERE rnk=1
    )

    SELECT *
    FROM CTE
    WHERE current_date()<=to_date(EFFECTIVE_END_DATE)
    '''
    )

Reporter_Reportee.createOrReplaceTempView("latest_mapping")

# COMMAND ----------

df_AE_SFDC = spark.sql(f'''
  WITH CTE AS (
    SELECT 
       TRIM(')' FROM SUBSTRING(pa.PARTICIPANT_NAME, INSTR(pa.PARTICIPANT_NAME, '(')+1, LEN(pa.PARTICIPANT_NAME)-INSTR(pa.PARTICIPANT_NAME, '('))) AEId,
       pa.participant_name AEName,
       lm.AEId AE_PosId,
       lm.AEName as AE_PosName,
       
       lm.M1Id as M1_PosId,
       lm.M1Name as M1_PosName,
      
       pa.POSITION_ID,
       pa.POSITION_START_DATE EFFECTIVE_START_DATE,
       pa.POSITION_END_DATE EFFECTIVE_END_DATE
       
  FROM latest_mapping lm
  LEFT JOIN {target_catalog}.fin_commissions_silver.latest_pos_part_mapping pa 
    ON lm.AEName = pa.position_name 

  WHERE 
      pa.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.latest_pos_part_mapping)

  AND pa.POSITION_START_DATE <= date_add(getdate(), dayofmonth(last_day(getdate())) - dayofmonth(getdate())) 
  AND pa.POSITION_END_DATE >= trunc(getdate(), 'MM')
  )
  
  SELECT DISTINCT
        AEId,
        AEName,
        us.username as Username_Ae,
        AE_PosId,
        AE_PosName,
        M1_PosId,
        M1_PosName,

        POSITION_ID,
        EFFECTIVE_START_DATE,
        EFFECTIVE_END_DATE

  FROM CTE ct 
    LEFT JOIN main.sfdc_bronze.user us
        ON ct.AEId = us.ID
  WHERE us.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.user)

''')

df_AE_SFDC.createOrReplaceTempView('AE_SFDC')

# COMMAND ----------

df_Mgr_SFDC = spark.sql(f'''
 WITH CTE AS (
  SELECT 
    ae.AEId,
    ae.AEName,
    ae.Username_Ae,
    ae.AE_PosId,
    ae.AE_PosName,

    TRIM(')' FROM SUBSTRING(pa.PARTICIPANT_NAME, INSTR(pa.PARTICIPANT_NAME, '(')+1, LEN(pa.PARTICIPANT_NAME)-INSTR(pa.PARTICIPANT_NAME, '('))) M1Id,
    pa.participant_name M1Name,
    CASE
      WHEN pa.participant_name IS NULL THEN NULL
          ELSE ae.M1_PosId
    END AS M1_PosId, 
    CASE
      WHEN pa.participant_name IS NULL THEN NULL
          ELSE ae.M1_PosName
    END AS M1_PosName,
    pa.POSITION_START_DATE EFFECTIVE_START_DATE,
    CASE 
        WHEN ae.M1_PosName LIKE 'Databricks_LLC%' THEN getdate()
        ELSE pa.POSITION_END_DATE 
    END AS EFFECTIVE_END_DATE

  FROM AE_SFDC ae
  LEFT JOIN main.fin_commissions_silver.latest_pos_part_mapping pa 
  ON ae.M1_PosName = pa.position_name 
  and pa.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.latest_pos_part_mapping)
),

CTE1 AS (
  
  SELECT DISTINCT
    ct.AEId,
    ct.AEName,
    ct.Username_Ae,
    ct.AE_PosId,
    ct.AE_PosName,

    ct.M1Id,
    ct.M1Name,
    CASE 
      WHEN ct.M1_PosName LIKE 'Databricks_LLC%' THEN 'Databricks_LLC'
      ELSE us.username
    END AS Username_M1,
    ct.M1_PosId, 
    ct.M1_PosName,
    EFFECTIVE_START_DATE,
    EFFECTIVE_END_DATE,
    CASE 
      WHEN ct.M1_PosName LIKE 'Databricks_LLC%' THEN (SELECT MAX(processDate) FROM main.sfdc_bronze.user)
      ELSE us.processDate
    END AS user_process_date

  FROM CTE ct 
    LEFT JOIN main.sfdc_bronze.user us
        ON ct.M1Id = us.ID
        AND us.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.user)

  )

  SELECT *
  FROM CTE1

''')

df_Mgr_SFDC.createOrReplaceTempView('MGR_SFDC')

# COMMAND ----------

df_hierarchy_data = df_Mgr_SFDC.select('AEId', 'AEName', 'Username_Ae', 'EFFECTIVE_START_DATE', 'M1Id', 'Username_M1').distinct()

df_mapping = (
              df_hierarchy_data.withColumnRenamed('M1Id', 'MgrId')
                               .withColumnRenamed('Username_M1', 'Username_Mgr')
             )

df_mapping_base_level = (
                            df_mapping.withColumnRenamed('AEId', 'M0Id')
                                      .withColumnRenamed('AEName', 'M0Name')
                                      .withColumnRenamed('Username_Ae', 'Username_M0')
                                      .withColumnRenamed('EFFECTIVE_START_DATE', 'EFFECTIVE_START_DATE_A1')
                                      .withColumnRenamed('MgrId', 'M1Id')
                                      .withColumnRenamed('Username_Mgr', 'Username_M1')
                        )

i = 1

while True:
  this_level_Id = 'M{}Id'.format(i)
  this_level_Name = 'M{}Name'.format(i)
  this_level_SFDC = 'Username_M{}'.format(i)

  next_level_Id = 'M{}Id'.format(i+1)
  next_level_Name = 'M{}Name'.format(i+1)
  next_level_SFDC = 'Username_M{}'.format(i+1)
  next_level_EFF_DATE = 'EFFECTIVE_START_DATE_A{}'.format(i+1)

  next_hierarchy_level = (
                      df_mapping.withColumnRenamed('AEId', this_level_Id)
                                .withColumnRenamed('AEName', this_level_Name)
                                .withColumnRenamed('MgrId',next_level_Id)
                                .withColumnRenamed('MgrName', next_level_Name)
                                .withColumnRenamed('Username_Mgr',next_level_SFDC)
                                .withColumnRenamed('EFFECTIVE_START_DATE', next_level_EFF_DATE)
                    )

  df_mapping_base_level = df_mapping_base_level.drop(col('Username_Ae')) 
  df_mapping_base_level = df_mapping_base_level.join(next_hierarchy_level, on=this_level_Id, how='left')
  df_mapping_base_level = df_mapping_base_level.drop(col(this_level_Id)).drop(col('Username_Ae')).drop(col(next_level_EFF_DATE))

  if df_mapping_base_level.where(col(next_level_Id).isNotNull()).count() == 0:
    break
  else:
    i += 1

df_mapping_base_level = df_mapping_base_level.drop(col(next_level_Id))
df_mapping_base_level = (
                  df_mapping_base_level.withColumnRenamed('M0Id','AEId')
                                      .withColumnRenamed('M0Name', 'AEName')
                                      .withColumnRenamed('Username_M0','Username_Ae')
                                      .withColumnRenamed('EFFECTIVE_START_DATE_A1', 'Ae_Effective_Start_Date')
)

df_mapping_base_level = df_mapping_base_level.drop('Ae_Effective_Start_Date')
df_mapping_base_level.createOrReplaceTempView('hierarchy_data')

# COMMAND ----------

df_mapping_base_level_start_date = spark.sql('''
    SELECT hier.*,
          AESF.EFFECTIVE_START_DATE as Ae_Effective_Start_Date
    FROM hierarchy_data hier
      JOIN AE_SFDC AESF
        ON hier.AEId = AESF.AEId                                          
''')
df_mapping_base_level_start_date.createOrReplaceTempView('df_mapping_base_level_start_date')

# COMMAND ----------

def get_fiscal_year(date_str):
    date = datetime.strptime(date_str, '%Y-%m-%d')
    fiscal_year = date.year if date.month >= 2 else date.year - 1
    fiscal_year += 1
    return f"FY{str(fiscal_year)[-2:]}"

# COMMAND ----------

def get_dashboard_visibility_year():
    current_date = datetime.now()
    current_year = current_date.year
    dashboard_visibility = current_year if current_date.month >= 3 else current_year - 1
    return f'FY{str(dashboard_visibility + 1)[-2:]}'

# COMMAND ----------

fiscal_year_udf = udf(get_fiscal_year, StringType())
df_mapping_base_level_start_date = df_mapping_base_level_start_date.withColumn("FISCAL_YEAR", fiscal_year_udf(df_mapping_base_level_start_date["Ae_Effective_Start_Date"]))

get_dashboard_visibility_udf = udf(get_dashboard_visibility_year, StringType())
df_mapping_base_level_start_date = df_mapping_base_level_start_date.withColumn("DASHBOARD_VISIBILITY", lit(get_dashboard_visibility_udf()))

df_mapping_base_level_start_date.createOrReplaceTempView('Hierarchy')

# COMMAND ----------

prefix = 'Username'
columns_to_concat = [col for col in df_mapping_base_level_start_date.columns if col.startswith(prefix)]

# Step 1: Concatenate all email addresses into a single column
df_final_output = df_mapping_base_level_start_date.withColumn(
    'temp_permitted_usernames',
    concat_ws(', ', *[col(c) for c in columns_to_concat])
)

# Step 2: Remove "@databricks.com" and "Databricks_LLC" from the concatenated column
df_final_output = df_final_output.withColumn(
    'permitted_user_names',
    regexp_replace(regexp_replace(col("temp_permitted_usernames"), "@databricks.com", ""), "Databricks_LLC", "")
)

df_final_output = df_final_output.drop("temp_permitted_usernames")

df_final_output.createOrReplaceTempView('Final_Hierarchy')

# COMMAND ----------

### TEMPORARY FIX
from pyspark.sql.functions import lit
from pyspark.sql.types import StringType

df_final_output = df_final_output.withColumn('M9Name', lit(None).cast(StringType())).withColumn('Username_M10',lit(None).cast(StringType())).withColumn('M10Name',lit(None).cast(StringType()))

df_final_output.createOrReplaceTempView("df_pre_title")

# COMMAND ----------

df_hierarchy_title = spark.sql(f'''     
        SELECT 
                fh.*,
                pt.TITLE_NAME as AE_Title,
                tg.`group` as AE_Title_Group
        
        FROM df_pre_title fh
          LEFT JOIN {target_catalog}.fin_commissions_silver.latest_pos_part_mapping pp
            ON fh.AEName = pp.PARTICIPANT_NAME
            
          LEFT JOIN {target_catalog}.fin_commissions_silver.xc_pos_title_assignment pt
            ON pp.POSITION_ID = pt.POSITION_ID
            AND pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_pos_title_assignment)
            
          LEFT JOIN {target_catalog}.fin_commissions_silver.Title_Group_Map tg
            ON pt.TITLE_NAME = tg.distinct_title
            AND tg.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.Title_Group_Map) 

        WHERE pp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.latest_pos_part_mapping) 
        AND (
              pp.POSITION_START_DATE <= date_add(getdate(), dayofmonth(last_day(getdate())) - dayofmonth(getdate())) 
          AND pp.POSITION_END_DATE >= trunc(getdate(), 'MM')
        )
        ''')

df_hierarchy_title.createOrReplaceTempView("df_hierarchy_title")

# COMMAND ----------

final_df_hierarchy_extended, process_date = add_audit_attributes(df_hierarchy_title)
final_df_hierarchy_extended = final_df_hierarchy_extended.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_hierarchy_extended.createOrReplaceTempView("GOLD_TABLE")

# COMMAND ----------

# Distinct dashboard_visibility flowing from data
distinct_DV_values = [row["DASHBOARD_VISIBILITY"] for row in final_df_hierarchy_extended.select("DASHBOARD_VISIBILITY").distinct().collect()]
distinct_DV_values

# COMMAND ----------

condition = "DASHBOARD_VISIBILITY IN (" + ", ".join([f"'{value}'" for value in distinct_DV_values]) + ")"
condition

# COMMAND ----------

full_table_name = f'{target_catalog}.{target_gold_schema}.{target_tablename}'
print (f'Updating data in {full_table_name} for {process_date}')

(final_df_hierarchy_extended
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .partitionBy('DASHBOARD_VISIBILITY')
  .option("replaceWhere", condition)
  .saveAsTable(full_table_name))
  

# COMMAND ----------


