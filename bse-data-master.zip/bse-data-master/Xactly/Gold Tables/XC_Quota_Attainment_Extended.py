# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import lit, udf
from pyspark.sql.types import StringType
from contextlib import contextmanager
from typing import Iterator
from contextlib import nullcontext
from logging import Logger

# COMMAND ----------

# MAGIC %run "./sales_intelligence_config"

# COMMAND ----------

target_tablename = 'xc_quota_attainment_extended'
snapshot_tablename = 'xc_quota_attainment_extended_history'
staging_tablename = 'xc_quota_attainment_extended_staging'

# COMMAND ----------

def get_fiscal_year():
    current_date = datetime.now()
    current_year = current_date.year
    fiscal_year = current_year if current_date.month >= 3 else current_year - 1
    return f'FY{str(fiscal_year + 1)[-2:]}'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Snapshot Table

# COMMAND ----------

#Extract the data in xc_quota_attainment_extended which contains the latest data

full_raw_table_name_snap = f'{target_catalog}.{target_silver_schema}.{snapshot_tablename}'
df_snap = sql(f''' SELECT * FROM main.{target_gold_schema}.{target_tablename} ''')

# COMMAND ----------

df_snap = df_snap.drop("PROCESS_DATE","PROCESS_USER")

# COMMAND ----------

final_df_snap, processDate = add_audit_attributes(df_snap)
final_df_snap = final_df_snap.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_snap.createOrReplaceTempView("SNAPSHOT_TABLE")

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {processDate}')

(final_df_snap
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Final Table

# COMMAND ----------

df_quota_attainment = spark.sql(f'''
                    WITH CTE AS (
                        SELECT a.COMMISSION_ID,
                          TRIM(')' FROM SUBSTRING(a.PARTICIPANT_NAME, INSTR(a.PARTICIPANT_NAME, '(')+1, LEN(a.PARTICIPANT_NAME)-INSTR(a.PARTICIPANT_NAME, '('))) SFDC_ID,
                          a.PARTICIPANT_ID,
                          a.PARTICIPANT_NAME, 
                          a.POSITION_NAME, 
                          a.EARNING_GROUP_NAME, 
                          a.PERIOD_NAME,
                          a.ROLL_ATTAINMENT_VALUE,
                          a.ROLL_MEASURE_VALUE

                      FROM main.fin_commissions_silver.xc_commission a
                      INNER JOIN (
                              SELECT max(COMMISSION_ID) as COMMISSION_ID,
                                      PARTICIPANT_NAME,
                                      POSITION_NAME,
                                      EARNING_GROUP_NAME
                              FROM main.fin_commissions_silver.xc_commission

                              WHERE  
                                  (EARNING_GROUP_NAME like '%Consumption%' OR 
                                              EARNING_GROUP_NAME like '%Commit%' OR 
                                              EARNING_GROUP_NAME like '%S2%' OR
                                              EARNING_GROUP_NAME IN (
                                                  'Count New Logo Commit',
                                                  'Tier 2 Commissionable Incremental Consumption',
                                                  'Commissionable Incremental Consumption',
                                                  'Total Commit',
                                                  'Partner Base Commissionable Incremental Consumption',
                                                  'Partner New Total Commit',
                                                  'Count New Customer Consumption',
                                                  'Activated Customer Count Consumption',
                                                  'U2 Opportunities',
                                                  'Product Consumption',
                                                  'Tier 2 Product Consumption',
                                                  'Product Consumption DBSQL',
                                                  'Product Consumption GenAI',
                                                  'Product Consumption UC',
                                                  'Technical Certified Individuals',
                                                  'Activated Logo',
                                                  'Activated Logo DB4K'
                                                  ))
                                  AND NAME NOT LIKE '%Monthly 0%'
                                  AND ROLL_MEASURE_VALUE IS NOT NULL 
                                  AND ROLL_ATTAINMENT_VALUE IS NOT NULL

                                  AND PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_commission)

                              GROUP BY
                                PARTICIPANT_NAME,
                                POSITION_NAME,
                                EARNING_GROUP_NAME
                              ) b
                      ON a.COMMISSION_ID = b.COMMISSION_ID

                      WHERE a.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_commission)
                    )      
                    
                    SELECT ct.*, 
                           us.username, 
                           xp.FISCAL_WEEK,
                           xp.FISCAL_MONTH,
                           xp.FISCAL_QUARTER,
                           xp.FISCAL_HALF_YEAR,
                           xp.FISCAL_YEAR,
                           xp.DATE as PERIOD_DATE

                    FROM CTE ct  
                    JOIN main.sfdc_bronze.user us
                      ON ct.SFDC_ID = us.ID
                    JOIN main.fin_commissions_silver.xc_period xp
                      ON ct.PERIOD_NAME = xp.NAME

                    WHERE us.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.user) AND 
                          xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_period)            
                         ''')

df_quota_attainment.createOrReplaceTempView('quota_attainment_extended')

# COMMAND ----------

df_updated = spark.sql(f''' 
                       WITH CTE AS (
                          SELECT DISTINCT p.POSITION_NAME, 
                                          p.POSITION_ID,
                                          p.POSITION_START_DATE EFFECTIVE_START_DATE, 
                                          p.POSITION_END_DATE EFFECTIVE_END_DATE

                          FROM main.fin_commissions_silver.latest_pos_part_mapping p
                          WHERE p.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.latest_pos_part_mapping)  
                        ),

                        CTE2 AS (
                        SELECT DISTINCT ce.*,
                                        ct.POSITION_ID ,  
                                        ct.EFFECTIVE_START_DATE, 
                                        ct.EFFECTIVE_END_DATE
                        FROM quota_attainment_extended ce 
                          LEFT JOIN CTE ct
                            ON (
                                  ce.POSITION_NAME = ct.POSITION_NAME 
                                  AND ce.PERIOD_DATE >= ct.EFFECTIVE_START_DATE 
                                  AND ce.PERIOD_DATE <= ct.EFFECTIVE_END_DATE
                                )
                        )
                        
                          SELECT DISTINCT ct.* 
                          FROM CTE2 ct 
                          JOIN main.fin_commissions_silver.xc_period xp
                            ON ct.PERIOD_DATE = xp.START_DATE
                            
                          WHERE (SUBSTRING(xp.START_DATE, 0, 7) = substring(xp.END_DATE, 0, 7)) AND
                                xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_period)
                       
                       ''')

df_updated.createOrReplaceTempView('df_updated')

# COMMAND ----------

df_title = spark.sql(f'''
    SELECT dt.*,
           pt.TITLE_NAME as Title,
           tg.`group` as Title_Group
       
    FROM df_updated dt 
      LEFT JOIN main.fin_commissions_silver.xc_pos_title_assignment pt
              ON dt.POSITION_ID = pt.POSITION_ID
      LEFT JOIN main.fin_commissions_silver.Title_Group_Map tg
              ON pt.TITLE_NAME = tg.distinct_title

    WHERE pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_title_assignment) AND
          tg.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.Title_Group_Map) 
                     ''')
df_title.createOrReplaceTempView('df_title')

# COMMAND ----------

final_df_quota_attainment, process_date = add_audit_attributes(df_title)
final_df_quota_attainment_extended = final_df_quota_attainment.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_quota_attainment_extended.createOrReplaceTempView("GOLD_TABLE")

# COMMAND ----------

# Distinct fiscal year flowing from data
distinct_DV_values = [row["FISCAL_YEAR"] for row in final_df_quota_attainment_extended.select("FISCAL_YEAR").distinct().collect()]
distinct_DV_values

# COMMAND ----------

condition = "FISCAL_YEAR IN (" + ", ".join([f"'{value}'" for value in distinct_DV_values]) + ")"
condition

# COMMAND ----------

staging_full_table_name = f'{target_catalog}.fin_commissions_silver.{staging_tablename}'
print(f'Updating data in {staging_full_table_name} for {process_date}')

(final_df_quota_attainment_extended.write
                                   .mode('overwrite')
                                   .format('delta')
                                   .option('mergeSchema', 'true')
                                   .partitionBy('FISCAL_YEAR')
                                   .option("replaceWhere", condition)
                                   .saveAsTable(staging_full_table_name)
)

# COMMAND ----------

df_staging_read = spark.sql(f''' SELECT * FROM {target_catalog}.fin_commissions_silver.{staging_tablename} ''')

# COMMAND ----------

full_table_name = f'{target_catalog}.{target_gold_schema}.{target_tablename}'
print(f'Updating data in {full_table_name} for {process_date}')

(df_staging_read.write
                .mode('overwrite')
                .format('delta')
                .option('overwriteSchema', 'true')
                .partitionBy('FISCAL_YEAR')
                .saveAsTable(full_table_name)
)
