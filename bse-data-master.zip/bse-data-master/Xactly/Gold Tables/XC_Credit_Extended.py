# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import lit, udf
from pyspark.sql.types import StringType
from contextlib import contextmanager
from typing import Iterator
from contextlib import nullcontext
from logging import Logger

# COMMAND ----------

# MAGIC %run "./sales_intelligence_config"

# COMMAND ----------

target_tablename = 'xc_credit_extended'
snapshot_tablename = 'xc_credit_extended_history'
staging_tablename = 'xc_credit_extended_staging'

# COMMAND ----------

def get_fiscal_year():
    current_date = datetime.now()
    current_year = current_date.year
    fiscal_year = current_year if current_date.month >= 3 else current_year - 1
    return f'FY{str(fiscal_year + 1)[-2:]}'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Snapshot Table

# COMMAND ----------

#Extract the data in xc_credit_extended which contains the latest data

full_raw_table_name_snap = f'{target_catalog}.{target_silver_schema}.{snapshot_tablename}'
df_snap = sql(f''' SELECT * FROM main.{target_gold_schema}.{target_tablename} ''')

# COMMAND ----------

df_snap = df_snap.drop("PROCESS_DATE","PROCESS_USER")

# COMMAND ----------

final_df_snap, processDate = add_audit_attributes(df_snap)
final_df_snap = final_df_snap.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_snap.createOrReplaceTempView("SNAPSHOT_TABLE")

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {processDate}')

(final_df_snap
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Final Table

# COMMAND ----------

df_credit_extended = spark.sql(f'''
                     WITH CTE AS (
                     SELECT cr.PARTICIPANT_ID,
                            cr.PARTICIPANT_NAME,
                            cr.POSITION_ID as cr_POSITION_ID,
                            cr.POSITION_NAME,
                            TRIM(')' FROM SUBSTRING(cr.PARTICIPANT_NAME, INSTR(cr.PARTICIPANT_NAME, '(')+1, LEN(cr.PARTICIPANT_NAME)-INSTR(cr.PARTICIPANT_NAME, '('))) SFDC_ID,
                            cr.PERIOD_NAME,
                            cr.CREDIT_TYPE_NAME,
                            cr.CUSTOMER_ID,
                            cr.CUSTOMER_NAME,
                            cr.ORDER_CODE,
                            ci.Platform_Type,
                            cr.AMOUNT_DISPLAY_SYMBOL,  
                            cr.PLAN_NAME,
                            SUM(cr.AMOUNT) as SUM_CREDIT_AMOUNT
                            

                     FROM main.fin_commissions_silver.xc_credit cr
                     JOIN main.fin_commissions_silver.xc_comp_order_item ci 
                            ON (ci.COMP_ORDER_ITEM_ID = cr.ORDER_ITEM_ID)

                     WHERE ci.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_comp_order_item)
                       AND cr.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_credit)

                     GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13
                     )

                     SELECT cr.PARTICIPANT_ID,
                            cr.PARTICIPANT_NAME,
                            cr.cr_POSITION_ID,
                            cr.POSITION_NAME,
                            cr.SFDC_ID,
                            us.username,
                            cr.PERIOD_NAME,
                            cr.CREDIT_TYPE_NAME,
                            cr.CUSTOMER_ID,
                            cr.CUSTOMER_NAME,
                            cr.ORDER_CODE,
                            cr.Platform_Type,
                            cr.AMOUNT_DISPLAY_SYMBOL,
                            cr.PLAN_NAME,
                            xp.FISCAL_WEEK,
                            xp.FISCAL_MONTH,
                            xp.FISCAL_QUARTER,
                            xp.FISCAL_HALF_YEAR,
                            xp.FISCAL_YEAR,
                            cr.SUM_CREDIT_AMOUNT,
                            xp.DATE as PERIOD_DATE

                     FROM CTE cr
                     JOIN main.fin_commissions_silver.xc_period xp
                            ON cr.PERIOD_NAME = xp.NAME
                     LEFT JOIN main.sfdc_bronze.user us
                            ON cr.SFDC_ID = us.ID

                     WHERE xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_period)
                       AND us.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.user)
                     
                               ''') 

df_credit_extended.createOrReplaceTempView('credit_extended')

# COMMAND ----------

df_updated = spark.sql(f''' 
                       WITH CTE AS (
                          SELECT DISTINCT pa.POSITION_NAME,
                                          p.POSITION_ID as pos_POSITION_ID, 
                                          p.EFFECTIVE_START_DATE, 
                                          p.EFFECTIVE_END_DATE

                          FROM main.fin_commissions_silver.xc_pos_part_assignment pa
                          LEFT JOIN main.fin_commissions_silver.xc_position p 
                            ON pa.position_id = p.position_id

                          WHERE pa.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_part_assignment) AND
                                p.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_position) 
                        ),

                        CTE2 AS (
                        SELECT DISTINCT ce.*, 
                                        ct.EFFECTIVE_START_DATE, 
                                        ct.EFFECTIVE_END_DATE,
                                        ct.pos_POSITION_ID

                        FROM credit_extended ce 
                          LEFT JOIN CTE ct
                            ON (
                                  ce.POSITION_NAME = ct.POSITION_NAME 
                                  AND ce.PERIOD_DATE >= ct.EFFECTIVE_START_DATE 
                                  AND ce.PERIOD_DATE <= ct.EFFECTIVE_END_DATE
                                )
                        )
                        
                          SELECT DISTINCT ct.*
                          FROM CTE2 ct 
                          JOIN main.fin_commissions_silver.xc_period xp
                            ON ct.PERIOD_DATE = xp.START_DATE

                          WHERE (SUBSTRING(xp.START_DATE, 0, 7) = substring(xp.END_DATE, 0, 7)) AND
                                xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_period)
                       
                       ''')

df_updated = df_updated.drop('cr_POSITION_ID')
df_updated = df_updated.withColumnRenamed('pos_POSITION_ID', 'POSITION_ID')
df_updated.createOrReplaceTempView('df_temp1')

# COMMAND ----------

df_FINAL = spark.sql(f'''
    SELECT 
       DISTINCT
       dt.*,
       pt.TITLE_NAME as Title,
       tg.`group` as Title_Group

    FROM df_temp1 dt 
      LEFT JOIN main.fin_commissions_silver.xc_pos_title_assignment pt
              ON dt.POSITION_ID = pt.POSITION_ID
      LEFT JOIN main.fin_commissions_silver.Title_Group_Map tg
              ON pt.TITLE_NAME = tg.distinct_title

    WHERE pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_title_assignment) AND
          tg.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.Title_Group_Map) 
  ''')
  
df_FINAL.createOrReplaceTempView("FINAL_DF")

# COMMAND ----------

final_df_credit_extended, process_date = add_audit_attributes(df_FINAL)
final_df_credit_extended = final_df_credit_extended.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_credit_extended.createOrReplaceTempView("GOLD_TABLE")

# COMMAND ----------

# Distinct fiscal year flowing from data
distinct_DV_values = [row["FISCAL_YEAR"] for row in final_df_credit_extended.select("FISCAL_YEAR").distinct().collect()]
distinct_DV_values

# COMMAND ----------

condition = "FISCAL_YEAR IN (" + ", ".join([f"'{value}'" for value in distinct_DV_values]) + ")"
condition

# COMMAND ----------

staging_full_table_name = f'{target_catalog}.fin_commissions_silver.{staging_tablename}'
print(f'Updating data in {staging_full_table_name} for {process_date}')

(final_df_credit_extended.write
                         .mode('overwrite')
                         .format('delta')
                         .option('mergeSchema', 'true')
                         .partitionBy('FISCAL_YEAR')
                         .option("replaceWhere", condition)
                         .saveAsTable(staging_full_table_name)
)

# COMMAND ----------

df_staging_read = spark.sql(f''' SELECT * FROM {target_catalog}.fin_commissions_silver.{staging_tablename} ''')

# COMMAND ----------

full_table_name = f'{target_catalog}.{target_gold_schema}.{target_tablename}'
print(f'Updating data in {full_table_name} for {process_date}')

(df_staging_read.write
                .mode('overwrite')
                .format('delta')
                .option('overwriteSchema', 'true')
                .partitionBy('FISCAL_YEAR')
                .saveAsTable(full_table_name)
)
