# Databricks notebook source
# MAGIC %md
# MAGIC #### Xactly xc_participant_extended
# MAGIC
# MAGIC - **Description**: 
# MAGIC   - Granularity: Participant
# MAGIC   - Contains details of all participants whose position's effective start date is less than prior fiscal month's end date and position's end date is greater than prior fiscal month's start date
# MAGIC     
# MAGIC     ( For Ex. If current month is Nov'23, prior fiscal month would be Oct'23. Each participant's position effective start and end date would be checked w.r.t Oct'23)
# MAGIC   - Contains Email, Position, SFDC ID, Title Name, Business Unit and Region Level details for each participant
# MAGIC
# MAGIC - **Data Sources**
# MAGIC   - fin_commissions_silver.xc_pos_title_assignment
# MAGIC   - fin_commissions_silver.xc_pos_part_assignment
# MAGIC   - fin_commissions_silver.xc_position
# MAGIC   - fin_commissions_silver.xc_participant
# MAGIC   - sfdc_bronze.user
# MAGIC - **Generated Tables**
# MAGIC   - **fin_commissions_gold.xc_participant_extended**: Contains the latest data
# MAGIC   - **fin_commissions_silver.xc_participant_extended_history**: Contains the snapshots of historical fin_commissions_gold.xc_participant_extended data

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import lit, udf
from pyspark.sql.types import StringType
from contextlib import contextmanager
from typing import Iterator
from contextlib import nullcontext
from logging import Logger

# COMMAND ----------

# MAGIC %run "./sales_intelligence_config"

# COMMAND ----------

staging_tablename = 'xc_participant_extended_staging'
target_tablename = 'xc_participant_extended'
snapshot_tablename = 'xc_participant_extended_history'

# COMMAND ----------

def get_fiscal_year():
    current_date = datetime.now()
    current_year = current_date.year
    fiscal_year = current_year if current_date.month >= 3 else current_year - 1
    return f'FY{str(fiscal_year + 1)[-2:]}'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Snapshot Table

# COMMAND ----------

#Extract the data in xc_participant_extended which contains the latest data

full_raw_table_name_snap = f'{target_catalog}.{target_silver_schema}.{snapshot_tablename}'
df_snap = sql(f''' SELECT * FROM main.{target_gold_schema}.{target_tablename} ''')

# COMMAND ----------

df_snap = df_snap.drop("PROCESS_DATE","PROCESS_USER")

# COMMAND ----------

final_df_snap, processDate = add_audit_attributes(df_snap)
final_df_snap = final_df_snap.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_snap.createOrReplaceTempView("SNAPSHOT_TABLE")

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {processDate}')

(final_df_snap
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gold Final Table

# COMMAND ----------

df_participant_extended = spark.sql(f'''
                      SELECT 
                          DISTINCT
                          pp.PARTICIPANT_ID, 
                          pt.NAME, 
                          CAST(pt.HIRE_DATE as date) HIRE_DATE,
                          pt.COUNTRY,
                          us.ID SFDC_ID, 
                          pp.POSITION_NAME, 
                          us.username, 
                          us.lastname, 
                          us.firstname, 
                          us.Email, 
                          us.Business_Unit__c, 
                          us.Region_Level_1__c, 
                          us.Region_Level_2__c, 
                          us.Region_Level_3__c, 
                          us.territory_name__c,
                          pa.TITLE_ID, 
                          pa.TITLE_NAME,
                          tg.`group` as TITLE_GROUP,
                          CAST(pp.POSITION_START_DATE as date) as pos_effective_start_date,
                          CAST(pp.POSITION_END_DATE as date) as pos_effective_end_date,
                          CAST(pp.PARTICIPANT_START_DATE as date) as part_effective_start_date,
                          CAST(pp.PARTICIPANT_END_DATE as date) as part_effective_end_date
                          
                      FROM main.fin_commissions_silver.xc_participant pt 
                        LEFT JOIN main.fin_commissions_silver.latest_pos_part_mapping pp
                          ON pt.PARTICIPANT_ID = pp.PARTICIPANT_ID
                        LEFT JOIN main.sfdc_bronze.user us
                          ON pt.EMPLOYEE_ID = us.ID
                        LEFT JOIN main.fin_commissions_silver.xc_pos_title_assignment pa
                          ON pp.POSITION_ID = pa.POSITION_ID
                        LEFT JOIN main.fin_commissions_silver.Title_Group_Map tg
                          ON pa.TITLE_NAME = tg.distinct_title

                      WHERE 
                      pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_participant) AND
                      pp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.latest_pos_part_mapping) AND
                      pa.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_title_assignment) AND
                      tg.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.Title_Group_Map) AND
                      us.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.user) AND
                      (
                        --pp.POSITION_START_DATE <= date_sub(getdate(), dayofmonth(getdate())) AND
                        pp.POSITION_END_DATE >= trunc(date_sub(getdate(), dayofmonth(getdate())), 'MM') AND 
                        --pp.PARTICIPANT_START_DATE <= date_sub(getdate(), dayofmonth(getdate())) AND
                        pp.PARTICIPANT_END_DATE >= trunc(date_sub(getdate(), dayofmonth(getdate())), 'MM')
                      )
''')

df_participant_extended.createOrReplaceTempView('participant_extended')

# COMMAND ----------

get_fiscal_year_udf = udf(get_fiscal_year, StringType())
df_participant_extended_final = df_participant_extended.withColumn("dashboard_visibility", lit(get_fiscal_year_udf()))

# COMMAND ----------

final_df_participant_extended, process_date = add_audit_attributes(df_participant_extended_final)
final_df_participant_extended = final_df_participant_extended.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_participant_extended.createOrReplaceTempView("GOLD_TABLE")

# COMMAND ----------

# Distinct dashboard_visibility flowing from data
distinct_DV_values = [row["dashboard_visibility"] for row in final_df_participant_extended.select("dashboard_visibility").distinct().collect()]
distinct_DV_values

# COMMAND ----------

condition = "dashboard_visibility IN (" + ", ".join([f"'{value}'" for value in distinct_DV_values]) + ")"
condition

# COMMAND ----------

staging_full_table_name = f'{target_catalog}.fin_commissions_silver.{staging_tablename}'
print(f'Updating data in {staging_full_table_name} for {process_date}')

date_str = process_date.strftime("%Y-%m-%d")
(
    final_df_participant_extended
      .write
      .mode('overwrite')
      .format('delta')
      .option('mergeSchema', 'true')
      .partitionBy('dashboard_visibility')
      .option("replaceWhere", condition)
      .saveAsTable(staging_full_table_name)
)

# COMMAND ----------

df_staging_read = spark.sql(f''' SELECT * FROM {target_catalog}.fin_commissions_silver.{staging_tablename} ''')

# COMMAND ----------

full_table_name = f'{target_catalog}.{target_gold_schema}.{target_tablename}'
print(f'Updating data in {full_table_name} for {process_date}')

(df_staging_read.write
                .mode('overwrite')
                .format('delta')
                .option('overwriteSchema', 'true')
                .partitionBy('dashboard_visibility')
                .saveAsTable(full_table_name)
)
