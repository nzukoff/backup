# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import lit, udf
from pyspark.sql.types import StringType
from contextlib import contextmanager
from typing import Iterator
from contextlib import nullcontext
from logging import Logger

# COMMAND ----------

spark.sql('''
          CREATE OR REPLACE TABLE main.fin_commissions_attainment_silver.xc_sales_comp_RLS_hierarchy
          AS SELECT pt.WORKDAY_ID as EMPLOYEE_ID,
                part.NAME as PARTICIPANT_NAME,
                part.POSITION_NAME,
                part.SFDC_ID,
                part.Email,
                part.TITLE_NAME PLAN_TITLE,
                part.TITLE_GROUP,
                hier.M1Name as DIRECT_MANAGER_NAME, 
                hier.Username_M1 as DIRECT_MANAGER_EMAIL
                
          FROM main.fin_commissions_gold.xc_participant_extended part
            LEFT JOIN main.fin_commissions_gold.xc_hierarchy_extended hier
              ON part.NAME = hier.AEName
              AND hier.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_gold.xc_hierarchy_extended)
            LEFT JOIN main.fin_commissions_silver.xc_participant pt
              ON part.PARTICIPANT_ID = pt.PARTICIPANT_ID
              AND pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_participant)
          WHERE part.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_gold.xc_participant_extended)
          AND (pt.TERMINATION_DATE IS NULL OR pt.TERMINATION_DATE > current_date())
          ''')

# COMMAND ----------

# %sql
# CREATE OR REPLACE VIEW main.fin_commissions_attainment_silver.xc_view_sales_comp_RLS
# AS SELECT pt.WORKDAY_ID as EMPLOYEE_ID,
#       part.NAME as PARTICIPANT_NAME,
#       part.POSITION_NAME,
#       part.SFDC_ID,
#       part.Email,
#       part.TITLE_NAME PLAN_TITLE,
#       part.TITLE_GROUP,
#       hier.M1Name as DIRECT_MANAGER_NAME, 
#       hier.Username_M1 as DIRECT_MANAGER_EMAIL
      
# FROM main.fin_commissions_gold.xc_participant_extended part
#   LEFT JOIN main.fin_commissions_gold.xc_hierarchy_extended hier
#     ON part.NAME = hier.AEName
#     AND hier.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_gold.xc_hierarchy_extended)
#   LEFT JOIN main.fin_commissions_silver.xc_participant pt
#     ON part.PARTICIPANT_ID = pt.PARTICIPANT_ID
#     AND pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_participant)
# WHERE part.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_gold.xc_participant_extended)
# AND (pt.TERMINATION_DATE IS NULL OR pt.TERMINATION_DATE > current_date())
