# Databricks notebook source
from typing import Callable, Optional, Sequence
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit
from datetime import datetime, date
from dataclasses import dataclass, field
from datetime import datetime, timedelta

# COMMAND ----------

from dataclasses import dataclass

@dataclass(frozen=True)
class defineconfig:
  name: str
  parquet_dir: str
  database: str
  target_catalog: str
  target_database_test: str
  target_bronze_schema: str
  target_silver_schema: str
  target_gold_schema: str
  process_date_column: str
  current_user_column: str
  xactly_s3_bucket: str
  SECRET_SCOPE: str
  xactly_report_extract_s3_access_key: str
  xactly_report_extract_s3_secret_key: str
  xactly_report_extract_s3_secret_key_sp: str
  JDBC_SECRET_SCOPE: str
  JDBC_URL: str
  JDBC_USER: str
  JDBC_PASS: str
  JDBC_CLIENT: str

# COMMAND ----------

dbutils.widgets.dropdown("environment", "dev", ["dev", "prod"])
ENV = dbutils.widgets.get("environment")

# COMMAND ----------

ri_config =  { 
'prod' : {
  'name' : 'Production',
  'parquet_dir' : 'dbfs:/mnt/bse-prod/Xactly/production',
  'database':'bdw',
  'target_catalog': 'main',
  'target_database_test': 'bdw',
  'target_bronze_schema': 'fin_commissions_bronze',
  'target_silver_schema': 'fin_commissions_silver',
  'target_gold_schema': 'fin_commissions_gold',
  'process_date_column': 'processDate',
  'current_user_column': 'processUser',
  'xactly_s3_bucket': 'xactly-ftp',
  'SECRET_SCOPE': 'xactly-ftp-automation',
  'xactly_report_extract_s3_access_key':'xactly-ftp-extract-s3-access-key',
  'xactly_report_extract_s3_secret_key':'xactly-ftp-extract-s3-secret-key',
  'xactly_report_extract_s3_secret_key_sp':'xactly-ftp-sp-extract-s3-secret-key',
  'JDBC_SECRET_SCOPE': 'xactly-jdbc-automation',
  'JDBC_URL': 'xactly-jdbc-url',
  'JDBC_USER': 'xactly-jdbc-user',
  'JDBC_PASS': 'xactly-jdbc-password',
  'JDBC_CLIENT': 'xactly-jdbc-client'
} ,

'dev' : {
  'name':'Dev',
  'parquet_dir': 'dbfs:/mnt/bse-dev/Xactly/dev',
  'database':'bdw_dev',
  'target_catalog': 'integration',
  'target_database_test': 'bdw_dev',
  'target_bronze_schema': 'fin_commissions_bronze',
  'target_silver_schema': 'fin_commissions_silver',
  'target_gold_schema': 'fin_commissions_gold',
  'process_date_column': 'processDate',
  'current_user_column': 'processUser',
  'xactly_s3_bucket': 'xactly-ftp',
  'SECRET_SCOPE': 'xactly-ftp-automation',
  'xactly_report_extract_s3_access_key':'xactly-ftp-extract-s3-access-key',
  'xactly_report_extract_s3_secret_key':'xactly-ftp-extract-s3-secret-key',
  'xactly_report_extract_s3_secret_key_sp':'xactly-ftp-sp-extract-s3-secret-key',
  'JDBC_SECRET_SCOPE': 'xactly-jdbc-automation',
  'JDBC_URL': 'xactly-jdbc-url',
  'JDBC_USER': 'xactly-jdbc-user',
  'JDBC_PASS': 'xactly-jdbc-password',
  'JDBC_CLIENT': 'xactly-jdbc-client'
} }

# COMMAND ----------

try:
  setconfig = defineconfig(
                        ri_config[ENV]['name'],
                        ri_config[ENV]['parquet_dir'],
                        ri_config[ENV]['database'],
                        ri_config[ENV]['target_catalog'],
                        ri_config[ENV]['target_database_test'],
                        ri_config[ENV]['target_bronze_schema'],
                        ri_config[ENV]['target_silver_schema'],
                        ri_config[ENV]['target_gold_schema'],
                        ri_config[ENV]['process_date_column'],
                        ri_config[ENV]['current_user_column'],
                        ri_config[ENV]['xactly_s3_bucket'],
                        ri_config[ENV]['SECRET_SCOPE'],
                        ri_config[ENV]['xactly_report_extract_s3_access_key'],
                        ri_config[ENV]['xactly_report_extract_s3_secret_key'],
                        ri_config[ENV]['xactly_report_extract_s3_secret_key_sp'],
                        ri_config[ENV]['JDBC_SECRET_SCOPE'],
                        ri_config[ENV]['JDBC_URL'],
                        ri_config[ENV]['JDBC_USER'],
                        ri_config[ENV]['JDBC_PASS'],
                        ri_config[ENV]['JDBC_CLIENT']
                      )
except Exception:
  raise Exception(f'Configurations are not defined for {ENV}')

# COMMAND ----------

xactly_data_extract_s3_access_key = dbutils.secrets.get(setconfig.SECRET_SCOPE, setconfig.xactly_report_extract_s3_access_key)
xactly_data_extract_s3_secret_key = dbutils.secrets.get(setconfig.SECRET_SCOPE, setconfig.xactly_report_extract_s3_secret_key)
xactly_data_extract_s3_secret_key_sp = dbutils.secrets.get(setconfig.SECRET_SCOPE, setconfig.xactly_report_extract_s3_secret_key_sp)

xactly_s3_bucket = setconfig.xactly_s3_bucket

metadata_process_date_column= setconfig.process_date_column
metadata_current_user_column = setconfig.current_user_column
target_database_test = setconfig.target_database_test
table_parquet_dir = setconfig.parquet_dir 
target_catalog = setconfig.target_catalog
target_bronze_schema = setconfig.target_bronze_schema
target_silver_schema = setconfig.target_silver_schema
target_gold_schema = setconfig.target_gold_schema

xactly_JDBC_URL = dbutils.secrets.get(setconfig.JDBC_SECRET_SCOPE, setconfig.JDBC_URL)
xactly_JDBC_USER = dbutils.secrets.get(setconfig.JDBC_SECRET_SCOPE, setconfig.JDBC_USER)
xactly_JDBC_PASS = dbutils.secrets.get(setconfig.JDBC_SECRET_SCOPE, setconfig.JDBC_PASS)
xactly_JDBC_CLIENT = dbutils.secrets.get(setconfig.JDBC_SECRET_SCOPE, setconfig.JDBC_CLIENT)

# COMMAND ----------

from datetime import datetime, timedelta
def add_audit_attributes(df ):
  """
  Add process date and current user

  """
  now = datetime.datetime.utcnow().date()
  a =spark.sql('''select current_user''').collect()[0]
  user = a[0]
  
  df2 = (df
    .withColumn(metadata_process_date_column, lit(now))
    .withColumn(metadata_current_user_column, lit(user))
    )
  
  return (df2, now)


# COMMAND ----------

def dbfs_file_exists(folder: str, filename: str) -> bool:
  """
  Determines whether a file (or folder) exists under a specific
  DBFS directory. Use this instead of testing the FUSE path,
  because the FUSE path's existence isn't always reliable.
  """
  
  exists = False
  for fi in dbutils.fs.ls(folder):
    name = fi.name
    if name[-1] == '/':
      name = name[0:-1]

    if name == filename:
      exists = True
      break

  return exists


# COMMAND ----------

def read_csv_into_df(FilePath) :
  return spark.read.format("csv").\
    option("header","true").\
    load(FilePath)

# COMMAND ----------

def df_column_whitespace(df) :
  new_column_name_list= list(map(lambda x: x.replace(" ", "_").replace(":","").replace(" ","").replace("(","").replace(")","").replace("$","dollar"), df.columns))
  renamed_df = df.toDF(*new_column_name_list)
  return renamed_df

# COMMAND ----------

def list_of_files(folder) :
  s3 = boto3.resource('s3', aws_access_key_id=xactly_data_extract_s3_access_key, aws_secret_access_key=xactly_data_extract_s3_secret_key)
  my_bucket = s3.Bucket(xactly_s3_bucket)
  files_in_s3 = [f.key.split(folder + "/")[1] for f in my_bucket.objects.filter(Prefix=folder).all()  ]
  files_in_s3 = [i for i in files_in_s3 if i != '']
  return files_in_s3

# COMMAND ----------

import boto3
import datetime

def copy_to_archive(xactly_s3_bucket_folder, archive_folder) :

  s3 = boto3.resource('s3',aws_access_key_id=xactly_data_extract_s3_access_key, aws_secret_access_key=xactly_data_extract_s3_secret_key)
  my_bucket = s3.Bucket(xactly_s3_bucket)
  todays_date = datetime.datetime.today().strftime('%Y-%m-%d')

  files_in_s3 = [f.key.split(xactly_s3_bucket_folder + "/")[1] for f in my_bucket.objects.filter(Prefix=xactly_s3_bucket_folder).all()  ]
  files_in_s3 = [i for i in files_in_s3 if i != '']

  for filename in files_in_s3 : 
    print ('Copying file: ' + filename )
    copy_source = { 'Bucket': xactly_s3_bucket , 'Key': f'{xactly_s3_bucket_folder}/{filename}' }

    new_filename =f'{todays_date}_{filename}'
    target =  f'{archive_folder}/{new_filename}'
    my_bucket.copy(copy_source, target)

    print(f'Copied over {new_filename} to the folder {archive_folder} ')
    print (f'Now deleting the original file  {xactly_s3_bucket_folder}/{filename}' )

    s3.Object(xactly_s3_bucket, f'{xactly_s3_bucket_folder}/{filename}' ).delete()

    print (f'Deletion successful for {xactly_s3_bucket_folder}/{filename}' )

# COMMAND ----------


