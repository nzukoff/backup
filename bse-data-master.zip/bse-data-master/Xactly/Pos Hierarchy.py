# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_pos_hierarchy  
# MAGIC
# MAGIC Description: The xc_pos_hierarchy table contains information about the hierarchy of point of sale (POS) systems within the business. It includes details such as the POS hierarchy ID, version, and type ID, as well as the names and IDs of the POS systems involved. The table also tracks whether the hierarchy is currently active, as well as when it was created and modified.
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Xactly JDBC Driver
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC   - **Table Name** : xc_pos_hierarchy
# MAGIC   - **Description** : Contains Xactly xc_pos_hierarchy raw data loaded after type casting attributes to support data types compatible with logFood.
# MAGIC   - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC
# MAGIC - **Silver Table**
# MAGIC   - **Schema Name** : fin_commissions_silver
# MAGIC   - **Table Name** : xc_pos_hierarchy
# MAGIC   - **Description** : Additional fiscal attributes added using CREATED_DATE
# MAGIC   - **Additional Columns** : FISCAL_WEEK, FISCAL_MONTH, FISCAL_QUARTER, FISCAL_YEAR, PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC   - **Other Table Dependencies** : it_core_dim.bi_dates

# COMMAND ----------

from datetime import datetime, timedelta
from pyspark.sql.functions import col, to_date
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_pos_hierarchy'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_pos_hierarchy'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT 
        CAST(POS_HIERARCHY_ID AS DECIMAL(38,0)) POS_HIERARCHY_ID,
        CAST(VERSION AS DECIMAL(38,0)) VERSION, 
        CAST(FROM_POS_ID AS DECIMAL(38,0)) FROM_POS_ID,
        FROM_POS_NAME,
        CAST(TO_POS_ID AS DECIMAL(38,0)) TO_POS_ID,
        TO_POS_NAME,
        CAST(POS_HIERARCHY_TYPE_ID AS DECIMAL(38,0)) POS_HIERARCHY_TYPE_ID,
        IS_ACTIVE,
        CAST(CREATED_DATE AS STRING) CREATED_DATE,
        CAST(CREATED_BY_ID AS DECIMAL(38,0)) CREATED_BY_ID,
        CREATED_BY_NAME,
        CAST(MODIFIED_DATE AS STRING) MODIFIED_DATE,
        CAST(MODIFIED_BY_ID AS DECIMAL(38,0)) MODIFIED_BY_ID,
        MODIFIED_BY_NAME

    FROM XACTLY.xc_pos_hierarchy
)'''

df_pos_hrc = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

# COMMAND ----------

bronze_df_pos_hrc, process_date = add_audit_attributes(df_pos_hrc)
bronze_df_pos_hrc = bronze_df_pos_hrc.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_pos_hrc
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM {target_catalog}.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_pos_hrc = df_pos_hrc.withColumn('CREATED_DATE_UPD', to_date(col('CREATED_DATE')))
df_pos_hrc_upd = df_pos_hrc.join(df_dates,df_pos_hrc.CREATED_DATE_UPD ==  df_dates.date,"inner")
df_pos_hrc_upd = df_pos_hrc_upd.drop('date','CREATED_DATE_UPD')

# COMMAND ----------

final_df_pos_hrc, process_date = add_audit_attributes(df_pos_hrc_upd)
final_df_pos_hrc = final_df_pos_hrc.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_pos_hrc.columns:
    final_df_pos_hrc = final_df_pos_hrc.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_pos_hrc
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))
