# Databricks notebook source
from datetime import datetime, timedelta
from pyspark.sql.functions import col, to_date
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_login'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_login'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT CAST(LOGIN_ID as decimal(38,0)) LOGIN_ID,
            CAST(USER_ID as decimal(38,0)) USER_ID,
            EMAIL,
            TICKET_ID,
            CAST(LOGIN_TIME as string) LOGIN_TIME,
            CAST(LOGOFF_TIME as string) LOGOFF_TIME,
            LOGIN_STATUS,
            SOURCE_IP,
            USER_STATUS,
            LOGIN_TYPE,
            LOGIN_URL,
            LOGIN_COMMENT,
            PARTNER_ID,
            PARTNER_SESSION_ID,
            SITE_POD_NAME,
            USER_AGENT,
            LOGOFF_METHOD,
            AKAMAI_IP,
            LOGIN_DEVICE,
            LOGIN_DEVICE_VERSION,
            LOGIN_DEVICE_OS_VERSION,
            CAST(MODULE_CODE as decimal(38,0)) MODULE_CODE

    FROM XACTLY.xc_login

)'''

df_business = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

df_business.createOrReplaceTempView("Check_test")                    

# COMMAND ----------

from pyspark.sql import functions as F 
from pyspark.sql.functions import to_date, date_format
from pyspark.sql.types import StringType

df_fixed = df_business.withColumn("LOGIN_TIME", date_format(to_date(df_business["LOGIN_TIME"], "dd-MMM-yy"), "yyyy-MM-dd")).withColumn("LOGOFF_TIME", date_format(to_date(df_business["LOGOFF_TIME"], "dd-MMM-yy"), "yyyy-MM-dd"))

# COMMAND ----------

bronze_df_business, process_date = add_audit_attributes(df_fixed)
bronze_df_business = bronze_df_business.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_business
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM main.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_fixed = df_fixed.withColumn('LOGIN_TIME_UPD', to_date(col('LOGIN_TIME')))
df_business_upd = df_fixed.join(df_dates,df_fixed.LOGIN_TIME_UPD ==  df_dates.date,"inner")
df_business_upd = df_business_upd.drop('LOGIN_TIME_UPD','date')

# COMMAND ----------

final_df_business, process_date = add_audit_attributes(df_business_upd)
final_df_business = final_df_business.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_business.columns:
    final_df_business = final_df_business.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_business
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))
