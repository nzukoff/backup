# Databricks notebook source
# MAGIC %run "./config_xc_report"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col, to_date
from pyspark.sql.functions import expr
import urllib
import urllib.request
import io
import pandas as pd
import boto3

# COMMAND ----------

quota_bronze_tablename = 'xc_quota_assignment'
quota_silver_tablename = 'xc_quota_assignment'

# COMMAND ----------

# MAGIC %md
# MAGIC Extract latest data from bronze quota assignment table

# COMMAND ----------

latestProcessDate = spark.sql(f'''
                                SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{quota_bronze_tablename}
                              ''' ).collect()[0][0] 
print(latestProcessDate)

# COMMAND ----------

df_quota_assgn = spark.sql(f'''
                            SELECT *
                            FROM {target_catalog}.{target_bronze_schema}.{quota_bronze_tablename} 
                            WHERE PROCESS_DATE = '{latestProcessDate}' 
                          ''')

df_quota_assgn.createOrReplaceTempView("df_quota_assgn")

# COMMAND ----------

df_quota_assign_updated = spark.sql(f''' 
                                SELECT 
                                  qa.QUOTA_ASSIGNMENT_ID,
                                  qa.VERSION,
                                  qa.ASSIGNMENT_ID,
                                  qa.ASSIGNMENT_NAME,
                                  qa.ASSIGNMENT_TYPE,
                                  qa.AMOUNT,
                                  qa.AMOUNT_UNIT_TYPE_ID,
                                  qa.PERIOD_ID,
                                  xp.NAME as PERIOD_NAME,

                                  qa.QUOTA_ID,
                                  qu.NAME as QUOTA_NAME,
                                  qa.EFFECTIVE_START_PERIOD_ID,
                                  xs.NAME as EFFECTIVE_START_PERIOD_NAME,

                                  qa.EFFECTIVE_END_PERIOD_ID,
                                  xe.NAME as EFFECTIVE_END_PERIOD_NAME,

                                  qa.IS_ACTIVE,
                                  qa.DESCRIPTION,
                                  qa.CREATED_DATE,
                                  qa.CREATED_BY_ID,
                                  qa.CREATED_BY_NAME,
                                  qa.MODIFIED_DATE,
                                  qa.MODIFIED_BY_ID,
                                  qa.MODIFIED_BY_NAME,
                                  qa.QTA_ASGNMT_ID,
                                  qa.Annual_Prorated_OTI,
                                  qa.Annual_Prorated_OTI_unit_type_id,
                                  qa.Duration,
                                  qa.Effective_OTI,
                                  qa.Effective_OTI_unit_type_id,
                                  qa.H_One_Prorated_OTI,
                                  qa.H_One_Prorated_OTI_unit_type_id,
                                  qa.H_Two_Prorated_OTI,
                                  qa.H_Two_Prorated_OTI_unit_type_id,
                                  qa.OTI_Weight,
                                  qa.OTI_Weight_unit_type_id,
                                  qa.Payout_Frequency,
                                  qa.PROCESS_DATE,
                                  qa.PROCESS_FILE,
                                  qa.PROCESS_USER 

                                FROM df_quota_assgn qa
                                  JOIN {target_catalog}.fin_commissions_silver.xc_period xp 
                                    ON qa.PERIOD_ID = xp.PERIOD_ID
                                  JOIN {target_catalog}.fin_commissions_silver.xc_period xs 
                                    ON qa.EFFECTIVE_START_PERIOD_ID = xs.PERIOD_ID
                                  JOIN {target_catalog}.fin_commissions_silver.xc_period xe 
                                    ON qa.EFFECTIVE_END_PERIOD_ID = xe.PERIOD_ID
                                  JOIN {target_catalog}.fin_commissions_silver.xc_quota qu
                                    ON qa.QUOTA_ID = qu.QUOTA_ID
  
                          WHERE xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_period)
                          AND xs.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_period)
                          AND xe.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_period)
                          AND qu.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_quota)
                          
                          ''')

df_quota_assign_updated.createOrReplaceTempView("df_quota_assign_updated")

# COMMAND ----------

# MAGIC %md
# MAGIC Add fiscal attributes to the data extracted from bronze quota assignment table

# COMMAND ----------

df_dates = spark.sql(f''' SELECT DISTINCT
                                 PERIOD_ID xc_period_PERIOD_ID, 
                                 FISCAL_MONTH, 
                                 FISCAL_WEEK, 
                                 FISCAL_QUARTER, 
                                 FISCAL_HALF_YEAR, 
                                 FISCAL_YEAR
                          FROM {target_catalog}.fin_commissions_silver.xc_period 
                          WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_period)''')

# COMMAND ----------

df_quota_bronze = df_quota_assign_updated.join(df_dates,df_quota_assign_updated.PERIOD_ID ==  df_dates.xc_period_PERIOD_ID,"inner")
df_quota_bronze = df_quota_bronze.drop('xc_period_PERIOD_ID')

df_quota_bronze.createOrReplaceTempView("quota_assignment_bronze")

# COMMAND ----------

# MAGIC %md
# MAGIC Extract latest data from silver quota assignment table

# COMMAND ----------

df_quota_latest_silver = spark.sql(f'''
                                         
          SELECT *
          FROM {target_catalog}.{target_silver_schema}.{quota_silver_tablename}
          WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_silver_schema}.{quota_silver_tablename})
                                          
                                          ''')
                                          
df_quota_latest_silver.createOrReplaceTempView("quota_latest_silver")

# COMMAND ----------

# MAGIC %md
# MAGIC Check DISTINCT PERIOD_NAMES in bronze quota assignment data

# COMMAND ----------

distinct_period_names = df_quota_bronze.select("PERIOD_NAME").distinct().rdd.flatMap(lambda x: x).collect()
distinct_period_names

# COMMAND ----------

# MAGIC %md
# MAGIC DELETE rows from latest Silver quota assignment data which have PERIOD_NAMES same as above

# COMMAND ----------

# Filter rows in Silver where PERIOD_NAME is not in distinct_period_names_values

silver_filtered = df_quota_latest_silver.filter(~col("PERIOD_NAME").isin(distinct_period_names))

# COMMAND ----------

# MAGIC %md
# MAGIC Add Bronze quota assignment data to filtered Silver quota assignment data

# COMMAND ----------

silver_combined = silver_filtered.unionByName(df_quota_bronze, allowMissingColumns=True)
silver_combined.createOrReplaceTempView("silver_combined")

# COMMAND ----------

# MAGIC %md
# MAGIC Update PROCESS_DATE with the current process date

# COMMAND ----------

silver_combined = silver_combined.drop("PROCESS_DATE","PROCESS_USER")
final_silver_combined, processDate = add_audit_attributes(silver_combined)
final_silver_combined = final_silver_combined.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_silver_combined.createOrReplaceTempView("final_silver_combined_table")

# COMMAND ----------

# MAGIC %md
# MAGIC Load the combined Silver quota assignment data into LogFood

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
full_silver_quota_tablename = f'{target_catalog}.{target_silver_schema}.{quota_silver_tablename}'

print (f'Updating data in {full_silver_quota_tablename} for {processDate}')

(final_silver_combined
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_silver_quota_tablename))

# COMMAND ----------


