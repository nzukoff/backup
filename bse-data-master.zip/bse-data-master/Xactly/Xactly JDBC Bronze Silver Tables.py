# Databricks notebook source
# MAGIC %run "./Xbpm Approval Res Instance"

# COMMAND ----------

# MAGIC %run "./Xbpm Approval Document"

# COMMAND ----------

# MAGIC %run "./Pos Part Assignment"

# COMMAND ----------

# MAGIC %run "./Batch Type"

# COMMAND ----------

# MAGIC %run "./User Batch"

# COMMAND ----------

# MAGIC %run "./Plan"

# COMMAND ----------

# MAGIC %run "./Plan Assignment" 

# COMMAND ----------

# MAGIC %run "./Bonus"

# COMMAND ----------

# MAGIC %run "./Business Group"

# COMMAND ----------

# MAGIC %run "./Currency Rate"

# COMMAND ----------

# MAGIC %run "./Draw"

# COMMAND ----------

# MAGIC %run "./Draw Assignment"

# COMMAND ----------

# MAGIC %run "./Emp Status Code"

# COMMAND ----------

# MAGIC %run "./Order Type"

# COMMAND ----------

# MAGIC %run "./Participant"

# COMMAND ----------

# MAGIC %run "./Period"

# COMMAND ----------

# MAGIC %run "./Pos Hierarchy"

# COMMAND ----------

# MAGIC %run "./Pos Hierarchy Type"

# COMMAND ----------

# MAGIC %run "./Pos Part Assignment"

# COMMAND ----------

# MAGIC %run "./Pos Rel Type"

# COMMAND ----------

# MAGIC %run "./Pos Relations"

# COMMAND ----------

# MAGIC %run "./Pos Title Assignment"

# COMMAND ----------

# MAGIC %run "./Position"

# COMMAND ----------

# MAGIC %run "./Quota"

# COMMAND ----------

# MAGIC %run "./Unit Type"
