# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_currency_rate 
# MAGIC
# MAGIC Description: The xc_currency_rate table stores information about currency exchange rates. It includes the base and target currency names, exchange rate, active start and end dates, and whether the rate is currently active. This data is important for financial analysis and decision-making related to currency exchange rates.
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Xactly JDBC Driver
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC   - **Table Name** : xc_currency_rate
# MAGIC   - **Description** : Contains Xactly xc_currency_rate raw data loaded after type casting attributes to support data types compatible with logFood.
# MAGIC   - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC
# MAGIC - **Silver Table**
# MAGIC   - **Schema Name** : fin_commissions_silver
# MAGIC   - **Table Name** : xc_currency_rate
# MAGIC   - **Description** : Additional fiscal attributes added using ACTIVE_START_DATE
# MAGIC   - **Additional Columns** : FISCAL_WEEK, FISCAL_MONTH, FISCAL_QUARTER, FISCAL_YEAR, PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC   - **Other Table Dependencies** : it_core_dim.bi_dates

# COMMAND ----------

from datetime import datetime, timedelta
from pyspark.sql.functions import col, to_date
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_currency_rate'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_currency_rate'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT CAST(CURRENCY_RATE_ID as DECIMAL(38,0)) CURRENCY_RATE_ID,
          CAST(VERSION as DECIMAL(38,0)) VERSION,
          BASE_CURRENCY_NAME,
          CAST(BASE_CURRENCY_UNIT_TYPE_ID as DECIMAL(38,0)) BASE_CURRENCY_UNIT_TYPE_ID,
          TARGET_CURRENCY_NAME,
          CAST(TARGET_CURRENCY_UNIT_TYPE_ID as DECIMAL(38,0)) TARGET_CURRENCY_UNIT_TYPE_ID,
          EXCHANGE_RATE,
          CAST(ACTIVE_START_DATE as string) ACTIVE_START_DATE,
          CAST(ACTIVE_END_DATE as string) ACTIVE_END_DATE,
          IS_ACTIVE,
          CAST(CREATED_DATE as string) CREATED_DATE,
          CAST(CREATED_BY_ID as DECIMAL(38,0)) CREATED_BY_ID,
          CREATED_BY_NAME,
          CAST(MODIFIED_DATE as string) MODIFIED_DATE,
          CAST(MODIFIED_BY_ID as DECIMAL(38,0)) MODIFIED_BY_ID,
          MODIFIED_BY_NAME,
          CAST(SOURCE_ID as DECIMAL(38,0)) SOURCE_ID

    FROM XACTLY.xc_currency_rate

)'''

df_currency = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

# COMMAND ----------

from pyspark.sql import functions as F

yyyy_mm_dd_pattern = r'^\d{4}-\d{2}-\d{2}$'  
dd_mon_yy_pattern = r'^\d{2}-[A-Z]{3}-\d{2}$'  

df_fixed = df_currency.withColumn(
    "ACTIVE_START_DATE",
    F.when(F.col("ACTIVE_START_DATE").rlike(yyyy_mm_dd_pattern), F.to_date(F.col("ACTIVE_START_DATE"), 'yyyy-MM-dd'))
    .when(F.col("ACTIVE_START_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.to_date(F.col("ACTIVE_START_DATE"), 'dd-MMM-yy'), 'yyyy-MM-dd'))
    .otherwise(None)  
).withColumn(
    "ACTIVE_END_DATE",
    F.when(F.col("ACTIVE_END_DATE").rlike(yyyy_mm_dd_pattern), F.date_format(F.last_day(F.to_date(F.col("ACTIVE_END_DATE"), 'yyyy-MM-dd')), 'yyyy-MM-dd'))
    .when(F.col("ACTIVE_END_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.last_day(F.to_date(F.col("ACTIVE_END_DATE"), 'dd-MMM-yy')), 'yyyy-MM-dd'))
    .otherwise(None)  
)

# COMMAND ----------

bronze_df_currency, process_date = add_audit_attributes(df_fixed)
bronze_df_currency = bronze_df_currency.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_currency
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM {target_catalog}.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_fixed = df_fixed.withColumn('ACTIVE_START_DATE_UPD', to_date(col('ACTIVE_START_DATE')))
df_currency_upd = df_fixed.join(df_dates,df_fixed.ACTIVE_START_DATE_UPD ==  df_dates.date,"inner")
df_currency_upd = df_currency_upd.drop('date','ACTIVE_START_DATE_UPD')

# COMMAND ----------

final_df_currency, process_date = add_audit_attributes(df_currency_upd)
final_df_currency = final_df_currency.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_currency.columns:
    final_df_currency = final_df_currency.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_currency
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))
