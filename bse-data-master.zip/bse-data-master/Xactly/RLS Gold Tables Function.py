# Databricks notebook source
sql("use catalog main")
sql("use schema fin_commissions_gold")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE FUNCTION rls_xactly_commissions(sfdc_id string)
# MAGIC RETURN
# MAGIC     SELECT 
# MAGIC         CASE
# MAGIC           WHEN is_member('datasets.main.role.fin_commissions.admin')
# MAGIC             THEN TRUE
# MAGIC           WHEN 
# MAGIC               (
# MAGIC                  is_member('datasets.main.role.fin_commissions.ae') 
# MAGIC               OR is_member('datasets.main.role.fin_commissions.sa')
# MAGIC               OR is_member('datasets.main.role.fin_commissions.leader_sales')
# MAGIC               OR is_member('datasets.main.role.fin_commissions.cloud')
# MAGIC               OR is_member('datasets.main.role.fin_commissions.partner')
# MAGIC               )
# MAGIC               AND 
# MAGIC               EXISTS (
# MAGIC                     SELECT 1
# MAGIC                     FROM main.fin_commissions_gold.xc_hierarchy_extended  l
# MAGIC                     WHERE l.PROCESS_DATE = (SELECT max(PROCESS_DATE) FROM main.fin_commissions_gold.xc_hierarchy_extended )
# MAGIC                         AND l.AEId =  sfdc_id
# MAGIC                         AND current_user() IN 
# MAGIC                         (l.Username_Ae, l.Username_M1, l.Username_M2, l.Username_M3, l.Username_M4, l.Username_M5) -- If the viewer is above the  person in the commission hierarchy,
# MAGIC                     ) 
# MAGIC           THEN TRUE -- Then allow the row to be viewable
# MAGIC           ELSE FALSE -- Else, deny the row from being viewable
# MAGIC       END
