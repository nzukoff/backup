# Databricks notebook source
# MAGIC %run "./config_xc_report"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col, to_date
from pyspark.sql.functions import expr
import urllib
import urllib.request
import io
import pandas as pd
import boto3

# COMMAND ----------

payment_bronze_tablename = 'xc_payment'
payment_silver_tablename = 'xc_payment'

# COMMAND ----------

target_catalog

# COMMAND ----------

# MAGIC %md
# MAGIC Extract latest data from bronze payments table

# COMMAND ----------

latestProcessDate = spark.sql(f'''
                                SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{payment_bronze_tablename}
                              ''' ).collect()[0][0] 
print(latestProcessDate)

# COMMAND ----------

df_payments = spark.sql(f'''SELECT 
                           CAST(PAYMENT_ID AS DECIMAL(38,0)) PAYMENT_ID,
                           CAST(VERSION AS DECIMAL(38,0)) VERSION,
                           NAME,
                           IS_ACTIVE,
                           CAST(PERIOD_ID AS DECIMAL(38,0)) PERIOD_ID,
                           PERIOD_NAME,
                           CAST(AMOUNT AS DECIMAL(38,8)) AMOUNT,
                           CAST(AMOUNT_UNIT_TYPE_ID AS DECIMAL(38,0)) AMOUNT_UNIT_TYPE_ID,
                           AMOUNT_DISPLAY_SYMBOL,
                           CAST(LOCAL_CURRENCY_AMT AS DECIMAL(38,8)) LOCAL_CURRENCY_AMT,
                           CAST(LOCAL_CURRENCY_UNIT_TYPE_ID AS DECIMAL(38,0)) LOCAL_CURRENCY_UNIT_TYPE_ID,
                           CAST(CONVERSION_RATE AS DECIMAL(38,8)) CONVERSION_RATE,
                           CAST(PARTICIPANT_ID AS DECIMAL(38,0)) PARTICIPANT_ID,
                           PARTICIPANT_NAME,
                           CAST(POSITION_ID AS DECIMAL(38,0)) POSITION_ID,
                           POSITION_NAME,
                           CAST(CREDIT_ID AS DECIMAL(38,0)) CREDIT_ID,
                           CAST(ORDER_ITEM_ID AS DECIMAL(38,0)) ORDER_ITEM_ID,
                           ITEM_CODE,
                           ORDER_CODE,
                           IS_HELD,
                           IS_DOWNLOADED,
                           CAST(RELEASE_DATE as string) RELEASE_DATE,
                           IS_RELEASED,
                           CAST(EARNING_GROUP_ID AS DECIMAL(38,0)) EARNING_GROUP_ID,
                           EARNING_GROUP_NAME,
                           CAST(BUS_AMOUNT AS DECIMAL(38,8)) BUS_AMOUNT,
                           CAST(BUS_AMOUNT_UNIT_TYPE_ID AS DECIMAL(38,0)) BUS_AMOUNT_UNIT_TYPE_ID,
                           CAST(BUS_GROUP_AMOUNT AS DECIMAL(38,8)) BUS_GROUP_AMOUNT,
                           CAST(BUS_GROUP_AMOUNT_UNIT_TYPE_ID AS DECIMAL(38,0)) BUS_GROUP_AMOUNT_UNIT_TYPE_ID,
                           CAST(BUSINESS_GROUP_ID AS DECIMAL(38,0)) BUSINESS_GROUP_ID,
                           CAST(PAYMENT_CURR_AMOUNT AS DECIMAL(38,8)) PAYMENT_CURR_AMOUNT,
                           CAST(PAYMENT_CURR_UNIT_TYPE_ID AS DECIMAL(38,0)) PAYMENT_CURR_UNIT_TYPE_ID,
                           COMP_EARNING_GROUP_NAME,
                           BONUS_EARNING_GROUP_NAME,
                           CAST(ITEM_PAY_CURR_AMT AS DECIMAL(38,8)) ITEM_PAY_CURR_AMT,
                           CAST(ITEM_PAY_CURR_UNIT_TYPE_ID AS DECIMAL(38,0)) ITEM_PAY_CURR_UNIT_TYPE_ID,
                           CAST(ITEM_PAY_CONV_RATE AS DECIMAL(38,8)) ITEM_PAY_CONV_RATE,
                           CAST(BUS_GROUP_CONV_RATE AS DECIMAL(38,8)) BUS_GROUP_CONV_RATE,
                           CAST(BUS_CONVERSION_RATE AS DECIMAL(38,8)) BUS_CONVERSION_RATE,
                           IS_FINAL,
                           CAST(TRANS_ID AS DECIMAL(38,0)) TRANS_ID,
                           CAST(PRODUCT_ID AS DECIMAL(38,0)) PRODUCT_ID,
                           PRODUCT_NAME,
                           CAST(CUSTOMER_ID AS DECIMAL(38,0)) CUSTOMER_ID,
                           CUSTOMER_NAME,
                           CAST(GEOGRAPHY_ID AS DECIMAL(38,0)) GEOGRAPHY_ID,
                           GEOGRAPHY_NAME,
                           PAYMENT_FLAG,
                           EVER_ON_HOLD,
                           SRC_TYPE,
                           CAST(RUN_ID AS DECIMAL(38,0)) RUN_ID,
                           CAST(INCENTIVE_DATE AS string) INCENTIVE_DATE,
                           CAST(EFF_PARTICIPANT_ID AS DECIMAL(38,0)) EFF_PARTICIPANT_ID,
                           CAST(EFF_POSITION_ID AS DECIMAL(38,0)) EFF_POSITION_ID,
                           CAST(AMOUNT_BKUP AS DECIMAL(38,0)) AMOUNT_BKUP,
                           CAST(ITEM_PAY_CURR_AMT_BKUP AS DECIMAL(38,0)) ITEM_PAY_CURR_AMT_BKUP,
                           CAST(BUS_AMOUNT_BKUP AS DECIMAL(38,0)) BUS_AMOUNT_BKUP,
                           CAST(BUS_GROUP_AMOUNT_BKUP AS DECIMAL(38,0)) BUS_GROUP_AMOUNT_BKUP,
                           CAST(PAYMENT_CURR_AMOUNT_BKUP AS DECIMAL(38,0)) PAYMENT_CURR_AMOUNT_BKUP,
                           CAST(CREATED_DATE AS string) CREATED_DATE,
                           CAST(CREATED_BY_ID AS DECIMAL(38,0)) CREATED_BY_ID,
                           CREATED_BY_NAME,
                           CAST(MODIFIED_DATE AS string) MODIFIED_DATE,
                           CAST(MODIFIED_BY_ID AS DECIMAL(38,0)) MODIFIED_BY_ID,
                           MODIFIED_BY_NAME,
                           CAST(MGR_EFF_POS_ID AS DECIMAL(38,0)) MGR_EFF_POS_ID,
                           CAST(MGR_MASTER_POS_ID AS DECIMAL(38,0)) MGR_MASTER_POS_ID,
                           CAST(MGR_EFF_PART_ID AS DECIMAL(38,0)) MGR_EFF_PART_ID,
                           PROCESS_FILE,
                           PROCESS_DATE,
                           PROCESS_USER                                                     
                         FROM {target_catalog}.{target_bronze_schema}.{payment_bronze_tablename} 
                         WHERE PROCESS_DATE = '{latestProcessDate}' ''')

# COMMAND ----------

# MAGIC %md
# MAGIC Add fiscal attributes to the data extracted from bronze payments table

# COMMAND ----------

df_dates = spark.sql(f''' SELECT 
                              DISTINCT concat(upper(substring(monthName,0,3)), '-', string(year)) as DT_PERIOD_NAME, 
                              fiscal_month as FISCAL_MONTH, 
                              fy_quarter as FISCAL_QUARTER, 
                              fy_year as FISCAL_YEAR 
                          FROM main.it_core_dim.bi_dates''')
                          
df_payments_bronze = df_payments.join(df_dates,df_payments.PERIOD_NAME ==  df_dates.DT_PERIOD_NAME,"inner")
df_payments_bronze = df_payments_bronze.drop('date','DT_PERIOD_NAME')

df_payments_bronze.createOrReplaceTempView("payment_bronze")

# COMMAND ----------

# MAGIC %md
# MAGIC Extract latest data from silver payments table

# COMMAND ----------

df_payments_latest_silver = spark.sql(f'''
                                         
          SELECT *
          FROM {target_catalog}.{target_silver_schema}.{payment_silver_tablename}
          WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_silver_schema}.{payment_silver_tablename})
                                          
                                          ''')
                                          
df_payments_latest_silver.createOrReplaceTempView("payments_latest_silver")

# COMMAND ----------

# MAGIC %md
# MAGIC Check DISTINCT PERIOD_NAMES in bronze payments data

# COMMAND ----------

distinct_period_names = df_payments_bronze.select("PERIOD_NAME").distinct().rdd.flatMap(lambda x: x).collect()
distinct_period_names

# COMMAND ----------

# MAGIC %md
# MAGIC DELETE rows from latest Silver payments data which have PERIOD_NAMES same as above

# COMMAND ----------

# Filter rows in Silver where PERIOD_NAME is not in distinct_period_names_values

silver_filtered = df_payments_latest_silver.filter(~col("PERIOD_NAME").isin(distinct_period_names))

# COMMAND ----------

# MAGIC %md
# MAGIC Add Bronze payments data to filtered Silver payments data

# COMMAND ----------

silver_combined = silver_filtered.unionByName(df_payments_bronze)
silver_combined.createOrReplaceTempView("silver_combined")

# COMMAND ----------

# MAGIC %md
# MAGIC Update PROCESS_DATE with the current process date

# COMMAND ----------

silver_combined = silver_combined.drop("PROCESS_DATE","PROCESS_USER")
final_silver_combined, processDate = add_audit_attributes(silver_combined)
final_silver_combined = final_silver_combined.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_silver_combined.createOrReplaceTempView("final_silver_combined_table")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT PROCESS_DATE, COUNT(DISTINCT PERIOD_NAME), COUNT(*)
# MAGIC FROM final_silver_combined_table
# MAGIC GROUP BY PROCESS_DATE
# MAGIC ORDER BY PROCESS_DATE DESC

# COMMAND ----------

# MAGIC %md
# MAGIC Load the combined Silver payments Data into LogFood

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
full_silver_payments_tablename = f'{target_catalog}.{target_silver_schema}.{payment_silver_tablename}'

print (f'Updating data in {full_silver_payments_tablename} for {processDate}')

(final_silver_combined
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_silver_payments_tablename))

# COMMAND ----------


