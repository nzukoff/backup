# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_comp_order_item 
# MAGIC
# MAGIC Description: 
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Files are stored on FTP Location and then transfered to S3 bucket. This script extracts data from files stored on S3 bucket and loads into logFood.
# MAGIC - **Data Load** : If the current date is either 15th or 25th of a month, PTD files are loaded. MTD files are loaded daily on the rest days.
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC     - **Table Name** : xc_comp_order_item
# MAGIC       - **Description** : Contains Xactly xc_comp_order_item raw data
# MAGIC       - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC       - **Partition Column** : PROCESS_DATE

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import expr
from datetime import datetime, timedelta
from datetime import datetime, date
import pandas as pd
import urllib.request
import datetime
import urllib
import io
import boto3
import datetime
import subprocess

# COMMAND ----------

comp_order_bronze_tablename = 'xc_comp_order_item'
comp_order_silver_tablename = 'xc_comp_order_item'

PTD_xactly_s3_folder = 'PTD/xc_comp_order_item'
PTD_archive_s3_folder = 'PTD/processed_xc_comp_order_item'

MTD_xactly_s3_folder = 'MTD/xc_comp_order_item'
MTD_archive_s3_folder = 'MTD/processed_xc_comp_order_item'

# COMMAND ----------

target_catalog

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load data from files in S3 into LogFood

# COMMAND ----------

#Load data from S3 files into Raw Comp Order Item Table in LogFood

def process_s3_monthly_file(filename, table_to_be_loaded, s3_folder):

    access_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-access-key")
    secret_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-secret-key")
    spark.conf.set("fs.s3a.access.key", access_key)
    spark.conf.set("fs.s3a.secret.key", secret_key)

    aws_bucket_name = "xactly-ftp"
    aws_region = 'us-east-2'
    spark.conf.set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

    files = dbutils.fs.ls("s3a://" + aws_bucket_name + "/" + MTD_xactly_s3_folder + "/" + filename)
    file_path = files[0].path

    full_raw_table_name = f'{target_catalog}.{target_bronze_schema}.{table_to_be_loaded}'

    #Add process date and file name
    df_raw = spark.read.format("csv").option("header", "true").load(file_path)
    df_updated = df_column_whitespace(df_raw)
    spark_df = df_updated.withColumn("PROCESS_FILE", lit(filename))
    df_pre, processDate = add_audit_attributes(spark_df)

    df_pre = df_pre.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')

    df_pre.createOrReplaceTempView("df_pre")

    final_df_pre = spark.sql('''
      SELECT
        CAST(COMP_ORDER_ITEM_ID as DECIMAL(38,0)) COMP_ORDER_ITEM_ID,
        CAST(VERSION as float) VERSION,
        CAST(IS_ACTIVE AS STRING) AS IS_ACTIVE,
        ITEM_CODE,
        CAST(LINE_NUMBER as DECIMAL(38,0)) LINE_NUMBER,
        CAST(AMOUNT as DECIMAL(38,8)) AMOUNT,
        CAST(AMOUNT_UNIT_TYPE_ID as DECIMAL(38,0)) AMOUNT_UNIT_TYPE_ID,
        CAST(AMOUNT_PCT as DECIMAL(38,8)) AMOUNT_PCT,
        CAST(INCENTIVE_DATE as string) INCENTIVE_DATE,
        CAST(PERIOD_ID as DECIMAL(38,0)) PERIOD_ID,
        CAST(ORDER_DATE as string) ORDER_DATE,
        CAST(SOURCE_ID as DECIMAL(38,0)) SOURCE_ID,
        CAST(ORDER_TYPE_ID as DECIMAL(38,0)) ORDER_TYPE_ID,
        CAST(IS_PROCESSED AS STRING) AS IS_PROCESSED,
        CAST(DISCOUNT as DECIMAL(38,8)) DISCOUNT,
        CAST(QUANTITY as DECIMAL(38,0)) QUANTITY,
        CAST(PRODUCT_ID as DECIMAL(38,0)) PRODUCT_ID,
        PRODUCT_NAME,
        CAST(CUSTOMER_ID as DECIMAL(38,0)) CUSTOMER_ID,
        CUSTOMER_NAME,
        CAST(GEOGRAPHY_ID as DECIMAL(38,0)) GEOGRAPHY_ID,
        GEOGRAPHY_NAME,
        CAST(UPLOAD_ID as DECIMAL(38,0)) UPLOAD_ID,
        CAST(BATCH_NUMBER as DECIMAL(38,0)) BATCH_NUMBER,
        CAST(BATCH_ID as DECIMAL(38,0)) BATCH_ID,
        BATCH_NAME,
        RELATED_ORDER_CODE,
        RELATED_ITEM_CODE,
        CAST(RELATED_ITEM_ID as DECIMAL(38,0)) RELATED_ITEM_ID,
        ORDER_CODE,
        DESCR,
        ITEM_STATUS,
        CAST(STATUS_DATE as string) STATUS_DATE,
        CAST(SPLT_AMT_PCT_TOTAL as DECIMAL(38, 8)) SPLT_AMT_PCT_TOTAL,
        CAST(Evaluation_Stage_Date_Stamp__c as string) Evaluation_Stage_Date_Stamp__c,
        CAST(Validate_Stage_Date as string) Validate_Stage_Date,
        CAST(Prospecting_Stage_Date_Stamp__c as string) Prospecting_Stage_Date_Stamp__c,
        CAST(Close_Won_Date_Original_Opportunity as string) Close_Won_Date_Original_Opportunity,
        CAST(POC_Scoping_Date_Stamp as string) POC_Scoping_Date_Stamp,
        CAST(Original_Expected_Renewal_Date as string) Original_Expected_Renewal_Date,
        Platform_Type,
        Type,
        Sub_Region,
        SDR,
        Product_Family,
        Partner_Impact,
        Opportunity_Name,
        Original_Opportunity_ID,
        New_Business_Rep,
        BD_Rep,
        Billing_Schedule,
        ARR_Renewal_Amt,
        Auto_Renewal,
        Create_Date,
        SDR_Stage,
        CAST(Term__c AS STRING) AS Term__c,
        Azure_Sales_Team,
        SDR_Points,
        AWS_New_Logo,
        Azure_New_Logo,
        Account_Partner,
        Upsell_Type,
        Databricks_Vertical_Map,
        Owner_Role,
        Horizontal_Solution,
        Subscription_Total_UnitType,
        Account_Partner_Type,
        Partner_Account_Account_Name,
        Business_Development_Rep,
        AWS_Marketplace_Deal,
        NAFR,
        Partner_Type,
        New_Logo_All,
        SCP_Status,
        Approval_Status,
        Horizontal_Cyber_Security,
        Business_Unit,
        Region_Level_1,
        Region_Level_2,
        Region_Level_3,
        Territory,
        Azure_Territory_Director,
        GCP_Territory_Director,
        Horizontal_Hadoop_Migration,
        Regional_BDR,
        Named_BDR,
        Cloud_BDR,
        SFDC_Role,
        AWS_Territory_Director,
        Region2_Level_1,
        databricks_vertical_segment,
        CAST(Term as DECIMAL(38,8)) Term,
        CAST(TCV as DECIMAL(38, 8)) TCV,
        CAST(Subscription_Total as DECIMAL(38, 8)) Subscription_Total,
        CAST(Delta_DBUs_vs_Total_DBUs as DECIMAL(38,0)) Delta_DBUs_vs_Total_DBUs,
        CAST(Delta_RevShareDollars as DECIMAL(38, 8)) Delta_RevShareDollars,
        CAST(Non_Delta_RevShareDollars as DECIMAL(38, 8)) Non_Delta_RevShareDollars,
        CAST(Incremental_Amount as DECIMAL(38, 8)) Incremental_Amount,
        CAST(Renewal_Amount as DECIMAL(38, 8)) Renewal_Amount,
        CAST(Total_Comm_Incremental_Consumption as DECIMAL(38, 8)) Total_Comm_Incremental_Consumption,
        CAST(Total_Comm_Delta_Incremental_Consumption as DECIMAL(38, 8)) Total_Comm_Delta_Incremental_Consumption,
        CAST(Total_Comm_SQL_Incremental_Consumption as DECIMAL(38, 8)) Total_Comm_SQL_Incremental_Consumption,
        CAST(Total_AWS_Comm_Incremental_Consumption as DECIMAL(38, 8)) Total_AWS_Comm_Incremental_Consumption,
        CAST(Total_AWS_Comm_Delta_Incremental_Consumption as DECIMAL(38, 8)) Total_AWS_Comm_Delta_Incremental_Consumption,
        CAST(Total_AWS_Comm_SQL_Incremental_Consumption as DECIMAL(38, 8)) Total_AWS_Comm_SQL_Incremental_Consumption,
        CAST(Total_Azure_Comm_Incremental_Consumption as DECIMAL(38, 8)) Total_Azure_Comm_Incremental_Consumption,
        CAST(Total_Azure_Comm_Delta_Incremental_Consumption as DECIMAL(38, 8)) Total_Azure_Comm_Delta_Incremental_Consumption,
        CAST(Total_Azure_Comm_SQL_Incremental_Consumption as DECIMAL(38, 8)) Total_Azure_Comm_SQL_Incremental_Consumption,
        CAST(Total_GCP_Comm_Incremental_Consumption as DECIMAL(38, 8)) Total_GCP_Comm_Incremental_Consumption,
        CAST(Total_GCP_Comm_Delta_Incremental_Consumption as DECIMAL(38, 8))Total_GCP_Comm_Delta_Incremental_Consumption,
        CAST(Total_GCP_Comm_SQL_Incremental_Consumption as DECIMAL(38, 8))Total_GCP_Comm_SQL_Incremental_Consumption,
        CAST(Total_Comm_ISV_Incremental_Consumption as DECIMAL(38, 8))Total_Comm_ISV_Incremental_Consumption,
        CAST(Total_AWS_Comm_ISV_Incremental_Consumption as DECIMAL(38, 8))Total_AWS_Comm_ISV_Incremental_Consumption,
        CAST(Total_Azure_Comm_ISV_Incremental_Consumption as DECIMAL(38, 8))Total_Azure_Comm_ISV_Incremental_Consumption,
        CAST(Total_GCP_Comm_ISV_Incremental_Consumption as DECIMAL(38, 8))Total_GCP_Comm_ISV_Incremental_Consumption,
        CAST(Mooncake_Comm_Incremental_Consumption as DECIMAL(38, 8))Mooncake_Comm_Incremental_Consumption,
        CAST(Mooncake_Delta_Incremental_Consumption as DECIMAL(38, 8))Mooncake_Delta_Incremental_Consumption,
        CAST(Mooncake_SQL_Incremental_Consumption as DECIMAL(38, 8))Mooncake_SQL_Incremental_Consumption,
        CAST(Rollover_Percent as DECIMAL(38,0))Rollover_Percent,
        CAST(Renewal_Days_Late as DECIMAL(38,0))Renewal_Days_Late,
        CAST(Total_AWS_Comm_DLT_Incremental_Consumption as DECIMAL(38, 8)) Total_AWS_Comm_DLT_Incremental_Consumption,
        CAST(Total_Azure_Comm_DLT_Incremental_Consumption as DECIMAL(38, 8))Total_Azure_Comm_DLT_Incremental_Consumption,
        CAST(Total_Comm_DLT_Incremental_Consumption as DECIMAL(38, 8))Total_Comm_DLT_Incremental_Consumption,
        CAST(Total_GCP_Comm_DLT_Incremental_Consumption as DECIMAL(38, 8))Total_GCP_Comm_DLT_Incremental_Consumption,
        
        CAST(Total_AWS_Comm_UC_Incremental_Consumption as DECIMAL(38, 8)) Total_AWS_Comm_UC_Incremental_Consumption,
        CAST(Mooncake_UC_Incremental_Consumption as DECIMAL(38, 8)) Mooncake_UC_Incremental_Consumption,
        CAST(Total_Azure_Comm_UC_Incremental_Consumption as DECIMAL(38, 8)) Total_Azure_Comm_UC_Incremental_Consumption,
        CAST(Total_Comm_UC_Incremental_Consumption as DECIMAL(38, 8)) Total_Comm_UC_Incremental_Consumption,
        CAST(Total_GCP_Comm_UC_Incremental_Consumption as DECIMAL(38, 8)) Total_GCP_Comm_UC_Incremental_Consumption,
        CAST(Mooncake_DLT_Incremental_Consumption as DECIMAL(38, 8)) Mooncake_DLT_Incremental_Consumption,
        
        CAST(Mooncake_GenAI_Incremental_Consumption as DECIMAL(38,8))
        Mooncake_GenAI_Incremental_Consumption,
        CAST(Total_AWS_Comm_GenAI_Incremental_Consumption as DECIMAL(38,8))
        Total_AWS_Comm_GenAI_Incremental_Consumption,
        CAST(Total_Azure_Comm_GenAI_Incremental_Consumption as DECIMAL(38,8))
        Total_Azure_Comm_GenAI_Incremental_Consumption,
        CAST(Total_Comm_GenAI_Incremental_Consumption as DECIMAL(38,8))
        Total_Comm_GenAI_Incremental_Consumption,
        CAST(Total_GCP_Comm_GenAI_Incremental_Consumption as DECIMAL(38,8))
        Total_GCP_Comm_GenAI_Incremental_Consumption,
        CAST(Total_Comm_GenAI_MCT_Incremental_Consumption AS DECIMAL(38,8)) 
          Total_Comm_GenAI_MCT_Incremental_Consumption,
        CAST(Total_Comm_GenAI_NonMCT_Incremental_Consumption AS DECIMAL(38,8)) 
          Total_Comm_GenAI_NonMCT_Incremental_Consumption,

        CAST(Total_Comm_LakeflowConnect_Incremental_Consumption as DECIMAL(38,0)) Total_Comm_LakeflowConnect_Incremental_Consumption,
        CAST(Total_Comm_LakeflowPipeline_Incremental_Consumption as DECIMAL(38,0)) Total_Comm_LakeflowPipeline_Incremental_Consumption,
        CAST(Total_AWS_Comm_LakeflowConnect_Incremental_Consumption as DECIMAL(38,0)) Total_AWS_Comm_LakeflowConnect_Incremental_Consumption,
        CAST(Total_AWS_Comm_LakeflowPipeline_Incremental_Consumption as DECIMAL(38,0)) Total_AWS_Comm_LakeflowPipeline_Incremental_Consumption,
        CAST(Total_Azure_Comm_LakeflowConnect_Incremental_Consumption as DECIMAL(38,0)) Total_Azure_Comm_LakeflowConnect_Incremental_Consumption,
        CAST(Total_Azure_Comm_LakeflowPipeline_Incremental_Consumption as DECIMAL(38,0)) Total_Azure_Comm_LakeflowPipeline_Incremental_Consumption,
        CAST(Total_GCP_Comm_LakeflowConnect_Incremental_Consumption as DECIMAL(38,0)) Total_GCP_Comm_LakeflowConnect_Incremental_Consumption,
        CAST(Total_GCP_Comm_LakeflowPipeline_Incremental_Consumption as DECIMAL(38,0)) Total_GCP_Comm_LakeflowPipeline_Incremental_Consumption,

        CAST(Total_Comm_Lakebase_Incremental_Consumption as DECIMAL(38,0)) Total_Comm_Lakebase_Incremental_Consumption,

        CAST(booking_arr as DECIMAL(38,0)) booking_arr,

        CAST(Term_UnitTypeId as DECIMAL(38,0))Term_UnitTypeId,
        CAST(TCV_UnitTypeId as DECIMAL(38,0)) TCV_UnitTypeId,
        CAST(Subscription_Total_UnitTypeId as DECIMAL(38,0))Subscription_Total_UnitTypeId,
        CAST(Delta_DBUs_vs_Total_DBUs_UnitTypeId as DECIMAL(38,0))Delta_DBUs_vs_Total_DBUs_UnitTypeId,
        CAST(Delta_RevShareDollars_UnitTypeId as DECIMAL(38,0))Delta_RevShareDollars_UnitTypeId,
        CAST(Non_Delta_RevShareDollars_UnitTypeId as DECIMAL(38,0))Non_Delta_RevShareDollars_UnitTypeId,
        CAST(Incremental_Amount_UnitTypeId as DECIMAL(38,0))Incremental_Amount_UnitTypeId,
        CAST(Renewal_Amount_UnitTypeId as DECIMAL(38,0))Renewal_Amount_UnitTypeId,
        CAST(Total_Comm_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_Comm_Incremental_Consumption_UnitTypeId,
        CAST(Total_Comm_Delta_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_Comm_Delta_Incremental_Consumption_UnitTypeId,
        CAST(Total_Comm_SQL_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_Comm_SQL_Incremental_Consumption_UnitTypeId,
        CAST(Total_AWS_Comm_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_AWS_Comm_Incremental_Consumption_UnitTypeId,
        CAST(Total_AWS_Comm_Delta_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_AWS_Comm_Delta_Incremental_Consumption_UnitTypeId,
        CAST(Total_AWS_Comm_SQL_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_AWS_Comm_SQL_Incremental_Consumption_UnitTypeId,
        CAST(Total_Azure_Comm_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_Azure_Comm_Incremental_Consumption_UnitTypeId,
        CAST(Total_Azure_Comm_Delta_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_Azure_Comm_Delta_Incremental_Consumption_UnitTypeId,
        CAST(Total_Azure_Comm_SQL_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_Azure_Comm_SQL_Incremental_Consumption_UnitTypeId,
        CAST(Total_GCP_Comm_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_GCP_Comm_Incremental_Consumption_UnitTypeId,
        CAST(Total_GCP_Comm_Delta_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_GCP_Comm_Delta_Incremental_Consumption_UnitTypeId,
        CAST(Total_GCP_Comm_SQL_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_GCP_Comm_SQL_Incremental_Consumption_UnitTypeId,
        CAST(Total_Comm_ISV_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_Comm_ISV_Incremental_Consumption_UnitTypeId,
        CAST(Total_AWS_Comm_ISV_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_AWS_Comm_ISV_Incremental_Consumption_UnitTypeId,
        CAST(Total_Azure_Comm_ISV_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_Azure_Comm_ISV_Incremental_Consumption_UnitTypeId,
        CAST(Total_GCP_Comm_ISV_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_GCP_Comm_ISV_Incremental_Consumption_UnitTypeId,
        CAST(Mooncake_Comm_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Mooncake_Comm_Incremental_Consumption_UnitTypeId,
        CAST(Mooncake_Delta_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Mooncake_Delta_Incremental_Consumption_UnitTypeId,
        CAST(Mooncake_SQL_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Mooncake_SQL_Incremental_Consumption_UnitTypeId,
        CAST(Rollover_Percent_UnitTypeId as DECIMAL(38,0))Rollover_Percent_UnitTypeId,
        CAST(Renewal_Days_Late_UnitTypeId as DECIMAL(38,0))Renewal_Days_Late_UnitTypeId,
        CAST(Total_AWS_Comm_DLT_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_AWS_Comm_DLT_Incremental_Consumption_UnitTypeId,
        CAST(Total_Azure_Comm_DLT_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_Azure_Comm_DLT_Incremental_Consumption_UnitTypeId,
        CAST(Total_Comm_DLT_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))Total_Comm_DLT_Incremental_Consumption_UnitTypeId,
        CAST(Total_GCP_Comm_DLT_Incremental_Consumption_UnitTypeId as DECIMAL(38,0)) Total_GCP_Comm_DLT_Incremental_Consumption_UnitTypeId,

        CAST(Total_AWS_Comm_UC_Incremental_Consumption_UnitTypeId as string) Total_AWS_Comm_UC_Incremental_Consumption_UnitTypeId, 
        CAST(Mooncake_UC_Incremental_Consumption_UnitTypeId as string) Mooncake_UC_Incremental_Consumption_UnitTypeId,
        CAST(Total_Azure_Comm_UC_Incremental_Consumption_UnitTypeId as string) Total_Azure_Comm_UC_Incremental_Consumption_UnitTypeId,
        CAST(Total_Comm_UC_Incremental_Consumption_UnitTypeId as string) Total_Comm_UC_Incremental_Consumption_UnitTypeId,
        CAST(Total_GCP_Comm_UC_Incremental_Consumption_UnitTypeId as string) Total_GCP_Comm_UC_Incremental_Consumption_UnitTypeId,
        CAST(Mooncake_DLT_Incremental_Consumption_UnitTypeId as string) Mooncake_DLT_Incremental_Consumption_UnitTypeId,

        CAST(Mooncake_GenAI_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))
        Mooncake_GenAI_Incremental_Consumption_UnitTypeId,
        CAST(Total_AWS_Comm_GenAI_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))
        Total_AWS_Comm_GenAI_Incremental_Consumption_UnitTypeId,
        CAST(Total_Azure_Comm_GenAI_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))
        Total_Azure_Comm_GenAI_Incremental_Consumption_UnitTypeId,
        CAST(Total_Comm_GenAI_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))
        Total_Comm_GenAI_Incremental_Consumption_UnitTypeId,
        CAST(Total_GCP_Comm_GenAI_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))
        Total_GCP_Comm_GenAI_Incremental_Consumption_UnitTypeId,
        CAST(Total_Comm_GenAI_MCT_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))
          Total_Comm_GenAI_MCT_Incremental_Consumption_UnitTypeId,
        CAST(Total_Comm_GenAI_NonMCT_Incremental_Consumption_UnitTypeId as DECIMAL(38,0))
        Total_Comm_GenAI_NonMCT_Incremental_Consumption_UnitTypeId,

        CAST(Total_Comm_LakeflowConnect_Incremental_Consumption_UnitTypeId as DECIMAL(38,0)) Total_Comm_LakeflowConnect_Incremental_Consumption_UnitTypeId,
        CAST(Total_Comm_LakeflowPipeline_Incremental_Consumption_UnitTypeId as DECIMAL(38,0)) Total_Comm_LakeflowPipeline_Incremental_Consumption_UnitTypeId,
        CAST(Total_AWS_Comm_LakeflowConnect_Incremental_Consumption_UnitTypeId as DECIMAL(38,0)) Total_AWS_Comm_LakeflowConnect_Incremental_Consumption_UnitTypeId,
        CAST(Total_AWS_Comm_LakeflowPipeline_Incremental_Consumption_UnitTypeId as DECIMAL(38,0)) Total_AWS_Comm_LakeflowPipeline_Incremental_Consumption_UnitTypeId,
        CAST(Total_Azure_Comm_LakeflowConnect_Incremental_Consumption_UnitTypeId as DECIMAL(38,0)) Total_Azure_Comm_LakeflowConnect_Incremental_Consumption_UnitTypeId,
        CAST(Total_Azure_Comm_LakeflowPipeline_Incremental_Consumption_UnitTypeId as DECIMAL(38,0)) Total_Azure_Comm_LakeflowPipeline_Incremental_Consumption_UnitTypeId,
        CAST(Total_GCP_Comm_LakeflowConnect_Incremental_Consumption_UnitTypeId as DECIMAL(38,0)) Total_GCP_Comm_LakeflowConnect_Incremental_Consumption_UnitTypeId,
        CAST(Total_GCP_Comm_LakeflowPipeline_Incremental_Consumption_UnitTypeId as DECIMAL(38,0)) Total_GCP_Comm_LakeflowPipeline_Incremental_Consumption_UnitTypeId,

        CAST(Total_Comm_Lakebase_Incremental_Consumption_UnitTypeId as DECIMAL(38,0)) Total_Comm_Lakebase_Incremental_Consumption_UnitTypeId,

        CAST(booking_arr_UnitTypeId as string) booking_arr_UnitTypeId,

        CAST(GEOGRAPHY_ID as string) CREATED_DATE,
        CAST(CREATED_BY_ID as DECIMAL(38,0)) CREATED_BY_ID,
        CREATED_BY_NAME,
        CAST(GEOGRAPHY_ID as string) MODIFIED_DATE,
        CAST(MODIFIED_BY_ID as DECIMAL(38,0)) MODIFIED_BY_ID,
        MODIFIED_BY_NAME,
        Region2_Level_2,
        Region2_Level_3,
        Territory2,
        CAST(Rollup_Flag AS STRING) AS Rollup_Flag,
        CAST(Flag_Interim_Coverage AS STRING) AS Flag_Interim_Coverage,
        CAST(Flag_Renewal_Downsell AS STRING) AS Flag_Renewal_Downsell,
        Region_Level_4,
        CAST(Mooncake AS STRING) AS Mooncake,
        CAST(Flag_Net_Negative AS STRING) AS Flag_Net_Negative,
        Account_Type,
        GSC_Code,
        PROCESS_DATE,
        PROCESS_FILE,
        PROCESS_USER
          
      FROM df_pre
    ''')

    print (f'Updating data in {full_raw_table_name} for {filename}')
    (final_df_pre
      .write
      .mode("overwrite")
      .format('delta')
      .option("mergeSchema", "true")
      .option('replaceWhere', f"PROCESS_FILE = '{filename}' and PROCESS_DATE = '{processDate}' ")
      .partitionBy("PROCESS_DATE") 
      .saveAsTable(full_raw_table_name))

# COMMAND ----------

# Display the files transfered to S3

files = list_of_files(MTD_xactly_s3_folder)
files

# COMMAND ----------

# Extract all the files from S3 and load into bronze xc_comp_order_item

files = list_of_files(MTD_xactly_s3_folder)
table = comp_order_bronze_tablename 

if len(files) == 0:
  raise Exception("There are no Comp Order Item MTD files present on FTP Location!!")
else:
  for each in files:
    print('Processing file ' + each)
    try : 
      process_s3_monthly_file(each, table, MTD_xactly_s3_folder)
    except : 
      print('Processing of '+ each + ' file failed!')

# COMMAND ----------

#Transfer files to processed folder in S3

files = list_of_files(MTD_xactly_s3_folder)

if len(files) == 0 :
  print('No files to be copied over today')
else :
  print('Files loaded - now moving xactly files to archive')
  copy_to_archive (MTD_xactly_s3_folder, MTD_archive_s3_folder)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Data Quality Checks: Bronze -> Silver Data

# COMMAND ----------

#Check if there are different months(PERIOD_ID) under same file name

duplicate_period_check = spark.sql(f"""
  SELECT PROCESS_DATE, PROCESS_FILE, COUNT(DISTINCT PERIOD_ID) as distinct_period_names
  FROM {target_catalog}.{target_bronze_schema}.{comp_order_bronze_tablename}
  GROUP BY PROCESS_DATE, PROCESS_FILE
  HAVING COUNT(*)>1
""")

if not duplicate_period_check:
  raise Exception("There is multiple periods data under single file name!!")

# COMMAND ----------

#Check if the current and prior month's data is present in bronze table

current_date = datetime.datetime.now()
processDate = current_date.strftime('%Y-%m-%d')

current_month_output = current_date.strftime("%Y-%m")

previous_month_date = current_date - timedelta(days=current_date.day)
previous_month_output = previous_month_date.strftime("%Y-%m")

query = f"""
    SELECT COUNT(*)
    FROM {target_catalog}.{target_bronze_schema}.{comp_order_bronze_tablename}
    WHERE PROCESS_DATE = '{processDate}'
    AND SUBSTRING(INCENTIVE_DATE, 0, 7) IN ('{current_month_output}', '{previous_month_output}')
"""

result = spark.sql(query).collect()[0][0]

if result <= 0:
    raise Exception(f"0 Records found for {current_month_output} and/or {previous_month_output}")
