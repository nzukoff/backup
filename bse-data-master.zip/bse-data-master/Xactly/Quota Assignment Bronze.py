# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_quota_assignment 
# MAGIC
# MAGIC Description: 
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Files are stored on FTP Location and then transfered to S3 bucket. This script extracts data from files stored on S3 bucket and loads into logFood.
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC     - **Table Name** : xc_quota_assignment
# MAGIC       - **Description** : Contains Xactly xc_quota_assignment raw data
# MAGIC       - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC       - **Partition Column** : PROCESS_DATE

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import expr
from datetime import datetime, timedelta
from datetime import datetime, date
import pandas as pd
import urllib.request
import datetime
import urllib
import io
import boto3
import datetime
import subprocess

# COMMAND ----------

quota_bronze_tablename = 'xc_quota_assignment'
quota_silver_tablename = 'xc_quota_assignment'

xactly_s3_folder = 'MTD/xc_quota_assignment'
archive_s3_folder = 'MTD/processed_xc_quota_assignment'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Files Transfer from FTP to S3

# COMMAND ----------

# MAGIC %sh
# MAGIC rm -f $HOME/rclone

# COMMAND ----------

# MAGIC %sh curl -o /tmp/rclone.zip https://downloads.rclone.org/rclone-current-linux-arm64.zip

# COMMAND ----------

# MAGIC %sh sh -c 'cd /tmp; unzip -o rclone.zip; cp rclone*arm64/rclone $HOME; chmod +x $HOME/rclone'

# COMMAND ----------

import datetime

quota_ass_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/logfood/xc_quota_assignment/main aws_s3_xactly:/xactly-ftp/MTD/xc_quota_assignment/ -v"

quota_ass_COPY_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf copy sftp_xactly:/logfood/xc_quota_assignment/main sftp_xactly:/logfood/xc_quota_assignment/archive -v"

quota_ass_DELETE_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf delete sftp_xactly:/logfood/xc_quota_assignment/main"

# SYNC files stored in MAIN folder on FTP location to Amazon S3
subprocess.run(
  quota_ass_SYNC_command,
  shell=True,
  stdout=subprocess.PIPE,
  stderr=subprocess.PIPE,
  text=True,
  check=True,
)
print("Files transfered from Main FTP to S3")

# COPY files from MAIN folder to ARCHIVE folder on FTP location
subprocess.run(
  quota_ass_COPY_command,
  shell=True,
  stdout=subprocess.PIPE,
  stderr=subprocess.PIPE,
  text=True,
  check=True,
)
print("Files copied from Main FTP to Archive FTP")

# DELETE files in MAIN folder on FTP Location
subprocess.run(
  quota_ass_DELETE_command,
  shell=True,
  stdout=subprocess.PIPE,
  stderr=subprocess.PIPE,
  text=True,
  check=True,
)
print("Files deleted from Main FTP")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load data from files in S3 into LogFood

# COMMAND ----------

#Load data from S3 files into Raw Quota Assignment Table in LogFood

def process_s3_monthly_file(filename, table_to_be_loaded):

    access_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-access-key")
    secret_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-secret-key")
    spark.conf.set("fs.s3a.access.key", access_key)
    spark.conf.set("fs.s3a.secret.key", secret_key)

    aws_bucket_name = "xactly-ftp"
    aws_region = 'us-east-2'
    spark.conf.set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

    files = dbutils.fs.ls("s3a://" + aws_bucket_name + "/" + xactly_s3_folder + "/" + filename)
    file_path = files[0].path

    full_raw_table_name = f'{target_catalog}.{target_bronze_schema}.{table_to_be_loaded}'

    #Add process date and file name
    df_raw = spark.read.format("csv").option("header", "true").load(file_path)
    df_updated = df_column_whitespace(df_raw)
    spark_df = df_updated.withColumn("PROCESS_FILE", lit(filename))
    df_pre, processDate = add_audit_attributes(spark_df)

    df_pre = df_pre.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')

    df_pre.createOrReplaceTempView("df_pre")

    final_df_pre = spark.sql(''' 
                             SELECT
                                CAST(QUOTA_ASSIGNMENT_ID as DECIMAL(38,0)) QUOTA_ASSIGNMENT_ID,
                                CAST(VERSION as DECIMAL(38,0)) VERSION,
                                CAST(ASSIGNMENT_ID as DECIMAL(38,0)) ASSIGNMENT_ID,
                                ASSIGNMENT_NAME,
                                CAST(ASSIGNMENT_TYPE as DECIMAL(38,0)) ASSIGNMENT_TYPE,
                                CAST(AMOUNT as DECIMAL(38,8)) AMOUNT,
                                CAST(AMOUNT_UNIT_TYPE_ID as DECIMAL(38,0)) AMOUNT_UNIT_TYPE_ID,
                                CAST(PERIOD_ID as DECIMAL(38,0)) PERIOD_ID,
                                CAST(QUOTA_ID as DECIMAL(38,0)) QUOTA_ID,
                                CAST(EFFECTIVE_START_PERIOD_ID as DECIMAL(38,0)) EFFECTIVE_START_PERIOD_ID,
                                CAST(EFFECTIVE_END_PERIOD_ID as DECIMAL(38,0)) EFFECTIVE_END_PERIOD_ID,
                                IS_ACTIVE,
                                DESCRIPTION,
                                CREATED_DATE,
                                CAST(CREATED_BY_ID as DECIMAL(38,0)) CREATED_BY_ID,
                                CREATED_BY_NAME,
                                MODIFIED_DATE,
                                CAST(MODIFIED_BY_ID as DECIMAL(38,0)) MODIFIED_BY_ID,
                                MODIFIED_BY_NAME,
                                QTA_ASGNMT_ID,
                                CAST(Annual_Prorated_OTI as DECIMAL(38,8)) Annual_Prorated_OTI,
                                CAST(Annual_Prorated_OTI_unit_type_id as DECIMAL(38,0))  Annual_Prorated_OTI_unit_type_id,
                                Duration,
                                CAST(Effective_OTI as DECIMAL(38,8)) Effective_OTI,
                                CAST(Effective_OTI_unit_type_id as DECIMAL(38,0)) Effective_OTI_unit_type_id,
                                CAST(H_One_Prorated_OTI as DECIMAL(38,8)) H_One_Prorated_OTI,
                                CAST(H_One_Prorated_OTI_unit_type_id as DECIMAL(38,0)) H_One_Prorated_OTI_unit_type_id,
                                CAST(H_Two_Prorated_OTI as DECIMAL(38,8)) H_Two_Prorated_OTI,
                                CAST(H_Two_Prorated_OTI_unit_type_id as DECIMAL(38,0)) H_Two_Prorated_OTI_unit_type_id,
                                CAST(OTI_Weight as DECIMAL(38,0)) OTI_Weight,
                                CAST(OTI_Weight_unit_type_id as DECIMAL(38,0)) OTI_Weight_unit_type_id,
                                Payout_Frequency,
                                PROCESS_DATE,
                                PROCESS_FILE,
                                PROCESS_USER
                              from df_pre
                             ''')

    print (f'Updating data in {full_raw_table_name} for {filename}')
    (final_df_pre
      .write
      .mode("overwrite")
      .format('delta')
      .option('mergeSchema', 'true')
      .option('replaceWhere', f"PROCESS_FILE = '{filename}' and PROCESS_DATE = '{processDate}' ")
      .partitionBy("PROCESS_DATE") 
      .saveAsTable(full_raw_table_name))

# COMMAND ----------

# Display the files transfered to S3

files = list_of_files(xactly_s3_folder)
files

# COMMAND ----------

#Extract all the file names from S3 and load into xc_quota_assignment

files = list_of_files(xactly_s3_folder)
table = quota_bronze_tablename 

if len(files) == 0 :
  print('No files to be processed today')
else :
  for each in files:
    print('Processing file ' + each)
    try : 
      process_s3_monthly_file(each, table)
    except : 
      print('Processing of '+ each + ' file failed!')

# COMMAND ----------

# Move the files to processed folder on S3

files = list_of_files(xactly_s3_folder)
if len(files) == 0 :
  print('No files to be copied over today')
else :
  print('Files loaded - now moving xactly files to archive')
  copy_to_archive (xactly_s3_folder, archive_s3_folder)

# COMMAND ----------


