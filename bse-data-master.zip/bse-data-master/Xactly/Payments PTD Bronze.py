# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql.functions import expr
from datetime import datetime, timedelta
from datetime import datetime, date
import pandas as pd
import urllib.request
import datetime
import urllib
import io
import boto3
import datetime
import subprocess

# COMMAND ----------

payment_bronze_tablename = 'xc_payment'
payment_silver_tablename = 'xc_payment'

PTD_xactly_s3_folder = 'PTD/xc_payment'
PTD_archive_s3_folder = 'PTD/processed_xc_payment'

MTD_xactly_s3_folder = 'MTD/xc_payment'
MTD_archive_s3_folder = 'MTD/processed_xc_payment'

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

target_catalog

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load data from files in S3 into LogFood

# COMMAND ----------

#Load data from S3 files into Raw Payments Table in LogFood

def process_s3_monthly_file(filename, table_to_be_loaded, s3_folder):

  access_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-access-key")
  secret_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-secret-key")
  spark.conf.set("fs.s3a.access.key", access_key)
  spark.conf.set("fs.s3a.secret.key", secret_key)

  aws_bucket_name = "xactly-ftp"
  aws_region = 'us-east-2'
  spark.conf.set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

  files = dbutils.fs.ls("s3a://" + aws_bucket_name + "/" + PTD_xactly_s3_folder + "/" + filename)
  file_path = files[0].path

  full_raw_table_name = f'{target_catalog}.{target_bronze_schema}.{table_to_be_loaded}'

  #Add process date and file name
  df_raw = spark.read.format("csv").option("header", "true").load(file_path)
  df_updated = df_column_whitespace(df_raw)
  spark_df = df_updated.withColumn("PROCESS_FILE", lit(filename))
  final_df_pre, processDate = add_audit_attributes(spark_df)
  final_df_pre.createOrReplaceTempView("xactly_data")

  final_df_pre = final_df_pre.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')

  print (f'Updating data in {full_raw_table_name} for {filename}')
  (final_df_pre
    .write
    .mode("overwrite")
    .format('delta')
    .option("overwriteSchema", "true")
    .option('replaceWhere', f"PROCESS_FILE = '{filename}' and PROCESS_DATE = '{processDate}' ")
    .partitionBy("PROCESS_DATE") 
    .saveAsTable(full_raw_table_name))

# COMMAND ----------

# Display the files transfered to S3

files = list_of_files(PTD_xactly_s3_folder)
files

# COMMAND ----------

# Extract all the files from S3 and load into bronze xc_commission

files = list_of_files(PTD_xactly_s3_folder)
table = payment_bronze_tablename 

if len(files) == 0:
  raise Exception("There are no Payments PTD files present on FTP Location!!")
else:
  for each in files:
    print('Processing file ' + each)
    try : 
      process_s3_monthly_file(each, table, PTD_xactly_s3_folder)
    except : 
      print('Processing of '+ each + ' file failed!')

# COMMAND ----------

#Transfer files to processed folder in S3

files = list_of_files(PTD_xactly_s3_folder)

if len(files) == 0 :
  print('No files to be copied over today')
else :
  print('Files loaded - now moving xactly files to archive')
  copy_to_archive (PTD_xactly_s3_folder, PTD_archive_s3_folder)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are different months(PERIOD_NAME) under same file name

duplicate_period_check = spark.sql(f"""
  SELECT PROCESS_DATE, PROCESS_FILE, COUNT(*) as number_of_duplicate_records
  FROM {target_catalog}.{target_bronze_schema}.{payment_bronze_tablename}
  GROUP BY PROCESS_DATE, PROCESS_FILE
  HAVING COUNT(*)>1
""")

if not duplicate_period_check:
  raise Exception("There is multiple periods data under single file name!!")

# COMMAND ----------


