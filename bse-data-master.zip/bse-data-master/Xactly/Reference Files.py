# Databricks notebook source
# MAGIC %run "./config_xc_report"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import expr
from datetime import datetime, date
import datetime
import subprocess
import urllib
import urllib.request
import io
import pandas as pd
import boto3

# COMMAND ----------

# MAGIC %sh
# MAGIC rm -f $HOME/rclone

# COMMAND ----------

# MAGIC %sh curl -o /tmp/rclone.zip https://downloads.rclone.org/rclone-current-linux-arm64.zip

# COMMAND ----------

# MAGIC %sh sh -c 'cd /tmp; unzip -o rclone.zip; cp rclone*arm64/rclone $HOME; chmod +x $HOME/rclone'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Trailer File

# COMMAND ----------

import datetime

comp_cat_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/logfood/trailer aws_s3_xactly:/xactly-ftp/Reference_Files/trailer_file/ -v"

# SYNC files stored in MAIN folder on FTP location to Amazon S3
subprocess.run(
  comp_cat_SYNC_command,
  shell=True,
  stdout=subprocess.PIPE,
  stderr=subprocess.PIPE,
  text=True,
  check=True,
)
print("Files transfered from Main FTP to S3")

# COMMAND ----------

raw_target_tablename_monthly = 'Finalize_Close_Month_Status'
xactly_s3_folder = 'Reference_Files/trailer_file'
archive_s3_folder = 'Reference_Files/processed_trailer_file'

# COMMAND ----------

#Load data from S3 files into Raw Commissions Table in LogFood

def process_s3_monthly_file(filename, table_to_be_loaded):

    access_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-access-key")
    secret_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-secret-key")
    spark.conf.set("fs.s3a.access.key", access_key)
    spark.conf.set("fs.s3a.secret.key", secret_key)

    aws_bucket_name = "xactly-ftp"
    aws_region = 'us-east-2'
    spark.conf.set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

    files = dbutils.fs.ls("s3a://" + aws_bucket_name + "/" + xactly_s3_folder + "/" + filename)
    file_path = files[0].path

    full_raw_table_name = f'{target_catalog}.{target_silver_schema}.{table_to_be_loaded}'

    #Add process date and file name
    df_raw = spark.read.format("csv").option("header", "true").load(file_path)
    df_updated = df_column_whitespace(df_raw)
    spark_df = df_updated.withColumn("PROCESS_FILE", lit(filename))
    df_pre, processDate = add_audit_attributes(spark_df)

    df_pre = df_pre.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')

    df_pre.createOrReplaceTempView("df_pre")

    final_df_pre = spark.sql('''
                            SELECT  CAST(period_name as STRING) AS PERIOD_NAME,
                                    PERIOD_STATUS,
                                    CAST(LATEST_PRELIM_LOAD_DATE as STRING) AS LATEST_PRELIM_LOAD_DATE,
                                    PROCESS_DATE,
                                    PROCESS_FILE,
                                    PROCESS_USER
                              
                            FROM df_pre
                          ''')

    print (f'Updating data in {full_raw_table_name} for {filename}')
    (final_df_pre
      .write
      .mode("overwrite")
      .format('delta')
      .option('overwriteSchema', 'true')
      .option('replaceWhere', f"PROCESS_DATE = '{processDate}' ")
      .partitionBy("PROCESS_DATE") 
      .saveAsTable(full_raw_table_name))

# COMMAND ----------

files = list_of_files(xactly_s3_folder)
files

# COMMAND ----------

#Extract all the file names from S3 and load into Component_Category_Map

files = list_of_files(xactly_s3_folder)
table = raw_target_tablename_monthly 

if len(files) == 0 :
  print('No files to be processed today')
else :
  for each in files:
    print('Processing file ' + each)
    try : 
      process_s3_monthly_file(each, table)
    except : 
      print('Processing of '+ each + ' file failed!')

# COMMAND ----------

# Move the files to processed folder on S3

files = list_of_files(xactly_s3_folder)
if len(files) == 0 :
  print('No files to be copied over today')
else :
  print('Files loaded - now moving xactly files to archive')
  copy_to_archive (xactly_s3_folder, archive_s3_folder)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Component Category

# COMMAND ----------

import datetime

comp_cat_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/inbound/reference_files/component_category/main aws_s3_xactly:/xactly-ftp/Reference_Files/component_category_map/ -v"

comp_cat_COPY_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf copy sftp_xactly:/inbound/reference_files/component_category/main sftp_xactly:/inbound/reference_files/component_category/archive -v"

comp_cat_DELETE_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf delete sftp_xactly:/inbound/reference_files/component_category/main"

# SYNC files stored in MAIN folder on FTP location to Amazon S3
subprocess.run(
  comp_cat_SYNC_command,
  shell=True,
  stdout=subprocess.PIPE,
  stderr=subprocess.PIPE,
  text=True,
  check=True,
)
print("Files transfered from Main FTP to S3")

# COMMAND ----------

raw_target_tablename_monthly = 'Component_Category_Map'
xactly_s3_folder = 'Reference_Files/component_category_map'
archive_s3_folder = 'Reference_Files/processed_component_category_map'

# COMMAND ----------

#Load data from S3 files into Raw Commissions Table in LogFood

def process_s3_monthly_file(filename, table_to_be_loaded):

    access_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-access-key")
    secret_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-secret-key")
    spark.conf.set("fs.s3a.access.key", access_key)
    spark.conf.set("fs.s3a.secret.key", secret_key)

    aws_bucket_name = "xactly-ftp"
    aws_region = 'us-east-2'
    spark.conf.set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

    files = dbutils.fs.ls("s3a://" + aws_bucket_name + "/" + xactly_s3_folder + "/" + filename)
    file_path = files[0].path

    full_raw_table_name = f'{target_catalog}.{target_silver_schema}.{table_to_be_loaded}'

    #Add process date and file name
    df_raw = spark.read.format("csv").option("header", "true").load(file_path)
    df_updated = df_column_whitespace(df_raw)
    spark_df = df_updated.withColumn("PROCESS_FILE", lit(filename))
    df_pre, processDate = add_audit_attributes(spark_df)

    df_pre = df_pre.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')

    df_pre.createOrReplaceTempView("df_pre")

    final_df_pre = spark.sql('''
                            SELECT  distinct_component,
                                    Cat1,
                                    Cat2,
                                    PROCESS_DATE,
                                    PROCESS_FILE,
                                    PROCESS_USER
                              
                            FROM df_pre
                          ''')


    print (f'Updating data in {full_raw_table_name} for {filename}')
    (final_df_pre
    .write
    .mode("overwrite")
    .format('delta')
    .option('overwriteSchema', 'true')
    .option('replaceWhere', f"PROCESS_DATE = '{processDate}' ")
    .partitionBy("PROCESS_DATE") 
    .saveAsTable(full_raw_table_name))

# COMMAND ----------

files = list_of_files(xactly_s3_folder)
files

# COMMAND ----------

#Extract all the file names from S3 and load into Component_Category_Map

files = list_of_files(xactly_s3_folder)
table = raw_target_tablename_monthly 

if len(files) == 0 :
  print('No files to be processed today')
else :
  for each in files:
    print('Processing file ' + each)
    try : 
      process_s3_monthly_file(each, table)
    except : 
      print('Processing of '+ each + ' file failed!')

# COMMAND ----------

# Move the files to processed folder on S3

files = list_of_files(xactly_s3_folder)
if len(files) == 0 :
  print('No files to be copied over today')
else :
  print('Files loaded - now moving xactly files to archive')
  copy_to_archive (xactly_s3_folder, archive_s3_folder)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Title Group Map

# COMMAND ----------

import datetime

tit_grp_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/inbound/reference_files/title_group/main aws_s3_xactly:/xactly-ftp/Reference_Files/title_group_map/ -v"

tit_grp_COPY_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf copy sftp_xactly:/inbound/reference_files/title_group/main sftp_xactly:/inbound/reference_files/title_group/archive -v"

tit_grp_DELETE_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf delete sftp_xactly:/inbound/reference_files/title_group/main"

# SYNC files stored in MAIN folder on FTP location to Amazon S3
subprocess.run(
  tit_grp_SYNC_command,
  shell=True,
  stdout=subprocess.PIPE,
  stderr=subprocess.PIPE,
  text=True,
  check=True,
)
print("Files transfered from Main FTP to S3")

# COMMAND ----------

raw_target_tablename_monthly = 'title_group_map'
xactly_s3_folder = 'Reference_Files/title_group_map'
archive_s3_folder = 'Reference_Files/processed_title_group_map'

# COMMAND ----------

#Load data from S3 files into Raw Commissions Table in LogFood

def process_s3_monthly_file(filename, table_to_be_loaded):

    access_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-access-key")
    secret_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-secret-key")
    spark.conf.set("fs.s3a.access.key", access_key)
    spark.conf.set("fs.s3a.secret.key", secret_key)

    aws_bucket_name = "xactly-ftp"
    aws_region = 'us-east-2'
    spark.conf.set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

    files = dbutils.fs.ls("s3a://" + aws_bucket_name + "/" + xactly_s3_folder + "/" + filename)
    file_path = files[0].path

    full_raw_table_name = f'{target_catalog}.{target_silver_schema}.{table_to_be_loaded}'

    #Add process date and file name
    df_raw = spark.read.format("csv").option("header", "true").load(file_path)
    df_updated = df_column_whitespace(df_raw)
    spark_df = df_updated.withColumn("PROCESS_FILE", lit(filename))
    df_pre, processDate = add_audit_attributes(spark_df)

    df_pre = df_pre.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')

    df_pre.createOrReplaceTempView("df_pre")

    final_df_pre = spark.sql('''
                            SELECT  distinct_title,
                                    group,
                                    PROCESS_DATE,
                                    PROCESS_FILE,
                                    PROCESS_USER
                              
                            FROM df_pre
                          ''')


    print (f'Updating data in {full_raw_table_name} for {filename}')
    (final_df_pre
    .write
    .mode("overwrite")
    .format('delta')
    .option('overwriteSchema', 'true')
    .option('replaceWhere', f"PROCESS_DATE = '{processDate}' ")
    .partitionBy("PROCESS_DATE") 
    .saveAsTable(full_raw_table_name))

# COMMAND ----------

files = list_of_files(xactly_s3_folder)
files

# COMMAND ----------

#Extract all the file names from S3 and load into Component_Category_Map

files = list_of_files(xactly_s3_folder)
table = raw_target_tablename_monthly 

if len(files) == 0 :
  print('No files to be processed today')
else :
  for each in files:
    print('Processing file ' + each)
    try : 
      process_s3_monthly_file(each, table)
    except : 
      print('Processing of '+ each + ' file failed!')

# COMMAND ----------

# Move the files to processed folder on S3

files = list_of_files(xactly_s3_folder)
if len(files) == 0 :
  print('No files to be copied over today')
else :
  print('Files loaded - now moving xactly files to archive')
  copy_to_archive (xactly_s3_folder, archive_s3_folder)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Title Attainment Measure Map

# COMMAND ----------

import datetime

tit_atn_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/inbound/reference_files/title_attainment/main aws_s3_xactly:/xactly-ftp/Reference_Files/title_attainment_measure_map/ -v"

tit_atn_COPY_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf copy sftp_xactly:/inbound/reference_files/title_attainment/main sftp_xactly:/inbound/reference_files/title_attainment/archive -v"

tit_atn_DELETE_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf delete sftp_xactly:/inbound/reference_files/title_attainment/main"

# SYNC files stored in MAIN folder on FTP location to Amazon S3
subprocess.run(
  tit_atn_SYNC_command,
  shell=True,
  stdout=subprocess.PIPE,
  stderr=subprocess.PIPE,
  text=True,
  check=True,
)
print("Files transfered from Main FTP to S3")

# COMMAND ----------

raw_target_tablename_monthly = 'title_attainment_measure_map'
xactly_s3_folder = 'Reference_Files/title_attainment_measure_map'
archive_s3_folder = 'Reference_Files/processed_title_attainment_measure_map'

# COMMAND ----------

#Load data from S3 files into Raw Commissions Table in LogFood

def process_s3_monthly_file(filename, table_to_be_loaded):

    access_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-access-key")
    secret_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-secret-key")
    spark.conf.set("fs.s3a.access.key", access_key)
    spark.conf.set("fs.s3a.secret.key", secret_key)

    aws_bucket_name = "xactly-ftp"
    aws_region = 'us-east-2'
    spark.conf.set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

    files = dbutils.fs.ls("s3a://" + aws_bucket_name + "/" + xactly_s3_folder + "/" + filename)
    file_path = files[0].path

    full_raw_table_name = f'{target_catalog}.{target_silver_schema}.{table_to_be_loaded}'

    #Add process date and file name
    df_raw = spark.read.format("csv").option("header", "true").load(file_path)
    df_updated = df_column_whitespace(df_raw)
    spark_df = df_updated.withColumn("PROCESS_FILE", lit(filename))
    df_pre, processDate = add_audit_attributes(spark_df)

    df_pre = df_pre.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')

    df_pre.createOrReplaceTempView("df_pre")

    final_df_pre = spark.sql('''
                            SELECT  Title,
                                    Component,
                                    Attainment,
                                    Quarter,
                                    Group,
                                    Quota_Map,
                                    PROCESS_DATE,
                                    PROCESS_FILE,
                                    PROCESS_USER
                              
                            FROM df_pre
                          ''')


    print (f'Updating data in {full_raw_table_name} for {filename}')
    (final_df_pre
    .write
    .mode("overwrite")
    .format('delta')
    .option('overwriteSchema', 'true')
    .option('replaceWhere', f"PROCESS_DATE = '{processDate}' ")
    .partitionBy("PROCESS_DATE") 
    .saveAsTable(full_raw_table_name))

# COMMAND ----------

files = list_of_files(xactly_s3_folder)
files

# COMMAND ----------

#Extract all the file names from S3 and load into Component_Category_Map

files = list_of_files(xactly_s3_folder)
table = raw_target_tablename_monthly 

if len(files) == 0 :
  print('No files to be processed today')
else :
  for each in files:
    print('Processing file ' + each)
    try : 
      process_s3_monthly_file(each, table)
    except : 
      print('Processing of '+ each + ' file failed!')

# COMMAND ----------

# Move the files to processed folder on S3

files = list_of_files(xactly_s3_folder)
if len(files) == 0 :
  print('No files to be copied over today')
else :
  print('Files loaded - now moving xactly files to archive')
  copy_to_archive (xactly_s3_folder, archive_s3_folder)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Territory Region Lookup

# COMMAND ----------

import datetime

reg_ter_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/inbound/reference_files/region_territory/main aws_s3_xactly:/xactly-ftp/Reference_Files/territory_region_mapping/ -v"

reg_ter_COPY_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf copy sftp_xactly:/inbound/reference_files/region_territory/main sftp_xactly:/inbound/reference_files/region_territory/archive -v"

reg_ter_DELETE_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf delete sftp_xactly:/inbound/reference_files/region_territory/main"

# SYNC files stored in MAIN folder on FTP location to Amazon S3
subprocess.run(
  reg_ter_SYNC_command,
  shell=True,
  stdout=subprocess.PIPE,
  stderr=subprocess.PIPE,
  text=True,
  check=True,
)
print("Files transfered from Main FTP to S3")


# COMMAND ----------

raw_target_tablename_monthly = 'xc_region_territory_lookup'
xactly_s3_folder = 'Reference_Files/territory_region_mapping'
archive_s3_folder = 'Reference_Files/processed_territory_region_mapping'

# COMMAND ----------

#Load data from S3 files into Raw Commissions Table in LogFood

def process_s3_monthly_file(filename, table_to_be_loaded):

    access_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-access-key")
    secret_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-secret-key")
    spark.conf.set("fs.s3a.access.key", access_key)
    spark.conf.set("fs.s3a.secret.key", secret_key)

    aws_bucket_name = "xactly-ftp"
    aws_region = 'us-east-2'
    spark.conf.set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

    files = dbutils.fs.ls("s3a://" + aws_bucket_name + "/" + xactly_s3_folder + "/" + filename)
    file_path = files[0].path

    full_raw_table_name = f'{target_catalog}.{target_silver_schema}.{table_to_be_loaded}'

    #Add process date and file name
    df_raw = spark.read.format("csv").option("header", "true").load(file_path)
    df_updated = df_column_whitespace(df_raw)
    spark_df = df_updated.withColumn("PROCESS_FILE", lit(filename))
    df_pre, processDate = add_audit_attributes(spark_df)

    df_pre = df_pre.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')

    df_pre.createOrReplaceTempView("df_pre")

    final_df_pre = spark.sql('''
                            SELECT  Territory,
                                    Assignments,
                                    Effective_Start,
                                    Effective_End,
                                    PROCESS_DATE,
                                    PROCESS_FILE,
                                    PROCESS_USER
                              
                            FROM df_pre
                          ''')


    print (f'Updating data in {full_raw_table_name} for {filename}')
    (final_df_pre
    .write
    .mode("overwrite")
    .format('delta')
    .option('overwriteSchema', 'true')
    .option('replaceWhere', f"PROCESS_DATE = '{processDate}' ")
    .partitionBy("PROCESS_DATE") 
    .saveAsTable(full_raw_table_name))

# COMMAND ----------

files = list_of_files(xactly_s3_folder)
files

# COMMAND ----------

#Extract all the file names from S3 and load into Component_Category_Map

files = list_of_files(xactly_s3_folder)
table = raw_target_tablename_monthly 

if len(files) == 0 :
  print('No files to be processed today')
else :
  for each in files:
    print('Processing file ' + each)
    try : 
      process_s3_monthly_file(each, table)
    except : 
      print('Processing of '+ each + ' file failed!')

# COMMAND ----------

# Move the files to processed folder on S3

files = list_of_files(xactly_s3_folder)
if len(files) == 0 :
  print('No files to be copied over today')
else :
  print('Files loaded - now moving xactly files to archive')
  copy_to_archive (xactly_s3_folder, archive_s3_folder)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Leader Territory

# COMMAND ----------

import datetime

tit_grp_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/inbound/reference_files/leader_territory/main aws_s3_xactly:/xactly-ftp/Reference_Files/leader_territory/ -v"

tit_grp_COPY_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf copy sftp_xactly:/inbound/reference_files/leader_territory/main sftp_xactly:/inbound/reference_files/leader_territory/archive -v"

tit_grp_DELETE_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf delete sftp_xactly:/inbound/reference_files/leader_territory/main"

# SYNC files stored in MAIN folder on FTP location to Amazon S3
subprocess.run(
  tit_grp_SYNC_command,
  shell=True,
  stdout=subprocess.PIPE,
  stderr=subprocess.PIPE,
  text=True,
  check=True,
)
print("Files transfered from Main FTP to S3")

# COMMAND ----------

raw_target_tablename_monthly = 'xc_leader_territory'
xactly_s3_folder = 'Reference_Files/leader_territory'
archive_s3_folder = 'Reference_Files/processed_leader_territory'

# COMMAND ----------

#Load data from S3 files into Raw Commissions Table in LogFood

def process_s3_monthly_file(filename, table_to_be_loaded):

    access_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-access-key")
    secret_key = dbutils.secrets.get(scope = "xactly-ftp-automation", key = "xactly-ftp-extract-s3-secret-key")
    spark.conf.set("fs.s3a.access.key", access_key)
    spark.conf.set("fs.s3a.secret.key", secret_key)

    aws_bucket_name = "xactly-ftp"
    aws_region = 'us-east-2'
    spark.conf.set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

    files = dbutils.fs.ls("s3a://" + aws_bucket_name + "/" + xactly_s3_folder + "/" + filename)
    file_path = files[0].path

    full_raw_table_name = f'{target_catalog}.{target_silver_schema}.{table_to_be_loaded}'

    #Add process date and file name
    df_raw = spark.read.format("csv").option("header", "true").load(file_path)
    df_updated = df_column_whitespace(df_raw)
    spark_df = df_updated.withColumn("PROCESS_FILE", lit(filename))
    df_pre, processDate = add_audit_attributes(spark_df)

    df_pre = df_pre.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')

    df_pre.createOrReplaceTempView("df_pre")

    final_df_pre = spark.sql('''
                            SELECT  Territory,
                                    Position_Name,
                                    `Return_Value.Amount` as Return_Value_Amount,
                                    Effective_Start_Date,
                                    Effective_End_Date,
                                    PROCESS_DATE,
                                    PROCESS_FILE,
                                    PROCESS_USER
                              
                            FROM df_pre
                          ''')


    print (f'Updating data in {full_raw_table_name} for {filename}')
    (final_df_pre
      .write
      .mode("overwrite")
      .format('delta')
      .option('overwriteSchema', 'true')
      .option('replaceWhere', f"PROCESS_DATE = '{processDate}' ")
      .partitionBy("PROCESS_DATE") 
      .saveAsTable(full_raw_table_name))

# COMMAND ----------

files = list_of_files(xactly_s3_folder)
files

# COMMAND ----------

#Extract all the file names from S3 and load into leader territory

files = list_of_files(xactly_s3_folder)
table = raw_target_tablename_monthly 

if len(files) == 0 :
  print('No files to be processed today')
else :
  for each in files:
    print('Processing file ' + each)
    try : 
      process_s3_monthly_file(each, table)
    except : 
      print('Processing of '+ each + ' file failed!')

# COMMAND ----------

# Move the files to processed folder on S3

files = list_of_files(xactly_s3_folder)
if len(files) == 0 :
  print('No files to be copied over today')
else :
  print('Files loaded - now moving xactly files to archive')
  copy_to_archive (xactly_s3_folder, archive_s3_folder)

# COMMAND ----------


