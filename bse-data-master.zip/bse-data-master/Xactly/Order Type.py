# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_order_type  
# MAGIC
# MAGIC Description: The xc_order_type table stores information about the different types of orders that can be placed by customers. This includes the name and description of each order type, as well as whether it is currently active or not. The table also tracks when each order type was created and modified, along with the user who made those changes. Additionally, there are fields to indicate whether an order type should be shown to customers and when it was last processed by a user.
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Xactly JDBC Driver
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC   - **Table Name** : xc_order_type
# MAGIC   - **Description** : Contains Xactly xc_order_type raw data loaded after type casting attributes to support data types compatible with logFood.
# MAGIC   - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC
# MAGIC - **Silver Table**
# MAGIC   - **Schema Name** : fin_commissions_silver
# MAGIC   - **Table Name** : xc_order_type
# MAGIC   - **Description** : Additional fiscal attributes added using CREATED_DATE
# MAGIC   - **Additional Columns** : FISCAL_WEEK, FISCAL_MONTH, FISCAL_QUARTER, FISCAL_YEAR, PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC   - **Other Table Dependencies** : it_core_dim.bi_dates

# COMMAND ----------

from datetime import datetime, timedelta
from pyspark.sql.functions import col, to_date
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_order_type'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_order_type'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT CAST(ORDER_TYPE_ID as DECIMAL(38,0)) ORDER_TYPE_ID,
            CAST(VERSION as DECIMAL(38,0)) VERSION,
            NAME,
            DESCR,
            IS_ACTIVE,
            CAST(CREATED_DATE as string) CREATED_DATE,
            CAST(CREATED_BY_ID as DECIMAL(38,0)) CREATED_BY_ID,
            CREATED_BY_NAME,
            CAST(MODIFIED_DATE as string) MODIFIED_DATE,
            CAST(MODIFIED_BY_ID as DECIMAL(38,0)) MODIFIED_BY_ID,
            MODIFIED_BY_NAME,
            IS_ORDERTYPE_SHOWN
    FROM XACTLY.xc_order_type
)'''

df_ordertype = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

# COMMAND ----------

bronze_df_ordertype, process_date = add_audit_attributes(df_ordertype)
bronze_df_ordertype = bronze_df_ordertype.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_ordertype
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM {target_catalog}.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_ordertype = df_ordertype.withColumn('CREATED_DATE_UPD', to_date(col('CREATED_DATE')))
df_ordertype_upd = df_ordertype.join(df_dates,df_ordertype.CREATED_DATE_UPD ==  df_dates.date,"inner")
df_ordertype_upd = df_ordertype_upd.drop('CREATED_DATE_UPD','date')

# COMMAND ----------

final_df_ordertype, process_date = add_audit_attributes(df_ordertype_upd)
final_df_ordertype = final_df_ordertype.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_ordertype.columns:
    final_df_ordertype = final_df_ordertype.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_ordertype
  .write
  .mode('overwrite')
  .format('delta')
  .option("mergeSchema", "true")
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))

# COMMAND ----------


