# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_pos_part_assignment
# MAGIC
# MAGIC Description: The xc_pos_part_assignment table contains information about the assignment of participants to positions within the organization. It includes details such as participant and position IDs, names, and whether the assignment is currently active. Additionally, it tracks creation and modification dates and users. This table is important for managing and tracking participant assignments and their associated positions within the organization. 
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Xactly JDBC Driver
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC   - **Table Name** : xc_pos_part_assignment
# MAGIC   - **Description** : Contains Xactly xc_pos_part_assignment raw data loaded after type casting attributes to support data types compatible with logFood.
# MAGIC   - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC
# MAGIC - **Silver Table**
# MAGIC   - **Schema Name** : fin_commissions_silver
# MAGIC   - **Table Name** : xc_pos_part_assignment
# MAGIC   - **Description** : Additional fiscal attributes added using CREATED_DATE
# MAGIC   - **Additional Columns** : FISCAL_WEEK, FISCAL_MONTH, FISCAL_QUARTER, FISCAL_YEAR, PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC   - **Other Table Dependencies** : it_core_dim.bi_dates

# COMMAND ----------

from pyspark.sql.functions import col, to_date
from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_pos_part_assignment'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_pos_part_assignment'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT CAST(POS_PART_ASSIGNMENT_ID as DECIMAL(38,0)) POS_PART_ASSIGNMENT_ID,
            CAST(VERSION as DECIMAL(38,0)) VERSION,
            CAST(PARTICIPANT_ID as DECIMAL(38,0)) PARTICIPANT_ID,
            PARTICIPANT_NAME,
            CAST(POSITION_ID as DECIMAL(38,0)) POSITION_ID,
            POSITION_NAME,
            IS_ACTIVE,
            CAST(CREATED_DATE as string) CREATED_DATE,
            CAST(CREATED_BY_ID as DECIMAL(38,0)) CREATED_BY_ID,
            CREATED_BY_NAME,
            CAST(MODIFIED_DATE as string) MODIFIED_DATE,
            CAST(MODIFIED_BY_ID as DECIMAL(38,0)) MODIFIED_BY_ID,
            MODIFIED_BY_NAME
    FROM XACTLY.xc_pos_part_assignment
)'''

df_pos_part_assignment = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

# COMMAND ----------

bronze_df_pos_part_assignment, process_date = add_audit_attributes(df_pos_part_assignment)
bronze_df_pos_part_assignment = bronze_df_pos_part_assignment.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_pos_part_assignment
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM {target_catalog}.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_pos_part_assignment = df_pos_part_assignment.withColumn('CREATED_DATE_UPD', to_date(col('CREATED_DATE')))
df_pos_part_assignment_upd = df_pos_part_assignment.join(df_dates,df_pos_part_assignment.CREATED_DATE_UPD ==  df_dates.date,"inner")
df_pos_part_assignment_upd = df_pos_part_assignment_upd.drop('CREATED_DATE_UPD','date')

# COMMAND ----------

final_df_pos_part_assignment, process_date = add_audit_attributes(df_pos_part_assignment_upd)
final_df_pos_part_assignment = final_df_pos_part_assignment.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_pos_part_assignment.columns:
    final_df_pos_part_assignment = final_df_pos_part_assignment.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_pos_part_assignment
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))

# COMMAND ----------


