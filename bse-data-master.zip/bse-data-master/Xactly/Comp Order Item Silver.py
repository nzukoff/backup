# Databricks notebook source
# MAGIC %run "./config_xc_report"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col, to_date
from pyspark.sql.functions import expr
import urllib
import urllib.request
import io
import pandas as pd
import boto3

# COMMAND ----------

comp_order_bronze_tablename = 'xc_comp_order_item'
comp_order_silver_tablename = 'xc_comp_order_item'

# COMMAND ----------

# MAGIC %md
# MAGIC Extract latest data from bronze comp order item table

# COMMAND ----------

latestProcessDate = spark.sql(f'''
                                SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{comp_order_bronze_tablename}
                              ''' ).collect()[0][0] 
print(latestProcessDate)

# COMMAND ----------

df_comp_order = spark.sql(f'''
                            SELECT *
                            FROM {target_catalog}.{target_bronze_schema}.{comp_order_bronze_tablename} 
                            WHERE PROCESS_DATE = '{latestProcessDate}' 
                          ''')

# COMMAND ----------

# MAGIC %md
# MAGIC Add fiscal attributes to the data extracted from bronze comp order item table

# COMMAND ----------

# DBTITLE 1,Distinct Fiscal Periods Extract
df_dates = spark.sql(f''' SELECT DISTINCT
                                 PERIOD_ID xc_period_PERIOD_ID, 
                                 NAME PERIOD_NAME, 
                                 FISCAL_MONTH, 
                                 FISCAL_WEEK, 
                                 FISCAL_QUARTER, 
                                 FISCAL_HALF_YEAR, 
                                 FISCAL_YEAR
                          FROM main.fin_commissions_silver.xc_period 
                          WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_period)''')

# COMMAND ----------

df_comp_order_bronze = df_comp_order.join(df_dates,df_comp_order.PERIOD_ID ==  df_dates.xc_period_PERIOD_ID,"inner")
df_comp_order_bronze = df_comp_order_bronze.drop('xc_period_PERIOD_ID')

df_comp_order_bronze.createOrReplaceTempView("comp_order_bronze")

# COMMAND ----------

# MAGIC %md
# MAGIC Extract latest data from silver comp order item table

# COMMAND ----------

df_comp_order_latest_silver = spark.sql(f'''
                                         
          SELECT *
          FROM {target_catalog}.{target_silver_schema}.{comp_order_silver_tablename}
          WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_silver_schema}.{comp_order_silver_tablename})
                                          
                                          ''')
                                          
df_comp_order_latest_silver.createOrReplaceTempView("comp_order_latest_silver")

# COMMAND ----------

# MAGIC %md
# MAGIC Check DISTINCT PERIOD_NAMES in bronze comp order item data

# COMMAND ----------

distinct_period_names = df_comp_order_bronze.select("PERIOD_NAME").distinct().rdd.flatMap(lambda x: x).collect()
distinct_period_names

# COMMAND ----------

# MAGIC %md
# MAGIC DELETE rows from latest Silver Comp Order Item data which have PERIOD_NAMES same as above

# COMMAND ----------

# Filter rows in Silver where PERIOD_NAME is not in distinct_period_names_values

silver_filtered = df_comp_order_latest_silver.filter(~col("PERIOD_NAME").isin(distinct_period_names))

# COMMAND ----------

# MAGIC %md
# MAGIC Add Bronze comp order item data to filtered Silver comp order item data

# COMMAND ----------

# silver_combined = silver_filtered.unionByName(df_comp_order_bronze)

for col in set(df_comp_order_bronze.columns) - set(silver_filtered.columns):
    silver_filtered = silver_filtered.withColumn(col, lit(None))

# Reorder columns in df2 to match df1
silver_filtered = silver_filtered.select(df_comp_order_bronze.columns)

# Concatenate dataframes
silver_combined = silver_filtered.unionByName(df_comp_order_bronze)


silver_combined.createOrReplaceTempView("silver_combined")

# COMMAND ----------

# MAGIC %md
# MAGIC Update PROCESS_DATE with the current process date

# COMMAND ----------

silver_combined = silver_combined.drop("PROCESS_DATE","PROCESS_USER")
final_silver_combined, processDate = add_audit_attributes(silver_combined)
final_silver_combined = final_silver_combined.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_silver_combined.createOrReplaceTempView("final_silver_combined_table")

# COMMAND ----------

# DBTITLE 1,Daily Period Record Summary
# MAGIC %sql
# MAGIC SELECT PROCESS_DATE, COUNT(DISTINCT PERIOD_NAME), COUNT(*)
# MAGIC FROM final_silver_combined_table
# MAGIC GROUP BY PROCESS_DATE
# MAGIC ORDER BY PROCESS_DATE DESC

# COMMAND ----------

# MAGIC %md
# MAGIC Load the combined Silver Comp Order Item Data into LogFood

# COMMAND ----------

# DBTITLE 1,Delta Table Overwrite Logger
date_str = processDate.strftime('%Y-%m-%d')
full_silver_comp_order_tablename = f'{target_catalog}.{target_silver_schema}.{comp_order_silver_tablename}'

print (f'Updating data in {full_silver_comp_order_tablename} for {processDate}')

(final_silver_combined
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_silver_comp_order_tablename))
