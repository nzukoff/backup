# Databricks notebook source
# MAGIC %run "./config_xc_report"

# COMMAND ----------

silver_target_tablename = 'latest_pos_part_mapping'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

df_active_latest_positions = spark.sql("""
WITH CTE AS (
SELECT pos.name POSITION_NAME, 
       pos.position_id, 
       pos.effective_start_date POSITION_START_DATE, 
       pos.effective_end_date POSITION_END_DATE, 
       part.participant_name,
       RANK() OVER (PARTITION BY pos.name ORDER BY pos.effective_start_date DESC) rnk
FROM main.fin_commissions_silver.xc_position pos
  LEFT JOIN main.fin_commissions_silver.xc_pos_part_assignment part
    ON pos.POSITION_ID = part.POSITION_ID
WHERE pos.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_part_assignment)
AND part.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_position)
)

SELECT POSITION_NAME, 
       POSITION_ID, 
       POSITION_START_DATE, 
       POSITION_END_DATE, 
       PARTICIPANT_NAME
FROM CTE
WHERE rnk=1
AND POSITION_END_DATE >= current_date()
""")

df_active_latest_positions.createOrReplaceTempView("active_latest_positions")

# COMMAND ----------

df_latest_pos_participant = spark.sql("""
WITH POSITION_CTE AS (
SELECT POSITION_ID, 
       NAME, 
       EFFECTIVE_START_DATE, 
       EFFECTIVE_END_DATE, 
       RANK() OVER (PARTITION BY NAME ORDER BY EFFECTIVE_START_DATE DESC) AS POSITION_RANK
FROM main.fin_commissions_silver.xc_position
WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_position)
),

POSITION_LATEST AS (    
SELECT POSITION_ID, 
       NAME POSITION_NAME, 
       EFFECTIVE_START_DATE POSITION_START_DATE,
       EFFECTIVE_END_DATE POSITION_END_DATE
FROM POSITION_CTE
WHERE POSITION_RANK = 1 
),

PARTICIPANT_TEMP AS (
    SELECT PARTICIPANT_ID,
           NAME,
           TRIM(')' FROM SUBSTRING(NAME, INSTR(NAME, '(')+1, LEN(NAME)-INSTR(NAME, '('))) SFDC_ID,
           EFFECTIVE_START_DATE, 
           EFFECTIVE_END_DATE
    FROM main.fin_commissions_silver.xc_participant
    WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_participant)
    AND xc_participant.EMP_STATUS_ID = '150044'
    AND IS_ACTIVE = 1
),

PARTICIPANT_CTE AS (
    SELECT PARTICIPANT_ID,
           NAME,
           SFDC_ID,
           EFFECTIVE_START_DATE, 
           EFFECTIVE_END_DATE,
           RANK() OVER (PARTITION BY SFDC_ID ORDER BY EFFECTIVE_START_DATE DESC) AS PARTICIPANT_RANK
    FROM PARTICIPANT_TEMP
),

PARTICIPANT_LATEST AS (
    SELECT PARTICIPANT_ID,
           NAME PARTICIPANT_NAME,
           SFDC_ID,
           EFFECTIVE_START_DATE PARTICIPANT_START_DATE, 
           EFFECTIVE_END_DATE PARTICIPANT_END_DATE
    FROM PARTICIPANT_CTE
    WHERE PARTICIPANT_RANK = 1
),

POS_PART_ASSIGNMENT AS (
   SELECT DISTINCT 
          PARTICIPANT_ID,
          PARTICIPANT_NAME,
          TRIM(')' FROM SUBSTRING(PARTICIPANT_NAME, INSTR(PARTICIPANT_NAME, '(')+1, LEN(PARTICIPANT_NAME)-INSTR(PARTICIPANT_NAME, '('))) SFDC_ID,
          POSITION_ID,
          POSITION_NAME
   FROM  main.fin_commissions_silver.xc_pos_part_assignment
   WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_part_assignment)
),

COMBINED AS
(
SELECT pos.*, 
       part.*
FROM POSITION_LATEST pos 
  LEFT JOIN POS_PART_ASSIGNMENT pos_part
    ON pos.POSITION_NAME = pos_part.POSITION_NAME 
  LEFT JOIN PARTICIPANT_LATEST part 
    ON part.SFDC_ID = pos_part.SFDC_ID ),

FINAL AS 
(
       SELECT DISTINCT 
              SFDC_ID,
              PARTICIPANT_ID,
              PARTICIPANT_NAME,
              PARTICIPANT_START_DATE,
              PARTICIPANT_END_DATE,
              POSITION_ID,
              POSITION_NAME,
              POSITION_START_DATE,
              POSITION_END_DATE,
              RANK() OVER (PARTITION BY SFDC_ID ORDER BY POSITION_START_DATE DESC) rnk
       FROM COMBINED 
)

SELECT SFDC_ID,
       PARTICIPANT_ID,
       PARTICIPANT_NAME,
       PARTICIPANT_START_DATE,
       PARTICIPANT_END_DATE,
       POSITION_ID,
       POSITION_NAME,
       POSITION_START_DATE,
       POSITION_END_DATE
FROM FINAL
WHERE rnk=1 
AND POSITION_NAME IN (
       SELECT DISTINCT POSITION_NAME
       FROM active_latest_positions
)
AND PARTICIPANT_NAME IS NOT NULL


""")

df_latest_pos_participant.createOrReplaceTempView("latest_pos_participant")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT PARTICIPANT_NAME
# MAGIC FROM latest_pos_participant
# MAGIC GROUP BY PARTICIPANT_NAME
# MAGIC HAVING COUNT(DISTINCT POSITION_NAME)>1

# COMMAND ----------

silver_df_latest_pos_participant, process_date = add_audit_attributes(df_latest_pos_participant)
silver_df_latest_pos_participant = silver_df_latest_pos_participant.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(silver_df_latest_pos_participant
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))

# COMMAND ----------


