# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_position
# MAGIC
# MAGIC Description: The xc_position table contains information about positions within the company, including their name, description, and various dates such as incentive start and end dates, effective start and end dates, and credit start and end dates. It also includes information about the position's parent record and parent position, as well as its title and position group.
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Xactly JDBC Driver
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC   - **Table Name** : xc_position
# MAGIC   - **Description** : Contains Xactly xc_position raw data loaded after type casting attributes to support data types compatible with logFood.
# MAGIC   - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC
# MAGIC - **Silver Table**
# MAGIC   - **Schema Name** : fin_commissions_silver
# MAGIC   - **Table Name** : xc_position
# MAGIC   - **Description** : Additional fiscal attributes added using CREATED_DATE
# MAGIC   - **Additional Columns** : FISCAL_WEEK, FISCAL_MONTH, FISCAL_QUARTER, FISCAL_YEAR, PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC   - **Other Table Dependencies** : it_core_dim.bi_dates

# COMMAND ----------

from pyspark.sql.functions import col, to_date
from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_position'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_position'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT CAST(POSITION_ID as DECIMAL(38,0)) POSITION_ID,
            CAST(VERSION as DECIMAL(38,0)) VERSION,
            NAME,
            DESCR,
            CAST(INCENT_ST_DATE as string) INCENT_ST_DATE,
            CAST(INCENT_END_DATE as string) INCENT_END_DATE,
            IS_ACTIVE,
            CAST(CREATED_DATE as string) CREATED_DATE,
            CAST(CREATED_BY_ID as DECIMAL(38,0)) CREATED_BY_ID,
            CREATED_BY_NAME,
            CAST(MODIFIED_DATE as string) MODIFIED_DATE,
            CAST(MODIFIED_BY_ID as DECIMAL(38,0)) MODIFIED_BY_ID,
            MODIFIED_BY_NAME,
            CAST(TITLE_ID as DECIMAL(38,0)) TITLE_ID,
            CAST(POS_GROUP_ID as DECIMAL(38,0)) POS_GROUP_ID,
            CAST(PARENT_RECORD_ID as DECIMAL(38,0)) PARENT_RECORD_ID,
            CAST(PARENT_POSITION_ID as DECIMAL(38,0)) PARENT_POSITION_ID,
            CAST(PARTICIPANT_ID as DECIMAL(38,0)) PARTICIPANT_ID,
            CAST(CAST(EFFECTIVE_START_DATE as DECIMAL(38,0)) as string) EFFECTIVE_START_DATE,
            CAST(CAST(EFFECTIVE_END_DATE as DECIMAL(38,0)) as string) EFFECTIVE_END_DATE,
            IS_MASTER,
            CAST(MASTER_POSITION_ID as DECIMAL(38,0)) MASTER_POSITION_ID,
            CAST(BUSINESS_GROUP_ID as DECIMAL(38,0)) BUSINESS_GROUP_ID,
            CAST(CREDIT_START_DATE as string) CREDIT_START_DATE,
            CAST(CREDIT_END_DATE as string) CREDIT_END_DATE
    FROM XACTLY.xc_position
)'''

df_position = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

# COMMAND ----------

from pyspark.sql import functions as F

yyyy_mm_dd_pattern = r'^\d{4}-\d{2}-\d{2}$'  
dd_mon_yy_pattern = r'^\d{2}-[A-Z]{3}-\d{2}$'  

df_fixed = df_position.withColumn(
    "EFFECTIVE_START_DATE",
    F.when(F.col("EFFECTIVE_START_DATE").rlike(yyyy_mm_dd_pattern), F.to_date(F.col("EFFECTIVE_START_DATE"), 'yyyy-MM-dd'))
    .when(F.col("EFFECTIVE_START_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.to_date(F.col("EFFECTIVE_START_DATE"), 'dd-MMM-yy'), 'yyyy-MM-dd'))
    .otherwise(None)  
).withColumn(
    "EFFECTIVE_END_DATE",
    F.when(F.col("EFFECTIVE_END_DATE").rlike(yyyy_mm_dd_pattern), F.date_format(F.last_day(F.to_date(F.col("EFFECTIVE_END_DATE"), 'yyyy-MM-dd')), 'yyyy-MM-dd'))
    .when(F.col("EFFECTIVE_END_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.last_day(F.to_date(F.col("EFFECTIVE_END_DATE"), 'dd-MMM-yy')), 'yyyy-MM-dd'))
    .otherwise(None)  
)

# COMMAND ----------

bronze_df_position, process_date = add_audit_attributes(df_fixed)
bronze_df_position = bronze_df_position.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_position
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM main.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_fixed = df_fixed.withColumn('CREATED_DATE_UPD', to_date(col('CREATED_DATE')))
df_position_upd = df_fixed.join(df_dates,df_fixed.CREATED_DATE ==  df_dates.date,"inner")
df_position_upd = df_position_upd.drop('date','CREATED_DATE_UPD')

# COMMAND ----------

final_df_position, process_date = add_audit_attributes(df_position_upd)
final_df_position = final_df_position.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_position.columns:
    final_df_position = final_df_position.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_position
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))
