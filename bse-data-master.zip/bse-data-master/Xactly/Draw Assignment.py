# Databricks notebook source
from datetime import datetime, timedelta
from pyspark.sql.functions import col, to_date
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_draw_assignment'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_draw_assignment'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT 
            CAST(DRAW_ASSIGNMENT_ID as DECIMAL(38,0)) DRAW_ASSIGNMENT_ID,
            CAST(VERSION as DECIMAL(38,0)) VERSION,
            CAST(ASSIGNMENT_ID as DECIMAL(38,0)) ASSIGNMENT_ID,
            ASSIGNMENT_NAME,
            CAST(ASSIGNMENT_TYPE as DECIMAL(38,0)) ASSIGNMENT_TYPE,
            CAST(PROJECTED_AMOUNT as DECIMAL(38,8)) PROJECTED_AMOUNT,
            CAST(PAY_AMOUNT as DECIMAL(38,8)) PAY_AMOUNT,
            CAST(BALANCE as DECIMAL(38,8)) BALANCE,
            CAST(PARTICIPANT_ID as DECIMAL(38,0)) PARTICIPANT_ID,
            CAST(PERIOD_ID as DECIMAL(38,0)) PERIOD_ID,
            PERSON_NAME,
            POSITION_NAME,
            CAST(BUSINESS_GROUP_ID as DECIMAL(38,0)) BUSINESS_GROUP_ID,
            CAST(FINALIZED_DATE as string) FINALIZED_DATE,
            FINALIZED_BY,
            IS_ACTIVE,
            CAST(CREATED_DATE as string) CREATED_DATE,
            CAST(CREATED_BY_ID as DECIMAL(38,0)) CREATED_BY_ID,
            CREATED_BY_NAME,
            CAST(MODIFIED_DATE as string) MODIFIED_DATE,
            CAST(MODIFIED_BY_ID as DECIMAL(38,0)) MODIFIED_BY_ID,
            MODIFIED_BY_NAME,
            CAST(DRAW_ID as DECIMAL(38,0)) DRAW_ID,
            CAST(RECOVERY_PERCENT as DECIMAL(38,0)) RECOVERY_PERCENT,
            CAST(PREVIEW_BALANCE as DECIMAL(38,8)) PREVIEW_BALANCE,
            CAST(EFF_PARTICIPANT_ID as DECIMAL(38,0)) EFF_PARTICIPANT_ID,
            CAST(EFF_POSITION_ID as DECIMAL(38,0)) EFF_POSITION_ID

    FROM XACTLY.xc_draw_assignment

)'''

df_business = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

df_business.createOrReplaceTempView("Check_test")                    

# COMMAND ----------

bronze_df_business, process_date = add_audit_attributes(df_business)
bronze_df_business = bronze_df_business.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_business
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM main.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_business = df_business.withColumn('CREATED_DATE_UPD', to_date(col('CREATED_DATE')))
df_business_upd = df_business.join(df_dates,df_business.CREATED_DATE_UPD ==  df_dates.date,"inner")
df_business_upd = df_business_upd.drop('CREATED_DATE_UPD','date')

# COMMAND ----------

final_df_business, process_date = add_audit_attributes(df_business_upd)
final_df_business = final_df_business.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_business.columns:
    final_df_business = final_df_business.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_business
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))

# COMMAND ----------


