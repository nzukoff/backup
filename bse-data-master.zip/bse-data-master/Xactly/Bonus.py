# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_bonus  
# MAGIC
# MAGIC Description: The xc_bonus table contains data related to bonuses earned by participants in the commission system. It includes information on the bonus amount, earning group, reason code, and release date. Additionally, it provides details on the participant, position, product, customer, and geography associated with the bonus. The table also tracks the status of the bonus, including whether it has been processed or held. Overall, this table is essential for analyzing and managing commission payouts within the business.
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Xactly JDBC Driver
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC   - **Table Name** : xc_bonus
# MAGIC   - **Description** : Contains Xactly xc_bonus raw data loaded after type casting attributes to support data types compatible with logFood.
# MAGIC   - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC
# MAGIC - **Silver Table**
# MAGIC   - **Schema Name** : fin_commissions_silver
# MAGIC   - **Table Name** : xc_bonus
# MAGIC   - **Description** : Additional fiscal attributes added using INCENTIVE_DATE
# MAGIC   - **Additional Columns** : FISCAL_WEEK, FISCAL_MONTH, FISCAL_QUARTER, FISCAL_YEAR, PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC   - **Other Table Dependencies** : it_core_dim.bi_dates

# COMMAND ----------

from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
from pyspark.sql.functions import col, to_date
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_bonus'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_bonus'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT 
        CAST(BONUS_ID as DECIMAL(38,0)) BONUS_ID,
        CAST(VERSION as DECIMAL(38,0)) VERSION,
        NAME,
        IS_ACTIVE,
        CAST(PERIOD_ID as DECIMAL(38,0)) PERIOD_ID,
        PERIOD_NAME,
        CAST(AMOUNT as DECIMAL(38,8)) AMOUNT,
        CAST(AMOUNT_UNIT_TYPE_ID as DECIMAL(38,0)) AMOUNT_UNIT_TYPE_ID,
        AMOUNT_DISPLAY_SYMBOL,
        CAST(PARTICIPANT_ID as DECIMAL(38,0)) PARTICIPANT_ID,
        PARTICIPANT_NAME,
        CAST(POSITION_ID as DECIMAL(38,0)) POSITION_ID,
        POSITION_NAME,
        CAST(ORDER_ITEM_ID as DECIMAL(38,0)) ORDER_ITEM_ID,
        ITEM_CODE,
        ORDER_CODE,
        CAST(RULE_ID as DECIMAL(38,0)) RULE_ID,
        RULE_NAME,
        IS_HELD,
        CAST(RELEASE_DATE as string) RELEASE_DATE,
        CAST(EARNING_GROUP_ID as DECIMAL(38,0)) EARNING_GROUP_ID,
        EARNING_GROUP_NAME,
        CAST(REASON_CODE_ID as DECIMAL(38,0)) REASON_CODE_ID,
        REASON_CODE_NAME,
        CAST(CREATED_DATE as string) CREATED_DATE,
        CAST(CREATED_BY_ID as DECIMAL(38,0)) CREATED_BY_ID,
        CREATED_BY_NAME,
        CAST(MODIFIED_DATE as string) MODIFIED_DATE,
        CAST(MODIFIED_BY_ID as DECIMAL(38,0)) MODIFIED_BY_ID,
        MODIFIED_BY_NAME,
        IS_PROCESSED,
        CAST(TRANS_ID as DECIMAL(38,0)) TRANS_ID,
        CAST(PRODUCT_ID as DECIMAL(38,0)) PRODUCT_ID,
        PRODUCT_NAME,
        CAST(CUSTOMER_ID as DECIMAL(38,0)) CUSTOMER_ID,
        CUSTOMER_NAME,
        CAST(GEOGRAPHY_ID as DECIMAL(38,0)) GEOGRAPHY_ID,
        GEOGRAPHY_NAME,
        EVER_ON_HOLD,
        CAST(RELEASE_GROUP_ID as DECIMAL(38,0)) RELEASE_GROUP_ID,
        CAST(ESTIMATED_REL_DATE as string) ESTIMATED_REL_DATE,
        CAST(BUSINESS_GROUP_ID as DECIMAL(38,0)) BUSINESS_GROUP_ID,
        CAST(RUN_ID as DECIMAL(38,0)) RUN_ID,
        CAST(INCENTIVE_DATE as string) INCENTIVE_DATE,
        CAST(EFF_PARTICIPANT_ID as DECIMAL(38,0)) EFF_PARTICIPANT_ID,
        CAST(EFF_POSITION_ID as DECIMAL(38,0)) EFF_POSITION_ID,
        CAST(PLAN_ID as DECIMAL(38,0)) PLAN_ID,
        PLAN_NAME,
        CAST(CREDIT_ID as DECIMAL(38,0)) CREDIT_ID,
        INPUT_TYPE,
        CAST(MGR_EFF_POS_ID as DECIMAL(38,0)) MGR_EFF_POS_ID,
        CAST(MGR_MASTER_POS_ID as DECIMAL(38,0)) MGR_MASTER_POS_ID,
        CAST(MGR_EFF_PART_ID as DECIMAL(38,0)) MGR_EFF_PART_ID
    FROM XACTLY.xc_bonus
)'''

df_bonus = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

# COMMAND ----------

from pyspark.sql import functions as F

yyyy_mm_dd_pattern = r'^\d{4}-\d{2}-\d{2}$'  
dd_mon_yy_pattern = r'^\d{2}-[A-Z]{3}-\d{2}$'  

df_fixed = df_bonus.withColumn(
    "INCENTIVE_DATE",
    F.when(F.col("INCENTIVE_DATE").rlike(yyyy_mm_dd_pattern), F.to_date(F.col("INCENTIVE_DATE"), 'yyyy-MM-dd'))
    .when(F.col("INCENTIVE_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.to_date(F.col("INCENTIVE_DATE"), 'dd-MMM-yy'), 'yyyy-MM-dd'))
    .otherwise(None)  
)

# COMMAND ----------

bronze_df_bonus, process_date = add_audit_attributes(df_fixed)
bronze_df_bonus = bronze_df_bonus.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_bonus
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

from pyspark.sql.functions import col
count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM {target_catalog}.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_bonus_upd = df_fixed.join(df_dates, df_fixed.INCENTIVE_DATE ==  df_dates.date,"inner")
df_bonus_upd = df_bonus_upd.drop('date')

# COMMAND ----------

final_df_bonus, process_date = add_audit_attributes(df_bonus_upd)
final_df_bonus = final_df_bonus.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_bonus.columns:
    final_df_bonus = final_df_bonus.withColumnRenamed(col, col.upper())

final_df_bonus.createOrReplaceTempView('final_df_bonus')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_bonus
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))
