# Databricks notebook source
from datetime import datetime, date
import datetime
import subprocess

# COMMAND ----------

# MAGIC %md
# MAGIC # Files Transfer from FTP to S3

# COMMAND ----------

# MAGIC %sh
# MAGIC rm -f $HOME/rclone

# COMMAND ----------

# MAGIC %sh curl -o /tmp/rclone.zip https://downloads.rclone.org/rclone-current-linux-arm64.zip

# COMMAND ----------

# MAGIC %sh sh -c 'cd /tmp; unzip -o rclone.zip; cp rclone*arm64/rclone $HOME; chmod +x $HOME/rclone'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Commissions

# COMMAND ----------

import datetime

commissions_success_check_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf ls sftp_xactly:/outbound/xc_commission/MTD/success_mtd_xc_commission"

commissions_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/outbound/xc_commission/MTD/Main aws_s3_xactly:/xactly-ftp/MTD/xc_commission/ -v"

commissions_COPY_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf copy sftp_xactly:/outbound/xc_commission/MTD/Main sftp_xactly:/outbound/xc_commission/MTD/Archive -v"

commissions_DELETE_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf delete sftp_xactly:/outbound/xc_commission/MTD/Main "

try:
    result = subprocess.run(
        commissions_success_check_command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=True,
    )
    
    # Capture the standard output
    commissions_success_check_command_output = result.stdout

    # Capture the standard error
    commissions_success_check_command_error = result.stderr

    # Check the exit code (0 indicates success)
    exit_code = result.returncode

    if exit_code == 0:
        print("RClone command executed successfully.")

        # Check if file present in success folder has current date stamp
        current_date = str(datetime.date.today().year)+str(datetime.date.today().strftime('%m'))+str(datetime.date.today().strftime('%d'))

        if current_date in commissions_success_check_command_output:

          # SYNC files stored in MAIN folder on FTP location to Amazon S3
          subprocess.run(
            commissions_SYNC_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files transfered from Main FTP to S3")
          
          # COPY files from MAIN folder to ARCHIVE folder on FTP location
          subprocess.run(
            commissions_COPY_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files copied from Main FTP to Archive FTP")

          # DELETE files in MAIN folder on FTP Location
          subprocess.run(
            commissions_DELETE_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files deleted from Main FTP")
          
        else:
          print("Latest Success file is missing")

    else:
        print("RClone command failed with exit code:", exit_code)
        print("Error:", commissions_success_check_command_error)

except subprocess.CalledProcessError as e:
    print("Error running RClone command:", e)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Credits

# COMMAND ----------

import datetime

credits_success_check_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf ls sftp_xactly:/outbound/xc_credit/MTD/success_mtd_xc_credit"

credits_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/outbound/xc_credit/MTD/Main aws_s3_xactly:/xactly-ftp/MTD/xc_credit/ -v"

credits_COPY_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf copy sftp_xactly:/outbound/xc_credit/MTD/Main sftp_xactly:/outbound/xc_credit/MTD/Archive -v"

credits_DELETE_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf delete sftp_xactly:/outbound/xc_credit/MTD/Main"

try:
    result = subprocess.run(
        credits_success_check_command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=True,
    )
    
    # Capture the standard output
    credits_success_check_command_output = result.stdout

    # Capture the standard error
    credits_success_check_command_error = result.stderr

    # Check the exit code (0 indicates success)
    exit_code = result.returncode

    if exit_code == 0:
        print("RClone command executed successfully.")

        # Check if file present in success folder has current date stamp
        current_date = str(datetime.date.today().year)+str(datetime.date.today().strftime('%m'))+str(datetime.date.today().strftime('%d'))

        if current_date in credits_success_check_command_output:

          # SYNC files stored in MAIN folder on FTP location to Amazon S3
          subprocess.run(
            credits_SYNC_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files transfered from Main FTP to S3")
          
          # COPY files from MAIN folder to ARCHIVE folder on FTP location
          subprocess.run(
            credits_COPY_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files copied from Main FTP to Archive FTP")
          
          # DELETE files in MAIN folder on FTP Location
          subprocess.run(
            credits_DELETE_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files deleted from Main FTP")
          
        else:
          print("Latest Success file is missing")

    else:
        print("RClone command failed with exit code:", exit_code)
        print("Error:", credits_success_check_command_error)

except subprocess.CalledProcessError as e:
    print("Error running RClone command:", e)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Comp Order Item

# COMMAND ----------

import datetime

comporder_success_check_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf ls sftp_xactly:/outbound/xc_comp_order_item/MTD/success_mtd_xc_comp_order_item"

comporder_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/outbound/xc_comp_order_item/MTD/Main aws_s3_xactly:/xactly-ftp/MTD/xc_comp_order_item/ -v"

comporder_COPY_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf copy sftp_xactly:/outbound/xc_comp_order_item/MTD/Main sftp_xactly:/outbound/xc_comp_order_item/MTD/Archive -v"

comporder_DELETE_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf delete sftp_xactly:/outbound/xc_comp_order_item/MTD/Main"

try:
    result = subprocess.run(
        comporder_success_check_command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=True,
    )
    
    # Capture the standard output
    comporder_success_check_command_output = result.stdout

    # Capture the standard error
    comporder_success_check_command_error = result.stderr

    # Check the exit code (0 indicates success)
    exit_code = result.returncode

    if exit_code == 0:
        print("RClone command executed successfully.")

        # Check if file present in success folder has current date stamp
        current_date = str(datetime.date.today().year)+str(datetime.date.today().strftime('%m'))+str(datetime.date.today().strftime('%d'))

        if current_date in comporder_success_check_command_output:

          # SYNC files stored in MAIN folder on FTP location to Amazon S3
          subprocess.run(
            comporder_SYNC_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files transfered from Main FTP to S3")
          
          # COPY files from MAIN folder to ARCHIVE folder on FTP location
          subprocess.run(
            comporder_COPY_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files copied from Main FTP to Archive FTP")

          # DELETE files in MAIN folder on FTP Location
          subprocess.run(
            comporder_DELETE_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files deleted from Main FTP")
          
        else:
          print("Latest Success file is missing")

    else:
        print("RClone command failed with exit code:", exit_code)
        print("Error:", comporder_success_check_command_error)

except subprocess.CalledProcessError as e:
    print("Error running RClone command:", e)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Login

# COMMAND ----------

import datetime

today_str = datetime.date.today().strftime('%Y%m%d')
dated_filename = f"xc_login_{today_str}.csv"

login_success_check_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf ls sftp_xactly:/outbound/xc_login/xc_login.csv"

login_RENAME_command = f"$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf moveto sftp_xactly:/outbound/xc_login/xc_login.csv sftp_xactly:/outbound/xc_login/{dated_filename} -v"

login_SYNC_command = f"$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/outbound/xc_login/ aws_s3_xactly:/xactly-ftp/MTD/xc_login/ --include '{dated_filename}' -v"

login_MOVE_command = f"$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf moveto sftp_xactly:/outbound/xc_login/{dated_filename} sftp_xactly:/outbound/xc_login/archive/{dated_filename} -v"

try:
    result = subprocess.run(
        login_success_check_command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=True,
    )
    
    # Capture the standard output
    login_success_check_command_output = result.stdout

    # Capture the standard error
    login_success_check_command_error = result.stderr

    # Check the exit code (0 indicates success)
    exit_code = result.returncode

    if exit_code == 0:
        print("RClone command executed successfully.")

        if 'xc_login.csv' in login_success_check_command_output:

            # RENAME the file to include the date
            subprocess.run(
                login_RENAME_command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                check=True,
            )
            print(f"File renamed to {dated_filename} on FTP")

            # SYNC file stored in xc_login folder on FTP location to Amazon S3
            subprocess.run(
                login_SYNC_command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                check=True,
            )
            print("Files transfered from FTP to S3")
            
            # MOVE file from xc_login folder to ARCHIVE folder on FTP location
            subprocess.run(
                login_MOVE_command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                check=True,
            )
            print("File moved to archive FTP")
          
        else:
          print("Latest file is missing")

    else:
        print("RClone command failed with exit code:", exit_code)
        print("Error:", login_success_check_command_error)

except subprocess.CalledProcessError as e:
    print("Error running RClone command:", e)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Payments

# COMMAND ----------

import datetime

payments_success_check_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf ls sftp_xactly:/outbound/xc_payment/MTD/success_mtd_xc_payment"

payments_SYNC_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf sync sftp_xactly:/outbound/xc_payment/MTD/Main aws_s3_xactly:/xactly-ftp/MTD/xc_payment/ -v"

payments_COPY_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf copy sftp_xactly:/outbound/xc_payment/MTD/Main sftp_xactly:/outbound/xc_payment/MTD/Archive -v"

payments_DELETE_command = "$HOME/rclone --config /Volumes/main/fin_commissions_bronze/xactly_config/rclone.conf delete sftp_xactly:/outbound/xc_payment/MTD/Main "

try:
    result = subprocess.run(
        payments_success_check_command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=True,
    )
    
    # Capture the standard output
    payments_success_check_command_output = result.stdout

    # Capture the standard error
    payments_success_check_command_error = result.stderr

    # Check the exit code (0 indicates success)
    exit_code = result.returncode

    if exit_code == 0:
        print("RClone command executed successfully.")

        # Check if file present in success folder has current date stamp
        current_date = str(datetime.date.today().year)+str(datetime.date.today().strftime('%m'))+str(datetime.date.today().strftime('%d'))

        if current_date in payments_success_check_command_output:

          # SYNC files stored in MAIN folder on FTP location to Amazon S3
          subprocess.run(
            payments_SYNC_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files transfered from Main FTP to S3")
          
          # COPY files from MAIN folder to ARCHIVE folder on FTP location
          subprocess.run(
            payments_COPY_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files copied from Main FTP to Archive FTP")

          # DELETE files in MAIN folder on FTP Location
          subprocess.run(
            payments_DELETE_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
          )
          print("Files deleted from Main FTP")
          
        else:
          print("Latest Success file is missing")

    else:
        print("RClone command failed with exit code:", exit_code)
        print("Error:", payments_success_check_command_error)

except subprocess.CalledProcessError as e:
    print("Error running RClone command:", e)
