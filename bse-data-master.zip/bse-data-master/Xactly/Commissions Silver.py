# Databricks notebook source
# MAGIC %run "./config_xc_report"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col, to_date
from pyspark.sql.functions import expr
import urllib
import urllib.request
import io
import pandas as pd
import boto3

# COMMAND ----------

commission_bronze_tablename = 'xc_commission'
commission_silver_tablename = 'xc_commission'

# COMMAND ----------

target_catalog

# COMMAND ----------

# MAGIC %md
# MAGIC Extract latest data from bronze commissions table

# COMMAND ----------

latestProcessDate = spark.sql(f'''
                                SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{commission_bronze_tablename}
                              ''' ).collect()[0][0] 
print(latestProcessDate)

# COMMAND ----------

df_commissions = spark.sql(f'''SELECT 
                            CAST(COMMISSION_ID as DECIMAL(38,0)) COMMISSION_ID,
                            CAST(VERSION as DECIMAL(38,0)) VERSION,
                            NAME,
                            IS_ACTIVE,
                            CAST(AMOUNT as DECIMAL(38,8)) AMOUNT,
                            CAST(AMOUNT_UNIT_TYPE_ID as DECIMAL(38,0)) AMOUNT_UNIT_TYPE_ID,
                            AMOUNT_DISPLAY_SYMBOL,
                            CAST(PERIOD_ID as DECIMAL(38,0)) PERIOD_ID,
                            PERIOD_NAME,
                            CAST(PARTICIPANT_ID as DECIMAL(38,0)) PARTICIPANT_ID,
                            PARTICIPANT_NAME,
                            CAST(POSITION_ID as DECIMAL(38,0)) POSITION_ID,
                            POSITION_NAME,
                            CAST(CREDIT_ID as DECIMAL(38,0)) CREDIT_ID,  
                            CREDIT_NAME,
                            CAST(ORDER_ITEM_ID as DECIMAL(38,0)) ORDER_ITEM_ID,
                            ITEM_CODE,
                            ORDER_CODE,
                            CAST(RULE_ID as DECIMAL(38,0)) RULE_ID,
                            RULE_NAME,
                            IS_HELD,
                            RELEASE_DATE,
                            CAST(RATE_AMOUNT as DECIMAL(38,8)) RATE_AMOUNT,
                            CAST(RATE_AMOUNT_UNIT_TYPE_ID as DECIMAL(38,0)) RATE_AMOUNT_UNIT_TYPE_ID,
                            RATE_AMOUNT_DISPLAY_SYMBOL,
                            CAST(EARNING_GROUP_ID as DECIMAL(38,0)) EARNING_GROUP_ID,
                            EARNING_GROUP_NAME,
                            CAST(REASON_CODE_ID as DECIMAL(38,0)) REASON_CODE_ID,
                            REASON_CODE_NAME,
                            CAST(RATE_TABLE_ID as DECIMAL(38,0)) RATE_TABLE_ID,
                            RATE_TABLE_NAME,
                            CAST(QUOTA_ID as DECIMAL(38,0)) QUOTA_ID,
                            QUOTA_NAME,
                            CAST(QUOTA_PERIOD_TYPE_ID as DECIMAL(38,0)) QUOTA_PERIOD_TYPE_ID,
                            QUOTA_PERIOD_TYPE_NAME,
                            CAST(MEASURE_VALUE as DECIMAL(38,8)) MEASURE_VALUE,
                            CAST(MEASURE_VALUE_UNIT_TYPE_ID as DECIMAL(38,0)) MEASURE_VALUE_UNIT_TYPE_ID,
                            CAST(ATTAINMENT_VALUE as DECIMAL(38, 8)) ATTAINMENT_VALUE,
                            CAST(ATTAINMENT_VALUE_UNIT_TYPE_ID as DECIMAL(38,0)) ATTAINMENT_VALUE_UNIT_TYPE_ID,
                            CAST(ENTRY_NUMBER as DECIMAL(38,0)) ENTRY_NUMBER,
                            IS_PROCESSED,
                            CAST(CREDIT_UNIT_TYPE_ID as DECIMAL(38,0)) CREDIT_UNIT_TYPE_ID,
                            CAST(CREDIT_AMOUNT as DECIMAL(38,8)) CREDIT_AMOUNT,
                            IS_CREDIT_APPLY,
                            PAYMENT_FX,
                            CAST(TRANS_ID as DECIMAL(38,0)) TRANS_ID,
                            CAST(PRODUCT_ID as DECIMAL(38,0)) PRODUCT_ID,
                            PRODUCT_NAME,
                            CAST(CUSTOMER_ID as DECIMAL(38,0)) CUSTOMER_ID,
                            CUSTOMER_NAME,
                            CAST(GEOGRAPHY_ID as DECIMAL(38,0)) GEOGRAPHY_ID,
                            GEOGRAPHY_NAME,
                            EVER_ON_HOLD,
                            CAST(RELEASE_GROUP_ID as DECIMAL(38,0)) RELEASE_GROUP_ID,
                            ESTIMATED_REL_DATE, 
                            CAST(BUSINESS_GROUP_ID as DECIMAL(38,0)) BUSINESS_GROUP_ID,
                            SOURCE,
                            CAST(RELEASED_AMOUNT as DECIMAL(38,8)) RELEASED_AMOUNT,
                            CAST(HELD_AMOUNT as DECIMAL(38,8)) HELD_AMOUNT,
                            CAST(RUN_ID as DECIMAL(38,0)) RUN_ID,
                            INCENTIVE_DATE,
                            CAST(EFF_PARTICIPANT_ID as DECIMAL(38,0)) EFF_PARTICIPANT_ID,
                            CAST(EFF_POSITION_ID as DECIMAL(38,0)) EFF_POSITION_ID,
                            CAST(PLAN_ID as DECIMAL(38,0)) PLAN_ID,
                            PLAN_NAME,
                            CAST(CREDIT_TYPE_ID as DECIMAL(38,0)) CREDIT_TYPE_ID,
                            CAST(ROLL_MEASURE_VALUE as DECIMAL(38,8)) ROLL_MEASURE_VALUE,
                            CAST(ROLL_ATTAINMENT_VALUE as DECIMAL(38,8)) ROLL_ATTAINMENT_VALUE,
                            CAST(CREDIT_APPLIED as DECIMAL(38,0)) CREDIT_APPLIED,
                            CAST(RATE_TABLE_TIER as DECIMAL(38,0)) RATE_TABLE_TIER,
                            CREATED_DATE,
                            CAST(CREATED_BY_ID as DECIMAL(38,0)) CREATED_BY_ID,
                            CREATED_BY_NAME,
                            MODIFIED_DATE,
                            CAST(MODIFIED_BY_ID as DECIMAL(38,0)) MODIFIED_BY_ID,
                            MODIFIED_BY_NAME,
                            CAST(PENDING_COMMISSION_AMOUNT as DECIMAL(38,8)) PENDING_COMMISSION_AMOUNT,
                            CAST(CALCULATED_RATE as DECIMAL(38,8)) CALCULATED_RATE,
                            CAST(ROLLING_INCENTIVE_ATTAINMENT as DECIMAL(38,8)) ROLLING_INCENTIVE_ATTAINMENT,
                            CAST(INCENTIVE_ATTAINMENT as DECIMAL(38,8)) INCENTIVE_ATTAINMENT,
                            CAST(PT_ACHIEVED_PERCENTAGE as DECIMAL(38,8)) PT_ACHIEVED_PERCENTAGE,
                            CAST(APPLIED_CREDIT_AMOUNT as DECIMAL(38,8)) APPLIED_CREDIT_AMOUNT,
                            EVER_ON_PENDING,
                            IS_PENDING,
                            ATTAINMENT_MEASURE_HASH,
                            PAYCURVE_VERSION_ID,
                            PAYCURVE_NAME,
                            CAST(RATE_TYPE as DECIMAL(38,0)) RATE_TYPE,
                            CAST(PT_VALUE as DECIMAL(38,8)) PT_VALUE,
                            CAST(MULTIPLIER_VALUE as DECIMAL(38,8)) MULTIPLIER_VALUE,
                            MULTIPLIER,
                            CAST(MGR_EFF_POS_ID as DECIMAL(38,0)) MGR_EFF_POS_ID,
                            CAST(MGR_MASTER_POS_ID as DECIMAL(38,0)) MGR_MASTER_POS_ID,
                            CAST(MGR_EFF_PART_ID as DECIMAL(38,0)) MGR_EFF_PART_ID, 
                            PROCESS_FILE,
                            PROCESS_DATE,
                            PROCESS_USER                                                     
                         FROM {target_catalog}.{target_bronze_schema}.{commission_bronze_tablename} 
                         WHERE PROCESS_DATE = '{latestProcessDate}' ''')

# COMMAND ----------

# MAGIC %md
# MAGIC Add fiscal attributes to the data extracted from bronze commissions table

# COMMAND ----------

df_dates = spark.sql(f''' SELECT 
                              DISTINCT concat(upper(substring(monthName,0,3)), '-', string(year)) as DT_PERIOD_NAME, 
                              fiscal_month as FISCAL_MONTH, 
                              fy_quarter as FISCAL_QUARTER, 
                              fy_year as FISCAL_YEAR 
                          FROM main.it_core_dim.bi_dates''')
                          
df_commissions_bronze = df_commissions.join(df_dates,df_commissions.PERIOD_NAME ==  df_dates.DT_PERIOD_NAME,"inner")
df_commissions_bronze = df_commissions_bronze.drop('date','DT_PERIOD_NAME')

df_commissions_bronze.createOrReplaceTempView("commission_bronze")

# COMMAND ----------

# MAGIC %md
# MAGIC Extract latest data from silver commissions table

# COMMAND ----------

df_commissions_latest_silver = spark.sql(f'''
                                         
          SELECT *
          FROM {target_catalog}.{target_silver_schema}.{commission_silver_tablename}
          WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_silver_schema}.{commission_silver_tablename})
                                          
                                          ''')
                                          
df_commissions_latest_silver.createOrReplaceTempView("commissions_latest_silver")

# COMMAND ----------

# MAGIC %md
# MAGIC Check DISTINCT PERIOD_NAMES in bronze commissions data

# COMMAND ----------

distinct_period_names = df_commissions_bronze.select("PERIOD_NAME").distinct().rdd.flatMap(lambda x: x).collect()
distinct_period_names

# COMMAND ----------

# MAGIC %md
# MAGIC DELETE rows from latest Silver Commissions data which have PERIOD_NAMES same as above

# COMMAND ----------

# Filter rows in Silver where PERIOD_NAME is not in distinct_period_names_values

silver_filtered = df_commissions_latest_silver.filter(~col("PERIOD_NAME").isin(distinct_period_names))

# COMMAND ----------

# MAGIC %md
# MAGIC Add Bronze commissions data to filtered Silver commissions data

# COMMAND ----------

silver_combined = silver_filtered.unionByName(df_commissions_bronze)
silver_combined.createOrReplaceTempView("silver_combined")

# COMMAND ----------

# MAGIC %md
# MAGIC Update PROCESS_DATE with the current process date

# COMMAND ----------

silver_combined = silver_combined.drop("PROCESS_DATE","PROCESS_USER")
final_silver_combined, processDate = add_audit_attributes(silver_combined)
final_silver_combined = final_silver_combined.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_silver_combined.createOrReplaceTempView("final_silver_combined_table")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT PROCESS_DATE, COUNT(DISTINCT PERIOD_NAME), COUNT(*)
# MAGIC FROM final_silver_combined_table
# MAGIC GROUP BY PROCESS_DATE
# MAGIC ORDER BY PROCESS_DATE DESC

# COMMAND ----------

# MAGIC %md
# MAGIC Load the combined Silver Commissions Data into LogFood

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
full_silver_commissions_tablename = f'{target_catalog}.{target_silver_schema}.{commission_silver_tablename}'

print (f'Updating data in {full_silver_commissions_tablename} for {processDate}')

(final_silver_combined
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_silver_commissions_tablename))

# COMMAND ----------


