# Databricks notebook source
from datetime import datetime, timedelta
from pyspark.sql.functions import col, lit
import datetime

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# DBTITLE 1,Sales Compensation Snapshot Tracker
target_tablename = 'sales_comp_attainment'
snapshot_tablename = 'sales_comp_attainment_history'

# COMMAND ----------

# MAGIC %md
# MAGIC ### SNAPSHOT TABLE

# COMMAND ----------

#Extract the data in xc_participant_extended which contains the latest data

full_raw_table_name_snap = f'{target_catalog}.{target_silver_schema}.{snapshot_tablename}'
df_snap = sql(f''' SELECT * FROM {target_catalog}.{target_silver_schema}.{target_tablename} ''')

# COMMAND ----------

df_snap = df_snap.drop("PROCESS_DATE","PROCESS_USER")

# COMMAND ----------

final_df_snap, processDate = add_audit_attributes(df_snap)
final_df_snap = final_df_snap.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_df_snap.createOrReplaceTempView("SNAPSHOT_TABLE")

# COMMAND ----------

# DBTITLE 1,Delta Table Update Logger
date_str = processDate.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {processDate}')

(final_df_snap
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC ### FINAL TABLE

# COMMAND ----------

# DBTITLE 1,Commission Currency Conversion Report
df_COMM_CURR_POS = spark.sql(
    f"""
  (
    SELECT  
        co.PARTICIPANT_NAME,
        co.POSITION_NAME,
        SUM(CASE WHEN co.EARNING_GROUP_NAME NOT LIKE '%Gate Not%' THEN co.AMOUNT ELSE 0 END) as COMMISSIONS_LOCAL,
        co.AMOUNT_DISPLAY_SYMBOL, 
        (
          CASE WHEN co.AMOUNT_DISPLAY_SYMBOL ='USD' THEN 1.0000000000
                ELSE cu.exchange_rate 
          END
        ) as FX_USD,
        ROUND(SUM(
          CASE 
            WHEN co.EARNING_GROUP_NAME NOT LIKE '%Gate Not%' AND co.AMOUNT_DISPLAY_SYMBOL ='USD' THEN co.AMOUNT
            WHEN co.EARNING_GROUP_NAME NOT LIKE '%Gate Not%' AND co.AMOUNT_DISPLAY_SYMBOL NOT LIKE 'USD' THEN (co.AMOUNT*cu.exchange_rate)
            ELSE 0 
          END), 
        2) as COMMISSIONS_USD,
        SUM(0) as AMOUNT_USD, 
        co.PERIOD_NAME,
        CAST(xp.START_DATE AS DATE) COMM_PERIOD_START_DATE,
        CAST(xp.END_DATE AS DATE) COMM_PERIOD_END_DATE, 
        pt.TITLE_NAME,
        SUM(CASE WHEN co.IS_CREDIT_APPLY = 1 THEN co.CREDIT_AMOUNT ELSE 0 END) as CREDIT_AMOUNT,
        (
          CASE WHEN co.QUOTA_NAME IS NULL or co.QUOTA_NAME = '' THEN co.EARNING_GROUP_NAME
               ELSE co.QUOTA_NAME 
          END
        ) as COMPONENT

    FROM {target_catalog}.fin_commissions_silver.xc_commission co 
    LEFT JOIN {target_catalog}.fin_commissions_silver.xc_currency_rate cu 
          ON co.AMOUNT_DISPLAY_SYMBOL = cu.base_currency_name AND 
             cu.target_currency_name ='USD' AND 
             co.INCENTIVE_DATE >= cu.active_start_date AND 
             co.INCENTIVE_DATE <= cu.active_end_date
    LEFT JOIN {target_catalog}.fin_commissions_silver.xc_pos_title_assignment pt  
          ON co.EFF_POSITION_ID = pt.POSITION_ID
    INNER JOIN {target_catalog}.fin_commissions_silver.xc_period xp 
          ON co.PERIOD_ID = xp.PERIOD_ID

    WHERE  
        CASE 
          WHEN CAST(xp.START_DATE AS DATE) < '2024-01-31'
              THEN co.EARNING_GROUP_NAME NOT LIKE 'Quarterly%'
          ELSE (
                co.EARNING_GROUP_NAME NOT LIKE 'Quarterly%' 
            AND co.EARNING_GROUP_NAME NOT LIKE 'Monthly%'
            AND co.EARNING_GROUP_NAME NOT LIKE '%BCF%'
          )
        END 
        AND (cu.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_currency_rate) OR cu.PROCESS_DATE IS NULL) 
        AND (pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_pos_title_assignment) or pt.PROCESS_DATE IS NULL) 
        AND xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_period) 
        AND co.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_commission)

            
    GROUP BY co.PARTICIPANT_NAME, 
             co.POSITION_NAME, 
             co.AMOUNT_DISPLAY_SYMBOL, 
             co.PERIOD_NAME, 
             COMPONENT, 
             pt.TITLE_NAME, 
             xp.START_DATE, 
             xp.END_DATE, 
             FX_USD
)

UNION

(
  SELECT  
        co.PARTICIPANT_NAME,
        co.POSITION_NAME,
        SUM(CASE WHEN co.EARNING_GROUP_NAME NOT LIKE '%Gate Not%' THEN co.AMOUNT ELSE 0 END) as COMMISSIONS_LOCAL,
        co.AMOUNT_DISPLAY_SYMBOL, 
        (
          CASE WHEN co.AMOUNT_DISPLAY_SYMBOL ='USD' THEN 1.0000000000
                ELSE cu.exchange_rate 
          END
        ) as FX_USD,
        ROUND(SUM(
          CASE 
            WHEN co.EARNING_GROUP_NAME NOT LIKE '%Gate Not%' AND co.AMOUNT_DISPLAY_SYMBOL ='USD' THEN co.AMOUNT
            WHEN co.EARNING_GROUP_NAME NOT LIKE '%Gate Not%' AND co.AMOUNT_DISPLAY_SYMBOL NOT LIKE 'USD' THEN (co.AMOUNT*cu.exchange_rate)
            ELSE 0 
          END), 
        2) as COMMISSIONS_USD,
        SUM(0) as AMOUNT_USD, 
        co.PERIOD_NAME,
        CAST(xp.START_DATE AS DATE) COMM_PERIOD_START_DATE,
        CAST(xp.END_DATE AS DATE) COMM_PERIOD_END_DATE, 
        pt.TITLE_NAME,
        SUM(0) as CREDIT_AMOUNT,
        co.EARNING_GROUP_NAME as COMPONENT

FROM {target_catalog}.fin_commissions_silver.xc_bonus co 
LEFT JOIN {target_catalog}.fin_commissions_silver.xc_currency_rate cu 
      ON co.AMOUNT_DISPLAY_SYMBOL = cu.base_currency_name AND 
        cu.target_currency_name ='USD' AND 
        co.INCENTIVE_DATE >= cu.active_start_date AND 
        co.INCENTIVE_DATE <= cu.active_end_date
LEFT JOIN {target_catalog}.fin_commissions_silver.xc_pos_title_assignment pt  
      ON co.EFF_POSITION_ID = pt.POSITION_ID
INNER JOIN {target_catalog}.fin_commissions_silver.xc_period xp 
      ON co.PERIOD_ID = xp.PERIOD_ID

WHERE  CASE 
          WHEN CAST(xp.START_DATE AS DATE) < '2024-01-31'
              THEN co.EARNING_GROUP_NAME NOT LIKE 'Quarterly%'
          ELSE (
                    co.EARNING_GROUP_NAME NOT LIKE 'Quarterly%' 
                AND co.EARNING_GROUP_NAME NOT LIKE 'Monthly%'
                AND co.EARNING_GROUP_NAME NOT LIKE '%BCF%'
              )
        END

        AND (cu.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_currency_rate) OR cu.PROCESS_DATE IS NULL) 
        AND (pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_pos_title_assignment) or pt.PROCESS_DATE IS NULL) 
        AND xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_period) 
        AND co.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_bonus)

GROUP BY co.PARTICIPANT_NAME, 
         co.POSITION_NAME, 
         co.AMOUNT_DISPLAY_SYMBOL, 
         co.PERIOD_NAME, 
         COMPONENT, 
         pt.TITLE_NAME, 
         xp.START_DATE, 
         xp.END_DATE, 
         FX_USD
)

UNION

(
  SELECT  
        co.PARTICIPANT_NAME,
        co.POSITION_NAME,
        SUM(CASE WHEN co.EARNING_GROUP_NAME NOT LIKE '%Gate Not%' THEN co.AMOUNT ELSE 0 END) as COMMISSIONS_LOCAL,
        ut.NAME as AMOUNT_DISPLAY_SYMBOL, 
        co.bus_conversion_rate as FX_USD,
        ROUND(SUM(
          CASE 
            WHEN co.EARNING_GROUP_NAME NOT LIKE '%Gate Not%' AND ut.NAME  ='USD' THEN co.AMOUNT
            WHEN co.EARNING_GROUP_NAME NOT LIKE '%Gate Not%' AND ut.NAME  NOT LIKE 'USD' THEN (co.AMOUNT*co.bus_conversion_rate)
            ELSE 0 
          END), 
        2) as COMMISSIONS_USD,
        co.BUS_AMOUNT as AMOUNT_USD, 
        co.PERIOD_NAME,
        CAST(xp.START_DATE AS DATE) COMM_PERIOD_START_DATE,
        CAST(xp.END_DATE AS DATE) COMM_PERIOD_END_DATE, 
        pt.TITLE_NAME,
        SUM(0) as CREDIT_AMOUNT,
        co.EARNING_GROUP_NAME || ' SRC' as COMPONENT

FROM {target_catalog}.fin_commissions_silver.xc_payment co 
LEFT JOIN {target_catalog}.fin_commissions_silver.xc_unit_type ut
      ON co.AMOUNT_UNIT_TYPE_ID = ut.UNIT_TYPE_ID
LEFT JOIN {target_catalog}.fin_commissions_silver.xc_pos_title_assignment pt  
      ON co.EFF_POSITION_ID = pt.POSITION_ID
INNER JOIN {target_catalog}.fin_commissions_silver.xc_period xp 
      ON co.PERIOD_ID = xp.PERIOD_ID


WHERE  CASE 
          WHEN CAST(xp.START_DATE AS DATE) < '2024-01-31'
              THEN co.EARNING_GROUP_NAME NOT LIKE 'Quarterly%'
          ELSE (
                  co.EARNING_GROUP_NAME NOT LIKE 'Quarterly%' 
              AND co.EARNING_GROUP_NAME NOT LIKE 'Monthly%'
              AND co.EARNING_GROUP_NAME NOT LIKE '%BCF%'
            )
        END

        AND co.SRC_TYPE LIKE '%Draw%'
        AND (pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_pos_title_assignment) or pt.PROCESS_DATE IS NULL) 
        AND xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_period) 
        AND co.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_payment)
        AND ut.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_unit_type)

GROUP BY ALL
)

  """
)

df_COMM_CURR_POS.createOrReplaceTempView("COMM_CURR_POS")

# COMMAND ----------

# DBTITLE 1,Fiscal Period Ranking Query
df_PERIOD_DATA = spark.sql(
  f'''
  SELECT CAST(END_DATE as DATE) as PERIOD_END_DATE, 
        FISCAL_QUARTER_END_DATE, 
        FISCAL_HALF_END_DATE as HALF_END_DATE, 
        FISCAL_YEAR_END_DATE, 
        NAME as PERIOD_TEXT, 
        CONCAT('QTR-', SUBSTRING(FISCAL_QUARTER, -1, 1), '-', FISCAL_YEAR) FISCAL_QTR, 
        CONCAT(REVERSE(SPLIT_PART(FISCAL_HALF_YEAR,'-',2)),'-',FISCAL_YEAR) FISCAL_HALFYEAR, 
        FISCAL_YEAR,
        CASE 
          WHEN PERIOD_TEXT LIKE 'FEB%' OR PERIOD_TEXT LIKE 'MAY%' OR PERIOD_TEXT LIKE 'AUG%' OR PERIOD_TEXT LIKE 'NOV%' THEN 1
          WHEN PERIOD_TEXT LIKE 'MAR%' OR PERIOD_TEXT LIKE 'JUN%' OR PERIOD_TEXT LIKE 'SEP%' OR PERIOD_TEXT LIKE 'DEC%' THEN 2
          WHEN PERIOD_TEXT LIKE 'APR%' OR PERIOD_TEXT LIKE 'JUL%' OR PERIOD_TEXT LIKE 'OCT%' OR PERIOD_TEXT LIKE 'JAN%' THEN 3
        END AS QTR_RNK,
        CASE 
          WHEN MONTH(END_DATE)>=2 AND MONTH(END_DATE)<=7 THEN MONTH(END_DATE)-1 
          WHEN MONTH(END_DATE)>=8 AND MONTH(END_DATE)<=12 THEN MONTH(END_DATE)-7
          ELSE 6 
        END AS HY_RNK,
        CASE 
          WHEN MONTH(END_DATE)=1 THEN 12
          ELSE MONTH(END_DATE)-1
        END AS FY_RNK

  FROM {target_catalog}.fin_commissions_silver.xc_period
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_period)
  '''
)

df_PERIOD_DATA.createOrReplaceTempView('PERIOD_DATA')

# COMMAND ----------

# DBTITLE 1,Dynamic Component Title Mapping
df_COMPONENT_TITLE = spark.sql(
  f'''
  WITH TA as (
    SELECT * 
    FROM  {target_catalog}.fin_commissions_silver.Title_Attainment_Measure_Map 
    WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.Title_Attainment_Measure_Map)
    )
  SELECT DISTINCT CC.distinct_component as COMPONENT,
                CONCAT(CC.distinct_component, ' OTI') COMPONENT_OTI,
                CONCAT(CC.distinct_component, ' OTI Weight') COMPONENT_OTI_WEIGHT,
                TA.Attainment as ATTAINMENT_MEASURE, 
                Cat1 as COMPONENT_GROUP, 
                Cat2 AS COMPONENT_GROUP2,
                CASE 
                     WHEN TA.Title = 'Leader - Sales New Hire Hunter  (150)' THEN 'Leader - Sales New Hire Hunter (150)'
                     WHEN TA.Title = 'Leader - Sales New Hire Hunter  (130)' THEN 'Leader - Sales New Hire Hunter (130)'
                     WHEN TA.Title = 'Leader - Sales New Hire Hunter  (120)' THEN 'Leader - Sales New Hire Hunter (120)'
                     ELSE TA.Title
                END as Title,
                TA.Quarter
                
  FROM {target_catalog}.fin_commissions_silver.Component_Category_Map CC
  LEFT JOIN TA 
  ON CC.distinct_component = TA.Component

  WHERE CC.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.Component_Category_Map)
  '''
)

df_COMPONENT_TITLE.createOrReplaceTempView('COMPONENT_TITLE')

# COMMAND ----------

# DBTITLE 1,Spark SQL Quota Data Query
df_QUOTA_DATA = spark.sql(
  f'''
  WITH CTE AS (
    SELECT qa.ASSIGNMENT_NAME, 
          xp.NAME PERIOD_NAME,
          CAST(xp.START_DATE AS DATE) PERIOD_START_DATE,
          CAST(xp.END_DATE AS DATE) PERIOD_END_DATE, 
          qa.QUOTA_ASSIGNMENT_ID, 
          qa.QUOTA_ID, 
          qt.NAME, 
          qa.AMOUNT,
          xp.FISCAL_YEAR,
          qa.EFFECTIVE_START_PERIOD_ID,
          qa.EFFECTIVE_END_PERIOD_ID

  FROM {target_catalog}.fin_commissions_silver.xc_quota_assignment qa 
  LEFT JOIN {target_catalog}.fin_commissions_silver.xc_quota qt
    ON qa.QUOTA_ID = qt.QUOTA_ID 
  INNER JOIN {target_catalog}.fin_commissions_silver.xc_period xp 
      ON qa.PERIOD_ID = xp.PERIOD_ID
      
  WHERE qa.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_quota_assignment) AND
        qt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_quota) AND 
        xp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_period)
  )

  SELECT DISTINCT
         ct.*,
         CAST(xp_st.START_DATE as DATE) AS EFF_START_PERIOD_START_DATE,
         CAST(xp_st.END_DATE AS DATE) EFF_START_PERIOD_END_DATE,
         CAST(xp_en.START_DATE AS DATE) EFF_END_PERIOD_START_DATE,
         CAST(xp_en.END_DATE AS DATE) EFF_END_PERIOD_END_DATE

  FROM CTE ct
  INNER JOIN {target_catalog}.fin_commissions_silver.xc_period xp_st
  ON ct.EFFECTIVE_START_PERIOD_ID = xp_st.PERIOD_ID
  INNER JOIN {target_catalog}.fin_commissions_silver.xc_period xp_en
  ON ct.EFFECTIVE_END_PERIOD_ID = xp_en.PERIOD_ID
  
  '''
)

df_QUOTA_DATA.createOrReplaceTempView('QUOTA_DATA')

# COMMAND ----------

# DBTITLE 1,Spark SQL Participant Rank Selector
df_participant = spark.sql(f'''
                           WITH CTE AS (
                             SELECT pa.*,
                                  RANK() OVER (PARTITION BY PA.NAME ORDER BY VERSION DESC, EFFECTIVE_END_DATE DESC) participant_rank
                           FROM {target_catalog}.fin_commissions_silver.xc_participant pa
                           WHERE pa.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_participant) 
                                AND pa.WORKDAY_ID IS NOT NULL
                           ) 
                           SELECT *
                           FROM CTE
                           WHERE participant_rank = 1
                           ''')
df_participant.createOrReplaceTempView('df_participant')

# COMMAND ----------

# DBTITLE 1,Spark SQL Cumulative Analysis Query
df_CUMULATIVE_PART_1 = spark.sql(
  f'''
  SELECT DISTINCT
                cc.*,
                pd.*,
                ct.ATTAINMENT_MEASURE, 
                CASE 
                  WHEN ct.ATTAINMENT_MEASURE = 'Monthly' THEN pd.PERIOD_TEXT
                  WHEN ct.ATTAINMENT_MEASURE = 'Quarterly' THEN pd.FISCAL_QTR
                  WHEN ct.ATTAINMENT_MEASURE = 'SemiAnnual' THEN pd.FISCAL_HALFYEAR
                  WHEN ct.ATTAINMENT_MEASURE = 'Annual' THEN pd.FISCAL_YEAR
                END AS QUOTA_EXTRACT_PERIOD,
              ct2.COMPONENT_GROUP, 
              ct2.COMPONENT_GROUP2, 
              ct.COMPONENT_OTI,
              ct.COMPONENT_OTI_WEIGHT,
              CASE 
                WHEN TG.group IS NOT NULL 
                    THEN TG.Group ELSE 'New Hire' 
              END AS TITLE_GROUP,
              CASE 
                WHEN cc.COMPONENT LIKE 'S2 Opportunities - Upsell' AND cc.COMM_PERIOD_START_DATE < '2024-01-31'
                  THEN 'S2 Opportunities'
                ELSE cc.COMPONENT
              END AS COMPONENT_MODIFIED,
              SUBSTRING_INDEX(cc.PARTICIPANT_NAME, '(', 1) as REP_NAME,
              TRIM(')' FROM SUBSTRING(cc.PARTICIPANT_NAME, INSTR(cc.PARTICIPANT_NAME, '(')+1, LEN(cc.PARTICIPANT_NAME)-INSTR(cc.PARTICIPANT_NAME, '('))) as ID,
              bg.NAME as BUSINESS_GROUP_NAME,
              pa.WORKDAY_ID,
              CASE WHEN cc.COMPONENT LIKE 'Total Commit - Ramped' AND cc.COMM_PERIOD_START_DATE < '2024-01-31'
                      THEN 'Total Commit'
                    WHEN cc.COMPONENT LIKE 'Total Consumption - Ramped' AND cc.COMM_PERIOD_START_DATE < '2024-01-31'
                      THEN 'Total Consumption'
                    WHEN cc.COMPONENT LIKE 'T2 Commissionable Incremental Consumption' AND cc.COMM_PERIOD_START_DATE < '2024-01-31'
                      THEN 'Tier 2 Commissionable Incremental Consumption'
                    ELSE cc.COMPONENT
              END AS COMPONENT_QUOTA

FROM COMM_CURR_POS cc 
  INNER JOIN PERIOD_DATA pd
    ON cc.PERIOD_NAME = pd.PERIOD_TEXT

  LEFT JOIN COMPONENT_TITLE ct
    ON (ct.COMPONENT = cc.COMPONENT and ct.Title = cc.TITLE_NAME and ct.Quarter = pd.FISCAL_QTR)

  LEFT JOIN COMPONENT_TITLE ct2
    ON (ct2.COMPONENT = cc.COMPONENT)

  LEFT JOIN {target_catalog}.fin_commissions_silver.Title_Group_Map TG
    ON cc.TITLE_NAME = TG.distinct_title

  INNER JOIN df_participant pa
    ON TRIM(')' FROM SUBSTRING(cc.PARTICIPANT_NAME, INSTR(cc.PARTICIPANT_NAME, '(')+1, LEN(cc.PARTICIPANT_NAME)-INSTR(cc.PARTICIPANT_NAME, '('))) = TRIM(')' FROM SUBSTRING(pa.NAME, INSTR(pa.NAME, '(')+1, LEN(pa.NAME)-INSTR(pa.NAME, '(')))
    
  INNER JOIN {target_catalog}.fin_commissions_silver.xc_business_group bg
    ON pa.BUSINESS_GROUP_ID = bg.BUSINESS_GROUP_ID
    
  WHERE (bg.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.xc_business_group))
   AND (TG.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.fin_commissions_silver.Title_Group_Map))
  '''
)

df_CUMULATIVE_PART_1.createOrReplaceTempView('CUMULATIVE_PART_1')

# COMMAND ----------

# DBTITLE 1,Periodic Sales Performance Analysis
df_CUMULATIVE_PART_2 = spark.sql(
  f'''
  SELECT DISTINCT
      CP1.*,
      qd.EFF_START_PERIOD_START_DATE,
      qd.EFF_START_PERIOD_END_DATE,
      qd.EFF_END_PERIOD_START_DATE,
      qd.EFF_END_PERIOD_END_DATE,
      qd.PERIOD_START_DATE, 
      qd.AMOUNT AS QUOTA_COMPONENT,
      CASE 
        WHEN qd.AMOUNT IS NOT NULL THEN (TRY_DIVIDE(CREDIT_AMOUNT,qd.AMOUNT)*100) 
        ELSE qd.AMOUNT
      END 
        AS PERIODIC_ATTAINMENT_COMPONENT_PERCENTAGE,

      CASE 
        WHEN ATTAINMENT_MEASURE = 'Monthly' THEN (CASE WHEN qd.AMOUNT IS NOT NULL THEN (TRY_DIVIDE(CREDIT_AMOUNT,qd.AMOUNT)*100) ELSE qd.AMOUNT END)
        WHEN ATTAINMENT_MEASURE = 'Quarterly' THEN 
        (
          CASE WHEN qd.AMOUNT IS NOT NULL THEN (TRY_DIVIDE(SUM(CREDIT_AMOUNT) OVER (PARTITION BY POSITION_NAME, COMPONENT, FISCAL_QTR ORDER BY QTR_RNK), qd.AMOUNT)*100)
          ELSE qd.AMOUNT END
        )
        WHEN ATTAINMENT_MEASURE = 'SemiAnnual' THEN 
        (
          CASE WHEN qd.AMOUNT IS NOT NULL THEN (TRY_DIVIDE(SUM(CREDIT_AMOUNT) OVER (PARTITION BY POSITION_NAME, COMPONENT, FISCAL_HALFYEAR ORDER BY HY_RNK), qd.AMOUNT)*100)
          ELSE qd.AMOUNT END
        )
        WHEN ATTAINMENT_MEASURE = 'Annual' THEN 
        (
          CASE WHEN qd.AMOUNT IS NOT NULL THEN (TRY_DIVIDE(SUM(CREDIT_AMOUNT) OVER (PARTITION BY POSITION_NAME, COMPONENT, qd.FISCAL_YEAR ORDER BY FY_RNK), qd.AMOUNT)*100)
          ELSE qd.AMOUNT END  
        ) 
      END 
        AS CUMULATIVE_ATTAINMENT_COMPONENT,

      CASE 
        WHEN ATTAINMENT_MEASURE = 'Monthly' THEN COMMISSIONS_USD
        WHEN ATTAINMENT_MEASURE = 'Quarterly' THEN 
        (
          SUM(COMMISSIONS_USD) OVER (PARTITION BY POSITION_NAME, COMPONENT, FISCAL_QTR ORDER BY QTR_RNK)  
        )
        WHEN ATTAINMENT_MEASURE = 'SemiAnnual' THEN 
        (
          SUM(COMMISSIONS_USD) OVER (PARTITION BY POSITION_NAME, COMPONENT, FISCAL_HALFYEAR ORDER BY HY_RNK)  
        )
        WHEN ATTAINMENT_MEASURE = 'Annual' THEN 
        (
          SUM(COMMISSIONS_USD) OVER (PARTITION BY POSITION_NAME, COMPONENT, cp1.FISCAL_YEAR ORDER BY FY_RNK)  
        ) 
      END 
        AS CUMULATIVE_COMM_COMPONENT_USD,

      CASE 
        WHEN ATTAINMENT_MEASURE = 'Monthly' THEN CREDIT_AMOUNT
        WHEN ATTAINMENT_MEASURE = 'Quarterly' THEN 
          SUM(CREDIT_AMOUNT) OVER (PARTITION BY POSITION_NAME, COMPONENT, FISCAL_QTR ORDER BY QTR_RNK)

        WHEN ATTAINMENT_MEASURE = 'SemiAnnual' THEN 
          SUM(CREDIT_AMOUNT) OVER (PARTITION BY POSITION_NAME, COMPONENT, FISCAL_HALFYEAR ORDER BY HY_RNK)
          
        WHEN ATTAINMENT_MEASURE = 'Annual' THEN 
          SUM(CREDIT_AMOUNT) OVER (PARTITION BY POSITION_NAME, COMPONENT, qd.FISCAL_YEAR ORDER BY FY_RNK)
      END 
        AS CUMULATIVE_CREDIT_AMOUNT,
        
      qd_ot.AMOUNT AS OTI_COMPONENT,
      qd_ot_wt.AMOUNT AS OTI_WEIGHT

FROM CUMULATIVE_PART_1 cp1 
LEFT JOIN QUOTA_DATA qd 
  ON (
    qd.ASSIGNMENT_NAME = cp1.POSITION_NAME AND 
    qd.NAME = cp1.COMPONENT AND 
    qd.PERIOD_NAME = cp1.QUOTA_EXTRACT_PERIOD AND
    cp1.COMM_PERIOD_END_DATE >= qd.EFF_START_PERIOD_START_DATE AND 
    cp1.COMM_PERIOD_END_DATE <= qd.EFF_END_PERIOD_END_DATE )

LEFT JOIN QUOTA_DATA qd_ot
  ON (
    qd_ot.ASSIGNMENT_NAME = cp1.POSITION_NAME AND 
    qd_ot.NAME = cp1.COMPONENT_OTI AND 
    qd_ot.PERIOD_NAME = cp1.QUOTA_EXTRACT_PERIOD AND
    cp1.COMM_PERIOD_END_DATE >= qd_ot.EFF_START_PERIOD_START_DATE AND 
    cp1.COMM_PERIOD_END_DATE <= qd_ot.EFF_END_PERIOD_END_DATE )

LEFT JOIN QUOTA_DATA qd_ot_wt
  ON (
    qd_ot_wt.ASSIGNMENT_NAME = cp1.POSITION_NAME AND 
    qd_ot_wt.NAME = cp1.COMPONENT_OTI_WEIGHT AND 
    qd_ot_wt.PERIOD_NAME = cp1.FISCAL_YEAR AND
    cp1.COMM_PERIOD_END_DATE >= qd_ot_wt.EFF_START_PERIOD_START_DATE AND
    cp1.PERIOD_END_DATE <= qd_ot_wt.EFF_END_PERIOD_END_DATE)
'''
)

df_CUMULATIVE_PART_2.createOrReplaceTempView('CUMULATIVE_PART_2')

# COMMAND ----------

df_FINAL = spark.sql(
  '''
  SELECT PARTICIPANT_NAME,
      POSITION_NAME,
      COMMISSIONS_LOCAL,
      AMOUNT_DISPLAY_SYMBOL as LOCAL_CURRENCY,
      FX_USD,
      COMMISSIONS_USD,
      PERIOD_NAME as PERIOD,
      TITLE_NAME as TITLE,
      CREDIT_AMOUNT,
      CUMULATIVE_CREDIT_AMOUNT,
      COMPONENT,
      PERIOD_END_DATE,
      FISCAL_QUARTER_END_DATE as QUARTER_END_DATE,
      HALF_END_DATE,
      FISCAL_YEAR_END_DATE as YEAR_END_DATE,
      PERIOD_TEXT,
      FISCAL_QTR as QUARTER,
      FISCAL_HALFYEAR as HALF,
      FISCAL_YEAR as YEAR,
      ATTAINMENT_MEASURE,
      QUOTA_COMPONENT,
      PERIODIC_ATTAINMENT_COMPONENT_PERCENTAGE,
      CUMULATIVE_ATTAINMENT_COMPONENT,
      TITLE_GROUP,
      COMPONENT_GROUP,
      COMPONENT_GROUP2,
      CUMULATIVE_COMM_COMPONENT_USD,
      CASE
          WHEN CUMULATIVE_ATTAINMENT_COMPONENT>100 THEN 'Y'
          WHEN CUMULATIVE_ATTAINMENT_COMPONENT IS NULL THEN 'N/A'
          ELSE 'N'
      END AS ATTAINMENT_MORE_THAN_100,
      COMPONENT_MODIFIED,
      REP_NAME,
      ID,
      WORKDAY_ID,
      BUSINESS_GROUP_NAME as BUSINESS_GROUP,
      OTI_COMPONENT,
      OTI_WEIGHT,
      COMPONENT_QUOTA

FROM CUMULATIVE_PART_2
  '''
)

# COMMAND ----------

for col in df_FINAL.columns:
    df_FINAL = df_FINAL.withColumnRenamed(col, col.lower())

df_FINAL.createOrReplaceTempView('FINAL_OUTPUT')

# COMMAND ----------

# DBTITLE 1,Datetime Processing Adder
now = datetime.datetime.utcnow().date() 
df_FINAL = df_FINAL.withColumn('PROCESS_DATE', lit(now))

# COMMAND ----------

full_table_name = f'{target_catalog}.{target_silver_schema}.{target_tablename}'
print (f'Updating data in {full_table_name} for {now}')

(df_FINAL
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .saveAsTable(full_table_name))

# COMMAND ----------


