# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_pos_rel_type  
# MAGIC
# MAGIC Description: The xc_pos_rel_type table contains information about the different types of point of sale relationships. This table is important for tracking the various relationships between the business and its partners. It includes details such as the name, description, and effective dates of each relationship type. 
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Xactly JDBC Driver
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC   - **Table Name** : xc_pos_rel_type
# MAGIC   - **Description** : Contains Xactly xc_pos_rel_type raw data loaded after type casting attributes to support data types compatible with logFood.
# MAGIC   - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC
# MAGIC - **Silver Table**
# MAGIC   - **Schema Name** : fin_commissions_silver
# MAGIC   - **Table Name** : xc_pos_rel_type
# MAGIC   - **Description** : Additional fiscal attributes added using CREATED_DATE
# MAGIC   - **Additional Columns** : FISCAL_WEEK, FISCAL_MONTH, FISCAL_QUARTER, FISCAL_YEAR, PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC   - **Other Table Dependencies** : it_core_dim.bi_dates

# COMMAND ----------

from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
from pyspark.sql.functions import col, to_date
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_pos_rel_type'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_pos_rel_type'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT 
        CAST(POS_REL_TYPE_ID AS DECIMAL(38,0)) POS_REL_TYPE_ID,
        CAST(VERSION AS DECIMAL(38,0)) VERSION,
        NAME,
        DESCR,
        IS_ACTIVE,
        CAST(CREATED_DATE AS string) CREATED_DATE,
        CAST(CREATED_BY_ID AS DECIMAL(38,0)) CREATED_BY_ID,
        CREATED_BY_NAME,
        CAST(MODIFIED_DATE AS string) MODIFIED_DATE,
        CAST(MODIFIED_BY_ID AS DECIMAL(38,0)) MODIFIED_BY_ID,
        MODIFIED_BY_NAME,
        CAST(EFFECTIVE_START_DATE AS string) EFFECTIVE_START_DATE,
        CAST(EFFECTIVE_END_DATE AS string) EFFECTIVE_END_DATE,
        IS_MASTER
    FROM XACTLY.xc_pos_rel_type

)'''

df_pos_relations = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

# COMMAND ----------

from pyspark.sql import functions as F

yyyy_mm_dd_pattern = r'^\d{4}-\d{2}-\d{2}$'  
dd_mon_yy_pattern = r'^\d{2}-[A-Z]{3}-\d{2}$'  

df_fixed = df_pos_relations.withColumn(
    "EFFECTIVE_START_DATE",
    F.when(F.col("EFFECTIVE_START_DATE").rlike(yyyy_mm_dd_pattern), F.to_date(F.col("EFFECTIVE_START_DATE"), 'yyyy-MM-dd'))
    .when(F.col("EFFECTIVE_START_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.to_date(F.col("EFFECTIVE_START_DATE"), 'dd-MMM-yy'), 'yyyy-MM-dd'))
    .otherwise(None)  
).withColumn(
    "EFFECTIVE_END_DATE",
    F.when(F.col("EFFECTIVE_END_DATE").rlike(yyyy_mm_dd_pattern), F.date_format(F.last_day(F.to_date(F.col("EFFECTIVE_END_DATE"), 'yyyy-MM-dd')), 'yyyy-MM-dd'))
    .when(F.col("EFFECTIVE_END_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.last_day(F.to_date(F.col("EFFECTIVE_END_DATE"), 'dd-MMM-yy')), 'yyyy-MM-dd'))
    .otherwise(None)  
)


# COMMAND ----------

bronze_df_pos_relations, process_date = add_audit_attributes(df_fixed)
bronze_df_pos_relations = bronze_df_pos_relations.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_pos_relations
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                          fiscal_week AS FISCAL_WEEK, 
                          fiscal_month as FISCAL_MONTH, 
                          fy_quarter as FISCAL_QUARTER, 
                          fy_year as FISCAL_YEAR 
                     FROM main.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_fixed = df_fixed.withColumn('CREATED_DATE_UPD', to_date(col('CREATED_DATE')))
df_pos_relations_upd = df_fixed.join(df_dates, df_fixed.CREATED_DATE_UPD == df_dates.date, "inner")
df_pos_relations_upd = df_pos_relations_upd.drop('CREATED_DATE_UPD', 'date')

display(df_pos_relations_upd)

# COMMAND ----------

final_df_pos_relations, process_date = add_audit_attributes(df_pos_relations_upd)
final_df_pos_relations = final_df_pos_relations.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_pos_relations.columns:
    final_df_pos_relations = final_df_pos_relations.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_pos_relations
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))
