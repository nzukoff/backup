# Databricks notebook source
from datetime import datetime, timedelta
from pyspark.sql.functions import col, to_date
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xbpm_approval_doc_instance'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xbpm_approval_doc_instance'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT APPROVAL_DOC_INST_ID,
                DOC_OWNER_ID,
                DOC_OWNER_NAME,
                INSTANCE_STATUS,
                DOCUMENT_NAME,
                PROCESS_TEMPLATE_NAME,
                APPROVAL_DOC_DEF_ID,
                INITIATOR_ID,
                INITIATOR_NAME,
                INSTANCE_CONTEXT,
                CONTEXT_PARAM,
                RUN_ID,
                CAST(CAST(EFFECTIVE_DATE as DECIMAL(38,0)) as string) EFFECTIVE_DATE,
                CAST(ERROR_REASON_CODE as DECIMAL(38,0)) ERROR_REASON_CODE,
                DEFAULT_ERROR_REASON,
                CAST(CAST(START_DATE as DECIMAL(38,0)) as string) START_DATE ,
                CAST(CAST(END_DATE as DECIMAL(38,0)) as string) END_DATE ,
                CAST(IS_RELATIVE_DATE as DECIMAL(38,0)) IS_RELATIVE_DATE,
                DISPUTE_TYPE,
                SUBJECT,
                CAST(PARTICIPANT_ID as DECIMAL(38,0)) PARTICIPANT_ID,
                PROCESS_NAME,
                PROCESS_VERSION,
                SIGNATURE_TYPE,
                CAST(ROUTING_GROUP_INST_ID as string) ROUTING_GROUP_INST_ID,
                CAST(REASON_CODE_ID as string) REASON_CODE_ID ,
                CAST(DECLINE_REASON_CODE_ID as string) DECLINE_REASON_CODE_ID ,
                CAST(WORKFLOW_OWNER_ID as string) WORKFLOW_OWNER_ID ,
                CAST(DOC_OWNER_USER_ID as string) DOC_OWNER_USER_ID ,
                CAST(PLAN_ID as string) PLAN_ID ,
                CAST(PLAN_DOC_TEMPLATE_ID as string) PLAN_DOC_TEMPLATE_ID ,
                CAST(POSITION_ID as DECIMAL(38,0)) POSITION_ID ,
                CAST(TITLE_ID as DECIMAL(38,0)) TITLE_ID ,
                CAST(PARTICIPANT_HIST_ID as DECIMAL(38,0)) PARTICIPANT_HIST_ID ,
                CAST(POSITION_HIST_ID as DECIMAL(38,0)) POSITION_HIST_ID 

    FROM XACTLY.xbpm_approval_doc_instance

)'''

df_business = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

df_business.createOrReplaceTempView("Check_test")                    

# COMMAND ----------

bronze_df_business, process_date = add_audit_attributes(df_business)
bronze_df_business = bronze_df_business.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_business
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM main.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_business = df_business.withColumn('EFFECTIVE_DATE_UPD', to_date(col('EFFECTIVE_DATE')))
df_business_upd = df_business.join(df_dates,df_business.EFFECTIVE_DATE_UPD ==  df_dates.date,"inner")
df_business_upd = df_business_upd.drop('EFFECTIVE_DATE_UPD','date')

# COMMAND ----------

final_df_business, process_date = add_audit_attributes(df_business_upd)
final_df_business = final_df_business.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_business.columns:
    final_df_business = final_df_business.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_business
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))

# COMMAND ----------


