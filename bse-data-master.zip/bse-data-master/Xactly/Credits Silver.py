# Databricks notebook source
# MAGIC %run "./config_xc_report"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col, to_date
from pyspark.sql.functions import expr
import urllib
import urllib.request
import io
import pandas as pd
import boto3

# COMMAND ----------

credits_bronze_tablename = 'xc_credit'
credits_silver_tablename = 'xc_credit'

# COMMAND ----------

target_catalog

# COMMAND ----------

# MAGIC %md
# MAGIC Extract latest data from bronze credits table

# COMMAND ----------

latestProcessDate = spark.sql(f'''
                                SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{credits_bronze_tablename}
                              ''' ).collect()[0][0] 
print(latestProcessDate)

# COMMAND ----------

df_credits = spark.sql(f'''SELECT 
                          CAST(CREDIT_ID AS DECIMAL(38,0)) CREDIT_ID,
                          CAST(VERSION AS DECIMAL(38,0)) VERSION,
                          NAME,
                          IS_ACTIVE,
                          CAST(PERIOD_ID AS DECIMAL(38,0)) PERIOD_ID,
                          PERIOD_NAME,
                          CAST(AMOUNT AS DECIMAL(38,8)) AMOUNT,
                          CAST(AMOUNT_UNIT_TYPE_ID AS DECIMAL(38,0)) AMOUNT_UNIT_TYPE_ID,
                          AMOUNT_DISPLAY_SYMBOL,
                          CAST(PARTICIPANT_ID AS DECIMAL(38,0)) PARTICIPANT_ID,
                          PARTICIPANT_NAME,
                          CAST(POSITION_ID AS DECIMAL(38,0)) POSITION_ID,
                          POSITION_NAME,
                          CAST(ORDER_ITEM_ID AS DECIMAL(38,0)) ORDER_ITEM_ID,
                          ITEM_CODE,
                          ORDER_CODE,
                          CAST(RULE_ID AS DECIMAL(38,0)) RULE_ID,
                          RULE_NAME,
                          IS_PROCESSED,
                          IS_ROLLABLE,
                          CAST(SOURCE_CREDIT_ID AS DECIMAL(38,0)) SOURCE_CREDIT_ID,
                          CAST(SRC_POS_RELATION_TYPE_ID AS DECIMAL(38,0)) SRC_POS_RELATION_TYPE_ID,
                          CAST(CREDIT_TYPE_ID AS DECIMAL(38,0)) CREDIT_TYPE_ID,
                          CREDIT_TYPE_NAME,
                          IS_HELD,
                          RELEASE_DATE,
                          CAST(REASON_CODE_ID AS DECIMAL(38,0)) REASON_CODE_ID,
                          REASON_CODE_NAME,
                          ROLLABLE_ON_REPORTING,
                          CAST(PRODUCT_ID AS DECIMAL(38,0)) PRODUCT_ID,
                          PRODUCT_NAME,
                          CAST(CUSTOMER_ID AS DECIMAL(38,0)) CUSTOMER_ID,
                          CUSTOMER_NAME,
                          CAST(GEOGRAPHY_ID AS DECIMAL(38,0)) GEOGRAPHY_ID,
                          GEOGRAPHY_NAME,
                          CAST(TRANS_ID AS DECIMAL(38,0)) TRANS_ID,
                          CAST(BATCH_NUMBER AS DECIMAL(38,0)) BATCH_NUMBER,
                          CAST(SUB_BATCH_NUMBER AS DECIMAL(38,0)) SUB_BATCH_NUMBER,
                          EVER_ON_HOLD,
                          CAST(RELEASE_GROUP_ID AS DECIMAL(38,0)) RELEASE_GROUP_ID,
                          ESTIMATED_REL_DATE,
                          CAST(BUSINESS_GROUP_ID AS DECIMAL(38,0)) BUSINESS_GROUP_ID,
                          CAST(RUN_ID AS DECIMAL(38,0)) RUN_ID,
                          INCENTIVE_DATE,
                          CAST(EFF_PARTICIPANT_ID AS DECIMAL(38,0)) EFF_PARTICIPANT_ID,
                          CAST(EFF_POSITION_ID AS DECIMAL(38,0)) EFF_POSITION_ID,
                          CAST(PLAN_ID AS DECIMAL(38,0)) PLAN_ID,
                          PLAN_NAME,
                          CAST(SOURCE_POSITION_ID AS DECIMAL(38,0)) SOURCE_POSITION_ID,
                          CREATED_DATE,
                          CAST(CREATED_BY_ID AS DECIMAL(38,0)) CREATED_BY_ID,
                          CREATED_BY_NAME,
                          MODIFIED_DATE,
                          CAST(MODIFIED_BY_ID AS DECIMAL(38,0)) MODIFIED_BY_ID,
                          MODIFIED_BY_NAME,
                          SUB_PART_KEY,
                          CAST(MGR_EFF_POS_ID AS DECIMAL(38,0)) MGR_EFF_POS_ID,
                          CAST(MGR_MASTER_POS_ID AS DECIMAL(38,0)) MGR_MASTER_POS_ID,
                          CAST(MGR_EFF_PART_ID AS DECIMAL(38,0)) MGR_EFF_PART_ID,
                          PROCESS_FILE,
                          PROCESS_DATE,
                          PROCESS_USER                                         
                         FROM {target_catalog}.{target_bronze_schema}.{credits_bronze_tablename} 
                         WHERE PROCESS_DATE = '{latestProcessDate}' ''')

# COMMAND ----------

# MAGIC %md
# MAGIC Add fiscal attributes to the data extracted from bronze credits table

# COMMAND ----------

df_dates = spark.sql(f''' SELECT 
                              DISTINCT concat(upper(substring(monthName,0,3)), '-', string(year)) as DT_PERIOD_NAME, 
                              fiscal_month as FISCAL_MONTH, 
                              fy_quarter as FISCAL_QUARTER, 
                              fy_year as FISCAL_YEAR 
                          FROM main.it_core_dim.bi_dates''')
                          
df_credits_bronze = df_credits.join(df_dates,df_credits.PERIOD_NAME ==  df_dates.DT_PERIOD_NAME,"inner")
df_credits_bronze = df_credits_bronze.drop('date','DT_PERIOD_NAME')

df_credits_bronze.createOrReplaceTempView("credits_bronze")

# COMMAND ----------

# MAGIC %md
# MAGIC Extract latest data from silver credits table

# COMMAND ----------

df_credits_latest_silver = spark.sql(f'''
                                         
          SELECT *
          FROM {target_catalog}.{target_silver_schema}.{credits_silver_tablename}
          WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_silver_schema}.{credits_silver_tablename})
                                          
                                          ''')
                                          
df_credits_latest_silver.createOrReplaceTempView("credits_latest_silver")

# COMMAND ----------

# MAGIC %md
# MAGIC Check DISTINCT PERIOD_NAMES in bronze credits data

# COMMAND ----------

distinct_period_names = df_credits_bronze.select("PERIOD_NAME").distinct().rdd.flatMap(lambda x: x).collect()
distinct_period_names

# COMMAND ----------

# MAGIC %md
# MAGIC DELETE rows from latest Silver Credits data which have PERIOD_NAMES same as above

# COMMAND ----------

# Filter rows in Silver where PERIOD_NAME is not in distinct_period_names_values

silver_filtered = df_credits_latest_silver.filter(~col("PERIOD_NAME").isin(distinct_period_names))

# COMMAND ----------

# MAGIC %md
# MAGIC Add Bronze credits data to filtered Silver credits data

# COMMAND ----------

silver_combined = silver_filtered.unionByName(df_credits_bronze)
silver_combined.createOrReplaceTempView("silver_combined")

# COMMAND ----------

# MAGIC %md
# MAGIC Update PROCESS_DATE with the current process date

# COMMAND ----------

silver_combined = silver_combined.drop("PROCESS_DATE","PROCESS_USER")
final_silver_combined, processDate = add_audit_attributes(silver_combined)
final_silver_combined = final_silver_combined.withColumnRenamed('processUser', 'PROCESS_USER').withColumnRenamed('processDate', 'PROCESS_DATE')
final_silver_combined.createOrReplaceTempView("final_silver_combined_table")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT PROCESS_DATE, COUNT(DISTINCT PERIOD_NAME), COUNT(*)
# MAGIC FROM final_silver_combined_table
# MAGIC GROUP BY PROCESS_DATE
# MAGIC ORDER BY PROCESS_DATE DESC

# COMMAND ----------

# MAGIC %md
# MAGIC Load the combined Silver Credits Data into LogFood

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')
full_silver_credits_tablename = f'{target_catalog}.{target_silver_schema}.{credits_silver_tablename}'

print (f'Updating data in {full_silver_credits_tablename} for {processDate}')

(final_silver_combined
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(full_silver_credits_tablename))

# COMMAND ----------


