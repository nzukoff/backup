# Databricks notebook source
from datetime import datetime, timedelta
from pyspark.sql.functions import col, lit
import datetime

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

target_tablename = 'main.fin_commissions_attainment_silver.sales_comp_quota_metrics_reporting'

# COMMAND ----------

df_participant = spark.sql(f'''
        
WITH part_data as (
  SELECT pt.WORKDAY_ID as EID,
        us.ID SFDC_ID,
        concat(pt.FIRST_NAME,' ', pt.LAST_NAME) as PARTICIPANT_NAME,
        pp.POSITION_NAME POSITION_NAME,
        pt.PLAN_EFFECTIVE_START_DATE,
        pt.BCR_EFFECTIVE_START_DATE as OTI_EFFECTIVE_START_DATE,
        pt.JOB_TITLE,
        pt.SEGMENT,
        pt.HIRE_DATE,
        pa.TITLE_NAME as POSITION_TITLE,
        tg.`group` as TITLE_GROUP,
        us.Region_Level_1__c as REGION_LEVEL_1, 
        us.Region_Level_2__c as REGION_LEVEL_2, 
        us.Region_Level_3__c as REGION_LEVEL_3,
        us.Region_Level_4__c as REGION_LEVEL_4,
        un.NAME as LOCAL_CURRENCY,
        (
         CASE WHEN un.NAME ='USD' THEN 1.0000000000
                ELSE cr.exchange_rate 
          END
        ) as FX_RATE,
        CAST(pt.PERSONAL_TARGET as DECIMAL(38,0)) as ANNUAL_OTI,
        CAST(pt.PRORATED_PERSONAL_TARGET as DECIMAL(38,0)) as PRORATED_ANNUAL_OTI

  FROM main.fin_commissions_silver.xc_participant pt 
    LEFT JOIN main.fin_commissions_silver.latest_pos_part_mapping pp
      ON pt.PARTICIPANT_ID = pp.PARTICIPANT_ID

    LEFT JOIN main.fin_commissions_silver.xc_pos_title_assignment pa
      ON pp.POSITION_ID = pa.POSITION_ID
      AND pa.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_title_assignment)
      
    LEFT JOIN main.sfdc_bronze.user us
      ON pt.EMPLOYEE_ID = us.ID
      AND us.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.user)

    LEFT JOIN main.fin_commissions_silver.Title_Group_Map tg
      ON pa.TITLE_NAME = tg.distinct_title
      AND tg.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.Title_Group_Map)

    LEFT JOIN main.fin_commissions_silver.xc_unit_type un
     ON pt.PAYMENT_CUR_UNIT_TYPE_ID = un.UNIT_TYPE_ID
     AND un.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_unit_type)

    LEFT JOIN main.fin_commissions_silver.xc_currency_rate cr
     ON un.NAME = cr.base_currency_name AND 
        cr.target_currency_name = 'USD' AND 
        cr.active_end_date >= pt.PLAN_EFFECTIVE_START_DATE AND
        cr.active_start_date <= pt.BCR_EFFECTIVE_START_DATE AND
        cr.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_currency_rate) 

  WHERE pt.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_participant)
    AND pp.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.latest_pos_part_mapping) 
 
),

plan_data as (
  
  SELECT pd.*,
         pln.NAME as PLAN_NAME
         
  FROM part_data pd
    LEFT JOIN main.fin_commissions_silver.xc_plan_assignment plas
      ON pd.POSITION_TITLE = plas.ASSIGNMENT_NAME
    LEFT JOIN main.fin_commissions_silver.xc_plan pln
      ON plas.PLAN_ID = pln.PLAN_ID

  WHERE plas.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_plan_assignment)
    AND pln.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_plan)
    
    AND plas.ACTIVE_END_DATE >= current_date()

)

SELECT *
FROM plan_data

''')

df_participant.createOrReplaceTempView("participant_data")

# COMMAND ----------

df_quota_data = spark.sql(f'''

WITH quota_amount as (
  SELECT qa.ASSIGNMENT_NAME,
         q.name as QUOTA_NAME,
         qa.AMOUNT as QUOTA_AMOUNT
  FROM main.fin_commissions_silver.xc_quota_assignment qa
    JOIN main.fin_commissions_silver.xc_period p 
      ON qa.effective_start_period_id = p.period_id 
    JOIN main.fin_commissions_silver.xc_period pr 
      ON qa.effective_end_period_id = pr.period_id
    JOIN main.fin_commissions_silver.xc_quota q 
      ON qa.quota_id = q.quota_id
      AND q.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_quota  )
  WHERE qa.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_quota_assignment)
    AND p.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_period  )
    AND pr.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_period  )
    AND qa.AMOUNT != 0
    AND (CAST(pr.end_date as DATE)> current_date())
    AND q.name IN 
      (
        'Commissionable Incremental Consumption',
        'Activated Customer Count Consumption',
        'Activated Logo',
        'Activated Logo DB4K'
      )
),

quota_oti_weight as (
  SELECT qa.ASSIGNMENT_NAME,
         REPLACE(q.name, ' OTI Weight', '')  as QUOTA_NAME,
         qa.AMOUNT as OTI_WEIGHT
  FROM main.fin_commissions_silver.xc_quota_assignment qa
    JOIN main.fin_commissions_silver.xc_period p 
      ON qa.effective_start_period_id = p.period_id 
    JOIN main.fin_commissions_silver.xc_period pr 
      ON qa.effective_end_period_id = pr.period_id
    JOIN main.fin_commissions_silver.xc_quota q 
      ON qa.quota_id = q.quota_id
      AND q.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_quota  )
  WHERE qa.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_quota_assignment)
    AND p.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_period  )
    AND pr.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_period  )
    AND qa.AMOUNT != 0
    AND (CAST(pr.end_date as DATE)> current_date())
    AND q.name IN 
      (
        'Commissionable Incremental Consumption OTI Weight',
        'Activated Customer Count Consumption OTI Weight',
        'Activated Logo OTI Weight',
        'Activated Logo DB4K OTI Weight'
      )
),

quota_oti_amount as (
  SELECT qa.ASSIGNMENT_NAME,
         REPLACE(q.name, ' OTI', '') as QUOTA_NAME,
         qa.AMOUNT as COMPONENT_OTI
  FROM main.fin_commissions_silver.xc_quota_assignment qa
    JOIN main.fin_commissions_silver.xc_period p 
      ON qa.effective_start_period_id = p.period_id 
    JOIN main.fin_commissions_silver.xc_period pr 
      ON qa.effective_end_period_id = pr.period_id
    JOIN main.fin_commissions_silver.xc_quota q 
      ON qa.quota_id = q.quota_id
      AND q.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_quota  )
  WHERE qa.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_quota_assignment)
    AND p.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_period  )
    AND pr.PROCESS_DATE = ( SELECT MAX(PROCESS_DATE) FROM  main.fin_commissions_silver.xc_period  )
    AND qa.AMOUNT != 0
    AND (CAST(pr.end_date as DATE)> current_date())
    AND q.name IN 
      (
        'Commissionable Incremental Consumption OTI',
        'Activated Customer Count Consumption OTI',
        'Activated Logo OTI',
        'Activated Logo DB4K OTI'
      )
),

Final As (
  SELECT DISTINCT pt.*,
                qa.QUOTA_NAME,
                qa.QUOTA_AMOUNT,
                qw.OTI_WEIGHT,
                qo.COMPONENT_OTI
FROM participant_data pt
  LEFT JOIN quota_amount qa
    ON pt.POSITION_NAME = qa.ASSIGNMENT_NAME
  LEFT JOIN quota_oti_weight qw
    ON pt.POSITION_NAME = qw.ASSIGNMENT_NAME
    AND qa.QUOTA_NAME = qw.QUOTA_NAME
  LEFT JOIN quota_oti_amount qo
    ON pt.POSITION_NAME = qo.ASSIGNMENT_NAME
    AND qa.QUOTA_NAME = qo.QUOTA_NAME
WHERE qa.QUOTA_NAME IN ('Commissionable Incremental Consumption', 'Activated Customer Count Consumption', 'Activated Logo', 'Activated Logo DB4K')
)

SELECT *
FROM Final
                          
                          ''')
df_quota_data.createOrReplaceTempView("quota_data")

# COMMAND ----------

hierarchy_mapping = spark.sql(f'''
      WITH CTE AS 
      (
        SELECT DISTINCT
        ph.TO_POS_ID AEId, 
        ph.TO_POS_NAME AEName,
        ph.FROM_POS_ID M1Id, 
        ph.FROM_POS_NAME M1Name,
        MIN(pht.EFFECTIVE_START_DATE) EFFECTIVE_START_DATE,
        MAX(pht.EFFECTIVE_END_DATE) EFFECTIVE_END_DATE
        
      FROM main.fin_commissions_silver.xc_pos_hierarchy ph 
        JOIN main.fin_commissions_silver.xc_pos_hierarchy_type pht
          ON ph.POS_HIERARCHY_TYPE_ID = pht.POS_HIERARCHY_TYPE_ID

      WHERE 
          ph.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_hierarchy)
      AND pht.PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM main.fin_commissions_silver.xc_pos_hierarchy_type)

      GROUP BY ph.TO_POS_ID, ph.TO_POS_NAME, ph.FROM_POS_ID, ph.FROM_POS_NAME
    ),

    ranked_cte AS (
      SELECT *, 
          RANK() OVER (PARTITION BY AEId ORDER BY EFFECTIVE_START_DATE DESC) rnk
      FROM CTE
    ),

    latest_hierarchy AS (
    SELECT 
          AEId,
          AEName, 
          M1Id,
          M1Name,
          EFFECTIVE_START_DATE, 
          EFFECTIVE_END_DATE
    FROM ranked_cte
    WHERE rnk=1
    )

    SELECT *
    FROM CTE
    WHERE current_date()<=to_date(EFFECTIVE_END_DATE)
    '''
    )

hierarchy_mapping.createOrReplaceTempView("hierarchy_mapping")

# COMMAND ----------

final_df = spark.sql(f'''
SELECT pt.EID,
       pt.SFDC_ID,
       pt.PARTICIPANT_NAME,
       pt.PLAN_NAME, 
       pt.JOB_TITLE,
       pt.POSITION_TITLE,
       pt.TITLE_GROUP,
       pt.PLAN_EFFECTIVE_START_DATE,
       pt.OTI_EFFECTIVE_START_DATE,
       pt.SEGMENT,
       pt.HIRE_DATE,
       hr.M1Name as MANAGER_NAME,
       pt.REGION_LEVEL_1,
       pt.REGION_LEVEL_2,
       pt.REGION_LEVEL_3,
       pt.REGION_LEVEL_4,
       pt.LOCAL_CURRENCY,
       pt.QUOTA_NAME,
       pt.QUOTA_AMOUNT,
       pt.ANNUAL_OTI,
       pt.PRORATED_ANNUAL_OTI,
       pt.OTI_WEIGHT,
       pt.COMPONENT_OTI,
       pt.FX_RATE,
       (pt.COMPONENT_OTI/pt.QUOTA_AMOUNT)*100 as BASE_COMMISSION_RATE_LOCAL,
       ( (pt.COMPONENT_OTI * pt.FX_RATE) /pt.QUOTA_AMOUNT)*100 as BASE_COMMISSION_RATE_USD
       
FROM quota_data pt
  LEFT JOIN hierarchy_mapping hr
    ON pt.POSITION_NAME = hr.AEName                  
''')

final_df.createOrReplaceTempView("final_df")

# COMMAND ----------

from datetime import datetime
process_date = datetime.utcnow().date()
final_df = final_df.withColumn('processDate', lit(process_date))         
date_str = process_date.strftime('%Y-%m-%d')
print(f'Updating data in {target_tablename} for {process_date}')

(final_df.write
          .mode('overwrite')
          .option('mergeSchema', 'true')
          .option('replaceWhere', f"processDate = '{date_str}'")
          .partitionBy('processDate')
          .saveAsTable(target_tablename))
