# Databricks notebook source
# MAGIC %md 
# MAGIC # Xactly xc_period  
# MAGIC
# MAGIC Description: The xc_period table contains information about different periods used in financial reporting. It includes the period's start and end dates, as well as its type and order number. The table also tracks whether a period is active, open, published, visible, excluded from ETL, hidden, or a calculation period. Additionally, it provides information about the fiscal week, month, quarter, and year associated with each period. 
# MAGIC
# MAGIC Notes:
# MAGIC
# MAGIC - **Data Source** : Xactly
# MAGIC - **Data Connection** : Xactly JDBC Driver
# MAGIC - **Bronze Table**
# MAGIC   - **Schema Name** : fin_commissions_bronze
# MAGIC   - **Table Name** : xc_period
# MAGIC   - **Description** : Contains Xactly xc_period raw data loaded after type casting attributes to support data types compatible with logFood.
# MAGIC   - **Additional Columns** : PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC
# MAGIC - **Silver Table**
# MAGIC   - **Schema Name** : fin_commissions_silver
# MAGIC   - **Table Name** : xc_period
# MAGIC   - **Description** : Additional fiscal attributes added using START_DATE
# MAGIC   - **Additional Columns** : FISCAL_WEEK, FISCAL_MONTH, FISCAL_QUARTER, FISCAL_QUARTER_END_DATE, FISCAL_HALF_YEAR, FISCAL_HALF_END_DATE, FISCAL_YEAR, FISCAL_YEAR_END_DATE, PROCESS_USER, PROCESS_DATE
# MAGIC   - **Partition Column** : PROCESS_DATE
# MAGIC   - **Other Table Dependencies** : it_core_dim.bi_dates

# COMMAND ----------

from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_period'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_period'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT CAST(PERIOD_ID as DECIMAL(38,0)) PERIOD_ID,
        CAST(VERSION as DECIMAL(38,0)) VERSION,
        NAME,
        CAST(START_DATE as string) START_DATE,
        CAST(END_DATE as string) END_DATE,
        IS_ACTIVE,
        IS_OPEN,
        CAST(PARENT_PERIOD_ID as DECIMAL(38,0)) PARENT_PERIOD_ID,
        PERIOD_TYPE_ID_FK,
        CAST(CALENDAR_ID as DECIMAL(38,0)) CALENDAR_ID,
        CAST(ORDER_NUMBER as DECIMAL(38,0)) ORDER_NUMBER,
        CAST(CREATED_DATE as string) CREATED_DATE,
        CAST(CREATED_BY_ID as string) CREATED_BY_ID,
        CREATED_BY_NAME,
        CAST(MODIFIED_DATE as string) MODIFIED_DATE,
        CAST(MODIFIED_BY_ID as string) MODIFIED_BY_ID,
        MODIFIED_BY_NAME,
        IS_PUBLISHED,
        IS_VISIBLE,
        IS_ETL_EXCLUDED,
        IS_HIDDEN,
        IS_CALC_PERIOD
    FROM XACTLY.xc_period
)'''

df_period = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

# COMMAND ----------

from pyspark.sql import functions as F

yyyy_mm_dd_pattern = r'^\d{4}-\d{2}-\d{2}$'  
dd_mon_yy_pattern = r'^\d{2}-[A-Z]{3}-\d{2}$'  

df_fixed = df_period.withColumn(
    "START_DATE",
    F.when(F.col("START_DATE").rlike(yyyy_mm_dd_pattern), F.to_date(F.col("START_DATE"), 'yyyy-MM-dd'))
    .when(F.col("START_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.to_date(F.col("START_DATE"), 'dd-MMM-yy'), 'yyyy-MM-dd'))
    .otherwise(None)  
).withColumn(
    "END_DATE",
    F.when(F.col("END_DATE").rlike(yyyy_mm_dd_pattern), F.date_format(F.last_day(F.to_date(F.col("END_DATE"), 'yyyy-MM-dd')), 'yyyy-MM-dd'))
    .when(F.col("END_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.last_day(F.to_date(F.col("END_DATE"), 'dd-MMM-yy')), 'yyyy-MM-dd'))
    .otherwise(None)  
)

# COMMAND ----------

bronze_df_period, process_date = add_audit_attributes(df_fixed)
bronze_df_period = bronze_df_period.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_period
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR,
                            fiscal_quarter_end_date as FISCAL_QUARTER_END_DATE, 
                            fiscal_half_year as FISCAL_HALF_YEAR
                     FROM {target_catalog}.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_period_upd = df_fixed.join(df_dates, df_fixed.START_DATE ==  df_dates.date,"inner")
df_period_upd.createOrReplaceTempView("df_period_upd")

# COMMAND ----------

df_period_upd = spark.sql('''
  SELECT *,
       CASE 
            WHEN (MONTH(CAST(START_DATE as DATE))> 1) THEN CONCAT(YEAR(CAST(START_DATE as DATE))+1,'-01-31')
            ELSE CONCAT(YEAR(CAST(START_DATE as DATE)),'-01-31')
       END AS FISCAL_YEAR_END_DATE,
       CASE 
            WHEN (MONTH(CAST(END_DATE as DATE)) <= 7 AND MONTH(CAST(END_DATE as DATE)) >= 2) THEN CONCAT(YEAR(CAST(START_DATE as DATE)),'-07-31')
            WHEN (MONTH(CAST(END_DATE as DATE)) > 7 AND MONTH(CAST(END_DATE as DATE)) <=12 ) THEN CONCAT(YEAR(CAST(START_DATE as DATE))+1,'-01-31')
            ELSE CONCAT(YEAR(CAST(START_DATE as DATE)),'-01-31')
       END AS FISCAL_HALF_END_DATE
  FROM df_period_upd 
                          ''')

# COMMAND ----------

final_df_period, process_date = add_audit_attributes(df_period_upd)
final_df_period = final_df_period.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_period.columns:
    final_df_period = final_df_period.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_period
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))

# COMMAND ----------


