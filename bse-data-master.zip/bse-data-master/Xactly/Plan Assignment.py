# Databricks notebook source
from datetime import datetime, timedelta
from pyspark.sql.functions import col, to_date
from pyspark.sql import SparkSession
from delta.tables import DeltaTable
import calendar

# COMMAND ----------

# MAGIC %run "./config_xc_report"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Bronze Schema

# COMMAND ----------

#define params
url = xactly_JDBC_URL
DRIVER = 'com.xactly.connect.jdbc.Driver'

bronze_target_tablename = 'xc_plan_assignment'
bronze_table_name = f'{target_catalog}.{target_bronze_schema}.{bronze_target_tablename}'

silver_target_tablename = 'xc_plan_assignment'
silver_table_name = f'{target_catalog}.{target_silver_schema}.{silver_target_tablename}'

# COMMAND ----------

_select_sql_ = '''(
    SELECT  CAST(PLAN_ASSIGNMENT_ID as decimal(38,0)) PLAN_ASSIGNMENT_ID,
            CAST(VERSION as decimal(38,0)) VERSION,
            CAST(ASSIGNMENT_ID as decimal(38,0)) ASSIGNMENT_ID,
            CAST(ASSIGNMENT_TYPE as decimal(38,0)) ASSIGNMENT_TYPE,
            ASSIGNMENT_NAME,
            IS_ACTIVE,
            CAST(CREATED_DATE as string) CREATED_DATE,
            CAST(CREATED_BY_ID as decimal(38,0)) CREATED_BY_ID,
            CREATED_BY_NAME,
            CAST(MODIFIED_DATE as string) MODIFIED_DATE,
            CAST(MODIFIED_BY_ID as decimal(38,0)) MODIFIED_BY_ID,
            MODIFIED_BY_NAME,
            CAST(PLAN_ID as decimal(38,0)) PLAN_ID,
            CAST(ACTIVE_START_DATE as string) ACTIVE_START_DATE,
            CAST(ACTIVE_END_DATE as string) ACTIVE_END_DATE

    FROM XACTLY.xc_plan_assignment

)'''

df_business = spark.read.jdbc(url, 
          _select_sql_,
          properties={"user": xactly_JDBC_USER, 
                      "password": xactly_JDBC_PASS, 
                      "driver": DRIVER,
                      "clientId": xactly_JDBC_CLIENT,
                      "consumer":'Databricks',
                      "useSSL":'false',
                      "sslVerifyServer":'false' })

# COMMAND ----------

from pyspark.sql import functions as F

yyyy_mm_dd_pattern = r'^\d{4}-\d{2}-\d{2}$'  
dd_mon_yy_pattern = r'^\d{2}-[A-Z]{3}-\d{2}$'  

df_fixed = df_business.withColumn(
    "ACTIVE_START_DATE",
    F.when(F.col("ACTIVE_START_DATE").rlike(yyyy_mm_dd_pattern), F.to_date(F.col("ACTIVE_START_DATE"), 'yyyy-MM-dd'))
    .when(F.col("ACTIVE_START_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.to_date(F.col("ACTIVE_START_DATE"), 'dd-MMM-yy'), 'yyyy-MM-dd'))
    .otherwise(None)  
).withColumn(
    "ACTIVE_END_DATE",
    F.when(F.col("ACTIVE_END_DATE").rlike(yyyy_mm_dd_pattern), F.date_format(F.last_day(F.to_date(F.col("ACTIVE_END_DATE"), 'yyyy-MM-dd')), 'yyyy-MM-dd'))
    .when(F.col("ACTIVE_END_DATE").rlike(dd_mon_yy_pattern), F.date_format(F.last_day(F.to_date(F.col("ACTIVE_END_DATE"), 'dd-MMM-yy')), 'yyyy-MM-dd'))
    .otherwise(None)  
)

# COMMAND ----------

bronze_df_business, process_date = add_audit_attributes(df_fixed)
bronze_df_business = bronze_df_business.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {bronze_table_name} for {process_date}')

(bronze_df_business
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(bronze_table_name))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Quality Checks

# COMMAND ----------

#Check if there are any records flowing for the latest process date

records_count = spark.sql(f"""
  SELECT COUNT(*) as count_latest_records
  FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename}
  WHERE PROCESS_DATE = (SELECT MAX(PROCESS_DATE) FROM {target_catalog}.{target_bronze_schema}.{bronze_target_tablename})
  
""")

count_records = records_count.select(col("count_latest_records").cast("int")).first()[0]
if count_records < 0:
  raise Exception("There are no new records!!!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Silver Schema

# COMMAND ----------

df_dates = spark.sql(f''' 
                     SELECT date, 
                            fiscal_week AS FISCAL_WEEK, 
                            fiscal_month as FISCAL_MONTH, 
                            fy_quarter as FISCAL_QUARTER, 
                            fy_year as FISCAL_YEAR 
                     FROM main.it_core_dim.bi_dates
                     ''')

# COMMAND ----------

df_fixed = df_fixed.withColumn('CREATED_DATE_UPD', to_date(col('CREATED_DATE')))
df_business_upd = df_fixed.join(df_dates,df_fixed.CREATED_DATE_UPD ==  df_dates.date,"inner")
df_business_upd = df_business_upd.drop('CREATED_DATE_UPD','date')

# COMMAND ----------

final_df_business, process_date = add_audit_attributes(df_business_upd)
final_df_business = final_df_business.withColumnRenamed('processDate', 'PROCESS_DATE').withColumnRenamed('processUser', 'PROCESS_USER')

# COMMAND ----------

for col in final_df_business.columns:
    final_df_business = final_df_business.withColumnRenamed(col, col.upper())

# COMMAND ----------

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {silver_table_name} for {process_date}')

(final_df_business
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"PROCESS_DATE = '{date_str}'")
  .partitionBy("PROCESS_DATE")
  .saveAsTable(silver_table_name))
