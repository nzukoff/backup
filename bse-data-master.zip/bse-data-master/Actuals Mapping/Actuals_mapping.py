# Databricks notebook source
# MAGIC %run "./Shared-Defs"

# COMMAND ----------

from pyspark.sql.functions import col, lit
import numpy as np

# COMMAND ----------

dbutils.widgets.text("env", "uat")

# COMMAND ----------

ENV = dbutils.widgets.get("env")
if ENV == 'prod':
  CATALOG = 'main'
  SCHEMA = 'it_sfdc_silver'
else:
  CATALOG = 'integration'
  SCHEMA = 'it_sfdc_silver'

# COMMAND ----------

df = spark.read.option("header",True).csv("/Volumes/users/dhananjay_gavade/uploadeddata/T200 Actuals Mapping Accounts - Accounts In T200.csv")

# COMMAND ----------

df.createOrReplaceTempView("selected_accounts")

# COMMAND ----------

# Get entity consumption for last 180 days
fct_entity_consumption_df = spark.sql(
    """
    WITH ranked_entities AS (
      SELECT
        customer_id as sfdcAccountId,
        dim_customer_name as sfdcAccountName,
        workspace_id,
        entity_id,
        -- dim_entity_name as entity_name,
        CASE 
          WHEN dim_entity_type = 'job' THEN 'JOBS' 
          WHEN dim_entity_type = 'endpoint' THEN 'WAREHOUSE' 
          ELSE 'CLUSTERS' 
        END as entity_type,
        dim_workspace_name as workspace_name,
        m_entity_revenue as revenue,
        ds
        -- ,ROW_NUMBER() OVER (PARTITION BY entity_id ORDER BY ds DESC) as row_num
      FROM 
        main.metric_store.fct_entity_consumption f 
      INNER JOIN 
        selected_accounts s 
      ON 
        lower(f.dim_customer_name) = lower(s.sfdcAccountName)
      WHERE 
        ds >= date_sub(current_date(), 180)
    )
    SELECT
      sfdcAccountId,
      sfdcAccountName,
      workspace_id,
      entity_id,
      -- entity_name,
      entity_type,
      workspace_name,
      revenue,
      ds
    FROM 
      ranked_entities
    -- WHERE 
    --   row_num = 1
  """
)

fct_entity_consumption_df.createOrReplaceTempView("fct_entity_consumption_view")

# COMMAND ----------

# fct_entity_consumption_df.select("SfdcAccountName").distinct().count()

# COMMAND ----------

# Get usecase partition from DS table. Entity ID's are  budgetId - AccountId
usecase_segmentation_df = spark.sql(
  """
  WITH ranked_use_cases AS (
    SELECT
      workspaceId,
      budgetId,
      REGEXP_REPLACE(budgetId, CONCAT(sfdcAccountId, '-'), '') as entityId,
      partition as use_case_grouping,
      ROW_NUMBER() OVER (PARTITION BY REGEXP_REPLACE(budgetId, CONCAT(sfdcAccountId, '-'), '') ORDER BY date DESC) as row_num
    FROM
      main.data_growth_ds.use_case_segmentation_result
  )
  SELECT
    workspaceId,
    budgetId,
    entityId,
    use_case_grouping
  FROM
    ranked_use_cases
  WHERE
    row_num = 1
  """
)
usecase_segmentation_df.createOrReplaceTempView("usecase_segmentation_view")


# COMMAND ----------

#  Get billing tags by joining  billable_usage_tags with billable_usage. 
# EntityID is the cluster_id for Interactive, Job Id for jobs  and warehouse_id for other products.
billing_tags = spark.sql("""
    WITH billable_usage as (
     select workspace_id, product_type, CASE when compute.cluster_id is not null and product_type != 'JOBS' then compute.cluster_id ELSE CASE when compute.job_id is not null and product_type = 'JOBS' then compute.job_id ELSE   compute.warehouse_id END END as entity_id, record_id from main.eng_billable_usage.billable_usage
    ),
    bu_tags as 
    (
      select bu.workspace_id, bu.product_type,t.billing_tags, bu.entity_id from billable_usage bu join (select record_id, billing_tags from main.eng_billable_usage.billable_usage_tags )t on bu.record_id = t.record_id
    ),
      bu_tags_compute_type as 
    (
      select distinct workspace_id, product_type, explode(billing_tags), entity_id
      from bu_tags
    ),
  

    bu_concat as 
    (select distinct workspace_id, concat(key,' : ',value[0]) as billing_tags, entity_id from bu_tags_compute_type )
    
    select distinct workspace_id, concat_ws(', ',collect_set(billing_tags)) as billing_tags, entity_id from bu_concat group by workspace_id,entity_id
    """)
billing_tags.createOrReplaceTempView("billing_tags")

# COMMAND ----------

# MAGIC %sql
# MAGIC --  Get Entity_consumption, usecase and billing tags 
# MAGIC CREATE OR REPLACE TEMP VIEW fct_usecase_billing_tags_selected_accounts AS
# MAGIC WITH fct_entityname  AS (
# MAGIC   SELECT DISTINCT entity_id, dim_entity_name as entity_name, ROW_NUMBER() OVER (PARTITION BY entity_id ORDER BY ds DESC) as row_num 
# MAGIC   FROM main.metric_store.fct_entity_consumption
# MAGIC ),
# MAGIC fct_entity AS (
# MAGIC SELECT f.*, e.entity_name FROM fct_entity_consumption_view f LEFT JOIN (SELECT * FROM fct_entityname WHERE row_num = 1) e ON f.entity_id = e.entity_id 
# MAGIC ),
# MAGIC fct_usecase AS (
# MAGIC   SELECT DISTINCT
# MAGIC     f.sfdcAccountId,
# MAGIC     f.sfdcAccountName,
# MAGIC     f.workspace_id,
# MAGIC     f.entity_id,
# MAGIC     f.entity_name,
# MAGIC     f.entity_type,
# MAGIC     f.workspace_name,
# MAGIC     f.entity_type,
# MAGIC     f.ds,
# MAGIC     f.revenue,
# MAGIC     u.use_case_grouping
# MAGIC   FROM
# MAGIC     fct_entity f
# MAGIC       join
# MAGIC         usecase_segmentation_view u
# MAGIC         on
# MAGIC           f.workspace_id = u.workspaceId
# MAGIC           and f.entity_id = u.entityId
# MAGIC ),
# MAGIC fct_usecase_billing_tags AS (
# MAGIC   SELECT DISTINCT
# MAGIC     f.sfdcAccountId,
# MAGIC     f.sfdcAccountName,
# MAGIC     f.workspace_id,
# MAGIC     f.entity_id,
# MAGIC     f.entity_name,
# MAGIC     f.entity_type,
# MAGIC     f.workspace_name,
# MAGIC     f.revenue,
# MAGIC     f.ds,
# MAGIC     f.use_case_grouping,
# MAGIC     b.billing_tags
# MAGIC   FROM
# MAGIC     fct_usecase f
# MAGIC       LEFT JOIN
# MAGIC         billing_tags b
# MAGIC         ON
# MAGIC           f.workspace_id = b.workspace_id
# MAGIC           and replace(f.entity_id, 'endpoint-','') = replace(b.entity_id,'endpoint-','')
# MAGIC )
# MAGIC SELECT
# MAGIC   *
# MAGIC from
# MAGIC   fct_usecase_billing_tags

# COMMAND ----------

# Calculate the 28 days DBUs for each entity 
actuals = spark.sql("""
   WITH t28ddbu as (
  SELECT
    sfdcAccountId,
    workspace_id,
    entity_id,
    entity_name,
    entity_type,
    workspace_name,
    use_case_grouping,
    sum(revenue) as revenue,
    billing_tags
  FROM
    fct_usecase_billing_tags_selected_accounts
  where
    ds >= date_sub(current_date(), 28)
  GROUP BY
    ALL
),
t28ddbu_gt_0 AS (
  SELECT
    *
  FROM
    t28ddbu
  WHERE
    revenue > 0
),
final as (
  SELECT distinct
    sfdcAccountId as Account__c,
    billing_tags as BillingTags__c,
    entity_type as ComputeType__c,
    int(use_case_grouping) as DataScienceUseCaseGrouping__c,
    entity_id as EntityID__c,
    entity_name as EntityName__c,
    entity_type as EntityType__c,
    revenue as T28DDBUs__c,
    workspace_name as WorkspaceName__c
  FROM
    t28ddbu_gt_0
)
SELECT
  *
FROM
  final
ORDER BY
  Account__c 
    """)

# COMMAND ----------

actuals.createOrReplaceTempView("actuals_mapping_billing_tags")

# COMMAND ----------

spark.sql(f"""
    
CREATE TABLE IF NOT EXISTS {CATALOG}.{SCHEMA}.actuals_mapping_billing_tags(
  Account__c STRING NOT NULL
  COMMENT "Salesforce Account ID",
  BillingTags__c STRING
  COMMENT "Billing Tags",
  DataScienceUseCaseGrouping__c INTEGER
  COMMENT "Data Science Use Case Grouping",
  EntityID__c STRING
  COMMENT "Entity ID",
  EntityName__c STRING
  COMMENT "Entity Name",
  EntityType__c STRING
  COMMENT "Entity Type",
  T28DDBUs__c DOUBLE
  COMMENT "28 days DBUs",
  WorkspaceName__c STRING
  COMMENT "Workspace Name",
  processDate DATE
  COMMENT "Date of process"
)
COMMENT 'Actuals Mapping table' PARTITIONED BY (processDate)""")

# COMMAND ----------

# Actual_mapping with billing_tags
update_from_view(table_name="actuals_mapping_billing_tags", view_name="actuals_mapping_billing_tags", CATALOG=CATALOG, SCHEMA=SCHEMA)

# COMMAND ----------

# Saving Actuals table without billing tags
actuals_without_billing_tags = actuals.drop('BillingTags__c').distinct()
actuals_without_billing_tags.createOrReplaceTempView("actuals_without_billing_tags")

# COMMAND ----------

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS { CATALOG }.{ SCHEMA }.actuals_mapping (
  Account__c STRING NOT NULL
  COMMENT "Salesforce Account ID",
  DataScienceUseCaseGrouping__c INTEGER
  COMMENT "Data Science Use Case Grouping",
  EntityID__c STRING
  COMMENT "Entity ID",
  EntityName__c STRING
  COMMENT "Entity Name",
  EntityType__c STRING
  COMMENT "Entity Type",
  T28DDBUs__c DOUBLE
  COMMENT "28 days DBUs",
  WorkspaceName__c STRING
  COMMENT "Workspace Name",
  processDate DATE
  COMMENT "Date of process"
)
COMMENT 'Actuals Mapping table' PARTITIONED BY (processDate)""")

# COMMAND ----------

update_from_view(table_name="actuals_mapping", view_name="actuals_without_billing_tags", CATALOG=CATALOG, SCHEMA=SCHEMA)

# COMMAND ----------


