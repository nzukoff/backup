# Databricks notebook source
import sys
import subprocess
from dbruntime.dbutils import DBUtils
from pyspark.sql.session import SparkSession
from simple_salesforce import Salesforce
from datetime import datetime, date
import json
from typing import List, Dict
from pyspark.sql.functions import lit
from it_data_lib import *

sfdc_configs = {
    "prod": {
        "env_name": "bronze",
        "env_prefix": "",
        "table_prefix": "",
        "sfdc_env_prefix": "sfdcprod",
        "sfdc_domain_name": "login",
        "parquet_dir": "dbfs:/mnt/bse-prod/sfdc-extract/prod",
        "catalog": "main",
    },
    "stg": {
        "env_name": "bronze",
        "env_prefix": "it_",
        "table_prefix": "",
        "sfdc_env_prefix": "stgnew",
        "sfdc_domain_name": "test",
        "parquet_dir": "dbfs:/mnt/bse-dev/sfdc-extract/stg/",
        "catalog": "main",
    },
    "uat": {
        "env_name": "dev",
        "env_prefix": "it_",
        "table_prefix": "uat_",
        "sfdc_env_prefix": "uatnew",
        "sfdc_domain_name": "test",
        "parquet_dir": "dbfs:/mnt/bse-dev/sfdc-extract/uat",
        "catalog": "main",
    },
    "uat2": {
        "env_name": "bronze",
        "env_prefix": "it_",
        "table_prefix": "",
        "sfdc_env_prefix": "uat2",
        "sfdc_domain_name": "test",
        "parquet_dir": "dbfs:/mnt/bse-dev/sfdc-extract/uat2",
        "catalog": "main",
    },
    "sit": {
        "env_name": "bronze",
        "env_prefix": "it_",
        "table_prefix": "sit_",
        "sfdc_env_prefix": "sitnew",
        "sfdc_domain_name": "test",
        "parquet_dir": "dbfs:/mnt/bse-dev/sfdc-extract/sit",
        "catalog": "integration",
    },
    "qa": {
        "env_name": "bronze",
        "env_prefix": "it_",
        "table_prefix": "",
        "sfdc_env_prefix": "qanew",
        "sfdc_domain_name": "test",
        "parquet_dir": "dbfs:/mnt/bse-dev/sfdc-extract/qa",
        "catalog": "main",
    },
}

def get_creds(prefix:str,
              dbutils: DBUtils):
  """
  params:
         prefix - environment prefix
  returns:
         list of user_name, password, security_token
  """
  username = dbutils.secrets.get('api-creds', prefix+'_username')
  password = dbutils.secrets.get('api-creds', prefix+'_password')
  consumer_key = dbutils.secrets.get('api-creds', prefix+'_consumer_key')
  privatekey_file=dbutils.secrets.get('api-creds', prefix+'_privatekey_location')
  return [username, password, consumer_key, privatekey_file]


def get_sfdc_connection(creds: str,
                        domain: str,
                        Salesforce: Salesforce,
                        prefix: str):
  """
  params:
         creds - connection credentials
         domain - environment specific identifiers 
  returns:
         sfdc connection object
  """
  return Salesforce(username=creds[0], \
                    password=creds[1], \
                    consumer_key=creds[2], \
                    privatekey_file=creds[3], \
                    domain=domain)

  
def connect_to_sfdc(
                    dbutils: DBUtils,
                    Salesforce: Salesforce,
                    ENV: str
                  ):
  """
  params:
        ENV - environment prefix to connect to
  returns:
        sfdc connection object
  """

  # Cast all user-inputs to lowercase to avoid issues with capitalization
  ENV = ENV.lower()
  
  try:
    environment = sfdc_configs[ENV]['sfdc_env_prefix']
    domain = sfdc_configs[ENV]['sfdc_domain_name']

    salesforce_credentials = get_creds(environment, dbutils)
    salesforce_connection = get_sfdc_connection(salesforce_credentials, domain, Salesforce, environment)

    return salesforce_connection

  except:
    raise Exception(f"Environment {ENV} not found in configs. Please submit an existing environment [prod, uat2, dev, etc.].")

def update_salesforce_records(
    sf: Salesforce,
    object_name: str,
    external_id_field: str,
    records: List[Dict[str, Any]],
    batch_size: int,
    api_call_type: str,
    environment: str,
    job_name: str,
) -> Dict[str, int]:

    updated_records_count = 0
    failed_records_count = 0
    failed_records = []
    successful_records = []

    if api_call_type == 'update':
      # Update the records in Salesforce using the bulk API and store the result
      if job_name.lower() == 'anaplan_account_etm_sf_upload':
        result = getattr(sf.bulk, object_name).update(records, batch_size=batch_size, use_serial=True)
      else:
        result = getattr(sf.bulk, object_name).update(records, batch_size=batch_size)
    elif api_call_type == 'insert':
      # Insert the records in Salesforce using the bulk API and store the result
      result = getattr(sf.bulk, object_name).insert(records, batch_size=batch_size)
    elif api_call_type == 'upsert':
      # Upsert the records in Salesforce using the bulk API and store the result
      result = getattr(sf.bulk, object_name).upsert(records, batch_size=batch_size)
    elif api_call_type == 'delete':
      # Delete the records in Salesforce using the bulk API and store the result
      result = getattr(sf.bulk, object_name).delete(records, batch_size=batch_size)
    else:
      raise Exception(f"Invalid API call type: {api_call_type}. Please use 'update', 'insert', 'delete', or 'upsert'.")

    # Add the external ID field value to each dictionary in the result list and count the number of updated and failed records
    for r in result:
        if r["success"]:
            updated_records_count += 1
            if api_call_type == 'insert':
              successful_record = {
                  "job_name": job_name,
                  "sfdc_object_name": object_name,
                  "external_id": r.get('id'),
                  "api_call_type": api_call_type,
                  "environment": environment,
              }
            else:
              r[external_id_field] = records[result.index(r)][external_id_field]
              successful_record = {
                  "job_name": job_name,
                  "sfdc_object_name": object_name,
                  "external_id": r.get(external_id_field),
                  "api_call_type": api_call_type,
                  "environment": environment,
              }
            successful_records.append(successful_record)
        else:
            # Create a dictionary representing the failed record and append it to the failed_records list
            if api_call_type == 'insert':
              failed_record = {
                  "job_name": job_name,
                  "sfdc_object_name": object_name,
                  "external_id": '',
                  "error_message": r.get("errors")[0].get("message"),
                  "api_call_type": api_call_type,
                  "environment": environment,
              }
            else:
              r[external_id_field] = records[result.index(r)][external_id_field]
              failed_record = {
                  "job_name": job_name,
                  "sfdc_object_name": object_name,
                  "external_id": r.get(external_id_field),
                  "error_message": r.get("errors")[0].get("message"),
                  "api_call_type": api_call_type,
                  "environment": environment,
              }
            failed_records.append(failed_record)
            failed_records_count += 1

      # if len(successful_records) > 1:
      #     aggregated_dict = {
      #         "job_name": None,
      #         "sfdc_object_name": None,
      #         "api_call_type": None,
      #         "ids_uploaded": [],
      #     }
      #     for d in successful_records:
      #         if aggregated_dict["job_name"] is None:
      #             aggregated_dict["job_name"] = d["job_name"]
      #         if aggregated_dict["sfdc_object_name"] is None:
      #             aggregated_dict["sfdc_object_name"] = d["sfdc_object_name"]
      #         if aggregated_dict["api_call_type"] is None:
      #             aggregated_dict["api_call_type"] = d["api_call_type"]
      #         aggregated_dict["ids_uploaded"].append(d["external_id"])

    return {
        "updated_records_count": updated_records_count,
        "successful_records": successful_records,
        "failed_records_count": failed_records_count,
        "failed_records": failed_records,
    }


def create_failure_delta_table(
    data,
    job_name,
    spark: SparkSession,
    database_name="main.it_sfdc_audit",
    table_name="logfood_to_sfdc_errors",
    column_order=[
        "job_name",
        "sfdc_object_name",
        "external_id",
        "error_message",
        "api_call_type",
        "processDate",
        "environment",
    ],
    metadata_process_date_column="processDate",
):
    """
    Creates a Delta table with a specified database name, table name, and column order.
    Appends the new data to the existing table if it exists.

    params:
        database_name (str): The name of the database to create the table in.
        table_name (str): The name of the table to create.
        column_order (list of str): The desired order of columns in the table.
        data (list of dict): The data to populate the table with.
        job_name (str): The name of the job that is updating the table.
        metadata_process_date_column (str): The datetime partition of the table being updated.

    returns:
        None
    """

    date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:00:00")

    exists = table_exists(schema_name=database_name, table_name=table_name, spark=spark)

    df = spark.createDataFrame(data)
    df = df.withColumn("processDate", lit(date_str))

    # Reorder the columns in the DataFrame
    df = df.select(column_order)

    full_table_name = f"{database_name}.{table_name}"

    if not exists:
        (
            df.write.mode("overwrite")
            .format("delta")
            .partitionBy(metadata_process_date_column)
            .saveAsTable(full_table_name)
        )

    if exists:
        (
            df.write.mode("append")
            .format("delta")
            .option("mergeSchema", "true")
            .saveAsTable(full_table_name)
        )


def create_success_delta_table(
    data,
    job_name,
    spark: SparkSession,
    database_name="main.it_sfdc_audit",
    table_name="logfood_to_sfdc_success",
    column_order=[
        "job_name",
        "sfdc_object_name",
        "external_id",
        "api_call_type",
        "processDate",
        "environment",
    ],
    metadata_process_date_column="processDate",
):
    """
    Creates a Delta table with a specified database name, table name, and column order.
    Appends the new data to the existing table if it exists.

    params:
        database_name (str): The name of the database to create the table in.
        table_name (str): The name of the table to create.
        column_order (list of str): The desired order of columns in the table.
        data (list of dict): The data to populate the table with.
        job_name (str): The name of the job that is updating the table.
        metadata_process_date_column (str): The datetime partition of the table being updated.

    returns:
        None
    """

    date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:00:00")

    exists = table_exists(schema_name=database_name, table_name=table_name, spark=spark)

    df = spark.createDataFrame(data)
    df = df.withColumn("processDate", lit(date_str))

    # Reorder the columns in the DataFrame
    df = df.select(column_order)

    full_table_name = f"{database_name}.{table_name}"

    if not exists:
        (
            df.write.mode("overwrite")
            .format("delta")
            .partitionBy(metadata_process_date_column)
            .saveAsTable(full_table_name)
        )

    if exists:
        (
            df.write.mode("append")
            .format("delta")
            .option("mergeSchema", "true")
            .saveAsTable(full_table_name)
        )


def clean_audit_table(
    audit_table_name="main.it_sfdc_audit.logfood_to_sfdc_success",
    table_retention_days=90,
):
    # Read the existing Delta table
    df = spark.table(audit_table_name)

    # Filter the DataFrame to keep only the last 90 days of data
    df_filtered = df.filter(
        datediff(current_date(), col("processDate")) <= table_retention_days
    )

    # Overwrite the existing Delta table with the filtered data
    (
        df_filtered.write.format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(audit_table_name)
    )

def find_value_by_tuple(tuple_key, list_of_dicts, key1, key2,  key3=None, return_key=None):
    for dictionary in list_of_dicts:
        if key3 == None:
            if (dictionary.get(key1), dictionary.get(key2)) == tuple_key:
                return dictionary.get(return_key)
        else:
            if (dictionary.get(key1), dictionary.get(key2), dictionary.get(key3)) == tuple_key:
                return dictionary.get(return_key)
    return None
