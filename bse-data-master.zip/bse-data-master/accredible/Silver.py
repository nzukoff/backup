# Databricks notebook source
# MAGIC %md
# MAGIC # Accredible Silver
# MAGIC
# MAGIC This notebook reads data from the Accredible Bronze tables, and (where useful) other tables,
# MAGIC and creates the Accredible Silver tables.

# COMMAND ----------

# MAGIC %run "./Defs"

# COMMAND ----------

EMPLOYEE_BRANCH_CODE = 'DBK_EMP'

# COMMAND ----------

config_keys, default_config = configurations()
dbutils.widgets.dropdown(
    name="configuration",
    label="Configuration",
    choices=config_keys,
    defaultValue=default_config
)

log_levels, default_level = get_log_levels()
dbutils.widgets.dropdown(
    name="log_level",
    label="Logging level",
    choices=log_levels,
    defaultValue=default_level
)

dbutils.widgets.dropdown(
    name="recreate",
    label="Recreate tables?",
    choices=("yes", "no"),
    defaultValue="no"
)

# COMMAND ----------

config = get_configuration(dbutils.widgets.get("configuration"))
logger = configure_logging(dbutils.widgets.get("log_level"))
sql = make_sql(spark=spark, logger=logger, log_level=logging.INFO)
config

# COMMAND ----------

from typing import Dict, Sequence as Seq, Optional, Any
from datetime import date
from pyspark.sql.types import *
from pyspark.sql import functions as F

# COMMAND ----------

RECREATE = dbutils.widgets.get("recreate") == "yes"
logger.debug(f"{RECREATE=}")

# COMMAND ----------

def add_silver_metadata(
    df: DataFrame, process_date: Optional[date] = None
) -> DataFrame:
    """
    Add desired silver metadata to a DataFrame, prior to writing it
    to the Delta silver table.

    Returns a (DataFrame, processDate) tuple
    """
    now = process_date or get_process_date()
    df2 = df.withColumn(METADATA_PROCESS_DATE_COLUMN, F.lit(now))
    return (df2, now)


def update_silver_table(
    table_name: str, source_view: str, process_date: Optional[date] = None
) -> None:
    """
    Take a source DataFrame containing new data for a silver table, and
    update the silver table. This function assumes the source DataFrame
    contains ALL the data. It creates (or overwrites) the table for the
    current/specific process date. It does not merge the data into an existing
    process date.

    Parameters:

    table_name:   The name of the (Delta) table to create or update
    source_df:    DataFrame with source data
    process_date: Optional date to override the process date (which defaults to today)
    """
    full_table_name = f"{config.silver_database}.{table_name}"

    if RECREATE:
        logger.debug(f"Dropping and recreating {full_table_name}")
        sql(f"DROP TABLE IF EXISTS {full_table_name}")

    source_df = spark.table(source_view)
    rows = source_df.count()
    logger.info(f"{rows:,} row(s) in update data set")
    if rows == 0:
        logger.info(f'Skipping "{table_name}". New data has no rows.')
        return

    # Add metadata columns.
    final_df, process_date = add_silver_metadata(source_df, process_date)
    table_already_exists = spark.catalog.tableExists(f"{config.silver_database}.{table_name}")
    temp_view_name = f"{source_view}_final"
    date_str = process_date.strftime("%Y-%m-%d")
    logger.debug(f"Created temp view {temp_view_name} from {source_view}, with "
                 f"process date {date_str}")
    final_df.createOrReplaceTempView(temp_view_name)
    try:
        if not table_already_exists:
            logger.info(f"Creating {full_table_name}")
            sql(f'CREATE TABLE {full_table_name} PARTITIONED BY (processDate) AS SELECT * FROM {temp_view_name}')
        else:
            sql(f"DELETE FROM {full_table_name} WHERE processDate = '{date_str}'")
            sql(f'INSERT INTO {full_table_name} BY NAME SELECT * FROM {temp_view_name}')
    finally:
        logger.info(f"Dropping view {temp_view_name}")
        spark.catalog.dropTempView(temp_view_name)
        spark.catalog.dropTempView(source_view)


def conditionally_zap_column(
    df: DataFrame, column_name: str, branch_code_column_name: str = "branch_code"
) -> DataFrame:
    """
    Assumes the existence of a "branch_code" column in the supplied DataFrame.
    If the branch code indicates that the specified column should be masked out,
    this function nulls the column and returns a new DataFrame. Otherwise, leaves
    the column alone.

    Currently, we unconditionally mask out PII for all branches except the employee
    branch.
    """
    return (
        df.select(
            F.col("*"),
            F.when(
                F.col(branch_code_column_name) == EMPLOYEE_BRANCH_CODE,
                F.col(column_name),
            )
            .otherwise(None)
            .alias("temp"),
        )
        .drop(column_name)
        .withColumnRenamed("temp", column_name)
    )


# COMMAND ----------

sql(f'USE CATALOG {config.uc_catalog}')

# COMMAND ----------

hash_string = f'{config.silver_database}.hash_string'

sql(f'''
-- Isolate the cryptohash calculation here, so it can easily be
-- changed in one place.
CREATE OR REPLACE FUNCTION {hash_string}(s STRING COMMENT 'The string to be hashed')
  RETURNS STRING
  COMMENT 'Creates a cryptohash of a string.'
  CONTAINS SQL DETERMINISTIC
  RETURN CASE
    WHEN s IS NULL THEN null
    WHEN trim(s) == '' THEN null
    ELSE sha2(s, 256)
  END
'''
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Initialization

# COMMAND ----------

sql(f'CREATE DATABASE IF NOT EXISTS {config.silver_database}')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Groups

# COMMAND ----------

df = (
  spark
    .table(f'{config.bronze_database}.groups')
    .drop(BRONZE_METADATA_SOURCE_COLUMN)
    .drop(METADATA_PROCESS_DATE_COLUMN)
    .createOrReplaceTempView('silver_groups')
)
update_silver_table(table_name='accredible_groups', source_view='silver_groups')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Credentials

# COMMAND ----------

sql(f'''
create or replace temp view silver_credentials_base as
with
  creds as (
    select approve,
           complete,
           credential_id,
           credential_name,
           expired_on,
           case
             when expired_on is null then false
             when expired_on <= current_timestamp() then true
             else false
           end as is_expired,
           group_id,
           group_name,
           issued_on,
           {hash_string}(recipient_email) as learner_email_hash,
           split(lower(recipient_email), '@', 2)[1] as learner_email_domain,
           recipient_id as learner_id,
           -- Note: We are now masking learner PII in the Accredible data unconditionally.
           -- I could just leave these columns out, except that they were in the table
           -- before this change, and I don't want to adjust the schema after the fact.
           -- Here's what used to be below:
           --
           recipient_email as learner_email,
           recipient_name as learner_name
    from {config.bronze_database}.credentials
    where processDate = (select max(processDate) from {config.bronze_database}.credentials)
  ),
  people as (
    select username_hash,
           branch_code
    from it_training_silver.docebo_users
    where processDate = (select max(processDate) from it_training_silver.docebo_users)
  )
select creds.*,
       people.branch_code
from creds
left outer join people on creds.learner_email_hash = people.username_hash
'''
)

# COMMAND ----------

# Mask out email, first name, and last name for anyone who is not in the 
# employee branch.

df = spark.table('silver_credentials_base')
for c in ('learner_email', 'learner_name'):
  df = conditionally_zap_column(df, c)

df.createOrReplaceTempView('silver_credentials')

# COMMAND ----------

update_silver_table(table_name='accredible_credentials', source_view='silver_credentials')
