# Databricks notebook source
from dataclasses import dataclass
from pyspark.sql import DataFrame
import datetime
import logging
from typing import Callable, Sequence as Seq, Tuple, Optional

import sys
sys.path.insert(0, "..")
from it_data_lib import configure_logging, get_log_levels, make_sql

# COMMAND ----------

@dataclass(frozen=True)
class Config:
    secret_scope: str
    uc_catalog: str
    bronze_database: str
    silver_database: str

# COMMAND ----------

current_user = spark.sql('select current_user as `user`').first().user

# COMMAND ----------

# Current user can be just a UUID, so we have to 
# check first whether there's an @ at all.
if '@' in current_user:
    inbox, _ = current_user.split("@")
    user_schema = inbox.replace(".", "_")
else:
    user_schema = current_user

CONFIG_DEV = Config(
    secret_scope="accredible-pipeline-dev",
    uc_catalog="users",
    bronze_database=user_schema,
    silver_database=user_schema
)

CONFIG_INTEGRATION = Config(
    secret_scope="accredible-pipeline",
    uc_catalog="integration",
    bronze_database="it_accredible_bronze",
    silver_database="it_training_silver"
)

CONFIG_PRODUCTION = Config(
    secret_scope='accredible-pipeline',
    uc_catalog="main",
    bronze_database='it_accredible_bronze',
    silver_database='it_training_silver'
)

CONFIGURATIONS = {
    "dev": CONFIG_DEV,
    "integration": CONFIG_INTEGRATION,
    "production": CONFIG_PRODUCTION
}

# COMMAND ----------

def get_configuration(key: str) -> Config:
    """
    Given a key, get the corresponding configuration
    """
    try:
        return CONFIGURATIONS[key]
    except KeyError:
        raise ValueError(f"Invalid configuration key: {key}")

def configurations() -> Tuple[Seq[str], str]:
    """
    Get the list of valid configuration keys,
    as well as the default configuration.
    """
    return (list(CONFIGURATIONS.keys()), "dev")

# COMMAND ----------

METADATA_PROCESS_DATE_COLUMN = 'processDate'
BRONZE_METADATA_SOURCE_COLUMN = 'source'

# COMMAND ----------

def get_process_date() -> datetime.date:
    """
    Get the process date (which is added as a metadata column to all bronze 
    and silver tables.)
    """
    return datetime.datetime.utcnow().date()

def get_api_key(config: Config) -> str:
    """
    Get the Accredible API key from the secrets scope
    """
    return dbutils.secrets.get(config.secret_scope, 'accredible_api_key')
