# Databricks notebook source
# MAGIC %md
# MAGIC # Accredible Bronze
# MAGIC
# MAGIC This notebook pulls data down from Accredible and stores it, mostly unmodified,
# MAGIC in the data lake's Accredible Bronze database.

# COMMAND ----------

# MAGIC %run "./Defs"

# COMMAND ----------

config_keys, default_config = configurations()
dbutils.widgets.dropdown(
    name="configuration",
    label="Configuration",
    choices=config_keys,
    defaultValue=default_config
)

log_levels, default_level = get_log_levels()
dbutils.widgets.dropdown(
    name="log_level",
    label="Logging level",
    choices=log_levels,
    defaultValue=default_level
)

dbutils.widgets.dropdown(
    name="recreate",
    label="Recreate tables?",
    choices=("yes", "no"),
    defaultValue="no"
)

# COMMAND ----------

from pyspark.sql import functions as F
import requests
import datetime
import json
import logging
from typing import Dict, Sequence as Seq, Optional, Any

# COMMAND ----------

config = get_configuration(dbutils.widgets.get("configuration"))
logger = configure_logging(dbutils.widgets.get("log_level"))
sql = make_sql(spark=spark, logger=logger, log_level=logging.INFO)
config

# COMMAND ----------

ACCREDIBLE_API_URL_PREFIX = 'https://api.accredible.com/v1'

# The issuer/all_groups endpoint is officially deprecated and behaves like it's
# broken if groups cross page boundaries. But the search endpoint appears to work
# just fine, and does the same thing, if you post to it with no payload.
#ACCREDIBLE_API_GET_GROUPS_URL = f'{ACCREDIBLE_API_URL_PREFIX}/issuer/all_groups'
ACCREDIBLE_API_GET_GROUPS_URL = f'{ACCREDIBLE_API_URL_PREFIX}/issuer/groups/search'
ACCREDIBLE_GET_CREDENTIALS_URL = f'{ACCREDIBLE_API_URL_PREFIX}/credentials'

PAGE_SIZE = 200
ACCREDIBLE_API_KEY = dbutils.secrets.get(config.secret_scope, 'accredible_api_key')

# COMMAND ----------

RECREATE = dbutils.widgets.get("recreate") == "yes"
logger.debug(f"{RECREATE=}")

# COMMAND ----------

class AccredibleException(Exception):
    pass

# COMMAND ----------

def get_auth_headers() -> Dict[str, str]:
    """
    Get a dictionary representing the authorization headers
    necessary to access the Accredible REST API.
    """
    # ACCREDIBLE_API_KEY is set in Defs
    return {'Authorization': f'Bearer {ACCREDIBLE_API_KEY}'}

# COMMAND ----------

def add_bronze_metadata(df: DataFrame, docebo_table_name: str, process_date: Optional[datetime.date] = None) -> DataFrame:
  """
  Add desired bronze metadata to a JSON DataFrame, prior to writing it
  to the Delta bronze table.
  
  Returns a (DataFrame, processDate) tuple
  """
  now = process_date or get_process_date()
  df2 = (df
      .withColumn(METADATA_PROCESS_DATE_COLUMN, F.lit(now))
      .withColumn(BRONZE_METADATA_SOURCE_COLUMN, F.lit(docebo_table_name))
  )
  return (df2, now)

# COMMAND ----------

def import_table(table_name: str, df: DataFrame, source: str) -> None:
    """
    Read a JSON file and import its contents into the named table.

    Parameters:

    table_name:       The name of the (Delta) table to create or update
    s3_path:          URL/path to the S3 file (JSON) to be imported
    adjust_dataframe: Optional function to call to adjust the JSON DataFrame before writing it.
    """
    full_table_name = f"{config.bronze_database}.{table_name}"

    sql(f"USE CATALOG {config.uc_catalog}")
    if RECREATE:
        logger.info(f"Dropping and recreating {full_table_name}")
        sql(f"DROP TABLE IF EXISTS {full_table_name}")

    rows = df.count()
    if rows == 0:
        logger.info(f'Skipping table "{full_table_name}". Data contains no rows.')
        return

    logger.debug(f"Saving {rows:,} row(s) to {full_table_name}.")

    # Add metadata columns.
    final_df, process_date = add_bronze_metadata(df, source)
    temp_view_name = f"{table_name}_view"
    final_df.createOrReplaceTempView(temp_view_name)
    table_already_exists = spark.catalog.tableExists(f"{config.bronze_database}.{table_name}")

    if not table_already_exists:
        logger.debug(f"Creating {full_table_name}")
        sql(f'CREATE TABLE {full_table_name} PARTITIONED BY (processDate) AS SELECT * FROM {temp_view_name}')
    else:
        date_str = process_date.strftime("%Y-%m-%d")
        sql(f"DELETE FROM {full_table_name} WHERE processDate = '{date_str}'")
        sql(f'INSERT INTO {full_table_name} BY NAME SELECT * FROM {temp_view_name}')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Initialization

# COMMAND ----------

sql(f"USE CATALOG {config.uc_catalog}")
sql(f"CREATE DATABASE IF NOT EXISTS {config.bronze_database}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Accredible Groups
# MAGIC
# MAGIC **WARNING**: The endpoint we're using to get groups is marked as deprecated
# MAGIC in the official Accredible documentation, and there's no other suitable
# MAGIC endpoint to get the list of groups.

# COMMAND ----------

def get_accredible_groups() -> Seq[Dict[str, Any]]:
    """
    Get the list of Accredible credential groups. They'll be stored
    in a table, but they're also used to get the actual credentials.
    """
    # Accredible seems to send down duplicate rows at time, so this
    # dictionary is used to ensure that we don't keep duplicates.
    records: Dict[int, Dict[str, Any]] = dict()
    auth_headers = get_auth_headers()
    next_page = None
    duplicates = 0
    while True:
        if next_page:
            params = {"page": next_page}
            logger.debug(f"Getting page {next_page} of groups")
        else:
            logger.debug("Getting first page of groups")
            params = {}

        params['page_size'] = PAGE_SIZE
        response = requests.post(
            ACCREDIBLE_API_GET_GROUPS_URL, headers=auth_headers, params=params
        )
        if response.status_code != 200:
            raise AccredibleException(
                f"Failed to get Accredible groups. Status code was {response.status_code}. {response.text}"
            )

        response_json = response.json()
        for group in response_json["groups"]:
            group_id = group['id']
            if group_id in records:
                duplicates += 1
            else:
                records[group_id] = {'groupName': group['course_name'], 'groupId': group_id}

        next_page = response_json["meta"].get("next_page")
        if not next_page:
            break

    if duplicates > 0:
        logger.info(f'Ignored {duplicates} duplicate record(s) in group data from Accredible.')

    return list(records.values())

# COMMAND ----------

groups = get_accredible_groups()
logger.info(f'Got {len(groups)} total groups')

# COMMAND ----------

df = spark.read.option('inferSchema', 'true').json(spark.sparkContext.parallelize([json.dumps(g) for g in groups]))
import_table('groups', df, ACCREDIBLE_API_GET_GROUPS_URL)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Accredible Credentials

# COMMAND ----------

def get_accredible_cred_data_for_group(group: Dict[str, str]):
    def decode_one(info: Dict[str, Any], group_name: str) -> Dict[str, Any]:
        return {
            "credential_name": info["name"],
            "credential_id": info["id"],
            "recipient_name": info["recipient"]["name"],
            "recipient_email": info["recipient"]["email"].strip().lower(),
            "recipient_id": info["recipient"]["id"],
            "approve": info["approve"],
            "complete": info["complete"],
            "issued_on": info["issued_on"],
            "expired_on": info["expired_on"],
            "group_id": group_id,
            "group_name": group_name,
        }

    def decode_page(credential_data: Seq[Dict[str, Any]], group_name: str) -> Seq[Dict[str, Any]]:
        res = []

        for info in credential_data:
            recipient = info.get("recipient")
            if recipient is None:
                continue

            res.append(decode_one(info, group_name))

        return res

    group_id, group_name = group["groupId"], group["groupName"]
    logger.debug(f'Getting credential data for group "{group_name}"')

    headers = get_auth_headers()

    # Accredible seems to send down duplicate rows at time, so this
    # dictionary is used to ensure that we don't keep duplicates.
    records: Dict[int, Dict[str, Any]] = dict()
    try:
        params = {"group_id": group_id, "page_size": PAGE_SIZE}
        next_page = None
        duplicates = 0
        while True:
            if next_page:
                params["page"] = next_page

            logger.debug(
                f'Getting {"first page" if not next_page else "page " + str(next_page)} for group "{group_name}"'
            )
            response = requests.get(
                ACCREDIBLE_GET_CREDENTIALS_URL, headers=headers, params=params
            )

            if response.status_code != 200:
                raise AccredibleException(
                    f'Failed to get credential data for group "{group_name}". '
                    f"Status code was {response.status_code}. "
                    f"Response text: {response.text}"
                )

            response_json = response.json()
            credentials = response_json["credentials"]
            logger.debug(f"{len(credentials)} record(s) in returned page")

            page_data = decode_page(credentials, group_name)
            for rec in page_data:
                credential_id = rec['credential_id']
                if credential_id in records:
                    duplicates += 1
                else:
                    records[credential_id] = rec

            next_page = response_json["meta"].get("next_page")
            if not next_page:
                break

    except AccredibleException:
        raise

    except Exception as e:
        raise AccredibleException(
            f'Failed to get credential data for group "{group_name}": {e}'
        )

    if duplicates > 0:
        logger.info(f'Ignored {duplicates} duplicate record(s) in credential data from Accredible.')

    return list(records.values())

# COMMAND ----------

data = []
for group in groups:
    data.extend(get_accredible_cred_data_for_group(group))
    logger.debug("----")

logger.debug(f"Read {len(data):,} total records")

# COMMAND ----------

js = [json.dumps(s) for s in data]
df = (
    spark
        .read
        .option("inferSchema", "true")
        .json(spark.sparkContext.parallelize(js))
        .withColumn("expired_on", F.col("expired_on").cast("timestamp"))
        .withColumn("issued_on", F.col("issued_on").cast("timestamp"))
)
import_table("credentials", df, ACCREDIBLE_GET_CREDENTIALS_URL)
