# accredible-pipeline

This repository contains Databricks notebooks that implement a pipeline
to pull data from our [Accredible](https://www.accredible.com/) instance
into the data lake. The notebooks live in the `notebooks/` subdirectory.

Accredible is a learner badging service. The Learning and Development
team pushes badges to Accredible to register learners' achievements,
including passing certification exams. Learners can then link to
their Accredible badges in their email signatures, on LinkedIn, etc.,
and Accredible serves to prove that they have actually achieved
those goals.

We ingest Accredible data (credential groups and credentials),
so that the L&D team can run analytics on the information, correlating
the data with other data sources. Currently, the code does a full
download every time it runs, and it uses the older v1 version of the
Accredible REST API. Using the v2 REST API, it would be possible
to implement a more efficient incremental download, but it would
_not_ be possible to detect deleted items that way.

## Data

The bronze data (downloaded via the `Bronze.py` notebook) is
written to `main.it_accredible_bronze` in Central Logfood.
Stakeholders should _not_ be doing analytics on bronze data.

The silver data, built from bronze via the `Silver.py` notebook,
is written to `main.it_training_silver`, with all Accredible
table names having the prefix `accredible_`. 
