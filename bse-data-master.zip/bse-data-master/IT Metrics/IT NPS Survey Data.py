# Databricks notebook source
# MAGIC %run Users/madan.gopal@databricks.com/forecast_dashboard/Read_GSheet_Logfood_UDF

# COMMAND ----------

from pyspark.sql.types import DoubleType
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
import pyspark.sql.functions as f
from pyspark.sql.types import IntegerType

# COMMAND ----------

Quarter_DF = read_google_worksheet_data('1JR_GQuuu_mNraI1g4QH4Kk6vyxOHr-IAKq9JWQ1QJ9I', '0')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Bronze Schema

# COMMAND ----------

Quarter_DF.write.mode("overwrite").option("mergeSchema","true").saveAsTable("main.it_freshservice_bronze.IT_NPS_Survey_Data")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Silver Schema

# COMMAND ----------

Quarter_DF_bronze = spark.sql(''' SELECT * FROM main.it_freshservice_bronze.IT_NPS_Survey_Data''')

# COMMAND ----------

Quarter_DF = (
  Quarter_DF_bronze.withColumnRenamed("how_likely_are_you_to_recommend_it_support_team_to_a_friend_or_colleague?", "how_likely_are_you_to_recommend_it_support_team_to_a_friend_or_colleague").
             withColumnRenamed("what_is_the_primary_reason_for_your_score?","what_is_the_primary_reason_for_your_score"))

# COMMAND ----------

Quarter_DF_upd = Quarter_DF.withColumn("how_likely_are_you_to_recommend_it_support_team_to_a_friend_or_colleague",Quarter_DF["how_likely_are_you_to_recommend_it_support_team_to_a_friend_or_colleague"].cast(IntegerType()))

# COMMAND ----------

spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
Quarter_DF_upd = Quarter_DF_upd.withColumn("Created_Date",to_date("timestamp", 'M/dd/yyyy HH:mm:ss')).drop("timestamp")

# COMMAND ----------

Quarter_DF_upd.write.mode("overwrite").option("mergeSchema","true").saveAsTable("main.it_freshservice_silver.IT_NPS_Survey_Data")
