# Databricks notebook source
from datetime import datetime, timedelta
from pandas import json_normalize
from pyspark.sql.functions import * 
from pyspark.sql.types import *
import pyspark.sql.functions as f
from pyspark.sql import SparkSession
import pandas as pd
import numpy as np
import requests
from io import StringIO

# COMMAND ----------

# MAGIC %md
# MAGIC #### IT Operations Metrics Bronze Table

# COMMAND ----------

  url_link = dbutils.secrets.get(scope = "it-freshservice-scope", key = "freshservice-url")
  auth_key = dbutils.secrets.get(scope = "it-freshservice-scope", key = "freshservice-auth")

# COMMAND ----------

response = requests.request("GET", url_link, auth=(auth_key, 'X'))

# COMMAND ----------

if response.status_code != 200:
  print(response.text)
  raise Exception(f"Unexpected status code: {response.status_code}")

# COMMAND ----------

import uuid
temp_path = f"dbfs:/tmp/{uuid.uuid4()}.csv"
python_path = temp_path.replace('dbfs:', '/dbfs')
path = temp_path.replace('dbfs:', '')

with open(python_path, mode='w', encoding='utf-8') as f:
    f.write(response.text)

# COMMAND ----------

tickets_raw = spark.read.format("csv").options(header='True', inferSchema='True', multiLine='true').load(path)

# COMMAND ----------

# tickets_raw.write.mode("overwrite").option("overwriteSchema","true").saveAsTable("integration.it_freshservice_bronze.IT_Tickets_Metrics")
tickets_raw.write.mode("overwrite").option("overwriteSchema","true").saveAsTable("main.it_freshservice_bronze.IT_Tickets_Metrics")

# COMMAND ----------

# MAGIC %md
# MAGIC #### IT Operations Metrics Silver Table

# COMMAND ----------

tickets = spark.sql(''' SELECT * FROM main.it_freshservice_bronze.IT_Tickets_Metrics''')

# COMMAND ----------

tempTickets = tickets.select('ID', 'Approval Status', 'Item Category', 'Category', 'Closed Date','Department Name','Created Date', 'Impact', 'Agent Group Name', 'Priority', 'Urgency','Status','Customer Reply Count','Agent Name','Agent Reply Count','Due By', 'Requester Primary Email','Requester Name', 'Resolution Status', 'Source', 'Last Updated Date','Survey Score','Sub-Category','Elapsed Time in Calendar Hours','Resolution Time in Bhrs','First Response Time in Chrs').\
withColumnRenamed('Closed Date', 'ClosedTime').\
withColumnRenamed('Created Date','CreatedTime').\
withColumnRenamed('Agent Group Name','Group').\
withColumnRenamed('Customer Reply Count','CustomerInteractions').\
withColumnRenamed('Agent Reply Count', 'AgentInteractions').\
withColumnRenamed('Agent Name', 'Agent').\
withColumnRenamed('Approval Status', 'ApprovalStatus').\
withColumnRenamed('Department Name', 'Department').\
withColumnRenamed('Due By', 'DueByTime').\
withColumnRenamed('Requester Primary Email','RequesterEmail').\
withColumnRenamed('Requester Name', 'RequesterName').\
withColumnRenamed('Resolution Status', 'ResolutionStatus').\
withColumnRenamed('Last Updated Date', 'LastUpdatedTime').\
withColumnRenamed('Survey Score','SurveyScore').\
withColumnRenamed('Sub-Category', 'SubCategory').\
withColumnRenamed('Category','HelpDeskQueue').\
withColumnRenamed('Item Category', 'Category').\
withColumnRenamed('Resolution Time in Bhrs','ResolutionTimeinBhrs').\
withColumnRenamed('First Response Time in Chrs','FirstResponseTimeinChrs')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Cleaning

# COMMAND ----------

#---- Attribute: ID

# UPDATE bdw_dev.IT_Tickets_Temp_List  
# SET ID = CASE  
#             WHEN ID IS NULL OR ID LIKE '' OR ID LIKE 'null' THEN 'NA' 
#             WHEN ID LIKE 'INC-%' OR ID LIKE 'SR-%' THEN ID 
#             ELSE 'No Ticket Id'
#           END 

update_ID = when((col("ID") == '') | (col("ID") == 'null') | col("ID").isNull(), 'NA').\
when((col("ID").substr(0,4) == "INC-") | (col("ID").substr(0,3) == "SR-"), col("ID")).otherwise("No Ticket Id")

tempTickets1 = tempTickets.withColumn("TicketID", update_ID).drop("ID")

# COMMAND ----------

#---- Attribute: Approval Status

# UPDATE bdw_dev.IT_Tickets_Temp_List  
# SET ApprovalStatus = CASE  
#             WHEN (ApprovalStatus IS NULL or ApprovalStatus LIKE 'null' or ApprovalStatus = '') THEN 'NA' 
#             WHEN ApprovalStatus NOT IN ('Approved', 'Canceled', 'Requested', 'Not Requested', 'Cancelled') THEN 'No Approval Status' 
#             ELSE ApprovalStatus
#           END

valid_AS = ["Approved", "Canceled", "Requested", "Not Requested", "Cancelled"]

update_AS = when((col("ApprovalStatus") == '') | (col("ApprovalStatus") == 'null') | col("ApprovalStatus").isNull(), 'NA').\
when((col("ApprovalStatus").isin(valid_AS)), col("ApprovalStatus")).otherwise("No Approval Status")

tempTickets2 = tempTickets1.withColumn("Approval_Status", update_AS).drop("ApprovalStatus").withColumnRenamed("Approval_Status", "ApprovalStatus")

# COMMAND ----------

#---- Attribute: Impact

valid_IM = ["Low", "Medium", "High", "low", "medium", "high"]

update_IM = when((col("Impact") == '') | (col("Impact") == 'null') | col("Impact").isNull(), 'NA').\
when((col("Impact").isin(valid_IM)), col("Impact")).otherwise("No Impact Assigned")

tempTickets3 = tempTickets2.withColumn("TicketImpact", update_IM).drop("Impact").withColumnRenamed("TicketImpact","Impact")

# COMMAND ----------

#---- Attribute: Priority

valid_PR = ["Low", "Medium", "High", "low", "medium", "high", "Urgent", "urgent"]

update_PR = when((col("Priority") == '') | (col("Priority") == 'null') | col("Priority").isNull(), 'NA').\
when((col("Priority").isin(valid_PR)), col("Priority")).otherwise("No Priority Assigned")

tempTickets4 = tempTickets3.withColumn("TPriority", update_PR).drop("Priority").withColumnRenamed("TPriority","Priority")

# COMMAND ----------

#---- Attribute: Urgency

valid_UR = ["Low", "Medium", "High", "low", "medium", "high"]

update_UR = when((col("Urgency") == '') | (col("Urgency") == 'null') | col("Urgency").isNull(), 'NA').\
when((col("Urgency").isin(valid_UR)), col("Urgency")).otherwise("No Urgency Assigned")

tempTickets5 = tempTickets4.withColumn("TicketUrgency", update_UR).drop("Urgency").withColumnRenamed("TicketUrgency","Urgency")

# COMMAND ----------

#---- Attribute: Survey Score

valid_SS = ["1", "2", "3", "4", "5"]

update_UR = when((col("SurveyScore") == '') | (col("SurveyScore") == 'null') | col("SurveyScore").isNull(), 'NA').\
when((col("SurveyScore").isin(valid_SS)), col("SurveyScore")).otherwise("No Survey Score Assigned").cast(IntegerType())

tempTickets6 = tempTickets5.withColumn("TSurveyScore", update_UR).drop("SurveyScore").withColumnRenamed("TSurveyScore","SurveyScore")

# COMMAND ----------

#---- Attribute: Status

valid_ST = ["CAB", "Closed", "Open", "Pending"]

update_ST = when((col("Status") == '') | (col("Status") == 'null') | col("Status").isNull(), 'NA').\
when((col("Status").isin(valid_ST)), col("Status")).otherwise("No Status Assigned")
# .cast(IntegerType())

tempTickets7 = tempTickets6.withColumn("TStatus", update_ST).drop("Status").withColumnRenamed("TStatus","Status")

# COMMAND ----------

#---- Attribute: Created Time

import pyspark.sql.functions as f
tempTickets8 = tempTickets7.withColumn("CreatedDate", f.from_unixtime(f.unix_timestamp("CreatedTime",'yyyy-MM-dd hh:mm:ss a'),'yyyy-MM-dd HH:mm:ss')).withColumn("Created_Time",to_timestamp("CreatedDate", 'yyyy-MM-dd HH:mm:ss')).drop("CreatedTime","CreatedDate").withColumnRenamed("Created_Time","CreatedTime")

# COMMAND ----------

#---- Attribute: Closed Time

tempTickets9 = tempTickets8.withColumn("ClosedDate", f.from_unixtime(f.unix_timestamp("ClosedTime",'yyyy-MM-dd hh:mm:ss a'),'yyyy-MM-dd HH:mm:ss')).withColumn("Closed_Time",to_timestamp("ClosedDate", 'yyyy-MM-dd HH:mm:ss')).drop("ClosedTime","ClosedDate").withColumnRenamed("Closed_Time","ClosedTime")

# COMMAND ----------

#---- Attribute: Due By Time

tempTickets10 = tempTickets9.withColumn("DueByDate", f.from_unixtime(f.unix_timestamp("DueByTime",'yyyy-MM-dd hh:mm:ss a'),'yyyy-MM-dd HH:mm:ss')).withColumn("DueBy_Time",to_timestamp("DueByDate", 'yyyy-MM-dd HH:mm:ss')).drop("DueByTime","DueByDate").withColumnRenamed("DueBy_Time","DueByTime")

# COMMAND ----------

#---- Attribute: Last Updated Time

tempTickets11 = tempTickets10.withColumn("LastUpdatedDate", f.from_unixtime(f.unix_timestamp("LastUpdatedTime",'yyyy-MM-dd hh:mm:ss a'),'yyyy-MM-dd HH:mm:ss')).withColumn("LastUpdated_Time",to_timestamp("LastUpdatedDate", 'yyyy-MM-dd HH:mm:ss')).drop("LastUpdatedTime","LastUpdatedDate").withColumnRenamed("LastUpdated_Time","LastUpdatedTime")


# COMMAND ----------

#---- Attribute: Resolution Status

valid_RS = ["SLA Violated", "Within SLA", "Closed"]

update_RS = when((col("ResolutionStatus") == '') | (col("ResolutionStatus") == 'null') | col("ResolutionStatus").isNull(), 'NA').\
when((col("ResolutionStatus").isin(valid_RS)), col("ResolutionStatus")).otherwise("No Resolution Status Assigned")
# .cast(IntegerType())

tempTickets12 = tempTickets11.withColumn("ResolStatus", update_RS).drop("ResolutionStatus").withColumnRenamed("ResolStatus","ResolutionStatus")

# COMMAND ----------

#---- Attribute: Resolution Status

tempTickets13 = tempTickets12.withColumn("ElapsedTime", col("Elapsed Time in Calendar Hours")/3600).drop("Elapsed Time in Calendar Hours")

# COMMAND ----------

from pyspark.sql import functions as sf
tempTickets14 = tempTickets13.withColumn("ItemCategory", sf.concat(sf.col('SubCategory'),sf.lit(' : '), sf.col('Category')))
display(tempTickets14)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write into LogFood

# COMMAND ----------

FinalTickets = tempTickets14.withColumnRenamed("SubCategory", "Sub-Category").\
withColumnRenamed("TicketID", "Ticket Id").\
withColumnRenamed("ApprovalStatus", "Approval Status").\
withColumnRenamed("CreatedTime", "Created Time").\
withColumnRenamed("ClosedTime","Closed Time").\
withColumnRenamed("ResolutionStatus", "Resolution Status").\
withColumnRenamed("ElapsedTime","Elapsed Time in Calendar Hours")

# COMMAND ----------

# FinalTickets.write.mode("overwrite").option("overwriteSchema","true").saveAsTable("bdw_dev.it_tickets_metricsdashboard")
FinalTickets.write.mode("overwrite").option("overwriteSchema","true").saveAsTable("main.it_freshservice_silver.IT_Tickets_Metrics")

# COMMAND ----------

# %sql
# ALTER TABLE main.it_freshservice_silver.IT_Tickets_Metrics SET TBLPROPERTIES (
#    'delta.columnMapping.mode' = 'name',
#    'delta.minReaderVersion' = '2',
#    'delta.minWriterVersion' = '5')

# COMMAND ----------


