# Databricks notebook source
dbutils.widgets.text("environment", 'production') # development, integration, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'production':
  schema = "main.it_o2c_bronze"
elif environment == 'integration':
  schema = "integration.it_o2c_bronze"
else:
  schema = "users.prabhakar_guha"

# COMMAND ----------

print(f"Writing on {schema}.payment_event_bs_recon")

# COMMAND ----------

spark.sql(f"""
create or replace table {schema}.payment_event_bs_recon
with ns_payment as (
select statusreason, 
       statusreasondetails, 
       eventdate,
       split(trim(regexp_extract(request, "(?<=billTo_customerID:)(.*)(?=billTo_email)")),'<')[0] as customer_id
from main.it_netsuite_bronze.paymentevent 
where processDate = (select max(processDate) from main.it_netsuite_bronze.paymentevent)
--and statusreason not in ('ACCEPT')
and statusreason is not null
)
select NS_Customer_Internal__c ns_customer_internal_id,
       ns.*, 
       pl.Account_Id__c sfdc_account_id, 
       pl.Active__c active, 
       pl.Customer_Name__c customer_name, 
       pl.Name bs_name, 
       pl.Platform_Account_ID__c platform_account_id, 
       pl.Platform__c platform, 
       pl.Subscription_Id__c subscription_id, 
       pl.Billing_System_ID__c billing_system_id
from ns_payment ns left join main.sfdc_bronze.platformsubscription__c pl on ns.customer_id = pl.NS_Customer_Internal__c
where pl.processDate = (select max(processDate) from main.sfdc_bronze.platformsubscription__c) and ns.eventdate >= '2024-01-01'
""")

# COMMAND ----------


