# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import * 
from datetime import datetime, timedelta
import requests
import json


env_configs = {
               
                  "dev": {
                        
                            "ver": "v1",
                            "prefix": "dev_",
                            "base_url": "https://api.metronome.com/v1/contracts/updateInvoiceIssueDate",
                            "sfdc_prefix": "sitnew",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "sandbox"
                  },
                  
                
                  "uat": {
                            "ver": "v1",
                            "prefix": "uat_",
                            "base_url": "https://api.metronome.com/v1/contracts/updateInvoiceIssueDate",
                            "sfdc_prefix": "sfdcprod",
                            "sfdc_domain": "databricks.my",
                            "output_schema": "bdw_dev",
                            "metronome_env": "uat"
                           
                  },
                  "stg": {
                        
                            "ver": "v1",
                            "prefix": "stg_",
                            "base_url": "https://api.metronome.com/v1/contracts/updateInvoiceIssueDate",
                            "sfdc_prefix": "uatnew",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "stg",
                  },
                  "prod": {
                            "ver": "v1",
                            "prefix": "",
                            "base_url": "https://api.metronome.com/v1/contracts/updateInvoiceIssueDate",
                            "sfdc_prefix": "sfdcprod",
                            "sfdc_domain": "databricks.my",
                            "output_schema": "bdw",
                            "metronome_env": "prod",
                  }

}
env_config = env_configs[ENV]

PAYLOAD_COL = "event"
ab_event_payload = ['invoice_id', 'issue_date']





# COMMAND ----------

# DBTITLE 1,Setup env variables
## Retrive Metronome API Key from the DB secrets 
def retrive_metronome_api_token(env = "sandbox"):
  return dbutils.secrets.get(scope = "bse-metronome", key = f"metronome_api_key_{env}") 

#set the enviornment through pipelibe parms
metronome_env = env_config["metronome_env"]
api_key = retrive_metronome_api_token(metronome_env)


# COMMAND ----------

#sachin decoding the object and capturing the status and error message.
import requests
import json
from pyspark.sql.types import MapType, StringType
from pyspark.sql.functions import udf

@udf(returnType=MapType(StringType(), StringType()))
def send_to_metronome_on_demand(payload):
    metronome_base_url = env_config['base_url']
    token = api_key
    count = 0
    retry_attempts = 3
    json_payload = json.loads(payload)
    print(json_payload)
    
    while True:
        try:
            response = requests.post(
                metronome_base_url,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json"
                },
                json=json_payload,
                timeout=30
            )
            
            # Decode the response content
            try:
                decoded_content = response.json()
            except ValueError:
                decoded_content = response.text
            
            # Construct a dictionary to return as the UDF result
            result = {
                "status_code": str(response.status_code),
                "response_content": json.dumps(decoded_content) if isinstance(decoded_content, dict) else decoded_content,
                "reason": response.reason,
                "url": response.url,
                "headers": json.dumps(dict(response.headers)),
                "cookies": json.dumps(requests.utils.dict_from_cookiejar(response.cookies)),
                "elapsed": str(response.elapsed)
            }
            
            # Check if the request was successful
            if response.status_code == 200:
                return result
            else:
                # Return the error information if status code is not 200
                return result

        except Exception as e:
            # Log the error and increment the retry count
            if count < retry_attempts:
                count += 1
            else:
                # Return error information if all retry attempts fail
                return {
                    "status_code": "error",
                    "response_content": str(e),
                    "reason": "RequestException",
                    "url": metronome_base_url,
                    "headers": "{}",
                    "cookies": "{}",
                    "elapsed": "0"
                }

    # Default return if something unexpected happens
    return {
        "status_code": "unknown",
        "response_content": "No response received",
        "reason": "Unknown",
        "url": metronome_base_url,
        "headers": "{}",
        "cookies": "{}",
        "elapsed": "0"
    }


# COMMAND ----------


