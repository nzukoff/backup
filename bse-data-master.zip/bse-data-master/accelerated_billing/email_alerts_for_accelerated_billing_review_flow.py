# Databricks notebook source
# MAGIC %pip install beautifulsoup4

# COMMAND ----------

from datetime import datetime, timedelta
import sys
from it_data_lib import email, configure_logging
from urllib.request import urlopen
import logging
import base64

# COMMAND ----------

sys.path.insert(0, "..")
logger = configure_logging(s_level='DEBUG')

# COMMAND ----------

dbutils.widgets.dropdown("environment", "dev", ['prod','dev','uat','stg','sit','preprod','dev_external'])
try:
  ENV = dbutils.widgets.get("env")
except:
  ENV = dbutils.widgets.get("environment")

ENV_ab = 'prod' if ENV == "prod" else 'dev'
print(ENV_ab)
print(ENV)

# COMMAND ----------

# MAGIC %run ./accelerated_billing_entry_config

# COMMAND ----------

print(catalog_nm,tgt_db_nm)

# COMMAND ----------

# MAGIC %md
# MAGIC Email Body

# COMMAND ----------

accelerated_customers_records_to_notify = spark.sql(f"""
select customer_name,customer_id,contract_id,contract_name,name as commit_name,type,total_usage , scheduled_total billed_total ,excess_amount ,next_invoice_id,next_installment_amount,next_installment_date,salesforce_opportunity_id, 

-- case when customer_name = 'Test Acceleration GroupE.1' then 'sachin.khurana@databricks.com' 
-- when customer_name  = 'Kargo'  then 'deepak.kher@databricks.com' 
-- when customer_name  = 'Raiffeisen Bank International'  then 'rachel.kelly@databricks.com' 
--  else NULL end as Owner_Email__c,
Owner_Email__c,
--   case when customer_name = 'Test Acceleration GroupE.1' then 'rachel.kelly@databricks.com' 
-- when customer_name  = 'Kargo'  then 'sachin.khurana@databricks.com' 
-- when customer_name  = 'Raiffeisen Bank International'  then 'deepak.kher@databricks.com' 
--  else NULL end
 
--  as Owner_Manager_Email__c

Owner_Manager_Email__c


from {catalog_nm}.it_billing_and_rating.accelerated_billing_daily 
where  current_Status = 'Reviewed and Processed to Metronome' 
and update_date = current_date() and update_user like '%Review%' --please put the filter.
""") 
accelerated_customers_records_to_notify.createOrReplaceTempView("accelerated_customers_records_to_notify")



# COMMAND ----------

# MAGIC %sql
# MAGIC select * From accelerated_customers_records_to_notify

# COMMAND ----------

# MAGIC %pip install Jinja2
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as F
import pandas as pd

# Define the email subject
subject = "Accelerated Billing Notification - Accelerated Customers "

# Clean the records to exclude null Owner_Email__c
accelerated_customers_records_to_notify = accelerated_customers_records_to_notify.filter(F.col("Owner_Email__c").isNotNull())

# Group the records by 'Owner_Email__c' to generate subsets of records to notify
records_grouped = accelerated_customers_records_to_notify.groupBy("Owner_Email__c").agg(
    F.collect_list(F.struct(*accelerated_customers_records_to_notify.columns)).alias("records")
)

# Function to format numeric fields
def format_numeric_fields(df, columns):
    for col in columns:
        if col in df.columns:
            df[col] = df[col].apply(lambda x: f"{float(x):,.2f}" if pd.notnull(x) else x)
    return df

# Function to clean column headers
def clean_column_headers(df):
    column_mapping = {
        col: col.replace("_", " ").replace("__c", "").title().replace(" C", "") 
        for col in df.columns
    }
    df.rename(columns=column_mapping, inplace=True)
    return df

# Style the table for HTML
def style_table(df):
    styles = [
        dict(selector="table", props=[("border-collapse", "collapse"), ("width", "100%")]),
        dict(selector="th", props=[("background-color", "#f2f2f2"), ("text-align", "center"), ("padding", "8px")]),
        dict(selector="td", props=[("text-align", "center"), ("padding", "8px")]),
    ]
    return df.style.set_table_styles(styles)

# Loop through each email group
for row in records_grouped.collect():
    email_address = row["Owner_Email__c"]
    records_subset = row["records"]

    # Extract CC from Owner_Manager_Email__c and include the default CC
    cc_addresses = ["manjeet.chhabra@databricks.com"]
    df_subset = pd.DataFrame([x.asDict() for x in records_subset])  # Convert Row objects to dictionaries

    if "Owner_Manager_Email__c" in df_subset.columns and not df_subset["Owner_Manager_Email__c"].isnull().all():
        manager_emails = df_subset["Owner_Manager_Email__c"].dropna().unique().tolist()
        cc_addresses.extend(manager_emails)

    # Format numeric fields and clean column headers
    numeric_columns = ["total_usage", "billed_total", "excess_amount", "next_installment_amount"]
    df_subset = format_numeric_fields(df_subset, numeric_columns)
    df_subset = clean_column_headers(df_subset)

    # Generate the HTML table and body
    styled_table = style_table(df_subset).hide_index().render()
    email_body = f"""
    <html>
    <head>
        <title>{subject}</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
            }}
            table {{
                border-collapse: collapse;
                width: 100%;
                margin-top: 20px;
            }}
            th, td {{
                border: 1px solid #ddd;
                text-align: center;
                padding: 8px;
            }}
            th {{
                background-color: #f2f2f2;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <p>This is an automated email alert for Accelerated Billing for your awareness.</p>
        <p>The customers below have consumed usage greater than the amount they have been billed, which has triggered an acceleration of the next scheduled installment invoice. This is a list of records that have been processed for acceleration.</p>
        {styled_table}
        <p>For any billing inquiries regarding this topic, please contact <a href="mailto:billing@databricks.com">billing@databricks.com</a>.</p>
        <p>Thank you in advance.</p>
    </body>
    </html>
    """

    # Send the email
    message_id = email.send_it_data_email(
        to_emails=email_address,
        subject=subject,
        body_html=email_body,
        cc_emails=cc_addresses,
        dbutils=dbutils,
        logger=logger,
        dry_run=False
    )
    logger.info(f"Email sent to {email_address} with Message ID: {message_id}")


# COMMAND ----------

# MAGIC %md
# MAGIC Send Emails
