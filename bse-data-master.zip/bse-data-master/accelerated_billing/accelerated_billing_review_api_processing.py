# Databricks notebook source
dbutils.widgets.dropdown("environment", "dev", ['prod','dev','uat','stg','sit','preprod','dev_external'])
try:
  ENV = dbutils.widgets.get("env")
except:
  ENV = dbutils.widgets.get("environment")

ENV_ab = 'prod' if ENV == "prod" else 'dev'
print(ENV_ab)
print(ENV)

# COMMAND ----------

# MAGIC %run ./accelerated_billing_entry_config
# MAGIC

# COMMAND ----------

print(catalog_nm,tgt_db_nm)

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.functions import lit
from datetime import datetime

def create_snapshot(df: DataFrame, output_table: str) -> None:
    process_date = datetime.utcnow().date()
    final_df = (df
                .withColumn('processDate', lit(process_date))  # Add processDate column
                .withColumn('type', lit('REVIEWED'))  # Add type column
               )
    date_str = process_date.strftime('%Y-%m-%d')
    type_str = 'REVIEWED'

    (final_df.write
             .mode('overwrite')
             .option('mergeSchema', 'true')
             .option('replaceWhere', f"processDate = '{date_str}' AND type = '{type_str}'")
             .partitionBy('processDate', 'type')
             .saveAsTable(output_table))

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * From main.it_billing_and_rating.accelerated_billing_review_upload
# MAGIC
# MAGIC

# COMMAND ----------


upload_exception_check = spark.sql(f'''select upload.*,case when abd.contract_id is null then 'Not in the accelarated billing table' 
                     when abd.next_installment_date <= current_date  then  'Invoice billing date has passed'
                     when upload.current_Status <> 'Reviewed and Ready to Process' then 'Invalid Status'
                     else 'Valid' end as Upload_status
                     
                     from {catalog_nm}.it_billing_and_rating.accelerated_billing_review_upload upload 
left join 
{catalog_nm}.it_billing_and_rating.accelerated_billing_daily abd 

on 
upload.contract_id = abd.contract_id
and upload.next_invoice_id = abd.next_invoice_id
and upload.name = abd.name''' )

upload_exception_check.createOrReplaceTempView('upload_exception_check')


# COMMAND ----------

exception_status_table = f'{catalog_nm}.it_billing_and_rating.accelarated_billing_daily_review_exception_status'
print(exception_status_table)

# COMMAND ----------

create_snapshot(df = spark.table('upload_exception_check'), output_table = exception_status_table)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * From upload_exception_check

# COMMAND ----------

abd_review_update = f'''MERGE INTO {catalog_nm}.it_billing_and_rating.accelerated_billing_daily AS target
USING (select distinct * from upload_exception_check ) AS upload
ON target.next_invoice_id = upload.next_invoice_id
and target.name = upload.name 
 AND target.current_status IN ('Review Needed')
 AND upload.Upload_status = 'Valid'
WHEN MATCHED THEN
  UPDATE SET 
    current_status = 'Reviewed and Ready to Process' ,
    UPDATE_DATE = CURRENT_DATE,
    Update_User = current_user||'_Review' '''

spark.sql(abd_review_update)


# COMMAND ----------

#%sql
#create or replace temp view accelarated_invoices_rollup as 
ab_invoice_rollup_reviewed = spark.sql(
f'''select ex.customer_name,ex.customer_id,contract_id,contract_name ,ex.next_invoice_id,next_installment_amount,next_installment_date, current_status as current_status, cast(NULL AS date) update_date,'REVIEWED' as Type
from 
--integration.it_billing_and_rating.accelarated_billing_daily 
upload_exception_check ex
Inner join (select next_invoice_id from {catalog_nm}.it_billing_and_rating.accelerated_billing_daily  abd  where
current_Status  not in ( 'Reviewed and Processed to Metronome','Processed to Metronome') group by 1 ) processed

on 
processed.next_invoice_id = ex.next_invoice_id

where Upload_status= 'Valid'
GROUP BY ALL

''' )

ab_invoice_rollup_reviewed.createOrReplaceTempView('ab_invoice_rollup_reviewed')


# COMMAND ----------

# MAGIC %sql
# MAGIC select * FRom ab_invoice_rollup_reviewed

# COMMAND ----------

inv_rollup_snap_table = f'{catalog_nm}.it_billing_and_rating.accelerated_billing_invoice_rollup_snapshot'
print(inv_rollup_snap_table)

# COMMAND ----------

create_snapshot(df = spark.table('ab_invoice_rollup_reviewed'), output_table = inv_rollup_snap_table)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.it_billing_and_rating.accelerated_billing_invoice_rollup_snapshot

# COMMAND ----------

source_df = spark.sql('''
    SELECT 
        next_invoice_id AS invoice_id, 
        * EXCEPT(next_invoice_id),
        
concat(
    date_format(current_date(), 'yyyy-MM-dd'), 
    'T', 
    '00:00:00.000', 
    'Z'
) AS issue_date


    FROM ab_invoice_rollup_reviewed
    --WHERE current_status in ('Reviewed and Ready to Process') 
       
''')

source_df.createOrReplaceTempView('source_df')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * FRom source_df

# COMMAND ----------

# MAGIC %run ./defs_and_helper_functions_ab

# COMMAND ----------

ab_events_processed = source_df.withColumn(PAYLOAD_COL,to_json(struct([field for field in ab_event_payload])))
ab_events_processed.createOrReplaceTempView('ab_events_processed')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ab_events_processed

# COMMAND ----------


ab_events_processed_to_upload = spark.sql('''select invoice_id,event from ab_events_processed''')
ab_events_processed_to_upload.createOrReplaceTempView('ab_events_processed_to_upload')


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ab_events_processed_to_upload

# COMMAND ----------

TARGET_EVENT_RESPONSE_TBL = f'{catalog_nm}.it_billing_and_rating.accelerated_billing_events_upload'
print(TARGET_EVENT_RESPONSE_TBL)


# COMMAND ----------

from pyspark.sql.functions import lit, current_date, current_timestamp

# Process ledger events
ab_events_processed_to_upload = ab_events_processed_to_upload.withColumn(
    'metronome_response', send_to_metronome_on_demand(PAYLOAD_COL)
)

# Create a temporary view for SQL operations
ab_events_processed_to_upload.createOrReplaceTempView('ab_events_processed_to_upload_view')

# SQL query to join and select required fields
events_table = spark.sql('''
    SELECT 
        sdp.invoice_id,
        sdp.customer_name,
        sdp.customer_id,
        sdp.contract_id,
        sdp.contract_name,
        sdp.next_installment_amount,
        sdp.next_installment_date,
        sdp.current_status,
        sdp.update_date,
        sdp.issue_date,
        
        CASE 
            WHEN ae.metronome_response.status_code != '200' THEN 'Not Processed- Check Metronome API response - Reach out to IT Team'
            WHEN ae.metronome_response.status_code = '200' THEN 'Processed to Metronome'
            ELSE 'unknown-further check' 
        END AS processing_status ,
        ae.event event,
       
        ae.metronome_response
    FROM source_df sdp
    LEFT JOIN ab_events_processed_to_upload_view ae
    ON sdp.invoice_id = ae.invoice_id
''')

# Create a temporary view for the events table
events_table.createOrReplaceTempView('events_table')
# Add process_date and process_timestamp columns and write to the target table
events_table.withColumn("process_timestamp", lit(current_timestamp())) \
            .write \
            .mode("overwrite") \
            .saveAsTable(TARGET_EVENT_RESPONSE_TBL)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * FRom  main.it_billing_and_rating.accelerated_billing_events_upload

# COMMAND ----------

from pyspark.sql.functions import current_date

# Define table names
current_table = f"{catalog_nm}.it_billing_and_rating.accelerated_billing_events_upload"
historical_table = f"{catalog_nm}.it_billing_and_rating.accelerated_billing_events_upload_hist"
print(current_table,historical_table)

# Read data from the current table
current_data_df = spark.table(current_table)

# Add a process_date column for tracking when the data was added to the historical table
# Add process_date and process_type columns
current_data_with_process_date_and_type = current_data_df \
    .withColumn("process_type", lit("Review"))\
    .withColumn("process_date", lit(current_date())) \
    

# Append data to the historical table
current_data_with_process_date_and_type.write \
    .mode("append") \
    .saveAsTable(historical_table)

print(f"Data from {current_table} successfully appended to {historical_table}")


# COMMAND ----------


Uploaded_API_trans = spark.sql(f''' 
select invoice_id,processing_status
 from 
{catalog_nm}.it_billing_and_rating.accelerated_billing_events_upload evnt
inner join  upload_exception_check file_data
ON evnt.invoice_id = file_data.next_invoice_id
 
--where invoice_id =  '19ddfe74-617b-584b-bb1e-028115c105a8'
where  
 file_data.Upload_status = 'Valid'
 
qualify row_number() over (partition by evnt.invoice_id order by case when evnt.processing_status = 'Processed to Metronome' then 1 else 2 end ,  evnt.process_timestamp desc) = 1 ''')

Uploaded_API_trans.createOrReplaceTempView('Uploaded_API_trans')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * FRom Uploaded_API_trans

# COMMAND ----------



merge_inv_rollupsnap = f'''MERGE INTO {catalog_nm}.it_billing_and_rating.accelerated_billing_invoice_rollup_snapshot AS target
USING Uploaded_API_trans AS upload
ON target.next_invoice_id = upload.invoice_id
  --AND upload.process_date = CURRENT_DATE
  AND target.current_status IN ('Failed to Process to Metronome', 
                                'Reviewed and Ready to Process', 
                                'Ready to Process')
  AND target.processDate = CURRENT_DATE 
WHEN MATCHED THEN
  UPDATE SET current_status = CASE 
                                WHEN target.current_status = 'Ready to Process' 
                                     AND upload.processing_status = 'Processed to Metronome' 
                                     THEN 'Processed to Metronome'
                                     
                                WHEN target.current_status = 'Reviewed and Ready to Process' 
                                     AND upload.processing_status = 'Processed to Metronome' 
                                     THEN 'Reviewed and Processed to Metronome'
                                     
                                WHEN target.current_status = 'Ready to Process' 
                                     AND upload.processing_status LIKE '%Not Processed%' 
                                     THEN 'Failed to Process to Metronome'
                                     
                                WHEN target.current_status = 'Reviewed and Ready to Process' 
                                     AND upload.processing_status LIKE '%Not Processed%' 
                                     THEN 'Reviewed and Failed to Process to Metronome'
                                
                                ELSE target.current_status -- Preserve existing value for unmatched rows
                              END,
     Update_Date = CURRENT_DATE,
     Update_User = current_user||'_Review' '''


spark.sql(merge_inv_rollupsnap)
     


# COMMAND ----------


merge_abd_review_processed = f'''MERGE INTO {catalog_nm}.it_billing_and_rating.accelerated_billing_daily AS target
USING Uploaded_API_trans AS upload
ON target.next_invoice_id = upload.invoice_id
 AND target.current_status IN ('Failed to Process to Metronome', 
                                'Reviewed and Ready to Process', 
                                'Ready to Process')
  -- AND upload.process_date = CURRENT_DATE
WHEN MATCHED THEN
  UPDATE SET 
    current_status = CASE 
                       WHEN target.current_status in( 'Ready to Process' ,'Failed to Process to Metronome') 
                            AND upload.processing_status = 'Processed to Metronome' 
                            THEN 'Processed to Metronome'
                             
                       WHEN target.current_status in( 'Reviewed and Ready to Process' ,'Reviewed and Failed to Process to Metronome')
                            AND upload.processing_status = 'Processed to Metronome' 
                            THEN 'Reviewed and Processed to Metronome'
                             
                       WHEN target.current_status = 'Ready to Process' 
                            AND upload.processing_status LIKE '%Not Processed%' 
                            THEN 'Failed to Process to Metronome'
                             
                       WHEN target.current_status = 'Reviewed and Ready to Process' 
                            AND upload.processing_status LIKE '%Not Processed%' 
                            THEN 'Reviewed and Failed to Process to Metronome'
                             
                       ELSE target.current_status -- Preserve existing value for unmatched rows
                     END,
    UPDATE_DATE = CURRENT_DATE,
    Update_User = current_user||'_Review' '''
    
spark.sql(merge_abd_review_processed)


# COMMAND ----------


