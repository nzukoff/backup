# Databricks notebook source
dbutils.widgets.dropdown("environment", "dev", ['prod','dev','uat','stg','sit','preprod','dev_external'])
try:
  ENV = dbutils.widgets.get("env")
except:
  ENV = dbutils.widgets.get("environment")

ENV_ab = 'prod' if ENV == "prod" else 'dev'
print(ENV_ab)
print(ENV)

# COMMAND ----------

# MAGIC %run ./accelerated_billing_entry_config

# COMMAND ----------

print(catalog_nm,tgt_db_nm)

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.functions import lit
from datetime import datetime

def create_snapshot(df: DataFrame, output_table: str) -> None:
    process_date = datetime.utcnow().date()
    final_df = (df
                .withColumn('processDate', lit(process_date))  # Add processDate column
                .withColumn('type', lit('AUTOMATED'))  # Add type column
               )
    date_str = process_date.strftime('%Y-%m-%d')
    type_str = 'AUTOMATED'

    (final_df.write
             .mode('overwrite')
             .option('mergeSchema', 'true')
             .option('replaceWhere', f"processDate = '{date_str}' AND type = '{type_str}'")
             .partitionBy('processDate', 'type')
             .saveAsTable(output_table))

# COMMAND ----------

#adding the disable flag from quote table + changing the filters for the ledger table.
 
accelarated_billing_transactions_cng_quote = spark.sql(f"""
with scheduled_invoices as (
    select customer_id, contract_id, name, cast(sum(line_item_silver.total)/100 as decimal(24,4)) as scheduled_total
    from {catalog_nm}.it_billing_and_rating.invoice_silver 
    left join {catalog_nm}.it_billing_and_rating.line_item_silver on invoice_silver.id = line_item_silver.invoice_id
    where start_timestamp <= current_date -- Current_date
    and invoice_label in ( 'SCHEDULED' ,'CORRECTION')
    and status != 'VOID'
    --and line_item_silver.total > 0 filter this to include credits - as part of ticket BSEDATA-4646
    and contract_id is not null
    and name not like '%royalty fee'
    and name not like '%Subscription%'
    group by customer_id, contract_id, name
),
future_invoices as (

    ---adding name to additional join to the scheduled invoice to correct invoice mapping
    select customer_id, contract_id,name,invoice_silver.id as next_invoice_id, invoice_silver.total/100 as next_installment_amount, date(invoice_silver.start_timestamp) as next_installment_date, invoice_silver.id, row_number() over (partition by invoice_silver.contract_id,name order by invoice_silver.start_timestamp) as next_installment
    from {catalog_nm}.it_billing_and_rating.draft_invoice_silver invoice_silver
    left join {catalog_nm}.it_billing_and_rating.draft_line_item_silver line_item_silver on invoice_silver.id = line_item_silver.invoice_id
    where invoice_silver.total  > 0 

      and label = 'SCHEDULED'
    and status != 'VOID'
    --and draft_line_item_silver.total > 0
    and contract_id is not null
  
),

metronome_customer as (
  select id, name, ingest_aliases
  from {catalog_nm}.it_billing_and_rating.customer_silver
  where customer_silver.archived_at is null
  and customer_silver.name != 'OLD'
),
grouped_usage_data as (
  
select CPQ_Disable_Billing_Dates_Update__c ,contracts_commits_ledger_calculated.commit_id , metronome_customer.name as customer_name, customer_id, contracts_commits_ledger_calculated.contract_id, contracts_contracts_silver.name as contract_name, contracts_contracts_silver.salesforce_opportunity_id,ac.OwnerId,ac.Owner_Email__c,ac.Owner_Manager__c,opp.Owner_Manager_Email__c,
  starting_at, ending_before, 
  contracts_commits_ledger_calculated.name, contracts_commits_silver.type, sum((contracts_commits_ledger_calculated.amount * (-1)))/100 as total_usage
  from {catalog_nm}.it_billing_and_rating.contracts_commits_ledger_calculated
  inner join {catalog_nm}.it_billing_and_rating.contracts_contracts_silver on contracts_commits_ledger_calculated.contract_id = contracts_contracts_silver.id
  inner join metronome_customer on metronome_customer.id = contracts_contracts_silver.customer_id
  inner join {catalog_nm}.it_billing_and_rating.contracts_commits_silver on contracts_commits_ledger_calculated.commit_id = contracts_commits_silver.id
  left join main.sfdc_bronze.opportunity opp 
  on contracts_contracts_silver.salesforce_opportunity_id = opp.id
  and opp.processDate = ( select max(processdate) from main.sfdc_bronze.opportunity )

  left join main.sfdc_bronze.sbqq__quote__c quote on opp.SBQQ__PrimaryQuote__c = quote.Id
  and   quote.processDate = ( select max(processdate) from main.sfdc_bronze.sbqq__quote__c)

  left join main.sfdc_bronze.account ac on ac.id = opp.accountid
  and ac.processDate = (select max(processDate) from main.sfdc_bronze.account )
  where --start_date <= current_date
   contracts_commits_ledger_calculated.type IN ('postpaid_automated_invoice_deduction','prepaid_automated_invoice_deduction','prepaid_manual','postpaid_manual') 
  and contracts_contracts_silver.archived_at is null
  and contracts_contracts_silver.ending_before >= date(DATE_TRUNC('month', CURRENT_DATE) )
  --and coalesce(contracts_commits_ledger_calculated.name, '') in ('AWS Direct Commit', 'AWS Marketplace Commit', 'Flexible Commit', 'GCP Direct Commit', 'GCP Marketplace Commit', 'MCT Direct Commit')
  and contracts_commits_ledger_calculated.type not in ('prepaid_commit_credited')
  and contracts_commits_silver.total_cost > 0
  and date(contracts_contracts_silver.created_at) < current_Date - interval '1' day
  --- jira https://databricks.atlassian.net/browse/BAR-4101 - change below
  AND CONCAT(
        contracts_commits_ledger_calculated.type, 
        '_', 
        trim(coalesce(SUBSTRING_INDEX(reason, '|', 1), 'valid'))
     ) <> 'prepaid_manual_Ledger out'
  --and contracts_commits_ledger_calculated.commit_id = 'f2a5430c-3d32-419b-9fd3-f7a726fc4f12'
  group by CPQ_Disable_Billing_Dates_Update__c,commit_id,metronome_customer.name, customer_id, contracts_commits_ledger_calculated.contract_id,contracts_commits_silver.type, starting_at, ending_before, contracts_commits_ledger_calculated.name, contracts_contracts_silver.name 
  ,contracts_contracts_silver.salesforce_opportunity_id,ac.OwnerId,ac.Owner_Email__c,ac.Owner_Manager__c,opp.Owner_Manager_Email__c
)

select grouped_usage_data.*, coalesce(scheduled_invoices.scheduled_total, 0) as scheduled_total, next_invoice_id ,next_installment_amount, next_installment_date
from grouped_usage_data
inner join future_invoices on 
grouped_usage_data.contract_id = future_invoices.contract_id  
and grouped_usage_data.name = future_invoices.name 

left join scheduled_invoices on scheduled_invoices.contract_id = grouped_usage_data.contract_id 
            and scheduled_invoices.name = grouped_usage_data.name
where  coalesce(scheduled_invoices.scheduled_total, 0) < grouped_usage_data.total_usage
and  next_installment = 1
""" )


display(accelarated_billing_transactions_cng_quote)

accelarated_billing_transactions_cng_quote.createOrReplaceTempView ('accelarated_billing_transactions_cng_quote')

# COMMAND ----------

co_term = spark.sql(f'''select contract_id, name, product_id, count(*)
from {catalog_nm}.it_billing_and_rating.contracts_commits_silver
group by all
having count(*) > 1 ''') 

co_term.createOrReplaceTempView('co_term_data')

# COMMAND ----------

source_df_pre = spark.sql(f'''
                      

  SELECT abi.*, total_usage - scheduled_total excess_amount,
       CASE 
           WHEN abi.name LIKE '%Marketplace Commit%' THEN 'MP commit not in scope'
           WHEN abi.type = 'postpaid' THEN 'Postpaid commit not in scope'
           WHEN lower(abi.name) like  '%support%' THEN 'Support commit not in scope'
           WHEN CPQ_Disable_Billing_Dates_Update__c is true then 'Deferred Billing Review Needed'   
           WHEN abi.name LIKE '%MCT%' THEN 'MCT Commit to Review'
           WHEN DATEDIFF(next_installment_date, current_date()) <= 1 Then 'Scheduled invoice within 1 day'
           WHEN hold.Metronome_Customer_Id is not NULL then 'Exception Hold'  
           WHEN next_installment_amount  >= 1000000 THEN 'next installment > 1M Revops to Review'
           WHEN ctd.contract_id is not null then 'Possible Co-Term to Review'
           
           ELSE 'Ready to Process' 
       END AS initial_status,
       CASE 
           WHEN abi.name  LIKE '%Marketplace Commit%' THEN 'MP commit not in scope'
           WHEN abi.type = 'postpaid' THEN 'Postpaid commit not in scope'
           WHEN lower(abi.name) like '%support%' THEN 'Support commit not in scope'
           WHEN CPQ_Disable_Billing_Dates_Update__c is true then 'Review Needed'
           WHEN abi.name LIKE '%MCT%' THEN 'Review Needed'
           WHEN DATEDIFF(next_installment_date, current_date()) <= 1 Then 'Scheduled invoice within 1 day'
           WHEN hold.Metronome_Customer_Id is not NULL then 'Review Needed'
           WHEN next_installment_amount >= 1000000 THEN 'Review Needed'
           WHEN ctd.contract_id is not null then 'Review Needed'   
           ELSE 'Ready to Process' 
       END AS current_Status ,

       current_Date as create_date,
       cast(NULL as date) as update_date,
       cast(NULL as STRING) as update_user
      -- current_date as accelerated_invoice_date
FROM accelarated_billing_transactions_cng_quote abi
LEFT JOIN co_term_data ctd
on abi.contract_id = ctd.contract_id
LEFT JOIN {catalog_nm}.it_billing_and_rating.accelerated_billing_exception_hold hold
on hold.Metronome_Customer_Id = abi.customer_id
and  current_date() >= hold.Hold_Start_Dt''')

source_df_pre.createOrReplaceTempView('source_df_pre')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * FRom source_df_pre
# MAGIC

# COMMAND ----------

accelerated_billing_snap = (f'{catalog_nm}.it_billing_and_rating.accelerated_billing_daily_snapshot')
print(accelerated_billing_snap)

# COMMAND ----------

create_snapshot(df = spark.table('source_df_pre'), output_table = accelerated_billing_snap)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.it_billing_and_rating.accelerated_billing_daily_snapshot

# COMMAND ----------

acc_daily_table = (f'{catalog_nm}.it_billing_and_rating.accelerated_billing_daily')
print(acc_daily_table)

# COMMAND ----------

insert_accelarated_daily = spark.sql(f"""
SELECT source.customer_name,
       source.customer_id,
       source.contract_id,
       source.contract_name,
       source.starting_at,
       source.ending_before,
       source.name,
       source.type,
       source.total_usage,
       source.scheduled_total,
       source.next_invoice_id,
       cast(source.next_installment_amount as decimal(38,4)),
       source.next_installment_date,
       source.excess_amount,
       source.initial_status,
       source.current_status,
       source.salesforce_opportunity_id, 
       source.OwnerId,                
       source.Owner_Email__c,           
       source.Owner_Manager__c,         
       source.Owner_Manager_Email__c,   
       source.create_date,
       source.update_date,
       current_user||'_Automated' as update_user
FROM source_df_pre AS source
LEFT JOIN {acc_daily_table} AS target
  ON source.contract_id = target.contract_id
    AND coalesce( source.name,'UNKNOWN') = COALESCE(target.name,'UNKNOWN' )
     AND source.next_invoice_id = target.next_invoice_id
WHERE target.contract_id IS NULL
""")
#insert_accelarated_daily.printSchema()

# Append the filtered rows to the target table
insert_accelarated_daily.write.mode("append").saveAsTable(acc_daily_table)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * FRom main.it_billing_and_rating.accelerated_billing_daily

# COMMAND ----------

#%sql
# create or replace temp view accelerated_invoices_rollup as
ab_invoice_rollup = spark.sql(
    f"""select customer_name,customer_id,contract_id,contract_name ,next_invoice_id,next_installment_amount,next_installment_date, current_status as current_status, cast(NULL AS date) update_date,'AUTOMATED' as Type ,cast(NULL as string) as update_user 
from {catalog_nm}.it_billing_and_rating.accelerated_billing_daily where current_status in( 'Failed to Process to Metronome','Ready to Process' ,'Reviewed and Ready to Process' )
GROUP BY ALL

"""
)

ab_invoice_rollup.createOrReplaceTempView("ab_invoice_rollup")

# COMMAND ----------

invoice_rollup_snap = (f'{catalog_nm}.it_billing_and_rating.accelerated_billing_invoice_rollup_snapshot')
print(invoice_rollup_snap)

# COMMAND ----------

create_snapshot(df = spark.table('ab_invoice_rollup'), output_table = invoice_rollup_snap)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * FRom main.it_billing_and_rating.accelerated_billing_invoice_rollup_snapshot

# COMMAND ----------

display(ab_invoice_rollup)

# COMMAND ----------

source_df = spark.sql('''
    SELECT 
        next_invoice_id AS invoice_id, 
        * EXCEPT(next_invoice_id),
concat(
    date_format(current_date(), 'yyyy-MM-dd'), 
    'T', 
    '00:00:00.000', 
    'Z'
) AS issue_date
    FROM ab_invoice_rollup 
    WHERE current_status in ('Failed to Process to Metronome','Reviewed and Ready to Process' , 'Ready to Process') 
       
''')

source_df.createOrReplaceTempView('source_df')

# COMMAND ----------

display(source_df)

# COMMAND ----------

# MAGIC
# MAGIC %run ./defs_and_helper_functions_ab

# COMMAND ----------

ab_events_processed = source_df.withColumn(PAYLOAD_COL,to_json(struct([field for field in ab_event_payload])))
ab_events_processed.createOrReplaceTempView('ab_events_processed')


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ab_events_processed

# COMMAND ----------


ab_events_processed_to_upload = spark.sql('''select invoice_id,event from ab_events_processed''')
ab_events_processed_to_upload.createOrReplaceTempView('ab_events_processed_to_upload')


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ab_events_processed_to_upload
# MAGIC

# COMMAND ----------

TARGET_EVENT_RESPONSE_TBL = f'{catalog_nm}.it_billing_and_rating.accelerated_billing_events_upload'
print(TARGET_EVENT_RESPONSE_TBL)

# COMMAND ----------

from pyspark.sql.functions import lit, current_date, current_timestamp

# Process ledger events
ab_events_processed_to_upload = ab_events_processed_to_upload.withColumn(
    'metronome_response', send_to_metronome_on_demand(PAYLOAD_COL)
)

# Create a temporary view for SQL operations
ab_events_processed_to_upload.createOrReplaceTempView('ab_events_processed_to_upload_view')

# SQL query to join and select required fields
events_table = spark.sql('''
    SELECT 
        sdp.invoice_id,
        sdp.customer_name,
        sdp.customer_id,
        sdp.contract_id,
        sdp.contract_name,
        sdp.next_installment_amount,
        sdp.next_installment_date,
        sdp.current_status,
        sdp.update_date,
        sdp.issue_date,
        
        CASE 
            WHEN ae.metronome_response.status_code != '200' THEN 'Not Processed- Check Metronome API response - Reach out to IT Team'
            WHEN ae.metronome_response.status_code = '200' THEN 'Processed to Metronome'
            ELSE 'unknown-further check' 
        END AS processing_status ,
        ae.event event,
       
        ae.metronome_response
    FROM source_df sdp
    LEFT JOIN ab_events_processed_to_upload_view ae
    ON sdp.invoice_id = ae.invoice_id
''')

# Create a temporary view for the events table
events_table.createOrReplaceTempView('events_table')
# Add process_date and process_timestamp columns and write to the target table
events_table.withColumn("process_timestamp", lit(current_timestamp())) \
            .write \
            .mode("overwrite") \
            .saveAsTable(TARGET_EVENT_RESPONSE_TBL)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * FRom main.it_billing_and_rating.accelerated_billing_events_upload

# COMMAND ----------

from pyspark.sql.functions import current_date

# Define table names
current_table = f"{catalog_nm}.it_billing_and_rating.accelerated_billing_events_upload"
historical_table = f"{catalog_nm}.it_billing_and_rating.accelerated_billing_events_upload_hist"
print(current_table,historical_table)
# Read data from the current table
current_data_df = spark.table(current_table)

# Add a process_date/processtype column for tracking when the data was added to the historical table
current_data_with_process_date_and_type = current_data_df \
    .withColumn("process_type", lit("Automated"))\
    .withColumn("process_date", lit(current_date())) \

# Append data to the historical table
current_data_with_process_date_and_type.write \
    .mode("append") \
    .saveAsTable(historical_table)

print(f"Data from {current_table} successfully appended to {historical_table}")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.it_billing_and_rating.accelerated_billing_events_upload_hist
# MAGIC --where process_date = (select max(process_date) from integration.it_billing_and_rating.accelerated_billing_events_upload)
# MAGIC --and accelerated_billing_events_upload.process_timestamp = '2025-01-06T21:43:06.918+00:00'

# COMMAND ----------


Uploaded_API_trans = spark.sql(f''' 
select invoice_id,processing_status
 from 
{catalog_nm}.it_billing_and_rating.accelerated_billing_events_upload
--where invoice_id =  '19ddfe74-617b-584b-bb1e-028115c105a8'
qualify row_number() over (partition by invoice_id order by case when processing_status = 'Processed to Metronome' then 1 else 2 end ,  process_timestamp desc) = 1 ''')

Uploaded_API_trans.createOrReplaceTempView('Uploaded_API_trans')

# COMMAND ----------

merge_invoice_rollup = f'''
MERGE INTO {catalog_nm}.it_billing_and_rating.accelerated_billing_invoice_rollup_snapshot AS target
USING Uploaded_API_trans AS upload
ON target.next_invoice_id = upload.invoice_id
  --AND upload.process_date = CURRENT_DATE
  AND target.current_status IN ('Failed to Process to Metronome', 
                                'Reviewed and Ready to Process', 
                                'Ready to Process')
  AND target.processDate = CURRENT_DATE
WHEN MATCHED THEN
  UPDATE SET current_status = CASE 
                                WHEN target.current_status = 'Ready to Process' 
                                     AND upload.processing_status = 'Processed to Metronome' 
                                     THEN 'Processed to Metronome'
                                     
                                WHEN target.current_status = 'Reviewed and Ready to Process' 
                                     AND upload.processing_status = 'Processed to Metronome' 
                                     THEN 'Reviewed and Processed to Metronome'
                                     
                                WHEN target.current_status = 'Ready to Process' 
                                     AND upload.processing_status LIKE '%Not Processed%' 
                                     THEN 'Failed to Process to Metronome'
                                     
                                WHEN target.current_status = 'Reviewed and Ready to Process' 
                                     AND upload.processing_status LIKE '%Not Processed%' 
                                     THEN 'Reviewed and Failed to Process to Metronome'
                                
                                ELSE target.current_status -- Preserve existing value for unmatched rows
                              END,
     Update_Date = CURRENT_DATE ,
     Update_User = current_user||'_Automated' '''

spark.sql(merge_invoice_rollup)


# COMMAND ----------

# MAGIC %sql
# MAGIC select * From main.it_billing_and_rating.accelerated_billing_invoice_rollup_snapshot
# MAGIC where processDate = current_date

# COMMAND ----------


merge_accelarated_billing_daily = f'''
MERGE INTO {catalog_nm}.it_billing_and_rating.accelerated_billing_daily AS target
USING Uploaded_API_trans AS upload
ON target.next_invoice_id = upload.invoice_id
 AND target.current_status IN ('Failed to Process to Metronome', 
                                'Reviewed and Ready to Process', 
                                'Ready to Process')
  -- AND upload.process_date = CURRENT_DATE
WHEN MATCHED THEN
  UPDATE SET 
    current_status = CASE 
                       WHEN target.current_status in( 'Ready to Process' ,'Failed to Process to Metronome') 
                            AND upload.processing_status = 'Processed to Metronome' 
                            THEN 'Processed to Metronome'
                             
                       WHEN target.current_status in( 'Reviewed and Ready to Process' ,'Reviewed and Failed to Process to Metronome')
                            AND upload.processing_status = 'Processed to Metronome' 
                            THEN 'Reviewed and Processed to Metronome'
                             
                       WHEN target.current_status = 'Ready to Process' 
                            AND upload.processing_status LIKE '%Not Processed%' 
                            THEN 'Failed to Process to Metronome'
                             
                       WHEN target.current_status = 'Reviewed and Ready to Process' 
                            AND upload.processing_status LIKE '%Not Processed%' 
                            THEN 'Reviewed and Failed to Process to Metronome'
                             
                       ELSE target.current_status -- Preserve existing value for unmatched rows
                     END,
    UPDATE_DATE = CURRENT_DATE,
    Update_User = current_user||'_Automated' '''

spark.sql(merge_accelarated_billing_daily)


# COMMAND ----------

# MAGIC %sql
# MAGIC select * From main.it_billing_and_rating.accelerated_billing_daily
# MAGIC where  update_date = current_date  and current_Status = 'Processed to Metronome'
# MAGIC --customer_name like '%Acce%'
# MAGIC --where next_invoice_id = '02b0f6b2-2b51-569a-856e-517fef056b96'

# COMMAND ----------


