# Databricks notebook source
dbutils.widgets.dropdown("environment", "dev", ['prod','dev','uat','stg','sit','preprod','dev_external'])
try:
  ENV = dbutils.widgets.get("env")
except:
  ENV = dbutils.widgets.get("environment")

ENV_ab = 'prod' if ENV == "prod" else 'dev'
print(ENV_ab)
print(ENV)

# COMMAND ----------

# MAGIC
# MAGIC %run ./accelerated_billing_entry_config

# COMMAND ----------

print(catalog_nm,tgt_db_nm)

# COMMAND ----------

import os
import shutil
from datetime import datetime

# Source and destination directories
source_dir = f'{volume_path}'
destination_dir = f'{volume_archive_path}'
print(source_dir)
print(destination_dir)

# Ensure destination directory exists, create if not
if not os.path.exists(destination_dir):
    os.makedirs(destination_dir)

# Get current timestamp
current_timestamp = datetime.now().strftime('%Y%m%d%H%M%S')

# Iterate over files in the source directory
for filename in os.listdir(source_dir):
    # Construct new filename with timestamp appended
    new_filename = f"{os.path.splitext(filename)[0]}_{current_timestamp}{os.path.splitext(filename)[1]}"
    
    # Move the file to the destination directory
    shutil.move(os.path.join(source_dir, filename), os.path.join(destination_dir, new_filename))

# COMMAND ----------

cd /Volumes/main/it_billing_and_rating/accelerated_billing_upload_prod/


# COMMAND ----------

ls -l


# COMMAND ----------

cd /Volumes/main/it_billing_and_rating/accelerated_billing_upload_archive_prod/


# COMMAND ----------

ls -l

