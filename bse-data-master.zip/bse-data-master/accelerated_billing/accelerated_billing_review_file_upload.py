# Databricks notebook source
dbutils.widgets.dropdown("environment", "dev", ['prod','dev','uat','stg','sit','preprod','dev_external'])
try:
  ENV = dbutils.widgets.get("env")
except:
  ENV = dbutils.widgets.get("environment")

ENV_ab = 'prod' if ENV == "prod" else 'dev'
print(ENV_ab)
print(ENV)

# COMMAND ----------

# MAGIC %run ./accelerated_billing_entry_config

# COMMAND ----------

print(catalog_nm,tgt_db_nm)

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql.functions import lit
from datetime import datetime

def create_snapshot(df: DataFrame, output_table: str) -> None:
    process_date = datetime.utcnow().date()
    final_df = (df
                .withColumn('processDate', lit(process_date))  # Add processDate column
                .withColumn('type', lit('REVIEWED'))  # Add type column
               )
    date_str = process_date.strftime('%Y-%m-%d')
    type_str = 'REVIEWED'

    (final_df.write
             .mode('overwrite')
             .option('mergeSchema', 'true')
             .option('replaceWhere', f"processDate = '{date_str}' AND type = '{type_str}'")
             .partitionBy('processDate', 'type')
             .saveAsTable(output_table))

# COMMAND ----------

accelerated_billing_tablename = f'{catalog_nm}.{tgt_db_nm}.accelerated_billing_review_upload' 
accelerated_billing_tablename_hist = f'{catalog_nm}.{tgt_db_nm}.accelerated_billing_review_upload_hist' 
print(accelerated_billing_tablename)
print(accelerated_billing_tablename_hist)

# COMMAND ----------

# Directory path
directory = volume_path
print(directory)
process_date = 'process_date'

# COMMAND ----------

import os

# Get list of files in the directory
files = os.listdir(directory)

# Filter out directories, if any
files = [f for f in files if os.path.isfile(os.path.join(directory, f))]

# Get the latest file based on creation time
latest_file = max(files, key=lambda x: os.path.getctime(os.path.join(directory, x)))

# Full path of the latest file
latest_file_path = os.path.join(directory, latest_file)

# Print the latest file name and path
print("Latest File:", latest_file)
print("Latest File Path:", latest_file_path)

# Assign the latest file name to a variable
latest_file_variable = latest_file

# COMMAND ----------

path = directory + '/' + latest_file_variable    
print(path)

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import to_timestamp, col, lit, coalesce

# Define a function to parse date columns with multiple formats
def parse_date_column(df, column_name, formats):
    """
    Parse a date column with multiple potential formats and coalesce into a single column.
    """
    parsed_col = None
    for fmt in formats:
        if parsed_col is None:
            parsed_col = to_timestamp(col(column_name), fmt)
        else:
            parsed_col = coalesce(parsed_col, to_timestamp(col(column_name), fmt))
    return df.withColumn(column_name, parsed_col)

# List of supported date and datetime formats
date_formats = [
    "MM/dd/yyyy", "M/d/yyyy", "dd/MM/yyyy", "d/M/yyyy", "yyyy-MM-dd", "yyyy/MM/dd"
]
datetime_formats = [
    "MM/dd/yyyy HH:mm", "M/d/yyyy H:mm", "yyyy-MM-dd HH:mm:ss", "yyyy/MM/dd HH:mm"
]

# Set Spark legacy time parser for lenient parsing
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

# File path
file_path = directory + '/' + latest_file_variable  

# Read CSV into DataFrame
df_pre = spark.read.csv(file_path, header=True, inferSchema=False)

# Parse date columns using the function
df_fixed = df_pre
df_fixed = parse_date_column(df_fixed, "starting_at", datetime_formats)
df_fixed = parse_date_column(df_fixed, "ending_before", datetime_formats)
df_fixed = parse_date_column(df_fixed, "next_installment_date", date_formats)

# Cast numeric and decimal columns
df_fixed = df_fixed \
    .withColumn("total_usage", col("total_usage").cast("double")) \
    .withColumn("scheduled_total", col("scheduled_total").cast("decimal(38, 4)")) \
    .withColumn("next_installment_amount", col("next_installment_amount").cast("decimal(38, 4)")) \
    .withColumn("excess_amount", col("excess_amount").cast("double"))\
    .withColumn("next_installment_date", col("next_installment_date").cast("date"))

# Add file name as a column
df = df_fixed.withColumn("fname", lit(latest_file_variable))

# Show the DataFrame
display(df)


# COMMAND ----------

accelerated_billing_df, processDate = add_audit_attributes(df)

# COMMAND ----------

display(accelerated_billing_df)

# COMMAND ----------

print(accelerated_billing_tablename)

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')

print(f'Completely overwriting data in {accelerated_billing_tablename} for {processDate}')
(accelerated_billing_df
  .write
  .mode('overwrite')
  .format('delta')
  #.option("mergeSchema", "true")
  .saveAsTable(accelerated_billing_tablename))

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')

print(f'Appending data in  {accelerated_billing_tablename_hist} for {processDate}')
(accelerated_billing_df
  .write
  .mode('append')
  .format('delta')
  .partitionBy('process_date') # Ensure data is partitioned by 'process_date'
  #.option("mergeSchema", "true")
  .saveAsTable(accelerated_billing_tablename_hist))

# COMMAND ----------

# MAGIC %sql
# MAGIC select * FRom  main.it_billing_and_rating.accelerated_billing_review_upload_hist 

# COMMAND ----------


