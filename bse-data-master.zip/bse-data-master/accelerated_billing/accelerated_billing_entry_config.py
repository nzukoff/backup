# Databricks notebook source
from typing import Callable, Optional, Sequence
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit
from datetime import datetime, date
from dataclasses import dataclass, field

# COMMAND ----------

from dataclasses import dataclass

@dataclass(frozen=True)
class defineconfig:
  name: str
  tgt_db_nm: str
  catalog_nm: str
  volume_path: str
  volume_archive_path: str
  process_date: str

# COMMAND ----------


config =  { 

  'prod' : {
    'name' : 'Production',
    'tgt_db_nm': 'it_billing_and_rating',
    'catalog_nm': 'main',
    'volume_path' : '/Volumes/main/it_billing_and_rating/accelerated_billing_upload_prod',
    'volume_archive_path' : '/Volumes/main/it_billing_and_rating/accelerated_billing_upload_archive_prod',
    'process_date': 'process_date'
  } ,

  'dev' : {
    'name' : 'dev',
    'tgt_db_nm': 'it_billing_and_rating',
    'catalog_nm': 'integration',
    'volume_path' : '/Volumes/integration/it_billing_and_rating/accelerated_billing_upload_dev',
    'volume_archive_path' : '/Volumes/integration/it_billing_and_rating/accelerated_billing_upload_archive_dev',
    'process_date': 'process_date'
  } 
}

# COMMAND ----------

#ENV = dbutils.widgets.get("Environment") 
#ENV_Ledger = 'dev'

try:
  setconfig = defineconfig(
                        config[ENV_ab]['name'],
                        config[ENV_ab]['tgt_db_nm'],
                        config[ENV_ab]['catalog_nm'],
                        config[ENV_ab]['volume_path'],
                        config[ENV_ab]['volume_archive_path'],
                        config[ENV_ab]['process_date']
                      )
except Exception as e:
  print(e)
  raise Exception(f'Configurations are not defined for {ENV_ab}')

# COMMAND ----------

name = setconfig.name            
tgt_db_nm = setconfig.tgt_db_nm
catalog_nm = setconfig.catalog_nm
volume_path = setconfig.volume_path
volume_archive_path = setconfig.volume_archive_path
process_date = setconfig.process_date

# COMMAND ----------

from datetime import datetime, timedelta

def add_audit_attributes(df ):
  """
  Add process date

  """
  now = datetime.utcnow().date()
  
  df2 = (df
    .withColumn(process_date, lit(now))
    )
  
  return (df2, now)

# COMMAND ----------

#Use the cell below - since it has an add on to accept the date

# from pyspark.sql import SparkSession
# from pyspark.sql.functions import pandas_udf, PandasUDFType
# import pandas as pd
# import requests

# # Function to fetch and sum ledger amounts
# def fetch_and_sum_ledger_amounts(customer_id, commit_id):
#     base_url = "https://api.metronome.com/v1/contracts/customerCommits/list"
    
#     total_amount = 0.0
#     starting_balance = 0.0
#     message = ""
#     next_page = True
#     params = {
#         "customer_id": customer_id,
#         "commit_id": commit_id,
#         "include_ledgers": True,
#         "include_contract_commits": True,
#     }
    
#     while next_page:
#         response = requests.post(
#             base_url,
#             headers={
#                 "Authorization": f"Bearer {api_key}",
#             },
#             json=params,
#         )
        
#         if response.status_code != 200:
#             message = f"Error: {response.status_code} - {response.text}"
#             break
        
#         data = response.json()
        
#         for entry in data.get('data', []):
#             ledger = entry.get('ledger', [])
#             if not ledger:
#                 message = "No ledger data found in this entry."
#                 continue

#             cleaned_ledger = []
#             for item in ledger:
#                 try:
#                     cleaned_item = item.copy()
#                     cleaned_item['amount'] = float(cleaned_item.get('amount', 0))
#                     cleaned_ledger.append(cleaned_item)
                    
#                     if cleaned_item['type'].endswith('SEGMENT_START') or  cleaned_item['type'].endswith('INITIAL_BALANCE'):
#                         starting_balance += cleaned_item['amount']
#                 except ValueError:
#                     message = f"Error converting amount for item: {item}"
#                     continue
            
#             try:
#                 df = pd.DataFrame(cleaned_ledger)
#                 if 'amount' in df.columns:
#                     total_amount += df['amount'].sum()
#                 else:
#                     message = "Column 'amount' not found in DataFrame."
#             except Exception as e:
#                 message = f"Error creating DataFrame: {e}"
        
#         next_page = data.get('next_page')
#         if next_page:
#             params['page'] = next_page
#         else:
#             next_page = None
    
#     return total_amount, starting_balance, message

# # Define a function to apply the API call to each row
# def fetch_amounts_for_row(row):
#     customer_id = row['customer_id']
#     commit_id = row['commit_id']
#     total_amount, starting_balance, message = fetch_and_sum_ledger_amounts(customer_id, commit_id)
#     return (total_amount, starting_balance, message)

# # Convert to Pandas UDF
# @pandas_udf("struct<total_amount: double, starting_balance: double, message: string>", PandasUDFType.SCALAR)
# def process_row(customer_id: pd.Series, commit_id: pd.Series) -> pd.DataFrame:
#     results = [fetch_amounts_for_row({'customer_id': c, 'commit_id': co}) for c, co in zip(customer_id, commit_id)]
#     return pd.DataFrame(results, columns=["total_amount", "starting_balance", "message"])




# COMMAND ----------

# from pyspark.sql import SparkSession
# # from pyspark.sql.functions import pandas_udf, PandasUDFType
# # import pandas as pd
# import requests
# from datetime import datetime,date

# # Function to fetch and sum ledger amounts till the posted date if provided else get the overall sum.
# @udf(returnType="struct<total_amount: double, starting_balance: double, message: string>")
# def fetch_and_sum_ledger_amounts(customer_id, commit_id, posted_date:date=None):
#     base_url = "https://api.metronome.com/v1/contracts/customerCommits/list"
    
#     total_amount = 0.0
#     starting_balance = 0.0
#     message = ""
#     next_page = True
#     status = ''
#     params = {
#         "customer_id": customer_id,
#         "commit_id": commit_id,
#         "include_ledgers": True,
#         "include_contract_commits": True,
#     }
    
#     # posted_date = datetime.strptime(posted_date, '%Y-%m-%d').date()

#     while next_page:
#         response = requests.post(
#             base_url,
#             headers={
#                 "Authorization": f"Bearer {api_key}",
#             },
#             json=params,
#         )
        
#         if response.status_code != 200:
#             message = f"Error: {response.status_code} - {response.text}"
#             break
        
#         data = response.json()
        
#         for entry in data.get('data', []):
#             ledger = entry.get('ledger', [])
#             if not ledger:
#                 message = "No ledger data found in this entry."
#                 continue

#             for item in ledger:
#                 try:
#                     amount = float(item.get('amount', 0))
                    
#                     if item['type'].endswith('SEGMENT_START') or  item['type'].endswith('INITIAL_BALANCE'):
#                         starting_balance += amount
                    
#                     ledger_timestamp = datetime.strptime(item['timestamp'], '%Y-%m-%dT%H:%M:%S+00:00').date()
#                     #print(ledger_timestamp) #remove
#                     if posted_date:
#                         if ledger_timestamp <= posted_date:  
#                             total_amount += amount
#                     else:
#                         total_amount += amount
                    
#                 except Exception as e:
#                     error = str(e)
#                     message = f"Error: ({error}) while converting amount for item: {item}"
#                     print(message)
#                     status = 'FAILED'
#                     break
        
#         if status == 'FAILED':
#             break

#         next_page = data.get('next_page')
#         if next_page:
#             params['next_page'] = next_page
#         else:
#             next_page = None
    
#     return {
#         "total_amount": total_amount,
#         "starting_balance": starting_balance,
#         "message": message
#     }



# COMMAND ----------


