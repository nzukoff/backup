# Databricks notebook source
# MAGIC %run "./config_netsuite_SO_integration_api"

# COMMAND ----------

from threading import Lock
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from pyspark.sql import functions as F
from pyspark.sql.functions import col, to_timestamp
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, DoubleType,TimestampType
import datetime
import time
import json
import requests
import math
import threading

# COMMAND ----------

# Check for SOLineExternalID duplicates in the paygo_threshold_billing_audit_details table

dups = spark.sql(f''' 
SELECT SOLineExternalId, count(*) 
FROM {catalog}.{schema}.{table} 
GROUP BY 1 
HAVING count(*) > 1 ''' )

dups.createOrReplaceTempView('dups')

row = dups.count()
if row > 0 :
    raise Exception("There are SOLineExternalID duplicates in the table paygo_threshold_billing_audit_details - Please review before proceeding")

# COMMAND ----------

so_posting_success_dict = []
so_posting_failure_dict = []

# COMMAND ----------

# MAGIC %md 
# MAGIC #### SO CREATION CHECKS
# MAGIC ###### 1. Check if the total Sales Order amount = the total Grant amount for each invoice
# MAGIC ###### 2. Check if the difference between total usage amount and total API Grant amount >= SO Threshold limit for each invoice

# COMMAND ----------

def SO_Creation_Validation_Checks():

  latestAuditProcessDate = spark.sql(f''' SELECT MAX(PROCESSDATE) maxProcessDate FROM {catalog}.it_billing_and_rating.paygo_threshold_billing_audit_details ''').collect()[0]['maxProcessDate'].strftime('%Y-%m-%d') 

  spark.sql(f'''
  WITH LatestRecon AS (
    SELECT MetronomeInvoiceID, 
          TotalSOAmount, 
          TotalGrantAmount,
          processDate
    FROM {catalog}.it_billing_and_rating.paygo_threshold_billing_recon_details
    WHERE processDate = (SELECT MAX(processDate) FROM {catalog}.it_billing_and_rating.paygo_threshold_billing_recon_details)

  ),

  SO_Validation_Check AS (
      SELECT elg.MetronomeInvoiceId, 
            elg.MetronomeCustomerId, 
            elg.NetsuiteCustomerId,
            elg.InvoiceTotalUsageAmount,
            elg.InvoiceTotalGrantAmount, 
            elg.InvoiceTotalDueAmount,
            elg.SOThresholdLimit,
            elg.SOAmount,
            recon.TotalSOAmount InvoiceTotalSOAmount,
            recon.TotalGrantAmount InvoiceTotalGrantAmount,
            CASE
              WHEN (recon.TotalSOAmount = recon.TotalGrantAmount AND (elg.InvoiceTotalUsageAmount - recon.TotalGrantAmount) >= elg.SOThresholdLimit)
                    OR (recon.TotalSOAmount IS NULL AND  recon.TotalGrantAmount IS NULL)
                    AND elg.NetsuiteCustomerId IS NOT NULL
                THEN 'PASS'
              WHEN elg.NetsuiteCustomerId IS NULL
                THEN 'FAIL - Netsuite Customer ID is NULL'
              WHEN recon.TotalSOAmount != recon.TotalGrantAmount
                THEN 'FAIL - Total SO Amount created does not match Total Grant Amount created for this Invoice ID'
              WHEN (elg.InvoiceTotalUsageAmount - recon.TotalGrantAmount) < elg.SOThresholdLimit
                THEN 'FAIL - Difference between Total Usage and Total Grant Amount is less than SO Threshold Limit'
              ELSE 'FAIL'
            END AS SOCreationCheck,
            recon.processDate
      FROM eligible_invoices_vw elg
        LEFT JOIN LatestRecon recon
          ON elg.MetronomeInvoiceID = recon.MetronomeInvoiceID
  )

  MERGE INTO {catalog}.it_billing_and_rating.paygo_threshold_billing_audit_details audit
  USING (
      SELECT *
      FROM SO_Validation_Check 
  ) tr
  ON audit.MetronomeInvoiceId = tr.MetronomeInvoiceId
  AND audit.processDate = '{latestAuditProcessDate}'

  WHEN MATCHED THEN
  UPDATE SET  
  audit.SOCreationCheck = tr.SOCreationCheck

''')
  

# COMMAND ----------

# MAGIC %md 
# MAGIC #### POST REQUEST
# MAGIC ###### Create Sales Orders in Netsuite

# COMMAND ----------

def process_batch_to_ns(batch_name, so_header_external_id_dict_str, lock):

  print(f'Starting:  {batch_name}')

  so_header_external_id_array = []
  request_body = []

  for so_header_external_id in so_header_external_id_dict_str:
    getSoLinesQry = '''select SOLineExternalId, SOHeaderExternalId, SOItemID, SOItemCode, SOTotalQuantity, SOThresholdLimit, NetsuiteCustomerId, SOBillingDate, PaymentTerm, Subsidiary, SOCurrency from {}.{}.{} where SOHeaderExternalId='{}' '''.format(catalog, schema, table, so_header_external_id)
    soLineSparkDf = spark.sql(getSoLinesQry)
    so_lines_df = soLineSparkDf.toPandas()
    so_lines_dict = so_lines_df.to_dict(orient='records')
    so_lines=[]

    for line in so_lines_dict:
      line_data = {
        "externalId": line.get('SOLineExternalId'),   
        "itemId": line.get('SOItemID'),              
        "itemCode": line.get('SOItemCode'),    
        "quantity": line.get('SOTotalQuantity'),   
        "rate": int(line.get('SOThresholdLimit')),               
        "termStartDate": str(line.get('SOBillingDate')),                
        "termEndDate": str(line.get('SOBillingDate'))                   
      }
      so_lines.append(line_data)

    if len(so_lines_dict) > 0:
      so_header_dict = so_lines_dict[0]
      so_record = {
        "externalId": so_header_dict.get('SOHeaderExternalId'),      
        "customerId": int(so_header_dict.get('NetsuiteCustomerId')),  
        "billingDate": str(so_header_dict.get('SOBillingDate')),        
        "paymentTerm": so_header_dict.get('PaymentTerm'),             
        "subsidiary": so_header_dict.get('Subsidiary'),            
        "currency": so_header_dict.get('SOCurrency'),
        "soType" : "Threshold Billing",              
        "orderItemList": {
          "replaceAll": True,
          "itemList": so_lines 
        }
      }

      so_header_external_id_array.append(so_header_dict.get('SOHeaderExternalId'))
      request_body.append(so_record)
    else:
      print("No details found with SOHeaderExternalId: {}".format(so_header_external_id))
    
  request_body_json = json.dumps(request_body)

  with lock:  
  # fetch OAuth token to invoke NetSuite API if token is empty or expired 
    GeneratedToken = getAccessToken()

  url = apiUrl + "/salesOrders/listSalesOrders"
  headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + GeneratedToken
  }
  response = requests.post(url, headers=headers, data=request_body_json, timeout=30)
  response_json = response.json()
  #print(response.json())
  #print(response.status_code)

  in_clause = "'" + "', '".join(so_header_external_id_array) + "'"

  if response.status_code == 201:
    for record in response_json:
        transformed_record = {
            'header_external_id': record['externalId'],
            'SalesOrderID': record['internalId'] if record['status'] == 'Success' else None,
            'StatusMessage': record['status'],
            'ErrorMessage': None if record['status'] == 'Success' else record.get('errorMessage')
        }
        so_posting_success_dict.append(transformed_record)
        print(transformed_record)
  else:
    print("http status code: {}".format(response.status_code))
    print(response_json)
    so_posting_failure_dict.append({'SalesOrderID': None, 'StatusMessage': response_json['message'], 'ErrorMessage': response_json['description'], 'header_external_id_in_clause': in_clause})

# COMMAND ----------

# MAGIC %md 
# MAGIC #### GET REQUEST
# MAGIC ###### Validate SOs created in Netsuite with data in Audit Table

# COMMAND ----------

def GET_SO_Creation_Status():

  GET_responses = []
  get_schema = StructType([
        StructField('header_external_id', StringType(), True),
        StructField('SalesOrderID', DoubleType(), True),
        StructField('Amount', DoubleType(), True),
        StructField('CreatedDate', StringType(), True),
        StructField('Message', StringType(), True),
        StructField('Description', StringType(), True)
    ])

  so_header_external_id_df = spark.sql(f'''SELECT DISTINCT(SOHeaderExternalId) from SO_Creation_Pass''')
  so_header_external_id_dict = so_header_external_id_df.toPandas().to_dict(orient='list')

  for header_id in so_header_external_id_dict.get('SOHeaderExternalId'):
    token = getAccessToken()
    url = f'{apiUrl}/salesOrders/{header_id}'
    headers = {
        'Authorization': 'Bearer ' + token
      }
    response = requests.get(url, headers=headers)
    response_json = response.json()
    #print(response.json())
    #print(response.status_code)

    if response.status_code == 200:

      if 'internalId' in response_json:
        transformed_record = {
            'header_external_id': response_json['externalId'],
            'SalesOrderID': float(response_json['internalId']),
            'Amount': float(response_json['total']),
            'CreatedDate': response_json['createdDate'],
            'Message': None,
            'Description': None
        }
        GET_responses.append(transformed_record)
      else:
        transformed_record = {
          'header_external_id': header_id,
          'SalesOrderID': None,
          'Amount': None,
          'CreatedDate': None,
          'Message': response_json['message'],
          'Description': response_json['description']
        }
        GET_responses.append(transformed_record)

    else:
       transformed_record = {
          'header_external_id': header_id,
          'SalesOrderID': None,
          'Amount': None,
          'CreatedDate': None,
          'Message': response_json['message'],
          'Description': response_json['description']
        }
       GET_responses.append(transformed_record)
        
  GET_records = spark.createDataFrame(GET_responses, get_schema)
  GET_records.createOrReplaceTempView("GET_records_vw")
  #display(GET_records)

  spark.sql(f'''
    MERGE INTO {catalog}.it_billing_and_rating.paygo_threshold_billing_audit_details AS tbl
    USING GET_records_vw AS GetRec
    ON tbl.SOHeaderExternalID = GetRec.header_external_id
    WHEN MATCHED THEN
    UPDATE SET
        tbl.SO_API_SalesOrderID = CASE 
                                    WHEN tbl.SO_API_SalesOrderID IS NULL AND GetRec.SalesOrderID IS NOT NULL -- SO Created in NS; AT update Fail
                                      THEN GetRec.SalesOrderID
                                    WHEN tbl.SO_API_SalesOrderID IS NOT NULL AND GetRec.SalesOrderID IS NULL -- SO Failed in NS; AT update incorrect
                                      THEN NULL
                                  ELSE tbl.SO_API_SalesOrderID
                                  END,
        tbl.SO_API_ResponseStatus = CASE WHEN GetRec.SalesOrderID IS NOT NULL 
                                      THEN 'SUCCESS' 
                                    ELSE GetRec.Message 
                                    END,
        tbl.SO_API_ErrorMessage = CASE WHEN tbl.SO_API_ErrorMessage IS NULL AND GetRec.SalesOrderID IS NULL
                                    THEN GetRec.Description
                                  ELSE tbl.SO_API_ErrorMessage 
                                  END,
        tbl.SOCreationStatus = CASE WHEN GetRec.SalesOrderID IS NOT NULL 
                                  THEN 'SUCCESS' 
                                ELSE 'FAIL' 
                                END,
        tbl.SO_API_PostedTimeStamp = CASE 
                                        WHEN tbl.SO_API_PostedTimeStamp IS NULL AND GetRec.SalesOrderID IS NOT NULL
                                          THEN date_format(GetRec.CreatedDate, 'yyyy-MM-dd HH:mm:ss')
                                        WHEN tbl.SO_API_SalesOrderID IS NOT NULL AND GetRec.SalesOrderID IS NULL 
                                          THEN NULL
                                    ELSE tbl.SO_API_PostedTimeStamp 
                                    END,
        tbl.SO_API_Amount = CASE 
                              WHEN tbl.SO_API_PostedTimeStamp IS NULL AND GetRec.SalesOrderID IS NOT NULL
                                THEN GetRec.Amount
                              WHEN tbl.SO_API_SalesOrderID IS NULL AND GetRec.SalesOrderID IS NULL 
                                THEN NULL
                              ELSE tbl.SO_API_Amount 
                            END,
        tbl.SOValidationCheck = CASE WHEN GetRec.SalesOrderID IS NOT NULL
                                      THEN 'PASS - Successful GET Request'
                                    WHEN GetRec.SalesOrderID IS NULL AND (tbl.SO_API_SalesOrderID IS NULL) 
                                      THEN 'IGNORE - SO Creation Failed'
                                    ELSE
                                      'DISCREPANCY - ADDITIONAL CHECKS NEEDED'
                                END
          ''')

# COMMAND ----------

# MAGIC %md
# MAGIC #### ------------------------------------------------------------------------------------------

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1: Filter eligible invoices
# MAGIC Extract eligible data from paygo_threshold_billing_audit_details to create sales orders in Netsuite

# COMMAND ----------

eligible_invoices = spark.sql(f'''
                              SELECT *
                              FROM {catalog}.{schema}.{table}
                              WHERE processDate = (SELECT MAX(processDate) FROM {catalog}.{schema}.{table})
                              AND 
                              (   -- Sales Order Creation Status is NEW
                                  SO_API_SalesOrderID IS NULL
                              AND SO_API_PostedTimeStamp IS NULL
                              AND SOCreationStatus = 'NEW'
                              )
                              ''')
eligible_invoices.createOrReplaceTempView('eligible_invoices_vw')
display(eligible_invoices)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2: SO Validation Checks
# MAGIC Check if the eligible data from paygo_threshold_billing_audit_details pass the validation checks to create Sales Orders in Netsuite

# COMMAND ----------

SO_Creation_Validation_Checks()

SO_Creation_Pass = spark.sql(f'''
                             SELECT *
                             FROM {catalog}.{schema}.{table}
                             WHERE processDate = (SELECT MAX(processDate) FROM {catalog}.{schema}.{table})
                             AND SOCreationCheck = 'PASS'
                              ''')

SO_Creation_Pass.createOrReplaceTempView('SO_Creation_Pass')
display(SO_Creation_Pass)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3: Process POST requests
# MAGIC Create Sales Orders in Netsuite

# COMMAND ----------

so_posting_success_dict = []
so_posting_failure_dict = []
today = datetime.date.today()
first = today.replace(day=1)
previous_month_last_day = first - datetime.timedelta(days=1)
previous_day = today - datetime.timedelta(days=1)

lock = Lock();
thread_pool = ThreadPoolExecutor(max_workers=10)
print(f'{thread_pool._max_workers} worker thread pool is created')
poolFutures = []

#Extract number of eligible invoices
record_count_spark_df = spark.sql(f'''
                        SELECT COUNT(DISTINCT SOHeaderExternalId) as RecordCount 
                        FROM SO_Creation_Pass
                        WHERE SOCreationStatus = 'NEW'
                        AND SOCreationCheck = 'PASS'
                            ''')

record_count_dict = record_count_spark_df.toPandas().to_dict(orient='records')
record_count = record_count_dict[0].get('RecordCount')
print("Record count: {}".format(record_count))

# Divide the data into batches of 200 since NetSuite Async batch job has maximum size limit of 200 records
batch_count = math.ceil(record_count/200) 
print("Batch count: {}".format(batch_count))

for batch_num in range(batch_count):
  print("Batch number: {}".format(batch_num))
  get200SubscriptionsQry = f'''
                            SELECT DISTINCT SOHeaderExternalId 
                            FROM SO_Creation_Pass 
                            WHERE SOCreationStatus = 'NEW'
                            AND SOCreationCheck = 'PASS'
                              
                            LIMIT 200
                            '''
  sparkdf = spark.sql(get200SubscriptionsQry)

  df = {}
  so_header_external_id_dict = {}
  so_header_external_id_dict = sparkdf.toPandas().to_dict(orient='list')

  so_header_external_id_dict_str = [str(x) for x in so_header_external_id_dict.get('SOHeaderExternalId')]
  print('Length: ', len(so_header_external_id_dict_str))
  header_external_id_in_clause = ", ".join([f"'{i}'" for i in so_header_external_id_dict_str])

  update_NSProcessing_SOLines = spark.sql(f''' UPDATE {catalog}.it_billing_and_rating.paygo_threshold_billing_audit_details 
                                               SET SOCreationStatus = "POSTING" 
                                               WHERE SOHeaderExternalID IN ({header_external_id_in_clause})''')

  future = thread_pool.submit(process_batch_to_ns, "batch"+str(batch_num), so_header_external_id_dict_str, lock)
  poolFutures.append(future)
  
for futur in as_completed(poolFutures):
  print("one of the thread has completed its job")
  if futur.exception() is not None:
    print(f'Exception={futur.exception()}')

print("all the threads have completed processing!")

schema = StructType([
    StructField("header_external_id", StringType(), True),
    StructField("SalesOrderID", StringType(), True),
    StructField("StatusMessage", StringType(), True),
    StructField("ErrorMessage", StringType(), True)
])
successful_records = spark.createDataFrame(so_posting_success_dict, schema)
successful_records.createOrReplaceTempView("successful_records_vw")

spark.sql(f'''
    MERGE INTO {catalog}.it_billing_and_rating.paygo_threshold_billing_audit_details AS tbl
    USING successful_records_vw AS u
    ON tbl.SOHeaderExternalID = u.header_external_id
    WHEN MATCHED THEN
    UPDATE SET
        tbl.SO_API_SalesOrderID = u.SalesOrderID,
        tbl.SO_API_ResponseStatus = u.StatusMessage,
        tbl.SO_API_ErrorMessage = u.ErrorMessage,
        tbl.SOCreationStatus = CASE WHEN u.StatusMessage = 'Success' THEN 'SUCCESS' ELSE 'FAIL' END,
        tbl.SO_API_PostedTimeStamp = CASE WHEN u.StatusMessage = 'Success' THEN current_timestamp() ELSE NULL END,
        tbl.SO_API_Amount = CASE WHEN u.StatusMessage = 'Success' THEN tbl.SOAmount ELSE NULL END
''')

for failure in so_posting_failure_dict:
  updateSOLinesWithFailureStatusQry = '''
                                UPDATE {}.{}.{} 
                                SET SO_API_SalesOrderID = null,
                                    SO_API_ResponseStatus = {},
                                    SO_API_ErrorMessage = {},
                                    SO_API_PostedTimeStamp = null, 
                                    SOCreationStatus = "FAIL" 
                                WHERE SOHeaderExternalID in ({})
                                '''.format(catalog, schema, table, failure.get('StatusMessage'), failure.get('ErrorMessage'),failure.get('header_external_id_in_clause'))
  result = spark.sql(updateSOLinesWithFailureStatusQry)
  print('********** Failure ********** Error while posting a batch of records to NetSuite, please check and re-run the this process.')

thread_pool.shutdown()
print("End of Threshold Billing SalesOrder processing Job!")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4: Process GET requests
# MAGIC Validate the Sales Orders created in Netsuite

# COMMAND ----------

time.sleep(600)

# COMMAND ----------

GET_SO_Creation_Status()
