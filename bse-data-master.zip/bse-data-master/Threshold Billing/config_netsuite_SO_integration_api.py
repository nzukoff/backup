# Databricks notebook source
from typing import Callable, Optional, Sequence
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit
from datetime import datetime, date
from dataclasses import dataclass, field
import json
import requests

# COMMAND ----------

from dataclasses import dataclass

@dataclass(frozen=True)
class defineconfig:
  name: str
  catalog: str
  schema: str
  table : str
  netsuite_transaction_table : str
  apiUrl: str
  token: str
  token_url: str
  token_client_id: str
  token_client_secret: str
  token_audience: str
  

# COMMAND ----------

pricing_config =  { 'prod' : {
  'name' : 'Production',
  'catalog': 'main',
  'schema': 'it_billing_and_rating',
  'table':'paygo_threshold_billing_audit_details',
  'netsuite_transaction_table': 'netsuite2_bronze_hourly',
  'apiUrl': 'https://db-ns-customer-subscription-sapi.us-w2.cloudhub.io/api',
  'token': 'ns_api_auth_token_prod',
  'token_url': 'https://databricks.us.auth0.com/oauth/token',
  'token_client_id': 'ns_token_client_id_prod',
  'token_client_secret': 'ns_token_client_secret_prod',
  'token_audience': 'https://db-ns-customer-subscription-sapi.us-w2.cloudhub.io'
  
} ,

'dev' : {
  'name':'dev',
  'catalog': 'integration',
  'schema': 'it_billing_and_rating',
  'table':'paygo_threshold_billing_audit_details',
  'netsuite_transaction_table': 'netsuite2_sandbox1_bronze',
  'apiUrl': 'https://db-ns-customer-subscription-sapi-dev.us-w2.cloudhub.io/api',
  'token': 'ns_api_auth_token_dev',
  'token_url': 'https://dev-databricks.us.auth0.com/oauth/token',
  'token_client_id': 'ns_token_client_id_dev',
  'token_client_secret': 'ns_token_client_secret_dev',
  'token_audience': 'https://db-ns-customer-subscription-sapi-dev.us-w2.cloudhub.io'
} ,

'uat' : {
  'name':'dev',
  'catalog': 'integration',
  'schema': 'it_billing_and_rating',
  'table':'paygo_threshold_billing_audit_details',
  'netsuite_transaction_table': 'netsuite2_sandbox1_bronze',
  'apiUrl': 'https://db-ns-customer-subscription-sapi-dev.us-w2.cloudhub.io/api',
  'token': 'ns_api_auth_token_dev',
  'token_url': 'https://dev-databricks.us.auth0.com/oauth/token',
  'token_client_id': 'ns_token_client_id_dev',
  'token_client_secret': 'ns_token_client_secret_dev',
  'token_audience': 'https://db-ns-customer-subscription-sapi-dev.us-w2.cloudhub.io'
} 

}

# COMMAND ----------

dbutils.widgets.dropdown("Environment", "dev", ['prod','dev', 'uat'])
try:
  ENV = dbutils.widgets.get("Environment")
except:
  ENV = dbutils.widgets.get("Environment")

try:
  setconfig = defineconfig(
                        pricing_config[ENV]['name'],
                        pricing_config[ENV]['catalog'],
                        pricing_config[ENV]['schema'],
                        pricing_config[ENV]['table'],
                        pricing_config[ENV]['netsuite_transaction_table'],
                        pricing_config[ENV]['apiUrl'],
                        pricing_config[ENV]['token'],
                        pricing_config[ENV]['token_url'],
                        pricing_config[ENV]['token_client_id'],
                        pricing_config[ENV]['token_client_secret'],
                        pricing_config[ENV]['token_audience']
                      )
except Exception:
  raise Exception(f'Configurations are not defined for {ENV}')

# COMMAND ----------

catalog = setconfig.catalog
schema = setconfig.schema
table = setconfig.table
netsuite_transaction_table = setconfig.netsuite_transaction_table
apiUrl = setconfig.apiUrl
token = setconfig.token
SECRET_SCOPE = 'payg-netsuite-integration-api'
token_url = setconfig.token_url
token_client_id = dbutils.secrets.get(SECRET_SCOPE, setconfig.token_client_id)
token_client_secret = dbutils.secrets.get(SECRET_SCOPE, setconfig.token_client_secret)
token_audience = setconfig.token_audience

# COMMAND ----------

class TokenDetails:
  token = None
  token_expiry = None

def getAccessToken():
  if TokenDetails.token_expiry is None or datetime.datetime.now() >= TokenDetails.token_expiry:
    print('fetching new token')
    token_payload = json.dumps({
      "client_id": token_client_id,
      "client_secret": token_client_secret,
      "audience": token_audience,
      "grant_type": "client_credentials"
    })
    token_headers = {
      'Content-Type': 'application/json'
    }
    token_response = requests.request("POST", token_url, headers=token_headers, data=token_payload)
    token_response_json = token_response.json()
    TokenDetails.token = token_response_json['access_token']
    TokenDetails.token_expiry = datetime.datetime.now() + datetime.timedelta(seconds = (token_response_json['expires_in'] - 2))
  else:
    print(f'token is valid and it will expire at : {TokenDetails.token_expiry}, current timestamp: {datetime.datetime.now()}')
  return TokenDetails.token;
