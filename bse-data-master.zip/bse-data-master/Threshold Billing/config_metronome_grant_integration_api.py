# Databricks notebook source
from typing import Callable, Optional, Sequence
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit
from datetime import datetime, date
from dataclasses import dataclass, field
from pyspark.sql.functions import *
from pyspark.sql.types import * 
import datetime
import time
import json
import requests

# COMMAND ----------

from dataclasses import dataclass

@dataclass(frozen=True)
class defineconfig:
  name: str
  catalog: str
  schema: str
  table : str
  metronome_env : str
  apiUrl: str

# COMMAND ----------

pricing_config =  { 
  'prod' : {
    'name' : 'Production',
    'catalog': 'main',
    'schema': 'it_billing_and_rating',
    'table':'paygo_threshold_billing_audit_details',
    "metronome_env": "prod",
    'apiUrl': 'https://api.metronome.com/v1/credits/createGrant',
  } ,

  'dev' : {
    'name':'dev',
    'catalog': 'integration',
    'schema': 'it_billing_and_rating',
    'table':'paygo_threshold_billing_audit_details',
    "metronome_env": "stg",
    'apiUrl': 'https://api.metronome.com/v1/credits/createGrant',
  } ,

  'uat' : {
    'name':'dev',
    'catalog': 'integration',
    'schema': 'it_billing_and_rating',
    'table':'paygo_threshold_billing_audit_details',
    "metronome_env": "stg",
    'apiUrl': 'https://api.metronome.com/v1/credits/createGrant',
  } 
}

# COMMAND ----------

dbutils.widgets.dropdown("Environment", "uat", ['prod', 'dev', 'uat'])
try:
  ENV = dbutils.widgets.get("Environment")
except:
  ENV = dbutils.widgets.get("Environment")

try:
  setconfig = defineconfig(
                        pricing_config[ENV]['name'],
                        pricing_config[ENV]['catalog'],
                        pricing_config[ENV]['schema'],
                        pricing_config[ENV]['table'],
                        pricing_config[ENV]['metronome_env'],
                        pricing_config[ENV]['apiUrl'],
                      )
except Exception:
  raise Exception(f'Configurations are not defined for {ENV}')

# COMMAND ----------

def retrive_metronome_api_token(env = "sandbox"):
  return dbutils.secrets.get(scope = "bse-metronome", key = f"metronome_threshold_billing_api_key_{env}") 

# COMMAND ----------

catalog = setconfig.catalog
schema = setconfig.schema
table = setconfig.table
metronome_env = setconfig.metronome_env
api_key = retrive_metronome_api_token(metronome_env)
apiUrl = setconfig.apiUrl
credit_type = "2714e483-4ff1-48e4-9e25-ac732e8f24f2"

# COMMAND ----------

@udf(returnType=MapType(StringType(), StringType()))
def post_to_metronome_on_demand(payload):
    metronome_base_url = apiUrl
    token = api_key
    count = 0
    retry_attempts = 3
    json_payload = json.loads(payload)
    result = {}
    print("Processing: ", json_payload)
    while True:
        try:
            response = requests.post(
                metronome_base_url,
                headers={
                    "Authorization": f"Bearer {token}",
                },
                json=json_payload,
                timeout=30
            )
            print("Response: ", response.json())
            if response.status_code == 200:
                result["status"] = "success"
                result["id"] = response.json().get("data", {}).get("id", "ID not found")
            else:
                result["status"] = "error"
                result["message"] = response.json().get("message", "No message found")
            return result
        
        except Exception as e:
            count += 1
            if count >= retry_attempts:
                if response is not None:
                    try:
                        result["status"] = "error"
                        result["message"] = response.json().get("message", "No message found")
                        print(response.json())
                    except Exception as json_error:
                        result["status"] = "error"
                        result["message"] = str(json_error)
                        print(str(json_error))
                else:
                    result["status"] = "error"
                    result["message"] = str(e)
                    print(str(e))
                return result
          
    result["status"] = "error"
    result["message"] = "No message found"
    return result
