# Databricks notebook source
from pyspark.sql.functions import lit, date_format, concat, current_date, current_timestamp, when, col
from pyspark.sql import functions as F
from datetime import datetime,timedelta
from pyspark.sql import DataFrame

# COMMAND ----------

dbutils.widgets.dropdown("Environment", "dev", ['dev','uat', 'prod'])
try:
  ENV = dbutils.widgets.get("Environment")
except:
  ENV = dbutils.widgets.get("Environment")

# COMMAND ----------

if ENV == 'prod':
  OUTPUT_CATALOG = 'main'
  Audit_Table = f'{OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details'
  Recon_Table = f'{OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_recon_details'
  Netsuite_Transaction_Table = 'netsuite2_bronze_hourly'
else:
  OUTPUT_CATALOG = 'integration'
  Audit_Table = f'{OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details'
  Recon_Table = f'{OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_recon_details'
  Netsuite_Transaction_Table = 'netsuite2_sandbox1_bronze'

# COMMAND ----------

def create_report_snapshot(df: DataFrame, output_table: str) -> None:
  process_date = datetime.utcnow().date()
  final_df = df.withColumn('processDate', lit(process_date))         
  date_str = process_date.strftime('%Y-%m-%d')
  print(f'Updating data in {output_table} for {process_date}')

  (final_df.write
           .mode('overwrite')
           .option('mergeSchema', 'true')
           .option('replaceWhere', f"processDate = '{date_str}'")
           .partitionBy('processDate')
           .saveAsTable(output_table))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Audit Table Snapshot
# MAGIC
# MAGIC

# COMMAND ----------

full_raw_table_name_snap = f'{OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details_history'
df_snap = sql(f''' SELECT * 
                   FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details 
                   WHERE cast(SOBillingDate as timestamp) >= date_trunc('month', current_date())
                     AND cast(SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)
                  ORDER BY processDate DESC
              ''')

df_snap = df_snap.withColumnRenamed('processDate', 'auditProcessDate')

process_date = datetime.utcnow().date()
final_df = df_snap.withColumn('SnapshotProcessDate', lit(process_date))
final_df.createOrReplaceTempView("SNAPSHOT_TABLE")
display(final_df)

date_str = process_date.strftime('%Y-%m-%d')
print (f'Updating data in {full_raw_table_name_snap} for {process_date}')

(final_df
  .write
  .mode('overwrite')
  .format('delta')
  .option('mergeSchema', 'true')
  .option('replaceWhere', f"SnapshotProcessDate = '{date_str}'")
  .partitionBy("SnapshotProcessDate")
  .saveAsTable(full_raw_table_name_snap))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Check 0: Latest Netsuite and Metronome Egress time
# MAGIC
# MAGIC

# COMMAND ----------

check_metronome_time = datetime.utcnow() - timedelta(hours=12)
print("Metronome Egress Time Check (Current Time - 12 hours): ", check_metronome_time)
current_date = datetime.utcnow().date()
print("Current Date: ", current_date)

latestAuditProcessDate = spark.sql(f''' SELECT MAX(processDate) LatestProcessDate FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details ''').collect()[0]['LatestProcessDate']

latestGrantProcessDate = spark.sql(f''' SELECT MAX(process_timestamp) LatestProcessTime FROM {OUTPUT_CATALOG}.it_billing_and_rating.credit_grant_silver  ''').collect()[0]['LatestProcessTime']

latestInvoiceProcessDate = spark.sql(f''' SELECT MAX(process_timestamp) LatestProcessTime FROM {OUTPUT_CATALOG}.it_billing_and_rating.draft_invoice_silver  ''').collect()[0]['LatestProcessTime']

latestTransactionProcessDate = spark.sql(f''' SELECT MAX(DATE(processTimestamp)) LatestProcessTime FROM main.{Netsuite_Transaction_Table}.transaction  ''').collect()[0]['LatestProcessTime']

latestTransactionLineProcessDate = spark.sql(f''' SELECT MAX(DATE(processTimestamp)) LatestProcessTime FROM main.{Netsuite_Transaction_Table}.transactionline  ''').collect()[0]['LatestProcessTime']

if latestGrantProcessDate is not None and latestTransactionProcessDate is not None and latestTransactionLineProcessDate is not None:
  if abs((current_date - latestAuditProcessDate).days) <= 1 and (latestGrantProcessDate <= check_metronome_time):
    raise Exception(f"The latest Metronome Egress data load in credit_grant_silver table logFood occurred more than 12 hours before the current time. Last Metronome update time: {latestGrantProcessDate}")

  elif abs((current_date - latestAuditProcessDate).days) > 1 and (latestInvoiceProcessDate <= check_metronome_time):
    raise Exception(f"The latest Metronome Egress data load in draft_invoice_silver logFood occurred more than 12 hours before the current time. Last Metronome update time: {latestGrantProcessDate}")

  elif (latestTransactionProcessDate < (datetime.utcnow().date()+ timedelta(days= (-1))) ) or (latestTransactionLineProcessDate < (datetime.utcnow().date()+ timedelta(days= (-1))) ):
    raise Exception(f"The Netsuite LogFood data is not refreshed with latest data. Last Netsuite update date: {latestTransactionProcessDate}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Check 1: Missing Sales Order details - SO Created in Netsuite but Audit Table failed to update
# MAGIC
# MAGIC For all audit entries where the SO ID is missing in the current month, search the Netsuite Transactions table for any matching sales orders with an ExternalID that matches the AuditTable's SO ExternalID. Once a match is found, update the related SO fields in the Audit table. Once SO fields are updated, Metronome Grant Creation would pick them as well.

# COMMAND ----------

transactions_data = spark.sql( f'''SELECT DISTINCT
                                          tl.custcol_external_id EXTERNAL_ID ,
                                          tr.externalid TRANSACTION_EXTID ,
                                          tl.transaction SO_INTERNAL_ID,
                                          tl.linecreateddate SOCreationDate,
                                          (-tal.amount) SOAmount, 
                                          (-tl.quantity) SOQuantity,
                                          (tl.rate) SORate

FROM main.{Netsuite_Transaction_Table}.transactionline tl
INNER JOIN main.{Netsuite_Transaction_Table}.transaction tr
  on tl.transaction = tr.id 
LEFT JOIN main.{Netsuite_Transaction_Table}.transactionaccountingline tal
  on tl.id = tal.transactionline
  and tl.transaction = tal.transaction
WHERE 
    tr.type = 'SalesOrd'
AND tl.custcol_external_id IS NOT NULL
AND tr.externalid IS NOT NULL
AND cast(tl.custcolcustcoldb_startdate as timestamp) >= date_trunc('month', current_date())
AND cast(tl.custcolcustcoldb_enddate as timestamp) <= add_months(date_trunc('month', current_date()), 1)
''' )
transactions_data.createOrReplaceTempView('transactions_data')

# COMMAND ----------

MergeSalesOrderID = f'''

      MERGE INTO {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details audit
        USING (
            SELECT *
            FROM transactions_data 
        ) tr
        ON audit.SO_API_SalesOrderID IS NULL
        AND audit.SOLineExternalId = tr.EXTERNAL_ID
        AND audit.SOHeaderExternalId = tr.TRANSACTION_EXTID
        AND cast(audit.SOBillingDate as timestamp) >= date_trunc('month', current_date())
        AND cast(audit.SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)

      WHEN MATCHED THEN
      UPDATE SET  
        audit.SOCreationCheck = 'PASS',
        audit.SOCreationStatus = 'SUCCESS',
        audit.SO_API_SalesOrderID = tr.SO_INTERNAL_ID,
        audit.SO_API_Amount = tr.SOAmount,
        audit.SO_API_ResponseStatus = 'SO details updated using Netsuite Transactions',
        audit.SO_API_ErrorMessage = 'SO created in NS; Audit table failed to update',
        audit.SO_API_PostedTimeStamp = tr.SOCreationDate,
        audit.SOValidationCheck = 'PASS'
        
      '''
    
sql(MergeSalesOrderID)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Check 2: Missing Grant details - Grant Created in Metronome but Audit Table failed to update
# MAGIC For all audit entries from the current month where the SO Creation is successful but the Grant creation is missing, verify the corresponding SO ID in the Metronome egress invoice item to match related grants. Update the grantID and $ amount accordingly.

# COMMAND ----------

spark.sql(f'''

WITH grant_data AS (
  SELECT aud.MetronomeInvoiceId, 
        aud.SO_API_SalesOrderID, 
        aud.Grant_API_CreditGrantID,
        grnt.id EgressCreditGrantID,
        (grnt.amount_granted/100) AS EgressGrantAmount,
        grnt.created_at as EgressGrantCreationTimestamp

  FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details aud
    JOIN {OUTPUT_CATALOG}.it_billing_and_rating.credit_grant_silver grnt
      ON aud.SO_API_SalesOrderID = get_json_object(grnt.custom_fields, '$.netsuite_sales_order_id')

  WHERE cast(aud.SOBillingDate as timestamp) >= date_trunc('month', current_date())
    AND cast(aud.SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)
)

 MERGE INTO {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details audit
        USING (
            SELECT *
            FROM grant_data 
        ) gr
        ON audit.SO_API_SalesOrderID = gr.SO_API_SalesOrderID
        AND audit.MetronomeInvoiceId = gr.MetronomeInvoiceId
        AND audit.Grant_API_CreditGrantID IS NULL
        AND cast(audit.SOBillingDate as timestamp) >= date_trunc('month', current_date())
        AND cast(audit.SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)

      WHEN MATCHED THEN
      UPDATE SET 
        audit.GrantCreationCheck = 'PASS',
        audit.GrantCreationStatus = 'SUCCESS', 
        audit.Grant_API_CreditGrantID = gr.EgressCreditGrantID,
        audit.Grant_API_Amount = gr.EgressGrantAmount,
        audit.Grant_API_ResponseStatus = 'Grant details updated using Metronome Egress',
        audit.Grant_API_ErrorMessage = 'Grant details failed through API call; Populated using Egress',
        audit.Grant_API_PostedTimeStamp = gr.EgressGrantCreationTimestamp,
        audit.GrantValidationCheck = 'PASS'

''')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Check 3: SO Creation Successful but Grant Creation Failed
# MAGIC SO ID is populated but GRANT ID is empty in both Egress and API Call details -> Validation Status is FAIL -> Send Email Notification

# COMMAND ----------

spark.sql(f'''

WITH grant_data AS (
  SELECT 
        aud.MetronomeInvoiceId, 
        aud.SO_API_SalesOrderID, 
        aud.Grant_API_CreditGrantID,
        grnt.id EgressCreditGrantID,
        CASE 
          WHEN aud.Grant_API_CreditGrantID IS NULL OR get_json_object(grnt.custom_fields, '$.netsuite_sales_order_id') IS NULL
            THEN 'FAIL - SO Created successfully but Grant Creation Failed' 
          ELSE aud.GrantValidationCheck
        END AS ValidationMessage

  FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details aud
    LEFT JOIN {OUTPUT_CATALOG}.it_billing_and_rating.credit_grant_silver grnt
      ON aud.SO_API_SalesOrderID = get_json_object(grnt.custom_fields, '$.netsuite_sales_order_id')

  WHERE cast(aud.SOBillingDate as timestamp) >= date_trunc('month', current_date())
    AND cast(aud.SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)
    AND aud.SO_API_SalesOrderID IS NOT NULL
)


 MERGE INTO {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details audit
        USING (
            SELECT *
            FROM grant_data 
        ) gr
        ON audit.SO_API_SalesOrderID = gr.SO_API_SalesOrderID
        AND audit.MetronomeInvoiceId = gr.MetronomeInvoiceId
        AND audit.Grant_API_CreditGrantID IS NULL

      WHEN MATCHED THEN
      UPDATE SET 
        audit.GrantValidationCheck = gr.ValidationMessage

''')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Check 4: Verify SO details from Netsuite Transactions pipeline

# COMMAND ----------

spark.sql(f'''
WITH transaction_lines AS (
  SELECT tl.*, 
         tal.amount AMOUNT
  FROM main.{Netsuite_Transaction_Table}.transactionline tl
    LEFT JOIN main.{Netsuite_Transaction_Table}.transactionaccountingline tal
      on tl.id = tal.transactionline
      and tl.transaction = tal.transaction
  WHERE tl.processTimestamp = (SELECT max(processTimestamp) FROM main.{Netsuite_Transaction_Table}.transactionline)
  AND tal.processTimestamp = (SELECT max(processTimestamp) FROM main.{Netsuite_Transaction_Table}.transactionaccountingline)
),
transactions AS (
  SELECT * 
  FROM main.{Netsuite_Transaction_Table}.transaction
  WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.{Netsuite_Transaction_Table}.transaction)
),
SO_Recon AS (
    SELECT DISTINCT    
          SOHeaderExternalId,
          SOLineExternalId,
          CASE 
          WHEN tl.transaction = aud.SO_API_SalesOrderID AND (-tl.AMOUNT) = aud.SO_API_Amount
              THEN 'PASS'
          WHEN tl.transaction = aud.SO_API_SalesOrderID AND (-tl.AMOUNT) <> aud.SO_API_Amount
              THEN 'FAIL - SO Amount is different in Netsuite and Audit Table'
          WHEN tl.transaction <> aud.SO_API_SalesOrderID AND (-tl.AMOUNT) = aud.SO_API_Amount
              THEN 'FAIL - SO ID is different in Netsuite and Audit Table'
          WHEN tl.transaction <> aud.SO_API_SalesOrderID AND (-tl.AMOUNT) <> aud.SO_API_Amount
                THEN 'FAIL - SO ID and amount is different in Netsuite and Audit Table'
          ELSE
                'FAIL - Discrepancy in SO details in Netsuite and Audit Table'
          END AS SO_Check

FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details aud
  INNER JOIN transaction_lines tl
  ON aud.SOLineExternalId = tl.custcol_external_id
  INNER JOIN transactions tr
  ON aud.SOHeaderExternalId = tr.externalid
  LEFT JOIN transactions tra
  ON tl.transaction = tra.id

WHERE cast(aud.SOBillingDate as timestamp) >= date_trunc('month', current_date())
  AND cast(aud.SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)
  AND (aud.SOValidationCheck LIKE 'FAIL%' OR aud.SOValidationCheck IS NULL)
  AND tra.type = 'SalesOrd'
)

MERGE INTO {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details audit
USING (
    SELECT *
    FROM SO_Recon 
) chk
ON  audit.SOLineExternalId = chk.SOLineExternalId
AND audit.SOHeaderExternalId = chk.SOHeaderExternalId
AND cast(audit.SOBillingDate as timestamp) >= date_trunc('month', current_date())
AND cast(audit.SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)

WHEN MATCHED THEN
UPDATE SET  
audit.SOValidationCheck = chk.SO_Check

''')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Check 5: Verify Grant details from Metronome Egress pipeline

# COMMAND ----------

spark.sql(f'''

WITH grant_data AS (
  SELECT aud.MetronomeInvoiceId,
         grnt.name,
         CASE
          WHEN aud.Grant_API_CreditGrantID = grnt.id
            AND aud.Grant_API_Amount = CAST(grnt.amount_granted as double)/100
            AND aud.SO_API_SalesOrderID = get_json_object(Grnt.custom_fields, '$.netsuite_sales_order_id')
          THEN 'PASS'
          ELSE 'FAIL - Discrepancy in grant details in Audit Table and Metronome'
          END AS GrantValidationCheck

  FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details aud
    JOIN {OUTPUT_CATALOG}.it_billing_and_rating.credit_grant_silver grnt
      ON CONCAT('THB_', aud.SOHeaderExternalId) = grnt.name

  WHERE cast(aud.SOBillingDate as timestamp) >= date_trunc('month', current_date())
    AND cast(aud.SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)
    AND (aud.GrantValidationCheck LIKE 'FAIL%' OR aud.GrantValidationCheck IS NULL)
)

 MERGE INTO {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details audit
  USING (
      SELECT *
      FROM grant_data 
  ) gr
  ON CONCAT('THB_', audit.SOHeaderExternalId) = gr.name
  AND cast(audit.SOBillingDate as timestamp) >= date_trunc('month', current_date())
  AND cast(audit.SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)

  WHEN MATCHED THEN
  UPDATE SET 
  audit.GrantValidationCheck = gr.GrantValidationCheck

''')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get Invoice and cash sale details

# COMMAND ----------

spark.sql(f"""
WITH base_transaction AS (
    SELECT tr.*, tl.createdFrom
    FROM main.{Netsuite_Transaction_Table}.transaction tr
      INNER JOIN main.{Netsuite_Transaction_Table}.transactionline tl
        on tl.transaction = tr.id 
    WHERE tr.processTimestamp = (SELECT max(processTimestamp) FROM main.{Netsuite_Transaction_Table}.transaction)
      and tl.processTimestamp = (SELECT max(processTimestamp) FROM main.{Netsuite_Transaction_Table}.transactionline)
      and tl.mainline = 'T'
  ),
  base_trans_invoice AS (
    select * from base_transaction 
    WHERE type in ('CustInvc','CashSale')
  ),
  transaction_final AS (
    SELECT p.SO_API_SalesOrderID, 
          b.tranid AS SO_API_SalesOrderName, 
          b1.tranid AS SO_API_TransactionName,
          CAST(b1.id as decimal(38,0)) AS SO_API_TransactionID, 
          b1.type AS SO_API_TransactionType
    FROM 
    {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details p
      LEFT JOIN base_transaction b 
        ON p.SO_API_SalesOrderID = b.id
      LEFT JOIN base_trans_invoice b1 
        ON b.id = b1.createdFrom
    WHERE p.SO_API_SalesOrderID IS NOT NULL
    AND cast(p.SOBillingDate as timestamp) >= date_trunc('month', current_date())
    AND cast(p.SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)
  )
  MERGE INTO {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details audit
  USING (
      SELECT *
      FROM transaction_final 
  ) tr
  ON tr.SO_API_SalesOrderID = audit.SO_API_SalesOrderID


  WHEN MATCHED THEN
  UPDATE SET 
  audit.SO_API_SalesOrderName = tr.SO_API_SalesOrderName,
  audit.SO_API_TransactionName = tr.SO_API_TransactionName,
  audit.SO_API_TransactionID = tr.SO_API_TransactionID,
  audit.SO_API_TransactionType = tr.SO_API_TransactionType
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Check 6: Final Recon

# COMMAND ----------

recon_data = spark.sql(f'''
WITH CTE AS (
  SELECT DISTINCT tr.custbody_end_customer as NetsuiteCustomerID,
                inv.customer_id MetronomeCustomerID, 
                SUBSTRING_INDEX(tr.externalid, '_', 1) MetronomeInvoiceID,
                CAST(tl.custcolcustcoldb_startdate as date) TERM_START_DATE,
                CONCAT(EXTRACT(YEAR FROM CAST(tl.custcolcustcoldb_startdate as date)), '-', LPAD(EXTRACT(MONTH FROM CAST(tl.custcolcustcoldb_startdate as date)), 2, '0')) PeriodName,
                (tl.transaction) SOInternalID,
                (-tal.amount) SOAmount, 
                grnt.credit_grant_type,
                grnt.id GrantID, 
                CAST(grnt.amount_granted/100 as DOUBLE) GrantAmount
        
  FROM main.{Netsuite_Transaction_Table}.transactionline tl
    LEFT JOIN main.{Netsuite_Transaction_Table}.transaction tr
      ON tl.transaction = tr.id
    LEFT JOIN main.{Netsuite_Transaction_Table}.transactionaccountingline tal
      ON tl.id = tal.transactionline
      and tl.transaction = tal.transaction

    LEFT JOIN {OUTPUT_CATALOG}.it_billing_and_rating.credit_grant_silver grnt
      ON tr.id = get_json_object(grnt.custom_fields, '$.netsuite_sales_order_id')

    LEFT JOIN {OUTPUT_CATALOG}.it_billing_and_rating.draft_invoice_silver inv
      ON SUBSTRING_INDEX(tr.externalid, '_', 1) = inv.id
  
  WHERE 
      tr.type = 'SalesOrd'
  AND (grnt.id IS NULL OR grnt.credit_grant_type = 'Threshold Billing')
  AND tl.custcol_external_id LIKE '%THRESHOLD_BILLING%'
  AND tr.externalid IS NOT NULL
  AND cast(tl.custcolcustcoldb_startdate as timestamp) >= date_trunc('month', current_date())
  AND cast(tl.custcolcustcoldb_enddate as timestamp) <= add_months(date_trunc('month', current_date()), 1)
)

SELECT CAST(NetsuiteCustomerID as double) NetsuiteCustomerID,
       MetronomeCustomerID,
       MetronomeInvoiceID,
       PeriodName,
       CAST(COUNT(DISTINCT SOInternalID) as bigint) TotalSOInternalIDs,
       SUM(SOAmount) TotalSOAmount,
       CAST(COUNT(DISTINCT(GrantID)) as bigint) TotalGrantIDs,
       CAST(SUM(GrantAmount) as DOUBLE) TotalGrantAmount,
       CASE
         WHEN SUM(SOAmount) = SUM(GrantAmount) AND COUNT(DISTINCT(GrantID)) = COUNT(DISTINCT SOInternalID)
           THEN 'PASS'
         ELSE
           'FAIL'
       END AS ReconCheck
FROM CTE
GROUP BY ALL


''')

recon_data.createOrReplaceTempView('recon_data')
display(recon_data)

# COMMAND ----------

create_report_snapshot(df = spark.table('recon_data'), output_table = Recon_Table)
