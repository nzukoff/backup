# Databricks notebook source
from pyspark.sql import DataFrame
from pyspark.sql.functions import lit, date_format, concat, current_date, when, col
from pyspark.sql import functions as F
from datetime import datetime, timedelta
from datetime import datetime

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.dropdown("Environment", "dev", ['dev','uat', 'prod'])
try:
  ENV = dbutils.widgets.get("Environment")
except:
  ENV = dbutils.widgets.get("Environment")

# COMMAND ----------

dbutils.widgets.text('Standard Threshold Limit', '')
StdThresholdLimit = dbutils.widgets.getArgument('Standard Threshold Limit')

# COMMAND ----------

dbutils.widgets.text('Freeze Period: First m days', '')
first_m_days = int(dbutils.widgets.getArgument('Freeze Period: First m days'))
dbutils.widgets.text('Freeze Period: Last n days', '')
last_n_days = int(dbutils.widgets.getArgument('Freeze Period: Last n days'))

# COMMAND ----------

if ENV == 'prod':
  OUTPUT_CATALOG = 'main'
  Audit_Table = f'{OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details'
  PlatformSubscription_TABLE = 'main.sfdc_bronze.platformsubscription__c'
  Threshold_Netsuite_Sku_ID = '14288'
else:
  OUTPUT_CATALOG = 'integration'
  Audit_Table = f'{OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details'
  PlatformSubscription_TABLE = 'integration.sfdc_bronze.uat2_platformsubscription__c' 
  Threshold_Netsuite_Sku_ID = '15291'

# COMMAND ----------

def create_report_snapshot(df: DataFrame, output_table: str) -> None:
  process_date = datetime.utcnow().date()
  final_df = df.withColumn('processDate', lit(process_date))         
  date_str = process_date.strftime('%Y-%m-%d')
  print(f'Updating data in {output_table} for {process_date}')

  (final_df.write
           .mode('overwrite')
           .option('mergeSchema', 'true')
           .option('replaceWhere', f"processDate = '{date_str}'")
           .partitionBy('processDate')
           .saveAsTable(output_table))

# COMMAND ----------

def threshold_engine(df, StdThresholdLimit):
    # Create the SOThresholdLimit column based on the conditions
    
    df = df.withColumn(
        "SOThresholdLimit",
        when(col("ThresholdExemptFlag") == True, -1)                  # If ThresholdExemptFlag is True, set to -1
        .when(col("SFDCThresholdLimit").isNull(), StdThresholdLimit)  # If SFDCThresholdLimit is NULL, use StdThresholdLimit
        .otherwise(col("SFDCThresholdLimit"))                         # Otherwise, use SFDCThresholdLimit
    )
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC #### Salesforce Platform 
# MAGIC ##### Extract Cloudless Business Subscriptions from Salesforce

# COMMAND ----------

CloudlessSubs = spark.sql(f'''
                          
SELECT Billing_System_ID__c,
       Customer_Name__c,
       Name as BusinessSubscriptionId,
       Subscription_Source__c,
       Subscription_Id__c,
       Platform_Account_ID__c PlatformAccountId,
       Active__c,
       Start_Date__c,
       End_Date__c,
       Trial_End_Date__c,
       Type__c,
       Subscription_Channel__c,
       threshold_exempt__c,
       NS_Customer_Internal__c,
       CAST(Threshold_limit__c as decimal(38,0)) as SFDCThresholdLimit
FROM {PlatformSubscription_TABLE} platSub
WHERE platSub.processDate = (SELECT MAX(processDate) FROM {PlatformSubscription_TABLE})
  AND platSub.Type__c = 'PAYG' 
  AND platsub.Subscription_Channel__c = 'DIRECT'
  AND platSub.Billing_System_ID__c IS NOT NULL
  AND platSub.NS_Customer_Internal__c IS NOT NULL
  AND platSub.Subscription_Source__c = 'CLOUDLESS_SIGNUP'
''')

CloudlessSubs.createOrReplaceTempView('CloudlessSubs')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Metronome Invoices
# MAGIC ##### Join with Metronome Invoices to extract data for valid Metronome Customers

# COMMAND ----------

MetrInvoiceDraft = spark.sql(f'''

SELECT Inv.id as MetronomeInvoiceId,
       platSub.Billing_System_ID__c as MetronomeCustomerId,
       platSub.Customer_Name__c as MetronomeCustomerName,
       CAST(Cust.netsuite_internal_customer_id as double) as NetsuiteCustomerId,
       platSub.BusinessSubscriptionId as BusinessSubscriptionId,
       platSub.PlatformAccountId as PlatformAccountId,
       platSub.Subscription_Id__c as PlatformSubscriptionId,
       platSub.Active__c as Active,
       platSub.Start_Date__c as SubscriptionStartDate,
       platSub.End_Date__c as SubscriptionEndDate,
       platSub.Trial_End_Date__c as TrialEndDate,
       platSub.SFDCThresholdLimit as SFDCThresholdLimit,
       platsub.threshold_exempt__c as ThresholdExemptFlag,
       CAST(SUM(CASE
        WHEN Line_Item.credit_grant_id IS NULL THEN (Line_Item.total/100)
        ELSE 0
       END) as double) AS InvoiceTotalUsageAmount,
       CAST(SUM(CASE
        WHEN Line_Item.credit_grant_id IS NOT NULL THEN (-(Line_Item.total)/100)
        ELSE 0
       END) as double) AS InvoiceTotalGrantAmount,
       CAST(Inv.total/100 as double) AS InvoiceTotalDueAmount,
       MIN(Inv.start_timestamp) start_timestamp,
       MIN(Inv.end_timestamp) end_timestamp

FROM CloudlessSubs platSub
  JOIN {OUTPUT_CATALOG}.it_billing_and_rating.draft_invoice_silver Inv
    ON platSub.Billing_System_ID__c = Inv.customer_id

  JOIN {OUTPUT_CATALOG}.it_billing_and_rating.customer_silver Cust
    ON Cust.id = Inv.customer_id

  JOIN {OUTPUT_CATALOG}.it_billing_and_rating.draft_line_item_silver Line_Item
    ON Inv.id = Line_Item.Invoice_Id

WHERE Inv.label = 'PLAN_ARREARS'
AND CAST(Cust.netsuite_internal_customer_id as double) IS NOT NULL
AND Inv.total/100 > 0
AND (
  CASE 
      WHEN ('{ENV}' = 'uat' or '{ENV}' = 'dev') THEN (Inv.environment_type = 'STAGING' and Cust.environment_type = 'STAGING')
      ELSE True
  END
)
AND cast(Inv.start_timestamp as timestamp) >= date_trunc('month', current_date())
AND cast(Inv.end_timestamp as timestamp) <= add_months(date_trunc('month', current_date()), 1)

GROUP BY ALL
       

''')

MetrInvoiceDraft = MetrInvoiceDraft.withColumn("InvoiceStartDate", date_format("start_timestamp", "yyyy-MM-dd")).withColumn("InvoiceEndDate", date_format("end_timestamp", "yyyy-MM-dd"))
MetrInvoiceDraft = MetrInvoiceDraft.drop("start_timestamp", "end_timestamp")
MetrInvoiceDraft.createOrReplaceTempView('MetrInvoiceDraft')

# COMMAND ----------

# VALIDATION CHECK: Each customer can have only one PayGO Invoice in a particular month 

Customer_Invoice_Count = spark.sql(f'''
    SELECT MetronomeCustomerId, COUNT(DISTINCT MetronomeInvoiceID) Invoice_Count
    FROM MetrInvoiceDraft
    GROUP BY MetronomeCustomerId
    HAVING COUNT(DISTINCT MetronomeInvoiceID) > 1 
    ''')

if Customer_Invoice_Count.count() > 0:
  raise Exception("Multiple Invoices for a Customer in the current month")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Threshold Engine
# MAGIC ###### 1. If ThresholdExemptFlag is True, invoice is exempt from Threshold Billing so SOThresholdLimit is set to -1
# MAGIC ###### 2. If ThresholdExemptFlag is False and Threshold Limit is populated in Salesforce so SOThresholdLimit is set to Salesforce Threshold Limit
# MAGIC ###### 3. Else SOThresholdLimit is set to Standard Threshold Limit
# MAGIC

# COMMAND ----------

MetrThresholdInvoiceDraft = threshold_engine(MetrInvoiceDraft, StdThresholdLimit)

MetrThresholdInvoiceDraft.createOrReplaceTempView('MetrThresholdInvoiceDraft')

# COMMAND ----------

eligibleInv = spark.sql(f'''

SELECT *
FROM MetrThresholdInvoiceDraft
WHERE InvoiceTotalDueAmount >= SOThresholdLimit 
  AND SOThresholdLimit <> (-1)  -- SOThresholdLimit = (-1) signifies ThresholdExemptFlag = True
  AND ThresholdExemptFlag = False
  AND (InvoiceTotalDueAmount - ((abs(floor(InvoiceTotalDueAmount/ SOThresholdLimit)))*SOThresholdLimit)) > 0.1 -- Balance in Metronome Invoice to ensure month end billing

''')
eligibleInv.createOrReplaceTempView('eligibleInv')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Audit Table
# MAGIC Set initial attributes for Grants and SOs for each invoice and add all the eligible invoices to the audit table with a process date

# COMMAND ----------

eligibleInvSO = eligibleInv.withColumn('SOHeaderExternalId', concat(eligibleInv['MetronomeInvoiceId'], lit('_'), current_date()))\
                            .withColumn('SOLineExternalId', concat(eligibleInv['MetronomeInvoiceId'], lit('_'), lit('THRESHOLD_BILLING'), lit('_'),current_date()))\
                            .withColumn('SOItemID', F.lit(Threshold_Netsuite_Sku_ID).cast('integer'))\
                            .withColumn('SOItemCode', F.lit('INCREMENTAL_USAGE_CHARGE'))\
                            .withColumn('SOTotalQuantity', (F.abs(F.floor(F.col('InvoiceTotalDueAmount') / F.col('SOThresholdLimit'))).cast('double')))\
                            .withColumn('SOAmount',F.col('SOTotalQuantity')*F.col('SOThresholdLimit'))\
                            .withColumn('SOBillingDate', F.current_date())\
                            .withColumn('PaymentTerm', F.lit('Due on receipt'))\
                            .withColumn('Subsidiary', F.lit('Databricks, Inc.'))\
                            .withColumn('SOCurrency', F.lit('USD'))\
                            .withColumn('SOCreationStatus', F.lit('NEW'))\
                            .withColumn('SOCreationCheck', lit(None).cast('string'))\
                            .withColumn('SO_API_SalesOrderID', lit(None).cast('double'))\
                            .withColumn('SO_API_Amount', lit(None).cast('double'))\
                            .withColumn('SO_API_ResponseStatus', lit(None).cast('string'))\
                            .withColumn('SO_API_ErrorMessage', lit(None).cast('string'))\
                            .withColumn('SO_API_PostedTimeStamp', lit(None).cast('string'))\
                            .withColumn('SO_API_SalesOrderName', lit(None).cast('string')) \
                            .withColumn('SO_API_TransactionName', lit(None).cast('string')) \
                            .withColumn('SO_API_TransactionID', lit(None).cast('string')) \
                            .withColumn('SO_API_TransactionType', lit(None).cast('string')) \
                            .withColumn('SOValidationCheck', lit(None).cast('string'))\
                            .withColumn('GrantCreationStatus', F.lit('NEW'))\
                            .withColumn('GrantCreationCheck', lit(None).cast('string'))\
                            .withColumn('Grant_API_CreditGrantID', lit(None).cast('string'))\
                            .withColumn('Grant_API_Amount', lit(None).cast('double'))\
                            .withColumn('Grant_API_ResponseStatus', lit(None).cast('string'))\
                            .withColumn('Grant_API_ErrorMessage', lit(None).cast('string'))\
                            .withColumn('Grant_API_PostedTimeStamp', lit(None).cast('string'))\
                            .withColumn('GrantValidationCheck', lit(None).cast('string'))\
                            .withColumn('ReconCheck', lit(None).cast('string'))

eligibleInvSO.createOrReplaceTempView('eligibleInvSO')

# COMMAND ----------

display(eligibleInvSO)

# COMMAND ----------

current_date = datetime.now()
next_month = current_date.replace(day=28) + timedelta(days=4)  
last_day_of_month = next_month - timedelta(days=next_month.day)

is_last_n_days = current_date >= last_day_of_month - timedelta(days=last_n_days - 1)
is_first_m_days = current_date.day <= first_m_days

if is_last_n_days or is_first_m_days:
    print("The current date is in the Freeze Period i.e. last {last_n_days} days or the first {first_m_days} days of the month.")
else:
    print("The current date is not in the freeze period of the month, process Threshold Billing!")
    create_report_snapshot(df = spark.table('eligibleInvSO'), output_table = Audit_Table)
