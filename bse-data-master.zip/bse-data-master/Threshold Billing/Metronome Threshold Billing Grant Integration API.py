# Databricks notebook source
# MAGIC %run "./config_metronome_grant_integration_api"

# COMMAND ----------

from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from pyspark.sql.functions import last_day
from delta.tables import DeltaTable
from pyspark.sql.functions import udf
from pyspark.sql.types import MapType, StringType
from datetime import datetime
from threading import Lock
import time
import json
import requests
import math
import threading

# COMMAND ----------

OUTPUT_CATALOG = 'main' if ENV == 'prod' else 'integration'
OUTPUT_TABLE = f'{OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details'
print(OUTPUT_TABLE)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### POST REQUEST
# MAGIC ###### Create grants in Metronome

# COMMAND ----------

def process_to_metronome(so_header_external_id_dict_str):
  
  request_body = []
  
  for so_header_external_id in so_header_external_id_dict_str:    
    getSoLinesQry = '''SELECT DISTINCT MetronomeCustomerId, 
                                       MetronomeCustomerName, 
                                       SOAmount, 
                                       SOBillingDate, 
                                       InvoiceStartDate,
                                       SOItemID, 
                                       InvoiceEndDate,
                                       SOHeaderExternalId, 
                                       SO_API_SalesOrderID 
                        FROM {}.{}.{} where SOHeaderExternalId='{}' 
                        '''.format(catalog, schema, table, so_header_external_id)
    soLineSparkDf = spark.sql(getSoLinesQry)
    so_lines_df = soLineSparkDf.toPandas()
    so_lines_dict = so_lines_df.to_dict(orient='records')

    for line in so_lines_dict:
      MetronomeName = f"THB_{line.get('SOHeaderExternalId')}"

      grant_record = {
        "customer_id": line.get('MetronomeCustomerId'),
        "grant_amount": {
                "amount": int(line.get('SOAmount')) * 100,
                "credit_type_id": credit_type,  # Corresponds to USD currency
            },
        "name": MetronomeName, 
        "reason": "Threshold Billing", 
        "effective_at": datetime.strptime(line.get('InvoiceStartDate'), "%Y-%m-%d").strftime("%Y-%m-%dT%H:%M:%SZ"), 
        "expires_at": datetime.strptime(line.get('InvoiceEndDate'), "%Y-%m-%d").strftime("%Y-%m-%dT%H:%M:%SZ"), 
        "paid_amount": {
            "amount": int(line.get('SOAmount')) * 100,
            "credit_type_id": credit_type,      # Corresponds to USD currency
        },
        "priority": 0.5,
        "credit_grant_type": "Threshold Billing",
        "custom_fields": {
            "netsuite_sales_order_id": str(int(line.get('SO_API_SalesOrderID'))),
            "netsuite_internal_credit_item_id": str(line.get('SOItemID'))
        },
      }

      request_body.append(grant_record)

  request_body_json = json.dumps(request_body)
  json_data = [(json.dumps(d),) for d in request_body]
  json_payload_df = spark.createDataFrame(json_data, ["JSON_Request_Body"])
  grants_processed_to_upload = json_payload_df.withColumn('Metronome_Response', post_to_metronome_on_demand("JSON_Request_Body"))  
  
  return grants_processed_to_upload

# COMMAND ----------

# MAGIC %md 
# MAGIC #### AUDIT TABLE
# MAGIC ###### Update audit table with the POST response

# COMMAND ----------

def update_audit_table(metronome_response_df):

  json_schema = MapType(StringType(), StringType())
  df_parsed = metronome_response_df.withColumn("parsed_json", from_json(col("JSON_Request_Body"), json_schema))

  df_response = df_parsed.withColumn("SOExternalHeaderID", col("parsed_json").getItem("name"))\
                                     .withColumn("Status", col("Metronome_Response").getItem("status"))\
                                     .withColumn("ErrorMessage",
                                                when(col("Metronome_Response").getItem("status") == "error", col("Metronome_Response").getItem("message")).otherwise(None))\
                                    .withColumn("CreditGrantID", when(col("Metronome_Response").getItem("status")  == "success", col("Metronome_Response").getItem("id")).otherwise(None))

  df_response = df_response.drop('JSON_Request_Body', 'parsed_json', 'Metronome_Response')

  return df_response

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1: Grant Creation Check
# MAGIC ###### - Validate if Metronome Egress running grant total matches audit table API grant sum

# COMMAND ----------

spark.sql(f'''

WITH latest_grant_amount AS (
        SELECT MetronomeInvoiceId, 
              TotalGrantAmount
        FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_recon_details
        WHERE processDate = (SELECT MAX(processDate) FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_recon_details)
    ),

invoice_SO_check AS (
  SELECT audit.MetronomeInvoiceId, 
        CASE
          WHEN lg.TotalGrantAmount IS NULL THEN 0
          ELSE lg.TotalGrantAmount
        END as LatestEgressGrantAmount,
        CASE
          WHEN SUM(audit.Grant_API_Amount) IS NULL THEN 0 
          ELSE SUM(audit.Grant_API_Amount)
        END as TotalAPIGrantAmount
        
  FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details audit
    LEFT JOIN latest_grant_amount lg
      ON audit.MetronomeInvoiceId = lg.MetronomeInvoiceId
  WHERE cast(audit.SOBillingDate as timestamp) >= date_trunc('month', current_date())
    AND cast(audit.SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)
  GROUP BY ALL
),

Grant_Validation_Check AS (
  
  SELECT MetronomeInvoiceId,
        CASE
          WHEN (LatestEgressGrantAmount = TotalAPIGrantAmount)
            THEN 'PASS'
          WHEN (LatestEgressGrantAmount < TotalAPIGrantAmount)
            THEN 'FAIL : Mismatch between Egress and API Grant amount - LatestEgressGrantAmount < TotalAPIGrantAmount'
          WHEN (LatestEgressGrantAmount > TotalAPIGrantAmount)
            THEN 'FAIL : Audit table failed to update the details of grant successfully created in Metronome'
        END AS GrantCreationCheck
  FROM invoice_SO_check 
)

MERGE INTO {catalog}.{schema}.{table} audit
  USING (
      SELECT *
      FROM Grant_Validation_Check chk
  ) tr
  ON audit.MetronomeInvoiceId = tr.MetronomeInvoiceId
  AND (audit.GrantCreationCheck IS NULL OR audit.GrantCreationCheck LIKE 'FAIL%')

WHEN MATCHED THEN
UPDATE SET  
  audit.GrantCreationCheck = tr.GrantCreationCheck
                              
''')


# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2: Filter eligible invoices
# MAGIC Extract eligible data from audit table to create grants in Metronome

# COMMAND ----------

so_posting_success_dict = []
so_posting_failure_dict = []
getEligibleSoIDsDF = spark.sql(f'''
                          SELECT DISTINCT SOHeaderExternalId 
                          FROM {catalog}.{schema}.{table} 
                          WHERE 
                           (
                                    SOCreationStatus = 'SUCCESS'
                                AND SO_API_SalesOrderID IS NOT NULL
                                AND SO_API_PostedTimeStamp IS NOT NULL
                                AND SOValidationCheck LIKE 'PASS%'
                                AND GrantCreationStatus = 'NEW' 
                                AND GrantCreationCheck = 'PASS'
                                AND Grant_API_CreditGrantID IS NULL
                                AND Grant_API_PostedTimeStamp IS NULL
                                AND processDate = (SELECT MAX(processDate) FROM {catalog}.{schema}.{table})
                            )
                            OR
                            (
                                    SOCreationStatus = 'SUCCESS'
                                AND SO_API_SalesOrderID IS NOT NULL
                                AND SO_API_PostedTimeStamp IS NOT NULL
                                AND SOValidationCheck LIKE 'PASS%'
                                AND (GrantCreationStatus = 'ERROR' OR GrantCreationStatus = 'NEW')
                                AND GrantCreationCheck = 'PASS'
                                AND Grant_API_CreditGrantID IS NULL
                                AND Grant_API_PostedTimeStamp IS NULL
                            )
                            
                            
                            AND cast(SOBillingDate as timestamp) >= date_trunc('month', current_date())
                            AND cast(SOBillingDate as timestamp) <= add_months(date_trunc('month', current_date()), 1)
                            
                      ''')

so_header_external_id_dict = {}
so_header_external_id_dict = getEligibleSoIDsDF.toPandas().to_dict(orient='list')
so_header_external_id_dict_str = [str(x) for x in so_header_external_id_dict.get('SOHeaderExternalId')]

# COMMAND ----------

display(getEligibleSoIDsDF)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3: Process POST requests
# MAGIC Create grants in Metronome

# COMMAND ----------

if getEligibleSoIDsDF.count() != 0 or len(so_header_external_id_dict_str) != 0:
  metronome_response = process_to_metronome(so_header_external_id_dict_str)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4: Update Audit Table
# MAGIC Update audit table with the grant status

# COMMAND ----------

if getEligibleSoIDsDF.count() != 0 or len(so_header_external_id_dict_str) != 0:   
    audit_response = update_audit_table(metronome_response)
    audit_response.createOrReplaceTempView('audit_response_view')

    spark.sql(f'''

        MERGE INTO {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details AS tgt
        USING audit_response_view AS src
                ON tgt.SOHeaderExternalId = SUBSTRING_INDEX(src.SOExternalHeaderID, '_', -2)

        WHEN MATCHED AND src.Status = 'success' THEN
            UPDATE SET 
                tgt.GrantCreationStatus = 'SUCCESS',
                tgt.Grant_API_CreditGrantID = src.CreditGrantID,
                tgt.Grant_API_Amount = tgt.SOAmount,
                tgt.Grant_API_PostedTimeStamp = current_timestamp(),
                tgt.Grant_API_ResponseStatus = src.Status,
                tgt.Grant_API_ErrorMessage = NULL

        WHEN MATCHED AND src.Status = 'error' THEN
            UPDATE SET 
                tgt.GrantCreationStatus = 'ERROR',
                tgt.Grant_API_CreditGrantID = NULL,
                tgt.Grant_API_Amount = NULL,
                tgt.Grant_API_PostedTimeStamp = NULL,
                tgt.Grant_API_ResponseStatus = src.Status,
                tgt.Grant_API_ErrorMessage = src.ErrorMessage

    ''')
