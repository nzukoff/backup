# Databricks notebook source
# MAGIC %pip install beautifulsoup4

# COMMAND ----------

from datetime import datetime, timedelta
import sys
from it_data_lib import email, configure_logging
from urllib.request import urlopen
import logging
import base64

# COMMAND ----------

sys.path.insert(0, "..")
logger = configure_logging(s_level='DEBUG')

# COMMAND ----------

email_list_account = ['threshold-billing-notification@databricks.com']

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

dbutils.widgets.dropdown("Environment", "dev", ['dev','uat', 'prod'])
try:
  ENV = dbutils.widgets.get("Environment")
except:
  ENV = dbutils.widgets.get("Environment")

# COMMAND ----------

if ENV == 'prod':
  OUTPUT_CATALOG = 'main'
else:
  OUTPUT_CATALOG = 'integration'

# COMMAND ----------

# MAGIC %md
# MAGIC Email Body

# COMMAND ----------

failed_records = spark.sql(f''' 
                    SELECT CAST(NetsuiteCustomerID as decimal(38,0)) NetsuiteCustomerID,
                           MetronomeCustomerID,
                           MetronomeInvoiceID, 
                           TotalSOInternalIDs,
                           CAST((CASE WHEN TotalSOAmount IS NULL THEN 0 ELSE TotalSOAmount END) as decimal(38,0)) as TotalSOAmount,
                           TotalGrantIDs,
                           CAST((CASE WHEN TotalGrantAmount IS NULL THEN 0 ELSE TotalGrantAmount END) as decimal(38,0)) as TotalGrantAmount,
                           processDate
                    FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_recon_details 
                    WHERE processDate = (SELECT MAX(processDate) FROM {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_recon_details) 
                    AND ReconCheck = 'FAIL' 
                           ''')
if failed_records.count() > 0:
       processDate = failed_records.select('processDate').collect()[0][0]
       previousProcessDate = processDate + timedelta(days= (-1))
       failed_records = failed_records.drop('processDate')

# COMMAND ----------

display(failed_records)

# COMMAND ----------

if failed_records.count() > 0:
  subject = f''' Failed Records from Threshold Billing Recon '''

# COMMAND ----------

if failed_records.count() > 0:  
  html_table = failed_records.toPandas().to_html(index=False, border=1, classes='dataframe', justify='center')

  email_body = f"""
    <html>
    <head>
      <title>{subject}</title>
    </head>
    <body>
      <p></p>
      <p>The recon table {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_recon_details, created on {processDate} reflects the records processed on {previousProcessDate}, with updates based on egress data on {processDate}. </p>
      <p>For detailed information, please refer to {OUTPUT_CATALOG}.it_billing_and_rating.paygo_threshold_billing_audit_details_history for the process date of {processDate}. </p>{html_table}
      <p></p>

    </body>
    </html>
    """

# COMMAND ----------

# MAGIC %md
# MAGIC Send Emails

# COMMAND ----------

if len(failed_records.collect()) > 0:
  for to_address in email_list_account:
    message_id = email.send_it_data_email(
      to_emails=to_address,
      subject=subject,
      body_html=email_body,
      dbutils=dbutils,
      logger=logger,
      dry_run=False
    )

# COMMAND ----------

# logger.info(f"Sending email to: {', '.join(to_addresses + cc_addresses)}")
