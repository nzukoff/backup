# Databricks notebook source
import json
from pyspark.sql import Row
from pyspark.sql import types as T
from pyspark.sql import functions as F
from pyspark.sql import *

# COMMAND ----------

write_mode_list = ['overwrite', 'append', 'init']
dbutils.widgets.dropdown("write_mode", 'overwrite', ['overwrite', 'init'])
write_mode = dbutils.widgets.get('write_mode')
print(write_mode)

# COMMAND ----------

muj_config = [
  {
    'muj_name' : 'admin',
    'enabled' : True,
    'flags' : ["isAdmin", "inExpGroup"],
    'recommendation_column' : 'adminMsIsRecommended',
    'milestones' : [ {
                        'milestone_name' : 'ms1__external_reads',                        
                        'milestone_sfdc_name' : 'adminMs1ExternalReads__c',
                        'isFlag' : False,
                        'flags' : []      
                      },
                      {
                        'milestone_name' : 'ms2__external_api_calls',
                        'milestone_sfdc_name' : 'adminMs2ExternalApiCalls__c',
                        'isFlag' : False,
                        'flags' : []
                      },
                      {
                        'milestone_name' : 'ms3__job_runs',
                        'milestone_sfdc_name' : 'adminMs3JobRuns__c',
                        'isFlag' : False,
                        'flags' : []
                      }                      
                   ]
  },
  {
    'muj_name' : 'DE',
    'enabled' : True,
    'flags' : ["isDE", "inExpGroup"],
    'recommendation_column' : 'deMsIsRecommended',
    'milestones' : [ {
                        'milestone_name' : 'ms1__running_commands',                        
                        'milestone_sfdc_name' : 'deMs1RunningCommands__c',
                        'isFlag' : False,
                        'flags' : []     
                      },
                      {
                        'milestone_name' : 'ms2__external_reads',
                        'milestone_sfdc_name' : 'deMs2ExternalReads__c',
                        'isFlag' : False,
                        'flags' : []
                      },
                      {
                        'milestone_name' : 'ms3__external_writes',
                        'milestone_sfdc_name' : 'deMs3ExternalWrites__c',
                        'isFlag' : False,
                        'flags' : []
                      },
                      {
                        'milestone_name' : 'ms4__external_job_writes',
                        'milestone_sfdc_name' : 'deMs4ExternalJobWrites__c',
                        'isFlag' : False,
                        'flags' : []
                      },
                      {
                        'milestone_name' : 'ms5__repo_commits',
                        'milestone_sfdc_name' : 'deMs5RepoCommits__c',
                        'isFlag' : False,
                        'flags' : []
                      },
                   ]
  },
  {
    'muj_name' : 'AutoLoader',
    'enabled' : True,
    'flags' : ["isAutoLoader", "inExpGroup"],
    'recommendation_column' : 'autoLoaderMsIsRecommended',
    'milestones' : [ {
                        'milestone_name' : 'ms1_used_autoloader',                        
                        'milestone_sfdc_name' : 'autoloaderMs1UsedAutoloader__c',
                        'isFlag' : False,
                        'flags' : []      
                      },
                      {
                        'milestone_name' : 'ms2_dataio_features',
                        'milestone_sfdc_name' : 'autoloaderMs2DataioFeatures__c',
                        'isFlag' : False,
                        'flags' : []
                      },
                      {
                        'milestone_name' : 'ms3_delta_jobs',
                        'milestone_sfdc_name' : 'autoloaderMs3DeltaJobs__c',
                        'isFlag' : False,
                        'flags' : []
                      },
                      {
                        'milestone_name' : 'ms4_streaming_jobs',
                        'milestone_sfdc_name' : 'autoloaderMs4StreamingJobs__c',
                        'isFlag' : False,
                        'flags' : []
                      }
                   ]
  },
  {
    'muj_name' : 'DS',
    'enabled' : True,
    'flags' : ["isds", "inExpGroup"],
    'recommendation_column' : 'dsIsRecommended',
    'milestones' : [ {
                        'milestone_name' : 'ms1_usesDisplay',
                        'milestone_sfdc_name' : 'dsMs1UsesDisplay__c',
                        'isFlag' : False,
                        'flags' : []
                      },
                      {
                        'milestone_name' : 'ms2_writeDataToDelta',
                        'milestone_sfdc_name' : 'dsMs2WriteDataToDelta__c',
                        'isFlag' : False,
                        'flags' : []
                      },
                      {
                        'milestone_name' : 'ms3_importMlFramework',
                        #'milestone_sfdc_name' : 'dsMs3InstallLibrairieWithPip__c',
                        'milestone_sfdc_name' : 'dsMs3ImportMlFramework__c',
                        'isFlag' : False,
                        'flags' : []
                      }
                   ]
  },
  {
    'muj_name' : 'DBSQL DA',
    'enabled' : True,
    'flags' : [],
    'recommendation_column' : 'dbsqlMsIsRecommended',
    'milestones' : [ {
                        'milestone_name' : 'ms0_is_digital_mvp_dbsql',                        
                        'milestone_sfdc_name' : 'dbsqldaMs0IsDigitalMvpDbsql__c',
                        'isFlag' : True,
                        'flags' : ["isDigitalMVP"]     
                      },
                      {
                        'milestone_name' : 'ms1_select_dbsql_warehouse',
                        'milestone_sfdc_name' : 'dbsqldaMs1SelectDbsqlWarehouse__c',
                        'isFlag' : True,
                        'flags' : ["isDBsqlDA", "inExpGroup"]
                      },
                      {
                        'milestone_name' : 'ms2_create_visualization',
                        'milestone_sfdc_name' : 'dbsqldaMs2CreateVisualization__c',
                        'isFlag' : True,
                        'flags' : ["isDBsqlDA", "inExpGroup"]
                      },
                      {
                        'milestone_name' : 'ms3_create_dashboard',
                        'milestone_sfdc_name' : 'dbsqldaMs3CreateDashboard__c',
                        'isFlag' : True,
                        'flags' : ["isDBsqlDA", "inExpGroup"]
                      }
                   ]
  },
  {
    'muj_name' : 'DE V2',
    'enabled' : False,
    'flags' : ["isDE", "inExpGroup"],
    'recommendation_column' : 'dev2MsIsRecommended',
    'milestones' : [ {
                        'milestone_name' : 'ms1_delta',                        
                        'milestone_sfdc_name' : 'deMs1DeltaWrite__c',
                        'isFlag' : True,
                        'flags' : ["isDigitalMVP"]     
                      },
                      {
                        'milestone_name' : 'ms2_jobs',
                        'milestone_sfdc_name' : 'deMs2ScheduleAutomatedJob__c',
                        'isFlag' : True,
                        'flags' : ["isDBsqlDA", "inExpGroup"]
                      },
                      {
                        'milestone_name' : 'ms3_mtj_and_dwo',
                        'milestone_sfdc_name' : 'deMs3DeltaWriteOptimizedMultiTaskJob__c',
                        'isFlag' : True,
                        'flags' : ["isDBsqlDA", "inExpGroup"]
                      }
                   ]
  },
  
]

# COMMAND ----------

myJson = sc.parallelize(muj_config)
myDf = sqlContext.read.option("multiline", "true").json(myJson)

# COMMAND ----------

json.loads(json.dumps(muj_config))

# COMMAND ----------

schema = T.StructType([T.StructField('muj_name', T.StringType()),
    T.StructField('enabled', T.BooleanType()),
    T.StructField('recommendation_column', T.StringType()),
    T.StructField('flags', T.ArrayType(T.StringType())),
    T.StructField('milestones', T.ArrayType( T.StructType([
        T.StructField('milestone_name', T.StringType()),
        T.StructField('milestone_sfdc_name', T.StringType()),
        T.StructField('isFlag', T.BooleanType()),
        T.StructField('flags', T.ArrayType(T.StringType())),
    ])))])

# COMMAND ----------

schema.jsonValue()

# COMMAND ----------

if write_mode == 'init':
  df = spark.createDataFrame(json.loads(json.dumps(muj_config)),schema)
  #df= df.withColumn("milestones", df.milestones.cast(T.StringType()))
  #df= df.withColumn("milestones", F.from_json(df.milestones, schema))
else:
  df = spark.read.format("delta").load("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/iss_recommend_config")

# COMMAND ----------

#Do your transformations here

# COMMAND ----------

display(df)

# COMMAND ----------

df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/iss_recommend_config")

# COMMAND ----------


