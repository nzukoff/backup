# Databricks notebook source
import json
from pyspark.sql import Row
from pyspark.sql import types as T
from pyspark.sql import functions as F
from pyspark.sql import *

# COMMAND ----------

write_mode_list = ['overwrite', 'append', 'init']
dbutils.widgets.dropdown("write_mode", 'overwrite', ['overwrite', 'init'])
write_mode = dbutils.widgets.get('write_mode')
print(write_mode)

# COMMAND ----------

muj_config = [
  {
    'muj_name' : 'DE V2',
    'enabled' : True,
    'flags' : ["isDeCIP", "inExpGroup"],
    'recommendation_column' : 'deCIPMsIsRecommended',
    'milestones' : [ {
                        'milestone_name' : 'ms1_delta',                        
                        'milestone_sfdc_name' : 'deMs1DeltaWrite__c',
                        'isFlag' : True,
                        'flags' : []     
                      },
                      {
                        'milestone_name' : 'ms2_jobs',
                        'milestone_sfdc_name' : 'deMs2ScheduleAutomatedJob__c',
                        'isFlag' : True,
                        'flags' : []
                      },
                      {
                        'milestone_name' : 'ms3_mtj_and_dwo',
                        'milestone_sfdc_name' : 'deMs3DeltaWriteOptimizedMultiTaskJob__c',
                        'isFlag' : True,
                        'flags' : []
                      }
                   ]
  },
  
]

# COMMAND ----------

myJson = sc.parallelize(muj_config)
myDf = sqlContext.read.option("multiline", "true").json(myJson)

# COMMAND ----------

json.loads(json.dumps(muj_config))

# COMMAND ----------

schema = T.StructType([T.StructField('muj_name', T.StringType()),
    T.StructField('enabled', T.BooleanType()),
    T.StructField('recommendation_column', T.StringType()),
    T.StructField('flags', T.ArrayType(T.StringType())),
    T.StructField('milestones', T.ArrayType( T.StructType([
        T.StructField('milestone_name', T.StringType()),
        T.StructField('milestone_sfdc_name', T.StringType()),
        T.StructField('isFlag', T.BooleanType()),
        T.StructField('flags', T.ArrayType(T.StringType())),
    ])))])

# COMMAND ----------

schema.jsonValue()

# COMMAND ----------

if write_mode == 'init':
  df = spark.createDataFrame(json.loads(json.dumps(muj_config)),schema)
  #df= df.withColumn("milestones", df.milestones.cast(T.StringType()))
  #df= df.withColumn("milestones", F.from_json(df.milestones, schema))
else:
  df = spark.read.format("delta").load("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/cip_recommend_config")

# COMMAND ----------

#Do your transformations here

# COMMAND ----------

display(df)

# COMMAND ----------

df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/cip_recommend_config")

# COMMAND ----------


