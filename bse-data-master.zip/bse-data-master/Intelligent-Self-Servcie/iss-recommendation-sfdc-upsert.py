# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ### Aim:
# MAGIC Get the recommendation data from the Engineering data team, transform it and upsert it into Salesforce contact object
# MAGIC 
# MAGIC ### MUJ added:
# MAGIC 1. Admin
# MAGIC 2. Data Engineer
# MAGIC 3. Autoloader
# MAGIC 4. Data Science
# MAGIC 5. DBSQL DA
# MAGIC 
# MAGIC ### Algorithm{Need to update}:
# MAGIC 1. Install simple_salesforce.
# MAGIC 2. Get latest recommendation data from the recommendation table maintained by Engineering Data/Cloud solutions team.
# MAGIC 3. Clean the data by ensuring all the emails are in lowercase.
# MAGIC 4. Get account and contacts data from SFDC and join it with the recommendation data to get address of the contact.
# MAGIC 5. Filter the state and country. Only USA. The precedence of the address are as follows:
# MAGIC     * Mailing State or Mailing Country
# MAGIC     * Billing State or Billing Country
# MAGIC     * Shipping State or Shipping Country
# MAGIC     * Intercom State or Intercom Country
# MAGIC 6. Map the milestones with SFDC contacts columns.
# MAGIC     * admin recommendation to be sent only to those with isAdmin and inExpGroup flags on.
# MAGIC     * De recommendation to be sent only to those with isDE and inExpGroup flags on.
# MAGIC 7. Upsert the data to SFDC.

# COMMAND ----------

# MAGIC %sh
# MAGIC pip install simple_salesforce

# COMMAND ----------

from pyspark.sql.functions import *
from simple_salesforce import Salesforce
import numpy as np
import json
import datetime
import requests
from requests.auth import HTTPBasicAuth
import json

# COMMAND ----------

token = dbutils.secrets.get('store-ssa-token', 'ssa-token')
sc._jsc.hadoopConfiguration().set("fs.azure.sas.databricks-prod-multi-geo-internal.dbmgintprodwestus.blob.core.windows.net", token)
# p_users.createOrReplaceTempView("pseudo_users")
# p_users_df = spark.sql("select distinct canonicalUserId,lower(email) from pseudo_users where email is not NULL")
# p_users_df = p_users_df.withColumnRenamed("canonicalUserId","cuid")

# COMMAND ----------

### RK changes
source_rec_df = spark.read.format("delta").load("wasbs://databricks-prod-multi-geo-internal@dbmgintprodwestus.blob.core.windows.net/tables/iss_recommendation_history_prod")
source_rec_df.createOrReplaceTempView("source_recommendations")

# COMMAND ----------

# job_status = dbutils.notebook.run("ISS_config",0)
# job_json = json.loads(job_status)

# COMMAND ----------

config_df=spark.read.format("delta").load("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/iss_recommend_config")

# COMMAND ----------

display(config_df)

# COMMAND ----------

config_json=config_df.toJSON().map(lambda j: json.loads(j)).collect()

# COMMAND ----------

# MAGIC %sql
# MAGIC select max(processedDate) running_for_processedDate
# MAGIC from source_recommendations

# COMMAND ----------

rec_df = spark.sql("""
select *
from source_recommendations
where processedDate = (select max(processedDate) from source_recommendations)
""")
rec_df = rec_df.withColumn("email",lower(col("email")))
print(rec_df.count())

# COMMAND ----------

# rec_df = spark.read.format("delta").load("wasbs://databricks-prod-multi-geo-internal@dbmgintprodwestus.blob.core.windows.net/tables/iss_recommendation_history_prod") \
#                                    .filter('processedDate = "{}"'.format(str((datetime.datetime.today()-datetime.timedelta(0)).date())))
#rec_df = rec_df.withColumn("email",lower(col("email")))

# COMMAND ----------

#rec_df.count()

# COMMAND ----------

account_df = spark.sql("""
SELECT Id as AccId, 
      BillingState, 
      ShippingState,
      BillingCountry,
      ShippingCountry
      from (SELECT 
            Id, 
            BillingState, 
            ShippingState,
            BillingCountry,
            ShippingCountry,
            ROW_NUMBER() OVER (PARTITION BY Id 
                               ORDER BY CreatedDate DESC) AS ROWNUM 
            FROM sfdc_ds.account 
            where ProcessDate=(SELECT 
                               max(ProcessDate) 
                               FROM sfdc_ds.account) 
            and Id is not NULL) 
            where ROWNUM=1""")

# COMMAND ----------

contact_df = spark.sql("SELECT lower(Email) as email_c,Id,MailingState, MailingCountry, AccountId  from (SELECT lower(Email) as Email,Id,CreatedDate, MailingState, MailingCountry, AccountId, ROW_NUMBER() OVER (PARTITION BY Email ORDER BY CreatedDate DESC) AS ROWNUM FROM sfdc_ds.contact where ProcessDate=(SELECT max(ProcessDate) FROM sfdc_ds.contact) and email is not NULL) where ROWNUM=1")

# COMMAND ----------

contact_join_df=contact_df.join(account_df, contact_df.AccountId == account_df.AccId, how="left")

# COMMAND ----------

rec_dfv1 = rec_df.join(contact_join_df, rec_df.email == contact_join_df.email_c, how="left").drop("email_c") #\
                  #.filter("inExpGroup")

# COMMAND ----------

rec_dfv1.filter("Id is NULL").count()

# COMMAND ----------

rec_dfv1.count()

# COMMAND ----------

rec_dfv2=rec_dfv1.withColumn("SFDCState",when(col("MailingState").isNotNull(), col("MailingState"))
                                                                   .when(col("ShippingState").isNotNull(), col("ShippingState"))
                                                                   .when(col("BillingState").isNotNull(), col("BillingState"))                                                                 
                                                                   .otherwise(col("BillingState"))) \
                 .withColumn("SFDCCountry",when(col("MailingCountry").isNotNull(), col("MailingCountry"))
                                                                   .when(col("ShippingCountry").isNotNull(), col("ShippingCountry"))
                                                                   .when(col("BillingCountry").isNotNull(), col("BillingCountry"))                                                                 
                                                                   .otherwise(col("BillingCountry")))

# COMMAND ----------

rec_dfv2.filter("SFDCCountry is NULL").count()

# COMMAND ----------

# intercom_contact_df = spark.read.format("delta").load("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/intercom_contact_stage")
# intercom_contact_df = intercom_contact_df.withColumnRenamed("processedDate","intercomProcessedDate")
# intercom_contact_df.write.format("delta").mode("append").partitionBy("intercomProcessedDate").option("mergeSchema", "true").save("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/intercom_contact_cache")

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM delta.`wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/intercom_contact_cache` WHERE intercomProcessedDate < date_sub(current_timestamp(), 30)

# COMMAND ----------

#Check email already in intercom_contact_table
intercom_contact_df = spark.read.format("delta").load("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/intercom_contact_cache")
process_date=intercom_contact_df.select('intercomProcessedDate').distinct().collect()[0]['intercomProcessedDate']

if datetime.datetime.strptime(process_date,"%Y-%m-%d").date() > (datetime.datetime.now() - datetime.timedelta(30)).date(): 
  intercom_contact_df = intercom_contact_df.withColumnRenamed("intercom_country", "intercom_country_cached") \
                                           .withColumnRenamed("region", "region_cached") \
                                           .drop('intercomProcessedDate')
  rec_dfv21 = rec_dfv2.join(broadcast(intercom_contact_df), rec_dfv2.email == intercom_contact_df.email_id, how="left").drop("email_id")

# COMMAND ----------

rec_dfv21.filter("(SFDCCountry is NULL and intercom_country_cached is NULL)").count()

# COMMAND ----------

#TODO: Add checkpointing
state_email=rec_dfv21.filter("SFDCCountry is NULL and intercom_country_cached is NULL").select("email").collect()
email_id_list=set([x['email'] for x in state_email])

intercom_cred = dbutils.secrets.get('bse-dev-creds', 'bse-intercom-api')
intercom_id = intercom_cred.split(',')[0]
intercom_token = intercom_cred.split(',')[1]

contact_query_list=[]
count=0
start_time=datetime.datetime.now()
#for j in range(10):
print("Getting intercom contact data from API..")
for i in email_id_list:
  #print(i)
  query = {
    "query": {
            "field": "email",
            "operator": "=",
            "value": i
    }
  }
  rs_contact = requests.post("https://api.intercom.io/contacts/search", auth = HTTPBasicAuth(intercom_token, intercom_id), json=query)
  if 'data' in rs_contact.json():
    if len(rs_contact.json()['data'])>0:
      rs_contact_json=rs_contact.json()['data'][0]
      rs_new_contact={}
      #rs_new_contact['contact_id'] = rs_contact_json['id']
      rs_new_contact['email_id'] = rs_contact_json['email']
      rs_new_contact['intercom_country'] = rs_contact_json['location']['country']
      rs_new_contact['region'] = rs_contact_json['location']['region']
      rs_new_contact['intercomProcessedDate'] = str(datetime.datetime.now().date())
      contact_query_list.append(rs_new_contact)
  else:
    print(rs_contact.json())
  count+=1
  if start_time + datetime.timedelta(seconds=1) <= datetime.datetime.now():
    print("Processed {}".format(count))
    start_time+=datetime.timedelta(seconds=10)

contact_json_rdd = sc.parallelize(contact_query_list).map(lambda x: json.dumps(x))
contact_query_df = spark.read.json(contact_json_rdd)
contact_query_df.createOrReplaceTempView("contact_query")
print("Writing data..")
res=spark.sql("""MERGE INTO delta.`wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/intercom_contact_cache` as contact
                      USING contact_query
                      ON contact.email_id = contact_query.email_id
                      WHEN MATCHED THEN
                        UPDATE SET *
                      WHEN NOT MATCHED THEN
                      INSERT *""")
res.show()
#contact_query_df.write.format("delta").mode("append").partitionBy("intercomProcessedDate").option("mergeSchema", "true").save("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/intercom_contact_cache")

# COMMAND ----------

rec_dfv3 = rec_dfv21.join(contact_query_df, rec_df.email == contact_query_df.email_id, how="left").drop("email_id")

# COMMAND ----------

rec_dfv31 = rec_dfv3.withColumn("region",when(col("region").isNotNull(), col("region"))                                                                
                                                          .otherwise(col("region_cached"))) \
                 .withColumn("intercom_country",when(col("intercom_country").isNotNull(), col("intercom_country"))
                                                              .otherwise(col("intercom_country_cached")))

# COMMAND ----------

#rec_dfv31.filter("SFDCState is NULL or SFDCCountry is NULL").count()

# COMMAND ----------

rec_dfv31.filter("intercom_country is NULL and SFDCCountry is NULL").count()

# COMMAND ----------

rec_dfv4 = rec_dfv31.withColumn("State",when(col("SFDCState").isNotNull(), col("SFDCState"))                                                                
                                                          .otherwise(col("region"))) \
                 .withColumn("Country",when(col("SFDCCountry").isNotNull(), col("SFDCCountry"))
                                                              .otherwise(col("intercom_country")))

# COMMAND ----------

rec_geo_df=rec_dfv4.select("email","State","Country","processedDate") \
                   .withColumn("processedDate", lit(str(datetime.date.today())))

# COMMAND ----------

rec_geo_df.count()

# COMMAND ----------

rec_geo_df.write.format("delta").mode("overwrite").partitionBy("processedDate").save("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/iss_recommendation_geo")

# COMMAND ----------

rec_dfv5 = rec_dfv4.filter("Country='United States' and Id is not NULL") #and State!='California'

# COMMAND ----------

#rec_dfv5.filter("isAdmin or isDe").count()

# COMMAND ----------

rec_dfv5.count()

# COMMAND ----------

#rec_dfv5.filter("isAdmin and inExpGroup").count()

# COMMAND ----------

#rec_dfv5.filter("isDE and inExpGroup").count()

# COMMAND ----------

#rec_dfv5.filter("isAutoLoader and inExpGroup").count()

# COMMAND ----------

rec_dfv5.createOrReplaceTempView("recommendation_filtered")

# COMMAND ----------

muj_config = config_json

# COMMAND ----------

muj_config

# COMMAND ----------

final_sql_str= "SELECT Id, \n"
milestone_str_list=[]
for i in muj_config:
  case_str = "CASE WHEN "
  #print(i['muj_name'])
  if i['enabled']:
    for milestone in i['milestones']:      
      flags = []
      flags.extend(i['flags'])
      if milestone['isFlag']:
        flags.extend(milestone['flags'])
      #print(i['flags'])
      #print(flags)
      milestone_str = case_str + ' AND '.join(flags) + ' THEN ' + i['recommendation_column'] + '.'
      milestone_str= milestone_str + milestone['milestone_name'] + " ELSE FALSE END AS " + milestone['milestone_sfdc_name']
      milestone_str_list.append(milestone_str)
      #print(milestone['milestone_sfdc_name'])
final_sql_str = final_sql_str + ",\n".join(milestone_str_list) + "\nFROM recommendation_filtered"
print(final_sql_str)

# COMMAND ----------

final_sql_df= spark.sql(final_sql_str)

# COMMAND ----------

final_sql_df.count()

# COMMAND ----------

display(final_sql_df)

# COMMAND ----------

final_sql_df.createOrReplaceTempView("final_recomenndation")

# COMMAND ----------

milestone_str_list = []
final_sql_str = "SELECT \n"
for i in config_json:
  case_str= "SUM(CASE WHEN "
  if i['enabled']:
    for milestone in i['milestones']:
      milestone_str=case_str + milestone['milestone_sfdc_name'] + " = 'true' THEN 1 ELSE 0 END) AS " + milestone['milestone_sfdc_name'] + "_TrueCount,\n"
      milestone_str=milestone_str + case_str + milestone['milestone_sfdc_name'] + " = 'false' THEN 1 ELSE 0 END) AS " + milestone['milestone_sfdc_name'] + "_FalseCount"
      milestone_str_list.append(milestone_str)
final_sql_str = final_sql_str + ",\n".join(milestone_str_list) + " FROM final_recomenndation"
print(final_sql_str)

# COMMAND ----------

stat_df= spark.sql(final_sql_str)
pan_df=stat_df.toPandas()
display(pan_df)

# COMMAND ----------

pan_df.T

# COMMAND ----------

con = final_sql_df.toPandas()

# COMMAND ----------

con = con.reindex(sorted(con.columns), axis=1)
 
con_upsert_data = [val for val in con.T.to_dict().values()]

# COMMAND ----------

print(len(con_upsert_data))

# COMMAND ----------

# MAGIC %run /Users/prabhakar.guha@databricks.com/helper-functions/SalesforceFunctions

# COMMAND ----------

print(len(con_upsert_data))

# COMMAND ----------

creds = get_creds('lfsf')
sf = get_sfdc_connection(creds, 'databricks.my')

# COMMAND ----------

result=sf.bulk.Contact.upsert(data=con_upsert_data, external_id_field='Id', batch_size=3000)

# COMMAND ----------

success=0
fail=0
error_list=[]
for i in result:
  if i['success'] == False:
    fail+=1
    if i['errors'] not in error_list:
      error_list.append(i['errors'])
  else:
    success+=1

# COMMAND ----------

error_list

# COMMAND ----------

success

# COMMAND ----------

fail

# COMMAND ----------

# id_list=[]
# for i in result:
#   if i['success'] == True:
#     id_list.append(i['id'])
    

# COMMAND ----------

#id_list

# COMMAND ----------

#display(final_sql_df.filter("Id in {}".format(str(tuple(id_list)))))

# COMMAND ----------


