# Databricks notebook source
# MAGIC %run ../gtm-growth/SalesforceFunctions

# COMMAND ----------

dbutils.widgets.removeAll()

# COMMAND ----------

from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# COMMAND ----------

dbutils.widgets.text("environment", 'development')
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

yesterday = str(datetime.today().date())

# COMMAND ----------

yesterday

# COMMAND ----------

dbutils.widgets.text("processDate", yesterday)
processDate = dbutils.widgets.get("processDate")
print(processDate)

# COMMAND ----------

rec_df = spark.sql("select sfdc_account_id,recommendation_id,case_subject,case_description,case_category, case_instructions, taskray_recommendation, case_priority  from recommendation_engine_dev.recommendations_to_deliver_salesforce_cse where processed_date = '{}'".format(processDate))

# COMMAND ----------

display(rec_df)

# COMMAND ----------

column_map = {
"sfdc_account_id" : "AccountId",
"recommendation_id" : "RecommendationId__c",
"case_subject" : "Subject",
"case_description" : "Description",
"case_category" : "Category__c",
"case_instructions" : "Instructions__c",
"taskray_recommendation" : "TaskRay_Playbook_Recommendation__c",
"case_priority" : "Priority"
  }

# COMMAND ----------

con = rec_df.toPandas()
con = con.replace({np.nan: None})

# COMMAND ----------

con = con[sorted(column_map.keys())]
con = con.rename(columns = column_map)
con = con.reindex(sorted(con.columns), axis=1)
con['RecordTypeId'] = "0128Y000001lHMNQA2"
#con['Priority'] = 'Normal'



# COMMAND ----------

records = [val for val in con.T.to_dict().values()]

# COMMAND ----------

print("Total records to be processed: {}".format(len(records)))

# COMMAND ----------

for i in records:
  i["attributes"] = {"type" : "Case", "referenceId" : i["RecommendationId__c"]}

# COMMAND ----------

if environment == "production":
  creds = get_creds('lfsf')
  sf = get_sfdc_connection(creds, 'databricks.my')
else:
  creds = get_creds('uat')
  sf = get_sfdc_connection(creds, 'test')



# COMMAND ----------

result = composite_api_create(records, sf, 10)

# COMMAND ----------

result

# COMMAND ----------

success=0
fail=0
error_list=[]
for i in result['Success']:
  if i['success'] == False:
    fail+=1
    if i['errors'] not in error_list:
      error_list.append(i['errors'])
  else:
    success+=1

# COMMAND ----------

fail

# COMMAND ----------

success

# COMMAND ----------


