# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ### Aim:
# MAGIC Get conversations data from intercom and store it in secured location

# COMMAND ----------

dbutils.widgets.dropdown("deployment_env", "Development", ["Development","Production"])

# COMMAND ----------

import requests
from requests.auth import HTTPBasicAuth
import datetime
import json
from pyspark.sql.functions import *

# COMMAND ----------

intercom_cred = dbutils.secrets.get('bse-dev-creds', 'bse-intercom-api')
intercom_id = intercom_cred.split(',')[0]
intercom_token = intercom_cred.split(',')[1]

# COMMAND ----------

deployment_env = dbutils.widgets.get("deployment_env")
if deployment_env == 'Production':
  stage_table = 'conversations_stage'
  shared_table = 'conversations_shared'
else:
  stage_table = 'conversations_stage_dev'
  shared_table = 'conversations_shared_dev'

# COMMAND ----------

print("The deployment environment is {} and the stage table name is {} and the shared table name is {}".format(deployment_env, stage_table, shared_table))

# COMMAND ----------

def delete_mounted_dir(dirname):
  files=dbutils.fs.ls(dirname)
  for f in files:
    if f.isDir():
      delete_mounted_dir(f.path)
    dbutils.fs.rm(f.path, recurse=True)

# COMMAND ----------

# DBTITLE 1,Get conversations from conversations Search API. Paginate the results.
def get_conv(start_date, end_date):
  query = {
      "query": {
          "operator": "AND",
          "value": [
            {
              "field": "created_at",
              "operator": ">",
              "value": start_date
            }, 
            {
              "field": "created_at",
              "operator": "<",
              "value": end_date
            },
            {
              "field": "tag_ids",
              "operator": "=",
              "value": "6277370"
            }
          ]
  }}
  r_conv = requests.post("https://api.intercom.io/conversations/search", auth = HTTPBasicAuth(intercom_token, intercom_id), json=query)
  print("Total conversations from conversations search API: {}".format(r_conv.json()['total_count']))

  conv_list=r_conv.json()['conversations']
  if r_conv.json()['pages']['total_pages'] > 1:
    query_page = {}
    query_page['query']=query['query']
    query_page['pagination']= {'starting_after': r_conv.json()['pages']['next']['starting_after']}
    start_after=r_conv.json()['pages']['next']['starting_after']
    for i in range(r_conv.json()['pages']['total_pages']-1):    
      r_conv_page = requests.post('https://api.intercom.io/conversations/search', auth = HTTPBasicAuth(intercom_token, intercom_id),json=query_page)
      conv_page_list = r_conv_page.json()['conversations']
      print("Processing conversations search API completed count: " + str(len(conv_page_list)))
      conv_list.extend(conv_page_list)
      if 'next' in r_conv_page.json()['pages']:      
        start_after=r_conv_page.json()['pages']['next']['starting_after']
        query_page['pagination']= {'starting_after': start_after}
  return conv_list

# COMMAND ----------

# DBTITLE 1,Get the conversation id list
def get_conv_id(conv_list):
  conv_id_list=[]
  for i in conv_list:
    conv_id_list.append(i['id'])
  conv_id_list=list(set(conv_id_list))
  return conv_id_list

# COMMAND ----------

# DBTITLE 1,Get individual conversations from conversation api.
def get_whole_conv(conv_id_list):
  conv_query_list=[]
  query = {
      "display_as" : "plaintext"
  }
  count=0
  start_time=datetime.datetime.now()
  #for j in range(10):
  for i in conv_id_list:
    rs_conv = requests.get("https://api.intercom.io/conversations/"+ i, auth = HTTPBasicAuth(intercom_token, intercom_id), json=query)
    conv_query_list.append(rs_conv.json())
    count+=1
    if start_time + datetime.timedelta(seconds=1) <= datetime.datetime.now():
      print("Processing indivdual conversations API completed count: " + str(count))
      start_time+=datetime.timedelta(seconds=10)

  conv_json_rdd = sc.parallelize(conv_query_list).map(lambda x: json.dumps(x))
  conv_query_df = spark.read.json(conv_json_rdd)
  conv_query_df = conv_query_df.selectExpr('*','contacts.contacts[0].id as con_id')
  return conv_query_df

# COMMAND ----------

# DBTITLE 1,Get contacts list from all the conversation.
def get_contact_list(conv_query_df):  
  contact_id_collect = conv_query_df.select('contacts').withColumn("contacts_exploded", explode("contacts.contacts")).select("contacts_exploded.id").collect()
  contact_id_list = set([x['id'] for x in contact_id_collect])
  return contact_id_list

# COMMAND ----------

# DBTITLE 1,Get user details from intercom API (email, country and region)
def get_contacts(contact_id_list):
  contact_query_list=[]
  query = {
      "display_as" : "plaintext"
  }
  count=0
  start_time=datetime.datetime.now()
  #for j in range(10):
  for i in contact_id_list:
    rs_contact = requests.get("https://api.intercom.io/contacts/" + i, auth = HTTPBasicAuth(intercom_token, intercom_id), json=query)
    rs_contact_json=rs_contact.json()
    rs_new_contact = {}
    rs_new_contact['contact_id'] = rs_contact_json['id']
    rs_new_contact['email'] = rs_contact_json['email']
    rs_new_contact['intercom_country'] = rs_contact_json['location']['country']
    rs_new_contact['intercom_region'] = rs_contact_json['location']['region']
    contact_query_list.append(rs_new_contact)
    count+=1
    if start_time + datetime.timedelta(seconds=1) <= datetime.datetime.now():
      print("Processing contacts API completion count: " + str(count))
      start_time+=datetime.timedelta(seconds=10)

  contact_json_rdd = sc.parallelize(contact_query_list).map(lambda x: json.dumps(x))
  contact_query_df = spark.read.json(contact_json_rdd)
  return contact_query_df

# COMMAND ----------

def get_contact_details(conv_query_df,contact_query_df):
  #Join intercom contact details with conversation df.
  conversations_df = conv_query_df.join(contact_query_df, conv_query_df.con_id == contact_query_df.contact_id, how = "left")

  #Get accounts data from SFDC for country and state filter
  account_df = spark.sql("""
  SELECT Id as AccId, 
        BillingState, 
        ShippingState,
        BillingCountry,
        ShippingCountry
        from (SELECT 
              Id, 
              BillingState, 
              ShippingState,
              BillingCountry,
              ShippingCountry,
              ROW_NUMBER() OVER (PARTITION BY Id 
                                 ORDER BY CreatedDate DESC) AS ROWNUM 
              FROM sfdc_ds.account 
              where ProcessDate=(SELECT 
                                 max(ProcessDate) 
                                 FROM sfdc_ds.account) 
              and Id is not NULL) 
              where ROWNUM=1""")

  #Get contacts data from SFDC for country and state filter
  contact_df = spark.sql("SELECT lower(Email) as email_c,Id,MailingState, MailingCountry, AccountId  from (SELECT lower(Email) as Email,Id,CreatedDate, MailingState, MailingCountry, AccountId, ROW_NUMBER() OVER (PARTITION BY Email ORDER BY CreatedDate DESC) AS ROWNUM FROM sfdc_ds.contact where ProcessDate=(SELECT max(ProcessDate) FROM sfdc_ds.contact) and email is not NULL) where ROWNUM=1")

  #Join accounts data and contacts data to get SFDC country and state for the users
  contact_join_df = contact_df.join(account_df, contact_df.AccountId == account_df.AccId, how="left") \
                            .withColumnRenamed('Id','SFDCId')

  #Join conversation data with SFDC data
  conversations_df_v1 = conversations_df.join(contact_join_df, conversations_df.email == contact_join_df.email_c, how="left").drop("email_c")
  return conversations_df_v1

# COMMAND ----------

def transform_conversations(conversations_df_v1):
  #Check for SFDC mailing address, if not check SFDC shipping address, if not check SFDC billing address, else intercom address
  conversations_df_v2 = conversations_df_v1.withColumn("region",when(col("MailingState").isNotNull(), col("MailingState"))
                                                                 .when(col("ShippingState").isNotNull(), col("ShippingState"))
                                                                 .when(col("BillingState").isNotNull(), col("BillingState"))                                                                 
                                                                 .otherwise(col("intercom_region"))) \
               .withColumn("country",when(col("MailingCountry").isNotNull(), col("MailingCountry"))
                                                                 .when(col("ShippingCountry").isNotNull(), col("ShippingCountry"))
                                                                 .when(col("BillingCountry").isNotNull(), col("BillingCountry"))                                                                 
                                                                 .otherwise(col("intercom_country")))
  #Filter Contacts of USA
  conversations_df_v3 = conversations_df_v2.filter((conversations_df_v2.country == 'United States')) \
                                         .filter((conversations_df_v2.country != '') & (conversations_df_v2.region!='')) \
                                         .filter((conversations_df_v2.country.isNotNull()) & (conversations_df_v2.region.isNotNull())) \
                                      .withColumn("email_id", lower("email")) \
                                      .drop("email")
  #& (conversations_df_v2.region!='California')) \
  
  #Get pseudo users data
  token = dbutils.secrets.get('store-ssa-token', 'ssa-token')
  sc._jsc.hadoopConfiguration().set("fs.azure.sas.databricks-prod-multi-geo-internal.dbmgintprodwestus.blob.core.windows.net", token)
  p_users = spark.read.format("delta").load("wasbs://databricks-prod-multi-geo-internal@dbmgintprodwestus.blob.core.windows.net/tables/pseudo_users")
  p_users.createOrReplaceTempView("pseudo_users")
  p_users_df = spark.sql("select max(canonicalUserId) as cuid, max(pseudoUserId) as puid, lower(email) as email  from pseudo_users group by lower(email) ")
  p_users_df = p_users_df.withColumnRenamed("canonicalUserId","cuid")
  
  #Join Pseudo users data with conversations api.
  conversations_df_v4 = conversations_df_v3.join(p_users_df, conversations_df_v3.email_id == p_users_df.email, how = "left")
  
  #Redact emails  and names from the conversation df.
  conversations_df_v5 = conversations_df_v4.select('id', explode('conversation_parts.conversation_parts').alias('conversation_parts_exploded')) \
                                           .withColumn("conversation_parts_exploded", col("conversation_parts_exploded").withField("author.email",lit("<redacted>"))) \
                                           .withColumn("conversation_parts_exploded", col("conversation_parts_exploded").withField("author.name",lit("<redacted>"))) \
                                           .groupBy("id").agg(collect_list('conversation_parts_exploded').alias("conversation_parts_exploded")) \
                                         .withColumnRenamed("id","conv_id")
  conversations_df_v6 = conversations_df_v4.withColumn("source", col("source").withField("author.email",lit("<redacted>"))) \
                                           .withColumn("source", col("source").withField("author.name",lit("<redacted>"))) \
                                           .join(conversations_df_v5, conversations_df_v4.id == conversations_df_v5.conv_id, how="left")
  
  conversations_df_v7=conversations_df_v6.withColumn("process_date",lit(str(datetime.date.today()))) \
                                       .withColumn("isId", when(((col("cuid").isNotNull()) | (col("puid").isNotNull())), True) \
                                                                .otherwise(False))
  
  conversations_df_v8=conversations_df_v7.select('admin_assignee_id','contacts','conversation_rating','created_at','first_contact_reply','id','open','priority','read','sla_applied','snoozed_until','source','state','statistics', 'tags', 'team_assignee_id', 'teammates', 'title', 'topics', 'type', 'updated_at', 'waiting_since', 'contact_id', 'country', 'region', 'cuid', 'puid',
                                                 'conversation_parts_exploded', 'process_date', "isId") \
                                         .withColumnRenamed("conversation_parts_exploded","conversation_parts")

  return conversations_df_v8

# COMMAND ----------

def get_stage_conversations(start_date,end_date):
    conv_list=get_conv(start_date, end_date)
    conv_id_list=get_conv_id(conv_list)
    conv_query_df = get_whole_conv(conv_id_list)
    contact_id_list=get_contact_list(conv_query_df)
    contact_query_df = get_contacts(contact_id_list)
    conversations_df_v1 = get_contact_details(conv_query_df,contact_query_df)
    conversations_df_v8 = transform_conversations(conversations_df_v1)
    print("Count of stage dataframe: " + str(conversations_df_v8.count()))
    return conversations_df_v8

# COMMAND ----------

# DBTITLE 1,Remove rows with no CUID and PUID
def filter_unknown_id(conversations_df_v8):
  conversations_df_v9 = conversations_df_v8.filter((col("cuid").isNotNull()) | (col("puid").isNotNull())) \
                                           .drop("isId")
  print("Count of shared/final dataframe: " + str(conversations_df_v9.count()))
  return conversations_df_v9

# COMMAND ----------

token = dbutils.secrets.get('bse-dev-creds', 'bse-data-shared')
sc._jsc.hadoopConfiguration().set("fs.azure.sas.bse-data-shared.dbbusinesssystems1.blob.core.windows.net/", token)

# COMMAND ----------

try:
  start_date=(datetime.datetime.today()-datetime.timedelta(7)).timestamp()
  end_date=(datetime.datetime.today()+datetime.timedelta(1)).timestamp()
  conversations_df_v8 = get_stage_conversations(start_date,end_date)
  conversations_df_v8.write.format("delta").mode("append").partitionBy("isId","process_date").save("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/" + stage_table)
except Exception as e:
  print("Exception writing staging data: " + str(e))
  print("Deleting old table...")
  delete_mounted_dir("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/" + stage_table)
  print("Getting data and transforming it..")
  start_date=datetime.datetime(2022,2,1).timestamp()
  end_date=(datetime.datetime.today()+datetime.timedelta(1)).timestamp()
  conversations_df_v8_full = get_stage_conversations(start_date,end_date)
  print("Writing new table")
  conversations_df_v8_full.write.format("delta").mode("append").partitionBy("isId","process_date").save("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/" + stage_table)

# COMMAND ----------

try:
  conversations_df_v9 = filter_unknown_id(conversations_df_v8)
  conversations_df_v9.createOrReplaceTempView("conversations_shared")
  result_df=spark.sql("""MERGE INTO delta.`wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/{}` as conv_shared
                        USING conversations_shared
                        ON conv_shared.id = conversations_shared.id
                        WHEN MATCHED THEN
                          UPDATE SET *
                        WHEN NOT MATCHED THEN
                        INSERT *""".format(shared_table))
except Exception as e:
  print("Error adding data to conversations_shared! Error: " + str(e))
  print("Deleting old table...")
  delete_mounted_dir("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/" + shared_table)
  conversations_df_v9_full = filter_unknown_id(conversations_df_v8_full)
  print("Writing new table")
  conversations_df_v9_full.write.format("delta").mode("append").partitionBy("process_date").save("wasbs://bse-data-shared@dbbusinesssystems1.blob.core.windows.net/tables/" + shared_table)
  

# COMMAND ----------


