-- Databricks notebook source
-- MAGIC %md
-- MAGIC ###Summary_table_royalty_recon

-- COMMAND ----------

select 
quarter,
format_number(unified_usage_cust_dollar,',###.####') as unified_usage_cust_dollar,
format_number(royalty_usage_cust_dollar,',###.####') as royalty_usage_cust_dollar,
format_number(royalty_usage_cust_dollar - unified_usage_cust_dollar ,',###.####') difference 
from(
select   
quarter,
sum(unified_usage_cust_dollar) unified_usage_cust_dollar,
sum(royalty_usage_cust_dollar) royalty_usage_cust_dollar
from main.it_cra_silver.cra_royalty_recon_usage_data agg 
where  Report_Snapshot_Date = (select max(Report_Snapshot_Date) from main.it_cra_silver.cra_royalty_recon_usage_data)
group by quarter
order by
  quarter desc)


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###Detail_table_royalty_recon

-- COMMAND ----------

select 
azure_subscription_id,
quarter,
difference_status,
format_number(unified_usage_cust_dollar,',###.####') unified_usage_cust_dollar,
format_number(royalty_usage_cust_dollar,',###.####') royalty_usage_cust_dollar,
format_number(difference,',###.####') difference 
from main.it_cra_silver.cra_royalty_recon_usage_data agg
where  
Report_Snapshot_Date = (select max(Report_Snapshot_Date) from main.it_cra_silver.cra_royalty_recon_usage_data)
and (agg.quarter = :p_quarter)
and (agg.difference_status = :p_difference_status or :p_difference_status ='All')
order by
  abs(agg.difference) desc


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###Summary_table_rated_usage_recon

-- COMMAND ----------

select   
   cast(month_end_date as date) month_end_date,
  format_number(cra_usage_cust_dollars, ',###.####') cra_usage_cust_dollars,
  format_number(finance_usage_cust_dollars, ',###.####') finance_usage_cust_dollars,
  format_number(finance_usage_cust_dollars - cra_usage_cust_dollars, ',###.####') difference 
from(
select
  month_end_date,
  sum(cra_usage_cust_dollars) cra_usage_cust_dollars,
  sum(finance_usage_cust_dollars) finance_usage_cust_dollars
from main.it_cra_silver.vw_rated_usage_recon_data agg
group by all)
order by month_end_date desc 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###Detail_table_rated_usage_recon

-- COMMAND ----------

select 
azure_subscription_id,
cast(month_end_date as date) month_end_date,
difference_status,
format_number(agg.cra_usage_cust_dollars,',###.####') cra_usage_cust_dollars,
format_number(agg.finance_usage_cust_dollars,',###.####') finance_usage_cust_dollars,
format_number(agg.difference,',###.####') difference
from main.it_cra_silver.vw_rated_usage_recon_data agg
where 
(date_format(agg.month_end_date,'y-MM') = date('${month_end_date}'))
and (agg.difference_status = :difference_status or :difference_status ='All')
order by
  abs(agg.difference) desc 



-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###CRA_Detail_table_rated_usage_recon

-- COMMAND ----------

with cte_latest_month_fin as  (
select max(last_day(add_months(date, -1))) as latest_month_billable
from main.it_cra_silver.finance_usage_snapshot_vw  
where platform = 'azure'

)

select 
        accountId sfdc_account_id,
        azureSubId,
        commit_sfdc_account_id,
        aggOrder,
        cast(posting_month_end_date as date) month_end_date,
        format_number(sum(usage_cust_dollars),',###.####') unified_usage_cust_dollars
from main.it_cra_silver.rr_true_up_snapshot_daily,cte_latest_month_fin
where usage_flag like 'snapshot_actual%'
and (date_format(posting_month_end_date,'y-MM') = date('${month_end_date}'))
and posting_month_end_date <= cte_latest_month_fin.latest_month_billable
 group by all
 order by azureSubId

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###royalty_recon_quarters

-- COMMAND ----------

select 
distinct quarter
from main.it_cra_silver.cra_royalty_recon_usage_data
where Report_Snapshot_Date = (select max(Report_Snapshot_Date) from main.it_cra_silver.cra_royalty_recon_usage_data)


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###rated_usage_month_ends

-- COMMAND ----------

select 
distinct cast(month_end_date as date) as month_end_date
from main.it_cra_silver.vw_rated_usage_recon_data


-- COMMAND ----------


