# Databricks notebook source
dbutils.widgets.removeAll()
dbutils.widgets.text('catalog_environment', 'prod')
catalog_environment = dbutils.widgets.get('catalog_environment')

# COMMAND ----------

# MAGIC %sql
# MAGIC show create table main.it_cra_silver.finance_usage_snapshot_vw

# COMMAND ----------

catalog = 'main' if catalog_environment == 'prod' else 'integration'
destination_schema = 'it_cra_silver'
finance_usage_snapshot_vw = 'main.it_cra_silver.finance_usage_snapshot_vw'
rr_true_up_snapshot_daily = f'{catalog}.it_cra_silver.rr_true_up_snapshot_daily'
universal_burndown_daily = f'{catalog}.it_cra_silver.universal_burndown_daily'
rated_usage_recon_data_table = f'{catalog}.it_cra_silver.tb_rated_usage_recon_data'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating a view in logfood

# COMMAND ----------

# Constructing the view name using Python string formatting


# Using the constructed view name in the SQL statement
sql_statement = f""" 
          CREATE OR REPLACE TEMP VIEW rated_usage_recon_data_view AS

-----------------To get the latest month--------------------------

with cte_latest_month_fin AS (
select max(last_day(add_months(date, -1))) as latest_month_billable
from main.it_cra_silver.finance_usage_snapshot_vw 
where platform = 'azure'),

-----------------Finance usage snapshot Report--------------------------

cte_finance_usage_report AS (
select 
        lower(azure_sub_id) azure_sub_id,
        last_day(date) month_end_date,
        sum(dbu_dollars)/0.85 as usage_cust_dollars
from {finance_usage_snapshot_vw}  
where last_day(date) = snapshot_month_end_date
and last_day(date) >= '2024-04-30'
and platform = 'azure'
group by all
order by month_end_date desc),

-----------------CRA Unified Report--------------------------

cte_cra_unified_report AS (
select 
        azureSubId,
        posting_month_end_date month_end_date,
        sum(usage_cust_dollars) as usage_cust_dollars
from {rr_true_up_snapshot_daily}
where usage_flag like 'snapshot_actual%'
 and posting_month_end_date >= '2024-04-30'
 group by all
 order by posting_month_end_date desc),

-----------------Joining unified and Finance usage--------------------------

cte_cra_finance_merged_report AS (
select
  ifnull(cra.azureSubId,fin.azure_sub_id) azure_subscription_id,
  ifnull(cra.month_end_date,fin.month_end_date) month_end_date,
  ifnull(cra.usage_cust_dollars,0) cra_usage_cust_dollars,
  ifnull(fin.usage_cust_dollars,0) finance_usage_cust_dollars
from cte_cra_unified_report cra
full outer join cte_finance_usage_report fin on cra.month_end_date = fin.month_end_date and lower(cra.azureSubId) = lower(fin.azure_sub_id))

-----------------Joining unified and Finance usage--------------------------
 
select
  azure_subscription_id,
  month_end_date,
  cra_usage_cust_dollars,
  finance_usage_cust_dollars,
  finance_usage_cust_dollars - cra_usage_cust_dollars as difference,
  CASE
    WHEN abs(
      finance_usage_cust_dollars - cra_usage_cust_dollars
    ) = 0 THEN 'No'
    WHEN abs(
      finance_usage_cust_dollars - cra_usage_cust_dollars
    ) > 0 THEN 'Yes'
  END AS difference_status
from
  cte_cra_finance_merged_report,
  cte_latest_month_fin
where
  month_end_date <= cte_latest_month_fin.latest_month_billable
"""

# Executing the SQL statement
spark.sql(sql_statement)

# COMMAND ----------

spark.sql(f""" 
create or replace temp view ub_snapshot_daily 
as
select 
        azure_sub_id,
        posting_month_end_date,
        sum(usage_cust_dollars) as ub_usage_cust_dollars
from {universal_burndown_daily}
where usage_flag like 'snapshot_actual%'
 and posting_month_end_date >= '2024-04-30'
 group by all

union all 

select coalesce(azure_sub_id, 'ledger-sub-id') azure_sub_id,
        posting_month_end_date,
        sum(usage_cust_dollars) as ub_usage_cust_dollars
from {universal_burndown_daily}     
where (posting_month_end_date = '2024-10-31' and metronome_ledger_reason_code = 'Azure Flex Usage for End of Oct 2024 | Flex Azure usage adjustment | 2024-10-31 | BAR-3305 | Pauline.fei')
group by all 
 """)

# COMMAND ----------

spark.sql(f""" 
create or replace temp view ub_rated_usage_recon
as        
select rv.* except(month_end_date),
       coalesce(rv.month_end_date, ub.posting_month_end_date) as month_end_date,
       ub.ub_usage_cust_dollars
from rated_usage_recon_data_view rv 
full outer join ub_snapshot_daily ub on rv.azure_subscription_id = ub.azure_sub_id and rv.month_end_date = ub.posting_month_end_date
""")

# COMMAND ----------

vw_ub_rated_usage_recon_df = spark.sql('select * from ub_rated_usage_recon')
vw_ub_rated_usage_recon_df.write\
                          .mode("overwrite")\
                          .option('overWriteSchema', 'true')\
.saveAsTable(f'{catalog}.it_cra_silver.tb_rated_usage_recon_data')
