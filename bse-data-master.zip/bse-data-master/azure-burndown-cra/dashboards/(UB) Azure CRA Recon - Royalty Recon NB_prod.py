# Databricks notebook source
dbutils.widgets.removeAll()
dbutils.widgets.text('catalog_environment', 'prod')
catalog_environment = dbutils.widgets.get('catalog_environment')

# COMMAND ----------

catalog = 'main' if catalog_environment == 'prod' else 'integration'
destination_schema = 'it_cra_silver'
ub_cra_royalty_recon_usage_data_table = 'cra_royalty_recon_usage_data_ub'

# COMMAND ----------

print(f'{catalog}.{destination_schema}.{cra_royalty_recon_usage_data_table}')

# COMMAND ----------

# MAGIC %md
# MAGIC ### To get the current quarter
# MAGIC

# COMMAND ----------

spark.sql(f""" 
CREATE OR REPLACE TEMP VIEW vw_latest_quarter_msft AS 
select calendar_quarter as latest_quarter_msft from (
select
  msft.month_end_date,
  bd.calendar_quarter,
  row_number() over (
    order by
      msft.month_end_date desc
  ) latest_month
from
  {catalog}.it_msft_silver.msft_royalty_qtrly_total_db msft
  left join main.it_core_dim.bi_dates bd on msft.month_end_date = bd.date)
  where latest_month = 1
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### CRA Unified Report

# COMMAND ----------

spark.sql(f""" 
CREATE OR REPLACE TEMP VIEW vw_cra_unified_report AS 
with cte_cra_snapshot as(
  select
    azureSubId AS azure_subscription_id,
    calendar_quarter AS quarter,
    sum(usage_cust_dollars) unified_usage_cust_dollars
  from
    {catalog}.it_cra_silver.rr_true_up_snapshot_daily cra
    left join main.it_core_dim.bi_dates bd on cra.posting_date = bd.date
  where
    usage_flag not like 'quarter-trueup%'
    and usage_flag not like '%adjustment%'
  group by
    all
),
cte_cra_trueup as(
  select
    quarter,
    azure_subscription_id,
    unified_usage_cust_dollars,
    prev_quarter_year || '-' || 'Q' || prev_quarter prev_quarter
  from(
      select
        calendar_quarter AS quarter,
        azureSubId AS azure_subscription_id,
        SUM(usage_cust_dollars) OVER (PARTITION BY bd.calendar_quarter,cra.azureSubId) AS unified_usage_cust_dollars,
        CASE
          WHEN bd.quarter = 1 THEN bd.year - 1
          ELSE bd.year
        END AS prev_quarter_year,
        CASE
          WHEN bd.quarter = 1 THEN 4
          ELSE bd.quarter - 1
        END AS prev_quarter
      from
       {catalog}.it_cra_silver.rr_true_up_snapshot_daily cra
        left join main.it_core_dim.bi_dates bd on cra.posting_date = bd.date
      where
        usage_flag like 'quarter-trueup%'
    )
  group by
    all
)

select 
  ifnull(cs.azure_subscription_id,ct.azure_subscription_id) azure_subscription_id,
  ifnull(cs.quarter,ct.prev_quarter) quarter,
  ifnull(cs.unified_usage_cust_dollars,0) as unified_usage_cust_dollars_ss,
  ifnull(ct.unified_usage_cust_dollars, 0) as unified_usage_cust_dollars_trueup,
  ifnull(ifnull(cs.unified_usage_cust_dollars,0) + ifnull(ct.unified_usage_cust_dollars, 0),0) as unified_usage_cust_dollar
from
  cte_cra_snapshot cs
  full outer join cte_cra_trueup ct on cs.quarter = ct.prev_quarter and cs.azure_subscription_id = ct.azure_subscription_id
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC with universal_burndown_daily as (
# MAGIC
# MAGIC select * except(platform),
# MAGIC               case when (platform is null and lower(metronome_ledger_reason_code) like '%azure%' and lower(metronome_ledger_reason_code) not like '%out%') then 'azure' else platform end as platform
# MAGIC from  main.it_cra_silver.universal_burndown_daily             
# MAGIC )
# MAGIC   select
# MAGIC     --azureSubId AS azure_subscription_id,
# MAGIC     calendar_quarter AS quarter,
# MAGIC     sum(usage_cust_dollars) unified_usage_cust_dollars
# MAGIC   from
# MAGIC      universal_burndown_daily ub
# MAGIC     left join main.it_core_dim.bi_dates bd on ub.posting_date = bd.date
# MAGIC   where
# MAGIC     usage_flag not like 'quarter-trueup%'
# MAGIC     and usage_flag not like '%adjustment%'
# MAGIC     and platform = 'azure'
# MAGIC   group by
# MAGIC     all
# MAGIC   order by 1

# COMMAND ----------

# MAGIC %md
# MAGIC ### Microsoft Royalty Report

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW vw_msft_royalty_report AS 
# MAGIC select
# MAGIC   SubscriptionGUID as azure_subscription_id,
# MAGIC   bd.calendar_quarter AS quarter,
# MAGIC   sum(msft.DataBricksRevShare) / 0.85 royalty_usage_cust_dollar -- Customer pays Microsoft ( post discount )
# MAGIC from
# MAGIC   main.it_msft_silver.msft_royalty_qtrly_total_db msft
# MAGIC   --left join main.it_core_dim.bi_dates bd on msft.month_end_date = bd.date
# MAGIC   left join main.it_core_dim.bi_dates bd on last_day(to_date(msft.BillingMonthKey, 'yyyyMMdd')) = bd.date
# MAGIC where processed_file not in ('aug_to_mar_adjustment file','Azure Royalty Revenue for Internal Usage - Jan-Sep 2023.csv','aug_sep_2023_ri_adjustment')
# MAGIC group by
# MAGIC   all

# COMMAND ----------

# MAGIC %md
# MAGIC ### Joining unified and microsoft

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view vw_cra_msft_merged_report as
# MAGIC select
# MAGIC   ifnull(cra.azure_subscription_id,msft.azure_subscription_id) azure_subscription_id,
# MAGIC   ifnull(cra.quarter,msft.quarter) quarter,
# MAGIC   ifnull(cra.unified_usage_cust_dollar,0) unified_usage_cust_dollar,
# MAGIC   ifnull(msft.royalty_usage_cust_dollar,0) royalty_usage_cust_dollar
# MAGIC from
# MAGIC   vw_cra_unified_report cra
# MAGIC   full outer join vw_msft_royalty_report msft on  cra.quarter  = msft.quarter and lower(cra.azure_subscription_id) = lower(msft.azure_subscription_id)
# MAGIC
# MAGIC   --cant have adjustements
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC ### Creating a table with Snapshot date in logfood

# COMMAND ----------

from datetime import date
today = date.today()
today_str = today.strftime('%Y-%m-%d')
print(today_str)

cra_recon_usage_daily_data_df = spark.sql(f"""select 
                                          azure_subscription_id,
                                          quarter,
                                          unified_usage_cust_dollar,
                                          royalty_usage_cust_dollar,
                                          royalty_usage_cust_dollar - unified_usage_cust_dollar as difference,
                                          CASE 
                                          WHEN abs(royalty_usage_cust_dollar - unified_usage_cust_dollar) = 0 THEN 'No'
                                          WHEN abs(royalty_usage_cust_dollar - unified_usage_cust_dollar) > 0 THEN 'Yes'
                                          END AS difference_status,
                                          cast('{today_str}' as date) as Report_Snapshot_Date
                                           from vw_cra_msft_merged_report ,vw_latest_quarter_msft
                                           where quarter <= vw_latest_quarter_msft.latest_quarter_msft
                                              """)
cra_recon_usage_daily_data_df.createOrReplaceTempView('cra_royalty_recon_usage_data')                       

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view universal_burndown_daily
# MAGIC as
# MAGIC with ub_main as (
# MAGIC   select
# MAGIC     coalesce(azure_sub_id,usage_flag)  AS azure_subscription_id,
# MAGIC     calendar_quarter AS quarter,
# MAGIC     sum(usage_cust_dollars) ub_usage_cust_dollars_main
# MAGIC   from
# MAGIC     main.it_cra_silver.universal_burndown_daily ub
# MAGIC     left join main.it_core_dim.bi_dates bd on ub.posting_date = bd.date
# MAGIC   where
# MAGIC     usage_flag not like 'quarter-trueup%'
# MAGIC     and usage_flag not like '%onetime%adjustment%'
# MAGIC     and platform = 'azure'
# MAGIC   group by
# MAGIC     all ),
# MAGIC
# MAGIC    ub_trueup as 
# MAGIC   (
# MAGIC   select
# MAGIC     quarter,
# MAGIC     azure_subscription_id,
# MAGIC     trueup_usage_cust_dollars,
# MAGIC     prev_quarter_year || '-' || 'Q' || prev_quarter prev_quarter
# MAGIC   from(
# MAGIC       select
# MAGIC         calendar_quarter AS quarter,
# MAGIC         coalesce(azure_sub_id,usage_flag) AS azure_subscription_id,
# MAGIC         SUM(usage_cust_dollars) OVER (PARTITION BY bd.calendar_quarter,ubtrue.azure_sub_id) AS trueup_usage_cust_dollars,
# MAGIC         CASE
# MAGIC           WHEN bd.quarter = 1 THEN bd.year - 1
# MAGIC           ELSE bd.year
# MAGIC         END AS prev_quarter_year,
# MAGIC         CASE
# MAGIC           WHEN bd.quarter = 1 THEN 4
# MAGIC           ELSE bd.quarter - 1
# MAGIC         END AS prev_quarter
# MAGIC       from
# MAGIC         integration.it_cra_silver.universal_burndown_daily ubtrue
# MAGIC         left join main.it_core_dim.bi_dates bd on ubtrue.posting_date = bd.date
# MAGIC       where
# MAGIC         usage_flag like 'quarter-trueup%'
# MAGIC         and platform = 'azure'
# MAGIC     )
# MAGIC   group by
# MAGIC     all 
# MAGIC   )
# MAGIC  select 
# MAGIC   ifnull(cs.azure_subscription_id,ct.azure_subscription_id) azure_subscription_id,
# MAGIC   ifnull(cs.quarter,ct.prev_quarter) quarter,
# MAGIC   ifnull(cs.ub_usage_cust_dollars_main,0) as ub_usage_cust_dollars_main,
# MAGIC   ifnull(ct.trueup_usage_cust_dollars, 0) as trueup_usage_cust_dollars,
# MAGIC   ifnull(ifnull(cs.ub_usage_cust_dollars_main,0) + ifnull(ct.trueup_usage_cust_dollars, 0),0) as ub_usage_cust_dollars
# MAGIC from
# MAGIC   ub_main cs
# MAGIC   full outer join ub_trueup ct on cs.quarter = ct.prev_quarter and cs.azure_subscription_id = ct.azure_subscription_id
# MAGIC    
# MAGIC
# MAGIC   

# COMMAND ----------

# MAGIC %md
# MAGIC #### ub manual ledger usage for 2024-Q3

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view ub_manual_ledger_usage as 
# MAGIC select 
# MAGIC     'ub manual ledger' as subscription, 
# MAGIC     case 
# MAGIC         when trim(SPLIT_PART(metronome_ledger_reason_code, '|', 1)) in (
# MAGIC             'Azure Flex TU/TD for End of Oct. 2024', 
# MAGIC             'Azure Flex TU for End of Oct-2024', 
# MAGIC             'Azure Flex TU correction -Oct-2024'
# MAGIC         ) 
# MAGIC         then '2024-Q3' 
# MAGIC         else bd.calendar_quarter 
# MAGIC     end as quarter, 
# MAGIC     0 as unified_usage_cust_dollar, 
# MAGIC     0 as royalty_usage_cust_dollar, 
# MAGIC     0 as difference, 
# MAGIC     null as difference_status, 
# MAGIC     current_date as report_snapshot_date, 
# MAGIC     sum(usage_cust_dollars) as usage_cust_dollars
# MAGIC from 
# MAGIC     main.it_cra_silver.universal_burndown_daily 
# MAGIC left join 
# MAGIC     main.it_core_dim.bi_dates bd 
# MAGIC on 
# MAGIC     posting_date = bd.date
# MAGIC where 
# MAGIC     usage_flag = 'METRONOME_MANUAL_LEDGER'
# MAGIC     and metronome_commit_name = 'Flexible Commit'
# MAGIC     and (
# MAGIC         trim(SPLIT_PART(metronome_ledger_reason_code, '|', 2)) = 'Flex Azure usage adjustment'
# MAGIC         or metronome_ledger_reason_code = 'Flex Azure usage adjustment|Azure Flex Usage for End of Aug 2024|2024-09-01'
# MAGIC     )
# MAGIC     and metronome_ledger_reason_code not like '%Azure Flex RR True-up for July 2024%' 
# MAGIC
# MAGIC     group by all

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view ub_manual_ledger_usage as 
# MAGIC select 
# MAGIC     'ub manual ledger' as subscription, 
# MAGIC     case 
# MAGIC         when trim(SPLIT_PART(metronome_ledger_reason_code, '|', 1)) in (
# MAGIC             'Azure Flex TU/TD for End of Oct. 2024', 
# MAGIC             'Azure Flex TU for End of Oct-2024', 
# MAGIC             'Azure Flex TU correction -Oct-2024'
# MAGIC         ) 
# MAGIC         then '2024-Q3' 
# MAGIC         else bd.calendar_quarter 
# MAGIC     end as quarter, 
# MAGIC     --metronome_ledger_reason_code,
# MAGIC     0 as unified_usage_cust_dollar, 
# MAGIC     0 as royalty_usage_cust_dollar, 
# MAGIC     0 as difference, 
# MAGIC     null as difference_status, 
# MAGIC     current_date as report_snapshot_date, 
# MAGIC     sum(usage_cust_dollars) as usage_cust_dollars
# MAGIC from 
# MAGIC     main.it_cra_silver.universal_burndown_daily 
# MAGIC left join 
# MAGIC     main.it_core_dim.bi_dates bd 
# MAGIC on 
# MAGIC     posting_date = bd.date
# MAGIC where 
# MAGIC     usage_flag = 'METRONOME_MANUAL_LEDGER'
# MAGIC     and metronome_commit_name = 'Flexible Commit'
# MAGIC     and (
# MAGIC         trim(SPLIT_PART(metronome_ledger_reason_code, '|', 2)) = 'Flex Azure usage adjustment'
# MAGIC         or metronome_ledger_reason_code = 'Flex Azure usage adjustment|Azure Flex Usage for End of Aug 2024|2024-09-01'
# MAGIC     )
# MAGIC     and metronome_ledger_reason_code not like '%Azure Flex RR True-up for July 2024%' 
# MAGIC
# MAGIC     group by all
# MAGIC
# MAGIC union all 
# MAGIC
# MAGIC select 
# MAGIC     'ub manual ledger' as subscription, 
# MAGIC     case 
# MAGIC         when trim(SPLIT_PART(metronome_ledger_reason_code, '|', 1)) in (
# MAGIC             'Azure Flex TU/TD for End of Oct. 2024', 
# MAGIC             'Azure Flex TU for End of Oct-2024', 
# MAGIC             'Azure Flex TU correction -Oct-2024'
# MAGIC         ) 
# MAGIC         then '2024-Q3' 
# MAGIC         else bd.calendar_quarter 
# MAGIC     end as quarter, 
# MAGIC     --metronome_ledger_reason_code,
# MAGIC     0 as unified_usage_cust_dollar, 
# MAGIC     0 as royalty_usage_cust_dollar, 
# MAGIC     0 as difference, 
# MAGIC     null as difference_status, 
# MAGIC     current_date as report_snapshot_date, 
# MAGIC     sum(usage_cust_dollars) as usage_cust_dollars
# MAGIC from 
# MAGIC     main.it_cra_silver.universal_burndown_daily 
# MAGIC left join 
# MAGIC     main.it_core_dim.bi_dates bd 
# MAGIC on 
# MAGIC     posting_date = bd.date
# MAGIC where 
# MAGIC     metronome_ledger_reason_code = 'Azure Flex Usage for End of Aug 2024-Rollover bucket | Usage adjustment | 8/30/24 | BAR-2709 | Pauline.fei' 
# MAGIC
# MAGIC     group by all;

# COMMAND ----------

# MAGIC %sql
# MAGIC create
# MAGIC or replace temp view ub_cra_royalty_recon_usage_data as
# MAGIC select
# MAGIC   coalesce(
# MAGIC     c.azure_subscription_id,
# MAGIC     ub.azure_subscription_id
# MAGIC   ) azure_subscription_id,
# MAGIC   coalesce(c.quarter, ub.quarter) quarter,
# MAGIC   unified_usage_cust_dollar,
# MAGIC   royalty_usage_cust_dollar,
# MAGIC   difference,
# MAGIC   difference_status,
# MAGIC   current_Date as Report_Snapshot_Date,
# MAGIC   coalesce(ub_usage_cust_dollars, 0) as ub_usage_cust_dollars
# MAGIC from
# MAGIC   cra_royalty_recon_usage_data c FULL
# MAGIC   outer join universal_burndown_daily ub on c.azure_subscription_id = ub.azure_subscription_id
# MAGIC   and c.quarter = ub.quarter
# MAGIC   and c.Report_Snapshot_Date = (
# MAGIC     select
# MAGIC       max(Report_Snapshot_Date)
# MAGIC     from
# MAGIC       main.it_cra_silver.cra_royalty_recon_usage_data
# MAGIC   )
# MAGIC UNION ALL
# MAGIC SELECT
# MAGIC   subscription,
# MAGIC   quarter,
# MAGIC   unified_usage_cust_dollar,
# MAGIC   royalty_usage_cust_dollar,
# MAGIC   difference,
# MAGIC   difference_status,
# MAGIC   current_date as report_snapshot_date,
# MAGIC   --'manual-ledger_flex' as trans_type,
# MAGIC   usage_cust_dollars
# MAGIC FROM
# MAGIC   ub_manual_ledger_usage

# COMMAND ----------

ub_cra_recon_usage_daily_data_df = spark.sql(f"""select * from ub_cra_royalty_recon_usage_data""")
ub_cra_recon_usage_daily_data_df.write.mode("overwrite")\
                                      .partitionBy("Report_Snapshot_Date", "quarter")\
                                      .option('mergeSchema', 'true')\
                                      .option('replaceWhere', f"Report_Snapshot_Date = '{today_str}'")\
                                      .saveAsTable(f"{catalog}.{destination_schema}.{ub_cra_royalty_recon_usage_data_table}") 
