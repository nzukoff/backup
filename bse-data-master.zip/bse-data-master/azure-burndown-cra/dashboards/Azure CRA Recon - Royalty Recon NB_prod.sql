-- Databricks notebook source
-- MAGIC %python
-- MAGIC dbutils.widgets.removeAll()
-- MAGIC dbutils.widgets.text('catalog_environment', 'prod')
-- MAGIC catalog_environment = dbutils.widgets.get('catalog_environment') 

-- COMMAND ----------

-- MAGIC %python
-- MAGIC catalog = 'main' if catalog_environment == 'prod' else 'integration'
-- MAGIC destination_schema = 'it_cra_silver'
-- MAGIC cra_royalty_recon_usage_data_table = 'cra_royalty_recon_usage_data'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### To get the current quarter
-- MAGIC

-- COMMAND ----------


CREATE OR REPLACE TEMP VIEW vw_latest_quarter_msft AS 
select calendar_quarter as latest_quarter_msft from (
select
  msft.month_end_date,
  bd.calendar_quarter,
  row_number() over (
    order by
      msft.month_end_date desc
  ) latest_month
from
  main.it_msft_silver.msft_royalty_qtrly_total_db msft
  left join main.it_core_dim.bi_dates bd on msft.month_end_date = bd.date)
  where latest_month = 1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### CRA Unified Report

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW vw_cra_unified_report AS 
with cte_cra_snapshot as(
  select
    azureSubId AS azure_subscription_id,
    calendar_quarter AS quarter,
    sum(usage_cust_dollars) unified_usage_cust_dollars
  from
    main.it_cra_silver.rr_true_up_snapshot_daily cra
    left join main.it_core_dim.bi_dates bd on cra.posting_date = bd.date
  where
    usage_flag not like 'quarter-trueup%'
    and usage_flag not like '%adjustment%'
  group by
    all
),
cte_cra_trueup as(
  select
    quarter,
    azure_subscription_id,
    unified_usage_cust_dollars,
    prev_quarter_year || '-' || 'Q' || prev_quarter prev_quarter
  from(
      select
        calendar_quarter AS quarter,
        azureSubId AS azure_subscription_id,
        SUM(usage_cust_dollars) OVER (PARTITION BY bd.calendar_quarter,cra.azureSubId) AS unified_usage_cust_dollars,
        CASE
          WHEN bd.quarter = 1 THEN bd.year - 1
          ELSE bd.year
        END AS prev_quarter_year,
        CASE
          WHEN bd.quarter = 1 THEN 4
          ELSE bd.quarter - 1
        END AS prev_quarter
      from
        main.it_cra_silver.rr_true_up_snapshot_daily cra
        left join main.it_core_dim.bi_dates bd on cra.posting_date = bd.date
      where
        usage_flag like 'quarter-trueup%'
    )
  group by
    all
)

select 
  ifnull(cs.azure_subscription_id,ct.azure_subscription_id) azure_subscription_id,
  ifnull(cs.quarter,ct.prev_quarter) quarter,
  ifnull(cs.unified_usage_cust_dollars,0) as unified_usage_cust_dollars_ss,
  ifnull(ct.unified_usage_cust_dollars, 0) as unified_usage_cust_dollars_trueup,
  ifnull(ifnull(cs.unified_usage_cust_dollars,0) + ifnull(ct.unified_usage_cust_dollars, 0),0) as unified_usage_cust_dollar
from
  cte_cra_snapshot cs
  full outer join cte_cra_trueup ct on cs.quarter = ct.prev_quarter and cs.azure_subscription_id = ct.azure_subscription_id


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Microsoft Royalty Report

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW vw_msft_royalty_report AS 
select
  SubscriptionGUID as azure_subscription_id,
  bd.calendar_quarter AS quarter,
  sum(msft.DataBricksRevShare) / 0.85 royalty_usage_cust_dollar -- Customer pays Microsoft ( post discount )
from
  main.it_msft_silver.msft_royalty_qtrly_total_db msft
  --left join main.it_core_dim.bi_dates bd on msft.month_end_date = bd.date
  left join main.it_core_dim.bi_dates bd on last_day(to_date(msft.BillingMonthKey, 'yyyyMMdd')) = bd.date
where processed_file not in ('aug_to_mar_adjustment file','Azure Royalty Revenue for Internal Usage - Jan-Sep 2023.csv','aug_sep_2023_ri_adjustment')
group by
  all

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Joining unified and microsoft

-- COMMAND ----------

create or replace temp view vw_cra_msft_merged_report as
select
  ifnull(cra.azure_subscription_id,msft.azure_subscription_id) azure_subscription_id,
  ifnull(cra.quarter,msft.quarter) quarter,
  ifnull(cra.unified_usage_cust_dollar,0) unified_usage_cust_dollar,
  ifnull(msft.royalty_usage_cust_dollar,0) royalty_usage_cust_dollar
from
  vw_cra_unified_report cra
  full outer join vw_msft_royalty_report msft on  cra.quarter  = msft.quarter and lower(cra.azure_subscription_id) = lower(msft.azure_subscription_id)

  --cant have adjustements



-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Creating a table with Snapshot date in logfood

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from datetime import date
-- MAGIC today = date.today()
-- MAGIC today_str = today.strftime('%Y-%m-%d')
-- MAGIC print(today_str)
-- MAGIC
-- MAGIC cra_recon_usage_daily_data_df = spark.sql(f"""select 
-- MAGIC                                           azure_subscription_id,
-- MAGIC                                           quarter,
-- MAGIC                                           unified_usage_cust_dollar,
-- MAGIC                                           royalty_usage_cust_dollar,
-- MAGIC                                           royalty_usage_cust_dollar - unified_usage_cust_dollar as difference,
-- MAGIC                                           CASE 
-- MAGIC                                           WHEN abs(royalty_usage_cust_dollar - unified_usage_cust_dollar) = 0 THEN 'No'
-- MAGIC                                           WHEN abs(royalty_usage_cust_dollar - unified_usage_cust_dollar) > 0 THEN 'Yes'
-- MAGIC                                           END AS difference_status,
-- MAGIC                                           cast('{today_str}' as date) as Report_Snapshot_Date
-- MAGIC                                            from vw_cra_msft_merged_report ,vw_latest_quarter_msft
-- MAGIC                                            where quarter <= vw_latest_quarter_msft.latest_quarter_msft
-- MAGIC                                               """)
-- MAGIC
-- MAGIC cra_recon_usage_daily_data_df.write.mode("overwrite")\
-- MAGIC                          .partitionBy("Report_Snapshot_Date", "quarter")\
-- MAGIC                          .option('mergeSchema', 'true')\
-- MAGIC                          .option('replaceWhere', f"Report_Snapshot_Date = '{today_str}'")\
-- MAGIC                          .saveAsTable(f"{catalog}.{destination_schema}.{cra_royalty_recon_usage_data_table}")                            
