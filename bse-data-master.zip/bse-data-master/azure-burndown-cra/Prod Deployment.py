# Databricks notebook source
def rename_table(table_name, renamed_table):
  """ 
    renames table_name to renamed_table
  """
  spark.sql(f""" 
              ALTER TABLE {table_name} RENAME TO {renamed_table}
            """)

def backup_table(table_name, backup_table_name):
    """
    Copies the hms_table to the uc_table
    :param hms_table:
    :param uc_table:
    :return:
    """
    df = spark.sql(f""" select * from {table_name} """)
    df.write\
      .option("overwriteSchema","true")\
      .format("delta")\
      .mode("overwrite")\
      .saveAsTable(backup_table_name)

def migrate_to_prod(dev_table, prod_table):
  print('dev: ', dev_table)
  print('prod: ', prod_table)
  # backup prod and dev
  backup_table(prod_table, prod_table + '_backup')
  print('backed up to: ', prod_table+'_backup')

  # rename prod
  rename_table(prod_table, prod_table+'_renamed')
  print('renamed to: ', prod_table+'_renamed')
  # #rename dev to prod
  rename_table(dev_table, prod_table)
  print('renamed dev to prod')

def deep_clone_between_schemas(dev_table, prod_table):
  print('dev: ', dev_table)
  print('prod: ', prod_table)
  # backup prod and dev


# COMMAND ----------

# MAGIC %md
# MAGIC #### mapping table

# COMMAND ----------

dev_mapping_table = 'main.it_consumption_silver.adhoc_cra_final_mapping_dev'
prod_mapping_table = 'main.it_consumption_silver.cra_final_mapping'

# COMMAND ----------

#backup_table(prod_mapping_table, prod_mapping_table + '_backup')

# COMMAND ----------

#rename_table(prod_mapping_table, prod_mapping_table+'_renamed')

# COMMAND ----------

# # back up and rename dev to prod
# backup_table(dev_mapping_table, dev_mapping_table + '_backup')
# rename_table(dev_mapping_table, prod_mapping_table)

# COMMAND ----------

# MAGIC %md
# MAGIC #### snapshot tables

# COMMAND ----------

dev_consumption_azure_daily_attribution_snapshot_enriched = 'main.it_consumption_silver.adhoc_consumption_azure_daily_attribution_snapshot_dev_4_enriched'
prod_consumption_azure_daily_attribution_snapshot_enriched = 'main.it_consumption_silver.consumption_azure_daily_attribution_snapshot_enriched'

dev_consumption_azure_daily_attribution_snapshot = 'main.it_consumption_silver.adhoc_consumption_azure_daily_attribution_snapshot_dev_4'

prod_consumption_azure_daily_attribution_snapshot = 'main.it_consumption_silver.consumption_azure_daily_attribution_snapshot'

# COMMAND ----------

# migrate_to_prod(dev_consumption_azure_daily_attribution_snapshot, prod_consumption_azure_daily_attribution_snapshot)

# COMMAND ----------

# rename_table(dev_consumption_azure_daily_attribution_snapshot_enriched, prod_consumption_azure_daily_attribution_snapshot_enriched)

# COMMAND ----------

# MAGIC %md
# MAGIC #### royalty migration

# COMMAND ----------

dev_royalty_report_daily_attribution_table_enriched ='main.it_consumption_silver.debug_adhoc_royalty_report_daily_attribution_dev_4_enriched'
prod_royalty_report_daily_attribution_table_enriched ='main.it_consumption_silver.royalty_report_daily_attribution_enriched'

dev_royalty_report_daily_attribution_table = 'main.it_consumption_silver.adhoc_royalty_report_daily_attribution_dev_4'

prod_royalty_report_daily_attribution_table = 'main.it_consumption_silver.royalty_report_daily_attribution'

# COMMAND ----------

# migrate_to_prod(dev_royalty_report_daily_attribution_table, prod_royalty_report_daily_attribution_table)

# COMMAND ----------

# rename_table(dev_royalty_report_daily_attribution_table_enriched, prod_royalty_report_daily_attribution_table_enriched)

# COMMAND ----------

# MAGIC %md
# MAGIC #### unified cra tables migration

# COMMAND ----------

dev_rr_true_up_snapshot_daily = 'main.it_consumption_silver.adhoc_rr_true_up_snapshot_daily_dev'

prod_rr_true_up_snapshot_daily = 'main.it_consumption_silver.rr_true_up_snapshot_daily'

# COMMAND ----------

#migrate_to_prod(dev_rr_true_up_snapshot_daily, prod_rr_true_up_snapshot_daily)

# COMMAND ----------

#snapshot true-up
dev_snapshot_true_up_staging_table = 'main.it_consumption_silver.adhoc_consumption_azure_true_up_snapshot_daily_staging'

prod_snapshot_true_up_staging_table = 'main.it_consumption_silver.consumption_azure_true_up_snapshot_daily_staging'

# COMMAND ----------

# migrate_to_prod(dev_snapshot_true_up_staging_table, prod_snapshot_true_up_staging_table)

# COMMAND ----------

# rr-true-up daily staging
dev_rr_true_up_snapshot_daily_table = 'main.it_consumption_silver.adhoc_rr_true_up_snapshot_daily_staging'

prod_rr_true_up_snapshot_daily_table = 'main.it_consumption_silver.rr_true_up_snapshot_daily_staging'

# COMMAND ----------

# migrate_to_prod(dev_rr_true_up_snapshot_daily_table, prod_rr_true_up_snapshot_daily_table)

# COMMAND ----------

# MAGIC %md
# MAGIC #### new schema changes

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from system.information_schema.tables
# MAGIC where 1=1
# MAGIC and table_catalog = 'main'
# MAGIC and table_schema = 'it_consumption_silver'
# MAGIC and table_owner = 'rk.aduri@databricks.com'
# MAGIC and table_name not like '%debug%'
# MAGIC and table_name not like '%adhoc%'
# MAGIC order by last_altered_by desc

# COMMAND ----------

table_names_rows = spark.sql(""" 
select table_name
from system.information_schema.tables
where 1=1
and table_catalog = 'main'
and table_schema = 'it_consumption_silver'
and table_owner = 'rk.aduri@databricks.com'
and table_name not like '%debug%'
and table_name not like '%adhoc%'
and table_name != 'revops_update_commits'
""").collect() 

table_names = [r.table_name for r in table_names_rows]
print(table_names)

# COMMAND ----------

def clone_same_table_to_new_schmema_main(table_name, from_schema, to_schema):
  from_table = f'main.{from_schema}.{table_name}' 
  to_table = f'main.{to_schema}.{table_name}' 
  spark.sql(f"""CREATE TABLE {to_table} CLONE {from_table}""")

def clone_same_table_to_new_schmema_integration(table_name, from_schema, to_schema):
  from_table = f'main.{from_schema}.{table_name}' 
  to_table = f'integration.{to_schema}.{table_name}' 
  spark.sql(f"""CREATE TABLE {to_table} CLONE {from_table}""")  

# COMMAND ----------

clone_same_table_to_new_schmema_main('revops_update_commits', 'it_consumption_silver', 'it_cra_fin_silver')

# COMMAND ----------

for table_name in table_names:
  print('cloning..', table_name)
  clone_same_table_to_new_schmema_integration(table_name, 'it_consumption_silver', 'it_cra_silver')

# COMMAND ----------


