# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from datetime import datetime

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("mapping_date", "")

mapping_date = getArgument("mapping_date")
if len(mapping_date) == 0:
  raise Exception('mapping date is empty')

# COMMAND ----------

# MAGIC %md
# MAGIC #### node definitions

# COMMAND ----------

class SubNode:
  """ 
  This class is used to store the subscription_guid and the account_list, common_account_list, siblings_list for a particular subscription_guid. """
  
  def __init__(self, subscription_guid):
    self.subscription_guid = subscription_guid
    self.account_list = []
    self.siblings_list = set()
    self.common_account_list = set()
  
  def get_account_list(self):
    return self.account_list
  
  def get_siblings_list(self):
    return set(self.siblings_list).difference(list(self.subscription_guid))
  
  def get_common_list(self):
    return set(self.common_account_list)

class AccountNode:
  """ 
  This class is used to store the commit_account_id and the sub_list for a particular commit_account_id.
  """
  
  def __init__(self, commit_account_id):
      self.commit_account_id = commit_account_id
      self.sub_list = []
    
  def get_sub_list(self):
      return self.sub_list

# COMMAND ----------

# MAGIC %md
# MAGIC #### base query

# COMMAND ----------

date_wise_mapping_rows = spark.sql(f""" 

  with 
  
  base_0_1 (
  
    select date,
           subscription_guid,
           case when len(revops_commit_account_id) > 0 then array(revops_commit_account_id) 
                else sfdc_account_commit_group 
           end as sfdc_account_commit_group
    from main.it_cra_silver.cra_final_mapping
    where date = '{mapping_date}'
  ),

  base_0 (

       select distinct m.*
       from base_0_1 m
       join main.it_cra_silver.cra_runtime_commit_account_group cra 
       on m.date = cra.date and m.subscription_guid = cra.subscription_guid
  ),
  
  base_1 (
  select distinct
         subscription_guid, 
         explode(sfdc_account_commit_group) commit_sfdc_account_id
  from base_0 
  )

  select commit_sfdc_account_id,
         collect_set(subscription_guid) subscription_guid_list
  from base_1
  group by all
""").collect()

date_wise_mapping_list = [r.asDict() for r in date_wise_mapping_rows]

# COMMAND ----------

# MAGIC %md
# MAGIC #### build { 'account-id':[ sub1, sub2,... ] }

# COMMAND ----------

#date_wise_mapping_list

date_wise_mapping_dict = {}

for r in date_wise_mapping_rows:
  date_wise_mapping_dict[r.commit_sfdc_account_id] = r.subscription_guid_list

#print(date_wise_mapping_dict)

# COMMAND ----------

# MAGIC %md
# MAGIC #### build graph

# COMMAND ----------

account_sub_graph = {}

def build_graph(date_wise_mapping_dict):

  # build all account/subscription nodes
  for commit_account_id, subscription_guids in date_wise_mapping_dict.items():

    #print('processing..', commit_account_id, subscription_guids)
    if commit_account_id not in account_sub_graph:
      account_sub_graph[commit_account_id] = AccountNode(commit_account_id)    

    for subscription_guid in subscription_guids:
      if subscription_guid not in account_sub_graph:
        account_sub_graph[subscription_guid] = SubNode(subscription_guid)
    
  # connect account to subscription nodes
  for commit_account_id, subscription_guids in date_wise_mapping_dict.items():
    
    account_node = account_sub_graph[commit_account_id]
    for subscription_guid in subscription_guids:
      #print('processing...', subscription_guid)
      sub_node = account_sub_graph[subscription_guid]
      account_node.sub_list.append(sub_node.subscription_guid)
      sub_node.account_list.append(account_node.commit_account_id)
      #print('account-list:', sub_node.get_account_list())
  
  #build siblings

  for commit_account_id, _ in date_wise_mapping_dict.items():
    
    subscription_guids = account_sub_graph[commit_account_id].get_sub_list()
    #print('processing..', subscription_guids)
    for subscription_guid in subscription_guids:
      #print('processing....', subscription_guid)
      sub_node = account_sub_graph[subscription_guid]
      existing_siblings = sub_node.siblings_list
      #print('existing_siblings-1:', existing_siblings)
      left = set(subscription_guids)
      right = set([subscription_guid])
      potential_set = left.difference(right)
      #print('potential_set', potential_set)
      sub_node.siblings_list = sub_node.siblings_list.union(potential_set)
      #print('existing_siblings after:', sub_node.siblings_list)
  
  #common list  
  for commit_account_id, _ in date_wise_mapping_dict.items():
    subscription_guids = account_sub_graph[commit_account_id].get_sub_list()
    for subscription_guid in subscription_guids:
      sub_node = account_sub_graph[subscription_guid]
      sub_node.common_account_list = sub_node.common_account_list.union(set(sub_node.account_list))

      for sibling in sub_node.siblings_list:
        sibling_node = account_sub_graph[sibling]
        sub_node.common_account_list = sub_node.common_account_list.union(sibling_node.common_account_list)
      

build_graph(date_wise_mapping_dict)

# COMMAND ----------

#common list - run-1  
for commit_account_id, _ in date_wise_mapping_dict.items():
    subscription_guids = account_sub_graph[commit_account_id].get_sub_list()
    for subscription_guid in subscription_guids:
      sub_node = account_sub_graph[subscription_guid]
      sub_node.common_account_list = sub_node.common_account_list.union(set(sub_node.account_list))

      for sibling in sub_node.siblings_list:
        sibling_node = account_sub_graph[sibling]
        sub_node.common_account_list = sub_node.common_account_list.union(sibling_node.common_account_list)

# COMMAND ----------

#common list - run-2
for commit_account_id, _ in date_wise_mapping_dict.items():
    subscription_guids = account_sub_graph[commit_account_id].get_sub_list()
    for subscription_guid in subscription_guids:
      sub_node = account_sub_graph[subscription_guid]
      sub_node.common_account_list = sub_node.common_account_list.union(set(sub_node.account_list))

      for sibling in sub_node.siblings_list:
        sibling_node = account_sub_graph[sibling]
        sub_node.common_account_list = sub_node.common_account_list.union(sibling_node.common_account_list)

# COMMAND ----------

# MAGIC %md
# MAGIC #### build common account list from the graph

# COMMAND ----------

subscription_guid_common_account_dict = {}

for _, subscription_guids in date_wise_mapping_dict.items():
  
  for subscription_guid in subscription_guids:
    
    if subscription_guid not in subscription_guid_common_account_dict:
      sub_node = account_sub_graph[subscription_guid]
      subscription_guid_common_account_dict[subscription_guid] = sub_node.common_account_list 

# COMMAND ----------

subscription_guid_common_account_str_dict = {}

for subscription_guid, common_account_list in subscription_guid_common_account_dict.items():
  subscription_guid_common_account_str_dict[subscription_guid] = '-'.join(sorted(list(common_account_list)))

# COMMAND ----------

# MAGIC %md
# MAGIC #### create subs_commit_account_group_id view

# COMMAND ----------

subscription_guid_common_account_str_dict_list = []
for k, v in subscription_guid_common_account_str_dict.items():
  subscription_guid_common_account_str_dict_list.append({'subscription_guid': k, 'common_account_id': v})

# COMMAND ----------

subscription_common_account_df = spark.createDataFrame(subscription_guid_common_account_str_dict_list)

subscription_common_account_df = subscription_common_account_df.withColumn('date', lit(mapping_date))

# COMMAND ----------

subscription_common_account_df.write\
                              .option("overwriteSchema", "true")\
                              .format("delta")\
                              .mode("overwrite")\
                              .option("replaceWhere",f"""date='{mapping_date}'""")\
                              .saveAsTable('main.it_cra_silver.date_subscription_commit_account_groups_v5')
