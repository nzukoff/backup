# Databricks notebook source
dbutils.widgets.removeAll()
dbutils.widgets.text("environment", "prod")

environment = dbutils.widgets.getArgument('environment')

# COMMAND ----------

@udf('string')
def commit_string(product_code, cpq_order_type):
  """ drops dollar from commit string  """
  commit_string = 'COMMIT'
  if cpq_order_type is None:
    cpq_order_type = ""
  if 'DOLLAR' in product_code and 'co-term' not in cpq_order_type.lower():
    commit_string = product_code.split('-')
    return '-'.join(commit_string[0:len(commit_string)-1])
  
  if 'DOLLAR' in product_code and 'co-term' in cpq_order_type.lower():
    commit_string = product_code.split('-')
    return '-'.join(commit_string[0:len(commit_string)-1]) + '-CO-TERM'
  
  if 'COMPLIMENTARY-USAGE-AWS' in product_code:
    return 'AWS-COMPLIMENTARY'
  
  if product_code.upper() == 'DEFERRED-TRUE-UP-COMMIT':
    if 'co-term' not in cpq_order_type.lower():
      return 'AZDTUFLEX-COMMIT' #DTU commit string is prefixed with AZ so that it is prioritized first in the burndown.
    else:
      return 'AZDTUFLEX-COMMIT' + '-CO-TERM'
  
  return commit_string

spark.udf.register("commit_string", commit_string)


@udf('string')
def split_commit_string(order):
  if order is None:
    return None
  else:
    split_string = order.split('-')
    return '-'.join(split_string[0:len(split_string)-1])

spark.udf.register("split_commit_string", split_commit_string)

# COMMAND ----------

# This view only exists on main catalog so we need to hardcode it here
cpq_aws_gcp_contracts_orders_vw = "main.it_cpq_silver.cpq_aws_gcp_contracts_orders_ub_vw"
bi_account_dim_table = "main.it_core_dim.bi_account_dim"

if environment == 'prod':
  catalog = 'main'
  is_debug = False
else:
  catalog = 'integration'
  is_debug = True

# The following tables exists in both catalogs so we can use the widget to set the table name
cra_orders_base = f"""{catalog}.it_cra_silver.cra_orders_base"""
cra_orders_base_manual = f"""{catalog}.it_cra_silver.cra_orders_base_manual"""

# COMMAND ----------

spark.sql(f""" 
-- new
--drop view if exists orders_base;
create or replace temp view orders_base_intermediate
as
with orders_base_intermediate_pre (
select --null usageBurstDate,
       concat(account_id, '-', commit_string(product_code, cpq_order_type), '-', generated_contract_number, '-', order_number, '-', order_item_start_date) aggorder_key,
       concat('UNIVERSAL-COMMIT-', generated_contract_number) UniversalOrder,
       concat(commit_string(product_code, cpq_order_type), '-', generated_contract_number, '-', order_number) AggOrder,
       concat(
       case
          when upper(product_code) = 'DEFERRED-TRUE-UP-COMMIT' then 'AZDTUFLEX-COMMIT'
          else 'FLEX-COMMIT'
       end
       ,'-', generated_contract_number, '-', order_number) flexOrder,
       concat(
       case 
          when lower(consumption_cloud)='flex' and upper(product_code) = 'DEFERRED-TRUE-UP-COMMIT' then 'AZDTUFlex' else consumption_cloud 
       end , '-COMPLIMENTARY-', generated_contract_number, '-', order_number) complimentary_order,
       --concat(consumption_cloud, '-COMMIT-CO-TERM-', generated_contract_number, '-', order_number) coterm_order,       
       concat(
       case 
          when lower(cpq_cloud)='flex' and upper(product_code) = 'DEFERRED-TRUE-UP-COMMIT' then 'AZDTUFlex' else cpq_cloud 
       end 
       , '-COMMIT-CO-TERM-', generated_contract_number, '-', order_number) coterm_order,       
       account_id sfdcAccountId,
       account_id commit_sfdc_account_id,
       acc.accountName sfdcAccountName,
       consumption_cloud Platform,
       contract_id,
       order_id,
       renewal_opportunity,
       order_item_start_date startDate,
       order_item_effective_end_date endDate,
       cast(contract_start_date__c as date)  contract_start_date,
       cast(contract_effective_end_date as date)  contract_effective_end_date,       
       committed_quantity cloudPartnerPurchase,
       committed_quantity ActualPartnerCommit,
       case when lower(consumption_cloud) = 'azure' then 0.85 * committed_quantity 
            else committed_quantity end as DBShareCommit,
       case when commit_string(product_code, cpq_order_type) like '%FLEX%' then committed_quantity else 0 end flexCommit,
       0 universalCommit,
       case when commit_string(product_code, cpq_order_type) = 'AWS-COMPLIMENTARY' then committed_quantity else 0 end complimentary_usage,
       case when commit_string(product_code, cpq_order_type) like '%COMMIT-CO-TERM' then committed_quantity else 0 end coterm_commit,
       case when order_item_start_date < cast(contract_start_date__c as date) then false
            else true end as is_valid
from {cpq_aws_gcp_contracts_orders_vw} c
join {bi_account_dim_table} acc on c.account_id = acc.accountId
where product_family = 'Workload Commitment'  
and lower(consumption_cloud) in ('azure', 'flex')
and  contract_start_date__c <=  contract_effective_end_date     
and committed_quantity > 1  
order by sfdcAccountId, startDate
)

select *
from orders_base_intermediate_pre
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from orders_base_intermediate 
# MAGIC where !is_valid

# COMMAND ----------

orders_base_manual = spark.sql(f'select * from {cra_orders_base_manual}') #manually added orders
orders_base = spark.sql(""" select * from orders_base_intermediate """).unionAll(orders_base_manual)

if not is_debug:
  orders_base.write.option("overwriteSchema", "true")\
            .format("delta")\
            .mode("overwrite")\
            .saveAsTable(cra_orders_base)   
