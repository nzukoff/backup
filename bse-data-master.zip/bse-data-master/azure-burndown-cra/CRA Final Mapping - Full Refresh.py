# Databricks notebook source
# MAGIC %md
# MAGIC #### notes
# MAGIC - refreshes cra-final-mapping table

# COMMAND ----------

from datetime import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC #### runtime - set up

# COMMAND ----------

@udf('string')
def commit_string(product_code, cpq_order_type):
  """ drops dollar from commit string  """
  commit_string = 'COMMIT'
  if cpq_order_type is None:
    cpq_order_type = ""
  if 'DOLLAR' in product_code and 'co-term' not in cpq_order_type.lower():
    commit_string = product_code.split('-')
    return '-'.join(commit_string[0:len(commit_string)-1])
  
  if 'DOLLAR' in product_code and 'co-term' in cpq_order_type.lower():
    commit_string = product_code.split('-')
    return '-'.join(commit_string[0:len(commit_string)-1]) + '-CO-TERM'
  
  if 'COMPLIMENTARY-USAGE-AWS' in product_code:
    return 'AWS-COMPLIMENTARY'
  
  if product_code.upper() == 'DEFERRED-TRUE-UP-COMMIT':
    return "AZDTUFLEX-COMMIT" #DTU commit string is prefixed with AZ so that it is prioritized first in the burndown.

  return commit_string

spark.udf.register("commit_string", commit_string)


@udf('string')
def split_commit_string(order):
  if order is None:
    return None
  else:
    split_string = order.split('-')
    return '-'.join(split_string[0:len(split_string)-1])

spark.udf.register("split_commit_string", split_commit_string)

@udf("double")
def distributeDailyRevShareDollars(revShareDollars, daysinmonth):
  """ returns daily share of a month """
  return revShareDollars/daysinmonth


@udf('string')
def generate_commit_account_group_id(sfdc_account_commit_group):
    """ returns a group-id """
    if sfdc_account_commit_group is not None:
      return '-'.join(sorted(sfdc_account_commit_group))
    return sfdc_account_commit_group
  
spark.udf.register("generate_commit_account_group_id", generate_commit_account_group_id)

# COMMAND ----------

dbutils.widgets.text("environment", "prod")
environment = dbutils.widgets.getArgument('environment')

catalog = 'main' if environment == 'prod' else 'integration'
data_schema = 'it_cra_silver'

# COMMAND ----------

#tables
main_sfdc_bronze_workspace_table = 'main.sfdc_bronze.workspace__c'
finance_dbu_dollars_table = 'main.it_lakehouse.azure_carveout'
msft_royalty_monthly = 'main.it_msft_silver.msft_royalty_monthly'
cpq_aws_gcp_contracts_orders_vw = 'main.it_cpq_silver.cpq_aws_gcp_contracts_orders_ub_vw'
bi_account_dim_table = 'main.it_core_dim.bi_account_dim'
billable_usage_table = 'main.eng_billable_usage.billable_usage'

# cra tables
account_subs_ranked_table = f'{catalog}.{data_schema}.account_subs_ranked'
cra_group_base_table = f'{catalog}.{data_schema}.cra_group_base'
unified_table = f'{catalog}.{data_schema}.rr_true_up_snapshot_daily'
cra_mapping_full_refresh_staging = f'{catalog}.{data_schema}.cra_mapping_full_refresh_staging'
cra_final_mapping_table = f'{catalog}.{data_schema}.cra_final_mapping'
cra_orders_base_table = f'{catalog}.{data_schema}.cra_orders_base'

#locations
account_subs_ranked_location = '/mnt/bse-dev/test/cra/account_subs_ranked'

# dates
mapping_run_date = datetime.now().strftime('%Y-%m-%d')
incremental_refresh_date_to_be_appended = datetime.now().strftime('%Y-%m-%d')


# COMMAND ----------

print(mapping_run_date, incremental_refresh_date_to_be_appended)

# COMMAND ----------

spark.sql(f""" 
create or replace temp view account_subs
as
with 

mapped_running_account_subs_bronze (
select distinct 
       processDate,
       account__c as sfdc_account_id,
       azureSubscriptionId__c as azure_subscription_id,
       creationTime__c as workspace_created_time,
       workspaceStatus__c
from {main_sfdc_bronze_workspace_table} 
where processDate = (select max(processDate) from {main_sfdc_bronze_workspace_table})
and workspaceStatus__c = 'RUNNING'
and account__c is not null
),

running_account_subs_bronze_1 (
select distinct 
       processDate,
       coalesce(account__c, 'unmapped account') as sfdc_account_id,
       azureSubscriptionId__c as azure_subscription_id,
       creationTime__c as workspace_created_time,
       workspaceStatus__c
from {main_sfdc_bronze_workspace_table} 
where processDate = (select max(processDate) from {main_sfdc_bronze_workspace_table})
and workspaceStatus__c = 'RUNNING'
--and account__c is not null
),

running_account_subs_bronze (

select b.processDate,
       b.sfdc_account_id,
       b.azure_subscription_id,
       b.workspace_created_time,
       b.workspaceStatus__c
from running_account_subs_bronze_1 b
left anti join mapped_running_account_subs_bronze m 
            on b.azure_subscription_id = m.azure_subscription_id

union 

select processDate,
       sfdc_account_id,
       azure_subscription_id,
       workspace_created_time,
       workspaceStatus__c
from mapped_running_account_subs_bronze
),

mapped_non_running_account_subs_bronze (
select distinct 
       processDate,
       coalesce(account__c, 'unmapped account') as sfdc_account_id,
       azureSubscriptionId__c as azure_subscription_id,
       creationTime__c as workspace_created_time,
       workspaceStatus__c
from {main_sfdc_bronze_workspace_table} b
left anti join running_account_subs_bronze r on b.azureSubscriptionId__c = r.azure_subscription_id
where b.processDate = (select max(processDate) from {main_sfdc_bronze_workspace_table})
and workspaceStatus__c != 'RUNNING'
and account__c is not null
),

non_running_account_subs_bronze_1 (
select distinct 
       processDate,
       coalesce(account__c, 'unmapped account') as sfdc_account_id,
       azureSubscriptionId__c as azure_subscription_id,
       creationTime__c as workspace_created_time,
       workspaceStatus__c
from {main_sfdc_bronze_workspace_table} b
left anti join running_account_subs_bronze r on b.azureSubscriptionId__c = r.azure_subscription_id
where b.processDate = (select max(processDate) from {main_sfdc_bronze_workspace_table})
and workspaceStatus__c != 'RUNNING'
),

non_running_account_subs_bronze (
select b.processDate,
       b.sfdc_account_id,
       b.azure_subscription_id,
       b.workspace_created_time,
       b.workspaceStatus__c
from non_running_account_subs_bronze_1 b
left anti join mapped_non_running_account_subs_bronze m 
            on b.azure_subscription_id = m.azure_subscription_id

union 

select processDate,
       sfdc_account_id,
       azure_subscription_id,
       workspace_created_time,
       workspaceStatus__c
from mapped_non_running_account_subs_bronze
),

account_subs_bronze (

select *
from running_account_subs_bronze

union 

select *
from non_running_account_subs_bronze

),

account_subs_ranked (

select processDate,
       sfdc_account_id,
       azure_subscription_id,
       workspaceStatus__c,
       row_number() over(partition by processDate, azure_subscription_id order by workspace_created_time desc) rno      
from account_subs_bronze 
)

select processDate, 
       sfdc_account_id,
       azure_subscription_id,
       workspaceStatus__c
from account_subs_ranked 
where rno = 1
""")

# COMMAND ----------

# bdw_dev.cra_account_subs_ranked
account_subs_df = spark.sql(""" select * from account_subs """)
account_subs_df.write\
               .option("overwriteSchema", "true")\
               .format("delta")\
               .mode("overwrite")\
               .saveAsTable(account_subs_ranked_table)
               #.save("/mnt/bse-dev/test/cra/account_subs_ranked")

# COMMAND ----------

spark.sql(f""" 
create or replace temp view contract_max_burn 
as
select contract_id, 
       max(burn_percentage) max_pct_burn
from {unified_table}
group by 1 
having max_pct_burn > 1 
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### all subscriptions reference

# COMMAND ----------

spark.sql(f""" 
create or replace temp view rr_subs
as
with royalty_mapping_base (
  select distinct
        rr.BillingMonthKey,
        rr.SubscriptionGUID,
        rr.TPID,
        rr.TPName,
        rr.EnrollmentNumber,
        rr.CustomerName customer_name
  from {msft_royalty_monthly} rr 
  order by rr.BillingMonthKey
),

royalty_mapping_base_ranked
(select SubscriptionGUID subscription_guid,
       tpid,
       tpname,
       enrollmentnumber,
       BillingMonthKey,
       row_number() over(partition by SubscriptionGUID order by BillingMonthKey desc) rno,
       customer_name,
       'royalty' source 
from royalty_mapping_base 
)

select * except(rno)
from royalty_mapping_base_ranked
where rno = 1
""")

# COMMAND ----------

spark.sql(f"""
create or replace temp view subs_with_usage_base
as
select distinct 
       lower(f.azure_sub_id) subscription_guid,
       f.tp_id tpid,
       f.tp_name tpname,
       f.enrollment_number enrollmentnumber,
       '' customer_name,
       'snapshot' source
from {finance_dbu_dollars_table} f
where f.platform = 'azure'
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view subs_with_usage
# MAGIC as
# MAGIC
# MAGIC with subs_with_usage_dups (
# MAGIC select s.subscription_guid,
# MAGIC        tpid,
# MAGIC        tpname,
# MAGIC        enrollmentnumber,
# MAGIC        customer_name,
# MAGIC        source,
# MAGIC        row_number() over(partition by s.subscription_guid order by tpid nulls last, enrollmentnumber nulls last) rno       
# MAGIC from subs_with_usage_base s 
# MAGIC join (
# MAGIC   select subscription_guid, count(*) as cnt
# MAGIC   from subs_with_usage_base
# MAGIC   group by subscription_guid
# MAGIC   having cnt > 1 
# MAGIC  ) d on s.subscription_guid = d.subscription_guid
# MAGIC order by s.subscription_guid
# MAGIC )
# MAGIC
# MAGIC select subscription_guid,
# MAGIC        tpid,
# MAGIC        tpname,
# MAGIC        enrollmentnumber,
# MAGIC        customer_name,
# MAGIC        source 
# MAGIC from subs_with_usage_dups 
# MAGIC where rno = 1
# MAGIC
# MAGIC union all 
# MAGIC
# MAGIC select subscription_guid,
# MAGIC        tpid,
# MAGIC        tpname,
# MAGIC        enrollmentnumber,
# MAGIC        customer_name,
# MAGIC        source 
# MAGIC from subs_with_usage_base b 
# MAGIC left anti join subs_with_usage_dups d on b.subscription_guid = d.subscription_guid
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view subscriptions_base
# MAGIC as
# MAGIC
# MAGIC select subscription_guid,
# MAGIC        tpid,
# MAGIC        tpname,
# MAGIC        enrollmentnumber,
# MAGIC        customer_name,
# MAGIC        source 
# MAGIC from rr_subs
# MAGIC
# MAGIC union  
# MAGIC
# MAGIC select u.subscription_guid,
# MAGIC        u.tpid,
# MAGIC        u.tpname,
# MAGIC        u.enrollmentnumber,
# MAGIC        u.customer_name,
# MAGIC        u.source 
# MAGIC from subs_with_usage u  
# MAGIC left anti join rr_subs r on u.subscription_guid = r.subscription_guid
# MAGIC -- left join msft.azure_subscriptions m on  u.subscription_guid = m.azureSubscriptionId
# MAGIC --where r.subscription_guid is null 

# COMMAND ----------

# MAGIC %sql
# MAGIC -- incremental subscription base
# MAGIC create or replace temp view incremental_subscriptions_base
# MAGIC as
# MAGIC -- select *
# MAGIC -- from subs_with_usage
# MAGIC
# MAGIC select *
# MAGIC from subscriptions_base 

# COMMAND ----------

# MAGIC %md
# MAGIC #### all account-subscriptions ranked
# MAGIC - add sfdc groups
# MAGIC - add sfdc commit groups

# COMMAND ----------

spark.sql(f""" 
-- new
create or replace temp view orders_base
as
select account_id,
       acc.accountName account_name,
       consumption_cloud,
       contract_id,
       order_id,
       order_item_start_date,
       order_item_effective_end_date,      
       committed_quantity cust_commit,
       case when lower(consumption_cloud) = 'azure' then 0.85 * committed_quantity 
            else committed_quantity end as revshare_commit,
       row_number() over(partition by account_id order by order_item_effective_end_date desc) contract_end_date_rno
from {cpq_aws_gcp_contracts_orders_vw} c
join {bi_account_dim_table} acc on c.account_id = acc.accountId
where product_family = 'Workload Commitment'   
and lower(consumption_cloud) in ('azure', 'flex')
--and current_date() between order_item_start_date and order_item_effective_end_date
and !(c.order_item_start_date < c.contract_start_date__c)
order by account_id, order_item_start_date
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### group all months

# COMMAND ----------

spark.sql(f""" 
create or replace temp view group_all_months 
as
with base (
select subscription_guid,
       tpid,
       tpname,
       enrollmentnumber,
       source,
       customer_name,
       coalesce(a.sfdc_account_id, 'unmapped account') sfdc_account_id
from incremental_subscriptions_base b
left join {account_subs_ranked_table} a on lower(b.subscription_guid) = lower(a.azure_subscription_id)
)

select concat(coalesce(lower(tpid), 'NA'),'-',coalesce(lower(enrollmentnumber), 'NA')) tpid_enr_key,
       b.*,
       case when o.contract_id is not null then true
            else false
       end as is_commit_account,
       acc.accountName account_name,
       o.contract_id,
       o.order_item_start_date,
       o.order_item_effective_end_date,
       o.cust_commit
from base b
--left join orders_base_latest o on b.sfdc_account_id = o.account_id
left join orders_base  o on b.sfdc_account_id = o.account_id
left join {bi_account_dim_table} acc on b.sfdc_account_id = acc.accountId
order by tpname
""")

# COMMAND ----------

# refresh cra_group_base
group_all_months = spark.sql(""" select * from group_all_months """)
group_all_months.write\
                .option("overwriteSchema", "true")\
                .format("delta")\
                .mode("overwrite")\
                .saveAsTable(cra_group_base_table)

# COMMAND ----------

# MAGIC %md
# MAGIC #### sfdc groups

# COMMAND ----------

spark.sql(f""" 
create or replace temp view sfdc_account_groups 
as 
select tpid_enr_key,
       collect_set(sfdc_account_id) sfdc_account_group
from {cra_group_base_table} 
where sfdc_account_id <> 'unmapped account'
group by tpid_enr_key
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### commit groups

# COMMAND ----------

spark.sql(f""" 
create or replace  temp view commit_group_base_data
as
with base (
select tpid_enr_key, 
       explode(sfdc_account_group) sfdc_account_group_member_id
from sfdc_account_groups g
)

select distinct
       b.tpid_enr_key,
       b.sfdc_account_group_member_id,
       case when o.contract_id is not null then true
            else false 
       end as is_commit
from base b
left join orders_base o on b.sfdc_account_group_member_id = o.account_id
--left join orders_base_latest o on b.sfdc_account_group_member_id = o.account_id
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view sfdc_account_commit_groups 
# MAGIC as 
# MAGIC select tpid_enr_key,
# MAGIC        collect_set(sfdc_account_group_member_id) sfdc_account_commit_group,
# MAGIC        count(distinct sfdc_account_group_member_id) commit_member_count
# MAGIC from commit_group_base_data
# MAGIC where is_commit
# MAGIC group by tpid_enr_key

# COMMAND ----------

# MAGIC %md
# MAGIC #### commit base set up

# COMMAND ----------

spark.sql(f""" 
create or replace temp view sfdc_commit_groups_silver 
as
with base (
select *,
       explode(sfdc_account_commit_group) sfdc_account_id_commit
from sfdc_account_commit_groups c 
),

contracts_burndown (

select o.*,
       c.max_pct_burn
from orders_base  o
left join contract_max_burn c on o.contract_id = c.contract_id

),

commit_group_base (
select  b.*,
        o.account_name sfdc_account_commit_name,
        o.contract_id,
        o.order_item_start_date,
        o.order_item_effective_end_date,
        o.cust_commit,
        o.max_pct_burn
from base b 
left join contracts_burndown o on b.sfdc_account_id_commit = o.account_id
)

select c.*,
       rank() over(partition by c.tpid_enr_key order by c.order_item_start_date) start_date_rno,
       rank() over(partition by c.tpid_enr_key order by c.max_pct_burn) pct_burn_rno
from commit_group_base c 
""")  

# COMMAND ----------

# MAGIC %sql
# MAGIC -- left join the commit group, because, a sfdc-account-group may not have commit
# MAGIC create or replace temp view sfdc_account_groups_combined
# MAGIC as
# MAGIC select distinct
# MAGIC        a.tpid_enr_key,
# MAGIC        a.sfdc_account_group,
# MAGIC        c.sfdc_account_commit_group,
# MAGIC        c.commit_member_count,
# MAGIC        c.sfdc_account_id_commit,
# MAGIC        c.sfdc_account_commit_name,
# MAGIC       --  c.contract_id,
# MAGIC       --  c.order_item_start_date,
# MAGIC       --  c.order_item_effective_end_date,
# MAGIC       --  c.cust_commit,
# MAGIC        c.start_date_rno, 
# MAGIC        c.pct_burn_rno       
# MAGIC from sfdc_account_groups a 
# MAGIC left join sfdc_commit_groups_silver c on a.tpid_enr_key = c.tpid_enr_key

# COMMAND ----------

# MAGIC %md
# MAGIC #### write full refresh

# COMMAND ----------

spark.sql(f""" 
create or replace temp view full_refresh_mapping_base
as
with final_base (
select distinct
       b.tpid_enr_key,
       b.subscription_guid,
       b.tpid tp_id,
       b.tpname tp_name,
       b.enrollmentnumber enrollment_number,
       b.sfdc_account_id,
       b.account_name,
       b.is_commit_account,
       b.customer_name,
       b.source,
       s.sfdc_account_group,
       s.sfdc_account_commit_group,
       s.sfdc_account_id_commit commit_sfdc_account_id, 
       s.sfdc_account_commit_name commit_account_name,
       -- s.contract_id commit_contract_id,
       -- s.order_item_start_date commit_order_item_start_date,
       -- s.order_item_effective_end_date commit_order_item_effective_end_date,
       -- s.cust_commit commit_cust_dollars,
       coalesce(s.commit_member_count, 0) commit_member_count,
       s.start_date_rno,
       s.pct_burn_rno,
       case when b.sfdc_account_id = s.sfdc_account_id_commit then true
            else false end as is_own_commit       
from {cra_group_base_table} b 
left join sfdc_account_groups_combined s on b.tpid_enr_key = s.tpid_enr_key
)

select *
from final_base
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view cra_full_refresh_commit 
# MAGIC as 
# MAGIC select *
# MAGIC from full_refresh_mapping_base 
# MAGIC where start_date_rno = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view fix_dup_sub_own_commits 
# MAGIC as
# MAGIC with dup_subs (
# MAGIC select subscription_guid,
# MAGIC        count(*) cnt
# MAGIC from cra_full_refresh_commit
# MAGIC group by 1 
# MAGIC having cnt > 1 
# MAGIC )
# MAGIC
# MAGIC select f.*,
# MAGIC        row_number() over(partition by f.subscription_guid order by is_commit_account desc) rno
# MAGIC from cra_full_refresh_commit f 
# MAGIC join dup_subs d on f.subscription_guid = d.subscription_guid
# MAGIC where f.is_own_commit;

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view fix_dup_sub_own_commits_distinct
# MAGIC as
# MAGIC select distinct 
# MAGIC        subscription_guid,
# MAGIC        tpid_enr_key,
# MAGIC        tp_id,
# MAGIC        tp_name,
# MAGIC        enrollment_number,
# MAGIC        sfdc_account_id,
# MAGIC        account_name,
# MAGIC        commit_sfdc_account_id,
# MAGIC        commit_account_name,
# MAGIC        sfdc_account_group,
# MAGIC        sfdc_account_commit_group,
# MAGIC        is_commit_account,
# MAGIC        customer_name,
# MAGIC        source
# MAGIC from fix_dup_sub_own_commits
# MAGIC where rno = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view cra_full_refresh_commit_valid
# MAGIC as
# MAGIC select  distinct
# MAGIC         subscription_guid,
# MAGIC         tpid_enr_key,
# MAGIC         tp_id,
# MAGIC         tp_name,
# MAGIC         enrollment_number,
# MAGIC         sfdc_account_id,
# MAGIC         account_name,
# MAGIC         commit_sfdc_account_id,
# MAGIC         commit_account_name,
# MAGIC         sfdc_account_group,
# MAGIC         sfdc_account_commit_group,
# MAGIC         is_commit_account,
# MAGIC         customer_name,
# MAGIC         source
# MAGIC from cra_full_refresh_commit c 
# MAGIC left anti join fix_dup_sub_own_commits_distinct d on c.subscription_guid = d.subscription_guid

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view cra_full_refresh_commit_clean
# MAGIC as
# MAGIC with base (
# MAGIC select *,
# MAGIC        case when tp_id = '1178588' and commit_sfdc_account_id <> '0016100001IwIDPAA3' then false  
# MAGIC             else true end as is_valid
# MAGIC from cra_full_refresh_commit_valid
# MAGIC )
# MAGIC
# MAGIC select * except(is_valid)
# MAGIC from base
# MAGIC where is_valid

# COMMAND ----------

# MAGIC %md
# MAGIC #### full refresh v2

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view cra_full_refresh_v2 
# MAGIC as 
# MAGIC
# MAGIC select  subscription_guid,
# MAGIC         tpid_enr_key,
# MAGIC         tp_id,
# MAGIC         tp_name,
# MAGIC         enrollment_number,
# MAGIC         sfdc_account_id,
# MAGIC         account_name,
# MAGIC         commit_sfdc_account_id,
# MAGIC         commit_account_name,
# MAGIC         sfdc_account_group,
# MAGIC         sfdc_account_commit_group,
# MAGIC         is_commit_account,
# MAGIC         customer_name,
# MAGIC         source
# MAGIC from fix_dup_sub_own_commits_distinct  
# MAGIC
# MAGIC union 
# MAGIC
# MAGIC select  subscription_guid,
# MAGIC         tpid_enr_key,
# MAGIC         tp_id,
# MAGIC         tp_name,
# MAGIC         enrollment_number,
# MAGIC         sfdc_account_id,
# MAGIC         account_name,
# MAGIC         commit_sfdc_account_id,
# MAGIC         commit_account_name,
# MAGIC         sfdc_account_group,
# MAGIC         sfdc_account_commit_group,
# MAGIC         is_commit_account,
# MAGIC         customer_name,
# MAGIC         source
# MAGIC from cra_full_refresh_commit_clean
# MAGIC
# MAGIC union
# MAGIC
# MAGIC select  subscription_guid,
# MAGIC         tpid_enr_key,
# MAGIC         tp_id,
# MAGIC         tp_name,
# MAGIC         enrollment_number,
# MAGIC         sfdc_account_id,
# MAGIC         account_name,
# MAGIC         commit_sfdc_account_id,
# MAGIC         commit_account_name,
# MAGIC         sfdc_account_group,
# MAGIC         sfdc_account_commit_group,
# MAGIC         is_commit_account,
# MAGIC         customer_name,
# MAGIC         source
# MAGIC from full_refresh_mapping_base 
# MAGIC where start_date_rno is null

# COMMAND ----------

# MAGIC %md
# MAGIC #### add active commit group

# COMMAND ----------

spark.sql(f""" 
create or replace temp view active_commit_groups 
as
with commit_accounts (
select distinct
       account_id as commit_sfdc_account_id,
       order_item_start_date as startDate,
       order_item_effective_end_date as endDate
from orders_base
),

mapping_base (
  select  
        subscription_guid,
        explode(sfdc_account_commit_group) mapping_commit_account_id
  from cra_full_refresh_v2
),

active_commit_base (
select distinct 
       m.subscription_guid,
       c.commit_sfdc_account_id active_commit_sfdc_account_id
from mapping_base m 
join commit_accounts c on m.mapping_commit_account_id = c.commit_sfdc_account_id
and '{mapping_run_date}' between c.startDate and c.endDate
)

select subscription_guid,
       collect_set(active_commit_sfdc_account_id) as active_commit_sfdc_account_group
from active_commit_base 
group by all 
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view cra_full_refresh_staging
# MAGIC as 
# MAGIC select distinct
# MAGIC        c.*,
# MAGIC        a.active_commit_sfdc_account_group,
# MAGIC        '' revops_commit_account_id,
# MAGIC        cast(current_date() as string) date       
# MAGIC from cra_full_refresh_v2 c
# MAGIC left join active_commit_groups a on c.subscription_guid = a.subscription_guid

# COMMAND ----------

# MAGIC %md
# MAGIC #### cursor

# COMMAND ----------

cra_full_refresh_staging = spark.sql(""" select *
                                    from cra_full_refresh_staging """)
cra_full_refresh_staging.write\
                        .option("overwriteSchema", "true")\
                        .format("delta")\
                        .mode("overwrite")\
                        .saveAsTable(cra_mapping_full_refresh_staging)

# COMMAND ----------

display(spark.sql(f""" 
select count(*)
from {cra_mapping_full_refresh_staging}
"""))

# COMMAND ----------

# fix any tpid-enr-key,date having more than one commit groups
spark.sql(f"""           
create or replace temp view fix_sfdc_commit_groups
as
with 
tpid_group_fix (
  select o.date,
         o.tpid_enr_key,
        --o.subscription_guid,
        o.sfdc_account_commit_group,
        count(sfdc_account_commit_group) total_cnt
        --  count(o.sfdc_account_commit_group) over(partition by o.tpid_enr_key, o.sfdc_account_commit_group) total_commit_group_count
  from  {cra_mapping_full_refresh_staging} o  
  join (      
    select date, 
          tpid_enr_key,
          count(distinct sfdc_account_commit_group) cnt
    from {cra_mapping_full_refresh_staging}
    where tpid_enr_key not like '%NA%'
    group by 1,2
    having cnt > 1 
    ) t on o.tpid_enr_key = t.tpid_enr_key and o.date = t.date

  group by 1,2,3
  order by 1,2,3
),

ranked_tpid_groups (
select date,
       tpid_enr_key,
       sfdc_account_commit_group,
       row_number() over(partition by date, tpid_enr_key order by total_cnt desc) rno
from tpid_group_fix t 
),

single_tpid_groups (
select date,
       tpid_enr_key,
       sfdc_account_commit_group
from ranked_tpid_groups
where rno = 1
),

potential_updates (
  select 
        o.date,
        o.subscription_guid,
        --o.sfdc_account_commit_group,
        r.tpid_enr_key,
        r.sfdc_account_commit_group,
        o.commit_sfdc_account_id,
        case when o.sfdc_account_commit_group <> r.sfdc_account_commit_group then true
              else false end as should_update
  from {cra_mapping_full_refresh_staging} o
  join single_tpid_groups r on o.tpid_enr_key = r.tpid_enr_key and o.date = r.date
  order by 2
)

select *
from potential_updates 
where should_update
""")

# COMMAND ----------

display(
  spark.sql(f""" 
  MERGE INTO {cra_mapping_full_refresh_staging} orig 
  USING fix_sfdc_commit_groups up 
  ON orig.subscription_guid = up.subscription_guid and orig.date = up.date
  WHEN MATCHED THEN
    UPDATE SET orig.sfdc_account_commit_group = up.sfdc_account_commit_group            
  """)
)

# COMMAND ----------

spark.sql(f""" 
create or replace temp view null_commit_groups
as
with 
fix_null_tpids (
select distinct 
       date,
       tpid_enr_key, 
       coalesce(sfdc_account_commit_group, array()) sfdc_account_commit_group,
       size(coalesce(sfdc_account_commit_group, array())) len_group,
       commit_sfdc_account_id
from {cra_mapping_full_refresh_staging}
),

more_than_one_keys (
select date,
       tpid_enr_key,
       count(*) cnt
from fix_null_tpids
group by 1,2
having cnt > 1 
),

pruned_null_keys (

select f.*
from fix_null_tpids f
join more_than_one_keys m on f.tpid_enr_key = m.tpid_enr_key
                         and f.date = m.date
),

zero_length_keys (
select date,
       tpid_enr_key
from pruned_null_keys
where len_group = 0
),

base (
  select p.*,
         row_number() over(partition by p.date, p.tpid_enr_key order by commit_sfdc_account_id) rno
  from pruned_null_keys p 
  join zero_length_keys z on p.tpid_enr_key = z.tpid_enr_key and p.date = z.date
  where p.len_group > 0 
)

select date,
       tpid_enr_key,
       sfdc_account_commit_group,
       commit_sfdc_account_id
from base
where rno = 1
""")

# COMMAND ----------

spark.sql(f""" 
create or replace temp view null_sub_updates
as
select o.subscription_guid,
       o.date,
       n.tpid_enr_key,
       n.sfdc_account_commit_group,
       n.commit_sfdc_account_id      
from {cra_mapping_full_refresh_staging} o
join null_commit_groups n on o.tpid_enr_key = n.tpid_enr_key and o.date = n.date
where o.sfdc_account_commit_group is null 
and o.commit_sfdc_account_id is null 
order by 2
""")

# COMMAND ----------

display(spark.sql(f""" 
MERGE INTO {cra_mapping_full_refresh_staging} orig 
USING null_sub_updates up 
ON orig.subscription_guid = up.subscription_guid and orig.date = up.date
WHEN MATCHED THEN
  UPDATE SET orig.sfdc_account_commit_group = up.sfdc_account_commit_group,
             orig.commit_sfdc_account_id = up.commit_sfdc_account_id
""")
)             

# COMMAND ----------

# MAGIC %md
# MAGIC #### handle NA / nan tpid-enr-keys

# COMMAND ----------

spark.sql(f""" 
create or replace temp view null_tpid_or_enr_subs 
as
with 
null_tpid_enr_subs (
select date, 
       subscription_guid,
       sfdc_account_id,
       account_name,
       is_commit_account,
       tpid_enr_key
from {cra_mapping_full_refresh_staging}
where tpid_enr_key like '%NA%'
or lower(tpid_enr_key) like '%nan%'
)

select case when sfdc_account_id = 'unmapped account' then null 
            else array(sfdc_account_id) 
       end as new_sfdc_account_group,
       case when sfdc_account_id = 'unmapped account' then null 
            else array(sfdc_account_id) 
       end as new_sfdc_account_commit_group,

       case when is_commit_account = False then null
            else array(sfdc_account_id) 
       end as new_active_commit_sfdc_account_group,
       
       case when sfdc_account_id = 'unmapped account' then null 
            when is_commit_account then sfdc_account_id
            else null 
       end as new_commit_sfdc_account_id, 
       case when sfdc_account_id = 'unmapped account' then null 
            when is_commit_account then account_name
            else null 
       end as new_commit_account_name,                 
       date,
       subscription_guid,
       tpid_enr_key
from null_tpid_enr_subs
""")

# COMMAND ----------

display(
spark.sql(f""" 
merge into {cra_mapping_full_refresh_staging} orig 
using null_tpid_or_enr_subs up on orig.subscription_guid = up.subscription_guid and orig.date = up.date and orig.tpid_enr_key = up.tpid_enr_key
when matched then 
     update set orig.sfdc_account_group = up.new_sfdc_account_group,
                orig.sfdc_account_commit_group = up.new_sfdc_account_commit_group,
                orig.active_commit_sfdc_account_group = up.new_active_commit_sfdc_account_group,
                orig.commit_sfdc_account_id = up.new_commit_sfdc_account_id,
                orig.commit_account_name = up.new_commit_account_name          
""")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### incrementals

# COMMAND ----------

# MAGIC %sql
# MAGIC select date, count(*)
# MAGIC from main.it_cra_silver.cra_final_mapping
# MAGIC group by all
# MAGIC order by date desc 

# COMMAND ----------

incremental_refresh = spark.sql(f""" 

                                  select  
                                          subscription_guid,
                                          tpid_enr_key,
                                          tp_id,
                                          tp_name,
                                          enrollment_number,
                                          sfdc_account_id,
                                          account_name,
                                          commit_sfdc_account_id,
                                          commit_account_name,
                                          sfdc_account_group,
                                          sfdc_account_commit_group,
                                          active_commit_sfdc_account_group,
                                          is_commit_account,
                                          revops_commit_account_id
                                      from {cra_final_mapping_table}
                                      where date = (select max(date) from {cra_final_mapping_table})                              
                                  """)

print(incremental_refresh.count())

# COMMAND ----------

incremental_refresh.createOrReplaceTempView('latest_mapping')

# COMMAND ----------

spark.sql(f""" 
create or replace temp view revops_updates
as
select l.subscription_guid,
       r.revops_commit_account_id
from {cra_mapping_full_refresh_staging} l
join latest_mapping r on l.subscription_guid = r.subscription_guid
where len(r.revops_commit_account_id) > 0
""")

# COMMAND ----------

display(
spark.sql(f""" 
merge into {cra_mapping_full_refresh_staging} orig 
using revops_updates up on orig.subscription_guid = up.subscription_guid 
when matched then 
     update set orig.revops_commit_account_id = up.revops_commit_account_id         
""")
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### [uc] write full refresh mapping table

# COMMAND ----------

def write_cra_mapping_final(incremental_refresh_date_to_be_appended,
                            cra_mapping_full_refresh_staging,
                            cra_final_mapping_table):
  
    incremental_refresh_final = spark.sql(f"""
                                    select  subscription_guid,
                                            tpid_enr_key,
                                            tp_id,
                                            tp_name,
                                            enrollment_number,
                                            source,
                                            customer_name,
                                            sfdc_account_id,
                                            account_name,
                                            commit_sfdc_account_id,
                                            commit_account_name,
                                            sfdc_account_group,
                                            sfdc_account_commit_group,
                                            active_commit_sfdc_account_group,
                                            is_commit_account,
                                            revops_commit_account_id,
                                            '{incremental_refresh_date_to_be_appended}' as date
                                    from {cra_mapping_full_refresh_staging}
    """)

    incremental_refresh_final.write\
                            .option("overwriteSchema", "true")\
                            .format("delta")\
                            .mode("overwrite")\
                            .option("replaceWhere",f"""date='{incremental_refresh_date_to_be_appended}'""")\
                            .saveAsTable(cra_final_mapping_table)

# COMMAND ----------

write_cra_mapping_final(incremental_refresh_date_to_be_appended,
                            cra_mapping_full_refresh_staging,
                            cra_final_mapping_table)

# COMMAND ----------

# MAGIC %md
# MAGIC #### backfill unmapped accounts

# COMMAND ----------

spark.sql(f""" 
create or replace temp view unmapped_accounts_update_base
as
with 
dates (
select date 
from main.it_core_dim.bi_dates
where date between '2024-01-01' and current_date()
--where month_end_date in ('2023-10-31', '2023-11-30')
),

usage_subs_t (
select 
       sfdc_account_id as usage_accountId, 
       lower(azure_sub_id) azureSubId,
       sfdc_account_name accountName,
       row_number() over(partition by azure_sub_id order by date desc) rno
from {finance_dbu_dollars_table}
where platform = 'azure'
and last_day(date) >= '2023-04-30' 
and sfdc_account_id is not null
),

commit_accounts (
select distinct sfdcAccountId account_id
from {cra_orders_base_table} 
),

usage_subs (
  select b.* except(rno),
         case when c.account_id is not null then true else false end is_commit_account
  from usage_subs_t b
  left join commit_accounts c on b.usage_accountId = c.account_id
  where rno = 1
),

usage_subs_dates (
select date usage_date, 
       accountName,
       usage_accountId,
       is_commit_account,
       azureSubId
from usage_subs u cross join dates d 
),

base (
  select u.usage_accountId, 
         u.accountName,
         u.is_commit_account,
         b.date,
         b.subscription_guid,
         b.tpid_enr_key,


       case when size(b.sfdc_account_commit_group) < 1 then array(usage_accountId) 
            else array_distinct(array_append(sfdc_account_commit_group, usage_accountId)) 
       end as new_sfdc_account_commit_group,
            
       case when size(b.active_commit_sfdc_account_group) < 1 then array(usage_accountId) 
            else array_distinct(array_append(active_commit_sfdc_account_group, usage_accountId)) 
        end as new_active_commit_sfdc_account_group,

       case when size(b.sfdc_account_group) < 1 then array(usage_accountId) 
            else array_distinct(array_append(sfdc_account_group, usage_accountId)) 
       end as new_sfdc_account_group,


         sfdc_account_group,
         sfdc_account_commit_group,
         active_commit_sfdc_account_group,
         case when commit_sfdc_account_id is null and u.is_commit_account then usage_accountId 
         else  commit_sfdc_account_id end as commit_sfdc_account_id,
         case when commit_sfdc_account_id is null and u.is_commit_account then accountName else  commit_account_name end as commit_account_name

  from {cra_final_mapping_table} b
  join usage_subs_dates u on b.subscription_guid = u.azureSubId and b.date = u.usage_date
  where b.date between '2024-01-01' and current_date()
  and sfdc_account_id like '%unmapped%'
  order by date 
)



select distinct
       usage_accountId,
       accountName,
       is_commit_account,
       date,
       subscription_guid,
       tpid_enr_key,

       case when is_commit_account then new_sfdc_account_commit_group
            else sfdc_account_commit_group
       end as sfdc_account_commit_group,

       case when is_commit_account then new_active_commit_sfdc_account_group
            else active_commit_sfdc_account_group
       end as active_commit_sfdc_account_group,

       new_sfdc_account_group as sfdc_account_group,
       commit_sfdc_account_id,
       commit_account_name
from base
""")

# COMMAND ----------

spark.sql(f""" 
create or replace temp view unmapped_accounts_dup_subs
as
with dups 
(
  select date, subscription_guid, count(*) cnt
  from unmapped_accounts_update_base
  group by all 
  having cnt > 1
)

select b.*
from {cra_final_mapping_table} b
join dups d on b.date = d.date and b.subscription_guid = d.subscription_guid
""")

# COMMAND ----------
unmapped_accounts_dup_subs_count = spark.table('unmapped_accounts_dup_subs').count()

if unmapped_accounts_dup_subs_count > 0:
  print(f"Unmapped accounts with duplicates found: {unmapped_accounts_dup_subs_count}")
  spark.sql(f""" 
    merge into {cra_final_mapping_table} orig 
    using unmapped_accounts_dup_subs d on orig.subscription_guid = d.subscription_guid and orig.date = d.date and orig.tpid_enr_key = 'NA-NA'
    when matched then
      delete
  """)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view unmapped_accounts_update
# MAGIC as
# MAGIC select *
# MAGIC from unmapped_accounts_update_base b 
# MAGIC left anti join unmapped_accounts_dup_subs d on b.subscription_guid = d.subscription_guid and b.date = d.date


# COMMAND ----------

display(spark.sql(f""" 
merge into {cra_final_mapping_table} orig
using unmapped_accounts_update up on orig.subscription_guid = up.subscription_guid and orig.date = up.date and orig.tpid_enr_key = up.tpid_enr_key
when matched then 
     update set orig.sfdc_account_id = up.usage_accountId,
                orig.account_name = up.accountName,
                orig.commit_sfdc_account_id = up.commit_sfdc_account_id,
                orig.commit_account_name = up.commit_account_name,
                orig.sfdc_account_group = up.sfdc_account_group,
                orig.sfdc_account_commit_group = up.sfdc_account_commit_group,
                orig.active_commit_sfdc_account_group = up.active_commit_sfdc_account_group,
                orig.is_commit_account = up.is_commit_account                  
"""))
