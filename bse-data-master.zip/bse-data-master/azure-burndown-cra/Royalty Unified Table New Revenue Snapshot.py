# Databricks notebook source
# MAGIC %run ./util-functions

# COMMAND ----------

dbutils.widgets.removeAll()

dbutils.widgets.text("catalog", "")
dbutils.widgets.text("data_schema", "")
dbutils.widgets.text("quarter_start_date", "")
dbutils.widgets.text("quarter_end_date", "")
dbutils.widgets.text("royalty_post_date", "")
dbutils.widgets.text("royalty_post_month_end_date", "")

catalog = dbutils.widgets.getArgument('catalog')
data_schema = dbutils.widgets.getArgument('data_schema')
quarter_start_date = dbutils.widgets.getArgument('quarter_start_date')
quarter_end_date = dbutils.widgets.getArgument('quarter_end_date')
royalty_post_date = dbutils.widgets.getArgument('royalty_post_date')
royalty_post_month_end_date = dbutils.widgets.getArgument('royalty_post_month_end_date')

if quarter_start_date == '' or quarter_end_date == '' or royalty_post_date == '' and royalty_post_month_end_date == '':
  raise Exception('no royalty dates are passed')

# COMMAND ----------

def iterate_through_runtime_for_voilations_dev(debug=False):
  spark.sql(f""" 
            create or replace temp view rr_true_up_snapshot_daily_staging_base 
            as
            select * except (posting_date),
                  posting_date as date,
                  (rolling_sum_dollars - cust_commit) overage,
                  case when (rolling_sum_dollars - cust_commit) > 0 then concat('MTMAzure', accountId)
                        else aggOrder end as aggOrder_refined,
                  count(aggOrder) over(partition by aggOrder order by posting_date, usage_cust_dollars) rolling_sum_seq_no
            from {rr_true_up_snapshot_daily_staging_runtime}
  """)
  
  spark.sql(""" 
            create or replace temp view fix_royalty_snapshot_union_month_check 
            as
            select *
            from rr_true_up_snapshot_daily_staging_base  
            where (rolling_sum_dollars - cust_commit)  > 0
            and cust_commit > 0
            
  """)
  fix_royalty_snapshot_rows = spark.sql(""" 
                                      select * 
                                      from fix_royalty_snapshot_union_month_check 
                                      """).collect()

  print(len(fix_royalty_snapshot_rows)
  )

  spark.sql(f""" 
            create or replace temp view next_available_orders_true_up
            as
            with base (
            select accountId,
                  aggOrder, 
                  azureSubId,
                  min(posting_date) min_usage_date,
                  max(posting_date) max_usage_date
            from {rr_true_up_snapshot_daily_staging_runtime}
            where aggOrder not like 'MTM%'
            group by all 
            order by 1,2
            ),

            base1 (
            select accountId,
                  aggOrder,
                  azureSubId,
                  min_usage_date,
                  max_usage_date,
                  lead(aggOrder) over(partition by azureSubId order by max_usage_date) aggOrder_next
            from base 
            ),

            base2 (
            select distinct 
                  accountId,
                  aggOrder,
                  azureSubId,
                  aggOrder_next,
                  max_usage_date
            from base1
            )

            select b.accountId,
                  b.azureSubId,
                  b.max_usage_date,
                  b.aggOrder,
                  coalesce(b.aggOrder_next, concat('MTMAzure', b.accountId)) aggOrder_next,
                  coalesce(o.ActualPartnerCommit,0) cust_commit,
                  coalesce(cast(o.startDate as string), '2001-01-01') startDate,
                  coalesce(cast(o.endDate as string), '2050-01-01') endDate 
            from base2 b 
            left join {orders_base_table} o on b.aggOrder_next = o.aggOrder
            """
  )

  next_available_order_rows = \
                spark.sql("""
                          select * 
                          from next_available_orders_true_up
                          """).collect()

  fixed_consumption_rows_month = \
  fix_consumption_rows_accurate_split(next_available_order_rows,
                                      fix_royalty_snapshot_rows, debug=debug)

  fixed_consumption_2 = spark.createDataFrame(fixed_consumption_rows_month)
  fixed_consumption_2.createOrReplaceTempView('fixed_consumption_month') 

  spark.sql(f""" 
    create or replace temp view royalty_snapshot_union_1_enriched_month_fix
    as
    with base_0 (
    select b.date,
          b.posting_month_end_date,
          b.accountId,
          --case when b.overage > 0 then b.aggOrder_refined 
          --      else b.aggOrder 
          --end as aggOrder,
          b.aggOrder,
          b.azureSubId,
          b.usage_flag,
          b.usage_cust_dollars,
          b.usage_quantity,
          b.cust_commit
          --case when b.overage > 0 then 0 
          --      else b.cust_commit 
          --end as cust_commit
    from rr_true_up_snapshot_daily_staging_base b 
    left anti join fix_royalty_snapshot_union_month_check f on b.date = f.date
                                                           and b.accountId = f.accountId
                                                           and b.azureSubId = f.azureSubId
                                                           and b.rolling_sum_seq_no = f.rolling_sum_seq_no
                                                           and b.usage_quantity = f.usage_quantity     

    union all 

    select date, 
          posting_month_end_date,
          accountId,
          aggOrder,
          azureSubId,
          usage_flag,
          usage_cust_dollars,
          usage_quantity,
          cust_commit
    from fixed_consumption_month
    ),

    base_1 (
    select *,
          sum(usage_cust_dollars) over(partition by aggOrder order by date, usage_cust_dollars) rolling_sum_dollars,
          sum(usage_quantity) over(partition by aggOrder order by date, usage_cust_dollars) rolling_sum_quantity,
          count(aggOrder) over(partition by aggOrder order by date, usage_cust_dollars) rolling_sum_seq_no     
    from base_0 
    )

    select 
          case when rolling_sum_dollars > cust_commit then concat('MTMAzure',accountId) 
                else aggOrder
          end as aggOrder_refined,
          *,
          case when rolling_sum_dollars > cust_commit then rolling_sum_dollars - cust_commit
                else 0
          end as overage  
    from base_1            
    order by date, usage_cust_dollars 
  """)


  month_snapshot = spark.sql(f""" 
                            select c.date as posting_date,
                                    c.* except(aggOrder_refined, date, rolling_sum_seq_no, overage),
                                    c.rolling_sum_dollars/c.cust_commit as burn_percentage,
                                    case when upper(c.aggOrder) like 'AZURE-COMMIT%' then '01t3f000000QCsTAAW'
                                        when upper(c.aggOrder) like 'FLEX%' then '01t3f000000QCsYAAW'
                                        when upper(c.aggOrder) like 'AZDTUFLEX%' then '01tVp000004lpKwIAI'
                                        else null end as product_code_id,                                  
                                    b.sfdcAccountId commit_sfdc_account_id,
                                    b.contract_id,
                                    b.order_id,
                                    b.startDate,
                                    b.endDate,
                                    case when usage_flag = 'royalty' then usage_cust_dollars
                                        else 0 
                                    end as royalty_cust_dollars
                            from royalty_snapshot_union_1_enriched_month_fix c      
                            left join {orders_base_table} b on lower(c.aggOrder) = lower(b.aggOrder)
  """)

  write_to_rr_true_up_true_up_snapshot_daily(month_snapshot, rr_true_up_snapshot_daily_staging_runtime)

def check_and_fix_burn_percentage_voilations_dev(debug=False):
  while True:
    voilation_count = spark.sql(f""" 
                                  select count(distinct aggOrder) as v_count
                                  from {rr_true_up_snapshot_daily_staging_runtime} 
                                  where burn_percentage > 1
                      """).collect()[0].v_count
    
    print('voilation_count: ', voilation_count)
    if voilation_count == 0:
      break 
    else:
      iterate_through_runtime_for_voilations(debug=debug)

# COMMAND ----------

# MAGIC %md
# MAGIC #### set up

# COMMAND ----------

def iterate_through_runtime_for_voilations(debug=False):
  spark.sql(f""" 
            create or replace temp view rr_true_up_snapshot_daily_staging_base 
            as
            select * except (posting_date),
                  posting_date as date,
                  (rolling_sum_dollars - cust_commit) overage,
                  case when (rolling_sum_dollars - cust_commit) > 0 then concat('MTMAzure', accountId)
                        else aggOrder end as aggOrder_refined,
                  count(aggOrder) over(partition by aggOrder order by posting_date, usage_cust_dollars) rolling_sum_seq_no
            from {rr_true_up_snapshot_daily_staging_runtime}
  """)

  spark.sql(f""" 
        create or replace temp view aggorders_over_100
        as
        with aggorders_over_100 (
        select aggOrder, 
              sum(usage_cust_dollars),
              max(cust_commit),
              case when sum(usage_cust_dollars) = max(cust_commit) then True 
                    else false end as is_100_percent,
              case when sum(usage_cust_dollars) > max(cust_commit) then True
                    else False end as is_more_than_100,
              abs(sum(usage_cust_dollars) - max(cust_commit)) as abs_diff
        from {rr_true_up_snapshot_daily_staging_runtime}
        where aggOrder not like 'MTM%'
        group by all  
        )
        select aggOrder, abs_diff 
        from aggorders_over_100
        where is_more_than_100 
        and abs_diff > 0.0000001           
            
  """)  

  spark.sql(f""" 
        create or replace temp view aggorders_100_done
        as
        with aggorders_100_done_ (
        select aggOrder, 
              sum(usage_cust_dollars),
              max(cust_commit),
              case when sum(usage_cust_dollars) = max(cust_commit) then True 
                    else false end as is_100_percent,
              case when sum(usage_cust_dollars) > max(cust_commit) then True
                    else False end as is_more_than_100,
              abs(sum(usage_cust_dollars) - max(cust_commit)) as abs_diff
        from {rr_true_up_snapshot_daily_staging_runtime}
        where aggOrder not like 'MTM%'
        group by all  
        )
        select aggOrder, abs_diff 
        from aggorders_100_done_
        where (is_more_than_100 and abs_diff < 0.0000001) 
        or is_100_percent        
            
  """) 

  spark.sql(""" 
            create or replace temp view fix_royalty_snapshot_union_month_check 
            as
            select b.*
            from rr_true_up_snapshot_daily_staging_base b
            join aggorders_over_100 a on b.aggOrder = a.aggOrder
            where (rolling_sum_dollars - cust_commit)  > 0.0000001
            and cust_commit > 0
  """)

  fix_royalty_snapshot_rows = spark.sql(""" 
                                      select * 
                                      from fix_royalty_snapshot_union_month_check 
                                      """).collect()

  print(len(fix_royalty_snapshot_rows)
  )

  
  # next_available_orders_true_up
  spark.sql(f""" 
            create or replace temp view next_available_orders_true_up
            as
            with base (
            select accountId,
                  aggOrder, 
                  azureSubId,
                  min(posting_date) min_usage_date,
                  max(posting_date) max_usage_date
            from {rr_true_up_snapshot_daily_staging_runtime}
            where aggOrder not like 'MTM%' 
            group by all 
            order by 1,2
            ),

            base1 (
            select accountId,
                  aggOrder,
                  azureSubId,
                  min_usage_date,
                  max_usage_date,
                  lead(aggOrder) over(partition by azureSubId order by max_usage_date) aggOrder_next
            from base 
            ),

            base2 (
            select distinct 
                  accountId,
                  aggOrder,
                  azureSubId,
                  aggOrder_next
                  --max_usage_date
            from base1
            ),

            base3 (
            select b.accountId,
                  b.azureSubId,
                  --b.max_usage_date,
                  b.aggOrder,
                  b.aggOrder_next,
                  o.ActualPartnerCommit cust_commit,
                  cast(o.startDate as string) startDate,
                  cast(o.endDate as string) endDate
                  --coalesce(b.aggOrder_next, concat('MTMAzure', b.accountId)) aggOrder_next,
                  --coalesce(o.ActualPartnerCommit, 0) cust_commit,
                  --coalesce(cast(o.startDate as string), '2001-01-01') startDate,
                  --coalesce(cast(o.endDate as string), '2050-01-01') endDate
            from base2 b 
            left join {orders_base_table} o on b.aggOrder_next = o.aggOrder
            ),
            
            base4 (
            select 
                  b.accountId,
                  b.azureSubId,
                  b.aggOrder,
                  b.aggOrder_next aggOrder_next_orig,

                  case when b.aggOrder = b.aggOrder_next then n.aggOrder_next
                      else coalesce(b.aggOrder_next, n.aggOrder_next) 
                  end as aggOrder_next,

                  case when b.aggOrder = b.aggOrder_next then n.cust_commit
                      else coalesce(b.cust_commit, n.cust_commit) 
                  end as cust_commit,

                  case when b.aggOrder = b.aggOrder_next then n.startDate 
                      else coalesce(b.startDate, n.startDate) 
                  end as startDate,

                  case when b.aggOrder = b.aggOrder_next then n.endDate
                      else coalesce(b.endDate, n.endDate) 
                  end as endDate
            from base3 b
            left join {next_available_orders_base_table} n on b.aggOrder = n.aggOrder 
            ),

            base5 (
            select 
                  accountId,
                  azureSubId,
                  aggOrder,
                  aggOrder_next_orig,

                  case when aggOrder = aggOrder_next then concat('MTMAzure', accountId)
                      else aggOrder_next 
                  end as aggOrder_next,

                  case when aggOrder = aggOrder_next then 0.0
                      else cust_commit
                  end as cust_commit,

                  case when aggOrder = aggOrder_next then '2001-01-01' 
                      else startDate
                  end as startDate,

                  case when aggOrder = aggOrder_next then '2050-01-01' 
                      else endDate 
                  end as endDate
            from base4 
            )

            select b.*
            from base5 b
            left anti join aggorders_100_done d1 on b.aggOrder_next = d1.aggOrder
            left anti join aggorders_100_done d2 on b.aggOrder = d2.aggOrder
            left anti join aggorders_over_100 d3 on b.aggOrder_next = d3.aggOrder
  """)   

#   spark.sql(f""" 
#             create or replace temp view next_available_orders_true_up
#             as
#             with base (
#             select accountId,
#                   aggOrder, 
#                   azureSubId,
#                   min(posting_date) min_usage_date,
#                   max(posting_date) max_usage_date
#             from {rr_true_up_snapshot_daily_staging_runtime}
#             where aggOrder not like 'MTM%'
#             group by all 
#             order by 1,2
#             ),

#             base1 (
#             select accountId,
#                   aggOrder,
#                   azureSubId,
#                   min_usage_date,
#                   max_usage_date,
#                   lead(aggOrder) over(partition by azureSubId order by max_usage_date) aggOrder_next
#             from base 
#             ),

#             base2 (
#             select distinct 
#                   accountId,
#                   aggOrder,
#                   azureSubId,
#                   aggOrder_next,
#                   max_usage_date
#             from base1
#             ),

#             base3 (
#             select b.accountId,
#                   b.azureSubId,
#                   b.max_usage_date,
#                   b.aggOrder,
#                   b.aggOrder_next,
#                   o.ActualPartnerCommit cust_commit,
#                   cast(o.startDate as string) startDate,
#                   cast(o.endDate as string) endDate
#             from base2 b 
#             left join {orders_base_table} o on b.aggOrder_next = o.aggOrder
#             )

#             select 
#                   b.accountId,
#                   b.azureSubId,
#                   b.max_usage_date,
#                   b.aggOrder,
#                   b.aggOrder_next aggOrder_next_orig,
#                   coalesce(b.aggOrder_next, n.aggOrder_next) aggOrder_next,
#                   coalesce(b.cust_commit, n.cust_commit) cust_commit,
#                   coalesce(b.startDate, n.startDate) startDate,
#                   coalesce(b.endDate, n.endDate) endDate
#             from base3 b
#             left join {next_available_orders_base_table} n on b.aggOrder = n.aggOrder 
#             """
#   )

  next_available_order_rows = \
                spark.sql("""
                          select * 
                          from next_available_orders_true_up
                          """).collect()

  fixed_consumption_rows_month = \
  fix_consumption_rows_accurate_split(next_available_order_rows,
                                      fix_royalty_snapshot_rows, debug=debug)

  fixed_consumption_2 = spark.createDataFrame(fixed_consumption_rows_month)
  fixed_consumption_2.createOrReplaceTempView('fixed_consumption_month') 

  spark.sql(f""" 
    create or replace temp view royalty_snapshot_union_1_enriched_month_fix
    as
    with base_0 (
    select b.date,
          b.posting_month_end_date,
          b.accountId,
          --case when b.overage > 0 then b.aggOrder_refined 
          --      else b.aggOrder 
          --end as aggOrder,
          b.aggOrder,
          b.azureSubId,
          b.usage_flag,
          b.usage_cust_dollars,
          b.usage_quantity,
          b.cust_commit
          --case when b.overage > 0 then 0 
          --      else b.cust_commit 
          --end as cust_commit
    from rr_true_up_snapshot_daily_staging_base b 
    left anti join fix_royalty_snapshot_union_month_check f on b.date = f.date
                                                           and b.accountId = f.accountId
                                                           and b.azureSubId = f.azureSubId
                                                           and b.rolling_sum_seq_no = f.rolling_sum_seq_no
                                                           --and b.usage_quantity = f.usage_quantity     

    union all 

    select date, 
          posting_month_end_date,
          accountId,
          aggOrder,
          azureSubId,
          usage_flag,
          usage_cust_dollars,
          usage_quantity,
          cust_commit
    from fixed_consumption_month
    ),

    base_1 (
    select *,
          sum(usage_cust_dollars) over(partition by aggOrder order by date, usage_cust_dollars, usage_flag) rolling_sum_dollars,
          sum(usage_quantity) over(partition by aggOrder order by date, usage_cust_dollars, usage_flag) rolling_sum_quantity,
          count(aggOrder) over(partition by aggOrder order by date, usage_cust_dollars, usage_flag) rolling_sum_seq_no     
    from base_0 
    )

    select 
          case when rolling_sum_dollars > cust_commit then concat('MTMAzure',accountId) 
                else aggOrder
          end as aggOrder_refined,
          *,
          case when rolling_sum_dollars > cust_commit then rolling_sum_dollars - cust_commit
                else 0
          end as overage  
    from base_1            
    order by date, usage_cust_dollars 
  """)


  month_snapshot = spark.sql(f""" 
                            select c.date as posting_date,
                                    c.* except(aggOrder_refined, date, rolling_sum_seq_no, overage),
                                    c.rolling_sum_dollars/c.cust_commit as burn_percentage,
                                    case when upper(c.aggOrder) like 'AZURE-COMMIT%' then '01t3f000000QCsTAAW'
                                        when upper(c.aggOrder) like 'FLEX%' then '01t3f000000QCsYAAW'
                                        when upper(c.aggOrder) like 'AZDTUFLEX%' then '01tVp000004lpKwIAI'
                                        else null end as product_code_id,                                  
                                    b.sfdcAccountId commit_sfdc_account_id,
                                    b.contract_id,
                                    b.order_id,
                                    b.startDate,
                                    b.endDate,
                                    case when usage_flag = 'royalty' then usage_cust_dollars
                                        else 0 
                                    end as royalty_cust_dollars
                            from royalty_snapshot_union_1_enriched_month_fix c      
                            left join {orders_base_table} b on lower(c.aggOrder) = lower(b.aggOrder)
  """)
  month_snapshot.createOrReplaceTempView('month_snapshot_debug')
  if not debug:
      write_to_rr_true_up_true_up_snapshot_daily(month_snapshot, rr_true_up_snapshot_daily_staging_runtime)
  else:
      print('debug mode: skip writing')

# COMMAND ----------

def check_and_fix_burn_percentage_voilations(debug=False):
  max_number_runs = 3
  run_counter = 0
  while True and run_counter <= max_number_runs:
    voilation_count = spark.sql(f""" 
                                  select count(distinct aggOrder) as v_count
                                  from {rr_true_up_snapshot_daily_staging_runtime} 
                                  where burn_percentage > 1.0001
                      """).collect()[0].v_count
    
    print('voilation_count: ', voilation_count)
    if voilation_count <= 1:
      break 
    else:
      run_counter += 1
      print('run_counter: ', run_counter)
      iterate_through_runtime_for_voilations(debug=debug)

# COMMAND ----------

royalty_report_daily_attribution_table = f'{catalog}.{data_schema}.royalty_report_daily_attribution'

royalty_report_daily_attribution_table_enriched =f'{catalog}.{data_schema}.royalty_report_daily_attribution_enriched'

consumption_azure_daily_attribution_snapshot = f'{catalog}.{data_schema}.consumption_azure_daily_attribution_snapshot'

consumption_azure_daily_attribution_snapshot_enriched = f'{catalog}.{data_schema}.consumption_azure_daily_attribution_snapshot_enriched'

consumption_azure_true_up_snapshot_daily_staging = f'{catalog}.{data_schema}.consumption_azure_true_up_snapshot_daily_staging'

consumption_azure_true_up_snapshot_daily_staging_runtime = f'{catalog}.{data_schema}.runtime_consumption_azure_true_up_snapshot_daily_staging'

consumption_azure_true_up_snapshot_daily_staging = f'{catalog}.{data_schema}.consumption_azure_true_up_snapshot_daily_staging'

consumption_azure_true_up_snapshot_daily = f'{catalog}.{data_schema}.consumption_azure_true_up_snapshot_daily'

rr_true_up_snapshot_daily = f'{catalog}.{data_schema}.rr_true_up_snapshot_daily'

rr_true_up_snapshot_daily_staging = f'{catalog}.{data_schema}.rr_true_up_snapshot_daily_staging'

rr_true_up_snapshot_daily_staging_runtime = f'{catalog}.{data_schema}.runtime_rr_true_up_snapshot_daily_staging'

bi_dates_dim = 'main.it_core_dim.bi_dates'

orders_base_table = f'{catalog}.{data_schema}.cra_orders_base_ub_latest'
next_available_orders_base_table = f'{catalog}.{data_schema}.next_available_orders_base_ub_latest'

# COMMAND ----------

def daily_to_staging(runtime_table, staging_table):
    """
    Copies the hms_table to the uc_table
    :param runtime_table:
    :param staging_table:
    :return:
    """
    hms_df = spark.sql(f""" select * from {runtime_table} """)
    hms_df.write\
          .option("overwriteSchema","true")\
          .format("delta")\
          .mode("overwrite")\
          .saveAsTable(staging_table)

def copy_staging_to_intermediate(staging_table, intermediate_table):
    """
    Copies the hms_table to the uc_table
    :param staging_table:
    :param intermediate_table:
    :return:
    """
    hms_df = spark.sql(f""" select * from {staging_table} """)
    hms_df.write\
          .option("overwriteSchema","true")\
          .format("delta")\
          .mode("overwrite")\
          .saveAsTable(intermediate_table)

def copy_runtime_to_daily(runtime_table, daily_table):
    """
    Copies the hms_table to the uc_table
    :param runtime_table:
    :param daily_table:
    :return:
    """
    hms_df = spark.sql(f""" select * from {runtime_table} """)
    hms_df.write\
          .option("overwriteSchema","true")\
          .format("delta")\
          .mode("overwrite")\
          .saveAsTable(daily_table)

def copy_table1_to_table2(table1, table2):
    """
    Copies the hms_table to the uc_table
    :param runtime_table:
    :param daily_table:
    :return:
    """
    hms_df = spark.sql(f""" select * from {table1} """)
    hms_df.write\
          .option("overwriteSchema","true")\
          .format("delta")\
          .mode("overwrite")\
          .saveAsTable(table2)

# COMMAND ----------

# switch from daily to staging 

# COMMAND ----------

# daily_to_staging(consumption_azure_true_up_snapshot_daily_staging_runtime, 
#                  consumption_azure_true_up_snapshot_daily_staging)

# COMMAND ----------

# daily_to_staging(rr_true_up_snapshot_daily_staging_runtime, 
#                  rr_true_up_snapshot_daily_staging)

# COMMAND ----------

# MAGIC %md
# MAGIC #### copy staging

# COMMAND ----------

print(rr_true_up_snapshot_daily_staging)
print(rr_true_up_snapshot_daily_staging_runtime)
print("-------------------------------------------------------")
print(consumption_azure_true_up_snapshot_daily_staging_runtime)
print(consumption_azure_true_up_snapshot_daily_staging)

# COMMAND ----------

# MAGIC %sql
# MAGIC select max(posting_date) from main.it_cra_silver.rr_true_up_snapshot_daily_staging

# COMMAND ----------

copy_staging_to_intermediate(consumption_azure_true_up_snapshot_daily_staging, 
                             consumption_azure_true_up_snapshot_daily_staging_runtime)

copy_staging_to_intermediate(rr_true_up_snapshot_daily_staging, 
                             rr_true_up_snapshot_daily_staging_runtime)

# COMMAND ----------

# MAGIC %md
# MAGIC #### royalty true up

# COMMAND ----------

# MAGIC %md
# MAGIC #### (1) royalty-burn-down

# COMMAND ----------

import copy

# COMMAND ----------

def write_to_rr_true_up_true_up_snapshot_daily(month_snapshot, runtime_table):
  """
  writes df: runtime table : runtime_rr_true_up_snapshot_daily_staging
  """
  month_snapshot.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(runtime_table)

# COMMAND ----------

def fix_consumption_rows_accurate_split(next_available_order_rows,
                                        fix_royalty_snapshot_rows,
                                        debug=False):
    """
    next_available_order_rows: the available orders
    fix_royalty_snapshot_rows: the consumption rows that need to be fixed for accuracy
    """
    # build agg-order lookup for to-be-fixed rows
    aggorder_fix_royalty_snapshot_rows = {}
    for row in fix_royalty_snapshot_rows:
      r = row.asDict()
      if row.aggOrder in aggorder_fix_royalty_snapshot_rows:
        aggorder_fix_royalty_snapshot_rows[row.aggOrder].append(r)
      else:
        aggorder_fix_royalty_snapshot_rows[row.aggOrder] = [r]
    
    if debug:
      print('number of aggorders to be fixed: ', len(aggorder_fix_royalty_snapshot_rows.keys()))
      
    check_count = 0
    for k in aggorder_fix_royalty_snapshot_rows:
      check_count += len(aggorder_fix_royalty_snapshot_rows[k])
    print(check_count)  

    aggorder_lookup = {}
    for available_order in next_available_order_rows:
      available_ = available_order.asDict()
      key = available_['accountId'] + available_['azureSubId'] + available_['aggOrder']
      if key in aggorder_lookup:
        aggorder_lookup[key].append(available_)
      else:
        aggorder_lookup[key] = [available_]

    row_counter = 0
    fixed_consumption_rows = []

    for aggOrder_t in aggorder_fix_royalty_snapshot_rows.keys():

      fix_aggorder_consumption_t = aggorder_fix_royalty_snapshot_rows[aggOrder_t]

      if debug:
        print(aggOrder_t, row_counter, 'len: ', len(fix_aggorder_consumption_t))

      for idx, rec in enumerate(fix_aggorder_consumption_t):
        # find the valid order
        key = rec['accountId'] + rec['azureSubId'] + rec['aggOrder']
        available_orders = aggorder_lookup[key] if key in aggorder_lookup else []

        # if debug:
        #   print('available orders:', available_orders)

        valid_order = None 
        for order in available_orders:
          if order['startDate'] is None or \
             order['endDate'] is None:
               break
          if rec['date'] >= order['startDate'] and \
            rec['date'] <= order['endDate']:
              valid_order = order
              break   

        if idx == 0:
          ex = copy.deepcopy(rec)
          quantity_dollar_factor = 0 if ex['usage_cust_dollars'] == 0 else ex['usage_quantity'] / ex['usage_cust_dollars'] 
          ex['usage_cust_dollars'] = ex['usage_cust_dollars'] - ex['overage']
          ex['usage_quantity'] = quantity_dollar_factor * ex['usage_cust_dollars']
          ex['rolling_sum_dollars'] = ex['rolling_sum_dollars'] - ex['overage']
          ex['overage'] = 0.0
          fixed_consumption_rows.append(ex)

          new = copy.deepcopy(rec)
          new['aggOrder'] = valid_order['aggOrder_next'] if valid_order is not None else new['aggOrder_refined']
          new['cust_commit'] = valid_order['cust_commit'] if valid_order is not None else 0.0
          new['usage_cust_dollars'] = new['overage']
          new['usage_quantity'] = quantity_dollar_factor * new['overage']
          new['overage'] = 0.0
          new['rolling_sum_dollars'] = 0.0
          fixed_consumption_rows.append(new)
        else:
          new = copy.deepcopy(rec)
          new['aggOrder'] = valid_order['aggOrder_next'] if valid_order is not None else new['aggOrder_refined']
          new['cust_commit'] = valid_order['cust_commit'] if valid_order is not None else 0.0
          new['overage'] = 0.0
          new['rolling_sum_dollars'] = 0.0
          fixed_consumption_rows.append(new)
        
        row_counter += len(fix_aggorder_consumption_t)
        
        # if debug:
        #   print('processed..', len(fixed_consumption_rows))       


    if debug:
      print('returning.. ', len(fixed_consumption_rows))

    return fixed_consumption_rows

# COMMAND ----------

spark.sql(f""" 
-- (1) royalty
create or replace temp view royalty_burn_down_base
as
select date,
       last_day(date) month_end_date,
       accountId,
       aggOrder,
       azureSubId,
       'royalty' usage_flag,
       sum(cust_dollars) cust_dollars,
       sum(dbu) usage_quantity,
       max(cust_commit) cust_commit
from {royalty_report_daily_attribution_table} 
group by all 
""")

# COMMAND ----------

spark.sql(f""" 
-- (1) royalty
create or replace temp view royalty_burn_down
as
select date,
       last_day(date) month_end_date,
       accountId,
       aggOrder,
       azureSubId,
       'royalty' usage_flag,
       sum(cust_dollars) cust_dollars,
       sum(dbu) usage_quantity,
       max(cust_commit) cust_commit
from {royalty_report_daily_attribution_table} 
where date <= '2023-03-31'
group by all
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### (2) snapshot-burn-down

# COMMAND ----------

spark.sql(f""" 
-- (2) snapshot
create or replace temp view snapshot_burn_down
as
select date posting_date,
       posting_month_end_date,
       accountId,
       aggOrder,
       azureSubId,
       case when snap_flag = 'actual' then 'snapshot_actual' 
            else 'snapshot_trueup' 
       end as usage_flag,
       sum(usage_cust_dollars) usage_cust_dollars,
       sum(usage_quantity) usage_quantity,
       max(cust_commit) cust_commit
from {consumption_azure_true_up_snapshot_daily} 
where posting_month_end_date >= '2023-04-30'
group by all 
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### iteration end

# COMMAND ----------

# MAGIC %md
# MAGIC #### add royalty

# COMMAND ----------

print(quarter_start_date, quarter_end_date, royalty_post_date, royalty_post_month_end_date)

# COMMAND ----------

debug = False
print('processing.. ', royalty_post_date)

# quarterly_trueup_burn_down_base
spark.sql(f""" 
        create or replace temp view quarterly_trueup_burn_down_base
        as          
        with royalty_actuals_quarter_base (
            select date,
                  --last_day(date) month_end_date,
                  accountId,
                  aggOrder,
                  azureSubId,
                  --'royalty' usage_flag,
                  sum(usage_cust_dollars) usage_cust_dollars,
                  sum(usage_quantity) usage_quantity,
                  max(cust_commit) cust_commit
            from {royalty_report_daily_attribution_table_enriched}
            where date between '{quarter_start_date}' and '{quarter_end_date}'
            group by all
        ),
        royalty_actuals_quarter (
          
          select  concat(date, accountId, azureSubId) usage_key,
                  *
          from royalty_actuals_quarter_base
        ),
        snapshot_usage_unified (
            select posting_date as date,
                  --posting_month_end_date,
                  accountId,
                  aggOrder,
                  azureSubId,
                  --'snapshot' usage_flag,
                  sum(usage_cust_dollars) usage_cust_dollars,
                  sum(usage_quantity) usage_quantity,
                  max(cust_commit) cust_commit
            from {rr_true_up_snapshot_daily_staging_runtime}
            where posting_date between '{quarter_start_date}' and '{quarter_end_date}'
            and !(usage_flag like 'quarter-trueup%')
            group by all
        ), 

        snapshot_usage (
          select concat(date, accountId, azureSubId) usage_key,
                 *
          from snapshot_usage_unified
        ),    
        
        base (
        select 'inner' source, 
              r.date,
              r.azureSubId,
              r.aggOrder,
              r.accountId,
              --r.month_end_date,
              'quarter-trueup' as usage_flag,
              --'part-1' usage_part,
              r.usage_cust_dollars royalty_dollars,
              s.usage_cust_dollars snapshot_dollars,
              r.usage_cust_dollars - s.usage_cust_dollars as usage_cust_dollars,
              r.usage_quantity - s.usage_quantity as usage_quantity,
              r.cust_commit
        from royalty_actuals_quarter r 
        join snapshot_usage s on r.date = s.date 
                            and r.azureSubId = s.azureSubId
                            and r.aggOrder = s.aggOrder
                            and r.accountId = s.accountId

        union all

        select 'only royalty' source, 
              r.date,
              r.azureSubId,
              r.aggOrder,
              r.accountId,
              --r.month_end_date,
              'quarter-trueup' as usage_flag,
              --'part-2' usage_part,
              r.usage_cust_dollars royalty_dollars,
              0 snapshot_dollars,
              r.usage_cust_dollars as usage_cust_dollars,
              r.usage_quantity as usage_quantity,
              r.cust_commit
        from royalty_actuals_quarter r 
        left anti join snapshot_usage s on r.date = s.date 
                                      and r.azureSubId = s.azureSubId
                                      and r.aggOrder = s.aggOrder
                                      and r.accountId = s.accountId

        union all 

        select 'only snapshot' source, 
              s.date,
              s.azureSubId,
              s.aggOrder,
              s.accountId,
              --s.posting_month_end_date month_end_date,
              'quarter-trueup' as usage_flag,
              --'part-3' usage_part,
              0 royalty_dollars,
              s.usage_cust_dollars snapshot_dollars,
              0 - s.usage_cust_dollars as usage_cust_dollars,
              0 - s.usage_quantity as usage_quantity,
              s.cust_commit
        from snapshot_usage s 
        left anti join royalty_actuals_quarter r on s.date = r.date 
                                                and s.azureSubId = r.azureSubId
                                                and s.aggOrder = r.aggOrder
                                                and s.accountId = r.accountId

        )
        
        select date, --'{royalty_post_date}' as posting_date,
              azureSubId,
              aggOrder,
              accountId,
              '{royalty_post_month_end_date}' as posting_month_end_date,
              'quarter-trueup' as usage_flag,
              sum(usage_cust_dollars) usage_cust_dollars,
              sum(usage_quantity) usage_quantity,
              max(cust_commit) cust_commit,
              sum(royalty_dollars) royalty_dollars,
              sum(snapshot_dollars) snapshot_dollars
              
        from base   
        group by all 
        
  """)


# aggorders 100% burn base
spark.sql(f""" 
        create or replace temp view rr_aggorders_100_burn_percentage_base  
        as
        with aggorders_100_burn_percentage_base (
              select    
                    aggOrder,
                    sum(usage_cust_dollars) total_royalty_cust_dollars,
                    max(cust_commit) cust_commit
              from {royalty_report_daily_attribution_table_enriched} b
              where date <= '{quarter_end_date}'
              and aggOrder not like 'MTM%'
              group by all
        )

        select distinct aggOrder
        from aggorders_100_burn_percentage_base
        where total_royalty_cust_dollars - cust_commit > 0.00001
""")

spark.sql(f""" 
        create or replace temp view rr_aggorders_100_burn_percentage_td
        as
          select q.aggOrder, sum(usage_cust_dollars) true_up_usage_cust_dollars
          from  quarterly_trueup_burn_down_base q 
          join rr_aggorders_100_burn_percentage_base r on q.aggOrder = r.aggOrder
          group by all
          having true_up_usage_cust_dollars < -0.00001
""")

spark.sql(f""" 
        create or replace temp view rr_aggorders_100_burn_percentage
        as
          select q.aggOrder, sum(usage_cust_dollars) true_up_usage_cust_dollars
          from  quarterly_trueup_burn_down_base q 
          join rr_aggorders_100_burn_percentage_base r on q.aggOrder = r.aggOrder
          left anti join rr_aggorders_100_burn_percentage_td r1 on q.aggOrder = r1.aggOrder          
          group by all
          --having true_up_usage_cust_dollars < 0 
""")

# new next available orders
spark.sql(f""" 
            create or replace temp view next_available_orders_true_up
            as
            with base (
            select accountId,
                  aggOrder, 
                  azureSubId,
                  min(date) min_usage_date,
                  max(date) max_usage_date
            from {royalty_report_daily_attribution_table}
            where aggOrder not like 'MTM%' 
            group by all 
            order by 1,2
            ),

            base1 (
            select accountId,
                  aggOrder,
                  azureSubId,
                  min_usage_date,
                  max_usage_date,
                  lead(aggOrder) over(partition by azureSubId order by max_usage_date) aggOrder_next
            from base 
            ),

            base2 (
            select distinct 
                  accountId,
                  aggOrder,
                  azureSubId,
                  aggOrder_next
                  --max_usage_date
            from base1
            ),

            base3 (
            select b.accountId,
                  b.azureSubId,
                  --b.max_usage_date,
                  b.aggOrder,
                  b.aggOrder_next,
                  o.ActualPartnerCommit cust_commit,
                  cast(o.startDate as string) startDate,
                  cast(o.endDate as string) endDate
                  --coalesce(b.aggOrder_next, concat('MTMAzure', b.accountId)) aggOrder_next,
                  --coalesce(o.ActualPartnerCommit, 0) cust_commit,
                  --coalesce(cast(o.startDate as string), '2001-01-01') startDate,
                  --coalesce(cast(o.endDate as string), '2050-01-01') endDate
            from base2 b 
            left join {orders_base_table} o on b.aggOrder_next = o.aggOrder
            ),
            
            base4 (
            select 
                  b.accountId,
                  b.azureSubId,
                  b.aggOrder,
                  b.aggOrder_next aggOrder_next_orig,

                  case when b.aggOrder = b.aggOrder_next then n.aggOrder_next
                      else coalesce(b.aggOrder_next, n.aggOrder_next) 
                  end as aggOrder_next,

                  case when b.aggOrder = b.aggOrder_next then n.cust_commit
                      else coalesce(b.cust_commit, n.cust_commit) 
                  end as cust_commit,

                  case when b.aggOrder = b.aggOrder_next then n.startDate 
                      else coalesce(b.startDate, n.startDate) 
                  end as startDate,

                  case when b.aggOrder = b.aggOrder_next then n.endDate
                      else coalesce(b.endDate, n.endDate) 
                  end as endDate
            from base3 b
            left join {next_available_orders_base_table} n on b.aggOrder = n.aggOrder 
            )

            select 
                  accountId,
                  azureSubId,
                  aggOrder,
                  aggOrder_next_orig,

                  case when aggOrder = aggOrder_next then concat('MTMAzure', accountId)
                      else aggOrder_next 
                  end as aggOrder_next,

                  case when aggOrder = aggOrder_next then 0.0
                      else cust_commit
                  end as cust_commit,

                  case when aggOrder = aggOrder_next then '2001-01-01' 
                      else startDate
                  end as startDate,

                  case when aggOrder = aggOrder_next then '2050-01-01' 
                      else endDate 
                  end as endDate
            from base4

""") 

next_available_order_rows = \
        spark.sql("""
              select * 
              from next_available_orders_true_up
""").collect()


spark.sql(f""" 
        create or replace temp view rr_aggorders_100_burn_percentage_enhanced
        as
          select r.aggOrder,
                n.aggOrder_next,
                n.azureSubId,
                n.cust_commit cust_commit_next,
                n.startDate,
                n.endDate
          from rr_aggorders_100_burn_percentage r 
          left join next_available_orders_true_up n on r.aggOrder = n.aggOrder
""") 


# #true-down orders
spark.sql(f""" 
      create or replace temp view rr_aggorders_100_burn_percentage_enhanced_td
      as
        select 
              r.aggOrder,
              n.aggOrder_next,
              n.azureSubId azureSubId_next,
              n.cust_commit cust_commit_next,
              n.startDate,
              n.endDate
        from rr_aggorders_100_burn_percentage_td r 
        left join next_available_orders_true_up n on r.aggOrder = n.aggOrder
""") 


spark.sql(f""" 
        create or replace temp view quarterly_trueup_burn_down
        as
        select b.date,
              b.azureSubId,
              b.aggOrder aggOrder_orig,
              case when r.aggOrder is null then b.aggOrder 
                    else coalesce(r.aggOrder_next, concat('MTMAzure', b.accountId)) 
              end as  aggOrder,
              b.accountId,
              b.posting_month_end_date,
              b.usage_flag,
              b.usage_cust_dollars,
              b.usage_quantity,
              case when r.aggOrder is null then b.cust_commit 
                    else coalesce(r.cust_commit_next, 0) 
              end as cust_commit,       
              b.cust_commit cust_commit_orig
        from quarterly_trueup_burn_down_base b 
        left join rr_aggorders_100_burn_percentage_enhanced r on b.aggOrder = r.aggOrder
                                                            and b.azureSubId = r.azureSubId
                                                            and b.date between r.startDate and r.endDate
""")

spark.sql(f""" 
        create or replace temp view royalty_snapshot_union_2 
        as
        select posting_date date,
              posting_month_end_date,
              accountId,
              aggOrder,
              azureSubId,
              usage_flag,
              usage_cust_dollars,
              usage_quantity,
              cust_commit
        from {rr_true_up_snapshot_daily_staging_runtime} 

        union all

        select --posting_date as date, 
              date,
              posting_month_end_date,
              accountId,
              coalesce(aggOrder, concat('MTMAzure', accountId)) aggOrder,
              azureSubId,
              usage_flag,
              usage_cust_dollars,
              usage_quantity,
              coalesce(cust_commit, 0.0) cust_commit
        from quarterly_trueup_burn_down --royalty_trueup_fix_1 
""") 

spark.sql(f""" 
          create or replace temp view royalty_snapshot_union_2_enriched
          as
          with base (
          select date,
                posting_month_end_date,
                accountId,
                aggOrder,
                azureSubId,
                usage_flag,
                usage_cust_dollars,
                usage_quantity,
                cust_commit,
                sum(usage_cust_dollars) over(partition by aggOrder order by date) rolling_sum_dollars,
                count(aggOrder) over(partition by aggOrder order by date) rolling_sum_seq_no,
                row_number() over(partition by aggOrder order by date, usage_cust_dollars) row_number_seq_no    
          from royalty_snapshot_union_2 
          )

          select 
                case when rolling_sum_dollars > cust_commit then concat('MTMAzure',accountId) 
                      else aggOrder
                end as aggOrder_refined,
                *,
                case when rolling_sum_dollars > cust_commit then rolling_sum_dollars - cust_commit
                      else 0
                end as overage  
          from base            
          order by date, usage_cust_dollars 
""")    

# correct the overage here 
spark.sql(f""" 
        create or replace temp view fix_royalty_snapshot_union_2 
        as
        with 

        aggOrders_100_percentage_fix (
              select aggOrder,
                    sum(usage_cust_dollars) usage_cust_dollars,
                    max(cust_commit) cust_commit
              from royalty_snapshot_union_2_enriched
              group by all
              having usage_cust_dollars > cust_commit
        ),
        
        fix_base_0 (
          select aggOrder, 
                rolling_sum_dollars, 
                max(rolling_sum_seq_no) max_rolling_sum_seq_no,
                max(row_number_seq_no) max_row_number_seq_no
          from royalty_snapshot_union_2_enriched  
          where overage > 0.000001
          and cust_commit > 0
        group by all  
        ),

        fix_base_1 (
              select f.*
              from fix_base_0 f
              left anti join aggOrders_100_percentage_fix a on f.aggOrder = a.aggOrder
        ),

        fix_base_2 (
        select r.*,
              row_number() over(partition by r.aggOrder, r.rolling_sum_dollars order by usage_cust_dollars desc) rno
        from royalty_snapshot_union_2_enriched r 
        join fix_base_1 f on r.aggOrder = f.aggOrder and r.rolling_sum_seq_no = f.max_rolling_sum_seq_no and r.row_number_seq_no = f.max_row_number_seq_no
        )
        select * except(rno)
        from fix_base_2
        where rno = 1
""") 

fix_royalty_snapshot_rows = spark.sql(""" 
                                        select * 
                                        from fix_royalty_snapshot_union_2 
                                        """).collect()

print(len(fix_royalty_snapshot_rows))

fixed_consumption_rows_month = fix_consumption_rows_accurate_split(next_available_order_rows,
                                                                   fix_royalty_snapshot_rows, debug=False)

if len(fixed_consumption_rows_month) == 0:
        spark.sql(""" 
                  create or replace temp view fixed_consumption_month_2
                  as 
                  select * from fix_royalty_snapshot_union_2
                  """) 
else:
  fixed_consumption_2 = spark.createDataFrame(fixed_consumption_rows_month)
  fixed_consumption_2.createOrReplaceTempView('fixed_consumption_month_2')

spark.sql(f""" 
          create or replace temp view unioned_base 
          as
            with base (
            select *,
                   'royalty_snapshot_union_2_enriched' source
            from royalty_snapshot_union_2_enriched 
            ),

            f_base (

            select *,
                   'fix_royalty_snapshot_union_2' source
            from fix_royalty_snapshot_union_2 
            ),

            u_base (
              select b.source,
                    b.date,
                    b.posting_month_end_date,
                    b.accountId, 
                    b.aggOrder,
                    b.azureSubId,
                    b.usage_flag,
                    b.usage_cust_dollars,
                    b.usage_quantity,
                    b.cust_commit
            from base b 
            left anti  join f_base f  
                                 on b.date = f.date
                                and b.accountId = f.accountId
                                and b.azureSubId = f.azureSubId
                                and b.row_number_seq_no = f.row_number_seq_no
                                and b.rolling_sum_seq_no = f.rolling_sum_seq_no
                                and b.usage_quantity = f.usage_quantity

            union all

            select  'fix' source,
                    date, 
                    posting_month_end_date,
                    accountId,
                    aggOrder,
                    azureSubId,
                    usage_flag,
                    usage_cust_dollars,
                    usage_quantity,
                    cust_commit
            from fixed_consumption_month_2
            )

            select *
            from u_base
""")

spark.sql(f""" 
            create or replace temp view royalty_snapshot_union_1_enriched_month_fix
            as
            with base_0_1 (
                select *
                from unioned_base
                
            ),

            base_0 (
                  
                select 
                  case when usage_flag like 'quarter-trueup%' and posting_month_end_date = '{royalty_post_month_end_date}'  
                            then '{royalty_post_date}' 
                      else date 
                  end as date, 
                  posting_month_end_date,
                  accountId,
                  aggOrder,
                  azureSubId,
                  usage_flag,
                  usage_cust_dollars,
                  usage_quantity,
                  cust_commit
              from base_0_1 

            ),

            base_1 (
            select *,
                  sum(usage_cust_dollars) over(partition by aggOrder order by date, usage_cust_dollars) rolling_sum_dollars,
                  sum(usage_quantity) over(partition by aggOrder order by date, usage_cust_dollars) rolling_sum_quantity,
                  count(aggOrder) over(partition by aggOrder order by date, usage_cust_dollars) rolling_sum_seq_no     
            from base_0 
            )

            select 
                  case when rolling_sum_dollars > cust_commit then concat('MTMAzure',accountId) 
                        else aggOrder
                  end as aggOrder_refined,
                  *,
                  case when rolling_sum_dollars > cust_commit then rolling_sum_dollars - cust_commit
                        else 0
                  end as overage  
            from base_1            
            order by date, usage_cust_dollars 
""")

month_snapshot = spark.sql(f""" 
                            select c.date as posting_date,
                                    --c.* except(aggOrder_refined, date, rolling_sum_seq_no, overage),
                                    cast(c.posting_month_end_date as string) posting_month_end_date,
                                    c.accountId,
                                    c.aggOrder,
                                    c.azureSubId,
                                    c.usage_flag,
                                    c.usage_cust_dollars,
                                    c.usage_quantity,
                                    c.cust_commit,
                                    c.rolling_sum_dollars,
                                    c.rolling_sum_quantity,
                                    c.rolling_sum_dollars/c.cust_commit as burn_percentage,
                                    case when upper(c.aggOrder) like 'AZURE-COMMIT%' then '01t3f000000QCsTAAW'
                                        when upper(c.aggOrder) like '%FLEX%' then '01t3f000000QCsYAAW'
                                        else null 
                                    end as product_code_id,                                  
                                    b.sfdcAccountId commit_sfdc_account_id,
                                    b.contract_id,
                                    b.order_id,
                                    b.startDate,
                                    b.endDate,
                                    case when usage_flag = 'royalty' then usage_cust_dollars
                                        else 0 
                                    end as royalty_cust_dollars
                            from royalty_snapshot_union_1_enriched_month_fix c      
                            left join {orders_base_table} b on lower(c.aggOrder) = lower(b.aggOrder)
""")

month_snapshot.createOrReplaceTempView('month_snapshot_debug')

if not debug:
      write_to_rr_true_up_true_up_snapshot_daily(month_snapshot, rr_true_up_snapshot_daily_staging_runtime)      
else:
      print('skip writing due to debug mode')

# COMMAND ----------

# MAGIC %md
# MAGIC #### write to staging

# COMMAND ----------

print(rr_true_up_snapshot_daily_staging_runtime)

# COMMAND ----------

display(
  spark.sql(f""" 
desc history {rr_true_up_snapshot_daily_staging_runtime}
"""))

# COMMAND ----------

spark.sql(f""" 
create or replace temp view rr_true_up_snapshot_daily_staging_runtime_vw
as
with month_dates (
select date month_start_date, month_end_date 
from main.it_core_dim.bi_dates 
where isMonthStart 
)

select case when usage_flag like 'snapshot_true%' then m.month_start_date 
            else posting_date end as posting_date,
       b.* except(posting_date),
       posting_date as usage_date
from  {rr_true_up_snapshot_daily_staging_runtime} b  
left join month_dates m on b.posting_month_end_date = m.month_end_date 
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select posting_month_end_date,
# MAGIC        case when usage_flag like 'snapshot_true%' then 'snapshot_true_up'
# MAGIC             when usage_flag like 'quarter-true%' then 'quarter-trueup'
# MAGIC             when usage_flag like 'snapshot_actual%' then 'snapshot_actual'
# MAGIC             else usage_flag end as usage_flag,
# MAGIC        sum(usage_cust_dollars)
# MAGIC from rr_true_up_snapshot_daily_staging_runtime_vw
# MAGIC group by all 
# MAGIC order by 1 desc, 2

# COMMAND ----------

rr_true_up_snapshot_daily_staging_runtime

# COMMAND ----------

daily_to_staging(rr_true_up_snapshot_daily_staging_runtime, 
                 rr_true_up_snapshot_daily_staging)
