# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from datetime import datetime

# COMMAND ----------

@udf('string')
def commit_string(product_code, cpq_order_type):
  """ drops dollar from commit string  """
  commit_string = 'COMMIT'
  if cpq_order_type is None:
    cpq_order_type = ""
  if 'DOLLAR' in product_code and 'co-term' not in cpq_order_type.lower():
    commit_string = product_code.split('-')
    return '-'.join(commit_string[0:len(commit_string)-1])
  
  if 'DOLLAR' in product_code and 'co-term' in cpq_order_type.lower():
    commit_string = product_code.split('-')
    return '-'.join(commit_string[0:len(commit_string)-1]) + '-CO-TERM'
  
  if 'COMPLIMENTARY-USAGE-AWS' in product_code:
    return 'AWS-COMPLIMENTARY'
  
  return commit_string

spark.udf.register("commit_string", commit_string)


@udf('string')
def split_commit_string(order):
  if order is None:
    return None
  else:
    split_string = order.split('-')
    return '-'.join(split_string[0:len(split_string)-1])

spark.udf.register("split_commit_string", split_commit_string)

@udf("double")
def distributeDailyRevShareDollars(revShareDollars, daysinmonth):
  """ returns daily share of a month """
  return revShareDollars/daysinmonth


@udf('string')
def generate_commit_account_group_id(sfdc_account_commit_group):
    """ returns a group-id """
    if sfdc_account_commit_group is not None:
      return '-'.join(sorted(sfdc_account_commit_group))
    return sfdc_account_commit_group
  
spark.udf.register("generate_commit_account_group_id", generate_commit_account_group_id)

# COMMAND ----------

# MAGIC %md
# MAGIC #### set up

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("catalog", "")
dbutils.widgets.text("data_schema", "")
dbutils.widgets.text("quarter_start_date", "")
dbutils.widgets.text("quarter_end_date", "")

catalog = dbutils.widgets.getArgument('catalog')
data_schema = dbutils.widgets.getArgument('data_schema')
quarter_start_date = dbutils.widgets.getArgument('quarter_start_date')
quarter_end_date = dbutils.widgets.getArgument('quarter_end_date')

# COMMAND ----------

#tables
main_sfdc_bronze_workspace_table = 'main.sfdc_bronze.workspace__c'
finance_dbu_dollars_table = 'main.it_lakehouse.azure_carveout'
msft_royalty_qtrly_total_db_table = 'main.it_msft_silver.msft_royalty_qtrly_total_db'
cpq_aws_gcp_contracts_orders_vw = 'main.it_cpq_silver.cpq_aws_gcp_contracts_orders_vw'
bi_account_dim_table = 'main.it_core_dim.bi_account_dim'
azure_contracts_orders_parallel_vw = 'main.it_cpq_silver.azure_contracts_orders_parallel_vw'
bi_dates_dim = 'main.it_core_dim.bi_dates'

# cra tables
cra_final_mapping_table = f'{catalog}.{data_schema}.cra_final_mapping' 
cra_orders_base = f'{catalog}.{data_schema}.cra_orders_base'
cra_orders_base_ub = f'{catalog}.{data_schema}.cra_orders_base_ub_latest'
royalty_azure_sub_multiple_commit_consumption_azure = f'{catalog}.{data_schema}.azure_sub_multiple_commit_consumption_royalty'
cra_royalty_consumption_daily = f'{catalog}.{data_schema}.royalty_report_consumption_daily'

royalty_dbu_dollars = f'{catalog}.{data_schema}.royalty_dbu_dollars'
royalty_dbu_dollars_mapped = f'{catalog}.{data_schema}.royalty_dbu_dollars_mapped'

#locations
account_subs_ranked_location = '/mnt/bse-dev/test/cra/account_subs_ranked'
cra_orders_base_location = '/mnt/bse-dev/cra/orders_base'
order_consumption_daily_staging_enhanced = '/mnt/bse-dev/cra/order_consumption_daily_staging_enhanced'

# dates
mapping_run_date = datetime.now().strftime('%Y-%m-%d')
incremental_refresh_date_to_be_appended = datetime.now().strftime('%Y-%m-%d')

# COMMAND ----------

spark.sql(f""" 
create or replace temp view month_keys
as
select replace(date, '-', '') month_start_key, 
       month_end_date,
       daysinmonth days_in_month
from {bi_dates_dim}
where isMonthStart 
order by 1
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### orders base

# COMMAND ----------

spark.sql(f""" 
create or replace temp view orders_base
as 
select *
from {cra_orders_base_ub}
""")

# COMMAND ----------

spark.sql(f""" 
create or replace temp view cra_final_mapping_vw
as 
select *
from {cra_final_mapping_table} 
""")

# COMMAND ----------

mapping_min_date = spark.sql(""" select min(date) min_date from cra_final_mapping_vw """).collect()[0].min_date
print(mapping_min_date)

# COMMAND ----------

spark.sql(f""" 
create or replace temp view weighted_usage 
as
with product_base (
select date,
       last_day(date) month_end_date,
       lower(azure_sub_id) azureSubId,
       sum(net_usage_amount) dbu,
       sum(usage_dollars)/0.85 cust_dollars 
from {finance_dbu_dollars_table}
where platform = 'azure'
and date between '{quarter_start_date}' and '{quarter_end_date}'
group by all
order by 1 
)

select date,
       azureSubId,
       month_end_date,
       dbu,
       cust_dollars,
       sum(dbu) over(partition by azureSubId, month_end_date) monthly_dbu,
       dbu / sum(dbu) over(partition by azureSubId, month_end_date) daily_quantity_ratio
from product_base 
order by date, azureSubId  
""")    

# COMMAND ----------

spark.sql(f""" 
create or replace temp view sub_rr_consumption_monthly
as
with 
msft_royalty_qtrly_total_db_ (

select BillingMonthKey,
       lower(SubscriptionGUID) SubscriptionGUID,
       max(CustomerPrice) CustomerPrice,
       sum(DatabricksRevShare)/0.85 cust_dollars,
       sum(DatabricksRevShare) revshare_dollars,
       sum(TotalUnits) TotalUnits
from  {msft_royalty_qtrly_total_db_table}
where date between '{quarter_start_date}' and '{quarter_end_date}'
group by all 
)

select SubscriptionGUID subscription_guid,
       --DatabricksSku sku,
       m.month_end_date,
       CustomerPrice cust_price,
       cust_dollars,
       revshare_dollars,
       TotalUnits dbu
from msft_royalty_qtrly_total_db_ r
join month_keys m on r.BillingMonthKey = m.month_start_key 
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select month_end_date, sum(cust_dollars)
# MAGIC from sub_rr_consumption_monthly
# MAGIC group by all
# MAGIC order by 1 

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view dbu_dollars_vw
# MAGIC as 
# MAGIC select coalesce(w.date, s.month_end_date) date, 
# MAGIC        s.month_end_date,
# MAGIC        'azure' platform,
# MAGIC        s.subscription_guid azureSubId,
# MAGIC        s.cust_price dbuPrice,
# MAGIC        case when w.daily_quantity_ratio is null then s.cust_dollars 
# MAGIC             else (s.cust_dollars * w.daily_quantity_ratio) end as custDollars,
# MAGIC        case when w.daily_quantity_ratio is null then s.revshare_dollars 
# MAGIC             else (s.revshare_dollars * w.daily_quantity_ratio) end as revShareDollars,            
# MAGIC        case when w.daily_quantity_ratio is null then s.dbu
# MAGIC             else (s.dbu * w.daily_quantity_ratio) end as dbu
# MAGIC from sub_rr_consumption_monthly s  
# MAGIC left join weighted_usage w on s.month_end_date = w.month_end_date 
# MAGIC                      and s.subscription_guid = w.azureSubId   

# COMMAND ----------

spark.sql(f""" 
create or replace temp view royalty_dbu_dollars_base
as
with sub_tpid_enr_base_t (
select m.month_end_date,
       SubscriptionGUID azureSubId,
       coalesce(TPID, 'NA') TPID,
       coalesce(EnrollmentNumber, 'NA') enrollmentNumber,
       concat(coalesce(TPID,'NA'),'-',coalesce(EnrollmentNumber,'NA')) tpid_enr_key,
       row_number() over(partition by SubscriptionGUID, m.month_end_date order by coalesce(EnrollmentNumber, 'NA') desc) rno
from  {msft_royalty_qtrly_total_db_table} b 
join month_keys m on b.BillingMonthKey = m.month_start_key  
),

sub_tpid_enr_base (
select month_end_date,
       azureSubId,
       tpid,
       enrollmentNumber,
       tpid_enr_key
from  sub_tpid_enr_base_t
where rno = 1
) 

select d.date, 
       d.month_end_date,
       d.platform,
       d.azureSubId,
       s.tpid,
       s.enrollmentNumber,
       s.tpid_enr_key,
       d.dbuPrice,
       d.custDollars,
       d.revShareDollars,            
       d.dbu       
from dbu_dollars_vw d 
left join sub_tpid_enr_base s on d.month_end_date = s.month_end_date
                             and d.azureSubId = s.azureSubId
""")

# COMMAND ----------

display(spark.sql(
f"""
select month_end_date,
       sum(custDollars) custDollars
from {royalty_dbu_dollars}
group by all
order by 1 desc
"""
))


# COMMAND ----------

royalty_dbu_dollars_df = spark.sql(""" select * from royalty_dbu_dollars_base""")
royalty_dbu_dollars_df.write\
                      .format('delta')\
                      .mode("overwrite")\
                      .option("replaceWhere", f"month_end_date >= '{quarter_start_date}' and month_end_date <= '{quarter_end_date}'") \
                      .saveAsTable(royalty_dbu_dollars)

# COMMAND ----------

display(spark.sql(
f"""
select month_end_date,
       sum(custDollars) custDollars
from {royalty_dbu_dollars}
group by all
order by 1 desc
"""
))

# COMMAND ----------

# spark.sql(f""" 
# create or replace temp view dbu_dollars_vw
# as
# with 
# monthly_msft_royalty_qtrly_total_db (
# select m.month_end_date,
#        lower(SubscriptionGUID) azureSubId,
#        max(CustomerPrice) * 0.85 dbuPrice,
#        sum(DatabricksRevShare)/0.85 custDollars,
#        sum(DataBricksRevShare) revShareDollars,
#        sum(TotalUnits) dbu
# from  {msft_royalty_qtrly_total_db_table} b 
# join month_keys m on b.BillingMonthKey = m.month_start_key 
# group by all  
# )

# select cast(dt.date as string) date,
#        s.month_end_date,
#        'azure' platform,
#        s.azureSubId,
#        s.dbuPrice,
#        (s.custDollars/dt.daysinmonth) custDollars,
#        (s.revShareDollars/dt.daysinmonth) revShareDollars,
#        (s.dbu/dt.daysinmonth) dbu
# from  monthly_msft_royalty_qtrly_total_db s 
# join {bi_dates_dim} dt on s.month_end_date = dt.month_end_date
# """)

# COMMAND ----------

spark.sql(f""" 
create or replace temp view fin_cra_mapping_usage_base
as
with 
fin_base (
select --f.accountId,
       --f.workspaceId,
       --f.sku,
       cast(f.date as string) date,
       f.platform,
       lower(azureSubID) azureSubID,
       sum(f.dbu) dbu,
       max(f.dbuPrice) dbu_price,
       sum(revShareDollars) revShareDollars,
       sum(custDollars) custDollars
from {royalty_dbu_dollars} f
where f.platform = 'azure'
and f.date >= '2019-06-01'
group by all
),

fin_mapping_base
(
  select 
      case when a.sfdc_account_id is null then '0013f000005RwT9AAK'
            else a.sfdc_account_id end as accountId,
       --f.workspaceId,
       --f.sku,
       f.date,
       f.platform,
       a.subscription_guid azureSubID,
       a.tp_id TPID,
       a.enrollment_number enrollmentNumber,
       concat(coalesce(a.tp_id,'NA'),'-',coalesce(a.enrollment_number,'NA')) tpid_enr_key,      
       f.dbu,
       f.dbu_price,
       f.revShareDollars,
       f.custDollars
from fin_base f 
join cra_final_mapping_vw a on f.azureSubID = a.subscription_guid
where f.platform = 'azure'
and f.date between '2019-06-01' and '{mapping_min_date}' 
and a.date = '{mapping_min_date}' 

union

select case when a.sfdc_account_id is null then '0013f000005RwT9AAK'
            else a.sfdc_account_id end as accountId,
       --f.workspaceId,
       --f.sku,
       f.date,
       f.platform,
       a.subscription_guid azureSubID,
       a.tp_id TPID,
       a.enrollment_number enrollmentNumber,
       concat(coalesce(a.tp_id,'NA'),'-',coalesce(a.enrollment_number,'NA')) tpid_enr_key,        
       f.dbu,
       f.dbu_price,
       f.revShareDollars,
       f.custDollars
from fin_base f 
join cra_final_mapping_vw a on f.azureSubID = a.subscription_guid 
                           and f.date = a.date
where f.platform = 'azure'
and a.date > '{mapping_min_date}'
)

select accountId,
       date,
       platform,
       azureSubID,
       TPID,
       enrollmentNumber,
       tpid_enr_key,
       sum(dbu) dbu,
       max(dbu_price) dbu_price,
       sum(revShareDollars) revShareDollars,
       sum(custDollars) custDollars
from fin_mapping_base
group by all
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select last_day(date) month_end_date,
# MAGIC        sum(custDollars)
# MAGIC from  fin_cra_mapping_usage_base 
# MAGIC group by all
# MAGIC order by 1 desc 

# COMMAND ----------

display(spark.sql(
f"""
select last_day(date) month_end_date,
       sum(custDollars)
from  {royalty_dbu_dollars_mapped} 
group by all
order by 1 desc
"""
))

# COMMAND ----------

royalty_dbu_dollars_mapped

# COMMAND ----------

royalty_dbu_dollars_mapped_df = spark.sql(""" select * from fin_cra_mapping_usage_base""")
royalty_dbu_dollars_mapped_df.write\
                             .option('overwriteSchema', 'true')\
                             .format('delta')\
                             .mode('overwrite')\
                             .saveAsTable(royalty_dbu_dollars_mapped)

# COMMAND ----------

spark.sql(f""" 
create or replace temp view azure_contracts_orders_parallel_vw
as
with 
parallel_contracts (
  select account_id,
         count(*) account_count
  from {azure_contracts_orders_parallel_vw}
  group by 1
  having account_count > 1
)
select b.*
from {azure_contracts_orders_parallel_vw} b
join parallel_contracts p on b.account_id = p.account_id
order by account_id
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view co_term_order_accounts 
# MAGIC as
# MAGIC with co_term_orders (
# MAGIC select aggorder_key,
# MAGIC        universalOrder,
# MAGIC        aggOrder
# MAGIC from orders_base 
# MAGIC where aggOrder like '%CO-TERM%'
# MAGIC )
# MAGIC
# MAGIC select distinct 
# MAGIC        o.sfdcAccountId account_id
# MAGIC from orders_base o 
# MAGIC join co_term_orders c on o.universalOrder = c.universalOrder
# MAGIC --order by o.universalOrder, o.startDate

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view parallel_contract_accounts_t
# MAGIC as 
# MAGIC with 
# MAGIC parallel_contract_accounts_base (
# MAGIC select distinct account_id
# MAGIC from azure_contracts_orders_parallel_vw 
# MAGIC
# MAGIC union
# MAGIC
# MAGIC select distinct account_id
# MAGIC from co_term_order_accounts
# MAGIC )
# MAGIC
# MAGIC select *
# MAGIC from parallel_contract_accounts_base

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view azure_flex_accounts
# MAGIC as
# MAGIC with flex_orders (
# MAGIC select sfdcAccountId,
# MAGIC        contract_id,
# MAGIC        count(distinct aggOrder) num_aggOrder
# MAGIC from orders_base 
# MAGIC where lower(platform) in ('azure', 'flex')
# MAGIC group by all
# MAGIC having num_aggOrder > 1
# MAGIC )
# MAGIC
# MAGIC select distinct 
# MAGIC        o.sfdcAccountId account_id
# MAGIC from orders_base o 
# MAGIC join flex_orders f on o.sfdcAccountId = f.sfdcAccountId
# MAGIC left anti join parallel_contract_accounts_t p on o.sfdcAccountId = p.account_id

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view flex_only_accounts
# MAGIC as
# MAGIC with flex_orders (
# MAGIC select sfdcAccountId,
# MAGIC        contract_id,
# MAGIC        count(distinct replace(aggOrder,'AZDTU','')) num_aggOrder
# MAGIC from orders_base 
# MAGIC where lower(platform) = 'flex'
# MAGIC group by all
# MAGIC having num_aggOrder = 1
# MAGIC )
# MAGIC
# MAGIC select distinct 
# MAGIC        o.sfdcAccountId account_id
# MAGIC from orders_base o 
# MAGIC join flex_orders f on o.sfdcAccountId = f.sfdcAccountId
# MAGIC left anti join parallel_contract_accounts_t p on o.sfdcAccountId = p.account_id
# MAGIC left anti join azure_flex_accounts a on o.sfdcAccountId = a.account_id

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view parallel_contract_accounts_prelim
# MAGIC as
# MAGIC
# MAGIC with base (
# MAGIC select account_id 
# MAGIC from azure_flex_accounts
# MAGIC
# MAGIC union
# MAGIC
# MAGIC select account_id
# MAGIC from parallel_contract_accounts_t
# MAGIC )
# MAGIC
# MAGIC select distinct account_id
# MAGIC from base

# COMMAND ----------

spark.sql(f""" 
CREATE or replace temp view orders_base_parallel_accounts
as
WITH sorted_table AS (
  SELECT sfdcAccountId, startDate as start_date, endDate as end_date,
         LAG(startDate) OVER (PARTITION BY sfdcAccountId ORDER BY startDate) AS prev_start_date,
         LAG(endDate) OVER (PARTITION BY sfdcAccountId ORDER BY startDate) AS prev_end_date
  FROM {cra_orders_base} 
),

sorted_table_2 as (
SELECT sfdcAccountId, start_date, end_date, prev_start_date, prev_end_date,
       case when start_date <= prev_end_date and end_date >= prev_end_date then True else False end as is_overlapping
FROM sorted_table
)

select DISTINCT sfdcAccountId as account_id
from sorted_table_2 s
left anti join parallel_contract_accounts_prelim p on s.sfdcAccountId = p.account_id
where is_overlapping 
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view parallel_contract_accounts
# MAGIC as
# MAGIC
# MAGIC with base (
# MAGIC select account_id 
# MAGIC from parallel_contract_accounts_prelim
# MAGIC
# MAGIC union
# MAGIC
# MAGIC select account_id
# MAGIC from orders_base_parallel_accounts
# MAGIC )
# MAGIC
# MAGIC select distinct account_id
# MAGIC from base

# COMMAND ----------

# MAGIC %md
# MAGIC #### handle sequenced contracts ( azure_sub_commit_accounts )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view azure_sub_commit_accounts
# MAGIC as
# MAGIC with
# MAGIC azure_sub_commit_accounts_t_base (
# MAGIC select distinct b.date,
# MAGIC                 b.subscription_guid, 
# MAGIC                 case when len(b.revops_commit_account_id) > 0 then array(b.revops_commit_account_id) 
# MAGIC                 else b.sfdc_account_commit_group end as sfdc_account_commit_group
# MAGIC from cra_final_mapping_vw b
# MAGIC ),
# MAGIC
# MAGIC azure_sub_commit_accounts_t (
# MAGIC
# MAGIC select date,
# MAGIC        subscription_guid,
# MAGIC        sfdc_account_commit_group,
# MAGIC        explode(sfdc_account_commit_group) commit_sfdc_account_id
# MAGIC from azure_sub_commit_accounts_t_base     
# MAGIC )
# MAGIC
# MAGIC select a.date,
# MAGIC        a.commit_sfdc_account_id,
# MAGIC        a.sfdc_account_commit_group,
# MAGIC        a.subscription_guid,
# MAGIC        o.Platform,
# MAGIC        o.sfdcAccountId,
# MAGIC        o.aggOrder,
# MAGIC        o.aggorder_key,
# MAGIC        row_number() over(partition by date, subscription_guid order by startDate, aggOrder) row_num,
# MAGIC        cast(o.startDate as string) startDate,
# MAGIC        cast(o.endDate as string) endDate,
# MAGIC        case when lower(o.aggOrder) like '%flex%' then coalesce(o.available_commit, o.actualPartnerCommit)  
# MAGIC             else o.actualPartnerCommit 
# MAGIC        end as cust_commit,
# MAGIC        case when lower(o.aggOrder) like '%flex%' then coalesce(o.available_commit, o.flexCommit)  
# MAGIC             else o.flexCommit 
# MAGIC        end as flex_commit  
# MAGIC from orders_base o
# MAGIC join azure_sub_commit_accounts_t a on o.sfdcAccountId = a.commit_sfdc_account_id
# MAGIC order by a.subscription_guid, o.aggOrder, o.startDate

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view subs_more_than_one_enhanced_accounts
# MAGIC as
# MAGIC select distinct 
# MAGIC        date,
# MAGIC        explode(sfdc_account_commit_group) commit_sfdc_account_id
# MAGIC from azure_sub_commit_accounts
# MAGIC where size(sfdc_account_commit_group) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view commit_account_group
# MAGIC as
# MAGIC select distinct b.date,
# MAGIC                 b.subscription_guid, 
# MAGIC                 b.sfdcAccountId, 
# MAGIC                 b.commit_sfdc_account_id,
# MAGIC                 b.sfdc_account_commit_group,
# MAGIC                 generate_commit_account_group_id(b.sfdc_account_commit_group) as 
# MAGIC                 sfdc_account_commit_group_orig                
# MAGIC from azure_sub_commit_accounts b  
# MAGIC join subs_more_than_one_enhanced_accounts a on b.commit_sfdc_account_id = a.commit_sfdc_account_id
# MAGIC
# MAGIC union
# MAGIC
# MAGIC select distinct b.date,
# MAGIC                 b.subscription_guid, 
# MAGIC                 b.sfdcAccountId, 
# MAGIC                 b.commit_sfdc_account_id,
# MAGIC                 b.sfdc_account_commit_group,
# MAGIC                 generate_commit_account_group_id(b.sfdc_account_commit_group) as 
# MAGIC                 sfdc_account_commit_group_orig                
# MAGIC from azure_sub_commit_accounts b  
# MAGIC join parallel_contract_accounts p on b.commit_sfdc_account_id = p.account_id

# COMMAND ----------

# MAGIC %sql
# MAGIC select date, count(*) 
# MAGIC from commit_account_group
# MAGIC group by all 

# COMMAND ----------

# MAGIC %md
# MAGIC #### overwrite subs_commit_account_group_id_vw

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view subs_commit_account_group_id_vw
# MAGIC as
# MAGIC
# MAGIC select date,
# MAGIC        subscription_guid,
# MAGIC        common_account_id as commit_account_group_id
# MAGIC from main.it_cra_silver.date_subscription_commit_account_groups_v2   
# MAGIC where date <= '2023-09-30'
# MAGIC
# MAGIC union all 
# MAGIC
# MAGIC select date,
# MAGIC        subscription_guid,
# MAGIC        common_account_id as commit_account_group_id
# MAGIC from main.it_cra_silver.date_subscription_commit_account_groups_v5   
# MAGIC where date >= '2023-10-01'

# COMMAND ----------

# MAGIC %sql
# MAGIC select date, count(*)
# MAGIC from subs_commit_account_group_id_vw
# MAGIC group by all
# MAGIC order by date desc 

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view subs_more_than_one_enhanced
# MAGIC as
# MAGIC with base (
# MAGIC select distinct 
# MAGIC        date,
# MAGIC        commit_sfdc_account_id,
# MAGIC        subscription_guid,
# MAGIC        sfdc_account_commit_group
# MAGIC from azure_sub_commit_accounts
# MAGIC ),
# MAGIC
# MAGIC subs_more_than_one (
# MAGIC select date,
# MAGIC        subscription_guid,
# MAGIC        collect_set(commit_sfdc_account_id) commit_sdfc_account_group,
# MAGIC        count(*) cnt
# MAGIC from base
# MAGIC group by all 
# MAGIC having cnt > 1
# MAGIC )
# MAGIC
# MAGIC select  generate_commit_account_group_id(array_sort(commit_sdfc_account_group)) as commit_sfdc_account_group_id,
# MAGIC         *
# MAGIC from subs_more_than_one

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view azure_sub_commit_accounts_enhanced
# MAGIC as
# MAGIC
# MAGIC select distinct
# MAGIC        s.commit_account_group_id commit_sfdc_account_group_id,
# MAGIC        a.*
# MAGIC from azure_sub_commit_accounts a 
# MAGIC join subs_commit_account_group_id_vw s on a.subscription_guid = s.subscription_guid
# MAGIC                                       and a.date = s.date

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view azure_sub_commit_accounts_enhanced_parallel 
# MAGIC as 
# MAGIC select  
# MAGIC     date,
# MAGIC     commit_sfdc_account_group_id,
# MAGIC     commit_sfdc_account_id,
# MAGIC     subscription_guid,
# MAGIC     Platform,
# MAGIC     sfdcAccountId,
# MAGIC     aggOrder,
# MAGIC     aggorder_key,
# MAGIC     row_num,
# MAGIC     startDate,
# MAGIC     endDate,
# MAGIC     cust_commit,
# MAGIC     flex_commit
# MAGIC from azure_sub_commit_accounts_enhanced 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create or replace temp view multiple_azure_sub_commit_accounts
# MAGIC as
# MAGIC with multiple_commit_base (
# MAGIC select distinct
# MAGIC        date,
# MAGIC        commit_sfdc_account_group_id,
# MAGIC        sfdcAccountId,
# MAGIC        aggOrder,
# MAGIC        aggorder_key,
# MAGIC        cust_commit,
# MAGIC        flex_commit,
# MAGIC        startDate,
# MAGIC        endDate
# MAGIC from azure_sub_commit_accounts_enhanced_parallel
# MAGIC order by date, commit_sfdc_account_group_id, startDate
# MAGIC )
# MAGIC
# MAGIC select *,
# MAGIC        row_number() over(partition by date, commit_sfdc_account_group_id order by startDate, cust_commit desc) rno
# MAGIC from multiple_commit_base;

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view commit_account_group_id_orders_base
# MAGIC as
# MAGIC select a.date,
# MAGIC        a.subscription_guid,
# MAGIC        a.commit_sfdc_account_id,
# MAGIC        a.aggOrder,
# MAGIC        a.startDate,
# MAGIC        a.endDate,
# MAGIC        a.cust_commit,
# MAGIC        a.row_num,
# MAGIC        s.commit_account_group_id
# MAGIC from azure_sub_commit_accounts a
# MAGIC join  subs_commit_account_group_id_vw s on a.date = s.date 
# MAGIC                                        and a.subscription_guid = s.subscription_guid;                                

# COMMAND ----------

# MAGIC %sql
# MAGIC select date, 
# MAGIC        count(*)
# MAGIC from multiple_azure_sub_commit_accounts 
# MAGIC group by 1 

# COMMAND ----------

distinct_commit_group_rows = spark.sql(""" 
                                       select distinct  
                                              --date,
                                              commit_sfdc_account_group_id 
                                       from multiple_azure_sub_commit_accounts """).collect()

# COMMAND ----------

distinct_commit_group_rows_clean = []
for d in distinct_commit_group_rows:
  if len(d.commit_sfdc_account_group_id) > 250:
    print(d.commit_sfdc_account_group_id) 
    
  distinct_commit_group_rows_clean.append(d)

# COMMAND ----------

print(len(distinct_commit_group_rows), len(distinct_commit_group_rows_clean))

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view multiple_commit_accounts
# MAGIC as
# MAGIC with min_start_dates (
# MAGIC select commit_sfdc_account_group_id,
# MAGIC        min(startDate) min_start_date,
# MAGIC        collect_set(sfdcAccountId) sfdcAccountId_group
# MAGIC from azure_sub_commit_accounts_enhanced_parallel
# MAGIC group by 1
# MAGIC ),
# MAGIC
# MAGIC dedup_min_start_dates (
# MAGIC select explode(sfdcAccountId_group) sfdcAccountId,
# MAGIC        min_start_date
# MAGIC from min_start_dates
# MAGIC ),
# MAGIC
# MAGIC account_min_start_dates (
# MAGIC select sfdcAccountId, 
# MAGIC        min(min_start_date) min_start_date 
# MAGIC from dedup_min_start_dates
# MAGIC group by 1 
# MAGIC )
# MAGIC
# MAGIC select distinct 
# MAGIC        c.subscription_guid,
# MAGIC        m.min_start_date
# MAGIC from cra_final_mapping_vw c 
# MAGIC join account_min_start_dates m on c.commit_sfdc_account_id = m.sfdcAccountId

# COMMAND ----------

# MAGIC %md
# MAGIC #### (cursor) azure_sub_multiple_commit_consumption

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view azure_sub_multiple_commit_consumption
# MAGIC as
# MAGIC
# MAGIC with 
# MAGIC sub_commit_group_dim_1 (
# MAGIC select distinct 
# MAGIC                 subscription_guid,
# MAGIC                 commit_sfdc_account_group_id
# MAGIC from azure_sub_commit_accounts_enhanced_parallel
# MAGIC where date = '2023-08-31'
# MAGIC ),
# MAGIC
# MAGIC sub_commit_group_dim_2 (
# MAGIC select distinct date,
# MAGIC                 subscription_guid,
# MAGIC                 commit_sfdc_account_group_id
# MAGIC from azure_sub_commit_accounts_enhanced_parallel
# MAGIC where date > '2023-08-31'
# MAGIC ),
# MAGIC
# MAGIC fin_base (
# MAGIC select 
# MAGIC        concat(f.date, '-', f.azureSubId, '-', f.accountId) usage_key,
# MAGIC        f.accountId,
# MAGIC        f.date,
# MAGIC        f.platform,
# MAGIC        f.azureSubID,
# MAGIC        TPID,
# MAGIC        enrollmentNumber,
# MAGIC        f.tpid_enr_key,        
# MAGIC        f.dbu,
# MAGIC        f.dbu_price,
# MAGIC        f.revShareDollars,
# MAGIC        f.custDollars
# MAGIC from fin_cra_mapping_usage_base f 
# MAGIC join multiple_commit_accounts m on f.azureSubID = m.subscription_guid and f.date >= m.min_start_date
# MAGIC where f.platform = 'azure'
# MAGIC ),
# MAGIC
# MAGIC parallel_1 (
# MAGIC select coalesce(s.commit_sfdc_account_group_id, 'MTM') commit_sfdc_account_group_id,
# MAGIC        f.*
# MAGIC from fin_base f 
# MAGIC left join sub_commit_group_dim_1 s on f.azureSubId = s.subscription_guid 
# MAGIC where f.date <= '2023-08-31'
# MAGIC ),
# MAGIC
# MAGIC parallel_2 (
# MAGIC select coalesce(s.commit_sfdc_account_group_id, 'MTM') commit_sfdc_account_group_id,
# MAGIC        f.*
# MAGIC from fin_base f 
# MAGIC left join sub_commit_group_dim_2 s on f.azureSubId = s.subscription_guid 
# MAGIC                                   and f.date = s.date
# MAGIC where f.date >= '2023-09-01'                                 
# MAGIC )
# MAGIC
# MAGIC select distinct *
# MAGIC from parallel_1 
# MAGIC union 
# MAGIC select distinct *
# MAGIC from parallel_2

# COMMAND ----------

# MAGIC %md
# MAGIC #### parallel consumption set up

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view commit_account_group_orders
# MAGIC as
# MAGIC select  distinct 
# MAGIC         s.commit_account_group_id,
# MAGIC         a.sfdcAccountId,
# MAGIC         a.aggOrder,
# MAGIC         a.aggorder_key,
# MAGIC         a.startDate,
# MAGIC         a.endDate,
# MAGIC         a.cust_commit,
# MAGIC         a.flex_commit,
# MAGIC         0 rolling_sum
# MAGIC from azure_sub_commit_accounts a 
# MAGIC join subs_commit_account_group_id_vw s on a.date = s.date and a.subscription_guid = s.subscription_guid 

# COMMAND ----------

global_commit_account_group_orders = {}

commit_account_group_orders_updated = spark.sql(""" 
                                                select * from commit_account_group_orders
                                                """).collect() 

for row in commit_account_group_orders_updated:

  if row.commit_account_group_id in global_commit_account_group_orders:
    global_commit_account_group_orders[row.commit_account_group_id].append(row)
  else:
    global_commit_account_group_orders[row.commit_account_group_id] = [row]

# COMMAND ----------

azure_sub_local_rows_account_map_updated = {}

multiple_azure_sub_commit_accounts_rows_updated = spark.sql(""" 

select  s.commit_account_group_id,
        a.date,
        a.subscription_guid,
        a.sfdcAccountId,
        a.aggOrder,
        a.aggorder_key,
        a.startDate,
        a.endDate,
        a.cust_commit,
        a.flex_commit,
        0 rolling_sum,
        a.row_num,
        count(a.aggOrder) over(partition by a.date, a.subscription_guid) order_count
from azure_sub_commit_accounts a 
join subs_commit_account_group_id_vw s on a.date = s.date and a.subscription_guid = s.subscription_guid 

""").collect()                                                     

for row in multiple_azure_sub_commit_accounts_rows_updated:

  if row.commit_account_group_id in azure_sub_local_rows_account_map_updated:
    azure_sub_local_rows_account_map_updated[row.commit_account_group_id].append(row)
  else:
    azure_sub_local_rows_account_map_updated[row.commit_account_group_id] = [row]

# COMMAND ----------

azure_sub_multiple_commit_consumption_rows = spark.sql(""" 
                                                       select *, 
                                                              False as is_contracted 
                                                       from azure_sub_multiple_commit_consumption order by date, custDollars 
                                                      """).collect()

# COMMAND ----------

# set master consumption for all commit groups
azure_sub_multiple_commit_consumption_rows_master = {}
for usage_row in azure_sub_multiple_commit_consumption_rows:
  if usage_row.commit_sfdc_account_group_id in azure_sub_multiple_commit_consumption_rows_master:
    azure_sub_multiple_commit_consumption_rows_master[usage_row.commit_sfdc_account_group_id].append(usage_row)
  else:
    azure_sub_multiple_commit_consumption_rows_master[usage_row.commit_sfdc_account_group_id] = [usage_row]

# COMMAND ----------

check_sum_t = 0
for k in azure_sub_multiple_commit_consumption_rows_master.keys():
  check_sum_t += len(azure_sub_multiple_commit_consumption_rows_master[k])

print(check_sum_t)

# COMMAND ----------

check_sum = 0

for d in sorted(distinct_commit_group_rows_clean):
  #print(check_sum, '--->' ,d.commit_sfdc_account_group_id)
  if d.commit_sfdc_account_group_id in azure_sub_multiple_commit_consumption_rows_master:
    check_sum += len(azure_sub_multiple_commit_consumption_rows_master[d.commit_sfdc_account_group_id])
  else:
    print(d.commit_sfdc_account_group_id)
print(check_sum)

# COMMAND ----------

azure_base_consumption_contract_rows = []

global_aggorder_rolling_sum = {}
usage_key_map = {}


for d in distinct_commit_group_rows_clean:

  print('processing..', d.commit_sfdc_account_group_id)

  if d.commit_sfdc_account_group_id in azure_sub_multiple_commit_consumption_rows_master:
    azure_sub_multiple_commit_consumption_rows_t = \
     azure_sub_multiple_commit_consumption_rows_master[d.commit_sfdc_account_group_id]
  else:
    azure_sub_multiple_commit_consumption_rows_t = []
  


  global_orders = [item.asDict() \
                      for item in global_commit_account_group_orders[d.commit_sfdc_account_group_id]] 

  for global_order in global_orders:
    if global_order['aggorder_key'] not in global_aggorder_rolling_sum:
      global_aggorder_rolling_sum[global_order['aggorder_key']] = 0
  
  possible_orders = [item.asDict() \
                      for item in azure_sub_local_rows_account_map_updated[d.commit_sfdc_account_group_id]]

  possible_orders_sub = {}

  for sub_order in possible_orders:
    key = sub_order['date'] + sub_order['subscription_guid']
    if key in possible_orders_sub:
      possible_orders_sub[key].append(sub_order)
    else:
      possible_orders_sub[key] = [sub_order]

  date_wise_azure_sub_multiple_commit_consumption_rows = {}

  for consumption_row in azure_sub_multiple_commit_consumption_rows_t:
    if consumption_row.date in date_wise_azure_sub_multiple_commit_consumption_rows:
      date_wise_azure_sub_multiple_commit_consumption_rows[consumption_row.date].append(consumption_row)
    else:
      date_wise_azure_sub_multiple_commit_consumption_rows[consumption_row.date] = [consumption_row]

  
  for usage_date in sorted(date_wise_azure_sub_multiple_commit_consumption_rows.keys()):
    date_consumption = date_wise_azure_sub_multiple_commit_consumption_rows[usage_date]
    for idx, c in enumerate(date_consumption):
      c_r = c.asDict()
      c_r['is_contracted'] = False 
      c_r['is_own_commit'] = False
      c_r['aggOrder'] = None 
      c_r['aggorder_key'] = None
      c_r['usage_key'] = c_r['date'] + '-' + c_r['accountId'] + '-' + c_r['azureSubID']
      is_own_commit = False  

      order_sub_key = '2023-08-31' + c_r['azureSubID'] if c_r['date'] <= '2023-08-31' else \
                      c_r['date'] + c_r['azureSubID']
      local_orders = possible_orders_sub[order_sub_key] if order_sub_key in possible_orders_sub else []

      if len(local_orders) == 1:
          local_order = local_orders[0]
          if global_aggorder_rolling_sum[local_order['aggorder_key']] < local_order['cust_commit'] \
             and c_r['date'] >= local_order['startDate'] and c_r['date'] <= local_order['endDate']:
            
            global_aggorder_rolling_sum[local_order['aggorder_key']] += c.custDollars
            c_r['aggOrder'] = local_order['aggOrder']
            c_r['aggorder_key'] = local_order['aggorder_key'] 
          else:
            c_r['aggOrder'] = 'MTMAzure' + c.accountId
            c_r['aggorder_key'] = 'MTMAzure' + c.accountId 

          if c_r['usage_key'] not in usage_key_map:
            usage_key_map[c_r['usage_key']] = c_r      
      else:
          for local_order in local_orders:
            if c_r['is_contracted'] and c_r['is_own_commit']:
              break
            else:
              if global_aggorder_rolling_sum[local_order['aggorder_key']] < local_order['cust_commit'] \
                and c_r['date'] >= local_order['startDate'] and c_r['date'] <= local_order['endDate']:
                 
                  if not c_r['is_contracted']:
                    c_r['aggOrder'] = local_order['aggOrder']
                    c_r['aggorder_key'] = local_order['aggorder_key'] 
                    c_r['is_contracted'] = True

                  if c.accountId == local_order['sfdcAccountId']:
                    c_r['is_own_commit'] = True
                    c_r['aggOrder'] = local_order['aggOrder']
                    c_r['aggorder_key'] = local_order['aggorder_key']

          if c_r['aggorder_key'] is None:
            c_r['aggOrder'] = 'MTMAzure' + c_r['accountId']
            c_r['aggorder_key'] = 'MTMAzure' + c_r['accountId']
          else:
            global_aggorder_rolling_sum[c_r['aggorder_key']] += c_r['custDollars']
          
          if c_r['usage_key'] not in usage_key_map:
            usage_key_map[c_r['usage_key']] = c_r 

# COMMAND ----------

azure_base_consumption_contract_rows = []

for usage_key, contracted_usage in usage_key_map.items():
  azure_base_consumption_contract_rows.append(contracted_usage)

# COMMAND ----------

len(azure_base_consumption_contract_rows)

# COMMAND ----------

azure_sub_multiple_commit_consumption_azure = spark.createDataFrame(azure_base_consumption_contract_rows)
azure_sub_multiple_commit_consumption_azure.createOrReplaceTempView('azure_sub_multiple_commit_consumption_azure')

# COMMAND ----------

azure_sub_multiple_commit_consumption_azure_imputed = \
spark.sql(""" 
            select * except(aggOrder),
                   coalesce(aggOrder, concat('MTMAzure', accountId)) aggOrder
            from azure_sub_multiple_commit_consumption_azure 
         """)

# COMMAND ----------

# MAGIC %md
# MAGIC #### write to intermediate table

# COMMAND ----------

azure_sub_multiple_commit_consumption_azure_imputed\
                                     .write\
                                     .option("overwriteSchema", "true")\
                                     .format("delta")\
                                     .mode("overwrite")\
                                     .saveAsTable(royalty_azure_sub_multiple_commit_consumption_azure)

# COMMAND ----------

# MAGIC %md
# MAGIC #### universal commits

# COMMAND ----------

spark.sql(f""" 
create or replace temp view universal_commits
as
select sfdcAccountId,
       UniversalOrder,
       sum(DBShareCommit + coterm_commit) universalCommit
from {cra_orders_base_ub}
where aggOrder not like '%COMPLIMENTARY%'
and aggOrder not like '%CO-TERM%'  
group by sfdcAccountId, 
         UniversalOrder
""")         

# COMMAND ----------

# MAGIC %md
# MAGIC #### split aggorders by cloud

# COMMAND ----------

spark.sql(f""" 
create or replace temp view aggorders_azure_only
as
select l.aggorder_key,
       l.UniversalOrder,
       l.sfdcAccountId commit_sfdc_account_id,
       l.sfdcAccountName,
       l.AggOrder,
       l.flexOrder,
       r.aggorder_key flex_aggorder_key,
       case when r1.complimentary_usage is null then null 
            else l.complimentary_order 
            end complimentary_order,
       case when r2.aggOrder is null then null 
            else r2.aggOrder 
            end coterm_order,
       l.sfdcAccountId,
       l.Platform,
       l.contract_id,
       l.order_id,
       l.renewal_opportunity,
       l.startDate,
       l.endDate,
       l.cloudPartnerPurchase,
       l.ActualPartnerCommit,
       l.DBShareCommit,
       case when r.AggOrder is not null then coalesce(r.available_commit, r.actualPartnerCommit) else 0 end flexCommit,
       coalesce(u.universalCommit +  coalesce(r2.DBShareCommit, 0), l.universalCommit +  coalesce(r2.DBShareCommit, 0)) universalCommit,
       coalesce(r1.complimentary_usage, 0) complimentary_usage,
       coalesce(r2.DBShareCommit, 0) coterm_dbshare_commit,
       r2.startDate coterm_startDate
from orders_base l
left join orders_base r on l.flexOrder = r.AggOrder and l.sfdcAccountId = r.sfdcAccountId
left join universal_commits u on l.UniversalOrder = u.UniversalOrder and l.sfdcAccountId = u.sfdcAccountId
left join orders_base r1 on l.complimentary_order = r1.aggOrder and l.sfdcAccountId = r1.sfdcAccountId
left join orders_base r2 on split_commit_string(l.coterm_order) = split_commit_string(r2.aggOrder) and l.sfdcAccountId = r2.sfdcAccountId
where l.AggOrder not like '%FLEX%'
  and l.AggOrder not like '%COMPLIMENTARY%'
  and l.AggOrder not like '%CO-TERM%'  
order by l.sfdcAccountId, l.startDate
""")

# COMMAND ----------

# flex_only_accounts
spark.sql(f""" 
create or replace temp view flex_only_accounts_aggorders
as
select l.aggorder_key,
       l.UniversalOrder,
       l.sfdcAccountId commit_sfdc_account_id,
       l.sfdcAccountName,
       l.AggOrder,
       l.flexOrder,
       r.aggorder_key flex_aggorder_key,
       case when r1.complimentary_usage is null then null 
            else l.complimentary_order 
            end complimentary_order,
       case when r2.aggOrder is null then null 
            else r2.aggOrder 
            end coterm_order,
       l.sfdcAccountId,
       'azure' Platform,
       l.contract_id,
       l.order_id,
       l.renewal_opportunity,
       l.startDate,
       l.endDate,
       l.cloudPartnerPurchase,
       l.ActualPartnerCommit,
       l.DBShareCommit,
       case when r.AggOrder is not null then coalesce(r.available_commit, r.actualPartnerCommit) else 0 end flexCommit,
       coalesce(u.universalCommit +  coalesce(r2.DBShareCommit, 0), l.universalCommit +  coalesce(r2.DBShareCommit, 0)) universalCommit,
       coalesce(r1.complimentary_usage, 0) complimentary_usage,
       coalesce(r2.DBShareCommit, 0) coterm_dbshare_commit,
       r2.startDate coterm_startDate
from orders_base l
join flex_only_accounts f on l.sfdcAccountId = f.account_id
left join orders_base r on l.flexOrder = r.AggOrder and l.sfdcAccountId = r.sfdcAccountId
left join universal_commits u on l.UniversalOrder = u.UniversalOrder and l.sfdcAccountId = u.sfdcAccountId
left join orders_base r1 on l.complimentary_order = r1.aggOrder and l.sfdcAccountId = r1.sfdcAccountId
left join orders_base r2 on split_commit_string(l.coterm_order) = split_commit_string(r2.aggOrder) and l.sfdcAccountId = r2.sfdcAccountId
order by l.sfdcAccountId, l.startDate
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view aggorders
# MAGIC as 
# MAGIC
# MAGIC select f.*
# MAGIC from flex_only_accounts_aggorders f
# MAGIC left anti join aggorders_azure_only az on f.aggOrder = az.aggOrder
# MAGIC
# MAGIC union all 
# MAGIC
# MAGIC select *
# MAGIC from aggorders_azure_only

# COMMAND ----------

set(spark.table('flex_only_accounts_aggorders').columns).difference(set(spark.table('aggorders_azure_only').columns))

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view azure_aggorders
# MAGIC as
# MAGIC with 
# MAGIC
# MAGIC cra_initial_mapping_curated (
# MAGIC
# MAGIC   select *
# MAGIC   from cra_final_mapping_vw
# MAGIC
# MAGIC ),
# MAGIC
# MAGIC mapping_base (
# MAGIC
# MAGIC select
# MAGIC     date,
# MAGIC     tpid_enr_key,
# MAGIC     subscription_guid,
# MAGIC     tp_id,
# MAGIC     tp_name,
# MAGIC     enrollment_number,
# MAGIC     sfdc_account_id,
# MAGIC     account_name,
# MAGIC     is_commit_account,
# MAGIC     sfdc_account_group,
# MAGIC     sfdc_account_commit_group,
# MAGIC     case when len(revops_commit_account_id) > 0 then revops_commit_account_id 
# MAGIC          else commit_sfdc_account_id 
# MAGIC     end as commit_sfdc_account_id
# MAGIC from cra_initial_mapping_curated  
# MAGIC ),
# MAGIC
# MAGIC distinct_commit_accounts (
# MAGIC   select          date,
# MAGIC                   tpid_enr_key, 
# MAGIC                   sfdc_account_id,
# MAGIC                   subscription_guid,
# MAGIC                   first(commit_sfdc_account_id) commit_sfdc_account_id                
# MAGIC   from mapping_base
# MAGIC   group by all
# MAGIC )
# MAGIC select o.* except(commit_sfdc_account_id),
# MAGIC        d.date,
# MAGIC        d.tpid_enr_key,
# MAGIC        d.subscription_guid,
# MAGIC        d.sfdc_account_id,
# MAGIC        d.commit_sfdc_account_id
# MAGIC from aggorders o
# MAGIC join distinct_commit_accounts d on o.sfdcAccountId = d.commit_sfdc_account_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view universal_commits_fixed
# MAGIC as
# MAGIC select sfdcAccountId,
# MAGIC        UniversalOrder,
# MAGIC        sum(DBShareCommit + coterm_dbshare_commit) universalCommit
# MAGIC from aggorders
# MAGIC where aggOrder not like '%COMPLIMENTARY%'
# MAGIC and aggOrder not like '%CO-TERM%'  
# MAGIC group by sfdcAccountId, UniversalOrder

# COMMAND ----------

spark.sql(f""" 
create or replace temp view azure_prod_consumption_sequenced 
as
with 

base_consumption (
select f.aggOrder,
       f.aggorder_key,
       f.accountId,
       f.date,
       dt.month_end_date,
       f.platform,
       f.azureSubID,
       f.tpid,
       f.enrollmentNumber,
       f.tpid_enr_key,
       f.dbu,
       f.dbu_price,
       coalesce(round(revShareDollars,6),0) revShareDollars,
       coalesce(round(custDollars,6), 0) custDollars
from {royalty_azure_sub_multiple_commit_consumption_azure} f
join {bi_dates_dim} dt on f.date = dt.date
where f.aggOrder is not null
order by f.date
),

order_consumption (
select a.commit_sfdc_account_id,
       a.aggOrder,
       a.dbshareCommit,
       a.complimentary_order,
       a.complimentary_usage,
       a.flexOrder,
       a.flexCommit,
       a.UniversalOrder,
       a.universalCommit,
       a.coterm_order,
       a.coterm_commit coterm_dbshare_commit,
       a.ActualPartnerCommit,
       a.contract_id,
       a.order_id,
       a.renewal_opportunity,
       a.startDate,
       a.endDate,
       case when a.aggOrder like '%CO-TERM%' then a.startDate
            else null
       end as coterm_startDate,
       b.* except(aggOrder, aggorder_key)
from base_consumption b
left join orders_base a on b.aggorder_key = a.aggorder_key
order by date
)


select o.*,
       sum(revShareDollars) over(partition by accountId, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_revshare_dollars,
       sum(custDollars) over(partition by accountId, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_cust_dollars
from order_consumption o
order by date, dbu
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### consumption setup

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view finance_usage_pricing
# MAGIC as
# MAGIC
# MAGIC select f.accountId,
# MAGIC        --f.workspaceId,
# MAGIC        --f.sku,
# MAGIC        f.date,
# MAGIC        f.platform,
# MAGIC        f.azureSubID,
# MAGIC        f.TPID,
# MAGIC        f.enrollmentNumber,
# MAGIC        f.tpid_enr_key,        
# MAGIC        f.dbu,
# MAGIC        f.dbu_price,
# MAGIC        f.revShareDollars,
# MAGIC        f.custDollars
# MAGIC from fin_cra_mapping_usage_base f 
# MAGIC where f.platform = 'azure'

# COMMAND ----------

# MAGIC %md
# MAGIC #### prod consumption

# COMMAND ----------

spark.sql(f""" 
create or replace temp view azure_prod_consumption 
as
with 

aggorder_azure_sub_multiple_commit_consumption (

select *
from {royalty_azure_sub_multiple_commit_consumption_azure}
where aggOrder is not null
),

base_consumption (
select f.accountId,
       f.date,
       dt.month_end_date,
       f.platform,
       f.azureSubID,
       f.tpid,
       f.enrollmentNumber,
       f.tpid_enr_key,
       f.dbu,
       f.dbu_price,
       coalesce(round(f.revShareDollars,6),0) revShareDollars,
       coalesce(round(f.custDollars,6), 0) custDollars
from finance_usage_pricing f
left join aggorder_azure_sub_multiple_commit_consumption b on f.date = b.date
                                                          and f.azureSubId = b.azureSubId
join {bi_dates_dim} dt on f.date = dt.date
where b.azureSubId is null
  and b.date is null
order by f.date
),

order_consumption (

select a.commit_sfdc_account_id,
       a.aggOrder,
       a.dbshareCommit,
       a.complimentary_order,
       a.complimentary_usage,
       a.flexOrder,
       a.flexCommit,
       a.UniversalOrder,
       a.universalCommit,
       a.coterm_order,
       a.coterm_dbshare_commit,
       a.ActualPartnerCommit,
       a.contract_id,
       a.order_id,
       a.renewal_opportunity,
       a.startDate,
       a.endDate,
       a.coterm_startDate,
       b.*
from base_consumption b
join azure_aggorders a on lower(b.platform) = lower(a.Platform) 
                      and b.azureSubId = a.subscription_guid
                      and b.date between a.startDate and a.endDate
where b.date <= "2023-08-31"                      

union 

select a.commit_sfdc_account_id,
       a.aggOrder,
       a.dbshareCommit,
       a.complimentary_order,
       a.complimentary_usage,
       a.flexOrder,
       a.flexCommit,
       a.UniversalOrder,
       a.universalCommit,
       a.coterm_order,
       a.coterm_dbshare_commit,
       a.ActualPartnerCommit,
       a.contract_id,
       a.order_id,
       a.renewal_opportunity,
       a.startDate,
       a.endDate,
       a.coterm_startDate,
       b.*
from base_consumption b
join azure_aggorders a on lower(b.platform) = lower(a.Platform) 
                      and b.azureSubId = a.subscription_guid
                      and b.date = a.date
                      and b.date between a.startDate and a.endDate
where b.date > '2023-08-31'
order by date
)

select o.*,
       sum(revShareDollars) over(partition by accountId, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_revshare_dollars,
       sum(custDollars) over(partition by accountId, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_cust_dollars
from order_consumption o
order by date, dbu
""")

# COMMAND ----------

# MAGIC %md
# MAGIC #### union the non-azure and azure consumption

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view prod_consumption
# MAGIC as
# MAGIC select *
# MAGIC from azure_prod_consumption_sequenced
# MAGIC
# MAGIC union all
# MAGIC
# MAGIC select *
# MAGIC from azure_prod_consumption

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view coterm_corrected_consumption
# MAGIC as
# MAGIC with base (
# MAGIC select   commit_sfdc_account_id,
# MAGIC          case when coterm_startDate <= date and (coterm_order is not null and rolling_sum_revshare_dollars > dbshareCommit) then coterm_order
# MAGIC               else aggOrder end aggOrder,
# MAGIC          dbshareCommit,
# MAGIC          complimentary_usage,
# MAGIC          flexOrder,
# MAGIC          flexCommit,
# MAGIC          universalOrder,
# MAGIC          universalCommit,
# MAGIC          coterm_order,
# MAGIC          coterm_dbshare_commit,
# MAGIC          ActualPartnerCommit,
# MAGIC          accountId,
# MAGIC          contract_id,
# MAGIC          order_id,
# MAGIC          coterm_startDate,
# MAGIC          startDate,
# MAGIC          endDate,
# MAGIC          renewal_opportunity,
# MAGIC          --workspaceId,
# MAGIC          --sku,
# MAGIC          date,
# MAGIC          month_end_date,
# MAGIC          platform,
# MAGIC          azureSubID,
# MAGIC          tpid,
# MAGIC          enrollmentNumber,
# MAGIC          tpid_enr_key,           
# MAGIC          dbu,
# MAGIC          dbu_price,
# MAGIC          revShareDollars,
# MAGIC          custDollars,
# MAGIC          rolling_sum_revshare_dollars,
# MAGIC          rolling_sum_cust_dollars
# MAGIC from prod_consumption --complimentary_corrected_consumption
# MAGIC order by date, dbu
# MAGIC )
# MAGIC
# MAGIC select commit_sfdc_account_id,
# MAGIC        aggorder,
# MAGIC        dbshareCommit,
# MAGIC        complimentary_usage,
# MAGIC        flexOrder,
# MAGIC        flexCommit,
# MAGIC        universalOrder,
# MAGIC        universalCommit,
# MAGIC        coterm_order,
# MAGIC        coterm_dbshare_commit,
# MAGIC        ActualPartnerCommit,
# MAGIC        accountId,
# MAGIC        contract_id,
# MAGIC        order_id,
# MAGIC        coterm_startDate,
# MAGIC        startDate,
# MAGIC        endDate,
# MAGIC        renewal_opportunity,
# MAGIC        --workspaceId,
# MAGIC        --sku,
# MAGIC        date,
# MAGIC        month_end_date,
# MAGIC        platform,
# MAGIC        azureSubID,
# MAGIC        tpid,
# MAGIC        enrollmentNumber,
# MAGIC        tpid_enr_key,         
# MAGIC        dbu,
# MAGIC        dbu_price,
# MAGIC        revShareDollars,
# MAGIC        custDollars,
# MAGIC        sum(revShareDollars) over(partition by accountId, platform, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_revshare_dollars,
# MAGIC        sum(custDollars) over(partition by accountId, platform, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_cust_dollars
# MAGIC
# MAGIC from base
# MAGIC order by date, dbu

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view corrected_order_consumption
# MAGIC as
# MAGIC with base (
# MAGIC select   case when (rolling_sum_cust_dollars <= ActualPartnerCommit or flexCommit = 0) and coterm_order is null then aggOrder
# MAGIC               when (rolling_sum_cust_dollars <= ActualPartnerCommit or flexCommit = 0) and coterm_order is not null then aggOrder 
# MAGIC               else flexOrder
# MAGIC          end as correctedAggorder,
# MAGIC          *
# MAGIC from coterm_corrected_consumption
# MAGIC order by date, dbu
# MAGIC )
# MAGIC
# MAGIC select commit_sfdc_account_id,
# MAGIC        correctedAggorder,
# MAGIC        aggorder,
# MAGIC        dbshareCommit,
# MAGIC        complimentary_usage,
# MAGIC        flexOrder,
# MAGIC        flexCommit,
# MAGIC        universalOrder,
# MAGIC        universalCommit,
# MAGIC        coterm_order,
# MAGIC        coterm_dbshare_commit,       
# MAGIC        ActualPartnerCommit,
# MAGIC        accountId,
# MAGIC        contract_id,
# MAGIC        order_id,
# MAGIC        coterm_startDate,       
# MAGIC        startDate,
# MAGIC        endDate,
# MAGIC        renewal_opportunity,
# MAGIC        --workspaceId,
# MAGIC        --sku,
# MAGIC        date,
# MAGIC        month_end_date,
# MAGIC        platform,
# MAGIC        azureSubID,
# MAGIC        tpid,
# MAGIC        enrollmentNumber,
# MAGIC        tpid_enr_key,         
# MAGIC        dbu,
# MAGIC        dbu_price,
# MAGIC        revShareDollars,
# MAGIC        custDollars,
# MAGIC        rolling_sum_revshare_dollars,
# MAGIC        rolling_sum_cust_dollars,
# MAGIC        sum(revShareDollars) over(partition by accountId, platform, correctedAggorder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) corrected_rolling_sum_cloud_revshare,
# MAGIC        sum(revShareDollars) over(partition by accountId, correctedAggorder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) corrected_rolling_sum_total_revshare,
# MAGIC
# MAGIC        sum(custDollars) over(partition by accountId, platform, correctedAggorder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) corrected_rolling_sum_cloud_cust,
# MAGIC        sum(custDollars) over(partition by accountId, correctedAggorder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) corrected_rolling_sum_total_cust
# MAGIC
# MAGIC from base
# MAGIC order by date, dbu

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view burn_consumption
# MAGIC as
# MAGIC select *,
# MAGIC        case when correctedAggorder not like '%FLEX%' and correctedAggorder not like '%COMPLIMENTARY%'  then corrected_rolling_sum_cloud_revshare / dbShareCommit * 100
# MAGIC             when correctedAggorder like '%COMPLIMENTARY%' then corrected_rolling_sum_cloud_revshare / complimentary_usage * 100
# MAGIC             when correctedAggorder like '%CO-TERM%' then corrected_rolling_sum_cloud_revshare / coterm_dbshare_commit * 100            
# MAGIC             else 0 end burn,
# MAGIC        case when correctedAggorder like '%FLEX%' then corrected_rolling_sum_cloud_revshare / flexCommit * 100
# MAGIC             else 0 end cloudFlexBurn,
# MAGIC        case when correctedAggorder like '%FLEX%' then corrected_rolling_sum_cloud_revshare / flexCommit * 100
# MAGIC             else 0 end FlexBurn            
# MAGIC from corrected_order_consumption

# COMMAND ----------

# MAGIC %md
# MAGIC #### write to consumption table

# COMMAND ----------

burn_consumption = spark.sql(""" select b.* 
                                 from burn_consumption b 
                                 """)

# COMMAND ----------

cra_royalty_consumption_daily

# COMMAND ----------

#daily_royalty_location = '/mnt/bse-dev/cra/royalty_report_burndown'
burn_consumption.write\
                .option("overwriteSchema", "true")\
                .format("delta")\
                .mode("overwrite")\
                .saveAsTable(cra_royalty_consumption_daily)   

# COMMAND ----------

spark.sql(f""" 
create or replace temp view omit_cra_usagec_consumption_daily
as
with base (
select  concat(date, azureSubId, tpid_enr_key, revshareDollars) as unique_key,
        *
from {cra_royalty_consumption_daily}
where accountId = '0016100000d2PbDAAU'
order by date 
),

row_numbered (
select row_number() over(partition by b.unique_key order by aggOrder) row_num, 
b.*
from base b
join (select unique_key, count(*) from base group by unique_key having count(*) > 1) t on b.unique_key = t.unique_key
order by date
)

select *
from row_numbered 
where row_num = 2
""")

# COMMAND ----------

spark.sql(f""" 
create or replace temp view deduped_cra_usagec_daily
as 
select *
from {cra_royalty_consumption_daily} b
left anti join omit_cra_usagec_consumption_daily o on b.date = o.date and b.aggorder = o.aggOrder
""")

# COMMAND ----------

deduped_cra_usagec_daily_df = spark.table('deduped_cra_usagec_daily')
deduped_cra_usagec_daily_df.write\
                           .option("overwriteSchema", "true")\
                           .format("delta")\
                           .mode("overwrite")\
                           .saveAsTable(cra_royalty_consumption_daily)
