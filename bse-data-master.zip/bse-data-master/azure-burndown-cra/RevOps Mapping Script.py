# Databricks notebook source
# MAGIC %md
# MAGIC #### updates the main.it_consumption_silver.cra_final_mapping based on updates from revops_update_commits

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text('environment', 'dev')

# COMMAND ----------

environment = dbutils.widgets.getArgument('environment')
print(environment)

# COMMAND ----------

mapping_table = 'main.it_cra_silver.cra_final_mapping'
revops_update_table = 'main.it_cra_fin_silver.revops_update_commits'

# COMMAND ----------

display(
spark.sql(f""" 
          select *
          from {revops_update_table}
          """)
)

# COMMAND ----------

# MAGIC %sql
# MAGIC select RevOps_Commit_Account_ID, count(*)
# MAGIC from main.it_cra_fin_silver.revops_update_commits
# MAGIC group by all

# COMMAND ----------

update_merge_query = f"""

with
base (
select  
       subscription_guid,
       revops_commit_account_id,
       revops_update_start_date,
       revops_update_end_date,
       row_number() over(partition by subscription_guid order by revops_update_end_date desc) rno
from {revops_update_table}
),

updates (

select *
from base
where rno = 1

)

MERGE INTO {mapping_table} orig
USING updates up
ON orig.subscription_guid =  up.subscription_guid
   and orig.date between up.revops_update_start_date and up.revops_update_end_date
WHEN MATCHED THEN
  UPDATE SET orig.revops_commit_account_id = up.revops_commit_account_id
"""

# COMMAND ----------

display(spark.sql(update_merge_query))
