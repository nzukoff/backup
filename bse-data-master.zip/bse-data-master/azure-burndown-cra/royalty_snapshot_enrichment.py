# Databricks notebook source
# MAGIC %md
# MAGIC #### Set up

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("catalog", "")
dbutils.widgets.text("data_schema", "")

catalog = dbutils.widgets.getArgument('catalog')
data_schema = dbutils.widgets.getArgument('data_schema')

# COMMAND ----------

royalty_report_daily_attribution_table = f'{catalog}.{data_schema}.royalty_report_daily_attribution'
royalty_report_daily_attribution_table_enriched =f'{catalog}.{data_schema}.royalty_report_daily_attribution_enriched'

orders_base_table = f'{catalog}.{data_schema}.cra_orders_base_ub_latest'
next_available_orders_base_table = f'{catalog}.{data_schema}.next_available_orders_base_ub_latest'

bi_dates_dim = 'main.it_core_dim.bi_dates'

# COMMAND ----------

print(royalty_report_daily_attribution_table, royalty_report_daily_attribution_table_enriched)

# COMMAND ----------

@udf('double')
def min_value(col1, col2):
  return min(col1, col2)

spark.udf.register('min_value', min_value)

# COMMAND ----------

import copy

# COMMAND ----------

def fix_consumption_rows_accurate_split(next_available_order_rows,
                                        fix_royalty_snapshot_rows,
                                        debug=False):
    """
    next_available_order_rows: the available orders
    fix_royalty_snapshot_rows: the consumption rows that need to be fixed for accuracy
    """
    # build agg-order lookup for to-be-fixed rows
    aggorder_fix_royalty_snapshot_rows = {}
    for row in fix_royalty_snapshot_rows:
      r = row.asDict()
      if row.aggOrder in aggorder_fix_royalty_snapshot_rows:
        aggorder_fix_royalty_snapshot_rows[row.aggOrder].append(r)
      else:
        aggorder_fix_royalty_snapshot_rows[row.aggOrder] = [r]
    
    if debug:
      print('number of aggorders to be fixed: ', len(aggorder_fix_royalty_snapshot_rows.keys()))
      
    check_count = 0
    for k in aggorder_fix_royalty_snapshot_rows:
      check_count += len(aggorder_fix_royalty_snapshot_rows[k])
    print(check_count)  

    aggorder_lookup = {}
    for available_order in next_available_order_rows:
      available_ = available_order.asDict()
      key = available_['accountId'] + available_['azureSubId'] + available_['aggOrder']
      if key in aggorder_lookup:
        aggorder_lookup[key].append(available_)
      else:
        aggorder_lookup[key] = [available_]

    row_counter = 0
    fixed_consumption_rows = []

    for aggOrder_t in aggorder_fix_royalty_snapshot_rows.keys():

      fix_aggorder_consumption_t = aggorder_fix_royalty_snapshot_rows[aggOrder_t]

      if debug:
        print(aggOrder_t, row_counter, 'len: ', len(fix_aggorder_consumption_t))

      for idx, rec in enumerate(fix_aggorder_consumption_t):
        # find the valid order
        key = rec['accountId'] + rec['azureSubId'] + rec['aggOrder']
        available_orders = aggorder_lookup[key] if key in aggorder_lookup else []
        valid_order = None 
        for order in available_orders:
          if rec['date'] >= order['startDate'] and \
            rec['date'] <= order['endDate']:
              valid_order = order
              break   

        if idx == 0:
          ex = copy.deepcopy(rec)
          quantity_dollar_factor = 0 if ex['usage_cust_dollars'] == 0 else ex['usage_quantity'] / ex['usage_cust_dollars'] 
          ex['usage_cust_dollars'] = ex['usage_cust_dollars'] - ex['overage']
          ex['usage_quantity'] = quantity_dollar_factor * ex['usage_cust_dollars']
          ex['rolling_sum_dollars'] = ex['rolling_sum_dollars'] - ex['overage']
          ex['overage'] = 0.0
          fixed_consumption_rows.append(ex)

          new = copy.deepcopy(rec)
          new['aggOrder'] = valid_order['aggOrder_next'] if valid_order is not None else 'MTMAzure' + new['accountId']
          new['cust_commit'] = valid_order['cust_commit'] if valid_order is not None else 0.0
          new['usage_cust_dollars'] = new['overage']
          new['usage_quantity'] = quantity_dollar_factor * new['overage']
          new['overage'] = 0.0
          new['rolling_sum_dollars'] = 0.0
          fixed_consumption_rows.append(new)
        else:
          new = copy.deepcopy(rec)
          new['aggOrder'] = valid_order['aggOrder_next'] if valid_order is not None else 'MTMAzure' + new['accountId']
          new['cust_commit'] = valid_order['cust_commit'] if valid_order is not None else 0.0
          new['overage'] = 0.0
          new['rolling_sum_dollars'] = 0.0
          fixed_consumption_rows.append(new)
        
        row_counter += len(fix_aggorder_consumption_t)
        
        # if debug:
        #   print('processed..', len(fixed_consumption_rows))       


    if debug:
      print('returning.. ', len(fixed_consumption_rows))

    return fixed_consumption_rows

# COMMAND ----------

def iterate_through_runtime_for_voilations_royalty_1(royalty_report_daily_attribution_table, 
 royalty_report_daily_attribution_table_enriched, 
 debug=False):
  """
  fixes all the voilations in the royalty
  """

  #iteration-1
  spark.sql(f""" 
        create or replace temp view aggorders_100_burn_percentage
        as
        with aggorders_100_burn_percentage_base_ (
        select    
              coalesce(aggOrder, concat('MTMAzure', accountId)) aggOrder,
              sum(cust_dollars) total_snap_cust_dollars,
              max(cust_commit) cust_commit
        from {royalty_report_daily_attribution_table} b
        where platform = 'azure'
        and aggOrder not like 'MTM%'
        group by all
        )

        select distinct aggOrder
        from aggorders_100_burn_percentage_base_
        where total_snap_cust_dollars > cust_commit
  """)

  # next available orders
  spark.sql(f""" 
          create or replace temp view next_available_orders_true_up
          as
          with base (
          select accountId,
                aggOrder, 
                azureSubId,
                min(date) min_usage_date,
                max(date) max_usage_date
          from {royalty_report_daily_attribution_table}
          where aggOrder not like 'MTM%' 
          group by all 
          order by 1,2
          ),

          base1 (
          select accountId,
                aggOrder,
                azureSubId,
                min_usage_date,
                max_usage_date,
                lead(aggOrder) over(partition by azureSubId order by max_usage_date) aggOrder_next
          from base 
          ),

          base2 (
          select distinct 
                accountId,
                aggOrder,
                azureSubId,
                aggOrder_next
                --max_usage_date
          from base1
          ),

          base3 (
          select b.accountId,
                b.azureSubId,
                --b.max_usage_date,
                b.aggOrder,
                b.aggOrder_next,
                o.ActualPartnerCommit cust_commit,
                cast(o.startDate as string) startDate,
                cast(o.endDate as string) endDate
                --coalesce(b.aggOrder_next, concat('MTMAzure', b.accountId)) aggOrder_next,
                --coalesce(o.ActualPartnerCommit, 0) cust_commit,
                --coalesce(cast(o.startDate as string), '2001-01-01') startDate,
                --coalesce(cast(o.endDate as string), '2050-01-01') endDate
          from base2 b 
          left join {orders_base_table} o on b.aggOrder_next = o.aggOrder
          ),
          
          base4 (
          select 
                b.accountId,
                b.azureSubId,
                b.aggOrder,
                b.aggOrder_next aggOrder_next_orig,

                case when b.aggOrder = b.aggOrder_next then n.aggOrder_next
                     else coalesce(b.aggOrder_next, n.aggOrder_next) 
                end as aggOrder_next,

                case when b.aggOrder = b.aggOrder_next then n.cust_commit
                     else coalesce(b.cust_commit, n.cust_commit) 
                end as cust_commit,

                case when b.aggOrder = b.aggOrder_next then n.startDate 
                     else coalesce(b.startDate, n.startDate) 
                end as startDate,

                case when b.aggOrder = b.aggOrder_next then n.endDate
                     else coalesce(b.endDate, n.endDate) 
                end as endDate
          from base3 b
          left join {next_available_orders_base_table} n on b.aggOrder = n.aggOrder 
          )

          select 
                accountId,
                azureSubId,
                aggOrder,
                aggOrder_next_orig,

                case when aggOrder = aggOrder_next then concat('MTMAzure', accountId)
                     else aggOrder_next 
                end as aggOrder_next,

                case when aggOrder = aggOrder_next then 0.0
                     else cust_commit
                end as cust_commit,

                case when aggOrder = aggOrder_next then '2001-01-01' 
                     else startDate
                end as startDate,

                case when aggOrder = aggOrder_next then '2050-01-01' 
                     else endDate 
                end as endDate
          from base4

  """) 

  # enhanced 100% aggorders
  spark.sql(f""" 
        create or replace temp view aggorders_100_burn_percentage_enhanced
        as
          select 
                r.aggOrder,
                n.aggOrder_next,
                n.azureSubId azureSubId_next,
                n.cust_commit cust_commit_next,
                n.startDate,
                n.endDate
          from aggorders_100_burn_percentage r 
          left join next_available_orders_true_up n on r.aggOrder = n.aggOrder
  """) 

  spark.sql(f""" 
      create or replace temp view daily_attribution_enhanced
      as
      with 
      base_1 (
        select 
              date,
              accountId,
              aggOrder,
              azureSubId,
              cust_dollars as usage_cust_dollars,
              dbu as usage_quantity,
              --usage_cust_dollars,
              --usage_quantity,
              cust_commit
        from  {royalty_report_daily_attribution_table}
      ),

      base_2 (
        select *,
              sum(usage_cust_dollars) over(partition by aggOrder order by date, usage_cust_dollars) rolling_sum_dollars,
              count(aggOrder) over(partition by aggOrder order by date, usage_cust_dollars) rolling_sum_seq_no,
              row_number() over(partition by aggOrder order by date, usage_cust_dollars) row_number_seq_no 
        from base_1
      )

      select *,
              case when rolling_sum_dollars > cust_commit then min_value( (rolling_sum_dollars - cust_commit), usage_cust_dollars)
                else 0
              end as overage
      from base_2
  """)


  # existing fix
  spark.sql(""" 
      create or replace temp view fix_daily_attribution_enhanced
      as
      select *,
             usage_quantity orig_usage_quantity
      from daily_attribution_enhanced  
      where 1=1
      and overage > 0
      and cust_commit > 0
  """)

  next_available_order_rows = \
                  spark.sql("""
                            select * 
                            from next_available_orders_true_up
                            """).collect()

  fix_royalty_snapshot_rows = spark.sql(""" 
                                        select * 
                                        from fix_daily_attribution_enhanced 
                                        """).collect()

  print(len(fix_royalty_snapshot_rows))

  fixed_consumption_rows_month = \
  fix_consumption_rows_accurate_split(next_available_order_rows,
                                      fix_royalty_snapshot_rows, debug=debug)

  if len(fixed_consumption_rows_month) == 0:
          spark.sql(""" 
                    create or replace temp view fixed_consumption_month
                    as 
                    select * from fix_daily_attribution_enhanced
                    """) 
  else:
        fixed_consumption = spark.createDataFrame(fixed_consumption_rows_month)
        fixed_consumption.createOrReplaceTempView('fixed_consumption_month') 


  spark.sql(f""" 
      create or replace temp view daily_attribution_fix
      as
      with base (
      select b.date,
            b.accountId,
            b.aggOrder,
            b.azureSubId,
            b.usage_cust_dollars,
            b.usage_quantity,
            b.cust_commit
      from daily_attribution_enhanced b 
      left anti join fix_daily_attribution_enhanced f on b.date = f.date
                                                  and b.accountId = f.accountId
                                                  and b.azureSubId = f.azureSubId
                                                  and b.rolling_sum_seq_no = f.rolling_sum_seq_no
                                                  and b.row_number_seq_no = f.row_number_seq_no
                                                  --and b.usage_quantity = f.usage_quantity    

      union all 

      select date, 
            accountId,
            coalesce(aggOrder, concat('MTMAzure', accountId)) aggOrder,
            azureSubId,
            usage_cust_dollars,
            usage_quantity,
            cust_commit
      from fixed_consumption_month
      )

      select c.*,
            b.sfdcAccountId commit_sfdc_account_id,
            b.contract_id,
            b.order_id,
            b.startDate,
            b.endDate
      from base c      
      left join {orders_base_table} b on lower(c.aggOrder) = lower(b.aggOrder)           
  """)

  daily_attribution_fix_df = spark.sql(f""" select * from daily_attribution_fix """)

  daily_attribution_fix_df.write\
                          .option("overwriteSchema", "true")\
                          .format("delta")\
                          .mode("overwrite")\
                          .saveAsTable(royalty_report_daily_attribution_table_enriched) 

# COMMAND ----------

def iterate_through_runtime_for_voilations_royalty_2(
 royalty_report_daily_attribution_table,
 royalty_report_daily_attribution_table_enriched,
 debug=False):
  """
  fixes all the voilations in the snapshot
  """

  #iteration-2
  spark.sql(f""" 
        create or replace temp view aggorders_100_burn_percentage
        as
        select    
              aggOrder,
              sum(usage_cust_dollars) total_snap_cust_dollars,
              max(cust_commit) cust_commit
        from {royalty_report_daily_attribution_table_enriched} b
        where aggOrder not like 'MTM%'
        group by all
        having total_snap_cust_dollars-cust_commit > 0.00001
  """)

  voilation_count = spark.sql(""" select * from aggorders_100_burn_percentage """).count()
  print('voilation_count :', voilation_count)
  if voilation_count > 0:
    # next available orders
    spark.sql(f""" 
            create or replace temp view next_available_orders_true_up
            as
            with base (
            select accountId,
                  aggOrder, 
                  azureSubId,
                  min(date) min_usage_date,
                  max(date) max_usage_date
            from {royalty_report_daily_attribution_table}
            where aggOrder not like 'MTM%' 
            group by all 
            order by 1,2
            ),

            base1 (
            select accountId,
                  aggOrder,
                  azureSubId,
                  min_usage_date,
                  max_usage_date,
                  lead(aggOrder) over(partition by azureSubId order by max_usage_date) aggOrder_next
            from base 
            ),

            base2 (
            select distinct 
                  accountId,
                  aggOrder,
                  azureSubId,
                  aggOrder_next
                  --max_usage_date
            from base1
            ),

            base3 (
            select b.accountId,
                  b.azureSubId,
                  --b.max_usage_date,
                  b.aggOrder,
                  b.aggOrder_next,
                  o.ActualPartnerCommit cust_commit,
                  cast(o.startDate as string) startDate,
                  cast(o.endDate as string) endDate
                  --coalesce(b.aggOrder_next, concat('MTMAzure', b.accountId)) aggOrder_next,
                  --coalesce(o.ActualPartnerCommit, 0) cust_commit,
                  --coalesce(cast(o.startDate as string), '2001-01-01') startDate,
                  --coalesce(cast(o.endDate as string), '2050-01-01') endDate
            from base2 b 
            left join {orders_base_table} o on b.aggOrder_next = o.aggOrder
            ),
            
            base4 (
            select 
                  b.accountId,
                  b.azureSubId,
                  b.aggOrder,
                  b.aggOrder_next aggOrder_next_orig,

                  case when b.aggOrder = b.aggOrder_next then n.aggOrder_next
                      else coalesce(b.aggOrder_next, n.aggOrder_next) 
                  end as aggOrder_next,

                  case when b.aggOrder = b.aggOrder_next then n.cust_commit
                      else coalesce(b.cust_commit, n.cust_commit) 
                  end as cust_commit,

                  case when b.aggOrder = b.aggOrder_next then n.startDate 
                      else coalesce(b.startDate, n.startDate) 
                  end as startDate,

                  case when b.aggOrder = b.aggOrder_next then n.endDate
                      else coalesce(b.endDate, n.endDate) 
                  end as endDate
            from base3 b
            left join {next_available_orders_base_table} n on b.aggOrder = n.aggOrder 
            )

            select 
                  accountId,
                  azureSubId,
                  aggOrder,
                  aggOrder_next_orig,

                  case when aggOrder = aggOrder_next then concat('MTMAzure', accountId)
                      else aggOrder_next 
                  end as aggOrder_next,

                  case when aggOrder = aggOrder_next then 0.0
                      else cust_commit
                  end as cust_commit,

                  case when aggOrder = aggOrder_next then '2001-01-01' 
                      else startDate
                  end as startDate,

                  case when aggOrder = aggOrder_next then '2050-01-01' 
                      else endDate 
                  end as endDate
            from base4

    """) 

    # enhanced 100% aggorders
    spark.sql(f""" 
          create or replace temp view aggorders_100_burn_percentage_enhanced
          as
            select 
                  r.aggOrder,
                  n.aggOrder_next,
                  n.azureSubId azureSubId_next,
                  n.cust_commit cust_commit_next,
                  n.startDate,
                  n.endDate
            from aggorders_100_burn_percentage r 
            left join next_available_orders_true_up n on r.aggOrder = n.aggOrder
    """) 

    spark.sql(f""" 
        create or replace temp view daily_attribution_enhanced
        as
        with 
        base_1 (
          select 
                date,
                accountId,
                aggOrder,
                azureSubId,
                usage_cust_dollars,
                usage_quantity,
                cust_commit
          from  {royalty_report_daily_attribution_table_enriched}
        ),

        base_2 (
          select *,
                sum(usage_cust_dollars) over(partition by aggOrder order by date, usage_cust_dollars) rolling_sum_dollars,
                count(aggOrder) over(partition by aggOrder order by date, usage_cust_dollars) rolling_sum_seq_no,
                row_number() over(partition by aggOrder order by date, usage_cust_dollars) row_number_seq_no 
          from base_1
        )

        select *,
                case when rolling_sum_dollars > cust_commit then min_value( (rolling_sum_dollars - cust_commit), usage_cust_dollars)
                  else 0
                end as overage
        from base_2
    """)


    # existing fix
    spark.sql(""" 
        create or replace temp view fix_daily_attribution_enhanced
        as
        select *
        from daily_attribution_enhanced  
        where 1=1
        and overage > 0
        and cust_commit > 0
    """)

    next_available_order_rows = \
                    spark.sql("""
                              select * 
                              from next_available_orders_true_up
                              """).collect()

    fix_royalty_snapshot_rows = spark.sql(""" 
                                          select * 
                                          from fix_daily_attribution_enhanced 
                                          """).collect()

    print(len(fix_royalty_snapshot_rows))

    fixed_consumption_rows_month = \
    fix_consumption_rows_accurate_split(next_available_order_rows,
                                        fix_royalty_snapshot_rows, debug=debug)

    if len(fixed_consumption_rows_month) == 0:
            spark.sql(""" 
                      create or replace temp view fixed_consumption_month
                      as 
                      select * from fix_daily_attribution_enhanced
                      """) 
    else:
          fixed_consumption = spark.createDataFrame(fixed_consumption_rows_month)
          fixed_consumption.createOrReplaceTempView('fixed_consumption_month') 


    spark.sql(f""" 
        create or replace temp view daily_attribution_fix
        as
        with base (
        select b.date,
              b.accountId,
              b.aggOrder,
              b.azureSubId,
              b.usage_cust_dollars,
              b.usage_quantity,
              b.cust_commit
        from daily_attribution_enhanced b 
        left anti join fix_daily_attribution_enhanced f on b.date = f.date
                                                    and b.accountId = f.accountId
                                                    and b.azureSubId = f.azureSubId
                                                    and b.rolling_sum_seq_no = f.rolling_sum_seq_no
                                                    and b.row_number_seq_no = f.row_number_seq_no
                                                    --and b.usage_quantity = f.usage_quantity    

        union all 

        select date, 
              accountId,
              coalesce(aggOrder, concat('MTMAzure', accountId)) aggOrder,
              azureSubId,
              usage_cust_dollars,
              usage_quantity,
              cust_commit
        from fixed_consumption_month
        )

        select c.*,
              b.sfdcAccountId commit_sfdc_account_id,
              b.contract_id,
              b.order_id,
              b.startDate,
              b.endDate
        from base c      
        left join {orders_base_table} b on lower(c.aggOrder) = lower(b.aggOrder)           
    """)

    daily_attribution_fix_df = spark.sql(f""" select * from daily_attribution_fix """)

    if not debug:
      daily_attribution_fix_df.write\
                              .option("overwriteSchema", "true")\
                              .format("delta")\
                              .mode("overwrite")\
                              .saveAsTable(royalty_report_daily_attribution_table_enriched)
  else:
    print('skipping..') 

# COMMAND ----------

# MAGIC %md
# MAGIC #### loop royalty fix

# COMMAND ----------

iterate_through_runtime_for_voilations_royalty_1(royalty_report_daily_attribution_table, 
 royalty_report_daily_attribution_table_enriched, 
 debug=False)

# COMMAND ----------

run_counter = 0
while run_counter <= 3:
  print('run counter: ', run_counter+1)
  voilation_count = spark.sql(f""" 
                                    select     
                                        aggOrder,
                                        sum(usage_cust_dollars) total_snap_cust_dollars,
                                        max(cust_commit) cust_commit
                                    from {royalty_report_daily_attribution_table_enriched} b
                                    where aggOrder not like 'MTM%'
                                      group by all
                                      having total_snap_cust_dollars-cust_commit > 0.00001
                                """).count()
  print(voilation_count)                            
  if voilation_count > 0:
      run_counter += 1
      iterate_through_runtime_for_voilations_royalty_2(
      royalty_report_daily_attribution_table,
      royalty_report_daily_attribution_table_enriched,
      debug=False)
  else:
      break 

# COMMAND ----------

display(
spark.sql(f""" 
      select     
          aggOrder,
          sum(usage_cust_dollars) total_snap_cust_dollars,
          max(cust_commit) cust_commit
      from {royalty_report_daily_attribution_table_enriched} b
      where aggOrder not like 'MTM%'
      group by all
      having total_snap_cust_dollars-cust_commit > 0.00001
""")
)
