# Databricks notebook source
@udf('string')
def commit_string(product_code, cpq_order_type):
  """ drops dollar from commit string  """
  commit_string = 'COMMIT'
  if cpq_order_type is None:
    cpq_order_type = ""
  if 'DOLLAR' in product_code and 'co-term' not in cpq_order_type.lower():
    commit_string = product_code.split('-')
    return '-'.join(commit_string[0:len(commit_string)-1])
  
  if 'DOLLAR' in product_code and 'co-term' in cpq_order_type.lower():
    commit_string = product_code.split('-')
    return '-'.join(commit_string[0:len(commit_string)-1]) + '-CO-TERM'
  
  if 'COMPLIMENTARY-USAGE-AWS' in product_code:
    return 'AWS-COMPLIMENTARY'
  
  return commit_string

spark.udf.register("commit_string", commit_string)


@udf('string')
def split_commit_string(order):
  if order is None:
    return None
  else:
    split_string = order.split('-')
    return '-'.join(split_string[0:len(split_string)-1])

spark.udf.register("split_commit_string", split_commit_string)

@udf("double")
def distributeDailyRevShareDollars(revShareDollars, daysinmonth):
  """ returns daily share of a month """
  return revShareDollars/daysinmonth

@udf('string')
def generate_commit_account_group_id(sfdc_account_commit_group):
    """ returns a group-id """
    if sfdc_account_commit_group is not None:
      return '-'.join(sorted(sfdc_account_commit_group))
    return sfdc_account_commit_group
  

spark.udf.register("generate_commit_account_group_id", generate_commit_account_group_id)

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists month_keys;
# MAGIC create temp view month_keys
# MAGIC as
# MAGIC select replace(date, '-', '') month_start_key, 
# MAGIC        month_end_date,
# MAGIC        daysinmonth days_in_month
# MAGIC from main.it_core_dim.bi_dates
# MAGIC where isMonthStart 
# MAGIC order by 1
