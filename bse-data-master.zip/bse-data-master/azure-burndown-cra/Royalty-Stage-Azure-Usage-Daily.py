# Databricks notebook source
# MAGIC %run ./util-functions

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from datetime import datetime

# COMMAND ----------

# MAGIC %md
# MAGIC #### set up

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("catalog", "")
dbutils.widgets.text("data_schema", "")
dbutils.widgets.text("quarter_start_date", "")
dbutils.widgets.text("quarter_end_date", "")

catalog = dbutils.widgets.getArgument('catalog')
data_schema = dbutils.widgets.getArgument('data_schema')
quarter_start_date = dbutils.widgets.getArgument('quarter_start_date')
quarter_end_date = dbutils.widgets.getArgument('quarter_end_date')

# COMMAND ----------

#tables
main_sfdc_bronze_workspace_table = 'main.sfdc_bronze.workspace__c'
main_sfdc_bronze_product2 = 'main.sfdc_bronze.product2'
finance_dbu_dollars_table = 'main.fin_live_gold.dbu_dollars'
msft_royalty_qtrly_total_db_table = 'main.it_msft_silver.msft_royalty_qtrly_total_db'
cpq_aws_gcp_contracts_orders_vw = 'main.it_cpq_silver.cpq_aws_gcp_contracts_orders_vw'
bi_account_dim_table = 'main.it_core_dim.bi_account_dim'

bi_dates_dim = 'main.it_core_dim.bi_dates'
msft_ri_daily = 'main.it_msft_silver.msft_ri_daily'
msft_azure_subscriptions = 'main.data_df_workspaces.azure_subscriptions'

# cra tables
cra_orders_base = f'{catalog}.{data_schema}.cra_orders_base'
cra_final_mapping_table = f'{catalog}.{data_schema}.cra_final_mapping' 

# royalty consumption tables 
royalty_azure_sub_multiple_commit_consumption_azure = f'{catalog}.{data_schema}.azure_sub_multiple_commit_consumption_royalty'
cra_royalty_consumption_daily = f'{catalog}.{data_schema}.royalty_report_consumption_daily'
royalty_report_daily_attribution = f'{catalog}.{data_schema}.royalty_report_daily_attribution'
royalty_dbu_dollars = f'{catalog}.{data_schema}.royalty_dbu_dollars'
royalty_dbu_dollars_mapped = f'{catalog}.{data_schema}.royalty_dbu_dollars_mapped'

#locations
account_subs_ranked_location = '/mnt/bse-dev/test/cra/account_subs_ranked'
cra_orders_base_location = '/mnt/bse-dev/cra/orders_base'
order_consumption_daily_staging_enhanced = '/mnt/bse-dev/cra/order_consumption_daily_staging_enhanced'

# dates
mapping_run_date = datetime.now().strftime('%Y-%m-%d')
incremental_refresh_date_to_be_appended = datetime.now().strftime('%Y-%m-%d')

# COMMAND ----------

spark.sql(f""" 
create or replace temp view cra_final_mapping_vw
as 
select *
from {cra_final_mapping_table} 
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### set up finance consumption

# COMMAND ----------

spark.sql(f""" 
  create or replace temp view sub_rr_consumption_daily_missing 
  as 
  select concat(b.date, b.azureSubId) usage_key,
        b.* 
  from {royalty_dbu_dollars} b  
  left anti join {royalty_dbu_dollars_mapped} d on b.date = d.date and b.azureSubId = d.azureSubId
 """)

# COMMAND ----------

spark.sql(f""" 
          create or replace temp view sub_rr_consumption_daily_t
          as
          select concat(date, azureSubId) usage_key,
                 *
          from {royalty_dbu_dollars_mapped}
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create or replace temp view sub_rr_consumption_daily 
# MAGIC as 
# MAGIC select 'mapped' source,
# MAGIC        usage_key, 
# MAGIC        accountId,
# MAGIC        date, 
# MAGIC        platform, 
# MAGIC        azureSubId,
# MAGIC        TPID, 
# MAGIC        enrollmentNumber,
# MAGIC        tpid_enr_key,
# MAGIC        last_day(date) month_end_date,
# MAGIC        dbu_price,
# MAGIC        custDollars,
# MAGIC        revShareDollars,
# MAGIC        dbu  
# MAGIC from sub_rr_consumption_daily_t 
# MAGIC
# MAGIC union all
# MAGIC
# MAGIC select 'missing' source,
# MAGIC        usage_key, 
# MAGIC        '0013f000005RwT9AAK' accountId,
# MAGIC        --accountId,
# MAGIC        date, 
# MAGIC        platform, 
# MAGIC        azureSubId,
# MAGIC        TPID, 
# MAGIC        enrollmentNumber,
# MAGIC        tpid_enr_key,
# MAGIC        month_end_date,
# MAGIC        dbuPrice dbu_price,
# MAGIC        custDollars,
# MAGIC        revShareDollars,
# MAGIC        dbu  
# MAGIC from sub_rr_consumption_daily_missing

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from month_keys

# COMMAND ----------

# MAGIC %sql
# MAGIC with base (
# MAGIC
# MAGIC select 
# MAGIC        m.month_end_date, r.subscriptionguid, sum(DataBricksRevShare) / 0.85 royalty_dollars
# MAGIC from main.it_msft_silver.msft_royalty_qtrly_total_db r 
# MAGIC join month_keys m on r.billingmonthkey = m.month_start_key
# MAGIC where billingmonthkey = '20240101'
# MAGIC group by all
# MAGIC ),
# MAGIC
# MAGIC base2 (
# MAGIC select last_day(date) month_end_date, azureSubId, sum(custDollars) cust_dollars
# MAGIC from sub_rr_consumption_daily s 
# MAGIC where last_day(date) = '2024-01-31'
# MAGIC group by all 
# MAGIC )
# MAGIC
# MAGIC select b2.* 
# MAGIC from base2 b2
# MAGIC left anti join base b1 on b1.month_end_date = b2.month_end_date and b1.subscriptionguid = b2.azureSubId
# MAGIC order by cust_dollars desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select source,
# MAGIC        last_day(date) royalty_month_end_date,
# MAGIC        sum(custDollars) royalty_cust_dollars
# MAGIC from sub_rr_consumption_daily
# MAGIC group by all
# MAGIC order by 2 desc, 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC        last_day(date) royalty_month_end_date,
# MAGIC        sum(custDollars) royalty_cust_dollars
# MAGIC from sub_rr_consumption_daily
# MAGIC group by all
# MAGIC order by 1 desc

# COMMAND ----------

spark.sql(f""" 
create or replace temp view fin_cra_mapping_usage_base
as
with 

cra_fin_base (
select * except(dbu_price),
       dbu_price dbuPrice
from sub_rr_consumption_daily
)

select accountId,
       date,
       platform,
       azureSubID,
       TPID,
       enrollmentNumber,
       tpid_enr_key,
       sum(dbu) dbu,
       max(dbuPrice) dbuPrice,
       sum(revShareDollars) revShareDollars,
       sum(custDollars) custDollars
from cra_fin_base
group by all
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC        last_day(date) royalty_month_end_date,
# MAGIC        sum(custDollars) royalty_cust_dollars
# MAGIC from fin_cra_mapping_usage_base
# MAGIC group by all
# MAGIC order by 1 desc

# COMMAND ----------

# DBTITLE 1,finance base
# MAGIC %sql
# MAGIC create or replace temp view finance_usage_pricing
# MAGIC as
# MAGIC select f.accountId,
# MAGIC        f.azureSubId,
# MAGIC        f.tpId,
# MAGIC        f.enrollmentNumber,
# MAGIC        f.date,
# MAGIC        f.platform,
# MAGIC        f.dbu,
# MAGIC        f.dbuPrice,
# MAGIC        f.revShareDollars,
# MAGIC        f.custDollars
# MAGIC from fin_cra_mapping_usage_base f
# MAGIC where platform = 'azure'

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view finance_azure_base
# MAGIC as
# MAGIC with base (
# MAGIC select concat(date, azureSubId) usage_key,
# MAGIC        date,
# MAGIC        accountId,
# MAGIC        platform,
# MAGIC        azureSubId,
# MAGIC        tpId,
# MAGIC        enrollmentNumber,
# MAGIC        dbu,
# MAGIC        dbuPrice,
# MAGIC        revShareDollars,
# MAGIC        custDollars
# MAGIC from finance_usage_pricing
# MAGIC )
# MAGIC
# MAGIC select *
# MAGIC from base 
# MAGIC where platform = 'azure'

# COMMAND ----------

# MAGIC %md
# MAGIC ### set up consumption daily

# COMMAND ----------

spark.sql(f""" 
create or replace temp view consumption_daily_base
as
with consumption_daily_base (
select concat(date, azureSubId) usage_key,
       date,
       accountId,
       platform,
       azureSubId,
       tpid,
       enrollmentNumber,
       commit_sfdc_account_id,
       dbu,
       dbu_price dbu_revshare_price,
       custDollars cust_dollars,
       revShareDollars revshare_dollars,
       correctedAggorder aggOrder,
       universalOrder,
       contract_id,
       order_id,
       renewal_opportunity,
       dbShareCommit revshare_commit,
       actualPartnerCommit cust_commit,
       flexCommit flex_commit,
       universalCommit universal_commit,
       startDate start_date,
       endDate end_date
from {cra_royalty_consumption_daily}
where platform = 'azure'
)

select *
from consumption_daily_base
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select last_day(date) royalty_month_end_date,
# MAGIC        sum(cust_dollars) royalty_cust_dollars
# MAGIC from consumption_daily_base
# MAGIC group by all
# MAGIC order by 2 desc, 1

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view consumption_daily_azure
# MAGIC as
# MAGIC with 
# MAGIC commit_base (
# MAGIC select 'commit' as source,
# MAGIC        c.usage_key,
# MAGIC        c.date,
# MAGIC        c.accountId,
# MAGIC        c.platform,
# MAGIC        c.azureSubId,
# MAGIC        c.tpId,
# MAGIC        c.enrollmentNumber,
# MAGIC        c.commit_sfdc_account_id,
# MAGIC        --c.workspaceId,
# MAGIC        --c.sku,
# MAGIC        c.dbu,
# MAGIC        c.dbu_revshare_price,
# MAGIC        c.cust_dollars,
# MAGIC        c.revshare_dollars,
# MAGIC        coalesce(c.aggOrder, concat('MTMAzure', c.accountId)) aggOrder,
# MAGIC        coalesce(c.universalOrder, concat('MTMAzure', c.accountId)) universalOrder,
# MAGIC        c.contract_id,
# MAGIC        c.order_id,
# MAGIC        c.renewal_opportunity,
# MAGIC        c.revshare_commit,
# MAGIC        coalesce(c.cust_commit, 0) cust_commit,
# MAGIC        coalesce(c.flex_commit, 0) flex_commit,
# MAGIC        coalesce(c.universal_commit, 0) universal_commit,
# MAGIC        coalesce(c.start_date, '2016-01-01') start_date,
# MAGIC        coalesce(c.end_date, '2069-12-31') end_date 
# MAGIC from finance_azure_base f 
# MAGIC join consumption_daily_base c on f.usage_key = c.usage_key
# MAGIC order by c.accountId, c.date
# MAGIC ),
# MAGIC
# MAGIC mtm_base (
# MAGIC
# MAGIC select 'mtm' as source,
# MAGIC        f.usage_key,
# MAGIC        f.date,
# MAGIC        f.accountId,
# MAGIC        f.platform,
# MAGIC        f.azureSubId,
# MAGIC        f.tpId,
# MAGIC        f.enrollmentNumber,
# MAGIC        f.accountId commit_sfdc_account_id,       
# MAGIC        --f.workspaceId,
# MAGIC        --f.sku,
# MAGIC        f.dbu,
# MAGIC        f.dbuPrice dbu_revshare_price,
# MAGIC        f.custDollars cust_dollars,
# MAGIC        f.revShareDollars revshare_dollars,
# MAGIC        concat('MTMAzure', f.accountId) aggOrder,
# MAGIC        --null corrected_aggorder,
# MAGIC        concat('MTMAzure', f.accountId) universalOrder,
# MAGIC        null contract_id,
# MAGIC        null order_id,
# MAGIC        null renewal_opportunity,
# MAGIC        0 revshare_commit,
# MAGIC        0 cust_commit,
# MAGIC        0 flex_commit,
# MAGIC        0 universal_commit,
# MAGIC        '2016-01-01' start_date,
# MAGIC        '2069-12-31' end_date
# MAGIC from finance_azure_base f
# MAGIC left anti join consumption_daily_base c on f.usage_key = c.usage_key
# MAGIC )
# MAGIC
# MAGIC select *
# MAGIC from commit_base
# MAGIC union all
# MAGIC select *
# MAGIC from mtm_base

# COMMAND ----------

# MAGIC %sql
# MAGIC select last_day(date) royalty_month_end_date,
# MAGIC        sum(cust_dollars) royalty_cust_dollars
# MAGIC from consumption_daily_azure
# MAGIC group by all
# MAGIC order by 2 desc, 1

# COMMAND ----------

spark.sql(f""" 
create or replace temp view ri_report
as
select sfdcAccountId,
       subscriptionId,
       microsoftTPID msft_tpid,
       enrollment_number,
       purchasePriceDatabricks ri_revshare_commit,
       effectiveStartDate ri_effective_start_date,
       effectiveEndDate ri_effective_end_date,
       processdate process_date
from {msft_ri_daily}
where processdate = (select max(processdate) from {msft_ri_daily})
and includeFlag = 1
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### set up consumption-azure-attribution

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view consumption_azure_daily_attribution
# MAGIC as
# MAGIC with base (
# MAGIC select cda.*,
# MAGIC        r.msft_tpid,
# MAGIC        r.enrollment_number,
# MAGIC        r.ri_revshare_commit,
# MAGIC        r.ri_effective_start_date,
# MAGIC        r.ri_effective_end_date,
# MAGIC        row_number() over(partition by cda.accountId, cda.usage_key order by r.ri_effective_start_date) rno
# MAGIC from consumption_daily_azure cda
# MAGIC left join ri_report r on cda.accountId = r.sfdcAccountId and cda.date between r.ri_effective_start_date and r.ri_effective_end_date
# MAGIC )
# MAGIC
# MAGIC select distinct
# MAGIC        b.*,
# MAGIC        case when aggOrder like '%COMMIT%' then 'DB-Commit'
# MAGIC             when aggOrder like '%MTM%' then 'DB-MTM'
# MAGIC             else 'DB-Unknown'
# MAGIC        end as db_consumption_flag,
# MAGIC        case 
# MAGIC             when msft_tpid is not null and ri_effective_start_date is not null then 'RI-Commit'
# MAGIC             when msft_tpid is null and ri_effective_start_date is null then 'RI-MTM'
# MAGIC             else 'RI-Unknown'
# MAGIC        end as ri_consumption_flag
# MAGIC from base b  
# MAGIC where rno = 1

# COMMAND ----------

# MAGIC %md
# MAGIC ### validate azure daily / finance

# COMMAND ----------

# MAGIC %md
# MAGIC ### add overage to daily consumption

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create or replace temp view consumption_azure_daily_attribution_overage
# MAGIC as
# MAGIC with base (
# MAGIC select  sum(cust_dollars) over(partition by accountId, aggOrder order by date, cust_dollars) rolling_sum,
# MAGIC         row_number() over(partition by accountId, aggOrder order by date, cust_dollars) rolling_sum_number,
# MAGIC         *
# MAGIC from consumption_azure_daily_attribution
# MAGIC )
# MAGIC
# MAGIC select c.usage_key,
# MAGIC        c.date,
# MAGIC        c.accountId,
# MAGIC        c.platform,
# MAGIC        c.azureSubId,
# MAGIC        c.tpId,
# MAGIC        c.enrollmentNumber,
# MAGIC        c.commit_sfdc_account_id,
# MAGIC        c.dbu,
# MAGIC        c.dbu_revshare_price,
# MAGIC        c.cust_dollars,
# MAGIC        c.revshare_dollars,
# MAGIC        c.aggOrder,
# MAGIC        c.universalOrder,
# MAGIC        c.contract_id,
# MAGIC        c.order_id,
# MAGIC        c.renewal_opportunity,
# MAGIC        c.rolling_sum,
# MAGIC        c.revshare_commit,
# MAGIC        (c.rolling_sum/c.cust_commit * 100) burn_percentage,
# MAGIC        case when (c.rolling_sum - c.cust_commit) > 0 and aggOrder like 'AZURE%' then c.rolling_sum - c.cust_commit
# MAGIC             when (c.rolling_sum - c.flex_commit) > 0 and aggOrder like 'FLEX%' then c.rolling_sum - c.flex_commit
# MAGIC             else 0
# MAGIC        end as overage_cust_dollars,
# MAGIC        c.cust_commit,
# MAGIC        c.flex_commit,
# MAGIC        c.universal_commit,
# MAGIC        c.start_date,
# MAGIC        c.end_date,
# MAGIC        c.rolling_sum_number
# MAGIC from base c

# COMMAND ----------

# MAGIC %md
# MAGIC ### aggregated consumption for excess

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view excess_consumption_daily
# MAGIC as
# MAGIC select accountId,
# MAGIC        aggOrder,
# MAGIC        sum(cust_dollars) cust_dollars,
# MAGIC        max(cust_commit) cust_commit,
# MAGIC        max(flex_commit) flex_commit,
# MAGIC        case when aggOrder like 'MTM%' then 0
# MAGIC             when (sum(cust_dollars) - max(cust_commit)) > 0 and aggOrder like 'AZURE%' then  (sum(cust_dollars) - max(cust_commit))
# MAGIC             when (sum(cust_dollars) - max(flex_commit)) > 0 and aggOrder like 'FLEX%' then  (sum(cust_dollars) - max(flex_commit))
# MAGIC             else 0 
# MAGIC        end as excess_consumption,
# MAGIC        max(date) max_usage_date,
# MAGIC        min(date) min_usage_date,
# MAGIC        max(start_date) order_start_date,
# MAGIC        min(rolling_sum_number) min_rolling_sum_number,
# MAGIC        max(rolling_sum_number) max_rolling_sum_number
# MAGIC from consumption_azure_daily_attribution_overage
# MAGIC where aggOrder not like 'MTM%'
# MAGIC group by accountId,
# MAGIC          aggOrder
# MAGIC order by accountId,
# MAGIC          aggOrder 

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view excess_consumption_daily_clean
# MAGIC as
# MAGIC with overlapping_excess_consumption (
# MAGIC select l.accountId l_accountId,
# MAGIC        l.aggOrder l_aggOrder,
# MAGIC        r.aggOrder r_aggOrder,
# MAGIC        l.excess_consumption l_excess_consumption,
# MAGIC        r.excess_consumption r_excess_consumption
# MAGIC from excess_consumption_daily l
# MAGIC full outer join excess_consumption_daily r on l.accountId = r.accountId and l.max_usage_date = r.min_usage_date
# MAGIC )
# MAGIC select e.accountId,
# MAGIC        e.aggOrder,
# MAGIC        e.cust_dollars,
# MAGIC        e.cust_commit,
# MAGIC        e.flex_commit,
# MAGIC        e.max_usage_date,
# MAGIC        e.min_usage_date,
# MAGIC        e.order_start_date,
# MAGIC        e.min_rolling_sum_number,
# MAGIC        e.max_rolling_sum_number,
# MAGIC        case when o.r_aggOrder is null then 0
# MAGIC             else e.excess_consumption
# MAGIC        end as excess_consumption
# MAGIC from excess_consumption_daily e
# MAGIC left join overlapping_excess_consumption o on e.accountId = o.l_accountId and e.aggOrder = o.l_aggOrder

# COMMAND ----------

# MAGIC %md
# MAGIC ### azure contract daily base aggregation

# COMMAND ----------

# MAGIC %md
# MAGIC ### adjusted cust dollars based on excess consumption

# COMMAND ----------

# MAGIC %sql 
# MAGIC create or replace temp view account_contract_daily_base_adjusted as
# MAGIC
# MAGIC select
# MAGIC   b.*,
# MAGIC   case
# MAGIC     when e.excess_consumption > 0
# MAGIC     and e.aggOrder = b.aggOrder 
# MAGIC     and e.max_rolling_sum_number = b.rolling_sum_number then (b.cust_dollars - e.excess_consumption)
# MAGIC     when e.excess_consumption > 0
# MAGIC     and e.aggOrder != b.aggOrder 
# MAGIC     and e.min_rolling_sum_number = b.rolling_sum_number then (b.cust_dollars + e.excess_consumption)
# MAGIC     else b.cust_dollars
# MAGIC   end as adjusted_cust_dollars,
# MAGIC   case
# MAGIC     when e.excess_consumption > 0
# MAGIC     and e.aggOrder = b.aggOrder 
# MAGIC     and e.max_rolling_sum_number = b.rolling_sum_number then ((-1) * e.excess_consumption)
# MAGIC     when e.excess_consumption > 0
# MAGIC     and e.aggOrder != b.aggOrder 
# MAGIC     and e.min_rolling_sum_number = b.rolling_sum_number then (e.excess_consumption)
# MAGIC     else 0
# MAGIC   end as excess_consumption_adjusted,
# MAGIC   case
# MAGIC       when e.excess_consumption > 0
# MAGIC       and e.aggOrder = b.aggOrder 
# MAGIC       and e.max_rolling_sum_number = b.rolling_sum_number then 'case1'
# MAGIC       when e.excess_consumption > 0
# MAGIC       and e.aggOrder != b.aggOrder 
# MAGIC       and e.min_rolling_sum_number = b.rolling_sum_number then 'case2'
# MAGIC       else 'actual'
# MAGIC     end as debug_flag 
# MAGIC from
# MAGIC   consumption_azure_daily_attribution_overage b
# MAGIC   left join excess_consumption_daily_clean e on b.accountId = e.accountId
# MAGIC   and b.date = e.max_usage_date

# COMMAND ----------

# MAGIC %md
# MAGIC ### daily consumption with burn percentage

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view account_contract_daily_burn_down
# MAGIC as
# MAGIC select *,
# MAGIC        sum(adjusted_cust_dollars) over(partition by accountId, aggOrder order by date, cust_dollars) as adjusted_rolling_sum, 
# MAGIC        round(sum(adjusted_cust_dollars) over(partition by accountId, aggOrder order by date, cust_dollars) / cust_commit, 4) * 100 as adjusted_burn_percentage
# MAGIC from account_contract_daily_base_adjusted

# COMMAND ----------

# MAGIC %md
# MAGIC ### write to table `royalty_report_daily_attribution`

# COMMAND ----------

spark.sql(f""" 
create or replace temp view account_contract_daily_burn_down_enhanced
as
select 
        c.usage_key,
        c.date,
        c.accountId,
        a1.accountName account_name,
        c.commit_sfdc_account_id,
        a2.accountName commit_account_name,        
        c.platform,
        lower(c.azureSubId) azureSubId,
        c.tpId,
        c.enrollmentNumber,
        c.dbu,
        c.dbu_revshare_price,
        c.cust_dollars,
        c.revshare_dollars,
        c.aggOrder,
        c.universalOrder,
        c.contract_id,
        c.order_id,
        c.renewal_opportunity,
        c.rolling_sum rolling_sum_cust_dollars,
        c.revshare_commit,
        c.burn_percentage,
        c.overage_cust_dollars,
        c.cust_commit,
        c.flex_commit,
        c.universal_commit,
        c.start_date,
        c.end_date,
        c.adjusted_cust_dollars,
        c.adjusted_rolling_sum adjusted_rolling_sum_cust_dollars,
        c.adjusted_burn_percentage
from account_contract_daily_burn_down c 
left join {bi_account_dim_table} a1 on c.accountId = a1.AccountID 
left join {bi_account_dim_table} a2 on c.commit_sfdc_account_id = a2.AccountID
""")

# COMMAND ----------

spark.sql(f""" 
create or replace temp view consumption_azure_daily_attribution_product2_dim
as
with product2_dim (
select Id, ProductCode
from {main_sfdc_bronze_product2} 
where processDate = (select max(processDate) from {main_sfdc_bronze_product2} )
and ProductCode like '%COMMIT%'
),

base (
select *,
       case when aggOrder like 'AZURE-COMMIT%' then 'AZURE-COMMIT-DOLLAR'
            when aggOrder like 'FLEX-COMMIT%' then 'FLEX-COMMIT-DOLLAR'
            when aggOrder like 'AZDTUFLEX-COMMIT%' then 'DEFERRED-TRUE-UP-COMMIT'
            else aggOrder end product_code_aggorder       
from account_contract_daily_burn_down_enhanced
),

tp_id_name_dim (
select tp_id as tpId, 
       first(tp_name) tpName
from {msft_azure_subscriptions}
where tp_name is not null
group by tp_id
)

select b.* except(product_code_aggorder),
       t.tpName,
       last_day(b.date) month_end_date,
       p2.Id product_code_id
from  base b
left join product2_dim p2 on b.product_code_aggorder = p2.ProductCode
left join tp_id_name_dim t on b.tpId = t.tpId
""")

# COMMAND ----------

royalty_report_daily_attribution

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view consumption_azure_daily_attribution_product2_dim_d
# MAGIC as
# MAGIC select distinct *
# MAGIC from consumption_azure_daily_attribution_product2_dim

# COMMAND ----------

display(spark.sql(f""" 
select 
       last_day(date) royalty_month_end_date,
       sum(cust_dollars) royalty_cust_dollars
from consumption_azure_daily_attribution_product2_dim_d
group by all
order by 1 desc
"""))

# COMMAND ----------

consumption_azure_daily_attribution_p2 = spark.sql(""" 
select distinct * from consumption_azure_daily_attribution_product2_dim """)

consumption_azure_daily_attribution_p2.write\
                                      .option("overwriteSchema", "true")\
                                      .format("delta")\
                                      .mode("overwrite")\
                                      .saveAsTable(royalty_report_daily_attribution)

# COMMAND ----------

display(spark.sql(f""" 
select 
       last_day(date) royalty_month_end_date,
       sum(cust_dollars) royalty_cust_dollars
from {royalty_report_daily_attribution}
group by all
order by 1 desc
"""))
