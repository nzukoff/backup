# Databricks notebook source
access_key = dbutils.secrets.get(scope = "bse-dev-creds", key = "bse-awsmp-accesskeyid")
secret_key = dbutils.secrets.get(scope = "bse-dev-creds", key = "bse-awsmp-secretkey")
#encoded_secret_key = secret_key.replace("/", "%2F")

aws_bucket_name = "databricks-bucket-marketplace-fda"
sc._jsc.hadoopConfiguration().set("fs.s3a.access.key", access_key)
sc._jsc.hadoopConfiguration().set("fs.s3a.secret.key", secret_key)

aws_region = "us-east-2"
sc._jsc.hadoopConfiguration().set("fs.s3a.endpoint", "s3." + aws_region + ".amazonaws.com")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Product Feed

# COMMAND ----------

productFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/ProductFeed_V1/", header = True)

productFeed_df.createOrReplaceTempView("productfeed_v1")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.productfeed_v1 table productfeed_v1
# MAGIC
# MAGIC
# MAGIC
# MAGIC MERGE INTO main.it_consumption_silver.productfeed_v1 as final
# MAGIC USING productfeed_v1 as tmp
# MAGIC ON final.product_id = tmp.product_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------

display(productFeed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Agreement Feed

# COMMAND ----------

agreementFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/AgreementFeed/", header = True)

agreementFeed_df.createOrReplaceTempView("agreementfeed")

# COMMAND ----------

display(agreementFeed_df)

# COMMAND ----------

agreementFeed_df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.agreementfeed table agreementfeed
# MAGIC
# MAGIC MERGE INTO main.it_consumption_silver.agreementfeed as final
# MAGIC USING agreementfeed as tmp
# MAGIC ON final.agreement_id = tmp.agreement_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Offer Feed

# COMMAND ----------

offerFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/OfferFeed_V1/", header = True)

offerFeed_df.createOrReplaceTempView("offerfeed_v1")

# COMMAND ----------

display(offerFeed_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.offerfeed_v1 table offerfeed_v1
# MAGIC
# MAGIC MERGE INTO main.it_consumption_silver.offerfeed_v1 as final
# MAGIC USING offerfeed_v1 as tmp
# MAGIC ON final.offer_id = tmp.offer_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Address data

# COMMAND ----------

piifeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/PIIFeed/", header = True)

piifeed_df.createOrReplaceTempView("piifeed")

# COMMAND ----------

display(piifeed_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.piifeed table piifeed
# MAGIC MERGE INTO main.it_consumption_silver.piifeed as final
# MAGIC USING piifeed as tmp
# MAGIC ON final.aws_account_id = tmp.aws_account_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Billing Event

# COMMAND ----------

billingeventfeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/BillingEventFeed_V1/", header = True)

billingeventfeed_df.createOrReplaceTempView("billingeventfeed_v1")

# COMMAND ----------

display(billingeventfeed_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.billingeventfeed_v1 table billingeventfeed_v1
# MAGIC MERGE INTO main.it_consumption_silver.billingeventfeed_v1 as final
# MAGIC USING billingeventfeed_v1 as tmp
# MAGIC ON final.billing_event_id = tmp.billing_event_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Account Feed

# COMMAND ----------

accountFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/AccountFeed_V1/", header = True)

accountFeed_df.createOrReplaceTempView("accountfeed_v1")

# COMMAND ----------

display(accountFeed_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.accountfeed_v1 table accountfeed_v1
# MAGIC
# MAGIC MERGE INTO main.it_consumption_silver.accountfeed_v1 as final
# MAGIC USING accountfeed_v1 as tmp
# MAGIC ON final.account_id = tmp.account_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Offer target feed

# COMMAND ----------

offertargetfeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/OfferTargetFeed_V1/", header = True)

offertargetfeed_df.registerTempTable("offertargetfeed_v1")

# COMMAND ----------

display(offertargetfeed_df)

# COMMAND ----------

offertargetfeed_df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.offertargetfeed_v1 table offertargetfeed_v1
# MAGIC
# MAGIC MERGE INTO main.it_consumption_silver.offertargetfeed_v1 as final
# MAGIC USING offertargetfeed_v1 as tmp
# MAGIC ON final.offer_id = tmp.offer_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Payment Schedule feed

# COMMAND ----------

paymentscheduletermfeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/PaymentScheduleTermFeed/", header = True)

paymentscheduletermfeed_df.registerTempTable("paymentscheduletermfeed")

# COMMAND ----------

display(paymentscheduletermfeed_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.paymentscheduletermfeed table paymentscheduletermfeed
# MAGIC MERGE INTO main.it_consumption_silver.paymentscheduletermfeed as final
# MAGIC USING paymentscheduletermfeed as tmp
# MAGIC ON final.agreement_id = tmp.agreement_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Offer Product Feed

# COMMAND ----------

offerproductfeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/OfferProductFeed_V1/", header = True)

offerproductfeed_df.registerTempTable("offerproductfeed_v1")

# COMMAND ----------

display(offerproductfeed_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.offerproductfeed_v1 table offerproductfeed_v1
# MAGIC
# MAGIC MERGE INTO main.it_consumption_silver.offerproductfeed_v1 as final
# MAGIC USING offerproductfeed_v1 as tmp
# MAGIC ON final.offer_id = tmp.offer_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------

taxItemFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/TaxItemFeed_V1/", header = True)

taxItemFeed_df.registerTempTable("taxItemFeed_v1")


# COMMAND ----------

display(taxItemFeed_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.taxItemFeed_v1 table taxItemFeed_v1
# MAGIC
# MAGIC MERGE INTO main.it_consumption_silver.taxItemFeed_v1 as final
# MAGIC USING taxItemFeed_v1 as tmp
# MAGIC ON final.invoice_id = tmp.invoice_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------

legacyIdMappingFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/LegacyIdMappingFeed_V1/", header = True)

legacyIdMappingFeed_df.registerTempTable("legacyIdMappingFeed_v1")

# COMMAND ----------

display(legacyIdMappingFeed_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert into bdw_dev.legacyIdMappingFeed_v1 table legacyIdMappingFeed_v1
# MAGIC
# MAGIC MERGE INTO main.it_consumption_silver.legacyIdMappingFeed_v1 as final
# MAGIC USING legacyIdMappingFeed_v1 as tmp
# MAGIC ON final.legacy_id = tmp.legacy_id and final.insert_date = tmp.insert_date and final.update_date = tmp.update_date
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT *

# COMMAND ----------


