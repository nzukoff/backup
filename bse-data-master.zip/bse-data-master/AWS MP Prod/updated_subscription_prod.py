# Databricks notebook source
#change all integration to main in this script before prod migration - change done.
access_key = dbutils.secrets.get(scope = "bse-dev-creds", key = "bse-awsmp-accesskeyid")
secret_key = dbutils.secrets.get(scope = "bse-dev-creds", key = "bse-awsmp-secretkey")
#encoded_secret_key = secret_key.replace("/", "%2F")

aws_bucket_name = "databricks-bucket-marketplace-fda"
sc._jsc.hadoopConfiguration().set("fs.s3a.access.key", access_key)
sc._jsc.hadoopConfiguration().set("fs.s3a.secret.key", secret_key)

aws_region = "us-east-2"
sc._jsc.hadoopConfiguration().set("fs.s3a.endpoint", "s3." + aws_region + ".amazonaws.com")

# COMMAND ----------

dbutils.fs.head("s3a://databricks-bucket-marketplace-fda/AccountFeed_V1/year=2022/month=01/data.csv")

# COMMAND ----------

productFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/ProductFeed_V1/", header = True)

productFeed_df.registerTempTable("productfeed_v1")

# COMMAND ----------

display(productFeed_df)

# COMMAND ----------

agreementFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/AgreementFeed/", header = True)

agreementFeed_df.registerTempTable("agreementfeed")

# COMMAND ----------

display(agreementFeed_df)

# COMMAND ----------

offerFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/OfferFeed_V1/", header = True)

offerFeed_df.registerTempTable("offerfeed_v1")

# COMMAND ----------

offerProductfeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/OfferProductFeed_V1/", header = True)

offerProductfeed_df.registerTempTable("offerproductfeed_v1")

# COMMAND ----------

offertargetfeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/OfferTargetFeed_V1/", header = True)

offertargetfeed_df.registerTempTable("offertargetfeed_v1")

# COMMAND ----------

piifeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/PIIFeed/", header = True)

piifeed_df.registerTempTable("piifeed")

# COMMAND ----------

billingeventfeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/BillingEventFeed_V1/", header = True)

billingeventfeed_df.registerTempTable("billingeventfeed_v1")

# COMMAND ----------

accountFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/AccountFeed_V1/", header = True)

accountFeed_df.registerTempTable("accountfeed_v1")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Subscriber Table
# MAGIC #### 1 record per subscriber

# COMMAND ----------

subscriber_df = sql("""

with pii_with_uni_temporal_data as (
    select
    *
    from
    (
        select
			*,
            ROW_NUMBER() OVER (PARTITION BY address_id, valid_from ORDER BY to_timestamp(update_date) desc) as row_num
        from
            piifeed

    )
    where
        -- keep latest ...
        row_num = 1
		--  remove the soft-deleted one.
		and (delete_date is null or delete_date = '')
),

-- We are only interested in the most recent tuple (BTW: a given address is not supposed to chaneg over time but when bugs ;-) so this query mainly does nothing)
pii_with_latest_revision as (
    select
    *
    from
    (
            select
            *,
            ROW_NUMBER() OVER (PARTITION BY address_id ORDER BY valid_from desc) as row_num_latest_revision
        from
            pii_with_uni_temporal_data
    )
    where
        row_num_latest_revision = 1
),

 agreements_with_uni_temporal_data AS
(
  SELECT agreement_id,
         origin_offer_id,
         proposer_account_id,
         acceptor_account_id,
         agreement_revision,
         start_date,
         end_date,
         acceptance_date,
         ROW_NUMBER() OVER(partition by agreement_id order by valid_from desc) as rn
         FROM (
         SELECT agreement_id,
					  delete_date,
                      origin_offer_id,
                      proposer_account_id,
                      acceptor_account_id,
                      agreement_revision,
                      to_timestamp(start_date) as start_date,
                      to_timestamp(end_date) as end_date,
                      to_timestamp(acceptance_date) as acceptance_date,
                      to_timestamp(valid_from ) as valid_from,
                      ROW_NUMBER() OVER (PARTITION BY agreement_id, to_timestamp(valid_from ) ORDER BY to_timestamp(update_date) DESC) AS row_num
				-- TODO change to agreementfeed_v1 when Agreement Feed is GA'ed
               FROM agreementfeed     
          )
  WHERE
  -- a agreement_id can appear multiple times with the same valid_from date but with a different update_date column
  -- we are only interested in the most recent tuple
  row_num = 1
  --  remove the soft-deleted one.
  and (delete_date is null or delete_date = '')
)
, -- an agreement has multiple revisions (each having a valid_from date) but we are only interested in the most recent 
agreements_with_latest_revision as
(
SELECT
         agreement_id,
         origin_offer_id as offer_id,
         proposer_account_id,
         acceptor_account_id,
         agreement_revision,
         start_date,
         end_date,
         acceptance_date
FROM agreements_with_uni_temporal_data
WHERE  rn = 1
and end_date = '9999-01-01T00:00:00.000+0000'
  )
  
  ,
  
  accounts_with_uni_temporal_data as (
    select
    account_id,
    aws_account_id,
    encrypted_account_id,
    mailing_address_id,
    tax_address_id,
    valid_from
    from
    (
        select
            account_id,
			delete_date,
            aws_account_id,
            encrypted_account_id,
            mailing_address_id,
            tax_address_id,
            to_timestamp(valid_from) as valid_from,
            ROW_NUMBER() OVER (PARTITION BY account_id, to_timestamp(valid_from) ORDER BY to_timestamp(update_date)desc) as row_num
        from accountfeed_v1
    )
    where
        -- keep latest ...
        row_num = 1
		--  remove the soft-deleted one.
		and (delete_date is null or delete_date = '')
),

-- Here, we build the validity time range (adding valid_to on top of valid_from) of each account revision.
-- We will use it to get account metadata at invoice time.
accounts_with_history as (
    select
        account_id,
        -- sometimes, this columns gets imported as a "bigint" and loses heading 0s -> casting to a char and re-adding heading 0s (if need be)
        substring('000000000000'||cast(aws_account_id as string),-12) aws_account_id,
        encrypted_account_id,
        mailing_address_id,
        tax_address_id,
        valid_from,
        coalesce(
            lead(valid_from) over (partition by account_id order by valid_from asc),
            timestamp '2999-01-01 00:00:00'
        ) as valid_to
    from
    accounts_with_uni_temporal_data
)
  
--    select * from  agreements_with_latest_revision where  acceptor_account_id = '432be48d0111121bdf872397e489710bc776c226' and end_date = '9999-01-01T00:00:00.000+0000'
--   select * from accounts_with_history where  account_id = '432be48d0111121bdf872397e489710bc776c226'

select
  af.agreement_id,
  af.offer_id,
  af.proposer_account_id,
  af.acceptor_account_id,
  af.agreement_revision,
  af.start_date,
  af.end_date,
  af.acceptance_date,
  --account
  ac.aws_account_id,
  ac.encrypted_account_id,
  ac.mailing_address_id,
  ac.tax_address_id,
--   ac.tax_registration_number,
--   ac.tax_legal_name,
  -- pii
  pii.address_id,
  pii.email_domain,
--   pii.company_name,
  pii.country,
  pii.state_or_region,
  pii.city,
  pii.postal_code,
  pii.address_line_1,
  pii.address_line_2,
  pii.address_line_3 ,
  -- sfdc
  sd.Cloud_Account_ID__c,
  sd.Platform_Account_ID__c,
  sd.Customer_Name__c as company_name

from
  agreements_with_latest_revision af
  join accounts_with_history ac on af.acceptor_account_id = ac.account_id
  join pii_with_latest_revision pii on ac.mailing_address_id = pii.address_id
  join (
    select
      Cloud_Account_ID__c,
      Platform_Account_ID__c,
    Customer_Name__c
    from
      main.sfdc_bronze.platformsubscription__c
    where
      Marketplace_Offer_Type__c = 'PUBLIC_OFFER'
      and Platform__c = 'aws'
      and Active__c = 'true'
      and processDate = (
        select
          max (processDate)
        from
          main.sfdc_bronze.platformsubscription__c
      )
  ) sd 
on ac.encrypted_account_id = sd.Cloud_Account_ID__c
-- left 
-- join 
-- (select * from finance.finance_usage_pricing where date >= '2022-05-10'  ) as up
-- on
-- up.productAccountID  = sd.Platform_Account_ID__c
where
  af.acceptance_date >= '2022-05-09' and ac.aws_account_id != '132467079112' 
  """)
  
# --   and ac.aws_account_id = '129722468505'

# COMMAND ----------

display(subscriber_df)

# COMMAND ----------

subscriber_df.registerTempTable("subscriber")

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from subscriber  

# COMMAND ----------

#change done
from delta.tables import *
subscriberdeltaTable = DeltaTable.forName(spark, 'main.it_consumption_silver.aws_mp_payg_subscriber')  

# COMMAND ----------

subscriberdeltaTable.alias("old_sub").merge(
    subscriber_df.alias("new_sub"),
    "old_sub.agreement_id = new_sub.agreement_id  and old_sub.aws_account_id = new_sub.aws_account_id and old_sub.Platform_Account_ID__c = new_sub.Platform_Account_ID__c and old_sub.Cloud_Account_ID__c = new_sub.Cloud_Account_ID__c and old_sub.mailing_address_id = new_sub.mailing_address_id  and old_sub.start_date = new_sub.start_date  and old_sub.end_date = new_sub.end_date ") \
  .whenNotMatchedInsertAll() \
  .execute()

# COMMAND ----------

# MAGIC %md
# MAGIC ### SubscriberRevenueMonthly
# MAGIC #### 1 record subscriber per month

# COMMAND ----------

SubscriberRevenueMonthlydf = sql("""
-- Revenue Recognition Reporting at Invoice Time

-- DISCLAIMER: This query uses the Agreement Feed, which is currently in private beta.
-- This query will be changed before General Availability (GA).

-- General note: When executing this query we are assuming that the data ingested in the database is using
-- two time axes (the valid_from column and the update_date column).
-- See documentation for more details: https://docs.aws.amazon.com/marketplace/latest/userguide/data-feed.html#data-feed-details


-- A product_id has several valid_from dates (each representing a product revision),
--   but because of bi-temporality, each product_id + valid_from tuple can appear multiple times with a different update_date.
-- We are only interested in the most recent tuple (ie, uni-temporal model)
with products_with_uni_temporal_data as (
    select
        *
    from
    (
        select
         *,
         ROW_NUMBER() OVER (PARTITION BY product_id, valid_from ORDER BY to_timestamp(update_date) desc) as row_num
        from
         productfeed_v1
      )
    where
        -- keep latest ...
        row_num = 1
        -- ... and remove the soft-deleted one.
        and (delete_date is null or delete_date = '')
),
-- Here, we build the validity time range (adding valid_to on top of valid_from) of each product revision.
-- We will use it to get the product title at invoice time.
-- NB: If you'd rather get "current" product title, un-comment "products_with_latest_revision"
products_with_history as (
    select
        product_id,
        title,
        to_timestamp(valid_from) as valid_from,
        coalesce(
            lead(to_timestamp(valid_from)) over (partition by product_id order by to_timestamp(valid_from) asc),
            timestamp '2999-01-01 00:00:00'
        ) as valid_to
    from products_with_uni_temporal_data
),
-- provided for reference only if you are interested into get "current" product title
--  (ie. not used afterwards)
products_with_latest_revision as (
    select
        *
    from
    (
        select
            product_id,
            title,
            ROW_NUMBER() OVER (PARTITION BY product_id ORDER BY to_timestamp(valid_from) desc) as row_num_latest_revision
        from
            products_with_uni_temporal_data
    )
    where
        row_num_latest_revision = 1
),

-- An agreement_id has several valid_from dates (each representing an agreement revision)
--   but because of bi-temporality, an agreement_id + valid_from tuple can appear multiple times with a different update_date.
-- We are only interested in the most recent tuple (ie, uni-temporal model)
agreements_with_uni_temporal_data as (
    select
        *
    from
    (
        select
            *,
            ROW_NUMBER() OVER (PARTITION BY agreement_id, valid_from ORDER BY to_timestamp(update_date) desc) as row_num
        from
            agreementfeed
    )
    where
        -- keep latest ...
        row_num = 1
        -- ... and remove the soft-deleted one.
        and (delete_date is null or delete_date = '')
),
-- Here, we build the validity time range (adding valid_to on top of valid_from) of each agreement revision.
-- We will use it to get agreement metadata at invoice time.
agreements_with_history as (
    select
        agreement_id,
        origin_offer_id as offer_id,
        proposer_account_id,
        acceptor_account_id,
        agreement_revision,
        start_date,
        end_date,
        acceptance_date,
        to_timestamp(valid_from) as valid_from,
        coalesce(
            lead(to_timestamp(valid_from)) over (partition by agreement_id order by to_timestamp(valid_from) asc),
            timestamp '2999-01-01 00:00:00'
        ) as valid_to
    from agreements_with_uni_temporal_data
),

-- An offer_id has several valid_from dates (each representing an offer revision)
--   but because of bi-temporality, an offer_id + valid_from tuple can appear multiple times with a different update_date.
-- We are only interested in the most recent tuple (ie, uni-temporal model)
offers_with_uni_temporal_data as (
    select
        *
    from
    (
        select
            *,
            ROW_NUMBER() OVER (PARTITION BY offer_id, valid_from ORDER BY to_timestamp(update_date) desc) as row_num
        from
            offerfeed_v1
    )
    where
        -- keep latest ...
        row_num = 1
        -- ... and remove the soft-deleted one.
        and (delete_date is null or delete_date = '')
),
-- Here, we build the validity time range (adding valid_to on top of valid_from) of each offer revision.
-- We will use it to get Offer name at invoice time.
-- NB: If you'd rather get "current" offer name, un-comment "offers_with_latest_revision"
offers_with_history as (
    select
        offer_id,
        offer_revision,
        name,
        opportunity_name,
        opportunity_description,
        to_timestamp(valid_from) as valid_from,
        coalesce(
            lead(to_timestamp(valid_from)) over (partition by offer_id order by to_timestamp(valid_from) asc),
            timestamp '2999-01-01 00:00:00'
        ) as valid_to
    from offers_with_uni_temporal_data
),
-- provided for reference only if you are interested into get "current" offer name
--  (ie. not used afterwards)
offers_with_latest_revision as (
    select
        *
    from
    (
        select
            offer_id,
            offer_revision,
            name,
            opportunity_name,
            opportunity_description,
            valid_from,
            null valid_to,
            ROW_NUMBER() OVER (PARTITION BY offer_id ORDER BY to_timestamp(valid_from) desc) as row_num_latest_revision
        from
         offers_with_uni_temporal_data
    )
    where
        row_num_latest_revision = 1
),

-- An offer_target_id has several valid_from dates (each representing an offer revision)
--   but because of bi-temporality, an offer_target_id + valid_from tuple can appear multiple times with a different update_date.
-- We are only interested in the most recent tuple (ie, uni-temporal model)
offer_targets_with_uni_temporal_data as (
    select
        *
    from
    (
        select
            *,
            ROW_NUMBER() OVER (PARTITION BY offer_target_id, valid_from ORDER BY to_timestamp(update_date) desc) as row_num
        from
            offertargetfeed_v1
    )
    where
        -- keep latest ...
        row_num = 1
        -- ... and remove the soft-deleted one.
        and (delete_date is null or delete_date = '')
),


offers_with_history_with_target_type as (
    select
        offer.offer_id,
        offer.offer_revision,
        -- even though today it is not possible to combine several types of targeting in a single offer, let's ensure the query is still predictable if this gets possible in the future
        max(
            distinct
            case
                when off_tgt.target_type is null then 'Public'
                when off_tgt.target_type='BuyerAccounts' then 'Private'
                when off_tgt.target_type='ParticipatingPrograms' then 'Program:'||cast(off_tgt.value as string)
                when off_tgt.target_type='CountryCodes' then 'GeoTargeted'
                -- well, there is no other case today, but rather be safe...
                else 'Other Targeting'
            end
        ) as offer_target,
        min(offer.name) as name,
        min(offer.opportunity_name) as opportunity_name,
        min(offer.opportunity_description) as opportunity_description,
        offer.valid_from,
        offer.valid_to
    from
        offers_with_history offer
        -- left joining because public offers don't have targets
        left join offer_targets_with_uni_temporal_data off_tgt on offer.offer_id=off_tgt.offer_id and offer.offer_revision=off_tgt.offer_revision
    group by
        offer.offer_id,
        offer.offer_revision,
        --redundant with offer_revision, as each revision has a dedicated valid_from/valid_to (but cleaner in the group by)
        offer.valid_from,
        offer.valid_to
),
-- provided for reference only if you are interested into get "current" offer targets
--  (ie. not used afterwards)
offers_with_latest_revision_with_target_type as (
    select
        offer.offer_id,
        offer.offer_revision,
        -- even though today it is not possible to combine several types of targeting in a single offer, let's ensure the query is still predictable if this gets possible in the future
        max(
            distinct
            case
                when off_tgt.target_type is null then 'Public'
                when off_tgt.target_type='BuyerAccounts' then 'Private'
                when off_tgt.target_type='ParticipatingPrograms' then 'Program:'||cast(off_tgt.value as string)
                when off_tgt.target_type='CountryCodes' then 'GeoTargeted'
                -- well, there is no other case today, but rather be safe...
                else 'Other Targeting'
            end
        ) as offer_target,
        min(offer.name) as name,
        min(offer.opportunity_name) as opportunity_name,
        min(offer.opportunity_description) as opportunity_description,
        offer.valid_from,
        offer.valid_to
    from
        offers_with_latest_revision offer
        -- left joining because public offers don't have targets
        left join offer_targets_with_uni_temporal_data off_tgt on offer.offer_id=off_tgt.offer_id and offer.offer_revision=off_tgt.offer_revision
    group by
        offer.offer_id,
        offer.offer_revision,
        -- redundant with offer_revision, as each revision has a dedicated valid_from (but cleaner in the group by)
        offer.valid_from,
        offer.valid_to
),


-- An account_id has several valid_from dates (each representing a separate revision of the data)
--   but because of bi-temporality, an account_id + valid_from tuple can appear multiple times with a different update_date.
-- We are only interested in the most recent tuple (ie, uni-temporal model)
accounts_with_uni_temporal_data as (
    select
       *
    from
    (
        select
            *,
            ROW_NUMBER() OVER (PARTITION BY account_id, valid_from ORDER BY to_timestamp(update_date) desc) as row_num
        from
            accountfeed_v1
    )
    where
        -- keep latest ...
        row_num = 1
        -- ... and remove the soft-deleted one.
        and (delete_date is null or delete_date = '')
),

-- Here, we build the validity time range (adding valid_to on top of valid_from) of each account revision.
-- We will use it to get account metadata at invoice time.
accounts_with_history as (
    select
        account_id,
        -- sometimes, this columns gets imported as a "bigint" and loses heading 0s -> casting to a char and re-adding heading 0s (if need be)
        substring('000000000000'||cast(aws_account_id as string),-12) aws_account_id,
        encrypted_account_id,
        mailing_address_id,
        tax_address_id,
        to_timestamp(valid_from) as valid_from,
        coalesce(
            lead(to_timestamp(valid_from)) over (partition by account_id order by to_timestamp(valid_from) asc),
            timestamp '2999-01-01 00:00:00'
        ) as valid_to
    from
        accounts_with_uni_temporal_data
),


-- An address_id has several valid_from dates (each representing a separate revision of the data)
--   but because of bi-temporality, an account_id + valid_from tuple can appear multiple times with a different update_date.
-- We are only interested in the most recent tuple (ie, uni-temporal model)
pii_with_uni_temporal_data as (
    select
        *
    from
    (
        select
            *,
            ROW_NUMBER() OVER (PARTITION BY address_id, valid_from ORDER BY to_timestamp(update_date) desc) as row_num
        from
            piifeed
    )
    where
        -- keep latest ...
        row_num = 1
        -- ... and remove the soft-deleted one.
        and (delete_date is null or delete_date = '')
),

-- We are only interested in the most recent tuple (BTW: a given address is not supposed to chaneg over time but when bugs ;-) so this query mainly does nothing)
pii_with_latest_revision as (
    select
        *
    from
    (
        select
            *,
            ROW_NUMBER() OVER (PARTITION BY address_id ORDER BY to_timestamp(valid_from) desc) as row_num_latest_revision
        from
            pii_with_uni_temporal_data
    )
    where
        row_num_latest_revision = 1
),

-- enrich each account history record
accounts_with_history_with_company_name as (
    select
        acc.account_id,
        acc.aws_account_id,
        acc.encrypted_account_id,
        acc.mailing_address_id,
        acc.tax_address_id,
        pii_mailing.company_name as mailing_company_name,
        pii_mailing.email_domain,
        acc.valid_from,
        acc.valid_to
    from accounts_with_history acc
    -- left join because mailing_address_id can be null but when exists
    left join pii_with_latest_revision pii_mailing on acc.mailing_address_id=pii_mailing.address_id
),


-- A given billing_event_id represents an accounting event and thus has only one valid_from date,
--   but because of bi-temporality, a billing_event_id (+ its valid_from) can appear multiple times with a different update_date.
-- We are only interested in the most recent tuple (ie, uni-temporal model)
billing_events_with_uni_temporal_data as (
    select
        *
    from
    (
        select
            billing_event_id,
            to_timestamp(valid_from) as valid_from,
            to_timestamp(update_date) as update_date,
            delete_date,
            to_timestamp(invoice_date) as invoice_date_as_date,
            invoice_date,
            transaction_type,
            transaction_reference_id,
            parent_billing_event_id,
            bank_trace_id,
            --As broker_id has not been backfilled, manually fill up this column
            case when broker_id is null or broker_id = '' then 'AWS_INC' else broker_id end as broker_id,
            product_id,
            disbursement_billing_event_id,
            action,
            from_account_id,
            to_account_id,
            end_user_account_id,
            billing_address_id,
            -- casting in case data was imported as varchar
            CAST(amount as decimal(20, 10)) as amount,
            currency,
            agreement_id,
            invoice_id,
            payment_due_date,
            usage_period_start_date,
            usage_period_end_date,
            ROW_NUMBER() OVER (PARTITION BY billing_event_id, valid_from ORDER BY to_timestamp(update_date) desc) as row_num
        from
            billingeventfeed_v1
    )
    where
        -- keep latest ...
        row_num = 1
        -- ... and remove the soft-deleted one.
        and (delete_date is null or delete_date = '')
),
-- for revenue recognition at invoice time, we are only interested at invoiced and forgiven records
--  (ie, disbursements are skipped)
invoiced_billing_events_with_uni_temporal_data as (
    select *
    from billing_events_with_uni_temporal_data
    where action in ('FORGIVEN', 'INVOICED')
),
-- Get billing event id for 'DISBURSEMENT'
disbursement_events as (
      select
        billing_events_raw.billing_event_id as disbursement_id,
        billing_events_raw.invoice_date as disbursement_date,
        billing_events_raw.bank_trace_id
      from
        billing_events_with_uni_temporal_data billing_events_raw
      where
        -- we're only interested in disbursements, so we filter non-disbursements by selecting transaction type to be DISBURSEMENT
        billing_events_raw.transaction_type = 'DISBURSEMENT'
    ),

-- Get the invoices along with the line items that are part of the above filtered disbursements
disbursed_line_items as (
  select
    line_items.billing_event_id,
    line_items.transaction_reference_id,
    line_items.parent_billing_event_id,
    line_items.product_id,
    line_items.transaction_type,
    line_items.amount,
    --Currently, partial payment is not allowed, but will be available in future, this is to identify per billing_event_id, how much has been disbursed in total
    sum(line_items.amount) over (partition by line_items.parent_billing_event_id) disbursed_amount_per_parent,
    --Similarly, when partial payment is implemented, this will catch the most recent date of disbursement
    --Note: format is subject to change when partial payment is implemented as we are also planning to show all previous disbursed dates if a billing_event_id is disbursed for more than 1 time
    max(disbursements.disbursement_date) over (partition by line_items.parent_billing_event_id) last_disbursement_date,
    disbursements.disbursement_id,
    disbursements.bank_trace_id
  from
    billing_events_with_uni_temporal_data line_items
    -- Each disbursed line item is linked to the parent disbursement via the disbursement_billing_event_id
    join disbursement_events disbursements on disbursements.disbursement_id = line_items.disbursement_billing_event_id
  where
    -- we are interested only in the invoice line items that are DISBURSED
    line_items.action = 'DISBURSED'
),

 -- Here we select the account_id of the current seller (We identify this by looking for the to_account_id related to revenue transactions).
 -- We will use it later to distinguish own agreements from agreements generated by channel partners.
 seller_account as (
     select
         from_account_id as seller_account_id
     from
         invoiced_billing_events_with_uni_temporal_data bill
     where
        -- Assumption here is only seller will pay listing fee. As of 12/21/2021, there are cases that Channel partner have 0 listing fee for CPPO, so the amount could be 0.
         bill.transaction_type like 'AWS_REV_SHARE' and amount <= 0 and action = 'INVOICED'
     group by
         -- from_account_id is always the same for all those "listing fee" transactions == the seller of record himself.
         -- If this view returns more than 1 record, the overall query will fail (on purpose). Please contact AWS Marketplace if this happens.
         from_account_id
 ),
--Join invoiced_item with disbursement_item to find out if the invoice has been disbursed
--'DISBURSED' action does not have 'AWS_TAX_SHARE' AND 'AWS_TAX_SHARE_REFUND' transaction_type, therefore, for billing_event_id with 'AWS_TAX_SHARE' AND 'AWS_TAX_SHARE_REFUND' transaction_type, we can't identify if it has been disbursed.
--Will unify disburse_flag based on invoice_id next step.
invoiced_line_items_with_disbursement_info  as(
    select invoice.*,
    case
        when disburse.parent_billing_event_id is not null and - disburse.disbursed_amount_per_parent = invoice.amount then 'Yes'
        when disburse.parent_billing_event_id is not null and - disburse.disbursed_amount_per_parent <> invoice.amount then 'Partial'
        else 'No'
    end as disburse_flag_temp,
    disburse.last_disbursement_date,
    - disburse.disbursed_amount_per_parent disburse_amount,
    disburse.bank_trace_id disburse_bank_trace_id
    from
        invoiced_billing_events_with_uni_temporal_data invoice
    left join
        (select distinct parent_billing_event_id, disbursed_amount_per_parent, last_disbursement_date, bank_trace_id from disbursed_line_items )disburse on invoice.billing_event_id = disburse.parent_billing_event_id),

--unify disburse_flag across invoice_id
invoiced_disbursed_disburse_flag_invoice_unified as(
    select invoice_item.billing_event_id,
           invoice_item.valid_from,
           invoice_item.update_date,
           invoice_item.delete_date,
           invoice_item.invoice_date_as_date,
           invoice_item.invoice_date,
           invoice_item.transaction_type,
           invoice_item.transaction_reference_id,
           invoice_item.parent_billing_event_id,
           invoice_item.bank_trace_id,
           invoice_item.broker_id,
           invoice_item.product_id,
           invoice_item.disbursement_billing_event_id,
           invoice_item.action,
           invoice_item.from_account_id,
           invoice_item.to_account_id,
           invoice_item.end_user_account_id,
           invoice_item.billing_address_id,
           invoice_item.amount,
           invoice_item.currency,
           invoice_item.agreement_id,
           invoice_item.invoice_id,
           invoice_item.payment_due_date,
           invoice_item.usage_period_start_date,
           invoice_item.usage_period_end_date,
           case
               when disbursed_item.invoice_id is null then 'No'
               when disbursed_item.disburse_flag_temp = 'Partial' then 'Partial'
               else 'Yes'
           end as disburse_flag,
           disbursed_item.last_disbursement_date,
           disbursed_item.disburse_bank_trace_id
    from
        invoiced_line_items_with_disbursement_info invoice_item
    left join
        (select distinct invoice_id,
                disburse_flag_temp,
                disburse_bank_trace_id,
                last_disbursement_date
            from invoiced_line_items_with_disbursement_info
            where disburse_flag_temp in ('Yes','Partial') ) disbursed_item
        on invoice_item.invoice_id = disbursed_item.invoice_id
),
invoiced_transactions_disbursed_disburse_flag_invoice_unified as (
  select
        currency,
        -- We are separating Revenue and Cost of Goods Sold below:
        --  customer invoiced seller_rev_share records expose from_account_id=<customer> to_account_id=Seller
        --  while COGS records expose from_account_id=Seller to_account_id=<manufacturer>
        sum(case when transaction_type = 'SELLER_REV_SHARE' and  to_account_id =(select seller_account_id from seller_account) then amount else 0 end) as gross_revenue,
        sum(case when transaction_type = 'AWS_REV_SHARE' then amount else 0 end) as aws_rev_share,
        -- _CREDIT is a form of refunds, hence we club those 2 together
        sum(case when transaction_type in ('SELLER_REV_SHARE_REFUND','SELLER_REV_SHARE_CREDIT') and to_account_id =(select seller_account_id from seller_account) then amount else 0 end) as gross_refunds,
        sum(case when transaction_type in ('AWS_REV_SHARE_REFUND','AWS_REV_SHARE_CREDIT') then amount else 0 end) as aws_refund_share,
        sum(case when transaction_type = 'AWS_TAX_SHARE' then amount else 0 end) as aws_tax_share,
        sum(case when transaction_type = 'AWS_TAX_SHARE_REFUND' then amount else 0 end) as aws_tax_share_refund,
        sum(case when transaction_type = 'SELLER_TAX_SHARE' then amount else 0 end) as seller_tax_share,
        sum(case when transaction_type = 'SELLER_TAX_SHARE_REFUND' then amount else 0 end) as seller_tax_share_refund,
        -- NB: the 2 following cost of goods records will be 0 if the seller is not a channel partner
        --set COGS/COGS refund =0 the when buyer is the seller itself
        sum(case when transaction_type = 'SELLER_REV_SHARE' and from_account_id = (select seller_account_id from seller_account) and to_account_id <> (select seller_account_id from seller_account) then amount else 0 end) as cogs,
        sum(case when transaction_type in ('SELLER_REV_SHARE_REFUND','SELLER_REV_SHARE_CREDIT') and from_account_id = (select seller_account_id from seller_account) and to_account_id <> (select seller_account_id from seller_account)  then amount else 0 end) as cogs_refund,
        agreement_id,
        product_id,
        invoice_date_as_date,
        invoice_date,
        invoice_id,
        broker_id,
        transaction_reference_id,
        disburse_flag,
        last_disbursement_date,
        disburse_bank_trace_id,
        max(
            case
                -- For AWS and BALANCE_ADJUSTMENT, the billing event feed will show the "AWS Marketplace" account as the
                -- receiver of the funds and the seller as the payer. We are not interested in this information here.
                -- Null values will be ignored by the `max` aggregation function.
                when transaction_type like 'AWS%' or transaction_type like 'BALANCE_ADJUSTMENT'
                then null
                -- We get the payer of the invoice from *any* transaction type that is not AWS and not BALANCE_ADJUSTMENT (because they are the same for a given end user + agreement + product).
                else from_account_id
            end
        ) as payer_account_id,
        -- A transaction will have the same billing_address_id for all of its line items.
         --Note: Currently, only transaction_type like 'SELLER_%' have billing_address_id exposed. Make adjustment on the max() selection when billing_address_id of other transaction_types exposed.
        max(billing_address_id) as billing_address_id,
        end_user_account_id,
        usage_period_start_date,
        usage_period_end_date,
        payment_due_date
    from
        invoiced_disbursed_disburse_flag_invoice_unified
    group by
        product_id,
        invoice_date,
        invoice_date_as_date,
        invoice_id,
        broker_id,
        currency,
        agreement_id,
        end_user_account_id,
        usage_period_start_date,
        usage_period_end_date,
        -- will always have same value given above grouping fields -> cleaner to group by in here rather than using a max or min in the select
        payment_due_date,
        transaction_reference_id,
        disburse_flag,
        last_disbursement_date,
        disburse_bank_trace_id
),

--add subscriber and payer addressID, payer address preference order: tax address > billing address > mailing address,
-- subscriber address preference order: tax address >  mailing address
invoiced_disbursed_disburse_flag_invoice_unified_with_sub_address as (
  select inv.*, agg.acceptor_account_id subscriber_account_id,
         coalesce (
             --empty value in Athena shows as '', change all '' value to null in order to follow the preference order logic above
             case when acc_acp.tax_address_id ='' then null else acc_acp.tax_address_id end,
             case when acc_acp.mailing_address_id = '' then null else acc_acp.mailing_address_id end) as subscriber_address_id,
         coalesce (
             case when acc_pay.tax_address_id = '' then null else acc_pay.tax_address_id end,
             case when inv.billing_address_id = '' then null else inv.billing_address_id end,
             case when acc_pay.mailing_address_id = '' then null else acc_pay.mailing_address_id end) as payer_address_id,
         coalesce (
             case when acc_end.tax_address_id = '' then null else acc_end.tax_address_id end,
             case when inv.billing_address_id = '' then null else inv.billing_address_id end,
             case when acc_end.mailing_address_id = '' then null else acc_end.mailing_address_id end) as end_user_address_id
  from invoiced_transactions_disbursed_disburse_flag_invoice_unified inv
  left join agreements_with_history agg on inv.agreement_id = agg.agreement_id
                                               and (inv.invoice_date_as_date >= agg.valid_from and inv.invoice_date_as_date < agg.valid_to)
  left join accounts_with_history_with_company_name acc_acp on agg.acceptor_account_id = acc_acp.account_id
                                               and (inv.invoice_date_as_date >= acc_acp.valid_from  and inv.invoice_date_as_date < acc_acp.valid_to)
  left join accounts_with_history_with_company_name acc_pay on inv.payer_account_id = acc_pay.account_id
                                               and (inv.invoice_date_as_date >= acc_pay.valid_from  and inv.invoice_date_as_date < acc_pay.valid_to)
  left join accounts_with_history_with_company_name acc_end on inv.end_user_account_id = acc_end.account_id
                                               and (inv.invoice_date_as_date >= acc_end.valid_from  and inv.invoice_date_as_date < acc_end.valid_to)
),

--cppo offer_id has not been backfilled to offertargetfeed_v1 table, causing cppo offer be defined as 'Public' in previous step, we will convert them back to 'Private' in next step
cppo_offer_id as(
select distinct agg.offer_id as offer_id
from invoiced_disbursed_disburse_flag_invoice_unified_with_sub_address inv
left join agreements_with_history agg on agg.agreement_id = inv.agreement_id and (inv.invoice_date_as_date >= agg.valid_from  and inv.invoice_date_as_date < agg.valid_to)

except
select distinct offer_id
from offer_targets_with_uni_temporal_data
),
revenue_recognition_at_invoice_time as (

select
    --Payer Information
    acc_payer.aws_account_id as PayerAWSAccountID, -- "Customer AWS Account Number" in legacy report
    pii_payer.company_name as PayerCompanyName,
    pii_payer.email_domain as PayerEmailDomain,
    pii_payer.city as PayerCity,
    pii_payer.state_or_region as PayerState,
    pii_payer.country as PayerCountry,
    pii_payer.postal_code as PayerPostalCode,

   --End Customer Information
    acc_enduser.aws_account_id as EndCustomerAWSAccountID,
    acc_enduser.encrypted_account_id as EndUserEncryptedAccountID,
    pii_end_user.company_name as EndCustomerCompanyName,
    pii_end_user.email_domain as EndCustomerEmailDomain,
    pii_end_user.city as EndCustomerCity,
    pii_end_user.state_or_region as EndCustomerState,
    pii_end_user.country as EndCustomerCountry,
    pii_end_user.postal_code as EndCustomerPostalCode,

    --Subscriber Information
    acc_subscriber.aws_account_id as SubscriberAWSAccountID,
    pii_subscriber.company_name as SubscriberCompanyName,
    pii_subscriber.email_domain as SubscriberEmailDomain,
    pii_subscriber.city as SubscriberCity,
    pii_subscriber.state_or_region as SubscriberState,
    pii_subscriber.country as SubscriberCountry,
    pii_subscriber.postal_code as SubscriberPostalCode,

   ------------------
   -- Product Info --
   ------------------
   inv.product_id as ProductID,
   -- product title at time of invoice. It is possible that the title changes over time and therefore there may be multiple product titles mapped to a single product id.
   p.title as ProductTitle,

   ----------------------
   -- Procurement Info --
   ----------------------
   offer.offer_id as OfferID,
   -- offer name at time of invoice. It is possible that the name changes over time therefore there may be multiple offer names mapped to a single offer id.
   offer.name as OfferName,
   -- offer target at time of invoice.
  -- case when offer.offer_id in (select distinct offer_id from cppo_offer_id) then 'Private' else offer.offer_target end as OfferTarget,
   -- ***********************############**************************
   case when offer.offer_id = cppo.offer_id   then 'Private' else offer.offer_target end as OfferTarget,
   offer.opportunity_name as OfferopportunityName,
   offer.opportunity_description as OfferopportunityDescription,
   -- We used a sub-select to fail the query if it returns more than 1 record (to be on the safe side)
   case when agg.proposer_account_id <> (select seller_account_id from seller_account) then acc_reseller.aws_account_id else null end as ResellerAWSAccountID,
   -- reseller company name at time of invoice
   case when agg.proposer_account_id <> (select seller_account_id from seller_account ) then  acc_reseller.mailing_company_name else null end ResellerCompanyName,
   agg.agreement_id as AgreementID,
   -- all agreement related data are surfaced as they were at time of invoice.
   agg.agreement_revision as AgreementRevision,
   agg.start_date as AgreementStartDate,
   agg.end_date as AgreementEndDate,
   agg.acceptance_date as AgreementAcceptanceDate,

   --------------
   -- Revenues --
   --------------
   inv.invoice_id as InvoiceID,
   inv.transaction_reference_id as TransactionReferenceID,
   inv.invoice_date as InvoiceDate,
   inv.usage_period_start_date as UsagePeriodStartDate,
   inv.usage_period_end_date as UsagePeriodEndDate,
   -- We are rounding the sums using 2 decimal precision
   -- Note that the rounding method might differ between SQL implementations.
   -- The monthly revenue report is using RoundingMode.HALF_UP. This might create tiny discrepancies between this SQL output
   -- and the legacy report
   round(inv.gross_revenue,2) as GrossRevenue,
   round(inv.gross_refunds,2) as GrossRefund,
   inv.payment_due_date as PaymentDueDate,
   round(inv.aws_rev_share,2) as ListingFee,
   round(inv.aws_refund_share,2) as ListingFeeRefund,
   round(inv.aws_tax_share,2) as AWSTaxShare,
   round(inv.aws_tax_share_refund,2) as AWSTaxShareRefund,
   round(inv.seller_tax_share,2) as SellerTaxShare,
   round(inv.seller_tax_share_refund,2) as SellerTaxShareRefund,
   round(inv.cogs,2) as COGS,
   round(inv.cogs_refund,2) as COGSRefund,
   -- summing rounded amounts to ensure that the calculation is consistent between above figures and this one
   -- net revenue = gross revenue - listing fee - tax - cogs
   (    round(inv.gross_revenue,2) +
        round(inv.aws_rev_share,2) +
        round(inv.gross_refunds,2) +
        round(inv.aws_refund_share,2) +
        round(inv.seller_tax_share,2) +
        round(inv.seller_tax_share_refund,2) +
        round(inv.cogs,2) +
        round(inv.cogs_refund,2)
   ) as SellerNetRevenue,
   currency as Currency,

   ------------------
   -- Disbursement --
   ------------------
    disburse_flag as DisbursementFlag,
    -- 'no value' cells in all data feeds show as 'empty string' in Athena, change the possible NULL values generated from previous left join to unify those columns with no value as ''
    case when last_disbursement_date is null then '' else last_disbursement_date end as LastDisbursementDate,
    case when disburse_bank_trace_id is null then '' else disburse_bank_trace_id end as DisburseBankTraceId,
    broker_id as BrokerID

from invoiced_disbursed_disburse_flag_invoice_unified_with_sub_address inv

    -- if you want to get current product title, replace the next join with: left join products_with_latest_revision p on p.product_id = inv.product_id
    join products_with_history p on p.product_id = inv.product_id and (inv.invoice_date_as_date >= p.valid_from  and inv.invoice_date_as_date < p.valid_to)
    left join accounts_with_history_with_company_name acc_payer on inv.payer_account_id = acc_payer.account_id
                                                                    and (inv.invoice_date_as_date >= acc_payer.valid_from  and inv.invoice_date_as_date < acc_payer.valid_to)
    -- left join because end_user_account_id is nullable (eg if the invoice is originated from a reseller)
    left join accounts_with_history_with_company_name acc_enduser on inv.end_user_account_id = acc_enduser.account_id
                                                                    and (inv.invoice_date_as_date >= acc_enduser.valid_from  and inv.invoice_date_as_date < acc_enduser.valid_to)
    left join accounts_with_history_with_company_name acc_subscriber on inv.subscriber_account_id = acc_subscriber.account_id
                                                                    and (inv.invoice_date_as_date >= acc_subscriber.valid_from  and inv.invoice_date_as_date < acc_subscriber.valid_to)
    left join pii_with_latest_revision pii_payer on inv.payer_address_id = pii_payer.address_id
    left join pii_with_latest_revision pii_subscriber on inv.subscriber_address_id = pii_subscriber.address_id
    left join pii_with_latest_revision pii_end_user on inv.end_user_address_id = pii_end_user.address_id
    left join agreements_with_history agg on agg.agreement_id = inv.agreement_id and (inv.invoice_date_as_date >= agg.valid_from  and inv.invoice_date_as_date < agg.valid_to)
    left join accounts_with_history_with_company_name acc_reseller on agg.proposer_account_id = acc_reseller.account_id
                                                                        and (inv.invoice_date_as_date >= acc_reseller.valid_from  and inv.invoice_date_as_date < acc_reseller.valid_to)
    -- if you want to get current offer name, replace the next join with: left join offer_targets_with_latest_revision_with_target_type off on agg.offer_id = off.offer_id
    left join offers_with_history_with_target_type offer on agg.offer_id = offer.offer_id and (inv.invoice_date_as_date >= offer.valid_from  and inv.invoice_date_as_date < offer.valid_to)
    left join cppo_offer_id cppo on offer.offer_id = cppo.offer_id 

)
select *
from revenue_recognition_at_invoice_time
-- Filter results to within a 90 trailing period
where to_date(InvoiceDate)  > date_sub(current_date, 90 ) 
-- To filter on a specific month, uncomment the following and replace the dates:
-- where "Invoice Date" >= '2021-08-01' and "Invoice Date"< '2021-10-15'

""")

# COMMAND ----------

SubscriberRevenueMonthlydf.registerTempTable('SubscriberRevenueMonthlydf_may')

# COMMAND ----------

display(SubscriberRevenueMonthlydf)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from integration.it_consumption_silver.aws_mp_payg_subscriber_monthly_revenue where ProductTitle != 'Databricks Unified Analytics Platform - Annual Commitment v3'  and PayerAWSAccountID != '665428379115' and UsagePeriodStartDate >= '2022-05-09' and AgreementEndDate = '9999-01-01T00:00:00Z'

# COMMAND ----------

# MAGIC %sql
# MAGIC select a.*, 
# MAGIC b.DBU,
# MAGIC b.custDBUDollars,
# MAGIC b.listDBUDollars,
# MAGIC company_name
# MAGIC
# MAGIC  from
# MAGIC (select * from integration.it_consumption_silver.aws_mp_payg_subscriber_monthly_revenue where ProductTitle != 'Databricks Unified Analytics Platform - Annual Commitment v3'  and PayerAWSAccountID != '665428379115' and UsagePeriodStartDate >= '2022-05-09' and AgreementEndDate = '9999-01-01T00:00:00Z') a
# MAGIC join 
# MAGIC (select * from integration.it_consumption_silver.aws_mp_payg_subscriber_usage_monthly where month_end_date = '2022-05-31') b
# MAGIC on 
# MAGIC a.EndUserEncryptedAccountID = b.Cloud_Account_ID__c

# COMMAND ----------

SubscriberRevenueMonthlydeltaTable = DeltaTable.forName(spark, 'main.it_consumption_silver.aws_mp_payg_subscriber_monthly_revenue')  

# COMMAND ----------

SubscriberRevenueMonthlydeltaTable.alias("old_rev").merge(
    SubscriberRevenueMonthlydf.alias("new_rev"),
    "old_rev.AgreementStartDate  = new_rev.AgreementStartDate      and old_rev.AgreementEndDate    = new_rev.AgreementEndDate        and old_rev.AgreementAcceptanceDate  = new_rev.AgreementAcceptanceDate and old_rev.InvoiceID   = new_rev.InvoiceID               and old_rev.TransactionReferenceID   = new_rev.TransactionReferenceID  and old_rev.InvoiceDate  = new_rev.InvoiceDate             and old_rev.UsagePeriodStartDate = new_rev.UsagePeriodStartDate    and old_rev.UsagePeriodEndDate   = new_rev.UsagePeriodEndDate and old_rev.PayerAWSAccountID = new_rev.PayerAWSAccountID ") \
  .whenNotMatchedInsertAll() \
  .execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from integration.it_consumption_silver.aws_mp_payg_subscriber_monthly_revenue

# COMMAND ----------

# MAGIC %md
# MAGIC ### SubscriberUsageDaily 
# MAGIC #### 1 record subscriber per workspace per sku per day

# COMMAND ----------

SubscriberUsageDailydf = sql("""

select
sub.*,
  
  -- platform subcription id 
 up.sku ,
COALESCE(up.date, (select max(date) from main.fin_live_gold.dbu_dollars)) as dbu_date,
up.dbu_Price dbuPrice,
COALESCE(up.list_Price,0) listPrice,
COALESCE(up.DBU,0) DBU,
COALESCE(up.delta_DBU,0) deltaDBU,
COALESCE(up.non_Delta_DBU,0) nonDeltaDBU,
COALESCE(up.dbt_DBU,0)  dbtDBU,
COALESCE(up.fivetran_DBU,0) fivetranDBU,
COALESCE(up.isv_DBU,0) isvDBU, 
up.product_Account_Creation_Date productAccountCreationDate,
up.workspace_sfdc_object_id workspaceSFDCID,
up.sfdc_workspace_id workspaceID,
up.workspace_Creation_Date workspaceCreationDate,
up.poc_Flag pocFlag,
up.shard_Region shardRegion,
up.pricing_Tier pricingTier,
up.is_Paying isPaying,
up.type,
up.type_2,
up.product_Account_ID productAccountID,

COALESCE(dbu.discount_Price,0) discountPrice,
dbu.sub_bu,
COALESCE(dbu.dbu_Dollars,0) dbuDollars,
COALESCE(dbu.delta_Dollars,0) deltaDollars,
COALESCE(dbu.non_Delta_Dollars,0) nonDeltaDollars,
COALESCE(dbu.dbt_Dollars,0) dbtDollars,
COALESCE(dbu.fivetran_Dollars,0) fivetranDollars,
COALESCE(dbu.isv_Dollars,0) isvDollars,
COALESCE(dbu.dbu_Dollars_At_List,0) dbuDollarsAtList,
COALESCE(dbu.delta_Dollars_At_List,0) deltaDollarsAtList,
COALESCE(dbu.non_Delta_Dollars_At_List,0) nonDeltaDollarsAtList,
COALESCE(dbu.dbt_Dollars_At_List,0) dbtDollarsAtList,
COALESCE(dbu.fivetran_Dollars_At_List,0) fivetranDollarsAtList,
COALESCE(dbu.isv_Dollars_At_List,0) isvDollarsAtList,
COALESCE(up.list_Price * up.DBU, 0) as listDBUDollars,
case
  when up.is_paying = true and (up.dbu_Price is not null and up.dbu_Price > 0) then up.dbu_Price * up.DBU
  when up.is_paying = true and (up.dbu_Price is  null or up.dbu_Price = 0)  then COALESCE(up.list_Price * up.DBU,0)
  else 0
end as custDBUDollars

  
from
( select 

distinct 

offer_id,
aws_account_id,
encrypted_account_id,
tax_address_id,
email_domain,
country,
Cloud_Account_ID__c,
Platform_Account_ID__c,
company_name
from main.it_consumption_silver.aws_mp_payg_subscriber  ) as sub
left join 
  (select * from main.fin_live_gold.dbu_dollars where date >= '2022-05-10') up
on
up.product_Account_ID  = sub.Platform_Account_ID__c

left join

(select * from main.fin_live_gold.dbu_dollars where date >= '2022-05-10') dbu

on 
dbu.product_Account_ID  = up.product_Account_ID and up.date = dbu.date and up.sku = dbu.sku and up.sfdc_workspace_id = dbu.sfdc_workspace_id

where sub.aws_account_id != '132467079112' 
  
  """)
  


# COMMAND ----------

display(SubscriberUsageDailydf)

# COMMAND ----------

SubscriberUsageDailydf.registerTempTable("subscribe_rev")

# COMMAND ----------

display(SubscriberUsageDailydf)

# COMMAND ----------

SubscriberUsageDailydf.printSchema()


# COMMAND ----------

from pyspark.sql.types import DoubleType,DateType,StringType
SubscriberUsageDailydf = SubscriberUsageDailydf.withColumn("dbuPrice", SubscriberUsageDailydf["dbuPrice"].cast(DoubleType()))
SubscriberUsageDailydf = SubscriberUsageDailydf.withColumn("discountPrice", SubscriberUsageDailydf["discountPrice"].cast(DoubleType()))
SubscriberUsageDailydf = SubscriberUsageDailydf.withColumn("productAccountCreationDate", (SubscriberUsageDailydf["productAccountCreationDate"]).cast(StringType()))
SubscriberUsageDailydf = SubscriberUsageDailydf.withColumn("workspaceCreationDate", (SubscriberUsageDailydf["workspaceCreationDate"]).cast(StringType()))


# COMMAND ----------

SubscriberUsageDailydf.write.mode("overwrite").format("delta").saveAsTable('main.it_consumption_silver.aws_mp_payg_subscriber_usage_daily')


# COMMAND ----------

# SubscriberUsageDailydeltaTable = DeltaTable.forName(spark, 'bdw.aws_mp_payg_subscriber_usage_daily')

# COMMAND ----------

# SubscriberUsageDailydeltaTable.alias("old_rev").merge(
#     SubscriberUsageDailydf.alias("new_rev"),
#     "old_rev.agreement_id  = new_rev.agreement_id      and old_rev.start_date    = new_rev.start_date        and old_rev.end_date  = new_rev.end_date and old_rev.aws_account_id   = new_rev.aws_account_id               and old_rev.mailing_address_id   = new_rev.mailing_address_id  and old_rev.Cloud_Account_ID__c  = new_rev.Cloud_Account_ID__c             and old_rev.Platform_Account_ID__c = new_rev.Platform_Account_ID__c    and old_rev.sku   = new_rev.sku and old_rev.workspaceID = new_rev.workspaceID and new_rev.dbu_date = old_rev.dbu_date") \
#   .whenNotMatchedInsertAll() \
#   .execute()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Monthly insert

# COMMAND ----------

monthly_df = sql("""select
  
  
offer_id,
b.aws_account_id,
encrypted_account_id,
tax_address_id,
email_domain,
country,
Cloud_Account_ID__c,
company_name,

  COALESCE(month_end_date,cast(last_day(current_date()) as string)) as month_end_date,
  COALESCE(DBU,0) as DBU,
  COALESCE(custDBUDollars,0) as custDBUDollars,
  COALESCE(listDBUDollars,0) as listDBUDollars
from
  (select 

distinct 

offer_id,
aws_account_id,
encrypted_account_id,
tax_address_id,
email_domain,
country,
Cloud_Account_ID__c,
company_name


from main.it_consumption_silver.aws_mp_payg_subscriber) b 
  left join 
   (
    select
      last_day(dbu_date) as month_end_date,
      aws_account_id,
      COALESCE(sum(DBU) ,0 )as DBU,
      COALESCE(sum(custDBUDollars),0) as custDBUDollars,
      COALESCE(sum(listDBUDollars),0) as listDBUDollars
    from
      main.it_consumption_silver.aws_mp_payg_subscriber_usage_daily
    where
      
    group by
      last_day(dbu_date),
      aws_account_id
  ) a
  
  on a.aws_account_id = b.aws_account_id""")

# COMMAND ----------

# monthly_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save('/mnt/bse-dev/aws_mp_payg_subscriber_usage_monthly')# monthly_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save('/mnt/bse-dev/aws_mp_payg_subscriber_usage_monthly')

# COMMAND ----------

display(monthly_df)

# COMMAND ----------

monthly_df.write.mode("overwrite").format("delta").saveAsTable('main.it_consumption_silver.aws_mp_payg_subscriber_usage_monthly')


# COMMAND ----------

# %sql

# create or replace table bdw_dev.aws_mp_payg_subscriber_usage_monthly_test clone bdw.aws_mp_payg_subscriber_usage_monthly 

# COMMAND ----------


