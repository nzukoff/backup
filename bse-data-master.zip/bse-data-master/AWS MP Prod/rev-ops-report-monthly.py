# Databricks notebook source
access_key = dbutils.secrets.get(scope = "bse-dev-creds", key = "bse-awsmp-accesskeyid")
secret_key = dbutils.secrets.get(scope = "bse-dev-creds", key = "bse-awsmp-secretkey")
#encoded_secret_key = secret_key.replace("/", "%2F")

aws_bucket_name = "databricks-bucket-marketplace-fda"
sc._jsc.hadoopConfiguration().set("fs.s3a.access.key", access_key)
sc._jsc.hadoopConfiguration().set("fs.s3a.secret.key", secret_key)

aws_region = "us-east-2"
sc._jsc.hadoopConfiguration().set("fs.s3a.endpoint", "s3." + aws_region + ".amazonaws.com")

# COMMAND ----------

productFeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/ProductFeed_V1/", header = True)

productFeed_df.createOrReplaceTempView("productfeed_v1")

# COMMAND ----------

offerProductfeed_df = spark.read.option("delimiter", ",").csv("s3a://databricks-bucket-marketplace-fda/OfferProductFeed_V1/", header = True)

offerProductfeed_df.createOrReplaceTempView("offerproductfeed_v1")

# COMMAND ----------

import datetime
import calendar

# Get today's date
now = datetime.datetime.now()

# Get the first day of the current month
first_day = datetime.datetime(now.year, now.month, 1)

# Get the last day of the previous month
last_day_prev_month = first_day - datetime.timedelta(days=1)

# Get the first day of the previous month
first_day_prev_month = datetime.datetime(last_day_prev_month.year, last_day_prev_month.month, 1)

last_day_prev = last_day_prev_month.date()
first_day_prev = first_day_prev_month.date()

print("First day of previous month:", first_day_prev)
print("Last day of previous month:",last_day_prev)

# COMMAND ----------

#change integration to main for all by a search before prod migration - change done.
monthly_rev_ops_df = sql("""


with products_with_uni_temporal_data as (
    select
        *
    from
    (
        select
         *,
         ROW_NUMBER() OVER (PARTITION BY product_id, valid_from ORDER BY to_timestamp(update_date) desc) as row_num
        from
         productfeed_v1
      )
    where
        -- keep latest ...
        row_num = 1
        -- ... and remove the soft-deleted one.
        and (delete_date is null or delete_date = '')
),
offers_with_uni_temporal_data as (
    select
        *
    from
    (
        select
            *,
            ROW_NUMBER() OVER (PARTITION BY offer_id, valid_from ORDER BY to_timestamp(update_date) desc) as row_num
        from
            offerproductfeed_v1
    )
    where
        -- keep latest ...
        row_num = 1
        -- ... and remove the soft-deleted one.
        and (delete_date is null or delete_date = '')
),

offers_product_view  as (

select distinct 

o.offer_id,
o.product_id,
p.title as productTitle


from 
offers_with_uni_temporal_data o
join 
products_with_uni_temporal_data p
on
o.product_id = p.product_id

)




select

  b.*,
  b.Cloud_Account_ID__c as EndCustomerAWSAccountID,
  pv.product_id,
  pv.productTitle,
  a.InvoiceID,
  a.TransactionReferenceID,
  a.InvoiceDate,
  coalesce(a.UsagePeriodStartDate,'{first_day_prev_month}T00:00:00Z') as UsagePeriodStartDate,
  coalesce(a.UsagePeriodEndDate, '{last_day_of_prev_month}T23:59:59Z') as UsagePeriodEndDate,
  a.GrossRevenue,
  a.GrossRefund,
  a.ListingFee,
  a.ListingFeeRefund,
  a.AWSTaxShare,
  a.AWSTaxShareRefund,
  a.SellerTaxShare,
  a.SellerTaxShareRefund,
  a.COGS,
  a.COGSRefund,
  a.SellerNetRevenue,
  a.DisbursementFlag,
  a.LastDisbursementDate,
  a.DisburseBankTraceId,
  a.BrokerID

from
  
   (
    select
      *
    from
      main.it_consumption_silver.aws_mp_payg_subscriber_usage_monthly
    where
      month_end_date = '{last_day_of_prev_month}'
  )b
   left join 
  (
    select
      *
    from
      main.it_consumption_silver.aws_mp_payg_subscriber_monthly_revenue
    where
      ProductTitle != 'Databricks Unified Analytics Platform - Annual Commitment v3'
      and PayerAWSAccountID != '665428379115'
      and UsagePeriodStartDate >= '{first_day_prev_month}'
      and AgreementEndDate = '9999-01-01T00:00:00Z'
  ) a
  on a.EndUserEncryptedAccountID = b.Cloud_Account_ID__c
left join 

offers_product_view pv

on 
b.offer_id = pv.offer_id
  """.format(last_day_of_prev_month= last_day_prev,first_day_prev_month = first_day_prev))

# COMMAND ----------

display(monthly_rev_ops_df)

# COMMAND ----------

monthly_rev_ops_df.createOrReplaceTempView("monthly_rev_ops_df_table")

# COMMAND ----------

#change to main before prod migration  - change done 
from delta.tables import *
aws_mp_payg_revops_monthlydeltaTable = DeltaTable.forName(spark, 'main.it_consumption_silver.aws_mp_payg_revops_monthly')  

# COMMAND ----------

aws_mp_payg_revops_monthlydeltaTable.alias("old_sub").merge(
    monthly_rev_ops_df.alias("new_sub"),
    "old_sub.encrypted_account_id = new_sub.encrypted_account_id and old_sub.month_end_date = new_sub.month_end_date  ") \
  .whenNotMatchedInsertAll() \
  .execute()

# COMMAND ----------

# aws_mp_payg_revops_monthlydeltaTable.alias("old_sub").merge(
#     monthly_rev_ops_df.alias("new_sub"),
#     "old_sub.encrypted_account_id = new_sub.encrypted_account_id and old_sub.month_end_date = new_sub.month_end_date  ") \
#   .whenMatchedUpdateAll() \
#   .execute()

# COMMAND ----------

# # Define the input and output formats and paths and the table name.
# write_format = 'delta'
# save_path = '/mnt/bse-dev/aws_mp_payg_revops_monthly'
# table_name = 'bdw.aws_mp_payg_revops_monthly'



# # Write the data to its target.
# monthly_rev_ops_df.write \
#   .format(write_format) \
#   .save(save_path)

# # Create the table.
# spark.sql("CREATE TABLE " + table_name + " USING DELTA LOCATION '" + save_path + "'")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select
# MAGIC       *
# MAGIC     from
# MAGIC       main.it_consumption_silver.aws_mp_payg_subscriber_monthly_revenue
# MAGIC     where
# MAGIC       ProductTitle != 'Databricks Unified Analytics Platform - Annual Commitment v3'
# MAGIC       and PayerAWSAccountID != '665428379115'
# MAGIC       and UsagePeriodStartDate >= '2022-11-01'
# MAGIC       and AgreementEndDate = '9999-01-01T00:00:00Z'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select encrypted_account_id, count(*) from main.it_consumption_silver.aws_mp_payg_revops_monthly where month_end_date  = '2022-10-31' group by encrypted_account_id

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from main.it_consumption_silver.aws_mp_payg_revops_monthly where month_end_date  = '2022-10-31' 

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct * from monthly_rev_ops_df_table;
# MAGIC
# MAGIC
# MAGIC with duplicates_records as (
# MAGIC select encrypted_account_id, count(*) as dup_count from monthly_rev_ops_df_table group by encrypted_account_id)
# MAGIC
# MAGIC select distinct * from monthly_rev_ops_df_table where encrypted_account_id in (select distinct encrypted_account_id from  duplicates_records where dup_count > 1  )

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select
# MAGIC       *
# MAGIC     from
# MAGIC       main.it_consumption_silver.aws_mp_payg_subscriber

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select
# MAGIC      count( distinct(
# MAGIC aws_account_id))
# MAGIC     from
# MAGIC       main.it_consumption_silver.aws_mp_payg_subscriber

# COMMAND ----------


