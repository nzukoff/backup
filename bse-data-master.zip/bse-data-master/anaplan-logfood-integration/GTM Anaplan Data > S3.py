# Databricks notebook source
# MAGIC %md
# MAGIC 1. Connect to S3 Bucket

# COMMAND ----------

from io import StringIO # python3; python2: BytesIO 
import boto3
import pandas as pd
import pyspark.sql.functions as F

access_key = dbutils.secrets.get(scope = "api-creds", key = "anaplan-accesskey")
secret_key = dbutils.secrets.get(scope = "api-creds", key = "anaplan-secretskey")

sc._jsc.hadoopConfiguration().set("fs.s3a.access.key", access_key)
sc._jsc.hadoopConfiguration().set("fs.s3a.secret.key", secret_key)

aws_bucket_name = "anaplan-datahub"
aws_region = "us-west-2"
sc._jsc.hadoopConfiguration().set("fs.s3a.endpoint", "s3." + aws_region + ".amazonaws.com")

s3_resource = boto3.client("s3",\
                    region_name='us-west-2',\
                    aws_access_key_id=access_key,\
                    aws_secret_access_key=secret_key)

base_target_path = 'quota_planning/export-to-anaplan'

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Defining Target Path and file format

# COMMAND ----------

def upload_df_to_s3(pandas_df, target_path):
    csv_buf = StringIO()
    pandas_df.to_csv(csv_buf, header=True, index=False)
    csv_buf.seek(0)
    return s3_resource.put_object(Bucket=aws_bucket_name, Body=csv_buf.getvalue(), Key=target_path)

# COMMAND ----------

# MAGIC %md
# MAGIC 3. Query the Data

# COMMAND ----------

# MAGIC %md
# MAGIC #LogFood_AccountBaseTable.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view account_firmagraphics as
# MAGIC select 
# MAGIC AccountID_CaseSafe__c,
# MAGIC Name,
# MAGIC OwnerId,
# MAGIC Interim_Coverage_Account__c,
# MAGIC Account_Status__c,
# MAGIC Ultimate_parent_account_casesafe_ID__c,
# MAGIC Ultimate_Parent_Account__c,
# MAGIC Enriched_Ultimate_Parent_Account_ID__c,
# MAGIC Enriched_Ultimate_Parent_Account_Name__c,
# MAGIC parentid,
# MAGIC Employees__c,
# MAGIC Enriched_Employees__c,
# MAGIC Enriched_Industry__c,
# MAGIC Enriched_Vertical__c,
# MAGIC Databricks_Vertical_Map_New__c,
# MAGIC T3M_DBU__c,
# MAGIC T3M_DBU_Annualised__c,
# MAGIC T3M_ARR__c,
# MAGIC ARR__c,
# MAGIC Next_Renewal_Date__c,
# MAGIC Next_12_Months_Cloud_Services_Spend__c,
# MAGIC --dfox__Revenue_Estimate__c,
# MAGIC --dfox__Keywords__c,
# MAGIC --dfox__Total_Funding__c, 
# MAGIC BRAG_Status__c, 
# MAGIC Sub_Industry__c,   
# MAGIC accountBuyingStage6sense_Databricks__c,
# MAGIC SCP_Enrollment_Date__c, 
# MAGIC CustomerType__c,
# MAGIC Owner_Manager__c,
# MAGIC Rollup_Current_Quarter_Actuals_DS_foreca__c,
# MAGIC Rollup_Current_Quarter_AE_DBU_Forecast__c,
# MAGIC Enriched_Country__c,
# MAGIC Enriched_State__c,
# MAGIC Enriched_City__c,
# MAGIC Enriched_Postal_Code__c,
# MAGIC Split__c,
# MAGIC Split_Percent__c,
# MAGIC PVC_Account_Tag__c,
# MAGIC Next_Renewal_Quarter__c,
# MAGIC Commit_Customer_Date__c, 
# MAGIC Open_Opportunity_Count__c,
# MAGIC Upcoming_Renewal_Amount__c,
# MAGIC Enriched_Sector__c,
# MAGIC Industry,
# MAGIC Sector__c,
# MAGIC accountIntentScore6sense_Databricks__c,
# MAGIC accountProfileFit6sense_Databricks__c,
# MAGIC Business_Unit__c,
# MAGIC DBX__c,
# MAGIC Account_Type__c,
# MAGIC Segment__c,
# MAGIC Enriched_Parent_Account_ID__c,
# MAGIC account.Enriched_Parent_Name__c
# MAGIC
# MAGIC
# MAGIC
# MAGIC FROM main.sfdc_bronze.account 
# MAGIC WHERE processdate = (select max(processdate) from main.sfdc_bronze.account);
# MAGIC
# MAGIC select * from account_firmagraphics

# COMMAND ----------

# MAGIC %md
# MAGIC S3 Bucket - Naming Account Firmagraphics Table Above

# COMMAND ----------

pandas_df = spark.table("account_firmagraphics").toPandas()
csv_file_name = "LogFood_AccountBaseTable.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------

# MAGIC %md
# MAGIC #LogFood_UserTable.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view user_base_data as
# MAGIC select X18_char_User_ID__c, 
# MAGIC name,
# MAGIC Username,
# MAGIC AE_Segment__c,
# MAGIC AEType__c,
# MAGIC Workday_ID__c,
# MAGIC ManagerID,
# MAGIC Business_Unit__c,
# MAGIC Region_Level_1__c,
# MAGIC Region_Level_2__c,
# MAGIC Region_Level_3__c,
# MAGIC Region_Level_4__c
# MAGIC
# MAGIC FROM main.sfdc_bronze.user 
# MAGIC where Username LIKE '%databricks%'
# MAGIC AND processdate = (select max(processdate) from main.sfdc_bronze.user);
# MAGIC
# MAGIC select * from user_base_data

# COMMAND ----------

pandas_df = spark.table("user_base_data").toPandas()
csv_file_name = "LogFood_UserTable.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------

# MAGIC %md
# MAGIC #LogFood_OpportunityData.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view logfood_opportunity_data as
# MAGIC select
# MAGIC account_id,
# MAGIC opportunity_id,
# MAGIC lost_reason,
# MAGIC prospecting_stage_date_stamp,
# MAGIC poc_scoping_stage_date_stamp,
# MAGIC proposal_stage_date_stamp,
# MAGIC validate_stage_date_stamp,
# MAGIC evaluation_stage_date_stamp,
# MAGIC negotiation_stage_date_stamp,
# MAGIC platform,
# MAGIC opportunity_name,
# MAGIC opportunity_type,
# MAGIC opportunity_stage,
# MAGIC is_closed,
# MAGIC is_won,
# MAGIC amount,
# MAGIC commit_amount,
# MAGIC subscription_total,
# MAGIC incremental_booking_arr,
# MAGIC gross_renewal_rate,
# MAGIC created_date,
# MAGIC close_date,
# MAGIC effective_renewal_date,
# MAGIC signed_stage_date_stamp,
# MAGIC opportunity_owner_id,
# MAGIC total_price,
# MAGIC ATR,
# MAGIC incremental_booking_forecast,
# MAGIC is_renewal,
# MAGIC is_new_business,
# MAGIC is_upsell,
# MAGIC close_date_logic_owner_id,
# MAGIC close_date_logic_owner_name
# MAGIC from focus_prod.core_opportunity_curated
# MAGIC where 
# MAGIC 1=1
# MAGIC AND snapshot_date = (SELECT MAX(snapshot_date) FROM focus_prod.core_opportunity_curated)
# MAGIC AND close_date_fiscal_year > 2023;
# MAGIC
# MAGIC select * from logfood_opportunity_data
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

pandas_df = spark.table("logfood_opportunity_data").toPandas()
csv_file_name = "LogFood_OpportunityData.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------

# MAGIC %md
# MAGIC #LogFood_DS Forecast.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table sales_operations_dev.ds_forecast as
# MAGIC
# MAGIC select 
# MAGIC accountid,
# MAGIC revShareDollars,
# MAGIC revShareForecastDollars_new,
# MAGIC month_end_date
# MAGIC from main.it_consumption_silver.usagec_account_monthly;
# MAGIC select * from sales_operations_dev.ds_forecast

# COMMAND ----------

pandas_df = spark.table("sales_operations_dev.ds_forecast").toPandas()
csv_file_name = "LogFood_DS Forecast.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------

# MAGIC %md #LogFood_T28D.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.team_sales_salesexecution.L28_Consumption

# COMMAND ----------

pandas_df = spark.table("main.team_sales_salesexecution.L28_Consumption").toPandas()
csv_file_name = "LogFood_T28D.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------

# MAGIC %md #LogFood_Consumption.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view logfood_consumption as
# MAGIC select 
# MAGIC accountid,
# MAGIC platform,
# MAGIC date,
# MAGIC date_part('month',date )as month,
# MAGIC concat(month,'-',LEFT(date,4)) as month_year,
# MAGIC total_dollars,
# MAGIC delta_dollars,
# MAGIC sql_dollars,
# MAGIC streaming_dollars,
# MAGIC uc_dollars
# MAGIC --ml_serving_dollars,
# MAGIC  from main.team_sales_salesexecution.Daily_Consumption
# MAGIC where 
# MAGIC date_part('year',date ) = 2023;
# MAGIC
# MAGIC select * from logfood_consumption

# COMMAND ----------

pandas_df = spark.table("logfood_consumption").toPandas()
csv_file_name = "LogFood_Consumption.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------


