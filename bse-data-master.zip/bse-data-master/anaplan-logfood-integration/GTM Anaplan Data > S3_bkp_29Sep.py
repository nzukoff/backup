# Databricks notebook source
# MAGIC %md
# MAGIC 1. Connect to S3 Bucket

# COMMAND ----------

from io import StringIO # python3; python2: BytesIO 
import boto3
import pandas as pd

access_key = dbutils.secrets.get(scope = "api-creds", key = "anaplan-accesskey")
secret_key = dbutils.secrets.get(scope = "api-creds", key = "anaplan-secretskey")

sc._jsc.hadoopConfiguration().set("fs.s3a.access.key", access_key)
sc._jsc.hadoopConfiguration().set("fs.s3a.secret.key", secret_key)

aws_bucket_name = "anaplan-datahub"
aws_region = "us-west-2"
sc._jsc.hadoopConfiguration().set("fs.s3a.endpoint", "s3." + aws_region + ".amazonaws.com")

s3_resource = boto3.client("s3",\
                    region_name='us-west-2',\
                    aws_access_key_id=access_key,\
                    aws_secret_access_key=secret_key)

base_target_path = 'quota_planning/export-to-anaplan'

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Defining Target Path and file format

# COMMAND ----------

def upload_df_to_s3(pandas_df, target_path):
    csv_buf = StringIO()
    pandas_df.to_csv(csv_buf, header=True, index=False)
    csv_buf.seek(0)
    return s3_resource.put_object(Bucket=aws_bucket_name, Body=csv_buf.getvalue(), Key=target_path)

# COMMAND ----------

# MAGIC %md
# MAGIC 3. Query the Data

# COMMAND ----------

# MAGIC %md
# MAGIC LogFood_AccountBaseTable.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view account_firmagraphics as
# MAGIC select 
# MAGIC AccountID_CaseSafe__c,
# MAGIC Name,
# MAGIC OwnerId,
# MAGIC Interim_Coverage_Account__c,
# MAGIC Account_Status__c,
# MAGIC Ultimate_parent_account_casesafe_ID__c,
# MAGIC Ultimate_Parent_Account__c,
# MAGIC Enriched_Ultimate_Parent_Account_ID__c,
# MAGIC Enriched_Ultimate_Parent_Account_Name__c,
# MAGIC Employees__c,
# MAGIC Enriched_Employees__c,
# MAGIC Enriched_Industry__c,
# MAGIC Enriched_Vertical__c,
# MAGIC Databricks_Vertical_Map_New__c,
# MAGIC T3M_DBU__c,
# MAGIC T3M_DBU_Annualised__c,
# MAGIC T3M_ARR__c,
# MAGIC ARR__c,
# MAGIC Top_25__c,
# MAGIC Strategic_Account__c,
# MAGIC X30_Account__c,
# MAGIC Next_Renewal_Date__c,
# MAGIC Next_12_Months_Cloud_Services_Spend__c,
# MAGIC dfox__Revenue_Estimate__c,
# MAGIC dfox__Keywords__c,
# MAGIC dfox__Total_Funding__c, 
# MAGIC BRAG_Status__c, 
# MAGIC Sub_Industry__c,   
# MAGIC accountBuyingStage6sense_Databricks__c,
# MAGIC SCP_Enrollment_Date__c, 
# MAGIC CustomerType__c,
# MAGIC Owner_Manager__c,
# MAGIC Rollup_Current_Quarter_Actuals_DS_foreca__c,
# MAGIC Rollup_Current_Quarter_AE_DBU_Forecast__c,
# MAGIC Enriched_Country__c,
# MAGIC Enriched_State__c,
# MAGIC Enriched_City__c,
# MAGIC Enriched_Postal_Code__c,
# MAGIC Split__c,
# MAGIC Split_Percent__c,
# MAGIC PVC_Account_Tag__c,
# MAGIC Next_Renewal_Quarter__c,
# MAGIC Commit_Customer_Date__c, 
# MAGIC Open_Opportunity_Count__c,
# MAGIC Upcoming_Renewal_Amount__c,
# MAGIC Enriched_Sector__c,
# MAGIC Industry,
# MAGIC Sector__c,
# MAGIC accountIntentScore6sense_Databricks__c,
# MAGIC accountProfileFit6sense_Databricks__c,
# MAGIC CurrencyIsoCode
# MAGIC
# MAGIC
# MAGIC FROM sfdc_prod.account 
# MAGIC WHERE processdate = (select max(processdate) from sfdc_prod.account);
# MAGIC
# MAGIC select * from account_firmagraphics

# COMMAND ----------

# MAGIC %md
# MAGIC S3 Bucket - Naming Account Firmagraphics Table Above

# COMMAND ----------

pandas_df = spark.table("account_firmagraphics").toPandas()
csv_file_name = "LogFood_AccountBaseTable.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------

# MAGIC %md
# MAGIC LogFood_UserTable.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view user_base_data as
# MAGIC select X18_char_User_ID__c, 
# MAGIC Username, 
# MAGIC name,
# MAGIC Business_Unit__c,
# MAGIC Region_Level_1__c,
# MAGIC Region_Level_2__c,
# MAGIC Region_Level_3__c 
# MAGIC
# MAGIC FROM sfdc_prod.user 
# MAGIC where Username LIKE '%databricks%'
# MAGIC AND processdate = (select max(processdate) from sfdc_prod.user);
# MAGIC
# MAGIC select * from user_base_data

# COMMAND ----------

pandas_df = spark.table("user_base_data").toPandas()
csv_file_name = "LogFood_UserTable.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------

# MAGIC %md
# MAGIC LogFood_OpportunityTable.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view commit_ops_ds as
# MAGIC select
# MAGIC account.Account_Type__c	as account_segment,
# MAGIC account.Business_Unit__c as business_unit,
# MAGIC account.id as account_id,
# MAGIC account.name as account_name,
# MAGIC opportunity.amount as amount,
# MAGIC opportunity.Billing_Schedule__c	as billing_schedule,
# MAGIC opportunity.CloseDate as oppty_close_date,
# MAGIC opportunity.CPQ_Closed_Won__c as cpq_closed_won,
# MAGIC opportunity.CPQ_Incremental_Booking_ARR__c as incremental_booking_revenue,
# MAGIC opportunity.CPQ_Renewal_Booking_ARR__c as CPQ_renewal_booking_ARR,
# MAGIC opportunity.End_Date__c	as oppty_end_date,
# MAGIC opportunity.ForecastCategoryName as forecast_category,
# MAGIC opportunity.id as oppty_id,
# MAGIC opportunity.name as oppty_name,
# MAGIC opportunity.NumberOfTermNewBuss__c	as number_of_term_newbuss,
# MAGIC opportunity.OM_Original_Opportunity_ID__c as OM_original_opportunity_id,
# MAGIC opportunity.OpportunityID_CaseSafe__c as opportunityID_casesafe,
# MAGIC opportunity.Platform_Type__c as platform_type,
# MAGIC opportunity.Pricebook2Id as pricebook2Id,
# MAGIC opportunity.primary_competitor__c as primary_competitor,
# MAGIC opportunity.Sales_Ops_Validated__c as sales_ops_validated,
# MAGIC opportunity.SBQQ__PrimaryQuote__c as SBQQ__primary_quote,
# MAGIC opportunity.Signed_Stage_Date_Stamp__c	as signed_stage_date_stamp,
# MAGIC opportunity.StageName as oppty_stage,
# MAGIC opportunity.Start_Date__c as start_date,
# MAGIC opportunity.TCV__c as oppty_tcv,
# MAGIC opportunity.CPQ_Booking_Total__c as oppty_booking_tcv,
# MAGIC opportunity.Term_Num__c	 as oppty_term_num,
# MAGIC opportunity.Term__c	as oppty_term,
# MAGIC opportunity.Total_Contract_Value__c	as oppty_total_contract_value,
# MAGIC opportunity.Type as oppty_type,
# MAGIC opportunity.SBQQ__RenewedContract__c as CPQNotNull,
# MAGIC opportunity.User_Business_Unit__c as user_business_unit,
# MAGIC opportunitylineitem.Cloud_Type__c as cloud_type,
# MAGIC opportunitylineitem.id	as oppty_lineitem_id,
# MAGIC lower(opportunitylineitem.id) as oppty_lineitem_id_lower_case,
# MAGIC opportunitylineitem.Incremental_Booking_Total_Fcst__c as incremental_booking_total_fcst,
# MAGIC opportunitylineitem.ListPrice as list_price,
# MAGIC opportunitylineitem.Product2Id	as Product2Id,
# MAGIC opportunitylineitem.Renewal_Booking_Total_Fcst__c as renewal_booking_total_fcst,
# MAGIC opportunitylineitem.TotalPrice as TotalPrice,
# MAGIC opportunitylineitem.UnitPrice as UnitPrice,
# MAGIC opportunitylineitem.CPQ_Renewal_Booking_ARR__c as ATR2,
# MAGIC pricebook2.name	as pricebook2_name,
# MAGIC product2.Family	product_family,
# MAGIC product2.name as product2_name,
# MAGIC account.OwnerId as account_owner_id,
# MAGIC user.name as oppty_owner,
# MAGIC opportunity.ownerid as oppty_owner_id,
# MAGIC opportunity.atg_Total_Amount__c as atg_Total_Amount__c,
# MAGIC opportunity.VP_Forecast__c as VP_Forecast__c,
# MAGIC opportunity.ARR_Renewal_Amount__c	as ATR
# MAGIC
# MAGIC 	
# MAGIC
# MAGIC
# MAGIC
# MAGIC FROM sfdc_prod.account
# MAGIC INNER JOIN sfdc_prod.opportunity on account.id = opportunity.AccountId and opportunity.processdate = (select max(processdate) from sfdc_prod.opportunity)
# MAGIC LEFT JOIN sfdc_prod.user on opportunity.ownerid = user.id and user.processdate = (select max(processdate) from sfdc_prod.user)
# MAGIC LEFT JOIN sfdc_prod.opportunitylineitem on opportunitylineitem.OpportunityId = opportunity.id and opportunitylineitem.processdate = (select max(processdate) from sfdc_prod.opportunitylineitem)
# MAGIC LEFT JOIN sfdc_prod.product2 on product2.id = opportunitylineitem.Product2Id and product2.processdate = (select max(processdate) from sfdc_prod.product2)
# MAGIC LEFT JOIN sfdc_prod.pricebook2 on opportunity.Pricebook2Id = pricebook2.id and pricebook2.processdate = (select max(processdate) from sfdc_prod.pricebook2)
# MAGIC
# MAGIC where account.processdate = (select max(processdate) from sfdc_prod.account) and opportunity.type in ('Upsell','Renewal','New Business','Pilot') and opportunity.StageName in ('Prospecting','Closed Won', 'Evaluation','Validate','Signed','Proposal','POC Scoping','Negotiation / Procurement');
# MAGIC
# MAGIC select * from commit_ops_ds

# COMMAND ----------

pandas_df = spark.table("commit_ops_ds").toPandas()
csv_file_name = "LogFood_OpportunityTable.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------

# MAGIC %md
# MAGIC LogFood_DS Forecast.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table sales_operations_dev.ds_forecast as
# MAGIC
# MAGIC select 
# MAGIC accountid,
# MAGIC revShareDollars,
# MAGIC revShareForecastDollars_new,
# MAGIC month_end_date
# MAGIC from bdw.usagec_account_monthly;
# MAGIC select * from sales_operations_dev.ds_forecast

# COMMAND ----------

pandas_df = spark.table("sales_operations_dev.ds_forecast").toPandas()
csv_file_name = "LogFood_DS Forecast.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------

# MAGIC %md LogFood_T28D.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.team_sales_salesexecution.L28_Consumption

# COMMAND ----------

pandas_df = spark.table("main.team_sales_salesexecution.L28_Consumption").toPandas()
csv_file_name = "LogFood_T28D.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)

# COMMAND ----------

# MAGIC %md LogFood_Consumption.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC accountid,
# MAGIC platform,
# MAGIC date_part('month',date )as month,
# MAGIC concat(month,'-',right(fiscal_quarter,4)) as month_year,
# MAGIC total_dollars,
# MAGIC delta_dollars,
# MAGIC sql_dollars,
# MAGIC streaming_dollars,
# MAGIC table_source
# MAGIC  from main.team_sales_salesexecution.Daily_Consumption
# MAGIC where date between "2022" and "2023";

# COMMAND ----------

pandas_df = spark.table("main.team_sales_salesexecution.Daily_Consumption").toPandas()
csv_file_name = "LogFood_Consumption.csv"
target_path = f"{base_target_path}/{csv_file_name}"
print(f"target_path: {target_path}")
upload_df_to_s3(pandas_df, target_path)
