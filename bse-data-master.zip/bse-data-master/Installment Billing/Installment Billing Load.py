# Databricks notebook source
# MAGIC %run "./Installment_Billing_Config"

# COMMAND ----------

full_table_name = f'{catalog_nm}.{tgt_db_nm}.{post_tbl_nm}'
print(full_table_name)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Delete all data from pre table first

# COMMAND ----------

DeletePreDataLoad = (f'''
DELETE FROM {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm} 
''' )

sql(DeletePreDataLoad)

# COMMAND ----------

# DBTITLE 1,Load Data
df_scheduled_payments = spark.sql(f'''
                SELECT 
                    companyname,
                    sfdc_account_id,
                    SALESFORCE_OPPORTUNITY_ID ,
                    LIST_ITEM_NAME,
                    Marketplace_FLAG,
                    TAX_LINE_FLAG,
                    Non_TAX_LINE_FLAG,
                    TE_ORDER_FLAG,

                    ZAB_SUBSCRIPTION,
                    
                    PAYG_COMMIT_TYPE,
                    Burst_Order_flag,
                    Burst_order_flag_direct,
                    ZAB_SUBSCRIPTION_INTERNAL_ID,
                    SUPERSEDE as Is_Supersede_subscription,
                    PRIOR_ORDER_ID,
                    PRIOR_SUBSCRIPTION_ID,
                    discount_item_unit_price,
                    
                    bill_amt_check,
                    discount_dollar,
                    transaction_line_amount,
                    case when time_range_filter ='include' then 'UPCOMING' else 'PAST' end as Payment_Details,
                    so_create_date,
                    ZAB_PLAN_NAME,

                    customer_id,
                    customer_full_name,
                    end_customer_companyname,
                    end_customer_name,
                    tranid as so_number,
                    transaction_id,
                    item_id,
                    item_displayname,
                    product_family,
                    schedule_name,
                    transaction_line_id,
                    total_transaction_amount,
                    transaction_line_create_date,
                    bill_schedule_date,
                    payment_due_date,
                    pay_term_name,
                    transaction_line_quantity as billable_quantity,
                    transaction_line_billed_quantity as billed_quantity,
                    bill_schedule_count_cumulative as billable_schedule_quantity_cumulative,
                    bill_schedule_amount_final as bill_schedule_amount, --after discount line applied
                    processDate as last_refresh_date,
                    TRANSACTION_DISCOUNT_LINE,
                    time_range_filter,
                    order_status,
                    order_notes,
              
                    case 
                      when year(date(bill_schedule_date)) = 2100 then 'Future dated'
                      when bill_schedule_date is null then 'No Schedule'
                      when round(bill_schedule_count_cumulative,3) <= round(transaction_line_billed_quantity,3)  then 'Billed' 
                      else 'Unbilled' 
                    end as billed_status,
                    
                    dense_rank() over ( partition by year(bill_schedule_date), month(bill_schedule_date) 
                      order by  sum(bill_schedule_amount_final) over ( partition by year(bill_schedule_date), month(bill_schedule_date) , companyname ) desc ) as account_rank_by_schedulemonth_amount_company_name,
                    
                    dense_rank() over ( partition by year(payment_due_date), month(payment_due_date) 
                      order by  sum(bill_schedule_amount_final) over ( partition by year(payment_due_date), month(payment_due_date) , companyname ) desc ) as account_rank_by_paymonth_amount_company_name,

                    dense_rank() over ( partition by year(bill_schedule_date), month(bill_schedule_date) 
                      order by  sum(bill_schedule_amount_final) over ( partition by year(bill_schedule_date), month(bill_schedule_date) , coalesce(end_customer_companyname,companyname) ) desc ) as account_rank_by_schedulemonth_amount_end_customer_companyname,
                    
                    dense_rank() over ( partition by year(payment_due_date), month(payment_due_date) 
                      order by  sum(bill_schedule_amount_final) over ( partition by year(payment_due_date), month(payment_due_date) , coalesce(end_customer_companyname,companyname) ) desc ) as account_rank_by_paymonth_amount_end_customer_companyname,

                      tl_line_type
                      ,bs_line_type

                  from 
                  (
                  SELECT 
                      customer.sfdc_account_id sfdc_account_id, 
                      customer.customer_id customer_id,
                      customer.FULL_NAME customer_full_name,
                      otl.LIST_ITEM_NAME,
                      case when s.marketplace = 'T' then 'T' else 'N' end as Marketplace_FLAG,
                      case when sl.memo = 'AVATAX' then 'AVATAX line' else 'OTHER LINE' end as TAX_LINE_FLAG,
                      case when sl.memo like '%Not Taxable%' then 'Not taxable line' else 'OTHER LINE' end as Non_TAX_LINE_FLAG,
                      case when sl.memo like '%Travel Expenses%' or sl.memo like  '%T&E Expenses%' then 'TE order' else 'OTHER ORDER' end TE_ORDER_FLAG ,
                      sl.amount transaction_line_amount,
                      max(case when  sl.transaction_line_id = 0 then sl.amount else 0 end ) over (partition by sl.transaction_id) total_transaction_amount,

                      s.SALESFORCE_OPPORTUNITY_ID ,
                      coalesce(sub.ZAB_SUBSCRIPTION_NAME,s.ZAB_SUBSCRIPTION) ZAB_SUBSCRIPTION  ,
                      s.ZAB_SUBSCRIPTION_INTERNAL_ID,
                      sub.SUPERSEDE,
                      sub.PRIOR_ORDER_ID ,
                      sub.PRIOR_SUBSCRIPTION_MASTER_ID as PRIOR_SUBSCRIPTION_ID,
                      sl_discount.item_unit_price discount_item_unit_price ,
                      b.bill_amount bill_amt_check,
                      ((coalesce(float(replace(sl_discount.item_unit_price,' %','')),0) * b.bill_amount)/100) discount_dollar,
                      case when UPPER(PAYG_PLAN) = 'T' THEN 'PAYG' when UPPER(PAYG_PLAN) = 'F'  then 'COMMIT' else 'UNKNOWN' end PAYG_COMMIT_TYPE,
                      case when i.DISPLAYNAME  like '%Excess Usage%' then 'Burst order' else 'Other' end Burst_Order_flag,
                      case when s.burst = 'T' then 'T' else 'F' end Burst_order_flag_direct,

                      s.TRANDATE so_create_date,
                      plan.ZAB_PLAN_NAME,
                      s.status order_status,
                      s.order_notes,
                      s.processDate,
                      
                      case 
                          when 
                          (year(date(b.bill_date)) > year(s.processDate))
                          or ( year(date(b.bill_date)) = year(s.processDate) and month(date(b.bill_date)) >= month(s.processDate) ) 
                          then 'include'
                          else 'exclude'
                      end as time_range_filter,
                    s.transaction_id, 
                    s.tranid,
                    s.transaction_number,
                    s.transaction_type,
                    sl_discount.TRANSACTION_DISCOUNT_LINE,
                      
                    sl.transaction_line_id, 
                    sl.date_created transaction_line_create_date,
                    sl.item_id,
                    --p.list_item_name,
                    i.DISPLAYNAME as item_displayname, 
                    p.list_item_name as product_family, 
                      
                    c.companyname,
                    c.full_name,
                    
                    ec.companyname as end_customer_companyname,
                    ec.full_name as end_customer_name,

                      bd.name as schedule_name,
                      b.bill_amount as bill_schedule_amount_original, 
                    date(b.bill_date) as bill_schedule_date, 
                      date_add(date(b.bill_date),int(payterms.DAYS_UNTIL_DUE)) as payment_due_date,
                      payterms.name pay_term_name,
                      
                    abs(sl.ITEM_COUNT) as transaction_line_quantity,
                      sl.NUMBER_BILLED as transaction_line_billed_quantity, 
                      b.BILL_COUNT as bill_schedule_count,
                      sum(b.BILL_COUNT) over (partition by s.transaction_number,s.transaction_id,sl.transaction_line_id order by date(b.bill_date)) as bill_schedule_count_cumulative,
                      
                    sl.item_unit_price transaction_line_rate,
                      
                    (abs(sl.ITEM_COUNT) - sl.NUMBER_BILLED) * int(sl.item_unit_price) as unbilled_item_amount,
                    (abs(sl.ITEM_COUNT) - sl.NUMBER_BILLED) * b.bill_amount as unbilled_schedule_amount,
                    sl.NUMBER_BILLED * int(sl.item_unit_price) as billed_gross_amount,
                      
                      coalesce(float(replace(sl_discount.item_unit_price,' %','')),0) as discount,
                      
                      b.bill_amount + ((coalesce(float(replace(sl_discount.item_unit_price,' %','')),0) * b.bill_amount)/100) as bill_schedule_amount_final, 
                        
                      case 
                        when 
                        sl.NUMBER_BILLED <> abs(sl.ITEM_COUNT) and  --fully billed 
                        sl.transaction_line_id <> 0  --exclude 0 line
                        then 'include for analysis' else 'exclude for analysis' end as criteria 
                        -- Filter criteria for transaction line that are not revenue/schedule impacting 
                        , SL.CPQ_LINE_TYPE tl_line_type
                        , b.CPQ_LINE_TYPE bs_line_type
                    
                  FROM 
                    {catalog_nm}.it_netsuite_bronze.transactions s
                    
                    INNER join {catalog_nm}.it_netsuite_bronze.TRANSACTION_LINES sl
                      on  s.transaction_id = sl.transaction_id 
                      and sl.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.TRANSACTION_LINES)

                    left join {catalog_nm}.it_netsuite_bronze.billing_schedule b
                      on sl.transaction_id = b.transaction_id
                      and sl.transaction_line_id = b.transaction_line_id
                      and b.processDate =(select max(processdate) from  {catalog_nm}.it_netsuite_bronze.billing_schedule)

                    left join {catalog_nm}.it_netsuite_bronze.items i
                      on sl.item_id = i.item_id
                      and i.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.items)

                    left join {catalog_nm}.it_netsuite_bronze.product_family_list p
                      on i.PRODUCT_FAMILY_ID = p.LIST_ID 
                      and p.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.product_family_list)

                    left join {catalog_nm}.it_netsuite_bronze.customers c 
                      on s.entity_id = c.customer_id 
                      and c.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.customers)

                    left join {catalog_nm}.it_netsuite_bronze.customers ec
                      on s.end_customer_id = ec.customer_id 
                      and ec.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.customers)
                      
                    left join {catalog_nm}.it_netsuite_bronze.billing_schedule_descriptions  bd
                      on sl.billing_schedule_id = bd.billing_Schedule_id
                      and bd.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.billing_schedule_descriptions)
                      
                      left join {catalog_nm}.it_netsuite_bronze.TRANSACTION_LINES sl_discount
                          on  s.transaction_id = sl_discount.transaction_id 
                          and sl_discount.TRANSACTION_DISCOUNT_LINE = 'Yes'
                          and sl_discount.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.TRANSACTION_LINES)
                          
                          and charindex('%',sl_discount.item_unit_price)  > 0
                      
                      left join {catalog_nm}.it_netsuite_bronze.payment_terms payterms
                          on s.payment_terms_id = payterms.payment_terms_id 
                          and payterms.processDate  =(select max(processdate) from  {catalog_nm}.it_netsuite_bronze.payment_terms)
                      
                  left join {catalog_nm}.it_netsuite_bronze.customers customer
                    on s.entity_id = customer.customer_id
                    and customer.processdate =(select max(processdate) from  {catalog_nm}.it_netsuite_bronze.customers)


                    left join {catalog_nm}.it_netsuite_bronze.zab_subscription sub
                  on  s.ZAB_SUBSCRIPTION_INTERNAL_ID = sub.ZAB_SUBSCRIPTION_ID
                  and sub.processdate =(select max(processdate) from  {catalog_nm}.it_netsuite_bronze.zab_subscription)

                  left join {catalog_nm}.it_netsuite_bronze.zab_plan plan 
                  ON plan.ZAB_PLAN_ID = sub.CURRENT_PLAN_ID
                  and plan.processdate =(select max(processdate) from  {catalog_nm}.it_netsuite_bronze.zab_plan)

                  left join  {catalog_nm}.it_netsuite_bronze.order_type_list otl
                  on s.ORDER_TYPE_ID = otl.LIST_ID
                  and  otl.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.order_type_list)
                          
                  where 
                    s.transaction_type = 'Sales Order' 
                    and s.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.transactions)   --'2023-03-15'
                    -- and s.status not in ('Closed','Cancelled')
                    and s.status not in ('Cancelled')
                      --and sl.transaction_line_id <> 0
                  qualify row_number() over (partition by sl.transaction_id ,sl.transaction_line_id ,b.bill_date order by coalesce(sub.date_created,sl.date_created) desc  )  = 1
                  )
                            ''')

df_scheduled_payments.createOrReplaceTempView('scheduled_payments')

# COMMAND ----------

co_term_orders = spark.sql(f'''
                         
SELECT ct.id,
      ct.OpportunityId,
      ct.CPQ_Order_Type__c,
      ct.CPQ_Original_Order__c,
      ct.Contractid,
      ct.OrderNumber,
      ct.OriginalOrderId,
      oo.OpportunityId as originaloppid , 
      ct.SBQQ__Quote__c,ct.Type 
FROM 
  {catalog_nm}.sfdc_bronze.order ct
  inner  join 
  {catalog_nm}.sfdc_bronze.order oo
  on ct.CPQ_Original_Order__c = oo.id

where ct.processdate = (select max(processdate) from {catalog_nm}.sfdc_bronze.order) --and ordernumber = 'SO43272'
and oo.processdate = (select max(processdate) from {catalog_nm}.sfdc_bronze.order) --and ordernumber = 'SO43272'
--and  CPQ_Order_Type__c = 'Co-term'
--and ct.opportunityid in ('0064N00000ZN6eqQAD','0068Y00001OaJVeQAN')
and ct.CPQ_Order_type__c = 'Co-term' 

qualify row_number() over(partition by oo.OpportunityId order by ct.activateddate desc ) =1  '''
                           )
co_term_orders.createOrReplaceTempView('co_term_orders')                    

# COMMAND ----------

scheduled_payments_updated_with_co_term = spark.sql( 
'''select  coalesce(case when lower(tl_line_type) like '%amendment%' then cto.OpportunityId else  sp.ZAB_SUBSCRIPTION  end , 
          sp.ZAB_SUBSCRIPTION) as new_opp_id , 
          sp.* 
          
from scheduled_payments sp
left join  co_term_orders cto

on substr(trim(cto.originaloppid),0,15) = substr(trim(sp.ZAB_SUBSCRIPTION) ,0,15)''')

scheduled_payments_updated_with_co_term.createOrReplaceTempView ('scheduled_payments_updated_with_co_term')


# COMMAND ----------

co_term_orders_header = spark.sql( '''select distinct so_number,new_opp_id  
from scheduled_payments_updated_with_co_term
where lower(tl_line_type) like '%amendment%' ''') 

co_term_orders_header.createOrReplaceTempView('co_term_orders_header')

# COMMAND ----------

scheduled_payments_updated_with_co_term_extended = spark.sql(f'''
        SELECT 
        coalesce(header.new_opp_id,line.new_opp_id) as new_opp_id,
        case when header.so_number is not null then 'YES' ELSE 'NO' END CO_TERM_FLAG,
        line.companyname,
        line.sfdc_account_id,
        line.SALESFORCE_OPPORTUNITY_ID,
        line.LIST_ITEM_NAME,
        line.Marketplace_FLAG,
        line.TAX_LINE_FLAG,
        line.Non_TAX_LINE_FLAG,
        line.TE_ORDER_FLAG,
        line.ZAB_SUBSCRIPTION,
        line.PAYG_COMMIT_TYPE,
        line.Burst_Order_flag,
        line.Burst_order_flag_direct,
        line.ZAB_SUBSCRIPTION_INTERNAL_ID,
        line.Is_Supersede_subscription,
        line.PRIOR_ORDER_ID,
        line.PRIOR_SUBSCRIPTION_ID,
        line.discount_item_unit_price,
        line.bill_amt_check,
        line.discount_dollar,
        line.transaction_line_amount,
        line.payment_Details,
        line.so_create_date,
        line.ZAB_PLAN_NAME,
        line.customer_id,
        line.customer_full_name,
        line.end_customer_companyname,
        line.end_customer_name,
        line.so_number,
        line.transaction_id,
        line.item_id,
        line.item_displayname,
        line.product_family,
        line.schedule_name,
        line.transaction_line_id,
        line.total_transaction_amount,
        line.transaction_line_create_date,
        line.bill_schedule_date,
        line.payment_due_date,
        line.pay_term_name,
        line.billable_quantity,
        line.billed_quantity,
        line.billable_schedule_quantity_cumulative,
        line.bill_schedule_amount,
        line.last_refresh_date,
        line.TRANSACTION_DISCOUNT_LINE,
        line.time_range_filter,
        line.order_status,
        line.order_notes,

        line.billed_status,
        line.account_rank_by_schedulemonth_amount_company_name,
        line.account_rank_by_paymonth_amount_company_name,
        line.account_rank_by_schedulemonth_amount_end_customer_companyname,
        line.account_rank_by_paymonth_amount_end_customer_companyname,
        line.tl_line_type,
        line.bs_line_type

FROM 
scheduled_payments_updated_with_co_term line
LEFT JOIN 
co_term_orders_header header
on line.so_number = header.so_number ''')

scheduled_payments_updated_with_co_term_extended.createOrReplaceTempView('scheduled_payments_updated_with_co_term_extended')

# COMMAND ----------

df_scheduled_payments_with_sf_attributes = spark.sql(f'''
                  SELECT q.id quote_id,
                          zs.ZAB_SUBSCRIPTION_NAME Prior_subscription_name,  
                          opp.Id opp_id, 
                          opp.CloseDate opp_close_date,
                          opp.Start_Date__c opp_start_date,
                          opp.End_Date__c opp_end_date,
                          opp.Renewal_Date__c renewal_date,
                          o.atg_TCV__c order_tcv,
                          o.OrderNumber,
                          o.ContractId,
                          opp.Platform_Type__c platform,
                          total_contract_value__c  total_contract_value, 
                          BillingSchedule__c billing_schedule,
                          so.* 
                  FROM scheduled_payments_updated_with_co_term_extended so

                  LEFT JOIN {catalog_nm}.sfdc_bronze.opportunity opp
                  ON substr(trim(so.new_opp_id),0,15) = substr(trim(opp.Id) ,0,15)
                  AND opp.processDate = (select max(processDate) from {catalog_nm}.sfdc_bronze.opportunity)

                  LEFT JOIN {catalog_nm}.sfdc_bronze.sbqq__quote__c q
                  ON opp.SBQQ__PrimaryQuote__c = q.id
                  AND q.processDate = (select max(processDate) from {catalog_nm}.sfdc_bronze.sbqq__quote__c)

                  LEFT JOIN {catalog_nm}.sfdc_bronze.order o
                  ON opp.id = o.OpportunityId
                  AND o.processDate = (select max(processDate) from {catalog_nm}.sfdc_bronze.order)

                  LEFT JOIN {catalog_nm}.it_netsuite_bronze.zab_subscription zs
                  ON zs.ZAB_SUBSCRIPTION_ID = so.PRIOR_SUBSCRIPTION_ID
                  AND zs.processDate = (select max(processDate) from {catalog_nm}.it_netsuite_bronze.zab_subscription )

                  WHERE bill_schedule_date is not null 

                  QUALIFY row_number() OVER (PARTITION BY so.transaction_id ,so.transaction_line_id ,so.bill_schedule_date ORDER BY coalesce(o.CreatedDate,so.transaction_line_create_date) DESC)  = 1
              ''') 

df_scheduled_payments_with_sf_attributes.createOrReplaceTempView('scheduled_payments_with_sf_attributes') 

# COMMAND ----------

spark.sql(f'''
  
  insert into {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm} 

      SELECT 
      int(transaction_id) ||'-'||int(transaction_line_id)||'-'||string(date(bill_schedule_date) ) as installment_billing_id,
      so_number netsuite_so_number,
      so_number netsuite_trans_number,
      so_number netsuite_transid,
      transaction_id ,
      transaction_line_id ,
      transaction_id as orig_transaction_id,
      transaction_line_id as orig_transaction__line_id,
      so_number orig_netsuite_transid,
      quote_id ,
      opp_id ,
      opp_start_date,
      opp_end_date,
      opp_close_date ,
      renewal_date,
      platform,
      total_contract_value,
      order_tcv,
      billing_schedule,
      OrderNumber salesforce_order_number ,
      ContractId salesforce_contract_id ,
      companyname ,
      sfdc_account_id ,
      LIST_ITEM_NAME as list_item_name,
      Marketplace_FLAG as marketplace_flag,
      ZAB_SUBSCRIPTION as zab_subscription ,
      ZAB_SUBSCRIPTION_INTERNAL_ID as zab_subscription_internal_id,
      Is_Supersede_subscription ,
      PRIOR_ORDER_ID as prior_order_id,
      PRIOR_SUBSCRIPTION_ID as prior_subscription_id,
      Prior_subscription_name as prior_subscription_name,
      discount_item_unit_price ,
      --bill_amt_check ,
      discount_dollar ,
      transaction_line_amount * (-1) transaction_line_amount,
      total_transaction_amount, 
      Payment_Details ,
      date(so_create_date) so_create_date ,
      ZAB_PLAN_NAME as zab_plan_name,
      customer_id ,
      customer_full_name ,
      end_customer_companyname ,
      end_customer_name ,
      item_displayname ,
      product_family ,
      schedule_name ,
      transaction_line_create_date,
      bill_schedule_date transaction_type_date,
      substr(bill_schedule_date,0,7) as transaction_type_year_month,
      pay_term_name,
      payment_due_date ,
      billable_quantity ,
      billed_quantity ,
      billable_schedule_quantity_cumulative ,
      bill_schedule_amount ,
      last_refresh_date ,
      TRANSACTION_DISCOUNT_LINE as transaction_discount_line ,
      order_notes,
      order_status,
      billed_status ,
      'BILLING SCHEDULE',
      tl_line_type,
      co_term_flag

      FROM 
      scheduled_payments_with_sf_attributes 
      where coalesce(order_notes,'valid') not like '%PAYG Externalization%'
      and transaction_line_id <> 0

  ''')

# COMMAND ----------

spark.sql(f'''
    insert into {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm} 
      select
      int(transaction_id) ||'-'||int(transaction_line_id)||'-'||string(date(bill_schedule_date)) as installment_billing_id,
      so_number netsuite_so_number,
      so_number netsuite_trans_number,
      so_number netsuite_transid,
      transaction_id ,
      transaction_line_id ,
      transaction_id as orig_transaction_id,
      transaction_line_id as orig_transaction_line_id,
      so_number orig_netsuite_transid,
      quote_id ,
      opp_id ,
      opp_start_date,
      opp_end_date,
      opp_close_date ,
      renewal_date,
      platform,
      total_contract_value,
      order_tcv,
      billing_schedule,
      OrderNumber salesforce_order_number ,
      ContractId salesforce_contract_id ,
      companyname ,
      sfdc_account_id ,
      LIST_ITEM_NAME as list_item_name,
      Marketplace_FLAG as marketplace_flag,
      ZAB_SUBSCRIPTION as zab_subscription ,
      ZAB_SUBSCRIPTION_INTERNAL_ID as zab_subscription_internal_id,
      Is_Supersede_subscription ,
      PRIOR_ORDER_ID as prior_order_id,
      PRIOR_SUBSCRIPTION_ID as prior_subscription_id,
      Prior_subscription_name as prior_subscription_name,
      discount_item_unit_price ,
      --bill_amt_check ,
      discount_dollar ,
      transaction_line_amount * (-1) transaction_line_amount,
      total_transaction_amount, 
      Payment_Details ,
      date(so_create_date) so_create_date ,
      ZAB_PLAN_NAME as zab_plan_name,
      customer_id ,
      customer_full_name ,
      end_customer_companyname ,
      end_customer_name ,
      'billing schedule tax line' as item_displayname ,
      product_family ,
      schedule_name ,
      transaction_line_create_date,
      bill_schedule_date transaction_type_date,
      substr(bill_schedule_date,0,7) as transaction_type_year_month,
      pay_term_name,
      payment_due_date ,
      billable_quantity ,
      billed_quantity ,
      billable_schedule_quantity_cumulative ,
      bill_schedule_amount ,
      last_refresh_date ,
      TRANSACTION_DISCOUNT_LINE as transaction_discount_line ,
      order_notes,
      order_status,
      billed_status ,
      'BILLING SCHEDULE',
      tl_line_type,
      co_term_flag

      FROM 
      scheduled_payments_with_sf_attributes 

      where coalesce(order_notes,'valid') not like '%PAYG Externalization%'
      and transaction_line_id = 0 and abs(bill_schedule_amount)  > 0 
--and so_number = 'SO10125'
          ''')


# COMMAND ----------

df_netsuite_transaction_links = spark.sql(f'''
      SELECT
        link.link_type, 
        link.applied_transaction_id,
        link.applied_transaction_line_id,
        applied.transaction_number as applied_transaction_number,
        link.original_transaction_id,
        link.original_transaction_line_id,
        original.transaction_number as original_transaction_number

      FROM {catalog_nm}.it_netsuite_bronze.transaction_links link

      LEFT JOIN {catalog_nm}.it_netsuite_bronze.transactions applied
        on link.applied_transaction_id = applied.transaction_id
        and applied.processdate = (select max(processdate) from {catalog_nm}.it_netsuite_bronze.transactions)

      LEFT JOIN {catalog_nm}.it_netsuite_bronze.transactions original
        on link.original_transaction_id = original.transaction_id
        and original.processdate = (select max(processdate) from {catalog_nm}.it_netsuite_bronze.transactions)

      WHERE link.processdate = (select max(processdate) from {catalog_nm}.it_netsuite_bronze.transaction_links)
                    ''')

df_netsuite_transaction_links.createOrReplaceTempView("netsuite_transaction_links")

# COMMAND ----------

transaction_billing_data = spark.sql(f'''
              SELECT *
              --transaction_id,transaction_line_id 

              FROM {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm}   
              where transaction_type ='BILLING SCHEDULE'
              qualify row_number() over (partition by transaction_id  order by transaction_type_date desc ) =1 
''')

transaction_billing_data.createOrReplaceTempView ('transaction_billing_data')

# COMMAND ----------

transaction_line_billing_data = spark.sql(f'''
              SELECT *
              --transaction_id,transaction_line_id 

              FROM {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm}   
              where transaction_type ='BILLING SCHEDULE'
              qualify row_number() over (partition by transaction_id,  transaction_line_id order by transaction_type_date desc ) =1 
''')

transaction_line_billing_data.createOrReplaceTempView ('transaction_line_billing_data')

# COMMAND ----------

spark.sql(f'''
    insert into {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm} 
      select 

      int(links.applied_transaction_id) ||'-'||int(links.applied_transaction_line_id)||'-'||string(date(applied.TRANDATE)) as installment_billing_id,
      scheduled.netsuite_so_number,
      applied.transaction_number netsuite_trans_number,
      applied.tranid netsuite_tranid,
      links.applied_transaction_id transaction_id,
      links.applied_transaction_line_id  transaction_line_id,
      links.original_transaction_id orig_transaction_id,
      coalesce(links.original_transaction_line_id , scheduled_line.transaction_line_id , scheduled.transaction_line_id)    orig_transaction_line_id,
      coalesce(scheduled_line.netsuite_tranid, scheduled.netsuite_tranid )  orig_netsuite_tranid,
      coalesce(scheduled_line.quote_id , scheduled.quote_id) quote_id	,
      coalesce(scheduled_line.opp_id ,scheduled.opp_id) opp_id 	,
      coalesce(scheduled_line.opp_start_date , scheduled.opp_start_date)  opp_start_date,
      coalesce(scheduled_line.opp_end_date , scheduled.opp_end_date ) opp_end_date,
      coalesce(scheduled_line.opp_close_date ,scheduled.opp_close_date) opp_close_date	,
      coalesce(scheduled_line.renewal_date , scheduled.renewal_date	) renewal_date ,
      coalesce(scheduled_line.platform , scheduled.platform) platform ,
      coalesce(scheduled_line.total_contract_value , scheduled.total_contract_value) total_contract_value ,
      coalesce(scheduled_line.order_tcv , scheduled.order_tcv) order_tcv ,
      coalesce(scheduled_line.billing_schedule, scheduled.billing_schedule) billing_schedule ,
      coalesce(scheduled_line.salesforce_order_number,scheduled.salesforce_order_number)	salesforce_order_number,
      coalesce(scheduled_line.salesforce_contract_id	,scheduled.salesforce_contract_id )  salesforce_contract_id,
      coalesce(scheduled_line.companyname ,scheduled.companyname) companyname	,
      coalesce(scheduled_line.sfdc_account_id ,scheduled.sfdc_account_id) sfdc_account_id	,
      coalesce(scheduled_line.list_item_name, scheduled.list_item_name) list_item_name	,
      coalesce(scheduled_line.marketplace_flag, scheduled.marketplace_flag) marketplace_flag	,
      coalesce(scheduled_line.zab_subscription, scheduled.zab_subscription) zab_subscription	,
      coalesce(scheduled_line.zab_subscription_internal_id, scheduled.zab_subscription_internal_id) zab_subscription_internal_id	,
      coalesce(scheduled_line.Is_Supersede_subscription,  scheduled.Is_Supersede_subscription) Is_Supersede_subscription	,
      coalesce(scheduled_line.prior_order_id, scheduled.prior_order_id) prior_order_id	,
      coalesce(scheduled_line.prior_subscription_id, scheduled.prior_subscription_id) prior_subscription_id	,
      coalesce(scheduled_line.prior_subscription_name, scheduled.prior_subscription_name) prior_subscription_name	,
      null as discount_item_unit_price	,
      null as discount_dollar	,
      applied_ln.amount transaction_line_amount	,
      coalesce(scheduled_line.total_transaction_amount, scheduled.total_transaction_amount) total_transaction_amount, 
      Null as Payment_Details	,
      applied.CREATE_DATE create_date	,
      scheduled.zab_plan_name	,
      coalesce(scheduled_line.customer_id, scheduled.customer_id) customer_id	,
      coalesce(scheduled_line.customer_full_name, scheduled.customer_full_name) customer_full_name ,
      coalesce(scheduled_line.end_customer_companyname, scheduled.end_customer_companyname) end_customer_companyname	,
      coalesce(scheduled_line.end_customer_name, scheduled.end_customer_name) end_customer_name,
      coalesce(scheduled_line.item_displayname, scheduled.item_displayname) item_displayname	,
      coalesce(scheduled_line.product_family, scheduled.product_family) product_family ,
      coalesce(scheduled_line.schedule_name, scheduled.schedule_name) 	original_trans_schedule_name,
      applied_ln.DATE_CREATED as transaction_line_create_date, -- 
      applied.TRANDATE as transaction_type_date, -- Schedule date for schedule, create date for invoice	,
      substr(applied.TRANDATE ,0,7)  transaction_type_year_month	,
      coalesce(scheduled_line.pay_term_name, scheduled.pay_term_name) pay_term_name ,
      applied.DUE_DATE as due_date	, -- for schedule payment due date - for invoice pauyment due date
      applied_ln.item_count billable_quantity, --Invoice billable qty
      applied_ln.NUMBER_BILLED billed_quantity,  -- Invoiced billed qty,
      NULL as billable_schedule_quantity_cumulative	,
      (applied_ln.amount  + ((coalesce(float(replace(sl_discount.item_unit_price,' %','')),0) * applied_ln.amount )/100) ) * (-1) as installment_bill_amount,
      --applied_ln.amount * (-1)  installment_bill_amount, -- bill_schedule_amount	for schedued line total amount for invoiced
      applied.processdate last_refresh_date	,
      NULL transaction_discount_line	,

      applied.order_notes,
      applied.Status,

      applied.Status installment_Billing_Status, --billed_status	for scheduled invoice status for actuals.
      'INVOICE'  AS transaction_type,

      coalesce(scheduled_line.order_line_type,  scheduled.order_line_type) order_line_type ,
      coalesce(scheduled_line.co_term_flag, scheduled.co_term_flag) co_term_flag
      from 

      transaction_billing_data scheduled
      INNER JOIN netsuite_transaction_links links

      on scheduled.TRANSACTION_ID = links.original_transaction_id
      --and scheduled.transaction_line_id = links.original_transaction_line_id

      left join {catalog_nm}.it_netsuite_bronze.transactions applied
        on links.applied_transaction_id = applied.transaction_id
        and applied.processdate = (select max(processdate) from {catalog_nm}.it_netsuite_bronze.transactions)

      left join {catalog_nm}.it_netsuite_bronze.transaction_lines applied_ln
        on links.applied_transaction_id = applied_ln.transaction_id
        and links.applied_transaction_line_id = applied_ln.transaction_line_id
        and applied_ln.processdate = (select max(processdate) from {catalog_nm}.it_netsuite_bronze.transaction_lines)

      left join {catalog_nm}.it_netsuite_bronze.TRANSACTION_LINES sl_discount
              on  applied_ln.transaction_id = sl_discount.transaction_id 
              and sl_discount.TRANSACTION_DISCOUNT_LINE = 'Yes'
              and sl_discount.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.TRANSACTION_LINES)
              
              and charindex('%',sl_discount.item_unit_price)  > 0
          
      left join transaction_line_billing_data scheduled_line
        on scheduled_line.TRANSACTION_ID = links.original_transaction_id
        and scheduled_line.transaction_line_id = links.original_transaction_line_id
        
      where links.link_type = 'Order Bill/Invoice'
--and scheduled.transaction_id = 3032030

          ''')

# COMMAND ----------

spark.sql(f'''
    INSERT INTO {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm}  
      SELECT 
      installment_billing_id||'-'||'PS' as installment_billing_id,
      netsuite_so_number	,
      netsuite_trans_number	,
      netsuite_tranid,
      transaction_id	,
      transaction_line_id	,
      orig_transaction_id	,
      orig_transaction_line_id	,
      orig_netsuite_tranid,
      quote_id	,
      opp_id	,
      opp_start_date	,
      opp_end_date	,
      opp_close_date	,
      renewal_date	,
      platform	,
      total_contract_value,
      order_tcv,
      billing_schedule,
      salesforce_order_number	,
      salesforce_contract_id	,
      companyname	,
      sfdc_account_id	,
      list_item_name	,
      marketplace_flag	,
      zab_subscription	,
      zab_subscription_internal_id	,
      Is_Supersede_subscription	,
      prior_order_id	,
      prior_subscription_id	,
      prior_subscription_name	,
      discount_percentage	,
      discount_dollar	,
      transaction_line_amount	,
      total_transaction_amount	,
      Payment_Details	,
      trans_create_date	,
      zab_plan_name	,
      customer_id	,
      customer_full_name	,
      end_customer_companyname	,
      end_customer_name	,
      item_displayname	,
      product_family	,
      schedule_name	,
      transaction_line_create_Date	,
      coalesce(due_date,transaction_type_date)  Installment_billing_date	,
      substr(coalesce(due_date,transaction_type_date) ,0,7) installment_billing_year_month	,
      pay_term_name,
      Null due_date	,
      billable_quantity	,
      billed_quantity	,
      billable_schedule_quantity_cumulative	,
      transaction_type_amount	,
      last_refresh_date	,
      transaction_discount_line	,
      order_notes	,
      order_status	,
      line_status	,
      'PAYMENT SCHEDULED' transaction_type	,
      ordeR_line_type,
      co_term_flag

    FROM {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm}   
    WHERE transaction_type = 'BILLING SCHEDULE'
          ''')

# COMMAND ----------

transaction_invoice_data_for_invoice_tax = spark.sql(f'''
                          select *
                          --transaction_id,transaction_line_id 

                          From {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm}   
                          where transaction_type ='INVOICE'
                          qualify row_number() over (partition by transaction_id  order by transaction_type_date desc ) =1
''' )

transaction_invoice_data_for_invoice_tax.createOrReplaceTempView ('transaction_invoice_data_for_invoice_tax')

# COMMAND ----------

spark.sql(f'''
          insert into {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm}
            select 
            int(invoices.transaction_id) ||'-'||int(line.transaction_line_id )||'-'||string(date(invoices.transaction_type_date)) as installment_billing_id,
            invoices.netsuite_so_number,
            invoices.netsuite_trans_number,
            invoices.netsuite_tranid,
            invoices.transaction_id transaction_id,
            line.transaction_line_id  transaction_line_id,
            invoices.orig_transaction_id orig_transaction_id,
            -1   orig_transaction_line_id,
            invoices.orig_netsuite_tranid as orig_netsuite_tranid,
            invoices.quote_id	,
            invoices.opp_id	,
            invoices.opp_start_date,
            invoices.opp_end_date,
            invoices.opp_close_date	,
            invoices.renewal_date	,
            invoices.platform,
            invoices.total_contract_value,
            invoices.order_tcv,
            invoices.billing_schedule,
            invoices.salesforce_order_number	,
            invoices.salesforce_contract_id	,
            invoices.companyname	,
            invoices.sfdc_account_id	,
            invoices.list_item_name	,
            invoices.marketplace_flag	,
            invoices.zab_subscription	,
            invoices.zab_subscription_internal_id	,
            invoices.Is_Supersede_subscription	,
            invoices.prior_order_id	,
            invoices.prior_subscription_id	,
            invoices.prior_subscription_name	,
            null as discount_item_unit_price	,
            null as discount_dollar	,
            line.amount transaction_line_amount	,
            invoices.total_transaction_amount, 
            Null as Payment_Details	,
            invoices.trans_create_date 	,
            invoices.zab_plan_name	,
            invoices.customer_id	,
            invoices.customer_full_name	,
            invoices.end_customer_companyname	,
            invoices.end_customer_name	,
            --'invoice tax line' item_displayname	, changed below
            coalesce(i.displayname,i.type_name,line.memo,'') || ' non linked extra lines' item_displayname	,
            invoices.product_family	,
            invoices.schedule_name	original_trans_schedule_name,
            line.DATE_CREATED as transaction_line_create_date, -- 
            invoices.transaction_type_date as transaction_type_date, -- Schedule date for schedule, create date for invoice	,
            substr(invoices.transaction_type_date ,0,7)  transaction_type_year_month	,
            invoices.pay_term_name,
            invoices.DUE_DATE as due_date	, -- for schedule payment due date - for invoice pauyment due date
            line.item_count billable_quantity, --Invoice billable qty
            line.NUMBER_BILLED billed_quantity,  -- Invoiced billed qty,
            NULL as billable_schedule_quantity_cumulative	,
            (line.amount ) * (-1)   as transaction_type_amount,
            --applied_ln.amount * (-1)  installment_bill_amount, -- bill_schedule_amount	for schedued line total amount for invoiced
            invoices.last_refresh_date last_refresh_date	,
            NULL transaction_discount_line	,

            invoices.order_notes,
            invoices.order_Status,

            invoices.line_Status installment_Billing_Status, --billed_status	for scheduled invoice status for actuals.
            invoices.transaction_type,
            invoices.order_line_type,
            invoices.co_term_flag

            from 

            transaction_invoice_data_for_invoice_tax invoices

            left join {catalog_nm}.it_netsuite_bronze.transaction_lines line
              on invoices.transaction_id = line.transaction_id
              and line.processdate = (select max(processdate) from {catalog_nm}.it_netsuite_bronze.transaction_lines)
              and line.transaction_line_id <> 0
              and line.TRANSACTION_DISCOUNT_LINE = 'No'
            
            left join {catalog_nm}.it_netsuite_bronze.items i
                      on line.item_id = i.item_id
                      and i.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.items)

            Left join {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm}  ib
            on line.TRANSACTION_ID = ib.transaction_id
            and line.TRANSACTION_LINE_ID = ib.transaction_line_id

              where  --invoices.netsuite_so_number = 'SO10125' and 
              ib.TRANSACTION_ID is NULL  
          ''')


# COMMAND ----------

transaction_invoice_data = spark.sql(f'''
          select *
          --transaction_id,transaction_line_id 

          From {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm}   
          where transaction_type ='INVOICE'
          qualify row_number() over (partition by transaction_id  order by transaction_type_date desc ) =1
              ''' )

transaction_invoice_data.createOrReplaceTempView ('transaction_invoice_data')

# COMMAND ----------

payments_breakup = spark.sql(f'''
                            SELECT A.nextdoc transaction_id,  
                                    B.tranid , 
                                    b.transaction_number,
                                    a.previousdoc prev_transaction_id ,
                                    c.tranid prev_tranid, 
                                    c.transaction_number prev_transaction_number ,
                                    sum(A.Foreignamount ) breakup_amount

                            from {catalog_nm}.it_netsuite_bronze.NextTransactionLineLink A, 
                            {catalog_nm}.it_netsuite_bronze.transactions B  ,
                            {catalog_nm}.it_netsuite_bronze.transactions C

                            where A.nextdoc = b.transaction_id
                            and A.previousdoc = C.transaction_id

                            --And A.nextdoc = 519037
                            and b.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.transactions)
                            and A.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.NextTransactionLineLink)
                            and C.processDate = (select max(processdate) from  {catalog_nm}.it_netsuite_bronze.transactions) 
                            
                            group by 1,2,3,4,5,6
''')

payments_breakup.createOrReplaceTempView('payments_breakup')

# COMMAND ----------

payments_transactions = spark.sql(f'''
                select 
                  int(links.applied_transaction_id) ||'-'||int(links.applied_transaction_line_id  )||'-'||string(date(applied.TRANDATE)) as installment_billing_id,
                  invoice.netsuite_so_number,
                  applied.transaction_number netsuite_trans_number,
                  applied.tranid netsuite_tranid,
                  links.applied_transaction_id transaction_id,
                  links.applied_transaction_line_id  transaction_line_id,
                  invoice.transaction_id orig_transaction_id,
                  invoice.transaction_line_id  orig_transaction_line_id,
                  invoice.quote_id	,
                  invoice.opp_id	,
                  invoice.opp_start_date,
                  invoice.opp_end_date,
                  invoice.opp_close_date	,
                  invoice.renewal_date	,
                  invoice.platform,
                  invoice.total_contract_value,
                  invoice.order_tcv,
                  invoice.billing_schedule,
                  invoice.salesforce_order_number	,
                  invoice.salesforce_contract_id	,
                  invoice.companyname	,
                  invoice.sfdc_account_id	,
                  invoice.list_item_name	,
                  invoice.marketplace_flag	,
                  invoice.zab_subscription	,
                  invoice.zab_subscription_internal_id	,
                  invoice.Is_Supersede_subscription	,
                  invoice.prior_order_id	,
                  invoice.prior_subscription_id	,
                  invoice.prior_subscription_name	,
                  null as discount_item_unit_price	,
                  null as discount_dollar	,
                  applied_ln.amount transaction_line_amount	,
                  invoice.total_transaction_amount,
                  Null as Payment_Details	,
                  applied.CREATE_DATE create_date	,
                  invoice.zab_plan_name	,
                  invoice.customer_id	,
                  invoice.customer_full_name	,
                  invoice.end_customer_companyname	,
                  invoice.end_customer_name	,
                  invoice.item_displayname	,
                  invoice.product_family	,
                  invoice.schedule_name	original_trans_schedule_name,
                  applied_ln.DATE_CREATED as transaction_line_create_date, 
                  applied.TRANDATE as transaction_type_date, -- Schedule date for schedule, create date for invoice,payment	,
                  substr(applied.TRANDATE ,0,7)  transaction_type_year_month	,
                  invoice.pay_term_name,
                  applied.DUE_DATE as due_date	, -- for schedule payment due date - for invoice pauyment due date
                  applied_ln.item_count billable_quantity, --Invoice billable qty
                  applied_ln.NUMBER_BILLED billed_quantity,  -- Invoiced billed qty,
                  NULL as billable_schedule_quantity_cumulative	,
                  applied_ln.amount  *(-1) installment_bill_amount, -- bill_schedule_amount	for schedued line total amount for invoiced,payment
                  applied.processdate last_refresh_date	,
                  NULL transaction_discount_line	,
                  applied.order_notes,
                  applied.Status,
                  applied.Status installment_Billing_Status, --billed_status	for scheduled invoice,payment status for actuals and payment
                  'PAYMENT'  AS transaction_type,
                  invoice.order_line_Type  order_line_Type,
                  invoice.co_term_flag co_term_flag

                  from 
                  transaction_invoice_data invoice

                  INNER JOIN netsuite_transaction_links links
                  on invoice.TRANSACTION_ID = links.original_transaction_id
                  --and invoice.transaction_line_id = links.original_transaction_line_id

                  left join {catalog_nm}.it_netsuite_bronze.transactions applied
                    on links.applied_transaction_id = applied.transaction_id
                    and applied.processdate = (select max(processdate) from {catalog_nm}.it_netsuite_bronze.transactions)

                  left join {catalog_nm}.it_netsuite_bronze.transaction_lines applied_ln
                    on links.applied_transaction_id = applied_ln.transaction_id
                    and links.applied_transaction_line_id = applied_ln.transaction_line_id
                    and applied_ln.processdate = (select max(processdate) from {catalog_nm}.it_netsuite_bronze.transaction_lines)

              where lower(links.link_type) = 'payment' ''')


payments_transactions.createOrReplaceTempView('payments_transactions')

# COMMAND ----------

spark.sql(f'''
    --create or replace table temp.payment_transactions_Data2 as 
    
    insert into {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm} 
        select 
        --int(links.applied_transaction_id) ||'-'||int(links.applied_transaction_line_id  )||'-'||string(date(applied.TRANDATE)) as installment_billing_id,
        pt.installment_billing_id||'-'||coalesce(string(pb.prev_transaction_id),string(int(orig_transaction_id)))  installment_billing_id  ,
        pt.netsuite_so_number,
        pt.netsuite_trans_number,
        pt.netsuite_tranid,
        pt.transaction_id,
        pt.transaction_line_id,
        --case when count() over (partition by links.applied_transaction_id  ,links.applied_transaction_line_id  order by invoice.transaction_id orig_transaction_id,
        pt.orig_transaction_id,
        pt.orig_transaction_line_id,
        pb.prev_tranid original_tranid,
        pt.quote_id	,
        pt.opp_id	,
        pt.opp_start_date,
        pt.opp_end_date,
        pt.opp_close_date	,
        pt.renewal_date	,
        pt.platform,
        pt.total_contract_value,
        pt.order_tcv,
        pt.billing_schedule,
        pt.salesforce_order_number	,
        pt.salesforce_contract_id	,
        pt.companyname	,
        pt.sfdc_account_id	,
        pt.list_item_name	,
        pt.marketplace_flag	,
        pt.zab_subscription	,
        pt.zab_subscription_internal_id	,
        pt.Is_Supersede_subscription	,
        pt.prior_order_id	,
        pt.prior_subscription_id	,
        pt.prior_subscription_name	,
        pt.discount_item_unit_price	,
        pt.discount_dollar	,
        pt.transaction_line_amount	,
        pt.installment_bill_amount as total_transaction_amount,
        pt.Payment_Details	,
        pt.create_date	,
        pt.zab_plan_name	,
        pt.customer_id	,
        pt.customer_full_name	,
        pt.end_customer_companyname	,
        pt.end_customer_name	,
        pt.item_displayname	,
        pt.product_family	,
        pt.original_trans_schedule_name,
        pt.transaction_line_create_date, 
        pt.transaction_type_date, -- Schedule date for schedule, create date for invoice,payment	,
        pt.transaction_type_year_month	,
        pt.pay_term_name,
        pt.due_date	, -- for schedule payment due date - for invoice pauyment due date
        pt.billable_quantity, --Invoice billable qty
        pt.billed_quantity,  -- Invoiced billed qty,
        pt.billable_schedule_quantity_cumulative	,
        --transaction_type_amount, -- bill_schedule_amount	for schedued line total amount for invoiced,payment
        pb.breakup_amount  transaction_type_amount,
        pt.last_refresh_date	,
        pt.transaction_discount_line	,
        pt.order_notes,
        pt.Status,
        pt.installment_Billing_Status, --billed_status	for scheduled invoice,payment status for actuals and payment
        pt.transaction_type,
        pt.order_line_Type,
        pt.co_term_flag
        from 
        payments_transactions pt
        LEFT JOIN payments_breakup  pb

        on pt.transaction_id = pb.transaction_id
        and pt.orig_transaction_id = pb.prev_transaction_id 
        --where  pt.installment_billing_id||'-'||pb.prev_tranid =  '9730289-1-2023-03-02-INV116695'
        --where pt.netsuite_trans_number = 'PMT17228'
          ''')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Add Process Date and transfer data to post_tbl_nm

# COMMAND ----------

df_so_installment_billing_pre = spark.sql(f'''
                                          SELECT * FROM {catalog_nm}.{tgt_db_nm}.{pre_tbl_nm}
                                          ''')

# COMMAND ----------

final_df_installment_billing, processDate = add_audit_attributes(df_so_installment_billing_pre)

# COMMAND ----------

print(f'{full_table_name} ')

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')

print (f'Updating data in {full_table_name} for {processDate}')
(final_df_installment_billing
  .write
  .mode('overwrite')
  .format('delta')
  .option('overwriteSchema', 'true')
  #.option("mergeSchema", "true")
  .option('replaceWhere', f"process_date = '{date_str}'")
  .partitionBy("process_date")
  .saveAsTable(full_table_name))

# COMMAND ----------


