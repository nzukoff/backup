# Databricks notebook source
# %sql
# -- BACKUP TABLE 

# CREATE TABLE spark_catalog.bdw_dev.so_installment_billing__TEST
# SELECT * FROM spark_catalog.bdw_dev.so_installment_billing

# COMMAND ----------

# dbutils.fs.rm('dbfs:/mnt/bdw_dev/so_installment_billing/',True)

# COMMAND ----------

# MAGIC %md
# MAGIC #### DEV

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE or replace TABLE integration.it_finance_silver.so_installment_billing_pre (
# MAGIC   installment_billing_id STRING,
# MAGIC   netsuite_so_number STRING,
# MAGIC   netsuite_trans_number STRING,
# MAGIC   netsuite_tranid STRING,
# MAGIC   transaction_id DOUBLE,
# MAGIC   transaction_line_id DOUBLE,
# MAGIC   orig_transaction_id DOUBLE,
# MAGIC   orig_transaction_line_id DOUBLE,
# MAGIC   orig_netsuite_tranid STRING, -- new 
# MAGIC   quote_id STRING,
# MAGIC   opp_id STRING,
# MAGIC   opp_start_date DATE,
# MAGIC   opp_end_date DATE,
# MAGIC   opp_close_date DATE,
# MAGIC   renewal_date DATE,
# MAGIC   platform STRING,
# MAGIC   total_contract_value DOUBLE,
# MAGIC   order_tcv DOUBLE,
# MAGIC   billing_schedule STRING,
# MAGIC   salesforce_order_number STRING,
# MAGIC   salesforce_contract_id STRING,
# MAGIC   companyname STRING,
# MAGIC   sfdc_account_id STRING,
# MAGIC   list_item_name STRING,
# MAGIC   marketplace_flag STRING,
# MAGIC   zab_subscription STRING,
# MAGIC   zab_subscription_internal_id STRING,
# MAGIC   Is_Supersede_subscription STRING,
# MAGIC   prior_order_id DOUBLE,
# MAGIC   prior_subscription_id DOUBLE,
# MAGIC   prior_subscription_name STRING,
# MAGIC   discount_percentage STRING,
# MAGIC   discount_dollar DOUBLE,
# MAGIC   transaction_line_amount DOUBLE,
# MAGIC   total_transaction_amount DOUBLE,
# MAGIC   Payment_Details STRING,
# MAGIC   trans_create_date DATE, --so create date or inv create data or payment create date
# MAGIC   zab_plan_name STRING,
# MAGIC   customer_id DOUBLE,
# MAGIC   customer_full_name STRING,
# MAGIC   end_customer_companyname STRING,
# MAGIC   end_customer_name STRING,
# MAGIC   item_displayname STRING,
# MAGIC   product_family STRING,
# MAGIC   schedule_name STRING,
# MAGIC   transaction_line_create_Date DATE,
# MAGIC   transaction_type_date  DATE, -- bill Schedule date for schedule, create date for invoice	,
# MAGIC   transaction_type_year_month STRING,
# MAGIC   pay_term_name STRING,
# MAGIC   due_date DATE, --for schedule payment due date - for invoice pauyment due date
# MAGIC   billable_quantity DOUBLE,
# MAGIC   billed_quantity DOUBLE,
# MAGIC   billable_schedule_quantity_cumulative DOUBLE,
# MAGIC   transaction_type_amount DOUBLE, -- bill_schedule_amount	for schedued line total amount for invoiced
# MAGIC   last_refresh_date DATE,
# MAGIC   transaction_discount_line STRING,
# MAGIC   order_notes STRING,
# MAGIC   order_status STRING, -- order level status 
# MAGIC   line_status STRING,
# MAGIC   transaction_type STRING) --billed_status	for scheduled invoice status for actuals. same as order level for invoice and payment however calculated for line level

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE or replace TABLE integration.it_finance_silver.so_installment_billing (
# MAGIC   installment_billing_id STRING,
# MAGIC   netsuite_so_number STRING,
# MAGIC   netsuite_trans_number STRING,
# MAGIC   netsuite_tranid STRING,
# MAGIC   transaction_id DOUBLE,
# MAGIC   transaction_line_id DOUBLE,
# MAGIC   orig_transaction_id DOUBLE,
# MAGIC   orig_transaction_line_id DOUBLE,
# MAGIC   orig_netsuite_tranid STRING, -- new 
# MAGIC   quote_id STRING,
# MAGIC   opp_id STRING,
# MAGIC   opp_start_date DATE,
# MAGIC   opp_end_date DATE,
# MAGIC   opp_close_date DATE,
# MAGIC   renewal_date DATE,
# MAGIC   platform STRING,
# MAGIC   total_contract_value DOUBLE,
# MAGIC   order_tcv DOUBLE,
# MAGIC   billing_schedule STRING,
# MAGIC   salesforce_order_number STRING,
# MAGIC   salesforce_contract_id STRING,
# MAGIC   companyname STRING,
# MAGIC   sfdc_account_id STRING,
# MAGIC   list_item_name STRING,
# MAGIC   marketplace_flag STRING,
# MAGIC   zab_subscription STRING,
# MAGIC   zab_subscription_internal_id STRING,
# MAGIC   Is_Supersede_subscription STRING,
# MAGIC   prior_order_id DOUBLE,
# MAGIC   prior_subscription_id DOUBLE,
# MAGIC   prior_subscription_name STRING,
# MAGIC   discount_percentage STRING,
# MAGIC   discount_dollar DOUBLE,
# MAGIC   transaction_line_amount DOUBLE,
# MAGIC   total_transaction_amount DOUBLE,
# MAGIC   Payment_Details STRING,
# MAGIC   trans_create_date DATE, --so create date or inv create data or payment create date
# MAGIC   zab_plan_name STRING,
# MAGIC   customer_id DOUBLE,
# MAGIC   customer_full_name STRING,
# MAGIC   end_customer_companyname STRING,
# MAGIC   end_customer_name STRING,
# MAGIC   item_displayname STRING,
# MAGIC   product_family STRING,
# MAGIC   schedule_name STRING,
# MAGIC   transaction_line_create_Date DATE,
# MAGIC   transaction_type_date  DATE, -- bill Schedule date for schedule, create date for invoice	,
# MAGIC   transaction_type_year_month STRING,
# MAGIC   pay_term_name STRING,
# MAGIC   due_date DATE, --for schedule payment due date - for invoice pauyment due date
# MAGIC   billable_quantity DOUBLE,
# MAGIC   billed_quantity DOUBLE,
# MAGIC   billable_schedule_quantity_cumulative DOUBLE,
# MAGIC   transaction_type_amount DOUBLE, -- bill_schedule_amount	for schedued line total amount for invoiced
# MAGIC   last_refresh_date DATE,
# MAGIC   transaction_discount_line STRING,
# MAGIC   order_notes STRING,
# MAGIC   order_status STRING, -- order level status 
# MAGIC   line_status STRING,
# MAGIC   transaction_type STRING,  --billed_status	for scheduled invoice status for actuals. same as order level for invoice and payment however calculated for line level
# MAGIC   process_date DATE) 
# MAGIC
# MAGIC   PARTITIONED BY (process_date)

# COMMAND ----------

# MAGIC %md
# MAGIC #### PROD

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE or replace TABLE main.it_finance_silver.so_installment_billing_pre (
# MAGIC   installment_billing_id STRING,
# MAGIC   netsuite_so_number STRING,
# MAGIC   netsuite_trans_number STRING,
# MAGIC   netsuite_tranid STRING,
# MAGIC   transaction_id DOUBLE,
# MAGIC   transaction_line_id DOUBLE,
# MAGIC   orig_transaction_id DOUBLE,
# MAGIC   orig_transaction_line_id DOUBLE,
# MAGIC   orig_netsuite_tranid STRING, -- new 
# MAGIC   quote_id STRING,
# MAGIC   opp_id STRING,
# MAGIC   opp_start_date DATE,
# MAGIC   opp_end_date DATE,
# MAGIC   opp_close_date DATE,
# MAGIC   renewal_date DATE,
# MAGIC   platform STRING,
# MAGIC   total_contract_value DOUBLE,
# MAGIC   order_tcv DOUBLE,
# MAGIC   billing_schedule STRING,
# MAGIC   salesforce_order_number STRING,
# MAGIC   salesforce_contract_id STRING,
# MAGIC   companyname STRING,
# MAGIC   sfdc_account_id STRING,
# MAGIC   list_item_name STRING,
# MAGIC   marketplace_flag STRING,
# MAGIC   zab_subscription STRING,
# MAGIC   zab_subscription_internal_id STRING,
# MAGIC   Is_Supersede_subscription STRING,
# MAGIC   prior_order_id DOUBLE,
# MAGIC   prior_subscription_id DOUBLE,
# MAGIC   prior_subscription_name STRING,
# MAGIC   discount_percentage STRING,
# MAGIC   discount_dollar DOUBLE,
# MAGIC   transaction_line_amount DOUBLE,
# MAGIC   total_transaction_amount DOUBLE,
# MAGIC   Payment_Details STRING,
# MAGIC   trans_create_date DATE, --so create date or inv create data or payment create date
# MAGIC   zab_plan_name STRING,
# MAGIC   customer_id DOUBLE,
# MAGIC   customer_full_name STRING,
# MAGIC   end_customer_companyname STRING,
# MAGIC   end_customer_name STRING,
# MAGIC   item_displayname STRING,
# MAGIC   product_family STRING,
# MAGIC   schedule_name STRING,
# MAGIC   transaction_line_create_Date DATE,
# MAGIC   transaction_type_date  DATE, -- bill Schedule date for schedule, create date for invoice	,
# MAGIC   transaction_type_year_month STRING,
# MAGIC   pay_term_name STRING,
# MAGIC   due_date DATE, --for schedule payment due date - for invoice pauyment due date
# MAGIC   billable_quantity DOUBLE,
# MAGIC   billed_quantity DOUBLE,
# MAGIC   billable_schedule_quantity_cumulative DOUBLE,
# MAGIC   transaction_type_amount DOUBLE, -- bill_schedule_amount	for schedued line total amount for invoiced
# MAGIC   last_refresh_date DATE,
# MAGIC   transaction_discount_line STRING,
# MAGIC   order_notes STRING,
# MAGIC   order_status STRING, -- order level status 
# MAGIC   line_status STRING,
# MAGIC   transaction_type STRING) --billed_status	for scheduled invoice status for actuals. same as order level for invoice and payment however calculated for line level

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE or replace TABLE main.it_finance_silver.so_installment_billing (
# MAGIC   installment_billing_id STRING,
# MAGIC   netsuite_so_number STRING,
# MAGIC   netsuite_trans_number STRING,
# MAGIC   netsuite_tranid STRING,
# MAGIC   transaction_id DOUBLE,
# MAGIC   transaction_line_id DOUBLE,
# MAGIC   orig_transaction_id DOUBLE,
# MAGIC   orig_transaction_line_id DOUBLE,
# MAGIC   orig_netsuite_tranid STRING, -- new 
# MAGIC   quote_id STRING,
# MAGIC   opp_id STRING,
# MAGIC   opp_start_date DATE,
# MAGIC   opp_end_date DATE,
# MAGIC   opp_close_date DATE,
# MAGIC   renewal_date DATE,
# MAGIC   platform STRING,
# MAGIC   total_contract_value DOUBLE,
# MAGIC   order_tcv DOUBLE,
# MAGIC   billing_schedule STRING,
# MAGIC   salesforce_order_number STRING,
# MAGIC   salesforce_contract_id STRING,
# MAGIC   companyname STRING,
# MAGIC   sfdc_account_id STRING,
# MAGIC   list_item_name STRING,
# MAGIC   marketplace_flag STRING,
# MAGIC   zab_subscription STRING,
# MAGIC   zab_subscription_internal_id STRING,
# MAGIC   Is_Supersede_subscription STRING,
# MAGIC   prior_order_id DOUBLE,
# MAGIC   prior_subscription_id DOUBLE,
# MAGIC   prior_subscription_name STRING,
# MAGIC   discount_percentage STRING,
# MAGIC   discount_dollar DOUBLE,
# MAGIC   transaction_line_amount DOUBLE,
# MAGIC   total_transaction_amount DOUBLE,
# MAGIC   Payment_Details STRING,
# MAGIC   trans_create_date DATE, --so create date or inv create data or payment create date
# MAGIC   zab_plan_name STRING,
# MAGIC   customer_id DOUBLE,
# MAGIC   customer_full_name STRING,
# MAGIC   end_customer_companyname STRING,
# MAGIC   end_customer_name STRING,
# MAGIC   item_displayname STRING,
# MAGIC   product_family STRING,
# MAGIC   schedule_name STRING,
# MAGIC   transaction_line_create_Date DATE,
# MAGIC   transaction_type_date  DATE, -- bill Schedule date for schedule, create date for invoice	,
# MAGIC   transaction_type_year_month STRING,
# MAGIC   pay_term_name STRING,
# MAGIC   due_date DATE, --for schedule payment due date - for invoice pauyment due date
# MAGIC   billable_quantity DOUBLE,
# MAGIC   billed_quantity DOUBLE,
# MAGIC   billable_schedule_quantity_cumulative DOUBLE,
# MAGIC   transaction_type_amount DOUBLE, -- bill_schedule_amount	for schedued line total amount for invoiced
# MAGIC   last_refresh_date DATE,
# MAGIC   transaction_discount_line STRING,
# MAGIC   order_notes STRING,
# MAGIC   order_status STRING, -- order level status 
# MAGIC   line_status STRING,
# MAGIC   transaction_type STRING, --billed_status	for scheduled invoice status for actuals. same as order level for invoice and payment however calculated for line level
# MAGIC   process_date DATE)
# MAGIC   PARTITIONED BY (process_date)

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table spark_catalog.bdw_dev.so_installment_billing_pre add columns ( order_line_type string)

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table spark_catalog.bdw_dev.so_installment_billing_pre add columns ( co_term_flag string)

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table spark_catalog.bdw.so_installment_billing_pre add columns ( order_line_type string)

# COMMAND ----------

# MAGIC %sql
# MAGIC alter table spark_catalog.bdw.so_installment_billing_pre add columns ( co_term_flag string)

# COMMAND ----------


