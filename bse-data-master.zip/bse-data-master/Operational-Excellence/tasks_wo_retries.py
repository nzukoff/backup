# Databricks notebook source
# MAGIC %pip install databricks-sdk==0.15.0
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

from databricks.sdk import WorkspaceClient
w = WorkspaceClient(
  host  = 'https://adb-2548836972759138.18.azuredatabricks.net',
  token = dbutils.secrets.get(scope = "bse-dev-creds", key = "dev-logfood-token-as")
)

# COMMAND ----------

# Get all job IDs from the API
job_ids_df = spark.sql('SELECT * FROM main.it_operations.job_details')
job_ids = job_ids_df.select('job_id')
job_ids_list = [row.job_id for row in job_ids_df.collect()]

# COMMAND ----------

import json

all_jobs = w.jobs.list(expand_tasks=True)

# jobs without retry enabled
job_ids_list = set(job_ids_list)
our_jobs = []
for job in all_jobs:
    job_dict = job.as_dict()
    if int(job_dict.get('job_id')) in job_ids_list:
        our_jobs.append(job_dict)


# COMMAND ----------

no_tasks = []
no_retries = []
for job in our_jobs:
  tasks = []
  try:
    tasks = job.get("settings", {}).get("tasks", [])
  except:
    no_tasks.append(job)
    continue
  for task in tasks:
    if "max_retries" not in task:
      no_retries.append((job,task))

# COMMAND ----------

f = []
for job, task in no_retries:
  f.append((job["creator_user_name"], job["settings"]["name"], task["task_key"]))

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, FloatType
schema = StructType([
    StructField("email", StringType(), True),
    StructField("job", StringType(), True),
    StructField("task", StringType(), True)
])
df = spark.createDataFrame(f, schema=schema)

# COMMAND ----------

df.write.mode("overwrite").saveAsTable("main.it_operations.tasks_wo_retries")

# COMMAND ----------


