# Databricks notebook source
# DBTITLE 1,Library Install
# %pip install --upgrade databricks-sdk
%pip install databricks-sdk==0.52.0
dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Environment config
# MAGIC %run ./operational_excellence__config

# COMMAND ----------

workspace = WORKSPACE.lower()

# COMMAND ----------

exclude_job_ids = dbutils.widgets.text("exclude_job_ids",'',"List of jobs to exclude (comma separated)")

# COMMAND ----------

exclude_job_ids_str = dbutils.widgets.get("exclude_job_ids")
exclude_job_ids_list = [jid.strip() for jid in exclude_job_ids_str.split(",") if jid.strip()]
exclude_job_ids_sql_str = ",".join([f"'{jid}'" for jid in exclude_job_ids_list])
print(exclude_job_ids_sql_str)

# COMMAND ----------

if len(exclude_job_ids_list) != 0:
    sql_filter = f'sj.job_id not in ({exclude_job_ids_sql_str})' # Logic to exclude specific jobs for mitigating permission issue causing pipeline failure, incorrect tagging etc.
else:
    sql_filter = '1=1' #no exclusions needed

# COMMAND ----------

# DBTITLE 1,Imports
import json
import pandas as pd
from databricks.sdk import WorkspaceClient
from pyspark.sql.functions import col, lit

# COMMAND ----------

# DBTITLE 1,Databricks IT Jobs Filter
def get_jobs(w):
    job_list = spark.sql(f'''
                        with sj as (SELECT
                        *,
                        ROW_NUMBER() OVER(PARTITION BY workspace_id, sj.job_id ORDER BY change_time DESC) as rn
                        FROM
                        system.lakeflow.jobs sj
                        QUALIFY rn=1
                        )
                        select job_id
                        from sj
                        where  
                        upper(sj.tags.Team) = 'IT-DATA' and
                        upper(sj.tags.Type) = 'PROD'
                        and sj.delete_time is null
                        and {sql_filter}
                         ''').collect()
    itjobs = [row['job_id'] for row in job_list]
    return itjobs

# COMMAND ----------

# DBTITLE 1,Workspace Job Data Fetch Function
def get_job_data(w, job_ids_list):
  tags_to_keep = {'AffectsEOM', 'Domain', 'Owner', 'Priority', 'Team', 'Type', 'Budget', 'Project', 'ResourceClass', 'Description', 'Name', 'SLA', 'Service', 'Tier'}
  job_data = [w.jobs.get(job_id=job_id).as_dict() for job_id in job_ids_list]
  for job in job_data:
    job['workspace'] = workspace
    job['is_job_deleted'] = 'no'
    if 'tags' in job['settings']:
      for key in list(job['settings']['tags'].keys()):
        if key not in tags_to_keep:
          del job['settings']['tags'][key]
  return job_data

# COMMAND ----------

def get_nested_value(d, keys, default=None):
    for key in keys:
        if isinstance(d, dict):
            d = d.get(key, default)
        else:
            return default
    return d

# COMMAND ----------

from pyspark.sql.types import *

schema = StructType([
    StructField("job_id", LongType(), True),
    
    StructField("created_time", LongType(), True),
    StructField("creator_user_name", StringType(), True),
    
    StructField("run_as_user_name", StringType(), True),
    StructField("workspace", StringType(), True),
    StructField("is_job_deleted", StringType(), True),
    
    StructField("settings__email_notifications__no_alert_for_skipped_runs", BooleanType(), True),
    StructField("settings__email_notifications__on_failure", ArrayType(StringType()), True),
    StructField("settings__format", StringType(), True),
    StructField("settings__max_concurrent_runs", LongType(), True),
    StructField("settings__name", StringType(), True),
    
    StructField("settings__notification_job__no_alert_for_canceled_runs", BooleanType(), True),
    StructField("settings__notification_job__no_alert_for_skipped_runs", BooleanType(), True),
    StructField("settings__schedule__pause_status", StringType(), True),
    StructField("settings__schedule__quartz_cron_expression", StringType(), True),
    StructField("settings__schedule__timezone_id", StringType(), True),
    
    StructField("settings__tags__AffectsEOM", StringType(), True),
    StructField("settings__tags__Owner", StringType(), True),
    StructField("settings__tags__Team", StringType(), True),
    StructField("settings__tags__Type", StringType(), True),
    StructField("settings__timeout_seconds", LongType(), True),
    
    StructField("settings__git_source__git_branch", StringType(), True),
    StructField("settings__git_source__git_provider", StringType(), True),
    StructField("settings__git_source__git_url", StringType(), True),
    StructField("settings__job_clusters", ArrayType(MapType(StringType(), StringType())), True),
    
    StructField("settings__email_notifications__on_success", ArrayType(StringType()), True),
    StructField("settings__parameters", ArrayType(MapType(StringType(), StringType())), True),
    StructField("settings__health__rules", ArrayType(MapType(StringType(), StringType())), True),
    StructField("settings__tags__Budget", StringType(), True),
    
    StructField("settings__compute", ArrayType(MapType(StringType(), StringType())), True),
    StructField("settings__continuous__pause_status", StringType(), True),
    StructField("settings__email_notifications__on_duration_warning_threshold_exceeded", ArrayType(StringType()), True),
    
    StructField("Domain", StringType(), True),
    StructField("Priority", StringType(), True),
    StructField("Job_link", StringType(), True),
    
    StructField("settings__tags__Project", StringType(), True),
    StructField("settings__description", StringType(), True),
    StructField("settings__tags__ResourceClass", StringType(), True),
    
    StructField("settings__queue__enabled", BooleanType(), True),
    StructField("settings__email_notifications__on_start", ArrayType(StringType()), True),
    
    StructField("settings__tags__Description", StringType(), True),
    StructField("settings__tags__Name", StringType(), True),
    StructField("settings__tags__SLA", StringType(), True),
    StructField("settings__tags__Priorit", StringType(), True),
    StructField("settings__tags__streaming_job", StringType(), True),
    StructField("settings__tags__Service", StringType(), True),
    
    StructField("settings__tags__Tier", StringType(), True),
    
    
    StructField("settings__trigger__pause_status", StringType(), True)
])


# COMMAND ----------

def transform_job_data(job_data):
  host = get_workspace_creds(workspace)
  extracted_data = [
    {
        'job_id': job['job_id'],
        
        'created_time': job['created_time'],
        'creator_user_name': job['creator_user_name'],
        
        'run_as_user_name': job['run_as_user_name'],
        'workspace': workspace,
        'is_job_deleted': job['is_job_deleted'],
        
        'settings__email_notifications__no_alert_for_skipped_runs': get_nested_value(job, ['settings', 'email_notifications', 'no_alert_for_skipped_runs']),
        'settings__email_notifications__on_failure': get_nested_value(job, ['settings', 'email_notifications', 'on_failure']),
        'settings__format': get_nested_value(job, ['settings', 'format']),
        'settings__max_concurrent_runs': get_nested_value(job, ['settings', 'max_concurrent_runs']),
        'settings__name': get_nested_value(job, ['settings', 'name']),

        'settings__notification_job__no_alert_for_canceled_runs': get_nested_value(job, ['settings', 'notification_job', 'no_alert_for_canceled_runs']),
        'settings__notification_job__no_alert_for_skipped_runs':get_nested_value(job, ['settings', 'notification_job', 'no_alert_for_skipped_runs']),
        'settings__schedule__pause_status':get_nested_value(job, ['settings', 'schedule','pause_status']),
        'settings__schedule__quartz_cron_expression':get_nested_value(job, ['settings', 'schedule', 'quartz_cron_expression']),
        'settings__schedule__timezone_id':get_nested_value(job, ['settings', 'schedule', 'timezone_id']),

        'settings__tags__AffectsEOM':get_nested_value(job, ['settings', 'tags', 'AffectsEOM']),
        'settings__tags__Owner':get_nested_value(job, ['settings', 'tags', 'Owner']),
        'settings__tags__Team':get_nested_value(job, ['settings', 'tags', 'Team']),
        'settings__tags__Type':get_nested_value(job, ['settings', 'tags', 'Type']),

        'settings__git_source__git_branch':get_nested_value(job, ['settings', 'git_source', 'git_branch']),
        'settings__git_source__git_provider':get_nested_value(job, ['settings', 'git_source', 'git_provider']),
        'settings__git_source__git_url':get_nested_value(job, ['settings', 'git_source', 'git_url']),
        'settings__job_clusters':get_nested_value(job, ['settings', 'job_clusters']),

        'settings__email_notifications__on_success':get_nested_value(job, ['settings', 'email_notifications', 'on_success']),
        'settings__parameters':get_nested_value(job, ['settings', 'parameters', 'git_url']),
        'settings__health__rules':get_nested_value(job, ['settings', 'health', 'rules']),
        'settings__tags__Budget':get_nested_value(job, ['settings', 'tags', 'Budget']),

        'settings__compute':get_nested_value(job, ['settings', 'compute']),
        'settings__continuous__pause_status':get_nested_value(job, ['settings', 'continuous', 'pause_status']),
        'settings__email_notifications__on_duration_warning_threshold_exceeded': get_nested_value(job, ['settings', 'email_notifications', 'on_duration_warning_threshold_exceeded']),

        'Domain':get_nested_value(job, ['settings', 'tags', 'Domain']),
        'Priority':get_nested_value(job, ['settings', 'tags', 'Priority']),
        'Job_link': get_nested_value(job, ['job_id']) and f"{host}/#job/{get_nested_value(job, ['job_id'])}" or None,
            
        'settings__tags__Project':get_nested_value(job, ['settings', 'tags', 'Project']),
        'settings__description':get_nested_value(job, ['settings', 'description']),
        'settings__tags__ResourceClass':get_nested_value(job, ['settings', 'tags', 'ResourceClass']),

        'settings__queue__enabled':get_nested_value(job, ['settings', 'queue', 'enabled']),
        'settings__email_notifications__on_start':get_nested_value(job, ['settings', 'email_notifications', 'on_start']),
            
        'settings__tags__Description':get_nested_value(job, ['settings', 'tags', 'Description']),
        'settings__tags__Name':get_nested_value(job, ['settings', 'tags', 'Name']),
        'settings__tags__SLA':get_nested_value(job, ['settings', 'tags', 'SLA']),
        'settings__tags__Priorit':get_nested_value(job, ['settings', 'tags', 'Priorit']),
        'settings__tags__streaming_job':get_nested_value(job, ['settings', 'tags', 'streaming_job']),
        'settings__tags__Service':get_nested_value(job, ['settings', 'tags', 'Service']),

        'settings__tags__Tier': get_nested_value(job, ['settings', 'tags', 'Tier']),
        
        'settings__trigger__pause_status':get_nested_value(job, ['settings', 'trigger', 'pause_status']),

    }
    for job in job_data
  ]

  return extracted_data


# COMMAND ----------

# DBTITLE 1,Databricks Workspace Selector Function
def get_workspace_creds(workspace=None):
  if(workspace == 'logfood'):
    host = 'https://adb-2548836972759138.18.azuredatabricks.net'
  elif (workspace == 'hr'):
    host = 'https://aws-people-analytics.cloud.databricks.com'
  elif (workspace == 'sox'):
    host = 'https://billing-workspace-mt-prod-aws-us-west-2.cloud.databricks.com'
  else: 
    raise Exception("workspace not recognized")

  return host


def get_workspace_client(workspace=None):
  return WorkspaceClient()


# COMMAND ----------

# DBTITLE 1,Workspace Job Details Extractor
def get_job_details():
  w = get_workspace_client()
  jobs_list = get_jobs(w)
  job_data = get_job_data(w, jobs_list)
  pd_job_dtl_df = transform_job_data(job_data)
  return pd_job_dtl_df

# COMMAND ----------

# DBTITLE 1,Job Details Table Name
table_name = 'job_details'

# COMMAND ----------

# DBTITLE 1,Data the CL workspace
job_dtl_df = get_job_details()

# COMMAND ----------

# DBTITLE 1,PySpark Dataframe to write into DB
job_dtl_df = spark.createDataFrame(job_dtl_df, schema=schema)
final_job_dtl_df = job_dtl_df.select([col(col_name).alias(col_name.replace('settings','job'))  for col_name in job_dtl_df.columns])
display(job_dtl_df)
final_job_dtl_df.createOrReplaceTempView('final_job_dtl_df_vw')

# COMMAND ----------

# Enable automatic schema evolution
# spark.sql("SET spark.databericks.delta.schema.autoMerge.enabled = true") 

# Create table if it does not exist
spark.sql(f'''
CREATE TABLE IF NOT EXISTS {uc_nm}.{uc_schema_nm}.job_details (
    job_id BIGINT,  -- Changed from STRING to match LongType in schema
    created_time BIGINT,  -- Matches LongType (timestamp as epoch)
    creator_user_name STRING,
    run_as_user_name STRING,
    workspace STRING,
    is_job_deleted STRING,
    job__email_notifications__no_alert_for_skipped_runs BOOLEAN,
    job__email_notifications__on_failure ARRAY<STRING>,
    job__format STRING,
    job__max_concurrent_runs BIGINT,
    job__name STRING,
    job__notification_job__no_alert_for_canceled_runs BOOLEAN,
    job__notification_job__no_alert_for_skipped_runs BOOLEAN,
    job__schedule__pause_status STRING,
    job__schedule__quartz_cron_expression STRING,
    job__schedule__timezone_id STRING,
    job__tags__AffectsEOM STRING,
    job__tags__Owner STRING,
    job__tags__Team STRING,
    job__tags__Type STRING,
    job__timeout_seconds BIGINT,
    job__git_source__git_branch STRING,
    job__git_source__git_provider STRING,
    job__git_source__git_url STRING,
    job__job_clusters ARRAY<MAP<STRING, STRING>>,
    job__email_notifications__on_success ARRAY<STRING>,
    job__parameters ARRAY<MAP<STRING, STRING>>,
    job__health__rules ARRAY<MAP<STRING, STRING>>,
    job__tags__Budget STRING,
    job__compute ARRAY<MAP<STRING, STRING>>,
    job__continuous__pause_status STRING,
    job__email_notifications__on_duration_warning_threshold_exceeded ARRAY<STRING>,
    Domain STRING,
    Priority STRING,
    Job_link STRING,
    job__tags__Project STRING,
    job__description STRING,
    job__tags__ResourceClass STRING,
    job__queue__enabled BOOLEAN,
    job__email_notifications__on_start ARRAY<STRING>,
    job__tags__Description STRING,
    job__tags__Name STRING,
    job__tags__SLA STRING,
    job__tags__Priorit STRING,
    job__tags__streaming_job STRING,
    job__tags__Service STRING,
    job__tags__Tier STRING,
    job__trigger__pause_status STRING
) USING DELTA
''')


display(spark.sql(f'''
MERGE INTO {uc_nm}.{uc_schema_nm}.job_details target
USING final_job_dtl_df_vw source
ON source.job_id = target.job_id AND source.workspace = target.workspace
WHEN MATCHED THEN
  UPDATE SET *
WHEN NOT MATCHED THEN
  INSERT *
WHEN NOT MATCHED BY SOURCE THEN
  UPDATE SET target.is_job_deleted = 'yes'
'''))
