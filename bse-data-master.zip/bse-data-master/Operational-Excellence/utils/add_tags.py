# !pip install gspread
import json
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, split, explode, regexp_replace, cast
import pandas as pd
import gspread
from databricks.sdk.runtime import *
from pyspark.sql.functions import col, when, udf, lit
from pyspark.sql.types import StringType
from databricks.sdk import WorkspaceClient
from pyspark.sql.functions import coalesce
from databricks.sdk.service.jobs import JobSettings,GitSource,GitProvider
from IPython.display import HTML
import pandas as pd
from pyspark.sql.types import StructType, StructField, StringType

class JobInfoGsheetProcessor:
    def __init__(self, spark: SparkSession, db_utils_cred):
        self.spark = spark
        self.db_utils_cred = db_utils_cred
        self.GCP_DEV_SA = 'dev-bse-storage-access-sa'
        self.gsheet='1ZYllrq0KTleLxLII7xl7RwYMCkBVLRtB2NM1vipPETE'
        self.tab_id='0'
        self.w = WorkspaceClient()
        
    def retrive_gcp_dev_bse_serv_acc_creds(self, sa_name):
        return json.loads(self.db_utils_cred)

    def open_gsheet_by_id(self, gsheet_id, service_account="dev-bse-storage-access-sa"):
        gc = gspread.service_account_from_dict(self.retrive_gcp_dev_bse_serv_acc_creds(service_account))
        return gc.open_by_key(gsheet_id)

    def read_google_worksheet_data(self, gsheet_id, worksheet_id, data_range=None):
        """Reads a worksheet and returns as Spark DataFrame."""
        gsheet = self.open_gsheet_by_id(gsheet_id)
        worksheet = gsheet.get_worksheet_by_id(int(worksheet_id))
        if data_range:
          ws_data = worksheet.get_values(data_range)
        else:
          ws_data = worksheet.get_values()
        pd_df = pd.DataFrame(ws_data)
        pd_df.fillna("",inplace=True) # convert None --> ''
        headers = pd_df.iloc[4]
        headers = [x.lower().replace(" ","_") for x in headers] # convert series to list
        pd_df  = pd.DataFrame(pd_df.values[5:], columns=headers)
        spark_df = self.spark.createDataFrame(pd_df)
        return spark_df
      
    def process_job_info(self):
        """Processes job information from a Google Sheet."""
        df = self.read_google_worksheet_data(self.gsheet, self.tab_id)
        df = (df.withColumnRenamed(
            "pipeline_priority:_importance_of_pipeline_from_a_business_standpoint", "Priority"
        )
        .withColumnRenamed(
            "Primary_Stakeholder(s)__(business_group,_not_individuals,_if_possible)", "Primary_Stakeholders"
        )
        .withColumnRenamed("link_to_job_page_if_available", "Job_link")
        .withColumnRenamed("pipeline_(do_not_update)", "Pipeline")
        .select(
            "Pipeline",
            "Domain",
            "Priority",
            "Primary_Stakeholders",
            "Job_link",
            "primary_owner(s)_of_pipeline",
            "end_of_month/qtr_impacting"
        )
        )
        df = (
            df.withColumn("Job_link", regexp_replace(col("Job_link"), "\n+", ","))
            .withColumn("Job_link", regexp_replace(col("Job_link"), " ", ""))
            .withColumn("Job_link", explode(split(col("Job_link"), ",")))
            .where(
                """Job_link like '%job%' 
                   and Job_link not like '%list%' 
                   and Job_link not like '%aws%' 
                   and Job_link != '' 
                """
            )
            .withColumn("Job_ID", (split(split(col("Job_link"), "#")[1], "/")[1]).cast("bigint"))
            .withColumnRenamed("end_of_month/qtr_impacting", "AffectsEOM")
            .dropDuplicates(["Job_ID"])
        )
        # return df
        return self.read_tags(df)
    
    def add_job_name(self, df):
      # udf definition
      def get_job_name(job_id):
        # w = WorkspaceClient()
        try:
            job = self.w.jobs.get(job_id=job_id)
            return job.settings.name
        except Exception as e:
            # Handle potential errors (e.g., invalid job ID, network issues)
            return f"Error: {str(e)}"
          
      df_list = df.collect()
      df_list2 = [];
      for row in df_list:
          job_id = row["job_id"]  
          job_name = get_job_name(job_id)  
          row = row.asDict()
          row["Jobname"] = job_name
          df_list2.append(row)
      df = self.spark.createDataFrame(df_list2)
      return df

    def read_tags(self, df):
      email_mapping = {
        'brian clapper': 'bmc@databricks.com',
        'madan gopal':'madan.gopal@databricks.com',
        'rk aduri':'rk.aduri@databricks.com',
        'prabhakar guha':'prabhakar.guha@databricks.com',
        'himanshu jain':'himanshu.jain@databricks.com',
        'sachin khurana':'sachin.khurana@databricks.com',
        'suhani mishra':'suhani.mishra@databricks.com',
        'awadhesh singh':'awadhesh.singh@databricks.com',
        'nitin arora':'nitin.arora@databricks.com',
        'zachary villarreal':'zachary.villarreal@databricks.com',
        'jose lainer':'jose.lainer@databricks.com',
        'arpit agrawal':'arpit.agrawal@databricks.com'
      }
      def get_email_address(name):
        name = name.lower()
        email = email_mapping.get(name)
        if email is None:
            raise ValueError(f"Name '{name}' not found in email_mapping")  # Raise an informative error
        return email

      get_email_address_udf = udf(get_email_address, StringType())
      df = df = df.withColumn('Owner', get_email_address_udf(col("primary_owner(s)_of_pipeline")))
      df = df.withColumn('Priority', col("Priority").substr(1, 2))
      df = df.withColumnRenamed('Job_ID', 'job_id')
      df = df.withColumnRenamed('Job_link', 'job_link')
      df = df.select('job_id', 'Pipeline', 'Owner', 'Priority', 'Domain', 'AffectsEOM', 'job_link')
      df = df.withColumn("AffectsEOM", when(col("AffectsEOM") == 'TRUE', "Yes").otherwise("No"))
      # return df, self.get_users(df)
      return self.add_job_name(df)
    
    def get_users(self, df):
      # users_list = df.select("Owner").distinct().rdd.flatMap(lambda x: x).collect()
      users_list = [email for row in df.select("Owner").distinct().collect() for email in row]
      return users_list

    def final_data_for_validation(self, selected_username, df_gsheet):
      df_table = df_gsheet.filter(df_gsheet.Owner == selected_username)
      df = df_table\
        .withColumn('Team', lit('IT-Data'))\
        .withColumn('Type', lit('PROD'))
        # .select(df_table.job_id, 'job_name', 'Team', 'Type', 'Owner', 'Priority', 'Domain')
      return df
    
    def update_jobs(self, df):
      w = self.w
      def row_to_job_settings(row):
          return JobSettings(
              tags={"Team": row["Team"],
                    "Type": row["Type"],
                    "Owner": row["Owner"],
                    "Priority": row["Priority"],
                    "Domain": row["Domain"],
                    "AffectsEOM": row["AffectsEOM"]}
          )
      # Initialize a list to collect exceptions
      exceptions = []
      successfully_updated = []
      for row in df.collect():
          job_id = str(row["job_id"])
          new_settings = row_to_job_settings(row)
          try:
              w.jobs.update(job_id=job_id, new_settings=new_settings)
              successfully_updated.append(job_id)
          except Exception as e:
              # print(f"Job update failed for job_id={job_id}")
              exceptions.append((job_id, str(e)))
      return self.pass_fail_dfs(df, successfully_updated, exceptions)

    def pass_fail_dfs(self, df, passed, failed):
      def process_result(df):
        if df.isEmpty():
          return None
        pdf = df.toPandas()
        pdf['Pipeline'] = pdf.apply(lambda row: f'<a href="{row["job_link"]}">{row["Pipeline"]}</a>', axis=1)
        pdf = pdf.drop('job_link', axis=1)
        pdf = HTML(pdf.to_html(index=False, escape=False))
        return pdf
      
      passed_df = df.filter(df.job_id.isin(passed)).select('job_id','Pipeline','Owner','Priority','Domain','Team','Type', 'AffectsEOM', 'job_link')
      passed_df_html = process_result(passed_df)
      
      exceptions_schema = StructType([
            StructField("job_id", StringType(), True),
            StructField("exception", StringType(), True)
        ])

      exceptions_df = spark.createDataFrame(failed, schema=exceptions_schema)
      failed_df = df.filter(df.job_id.isin([i for i,j in failed])).select('job_id','Pipeline','job_link')
      failed_df = failed_df.join(exceptions_df, on="job_id", how="left_outer").select('job_id','Pipeline', 'job_link', 'exception')
      failed_df_html = process_result(failed_df)
      return passed_df_html, failed_df_html
    
    def update_git(self, df):
      w = self.w
      def gitMigration(jobID):
        try:
          job_git_source = w.jobs.get(job_id=jobID).settings.git_source
          #getting the last field of the git_url to get the repo name
          repo_name = (str(job_git_source.git_url)[::-1].split('/')[0][::-1])
          url = 'https://github.com/databricks-it/'
          #adding the new url with the repo name
          new_git_url = f'{url}{repo_name}'
          job_git_source.git_url = new_git_url
          job_git_source.git_provider = GitProvider('gitHub')
          newSettings = JobSettings(git_source=job_git_source)
          return newSettings
        except Exception as e:
          print("GIT Source object creation failed")
          raise e

      # Initialize a list to collect exceptions
      exceptions = []
      successfully_updated = []
      for row in df.collect():
          job_id = str(row["job_id"])        
          try:
              new_settings = gitMigration(job_id)
              w.jobs.update(job_id=job_id, new_settings=new_settings)
              successfully_updated.append(job_id)
          except Exception as e:
              exceptions.append((job_id, str(e)))
      
      if len(exceptions)==0:
        print("GIT url and GIT Provider has been updated successfully for all the listed jobs.")
        #print("Successfully updated GIT info for jobs: ", '\n'.join(successfully_updated))
        display(df.selectExpr("job_id", "JobName", "'Success' as status","'' as error"))
      else:
        print('Update GIT operation FAILED for few/all jobs.')
        print('Please update GIT info MANUALLY for those jobs.')
        failed_df = spark.createDataFrame(exceptions,['job_id','Error']).createOrReplaceTempView('failed_vw')
        df.createOrReplaceTempView('user_jobs_vw')
        result_df = spark.sql('select uv.job_id, uv.JobName,case when fv.job_id is null then "Success" else "Failed" end as status, fv.error from user_jobs_vw uv left join failed_vw fv on uv.job_id = fv.job_id')
        display(result_df)
      return None

