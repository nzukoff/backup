# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook to add tags to IT-data jobs
# MAGIC This notebook will add/OVERWRITE tags  to the jobs added in [IT Data & Integration - Workflow Documentation](https://docs.google.com/spreadsheets/d/1ZYllrq0KTleLxLII7xl7RwYMCkBVLRtB2NM1vipPETE/edit#gid=0).
# MAGIC If you have NOT added your production job to this workflow document, please add it and use this notebook to add the tags. Optionally, you can also add tags to your job manually as per the [IT-data prod deployment guide](https://docs.google.com/document/d/1Q5c5SX49Y7kySMnrPYGW0sUevzO2Id2FVDoPxDcsf5M/edit?usp=sharing).
# MAGIC
# MAGIC **Note: Please run the notebook only using bse-dev cluster**
# MAGIC

# COMMAND ----------

# DBTITLE 1,Install packages
# MAGIC %pip install gspread
# MAGIC %pip install databricks-sdk
# MAGIC dbutils.library.restartPython()
# MAGIC dbutils.widgets.removeAll()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Please Run the below cell and validate the displayed tags for each job. 
# MAGIC If they are not correct, please add the correct value to [IT Data & Integration - Workflow Documentation](https://docs.google.com/spreadsheets/d/1ZYllrq0KTleLxLII7xl7RwYMCkBVLRtB2NM1vipPETE/edit#gid=0). And then **RERUN** the previous(Select User) cell.
# MAGIC
# MAGIC **Tags**: Owner, Priority, Domain, Team, Type, AffectsEOM

# COMMAND ----------

# DBTITLE 1,Review: please validate the tags to be added to your jobs
dbutils.widgets.removeAll()

db_utils_cred = dbutils.secrets.get(scope="bse-dev-creds", key=f"gcp_dev_bse_creds")
from utils.add_tags import JobInfoGsheetProcessor
job_info_processor = JobInfoGsheetProcessor(spark, db_utils_cred)
df_gsheet = job_info_processor.process_job_info()

username = sql("select current_user() as user").first().user
df = job_info_processor.final_data_for_validation(username, df_gsheet)
display(df.selectExpr('job_id','Pipeline','Jobname','Owner as Tag__Owner','Priority as Tag__Priority','Domain as Tag__Domain','Team as Tag__Team','Type as Tag__Type', 'AffectsEOM as Tag__AffectsEOM'))
dbutils.widgets.dropdown("looks_alright", defaultValue="No", choices=["No","Yes"], label="Verify if looks right")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Please select YES to add the tags
# MAGIC Please use the widget above. Do not run the below cell. 

# COMMAND ----------

# DBTITLE 1,Update Tags:
looks_alright = dbutils.widgets.get("looks_alright")
if looks_alright == "Yes":
  passed, failed = job_info_processor.update_jobs(df)
  if passed is not None:
    print("Tags have been updated for the following jobs")
    display(passed)
  if failed is not None:
    print("Tags update FAILED for the following jobs")
    display(failed)
