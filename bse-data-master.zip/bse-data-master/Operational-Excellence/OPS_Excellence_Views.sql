-- Databricks notebook source
CREATE OR REPLACE VIEW main.it_operations.ops_run_details_vw 
AS 
select 
task_run_id,
job_run_id,
job_id,
job__name,
job_run_page_url,
timestamp_millis(case when task_start_time = 0 then NULL else task_start_time end) as task_start_time,
timestamp_millis(case when task_end_time = 0 then NULL else task_end_time end) as task_end_time,
timestamp_millis(case when job_start_time = 0 then NULL else job_start_time end) as job_start_time,
timestamp_millis(case when job_end_time = 0 then NULL else job_end_time end) as job_end_time,
timestamp_millis(case when created_time = 0 then NULL else created_time end) as created_time,
floor((case when coalesce(job_run_duration,
0) = 0 then (job_setup_duration + job_execution_duration + job_cleanup_duration) else job_run_duration end)/1000) as job_elapsed_time_sec,
floor((task_setup_duration + task_execution_duration + task_cleanup_duration)/1000) as task_elapsed_time_sec,
floor(task_cleanup_duration/1000) as task_cleanup_duration_sec,
floor(task_execution_duration/1000) as task_execution_duration_sec,
floor(task_setup_duration/1000) as task_setup_duration_sec,
floor(job_cleanup_duration/1000) as job_cleanup_duration_sec,
floor(job_execution_duration/1000) as job_execution_duration_sec,
floor(job_run_duration/1000) as job_run_duration_sec,
floor(job_setup_duration/1000) as job_setup_duration_sec,
task_attempt_number,
task_cluster_instance,
task_git_source,
task_job_run_id,
task_notebook_task,
task_run_if,
task_key,
task_existing_cluster_id,
task_depends_on,
task_new_cluster,
task_libraries,
task_description,
task_state__life_cycle_state,
task_state__user_cancelled_or_timedout,
task_state__result_state,
task_state__state_message,
task_notebook_output,
task_error,
task_error_trace,
task_sql_task,
task_original_attempt_run_id,
job_creator_user_name,
job_job_clusters,
job_number_in_job,
job_original_attempt_run_id,
job_run_name,
job_run_type,
job_schedule,
job_tasks,
job_trigger,
job_overriding_parameters,
job_state__life_cycle_state,
job_state__user_cancelled_or_timedout,
job_state__result_state,
job_state__state_message,
job_job_parameters,
creator_user_name,
run_as_user_name,
job__email_notifications__no_alert_for_skipped_runs,
job__email_notifications__on_failure,
job__email_notifications__on_success,
job__format,
job__max_concurrent_runs,
job__notification_job__no_alert_for_canceled_runs,
job__notification_job__no_alert_for_skipped_runs,
job__schedule__pause_status,
job__schedule__quartz_cron_expression,
job__schedule__timezone_id,
job__timeout_seconds,
job__git_source__git_branch,
job__git_source__git_provider,
job__git_source__git_url,
job__email_notifications__on_start,
job__health__rules,
job__tags__Owner,
job__email_notifications__on_duration_warning_threshold_exceeded,
job__tags__Application,
job__tags__Priority,
Pipeline,
Domain,
Priority,
Primary_Stakeholders,
Job_link 
from main.it_operations.task_run_details tr
join main.it_operations.job_run_details jr on tr.task_job_run_id = jr.job_run_id
join main.it_operations.job_details jd using (job_id)


-- COMMAND ----------

create or replace view main.it_operations.ops_long_running_vw
as
with res_set as (
  select job_run_name, job_id, job_run_id, job_start_time, job_state__life_cycle_state as job_life_cycle_state, job_run_page_url  from main.it_operations.job_run_details where job_state__life_cycle_state in ("PENDING","RUNNING","TERMINATING")
),
avg_run as (
  select 
    job_id,
    floor(avg(case when coalesce(job_run_duration,0) = 0 then (job_setup_duration + job_execution_duration + job_cleanup_duration) else job_run_duration end)) as avg_elapsed_time_last30Days
  from main.it_operations.job_run_details where date(timestamp_millis(job_start_time)) between date_add(current_date(),-30) and current_date() and 
  job_id in (select job_id from res_set) and 
  job_state__result_state = 'SUCCESS'
  group by job_id
),
last_updated_job_run_details as (
  select max(timestamp) as last_status_updated_ts from (describe history main.it_operations.job_run_details) where operation = 'MERGE'
)
select 
  job_run_page_url,job_run_name,timestamp_millis(job_start_time) job_start_time, ceil((unix_millis(last_status_updated_ts) - job_start_time)/60000) || ' minutes' job_elapsed_time ,
  ceil(avg_elapsed_time_last30Days/60000)|| ' minutes' avg_elapsed_time_last30Days, round(job_elapsed_time/avg_elapsed_time_last30Days,2) elapsed_x_times_avg, case when (job_elapsed_time/avg_elapsed_time_last30Days) >= 3 then True else False end as long_running_review_3X_avg, jd.Priority
from res_set rs
join avg_run av using (job_id)
join main.it_operations.job_details jd on rs.job_id = jd.job_id
join last_updated_job_run_details last_exec on 1 = 1
order by job_elapsed_time desc, job_start_time desc

-- COMMAND ----------

create or replace view main.it_operations.ops_enforced_rules_vw
as
select job__name,
case when (job__git_source__git_provider is null) then false else true end as Check_RunningFromGIT,
case when (not array_contains(job__email_notifications__on_failure,'bse-data-email.qpvormey@databricks.pagerduty.com') ) then false else true end as Check_PagerDutyAlert,
timestamp_millis(created_time) created_time,creator_user_name,run_as_user_name,Domain,Primary_Stakeholders,Priority,Job_link from main.it_operations.job_details where job__schedule__pause_status = 'UNPAUSED' and (job__git_source__git_provider is null or not array_contains(job__email_notifications__on_failure,'bse-data-email.qpvormey@databricks.pagerduty.com') )

-- COMMAND ----------


