# Databricks notebook source
# MAGIC %pip install databricks-sdk --upgrade

# COMMAND ----------

from databricks.sdk import WorkspaceClient

w = WorkspaceClient()

# COMMAND ----------

df = spark.sql('select distinct job_id from main.it_operations.job_details')
jobs_to_monitor = [row['job_id'] for row in df.collect()]
print(jobs_to_monitor)

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

import datetime
def converttounix(given_datetime) :
  #pattern='%Y-%m-%d %H:%M:%S'
  #formatted_datetime = datetime.datetime.strptime(given_datetime,pattern)
  unixtime = int(datetime.datetime.timestamp(given_datetime))*1000
  return unixtime

# COMMAND ----------

run_data = []
import datetime
    
d = datetime.datetime.now() - datetime.timedelta(days=1)
#d = datetime.datetime.strftime(d,'%Y-%m-%d %H:%M:%S.%s')
#start_time_from = converttounix(d)
start_time_to = converttounix(d)
#print(start_time_from)
print(start_time_to)


# COMMAND ----------

# DBTITLE 1,Generating run_data list with each job IDs run data

for job_id in jobs_to_monitor:
  job_run_data = [c.as_dict() for c in w.jobs.list_runs(job_id=job_id, expand_tasks=True, start_time_to=start_time_to)]
  run_data.extend(job_run_data)

# COMMAND ----------

print(len(run_data))

# COMMAND ----------

# DBTITLE 1,Creating Job level DF from run_data list
job_run_df = spark.createDataFrame(run_data)
job_run_df = job_run_df.select([col(col_name).alias("job_" + col_name)  for col_name in job_run_df.columns])
job_state = [f'job_state.{col_name} as job_state__{col_name}' for col_name in ['life_cycle_state','user_cancelled_or_timedout','result_state','state_message']]
job_run_df = job_run_df.selectExpr('*',*job_state).drop('job_state')
job_run_df = job_run_df.withColumnRenamed('job_job_id','job_id')
display(job_run_df)
job_run_df.createOrReplaceTempView('job_run_df_vw')

# COMMAND ----------

# DBTITLE 1,Loading the Job_Run_Details table
#add a run_id duplicate check - will be useful for running jobs scenario merge operation 
job_run_df.write.format('delta').option("mergeSchema", "true").option("path", "/mnt/bdw-dev/job_run_details").mode('overwrite').saveAsTable('main.it_operations.job_run_details')

# COMMAND ----------

# dbutils.fs.rm('/mnt/bdw-dev/job_run_details/',True)

# COMMAND ----------

# %sql
# drop table main.it_operations.job_run_details

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.it_operations.job_run_details;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from main.it_operations.job_run_details;

# COMMAND ----------

# DBTITLE 1,Generating data for task level from run_data and creating task level df from it
# pd_task_run_df = pd.json_normalize(
#     run_data, "tasks", ['run_id' , 'job_id', 'run_name'] ,record_prefix='task_', sep = '__', errors='ignore'
# )

tasks = []
for run in run_data:
  ltask = run['tasks']
  job_run_id = run['run_id']
  for task in ltask:
    try:
      del task['notebook_task']['base_parameters']
    except:
      None
    task['job_run_id'] = job_run_id
    
  tasks.extend(ltask)

task_run_df = spark.createDataFrame(tasks)

task_run_df = task_run_df.select([col(col_name).alias("task_" + col_name)  for col_name in task_run_df.columns])
state = [f'task_state.{col_name} as task_state__{col_name}' for col_name in ['life_cycle_state','user_cancelled_or_timedout','result_state','state_message']]
task_run_df = task_run_df.selectExpr('*',*state).drop('task_state')
task_run_df = task_run_df.withColumnRenamed('task_task_key','task_key')

display(task_run_df)
task_run_df.createOrReplaceTempView('task_run_df_vw')

# COMMAND ----------

# DBTITLE 1,Extracting Task Run ID for the failed Tasks and getting the error using get_run_output Jobs API
from pyspark.sql.functions import lit
failed_tasks = task_run_df.where("task_state__result_state = 'FAILED'").select('task_run_id').collect()

if len(failed_tasks) != 0:
  #run_dtl_data = [w.jobs.get_run_output(run_id=run['task_run_id']).as_dict() for run in failed_tasks]
  run_dtl_data = []
  for run in failed_tasks:
    try:
      out = w.jobs.get_run_output(run_id=run['task_run_id']).as_dict()
    except Exception as e:
      error = str(e)
      out = {'metadata' : {'run_id' : run['task_run_id']},
             'notebook_output' : f"{error}",
             'error' : f"{error}",
             'error_trace' : f"{error}"
             }
    run_dtl_data.append(out)
  
  df = spark.createDataFrame(run_dtl_data)
  if 'error' not in df.columns:
    df = df.withColumn('error',lit(None).cast('string')).withColumn('error_trace',lit(None).cast('string'))
  df = df.select('metadata.run_id','notebook_output','error','error_trace')
  df.createOrReplaceTempView('task_error_dtl_vw')
  df_task_final = spark.sql('''
                          select tr.*, te.notebook_output as task_notebook_output, te.error as task_error, te.error_trace as task_error_trace
                          from task_run_df_vw tr
                          left join task_error_dtl_vw te on tr.task_run_id = te.run_id
                          ''')
else:
  df_task_final = spark.sql('''select tr.*, cast(Null as string) as task_notebook_output, cast(Null as string) as task_error, cast(Null as string) as task_error_trace from task_run_df_vw tr''')


# COMMAND ----------

df_task_final.write.format('delta').option("mergeSchema", "true").option("path", "/mnt/bdw-dev/task_run_details").mode('overwrite').saveAsTable('main.it_operations.task_run_details')

# COMMAND ----------

# dbutils.fs.rm('/mnt/bdw-dev/task_run_details/',True)

# COMMAND ----------

# %sql
# drop table main.it_operations.task_run_details ;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.it_operations.task_run_details;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from main.it_operations.task_run_details;

# COMMAND ----------


