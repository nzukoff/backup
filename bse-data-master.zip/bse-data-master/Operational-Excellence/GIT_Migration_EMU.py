# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook to update GIT URL and GIT Provider to IT-data jobs after updating GIT creds in Logfood
# MAGIC This notebook will update GIT URL and GIT Provider to the jobs added in [IT Data & Integration - Workflow Documentation](https://docs.google.com/spreadsheets/d/1ZYllrq0KTleLxLII7xl7RwYMCkBVLRtB2NM1vipPETE/edit#gid=0).
# MAGIC If you have NOT added your production job to this workflow document, please add it and use this notebook to update GIT URL and GIT Provider. Optionally, you can also update GIT settings to your jobs manually
# MAGIC
# MAGIC **Note: Please run the notebook only using bse-dev cluster**
# MAGIC

# COMMAND ----------

# DBTITLE 1,Install packages
# MAGIC %pip install gspread
# MAGIC %pip install databricks-sdk
# MAGIC dbutils.library.restartPython()
# MAGIC dbutils.widgets.removeAll()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Please Run the below cell and validate the jobs list. 
# MAGIC If they are not correct, please correct your info in the [IT Data & Integration - Workflow Documentation](https://docs.google.com/spreadsheets/d/1ZYllrq0KTleLxLII7xl7RwYMCkBVLRtB2NM1vipPETE/edit#gid=0). And then **RERUN** the below cell.
# MAGIC

# COMMAND ----------

# DBTITLE 1,Please review your jobs list
#dbutils.widgets.removeAll()

db_utils_cred = dbutils.secrets.get(scope="bse-dev-creds", key=f"gcp_dev_bse_creds")
from utils.add_tags import JobInfoGsheetProcessor
job_info_processor = JobInfoGsheetProcessor(spark, db_utils_cred)
df_gsheet = job_info_processor.process_job_info()

username = sql("select current_user() as user").first().user
#username = ''
df = job_info_processor.final_data_for_validation(username, df_gsheet)
df = df.selectExpr('job_id','Pipeline','Jobname','Owner')
display(df)
#dbutils.widgets.dropdown("looks_alright", defaultValue="No", choices=["No","Yes"], label="Verify if looks right")

# COMMAND ----------

# DBTITLE 1,Update New GIT Url and Provider in the Jobs listed above
job_info_processor.update_git(df)

# COMMAND ----------


