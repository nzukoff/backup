# Databricks notebook source
from pyspark.sql.functions import col,lit

sel_sql = '''
select * 
from main.it_operations.task_run_details tr
join main.it_operations.job_run_details jr on tr.task_job_run_id = jr.job_run_id
join main.it_operations.job_details jd using (job_id)'''

df = spark.sql(sel_sql)
cols_list = df.columns
rearr_cols = ['task_run_id','job_run_id','job_id','job__name','job_run_page_url']
for rearr_column in rearr_cols:
  cols_list.remove(rearr_column)

#converting time columns data from epoch milliseconds to  timestamp format 'yyyy-mm-dd hh24:mi:ss.sss' using timestamp_millis(created_time)
time_columns = ['task_start_time','task_end_time','job_start_time','job_end_time','created_time']
for time_col in time_columns:
  #df = df.withColumn(time_col, timestamp_millis(col(time_col)))
  rearr_cols.append(f'timestamp_millis(case when {time_col} = 0 then NULL else {time_col} end) as {time_col}')
  cols_list.remove(time_col)

#adding exact run duration for job and task 
job_elapsed_time_sec = 'floor((case when coalesce(job_run_duration,0) = 0 then (job_setup_duration + job_execution_duration + job_cleanup_duration) else job_run_duration end)/1000) as job_elapsed_time_sec'
rearr_cols.append(job_elapsed_time_sec)

task_elapsed_time_sec = 'floor((task_setup_duration + task_execution_duration + task_cleanup_duration)/1000) as task_elapsed_time_sec'
rearr_cols.append(task_elapsed_time_sec)


#converting duration columns data from milliseconds to seconds
duration_columns = ['task_cleanup_duration','task_execution_duration','task_setup_duration','job_cleanup_duration','job_execution_duration','job_run_duration','job_setup_duration']
for dur_col in duration_columns:
  #df = df.withColumn(dur_col, col(dur_col) / lit(1000) )
  rearr_cols.append(f'floor({dur_col}/1000) as {dur_col}_sec')
  cols_list.remove(dur_col)

rearr_cols.extend(cols_list)
col_str = ','.join(rearr_cols)
rearr_sel_sql = f'{sel_sql}'.replace('*',col_str)

#print(rearr_sel_sql)
# f'''
# select {col_str}
# from main.it_operations.task_run_details tr
# join main.it_operations.job_run_details jr on tr.task_job_run_id = jr.job_run_id
# join main.it_operations.job_details jd using (job_id)
# '''

spark.sql(f'create or replace view main.it_operations.ops_run_details_vw as {rearr_sel_sql}')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.it_operations.ops_run_details_vw limit 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from main.it_operations.ops_run_details_vw;

# COMMAND ----------

# MAGIC %sql
# MAGIC view definition -
# MAGIC --create or replace view main.it_operations.ops_run_details_vw as
# MAGIC select
# MAGIC   task_run_id,
# MAGIC   job_run_id,
# MAGIC   job_id,
# MAGIC   job__name,
# MAGIC   job_run_page_url,
# MAGIC   timestamp_millis(
# MAGIC     case
# MAGIC       when task_start_time = 0 then NULL
# MAGIC       else task_start_time
# MAGIC     end
# MAGIC   ) as task_start_time,
# MAGIC   timestamp_millis(
# MAGIC     case
# MAGIC       when task_end_time = 0 then NULL
# MAGIC       else task_end_time
# MAGIC     end
# MAGIC   ) as task_end_time,
# MAGIC   timestamp_millis(
# MAGIC     case
# MAGIC       when job_start_time = 0 then NULL
# MAGIC       else job_start_time
# MAGIC     end
# MAGIC   ) as job_start_time,
# MAGIC   timestamp_millis(
# MAGIC     case
# MAGIC       when job_end_time = 0 then NULL
# MAGIC       else job_end_time
# MAGIC     end
# MAGIC   ) as job_end_time,
# MAGIC   timestamp_millis(
# MAGIC     case
# MAGIC       when created_time = 0 then NULL
# MAGIC       else created_time
# MAGIC     end
# MAGIC   ) as created_time,
# MAGIC   floor(
# MAGIC     (
# MAGIC       case
# MAGIC         when coalesce(job_run_duration, 0) = 0 then (
# MAGIC           job_setup_duration + job_execution_duration + job_cleanup_duration
# MAGIC         )
# MAGIC         else job_run_duration
# MAGIC       end
# MAGIC     ) / 1000
# MAGIC   ) as job_elapsed_time_sec,
# MAGIC   floor(
# MAGIC     (
# MAGIC       task_setup_duration + task_execution_duration + task_cleanup_duration
# MAGIC     ) / 1000
# MAGIC   ) as task_elapsed_time_sec,
# MAGIC   floor(task_cleanup_duration / 1000) as task_cleanup_duration_sec,
# MAGIC   floor(task_execution_duration / 1000) as task_execution_duration_sec,
# MAGIC   floor(task_setup_duration / 1000) as task_setup_duration_sec,
# MAGIC   floor(job_cleanup_duration / 1000) as job_cleanup_duration_sec,
# MAGIC   floor(job_execution_duration / 1000) as job_execution_duration_sec,
# MAGIC   floor(job_run_duration / 1000) as job_run_duration_sec,
# MAGIC   floor(job_setup_duration / 1000) as job_setup_duration_sec,
# MAGIC   task_attempt_number,
# MAGIC   task_cluster_instance,
# MAGIC   task_git_source,
# MAGIC   task_job_run_id,
# MAGIC   task_notebook_task,
# MAGIC   task_run_if,
# MAGIC   task_key,
# MAGIC   task_existing_cluster_id,
# MAGIC   task_depends_on,
# MAGIC   task_libraries,
# MAGIC   task_description,
# MAGIC   task_state__life_cycle_state,
# MAGIC   task_state__user_cancelled_or_timedout,
# MAGIC   task_state__result_state,
# MAGIC   task_state__state_message,
# MAGIC   task_notebook_output,
# MAGIC   task_error,
# MAGIC   task_error_trace,
# MAGIC   task_sql_task,
# MAGIC   task_original_attempt_run_id,
# MAGIC   job_creator_user_name,
# MAGIC   job_job_clusters,
# MAGIC   job_number_in_job,
# MAGIC   job_original_attempt_run_id,
# MAGIC   job_run_name,
# MAGIC   job_run_type,
# MAGIC   job_schedule,
# MAGIC   job_tasks,
# MAGIC   job_trigger,
# MAGIC   job_overriding_parameters,
# MAGIC   job_state__life_cycle_state,
# MAGIC   job_state__user_cancelled_or_timedout,
# MAGIC   job_state__result_state,
# MAGIC   job_state__state_message,
# MAGIC   job_job_parameters,
# MAGIC   creator_user_name,
# MAGIC   run_as_user_name,
# MAGIC   job__email_notifications__no_alert_for_skipped_runs,
# MAGIC   job__email_notifications__on_failure,
# MAGIC   job__email_notifications__on_success,
# MAGIC   job__format,
# MAGIC   job__max_concurrent_runs,
# MAGIC   job__notification_job__no_alert_for_canceled_runs,
# MAGIC   job__notification_job__no_alert_for_skipped_runs,
# MAGIC   job__schedule__pause_status,
# MAGIC   job__schedule__quartz_cron_expression,
# MAGIC   job__schedule__timezone_id,
# MAGIC   job__timeout_seconds,
# MAGIC   job__git_source__git_branch,
# MAGIC   job__git_source__git_provider,
# MAGIC   job__git_source__git_url,
# MAGIC   job__email_notifications__on_start,
# MAGIC   job__health__rules,
# MAGIC   job__tags__Owner,
# MAGIC   job__email_notifications__on_duration_warning_threshold_exceeded,
# MAGIC   job__tags__Application,
# MAGIC   job__tags__Priority,
# MAGIC   Pipeline,
# MAGIC   Domain,
# MAGIC   Priority,
# MAGIC   Primary_Stakeholders,
# MAGIC   Job_link
# MAGIC from
# MAGIC   main.it_operations.task_run_details tr
# MAGIC   join main.it_operations.job_run_details jr on tr.task_job_run_id = jr.job_run_id
# MAGIC   join main.it_operations.job_details jd using (job_id)
