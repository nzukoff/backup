# Databricks notebook source
# MAGIC %md
# MAGIC ## Feature - Auditing of enforced rules for a production Job

# COMMAND ----------

# MAGIC %md
# MAGIC ###Jobs where email notification for failure is not set with Pagerduty.

# COMMAND ----------

# DBTITLE 0,Jobs where email notification for failure is not set for Pagerduty.
# MAGIC %sql
# MAGIC select job__name,timestamp_millis(created_time) created_time,creator_user_name,run_as_user_name,Domain,Primary_Stakeholders,Priority,job__email_notifications__on_failure, Job_link from main.it_operations.job_details where not array_contains(job__email_notifications__on_failure,'bse-data-email.qpvormey@databricks.pagerduty.com') 

# COMMAND ----------

# MAGIC %md
# MAGIC ###Jobs which are not scheduled from GIT

# COMMAND ----------

# DBTITLE 0,Jobs which are not scheduled from GIT
# MAGIC %sql
# MAGIC select job_id,job__name,timestamp_millis(created_time) created_time,creator_user_name,run_as_user_name,Domain,Primary_Stakeholders,Priority,Job_link from main.it_operations.job_details where job__git_source__git_provider is null

# COMMAND ----------

# MAGIC %md
# MAGIC ## Feature - Pattern Analysis and Reporting

# COMMAND ----------

# MAGIC %md 
# MAGIC ###Jobs which failed more than 10 times in last 2 months along with the details of failure, to identify the recurring Failures.
# MAGIC ###These recurring errors can be taken up for RCA, and thus can be prioritized for permanent resolution to bring more quality to the Production jobs.

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC with failures_detail as
# MAGIC (select job_run_name,run_as_user_name, sum(count(1)) over (partition by job_run_name) Total_failure_count,task_key,task_error, count(1) error_count
# MAGIC from main.it_operations.ops_run_details_vw
# MAGIC where task_state__result_state='FAILED' group by job_run_name,run_as_user_name,task_key,task_error)
# MAGIC select * from failures_detail
# MAGIC where Total_failure_count > 10
# MAGIC order by Total_failure_count desc

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select *
# MAGIC from
# MAGIC (select job_run_name,run_as_user_name, sum(count(1)) over (partition by job_run_name) Total_failure_count,task_key,task_error, count(1) error_count
# MAGIC from main.it_operations.ops_run_details_vw
# MAGIC where task_state__result_state='FAILED' group by job_run_name,task_key,task_error)
# MAGIC where Total_failure_count > 10
# MAGIC order by Total_failure_count desc

# COMMAND ----------

# MAGIC %md
# MAGIC ### Num of failures per week - last 2 months 

# COMMAND ----------

spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

# COMMAND ----------

display(spark.sql('''select date_format(job_start_time,'MMMM') Month,'week_'||date_format(job_start_time, 'W') month_week, count(*) as num_of_failures from main.it_operations.ops_run_details_vw
where task_state__result_state = 'FAILED' 
group by date_format(job_start_time,'MMMM'), date_format(job_start_time, 'W')''').groupBy('Month').pivot('month_week').sum('num_of_failures').orderBy(''))

# COMMAND ----------

# MAGIC %md 
# MAGIC #### success percent/ratio of job runs per domain

# COMMAND ----------

# MAGIC %sql
# MAGIC select domain, count(distinct job_id) total_num_of_jobs, sum(case when task_state__result_state = 'SUCCESS' then 1 else 0 end) success, sum(case when task_state__result_state != 'SUCCESS' then 1 else 0 end) failures, sum(1) total_num_of_runs, ceil((success/total_num_of_runs * 100)) success_percentage
# MAGIC from 
# MAGIC (select DISTINCT job_run_id, job_id, Domain, task_state__result_state, row_number() OVER(partition by job_run_id ORDER BY task_state__result_state) RN from main.it_operations.ops_run_details_vw where task_state__result_state in ('SUCCESS','FAILED','TIMEDOUT','CANCELED')) dom where RN =1 
# MAGIC group by 1

# COMMAND ----------

# MAGIC %md
# MAGIC ####Longest run of each job from last 2 weeks along with the average run duration of their previous 10 runs 
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC with res_set as (
# MAGIC   select * from
# MAGIC   (select 
# MAGIC     job_run_id, job_id, job_run_page_url, job_run_name, timestamp_millis(job_start_time) job_start_time, timestamp_millis(job_end_time) job_end_time, 
# MAGIC     case when coalesce(job_run_duration,0) = 0 then (job_setup_duration + job_execution_duration + job_cleanup_duration) else job_run_duration end as job_elapsed_time,
# MAGIC     row_number() over (partition by job_run_name order by (case when coalesce(job_run_duration,0) = 0 then (job_setup_duration + job_execution_duration + job_cleanup_duration) else job_run_duration end) desc) rn,
# MAGIC     job_state__result_state
# MAGIC   from main.it_operations.job_run_details 
# MAGIC   where date(timestamp_millis(job_start_time)) between date_add(current_date(),- 15) and current_date() )
# MAGIC   where RN=1
# MAGIC ),
# MAGIC avg_prev_10Runs_exc_CR as (
# MAGIC   select 
# MAGIC     job_run_id,
# MAGIC     floor(avg(case when coalesce(job_run_duration,0) = 0 then (job_setup_duration + job_execution_duration + job_cleanup_duration) else job_run_duration end) over (partition by job_id order by job_start_time asc rows between 51 preceding and 1 preceding)) as avg_prev_10Runs_exc_CR
# MAGIC   from main.it_operations.job_run_details where job_id in (select job_id from res_set)
# MAGIC )
# MAGIC select 
# MAGIC   job_run_page_url,job_run_name,job_start_time,job_end_time,convert_misec_py(job_elapsed_time) job_elapsed_time ,job_state__result_state,
# MAGIC   convert_misec_py(avg_prev_10Runs_exc_CR) avg_prev_10Runs_exc_CR, round(job_elapsed_time/avg_prev_10Runs_exc_CR,2) elapsed_x_times_avg, case when (job_elapsed_time/avg_prev_10Runs_exc_CR) >= 3 then True else False end as review_3x, jd.priority
# MAGIC from res_set rs
# MAGIC join avg_prev_10Runs_exc_CR av using (job_run_id)
# MAGIC join main.it_operations.job_details jd using (job_id)
# MAGIC order by rs.job_elapsed_time desc, job_start_time desc
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #Automation and alerting Feature - Future iterations

# COMMAND ----------

# MAGIC %md 
# MAGIC ###Automation around Repair run - Analysis (WIP) 
# MAGIC ###Failures where tast_state__life_cycle_state is "INTERNAL_ERROR", a repair-run may resolve the the issue.

# COMMAND ----------

# DBTITLE 0,After analysis of failed runs from a total of 11k task runs, it has been analysed that the failures where a restart would be a solution has a life_cycle_state as "INTERNAL_ERROR"
# MAGIC %sql
# MAGIC select distinct task_state__life_cycle_state,task_state__state_message,task_error from main.it_operations.ops_run_details_vw where task_state__result_state='FAILED'  and (task_state__life_cycle_state = 'INTERNAL_ERROR' or lower(task_error) like '%connect%')

# COMMAND ----------

# MAGIC %md 
# MAGIC ###Approx % of failures where action was a repair-run 

# COMMAND ----------

# DBTITLE 0,Approx % of failures where action was a repair-run 
# MAGIC %sql
# MAGIC
# MAGIC select *, ceil(RERUN_SCENARIO/ALL_FAILURES *100 ) as Perc_failures_where_action_was_a_rerun from
# MAGIC (select 'ALL_FAILURES' as Failure_Type, count(*) Num_of_Failures from main.it_operations.ops_run_details_vw where task_state__result_state = 'FAILED' 
# MAGIC union
# MAGIC select 'RERUN_SCENARIO' as Failure_Type, count(*) Num_of_Failures from main.it_operations.ops_run_details_vw where task_state__result_state = 'FAILED'  and (task_state__life_cycle_state = 'INTERNAL_ERROR' or lower(task_error) like '%connect%') ) fails
# MAGIC pivot
# MAGIC (sum(num_of_failures)
# MAGIC for failure_type in ('ALL_FAILURES','RERUN_SCENARIO'))
# MAGIC

# COMMAND ----------

# MAGIC %md 
# MAGIC #### Thus, more than 20% of the failures required a repair-run action which could be resolved via automation, thus removing human intervention in those cases. Thus, this can help in off-loading signicant work from on-call.

# COMMAND ----------


