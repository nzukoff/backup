# Databricks notebook source
# MAGIC %md
# MAGIC ###Table and view names - Operational Excellence
# MAGIC #####bdw_dev.job_details - It has details of the Jobs.
# MAGIC #####bdw_dev.job_run_details - It has details of the Job runs.
# MAGIC #####bdw_dev.task_run_details - It has details of the task runs
# MAGIC #####bdw_dev.ops_run_details_vw - It is a flattened view that has details at the task run level and has all the columns from the above 3 tables.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###Enter the date range (format YYYY-MM-DD) and click on "Run all" to get the failure report for the period.

# COMMAND ----------

# DBTITLE 0,Run the cells to specify the date range, format (yyyy-MM-dd)
dbutils.widgets.text("end_date","")
dbutils.widgets.text("start_date","")


# COMMAND ----------

import datetime
def validate(date_text):
  try:
    datetime.date.fromisoformat(date_text)
  except Exception as e:
    error = (str(e))
    print(error)
    raise Exception(f"Incorrect data format/value - {val} . Please correct the format - YYYY-MM-DD or check the date range.")

start_date = dbutils.widgets.getArgument('start_date')
end_date = dbutils.widgets.getArgument('end_date')

for val in start_date,end_date:
  validate(val)

# COMMAND ----------

df = spark.sql(f'''
with failure_count as (
  select ops.job__name, min(ops.run_as_user_name) run_user_name  , count(distinct ops.JOB_RUN_ID) total_runs_of_job_during_the_period ,
  count(distinct (case when task_state__result_state in ('FAILED','TIMEDOUT')  then ops.JOB_RUN_ID else NULL end)) failed_runs_of_job_during_the_period,
  round(failed_runs_of_job_during_the_period/total_runs_of_job_during_the_period * 100 , 2 ) Perc_failures_for_the_period
  from main.it_operations.ops_run_details_vw ops
  where to_date(job_start_time) between to_date('{start_date}', 'yyyy-MM-dd') and to_date('{end_date}', 'yyyy-MM-dd') 
  group by 1
  having failed_runs_of_job_during_the_period > 0
)
select * from failure_count ''')
df.createOrReplaceTempView('failure_count_vw')

# COMMAND ----------

# DBTITLE 1,Job Level details 
# MAGIC %sql
# MAGIC select * from failure_count_vw

# COMMAND ----------

df = spark.sql(f''' select run_as_user_name,job__name,coalesce(task_error, task_state__state_message) task_error, job_run_page_url , JOB_RUN_ID, job_start_time,task_run_id, task_start_time, task_attempt_number, task_state__result_state  from main.it_operations.ops_run_details_vw where to_date(job_start_time) between to_date('{start_date}', 'yyyy-MM-dd') and to_date('{end_date}', 'yyyy-MM-dd') and task_state__result_state in ('FAILED','TIMEDOUT') ''')
df.createOrReplaceTempView('job_failures_vw')


# COMMAND ----------

# DBTITLE 1,Run Level Details
# MAGIC %sql
# MAGIC select * from job_failures_vw
# MAGIC order by job__name,job_run_id,task_attempt_number

# COMMAND ----------

# MAGIC %md
# MAGIC ###Jobs where email notification for failure is not set with Pagerduty.

# COMMAND ----------

# MAGIC %sql
# MAGIC select job__name,timestamp_millis(created_time) created_time,creator_user_name,run_as_user_name,Domain,Primary_Stakeholders,Priority,job__email_notifications__on_failure, Job_link from main.it_operations.job_details where  job__schedule__pause_status = 'UNPAUSED' and not array_contains(job__email_notifications__on_failure,'bse-data-email.qpvormey@databricks.pagerduty.com') 

# COMMAND ----------

# MAGIC %md
# MAGIC ###Jobs which are not scheduled from GIT

# COMMAND ----------

# DBTITLE 0,Jobs which are not scheduled from GIT
# MAGIC %sql
# MAGIC select job_id,job__name,timestamp_millis(created_time) created_time,creator_user_name,run_as_user_name,Domain,Primary_Stakeholders,Priority,Job_link from main.it_operations.job_details where job__schedule__pause_status = 'UNPAUSED' and job__git_source__git_provider is null

# COMMAND ----------

# MAGIC %md
# MAGIC #####Identifying actionable errors from last 90 days runs(retries included) which occured in last 30 Days as well

# COMMAND ----------

# DBTITLE 0, 
# MAGIC %sql  
# MAGIC with cte as (select job_run_name,run_as_user_name,task_error,case 
# MAGIC   --when upper(task_error) like '%POOL%' then 'POOL'
# MAGIC   when upper(task_error) like '%GIT%' then 'GIT'
# MAGIC   when upper(task_error) like '%FATAL%' then 'FATAL'
# MAGIC   when upper(task_error) like '%COLUMN%' then 'COLUMN'
# MAGIC   when upper(task_error) like '%TABLE%' or upper(task_error) like '%VIEW%' then 'TABLE_OR_VIEW'
# MAGIC   when upper(task_error) like '%IMPORT%' then 'IMPORT'
# MAGIC   when upper(task_error) like '%CONNECTION%' then 'CONNECTION'
# MAGIC   when upper(task_error) like '%CLUSTER%' then 'CLUSTER'
# MAGIC   else 'OTHER'
# MAGIC end as error_type, max(job_start_time) as Error_last_occured_on, min(job_start_time) first_occurance_last90Days, count(*) failure_count
# MAGIC from main.it_operations.ops_run_details_vw where task_state__result_state = 'FAILED' and to_date(job_start_time) between date_add(current_date(), -90 ) and current_date()
# MAGIC  group by job_run_name,run_as_user_name,task_error)
# MAGIC select * from cte 
# MAGIC where Error_last_occured_on between date_add(current_date(), -30 ) and current_date() order by failure_count desc
# MAGIC

# COMMAND ----------


