# Databricks notebook source
ENV =    dbutils.widgets.get("ENV")
WORKSPACE = dbutils.widgets.get("WORKSPACE")

# COMMAND ----------


if ENV.upper() == 'PROD':
  if WORKSPACE.upper() == 'LOGFOOD':
    name = 'PROD'
    uc_nm = 'main'
    uc_schema_nm = 'it_operations'
  elif WORKSPACE.upper() == 'SOX':
    name = 'PROD'
    uc_nm = 'main'
    uc_schema_nm = 'it_sox_migration_poc'
elif ENV.upper() == 'INT':
  if WORKSPACE.upper() == 'LOGFOOD':
    name = 'INT'
    uc_nm = 'integration'
    uc_schema_nm = 'it_operations'
  elif WORKSPACE.upper() == 'SOX':
    name = 'INT'
    uc_nm = 'integration'
    uc_schema_nm = 'it_sox_migration_poc'
elif ENV.upper() == 'DEV':
  name = 'DEV'
  uc_nm = 'users'
  uc_schema_nm = 'himanshu_jain'
else:
  raise Exception(f"Config is not defined for {ENV}")

# COMMAND ----------


