# Databricks notebook source
from pyspark.sql.functions import udf, struct, lag
from pyspark.sql.types import BooleanType
from pyspark.sql import functions as F
from datetime import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import *

# COMMAND ----------

def set_config(env):
  """ sets config for an environment """
  scope = "bui-bse-integration-"+env
  sas_container = "fs.azure.sas.container-bui-bse-share-{0}.stbuibseshare{0}.blob.core.windows.net".format(env)
  spark.conf.set(sas_container, dbutils.secrets.get(scope,"stbuibseshare/r/sas"))

# COMMAND ----------

# config for tables
uc_catalog = 'main'
uc_schema = 'it_bui_silver'
uc_prefx = f"""{uc_catalog}.{uc_schema}"""

workspaces_table = f"""{uc_prefx}.bui_workspaces"""
bui_accounts_table = f"""{uc_prefx}.bui_accounts"""
bui_metering_table = f"""{uc_prefx}.bui_metering"""
bui_metering_agg_table = f"""{uc_prefx}.bui_metering_agg"""
bui_subscriptions_table = f"""{uc_prefx}.bui_subscriptions"""
bui_subscriptions_latest_view = f"""{uc_prefx}.bui_subscriptions_latest_vw"""
bui_workspaces_table = f"""{uc_prefx}.bui_workspaces"""
bui_workspaces_latest_table = f"""{uc_prefx}.bui_workspaces_latest"""

# COMMAND ----------

env = "prod"
set_config(env)
REDACTED_METERING_LOCATION_OLD = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/redacted_metering/".format(env)
REDACTED_METERING_LOCATION_NEW = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/dlt/redacted_metering/".format(env)

REDACTED_ACCOUNTS_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/redacted_accounts/".format(env)
REDACTED_HISTORY_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/workspaces_history/".format(env)
REDACTED_SNAPSHOT_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/workspaces_snapshot/".format(env)

# COMMAND ----------

REDACTED_SUBSCRIPTION_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/redacted_subscriptions/".format(env)

# COMMAND ----------

print(REDACTED_METERING_LOCATION_OLD, REDACTED_METERING_LOCATION_NEW)

# COMMAND ----------

#metering_df = spark.read.format("delta").load(REDACTED_METERING_LOCATION)

metering_df_old = spark.read.format("delta").load(REDACTED_METERING_LOCATION_OLD)
metering_df_new = spark.read.format("delta").load(REDACTED_METERING_LOCATION_NEW)

accounts_df = spark.read.format("delta").load(REDACTED_ACCOUNTS_LOCATION)
hist_df = spark.read.format("delta").load(REDACTED_HISTORY_LOCATION)
snapshot_df = spark.read.format("delta").load(REDACTED_SNAPSHOT_LOCATION)

# COMMAND ----------

drop_columns = ['awsInfo', 'azureInfo', 'billing']
hist_df = hist_df.withColumn("aws_is_hippa", col("awsInfo.is_hipaa"))\
                 .withColumn("aws_mp_customer_identifier", col("awsInfo.aws_marketplace_info.customer_identifier"))\
                 .withColumn("aws_mp_product_code", col("awsInfo.aws_marketplace_info.product_code"))\
                 .withColumn("azure_appliance_id", col("azureInfo.appliance_id"))\
                 .withColumn("azure_location", col("azureInfo.location"))\
                 .withColumn("billing_id", col("billing.billing_id"))\
                 .withColumn("chargify_cc_subscription_id", col("billing.chargify_credit_card.subscription_id"))\
                 .withColumn("chargify_invoice_subscription_id", col("billing.chargify_invoice.subscription_id"))\
                 .withColumn("netsuite_subscription_id", col("billing.net_suite_subscription.subscription_id"))\
                 .withColumn("billing_manual", col("billing.manual"))\
                 .drop(*drop_columns)

# COMMAND ----------

metering_df_old = metering_df_old.withColumn("clusterNodeType", col("tags.clusterNodeType"))\
                                 .withColumn("dbuMultiplier", col("tags.dbuMultiplier"))\
                                 .withColumn("clusterInstanceMilliseconds", col("tags.clusterInstanceMilliseconds"))\
                                 .withColumn("clusterId", col("tags.clusterId"))\
                                 .withColumn("workloadType", col("tags.workloadType"))\
                                 .withColumn("clusterCreator", col("tags.clusterCreator"))\
                                 .withColumn("billingTimestamp", col("tags.billingTimestamp"))\
                                 .withColumn("clusterSku", col("tags.clusterSku"))\
                                 .withColumn("clusterName", col("tags.clusterName"))\
                                 .drop("tags")

metering_df_new = metering_df_new.withColumn("clusterNodeType", col("tags.clusterNodeType"))\
                                 .withColumn("dbuMultiplier", col("tags.dbuMultiplier"))\
                                 .withColumn("clusterInstanceMilliseconds", col("tags.clusterInstanceMilliseconds"))\
                                 .withColumn("clusterId", col("tags.clusterId"))\
                                 .withColumn("workloadType", col("tags.workloadType"))\
                                 .withColumn("clusterCreator", col("tags.clusterCreator"))\
                                 .withColumn("billingTimestamp", col("tags.billingTimestamp"))\
                                 .withColumn("clusterSku", col("tags.clusterSku"))\
                                 .withColumn("clusterName", col("tags.clusterName"))\
                                 .drop("tags", "eventId")

metering_df_old.createOrReplaceTempView("metering_old")
metering_df_new.createOrReplaceTempView("metering_new")

# COMMAND ----------

# BUI has been cutover to the new billing pipeline from 01/24/2022 onwards
# Old billing pipeline still should be good for data prior to 01/24/2022
metering_df = spark.sql("""
select *
from metering_old
where date < "2022-01-24"
union
select *
from metering_new
where date >= "2022-01-24"
""")

# COMMAND ----------

# DBTITLE 1,Account Table
accounts_df.write/
           .option("overwriteSchema", "true")/
           .format("delta")/
           .mode("overwrite")/
           .saveAsTable(bui_accounts_table)
           #.save("/mnt/bse-dev/bui_accounts")

# COMMAND ----------

# %sql
# create table bdw.bui_accounts
# using delta
# location "/mnt/bse-dev/bui_accounts"

# COMMAND ----------

# DBTITLE 1,Metering Table
metering_df.write/
           .option("overwriteSchema", "true")/
           .format("delta")/
           .mode("overwrite")/
           .saveAsTable(bui_metering_table)
           #.save("/mnt/bse-dev/bui_metering")

# COMMAND ----------

# %sql
# create table bdw.bui_metering
# using delta
# location "/mnt/bse-dev/bui_metering"

# COMMAND ----------

# DBTITLE 1,History Table
# maxQueryTimestamp = spark.sql("select max(queryTimestamp) as max_queryTimestamp from bdw.bui_workspaces").collect()[0].max_queryTimestamp
# hist_df_append = hist_df.filter(hist_df.queryTimestamp > maxQueryTimestamp)

# COMMAND ----------

#hist_df_append.write.option("overwriteSchema", "true").format("delta").mode("append").save("/mnt/bse-dev/bui_hist")
#hist_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/bui_hist")

# COMMAND ----------

# %sql
# create table bdw.bui_workspaces
# using delta
# location "/mnt/bse-dev/bui_hist"

# COMMAND ----------

# %sql
# optimize bdw.bui_workspaces

# COMMAND ----------

# DBTITLE 1,Latest Workspace-NetSuitesubscriptionId
#workspace_df = spark.sql("select * from bdw.bui_workspaces")

# COMMAND ----------

# subscription_window = Window.partitionBy("workspaceId")\
#                             .orderBy(desc("queryTimestamp"))
# workspace_df = workspace_df.withColumn("row_number", row_number().over(subscription_window))
# workspace_df = workspace_df.filter(workspace_df.row_number==1)\
#                            .drop(workspace_df.row_number)

# COMMAND ----------

drop_columns = ['awsInfo', 'azureInfo', 'billing']
workspace_df = snapshot_df.withColumn("aws_is_hippa", col("awsInfo.is_hipaa"))\
                           .withColumn("aws_mp_customer_identifier", col("awsInfo.aws_marketplace_info.customer_identifier"))\
                           .withColumn("aws_mp_product_code", col("awsInfo.aws_marketplace_info.product_code"))\
                           .withColumn("azure_appliance_id", col("azureInfo.appliance_id"))\
                           .withColumn("azure_location", col("azureInfo.location"))\
                           .withColumn("billing_id", col("billing.billing_id"))\
                           .withColumn("chargify_cc_subscription_id", col("billing.chargify_credit_card.subscription_id"))\
                           .withColumn("chargify_invoice_subscription_id", col("billing.chargify_invoice.subscription_id"))\
                           .withColumn("netsuite_subscription_id", col("billing.net_suite_subscription.subscription_id"))\
                           .withColumn("billing_manual", col("billing.manual"))\
                           .drop(*drop_columns)

# COMMAND ----------

workspace_df.write/
            .option("overwriteSchema", "true")/
            .format("delta")/
            .mode("overwrite")/
            .saveAsTable(bui_workspaces_latest_table)
            #.save("/mnt/bse-dev/bui_workspace_latest")

# COMMAND ----------

# %sql
# create table bdw.bui_workspaces_latest
# using delta
# location "/mnt/bse-dev/bui_workspace_latest"

# COMMAND ----------

# DBTITLE 1,metering_agg table
metering_agg_query = f"""
with metering_agg (
select workspaceId,
       sku,
       date,
       isPaying,
       sum(quantity) quantity
from {bui_metering_table}
group by 1,2,3,4
)

select mg.workspaceId,
       wl.netsuite_subscription_id,
       mg.sku,
       mg.date,
       mg.isPaying,
       mg.quantity,
       wl.workspaceName,
       wl.trialExpirationTime 
from metering_agg mg
join {bui_workspaces_latest_table} wl on mg.workspaceId = cast(wl.workspaceId as string)
"""
metering_agg_df = spark.sql(metering_agg_query)

# COMMAND ----------

display(metering_agg_df)

# COMMAND ----------

metering_agg_df.write/
               .option("overwriteSchema", "true")/
               .format("delta")/
               .mode("overwrite")/
               .saveAsTable(bui_metering_agg_table)
               #.save("/mnt/bse-dev/bui_metering_agg")

# COMMAND ----------

# %sql
# create table bdw.bui_metering_agg
# using delta
# location "/mnt/bse-dev/bui_metering_agg"

# COMMAND ----------

subscriptions_df = spark.read.format("delta").load(REDACTED_SUBSCRIPTION_LOCATION)

# COMMAND ----------

subscriptions_df.write/
                .option("overwriteSchema", "true")/
                .format("delta")/
                .mode("overwrite")/
                .saveAsTable(bui_subscriptions_table)
                #.save("/mnt/bse-dev/aws_subscriptions")

# COMMAND ----------

# %sql
# create table bdw.bui_subscriptions
# using delta
# location '/mnt/bse-dev/aws_subscriptions'
