# Databricks notebook source
spark.sql(

f'''

insert into main.it_data_insights.it_tickets_metrics_sales_ops_support 
select 
Category,
HelpDeskQueue,
Department,
Group,
CustomerInteractions,
Agent,
AgentInteractions,
RequesterEmail,
RequesterName,
Source,
`Sub-Category` as sub_category,
ResolutionTimeinBhrs,
FirstResponseTimeinChrs,
`Ticket Id` as ticket_id,
`Approval Status` as approval_status,
Impact,
Priority,
Urgency,
SurveyScore,
Status,
`Created Time` as created_time,
`Closed Time` as closed_time,
DueByTime,
LastUpdatedTime,
`Resolution Status` as resolution_status,
`Elapsed Time in Calendar Hours` as elapsed_time_in_calendar_hours,
ItemCategory,
current_timestamp() as table_update_timestamp
 from main.it_freshservice_silver.IT_Tickets_Metrics where HelpDeskQueue in ('Sales Ops Support') 
'''
)
