# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC INSERT INTO main.it_data_insights.eng_tickets_fresh_service
# MAGIC SELECT
# MAGIC created_date,
# MAGIC   created_week,
# MAGIC   created_month,
# MAGIC   trim(RequesterEmail) AS RequesterEmail,
# MAGIC   trim(RequesterName) AS RequesterName,
# MAGIC   trim(hire_date) AS hire_date,
# MAGIC   trim(tenure_range) AS tenure_range,
# MAGIC   trim(tenure_ticket_created) AS tenure_ticket_created,
# MAGIC   trim(location) AS location,
# MAGIC   trim(job_profile) AS job_profile,
# MAGIC   trim(business_title) AS business_title,
# MAGIC   --trim(cost_center) AS cost_center,
# MAGIC   trim(Department) AS department,
# MAGIC   trim(ticket_group) AS ticket_group,
# MAGIC   trim(sup_org_name) AS sup_org_name,
# MAGIC   trim(estaff) AS esaff,
# MAGIC   trim(L0) AS L0,
# MAGIC   trim(L1) AS L1,
# MAGIC   trim(L2) AS L2,
# MAGIC   trim(L3) AS L3,
# MAGIC   trim(L4) AS L4,
# MAGIC   trim(L5) AS L5,
# MAGIC   trim(L6) AS L6,
# MAGIC   trim(Category) AS Category,
# MAGIC   trim(sub_category) AS sub_category,
# MAGIC   trim(HelpDeskQueue) AS HelpDeskQueue,
# MAGIC   trim(Source) AS Source,
# MAGIC   trim(Impact) AS Impact,
# MAGIC   trim(Priority) AS Priority,
# MAGIC   trim(Urgency) AS Urgency,
# MAGIC   trim(Status) AS Status,
# MAGIC   trim(ItemCategory) AS ItemCategory,
# MAGIC   trim(ticket_id) AS ticket_id,
# MAGIC   count(1) AS count,
# MAGIC   current_timestamp() as table_update_timestamp
# MAGIC FROM (
# MAGIC   SELECT DISTINCT
# MAGIC   date(`Created Time`) as created_date,
# MAGIC     substr((date_trunc('week', `Created Time` + interval '2' day) - interval '2' day), 1, 10) AS created_week,
# MAGIC     substr(date_trunc('month', `Created Time`), 1, 7) AS created_month,
# MAGIC     T.RequesterEmail,
# MAGIC     RequesterName,
# MAGIC     hire_date,
# MAGIC     CASE
# MAGIC         WHEN DATEDIFF(CURRENT_DATE(), hire_date) < 30 THEN '1 month'
# MAGIC         WHEN DATEDIFF(CURRENT_DATE(), hire_date) < 60 THEN '2 months'
# MAGIC         WHEN DATEDIFF(CURRENT_DATE(), hire_date) < 90 THEN '3 months'
# MAGIC         WHEN DATEDIFF(CURRENT_DATE(), hire_date) BETWEEN 90 AND 180 THEN '3-6 months'
# MAGIC         ELSE 'More than 6 months'
# MAGIC     END AS tenure_range,
# MAGIC     CASE
# MAGIC         WHEN DATEDIFF(`Created Time`, hire_date) < 2 THEN '1 day'
# MAGIC         WHEN DATEDIFF(`Created Time`, hire_date) BETWEEN 2 AND 7 THEN '2 day - 1 week'
# MAGIC         WHEN DATEDIFF(`Created Time`, hire_date) BETWEEN 8 AND 30 THEN '1 week - 1 month' 
# MAGIC         WHEN DATEDIFF(`Created Time`, hire_date) < 60 THEN '2 months'
# MAGIC         WHEN DATEDIFF(`Created Time`, hire_date) < 90 THEN '3 months'
# MAGIC         WHEN DATEDIFF(`Created Time`, hire_date) BETWEEN 90 AND 180 THEN '3-6 months'
# MAGIC         WHEN DATEDIFF(`Created Time`, hire_date) BETWEEN 180 AND 365 THEN '6-12 months'
# MAGIC         WHEN DATEDIFF(`Created Time`, hire_date) BETWEEN 365 AND 730 THEN '12-24 months'
# MAGIC         ELSE 'More than 24 months'
# MAGIC     END AS tenure_ticket_created,
# MAGIC     location,
# MAGIC     job_profile,
# MAGIC     E.business_title,
# MAGIC     cost_center,
# MAGIC     Department,
# MAGIC     'Group' AS ticket_group,
# MAGIC     sup_org_name,
# MAGIC     estaff,
# MAGIC     L0,
# MAGIC     L1,
# MAGIC     L2,
# MAGIC     L3,
# MAGIC     L4,
# MAGIC     L5,
# MAGIC     L6,
# MAGIC     Category,
# MAGIC     `Sub-Category` AS sub_category,
# MAGIC     HelpDeskQueue,
# MAGIC     Source,
# MAGIC     Impact,
# MAGIC     Priority,
# MAGIC     Urgency,
# MAGIC     Status,
# MAGIC     ItemCategory,
# MAGIC     `Ticket Id` AS ticket_id
# MAGIC   FROM main.data_opex.workday_hierarchy W
# MAGIC   INNER JOIN main.it_freshservice_silver.IT_Tickets_Metrics T
# MAGIC     ON W.email = T.RequesterEmail
# MAGIC   INNER JOIN (SELECT *  from  
# MAGIC               main.workday.active_workers 
# MAGIC               where effective_date in (select max(effective_date) from main.workday.active_workers 
# MAGIC               ) ) E
# MAGIC     ON W.email = E.email
# MAGIC   WHERE W.L2 = 'vinod.marur@databricks.com'
# MAGIC     --AND T.Department = '201 Engineering'
# MAGIC ) t
# MAGIC GROUP BY
# MAGIC created_date,
# MAGIC   created_week,
# MAGIC   created_month,
# MAGIC   trim(RequesterEmail),
# MAGIC   trim(RequesterName),
# MAGIC   trim(hire_date),
# MAGIC   trim(tenure_range),
# MAGIC   trim(tenure_ticket_created),
# MAGIC   trim(location),
# MAGIC   trim(job_profile),
# MAGIC   trim(business_title),
# MAGIC   --trim(cost_center),
# MAGIC   trim(Department),
# MAGIC   trim(ticket_group),
# MAGIC   trim(sup_org_name),
# MAGIC   trim(estaff),
# MAGIC   trim(L0),
# MAGIC   trim(L1),
# MAGIC   trim(L2),
# MAGIC   trim(L3),
# MAGIC   trim(L4),
# MAGIC   trim(L5),
# MAGIC   trim(L6),
# MAGIC   trim(Category),
# MAGIC   trim(sub_category),
# MAGIC   trim(HelpDeskQueue),
# MAGIC   trim(Source),
# MAGIC   trim(Impact),
# MAGIC   trim(Priority),
# MAGIC   trim(Urgency),
# MAGIC   trim(Status),
# MAGIC   trim(ItemCategory),
# MAGIC   trim(ticket_id),
# MAGIC   current_timestamp();

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC INSERT OVERWRITE main.it_data_insights.eng_tickets_last120days
# MAGIC SELECT * 
# MAGIC from main.it_data_insights.eng_tickets_fresh_service
# MAGIC   where datediff(current_date(), created_date) <  120
# MAGIC   and table_update_timestamp = (select max(table_update_timestamp) from main.it_data_insights.eng_tickets_fresh_service)
# MAGIC ;
# MAGIC
