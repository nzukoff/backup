# Databricks notebook source
# MAGIC %md
# MAGIC ### Give access to all the gsheets dev-bse-storage-access-sa@gcp-dev-bse.iam.gserviceaccount.com

# COMMAND ----------

# MAGIC %run ./Read_GSheet_Logfood_UDF

# COMMAND ----------

from pyspark.sql.types import DoubleType
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'test':
  savings_table_name = "integration.it_operations.it_estaff_savings"
  fy_26_savings_table_name = "integration.it_operations.fy26_it_estaff_savings"
  saas_master_table_name = "integration.it_operations.it_company_saas_master"
  emp_table_name = "integration.it_operations.it_estaff_emloyee_count"
  saasmaster_table_new_name = "integration.it_operations.it_company_saas_application"
else:
  savings_table_name = "main.it_operations.it_estaff_savings"
  fy_26_savings_table_name = "main.it_operations.fy26_it_estaff_savings"
  saas_master_table_name = "main.it_operations.it_company_saas_master"
  emp_table_name = "main.it_operations.it_estaff_emloyee_count"
  saasmaster_table_new_name = "main.it_operations.it_company_saas_application"

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Reading Savings Sheet Gsheet and writing it to the table
# MAGIC Link: https://docs.google.com/spreadsheets/d/193DGn0qjp-v20OUTaiGbuty5PB8rzt6wwOy1iCWyUTc/edit#gid=0

# COMMAND ----------

savings_df = read_google_worksheet_data('193DGn0qjp-v20OUTaiGbuty5PB8rzt6wwOy1iCWyUTc', '0')

# COMMAND ----------

display(savings_df)

# COMMAND ----------

savings_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(savings_table_name)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### FY26 Reading Savings Sheet Gsheet and writing it to the table
# MAGIC Link: https://docs.google.com/spreadsheets/d/1yA9xCyd6vQ5QP8Dq9CQMTbcLB2E5yKqIImPDnS2duFQ/edit?gid=562676422#gid=562676422

# COMMAND ----------

fy26_savings_df = read_google_worksheet_data('1yA9xCyd6vQ5QP8Dq9CQMTbcLB2E5yKqIImPDnS2duFQ', '562676422')

# COMMAND ----------

fy26_savings_df = fy26_savings_df.withColumnRenamed("what's_the_plan?", "what_is_the_plan") \
                       .withColumnRenamed("contract_value_(annual)/fy25_actuals", "contract_value_annual_fy25_actuals") \
                       .withColumn("contract_value_annual_fy25_actuals", when(col('contract_value_annual_fy25_actuals') == '', lit('0')).otherwise(regexp_replace('contract_value_annual_fy25_actuals', ',', lit('')))) \
                       .withColumn("fy26_forecast", when(col('fy26_forecast') == '', lit('0')).otherwise(regexp_replace('fy26_forecast', ',', lit('')))) \
                       .withColumn("fy26_actuals", when(col('fy26_actuals') == '', lit('0')).otherwise(regexp_replace('fy26_actuals', ',', lit('')))) \
                       .withColumn("fy26_savings", when(col('fy26_savings') == '', lit('0')).otherwise(regexp_replace('fy26_savings', ',', lit(''))))
                       #.withColumn("fy_27_savings", when(col('fy_27_savings') == '', lit('0')).otherwise(regexp_replace('fy_27_savings', ',', lit(''))))

# COMMAND ----------

display(fy26_savings_df)

# COMMAND ----------

fy26_savings_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(fy_26_savings_table_name)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Deprecated and using the new sheet as per jira BSEDATA-3410
# MAGIC ### Reading Master All Data (first sheet) GSheet and writing it to the table
# MAGIC
# MAGIC
# MAGIC * Link: https://docs.google.com/spreadsheets/d/1t7thOX7WhU3PudomAVkNx58KNpWGeeqW_JrXncrE1UM/edit#gid=1966588242

# COMMAND ----------

# master_all_df = read_google_worksheet_data('1t7thOX7WhU3PudomAVkNx58KNpWGeeqW_JrXncrE1UM', '1966588242')

# COMMAND ----------

# display(master_all_df)

# COMMAND ----------

# master_all_df = master_all_df.withColumnRenamed("estaff", "Estaff") \
#                              .withColumnRenamed("vendor", "Vendor") \
#                              .withColumnRenamed("sum_of_fy23", "SUM_of_FY23") \
#                              .withColumnRenamed("sum_of_fy24", "SUM_of_FY24") \
#                              .withColumnRenamed("yoy", "YoY") \
#                              .withColumnRenamed("renewal_date", "Renewal_Date") \
#                              .withColumnRenamed("naveen_recommendation", "Naveen_Recommendation") \
#                              .withColumnRenamed("estaff_perspective", "eStaff_Perspective")

# COMMAND ----------

# master_all_df = master_all_df.withColumn("SUM_of_FY23", when(col('SUM_of_FY23') == '', lit('0')).otherwise(regexp_replace('SUM_of_FY23', ',', lit('')))) \
#                              .withColumn("SUM_of_FY24", when(col('SUM_of_FY24') == '', lit('0')).otherwise(regexp_replace('SUM_of_FY24', ',', lit('')))) \
#                              .withColumn("YoY", when(col('YoY') == '', lit('0')).otherwise(regexp_replace('SUM_of_FY24', '%', lit(''))))

# COMMAND ----------

# master_all_df = master_all_df.withColumn("SUM_of_FY23", col('SUM_of_FY23').cast('double')) \
#                              .withColumn("SUM_of_FY24", col('SUM_of_FY24').cast('double')) \
#                              .withColumn("YoY", col('YoY').cast('double'))

# COMMAND ----------

# display(master_all_df)

# COMMAND ----------

# master_all_df = spark.sql("""
# select * from master_all_data
# union
# select 'all' as Estaff, 'all' as Vendor, sum(SUM_of_FY23) as SUM_of_FY23, sum(SUM_of_FY24) as SUM_of_FY24, sum(YoY) as YoY, 'N/A' as Renewal_Date, '' as Naveen_Recommendation, ''  as eStaff_Perspective, '' as action from hive_metastore.bdw_dev.fy_24_company_saa_s_master_all_data_1
# """)

# COMMAND ----------

# master_all_df.write.mode("overwrite").option("overwriteSchema","true").saveAsTable(saas_master_table_name)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Reading Master All Data (second sheet) GSheet and writing it to the table
# MAGIC Link: https://docs.google.com/spreadsheets/d/1t7thOX7WhU3PudomAVkNx58KNpWGeeqW_JrXncrE1UM/edit#gid=145432674

# COMMAND ----------

master_emp_cnt_df = read_google_worksheet_data('1t7thOX7WhU3PudomAVkNx58KNpWGeeqW_JrXncrE1UM', '145432674')

# COMMAND ----------

display(master_emp_cnt_df)

# COMMAND ----------

master_emp_cnt_df = master_emp_cnt_df.withColumn("count", regexp_replace('count', ',', '').cast('long')) \
                                     .withColumnRenamed("leader", "Leader") \
                                     .withColumnRenamed("count", "Count")

# COMMAND ----------

display(master_emp_cnt_df)

# COMMAND ----------

master_emp_cnt_df.write.mode("overwrite").option("overwriteSchema","true").saveAsTable(emp_table_name)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Reading Master All Data (first sheet) GSheet and writing it to the table
# MAGIC Link: https://docs.google.com/spreadsheets/d/1yA9xCyd6vQ5QP8Dq9CQMTbcLB2E5yKqIImPDnS2duFQ/edit#gid=972634547

# COMMAND ----------

master_all_df = read_google_worksheet_data('1yA9xCyd6vQ5QP8Dq9CQMTbcLB2E5yKqIImPDnS2duFQ', '972634547')

# COMMAND ----------

master_all_df = master_all_df.drop("") \
                             .withColumn("fy23_amount", when(col('fy23_amount') == '', lit('0')).otherwise(regexp_replace('fy23_amount', ',', lit('')))) \
                             .withColumn("fy24_amount", when(col('fy24_amount') == '', lit('0')).otherwise(regexp_replace('fy24_amount', ',', lit('')))) \
                             .withColumn("fy25_amount", when(col('fy25_amount') == '', lit('0')).otherwise(regexp_replace('fy25_amount', ',', lit('')))) \
                             .withColumn("fy26_amount", when(col('fy26_amount') == '', lit('0')).otherwise(regexp_replace('fy26_amount', ',', lit('')))) \
                             .withColumn("fy24_yoy", when(col('fy24_yoy') == '', lit('0')).otherwise(regexp_replace('fy24_yoy', '%', lit('')))) \
                             .withColumn("fy25_yoy", when(col('fy25_yoy') == '', lit('0')).otherwise(regexp_replace('fy25_yoy', '%', lit('')))) \
                             .withColumn("fy26_yoy", when(col('fy26_yoy') == '', lit('0')).otherwise(regexp_replace('fy26_yoy', '%', lit(''))))

# COMMAND ----------

master_all_df = master_all_df.withColumn("fy23_amount", col('fy23_amount').cast('double')) \
                             .withColumn("fy24_amount", col('fy24_amount').cast('double')) \
                             .withColumn("fy25_amount", col('fy25_amount').cast('double')) \
                             .withColumn("fy26_amount", col('fy26_amount').cast('double')) \
                             .withColumn("fy24_yoy", col('fy24_yoy').cast('double')) \
                             .withColumn("fy25_yoy", col('fy25_yoy').cast('double')) \
                             .withColumn("fy26_yoy", col('fy26_yoy').cast('double'))

# COMMAND ----------

display(master_all_df)

# COMMAND ----------

master_all_df.write.mode("overwrite").option("overwriteSchema","true").saveAsTable(saasmaster_table_new_name)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Reading FY26 data GSheet and writing it to the table
# MAGIC * Jira: https://databricks.atlassian.net/browse/BSEDATA-3410
# MAGIC * Link: https://docs.google.com/spreadsheets/d/1yA9xCyd6vQ5QP8Dq9CQMTbcLB2E5yKqIImPDnS2duFQ/edit?gid=722224811#gid=722224811

# COMMAND ----------

fy26_saas_master_df = read_google_worksheet_data('1yA9xCyd6vQ5QP8Dq9CQMTbcLB2E5yKqIImPDnS2duFQ', '722224811')

# COMMAND ----------

display(fy26_saas_master_df)

# COMMAND ----------

fy26_data_df = fy26_saas_master_df.withColumn("fy24_spend", when(col('fy24_spend') == '', lit('0')).otherwise(regexp_replace('fy24_spend', ',', lit('')))) \
                             .withColumn("fy25_spend", when(col('fy25_spend') == '', lit('0')).otherwise(regexp_replace('fy25_spend', ',', lit('')))) \
                             .withColumn("fy26_forecast", when(col('fy26_forecast') == '', lit('0')).otherwise(regexp_replace('fy26_forecast', ',', lit('')))) \
                             .withColumn("fy26_yoy_$", when(col('fy26_yoy_$') == '', lit('0')).otherwise(regexp_replace('fy26_yoy_$', '%', lit('')))) \
                             .withColumn("fy25_yoy_%", when(col('fy25_yoy_%') == '', lit('0')).otherwise(regexp_replace('fy25_yoy_%', '%', lit('')))) \
                             .withColumn("fy26_yoy_%", when(col('fy26_yoy_%') == '', lit('0')).otherwise(regexp_replace('fy26_yoy_%', '%', lit('')))) \
                             .withColumn("fy24_spend", col('fy24_spend').cast('double')) \
                             .withColumn("fy25_spend", col('fy25_spend').cast('double')) \
                             .withColumn("fy26_forecast", col('fy26_forecast').cast('double')) \
                             .withColumn("fy26_yoy_$", col('fy26_yoy_$').cast('double')) \
                             .withColumn("fy25_yoy_%", col('fy25_yoy_%').cast('double')) \
                             .withColumn("fy26_yoy_%", col('fy26_yoy_%').cast('double'))

# COMMAND ----------

display(fy26_data_df)

# COMMAND ----------

fy26_data_df.write.mode("overwrite").option("overwriteSchema","true").saveAsTable(saas_master_table_name)

# COMMAND ----------


