# Databricks notebook source
# MAGIC %md
# MAGIC <h2> UDF to read GSheet as a Spark dataframe. 
# MAGIC Please make sure "dev-bse-storage-access-sa@gcp-dev-bse.iam.gserviceaccount.com" user has proper (READ/WRITE) access to the spreadsheet 

# COMMAND ----------

!pip install gspread

# COMMAND ----------

import json
import pandas as pd
import gspread

# COMMAND ----------

GCP_DEV_SA = 'dev-bse-storage-access-sa'

# COMMAND ----------

def retrive_gcp_dev_bse_serv_acc_creds(sa_name):
  return json.loads(dbutils.secrets.get(scope = "bse-dev-creds", key = f"gcp_dev_bse_creds"))#[sa_name]

def open_gsheet_by_id(gsheet_id, service_account = GCP_DEV_SA):
  gc = gspread.service_account_from_dict(retrive_gcp_dev_bse_serv_acc_creds(service_account))
  return gc.open_by_key(gsheet_id)

def read_google_worksheet_data(gsheet_id, worksheet_id, data_range = None):
  """
    This function reads a worksheet (based on range if defined) and return as spark dataframe
  """

  gsheet = open_gsheet_by_id(gsheet_id)
  worksheet = gsheet.get_worksheet_by_id(int(worksheet_id))

  if data_range:
    ws_data = worksheet.get_values(data_range)
  else:
    ws_data = worksheet.get_values()

  pd_df = pd.DataFrame(ws_data)
  pd_df.fillna("",inplace=True) # convert None --> ''

  headers = pd_df.iloc[0]
  headers = [x.lower().replace(" ","_") for x in headers] # convert series to list

  pd_df  = pd.DataFrame(pd_df.values[1:], columns=headers)
  
  spark_df = spark.createDataFrame(pd_df)
  
  return spark_df


# COMMAND ----------

#display(read_google_worksheet_data('1d3qYDVPZjoTsRu29E4d7hmk8gO4r01LBSnJlzkf-E9w', '1565179257', 'A1:B10'))
