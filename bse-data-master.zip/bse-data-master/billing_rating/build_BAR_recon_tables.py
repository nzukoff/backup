# Databricks notebook source
# MAGIC %md
# MAGIC This notebook is responsible for ingesting and populating the recon dashboard tables.   
# MAGIC **IMPORTANT** 
# MAGIC Change the default environment when migrating from DEV to SIT and UAT and Prod

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.dropdown("environment", "uat", ["dev", "sit", "stg", "uat", "prod"])

# COMMAND ----------

ENV = dbutils.widgets.get('environment')
print(ENV)

# COMMAND ----------

# MAGIC %run 
# MAGIC ./utils/defs_and_helper_functions_recon

# COMMAND ----------

print(f'{UC_CATALOG}.{UC_SCHEMA}.{PLATFORM_SRC_TBL_NAME}')
print(f'{INVOICE_TRGT_TABLE}')
print(f'{CUST_TRGT_TABLE}')
print(f'{REPORT_SKU_CONFIG}')
print(f'{REPORT_USAGE_TRGT_TBLE}')  
print (f'{REPORT_INVOICE_TRGT_TBLE}')
print(f'{REPORT_TRGT_TBLE}')
print(f'{BILLABLE_USAGE_DATA}')
print(f'{business_sub_tbl}')


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.it_billing_and_rating.dlt_business_subscription

# COMMAND ----------

# MAGIC %md
# MAGIC Selects the usage data from billable_usage table and tries to eliminate any missing business subscription ids by joining with SF table views.
# MAGIC Then summarizes the data by Business Subscription ID, Platform SKU and Date.

# COMMAND ----------

#First Usage Data from billable_usage table. The source for Platform data. 
# In future this will change to platform table directly.
sqlquery = f''' 
      with cte as (
      select *,
      row_number() over (partition by record_id order by usage_time desc) as rn
      from 
      {BILLABLE_USAGE_DATA} 
      --users.rongduan_zhu.billable_usage
      ),
      null_bs_cte as (
      select business_subscription_id, platform_subscription_id, platform_account_id, sku_name,usage_time,net_usage_amount from cte
      where rn = 1  
      and business_subscription_id is null ),
      not_null_bs_cte AS (
       select business_subscription_id, platform_subscription_id, platform_account_id, sku_name,usage_time,net_usage_amount from cte
      where rn = 1  
      and business_subscription_id is not null 
      ),
      sfdc_cte AS (
        select a.*, b.sfdc_business_subscription_id
        from null_bs_cte a LEFT join  
        {business_sub_tbl} b
        --bdw_dev.stg_dlt_business_subscription 
        on (a.platform_subscription_id = b.platform_subscription_id)  
                                          or ((a.platform_subscription_id is null and b.platform_subscription_id is null) and a.platform_account_id = b.platform_account_id)
      ),
      all_cte as (
      select sfdc_business_subscription_id as business_subscription_id, platform_subscription_id, platform_account_id, sku_name,usage_time,net_usage_amount 
      from sfdc_cte 
      union all
      select business_subscription_id, platform_subscription_id, platform_account_id, sku_name,usage_time,net_usage_amount 
      from not_null_bs_cte
      )
      select * from all_cte 
  '''

usage_df = spark.sql(sqlquery)
#usage_df.display()
usage_df.createOrReplaceTempView('bu_data_by_ut')
#Create a summary view of usage data to be in the same 'grain' as the invoice data. ie by bus-id,sku and date
summary_df = spark.sql(
            '''
                select business_subscription_id, platform_subscription_id, sku_name, sum(net_usage_amount) as usage_quantity,to_date(usage_time,'yyyy-mm-dd') as date
                from bu_data_by_ut
                group by business_subscription_id, platform_subscription_id, sku_name,to_date(usage_time,'yyyy-mm-dd')
            ''')

summary_df.createOrReplaceTempView('summarydata')


# COMMAND ----------

# MAGIC %md
# MAGIC This step selects the daily set of metronome invoices for the recon process. Since Metronome drops invoices that may have changed invoice ids due to plan changes this logic to ensure all the invoices are correctly picked up for the recon process.

# COMMAND ----------

#Then Invoice data
preinvoice_df = spark.sql(
  f'''

    with allinvoice as (
        select *, dense_rank() over (partition by customer_id,plan_id,date(start_timestamp) order by process_timestamp desc) as rn
        from {INVOICE_TRGT_TABLE} where plan_id is not null
    )
      select * from allinvoice where rn = 1
  
    union all 

      select *,1 from {INVOICE_TRGT_TABLE}
      where plan_id is null
'''
)
preinvoice_df.createOrReplaceTempView('invoicestbl')
invoice_df = spark.sql(
  '''
    with distinct_cte as (
        select *, row_number() over (partition by id order by process_timestamp)as rnum 
        from invoicestbl 
        )
    select * from distinct_cte where rnum = 1
  '''
)


# COMMAND ----------

# MAGIC %md
# MAGIC Process invoices to extract line and subline items.

# COMMAND ----------


# now process invoice data to be flattened
df_line = invoice_df.withColumn("line_item_struct", explode("line_items"))
df_line = df_line.withColumn("sub_line_item_struct", explode("line_item_struct.sub_line_items"))


# COMMAND ----------

# MAGIC %md
# MAGIC Filter out a large set of records that have 0 quantity since they are just noise.

# COMMAND ----------

# Due to a lot of skus with no usage data.
df_flat = df_line.filter(df_line.sub_line_item_struct.quantity != "0")
#print(df_flat.count())


# COMMAND ----------

# MAGIC %md
# MAGIC Create the flattened invoice df with the correct schema

# COMMAND ----------


df_flat= (
    df_flat.withColumn("invoice_servicename", col("line_item_struct.name"))
    .withColumn("invoice_total_qty", col("line_item_struct.quantity").cast("double"))
    .withColumn("invoice_total_usage", col("line_item_struct.total").cast("double"))
    .withColumn("invoice_product_id", col("line_item_struct.product_id"))
    .withColumn("sline_item_name", col("sub_line_item_struct.name"))
    .withColumn("sline_item_price", col("sub_line_item_struct.price").cast("double"))
    .withColumn("sline_item_charge_id", col("sub_line_item_struct.charge_id"))
    .withColumn(
        "sline_item_quantity", col("sub_line_item_struct.quantity").cast("double")
    )
    .withColumn(
        "sline_item_subtotal", col("sub_line_item_struct.subtotal").cast("double")
    )
    .withColumn(
        "sline_item_netsuite_internal_item_id",
        col("sub_line_item_struct.custom_fields.netsuite_internal_item_id"),
    )
    .drop(col("line_item_struct"))
    .drop(col("sub_line_item_struct"))
    .drop(col("line_items"))
)
df_flat = df_flat.withColumn(
    "credit_type_id", regexp_extract(col("credit_type"), "id=(.*)\}", 1)
).withColumn("currency", regexp_extract(col("credit_type"), "name=(.*?),", 1))

# COMMAND ----------

# MAGIC %md
# MAGIC Extract the final cust_id column and then clean up the dates column. 

# COMMAND ----------


cust_df = spark.sql(f'''
select * from {CUST_TRGT_TABLE}
''')
cust_df= cust_df.withColumn('bus_id', explode(col('ingest_aliases')))
cust_df = cust_df.select('name','id','bus_id')
cust_df = cust_df.withColumnRenamed('id','c_id').withColumnRenamed('bus_id','b_id')
#cust_df.display()
#cust_df.createOrReplaceTempView('customertable')
#df_flat.createOrReplaceTempView('invoiceflat')

df_flat_cust = df_flat.join(cust_df,cust_df.c_id==df_flat.customer_id,'inner')
df_flat_cust.count()
df_flat_cust2 = df_flat_cust.withColumn('invoice_process_dt', col('process_timestamp').cast('date')).\
      withColumn('invoice_start_dt',col('start_timestamp').cast('date')).\
      withColumn('invoice_end_dt',col('end_timestamp').cast('date'))   


# COMMAND ----------

# MAGIC %md
# MAGIC Save transformed invoice df to table.

# COMMAND ----------

#Write the recon invoice data df and save.
pathtoinvoicetble = f'{REPORT_INVOICE_TRGT_TBLE}'
df_flat_cust2.write.mode('overwrite').option('mergeSchema', 'true').saveAsTable(pathtoinvoicetble)

# COMMAND ----------

# MAGIC %md
# MAGIC Process usage data to ensure correct mapping between Platform SKU names and Metronome SKU names.

# COMMAND ----------

#Add missing SKUs/Map SKU names to usage table to represent what is in Metronome
summary_df = spark.sql(f'''
select /*+ BROADCAST(t2) */
t1.*, t2.product_name as newproductname
--case  when product_name is null then sku_name
--      else product_name
--      end as newproductname
from summarydata t1 left join {REPORT_SKU_CONFIG} t2 ON t1.sku_name = t2.productcode;
''')
#Save to table 
summary_df = summary_df.withColumnRenamed('sku_name','platform_sku_name').drop('product_name').withColumnRenamed('newproductname','sku_name')
summary_df.display()
target_table_path = f'{REPORT_USAGE_TRGT_TBLE}'
summary_df.write.format('delta').option('mergeSchema','true').mode('overwrite').saveAsTable(target_table_path)


# COMMAND ----------

# MAGIC %md
# MAGIC The following sql is to reconcile Usage Platform data with Metronome recieved data.

# COMMAND ----------

reporting_table_df = spark.sql( f''' 
with sum_usage_cte as (
  select b.business_subscription_id,b.platform_sku_name, b.sku_name, month(date) as month, a.id, sum(b.usage_quantity) as usage_sum
    from {REPORT_USAGE_TRGT_TBLE} b  
    left join {REPORT_INVOICE_TRGT_TBLE} a --bdw_dev.metronome_recon_invoice_data a
      on a.b_id = b.business_subscription_id
      and a.sline_item_name = b.sku_name 
      and b.date BETWEEN a.invoice_start_dt and date_sub(a.invoice_end_dt, 1)
    group by b.business_subscription_id, b.platform_sku_name, b.sku_name, a.id, month(date)
)

select
  d.b_id as bus_subscr_from_metronome,
  c.business_subscription_id as bus_subscr_from_platform,
  d.customer_id,
  d.name as name_of_client,
  d.id as metronome_invoice_id,
  month,
  d.status,
  c.platform_sku_name as sku_from_platform,
  d.sline_item_name as sku_from_metronome,
  ifnull(round(c.usage_sum,10),0) as platform_usage,
  ifnull(round(d.sline_item_quantity,10),0) as metronome_usage,
  abs(ifnull(c.usage_sum,0) - ifnull(d.sline_item_quantity,0)) as difference,
  round(d.sline_item_price/100,2) as invoice_lineitem_price,
  round(d.sline_item_subtotal/100,2) as invoice_item_subtotal,
  d.invoice_start_dt,
  d.invoice_end_dt,
  d.process_timestamp,
  d.plan_id,
  date_sub(d.invoice_end_dt, 1) as actual_end_dt
from
  sum_usage_cte c
  FULL OUTER JOIN  {REPORT_INVOICE_TRGT_TBLE} d ----{REPORT_INVOICE_TRGT_TBLE} d
on c.id = d.id
   and c.business_subscription_id = d.b_id
   and c.sku_name = d.sline_item_name 
--where (c.business_subscription_id = 'BS-0000025535' or d.b_id = 'BS-0000025535')
order by difference
'''
)
reporting_table_df.createOrReplaceTempView('recon_reporting_table')


# COMMAND ----------

# MAGIC %md
# MAGIC Save the report view from above as a table to ensure dashboard is performant. This report table is recalculated every day. 

# COMMAND ----------

pathtoreportingtable = f'{REPORT_TRGT_TBLE}'
reporting_table_df.write.format('delta').option('mergeSchema','true').mode('overwrite').saveAsTable(pathtoreportingtable)


# COMMAND ----------


