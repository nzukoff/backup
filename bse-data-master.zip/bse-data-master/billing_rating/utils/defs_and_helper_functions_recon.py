# Databricks notebook source
# DBTITLE 1,Global Variables Setup
from pyspark.sql.functions import *
from pyspark.sql.types import * 
from datetime import datetime, timedelta
import requests
import json

env_configs = {
                "dev_external": {
                            "prnt_dir": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating",
                            "ver": "v1",
                            "prefix": "dev_external_",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/mnt/bse-dev/billing_and_rating/dev_external/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/dev_external/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/mnt/bse-dev/billing_and_rating/dev_external/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/dev_external/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/dev_external/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/dev_external/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sitnew",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "sandbox",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "users.madan_gopal.dev_metronome_customers",
                            "invoice_trgt_table": "users.madan_gopal.dev_metronome_invoices",
                            "platform_source_schema": "users.rongduan_zhu",
                            "platform_source_table": "billable_usage"
                  },
                  "dev": {
                            "prnt_dir": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating",
                            "ver": "v1",
                            "prefix": "dev_",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/mnt/bse-dev/billing_and_rating/dev/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/dev/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/mnt/bse-dev/billing_and_rating/dev/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/dev/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/dev/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/dev/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sitnew",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "sandbox",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "users.madan_gopal.dev_metronome_customers",
                            "invoice_trgt_table": "users.madan_gopal.dev_metronome_invoices",
                            "platform_source_schema": "users.rongduan_zhu",
                            "platform_source_table": "billable_usage",
                            "reporting_invoice_trgt_table": "metronome_recon_invoice_data",
                            "reporting_usage_trgt_table": "recon_usage_summary",
                            "reporting_trgt_table": "recon_reporting_table",
                            "sku_config": "metronome_sku_config",
                            "s3_egress_bucketname": "bse-metronome-egress-test",
                            "s3_egress_foldername": "metronome_sit_s3",
                            "uc_catalog":"main",
                            "uc_schema":"it_billing_and_rating"
                  },
                  "sit": {
                            "prnt_dir": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating",
                            "ver": "v1",
                            "prefix": "",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/mnt/bse-dev/billing_and_rating/sit/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/sit/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/mnt/bse-dev/billing_and_rating/sit/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/sit/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/sit/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/sit/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sitnew",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "sit",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "users.madan_gopal.metronome_customers", #"integration.it_billing_and_rating.sit_metronome_customers",
                            "invoice_trgt_table": "users.madan_gopal.metronome_invoices", #"integration.it_billing_and_rating.sit_metronome_invoices",
                            "platform_source_schema": "users.rongduan_zhu",
                            "platform_source_table": "billable_usage",
                            "reporting_invoice_trgt_table": "metronome_recon_invoice_data",
                            "reporting_usage_trgt_table": "recon_usage_summary",
                            "reporting_trgt_table": "recon_reporting_table",
                            "sku_config": "metronome_sku_config",
                            "s3_egress_bucketname":"bse-metronome-egress-test",
                            "s3_egress_foldername":"metronome_sit_s3",
                            "uc_catalog":"main",
                            "uc_schema":"it_billing_and_rating"

                  },
                  "uat": {
                            "prnt_dir": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating",
                            "ver": "v1",
                            "prefix": "",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/mnt/bse-dev/billing_and_rating/uat/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/uat/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/mnt/bse-dev/billing_and_rating/uat/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/uat/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/uat/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/uat/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sitnew",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "uat",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "integration.it_billing_and_rating.uat_metronome_customers",
                            "invoice_trgt_table": "integration.it_billing_and_rating.uat_metronome_invoices", 
                            "reporting_invoice_trgt_table": "metronome_recon_invoice_data",
                            "reporting_usage_trgt_table": "recon_usage_summary",
                            "reporting_trgt_table": "recon_reporting_table",
                            "sku_config": "metronome_sku_config",
                            "s3_egress_bucketname":"bse-metronome-egress-test",
                            "s3_egress_foldername":"metronome_sit_s3",
                            "uc_catalog":"main",
                            "uc_schema":"it_billing_and_rating"       
                  },
                  "stg": {
                            "prnt_dir": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/v1",
                            "ver": "v1",
                            "prefix": "stg_",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/mnt/bse-dev/billing_and_rating/stg/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/stg/usage_events_upload/v2/streaming_job_checkpoint",
                            "fallback_location": "/mnt/bse-dev/billing_and_rating/stg/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/stg/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/stg/usage_events_upload/v2/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/stg/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "stgnew",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "stg",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "users.madan_gopal.stg_metronome_customers", #"integration.it_billing_and_rating.sit_metronome_customers",
                            "invoice_trgt_table": "users.madan_gopal.stg_metronome_invoices", #"integration.it_billing_and_rating.sit_metronome_invoices",
                            "platform_source_schema": "users.rongduan_zhu",
                            "platform_source_table": "billable_usage",
                            "reporting_invoice_trgt_table": "metronome_recon_invoice_data",
                            "reporting_usage_trgt_table": "recon_usage_summary",
                            "reporting_trgt_table": "recon_reporting_table",
                            "sku_config": "metronome_sku_config",
                            "s3_egress_bucketname":"bse-metronome-egress-test",
                            "s3_egress_foldername":"metronome_sit_s3",
                            "uc_catalog":"main",
                            "uc_schema":"it_billing_and_rating"
                  },
                  "prod": {
                            "prnt_dir": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating",
                            "ver": "v1",
                            "prefix": "",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/mnt/bse-prod/billing_and_rating/prod/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/prod/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/mnt/bse-prod/billing_and_rating/prod/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/mnt/bse-prod/billing_and_rating/prod/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/prod/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/mnt/bse-prod/billing_and_rating/prod/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sfdcprod",
                            "sfdc_domain": "databricks.my",
                            "output_schema": "bdw",
                            "metronome_env": "prod",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "platform_source_schema": "users.rongduan_zhu",
                            "platform_source_table": "billable_usage",
                            "cust_trgt_table": "main.it_billing_and_rating.metronome_customers",
                            "invoice_trgt_table": "main.it_billing_and_rating.metronome_invoices",
                            "reporting_invoice_trgt_table": "metronome_recon_invoice_data",
                            "reporting_usage_trgt_table": "recon_usage_summary",
                            "reporting_trgt_table": "recon_reporting_table",
                            "sku_config": "metronome_sku_config",
                            "s3_egress_bucketname":"bse-metronome-egress-test",
                            "s3_egress_foldername":"metronome_sit_s3",
                            "uc_catalog":"main",
                            "uc_schema":"it_billing_and_rating"
                  }
}

env_config = env_configs[ENV]

PRT_DIR = f"{env_config['prnt_dir']}/{ENV}"
TBL_VER = env_config["ver"]
TBL_PREFIX = env_config["prefix"]
DLT_TBL_PRT_DIR = f"{PRT_DIR}/tables/{TBL_VER}"
OUTPUT_SCHEMA = env_config["output_schema"]


PLATFORM_SRC_SCHEMA = env_config["platform_source_schema"] 
PLATFORM_SRC_TBL_NAME = env_config["platform_source_table"]
INVOICE_TRGT_TABLE = env_config["invoice_trgt_table"]
CUST_TRGT_TABLE = env_config["cust_trgt_table"]

rpt_inv_trgt_tble= env_config["reporting_invoice_trgt_table"]
rpt_usage_trgt_tble = env_config["reporting_usage_trgt_table"]
rpt_trgt = env_config["reporting_trgt_table"]
rpt_sku_tble = env_config["sku_config"]

UC_CATALOG = env_config["uc_catalog"] 
UC_SCHEMA =  env_config["uc_schema"]


#Reporting 
BILLABLE_USAGE_DATA = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}{PLATFORM_SRC_TBL_NAME}"

REPORT_INVOICE_TRGT_TBLE = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}{rpt_inv_trgt_tble}"
REPORT_USAGE_TRGT_TBLE = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}{rpt_usage_trgt_tble}"
REPORT_TRGT_TBLE = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}{rpt_trgt}"
REPORT_SKU_CONFIG= f"{UC_CATALOG}.{UC_SCHEMA}.{rpt_sku_tble}"

S3_EGRESS_BUCKET= env_config["s3_egress_bucketname"]
S3_EGRESS_FOLDER = env_config["s3_egress_foldername"]

SFDC_BS_SRC_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}business_sub"
REPROCESSED_USAGE_EVENTS_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}reprocessed_events_batch"
REPROCESSED_USAGE_EVENTS_TBL = f"{OUTPUT_SCHEMA}.{TBL_PREFIX}reprocessed_events_batch"

DLT_USAGE_EVENTS_GOLD_TABLE_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}dlt_usage_events_gold"
DLT_HOLD_USAGE_EVENTS_WO_BS_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}dlt_hold_usage_events_without_bs"

OUTPUT_FALLBACK_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}hold_unsucessfull_events"
OUTPUT_PROCESSED_EVENTS_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}usage_processed_events"

processed_output_table_name = f"{OUTPUT_SCHEMA}.{TBL_PREFIX}usage_processed_events"
hold_unsucessfull_output_table_name = f"{OUTPUT_SCHEMA}.{TBL_PREFIX}hold_unsucessfull_events"
business_sub_tbl = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}dlt_business_subscription"

NUM_OF_PARALLEL_CONECTIONS = 32 #this will be equal to number of taks for each batch; configured for 8workers 3tasks/worker
TRANSACTION_ID_COL = "record_id"
CUSTOMER_ID_ALS = "business_subscription_id"
TIMESTAMP_COL = "usage_time"
PAYLOAD_COL = "event"
EVENT_TYPE_VALUE = "billable"          #hard coded value 
BACKDATED_DATA_API_LIMIT = 34
PROCESS_DATE_COLUMN_NAME = "process_date"
PROCESS_TIMESTAMP_COLUMN_NAME = "process_timestamp"
UNIQUE_RECORD_ID = "record_id"
MISSING_BS_ID_COL = "missing_bs_id"
MISSING_SFDC_BS_ID_COL = "missing_sfdc_bs_id"

USAGE_TABLE_FIELDS = ['business_subscription_id', 'event_id', 'platform_subscription_id', 'platform_account_id', 'record_id', 'record_type', 'parent_record_id', 'date', 'metering_type', 'usage_amount', 'start_time','end_time', 'event_time', 'workspace_id', 'sku_name', 'list_price', 'paying_status', 'cloud', 'contract_model', 'invoicing_channel', 'add_ons_list_price_rated_amount', 'credits_usage_amount','net_usage_amount', 'usage_time', 'billable_usage_write_time']

metronome_event_payload = ['transaction_id', 'timestamp', 'customer_id', 'event_type', 'properties']
properties_map = ['business_subscription_id', 'net_usage_amount', 'sku_name', 'workspace_id', 'cloud', 'add_ons_list_price_rated_amount', 'metering_type']


# COMMAND ----------

## Retrive Metronome API Key from the DB secrets 
def retrive_metronome_api_token(env = "sandbox"):
  return dbutils.secrets.get(scope = "bse-metronome", key = f"metronome_api_key_{env}") 

def set_config(env):
  """ sets config for an environment """
  scope = "bse-metronome"
  sas_container = "fs.azure.sas.bse-rating-and-billing.dbbusinesssystems1.blob.core.windows.net"
  spark.conf.set(sas_container, dbutils.secrets.get(scope,"bse-rating-and-billing-access-key"))
  print(scope)
  print(sas_container)


set_config(ENV)
