# Databricks notebook source
# DBTITLE 1,Global Variables Setup
from pyspark.sql.functions import *
from pyspark.sql.types import * 
from datetime import datetime, timedelta
import requests
import json


env_configs = {
                "dev_external": {
                            "prnt_dir": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating",
                            "ver": "v1",
                            "prefix": "dev_external_",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/mnt/bse-dev/billing_and_rating/dev_external/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/dev_external/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/mnt/bse-dev/billing_and_rating/dev_external/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/dev_external/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/dev_external/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/dev_external/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sitnew",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "sandbox",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "users.madan_gopal.dev_metronome_customers",
                            "invoice_trgt_table": "users.madan_gopal.dev_metronome_invoices",
                            "platform_source_schema": "users.rongduan_zhu",
                            "platform_source_table": "billable_usage",
                            "ondemand_uploads": "users.madan_gopal.ondemand_event_uploads",
                            "uc_catalog": "users",
                            "uc_schema": "madan_gopal"
                  },
                  "dev": {
                            "prnt_dir": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating",
                            "ver": "v1",
                            "prefix": "dev_",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/mnt/bse-dev/billing_and_rating/dev/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/dev/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/mnt/bse-dev/billing_and_rating/dev/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/dev/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating/dev/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/mnt/bse-dev/billing_and_rating/dev/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sitnew",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "sandbox",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "users.madan_gopal.dev_metronome_customers",
                            "invoice_trgt_table": "users.madan_gopal.dev_metronome_invoices",
                            "platform_source_schema": "users.rongduan_zhu",
                            "platform_source_table": "billable_usage",
                            "ondemand_uploads": "users.madan_gopal.ondemand_event_uploads",
                            "uc_catalog": "users",
                            "uc_schema": "madan_gopal"
                  },
                  "sit": {
                            "prnt_dir":  "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol",
                            "ver": "v1",
                            "prefix": "sit_",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sit/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sit/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sit/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sit/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sit/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sit/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sitnew",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "sit",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "users.madan_gopal.metronome_customers", #"integration.it_billing_and_rating.sit_metronome_customers",
                            "invoice_trgt_table": "users.madan_gopal.metronome_invoices", #"integration.it_billing_and_rating.sit_metronome_invoices",
                            "platform_source_schema": "users.rongduan_zhu",
                            "platform_source_table": "billable_usage",
                            "ondemand_uploads": "users.madan_gopal.ondemand_event_uploads",
                            "uc_catalog": "integration",
                            "uc_schema": "it_billing_and_rating"
                  },
                  "uat": {
                            "prnt_dir":  "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol",
                            "ver": "v1",
                            "prefix": "",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sfdcprod",
                            "sfdc_domain": "databricks.my",
                            "output_schema": "bdw_dev",
                            "metronome_env": "uat",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "integration.it_billing_and_rating.uat_metronome_customers",
                            "invoice_trgt_table": "integration.it_billing_and_rating.uat_metronome_invoices",
                            "platform_source_schema": "integration.eng_billable_usage",
                            "platform_source_table": "billable_usage",
                            "ondemand_uploads": "users.madan_gopal.ondemand_event_uploads",
                            "uc_catalog": "integration",
                            "uc_schema": "it_billing_and_rating"
                           
                  },
                  "stg": {
                            "prnt_dir": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol",
                            "ver": "v1",
                            "prefix": "stg_",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/stg/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/stg/usage_events_upload/v3/streaming_job_checkpoint",
                            "fallback_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/stg/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/stg/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/stg/usage_events_upload/v2/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/stg/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "uat2",
                            "sfdc_domain": "test",
                            "output_schema": "bdw_dev",
                            "metronome_env": "stg",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "integration.it_billing_and_rating.stg_metronome_customers", #"integration.it_billing_and_rating.sit_metronome_customers",
                            "invoice_trgt_table": "integration.it_billing_and_rating.stg_metronome_invoices", #"integration.it_billing_and_rating.sit_metronome_invoices",
                            "platform_source_schema": "integration.eng_billable_usage",
                            "platform_source_table": "billable_usage",
                            "ondemand_uploads": "integration.it_billing_and_rating.ondemand_event_uploads",
                            "uc_catalog": "integration",
                            "uc_schema": "it_billing_and_rating"
                  },
                  "prod": {
                            "prnt_dir": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol",
                            "ver": "v1",
                            "prefix": "",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/prod/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/prod/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/prod/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/prod/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/prod/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/prod/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sfdcprod",
                            "sfdc_domain": "databricks.my",
                            "output_schema": "bdw",
                            "metronome_env": "prod",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "main.it_billing_and_rating.metronome_customers",
                            "invoice_trgt_table": "main.it_billing_and_rating.metronome_invoices",
                            "platform_source_schema": "main.eng_billable_usage",
                            "platform_source_table": "billable_usage",
                            "ondemand_uploads": "main.it_billing_and_rating.ondemand_event_uploads",
                            "uc_catalog": "main",
                            "uc_schema": "it_billing_and_rating"
                  },
                  "preprod": {
                            #"prnt_dir": "wasbs://bse-rating-and-billing@dbbusinesssystems1.blob.core.windows.net/billing_and_rating",
                            "prnt_dir": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol",
                            "ver": "v1",
                            "prefix": "preprod_",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/preprod/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/preprod/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/preprod/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/preprod/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/preprod/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/preprod/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sfdcprod",
                            "sfdc_domain": "databricks.my",
                            "output_schema": "bdw_dev",
                            "metronome_env": "sandbox",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "integration.it_billing_and_rating.metronome_customers",
                            "invoice_trgt_table": "integration.it_billing_and_rating.metronome_invoices",
                            "platform_source_schema": "main.eng_billable_usage",
                            "platform_source_table": "billable_usage_preprod",
                            "ondemand_uploads": "integration.it_billing_and_rating.ondemand_event_uploads",
                            "uc_catalog": "integration",
                            "uc_schema": "it_billing_and_rating"
                  },
                  "sox_test": {
                            "prnt_dir": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol",
                            "ver": "v1",
                            "prefix": "",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sox_test/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sox_test/usage_events_upload/v3/streaming_job_checkpoint",
                            "fallback_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sox_test/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sox_test/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sox_test/usage_events_upload/v2/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/Volumes/integration/it_billing_and_rating/np_billing_and_rating_vol/billing_and_rating/sox_test/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sfdcprod",
                            "sfdc_domain": "databricks.my",
                            "output_schema": "bdw_dev",
                            "metronome_env": "prod",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "integration.it_billing_and_rating.metronome_customers", 
                            "invoice_trgt_table": "integration.it_billing_and_rating.metronome_invoices",
                            "platform_source_schema": "eng_billable_usage_central_logfood_prod.eng_billable_usage",
                            "platform_source_table": "billable_usage",
                            "ondemand_uploads": "integration.it_billing_and_rating.ondemand_event_uploads",
                            "uc_catalog": "integration",
                            "uc_schema": "it_billing_and_rating"
                  },
                  "sox_egress": {
                            "prnt_dir": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol",
                            "ver": "v1",
                            "prefix": "",
                            "base_url": "https://api.metronome.com/v1/ingest",
                            "log_dir": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/events_processed",
                            "job_checkpoint_location": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/streaming_job_checkpoint",
                            "fallback_location": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/hold_unsucessfull_events",
                            "app_checkpoint_location": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/app_intrm_checkpoint_location",
                            "batch_job_checkpoint_location": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/batch_job_checkpoint",
                            "batch_app_checkpoint_location": "/Volumes/main/it_billing_and_rating/prod_billing_and_rating_vol/billing_and_rating/uat/usage_events_upload/v1/batch_app_intrm_checkpoint_location",
                            "sfdc_prefix": "sfdcprod",
                            "sfdc_domain": "databricks.my",
                            "output_schema": "bdw",
                            "metronome_env": "uat",
                            "customer_endpoint": "https://api.metronome.com/v1/customers",
                            "cust_trgt_table": "main.it_billing_and_rating.metronome_customers",
                            "invoice_trgt_table": "main.it_billing_and_rating.metronome_invoices",
                            "platform_source_schema": "main.eng_billable_usage",
                            "platform_source_table": "billable_usage_clf",
                            "ondemand_uploads": "main.it_billing_and_rating.ondemand_event_uploads",
                            "uc_catalog": "main",
                            "uc_schema": "it_billing_and_rating"
                  }
}

env_config = env_configs[ENV]

PRT_DIR = f"{env_config['prnt_dir']}/{ENV}"
TBL_VER = env_config["ver"]
TBL_PREFIX = env_config["prefix"]
DLT_TBL_PRT_DIR = f"{PRT_DIR}/tables/{TBL_VER}"
OUTPUT_SCHEMA = env_config["output_schema"]

UC_CATALOG = env_config["uc_catalog"]
UC_SCHEMA = env_config["uc_schema"]

PLATFORM_SRC_SCHEMA = env_config["platform_source_schema"] 
PLATFORM_SRC_TBL_NAME = env_config["platform_source_table"]

SFDC_BS_SRC_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}busniess_sub"
REPROCESSED_USAGE_EVENTS_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}reprocessed_events_batch"
REPROCESSED_USAGE_EVENTS_TBL = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}reprocessed_events_batch"
ONDEMAND_EVENTS_TBL = env_config['ondemand_uploads']

DLT_USAGE_EVENTS_GOLD_TABLE_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}dlt_usage_events_gold"
DLT_HOLD_USAGE_EVENTS_WO_BS_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}dlt_hold_usage_events_without_bs"

DLT_USAGE_EVENTS_GOLD_TABLE = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}dlt_usage_events_gold"
DLT_HOLD_USAGE_EVENTS_WO_BS_TABLE = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}dlt_hold_usage_events_without_bs"

OUTPUT_FALLBACK_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}hold_unsucessfull_events"
OUTPUT_PROCESSED_EVENTS_LOC = f"{DLT_TBL_PRT_DIR}/{TBL_PREFIX}usage_processed_events"

processed_output_table_name = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}usage_processed_events"
hold_unsucessfull_output_table_name = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}hold_unsucessfull_events"
business_sub_tbl = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}dlt_business_subscription"
audit_log_table = f"{UC_CATALOG}.{UC_SCHEMA}.{TBL_PREFIX}metronome_audit_logs"

NUM_OF_PARALLEL_CONECTIONS = 32 #this will be equal to number of taks for each batch; configured for 8workers 3tasks/worker
TRANSACTION_ID_COL = "record_id"
CUSTOMER_ID_ALS = "business_subscription_id"
TIMESTAMP_COL = "usage_invoice_time"
PAYLOAD_COL = "event"
EVENT_TYPE_VALUE = "billable"          #hard coded value 
BACKDATED_DATA_API_LIMIT = 34
PROCESS_DATE_COLUMN_NAME = "process_date"
PROCESS_TIMESTAMP_COLUMN_NAME = "process_timestamp"
UNIQUE_RECORD_ID = "record_id"
MISSING_BS_ID_COL = "missing_bs_id"
MISSING_SFDC_BS_ID_COL = "missing_sfdc_bs_id"

USAGE_TABLE_FIELDS = ['business_subscription_id', 'event_id', 'platform_subscription_id', 'platform_account_id', 'record_id', 'record_type', 'parent_record_id', 'date', 'metering_type', 'usage_amount', 'start_time','end_time', 'event_time', 'workspace_id', 'sku_name', 'list_price', 'paying_status', 'cloud', 'contract_model', 'invoicing_channel', 'add_ons_list_price_rated_amount', 'credits_usage_amount','net_usage_amount', 'usage_time', 'billable_usage_write_time', 'usage_invoice_time']

metronome_event_payload = ['transaction_id', 'timestamp', 'customer_id', 'event_type', 'properties']
properties_map = ['business_subscription_id', 'net_usage_amount', 'sku_name', 'workspace_id', 'cloud', 'add_ons_list_price_rated_amount', 'metering_type']


# COMMAND ----------

# DBTITLE 1,Setup env variables
## Retrive Metronome API Key from the DB secrets 
def retrive_metronome_api_token(env = "sandbox"):
  return dbutils.secrets.get(scope = "bse-metronome", key = f"metronome_api_key_{env}") 

def set_config(env):
  """ sets config for an environment """
  scope = "bse-metronome"
  sas_container = "fs.azure.sas.bse-rating-and-billing.dbbusinesssystems1.blob.core.windows.net"
  spark.conf.set(sas_container, dbutils.secrets.get(scope,"bse-rating-and-billing-access-key"))
  print(scope)
  print(sas_container)


set_config(ENV)

#set the enviornment through pipelibe parms
metronome_env = env_config["metronome_env"]
api_key = retrive_metronome_api_token(metronome_env)
print(DLT_TBL_PRT_DIR)
dbutils.fs.mkdirs(DLT_TBL_PRT_DIR)
dbutils.fs.mkdirs(env_config['log_dir'])
dbutils.fs.mkdirs(env_config['job_checkpoint_location'])
dbutils.fs.mkdirs(env_config['fallback_location'])
dbutils.fs.mkdirs(env_config['app_checkpoint_location'])
dbutils.fs.mkdirs(env_config['batch_job_checkpoint_location'])
dbutils.fs.mkdirs(env_config['batch_app_checkpoint_location'])

# COMMAND ----------

# DBTITLE 1,Map Functions
# this function depreciated and replaced with the SQL function on 1/29 as part of UC migration
@udf(returnType=MapType(StringType(), StringType()))
def build_properties(business_subscription_id, net_usage_amount, sku, workspace_id, cloud, add_ons, metering_type):
  """ returns a map of strings for a given event-id """
  properties_map = {
    'business_subscription_id' : business_subscription_id,
    'quantity' : net_usage_amount,
    'sku' : sku,
    'workspace_id' : workspace_id,
    'cloud' : cloud,
    'metering_type' : metering_type
  }

  metronome_addons = {}
  if add_ons and len(add_ons) > 0:
    for add_on in add_ons:
      if add_on:
        add_on_sku = add_on['add_on_sku_name']
        add_on_amt = add_on['rated_amount']
        metronome_addons.update({add_on_sku: add_on_amt})

  properties_map.update(metronome_addons)
  return properties_map

@udf('string')
def convert_rfc_3339(timestamp):
  """ RFC timestmap """
  return timestamp[:10]+"T"+timestamp[11:19]+"Z"  

# COMMAND ----------

# DBTITLE 1,Streaming Functions
## Function to prepare the usage events and send to metronome ingest REST API - This function executs on each worker node/each underlying partition
## Little overhead in terms of serialization/de-serialization python function however required to intract with metronome REST API interface
## Writing logs at env_config['log_dir'] at a unique json file; 
## Failed events (due to issue in payload) are stored as a json file at env_config['fallback_location']; this may changed to a messaging queuing approach in future
## The unique transaction_id (recordid) in each event prevents duplicate processing at metronome side, so retries are always safe - https://docs.metronome.com/getting-usage-data-into-metronome/overview/#queue-and-retry


class SendToMetronome:
  import time as tm
  import os as os
  import concurrent.futures as futures

  def __init__(self, reprocessing = False):
    self.reprocessing = reprocessing
    if reprocessing:
      self.app_checkpoint_location = f"{env_config['batch_app_checkpoint_location']}"
    else:
      self.app_checkpoint_location = f"{env_config['app_checkpoint_location']}"

  paritionid = epochid = None
  json_data_list = [] 
  transaction_id_list = [] 
  events = []
  processed_events = {}
  token = api_key
  metronome_base_url = env_config['base_url']
  log_dir = f"{env_config['log_dir']}"
  fallback_location = f"{env_config['fallback_location']}"
  metronome_batch_size = 100 ##Sending 100 records/events in each bacth - max 100 can be sent
  HTTPS_200_STATUS_CODE = 200
  HTTPS_400_STATUS_CODE = 400
  HTTPS_500_STATUS_CODE = 500
  CONCURRENT_REQUESTS_IN_BATCH = 5     #Increasing the number of thread to higher number may cause lot of switching overhead on workers
  PAYLOAD_COL_NAME = PAYLOAD_COL
  EVENT_UNIQUE_ID_COL_NAME = TRANSACTION_ID_COL

  def reset_lists(self):
    self.json_data_list = []
    self.transaction_id_list = []
    self.events = []

  def get_unique_file_name(self):
    current_ts = self.tm.time_ns()
    return f"{self.epoch_id}_{self.parition_id}_{current_ts}"

  def create_directory(self, dir_path):
    if not self.os.path.exists(dir_path):
      try:
        self.os.mkdir(dir_path)
      except FileExistsError as e:
        print("directory exists")

  def dump_json_data(self, file_name, json_data):
    count = 0
    retry_attempts = 3
    while True: 
      try:
        with open(file_name, 'w', encoding = 'utf-8') as f:           #disk IO
          json.dump(json_data, f, ensure_ascii = False)
        return 0
      except Exception as e:
        if count < retry_attempts:
          count = count + 1   
        else:
          raise e

  def load_json_data(self, file_name):
    count = 0
    retry_attempts = 3
    while True: 
      try:
        with open(file_name, 'r', encoding = 'utf-8') as f:                 #disk IO
          return json.load(f)   
      except FileNotFoundError as e:
        return {}
      except Exception as e:
        if count < retry_attempts:
          count = count + 1   
        else:
          raise e

  def write_data_to_disk(self, parent_dir, json_data):
    today_str = datetime.utcnow().strftime('%Y%m%d')
    directory_name = f"{parent_dir}/{today_str}"
    log_file_name = f"{directory_name}/{self.get_unique_file_name()}.json"
    self.create_directory(directory_name) 
    self.dump_json_data(log_file_name, json_data)

  def write_processed_events(self, parent_dir, processed_events):
    file_name = f"{parent_dir}/{self.epoch_id}_{self.parition_id}.json"
    self.dump_json_data(file_name, processed_events)

  def loads_processed_events(self, parent_dir):
    checkpoint_file_name = f"{parent_dir}/{self.epoch_id}_{self.parition_id}.json"   
    try:     
      self.processed_events = self.load_json_data(checkpoint_file_name)
    except Exception as e:
      self.processed_events = {}

  def upload_events_to_metronome(self, json_data):
    count = 0
    retry_attempts = 3
    while True:
        try:
            response = requests.post(
              self.metronome_base_url,
                headers = {
                    "Authorization": f"Bearer {self.token}",
                },
                json = json_data,
                timeout = 10
            )
            return response
        except Exception as e:
            if count < retry_attempts:
              count = count + 1   
              self.tm.sleep(2) #wait for 2sec before retry. NOTE: ONLY CURRENT TASK WILL BE PAUSED NO IMPACT ON OTHER PARITIONS/TASKS 
            else:
              raise e

  ## This function will be called for the failed batch as a fallback option (400 status code) 
  ## so it can deliver as many as events as possble from the batch 1 or 10 in each call;      
  def process_event(self, event_dict_list):     
    count = 0
    retry_attempts = 3 
    transaction_id_list = [event_dict[self.EVENT_UNIQUE_ID_COL_NAME] for event_dict in event_dict_list]
    event_list = [event_dict[self.PAYLOAD_COL_NAME] for event_dict in event_dict_list]
  
    while True:    
        response = self.upload_events_to_metronome(event_list)
        api_response = {  
                          "json": response.json(), 
                          "status_code": f"{response.status_code}"
                        }  
        log_data = {      
                      "request_timestamp" : f"{datetime.utcnow()}",
                      "response" : api_response,
                      "transactions": transaction_id_list,
                      "parition_id" : self.parition_id,
                      "epoch_id" : self.epoch_id
                    }

        self.write_data_to_disk(self.log_dir, log_data)  
      
        if int(response.status_code) == self.HTTPS_200_STATUS_CODE:        #event sucessfully delivered to metronome
            self.processed_events.update(dict.fromkeys(transaction_id_list, self.HTTPS_200_STATUS_CODE))
            return 0     
        elif int(response.status_code) >= self.HTTPS_500_STATUS_CODE:        #encountered an network issue; retry logic
            #seems like a network issue hence re-trying
            if count < retry_attempts:
              count = count + 1   
            else:
              raise Exception(f'{self.HTTPS_500_STATUS_CODE} error.. after retry_attempts are completed.. Stopping Streaming Job. Please check the logs...')  
        elif int(response.status_code) >= self.HTTPS_400_STATUS_CODE:   #issue with the payload hence writing it to a fallback/dead-letter location to reprocess sepratelly
            self.write_data_to_disk(self.fallback_location, {"transactions_ids" : transaction_id_list})  #writing failed records to fallback/parked location
            return 0   #ending the loop; can't retry in case of payload issue; may need manual intervantion
        else:
            raise Exception("Unknown Error Stopping Streaming Job. Please check the logs...")            

  ## processing each event from batch parallelly
  def process_events_parallelly(self, events_batch):
    def chunks(lst, n):
      for i in range(0, len(lst), n):
          yield lst[i : i + n]

    workers = self.CONCURRENT_REQUESTS_IN_BATCH

    if self.reprocessing:
      batches = list(chunks(events_batch, 1))   #upload one event in each call in case of reprocessing 
    else:
      batches = list(chunks(events_batch, 10))   #upload ten events in each call
      
    with self.futures.ThreadPoolExecutor(max_workers = workers) as executor:
      try:
        for task in executor.map(self.process_event, batches):
          print(task)
      except Exception as e:
        raise e

              
  ## This function will be called for the batch (based on the batch size <= 100) and try to deliver it in a single call
  def process_events_in_batches(self):
    count = 0
    retry_attempts = 30  #retry until 30 * 5 = 150 secs
    
    while True:    
        response = self.upload_events_to_metronome(self.json_data_list)

        api_response = {  
                          "json": response.json(), 
                          "status_code": f"{response.status_code}"
                        }  
        log_data = {      
                      "request_timestamp" : f"{datetime.utcnow()}",
                      "response" : api_response,
                      "transactions": self.transaction_id_list,
                      "parition_id" : self.parition_id,
                      "epoch_id" : self.epoch_id
                    }
        
        #writing to log file, will replace to logging framework
        self.write_data_to_disk(self.log_dir, log_data)  
      
        if int(response.status_code) == self.HTTPS_200_STATUS_CODE:        #event sucessfully delivered to metronome
            self.processed_events.update(dict.fromkeys(self.transaction_id_list, self.HTTPS_200_STATUS_CODE))
            return 0      
        elif int(response.status_code) >= self.HTTPS_500_STATUS_CODE:        #encountered an network issue; retry logic
            #seems like a network issue hence re-trying
            if count < retry_attempts:
              count = count + 1   
              self.tm.sleep(5) #wait for 5 secs before making another attempt. NOTE: ONLY CURRENT TASK WILL BE PAUSED NO IMPACT ON OTHER PARITIONS/TASKS 
            else:
              raise Exception(f'{self.HTTPS_500_STATUS_CODE} error.. after retry_attempts are completed.. Stopping Streaming Job. Please check the logs...')  
        elif int(response.status_code) >= self.HTTPS_400_STATUS_CODE:   #issue with the payload in one of the event from batch
            try:
              json_msg = response.json()
            except Exception as e:
              self.write_data_to_disk(self.fallback_location, {"transactions_ids" : self.transaction_id_list})  
              return 0

            if json_msg and json_msg.get('message', 'null') == "Unauthorized":
              raise Exception("Unauthorized.. Please verify the API Key and the Permissions...")

            self.process_events_parallelly(self.events)   #Fallback to process each event in a separat call parallelly 
            return 0    
        else:
            raise Exception("Unknown Error Stopping Streaming Job. Please check the logs...")

  def open(self, partition_id, epoch_id):
    self.parition_id = partition_id
    self.epoch_id = epoch_id
    self.loads_processed_events(self.app_checkpoint_location)
    return True

  def process(self, row):
    if row[self.EVENT_UNIQUE_ID_COL_NAME] in self.processed_events:
      print(f"event is already processed: {row[self.EVENT_UNIQUE_ID_COL_NAME]}")
    else:
      self.json_data_list.append(json.loads(row[self.PAYLOAD_COL_NAME]))
      self.transaction_id_list.append(row[self.EVENT_UNIQUE_ID_COL_NAME])
      self.events.append({self.EVENT_UNIQUE_ID_COL_NAME: row[self.EVENT_UNIQUE_ID_COL_NAME], self.PAYLOAD_COL_NAME: json.loads(row[self.PAYLOAD_COL_NAME])})

      if len(self.json_data_list) >= self.metronome_batch_size:
        try:
          self.process_events_in_batches()
          self.write_processed_events(self.app_checkpoint_location, self.processed_events)
          self.reset_lists()
        except Exception as e:
          raise e    

  def close(self, err):
    # This is called after all the rows have been processed.
    if err:
      raise err
    else:
      if len(self.json_data_list) > 0:
        try:
          self.process_events_in_batches()
          self.write_processed_events(self.app_checkpoint_location, self.processed_events)
          self.reset_lists()
        except Exception as e:
          raise e


# COMMAND ----------

# DBTITLE 1,Salesforce Query Functions
def get_creds(prefix):
  """
  params:
         prefix - 'uat' for uat, 'lfsf' for prod
  returns:
         list of user_name, password, security_token
  """
  username = dbutils.secrets.get('api-creds', prefix+'_username')
  password = dbutils.secrets.get('api-creds', prefix+'_password')
  security_token = dbutils.secrets.get('api-creds', prefix+'_security_token')
  return [username, password, security_token]


def get_sfdc_connection(creds, domain):
  """
  params:
         creds - connection credentials
         domain - 'test' for uat, 'databricks.my' for prod
  returns:
         sfdc connection object
  """
  return Salesforce(username=creds[0], \
                    password=creds[1], \
                    security_token=creds[2], \
                    domain=domain)


def get_dataframe(query, environement_prefix, domain):

    """
    calls get_creds, get_sfdc_connection functions
    uses salesforce's soql query api 
    params: query, environement_prefix, domain
    returns: pandas dataframe
    """
  
    creds = get_creds(environement_prefix)
    sf = get_sfdc_connection(creds, domain)
    
    list_data_records = []
    data = sf.query(query)
    list_data_records = data['records']
    prev_counter = 0
    cur_counter = 0
    while 'nextRecordsUrl' in data.keys():
        next_record = data['nextRecordsUrl'].split('/')[-1]
        data = sf.query_more(next_record)
        list_data_records += data['records']
        if cur_counter-prev_counter >= 50000:
          prev_counter = cur_counter
          sf = get_sfdc_connection(creds, domain) # connection reset
        cur_counter = len(list_data_records)
    return pd.DataFrame(list_data_records).drop(columns='attributes')
  
  
import numpy as np
import pandas as pd
from pyspark.sql.types import *
pandas_spark_types_map = {
                    np.int8: ByteType(),
                    np.uint8: ShortType(),
                    np.int16: ShortType(),
                    np.uint16: IntegerType(),
                    np.int32: IntegerType(),
                    np.int64: LongType(),
                    np.float32: FloatType(),
                    np.float64: DoubleType(),
                    np.string_: StringType(),
                    np.str_: StringType(),
                    np.unicode_: StringType(),
                    np.bool_: BooleanType(),
                    np.object_: StringType()
                }

def build_spark_schema(numpy_dtypes):
    """
    takes pandas dtypes and converts to Spark Schema
    parms: numpy_dtypes, pandas_spark_types_map
    returns: Pyspark Schema
    """
    return StructType([StructField(col_name, pandas_spark_types_map[col_type.type], True) for col_name, col_type in numpy_dtypes.iteritems()])

# COMMAND ----------

# DBTITLE 1,Extract metronome data
import time
def call_metronome_rest_api(rest_api_endpoint, params):
  count = 0
  retry_attempts = 10
  while True:
    try:
        response = requests.get(
                          rest_api_endpoint,
                          params = params,
                          headers = {
                              "Authorization": f"Bearer {api_key}",
                          },
                          timeout = 30
                      )
        data = response.json()['data'] if "data" in response.json() else []
        print(f"{datetime.utcnow()}: {rest_api_endpoint}: {response}: {len(data)}")
        if int(response.status_code) != 200:
          raise Exception("retrying")
        return response
    except Exception as e:
        if count < retry_attempts:
          count = count + 1   
          time.sleep(1.5 ** count)
          print(f"{datetime.utcnow()}: {rest_api_endpoint}: retry {count}")
        else:
          raise e


def extract_data(rest_api_endpoint, **kwargs):
    record_limit = 100
    params = {"limit" : record_limit}

    if "invoice_starting_on" in kwargs:
      params["starting_on"] = kwargs["invoice_starting_on"]
      params["limit"] = 4
    
    if "invoice_ending_before" in kwargs:
      params["ending_before"] = kwargs["invoice_ending_before"]

    response = call_metronome_rest_api(rest_api_endpoint, params)
    json_data = response.json()
    next_page = json_data["next_page"] if "next_page" in json_data else None
    data = json_data['data'] if "data" in json_data else []

    while next_page:
        params.update({"next_page" : next_page})
        response = call_metronome_rest_api(rest_api_endpoint, params)
        json_data = response.json()
        data += json_data['data']  if "data" in json_data else []
        next_page = json_data["next_page"] if "next_page" in json_data else None

    return data


# COMMAND ----------

import requests
import json

@udf(returnType=MapType(StringType(), StringType()))
def send_to_metronome_on_demand(payload):
  metronome_base_url = env_config['base_url']
  token = api_key
  count = 0
  retry_attempts = 3
  json_payload = [json.loads(payload)]
  while True:
      try:
          response = requests.post(
            metronome_base_url,
              headers = {
                  "Authorization": f"Bearer {token}",
              },
              json = json_payload,
              timeout = 30
          )
          api_response = {  
                        "json": response.json(), 
                        "status_code": f"{response.status_code}"
                      }  
          return api_response
      except Exception as e:
          if count < retry_attempts:
            count = count + 1   
          else:
            raise e
  return api_response
