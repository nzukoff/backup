# Databricks notebook source
# DBTITLE 1,Set Metronome Customer ids separated by "," and Env
ENV = "prod"

cust_ids = [
'e65414aa-17ff-463b-8b13-4408ce84e286'
]

# COMMAND ----------

# DBTITLE 1,Setting pipeline variables
load_type = "Daily"

is_full_load = False
if load_type == "Full":
  is_full_load = True

try:
  invoices_since_num_days = dbutils.widgets.get("invoices_since_num_days") #Extract and update invoices where start date > 35 days 
except Exception:
  invoices_since_num_days = 40

# COMMAND ----------

#main.it_billing_and_rating.metronome_customers

# COMMAND ----------

# MAGIC %run ./utils/defs_and_helper_functions

# COMMAND ----------

from datetime import date, timedelta, datetime
from pytz import timezone

customers_api_endpoint = env_config["customer_endpoint"]
customers_trgt_tbl = env_config["cust_trgt_table"]
customers_invoices_trgt_tbl = env_config["invoice_trgt_table"]
print(customers_invoices_trgt_tbl)

date = (datetime.now(timezone('America/Los_Angeles')) - timedelta(days = invoices_since_num_days)).strftime('%Y-%m-%d')

#if is_full_load or not spark.catalog.tableExists(customers_invoices_trgt_tbl):
if is_full_load:
  invoice_starting_on = f"2023-03-01T00:00:00+00:00"
else:
  invoice_starting_on =  f"{date}T00:00:00+00:00"
#invoice_ending_before = ""

print(f"Loading invoice_starting_on: {invoice_starting_on}")

# COMMAND ----------


customers_schema = StructType([
                                StructField("name", StringType(), True),
                                StructField("id", StringType(), True),
                                StructField("customer_config", MapType(StringType(), StringType()), True),
                                StructField("external_id", StringType(), True),
                                StructField("ingest_aliases", ArrayType(StringType()), True),
                                StructField("custom_fields", MapType(StringType(), StringType(), True), True)
                              ]
                            )

line_items = ArrayType(StructType([

          StructField("name", StringType(), True),
          StructField("group_key", StringType(), True),
          StructField("group_value", StringType(), True),
          StructField("quantity", StringType(), True),
          StructField("total", StringType(), True),
          StructField("product_id", StringType(), True),
          StructField("credit_type", MapType(StringType(), StringType()), True),
          StructField("sub_line_items", ArrayType(
            StructType([
              StructField("name", StringType(), True),
              StructField("price", StringType(), True),
              StructField("charge_id", StringType(), True),
              StructField("quantity", StringType(), True),
              StructField("subtotal", StringType(), True),
              StructField("tiers", ArrayType(MapType(StringType(), StringType())), True),
              StructField("custom_fields", MapType(StringType(), StringType()), True)
            ]))),
          StructField("custom_fields", MapType(StringType(), StringType()), True)
]))

invoice_schema = StructType([
                                StructField("customer_id", StringType(), True),
                                StructField("id", StringType(), True),
                                StructField("credit_type", StringType(), True),
                                StructField("invoice_adjustments", StringType(), True),
                                StructField("plan_id", StringType(), True),
                                StructField("plan_name", StringType(), True),
                                StructField("line_items", line_items, True),
                                StructField("status", StringType(), True),
                                StructField("external_invoice", StringType(), True),
                                StructField("start_timestamp", StringType(), True),
                                StructField("end_timestamp", StringType(), True),
                                StructField("total", StringType(), True),
                                StructField("subtotal", StringType(), True)
                              ]
                            ) 

# COMMAND ----------

all_cust_invoices_raw = []
for cust in cust_ids:
  metronome_cust_id = cust
  metronome_invoice_api = f"{customers_api_endpoint}/{metronome_cust_id}/invoices"
  print(metronome_invoice_api)
  cust_invoices = extract_data(metronome_invoice_api, invoice_starting_on = invoice_starting_on)
  all_cust_invoices_raw += cust_invoices
cust_invoices_df = spark.createDataFrame(all_cust_invoices_raw, invoice_schema)
cust_invoices_df.printSchema()

# COMMAND ----------

display(cust_invoices_df)

# COMMAND ----------

print(f"ingesting customer invoices data to {customers_invoices_trgt_tbl}")

cust_invoices_df.withColumn("process_timestamp", lit(current_timestamp())).createOrReplaceTempView("cust_invoices")

#if is_full_load or not spark.catalog.tableExists(customers_invoices_trgt_tbl):
if is_full_load :
  print(f"Creating table: {customers_invoices_trgt_tbl}")
  cust_invoices_df.withColumn("process_timestamp", lit(current_timestamp()))\
                  .write\
                  .partitionBy("start_timestamp")\
                  .mode("overwrite")\
                  .option('overwriteSchema', 'true')\
                  .saveAsTable(customers_invoices_trgt_tbl)
else:
  print(f"Merging into: {customers_invoices_trgt_tbl}")
  merge_query = f"""MERGE INTO {customers_invoices_trgt_tbl}
                    USING cust_invoices
                    ON {customers_invoices_trgt_tbl}.id = cust_invoices.id
                    AND {customers_invoices_trgt_tbl}.start_timestamp = cust_invoices.start_timestamp
                    WHEN MATCHED THEN UPDATE SET *
                    WHEN NOT MATCHED THEN INSERT *
                  """
  print(merge_query)
  display(spark.sql(merge_query))

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC desc main.it_billing_and_rating.metronome_invoices 
# MAGIC
