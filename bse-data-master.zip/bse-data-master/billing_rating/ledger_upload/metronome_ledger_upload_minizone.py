# Databricks notebook source
# DBTITLE 0,Read Me
# MAGIC %md
# MAGIC ## uploads usage events in the following steps
# MAGIC - upload a csv file into DB in a table, make sure the schema of the table is correct
# MAGIC - run the notebook/job

# COMMAND ----------

dbutils.widgets.dropdown("environment", "dev", ['prod','dev','uat','stg','sit','preprod','dev_external'])
try:
  ENV = dbutils.widgets.get("env")
except:
  ENV = dbutils.widgets.get("environment")

ENV_Ledger = 'prod' if ENV == "prod" else 'dev'
print(ENV_Ledger)
print(ENV)

# COMMAND ----------

# #ledger
# ENV = dbutils.widgets.get("env")
# #ENV = 'uat'
# ENV_Ledger = 'prod' if ENV == "prod" else 'dev'
# print(ENV_Ledger)

# COMMAND ----------

# MAGIC
# MAGIC %run ./defs_and_helper_functions_minizone

# COMMAND ----------

# MAGIC %run ./metronome_ledger_entry_config
# MAGIC

# COMMAND ----------

print(catalog_nm)

# COMMAND ----------


#SOURCE_TBL_NAME = dbutils.widgets.get("source_table") #'users.madan_gopal.manual_upload_usage_events'
SOURCE_TBL_NAME = f'{catalog_nm}.{tgt_db_nm}.metronome_ledger_entry_upload' 
print(f"ENV: {ENV}. Source Table: {SOURCE_TBL_NAME}")
TARGET_EVENT_RESPONSE_TBL = f'{catalog_nm}.{tgt_db_nm}.ledger_ondemand_events_upload'
print(TARGET_EVENT_RESPONSE_TBL)



# COMMAND ----------

spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")


# COMMAND ----------

print(catalog_nm)

# COMMAND ----------


file_data = spark.sql ( f'''

select concat( commit_id, '-',row_number() over (partition by commit_id order by amount)) as commit_id_seq , 
commit_id,
amount,
reason,
adjustment_type,
date,
jira_ticket,
username,
fname,
balance_date,
process_date

 from {catalog_nm}.{tgt_db_nm}.metronome_ledger_entry_upload''')

file_data.createOrReplaceTempView('file_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from file_data

# COMMAND ----------

file_data_with_customer_id = spark.sql(f'''
SELECT 
     fd.commit_id_seq ,
     fd.commit_id,
     fd.amount,
     SUM(fd.amount) OVER(PARTITION BY fd.commit_id) commit_file_total_amount ,
     fd.reason,
     fd.adjustment_type,
     to_date(fd.date, 'MM/dd/yy') date,
     --fd.date,
     fd.jira_ticket,
     fd.username,
     fd.fname,
     to_date(balance_date, 'MM/dd/yy') as balance_date,
     --fd.balance_date,
     fd.process_date ,
     cmt.name commit_name,
     cmt.contract_id,
     cmt.access_schedule ,
     cntrct.customer_id,
     cntrct.metadata['salesforce_opportunity_id']  salesforce_opportunity_id,
     cs.name as customer_name, 
     cmt.total_commit egress_total_commit,
     cmt.remaining_balance egress_remaining_balance

FROM file_data  fd  
LEFT JOIN {catalog_nm}.{tgt_db_nm}.contracts_commits_silver cmt
ON fd.commit_id = cmt.id
LEFT JOIN {catalog_nm}.{tgt_db_nm}.contracts_contracts_silver cntrct
ON cmt.contract_id = cntrct.id
LEFT JOIN {catalog_nm}.it_billing_and_rating.customer_silver cs 
on cntrct.customer_id = cs.id ''')


file_data_with_customer_id.createOrReplaceTempView('file_data_with_customer_id')



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from file_data_with_customer_id

# COMMAND ----------

# file_data_with_customer_id_and_amounts = file_data_with_customer_id.withColumn("amounts", process_row(col("customer_id"), col("commit_id")))

# display(file_data_with_customer_id_and_amounts)

# # Split the struct column into separate columns
# file_data_with_customer_id_and_amounts = file_data_with_customer_id_and_amounts.select(
#     "*",
#     col("amounts.total_amount").alias("api_remaining_balance"),
#     col("amounts.starting_balance").alias("api_total_commit_at_start"),
#     col("amounts.message").alias("message")
# ).drop("amounts")

# # Show results
# # df_with_amounts.show(truncate=False)
# #display(df_with_amounts)

# file_data_with_customer_id_and_amounts.createOrReplaceTempView('file_data_with_customer_id_and_amounts')

# COMMAND ----------

file_data_with_customer_id_and_amounts = file_data_with_customer_id.withColumn("amounts", fetch_and_sum_ledger_amounts(col("customer_id"), col("commit_id"),col("balance_date")))

display(file_data_with_customer_id_and_amounts)

# Split the struct column into separate columns
file_data_with_customer_id_and_amounts = file_data_with_customer_id_and_amounts.select(
    "*",
    col("amounts.total_amount").alias("api_remaining_balance"),
    col("amounts.starting_balance").alias("api_total_commit_at_start"),
    col("amounts.message").alias("message")
).drop("amounts")

# Show results
# df_with_amounts.show(truncate=False)
#display(df_with_amounts)

file_data_with_customer_id_and_amounts.createOrReplaceTempView('file_data_with_customer_id_and_amounts')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * From file_data_with_customer_id_and_amounts

# COMMAND ----------

#ledger
source_df_pre = spark.sql(f'''
SELECT 
       commit_name , --remove this for debug
       '{ENV}' as env,
       username,
       fname,
       trim(commit_id_seq|| '|' ||
       access_schedule.schedule_items[0].id 
       || '|' || to_date(date, 'MM/dd/yy') 
       || '|' || current_date) as transaction_id,
       customer_id,
       salesforce_opportunity_id,
       customer_name as customer_name,
       contract_id, 
       commit_id as id,
       trim(get_json_object(to_json(access_schedule), '$.schedule_items[0].id')) as segment_id,
       amount * 100 amount, --converting to cents since metronome stores everything as cents in table 
       commit_file_total_amount* 100 commit_file_total_amount,  --converting to cents since metronome stores everything as cents in table  , 
       reason || ' | ' || adjustment_type || ' | ' || date || ' | ' || jira_ticket || ' | ' || username as reason,
    --   date,
    --    balance_date,
    --  to_date(balance_date, 'MM/dd/yy') to_Date_balance,
    --  to_date(date, 'MM/dd/yy') to_date_date,
      -- cast(to_date(date, 'MM/dd/yy') as timestamp) as timestamp,
     --  cast(to_date(balance_date, 'MM/dd/yy') as timestamp) as balance_date,
       cast(date as timestamp) as timestamp,
       balance_date as balance_date,
       api_total_commit_at_start total_commit,
       api_remaining_balance remaining_balance,
       adjustment_type,
       CASE WHEN trim(get_json_object(split(message, ' - ')[1], '$.message')) LIKE '%is not a valid UUID%' 
        THEN 'Invalid Commit Id - Please check and Fix'
        WHEN trim(get_json_object(split(message, ' - ')[1], '$.message')) = 'The specified customer was not found'
           then 'Invalid customer id - Please check and Fix' 
        WHEN message != ''  then  message 

           WHEN commit_id is null THEN 'Invalid Commit Id - Please check and Fix'
           WHEN amount is null or amount = 0 THEN 'amount value is null or zero'
           WHEN adjustment_type is null THEN 'adjustment type is null'
           WHEN commit_id is null THEN 'commit id is null'
           WHEN username is null THEN 'username is null'
           WHEN date is null THEN 'date is null'
           WHEN  commit_file_total_amount * 100 + api_remaining_balance > api_total_commit_at_start and commit_file_total_amount * 100 > 0 THEN 'Commit Bucket Exceeded for the total commit dollars in file'
           WHEN commit_file_total_amount * 100  + api_remaining_balance < 0 and commit_file_total_amount * 100 < 0 THEN 'Not enough commit balance to adjust for the total commit dollars in file'
           WHEN lower(trim(coalesce( adjustment_type, 'xyz'))) not like '%ledger out%'
                and lower(trim(coalesce(adjustment_type, 'xyz'))) not like '%reinstate balance%'
                and lower(trim(coalesce(adjustment_type, 'xyz'))) not like '%usage adjustment%'
                and lower(trim(coalesce(adjustment_type, 'xyz'))) not like '%flex azure usage adjustment%'
                and lower(trim(coalesce(adjustment_type, 'xyz'))) not like '%support supersede fix%'
                and lower(trim(coalesce(adjustment_type, 'xyz'))) not like '%product swap%'
                and lower(trim(coalesce(adjustment_type, 'xyz'))) not like '%mc support azure usage adjustment%'
                and lower(trim(coalesce(adjustment_type, 'xyz'))) not like '%ledger out: azure deferred true-up%'
                THEN 'Invalid adjustment type - Please check'
           WHEN lower(trim(coalesce(adjustment_type, 'xyz'))) like '%flex azure usage adjustment%' and lower(trim(coalesce(commit_name, ''))) not like '%flex%' THEN 'Invalid adjustment type - Flex adjustment for a non flex commit'
           ELSE 'Ledger entry is valid'
       END as Exception_Status
FROM file_data_with_customer_id_and_amounts fd


''')

source_df_pre.createOrReplaceTempView('source_df_pre')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from source_df_pre

# COMMAND ----------

source_df_valid = spark.sql('''select *  from source_df_pre where Exception_Status = 'Ledger entry is valid' ''')

# COMMAND ----------

display(source_df_valid)

# COMMAND ----------

#ledger
ledger_events_processed = source_df_valid.withColumn(PAYLOAD_COL,to_json(struct([field for field in ledger_event_payload])))
ledger_events_processed.createOrReplaceTempView('ledger_events_processed')


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ledger_events_processed

# COMMAND ----------

#ledger
ledger_events_processed_to_upload = spark.sql('''select transaction_id,event from ledger_events_processed''')

# COMMAND ----------

display(ledger_events_processed_to_upload)

# COMMAND ----------

# MAGIC %md
# MAGIC // Add a manual ledger entry to a balance
# MAGIC {
# MAGIC   // ID of the customer whose balance is to be updated.
# MAGIC   "customer_id": UUID, // (required)
# MAGIC
# MAGIC   // ID of the contract to update. Leave blank to update a customer level
# MAGIC   // balance.
# MAGIC   "contract_id": UUID,
# MAGIC
# MAGIC   // ID of the balance (commit or credit) to update.
# MAGIC   "id": UUID, // (required)
# MAGIC
# MAGIC   // ID of the segment to update.
# MAGIC   "segment_id": UUID, // (required)
# MAGIC
# MAGIC   // Amount to add to the segment. A negative number will draw down from the
# MAGIC   // balance.
# MAGIC   "amount": number, // (required)
# MAGIC
# MAGIC   // Reason for the manual adjustment. This will be displayed in the ledger.
# MAGIC   "reason": string, // (required)
# MAGIC
# MAGIC   // RFC 3339 timestamp indicating when the manual adjustment takes place. If
# MAGIC   // not provided, it will default to the start of the segment.
# MAGIC   "timestamp": datetime // RFC 3339
# MAGIC }

# COMMAND ----------

# MAGIC %md
# MAGIC {"customer_id":"f271500f-752f-4249-915d-060279de5ce0",
# MAGIC "contract_id":"6cdd997d-525a-419d-8c0f-ce10535433a6",
# MAGIC "id":"fb5826f2-8b00-42db-a7b5-69ca677a81da",
# MAGIC "segment_id":"1a5861d7-5533-4580-a32e-711dfdba3d49",
# MAGIC "amount":1000,
# MAGIC "Reason":"Missing or additional Usage in Metronome::3456-sample::sachin.khurana",
# MAGIC "timestamp":"2024-03-02T00:00:00.000Z"}

# COMMAND ----------

print(PAYLOAD_COL)

# COMMAND ----------

print (TARGET_EVENT_RESPONSE_TBL)

# COMMAND ----------

from pyspark.sql.functions import lit, current_date, current_timestamp

# Process ledger events
ledger_events_processed_to_upload = ledger_events_processed_to_upload.withColumn(
    'metronome_response', send_to_metronome_on_demand(PAYLOAD_COL)
)

# Create a temporary view for SQL operations
ledger_events_processed_to_upload.createOrReplaceTempView('ledger_events_processed_to_upload_view')

# SQL query to join and select required fields
events_table = spark.sql('''
    SELECT 
        sdp.transaction_id,
        sdp.customer_id,
        sdp.customer_name,
        sdp.salesforce_opportunity_id, 
        sdp.contract_id,
        sdp.id AS commit_id,
        sdp.segment_id,
        sdp.reason,
        sdp.adjustment_type, 
        sdp.amount,
        sdp.total_commit,
        sdp.remaining_balance,
        sdp.exception_status,
        le.event,
        le.metronome_response,
        env,
        username,
        fname,
        CASE 
            WHEN sdp.exception_status <> 'Ledger entry is valid' THEN 'Not Processsed - Check Exception Status'
            WHEN le.metronome_response.status_code != '200' THEN 'Not Processed- Check Metronome API response - Reach out to IT Team'
            WHEN le.metronome_response.status_code = '200' THEN 'Processed to Metronome'
            ELSE 'unknown-further check' 
        END AS processing_status,
        sdp.commit_file_total_amount,
        sdp.commit_name
    FROM source_df_pre sdp
    LEFT JOIN ledger_events_processed_to_upload_view le
    ON sdp.transaction_id = le.transaction_id
''')

# Create a temporary view for the events table
events_table.createOrReplaceTempView('events_table')
# Add process_date and process_timestamp columns and write to the target table
events_table.withColumn("process_date", lit(current_date())) \
            .withColumn("process_timestamp", lit(current_timestamp())) \
            .write \
            .partitionBy("process_date") \
            .mode("append") \
            .saveAsTable(TARGET_EVENT_RESPONSE_TBL)

# COMMAND ----------

print(TARGET_EVENT_RESPONSE_TBL) 

# COMMAND ----------

# %sql
# drop  table integration.it_billing_and_rating.ledger_ondemand_events_upload 
# --as select * From integration.it_billing_and_rating.ledger_ondemand_events_upload 


# COMMAND ----------

# MAGIC %sql
# MAGIC select * From main.it_billing_and_rating.ledger_ondemand_events_upload order by process_timestamp desc

# COMMAND ----------

# DBTITLE 1,Records not Uploaded
# #verification
# failed_events = ledger_events_processed_to_upload.where("metronome_response.status_code != '200'")

# if failed_events.count() > 0:
#   display(failed_events)
#   raise Exception(f"Ledger Events Failed to Upload in Metronome")


# COMMAND ----------

# MAGIC %md
# MAGIC <h3> Verification

# COMMAND ----------


