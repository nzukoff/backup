# Databricks notebook source
ENV = dbutils.widgets.get("env")
#ENV = 'sit'
ENV_Ledger = 'prod' if ENV == "prod" else 'dev'


# COMMAND ----------

# MAGIC
# MAGIC %run ./metronome_ledger_entry_config

# COMMAND ----------

import os
import shutil
from datetime import datetime

# Source and destination directories
source_dir = f'{volume_path}'
destination_dir = f'{volume_archive_path}'
print(source_dir)
print(destination_dir)

# Ensure destination directory exists, create if not
if not os.path.exists(destination_dir):
    os.makedirs(destination_dir)

# Get current timestamp
current_timestamp = datetime.now().strftime('%Y%m%d%H%M%S')

# Iterate over files in the source directory
for filename in os.listdir(source_dir):
    # Construct new filename with timestamp appended
    new_filename = f"{os.path.splitext(filename)[0]}_{current_timestamp}{os.path.splitext(filename)[1]}"
    
    # Move the file to the destination directory
    shutil.move(os.path.join(source_dir, filename), os.path.join(destination_dir, new_filename))

# COMMAND ----------

cd /Volumes/main/it_billing_and_rating/ledger_entries_upload_dev


# COMMAND ----------

ls -l

