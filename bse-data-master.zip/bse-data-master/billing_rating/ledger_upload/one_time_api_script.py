# Databricks notebook source
from pyspark.sql.functions import col, lit

(spark.read.table('main.it_billing_and_rating.ledger_ondemand_events_upload')
  .withColumn("total_commit", col("total_commit").cast("double"))
  .withColumn("commit_file_total_amount", lit(None).cast("double"))
  .withColumn("commit_name", lit(None).cast("string")) 
  .write
  .mode("overwrite")
  .partitionBy("process_date") 
  .option("overwriteSchema", "true")
  .saveAsTable('main.it_billing_and_rating.ledger_ondemand_events_upload')

)

# COMMAND ----------

# MAGIC %sql
# MAGIC Update  integration.it_billing_and_rating.ledger_ondemand_events_upload-- order by process_date desc
# MAGIC SET amount = amount * 100 
# MAGIC where commit_file_total_amount is null 
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * From integration.it_billing_and_rating.ledger_ondemand_events_upload
# MAGIC order by process_timestamp desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select total_commit, cast(total_commit AS double),
# MAGIC  * from main.it_billing_and_rating.ledger_ondemand_events_upload
# MAGIC
# MAGIC where customer_id = 'fdcb2fe4-f61f-45b8-9327-f79f8d96e944'

# COMMAND ----------

# MAGIC %sql
# MAGIC show create table integration.it_billing_and_rating.metronome_ledger_entry_upload_hist

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE integration.it_billing_and_rating.metronome_ledger_entry_upload_hist (
# MAGIC   commit_id STRING,
# MAGIC   amount DOUBLE,
# MAGIC   reason STRING,
# MAGIC   adjustment_type STRING,
# MAGIC   date STRING,
# MAGIC   jira_ticket STRING,
# MAGIC   username STRING,
# MAGIC   fname STRING,
# MAGIC   process_date DATE)
# MAGIC USING delta
# MAGIC PARTITIONED BY (process_date)
# MAGIC TBLPROPERTIES (
# MAGIC   'delta.minReaderVersion' = '1',
# MAGIC   'delta.minWriterVersion' = '2')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * From integration.it_billing_and_rating.metronome_ledger_entry_upload

# COMMAND ----------


from pyspark.sql.functions import col, lit
# added as part of new changes for the data to be passed.




(spark.read.table('integration.it_billing_and_rating.metronome_ledger_entry_upload')

  .withColumn("balance_date", lit(None).cast("STRING")) 
  .write
  .mode("overwrite")
  #.partitionBy("process_date") 
  .option("overwriteSchema", "true")
  .saveAsTable('integration.it_billing_and_rating.metronome_ledger_entry_upload')

)

# COMMAND ----------


from pyspark.sql.functions import col, lit
# added as part of new changes for the data to be passed.




(spark.read.table('integration.it_billing_and_rating.metronome_ledger_entry_upload_hist')

  .withColumn("balance_date", lit(None).cast("STRING")) 
  .write
  .mode("overwrite")
  .partitionBy("process_date") 
  .option("overwriteSchema", "true")
  .saveAsTable('integration.it_billing_and_rating.metronome_ledger_entry_upload_hist')

)

# COMMAND ----------


