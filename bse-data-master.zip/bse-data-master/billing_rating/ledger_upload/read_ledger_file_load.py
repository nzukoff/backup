# Databricks notebook source
dbutils.widgets.dropdown("environment", "dev", ['prod','dev','uat','stg','sit','preprod','dev_external'])
try:
  ENV = dbutils.widgets.get("env")
except:
  ENV = dbutils.widgets.get("environment")

ENV_Ledger = 'prod' if ENV == "prod" else 'dev'
print(ENV_Ledger)
print(ENV)

# COMMAND ----------

# ENV = dbutils.widgets.get("env")
# #ENV = 'stg'
# ENV_Ledger = 'prod' if ENV == "prod" else 'dev'


# COMMAND ----------

# MAGIC %run ./metronome_ledger_entry_config

# COMMAND ----------

ledger_table_name = f'{catalog_nm}.{tgt_db_nm}.metronome_ledger_entry_upload' 
ledger_table_name_hist = f'{catalog_nm}.{tgt_db_nm}.metronome_ledger_entry_upload_hist' 
print(ledger_table_name)
print(ledger_table_name_hist)

# COMMAND ----------

# Directory path
directory = volume_path
print(directory)
process_date = 'process_date'

# COMMAND ----------

import os

# Get list of files in the directory
files = os.listdir(directory)

# Filter out directories, if any
files = [f for f in files if os.path.isfile(os.path.join(directory, f))]

# Get the latest file based on creation time
latest_file = max(files, key=lambda x: os.path.getctime(os.path.join(directory, x)))

# Full path of the latest file
latest_file_path = os.path.join(directory, latest_file)

# Print the latest file name and path
print("Latest File:", latest_file)
print("Latest File Path:", latest_file_path)

# Assign the latest file name to a variable
latest_file_variable = latest_file

# COMMAND ----------

path = directory + '/' + latest_file_variable    
print(path)

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType,DoubleType

schema = StructType([
    StructField("commit_id", StringType(), True),
    StructField("amount", DoubleType(), True),
    StructField("reason", StringType(), True),  
    StructField("adjustment_type", StringType(), True), 
    StructField("date", StringType(), True),
    StructField("jira_ticket", StringType(), True),
    StructField("username", StringType(), True),
    StructField("balance_date", StringType(), True)
])

# Assuming 'directory' and 'latest_file_variable' are defined elsewhere in your code
file_path = directory + '/' + latest_file_variable  

# Read CSV into DataFrame
df_pre = spark.read.csv(file_path, header=True, schema=schema)



df = df_pre.withColumn("fname", lit(latest_file_variable))

# Show the DataFrame
display(df)




# COMMAND ----------

ledger_entry_df, processDate = add_audit_attributes(df)

# COMMAND ----------

# from pyspark.sql.functions import col
# from pyspark.sql.types import DateType
# from pyspark.sql.functions import to_date
# dateFormat = 'MM/dd/yy'
# ledger_entry_df, processDate = add_audit_attributes(df)


# ledger_entry_df = ledger_entry_df.withColumn("date", to_date(col("date"), dateFormat))




# COMMAND ----------

# spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

# COMMAND ----------

display(ledger_entry_df)

# COMMAND ----------

# from pyspark.sql import SparkSession

# spark = SparkSession.builder \
#     .appName("YourAppName") \
#     .config("spark.sql.legacy.timeParserPolicy", "LEGACY") \
#     .getOrCreate()
# display(ledger_entry_df)

# COMMAND ----------

#display(ledger_entry_df)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

print(ledger_table_name)

# COMMAND ----------

display(ledger_entry_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * From main.it_billing_and_rating.metronome_ledger_entry_upload

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')

print(f'Completely overwriting data in {ledger_table_name} for {processDate}')
(ledger_entry_df
  .write
  .mode('overwrite')
  .format('delta')
  #.option("mergeSchema", "true")
  .saveAsTable(ledger_table_name))

# COMMAND ----------

date_str = processDate.strftime('%Y-%m-%d')

print(f'Appending data in  {ledger_table_name_hist} for {processDate}')
(ledger_entry_df
  .write
  .mode('append')
  .format('delta')
  .partitionBy('process_date') # Ensure data is partitioned by 'process_date'
  #.option("mergeSchema", "true")
  .saveAsTable(ledger_table_name_hist))


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from  main.it_billing_and_rating.metronome_ledger_entry_upload
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from  main.it_billing_and_rating.metronome_ledger_entry_upload_hist

# COMMAND ----------


