-- Databricks notebook source
-- MAGIC %python
-- MAGIC
-- MAGIC ENV = 'prod'
-- MAGIC
-- MAGIC if ENV == 'prod':
-- MAGIC   spark.sql("use database bdw")
-- MAGIC   alert_table = "main.it_billing_and_rating.alerts"
-- MAGIC else:
-- MAGIC   spark.sql("use database bdw_dev")
-- MAGIC   alert_table = "users.madan_gopal.alerts"
-- MAGIC
-- MAGIC def set_config(env):
-- MAGIC   """ sets config for an environment """
-- MAGIC   scope = "bse-metronome"
-- MAGIC   sas_container = "fs.azure.sas.bse-rating-and-billing.dbbusinesssystems1.blob.core.windows.net"
-- MAGIC   spark.conf.set(sas_container, dbutils.secrets.get(scope,"bse-rating-and-billing-access-key"))
-- MAGIC   print(scope)
-- MAGIC   print(sas_container)
-- MAGIC
-- MAGIC
-- MAGIC set_config(ENV)

-- COMMAND ----------

-- DBTITLE 1,Hold Usage in last 34 Days
select platform_subscription_id, platform_account_id, workspace_id, cloud, min(usage_time) as min_usage_time, max(usage_time) as max_usage_time, round(sum(net_usage_amount),6) as net_usage_amount
from dlt_hold_usage_events_without_bs a
left anti join bdw.dlt_usage_events_gold b on a.record_id = b.record_id
where usage_time > (NOW() - INTERVAL 34 DAYS)
group by platform_subscription_id, platform_account_id, workspace_id, cloud
order by max_usage_time desc

-- COMMAND ----------


