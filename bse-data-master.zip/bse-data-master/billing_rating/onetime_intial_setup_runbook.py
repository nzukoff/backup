# Databricks notebook source
# DBTITLE 1,Setting pipeline variables
ENV = "sit"

PLATFORM_SOURCE_TBL =  "bdw_dev.billable_usage" #"sfdc_dev.platform_billable_usage_samples_v4"

# COMMAND ----------

# MAGIC %run ./utils/defs_and_helper_functions

# COMMAND ----------

print(REPROCESSED_USAGE_EVENTS_TBL, processed_output_table_name, hold_unsucessfull_output_table_name)

# COMMAND ----------

# DBTITLE 1,Setting Reprocessing Dataset/Table
#Creates Sample schema - Run only first time 
print(f" {PLATFORM_SOURCE_TBL} -> {REPROCESSED_USAGE_EVENTS_LOC}")
source_df_schema = spark.table(PLATFORM_SOURCE_TBL)\
                        .withColumn("sfdc_business_subscription_id", lit(None).cast("string"))\
                        .select(*USAGE_TABLE_FIELDS, "sfdc_business_subscription_id")\
                        .limit(0)\
                        .withColumn(f"{PROCESS_DATE_COLUMN_NAME}", lit(current_date()))\
                        .withColumn(f"{PROCESS_TIMESTAMP_COLUMN_NAME}", lit(current_timestamp()))

source_df_schema.limit(0).write.partitionBy(f"{PROCESS_DATE_COLUMN_NAME}").format('delta')\
                                .option("mergeSchema", "true").mode('append').save(REPROCESSED_USAGE_EVENTS_LOC)

spark.sql(f"CREATE TABLE IF NOT EXISTS {REPROCESSED_USAGE_EVENTS_TBL} USING DELTA LOCATION '{REPROCESSED_USAGE_EVENTS_LOC}'")

# COMMAND ----------

# DBTITLE 1,Setting Monitoring Tables
from datetime import datetime, timedelta
from pyspark.sql.functions import udf, struct, lag, lit, col

today_date = datetime.utcnow().date()
yesterday_date = datetime.utcnow().date() - timedelta(days = 2)

process_date = today_date.strftime('%Y-%m-%d')
yesterday_process_date = yesterday_date.strftime('%Y-%m-%d')

schema = StructType([StructField('transactions', ArrayType(StringType(), True), True),  StructField('response', StructType([StructField('json', StringType(), True), StructField('status_code', StringType(), True)]), True)])


spark.createDataFrame([[["sample"],None]], schema)\
                  .withColumn("process_date", lit(process_date))\
                  .limit(0)\
                  .write.partitionBy("process_date")\
                  .format("delta")\
                  .mode('append')\
                  .save(OUTPUT_PROCESSED_EVENTS_LOC)


spark.createDataFrame([[["sample"]]], ["transactions_ids"])\
                  .withColumn("process_date", lit(process_date))\
                  .withColumn("process_timestamp", lit(current_timestamp()))\
                  .limit(0)\
                  .write.partitionBy("process_date")\
                  .format("delta")\
                  .option("mergeSchema", "true")\
                  .mode('append')\
                  .save(OUTPUT_FALLBACK_LOC)       


spark.sql(f"CREATE TABLE IF NOT EXISTS {processed_output_table_name} USING DELTA LOCATION '{OUTPUT_PROCESSED_EVENTS_LOC}'")  

spark.sql(f"CREATE TABLE IF NOT EXISTS {hold_unsucessfull_output_table_name} USING DELTA LOCATION '{OUTPUT_FALLBACK_LOC}'")                               

# COMMAND ----------


