-- Databricks notebook source
-- DBTITLE 1,Setting up env variables
-- MAGIC %python
-- MAGIC dbutils.widgets.dropdown("environment", "dev", ['prod','dev'])
-- MAGIC try:
-- MAGIC   ENV = dbutils.widgets.get("env")
-- MAGIC except:
-- MAGIC   ENV = dbutils.widgets.get("environment")

-- COMMAND ----------

-- DBTITLE 1,Setting up notebook variables
-- MAGIC %python
-- MAGIC OUTPUT_CATALOG = 'main' if ENV == 'prod' else 'integration'
-- MAGIC OUTPUT_TABLE = f'{OUTPUT_CATALOG}.it_billing_and_rating.contracts_recon_report'
-- MAGIC print(OUTPUT_TABLE)

-- COMMAND ----------

-- DBTITLE 1,Daily snapshot function
-- MAGIC %python
-- MAGIC from pyspark.sql import DataFrame
-- MAGIC from pyspark.sql.functions import lit
-- MAGIC from datetime import datetime
-- MAGIC
-- MAGIC def create_report_snapshot(df: DataFrame, output_table: str) -> None:
-- MAGIC   process_date = datetime.utcnow().date()
-- MAGIC   final_df = df.withColumn('processDate', lit(process_date))         
-- MAGIC   date_str = process_date.strftime('%Y-%m-%d')
-- MAGIC
-- MAGIC   (final_df.write
-- MAGIC            .mode('overwrite')
-- MAGIC            .option('mergeSchema', 'true')
-- MAGIC            .option('replaceWhere', f"processDate = '{date_str}'")
-- MAGIC            .partitionBy('processDate')
-- MAGIC            .saveAsTable(output_table))

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Salesforce data

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW salesforce_amendment AS 
WITH
Coterm AS (
  SELECT DISTINCT CPQ_Original_Order__c, Id, CPQ_Order_Type__c, Count_of_Azure_Products__c
    FROM main.sfdc_bronze.hourly_order
   WHERE processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.hourly_order)
     AND CPQ_Order_Type__c = 'Co-term'
),
Renewal AS (
  SELECT DISTINCT CPQ_Original_Order__c, Id, CPQ_Order_Type__c, Count_of_Azure_Products__c
    FROM main.sfdc_bronze.hourly_order
   WHERE processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.hourly_order)
     AND CPQ_Order_Type__c = 'Renewal'
)
SELECT Coterm.Id, 
       CASE WHEN Coterm.Count_of_Azure_Products__c > 0 OR Renewal.Count_of_Azure_Products__c > 0 THEN TRUE
            ELSE FALSE
            END AS is_Azure
  FROM Coterm
       LEFT JOIN Renewal ON Coterm.CPQ_Original_Order__c = Renewal.Id

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW salesforce_data AS
WITH 
Orders AS ( 
  SELECT AccountId, 
         Billing_System_ID__c,  
         CPQ_Order_Form_Signed__c,
         CPQ_Order_Type__c,
         Count_of_AWS_Products__c, 
         Count_of_Azure_Products__c, 
         Count_of_GCP_Products__c,
         CurrencyIsoCode,
         CreatedDate,
         EffectiveDate,
         COALESCE(CPQ_Order_End_Date__c,EndDate) AS EndDate, 
         Id,
         NS_InternalID__c,
         OpportunityId,
         OrderNumber,
         CPQ_Effective_Support_Percentage__c,
         CPQ_Original_Order__c,
         CPQ_Merged_Original_Orders__c,
         CPQ_MultiCloud__c
   FROM main.sfdc_bronze.hourly_order
  WHERE processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.hourly_order)
),
OrderItems AS (
  SELECT cpq_commit_royalty__c,
         NS_InternalID__c,
         OrderId,
         Product2Id,
         Sales_Order_Id__c,
         CASE WHEN TotalPrice = 0 THEN SBQQ__OrderedQuantity__c
              ELSE TotalPrice END AS TotalPrice
    FROM main.sfdc_bronze.hourly_orderitem
   WHERE processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.hourly_orderitem)
),
Opportunity AS (
  SELECT CloseDate,
         CPQ_Closed_Won__c,
         Id, 
         Name,
         End_Date__c,
         Start_Date__c
    FROM main.sfdc_bronze.hourly_opportunity
   WHERE processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.hourly_opportunity)
),
Products AS (
  SELECT Id,
         Family,
         Name,
         NS_Internal_ID__c,
         ProductCode
    FROM main.sfdc_bronze.hourly_product2
   WHERE processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.hourly_product2)
     AND ProductCode NOT LIKE '%bundle%'
     AND Family NOT IN ('Usage')
                   
),
Account AS (
  SELECT Id,
         Name
    FROM main.sfdc_bronze.hourly_account
   WHERE processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.hourly_account)
)
SELECT DISTINCT
       Orders.AccountId AS Account_ID,
       Orders.Billing_System_ID__c AS Billing_System_ID,
       Orders.OpportunityId AS Opportunity_ID,
       Orders.Id AS Order_ID,
       Orders.OrderNumber AS Order_Number,
       Orders.NS_InternalID__c AS Order_NS_Internal_ID,
       OrderItems.NS_InternalID__c AS Item_NS_Internal_ID,
       OrderItems.Sales_Order_Id__c AS Item_NS_SO_ID,
       Orders.CPQ_Order_Type__c AS Order_Type,
       DATE(Orders.CreatedDate) AS Order_Create_Date,
       DATE(Orders.EffectiveDate) AS Order_Start_Date,
       DATE(Orders.EndDate) AS Order_End_Date,
       DATE(Orders.CPQ_Order_Form_Signed__c) AS Order_Form_Signed,
       Orders.CurrencyIsoCode AS Order_Currency,
       Opportunity.Name AS Opportunity_Name,
       Opportunity.CloseDate AS Opportunity_Close_Date,
       DATE(Opportunity.CPQ_Closed_Won__c) AS Opportunity_Close_Won_Date,
       Products.Name AS Product_Name,
       OrderItems.TotalPrice AS Total_Price, 
       Products.ProductCode as ProductCode,
       Products.Family AS Product_Family,
       Products.NS_Internal_ID__c AS NS_Internal_Item_ID,
       Orders.Count_of_AWS_Products__c AS Count_of_AWS_Products, 
       Orders.Count_of_Azure_Products__c AS Count_of_Azure_Products, 
       Orders.Count_of_GCP_Products__c AS Count_of_GCP_Products,
       Account.Name AS Account_Name,
       Orders.CPQ_Effective_Support_Percentage__c,
       OrderItems.cpq_commit_royalty__c,
       Orders.CPQ_Original_Order__c,
       prior_orders.Billing_System_ID__c as Metronome_Prior_Contract_ID,
       Opportunity.Start_Date__c as SFDC_Opportunity_Start_Date,
       Opportunity.End_Date__c as SFDC_Opportunity_End_Date,
       Orders.CPQ_Merged_Original_Orders__c as SFDC_Prior_Merged_Contracts,
       Orders.CPQ_MultiCloud__c, 
       salesforce_amendment.is_Azure
  FROM Orders
       LEFT JOIN OrderItems ON Orders.Id = OrderItems.OrderId
       LEFT JOIN Opportunity ON Orders.OpportunityId = Opportunity.Id
       LEFT JOIN Products ON OrderItems.Product2Id = Products.Id
       LEFT JOIN Account ON Orders.AccountId = Account.Id
       LEFT JOIN Orders prior_orders ON Orders.CPQ_Original_Order__c = prior_orders.id
       LEFT JOIN salesforce_amendment ON Orders.Id = salesforce_amendment.Id
 WHERE Products.ProductCode IS NOT NULL

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Metronome data

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW metronome_commits AS 
WITH
Contracts AS (
  SELECT id,
         customer_id,
         starting_at,
         ending_before,
         rate_card_id,
         metadata.reseller_royalties[0].fraction as Metronome_Royalty_Fee
    FROM main.it_billing_and_rating.contracts_contracts_silver
),
Commits AS (
  SELECT access_schedule,
         contract_id,
         name,
         netsuite_internal_item_id,
         netsuite_sales_order_id,
         product_name,
         (total_commit/100) AS total_commit,
         (total_cost/100) as total_cost,
         id
    FROM main.it_billing_and_rating.contracts_commits_silver
),
Customers AS (
  SELECT id,
         name,
         archived_at
    FROM main.it_billing_and_rating.customer_silver
)
SELECT Customers.id AS Customer_ID,
       Customers.name AS Customer_Name,
       Commits.contract_id AS Contract_ID,
       DATE(Contracts.starting_at) AS Contract_Start_Date,
       DATE(Contracts.ending_before) AS Contract_End_Date,
       Commits.name AS Commit_Name,
       Commits.netsuite_internal_item_id AS NS_Internal_Item_ID,
       Commits.product_name AS Product_Name,
       Commits.total_commit AS Total_Commit,
       Commits.total_cost as Metronome_Total_Cost,
       Commits.netsuite_sales_order_id AS NS_Sales_Order_ID,
       rollover.total_commit as Metronome_Prior_Contract_Rollover_Amount,
       DATE(GET(Commits.access_schedule.schedule_items,0).date) AS Metronome_Commit_Start_Date,
       DATE(GET(Commits.access_schedule.schedule_items,0).end_date) AS Metronome_Commit_End_Date,
       Contracts.Metronome_Royalty_Fee,
       Commits.id AS Commit_Id
  FROM Contracts
       LEFT JOIN Commits ON Contracts.id = Commits.contract_id
       LEFT JOIN Customers ON Contracts.customer_id = Customers.id
       LEFT JOIN (SELECT * FROM Commits where name LIKE '%Rollover Allowance%') rollover on rollover.contract_id = Contracts.id
 WHERE Customers.name NOT LIKE '%ARCHIVE%'
       AND Customers.archived_at is null
       AND Customers.name != 'OLD';

------------------------------------------------------------------

CREATE OR REPLACE TEMPORARY VIEW metronome_discounts AS 
WITH
Contracts AS (
  SELECT id,
         customer_id,
         starting_at,
         ending_before,
         rate_card_id,
         metadata.reseller_royalties[0].fraction as Metronome_Royalty_Fee
    FROM main.it_billing_and_rating.contracts_contracts_silver
),
Discounts AS (
  SELECT contract_id,
         name,
         metadata:netsuite_sales_order_id,
         product_id,
         (total_amount/100) * -1.0 AS total_commit
    FROM main.it_billing_and_rating.contracts_discounts_silver
),
contract_discounts_schedule as (
  select contract_id, min(schedule_items.date) as start_date,  max(schedule_items.end_date) as end_date
  from (
      select contract_id, explode(schedule.schedule_items) as schedule_items
      from main.it_billing_and_rating.contracts_discounts_silver 
  )
  group by 1
),
Customers AS (
  SELECT id,
         name,
         archived_at
    FROM main.it_billing_and_rating.customer_silver
),
Products AS (
  SELECT metadata, product_list_item_id
    FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY product_list_item_id ORDER BY version DESC) rn
          FROM main.it_billing_and_rating.contracts_product_list_item_versions_silver)
   WHERE rn = 1
)
SELECT Customers.id AS Customer_ID,
       Customers.name AS Customer_Name,
       Discounts.contract_id AS Contract_ID,
       DATE(Contracts.starting_at) AS Contract_Start_Date,
       DATE(Contracts.ending_before) AS Contract_End_Date,
       Discounts.name AS Commit_Name,
       Products.metadata:netsuite_internal_item_id AS NS_Internal_Item_ID,
       NULL AS Product_Name,
       Discounts.total_commit AS Total_Commit,
       total_commit as Metronome_Total_Cost,
       Discounts.netsuite_sales_order_id AS NS_Sales_Order_ID,
       NULL as Metronome_Prior_Contract_Rollover_Amount,
       contract_discounts_schedule.start_date as Metronome_Commit_Start_Date,
       contract_discounts_schedule.end_date as Metronome_Commit_End_Date,
       Contracts.Metronome_Royalty_Fee as Metronome_Royalty_Fee,
       NULL AS Commit_Id
  FROM Discounts
       LEFT JOIN Contracts ON Discounts.contract_id = Contracts.id
       LEFT JOIN Customers ON Contracts.customer_id = Customers.id
       LEFT JOIN contract_discounts_schedule on contract_discounts_schedule.contract_id = Contracts.id
       LEFT JOIN Products ON Discounts.product_id = Products.product_list_item_id
 WHERE Customers.name NOT LIKE '%ARCHIVE%'
       AND Customers.archived_at is null
       AND Customers.name != 'OLD';

------------------------------------------------------------------

CREATE OR REPLACE TEMPORARY VIEW metronome_additional_terms AS 
WITH
Contracts AS (
  SELECT id,
         customer_id,
         starting_at,
         ending_before,
         rate_card_id,
         metadata.reseller_royalties[0].fraction as Metronome_Royalty_Fee
    FROM main.it_billing_and_rating.contracts_contracts_silver
),
Schedule_Charges AS (
  SELECT contract_id,
         name,
         metadata:netsuite_sales_order_id,
         product_id,
         (total_amount/100) AS total_commit
    FROM main.it_billing_and_rating.contracts_scheduled_charges_silver
),
contract_schedule_charges_schedule as (
  select contract_id, min(schedule_items.date) as start_date,  max(schedule_items.end_date) as end_date
  from (
      select contract_id, explode(schedule.schedule_items) as schedule_items
      from main.it_billing_and_rating.contracts_scheduled_charges_silver 
  )
  group by 1
),
Customers AS (
  SELECT id,
         name,
         archived_at
    FROM main.it_billing_and_rating.customer_silver
),
Products AS (
  SELECT metadata, product_list_item_id
    FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY product_list_item_id ORDER BY version DESC) rn
          FROM main.it_billing_and_rating.contracts_product_list_item_versions_silver)
   WHERE rn = 1
)
SELECT Customers.id AS Customer_ID,
       Customers.name AS Customer_Name,
       Schedule_Charges.contract_id AS Contract_ID,
       DATE(Contracts.starting_at) AS Contract_Start_Date,
       DATE(Contracts.ending_before) AS Contract_End_Date,
       Schedule_Charges.name AS Commit_Name,
       Products.metadata:netsuite_internal_item_id AS NS_Internal_Item_ID,
       NULL AS Product_Name,
       Schedule_Charges.total_commit AS Total_Commit,
       NULL as Metronome_Total_Cost,
       Schedule_Charges.netsuite_sales_order_id AS NS_Sales_Order_ID,
       NULL as Metronome_Prior_Contract_Rollover_Amount,
       contract_schedule_charges_schedule.start_date as Metronome_Commit_Start_Date,
       contract_schedule_charges_schedule.end_date as Metronome_Commit_End_Date,
       Contracts.Metronome_Royalty_Fee as Metronome_Royalty_Fee,
       NULL AS Commit_Id
  FROM Schedule_Charges
       LEFT JOIN Contracts ON Schedule_Charges.contract_id = Contracts.id
       LEFT JOIN Customers ON Contracts.customer_id = Customers.id
       LEFT JOIN contract_schedule_charges_schedule on contract_schedule_charges_schedule.contract_id = Contracts.id
       LEFT JOIN Products ON Schedule_Charges.product_id = Products.product_list_item_id
 WHERE Customers.name NOT LIKE '%ARCHIVE%'
       AND Customers.archived_at is null
       AND Customers.name != 'OLD';

------------------------------------------------------------------

CREATE OR REPLACE TEMPORARY VIEW comp_buckets AS 
SELECT DISTINCT contract_id
  FROM main.it_billing_and_rating.contracts_commits_silver
 WHERE (name LIKE '%Comp%' OR name LIKE '%Rollover Allowance%')
   AND total_cost = 0;

------------------------------------------------------------------

CREATE OR REPLACE TEMPORARY VIEW metronome_data AS 
WITH base_data AS (
    SELECT *
      FROM metronome_commits
    UNION ALL
    SELECT *
      FROM metronome_discounts 
    UNION ALL
    SELECT *
      FROM metronome_additional_terms
),  
support_percentage AS (
    SELECT contract_id, collect_set(new_rate:fraction) AS Metronome_Support_Percentage
      FROM main.it_billing_and_rating.contracts_overrides_silver 
     WHERE rate_type = 'overwrite_percentage'
       AND product_id NOT IN ('7198ce96-41d4-4c09-9b2c-385e8c2bfeb6', '945b0809-441c-4ad3-8c4c-304eba7d9066')
     GROUP BY 1
)
SELECT base_data.*,
       support_percentage.Metronome_Support_Percentage,
       CASE WHEN base_data.Commit_Name LIKE '%Support%' 
                 AND COALESCE(base_data.Metronome_Total_Cost,0) = 0 
                 AND base_data.Total_Commit > 0 
                 AND comp_buckets.contract_id IS NOT NULL THEN TRUE
            ELSE FALSE
            END AS Promo_Support_Presence
  FROM base_data
       LEFT JOIN support_percentage ON base_data.Contract_ID = support_percentage.contract_id
       LEFT JOIN comp_buckets ON base_data.Contract_ID = comp_buckets.contract_id;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Netsuite data

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW netsuite_data AS 
WITH
Transactions AS (
  SELECT TRANSACTION_ID,
         ZAB_SUBSCRIPTION_INTERNAL_ID,
         currencies.SYMBOL as NS_SO_Currency,
         DISCOUNT_AMOUNT as NS_SO_Royalty_Fee
    FROM main.it_netsuite_bronze.transactions
    LEFT JOIN main.it_netsuite_bronze.currencies on currencies.CURRENCY_ID = transactions.CURRENCY_ID 
              and currencies.processDate = (SELECT MAX(processDate) FROM main.it_netsuite_bronze.currencies)
   WHERE transactions.processDate = (SELECT MAX(processDate) FROM main.it_netsuite_bronze.transactions)
         AND ZAB_SUBSCRIPTION_INTERNAL_ID IS NOT NULL
         AND TRANSACTION_TYPE = 'Sales Order'
),
TransactionLines AS (
  SELECT ITEM_ID,
         ITEM_UNIT_PRICE,
         TRANSACTION_ID
    FROM main.it_netsuite_bronze.transaction_lines
   WHERE processDate = (SELECT MAX(processDate) FROM main.it_netsuite_bronze.transaction_lines)
         AND ITEM_ID IS NOT NULL 
),
Items AS (
  SELECT ITEM_ID, 
         NAME
    FROM main.it_netsuite_bronze.items
   WHERE processDate = (SELECT MAX(processDate) FROM main.it_netsuite_bronze.items)
),
Subs AS (
  SELECT DATE(END_DATE) AS END_DATE, 
         DATE(START_DATE) AS START_DATE, 
         ZAB_SUBSCRIPTION_ID,
         SUPPORT_PERCENTAGE,
         PRIOR_SUBSCRIPTION_MASTER_ID
    FROM main.it_netsuite_bronze.zab_subscription
   WHERE processDate = (SELECT MAX(processDate) FROM main.it_netsuite_bronze.zab_subscription)
)
SELECT Transactions.TRANSACTION_ID AS Transaction_ID,
       Transactions.ZAB_SUBSCRIPTION_INTERNAL_ID AS ZAB_Subscription_ID,
       Subs.START_DATE AS Sub_Start_Date,
       Subs.END_DATE AS Sub_End_Date,
       Items.ITEM_ID AS Item_ID,
       Items.NAME AS Item_Name,
       TransactionLines.ITEM_UNIT_PRICE AS Item_Price,
       NS_SO_Currency,
       SUPPORT_PERCENTAGE as NS_ZAB_Support_Percentage,
       NS_SO_Royalty_Fee,
       PRIOR_SUBSCRIPTION_MASTER_ID as NS_PRIOR_SUBSCRIPTION_MASTER_ID
  FROM Transactions
       LEFT JOIN TransactionLines ON Transactions.TRANSACTION_ID = TransactionLines.TRANSACTION_ID
       LEFT JOIN Items ON TransactionLines.ITEM_ID = Items.ITEM_ID
       LEFT JOIN Subs ON Transactions.ZAB_SUBSCRIPTION_INTERNAL_ID = Subs.ZAB_SUBSCRIPTION_ID
 WHERE Items.NAME <> 'AVATAX'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Contracts Recon
-- MAGIC
-- MAGIC Salesforce <> Metronome <> Netsuite

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW contracts_recon_report AS
SELECT CASE 
            WHEN round(abs(coalesce(s.Total_Price,0) - coalesce(m.Total_Commit,0)),2) = 0 AND
                 round(abs(coalesce(s.Total_Price,0) - coalesce(n.Item_Price,0)),2) = 0 AND
                 round(abs(coalesce(m.Total_Commit,0) - coalesce(n.Item_Price,0)),2) = 0 AND
                 s.Order_Start_Date = m.Contract_Start_Date AND 
                 s.Order_End_Date = date_add(m.Contract_End_Date, -1) AND
                 s.Order_Start_Date = n.Sub_Start_Date AND 
                 s.Order_End_Date = n.Sub_End_Date
                 THEN 'Exact match - in 3 System'
            WHEN s.Product_Family LIKE '%Internal%' OR 
                 s.Product_Family LIKE '%Training%' OR 
                 s.Product_Family LIKE '%Run Rate%' OR 
                 s.Product_Family LIKE '%Services Subscription%' OR 
                 s.Product_Family LIKE '%Professional Services%' OR 
                 s.Product_Name = 'Platform & Support Services' OR
                 s.Order_Type = 'Professional Service & Training only' OR 
                   --(s.Count_of_Azure_Products > 0 OR s.is_Azure IS TRUE) --commented as part tof minizone ne logic below for this by sachin
                 (s.Count_of_Azure_Products > 0 and CPQ_MultiCloud__c = false) ---added as part of minizone by sachin
                 THEN 'N/A for Recon (currently out of scope)'
            WHEN lower(m.Commit_Name) LIKE '%rollover%' THEN 'Met Only - Rollover'
            WHEN m.Commit_Name is not null and s.Product_Name is null THEN 'Met Only'
            ELSE 'Recon Item - Mismatch'
            END Reconciling_Reason_Code,

       CASE WHEN Reconciling_Reason_Code = 'Exact match - in 3 System' 
                 THEN 'Exact match - in 3 System'
            WHEN s.Order_Type = 'Professional Service & Training only' 
                 THEN 'N/A for Recon (currently out of scope): PS&T'
          --WHEN (s.Count_of_Azure_Products > 0 OR s.is_Azure IS TRUE)  --commented as part tof minizone ne logic below for this by sachin
              --   THEN 'N/A for Recon (currently out of scope): Azure'
            WHEN s.Product_Family LIKE '%Internal%' OR 
                 s.Product_Family LIKE '%Training%'
                 THEN 'N/A for Recon (currently out of scope): Internal or Training'
            WHEN s.Product_Family LIKE '%Run Rate%' 
                 THEN 'N/A for Recon (currently out of scope): Run Rate'
            WHEN s.Product_Family LIKE '%Services Subscription%' OR 
                 s.Product_Family LIKE '%Professional Services%'
                 THEN 'N/A for Recon (currently out of scope): PS&T'
            WHEN s.Product_Name = 'Platform & Support Services' 
                 THEN 'N/A for Recon (currently out of scope): Platform & Support Services'

            WHEN (s.Count_of_Azure_Products > 0 and CPQ_MultiCloud__c = false)
                 THEN  'N/A for Recon (currently out of scope)- Azure' -- added as part of minizone project sachin 
                 
            WHEN lower(m.Commit_Name) LIKE '%rollover%' 
                 THEN 'Met Only - Rollover'
            WHEN (m.Commit_Name is not null and s.Product_Name is null) OR 
                 m.Promo_Support_Presence IS TRUE 
                 THEN 'Met Only'
            WHEN (s.Billing_System_ID IS NOT NULL AND s.Total_Price = 0) OR 
                 (m.Contract_ID IS NOT NULL AND m.Total_Commit = 0) OR 
                 (n.Transaction_ID IS NOT NULL AND n.Item_Price = 0) 
                 THEN '\$0 Commit'
            WHEN s.Opportunity_ID IS NOT NULL AND s.Billing_System_ID IS NULL 
                 THEN 'Billing_System_ID missing in SFDC'
            WHEN s.Billing_System_ID IS NULL 
                 THEN 'Contract or Commit missing in SFDC'
            WHEN m.Contract_ID IS NULL 
                 THEN 'Contract or Commit missing in Metronome'
            WHEN m.NS_Sales_Order_ID IS NULL 
                 THEN 'Sales Order missing in Metronome'
            WHEN n.Transaction_ID IS NULL 
                 THEN 'Sales Order missing in NS'
            WHEN round(abs(coalesce(s.Total_Price,0) - coalesce(m.Total_Commit,0)),2) > 0 
                 THEN 'Amount Mismatch between SFDC and Metronome'
            WHEN round(abs(coalesce(s.Total_Price,0) - coalesce(n.Item_Price,0)),2) > 0 
                 THEN 'Amount Mismatch between SFDC and NS'
            WHEN round(abs(coalesce(m.Total_Commit,0) - coalesce(n.Item_Price,0)),2) > 0 
                 THEN 'Amount Mismatch between Metronome and NS'
            WHEN s.Order_Start_Date != m.Contract_Start_Date OR 
                 s.Order_End_Date != date_add(m.Contract_End_Date, -1) 
                 THEN 'Date Mismatch between SFDC and Metronome'
            WHEN s.Order_Start_Date != n.Sub_Start_Date AND 
                 s.Order_End_Date != n.Sub_End_Date 
                 THEN 'Date Mismatch between SFDC and NS'
            WHEN round(abs(coalesce(s.Total_Price,0) - coalesce(m.Total_Commit,0)),2) = 0 AND
                 round(abs(coalesce(s.Total_Price,0) - coalesce(n.Item_Price,0)),2) = 0 AND
                 round(abs(coalesce(m.Total_Commit,0) - coalesce(n.Item_Price,0)),2) = 0 AND
                 s.Order_Start_Date = m.Contract_Start_Date AND 
                 s.Order_End_Date = date_add(m.Contract_End_Date, -1) AND
                 s.Order_Start_Date = n.Sub_Start_Date AND 
                 s.Order_End_Date = n.Sub_End_Date
                 THEN 'Exact match'
            ELSE 'Unknown'
            END AS Reconciling_Item,
                           
        s.Account_Name as SFDC_Customer_Name,
        s.Opportunity_ID AS SFDC_Opportunity_ID,
        s.Opportunity_Name AS SFDC_Opportunity_Name,
        s.Order_Start_Date AS SFDC_Opportunity_Start_Date,
        s.Order_End_Date AS SFDC_Opportunity_End_Date,
        s.Opportunity_Close_Won_Date AS SFDC_Opportunity_Close_Won_Date,
        s.Opportunity_Close_Date AS SFDC_Opportunity_Close_Date,
        s.Order_Form_Signed AS SFDC_Order_Form_Signed,
        s.Order_Create_Date AS SFDC_Order_Create_Date,
        s.Order_ID AS SFDC_Order_ID,
        s.Order_Type AS SFDC_Order_Type,
        s.Billing_System_ID AS SFDC_Billing_System_ID,
        s.Item_NS_SO_ID AS SFDC_NS_SO_ID,
        s.Product_Name AS SFDC_Product,
        s.Order_Currency AS SFDC_Currency,
        round(coalesce(s.Total_Price,0),2) AS SFDC_Product_Price,
        s.CPQ_Effective_Support_Percentage__c AS SFDC_Support_Percentage,
        s.cpq_commit_royalty__c AS SFDC_Royalty_Fee,
        s.CPQ_Original_Order__c AS SFDC_Prior_Contract_ID,
        s.SFDC_Prior_Merged_Contracts AS SFDC_Prior_Merged_Contracts,
        
        n.ZAB_Subscription_ID AS NS_ZAB_Subscription_ID,
        n.Sub_Start_Date AS NS_ZAB_Start_Date,
        n.Sub_End_Date AS NS_ZAB_End_Date,
        n.Transaction_ID AS NS_SO_ID,
        n.Item_Name AS NS_SO_Product,
        NS_SO_Currency,
        round(coalesce(n.Item_Price,0),2) AS NS_SO_Product_Price,
        NS_ZAB_Support_Percentage,
        NS_SO_Royalty_Fee,
        NS_PRIOR_SUBSCRIPTION_MASTER_ID,

        m.Customer_Name AS Metronome_Customer_Name,
        m.Customer_ID AS Metronome_Customer_ID,
        m.Contract_ID AS Metronome_Contract_ID,
        m.Contract_Start_Date AS Metronome_Contract_Start_Date,
        m.Contract_End_Date AS Metronome_Contract_End_Date,
        s.Metronome_Prior_Contract_ID,
        m.Metronome_Prior_Contract_Rollover_Amount,
        m.Commit_Id AS Metronome_Commit_ID,
        m.NS_Sales_Order_ID AS Metronome_NS_SO_ID,
        m.Metronome_Commit_Start_Date,
        m.Metronome_Commit_End_Date,
        m.Commit_Name AS Metronome_Commit_Name,
        coalesce(m.Product_Name, m.Commit_Name) AS Metronome_Product,
        round(coalesce(m.Total_Commit,0),2) AS Metronome_Total_Commit,
        round(coalesce(m.Metronome_Total_Cost,0),2) AS Metronome_Total_Cost,
        m.Metronome_Support_Percentage,
        m.Promo_Support_Presence AS Metronome_Promo_Support_Presence,
        m.Metronome_Royalty_Fee,
        
        round(abs(coalesce(s.Total_Price,0) - coalesce(m.Total_Commit,0)),2) AS Variance_SFDC_Metronome_Price,
        round(abs(coalesce(s.Total_Price,0) - coalesce(n.Item_Price,0)),2) AS Variance_SFDC_NS_Price,
        round(abs(coalesce(m.Total_Commit,0) - coalesce(n.Item_Price,0)),2) AS Variance_NS_Metronome_Price

    FROM salesforce_data s
         FULL OUTER JOIN metronome_data m ON s.Billing_System_ID = m.Contract_ID 
                                         AND s.NS_Internal_Item_ID = m.NS_Internal_Item_ID
                                        --  AND s.Item_NS_SO_ID = m.NS_Sales_Order_ID
         LEFT JOIN netsuite_data n ON m.NS_Sales_Order_ID = n.Transaction_ID 
                                  AND m.NS_Internal_Item_ID = n.Item_ID

-- COMMAND ----------

-- MAGIC %python
-- MAGIC create_report_snapshot(df = spark.table('contracts_recon_report'), output_table = OUTPUT_TABLE)
