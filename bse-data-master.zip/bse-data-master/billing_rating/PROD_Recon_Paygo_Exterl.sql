-- Databricks notebook source
create or replace temp view dates as
select last_day(add_months(current_date(), -3)) + 1 as start_date, last_day(add_months(current_date(), 0)) + 1 as end_date, last_day(add_months(current_date(), -1)) as last_day;
select * from dates

-- COMMAND ----------

create or replace temp view metronome_customers as
select id, explode(ingest_aliases) as bs_id from main.it_billing_and_rating.metronome_customers 

-- COMMAND ----------

-- DBTITLE 1,Recon dashboard build query - (not filtering 0 amount invoices here)
create or replace temp view metronome_invoices as
with base as (
  select * except (line_items) , month(start_timestamp) as invoice_month
  from main.it_billing_and_rating.metronome_invoices 
  where status != 'VOID' and is_deleted = false
  and plan_id is not null
),

latest_invoice as (
  select customer_id, invoice_month, max(process_timestamp) as process_timestamp
  from base
  group by customer_id, invoice_month
),

base_invoices as 
(
  select a.*
  from main.it_billing_and_rating.metronome_invoices a
  inner join latest_invoice b on a.customer_id = b.customer_id and month(a.start_timestamp) = b.invoice_month and a.process_timestamp = b.process_timestamp
  inner join dates d
  where start_timestamp >= d.start_date and end_timestamp <= d.end_date
  --where start_timestamp >= cast('2023-06-01' as date) and end_timestamp <= cast('2023-07-01' as date)
  and status != 'VOID' and is_deleted = false
  and plan_id is not null
),

invoicestbl as (
  select * from (
        select *, row_number() over (partition by customer_id,plan_id,date(start_timestamp) order by process_timestamp desc) as rn
        from base_invoices
    ) where rn = 1
union all 
select *,1 from base_invoices
where plan_id is null
),

distinct_cte as (
      select *, row_number() over (partition by id order by process_timestamp)as rnum 
      from invoicestbl 
      )

select distinct_cte.id, total, subtotal, bs_id, start_timestamp, end_timestamp, customer_id
from distinct_cte 
inner join metronome_customers on distinct_cte.customer_id = metronome_customers.id
where rnum = 1


-- COMMAND ----------

select id, count(*)
from metronome_invoices
group by 1
having count(*) > 1

-- COMMAND ----------

create or replace temp view paygo_metronome_invoices as
with invoice_dbus as
(
  select id, customer_id, sum(sline_item_quantity) as quantity
  from main.it_billing_and_rating.metronome_recon_invoice_data
  inner join dates d 
  where invoice_start_dt >= d.start_date and invoice_end_dt <= d.end_date
  --where month(invoice_start_dt) >= cast('2023-06-01' as date) and invoice_end_dt <= cast('2023-07-01' as date)
  group by id, customer_id
)

select all_invoices.customer_id, platform_account_id, sfdc_business_subscription_id, date_format(start_timestamp, 'y-MM') as recon_month, sum(quantity) as quantity, sum(all_invoices.total) as invoice_total, min(all_invoices.start_timestamp) as min_invoice_start_date, max(all_invoices.end_timestamp) as max_invoice_end_date
from metronome_invoices all_invoices
left join invoice_dbus i on all_invoices.id = i.id  
left join main.it_billing_and_rating.dlt_business_subscription bs on bs.sfdc_business_subscription_id = bs_id
GROUP BY all_invoices.customer_id, platform_account_id, sfdc_business_subscription_id, date_format(start_timestamp, 'y-MM')

-- COMMAND ----------

select recon_month,count(*) from paygo_metronome_invoices group by 1

-- COMMAND ----------

create or replace temp view paygo_extract_logfood as
SELECT ProductAccountId, bs.sfdc_business_subscription_id,  date_format(monthenddate, 'y-MM') as recon_month, min(pue.SubscriptionStartDate) as min_SubscriptionStartDate, max(pue.SubscriptionEndDate) as max_SubscriptionEndDate,
sum(pue.Amount) as total_dbu_dollar, sum(pue.Qty) as paygo_ext_qunty, sum(ue.Qty) as gold_table_qunty, min(pue.UsageDate) as min_usage_date_extr, max(pue.UsageDate) as max_usage_date_extr
FROM main.it_usage_gold.paygo_usage_extract pue 
INNER JOIN main.it_usage_gold.usage_extract ue ON pue.ExternalId = ue.ExternalId 
inner join dates d 
left join main.it_billing_and_rating.dlt_business_subscription bs on bs.platform_account_id = ue.ProductAccountId
WHERE monthenddate > d.start_date and monthenddate < d.end_date
AND ue.processDate = (select max(processDate) from main.it_usage_gold.usage_extract)
group by 1, 2, 3

-- COMMAND ----------

select recon_month,count(*) from paygo_extract_logfood group by 1

-- COMMAND ----------

create or replace temp view gold_usage_data as

with mid_day_conversion as (
  select distinct ProductAccountId, date_format(UsageDate, 'y-MM') as recon_month
  FROM main.it_usage_gold.usage_extract ue 
  inner join dates d 
  where UsageDate >= d.start_date and UsageDate < d.end_date
  --where UsageDate between '2023-06-01' and '2023-06-30' 
  AND ue.processDate = (select max(processDate) from main.it_usage_gold.usage_extract)
  group by ProductAccountId, UsageDate
  having count(distinct IsPaying) > 1
)

select ue.ProductAccountId,date_format(ue.UsageDate, 'y-MM') as recon_month, sum(ue.Qty) as qty, max(UsageDate) as max_usage_date,
max(case when SubscriptionStartDate is null and IsPaying = true then 1 else 0 end) as missing_ws,
max(case when mdc.ProductAccountId is not null then 1 else 0 end) as mid_day_conversion
FROM main.it_usage_gold.usage_extract ue 
inner join dates d 
left join mid_day_conversion mdc on ue.ProductAccountId = mdc.ProductAccountId and mdc.recon_month = date_format(ue.UsageDate, 'y-MM')
where UsageDate >= d.start_date and UsageDate < d.end_date
--where UsageDate between '2023-06-01' and '2023-06-30' 
AND ue.processDate = (select max(processDate) from main.it_usage_gold.usage_extract)
group by 1, 2

-- COMMAND ----------

create or replace temp view billable_usage as
select platform_account_id,date_format(usage_time, 'y-MM') as recon_month, sum((net_usage_amount) + coalesce(add_ons_list_price_rated_amount[0].rated_amount, 0)) as net_usage_amount,
sum(case when cast(usage_time as date) <= ue.max_usage_date then net_usage_amount + coalesce(add_ons_list_price_rated_amount[0].rated_amount, 0) else 0 end) as billable_usage_dbu,
max(ue.qty) as gold_qty, min(usage_time) as min_usage_time, max(usage_time) as max_usage_time
FROM main.eng_billable_usage.billable_usage bu
inner join dates d 
left JOIN gold_usage_data ue on bu.platform_account_id = ue.ProductAccountId and date_format(usage_time, 'y-MM') = ue.recon_month
where usage_time >= d.start_date and usage_time < d.end_date
--and coalesce(cloud, '') != 'azure' and coalesce(internal_data.should_ingest_by_metronome, false) = true and date >= '2023-11-01'
--where usage_time >= '2023-06-01' and usage_time < '2023-07-01' 
group by 1,2

-- COMMAND ----------

create or replace temp view events_uploaded as
with cte_usage_processed_events AS (
select distinct response.status_code as status_code, explode(transactions) as transaction_id
from main.it_billing_and_rating.usage_processed_events
),
succeed_events as (
  select * 
  from cte_usage_processed_events 
  where status_code = 200
),
errored_events as (
  select * 
  from cte_usage_processed_events 
  left anti join succeed_events on succeed_events.transaction_id = cte_usage_processed_events.transaction_id
  where cte_usage_processed_events.status_code <> 200
),
final_usage_processed_events as (
  select status_code, transaction_id from succeed_events
  union all
  select status_code, transaction_id from errored_events
),
cte_events_at_dest as (
select platform_account_id, business_subscription_id, date_format(usage_time, 'y-MM') as recon_month, sum(case when coalesce(status_code,0) = 200 then net_usage_amount + coalesce(add_ons_list_price_rated_amount[0].rated_amount, 0) else 0 end) as dbu_quantity_uploaded,
sum(case when coalesce(status_code,0) <> 200 then net_usage_amount + coalesce(add_ons_list_price_rated_amount[0].rated_amount, 0) else 0 end) as dbu_quantity_not_uploaded,
sum(net_usage_amount + coalesce(add_ons_list_price_rated_amount[0].rated_amount, 0)) as total_quantity,
min(usage_time) as min_usage_time, max(usage_time) as max_usage_time
from main.it_billing_and_rating.dlt_usage_events_gold source 
left join final_usage_processed_events dest on dest.transaction_id = source.record_id 
inner join dates d 
where usage_time >= d.start_date and usage_time < d.end_date
--where usage_time >= '2023-06-01' and usage_time < '2023-07-01' 
group by business_subscription_id, platform_account_id, 3
)

select * from cte_events_at_dest

-- COMMAND ----------

select recon_month, count(*) from paygo_metronome_invoices group by 1

-- COMMAND ----------

select recon_month, count(*) from paygo_extract_logfood group by 1

-- COMMAND ----------

-- DBTITLE 0,Metronome Invoice Recon with PayGo External Table - March
create or replace table main.it_billing_and_rating.billing_dashboard 
PARTITIONED BY (recon_month)
as
select round(abs(coalesce((a.invoice_total/100),0) - coalesce(b.total_dbu_dollar,0)), 6) as abs_diff_amount_paygo_externalization, 
round(coalesce((a.invoice_total/100),0) - coalesce(b.total_dbu_dollar,0), 6) as diff_amount_paygo_externalization, 

case when (a.invoice_total/100) = 0 and b.ProductAccountId is null then '0$ Invoice - Exists in Metronome but not in PayGo'
     when billable_usage.platform_account_id is null then 'Account missing in billable_usage'
     when round(round(gold_usage_data.qty, 3) - round(billable_usage.billable_usage_dbu, 3),3) > 0 then 'Gold Schema Mismatch - conversion issue'
     when abs(round(round(gold_usage_data.qty, 3) - round(billable_usage.billable_usage_dbu, 3),3)) > 0 then 'Gold Schema Mismatch'
     when metronome_customers.id is null then 'Account Missing in Metronome'
     when metronome_customers.id is not null and a.sfdc_business_subscription_id is null then 'NO ACTIVE PLAN in Metronome'
     when (a.invoice_total/100) > 0 and b.ProductAccountId is null then 'Exists in Metronome but not in PayGo'
     when gold_usage_data.missing_ws = 1 then 'Workspace mapping issue'
     when gold_usage_data.mid_day_conversion = 1 then 'Mid day Conversion'
     when billable_usage.net_usage_amount = dbu_quantity_uploaded and (round(abs(coalesce((a.invoice_total/100),0) - coalesce(b.total_dbu_dollar,0)), 6)) > 0 then 'External table latency or plan mismatch'
     when (round(abs(coalesce((a.invoice_total/100),0) - coalesce(b.total_dbu_dollar,0)), 6)) = 0 then 'Exact Match' 
     when billable_usage.net_usage_amount <> dbu_quantity_uploaded and dbu_quantity_not_uploaded = 0 and (round(abs(coalesce((a.invoice_total/100),0) - coalesce(b.total_dbu_dollar,0)), 6)) > 0 then 'Upload Latency'
     when round(dbu_quantity_not_uploaded,3) > 0 then 'DBUs dropped in upload process'
     else 'unknown'
end as Reason_Code,

gold_usage_data.qty as existing_usage_gold_dbu,
billable_usage.billable_usage_dbu,
b.paygo_ext_qunty as paygoext_quantity,
a.quantity as metronome_quantity,
billable_usage.net_usage_amount as billable_usage_live_dbu,
gold_usage_data.max_usage_date as max_usage_date_gold,
min_usage_date_extr, max_usage_date_extr,
billable_usage.min_usage_time, billable_usage.max_usage_time,
events_uploaded.dbu_quantity_uploaded,
a.platform_account_id as metronome_pa,
a.sfdc_business_subscription_id as metronome_bs_id,
b.ProductAccountId as paygoext_pa,
b.sfdc_business_subscription_id as paygo_bs_id,
(b.total_dbu_dollar) as total_dollar_paygoexternal,
(a.invoice_total/100) as total_dollar_metronome,
--b.paygo_ext_qunty as paygoext_quantity,
--a.quantity as metronome_quantity,
coalesce(metronome_customers.id, a.customer_id) as customer_id,
min_invoice_start_date, max_invoice_end_date,
b.min_SubscriptionStartDate, b.max_SubscriptionendDate,
dbu_quantity_not_uploaded,
total_quantity,
coalesce(b.recon_month, a.recon_month) as recon_month
--events_uploaded.*
from paygo_metronome_invoices a
full outer join paygo_extract_logfood b on a.platform_account_id = b.ProductAccountId and a.recon_month = b.recon_month
left join metronome_customers on coalesce(a.sfdc_business_subscription_id,b.sfdc_business_subscription_id) = metronome_customers.bs_id
left join events_uploaded on events_uploaded.business_subscription_id = coalesce(b.sfdc_business_subscription_id, a.sfdc_business_subscription_id) and events_uploaded.recon_month = coalesce(b.recon_month, a.recon_month)
left join gold_usage_data on coalesce(b.ProductAccountId,a.platform_account_id) = gold_usage_data.ProductAccountId and gold_usage_data.recon_month = coalesce(b.recon_month, a.recon_month)
left join billable_usage on coalesce(b.ProductAccountId,a.platform_account_id) = billable_usage.platform_account_id and billable_usage.recon_month = coalesce(b.recon_month, a.recon_month)
ORDER BY 1 desc

-- COMMAND ----------

create or replace table main.it_billing_and_rating.billing_dashboard_invoices
PARTITIONED BY (recon_month)
with invoice_dbus as
(
  select id, customer_id, sum(sline_item_quantity) as quantity
  from main.it_billing_and_rating.metronome_recon_invoice_data
  inner join dates d 
  where invoice_start_dt >= d.start_date and invoice_end_dt <= d.end_date
  --where month(invoice_start_dt) >= cast('2023-06-01' as date) and invoice_end_dt <= cast('2023-07-01' as date)
  group by id, customer_id
)

select all_invoices.customer_id, all_invoices.id, metronome_bs_id as bs_id, recon_month,Reason_Code, quantity as total_dbu, cast(all_invoices.total as double)/100 as invoice_total, all_invoices.start_timestamp as invoice_start_date, all_invoices.end_timestamp as invoice_end_date
from main.it_billing_and_rating.billing_dashboard bd
inner join metronome_invoices all_invoices on bd.customer_id = all_invoices.customer_id and bd.recon_month = date_format(start_timestamp, 'y-MM')
inner join invoice_dbus i on all_invoices.id = i.id  

-- COMMAND ----------

create or replace table main.it_billing_and_rating.billing_dashboard_workspaces
PARTITIONED BY (recon_month) 
as
select bd.Reason_Code, platform_account_id, bu.workspace_id, date_format(usage_time, 'y-MM') as recon_month
, case when ue.missing_ws = 1 then true else false end as missing_ws_mapping
, sum(net_usage_amount) as platform_dbu
FROM main.it_billing_and_rating.billing_dashboard bd
inner join main.eng_billable_usage.billable_usage bu on bd.paygoext_pa = bu.platform_account_id
inner join dates d 
left JOIN gold_usage_data ue on bu.platform_account_id = ue.ProductAccountId and date_format(usage_time, 'y-MM') = ue.recon_month
where usage_time >= d.start_date and usage_time < d.end_date
group by 1,2,3,4,5

-- COMMAND ----------


