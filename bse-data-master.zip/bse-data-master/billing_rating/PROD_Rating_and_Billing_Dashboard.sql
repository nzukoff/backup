-- Databricks notebook source
-- MAGIC %python
-- MAGIC
-- MAGIC ENV = 'prod'
-- MAGIC
-- MAGIC if ENV == 'prod':
-- MAGIC   spark.sql("use catalog main")
-- MAGIC   spark.sql("use schema it_billing_and_rating")
-- MAGIC   alert_table = "main.it_billing_and_rating.alerts"
-- MAGIC else:
-- MAGIC   spark.sql("use catalog users")
-- MAGIC   spark.sql("use schema madan_gopal")
-- MAGIC   alert_table = "users.madan_gopal.alerts"
-- MAGIC
-- MAGIC def set_config(env):
-- MAGIC   """ sets config for an environment """
-- MAGIC   scope = "bse-metronome"
-- MAGIC   sas_container = "fs.azure.sas.bse-rating-and-billing.dbbusinesssystems1.blob.core.windows.net"
-- MAGIC   spark.conf.set(sas_container, dbutils.secrets.get(scope,"bse-rating-and-billing-access-key"))
-- MAGIC   print(scope)
-- MAGIC   print(sas_container)
-- MAGIC
-- MAGIC
-- MAGIC set_config(ENV)

-- COMMAND ----------

-- DBTITLE 1,Alerts Table
-- MAGIC %python
-- MAGIC spark.sql(f"""CREATE TABLE IF NOT EXISTS {alert_table} 
-- MAGIC               (run_date timestamp,
-- MAGIC                billable_usage_write_time timestamp,
-- MAGIC                query_name string,
-- MAGIC                error_message string,
-- MAGIC                trigger_alert boolean
-- MAGIC               )
-- MAGIC               PARTITIONED BY (query_name, billable_usage_write_time)
-- MAGIC           """
-- MAGIC           )
-- MAGIC spark.sql(f"""create or replace temp view vw_alerts as
-- MAGIC               select * from {alert_table} where billable_usage_write_time >= (NOW() - INTERVAL 5 HOUR) 
-- MAGIC           """)

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW tmp_vw_dashboard_query1 as

with cte_events_at_source as (
select source.billable_usage_write_time,
count(source.event_id) as events_at_source
from billable_usage source
group by source.billable_usage_write_time
),

cte_events_at_gold as (
select gold.billable_usage_write_time,
count(gold.event_id) as events_at_gold
from dlt_usage_events_gold gold
group by gold.billable_usage_write_time
),

cte_events_at_hold as (
select hold.billable_usage_write_time,
count(hold.event_id) as events_at_gold
from dlt_hold_usage_events_without_bs hold 
group by hold.billable_usage_write_time
),

cte_usage_processed_events AS (
select request_timestamp, response.json as josn_message, response.status_code as status_code, process_date,
explode(transactions) as transaction_id, epoch_id, parition_id
from usage_processed_events
),

cte_events_at_dest as (
select source.billable_usage_write_time as billable_usage_write_time,
status_code,
count(dest.transaction_id) as events_at_dest,
max(dest.request_timestamp) as max_timestamp
from billable_usage source 
inner join cte_usage_processed_events dest on dest.transaction_id = source.record_id and dest.request_timestamp >= source.billable_usage_write_time
group by billable_usage_write_time, status_code
)


SELECT date_trunc('HOUR', source.billable_usage_write_time) as billable_usage_write_time,
max(timestampdiff(SECOND, source.billable_usage_write_time, coalesce(dest_success.max_timestamp, Current_timestamp)) / 60) as success_latency_mins,
sum(source.events_at_source) as events_at_source,   
sum(coalesce(hold.events_at_gold, 0)) as events_at_hold,
sum(coalesce(gold.events_at_gold, 0)) as events_at_gold,
sum(coalesce(dest_success.events_at_dest, 0)) as events_delivered,
sum(coalesce(dest_failed.events_at_dest, 0)) as events_failed

FROM cte_events_at_source source 
LEFT JOIN cte_events_at_gold gold on gold.billable_usage_write_time = source.billable_usage_write_time 
LEFT JOIN cte_events_at_hold hold on hold.billable_usage_write_time = source.billable_usage_write_time
LEFT JOIN cte_events_at_dest dest_success on dest_success.billable_usage_write_time = source.billable_usage_write_time and dest_success.status_code = 200 
LEFT JOIN cte_events_at_dest dest_failed on dest_failed.billable_usage_write_time = source.billable_usage_write_time and dest_failed.status_code <> 200 

where source.billable_usage_write_time >= (NOW() - INTERVAL 24 HOUR)
GROUP BY 1
order by 1;

select * from tmp_vw_dashboard_query1;



-- COMMAND ----------

-- DBTITLE 1,Build Alert - Query 1
-- MAGIC %python
-- MAGIC display(spark.sql(f"""
-- MAGIC               insert into {alert_table}
-- MAGIC               select distinct now() as run_time, a.billable_usage_write_time, 'dashboard_query1' as query_name, null as error, true as trigger_alert 
-- MAGIC               from tmp_vw_dashboard_query1 a
-- MAGIC               left anti join vw_alerts b on a.billable_usage_write_time = b.billable_usage_write_time and b.query_name = "dashboard_query1"
-- MAGIC               where a.billable_usage_write_time >= (NOW() - INTERVAL 5 HOUR)
-- MAGIC               and (success_latency_mins >= 35 or events_failed > 0 or events_at_source <> events_delivered) 
-- MAGIC             """
-- MAGIC           ))

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW tmp_vw_dashboard_query2 as

with cte_events_at_source as (
select source.billable_usage_write_time,
count(source.event_id) as events_at_source
from billable_usage source
group by source.billable_usage_write_time
),

cte_events_at_gold as (
select gold.billable_usage_write_time,
count(gold.event_id) as events_at_gold
from dlt_usage_events_gold gold
group by gold.billable_usage_write_time
),

cte_events_at_hold as (
select hold.billable_usage_write_time,
count(hold.event_id) as events_at_hold
from dlt_hold_usage_events_without_bs hold 
group by hold.billable_usage_write_time
),

cte_unsucessfull_events_flattend as (
select process_timestamp, explode(transactions_ids) as transaction_id
from hold_unsucessfull_events
),

cte_unsucessfull_events as (
select source.billable_usage_write_time,
count( ue.transaction_id ) as unsucessfull_events
from billable_usage source 
inner join cte_unsucessfull_events_flattend ue  on ue.transaction_id = source.record_id and ue.process_timestamp >= source.billable_usage_write_time
group by source.billable_usage_write_time
)


SELECT date_trunc('HOUR', source.billable_usage_write_time) as billable_usage_write_time,
sum(source.events_at_source) as events_at_source,   
sum(coalesce(hold.events_at_hold, 0)) as events_at_hold,
sum(coalesce(gold.events_at_gold, 0)) as events_at_gold,
sum(coalesce(unsc.unsucessfull_events, 0)) as unsucessfull_events

FROM cte_events_at_source source 
LEFT JOIN cte_events_at_gold gold on gold.billable_usage_write_time = source.billable_usage_write_time 
LEFT JOIN cte_events_at_hold hold on hold.billable_usage_write_time = source.billable_usage_write_time
LEFT JOIN cte_unsucessfull_events unsc on unsc.billable_usage_write_time = source.billable_usage_write_time 

where source.billable_usage_write_time >= (NOW() - INTERVAL 24 HOUR)
GROUP BY 1
order by 1;

select * from tmp_vw_dashboard_query2


-- COMMAND ----------

-- DBTITLE 1,Build Alert - Query 2
-- MAGIC %python
-- MAGIC display(spark.sql(f"""
-- MAGIC               insert into {alert_table}
-- MAGIC               select distinct now() as run_time, a.billable_usage_write_time, 'dashboard_query2' as query_name, null as error, true as trigger_alert 
-- MAGIC               from tmp_vw_dashboard_query2 a
-- MAGIC               left anti join vw_alerts b on a.billable_usage_write_time = b.billable_usage_write_time and b.query_name = "dashboard_query2"
-- MAGIC               where a.billable_usage_write_time >= (NOW() - INTERVAL 5 HOUR)
-- MAGIC               and (events_at_hold > 0 or unsucessfull_events > 0)
-- MAGIC             """
-- MAGIC           ))

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW tmp_vw_dashboard_query3 as

with usage_processed_events AS (
select request_timestamp, response.json as josn_message, response.status_code as status_code, process_date,
explode(transactions) as transaction_id, epoch_id, parition_id
from usage_processed_events
)

SELECT date_trunc('HOUR', source.billable_usage_write_time) as billable_usage_write_time, dest.status_code, count(*) as num_records
FROM dlt_usage_events_gold source 
LEFT JOIN usage_processed_events dest on source.record_id = dest.transaction_id and coalesce(dest.request_timestamp, CURRENT_TIMESTAMP()) >= source.billable_usage_write_time  
where source.billable_usage_write_time >= (NOW() - INTERVAL 24 HOUR)
group by 1, dest.status_code
order by 1 desc;

select * from tmp_vw_dashboard_query3


-- COMMAND ----------

-- DBTITLE 1,Build Alert - Query 3
-- MAGIC %python
-- MAGIC display(spark.sql(f"""
-- MAGIC               insert into {alert_table}
-- MAGIC               select distinct now() as run_time, a.billable_usage_write_time, 'dashboard_query3' as query_name, null as error, true as trigger_alert 
-- MAGIC               from tmp_vw_dashboard_query3 a
-- MAGIC               left anti join vw_alerts b on a.billable_usage_write_time = b.billable_usage_write_time and b.query_name = "dashboard_query3"
-- MAGIC               where a.billable_usage_write_time >= (NOW() - INTERVAL 5 HOUR)
-- MAGIC               and status_code <> 200 
-- MAGIC             """
-- MAGIC           ))

-- COMMAND ----------


