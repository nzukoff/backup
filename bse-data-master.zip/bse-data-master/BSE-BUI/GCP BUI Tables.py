# Databricks notebook source
from pyspark.sql.functions import udf, struct, lag, lit
from pyspark.sql.types import BooleanType
from pyspark.sql import functions as F
from datetime import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import *

# COMMAND ----------

# config for tables
uc_catalog = 'main'
uc_schema = 'it_bui_silver'
uc_prefx = f"""{uc_catalog}.{uc_schema}"""

gcp_accounts_table = f"""{uc_prefx}.gcp_accounts"""
gcp_metering_table = f"""{uc_prefx}.gcp_metering"""
gcp_metering_agg_table = f"""{uc_prefx}.gcp_metering_agg"""
gcp_subscriptions_table = f"""{uc_prefx}.gcp_subscriptions"""
gcp_workspaces_table = f"""{uc_prefx}.gcp_workspaces"""
gcp_workspaces_latest_table = f"""{uc_prefx}.gcp_workspaces_latest"""

# COMMAND ----------

def set_config(env):
  """ sets config for an environment """
  scope = "bui-bse-integration-"+env
  sas_container = "fs.azure.sas.container-bui-bse-share-{0}.stbuibseshare{0}.blob.core.windows.net".format(env)
  print('scope: ', scope)
  spark.conf.set(sas_container, dbutils.secrets.get(scope,"stbuibseshare/r/sas"))

# COMMAND ----------

env = "prod"
set_config(env)
REDACTED_METERING_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/gcp_v2/redacted_metering/".format(env)
REDACTED_ACCOUNTS_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/gcp_v2/redacted_accounts_gcp/".format(env)
REDACTED_HISTORY_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/gcp_v2/workspaces_history/".format(env)
REDACTED_SNAPSHOT_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/gcp_v2/workspaces_snapshot/".format(env)
REDACTED_SUBS_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/gcp_v2/redacted_subscriptions/".format(env)

# COMMAND ----------

print(REDACTED_METERING_LOCATION)

# COMMAND ----------

metering_df = spark.read.format("delta").load(REDACTED_METERING_LOCATION)
accounts_df = spark.read.format("delta").load(REDACTED_ACCOUNTS_LOCATION)
hist_df = spark.read.format("delta").load(REDACTED_HISTORY_LOCATION)
snapshot_df = spark.read.format("delta").load(REDACTED_SNAPSHOT_LOCATION)
subs_df = spark.read.format("delta").load(REDACTED_SUBS_LOCATION)

# COMMAND ----------

metering_df = metering_df.withColumn("clusterNodeType", col("tags.clusterNodeType"))\
                         .withColumn("dbuMultiplier", col("tags.dbuMultiplier"))\
                         .withColumn("clusterInstanceMilliseconds", col("tags.clusterInstanceMilliseconds"))\
                         .withColumn("clusterId", col("tags.clusterId"))\
                         .withColumn("workloadType", col("tags.workloadType"))\
                         .withColumn("clusterCreator", col("tags.clusterCreator"))\
                         .withColumn("clusterSku", col("tags.clusterSku"))\
                         .withColumn("clusterName", col("tags.clusterName"))\
                         .withColumn("dataFactorySubscription", col("tags.dataFactorySubscription"))\
                         .drop("tags")\
                         .drop("timings")

# COMMAND ----------

# DBTITLE 1,Account Table
accounts_df.write\
           .option("overwriteSchema", "true")\
           .format("delta")\
           .mode("overwrite")\
           .saveAsTable(gcp_accounts_table)
           #.save("/mnt/bse-dev/redacted_accounts_gcp")

# COMMAND ----------

# %sql
# create table bdw.gcp_accounts
# using delta
# location "/mnt/bse-dev/redacted_accounts_gcp"

# COMMAND ----------

# DBTITLE 1,Metering Table
metering_df.write\
           .option("overwriteSchema", "true")\
           .format("delta")\
           .mode("overwrite")\
           .saveAsTable(gcp_metering_table)
           #.save("/mnt/bse-dev/gcp_metering")

# COMMAND ----------

# %sql
# create table bdw.gcp_metering
# using delta
# location "/mnt/bse-dev/gcp_metering"

# COMMAND ----------

# %sql
# desc history bdw.gcp_metering

# COMMAND ----------

# DBTITLE 1,History Table
# maxQueryTimestamp = spark.sql("select max(queryTimestamp) as max_queryTimestamp from bdw.gcp_workspaces_hist").collect()[0].max_queryTimestamp
# hist_df_append = hist_df.filter(hist_df.queryTimestamp > maxQueryTimestamp)

# COMMAND ----------

# hist_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/gcp_workspaces_hist")

# COMMAND ----------

# %sql
# create table bdw.gcp_workspaces_hist
# using delta
# location "/mnt/bse-dev/gcp_workspaces_hist"

# COMMAND ----------

# %sql
# optimize bdw.bui_workspaces

# COMMAND ----------

# DBTITLE 1,Latest Workspace-NetSuitesubscriptionId
drop_columns = ['awsInfo', 'azureInfo', 'billing']
workspace_df = snapshot_df.drop(*drop_columns)

# COMMAND ----------

workspace_df.write\
            .option("overwriteSchema", "true")\
            .format("delta")\
            .mode("overwrite")\
            .saveAsTable(gcp_workspaces_latest_table)
            #.save("/mnt/bse-dev/gcp_workspaces_latest")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- create table bdw.gcp_workspaces_latest
# MAGIC -- using delta
# MAGIC -- location "/mnt/bse-dev/gcp_workspaces_latest"

# COMMAND ----------

# %sql
# desc history bdw.gcp_subscriptions

# COMMAND ----------

# DBTITLE 1,GCP Subscriptions
subs_df = subs_df.withColumn("gcpPricingPlan", col("gcpEntitlementInfo.gcpPricingPlan"))\
                 .withColumn("newPricingPlan", col("gcpEntitlementInfo.newPricingPlan"))\
                 .withColumn("planChangeTime", col("gcpEntitlementInfo.planChangeTime"))\
                 .withColumn("externalQuoteId", col("gcpEntitlementInfo.externalQuoteId"))\
                 .drop("gcpEntitlementInfo")

# COMMAND ----------

subs_df.write\
       .option("overwriteSchema", "true")\
       .format("delta")\
       .mode("overwrite")\
       .saveAsTable(gcp_subscriptions_table)
       #.save("/mnt/bse-dev/gcp_subscriptions")

# COMMAND ----------

# %sql
# create table bdw.gcp_subscriptions
# using delta
# location "/mnt/bse-dev/gcp_subscriptions"

# COMMAND ----------

# DBTITLE 1,metering_agg table
#### include wl.externalSubscriptionId once this is available in the snapshot
metering_agg_query = f"""
with metering_agg (
select workspaceId,
       sku,
       cast(from_utc_timestamp(billingTimeStamp, 'PST') as date) date,
       isPaying,
       sum(quantity) quantity
from {gcp_metering_table}
group by 1,2,3,4
),

gcp_subs (
select distinct subscriptionId,
                externalSubscriptionId
from {gcp_subscriptions_table}
),

workspaces_latest (
select distinct 
         g.externalSubscriptionId netsuite_subscription_id,
         gwl.workspaceId,
         gwl.workspaceName,
         gwl.trialExpirationTime
from {gcp_workspaces_latest_table} gwl 
left join gcp_subs g on gwl.subscriptionId = g.subscriptionId
)

select mg.workspaceId,
       wl.netsuite_subscription_id,
       concat('GCP_', mg.sku) sku,
       mg.date,
       mg.isPaying,
       mg.quantity,
       wl.workspaceName,
       cast(wl.trialExpirationTime as long)
from metering_agg mg
join workspaces_latest wl on mg.workspaceId = cast(wl.workspaceId as string)
"""
metering_agg_df = spark.sql(metering_agg_query)

# COMMAND ----------

metering_agg_df.write\
               .option("overwriteSchema", "true")\
               .format("delta")\
               .mode("overwrite")\
               .saveAsTable(gcp_metering_agg_table)
               #.save("/mnt/bse-dev/gcp_metering_agg")

# COMMAND ----------

# %sql
# create table bdw.gcp_metering_agg
# using delta
# location "/mnt/bse-dev/gcp_metering_agg"

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))
