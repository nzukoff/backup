# Databricks notebook source
from pyspark.sql.functions import udf, struct, lag
from pyspark.sql.types import BooleanType
from pyspark.sql import functions as F
from datetime import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import *

# COMMAND ----------

def set_config(env):
  """ sets config for an environment """
  scope = "bui-bse-integration-"+env
  sas_container = "fs.azure.sas.container-bui-bse-share-{0}.stbuibseshare{0}.blob.core.windows.net".format(env)
  spark.conf.set(sas_container, dbutils.secrets.get(scope,"stbuibseshare/r/sas"))

# COMMAND ----------

env = "prod"
set_config(env)
REDACTED_METERING_ADDONS_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/dlt/redacted_metering_with_add_ons/".format(env)

metering_df_addons = spark.read.format("delta").load(REDACTED_METERING_ADDONS_LOCATION)
metering_df_addons.createOrReplaceTempView("metering_addons")

# COMMAND ----------

bui_metering_agg_table = 'main.it_bui_silver.bui_metering_agg'
usage_gold_table = 'main.it_usage_gold.usage_extract'

# COMMAND ----------

validate_metering_upload = spark.sql(f"""
with base (
select workspaceId,
       sku,
       date,
       isPaying,
       sum(quantity) quantity 
from metering_addons
group by all
),

netsuite (
select workspaceName,
       SKUType,
       Qty,
       UsageDate,
       isPaying,
       status
from {usage_gold_table}
where processDate = (select max(processDate) from {usage_gold_table})
order by 1
)


select * from (
    select b.workspaceId,
           b.sku,
           b.date,
           b.quantity actualQuantity,
           n.Qty uploadedQuantity,
           (b.quantity - n.Qty) diff,       
           b.isPaying,
           n.status netsuiteProcessStatus
    from base b
    join netsuite n on b.workspaceId = n.workspaceName and b.sku = n.SKUType and b.date = n.UsageDate and b.isPaying = n.isPaying
    order by diff desc
)
where date >= '2023-02-01'
and date < current_date()
and abs(diff) > 0.1
""")

# COMMAND ----------

validate_count = validate_metering_upload.count()
print(validate_count)

# COMMAND ----------

# MAGIC %md
# MAGIC #### check if usage is missing

# COMMAND ----------

validate_metering_insert = spark.sql(f"""
with base (
select workspaceId,
       sku,
       date,
       isPaying,
       sum(quantity) quantity 
from metering_addons
where date between '2024-02-01'  and date_sub(current_date(), 2)
and workspaceId is not null
and workspaceId != 0
group by all
),

netsuite (
select workspaceName,
       SKUType,
       Qty,
       UsageDate,
       isPaying,
       status
from {usage_gold_table}
where processDate = (select max(processDate) from {usage_gold_table})
order by 1
)


select b.*
from base b
left anti join netsuite n on b.workspaceId = n.workspaceName 
                         and b.sku = n.SKUType 
                         and b.date = n.UsageDate 
                         and b.isPaying = n.isPaying
""")

# COMMAND ----------

validate_metering_insert.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view duplicate_external_ids
# MAGIC as
# MAGIC select *
# MAGIC from it_usage_gold.duplicate_external_ids
# MAGIC where processDate = (select max(processDate) from it_usage_gold.duplicate_external_ids)

# COMMAND ----------

def check_for_duplicate_external_ids():
  """ checks for duplicate external-ids with the composition of date,workspaceId,sku,isPaying """
  return True if spark.sql(""" select * from duplicate_external_ids """).count() > 0 else False

# COMMAND ----------

if validate_count > 0:
  display(validate_metering_upload)
  raise Exception("Found mismatch for metering upload")

# if the insert count is greater than 0, then it checks if the job has failed for any duplicate external-ids
# otw, it displays the insert mismatch
if validate_metering_insert.count() > 0:
  display(validate_metering_insert)
  if check_for_duplicate_external_ids():
    print('found duplicate external-ids')
    display(spark.sql(""" select * from duplicate_external_ids """))
  raise Exception("Gold Schema is missing usage records")
