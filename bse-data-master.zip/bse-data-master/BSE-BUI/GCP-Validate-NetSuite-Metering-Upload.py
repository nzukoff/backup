# Databricks notebook source
dbutils.widgets.removeAll()

# COMMAND ----------

# default date set
dbutils.widgets.text("validate_from_date", "2023-04-01")

# COMMAND ----------

validate_from_date = dbutils.widgets.get("validate_from_date")
print(validate_from_date)

# COMMAND ----------

gcp_metering_agg_table = 'main.it_bui_silver.gcp_metering_agg'
usage_gold_table = 'main.it_usage_gold.usage_extract'

# COMMAND ----------

upload_validate_metering_upload = spark.sql(f"""
with base (
select workspaceId,
       sku,
       quantity,
       date,
       isPaying
from {gcp_metering_agg_table}
),

netsuite (
select workspaceName,
       SKUType,
       Qty,
       UsageDate,
       isPaying,
       status
from {usage_gold_table}
where processDate = (select max(processDate) from {usage_gold_table})
and cloudType = 'gcp'
order by 1
)


select * from (
    select b.workspaceId,
           b.sku,
           b.date,
           b.quantity actualQuantity,
           n.Qty uploadedQuantity,
           (b.quantity - n.Qty) diff,       
           b.isPaying,
           n.status netsuiteProcessStatus
    from base b
    join netsuite n on b.workspaceId = n.workspaceName and b.sku = n.SKUType and b.date = n.UsageDate and b.isPaying = n.isPaying
    order by diff desc
)
where date >= '{validate_from_date}' 
and date <= current_date()
and abs(diff) > 0.01
""")

# COMMAND ----------

upload_validate_count = upload_validate_metering_upload.count()
print(upload_validate_count)

# COMMAND ----------

# MAGIC %md
# MAGIC #### left join to check if usage_gold is missing any usage

# COMMAND ----------

insert_validate_metering_upload = spark.sql(f""" 
with base (
select workspaceId,
       sku,
       quantity,
       date,
       isPaying
from {gcp_metering_agg_table}
where date between '{validate_from_date}'  and date_sub(current_date(), 2)
),

netsuite (
select workspaceName,
       SKUType,
       Qty,
       UsageDate,
       isPaying,
       status,
       processDate
from {usage_gold_table}
where processDate = (select max(processDate) from {usage_gold_table})
and cloudType = 'gcp'
order by 1
)


select * from (
    select 
           b.workspaceId,
           b.sku,
           b.date,
           b.quantity actualQuantity,
           n.Qty uploadedQuantity,
           (b.quantity - n.Qty) diff,       
           b.isPaying,
           n.status netsuiteProcessStatus,
           n.processDate
    from base b
    left join netsuite n on b.workspaceId = n.workspaceName and b.sku = n.SKUType and b.date = n.UsageDate and b.isPaying = n.isPaying
    where n.SKUType is null and n.workspaceName is null 
)
order by date, workspaceId
""")

# COMMAND ----------

insert_validate_count = insert_validate_metering_upload.count()

# COMMAND ----------

should_raise_exception = False

if upload_validate_count > 0:
  print('update mismatch')
  display(upload_validate_metering_upload)
  should_raise_exception = True

if insert_validate_count > 0:
  print('insert mismatch')
  display(insert_validate_metering_upload)
  should_raise_exception = True

if should_raise_exception:
  raise Exception("Found mismatch for metering upload")
