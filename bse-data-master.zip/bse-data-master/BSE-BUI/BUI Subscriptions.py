# Databricks notebook source
from pyspark.sql.functions import udf, struct, lag, lit
from pyspark.sql.types import BooleanType
from pyspark.sql import functions as F
from datetime import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import *

# COMMAND ----------

def set_config(env):
  """ sets config for an environment """
  scope = "bui-bse-integration-"+env
  sas_container = "fs.azure.sas.container-bui-bse-share-{0}.stbuibseshare{0}.blob.core.windows.net".format(env)
  spark.conf.set(sas_container, dbutils.secrets.get(scope,"stbuibseshare/r/sas"))

# COMMAND ----------

env = "prod"
db_env = 'bdw'
set_config(env)

# COMMAND ----------

# config for tables
uc_catalog = 'main'
uc_schema = 'it_bui_silver'
uc_prefx = f"""{uc_catalog}.{uc_schema}"""

bui_subscriptions_table = f"""{uc_prefx}.bui_subscriptions"""

# COMMAND ----------

REDACTED_SUBSCRIPTION_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/redacted_subscriptions/".format(env)
GCP_REDACTED_SUBSCRIPTION_LOCATION = "wasbs://container-bui-bse-share-{0}@stbuibseshare{0}.blob.core.windows.net/gcp/redacted_subscriptions/".format(env)

# COMMAND ----------

subscriptions_df = spark.read.format("delta").load(REDACTED_SUBSCRIPTION_LOCATION)
gcp_subscriptions_df = spark.read.format("delta").load(GCP_REDACTED_SUBSCRIPTION_LOCATION)
#subscriptions_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/aws_subscriptions")

# COMMAND ----------

gcp_subscriptions_df = gcp_subscriptions_df.withColumn("awsMarketplaceInfo", lit(None))

# COMMAND ----------

# build col-name and col-type map to use it to add to GCP subscriptions
name_type_map = {}
for col in subscriptions_df.schema:
  #print(col.name, col.dataType)
  if col.name not in name_type_map:
    name_type_map[col.name] = col.dataType

print(name_type_map)

# COMMAND ----------

gcp_to_aws_diff_columns = set(subscriptions_df.columns).difference(set(gcp_subscriptions_df.columns))
print(gcp_to_aws_diff_columns)

# COMMAND ----------

for gcp_col in gcp_to_aws_diff_columns:
  gcp_col_data_type = name_type_map[gcp_col]
  print('adding', gcp_col, gcp_col_data_type)
  gcp_subscriptions_df = gcp_subscriptions_df.withColumn(gcp_col, lit(None).cast(gcp_col_data_type))

# COMMAND ----------

gcp_subscriptions_df = gcp_subscriptions_df.select(*sorted(gcp_subscriptions_df.columns))
subscriptions_df = subscriptions_df.select(*sorted(subscriptions_df.columns))

subscriptions_all = subscriptions_df.union(gcp_subscriptions_df)

# COMMAND ----------

subscriptions_all.write\
                 .option("overwriteSchema", "true")\
                 .format("delta")\
                 .mode("overwrite")\
                 .saveAsTable(bui_subscriptions_table)

# COMMAND ----------

# subscriptions_all.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/aws_subscriptions")

# COMMAND ----------

# %sql
# create table bdw.bui_subscriptions
# using delta
# location '/mnt/bse-dev/aws_subscriptions'
