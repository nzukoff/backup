# Databricks notebook source
# MAGIC %md
# MAGIC #### set up

# COMMAND ----------

validate_from_date = '2023-04-01'

# COMMAND ----------

gcp_metering_agg_table = 'main.it_bui_silver.gcp_metering_agg'
usage_gold_table = 'main.it_usage_gold.usage_extract'
usage_gold_table_audit = 'main.it_usage_gold.usage_extract_audit'

# COMMAND ----------

# MAGIC %md
# MAGIC #### gcp validation - metering

# COMMAND ----------

gcp_validate_metering_upload = spark.sql("""
with base (
select workspaceId,
       sku,
       quantity,
       date,
       isPaying
from {gcp_metering_agg_table}
),

netsuite (
select workspaceName,
       SKUType,
       Qty,
       UsageDate,
       isPaying,
       status,
       processDate
from {usage_gold_table}
where processDate = (select max(processDate) from usage_gold.usage_extract)
and cloudType = 'gcp'
order by 1
)


select * from (
    select 
           b.workspaceId,
           b.sku,
           b.date,
           b.quantity actualQuantity,
           n.Qty uploadedQuantity,
           (b.quantity - n.Qty) diff,       
           b.isPaying,
           n.status netsuiteProcessStatus,
           n.processDate
    from base b
    join netsuite n on b.workspaceId = n.workspaceName and b.sku = n.SKUType and b.date = n.UsageDate and b.isPaying = n.isPaying
    order by diff desc
)
where date >= '{0}' 
and date <= current_date()
and abs(diff) > 0.001
""".format(validate_from_date))

# COMMAND ----------

# MAGIC %md
# MAGIC #### run merge updates to fix the voilations

# COMMAND ----------

count_gcp_validate_metering_upload = gcp_validate_metering_upload.count()

# COMMAND ----------

if count_gcp_validate_metering_upload > 0:
  display(gcp_validate_metering_upload)

# COMMAND ----------


if count_gcp_validate_metering_upload > 0:
          print('running the merge updates..')
          spark.sql("""
                    with
                    updates (
                    select *
                    from gcp_validate_metering_upload
                    )

                    MERGE INTO usage_gold.usage_extract orig
                    USING updates up
                    ON orig.workspaceName = up.workspaceId 
                      and orig.SKUType = up.sku 
                      and orig.UsageDate = up.date 
                      and orig.isPaying = up.isPaying
                      and orig.processDate = up.processDate
                    WHEN MATCHED THEN
                      UPDATE SET orig.Qty = up.actualQuantity
          """)
else:
          print(' all uploaded records match nothing to update')

# COMMAND ----------

# MAGIC %md
# MAGIC #### audit table

# COMMAND ----------

gcp_validate_metering_upload.createOrReplaceTempView('gcp_validate_metering_upload')

# COMMAND ----------

if count_gcp_validate_metering_upload > 0:
  print(' adding and rewriting the audit table')

  usage_gold_audit_df = spark.sql(""" 
                                      select date usage_date,
                                            workspaceId workspace_id,
                                            sku, 
                                            isPaying is_paying,
                                            'gcp' cloud,
                                            concat(date, '-', 'gcp', '-', workspaceId,'-', sku, '-', IsPaying) usage_key, 
                                            actualQuantity new_quantity,
                                            uploadedQuantity old_quantity,
                                            diff difference,
                                            current_date() audit_date
                                      from gcp_validate_metering_upload 

                                      union all

                                      select usage_date,
                                            workspace_id,
                                            sku, 
                                            is_paying,
                                            cloud,
                                            usage_key, 
                                            new_quantity,
                                            old_quantity,
                                            difference,
                                            audit_date
                                      from usage_gold.audit_usage_extract 
  """)   

  usage_gold_audit_df.write\
                     .option("mergeSchema", "true")\
                     .format("delta")\
                     .mode("overwrite")\
                     .saveAsTable(usage_gold_table_audit)
                     #.save("/mnt/bse-prod/usage_gold/usage_extract_audit")

# COMMAND ----------

display(spark.sql(f""" 
select last_day(usage_date),
       sum(difference)
from {usage_gold_table_audit}
group by 1
"""))
