# Databricks notebook source
# MAGIC %md
# MAGIC # Generates core_accounts table for Customer Data Analytics

# COMMAND ----------

# MAGIC %run "./CDA-Config"

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql import functions as sqlf
from pyspark.sql import Window
from pyspark.sql import *
from datetime import datetime, timedelta
import json
from pprint import pprint

# COMMAND ----------

@udf("double")
def t3mARR(ARR, T3MDollarDBUs):
  """ returns max of ARR or 4 times T3M Dollars"""
  return max(ARR, (T3MDollarDBUs*4))

spark.udf.register("t3mARR", t3mARR)

@udf("string")
def t3mARRBand(T3MARR):
  """ retuns a T3M ARR Band """
  if T3MARR > 1000000:
    T3MARRBand = "$1M+"
  elif T3MARR > 500000 and T3MARR <= 1000000:
    T3MARRBand = "$500K-$1M"
  elif T3MARR > 240000 and T3MARR <= 500000:
    T3MARRBand = "$240K-$500K"
  elif T3MARR > 100000 and T3MARR <= 240000:
    T3MARRBand = "$100K-$240K"
  else:
    T3MARRBand = "<$100K"
  
  return T3MARRBand

spark.udf.register("t3mARRBand", t3mARRBand)

# COMMAND ----------

dbutils.widgets.text("environment", 'development') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

dbutils.widgets.text("writeMode", 'overwrite')  # Awlays overwrite, only when initiating the table we should append
writeMode = dbutils.widgets.get("writeMode")
print(writeMode)

# COMMAND ----------

dbutils.widgets.text("processDate", datetime.now().strftime("%Y-%m-%d"))
processDate = dbutils.widgets.get("processDate")
print("processing :", processDate)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

prev_week_date = str((datetime.strptime(processDate, "%Y-%m-%d") -timedelta(7)).date())

# COMMAND ----------

df=spark.sql("select max(processDate) from {2} where processDate <= '{0}' and processDate >='{1}'".format(processDate,prev_week_date,SFDC_USER))
if df.dropna().count() == 0:
  raise Exception("Empty {} dataframe for last 7 days of process date: {}".format(SFDC_USER,processDate))

# COMMAND ----------

spark.sql("""
select *
from {1}
where processDate = (select max(processDate) from {1} where processDate <= '{0}')
""".format(processDate, SFDC_USER)).createOrReplaceTempView("sfdc_user")

# COMMAND ----------

df=spark.sql("select max(processDate) from {2} where processDate <= '{0}' and processDate >='{1}'".format(processDate,prev_week_date, SFDC_ACCOUNT))
if df.dropna().count() == 0:
  raise Exception("Empty {} dataframe for last 7 days of process date: {}".format(SFDC_ACCOUNT,processDate))

# COMMAND ----------

df=spark.sql("select max(processDate) from {2} where processDate <= '{0}' and processDate >='{1}'".format(processDate,prev_week_date, SFDC_RTM))
if df.dropna().count() == 0:
  raise Exception("Empty {} dataframe for last 7 days of process date: {}".format(SFDC_RTM,processDate))

# COMMAND ----------

# identify all the sales regions
# todo: change it to processDate parameter
# todo: union - count(AEOwnerId) > 1 + count(AEOwnerId) = 1
sales_regions = spark.sql("""
with account_ae (
select distinct 
       a.OwnerId AEOwnerId,
       u.UserRoleId
from {1} a
left join sfdc_user u on u.Id = a.OwnerId
where a.processDate = (select max(processDate) from {1} where processDate <= '{0}')
)
select distinct
       usr.AEOwnerId, 
       Business_Unit__c sales_business_unit,
       Region_Level_1__c sales_subregion_level_1,
       Region_Level_2__c sales_subregion_level_2,
       Region_Level_3__c sales_subregion_level_3
from {2} rtm
join account_ae usr on rtm.Role_ID__c = usr.UserRoleId
where processDate = (select max(processDate) from {2} where processDate <= '{0}')
and Consider_Role_Under_Forecast__c and not rtm.IsDeleted
""".format(processDate,SFDC_ACCOUNT,SFDC_RTM))

# COMMAND ----------

if sales_regions.limit(1).count() == 0:
  dbutils.notebook.exit(json.dumps({
    "status": "Empty Sales_Region"
  }))
  raise Exception("empty sales_regions dataframe")

# COMMAND ----------

df=spark.sql("select max(processDate) from {2} where processDate <= '{0}' and processDate >='{1}'".format(processDate,prev_week_date,SFDC_BRAG_STATUS))
if df.dropna().count() == 0:
  raise Exception("Empty {} dataframe for last 7 days of process date: {}".format(SFDC_BRAG_STATUS, processDate))

# COMMAND ----------

user_df  = spark.sql("""SELECT
                        Id AS brag_last_modified_by_user_id,
                        Name AS brag_last_modified_by_user
                        FROM {1}
                        WHERE processDate = (select max(processDate) from {1} where processDate <= "{0}")
                     """.format(processDate, SFDC_USER))

brag_history_df = spark.sql("""WITH base_table AS
                               (SELECT
                               DISTINCT
                               Account__c AS account_id,
                               Start_Date__c AS start_date,
                               LastModifiedById AS last_modified_by_user_id
                               FROM {1}
                               WHERE processDate = (select max(processDate) from {1} where processDate <= "{0}")
                               AND Account__c IS NOT NULL)
                               SELECT
                               DISTINCT
                               account_id,
                               LAST(start_date) OVER (PARTITION BY account_id ORDER BY start_date ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS latest_brag_start_date,
                               LAST(last_modified_by_user_id) OVER (PARTITION BY account_id ORDER BY start_date ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS brag_last_modified_by_user_id
                               FROM base_table
                            """.format(processDate,SFDC_BRAG_STATUS))

brag_df = brag_history_df \
          .join(user_df, "brag_last_modified_by_user_id", "left") \
          .withColumn("latest_brag_start_date", sqlf.substring("latest_brag_start_date", 0, 10)) \
          .drop("brag_last_modified_by_user_id")

brag_df.createOrReplaceTempView("brag_details")

# COMMAND ----------

# builds account attributes from snapshot
account_df = spark.sql("""
with account_dates_base as (
select accountId,
       min(month_end_date) paygo_customer_start_date
from {1}
where cumRevShareDollars >= 1000
group by 1
)

select a.id account_id,
       a.Name account_name,
       a.CustomerType__c customer_type,
       a.Account_Status__c account_status,       
       a.SCP_Status__c scp_status,
       case when a.SCP_Status__c = "Enrolled" then true
            else false
       end as is_scp,
       a.SCP_Tier__c scp_tier,
       a.SCP_Enrollment_Date__c scp_enrollment_date,
       a.BRAG_Status__c brag_status,
       a.Support_Tier__c support_tier,
       a.CSE_Tier__c customer_success_engineer_tier,
       a.Next_Renewal_Date__c next_renewal_date,
       a.Next_Renewal_Quarter__c next_renewal_quarter,
       a.Upcoming_Renewal_Amount__c upcoming_renewal_amount,
       a.ParentId parent_account_id,
       a2.Name parent_account_name,
       a.AE_of_DS_Fcst__c current_quarter_account_executive_forecast,
       a.NQ_AE_of_DS_Fcst__c next_quarter_account_executive_forecast,
       a.Commit_Customer_Date__c commit_customer_start_date,
       a.Databricks_Vertical_Map_New__c vertical,
       
       ad.paygo_customer_start_date,
       u.Name as account_executive,
       u2.Name customer_success_engineer,
       u3.Name resident_solution_architect,
       u.Role_Region__c sales_region,
       u.Region_Level_1__c subregion_level_1,
       u.Region_Level_2__c subregion_level_2,
       u.UserRoleId AEOwnerRoleId,
       u2.UserRoleId CSEUserRoleId,
       
       bd.brag_last_modified_by_user,
       bd.latest_brag_start_date,
   
       a.OwnerId,
       
       case when a.Commit_Customer_Date__c is null then ad.paygo_customer_start_date
            when ad.paygo_customer_start_date is null then a.Commit_Customer_Date__c
            when ad.paygo_customer_start_date < a.Commit_Customer_Date__c then ad.paygo_customer_start_date
            else a.Commit_Customer_Date__c
       end as customer_start_date,
       
       a.processDate snapshot_date
from {2} a 
left join sfdc_user u on u.Id = a.OwnerId 
left join sfdc_user u2 on u2.Id = a.CSE_New__c 
left join sfdc_user u3 on u3.Id = a.RSAUser__c 
left join {2} a2 on a.ParentId = a2.Id and a.processDate = a2.processDate
left join account_dates_base ad on a.Id = ad.accountId
left join brag_details bd on a.Id = bd.account_id
where a.processDate = "{0}"
""".format(processDate, USAGE_ACCOUNT_MONTHLY, SFDC_ACCOUNT))

account_df = account_df.join(sales_regions, account_df.OwnerId == sales_regions.AEOwnerId, 'left')\
                       .drop(sales_regions.AEOwnerId)
                       

account_df.createOrReplaceTempView("accounts")



# joins the account attributes for the ae, cse role names
accounts_base = spark.sql("""
select acc.*,
       urh1.RoleName account_executive_role,
       urh2.RoleName customer_success_engineer_role
from accounts acc       
left join {0} urh1 on acc.AEOwnerRoleId = urh1.UserRoleId
left join {0} urh2 on acc.CSEUserRoleId = urh2.UserRoleId
""".format(USER_ROLE_HIERARCHY))


# customer win date calculations
account_win_dates = spark.sql("""
select acc.account_id,
       round(datediff(snapshot_date, acc.customer_start_date)/365,2) customer_age_years,
       round((datediff(snapshot_date, acc.customer_start_date)/365)*12,2) customer_age_months,
       datediff(snapshot_date, acc.customer_start_date) customer_age_days
from accounts acc
""")

accounts_base.createOrReplaceTempView("accounts_base")
account_win_dates.createOrReplaceTempView("account_win_dates")

# COMMAND ----------

# consolidate the account attributes

account_attribs = spark.sql("""
select ab.*,
       acc.LastSAEngagedName last_solution_architect_engaged,
       dt.fiscal_year_month customer_win_month, 
       dt.fiscal_year_quarter customer_win_quarter,
       dt.fiscal_year customer_win_fiscal_year,
       ad.customer_age_years,
       ad.customer_age_months,
       ad.customer_age_days
from accounts_base ab        
left join {0} dt on ab.customer_start_date = dt.date
left join {1} acc on ab.account_id = acc.accountId
left join account_win_dates ad on ab.account_id = ad.account_id
""".format(DATE_DIM, BI_ACCOUNT_DIM))

# COMMAND ----------


account_attribs.write.mode('overwrite').format("delta").option("overwriteSchema", "true").save(ACCOUNT_ATTRIBS_STAGE_LOCATION)

# COMMAND ----------

account_attribs = spark.read.format("delta").load(ACCOUNT_ATTRIBS_STAGE_LOCATION)

# COMMAND ----------

account_attrib_count= account_attribs.count()
print(account_attrib_count)

# COMMAND ----------

# AE user, role ids
spark.sql("""
select distinct
       u.Name as AEName,
       u.UserRoleId AEUserRoleId,
       a.OwnerId as AEOwnerId
from {1} a 
left join sfdc_user u on u.Id = a.OwnerId
where a.processDate = "{0}"
""".format(processDate, SFDC_ACCOUNT)).createOrReplaceTempView("account_ae_dim")

spark.sql("""
select usr.Id,
       usr.userroleid,
       usr.name,
       usr.title,
       usr.email,
       usr.department
from sfdc_user usr
where isActive = 'true'
and lower(usr.name) not like '%logfood%'
and usr.Email like '%databricks.com'
""").createOrReplaceTempView("users")

spark.sql("""
select AEName,
       AEOwnerId,
       AEUserRoleId
from account_ae_dim
""").createOrReplaceTempView("AEUserRoles")

# pulls hierarchy of users from user_role_hierarchy table
spark.sql("""
with 
firstLevelManagers (
select ae.*,
       urh.ParentRoleId AEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {1} urh
join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
),

base (
select  distinct
        flm.AEOwnerId,
        flm.AEUserRoleId,
        u1.name level1Name,
        u1.id level1Id,
        u2.name level2Name,
        u2.id level2Id,
        u3.name level3Name,
        u3.id level3Id,        
        u4.name level4Name,
        u4.id level4Id,        
        u5.name level5Name,
        u5.id level5Id,        
        u6.name level6Name,
        u6.id level6Id,
        u7.name level7Name
from firstLevelManagers flm
join users u on flm.AEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u7.name = "Ron Gabrisko"
and u6.name not in ("Michael Hoff")
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
and flm.RoleLevel = 1
and flm.RoleDepth = 1
order by 1
)

select distinct b.AEOwnerId,
                b.level1Name AE, 
                b.level2Name sales_manager, 
                b.level3Name sales_leader
from base b
join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.level1Name
""".format(processDate, USER_ROLE_HIERARCHY)).createOrReplaceTempView("user_hierarchy_level1")

spark.sql("""
with 
firstLevelManagers (
select ae.*,
       urh.ParentRoleId AEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {1} urh
join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
),

base (
select  distinct
        flm.AEOwnerId,
        flm.AEUserRoleId,
        u1.name level1Name,
        u1.id level1Id,
        u2.name level2Name,
        u2.id level2Id,
        u3.name level3Name,
        u3.id level3Id,        
        u4.name level4Name,
        u4.id level4Id,        
        u5.name level5Name,
        u5.id level5Id,        
        u6.name level6Name,
        u6.id level6Id,
        u7.name level7Name
from firstLevelManagers flm
join users u on flm.AEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u7.name = "Ron Gabrisko"
and u6.name not in ("Michael Hoff")
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
and flm.RoleLevel = 2
and flm.RoleDepth = 1
order by 1
)

select distinct b.AEOwnerId,
                b.level2Name AE, 
                b.level3Name sales_manager, 
                b.level4Name sales_leader
from base b
join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.level2Name
""".format(processDate, USER_ROLE_HIERARCHY)).createOrReplaceTempView("user_hierarchy_level2")


spark.sql("""
with 

firstLevelManagers (
select ae.*,
       urh.ParentRoleId AEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {1} urh
join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
),

base (
select  distinct
        flm.AEOwnerId,
        flm.AEUserRoleId,
        u1.name level1Name,
        u1.id level1Id,
        u2.name level2Name,
        u2.id level2Id,
        u3.name level3Name,
        u3.id level3Id,        
        u4.name level4Name,
        u4.id level4Id,        
        u5.name level5Name,
        u5.id level5Id,        
        u6.name level6Name,
        u6.id level6Id,
        u7.name level7Name
from firstLevelManagers flm
join users u on flm.AEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u7.name = "Ron Gabrisko"
and u6.name not in ("Michael Hoff")
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
and flm.RoleLevel = 3
and flm.RoleDepth = 1
order by 1
)

select distinct b.AEOwnerId,
                b.level3Name AE, 
                b.level4Name sales_manager, 
                b.level5Name sales_leader
from base b
join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.level3Name
""".format(processDate,USER_ROLE_HIERARCHY)).createOrReplaceTempView("user_hierarchy_level3")

spark.sql("""
with 

firstLevelManagers (
select ae.*,
       urh.ParentRoleId AEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {1} urh
join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
),

base (
select  distinct
        flm.AEOwnerId,
        flm.AEUserRoleId,
        u1.name level1Name,
        u1.id level1Id,
        u2.name level2Name,
        u2.id level2Id,
        u3.name level3Name,
        u3.id level3Id,        
        u4.name level4Name,
        u4.id level4Id,        
        u5.name level5Name,
        u5.id level5Id,        
        u6.name level6Name,
        u6.id level6Id,
        u7.name level7Name
from firstLevelManagers flm
join users u on flm.AEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u7.name = "Ron Gabrisko"
and u6.name not in ("Michael Hoff")
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
and flm.RoleLevel = 4
and flm.RoleDepth = 1
order by 1
)

select distinct b.AEOwnerId,
                b.level4Name AE, 
                b.level5Name sales_manager, 
                b.level6Name sales_leader
from base b
join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.level4Name
""".format(processDate, USER_ROLE_HIERARCHY)).createOrReplaceTempView("user_hierarchy_level4")

spark.sql("""
with 

firstLevelManagers (
select ae.*,
       urh.ParentRoleId AEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {1} urh
join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
),

base (
select  distinct
        flm.AEOwnerId,
        flm.AEUserRoleId,
        u1.name level1Name,
        u1.id level1Id,
        u2.name level2Name,
        u2.id level2Id,
        u3.name level3Name,
        u3.id level3Id,        
        u4.name level4Name,
        u4.id level4Id,        
        u5.name level5Name,
        u5.id level5Id,        
        u6.name level6Name,
        u6.id level6Id,
        u7.name level7Name
from firstLevelManagers flm
join users u on flm.AEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u7.name = "Ron Gabrisko"
and u6.name not in ("Michael Hoff")
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
and flm.RoleLevel = 5
and flm.RoleDepth = 1
order by 1
)

select distinct b.AEOwnerId,
                b.level5Name AE, 
                b.level6Name sales_manager, 
                b.level7Name sales_leader
from base b
join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.level5Name
""".format(processDate, USER_ROLE_HIERARCHY)).createOrReplaceTempView("user_hierarchy_level5")

# final sales hierarchy 
sales_leaders = spark.sql("""
select distinct AEOwnerId,
                AE, 
                sales_manager, 
                sales_leader
from user_hierarchy_level1
where AE is not null
union
select distinct AEOwnerId,
                AE, 
                sales_manager, 
                sales_leader
from user_hierarchy_level2
where AE is not null
union
select distinct AEOwnerId,
                AE, 
                sales_manager, 
                sales_leader
from user_hierarchy_level3
where AE is not null
union
select distinct AEOwnerId,
                AE, 
                sales_manager, 
                sales_leader
from user_hierarchy_level4
where AE is not null
union
select distinct AEOwnerId,
                AE, 
                sales_manager, 
                sales_leader
from user_hierarchy_level5
where AE is not null
""")

# COMMAND ----------

sales_leaders.write.mode('overwrite').format("delta").option("overwriteSchema", "true").save(SALES_LEADERS_STAGE_LOCATION)


# COMMAND ----------

sales_leaders = spark.read.format("delta").load(SALES_LEADERS_STAGE_LOCATION)

# COMMAND ----------

sales_leaders.count()

# COMMAND ----------

sales_leaders.createOrReplaceTempView("sales_leaders")

# COMMAND ----------

sales_check_df=spark.sql("""
with base (
select AEOwnerId, count(*) cnt
from sales_leaders
group by 1
having cnt > 1
),
filter_dups as (
select  s.* --/*+ BROADCAST(b) */
from sales_leaders s
join base b on s.aeownerid = b.aeownerid
where 
--sales_manager not in () and
s.AEOwnerId not in ('0053f000000WgPwAAK') and 
 sales_leader not in ("Harris Thayer")
),

second_check as (
  select aeownerid, count(*) cnt
  from filter_dups
  group by 1
  having cnt > 1
)
select  s.* --/*+ BROADCAST(b) */
from sales_leaders s
join second_check b on s.aeownerid = b.aeownerid
""")
if len(sales_check_df.head(1)) > 0:
  display(sales_check_df)
#, "Richard Wylie"


# COMMAND ----------

#todo: revisit the role hierarchy logic
sales_leaders = spark.sql("""
with base as (
  select *,
  row_number() over (partition by AEOwnerId order by AE) row_num
  from sales_leaders
)
select * from base where row_num = 1""").drop("row_num")

# COMMAND ----------

account_sales_hierarchy = account_attribs.join(sqlf.broadcast(sales_leaders), (account_attribs.OwnerId==sales_leaders.AEOwnerId) & (account_attribs.account_executive==sales_leaders.AE), 'left')\
                                         .drop(sales_leaders.AE)\
                                         .drop(account_attribs.AEOwnerRoleId)\
                                         .drop(account_attribs.CSEUserRoleId) \
                                        .drop(account_attribs.OwnerId)

# COMMAND ----------

account_sales_hierarchy_count = account_sales_hierarchy.count()
print(account_sales_hierarchy_count)

# COMMAND ----------

if account_sales_hierarchy_count == account_attrib_count:
  pass
else:
  account_sales_hierarchy.createOrReplaceTempView("account_sales_hierarchy")
  display(sql("""with dups as (
                  select account_id, count(*) cnt
                  from account_sales_hierarchy
                  group by account_id
                  having cnt > 1
                  )
                  select distinct sales_manager, sales_leader from account_sales_hierarchy where account_id in (select account_id from dups)"""))
  raise Exception("counts mismatch after including the sales hierarchy")
  #print("counts mismatch after including the sales hierarchy")

# COMMAND ----------

# CS levels 
#TODO: review all the managers that are exempted

spark.sql("""
with 
users (
select usr.Id,
       usr.userroleid,
       usr.name,
       usr.title,
       usr.email,
       usr.department
from sfdc_user usr
where isActive = true
and lower(usr.name) not like '%logfood%'
),

base (
select distinct customer_success_engineer   
from accounts
where customer_success_engineer is not null
order by 1
),

CSEUserRoles (
select customer_success_engineer CSE,
       usr.Id CSEOwnerId,
       usr.UserRoleId CSEUserRoleId,
       usr.Email,
       usr.Department,
       usr.Name
from users usr
join base b on usr.Name = b.customer_success_engineer
where usr.Email like '%databricks.com'
),


firstLevelManagers (
select cse.*,
       urh.ParentRoleId CSEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {1} urh
join CSEUserRoles cse on urh.UserRoleId = cse.CSEUserRoleId
)

select  distinct
        u1.name level1Name,
        u2.name level2Name,
        u3.name level3Name,
        u4.name level4Name,        
        u5.name level5Name,
        u6.name level6Name,
        u7.name level7Name
from firstLevelManagers flm
join users u on flm.CSEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u6.name in ("Nick Cochran", "Carrie Anderson", "Unassigned_VP_CS")
and u7.name = "Hatim Shafique"
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
order by 1
""".format(processDate, USER_ROLE_HIERARCHY)).createOrReplaceTempView("CSELevels")


cse = spark.sql("""
with base (
select distinct customer_success_engineer CSE     
from accounts
where customer_success_engineer is not null
order by 1
)

select * from (

select distinct 
       b.CSE,
       cse.level2Name Manager,
       cse.level3Name Leader
from base b
join CSELevels cse on b.CSE = cse.level1Name

union

select distinct 
       b.CSE,
       cse.level3Name Manager,
       cse.level4Name Leader
from base b
join CSELevels cse on b.CSE = cse.level2Name
where cse.level3Name not in ("Kunal Gaurav", "Anurag Mynam", "Matthew Schwalm", "Unassigned_CSE_AMER_Enterprise_Strategic_East_Central", "Andrew Hoogeveen", "Unassigned_CSE_AMER_Enterprise_Strategic_West", "Unassigned_Ent_East_OHV_Manager")
union

select distinct 
       b.CSE,
       cse.level4Name Manager,
       cse.level5Name Leader
from base b
join CSELevels cse on b.CSE = cse.level3Name
where cse.level4Name != "Nishit Jain"

union

select distinct 
       b.CSE,
       cse.level5Name Manager,
       cse.level6Name Leader
from base b
join CSELevels cse on b.CSE = cse.level4Name
where cse.level5Name != "Nishit Jain"
union

select distinct 
       b.CSE,
       cse.level6Name Manager,
       cse.level7Name Leader
from base b
join CSELevels cse on b.CSE = cse.level5Name

)
order by CSE
""")

cse = cse.withColumnRenamed("Manager", "customer_success_manager")\
         .withColumnRenamed("Leader", "customer_success_leader")

cse.createOrReplaceTempView("cse")

# COMMAND ----------

cse.write.mode('overwrite').format("delta").option("overwriteSchema", "true").save(CSE_STAGE_LOCATION)


# COMMAND ----------

cse = spark.read.format("delta").load(CSE_STAGE_LOCATION)
cse.createOrReplaceTempView('cse')

# COMMAND ----------

cse.count()

# COMMAND ----------

cse = spark.sql("""
select *
from cse
where customer_success_manager not in ('')
and customer_success_leader not in ('')
""")
cse.createOrReplaceTempView('cse')

# COMMAND ----------

cse.createOrReplaceTempView("cse")

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from cse 
# MAGIC where cse in (
# MAGIC  select cse from (
# MAGIC     select cse, count(*) cnt
# MAGIC     from cse
# MAGIC     group by cse
# MAGIC     having cnt > 1)
# MAGIC   )

# COMMAND ----------

usage_df = spark.table(USAGE_AGGORDER_MONTHLY)
multi_cloud_df = usage_df. \
                 filter("platform IS NOT NULL"). \
                 groupBy("accountId"). \
                 agg(sqlf.countDistinct(sqlf.col("platform")).alias("counter")).filter("counter > 1"). \
                 drop("counter"). \
                 withColumn("is_multi_cloud", sqlf.lit(True)). \
                 withColumnRenamed("accountId", "account_id")

# COMMAND ----------

account_final = account_sales_hierarchy.join(sqlf.broadcast(cse), account_sales_hierarchy.customer_success_engineer==cse.CSE, 'left')\
                                       .drop(cse.CSE)\
                                       .join(multi_cloud_df, "account_id", "left")
#.drop(account_sales_hierarchy.AEOwnerId) \

# COMMAND ----------

account_final_count = account_final.count()
print(account_final_count)

# COMMAND ----------

if account_sales_hierarchy_count == account_final_count:
   pass
else:
  raise Exception("counts mismatch after including the cs hierarchy")
  #print("counts mismatch after including the cs hierarchy")

# COMMAND ----------

if account_final_count == 0:
  raise Exception("empty account_final dataframe for processDate: ", processDate)

# COMMAND ----------

dup_df = account_final.groupBy(["account_id","snapshot_date"]).count().filter("count > 1")

# COMMAND ----------

duplicate_count = dup_df.count()
print("Count of duplicate accounts : " + str(duplicate_count))


# COMMAND ----------

if duplicate_count>1:
  display(dup_df)

# COMMAND ----------

if duplicate_count > 0:
  raise Exception("Duplicates in account_final dataframe for processDate: ", processDate)

# COMMAND ----------

# if environment == 'development':
#   ACCOUNT_LOCATION = "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/test/cda_accounts"
#   # elif environment == 'both':
#   #   ACCOUNT_LOCATION = "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/prod/tables/cda_accounts/"
#   #   ACCOUNT_LOCATION_PROD = "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/prod/core_accounts"
# else:
#   ACCOUNT_LOCATION = "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/prod/core_accounts"

# COMMAND ----------

# if writeMode == 'backfill':
#   TEMP_DIR = 'wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/test/temp/temp_account'
#   account_final.write.mode('overwrite').partitionBy("snapshot_date").format("delta").option("overwriteSchema", "true").save(TEMP_DIR)  
#   if environment == 'both':
#     account_final.write \
#       .format("delta") \
#       .mode("overwrite") \
#       .option("replaceWhere", "snapshot_date = '{0}'".format(processDate)) \
#       .save(ACCOUNT_LOCATION_PROD)

#   account_final = spark.sql("select * from delta.`{}`".format(TEMP_DIR))

# COMMAND ----------

account_final.printSchema()

# COMMAND ----------

account_final = account_final.withColumn("snapshot_date",sqlf.to_date(sqlf.col("snapshot_date")))

# COMMAND ----------

print(f"Writing data to the table {CATALOG}.{CORE_SCHEMA}.{CORE_ACCOUNTS_TABLE}")
if writeMode == 'append':
  account_final.write.mode('append').format("delta").option("overwriteSchema", "true").saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_ACCOUNTS_TABLE))
elif writeMode == 'overwrite':
  account_final.write \
      .format("delta") \
      .mode("overwrite") \
      .option("mergeSchema", "true") \
      .option("replaceWhere", "snapshot_date = '{0}'".format(processDate)) \
      .saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_ACCOUNTS_TABLE))
else:
  raise exception("Writemode is invalid! Please give valid writemode!")

# COMMAND ----------

# if environment in ('development', 'test'):
#   if writeMode == 'append':
#     account_final.write.mode('append').format("delta").option("overwriteSchema", "true").saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_ACCOUNTS_TABLE))
#   elif writeMode == 'overwrite':
#     account_final.write \
#         .format("delta") \
#         .mode("overwrite") \
#         .option("replaceWhere", "snapshot_date = '{0}'".format(processDate)) \
#         .saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_ACCOUNTS_TABLE))
#   else:
#     raise exception("Writemode is invalid! Please give valid writemode!")
# else:
#   if writeMode == 'append':
#     account_final.write.mode('append').format("delta").option("overwriteSchema", "true").save(ACCOUNT_LOCATION)
#   elif writeMode == 'overwrite':
#     account_final.write \
#         .format("delta") \
#         .mode("overwrite") \
#         .option("replaceWhere", "snapshot_date = '{0}'".format(processDate)) \
#         .saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_ACCOUNTS_TABLE))
#   else:
#     raise exception("Writemode is invalid! Please give valid writemode!")
  

# COMMAND ----------

import json
if writeMode == 'backfill':
  dbutils.notebook.exit((json.dumps({
  "status": "OK",
  "data" : {
            "location" : TEMP_DIR
           }
  })
   )
  )
else:  
  dbutils.notebook.exit(json.dumps({
    "status": "OK"
  }))
