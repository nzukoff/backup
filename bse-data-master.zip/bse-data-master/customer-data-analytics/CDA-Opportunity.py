# Databricks notebook source
# MAGIC %md
# MAGIC # Generates core_opportunity table for Customer Data Analytics

# COMMAND ----------

# MAGIC %run "./CDA-Config"

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql import functions as sqlf
from pyspark.sql import Window
from datetime import datetime, timedelta
import json
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'development') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

dbutils.widgets.text("writeMode", 'overwrite') # Awlays overwrite, only when initiating the table we should append
writeMode = dbutils.widgets.get("writeMode")
print(writeMode)

# COMMAND ----------

dbutils.widgets.text("processDate", datetime.now().strftime("%Y-%m-%d"))
processDate = dbutils.widgets.get("processDate")
print("processing :", processDate)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  create_uc_schema(CATALOG, CORE_SCHEMA)
  pprint(config["development"])
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

prev_week_date = str((datetime.strptime(processDate, "%Y-%m-%d") -timedelta(7)).date())

# COMMAND ----------

opp_lineitems = spark.sql("""
with base (
select  opportunityid,
        ProductCode,
        case when Product_Family__c = "License" then coalesce(TotalPrice, 0) else 0 end as license_total_price,
        case when Product_Family__c = "Support" then coalesce(TotalPrice, 0) else 0 end as support_total_price,
        case when Product_Family__c in ("Training", 
                                        "Training - Non Customer", 
                                        "Training - Recurring", 
                                        "Professional Services", 
                                        "Professional Services - Non Customer", 
                                        "Professional Services - Recurring") then coalesce(TotalPrice, 0) else 0 end as services_total_price,
        case when Product_Family__c in ("Expense", "Usage", "Run Rate") then coalesce(TotalPrice, 0) else 0 end as other_total_price,
        case when Product_Family__c = 'License' then 1 else 0 end as license_count,
        case when Product_Family__c = 'Support' then 1 else 0 end as support_count
from {1} oli
where processDate = "{0}" 
)

select opportunityid,
       sum(license_total_price) license_total_price,
       sum(support_total_price) support_total_price,
       sum(services_total_price) services_total_price,
       sum(other_total_price) other_total_price,
       sum(license_total_price + support_total_price + services_total_price + other_total_price) total_price,
       case when sum(license_count) > 0 then True else False end as is_license,
       case when sum(license_count) > 0 then True else False end as is_support
from base
group by 1
""".format(processDate, SFDC_OPP_LINE_ITEM))

opp_lineitems.createOrReplaceTempView("opp_lineitems")

# COMMAND ----------

df=spark.sql("select max(snapshot_date) from {2} where snapshot_date <= '{0}' and snapshot_date >='{1}'".format(processDate,prev_week_date,CORE_ACCOUNTS))

if df.dropna().count() == 0:
  raise Exception("Empty {0} dataframe for last 7 days of process date: {1}".format(CORE_ACCOUNTS, processDate))

# COMMAND ----------

initialAmount_ValidStage = spark.sql("""
SELECT DISTINCT
opportunity_id, 
FIRST_VALUE(amount) over (partition by opportunity_id order by snapshot_date) as initial_amount_at_validate_date
from {0}
where validate_stage_start_date is not null
""".format(CORE_OPPORTUNITY))

initialAmount_ValidStage.createOrReplaceTempView("initialAmount_ValidStage")

# COMMAND ----------

initialAmount_ValidStage_Check = spark.sql("""
SELECT DISTINCT
opportunity_id
from {0}
where validate_stage_start_date is not null
""".format(CORE_OPPORTUNITY))

initialAmount_ValidStage_Check.createOrReplaceTempView("initialAmount_ValidStage_Check")

# COMMAND ----------

if initialAmount_ValidStage.count() != initialAmount_ValidStage_Check.count():
  raise Exception("Opportunity ID count mismatch in core_opportunity")

# COMMAND ----------

firstPrimary_Contact = spark.sql("""
  SELECT 	
  opportunity_id,	
  first_primary_contact_id,	
  CONCAT(FirstName,' ', LastName) AS first_primary_contact	
  FROM	
  (	
    SELECT 
    p.ContactId AS first_primary_contact_id,
    p.IsPrimary AS is_primary,
    p.OpportunityId AS opportunity_id,
    CONCAT(q.FirstName,' ', q.LastName) AS name,
    q.FirstName, 
    q.LastName,
    row_number() OVER (PARTITION BY p.OpportunityId ORDER BY p.IsPrimary DESC, p.CreatedDate ASC) AS rn
    FROM {1} p
    LEFT JOIN {2} q ON p.ContactId = q.Id AND p.processDate = q.processDate
    WHERE p.processDate = '{0}') a
  WHERE a.rn = 1	
""".format(processDate, SFDC_OPPCONTACTROLE, SFDC_CONTACT))

firstPrimary_Contact.createOrReplaceTempView("firstPrimary_Contact")

# COMMAND ----------

opp_lineitems_upd = opp_lineitems.join(initialAmount_ValidStage, opp_lineitems.opportunityid == initialAmount_ValidStage.opportunity_id, 'left') \
                                  .join(firstPrimary_Contact, opp_lineitems.opportunityid == firstPrimary_Contact.opportunity_id, 'left') \
                                  .drop(initialAmount_ValidStage.opportunity_id) \
                                  .drop(firstPrimary_Contact.opportunity_id)

opp_lineitems_upd.createOrReplaceTempView("opp_lineitems_upd")

# COMMAND ----------

# opp_lineitems_upd = opp_lineitems_upd.join(firstPrimary_Contact, opp_lineitems_upd.opportunityid == firstPrimary_Contact.opportunity_id, 'left')\
#                                   .drop(firstPrimary_Contact.opportunity_id)

# opp_lineitems_upd.createOrReplaceTempView("opp_lineitems_upd") 

# COMMAND ----------

cda_account_snap = spark.sql("""
select *
from {1}
where snapshot_date = (select max(snapshot_date) from {1} where snapshot_date <= '{0}')
""".format(processDate, CORE_ACCOUNTS))

# COMMAND ----------

cda_account_snap.createOrReplaceTempView("cda_account_snap")

# COMMAND ----------

if cda_account_snap.count() == 0:
    dbutils.notebook.exit(json.dumps({
        "status": "cda_account_snap is empty"
    }))
    raise Exception("cda_account_snap is empty")

# COMMAND ----------

cda_opps_staging = spark.sql("""
with opps (
select  Id opportunity_id,
        accountId account_id,
        platform_type__c platform,
        Name as opportunity_name,
        Type as opportunity_type,
        case when lower(StageName) like 'closed%' then 'closed'
             when lower(StageName) = 'disqualified' then 'closed'
             when lower(StageName) = 'signed' then 'signed'
             else 'open'
        end as opportunity_status,             
        StageName as opportunity_stage,
        region__c opportunity_region,
        role_region__c opportunity_role_region,
        region_level_1__c opportunity_region_level_1,
        region_level_2__c opportunity_region_level_2,
        region_level_3__c opportunity_region_level_3,
        
        Description opportunity_description,
    
        Amount amount,
        Subscription_Amount__c AS subscription_amount,
        Subscription_Total_RH__c AS subscription_total,
        Annualized_T3M_ARR_Run_Rate__c annualized_t3m_arr_run_rate,
        T3M_ARR__c t3m_arr,
        grr__c gross_renewal_rate,
        coalesce(arr_renewal_amount__c,0) available_to_renew,
        coalesce(actual_renewed_arr__c,0) renewed_available_to_renew,
        
        Created_By_Role__c created_by_role,
        cast(createddate as date) created_date,
        Commit_Start_Date__c commit_start_date,
        Original_Expected_Renewal_Date__c original_expected_renewal_date,
        Renewal_Date__c renewal_date,
        Start_Date__c start_date,
        End_Date__c end_date,
        CloseDate close_date,
        Cancelation_Date__c cancellation_date,
        effective_renewal_date__c effective_renewal_date,
        Renewal_Quarter__c renewal_quarter,
        Prospecting_Stage_Date_Stamp__c prospecting_stage_start_date,
        POC_Scoping_Stage_Date_Stamp__c poc_scoping_stage_start_date,
        Proposal_Stage_Date_Stamp__c proposal_stage_start_date,
        Validate_Stage_Date_Stamp__c validate_stage_start_date,
        Evaluation_Stage_Date_Stamp__c evaluation_stage_start_date,
        Negotiation_Stage_Date_Stamp__c negotiation_stage_start_date,
        Signed_Stage_Date_Stamp__c signed_stage_start_date,
        
        Latest_Opp__c latest_opportunity,
        CSMgr_GRR__c cs_manager_grr,
        Contract_Opp_Flag__c contract_opportunity_flag,
        Opportunity_URL__c opportunity_url,
        BRAG_Number__c brag_number,
        BRAG_Status__c brag_status,
        Color_code_brag__c brag_color_code,
        Vertical__c vertical,
        Cloned_By_Opportunity__c cloned_by_opportunity,
        churn_amount__c dollar_churn,
        
        Sales_Plays__c sales_play,
        Horizontal_Solution__c horizonatal_solution,
        Upsell_Type__c upsell_type,
        NextStep opportunity_next_step,
        Probability opportunity_probability,
        ForecastCategory forecast_category,
        lossreason__c lost_reason,
        lossreasondetail__c lost_reason_detail,
    
        LeadSource AS lead_source,
        Opportunity_Sourced_By__c AS opportunity_sourced_by,
        Opportunity_Campaign_Source__c AS opportunity_campaign_source,
        Campaign_Source_Member_Id__c AS opportunity_campaign_source_member_id,
        
        Churn_Reason__c churn_reason,
        Churn_Cause_Sub_Reason__c churn_cause_sub_reason,
        Churn_Cause_Reason__c churn_cause_reason,
        Why_At_Risk__c why_at_risk,
        churn_mitigation_plan__c churn_mitigation_plan,
        churn_risk_next_steps__c churn_risk_next_steps,
        churn_outcome_reason__c churn_outcome_reason,
        churn_outcome_sub_reason__c churn_outcome_sub_reason,
        SDR_Responsible_For__c sales_development_representative_id,
        OwnerId opportunity_owner_id,
        Sales_Ops_Validated__c sales_ops_validated,        
        processDate snapshot_date,

        Entered_Pipeline_Date__c as pipeline_entered_date,
        aws_marketplace_deal__c as aws_marketplace_deal
        
from {1} 
where processDate = "{0}" 
)

select opp.*,
       case when opportunity_stage in ('Signed', 'Closed Won') 
             and opportunity_type in ('Pilot', 'New Business', 'Upsell')
             and platform <> 'Azure – P3 Only'
             and sales_ops_validated = True
            then True
       else False
       end as sales_compensation_booking_flag,
        
       acc.account_name,
       acc.account_status,
       acc.account_executive,
       acc.AEOwnerId,
       acc.customer_success_engineer,
       acc.resident_solution_architect,
       acc.customer_success_manager,
       acc.customer_success_leader,
       
       acc.subregion_level_1 account_subregion_level_1,
       acc.subregion_level_2 account_subregion_level_2,
       
       acc.sales_business_unit account_sales_business_unit,
       acc.sales_region account_sales_region,
       acc.sales_subregion_level_1 account_sales_subregion_level_1,
       acc.sales_subregion_level_2 account_sales_subregion_level_2,
       acc.sales_subregion_level_3 account_sales_subregion_level_3,

       dt1.fiscal_year start_year,
       dt1.fiscal_year_month start_month,
       dt1.fiscal_year_quarter start_quarter,
       dt1.week_of_fiscal_year start_week,

       dt2.fiscal_year created_year,
       dt2.fiscal_year_month created_month,
       dt2.fiscal_year_quarter created_quarter,
       dt2.week_of_fiscal_year created_week,

       dt3.fiscal_year close_year,
       dt3.fiscal_year_month close_month,
       dt3.fiscal_year_quarter close_quarter,
       dt3.week_of_fiscal_year close_week,

       dt4.fiscal_year end_year,
       dt4.fiscal_year_month end_month,
       dt4.fiscal_year_quarter end_quarter,
       dt4.week_of_fiscal_year end_week,
       
       dt5.fiscal_year renewal_year,
       dt5.fiscal_year_month renewal_month,
       dt5.fiscal_year_quarter renewal_quarter_date,
       dt5.week_of_fiscal_year renewal_week,
       
       dt6.fiscal_year effective_renewal_year,
       dt6.fiscal_year_month effective_renewal_month,
       dt6.fiscal_year_quarter effective_renewal_quarter,
       dt6.week_of_fiscal_year effective_renewal_week,
       
       dt7.fiscal_year cancellation_year,
       dt7.fiscal_year_month cancellation_month,
       dt7.fiscal_year_quarter cancellation_quarter,
       dt7.week_of_fiscal_year cancellation_week
       
from opps opp
left join cda_account_snap acc on opp.account_id = acc.account_id
left join {2} dt1 on opp.commit_start_date = dt1.date
left join {2} dt2 on opp.created_date = dt2.date
left join {2} dt3 on opp.close_date = dt3.date
left join {2} dt4 on opp.end_date = dt4.date
left join {2} dt5 on opp.renewal_date = dt5.date
left join {2} dt6 on opp.effective_renewal_date = dt6.date
left join {2} dt7 on opp.cancellation_date = dt7.date
left join {2} dt8 on opp.snapshot_date = dt8.date
""".format(processDate, SFDC_OPPORTUNITY, DATE_DIM)). \
withColumn("account_id", sqlf.when((sqlf.col("opportunity_role_region").isin('AMER', 'LATAM')) & (sqlf.col("account_id").isNull()), "0013f000005RwT9AAK"). \
                         when((sqlf.col("opportunity_role_region") == 'EMEA') & (sqlf.col("account_id").isNull()), "0013f0000063xxLAAQ"). \
                         when((sqlf.col("opportunity_role_region") == 'APJ') & (sqlf.col("account_id").isNull()), "0013f0000063xxQAAQ"). \
                         otherwise(sqlf.col("account_id")))

# abs(round(CASE WHEN contract_opportunity_flag = False THEN 0 
#                       WHEN opportunity_stage not in ('Closed Won', 'Closed Lost') THEN available_to_renew * (cs_manager_grr - 1) 
#                       WHEN (available_to_renew - renewed_available_to_renew) > 0 THEN 0 
#                       ELSE (renewed_available_to_renew - available_to_renew) END,2)) dollar_churn_calculated,

# COMMAND ----------

cda_opps_staging.createOrReplaceTempView("cda_opps_staging")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) --count(distinct opportunity_owner_id) -- 848
# MAGIC from cda_opps_staging
# MAGIC -- select distinct 
# MAGIC --        account_executive as owner,
# MAGIC --        sales_manager,
# MAGIC --        sales_leader
# MAGIC -- from cda_account_snap 

# COMMAND ----------

df=spark.sql("select max(processDate) from {2} where processDate <= '{0}' and processDate >='{1}'".format(processDate,prev_week_date, SFDC_RTM))
if df.dropna().count() == 0:
  raise Exception("Empty {0} dataframe for last 7 days of process date: {1}".format(SFDC_RTM, processDate))

# COMMAND ----------

opp_sales_regions = spark.sql("""
with opp_owners (
select distinct
       opp.Id opportunityId,
       opp.OwnerId OppOwnerId,
       u.UserRoleId OppOwnerRoleId
from {1} opp
left join {2} u on opp.OwnerId = u.Id and opp.processDate = u.processDate
where opp.processDate = "{0}"
)
select distinct
       usr.opportunityId,
       usr.OppOwnerId, 
       Role_Name__c opportunity_owner_role,
       Region_Level_1__c opportunity_sales_subregion_level_1,
       Region_Level_2__c opportunity_sales_subregion_level_2,
       Region_Level_3__c opportunity_sales_subregion_level_3
from {3} rtm
join opp_owners usr on rtm.Role_ID__c = usr.OppOwnerRoleId
where processDate = (select max(processDate) from {3} where processDate <= "{0}") and Consider_Role_Under_Forecast__c and not rtm.IsDeleted 
""".format(processDate, SFDC_OPPORTUNITY, SFDC_USER, SFDC_RTM))

# COMMAND ----------

opp_owner_hierarchy = spark.sql("""
with sales_hierarchy (
select distinct 
       account_executive as owner,
       AEOwnerId,
       sales_manager,
       sales_leader
from cda_account_snap       
),

users (
select usr.Id,
       usr.Name as owner,
       sh.sales_manager,
       sh.sales_leader
from {1} usr
left join sales_hierarchy sh on usr.Name = sh.owner and usr.Id = sh.AEOwnerId
where processDate = "{0}"
)

select c.opportunity_id,
       c.opportunity_owner_id,
       u.owner opportunity_owner,
       u.sales_manager,
       u.sales_leader
from cda_opps_staging c
left join users u on c.opportunity_owner_id = u.Id
""".format(processDate, SFDC_USER))

opp_owner_hierarchy.count()

# COMMAND ----------

if cda_opps_staging.count() == 0:
    dbutils.notebook.exit(json.dumps({
        "status": "cda_opps_staging is empty"
    }))
    raise Exception("cda_opps_staging is empty")

# COMMAND ----------

cda_opps_staging = cda_opps_staging.join(opp_owner_hierarchy, (cda_opps_staging.opportunity_id == opp_owner_hierarchy.opportunity_id) &\
                                                              (cda_opps_staging.opportunity_owner_id == opp_owner_hierarchy.opportunity_owner_id) ,\
                                                    
                                                    'left')\
                                   .drop(opp_owner_hierarchy.opportunity_id)\
                                   .drop(opp_owner_hierarchy.opportunity_owner_id)

# COMMAND ----------

cda_opps = cda_opps_staging.join(opp_lineitems_upd, cda_opps_staging.opportunity_id == opp_lineitems_upd.opportunityid, 'left')\
                           .drop(opp_lineitems_upd.opportunityid)

# COMMAND ----------

cda_opps.createOrReplaceTempView("cda_opps")

# COMMAND ----------

cda_opps_final = spark.sql("""
select *,
       case when sales_compensation_booking_flag = True then (license_total_price + support_total_price)
            else 0
       end as sales_compensation_booking
FROM cda_opps""")

cda_opps_final = cda_opps_final.drop("sales_compensation_booking_flag")

# COMMAND ----------

sdr_user = spark.sql("""SELECT
                        Id AS sales_development_representative_id,
                        Name AS sales_development_representative
                        FROM {1}
                        WHERE processDate = "{0}"
                     """.format(processDate, SFDC_USER))

# COMMAND ----------

cda_opps_final = cda_opps_final.join(opp_sales_regions, (cda_opps_final.opportunity_id == opp_sales_regions.opportunityId) & \
                                                        (cda_opps_final.opportunity_owner_id == opp_sales_regions.OppOwnerId), \
                                                    'left')\
                               .drop(opp_sales_regions.opportunityId) \
                               .drop(opp_sales_regions.OppOwnerId) \
                               .join(sdr_user, "sales_development_representative_id", "left") \
                               .drop("sales_development_representative_id")

# COMMAND ----------

cda_opps_final.count()

# COMMAND ----------

dup_df = cda_opps_final.groupBy(["opportunity_id","snapshot_date"]).count().filter("count > 1")
duplicate_count = dup_df.count()
print("Count of duplicate opportunities : " + str(duplicate_count))

# COMMAND ----------

if duplicate_count > 0:
  raise Exception("Duplicates in account_final dataframe for processDate: ", processDate)

# COMMAND ----------

print(f"Environment : {environment}, Write Mode : {writeMode}")

# COMMAND ----------

cda_opps_final = cda_opps_final.withColumn("snapshot_date",sqlf.to_date(sqlf.col("snapshot_date")))

# COMMAND ----------

print(f"Writing data to the table {CATALOG}.{CORE_SCHEMA}.{CORE_OPPORTUNITY_TABLE}")
if writeMode == 'append':
  cda_opps_final.write.mode('append').partitionBy("snapshot_date").format("delta").option("overwriteSchema", "true").saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_OPPORTUNITY_TABLE))
elif writeMode == 'overwrite':
  cda_opps_final.write \
      .format("delta") \
      .mode("overwrite") \
      .option("replaceWhere", "snapshot_date = '{0}'".format(processDate)).option("mergeSchema", "true") \
      .saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_OPPORTUNITY_TABLE))
else:
  raise exception("Writemode is invalid! Please give valid writemode!")

# COMMAND ----------


# if environment in ('development', 'test'):
#   if writeMode == 'append':
#     cda_opps_final.write.mode('append').partitionBy("snapshot_date").format("delta").option("overwriteSchema", "true").saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_OPPORTUNITY_TABLE))
#   elif writeMode == 'overwrite':
#     cda_opps_final.write \
#         .format("delta") \
#         .mode("overwrite") \
#         .option("replaceWhere", "snapshot_date = '{0}'".format(processDate)).option("mergeSchema", "true") \
#         .saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_OPPORTUNITY_TABLE))
#   else:
#     raise exception("Writemode is invalid! Please give valid writemode!")
# else:
#   if writeMode == 'append':
#     cda_opps_final.write.mode('append').partitionBy("snapshot_date").format("delta").option("overwriteSchema", "true").saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_OPPORTUNITY_TABLE))
#   elif writeMode == 'overwrite':
#     cda_opps_final.write \
#         .format("delta") \
#         .mode("overwrite") \
#         .option("replaceWhere", "snapshot_date = '{0}'".format(processDate)).option("mergeSchema", "true") \
#         .saveAsTable("{}.{}.{}".format(CATALOG, CORE_SCHEMA, CORE_OPPORTUNITY_TABLE))
#   else:
#   raise exception("Writemode is invalid! Please give valid writemode!")

# COMMAND ----------

import json
if writeMode == 'backfill':
  dbutils.notebook.exit((json.dumps({
  "status": "OK",
  "data" : {
            "location" : TEMP_DIR
           }
  })
   )
  )
else:  
  dbutils.notebook.exit(json.dumps({
    "status": "OK"
  }))

# COMMAND ----------

# opps_with_commits = spark.sql("""
# with commitContracts (
# select sfdc_account_id,
#        zab_subscription,
#        netsuite_salesorder,
#        abs(coalesce(gross_amount, net_amount)) usageCommit,
#        cast(lineItemStartDate as date) usageCommitStartDate,
#        cast(lineItemEndDate as date) usageCommitEndDate
# from bdw_dev.cloudcontracts_silver
# where lineitemCategory like "Workload%"
# )
# select opp.OppId,
#        c.zab_subscription,
#        c.netsuite_salesorder,
#        c.usageCommit,
#        c.usageCommitStartDate,
#        c.usageCommitEndDate
# from cda_opps_staging opp
# join commitContracts c on substr(opp.oppId,1,15) = c.zab_subscription and opp.accountId = c.sfdc_account_id
# """)

# opps_with_commits.createOrReplaceTempView("opps_with_commits")

# COMMAND ----------

# fuzzy_matched_opps = spark.sql("""
# with base (
# select opp.OppId,
#        opp.accountId,
#        opp.oppName,
#        opp.Amount,
#        opp.startDate,
#        opp.endDate,
#        opp.closeDate,
#        opp.contractOppFlag,
#        c.zab_subscription,
#        c.netsuite_salesorder,
#        abs(coalesce(c.gross_amount, c.net_amount)) usageCommit,
#        c.lineItemStartDate usageCommitStartDate,
#        c.lineItemEndDate usageCommitEndDate,
#        abs(datediff(c.lineItemStartDate, coalesce(opp.startDate, opp.closeDate))) as diff_threshold
# from cda_opps_staging opp
# join bdw_dev.cloudcontracts_silver c on opp.accountId = c.sfdc_account_id
# where opp.Stage = "Closed Won"
# and c.zab_subscription is null
# and c.lineitemcategory = "Workloads Commitment"
# order by c.lineitemStartDate
# ),

# base_filtered (
# select OppId,
#        OppName,
#        zab_subscription,
#        netsuite_salesorder,
#        usageCommit,
#        usageCommitStartDate,
#        usageCommitEndDate,
#        diff_threshold,
#        row_number() over(partition by netsuite_salesorder order by  diff_threshold) rno
# from base
# where diff_threshold < 30
# )

# select OppId,
#        zab_subscription,
#        netsuite_salesorder,
#        usageCommit,
#        usageCommitStartDate,
#        usageCommitEndDate
# from base_filtered 
# where rno = 1
# """)

# fuzzy_matched_opps.createOrReplaceTempView("fuzzy_matched_opps")

# COMMAND ----------

# revisit the logic, e.g.: check 0066100000SGxktAAD
# fuzzy_matched_opps_zab = spark.sql("""
# select distinct
#        coalesce(z.oppId, f.oppId) oppId,
#        coalesce(z.zab_subscription, f.zab_subscription) zab_subscription,
#        coalesce(z.netsuite_salesorder, f.netsuite_salesorder) netsuite_salesorder,
#        coalesce(z.usageCommit, f.usageCommit) usageCommit,
#        coalesce(z.usageCommitStartDate, f.usageCommitStartDate) usageCommitStartDate,
#        coalesce(z.usageCommitEndDate, f.usageCommitEndDate) usageCommitEndDate
# from opps_with_commits z
# full join fuzzy_matched_opps f on z.oppId = f.oppId
# """)
# fuzzy_matched_opps_zab = fuzzy_matched_opps_zab.dropDuplicates(["oppId"])
# fuzzy_matched_opps_zab.createOrReplaceTempView("fuzzy_matched_opps_zab")

# COMMAND ----------

# cda_opps = spark.sql("""
# select opp.*,
#        f.zab_subscription,
#        f.netsuite_salesorder,
#        f.usageCommit,
#        cast(f.usageCommitStartDate as date) usageCommitStartDate,
#        cast(f.usageCommitEndDate as date) usageCommitEndDate
# from cda_opps_staging opp
# left join fuzzy_matched_opps_zab f on opp.oppId = f.oppId
# """)
