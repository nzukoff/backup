# Databricks notebook source
import pandas as pd
import numpy as np

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

# COMMAND ----------

START_YEAR = "2014"
START_DATE = "2014-01-01"
END_DATE = "2030-12-31"
MONTHS_TO_BE_CORRECTED = [2, 4, 6, 9, 11]
#OUTPUT_DATABASE = "main.it_core_dim"
OUTPUT_TABLE_NAME = "main.it_core_dim.dim_dates"
DATEDIM_LOCATION = "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/prod/dim_dates/"


CUSTOM_MONTH_MAP = { 
    'January': 12, 
    'February': 1,
    'March': 2,
    'April': 3,
    'May': 4,
    'June': 5,
    'July': 6,
    'August': 7,
    'September': 8,
    'October': 9,
    'November': 10,
    'December': 11
}

CUSTOM_QUARTER_MAP = {
    'January': 4,
    'February': 1,
    'March': 1,
    'April': 1,
    'May': 2,
    'June': 2,
    'July': 2,
    'August': 3,
    'September': 3,
    'October': 3,
    'November': 4,
    'December': 4,
    }

CUSTOM_HALF_YEAR_MAP = {
    'January': 2,
    'February': 1,
    'March': 1,
    'April': 1,
    'May': 1,
    'June': 1,
    'July': 1,
    'August': 2,
    'September': 2,
    'October': 2,
    'November': 2,
    'December': 2,
    }


CUSTOM_MONTH_ORDER_IN_QUARTER_MAP = { 
    'January': 3, 
    'February': 1,
    'March': 2,
    'April': 3,
    'May': 1,
    'June': 2,
    'July': 3,
    'August': 1,
    'September': 2,
    'October': 3,
    'November': 1,
    'December': 2
}

# COMMAND ----------

def get_base_dataframe(start_date, end_date):
    start_date, end_date = pd.Timestamp(start_date), pd.Timestamp(end_date)
    date_df = pd.DataFrame({"date":pd.date_range(start_date, end_date)})
    return date_df


def fiscal_week(d, start_month, start_day):
    from datetime import datetime, timedelta
    y_int = d.dt.year
    y_str = y_int.astype(str)
    start_md = (datetime(2021, start_month, start_day) - timedelta(days=1)).strftime('%m-%d')
    start_ymd = pd.to_datetime(y_str + '-' + start_md)
    s = d.dt.dayofyear - start_ymd.dt.dayofyear
    m1 = s.mask(s < 1, 365 - abs(s))
    m2 = m1.mask((y_int % 4 == 0) & (d > start_ymd), m1 - 1)
    return np.where(y_int % 4 != 0, (m2 + 6) / 7, (m2 + 7) / 7).astype(int)


def fiscal_day(d, start_month, start_day):
    from datetime import datetime, timedelta
    y_int = d.dt.year
    y_str = y_int.astype(str)
    start_md = (datetime(2021, start_month, start_day) - timedelta(days=1)).strftime('%m-%d')
    start_ymd = pd.to_datetime(y_str + '-' + start_md)
    s = d.dt.dayofyear - start_ymd.dt.dayofyear
    m1 = s.mask(s < 1, 365 - abs(s))
    m2 = m1.mask((y_int % 4 == 0) & (d <= start_ymd), m1 + 1)
    return m2


def get_year_month(month):
    if int(month) < 10:
        return START_YEAR + "-0" + str(month)
    return START_YEAR + "-" + str(month)


def prior_date_correction(date_df, month_to_be_corrected, skip_date, year_month_max_date):
    for dts in date_df[date_df['calendar_month'] == month_to_be_corrected].groupby('calendar_year').agg({'date' : max}).reset_index()['date']:
        if dts.strftime("%Y-%m-%d") == skip_date:
            continue
        year_month_of_prior_month = date_df[date_df['date'] == dts]['date_of_prior_month'].values[0].strftime("%Y-%m")
        year_month_of_prior_quarter = date_df[date_df['date'] == dts]['date_of_prior_quarter'].values[0].strftime("%Y-%m")
        year_month_of_prior_year = date_df[date_df['date'] == dts]['date_of_prior_year'].values[0].strftime("%Y-%m")
        corrected_date_of_prior_month = year_month_max_date[year_month_max_date['calendar_year_month'] == year_month_of_prior_month]['date'].values[0]
        corrected_date_of_prior_quarter = year_month_max_date[year_month_max_date['calendar_year_month'] == year_month_of_prior_quarter]['date'].values[0]
        corrected_date_of_prior_year = year_month_max_date[year_month_max_date['calendar_year_month'] == year_month_of_prior_year]['date'].values[0]
#         print("Fixing the 'date_of_prior_month': {0}, 'date_of_prior_quarter': {1}, 'date_of_prior_year': {2} for the date {3}".format(corrected_date_of_prior_month, 
#                                                                                                                                        corrected_date_of_prior_quarter, 
#                                                                                                                                        corrected_date_of_prior_year,
#                                                                                                                                        dts))
        date_df.loc[date_df['date'] == dts, 'date_of_prior_month'] = corrected_date_of_prior_month
        date_df.loc[date_df['date'] == dts, 'date_of_prior_quarter'] = corrected_date_of_prior_quarter
        date_df.loc[date_df['date'] == dts, 'date_of_prior_year'] = corrected_date_of_prior_year
    return date_df


def fix_prior_dates(date_df, months_list, year_month_max_date):
    dates_to_be_skipped = list(
        map(
            lambda x: year_month_max_date[year_month_max_date["calendar_year_month"] == x]["date"].values[0].strftime("%Y-%m-%d"),
            list(map(get_year_month, months_list)
            )
        )
    )
    
    for idx, month in enumerate(months_list):
        date_df = prior_date_correction(date_df, month, dates_to_be_skipped[idx], year_month_max_date)
    return date_df

def create_pandas_features(date_df):
    date_df['day'] = date_df["date"].apply(lambda dt: dt.day_name())
    date_df['calendar_year'] = date_df["date"].apply(lambda dt: dt.year)
    date_df['calendar_month'] = date_df["date"].apply(lambda dt: dt.month)
    date_df['month_name'] = date_df["date"].apply(lambda dt: dt.month_name())
    date_df['calendar_quarter'] = date_df["date"].apply(lambda dt: dt.quarter)
    date_df['calendar_year_month'] = date_df["date"].apply(lambda dt: str(dt.year)+'-'+str(dt.strftime('%m')))
    date_df['calendar_week'] = date_df["date"].apply(lambda dt: dt.week)
    
    date_df['day_of_week'] = date_df["date"].apply(lambda dt: dt.dayofweek)
    date_df["day_of_calendar_year"] = date_df["date"].apply(lambda dt: dt.timetuple().tm_yday)
    date_df['days_in_fiscal_month'] = date_df["date"].apply(lambda dt: dt.daysinmonth)

    date_df['date_prior_7days'] = date_df["date"].apply(lambda dt: dt - pd.to_timedelta(7, unit='d'))
    date_df['date_prior_7days'] = date_df['date_prior_7days'].apply(lambda dt: dt.date())
    date_df['date_prior_14days'] = date_df["date"].apply(lambda dt: dt - pd.to_timedelta(14, unit='d'))
    date_df['date_prior_14days'] = date_df['date_prior_14days'].apply(lambda dt: dt.date())
    date_df['date_prior_30days'] = date_df["date"].apply(lambda dt: dt - pd.to_timedelta(30, unit='d'))
    date_df['date_prior_30days'] = date_df['date_prior_30days'].apply(lambda dt: dt.date())
    date_df['date_prior_60days'] = date_df["date"].apply(lambda dt: dt - pd.to_timedelta(60, unit='d'))
    date_df['date_prior_60days'] = date_df['date_prior_60days'].apply(lambda dt: dt.date())
    date_df['date_prior_90days'] = date_df["date"].apply(lambda dt: dt - pd.to_timedelta(90, unit='d'))
    date_df['date_prior_90days'] = date_df['date_prior_90days'].apply(lambda dt: dt.date())

    date_df['is_month_start'] = date_df["date"].apply(lambda dt: dt.is_month_start)
    date_df['is_month_end'] = date_df["date"].apply(lambda dt: dt.is_month_end)
    
    date_df["fiscal_year"] = date_df["date"].apply(pd.Period, freq='A-JAN')
    date_df["fiscal_year"] = date_df["fiscal_year"].apply(lambda dt: int(dt.strftime('%Y')))
    date_df['fiscal_month'] = date_df["month_name"].apply(lambda month: CUSTOM_MONTH_MAP[month])
    date_df['fiscal_quarter'] = date_df["month_name"].apply(lambda month: CUSTOM_QUARTER_MAP[month])
    date_df['fiscal_half_year'] = date_df["month_name"].apply(lambda month: CUSTOM_HALF_YEAR_MAP[month])
    date_df['fiscal_month_number_in_quarter'] = date_df["month_name"].apply(lambda month: CUSTOM_MONTH_ORDER_IN_QUARTER_MAP[month])
    date_df["fiscal_year_month"] = date_df.apply(lambda dt: "FY'"+str(dt.fiscal_year)[2:]+" "+str(dt.fiscal_month), axis=1)
    date_df["fiscal_year_quarter"] = date_df.apply(lambda dt: "FY'"+str(dt.fiscal_year)[2:]+" Q"+str(dt.fiscal_quarter), axis=1)
    date_df["fiscal_year_half_year"] = date_df.apply(lambda dt: "FY'"+str(dt.fiscal_year)[2:]+" H"+str(dt.fiscal_half_year), axis=1)
    
    date_df['day_of_fiscal_year'] = fiscal_day(date_df['date'], 2, 1)
    date_df['week_of_fiscal_year'] = fiscal_week(date_df['date'], 2, 1)
    
    date_df["date_of_prior_month"] = date_df['date'].apply(lambda dt:  (dt - pd.DateOffset(months=1)).date())
    date_df["date_of_prior_quarter"] = date_df['date'].apply(lambda dt:  (dt - pd.DateOffset(months=3)).date())
    date_df["date_of_prior_year"] = date_df['date'].apply(lambda dt:  (dt - pd.DateOffset(years=1)).date())
    
    date_df['date'] = date_df["date"].apply(lambda dt: dt.date())
    return date_df

    
def delta_dml(temporary_table_name):
    output_dataframe = spark.sql(
        """
        WITH base (
        SELECT *,
               ROW_NUMBER() OVER(PARTITION BY calendar_year, calendar_month ORDER BY date) AS day_of_month,
               ROW_NUMBER() OVER(PARTITION BY fiscal_year_quarter ORDER BY date) AS day_of_fiscal_quarter,
               CAST(count(date) OVER(PARTITION BY fiscal_year_quarter) AS int) AS days_in_fiscal_quarter,
               CAST(count(date) OVER(PARTITION BY fiscal_year_half_year) AS int) AS days_in_fiscal_half_year,
               CAST(count(date) OVER(PARTITION BY fiscal_year) AS int) AS days_in_fiscal_year,
               FIRST(date) OVER(PARTITION BY fiscal_year_quarter) AS fiscal_quarter_start_date,
               LAST(date) OVER(PARTITION BY fiscal_year_quarter) AS fiscal_quarter_end_date,
               FIRST(date) OVER(PARTITION BY calendar_year, calendar_month) AS month_start_date,
               LAST(date) OVER(PARTITION BY calendar_year, calendar_month) AS month_end_date,
               FIRST(date) OVER(PARTITION BY fiscal_year) AS fiscal_year_start_date,
               LAST(date) OVER(PARTITION BY fiscal_year) AS fiscal_year_end_date,       
               CASE WHEN day_of_week < 5 THEN true ELSE false END AS is_weekday
        FROM {0}
        )
        SELECT *,
              CASE WHEN date = fiscal_quarter_end_date THEN true ELSE false END AS is_fiscal_quarter_end,
              CASE WHEN date = fiscal_year_end_date THEN true ELSE false END AS is_fiscal_year_end,
              date_sub(month_end_date, days_in_fiscal_month) prior_month_end_date,
              date_sub(fiscal_quarter_end_date, days_in_fiscal_quarter) prior_fiscal_quarter_end,
              date_sub(fiscal_year_end_date, days_in_fiscal_year) prior_fiscal_year_end,
              days_in_fiscal_month - day_of_month days_left_in_month
        FROM base
        WHERE date >= '2015-01-01'
        ORDER BY date
        """.format(temporary_table_name))
    return output_dataframe

# COMMAND ----------

date_df = get_base_dataframe(START_DATE, END_DATE)
date_df = create_pandas_features(date_df)

year_month_max_date = date_df.groupby('calendar_year_month').agg({'date' : max}).reset_index()
date_df = fix_prior_dates(date_df, MONTHS_TO_BE_CORRECTED, year_month_max_date)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

temporary_table_name = "date_dim_table"
spark_date_dim_df = spark.createDataFrame(date_df)
spark_date_dim_df = spark_date_dim_df. \
                    withColumn("days_in_fiscal_month", col("days_in_fiscal_month").cast("int")). \
                    withColumn("day_of_fiscal_year", col("day_of_fiscal_year").cast("int"))

# COMMAND ----------

spark_date_dim_df.createOrReplaceTempView(temporary_table_name)

# COMMAND ----------

dim_dates_df = delta_dml(temporary_table_name)

# COMMAND ----------

display(dim_dates_df)

# COMMAND ----------

dim_dates_df.write.mode('overwrite').format("delta").option("mergeSchema", "true").saveAsTable(OUTPUT_TABLE_NAME)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM main.it_core_dim.dim_dates

# COMMAND ----------


