# Databricks notebook source
# This notebook is intended to be included (via %run) into other notebooks.

# COMMAND ----------

#Add stage location configuration
token = dbutils.secrets.get('bse-dev-creds', 'bse-cust-analytics-secure')
spark.conf.set("fs.azure.sas.bse-cust-analytics.dbbusinesssystems1.blob.core.windows.net", token)

# COMMAND ----------

def create_uc_schema(catalog, schema):
  """
  Creates a UC schema if the schema does not exists.

  PARAMS:
  schema : Schema name to be created
  catalog : Catalog of the schema
  """
  try:
    if not spark.catalog.databaseExists("{}.{}".format(catalog, schema)):
      print("Creating schema {}.{}".format(catalog, schema))
      spark.sql("""USE CATALOG {};""".format(catalog))
      spark.sql("""CREATE SCHEMA IF NOT EXISTS {}""".format(schema))
    else:
      print("Schema already existis!")
  except Exception as e:
    print("Cannot create the schema {}.{}. Error : {}".format(catalog, schema, str(e)))    
  return

# COMMAND ----------

DEV_SOURCE_CATALOG = "users"
dev_base_config = {
  "SFDC_SCHEMA" : "main.sfdc_bronze",
  "CONSUMPTION_SCHEMA" : "main.it_consumption_silver",
  "DIM_SCHEMA" : "main.it_core_dim",
  "OUTPUT_CATALOG" : "users",
  "CORE_SCHEMA" : "prabhakar_guha",
  "AU_SCHEMA" : "prabhakar_guha",
  "CORE_ACCOUNTS_TABLE" : "core_accounts",
  "CORE_OPPORTUNITY_TABLE" : "core_opportunity"
}
dev_config = {
  "CATALOG" : dev_base_config["OUTPUT_CATALOG"],
  "CORE_SCHEMA" : dev_base_config["CORE_SCHEMA"],
  "AU_SCHEMA" : dev_base_config["AU_SCHEMA"],
  
  
  #CDA-Account
  "SFDC_USER" : dev_base_config["SFDC_SCHEMA"] + ".user",
  "SFDC_ACCOUNT" : dev_base_config["SFDC_SCHEMA"] + ".account",
  "SFDC_RTM" : dev_base_config["SFDC_SCHEMA"] + ".role_territory_mapping_object__c",
  "SFDC_BRAG_STATUS" : dev_base_config["SFDC_SCHEMA"] + ".BRAG_Status_History__c",
  "USAGE_ACCOUNT_MONTHLY" : dev_base_config["CONSUMPTION_SCHEMA"] + ".usagec_account_monthly",
  "USAGE_AGGORDER_MONTHLY" : dev_base_config["CONSUMPTION_SCHEMA"] + ".usagec_aggorder_monthly",
  "USER_ROLE_HIERARCHY" : "main.it_core_dim.user_role_hierarchy",
  "DATE_DIM" : dev_base_config["DIM_SCHEMA"] + ".dim_dates",
  "BI_ACCOUNT_DIM" : dev_base_config["DIM_SCHEMA"] + ".bi_account_dim",
  "ACCOUNT_ATTRIBS_STAGE_LOCATION" : "/mnt/bse-dev/staging/cda_accounts/account_attribs_stage/",
  "SALES_LEADERS_STAGE_LOCATION" : "/mnt/bse-dev/staging/cda_accounts/sales_leaders_stage/",
  "CSE_STAGE_LOCATION" : "/mnt/bse-dev/staging/cda_accounts/cse_stage/",
  "ACCOUNT_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/test/cda_accounts",
  "CORE_ACCOUNTS_TABLE" : dev_base_config["CORE_ACCOUNTS_TABLE"],
  #CDA-Opportunity
  "SFDC_OPP_LINE_ITEM" : dev_base_config["SFDC_SCHEMA"] + ".opportunitylineitem",
  "CORE_ACCOUNTS" : "{}.{}.{}".format(dev_base_config["OUTPUT_CATALOG"],dev_base_config["CORE_SCHEMA"],dev_base_config["CORE_ACCOUNTS_TABLE"]),
  "CORE_OPPORTUNITY" : "{}.{}.{}".format(dev_base_config["OUTPUT_CATALOG"],dev_base_config["CORE_SCHEMA"],dev_base_config["CORE_OPPORTUNITY_TABLE"]),
  "SFDC_OPPCONTACTROLE" : dev_base_config["SFDC_SCHEMA"] + ".opportunitycontactrole",
  "SFDC_CONTACT" : dev_base_config["SFDC_SCHEMA"] + ".contact",
  "SFDC_OPPORTUNITY" : dev_base_config["SFDC_SCHEMA"] + ".opportunity",
  "OPPORTUNITY_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/test/core_opportunity/",
  "CORE_OPPORTUNITY_TABLE" : dev_base_config["CORE_OPPORTUNITY_TABLE"],
  
  #Active-Users
  "WORKLOAD_INSIGHTS" : "prod.workload_insights",
  "ACTIVE_USERS" : "active_users",
  "ACTIVE_USERS_WORKSPACE_AGG" : "active_users_workspace_agg",
  "ACTIVE_USERS_SKU_AGG" : "active_users_sku_agg",
  "ACTIVE_USERS_ACCOUNT_AGG" : "active_users_account_agg",
  "PROD_CORE_ACCOUNTS" : "main.it_sfdc_silver.{}".format(dev_base_config["CORE_ACCOUNTS_TABLE"]),
  "PROD_LOGINS_AU" : "focus_prod.login_active_users_workspace_kpis"
}

# COMMAND ----------

TEST_SOURCE_CATALOG = "integration"
test_base_config = {
  "SFDC_SCHEMA" : "main.sfdc_bronze",
  "CONSUMPTION_SCHEMA" : TEST_SOURCE_CATALOG + ".it_consumption_silver",
  "DIM_SCHEMA" : TEST_SOURCE_CATALOG + ".it_core_dim",
  "OUTPUT_CATALOG" : TEST_SOURCE_CATALOG,
  "CORE_SCHEMA" : "it_sfdc_silver",
  "AU_SCHEMA" : "it_consumption_silver",
  "CORE_ACCOUNTS_TABLE" : "core_accounts",
  "CORE_OPPORTUNITY_TABLE" : "core_opportunity"
}
test_config = {
  "CATALOG" : test_base_config["OUTPUT_CATALOG"],
  "CORE_SCHEMA" : test_base_config["CORE_SCHEMA"],
  "AU_SCHEMA" : test_base_config["AU_SCHEMA"],
  
  
  #CDA-Account
  "SFDC_USER" : test_base_config["SFDC_SCHEMA"] + ".user",
  "SFDC_ACCOUNT" : test_base_config["SFDC_SCHEMA"] + ".account",
  "SFDC_RTM" : test_base_config["SFDC_SCHEMA"] + ".role_territory_mapping_object__c",
  "SFDC_BRAG_STATUS" : test_base_config["SFDC_SCHEMA"] + ".BRAG_Status_History__c",
  "USAGE_ACCOUNT_MONTHLY" : test_base_config["CONSUMPTION_SCHEMA"] + ".usagec_account_monthly",
  "USAGE_AGGORDER_MONTHLY" : test_base_config["CONSUMPTION_SCHEMA"] + ".usagec_aggorder_monthly",
  "USER_ROLE_HIERARCHY" : "main.it_core_dim.user_role_hierarchy",
  "DATE_DIM" : test_base_config["DIM_SCHEMA"] + ".dim_dates",
  "BI_ACCOUNT_DIM" : test_base_config["DIM_SCHEMA"] + ".bi_account_dim",
  "ACCOUNT_ATTRIBS_STAGE_LOCATION" : "/mnt/bse-dev/staging/cda_accounts/account_attribs_stage/",
  "SALES_LEADERS_STAGE_LOCATION" : "/mnt/bse-dev/staging/cda_accounts/sales_leaders_stage/",
  "CSE_STAGE_LOCATION" : "/mnt/bse-dev/staging/cda_accounts/cse_stage/",
  "ACCOUNT_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/test/cda_accounts",
  "CORE_ACCOUNTS_TABLE" : test_base_config["CORE_ACCOUNTS_TABLE"],
  #CDA-Opportunity
  "SFDC_OPP_LINE_ITEM" : test_base_config["SFDC_SCHEMA"] + ".opportunitylineitem",
  "CORE_ACCOUNTS" : "{}.{}.{}".format(test_base_config["OUTPUT_CATALOG"],test_base_config["CORE_SCHEMA"],test_base_config["CORE_ACCOUNTS_TABLE"]),
  "CORE_OPPORTUNITY" : "{}.{}.{}".format(test_base_config["OUTPUT_CATALOG"],test_base_config["CORE_SCHEMA"],test_base_config["CORE_OPPORTUNITY_TABLE"]),
  "SFDC_OPPCONTACTROLE" : test_base_config["SFDC_SCHEMA"] + ".opportunitycontactrole",
  "SFDC_CONTACT" : test_base_config["SFDC_SCHEMA"] + ".contact",
  "SFDC_OPPORTUNITY" : test_base_config["SFDC_SCHEMA"] + ".opportunity",
  "OPPORTUNITY_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/test/core_opportunity/",
  "CORE_OPPORTUNITY_TABLE" : test_base_config["CORE_OPPORTUNITY_TABLE"],

  #Active-Users
  "WORKLOAD_INSIGHTS" : "prod.workload_insights",
  "ACTIVE_USERS" : "active_users",
  "ACTIVE_USERS_WORKSPACE_AGG" : "active_users_workspace_agg",
  "ACTIVE_USERS_SKU_AGG" : "active_users_sku_agg",
  "ACTIVE_USERS_ACCOUNT_AGG" : "active_users_account_agg",
  "PROD_CORE_ACCOUNTS" : "main.it_sfdc_silver.{}".format(test_base_config["CORE_ACCOUNTS_TABLE"]),
  "PROD_LOGINS_AU" : "focus_prod.login_active_users_workspace_kpis"
}

# COMMAND ----------

# test_config =  {
#   "CATALOG" : "integration",
#   "CORE_SCHEMA" : "it_sfdc_silver",
#   "AU_SCHEMA" : "it_consumption_silver",
#   #CDA-Account
#   "SFDC_USER" : "sfdc_prod.user",
#   "SFDC_ACCOUNT" : "sfdc_prod.account",
#   "SFDC_RTM" : "sfdc_prod.role_territory_mapping_object__c",
#   "SFDC_BRAG_STATUS" : "sfdc_prod.BRAG_Status_History__c",  
#   "USAGE_ACCOUNT_MONTHLY" : "bdw.usagec_account_monthly",
#   "USAGE_AGGORDER_MONTHLY" : "bdw.usagec_aggorder_monthly",
#   "USER_ROLE_HIERARCHY" : "bdw.user_role_hierarchy",
#   "DATE_DIM" : "bdw.dim_dates",
#   "BI_ACCOUNT_DIM" : "bdw.bi_account_dim",
#   "ACCOUNT_ATTRIBS_STAGE_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/stage/cda_accounts/account_attribs_stage/",
#   "SALES_LEADERS_STAGE_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/stage/cda_accounts/sales_leaders_stage/",
#   "CSE_STAGE_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/stage/cda_accounts/cse_stage/",
#   "ACCOUNT_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/test/cda_accounts",
#   "CORE_ACCOUNTS_TABLE" : "core_accounts",
#   #CDA-Opportunity
#   "SFDC_OPP_LINE_ITEM" : "sfdc_prod.opportunitylineitem",
#   "CORE_ACCOUNTS" : "bdw_dev.core_accounts",
#   "CORE_OPPORTUNITY" : "bdw.core_opportunity",
#   "SFDC_OPPCONTACTROLE" : "sfdc_prod.opportunitycontactrole",
#   "SFDC_CONTACT" : "sfdc_prod.contact",
#   "SFDC_OPPORTUNITY" : "sfdc_prod.opportunity",
#   "OPPORTUNITY_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/test/core_opportunity/",
#   "CORE_OPPORTUNITY_TABLE" : "core_opportunity"
# }

# COMMAND ----------

PROD_SOURCE_CATALOG = "main"
prod_base_config = {
  "SFDC_SCHEMA" : "main.sfdc_bronze",
  "CONSUMPTION_SCHEMA" : PROD_SOURCE_CATALOG + ".it_consumption_silver",
  "DIM_SCHEMA" : PROD_SOURCE_CATALOG + ".it_core_dim",
  "OUTPUT_CATALOG" : PROD_SOURCE_CATALOG,
  "CORE_SCHEMA" : "it_sfdc_silver",
  "AU_SCHEMA" : "it_consumption_silver",
  "CORE_ACCOUNTS_TABLE" : "core_accounts",
  "CORE_OPPORTUNITY_TABLE" : "core_opportunity"
}
prod_config = {
  "CATALOG" : prod_base_config["OUTPUT_CATALOG"],
  "CORE_SCHEMA" : prod_base_config["CORE_SCHEMA"],
  "AU_SCHEMA" : prod_base_config["AU_SCHEMA"],
  
  
  #CDA-Account
  "SFDC_USER" : prod_base_config["SFDC_SCHEMA"] + ".user",
  "SFDC_ACCOUNT" : prod_base_config["SFDC_SCHEMA"] + ".account",
  "SFDC_RTM" : prod_base_config["SFDC_SCHEMA"] + ".role_territory_mapping_object__c",
  "SFDC_BRAG_STATUS" : prod_base_config["SFDC_SCHEMA"] + ".BRAG_Status_History__c",
  "USAGE_ACCOUNT_MONTHLY" : prod_base_config["CONSUMPTION_SCHEMA"] + ".usagec_account_monthly",
  "USAGE_AGGORDER_MONTHLY" : prod_base_config["CONSUMPTION_SCHEMA"] + ".usagec_aggorder_monthly",
  "USER_ROLE_HIERARCHY" : "main.it_core_dim.user_role_hierarchy",
  "DATE_DIM" : prod_base_config["DIM_SCHEMA"] + ".dim_dates",
  "BI_ACCOUNT_DIM" : prod_base_config["DIM_SCHEMA"] + ".bi_account_dim",
  "ACCOUNT_ATTRIBS_STAGE_LOCATION" : "/mnt/bse-dev/staging/cda_accounts/account_attribs_stage/",
  "SALES_LEADERS_STAGE_LOCATION" : "/mnt/bse-dev/staging/cda_accounts/sales_leaders_stage/",
  "CSE_STAGE_LOCATION" : "/mnt/bse-dev/staging/cda_accounts/cse_stage/",
  "ACCOUNT_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/prod/core_accounts",
  "CORE_ACCOUNTS_TABLE" : prod_base_config["CORE_ACCOUNTS_TABLE"],
  
  #CDA-Opportunity
  "SFDC_OPP_LINE_ITEM" : prod_base_config["SFDC_SCHEMA"] + ".opportunitylineitem",
  "CORE_ACCOUNTS" : "{}.{}.{}".format(prod_base_config["OUTPUT_CATALOG"],prod_base_config["CORE_SCHEMA"],prod_base_config["CORE_ACCOUNTS_TABLE"]),
  "CORE_OPPORTUNITY" : "{}.{}.{}".format(prod_base_config["OUTPUT_CATALOG"],prod_base_config["CORE_SCHEMA"],prod_base_config["CORE_OPPORTUNITY_TABLE"]),
  "SFDC_OPPCONTACTROLE" : prod_base_config["SFDC_SCHEMA"] + ".opportunitycontactrole",
  "SFDC_CONTACT" : prod_base_config["SFDC_SCHEMA"] + ".contact",
  "SFDC_OPPORTUNITY" : prod_base_config["SFDC_SCHEMA"] + ".opportunity",
  "OPPORTUNITY_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/prod/core_opportunity",
  "CORE_OPPORTUNITY_TABLE" : prod_base_config["CORE_OPPORTUNITY_TABLE"],

  #Active-Users
  "WORKLOAD_INSIGHTS" : "prod.workload_insights",
  "ACTIVE_USERS" : "active_users",
  "ACTIVE_USERS_WORKSPACE_AGG" : "active_users_workspace_agg",
  "ACTIVE_USERS_SKU_AGG" : "active_users_sku_agg",
  "ACTIVE_USERS_ACCOUNT_AGG" : "active_users_account_agg",
  "PROD_CORE_ACCOUNTS" : "main.it_sfdc_silver.{}".format(prod_base_config["CORE_ACCOUNTS_TABLE"]),
  "PROD_LOGINS_AU" : "focus_prod.login_active_users_workspace_kpis"
}

# COMMAND ----------

# prod_config_old = {
#   "CATALOG" : "main",
#   "CORE_SCHEMA" : "it_sfdc_silver",
#   "AU_SCHEMA" : "it_consumption_silver",
#   #CDA-Account
#   "SFDC_USER" : "sfdc_prod.user",
#   "SFDC_ACCOUNT" : "sfdc_prod.account",
#   "SFDC_RTM" : "sfdc_prod.role_territory_mapping_object__c",
#   "SFDC_BRAG_STATUS" : "sfdc_prod.BRAG_Status_History__c",
#   "USAGE_ACCOUNT_MONTHLY" : "bdw.usagec_account_monthly",
#   "USAGE_AGGORDER_MONTHLY" : "bdw.usagec_aggorder_monthly",
#   "USER_ROLE_HIERARCHY" : "bdw.user_role_hierarchy",
#   "DATE_DIM" : "bdw.dim_dates",
#   "BI_ACCOUNT_DIM" : "bdw.bi_account_dim",
#   "ACCOUNT_ATTRIBS_STAGE_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/stage/cda_accounts/account_attribs_stage/",
#   "SALES_LEADERS_STAGE_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/stage/cda_accounts/sales_leaders_stage/",
#   "CSE_STAGE_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/stage/cda_accounts/cse_stage/",
#   "ACCOUNT_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/prod/core_accounts",
#   "CORE_ACCOUNTS_TABLE" : "core_accounts",
#   #CDA-Opportunity
#   "SFDC_OPP_LINE_ITEM" : "sfdc_prod.opportunitylineitem",
#   "CORE_ACCOUNTS" : "bdw.core_accounts",
#   "CORE_OPPORTUNITY" : "bdw.core_opportunity",
#   "SFDC_OPPCONTACTROLE" : "sfdc_prod.opportunitycontactrole",
#   "SFDC_CONTACT" : "sfdc_prod.contact",
#   "SFDC_OPPORTUNITY" : "sfdc_prod.opportunity",
#   "OPPORTUNITY_LOCATION" : "wasbs://bse-cust-analytics@dbbusinesssystems1.blob.core.windows.net/tables/prod/core_opportunity",
#   "CORE_OPPORTUNITY_TABLE" : "core_opportunity",

#   #Active-Users
#   "WORKLOAD_INSIGHTS" : "prod.workload_insights",
#   "ACTIVE_USERS" : "active_users",
#   "ACTIVE_USERS_WORKSPACE_AGG" : "active_users_workspace_agg",
#   "ACTIVE_USERS_SKU_AGG" : "active_users_sku_agg",
#   "ACTIVE_USERS_ACCOUNT_AGG" : "active_users_account_agg",
#   "PROD_CORE_ACCOUNTS" : "main.it_sfdc_silver.core_accounts",
#   "PROD_LOGINS_AU" : "focus_prod.login_active_users_workspace_kpis"
# }

# COMMAND ----------

#TABLE DEFINITIONS
config = {
            "development" : dev_config,
            "test" : test_config,
            "production" : prod_config
}


# COMMAND ----------


