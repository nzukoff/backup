# Databricks notebook source
# MAGIC %pip install simple-salesforce

# COMMAND ----------

#dbutils.library.installPyPI("simple-salesforce")
from simple_salesforce import Salesforce
import pandas as pd
import numpy as np

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

from datetime import datetime

# COMMAND ----------

def get_creds(prefix):
  """
  JWT Login method
  params:
         prefix - 'uat' for uat, 'sfdcprod' for prod
  returns:
         list of user_name, password, consumer_key, privatekey_file 
  """
  username = dbutils.secrets.get('api-creds', prefix+'_username')
  password = dbutils.secrets.get('api-creds', prefix+'_password')
  consumer_key = dbutils.secrets.get('api-creds', prefix+'_consumer_key')
  privatekey_file= dbutils.secrets.get('api-creds', prefix+'_privatekey_location')
  return [username, password, consumer_key, privatekey_file]


def get_sfdc_connection(creds, domain):
  """
  params:
         creds - connection credentials
         domain - 'test' for uat, 'login' for prod
  returns:
         sfdc connection object
  """
  return Salesforce(username=creds[0], \
                    password=creds[1], \
                    consumer_key=creds[2], \
                    privatekey_file=creds[3], \
                    domain=domain)


def get_dataframe(query, environement_prefix, domain):

    """
    calls get_creds, get_sfdc_connection functions
    uses salesforce's soql query api 
    params: query, environement_prefix, domain
    returns: pandas dataframe
    """
  
    creds = get_creds(environement_prefix)
    sf = get_sfdc_connection(creds, domain)
    
    list_data_records = []
    data = sf.query(query)
    list_data_records = data['records']
    prev_counter = 0
    cur_counter = 0
    while 'nextRecordsUrl' in data.keys():
        next_record = data['nextRecordsUrl'].split('/')[-1]
        data = sf.query_more(next_record)
        list_data_records += data['records']
        if cur_counter-prev_counter >= 50000:
          prev_counter = cur_counter
          sf = get_sfdc_connection(creds, domain) # connection reset
        cur_counter = len(list_data_records)
    return pd.DataFrame(list_data_records).drop(columns='attributes')
  
  
def check_total_records(sf_object):
  """ returns records in the object"""
  zero_rocord_check_soql = """  select count() from {0} """.format(sf_object)
  creds = get_creds('sfdcprod')
  sf = get_sfdc_connection(creds, 'login')
  data = sf.query(zero_rocord_check_soql)  
  return data['totalSize']
  
  
import numpy as np
import pandas as pd
from pyspark.sql.types import *
pandas_spark_types_map = {
                    np.int8: ByteType(),
                    np.uint8: ShortType(),
                    np.int16: ShortType(),
                    np.uint16: IntegerType(),
                    np.int32: IntegerType(),
                    np.int64: LongType(),
                    np.float32: FloatType(),
                    np.float64: DoubleType(),
                    np.string_: StringType(),
                    np.str_: StringType(),
                    np.unicode_: StringType(),
                    np.bool_: BooleanType(),
                    np.object_: StringType()
                }

def build_spark_schema(numpy_dtypes):
    """
    takes pandas dtypes and converts to Spark Schema
    parms: numpy_dtypes, pandas_spark_types_map
    returns: Pyspark Schema
    """
    return StructType([StructField(col_name, pandas_spark_types_map[col_type.type], True) for col_name, col_type in numpy_dtypes.iteritems()])
  
  
def get_spark_dataframe(soql_query, env, domain):
  """
  returns spark dataframe
  """
  df = get_dataframe(soql_query, env, domain)
  df_schema = build_spark_schema(df.dtypes)
  return spark.createDataFrame(df, df_schema)
