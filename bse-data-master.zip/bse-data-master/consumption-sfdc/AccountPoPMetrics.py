# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

from datetime import datetime, timedelta
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

dates_df = spark.sql(f""" select * from {BI_DATES} """)

current_date = datetime.today()
today = dates_df.filter(dates_df.date==current_date.date()).collect()[0]
cur_year, cur_fiscalYear, cur_fiscalQuarter, cur_month, cur_week, cur_month_end_date  = today.year, today.fiscalYear, today.fiscalQuarter, today.month,  today.week, today.month_end_date
print(cur_year, cur_fiscalYear, cur_fiscalQuarter, cur_month, cur_week, cur_month_end_date, current_date.date())

next_w = spark.sql(f"""
select date, 
       week,
       fiscalYear
from {BI_DATES}
where date >= date_add(current_date(), 7)
order by date
limit 1
""").collect()[0]
next_week = next_w.week
next_week_fiscalYear = next_w.fiscalYear
print('next-week:', next_week, 'fiscalYear: ', next_week_fiscalYear)

next_m = spark.sql(f"""
select month_end_date,
       month,
       fiscalYear
from {BI_DATES}
where date >= current_date()
and isMonthEnd = 1
order by 1 
limit 2
""").collect()[1]

next_month = next_m.month
next_month_fiscalYear = next_m.fiscalYear
print("next-month: ", next_month, 'fiscalYear: ', next_month_fiscalYear)

next_fiscal = spark.sql(f"""
select distinct
       fiscalYear,
       fiscalQuarter
from {BI_DATES}
where date >= current_date()
order by 1, 2 
limit 2
""").collect()[1]
 
next_fiscal_quarter = next_fiscal.fiscalQuarter
next_fiscalYear = next_fiscal.fiscalYear
print("next-fiscals: ", next_fiscal_quarter, next_fiscalYear)

current_fiscal = spark.sql(f"""
select date,
       week,
       month,
       fiscalYear,
       fiscalQuarter
from {BI_DATES}
where date = current_date()
""").collect()[0]
current_week = current_fiscal.week
current_month = current_fiscal.month
current_fiscal_quarter = current_fiscal.fiscalQuarter
current_fiscal_year = current_fiscal.fiscalYear
print("current-fiscals: ", current_fiscal.date, 'current-week: ', current_week, ' current-month: ', current_month, ' Q: ', current_fiscal_quarter, ' FY ', current_fiscal_year)

# COMMAND ----------

# DBTITLE 1,week
current_week_df = spark.sql(f"""
select accountId,
       sum(case when revShareDollars > 0 then revShareDollars else revShareForecastDollars_new end) RevShareCurrentWeek,
       sum(revShareDollars) RevShareDollarsWTD
from {USAGE_ACCOUNT_DAILY} uad
join {BI_DATES} dt on uad.usage_date = dt.date 
where dt.week = {current_week} and dt.fiscalYear = {current_fiscal_year}
group by 1
"""
)

current_week_df.createOrReplaceTempView('account_current_week')

next_week_df = spark.sql(f"""
select accountId,
       sum(revShareForecastDollars_new) RevShareNextWeek
from {USAGE_ACCOUNT_DAILY} uad
join {BI_DATES} dt on uad.usage_date = dt.date 
where dt.week = {next_week} and dt.fiscalYear = {next_week_fiscalYear}
group by 1
"""
)

next_week_df.createOrReplaceTempView('account_next_week')

# COMMAND ----------

# DBTITLE 1,month
current_month_df = spark.sql(f"""
select accountId,
       sum(case when revShareDollars > 0 then revShareDollars else revShareForecastDollars_new end) RevShareCurrentMonth,
       sum(revShareDollars) RevShareDollarsMTD
from {USAGE_ACCOUNT_DAILY} uad
join {BI_DATES} dt on uad.usage_date = dt.date 
where dt.month = {current_month} and dt.fiscalYear = {current_fiscal_year}
group by 1
""" 
)

current_month_df.createOrReplaceTempView('account_current_month')

next_month_df = spark.sql(f"""
select accountId,
       sum(revShareForecastDollars_new) RevShareNextMonth
from {USAGE_ACCOUNT_DAILY} uad
join {BI_DATES} dt on uad.usage_date = dt.date 
where dt.month = {next_month} and dt.fiscalYear = {next_month_fiscalYear}
group by 1
"""
)

next_month_df.createOrReplaceTempView('account_next_month')

# COMMAND ----------

# DBTITLE 1,quarter
current_quarter_df = spark.sql(f"""
select accountId,
       sum(case when revShareDollars > 0 then revShareDollars else revShareForecastDollars_new end) RevShareCurrentQuarter,
       sum(revShareDollars) RevShareDollarsQTD
from {USAGE_ACCOUNT_DAILY} uad
join {BI_DATES} dt on uad.usage_date = dt.date 
where dt.fiscalQuarter = {current_fiscal_quarter} and dt.fiscalYear = {current_fiscal_year}
group by 1
"""
)

current_quarter_df.createOrReplaceTempView('account_current_quarter')

next_quarter_df = spark.sql(f"""
select accountId,
       sum(revShareForecastDollars_new) RevShareNextQuarter
from {USAGE_ACCOUNT_DAILY} uad
join {BI_DATES} dt on uad.usage_date = dt.date 
where dt.fiscalQuarter = {next_fiscal_quarter} and dt.fiscalYear = {next_fiscalYear}
group by 1
"""
)

next_quarter_df.createOrReplaceTempView('account_next_quarter')

# COMMAND ----------

accountQtrMonthWeek = spark.sql(f"""
with base (
select accountId,

       sum(RevShareLastQtr) RevShareLastQtr,
       --sum(RevShareCurrentQtr) RevShareCurrentQtr,
       --sum(RevShareNextQtr) RevShareNextQtr,
      
       sum(RevShareLastMonth) RevShareLastMonth,
       --sum(RevShareCurrentMonth) RevShareCurrentMonth,
       --sum(RevShareNextMonth) RevShareNextMonth,
       
       sum(RevShareLastWeek) RevShareLastWeek,
       
       --sum(RevShareCurrentWeek) RevShareCurrentWeek,
       --sum(RevShareNextWeek) RevShareNextWeek
       
       sum(T3MRevShareDollars) T3MRevShareDollars
from {USAGEC_POPMETRICS}
group by 1
)

select b.accountId,
       b.RevShareLastQtr,
       coalesce(cq.RevShareDollarsQTD, 0) RevShareDollarsQTD,
       coalesce(cq.RevShareCurrentQuarter, 0) RevShareCurrentQtr,
       coalesce(nq.RevShareNextQuarter, 0) RevShareNextQtr,
       
       b.RevShareLastMonth,
       coalesce(cm.RevShareDollarsMTD, 0) RevShareDollarsMTD,
       coalesce(cm.RevShareCurrentMonth, 0) RevShareCurrentMonth,
       coalesce(nm.RevShareNextMonth, 0) RevShareNextMonth,
       
       b.RevShareLastWeek,
       coalesce(cw.RevShareDollarsWTD, 0) RevShareDollarsWTD,
       coalesce(cw.RevShareCurrentWeek, 0) RevShareCurrentWeek,
       coalesce(nw.RevShareNextWeek, 0) RevShareNextWeek,
       b.T3MRevShareDollars
from base b
left join account_current_quarter cq on b.accountId = cq.accountId
left join account_next_quarter nq on b.accountId = nq.accountId
left join account_current_month cm on b.accountId = cm.accountId
left join account_next_month nm on b.accountId = nm.accountId
left join account_current_week cw on b.accountId = cw.accountId
left join account_next_week nw on b.accountId = nw.accountId
""")

accountQtrMonthWeek.createOrReplaceTempView("accountQtrMonthWeek")

# COMMAND ----------

accountQtrMonthWeek.count()

# COMMAND ----------

# DBTITLE 1,two-quarters-ago-actuals
TWOqtrsagoactuals = spark.sql(f"""
with fiscalQuarters (
select distinct
       fiscalYear,
       fiscalQuarter
from {BI_DATES}
where date <= current_date()
order by 1 desc, 2 desc
limit 3
),

orderedfiscalQuarters (
select fiscalYear,
       fiscalQuarter,
       row_number() over(order by fiscalYear desc, fiscalQuarter desc) as rno
from fiscalQuarters
)

select acc.accountId,
       dt.fiscalYear,
       dt.fiscalQuarter,
       sum(acc.revShareDollars) 2QTRAgoActuals
from {USAGEC_ACCOUNT_MONTHLY} acc
join {BI_DATES} dt on acc.month_end_date = dt.date
left join orderedfiscalQuarters q on dt.fiscalYear = q.fiscalYear and dt.fiscalQuarter = q.fiscalQuarter
where acc.month_end_date > '2020-01-01'
and q.rno > 2
group by 1,2,3
order by 1,2,3
""")

TWOqtrsagoactuals.createOrReplaceTempView("TWOqtrsagoactuals")

# COMMAND ----------

accountPoPJ1 = accountQtrMonthWeek.join(TWOqtrsagoactuals, accountQtrMonthWeek.accountId == TWOqtrsagoactuals.accountId, 'left')\
                                  .drop(TWOqtrsagoactuals.accountId)\
                                  .drop(TWOqtrsagoactuals.fiscalYear)\
                                  .drop(TWOqtrsagoactuals.fiscalQuarter)

# COMMAND ----------

# DBTITLE 1,current and next quarter AE forecast
curNxtQTRAEForecastDollars = spark.sql(f"""

with nextquarters (
select distinct
       fiscalYear,
       fiscalQuarter
from {BI_DATES}
where date >= current_date()
order by fiscalYear, fiscalQuarter
limit 2
),

curNextQuarters (
select 
       fiscalYear,
       fiscalQuarter,
       row_number() over(order by fiscalYear, fiscalQuarter) rno
from nextquarters 
),

base (
select acc.accountId,
       q.fiscalYear,
       q.fiscalQuarter,
       q.rno,
       sum(acc.AEForecastDBUDollars) quarterAEForecastDBUDollars
from {USAGEC_ACCOUNT_MONTHLY} acc
join {BI_DATES} dt on acc.month_end_date = dt.date
left join curNextQuarters q on dt.fiscalYear = q.fiscalYear and dt.fiscalQuarter = q.fiscalQuarter
where acc.month_end_date > '2020-01-01'
group by 1,2,3,4
order by 1,2,3,4
)


select * from (
select accountId, rno, quarterAEForecastDBUDollars
from base
) pivot (
    
    first(quarterAEForecastDBUDollars) AEForecastDollars
    for rno in (1 CurrentQTRAEForecastDollars, 2 NextQTRAEForecastDollars)
)

""")

curNxtQTRAEForecastDollars.createOrReplaceTempView("curNxtQTRAEForecastDollars")

# COMMAND ----------

accountPoPJ2 = accountPoPJ1.join(curNxtQTRAEForecastDollars, accountPoPJ1.accountId == curNxtQTRAEForecastDollars.accountId, 'left')\
                           .drop(curNxtQTRAEForecastDollars.accountId)

# COMMAND ----------

# DBTITLE 1,3 months, 2 months ago actuals
last3MonthsAgoActuals = spark.sql(f"""
with last3Months (
select month_end_date
from {BI_DATES}
where date < current_date()
and isMonthEnd = 1
order by 1 desc
limit 3
),

distinctAccounts (
select distinct accountId
from {USAGEC_ACCOUNT_MONTHLY}
),

last3MonthAccounts (
select accountId,
       month_end_date
from distinctAccounts
cross join last3Months
)

select * from (
select accountId, revShareDollars, rno from (

    select l3m.accountId,
           coalesce(uam.revShareDollars,0) revShareDollars,
           l3m.month_end_date,
           row_number() over(partition by l3m.accountId order by l3m.month_end_date) rno
    from last3MonthAccounts l3m
    left join {USAGEC_ACCOUNT_MONTHLY} uam  on l3m.month_end_date = uam.month_end_date and l3m.accountId = uam.accountId )
) pivot (
      first(revShareDollars)
      for rno in (1 3MonthAgoActuals, 2 2MonthAgoActuals)
)
""")

last3MonthsAgoActuals.createOrReplaceTempView("last3MonthsAgoActuals")

# COMMAND ----------

accountPoPJ3 = accountPoPJ2.join(last3MonthsAgoActuals, accountPoPJ2.accountId == last3MonthsAgoActuals.accountId, 'left')\
                           .drop(last3MonthsAgoActuals.accountId)

# COMMAND ----------

# DBTITLE 1,current-month and next-month, next-2-month AE forecast & DS forecast
monthAEDSForecast = spark.sql(f"""
with curNextMonths (
select month_end_date,
       row_number() over(order by month_end_date) rno
from {BI_DATES}
where date >= current_date()
and isMonthEnd = 1
order by month_end_date
limit 3 ),

base (
select acc.accountId,
       m.month_end_date,
       m.rno,
       acc.AEForecastDBUDollars,
       round((acc.revShareDollars + acc.RevShareForecastDollars_New),2) DSForecastDBUDollars
from {USAGEC_ACCOUNT_MONTHLY} acc
left join curNextMonths m on acc.month_end_date = m.month_end_date
order by 1,2
)

select * from (
select accountId, rno, AEForecastDBUDollars, DSForecastDBUDollars
from base
) pivot (
  
  first(AEForecastDBUDollars) AEForecastDBUDollars, first(DSForecastDBUDollars) DSForecastDBUDollars
  for rno in (1 CurrentMonth, 2 NextMonth, 3 Next2Month)
)
""")

monthAEDSForecast.createOrReplaceTempView("monthAEDSForecast")

# COMMAND ----------

accountPoPJ4 = accountPoPJ3.join(monthAEDSForecast, accountPoPJ3.accountId == monthAEDSForecast.accountId, 'left')\
                           .drop(monthAEDSForecast.accountId)

# COMMAND ----------

# DBTITLE 1,current-month, next-month, next-2-month run rate
monthRunRates = spark.sql(f"""
with dailyRunRate (
select    accountId,
          round(sum(d.revShareDollars) / 7, 2) weekRunRate
from {USAGEC_AGGORDER_DAILY} d
join {BI_DATES} dt on d.usage_date = dt.date
where date >= date_sub(current_date,8)
and date <= date_sub(current_date,2)
group by 1
),

monthDays(
select month_end_date nextMonthEndDate,
       daysinmonth runRateDays,
       row_number() over(order by month_end_date) rowNum
from {BI_DATES}
where date >= current_date()
and isMonthEnd = 1
order by month_end_date 
limit 3
)

select * from (
select accountId, rowNum, RunRate from (
select rowNum,
       accountId,
       nextMonthEndDate,
       round((weekRunRate * runRateDays),2) RunRate
from dailyRunRate 
cross join monthDays
 )
) pivot (

    first(RunRate)
    for rowNum in ( 1 curMonthRunRate, 2 nextMonthRunRate, 3 next2MonthRunRate )
)
""")


monthRunRates.createOrReplaceTempView("monthRunRates")

# COMMAND ----------

accountPoPJ5 = accountPoPJ4.join(monthRunRates, accountPoPJ4.accountId == monthRunRates.accountId, 'left')\
                           .drop(monthRunRates.accountId)

# COMMAND ----------

# DBTITLE 1,Four, three, two weeks ago actuals
weekAgoActuals = spark.sql(f"""
with weeks (
select distinct
       week,
       fiscalYear
from {BI_DATES}
where date <= current_date()
and date >= date_sub(current_date(), 27)
order by week, fiscalYear
),

base (
select accountId,
       usage_date,
       w.week,
       revShareDollars
from {USAGEC_AGGORDER_DAILY} d
join {BI_DATES} dt on d.usage_date = dt.date
join weeks w on dt.week = w.week and dt.fiscalYear = w.fiscalYear
order by 1
),

base2  (
select accountId,
       week,
       round(sum(revShareDollars),2) weekAgoActuals
from base
group by 1,2
order by 1,2
)

select * from (
select accountId, rno,  weekAgoActuals from (
select  accountId,
        week,
        weekAgoActuals,
        row_number() over(partition by accountId order by week) rno
from base2
) 
) pivot (

    first(weekAgoActuals)
    for rno in ( 1 4WeekAgoActuals, 2 3WeekAgoActuals, 3 2WeekAgoActuals )
)
""")

weekAgoActuals.createOrReplaceTempView("weekAgoActuals")

# COMMAND ----------

accountPoPJ6 = accountPoPJ5.join(weekAgoActuals, accountPoPJ5.accountId == weekAgoActuals.accountId, 'left')\
                           .drop(weekAgoActuals.accountId)

# COMMAND ----------

currentWeekRunRate = spark.sql(f"""
select    accountId,
          round(sum(d.revShareDollars), 2) weekRunRate
from {USAGEC_AGGORDER_DAILY} d
join {BI_DATES} dt on d.usage_date = dt.date
where date >= date_sub(current_date,8)
and date <= date_sub(current_date,2)
group by 1
""")

accountPoPJ7 = accountPoPJ6.join(currentWeekRunRate, accountPoPJ6.accountId == currentWeekRunRate.accountId, 'left')\
                           .drop(currentWeekRunRate.accountId)


plat_pop_metrics = spark.sql(f""" select distinct accountId, cast(month_end_date as string) month_end_date from {USAGEC_POPMETRICS}""")
accountPoPJ8 = accountPoPJ7.join(plat_pop_metrics, accountPoPJ7.accountId == plat_pop_metrics.accountId, 'left')\
                           .drop(plat_pop_metrics.accountId)

# COMMAND ----------

accountPoPJ8.count()

# COMMAND ----------

accountPoPJ8.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_ACCOUNT_POPMETRICS)

# COMMAND ----------

# %sql
# create table bdw.usagec_account_popmetrics
# using delta
# location '/mnt/bse-dev/test_usagec_account_popmetrics'

# COMMAND ----------

# import json
# dbutils.notebook.exit(json.dumps({
#   "status": "OK"
# }))

# COMMAND ----------

# MAGIC %sh
# MAGIC pip install simple-salesforce

# COMMAND ----------

#dbutils.library.installPyPI("simple-salesforce")

from simple_salesforce import Salesforce
import pandas as pd
import numpy as np

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

from datetime import datetime

# COMMAND ----------

def get_creds(prefix):
  """
  params:
         prefix - 'uat' for uat, 'sfdcprod' for prod
  returns:
         list of user_name, password, security_token, client_id, client_secret
  """
  username = dbutils.secrets.get('api-creds', prefix+'_username')
  password = dbutils.secrets.get('api-creds', prefix+'_password')
  consumer_key = dbutils.secrets.get('api-creds', prefix+'_consumer_key')
  privatekey_file=dbutils.secrets.get('api-creds', prefix+'_privatekey_location')
  return [username, password, consumer_key, privatekey_file]


def get_sfdc_connection(creds, domain):
  """
  params:
         creds - connection credentials
         domain - 'test' for uat, 'databricks.my' for prod
  returns:
         sfdc connection object
  """
  return Salesforce(username=creds[0], \
                    password=creds[1], \
                    consumer_key=creds[2], \
                    privatekey_file=creds[3], \
                    domain=domain)


def get_dataframe(query, environement_prefix, domain):

    """
    calls get_creds, get_sfdc_connection functions
    uses salesforce's soql query api 
    params: query, environement_prefix, domain
    returns: pandas dataframe
    """
  
    creds = get_creds(environement_prefix)
    sf = get_sfdc_connection(creds, domain)
    
    list_data_records = []
    data = sf.query(query)
    list_data_records = data['records']
    prev_counter = 0
    cur_counter = 0
    while 'nextRecordsUrl' in data.keys():
        next_record = data['nextRecordsUrl'].split('/')[-1]
        data = sf.query_more(next_record)
        list_data_records += data['records']
        if cur_counter-prev_counter >= 50000:
          prev_counter = cur_counter
          sf = get_sfdc_connection(creds, domain) # connection reset
        cur_counter = len(list_data_records)
    return pd.DataFrame(list_data_records).drop(columns='attributes')
  
  
import numpy as np
import pandas as pd
from pyspark.sql.types import *
pandas_spark_types_map = {
                    np.int8: ByteType(),
                    np.uint8: ShortType(),
                    np.int16: ShortType(),
                    np.uint16: IntegerType(),
                    np.int32: IntegerType(),
                    np.int64: LongType(),
                    np.float32: FloatType(),
                    np.float64: DoubleType(),
                    np.string_: StringType(),
                    np.str_: StringType(),
                    np.unicode_: StringType(),
                    np.bool_: BooleanType(),
                    np.object_: StringType()
                }

def build_spark_schema(numpy_dtypes):
    """
    takes pandas dtypes and converts to Spark Schema
    parms: numpy_dtypes, pandas_spark_types_map
    returns: Pyspark Schema
    """
    return StructType([StructField(col_name, pandas_spark_types_map[col_type.type], True) for col_name, col_type in numpy_dtypes.iteritems()])

# COMMAND ----------

@udf("String")
def popUniqueId(accountId):
  return accountId

pop_rename_column_map = {
  "accountId" : "Account_Id__c",
  "RevShareLastWeek" : "RevShareLastWeek__c",
  "RevShareCurrentWeek" : "RevShareCurrentWeek__c",
  "RevShareNextWeek" : "RevShareFsctNextWeek__c",
  "RevShareLastMonth" : "RevShareLastMonth__c",
  "RevShareCurrentMonth" : "RevShareCurrentMonth__c",
  "RevShareNextMonth" : "RevShareFcstNextMonth__c",
  "RevShareLastQtr" : "RevShareLastQtr__c",
  "RevShareCurrentQtr" : "RevShareCurrentQtr__c",
  "RevShareNextQtr" : "RevShareFcstNextQtr__c",
  "2QTRAgoActuals": "Two_Quarters_Ago_Actuals__c",
  "CurrentQTRAEForecastDollars": "Current_Quarter_AE_Forecast__c",
  "NextQTRAEForecastDollars": "Next_Quarter_AE_Forecast__c",
  "3MonthAgoActuals": "Three_Months_Ago_Actuals__c",
  "2MonthAgoActuals":"Two_Months_Ago_Actuals__c",
  "CurrentMonth_AEForecastDBUDollars": "Current_Month_AE_Forecast__c",
  "CurrentMonth_DSForecastDBUDollars": "Current_Month_Actuals_DS_Forecast__c",
  "NextMonth_AEForecastDBUDollars": "Next_Month_AE_Forecast__c",
  "NextMonth_DSForecastDBUDollars": "Next_Month_DS_Forecast__c",
  "Next2Month_AEForecastDBUDollars": "Two_Months_from_now_AE_Forecast__c",
  "Next2Month_DSForecastDBUDollars": "Two_Months_from_now_DS_Forecast__c",
  "curMonthRunRate": "Current_Month_Run_Rate_Rollup__c",
  "nextMonthRunRate": "Next_Month_Run_Rate_Rollup__c",
  "4WeekAgoActuals": "Four_Weeks_ago_Actuals__c",
  "3WeekAgoActuals": "Three_Weeks_ago_Actuals__c",
  "2WeekAgoActuals": "Two_Weeks_ago_Actuals__c",
  "weekRunRate": "Run_Rate__c",
  "Unique_Id__c":"Unique_Id__c",
  "T3MRevShareDollars": "T3MRevShareDollars__c",
  "month_end_date" : "Usage_Date__c",
  "RevShareDollarsQTD": "RevShareDollarsQTD__c",
  "RevShareDollarsMTD": "RevShareDollarsMTD__c",
  "RevShareDollarsWTD": "RevShareDollarsWTD__c"  
}

# COMMAND ----------

popdf = spark.sql(f"""
select *
from {USAGEC_ACCOUNT_POPMETRICS}
""")

popdf = popdf.withColumn("Unique_Id__c", popUniqueId("accountId"))
pop = popdf.toPandas()
pop = pop.replace({np.nan: 0.0})


pop = pop[sorted(pop_rename_column_map.keys())]
pop = pop.rename(columns = pop_rename_column_map)
pop['RecordTypeId'] = pop.apply(lambda row: "0123f000000PEvGAAW", axis=1)

pop['Last_Week_Actuals__c'] = pop['RevShareLastWeek__c']
pop['Current_Week_Actuals_DS_Forecast__c'] = pop['RevShareCurrentWeek__c']
pop['Next_Week_DS_Forecast__c'] = pop['RevShareFsctNextWeek__c']

pop['Last_Month_Actuals__c'] = pop['RevShareLastMonth__c']
pop['Current_Month_Actuals_DS_Forecast__c'] = pop['RevShareCurrentMonth__c']
pop['Next_Month_DS_Forecast__c'] = pop['RevShareFcstNextMonth__c']


pop['Last_Quarter_Actuals__c'] = pop['RevShareLastQtr__c']
pop['Current_Quarter_Actuals_DS_Forecast__c'] = pop['RevShareCurrentQtr__c']
pop['Next_Quarter_DS_Forecast__c'] = pop['RevShareFcstNextQtr__c']

pop = pop.reindex(sorted(pop.columns), axis=1)
upsert_pop = pop.copy()

pop_upsert_data = [val for val in upsert_pop.T.to_dict().values()]
print(upsert_pop.shape)

# COMMAND ----------

if environment == 'production':
  creds = get_creds('sfdcprod')
  sf = get_sfdc_connection(creds, 'login')
  sf.bulk.Consumption__c.upsert(data=pop_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)

# COMMAND ----------

account_pop_consumption_soql_query = """
SELECT Id, Account_Id__c, Unique_Id__c, RevShareLastQtr__c, RevShareDollarsQTD__c, RevShareDollarsMTD__c, Usage_Date__c FROM Consumption__c WHERE RecordTypeId = '0123f000000PEvGAAW'
"""
 
accpop_consumption_df = get_dataframe(account_pop_consumption_soql_query, 'sfdcprod', 'login')
accpop_consumption_schema = build_spark_schema(accpop_consumption_df.dtypes)
spark_pop_consumption_df = spark.createDataFrame(accpop_consumption_df, accpop_consumption_schema)
spark_pop_consumption_df.createOrReplaceTempView("sfdc_account_popmetrics")

# COMMAND ----------

outDatedPoPMetricsIds = [ {'Id':row.Id} for row in spark.sql("""
select Id
from sfdc_account_popmetrics
where Account_Id__c <> Unique_Id__c
""").collect()]
 
print(len(outDatedPoPMetricsIds))

# COMMAND ----------

if len(outDatedPoPMetricsIds) > 0 and environment == 'production':
  creds = get_creds('sfdcprod')
  sf = get_sfdc_connection(creds, 'login')
  sf.bulk.Consumption__c.delete(outDatedPoPMetricsIds, batch_size=3000, use_serial=True)

# COMMAND ----------

#cleanup existing account pop records
zeroup_outDatedAccountPoPIds = spark.sql(f"""
select sfdc.Id
from sfdc_account_popmetrics sfdc
left join {USAGEC_ACCOUNT_POPMETRICS} acc on sfdc.Account_Id__c = acc.accountId
where acc.accountId is null
""")
 
zeroup_outDatedAccountPoPIds = zeroup_outDatedAccountPoPIds.withColumn("T3MRevShareDollars__c", lit("0.0"))\
                                                           .withColumn("RevShareLastWeek__c", lit("0.0"))\
                                                           .withColumn("RevShareCurrentWeek__c", lit("0.0"))\
                                                           .withColumn("RevShareFsctNextWeek__c", lit("0.0"))\
                                                           .withColumn("RevShareLastMonth__c", lit("0.0"))\
                                                           .withColumn("RevShareCurrentMonth__c", lit("0.0"))\
                                                           .withColumn("RevShareFcstNextMonth__c", lit("0.0"))\
                                                           .withColumn("RevShareLastQtr__c", lit("0.0"))\
                                                           .withColumn("RevShareCurrentQtr__c", lit("0.0"))\
                                                           .withColumn("RevShareFcstNextQtr__c", lit("0.0"))
 
  
zeroup_outDatedAccountPoPIds_count = zeroup_outDatedAccountPoPIds.count()
print(zeroup_outDatedAccountPoPIds_count)
 
if zeroup_outDatedAccountPoPIds_count > 0 and environment == 'production':
  
  zeroup_outDatedAccountPoPIds_pd = zeroup_outDatedAccountPoPIds.toPandas()
  zeroup_outDatedAccountPoPIds_data = [val for val in zeroup_outDatedAccountPoPIds_pd.T.to_dict().values()]
  creds = get_creds('sfdcprod')
  sf = get_sfdc_connection(creds, 'login')
  sf.bulk.Consumption__c.upsert(data=zeroup_outDatedAccountPoPIds_data, external_id_field='Id', batch_size=1000)  

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))

# COMMAND ----------


