# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

# MAGIC %md
# MAGIC Comparable with Daily Usage Build
# MAGIC - Excludes windowing functions so as to keep the same grain as PUM

# COMMAND ----------

sap_usage_granular_df = spark.sql(f"""
select sfdc_account_id accountID,
       sfdc_account_name accountName,
       p.date usage_date,
       lower(sku) usage_sku,
       round(net_usage_amount,4) dbu_quantity,
       w.Id workspaceSFDCID, -- need to join in workspace table
       platform,
       shard_region deployedRegion,
       sfdc_workspace_id as workspaceId,
       business_subscription_id businessSubscriptionID,
       round(list_price, 2) listPrice,
       rev_share_price dbuRevSharePrice,
       discount_price dbuCustPrice,      
       round(workload_insights_metric.delta_dbu,4) delta_dbu_quantity,
       coalesce(workload_insights_metric.isv_dbu,0) isv_dbu_quantity,
       coalesce(workload_insights_metric.dbt_dbu,0) dbt_dbu_quantity,
       coalesce(sales_comp_metric.uc_dbu, 0) uc_dbu_quantity,
       coalesce(sales_comp_metric.uc_dollars, 0) uc_dbu_dollars,
       coalesce(workload_insights_metric.ml_dbu, 0) ml_dbu_quantity,
       coalesce(workload_insights_metric.fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dbu, 0) streaming_dlt_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dollars, 0) streaming_dlt_dbu_dollars,
       coalesce(sales_comp_metric.cpu_model_serving_dollars, 0) cpu_model_serving_dollars,
       coalesce(sales_comp_metric.gpu_model_serving_dbu, 0) gpu_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.gpu_model_serving_dollars, 0) gpu_model_serving_dollars,
       coalesce(sales_comp_metric.throughput_model_serving_dbu, 0) throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.throughput_model_serving_dollars, 0) throughput_model_serving_dollars,
       coalesce(sales_comp_metric.foundation_model_api_dbu, 0) foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.foundation_model_api_dollars, 0) foundation_model_api_dollars,
       coalesce(sales_comp_metric.foundation_model_training_dollars, 0) foundation_model_training_dollars,
       coalesce(sales_comp_metric.vector_search_dbu, 0) vector_search_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_dollars, 0) vector_search_dollars,
       coalesce(sales_comp_metric.vector_search_ingestion_dollars, 0) vector_search_ingestion_dollars,
       coalesce(sales_comp_metric.vector_search_serving_dollars, 0) vector_search_serving_dollars,
       coalesce(sales_comp_metric.gen_ai_dbu, 0) gen_ai_dbu_quantity,
       coalesce(sales_comp_metric.gen_ai_dollars, 0) gen_ai_dbu_dollars,
       coalesce(sales_comp_metric.lakeflow_connect_dbu, 0) lakeflow_connect_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_pipelines_dbu, 0) lakeflow_pipelines_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_dbu, 0) lakeflow_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_connect_dollars, 0) lakeflow_connect_dollars,
       coalesce(sales_comp_metric.lakeflow_pipelines_dollars, 0) lakeflow_pipelines_dollars,
       coalesce(sales_comp_metric.lakeflow_dollars, 0) lakeflow_dollars,
       coalesce(sales_comp_metric.batch_inference_model_serving_dbu, 0) as batch_inference_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.batch_inference_model_serving_dollars, 0) as batch_inference_model_serving_dollars,
       coalesce(sales_comp_metric.agent_framework_dbu, 0) as agent_framework_dbu_quantity,
       coalesce(sales_comp_metric.agent_framework_dollars, 0) as agent_framework_dollars,
       coalesce(sales_comp_metric.vector_search_storage_dbu, 0) as vector_search_storage_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_storage_dollars, 0) as vector_search_storage_dollars,
       coalesce(sales_comp_metric.fy26_ai_dbu, 0) as fy26_ai_dbu_quantity,
       coalesce(sales_comp_metric.fy26_ai_dollars, 0) as fy26_ai_dollars,
       0 mct_dbu_quantity,
       0 mct_dbu_dollars,
       0 mct_model_hero_run_training_dollars,
       0 mct_model_reserved_training_dollars,
       0 mct_model_on_demand_training_dollars,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_amount,0) as finetuning_dbu_quantity,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_dollars,0) as 
       finetuning_dollars,
       coalesce(sales_comp_metric.agent_evaluation_dbu,0) as agent_evals_dbu_quantity,
       coalesce(sales_comp_metric.agent_evaluation_dollars,0) as agent_evals_dollars,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dbu,0) as agent_evals_synthetic_data_dbu_quantity,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dollars,0) as agent_evals_synthetic_data_dollars,
       coalesce(sales_comp_metric.ai_runtime_dbu,0) as ai_runtime_dbu_quantity,
       coalesce(sales_comp_metric.ai_runtime_dollars,0) as ai_runtime_dollars,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dbu,0) as anthropic_throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dollars,0) as anthropic_throughput_model_serving_dollars,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dbu,0) as anthropic_foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dollars,0) as anthropic_foundation_model_api_dollars,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_amount,0) as model_serving_fmapi_dbu_quantity,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_dollars,0) as model_serving_fmapi_dollars,
       coalesce(sales_comp_metric.lakehouse_monitoring_dbu, 0) as lakehouse_monitoring_dbu,
       coalesce(sales_comp_metric.lakehouse_monitoring_dollars, 0) as lakehouse_monitoring_dollars,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dbu, 0) as fm_mixtral_8_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dbu, 0) as fm_llama2_70b_chat_dbu,
       coalesce(sales_comp_metric.fm_bge_large_en_dbu, 0) as fm_bge_large_en_dbu,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dbu, 0) as fm_mpt_30b_instruct_dbu,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dbu, 0) as fm_mpt_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dbu, 0) as fm_databricks_dbrx_chat_dbu,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dollars, 0) as fm_mixtral_8_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dollars, 0) as fm_llama2_70b_chat_dollars,
       coalesce(sales_comp_metric.fm_bge_large_en_dollars, 0) as fm_bge_large_en_dollars,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dollars, 0) as fm_mpt_30b_instruct_dollars,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dollars, 0) as fm_mpt_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dollars, 0) as fm_databricks_dbrx_chat_dollars,
       usage_dollars dbu_dollars,
       add_on.shield_dollars,
       is_paying isPaying
from {FINANCE_PAID_METERING_USAGE} p
left join {SFDC_WORKSPACE} w 
  on p.sfdc_workspace_id = w.workspaceId__c
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
where platform = 'sap'
  and p.date >= '{SOURCE_SWITCH_DATE}'
order by usage_date desc 
""")

sap_usage_granular_df.createOrReplaceTempView("sap_usage_granular")


# COMMAND ----------

sap_orders_granular_query = f"""
with initial_usage_orders (
select ug.*,
       agg.aggOrder,
       agg.SubscriptionID,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit,
       'shared' as scope
from sap_usage_granular ug
join (
  select null usageBurstDate,
        concat("MTMSAP",coalesce(sfdc_account_id, 'noSFDCAccountID'))  AggOrder,
        coalesce(sfdc_account_id, 'noSFDCAccountID') sfdcAccountID,
        coalesce(sfdc_account_name, 'noSFDCAccountName') sfdcAccountName, 
        'sap' Platform,
        'SAPSubscriptionID' SubscriptionID, 
        min(date) startDate,
        date_add(min(date), (365*25)) endDate,
        0 cloudPartnerPurchase,
        0 ActualPartnerCommit,
        0 DBShareCommit,
        cast(0 as double) dbuCustPriceDiscount,
        concat("MTM",coalesce(sfdc_account_id, 'noSFDCAccountID')) orderId
  from {FINANCE_PAID_METERING_USAGE}
  where platform = 'sap'
  group by sfdc_account_id, sfdc_account_name
) agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
                         and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where ug.platform in ('sap')
order by usage_date
)
select *
from initial_usage_orders
"""

sap_orders_granular_df = spark.sql(sap_orders_granular_query)
sap_orders_granular_df = sap_orders_granular_df.select(*sorted(sap_orders_granular_df.columns))

# COMMAND ----------

sap_orders_granular_df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC Comparable with Daily Rollups:
# MAGIC 1. Have kept the code structure / style similar
# MAGIC 2. Removed burst calculations since they are no longer relevant going forward. This consumption pipeline is not used for burndown.
# MAGIC 3. Most of the code here is only for matching the schema to the current schema for prod-daily. There are no grain changes or aggregations that take place as a part of this code.
# MAGIC 4. The code has logic for calculating cumulative revShare and DBU numbers

# COMMAND ----------

# DBTITLE 1,Relevant functions from Daily Rollups
@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def sql_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType in ('sql', 'virtual') else 0

@udf("double")
def sql_dollars(dbu_quantity, skuType, dbuRevSharePrice):
  if dbuRevSharePrice is None:
    return 0.0
  return (dbu_quantity * dbuRevSharePrice) if skuType in ('sql', 'virtual') else 0.0

@udf("string")
def entitlementTier(usage_sku):
  
  entitlementTier = "Unknown"
  if "enterprise" in usage_sku:
    entitlementTier = "Enterprise"
  elif "premium" in usage_sku:
    entitlementTier = "Premium"
  else:
    entitlementTier = "Standard"
  
  return entitlementTier

@udf("double")
def standardDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Standard" else 0.0

@udf("double")
def premiumDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Premium" else 0.0  

@udf("double")
def enterpriseDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Enterprise" else 0.0  

@udf("double")
def moonCakeDBUs(deployedRegion, dbu_quantity):
  if deployedRegion is None:
    return 0.0
  return dbu_quantity if 'china' in deployedRegion else 0.0

@udf("double")
def moonCakeDeltaDBUs(deployedRegion, delta_dbu_quantity):
  if deployedRegion is None:
    return 0.0
  return delta_dbu_quantity if 'china' in deployedRegion else 0.0

@udf("double")
def moonCakeSQLDBUs(deployedRegion, dbu_quantity, skuType):
  if deployedRegion is None:
    return 0.0
  return dbu_quantity if ('china' in deployedRegion and skuType == 'sql') else 0.0

@udf("double")
def serverlessDBUs(usage_sku, dbu_quantity):
  return dbu_quantity if 'serverless' in usage_sku.lower() else 0.0

@udf("double")
def photonDBUs(usage_sku, dbu_quantity):
  return dbu_quantity if 'photon' in usage_sku.lower() else 0.0

@udf("double")
def dltDBUs(usage_sku, dbu_quantity):
  return dbu_quantity if 'dlt' in usage_sku.lower() else 0.0

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"

# COMMAND ----------

dates_df = spark.sql(f"select * from main.it_core_dim.bi_dates")
product_df = spark.sql(f"""
select distinct meterSubCategory skuType, 
                meterName 
from main.it_core_dim.bi_product_dim
where meterCategory = 'workloads'
and coalesce(meterSubCategory,'') <> 'virtual' --in ('automated', 'interactive', 'sql', null)
""")


prod_daily = sap_orders_granular_df.withColumn("dbuRevSharePrice", col("dbuRevSharePrice").cast("double"))

# COMMAND ----------

prod_daily = prod_daily.withColumn("month", date_format(prod_daily.usage_date, 'yyyy-MM'))\
                       .withColumn("listDollars", round(col("listPrice")*col("dbu_quantity"), 6))\
                       .withColumn("custDollars", round(col("dbu_quantity")*col("dbuCustPrice") + when(col("platform") == "azure", col("shield_dollars")/0.85).otherwise(col("shield_dollars")), 6))\
                       .withColumn("revShareDollars", round(col("dbu_dollars"), 6))\
                       .withColumn("DeltaRevShareDollars", round(col("dbuRevSharePrice")*col("delta_dbu_quantity"), 6))\
                       .withColumn("ISVRevShareDollars", round(col("dbuRevSharePrice")*col("isv_dbu_quantity"), 6))\
                       .withColumn("DBTRevShareDollars", round(col("dbuRevSharePrice")*col("dbt_dbu_quantity"), 6))\
                       .withColumn("FivetranRevShareDollars", round(col("dbuRevSharePrice")*col("fivetran_dbu_quantity"), 6))\
                       .withColumn("GenAIRevShareDollars", round(col("gen_ai_dbu_dollars"), 6))\
                       .withColumn("MCTRevShareDollars", round(col("mct_dbu_dollars"), 6))\
                       .withColumn("StreamingDLTRevShareDollars", round(col("streaming_dlt_dbu_dollars"), 6))\
                       .withColumn("StreamingDLTRevShareDollars_calculated", round(col("dbuRevSharePrice")*col("streaming_dlt_dbu_quantity"), 6))
                       

prod_daily = prod_daily.withColumnRenamed("cloudPartnerPurchase", "ListCommit")\
                       .withColumnRenamed("ActualPartnerCommit", "DiscountedCommit")\
                       .withColumnRenamed("DBShareCommit", "RevShareCommit")\
                       .withColumnRenamed("uc_dbu_quatity", "uc_dbu_quantity")

# COMMAND ----------

# add sku-type
prod_daily = prod_daily.join(product_df, prod_daily.usage_sku == product_df.meterName, 'left')\
                       .drop(product_df.meterName)

# add interactive/automated dbus
prod_daily = prod_daily.withColumn("InteractiveDBUs", coalesce(interactive_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("AutomatedDBUs", coalesce(automated_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaInteractiveDBUs", coalesce(interactive_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaAutomatedDBUs", coalesce(automated_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaSQLDBUs", coalesce(sql_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLAnalyticsDBUs", coalesce(sql_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLRevShareDollars", round(sql_dollars("dbu_quantity", "skuType", "dbuRevSharePrice"), 6))\
                       .withColumn("EntitlementTier", entitlementTier("usage_sku"))\
                       .withColumn("StandardDBUs", standardDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("PremiumDBUs", premiumDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("EnterpriseDBUs", enterpriseDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("StandardRevShareDollars", round(col("dbuRevSharePrice")*col("StandardDBUs"), 6))\
                       .withColumn("PremiumRevShareDollars", round(col("dbuRevSharePrice")*col("PremiumDBUs"), 6))\
                       .withColumn("EnterpriseRevShareDollars", round(col("dbuRevSharePrice")*col("EnterpriseDBUs"), 6))\
                       .withColumn("ServerlessDBUs", serverlessDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("ServerlessRevShareDollars", round(col("dbuRevSharePrice")*col("ServerlessDBUs"), 6))\
                       .withColumn("PhotonDBUs", photonDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("PhotonRevShareDollars", round(col("dbuRevSharePrice")*col("PhotonDBUs"), 6))\
                       .withColumn("DLTDBUs", dltDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("DLTRevShareDollars", round(col("dbuRevSharePrice")*col("DLTDBUs"), 6))\
                       .withColumn("UCRevShareDollars", round(col("uc_dbu_dollars"), 6))\
                       .withColumn("MLRevShareDollars", round(col("dbuRevSharePrice")*col("ml_dbu_quantity"), 6))\
                       .withColumn("GPUModelServingRevShareDollars", round(col("gpu_model_serving_dollars"), 6))\
                       .withColumn("ThroughputModelServingRevShareDollars", round(col("throughput_model_serving_dollars"), 6))\
                       .withColumn("FoundationModelAPIRevShareDollars", round(col("foundation_model_api_dollars"), 6))\
                       .withColumn("VectorSearchRevShareDollars", round(col("vector_search_dollars"), 6))\
                       .withColumn("UCRevShareDollars_calculated", round(col("dbuRevSharePrice")*col("uc_dbu_quantity"), 6))\
                       .withColumn("CPUModelServingRevShareDollars", round(col("cpu_model_serving_dollars"), 6))\
                       .withColumn("FoundationModelTrainingRevShareDollars", round(col("foundation_model_training_dollars"), 6))\
                       .withColumn("VectorSearchIngestionRevShareDollars", round(col("vector_search_ingestion_dollars"), 6))\
                       .withColumn("VectorSearchServingRevShareDollars", round(col("vector_search_serving_dollars"), 6))\
                       .withColumn("MCTModelHeroRunTrainingRevShareDollars", round(col("mct_model_hero_run_training_dollars"), 6))\
                       .withColumn("MCTModelReservedTrainingRevShareDollars", round(col("mct_model_reserved_training_dollars"), 6))\
                       .withColumn("MCTModelOnDemandTrainingRevShareDollars", round(col("mct_model_on_demand_training_dollars"), 6))\
                       .withColumn("LakeflowConnectDBUs", round(col("lakeflow_connect_dbu_quantity"), 6))\
                       .withColumn("LakeflowPipelinesDBUs", round(col("lakeflow_pipelines_dbu_quantity"), 6))\
                       .withColumn("LakeflowDBUs", round(col("lakeflow_dbu_quantity"), 6))\
                       .withColumn("LakeflowConnectRevShareDollars", round(col("lakeflow_connect_dollars"), 6))\
                       .withColumn("LakeflowPipelinesRevShareDollars", round(col("lakeflow_pipelines_dollars"), 6))\
                       .withColumn("LakeflowRevShareDollars", round(col("lakeflow_dollars"), 6))\
                       .withColumn("BatchInferenceModelServingDBUs", round(col("batch_inference_model_serving_dbu_quantity"), 6))\
                       .withColumn("BatchInferenceModelServingRevShareDollars", round(col("batch_inference_model_serving_dollars"), 6))\
                       .withColumn("AgentFrameworkDBUs", round(col("agent_framework_dbu_quantity"), 6))\
                       .withColumn("AgentFrameworkRevShareDollars", round(col("agent_framework_dollars"), 6))\
                       .withColumn("VectorSearchStorageDBUs", round(col("vector_search_storage_dbu_quantity"), 6))\
                       .withColumn("VectorSearchStorageRevShareDollars", round(col("vector_search_storage_dollars"), 6))\
                       .withColumn("FY26AIDBUs", round(col("fy26_ai_dbu_quantity"), 6))\
                       .withColumn("FY26AIDollars", round(col("fy26_ai_dollars"), 6))\
                       .withColumn("FinetuningDBUs", round(col("finetuning_dbu_quantity"), 6))\
                       .withColumn("FinetuningRevShareDollars", round(col("finetuning_dollars"), 6))\
                       .withColumn("AgentEvalsDBUs", round(col("agent_evals_dbu_quantity"), 6))\
                       .withColumn("AgentEvalsRevShareDollars", round(col("agent_evals_dollars"), 6))\
                       .withColumn("AgentEvalsSyntheticDataDBUs", round(col("agent_evals_synthetic_data_dbu_quantity"), 6))\
                       .withColumn("AgentEvalsSyntheticDataRevShareDollars", round(col("agent_evals_synthetic_data_dollars"), 6))\
                       .withColumn("AIRuntimeDBUs", round(col("ai_runtime_dbu_quantity"), 6))\
                       .withColumn("AIRuntimeRevShareDollars", round(col("ai_runtime_dollars"), 6))\
                       .withColumn("AnthropicThroughputModelServingDBUs", round(col("anthropic_throughput_model_serving_dbu_quantity"), 6))\
                       .withColumn("AnthropicThroughputModelServingRevShareDollars", round(col("anthropic_throughput_model_serving_dollars"), 6))\
                       .withColumn("AnthropicFoundationModelAPIDBUs", round(col("anthropic_foundation_model_api_dbu_quantity"), 6))\
                       .withColumn("AnthropicFoundationModelAPIRevShareDollars", round(col("anthropic_foundation_model_api_dollars"), 6))\
                       .withColumn("ModelServingFMAPIDBUs", round(col("model_serving_fmapi_dbu_quantity"), 6))\
                       .withColumn("ModelServingFMAPIRevShareDollars", round(col("model_serving_fmapi_dollars"), 6))\
                       .withColumn("LakehouseMonitoringDBUs", round(col("lakehouse_monitoring_dbu"), 6))\
                       .withColumn("LakehouseMonitoringRevShareDollars", round(col("lakehouse_monitoring_dollars"), 6))\
                       .withColumn("FmMixtral87bInstructDBUs", round(col("fm_mixtral_8_7b_instruct_dbu"), 6))\
                       .withColumn("FmLlama270bChatDBUs", round(col("fm_llama2_70b_chat_dbu"), 6))\
                       .withColumn("FmBgeLargeENDBUs", round(col("fm_bge_large_en_dbu"), 6))\
                       .withColumn("FmMpt30bInstructDBUs", round(col("fm_mpt_30b_instruct_dbu"), 6))\
                       .withColumn("FmMpt7bInstructDBUs", round(col("fm_mpt_7b_instruct_dbu"), 6))\
                       .withColumn("FmDatabricksDbrxChatDBUs", round(col("fm_databricks_dbrx_chat_dbu"), 6))\
                       .withColumn("FmMixtral87bInstructRevShareDollars", round(col("fm_mixtral_8_7b_instruct_dollars"), 6))\
                       .withColumn("FmLlama270bChatRevShareDollars", round(col("fm_llama2_70b_chat_dollars"), 6))\
                       .withColumn("FmBgeLargeENRevShareDollars", round(col("fm_bge_large_en_dollars"), 6))\
                       .withColumn("FmMpt30bInstructRevShareDollars", round(col("fm_mpt_30b_instruct_dollars"), 6))\
                       .withColumn("FmMpt7bInstructRevShareDollars", round(col("fm_mpt_7b_instruct_dollars"), 6))\
                       .withColumn("FmDatabricksDbrxChatRevShareDollars", round(col("fm_databricks_dbrx_chat_dollars"), 6))                         
                               
prod_daily = prod_daily.withColumn("MoonCakeDBUs", moonCakeDBUs("deployedRegion", "dbu_quantity"))\
                       .withColumn("MoonCakeDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDBUs"), 6))\
                       .withColumn("MoonCakeDeltaDBUs", moonCakeDeltaDBUs("deployedRegion", "delta_dbu_quantity"))\
                       .withColumn("MoonCakeDeltaDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDeltaDBUs"), 6))\
                       .withColumn("MoonCakeSQLDBUs", moonCakeSQLDBUs("deployedRegion", "delta_dbu_quantity", "skuType"))\
                       .withColumn("MoonCakeSQLDollars", round(col("dbuRevSharePrice")*col("MoonCakeSQLDBUs"), 6))     

# Drop upstream dollar columns w/ original name
columns_to_drop = ['gen_ai_dbu_dollars','streaming_dlt_dbu_dollars','uc_dbu_dollars','gpu_model_serving_dollars'
                   ,'throughput_model_serving_dollars','foundation_model_api_dollars','vector_search_dollars'
                   ,'mct_dbu_dollars','cpu_model_serving_dollars','foundation_model_training_dollars','vector_search_ingestion_dollars','vector_search_serving_dollars','mct_model_hero_run_training_dollars','mct_model_reserved_training_dollars','mct_model_on_demand_training_dollars', 
                   'lakeflow_connect_dbu_quantity', 'lakeflow_pipelines_dbu_quantity', 'lakeflow_dbu_quantity', 'lakeflow_connect_dollars', 'lakeflow_pipelines_dollars', 'lakeflow_dollars',
                   'batch_inference_model_serving_dbu_quantity', 'batch_inference_model_serving_dollars', 'agent_framework_dbu_quantity', 'agent_framework_dollars', 'vector_search_storage_dbu_quantity', 'vector_search_storage_dollars', 'fy26_ai_dbu_quantity', 'fy26_ai_dollars', 'finetuning_dbu_quantity', 'finetuning_dollars', 'agent_evals_dbu_quantity', 'agent_evals_dollars', 'agent_evals_synthetic_data_dbu_quantity', 'agent_evals_synthetic_data_dollars', 'ai_runtime_dbu_quantity', 'ai_runtime_dollars','anthropic_throughput_model_serving_dbu_quantity', 'anthropic_throughput_model_serving_dollars', 'anthropic_foundation_model_api_dbu_quantity', 'anthropic_foundation_model_api_dollars', 'model_serving_fmapi_dbu_quantity', 'model_serving_fmapi_dollars', 'lakehouse_monitoring_dbu', 'lakehouse_monitoring_dollars', 'fm_mixtral_8_7b_instruct_dbu', 'fm_llama2_70b_chat_dbu', 'fm_bge_large_en_dbu', 'fm_mpt_30b_instruct_dbu', 'fm_mpt_7b_instruct_dbu', 'fm_databricks_dbrx_chat_dbu', 'fm_mixtral_8_7b_instruct_dollars', 'fm_llama2_70b_chat_dollars', 'fm_bge_large_en_dollars', 'fm_mpt_30b_instruct_dollars', 'fm_mpt_7b_instruct_dollars', 'fm_databricks_dbrx_chat_dollars']

prod_daily = prod_daily.drop(*columns_to_drop)

# COMMAND ----------

# DBTITLE 1,orders_daily
orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]

groupbyColumns = ["accountId", "accountName", "platform", "aggOrder", "usage_date", "ListCommit","DiscountedCommit", "RevShareCommit"]

usage_window = Window.partitionBy(*partitionByColumns)\
                      .orderBy("usage_date")\
                      .rowsBetween(Window.unboundedPreceding, Window.currentRow)


orders_daily = prod_daily.groupBy(*groupbyColumns)\
                                              .agg(\
                                                    round(sum("listDollars"),4).alias("listDollars"),\
                                                    round(sum("custDollars"),4).alias("custDollars"),\
                                                    round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                    round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                    round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                    round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                    round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                    round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                    round(sum("DeltaSQLDBUs"),4).alias("DeltaSQLDBUs"),\
                                                    round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                    round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                    round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                    round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                    round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                    round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                    round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                    round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                    round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                    round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                    round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                    round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars"),\
                                                    round(sum("isv_dbu_quantity"),4).alias("ISVDBUs"),\
                                                    round(sum("ISVRevShareDollars"),4).alias("ISVRevShareDollars"),\
                                                    round(sum("dbt_dbu_quantity"),4).alias("DBTDBUs"),\
                                                    round(sum("DBTRevShareDollars"),4).alias("DBTRevShareDollars"),\
                                                    round(sum("fivetran_dbu_quantity"),4).alias("FivetranDBUs"),\
                                                    round(sum("FivetranRevShareDollars"),4).alias("FivetranRevShareDollars"),\
                                                    round(sum("ServerlessDBUs"),4).alias("ServerlessDBUs"),\
                                                    round(sum("ServerlessRevShareDollars"),4).alias("ServerlessRevShareDollars"),\
                                                    round(sum("PhotonDBUs"),4).alias("PhotonDBUs"),\
                                                    round(sum("PhotonRevShareDollars"),4).alias("PhotonRevShareDollars"),\
                                                    round(sum("DLTDBUs"),4).alias("DLTDBUs"),\
                                                    round(sum("DLTRevShareDollars"),4).alias("DLTRevShareDollars"),\
                                                    round(sum("MoonCakeSQLDBUs"),4).alias("MoonCakeSQLDBUs"),\
                                                    round(sum("MoonCakeSQLDollars"),4).alias("MoonCakeSQLDollars"),\
                                                    round(sum("dbu_quantity"),6).alias("DBUs"),\
                                                    round(sum("delta_dbu_quantity"),6).alias("DeltaDBUs"),\
                                                    round(sum("streaming_dlt_dbu_quantity"),6).alias("StreamingDLTDBUs"),\
                                                    round(sum("StreamingDLTRevShareDollars"),4).alias("StreamingDLTRevShareDollars"),\
                                                    round(sum("uc_dbu_quantity"),6).alias("UCDBUs"),\
                                                    round(sum("UCRevShareDollars"),4).alias("UCRevShareDollars"),\
                                                    round(sum("gen_ai_dbu_quantity"),6).alias("GenAIDBUs"),\
                                                    round(sum("GenAIRevShareDollars"),4).alias("GenAIRevShareDollars"),\
                                                    round(sum("ml_dbu_quantity"),6).alias("MLDBUs"),\
                                                    round(sum("MLRevShareDollars"),4).alias("MLRevShareDollars"),\
                                                    round(sum("gpu_model_serving_dbu_quantity"),6).alias("GPUModelServingDBUs"),\
                                                    round(sum("GPUModelServingRevShareDollars"),4).alias("GPUModelServingRevShareDollars"),\
                                                    round(sum("CPUModelServingRevShareDollars"),4).alias("CPUModelServingRevShareDollars"),\
                                                    round(sum("throughput_model_serving_dbu_quantity"),6).alias("ThroughputModelServingDBUs"),\
                                                    round(sum("ThroughputModelServingRevShareDollars"),4).alias("ThroughputModelServingRevShareDollars"),\
                                                    round(sum("foundation_model_api_dbu_quantity"),6).alias("FoundationModelAPIDBUs"),\
                                                    round(sum("FoundationModelAPIRevShareDollars"),4).alias("FoundationModelAPIRevShareDollars"),\
                                                    round(sum("FoundationModelTrainingRevShareDollars"),4).alias("FoundationModelTrainingRevShareDollars"),\
                                                    round(sum("vector_search_dbu_quantity"),6).alias("VectorSearchDBUs"),\
                                                    round(sum("VectorSearchRevShareDollars"),4).alias("VectorSearchRevShareDollars"),\
                                                    round(sum("VectorSearchIngestionRevShareDollars"),4).alias("VectorSearchIngestionRevShareDollars"),\
                                                    round(sum("VectorSearchServingRevShareDollars"),4).alias("VectorSearchServingRevShareDollars"),\
                                                    round(sum("mct_dbu_quantity"),6).alias("MCTDBUs"),\
                                                    round(sum("MCTRevShareDollars"),4).alias("MCTRevShareDollars"),\
                                                    round(sum("MCTModelHeroRunTrainingRevShareDollars"),4).alias("MCTModelHeroRunTrainingRevShareDollars"),\
                                                    round(sum("MCTModelReservedTrainingRevShareDollars"),4).alias("MCTModelReservedTrainingRevShareDollars"),\
                                                    round(sum("MCTModelOnDemandTrainingRevShareDollars"),4).alias("MCTModelOnDemandTrainingRevShareDollars"),\
                                                    round(sum("LakeflowConnectDBUs"),4).alias("LakeflowConnectDBUs"),
                                                    round(sum("LakeflowPipelinesDBUs"),4).alias("LakeflowPipelinesDBUs"),
                                                    round(sum("LakeflowDBUs"),4).alias("LakeflowDBUs"),
                                                    round(sum("LakeflowConnectRevShareDollars"),4).alias("LakeflowConnectRevShareDollars"),
                                                    round(sum("LakeflowPipelinesRevShareDollars"),4).alias("LakeflowPipelinesRevShareDollars"),
                                                    round(sum("LakeflowRevShareDollars"),4).alias("LakeflowRevShareDollars"),
                                                    round(sum("BatchInferenceModelServingDBUs"), 4).alias("BatchInferenceModelServingDBUs"),
                                                    round(sum("BatchInferenceModelServingRevShareDollars"), 4).alias("BatchInferenceModelServingRevShareDollars"),
                                                    round(sum("AgentFrameworkDBUs"), 4).alias("AgentFrameworkDBUs"),
                                                    round(sum("AgentFrameworkRevShareDollars"), 4).alias("AgentFrameworkRevShareDollars"),
                                                    round(sum("VectorSearchStorageDBUs"), 4).alias("VectorSearchStorageDBUs"),
                                                    round(sum("VectorSearchStorageRevShareDollars"), 4).alias("VectorSearchStorageRevShareDollars"),
                                                    round(sum("FY26AIDBUs"), 4).alias("FY26AIDBUs"),
                                                    round(sum("FY26AIDollars"), 4).alias("FY26AIDollars"),
                                                    round(sum("UCRevShareDollars_calculated"),4).alias("UCRevShareDollars_calculated"),\
                                                    round(sum("StreamingDLTRevShareDollars_calculated"),4).alias("StreamingDLTRevShareDollars_calculated"),round(sum("FinetuningDBUs"), 4).alias("FinetuningDBUs"),
                                                    round(sum("FinetuningRevShareDollars"), 4).alias("FinetuningRevShareDollars"),
                                                    round(sum("AgentEvalsDBUs"), 4).alias("AgentEvalsDBUs"),
                                                    round(sum("AgentEvalsRevShareDollars"), 4).alias("AgentEvalsRevShareDollars"),
                                                    round(sum("AgentEvalsSyntheticDataDBUs"), 4).alias("AgentEvalsSyntheticDataDBUs"),
                                                    round(sum("AgentEvalsSyntheticDataRevShareDollars"), 4).alias("AgentEvalsSyntheticDataRevShareDollars"),
                                                    round(sum("AIRuntimeDBUs"), 4).alias("AIRuntimeDBUs"),
                                                    round(sum("AIRuntimeRevShareDollars"), 4).alias("AIRuntimeRevShareDollars"),
                                                    round(sum("AnthropicThroughputModelServingDBUs"), 4).alias("AnthropicThroughputModelServingDBUs"),
                                                    round(sum("AnthropicThroughputModelServingRevShareDollars"), 4).alias("AnthropicThroughputModelServingRevShareDollars"),
                                                    round(sum("AnthropicFoundationModelAPIDBUs"), 4).alias("AnthropicFoundationModelAPIDBUs"),
                                                    round(sum("AnthropicFoundationModelAPIRevShareDollars"), 4).alias("AnthropicFoundationModelAPIRevShareDollars"),
                                                    round(sum("ModelServingFMAPIDBUs"), 4).alias("ModelServingFMAPIDBUs"),
                                                    round(sum("ModelServingFMAPIRevShareDollars"), 4).alias("ModelServingFMAPIRevShareDollars"),
                                                    round(sum("LakehouseMonitoringDBUs"), 4).alias("LakehouseMonitoringDBUs"),
                                                    round(sum("LakehouseMonitoringRevShareDollars"), 4).alias("LakehouseMonitoringRevShareDollars"),
                                                    round(sum("FmMixtral87bInstructDBUs"), 4).alias("FmMixtral87bInstructDBUs"),
                                                    round(sum("FmLlama270bChatDBUs"), 4).alias("FmLlama270bChatDBUs"),
                                                    round(sum("FmBgeLargeENDBUs"), 4).alias("FmBgeLargeENDBUs"),
                                                    round(sum("FmMpt30bInstructDBUs"), 4).alias("FmMpt30bInstructDBUs"),
                                                    round(sum("FmMpt7bInstructDBUs"), 4).alias("FmMpt7bInstructDBUs"),
                                                    round(sum("FmDatabricksDbrxChatDBUs"), 4).alias("FmDatabricksDbrxChatDBUs"),
                                                    round(sum("FmMixtral87bInstructRevShareDollars"), 4).alias("FmMixtral87bInstructRevShareDollars"),
                                                    round(sum("FmLlama270bChatRevShareDollars"), 4).alias("FmLlama270bChatRevShareDollars"),
                                                    round(sum("FmBgeLargeENRevShareDollars"), 4).alias("FmBgeLargeENRevShareDollars"),
                                                    round(sum("FmMpt30bInstructRevShareDollars"), 4).alias("FmMpt30bInstructRevShareDollars"),
                                                    round(sum("FmMpt7bInstructRevShareDollars"), 4).alias("FmMpt7bInstructRevShareDollars"),
                                                    round(sum("FmDatabricksDbrxChatRevShareDollars"), 4).alias("FmDatabricksDbrxChatRevShareDollars")
                                                    )




orders_daily = orders_daily.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                          .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                          .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                          .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                          .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                          .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                          .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                          .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                          .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                          .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

orders_daily = orders_daily.withColumnRenamed("cumDBDollars", "cumRevShareDollars")
orders_daily = orders_daily.withColumn("consumptionType", consumptionType("aggOrder"))
orders_daily = orders_daily.select(*sorted(orders_daily.columns))

# COMMAND ----------

orders_daily.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_SAP_ORDERS_DAILY)

# COMMAND ----------

# DBTITLE 1,prod_daily
prod_daily = prod_daily.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                    .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                    .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                    .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                    .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                    .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                    .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                    .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                    .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                    .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))


# COMMAND ----------

dateSelectColumns = ["date", "isMonthEnd", "year_month"]
datesFiltered = dates_df.select(*dateSelectColumns)\
                        .filter(dates_df.isMonthEnd==1)\
                        .drop(dates_df.isMonthEnd)\
                        .withColumnRenamed("date", "month_end_date")


prod_daily = prod_daily.join(datesFiltered, prod_daily.month==datesFiltered.year_month)\
                                      .drop(datesFiltered.year_month)

prod_daily = prod_daily.drop(prod_daily.month)

# COMMAND ----------

columns_to_drop = ['dbu_dollars','shield_dollars']
prod_daily = prod_daily.drop(*columns_to_drop)

# COMMAND ----------

prod_daily.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_SAP_PROD_DAILY)
