# Databricks notebook source
# This notebook is intended to be included (via %run) into other notebooks.

# COMMAND ----------

def create_uc_schema(catalog, schema):
  """
  Creates a UC schema if the schema does not exists.

  PARAMS:
  schema : Schema name to be created
  catalog : Catalog of the schema
  """
  try:
    if not spark.catalog.databaseExists("{}.{}".format(catalog, schema)):
      print("Creating schema {}.{}".format(catalog, schema))
      spark.sql("""USE CATALOG {};""".format(catalog))
      spark.sql("""CREATE SCHEMA IF NOT EXISTS {}""".format(schema))
    else:
      print("Schema already existis!")
  except Exception as e:
    print("Cannot create the schema {}.{}. Error : {}".format(catalog, schema, str(e)))    
  return

# COMMAND ----------

def consumption_validation(finance_usage, finance_paid_usage_metering, finance_pvc_usage, finance_pubsec_usage, usage_table, bi_dates, dbu_dollars_col):
  spark.sql(f"""
  create or replace temporary view finance_consumption
  as 
  with pubSec (
  select fiscal_year fiscalYear, fiscal_qtr fiscalQtr, 
        round(sum(dbu_dollars),0) pubsecQtrFinance
  from {finance_pubsec_usage}
  where fiscal_year >= 'FY19'
  group by 1,2
  order by 1,2
  ), 

  pvc (
  select fiscal_year fiscalYear, fiscal_qtr fiscalQtr, 
        round(sum(dbu_dollars),0) pvcQtrFinance
  from {finance_pvc_usage}
  where fiscal_year >= 'FY19'
  group by 1,2
  order by 1,2
  ),

  allPVC(
  select case when p.fiscalYear='FY21' then 2021
              when p.fiscalYear='FY22' then 2022
              when p.fiscalYear='FY23' then 2023
              when p.fiscalYear='FY24' then 2024
              when p.fiscalYear='FY25' then 2025
              when p.fiscalYear='FY20' then 2020
              when p.fiscalYear='FY19' then 2019            
        end as fiscalYear,
        case when p.fiscalQtr='Q1' then 1
              when p.fiscalQtr='Q2' then 2
              when p.fiscalQtr='Q3' then 3
              else 4
        end as fiscalQtr,
        (pubsecQtrFinance + pvcQtrFinance) privateQtrFinance
  from pubSec pu
  join pvc p on pu.fiscalYear = p.fiscalYear and pu.fiscalQtr = p.fiscalQtr
  order by 1,2
  ),

  SAS (
  select dt.fiscalYear,
        dt.fiscalQuarter,
        sum(qtrFinance) qtrFinance
  from (
      select dt.fiscalYear, 
            dt.fiscalQuarter, 
            round(sum(dbu_dollars),2) qtrFinance
      from {finance_usage} f
      join {bi_dates} dt on f.date = dt.date
      where dt.date between '2018-02-01' and '2020-12-31'
      group by 1,2

      UNION ALL

      select dt.fiscalYear, 
            dt.fiscalQuarter, 
            round(sum(usage_dollars),2) - round(sum(sales_comp_metric.mct_dollars),2) qtrFinance
      from {finance_paid_usage_metering} f
      join {bi_dates} dt on f.date = dt.date
      where dt.date >= '2021-01-01'
      group by 1,2
      order by 1,2
      ) dt
  group by 1,2
  )

  select s.fiscalYear,
        s.fiscalQuarter,
        (coalesce(privateQtrFinance,0) + qtrFinance) qtrFinance
  from SAS s
  left join allPVC p on s.fiscalYear = p.fiscalYear and s.fiscalQuarter = p.fiscalQtr
  order by 1,2
  """)


  spark.sql(f"""
  create or replace temporary view validate_consumption
  as
  with sfdc (
  select
    dt.fiscalYear,
    dt.fiscalQuarter,
    sum({dbu_dollars_col}) qtrSFDC
  from
    {usage_table} c
    join {bi_dates} dt 
    on c.usage_date = dt.date
  group by
    dt.fiscalYear,
    dt.fiscalQuarter
  order by
    dt.fiscalYear,
    dt.fiscalQuarter
  )


  select s.fiscalYear,
        s.fiscalQuarter,
        s.qtrSFDC,
        f.qtrFinance,
        (qtrSFDC - qtrFinance) diff,
        ((qtrSFDC - qtrFinance)/qtrFinance) * 100 diff_percentage
        
  from sfdc s
  join finance_consumption f on s.fiscalYear = f.fiscalYear and s.fiscalQuarter = f.fiscalQuarter
  order by s.fiscalYear, s.fiscalQuarter
  """)

  validate_consumption = spark.sql("""

    select *
    from validate_consumption 
    where abs(diff_percentage) > 2

  """)

  return validate_consumption

# COMMAND ----------

common_base_config = {
  "SFDC_DB_NAME" : "main.sfdc_bronze"
}
common_config = {
  "FINANCE_DBU_DOLLARS" : "main.it_lakehouse.dbu_dollars_prior_to_2021_vw",
  "FINANCE_USAGE_PRICING" : "main.it_lakehouse.dbu_dollars_prior_to_2021_vw",
  "FINANCE_PAID_METERING_USAGE" : "main.fin_live_gold.paid_usage_metering",
  "SOURCE_SWITCH_DATE" : "2021-01-01",
  "SFDC_WORKSPACE" : common_base_config["SFDC_DB_NAME"] + ".workspace__c",
  "BI_AGGORDERS" : "main.it_consumption_silver.bi_aggorders",
  "DIM_REGION" : "main.it_core_dim.bi_region_dim",
  "BI_DATES" : "main.it_core_dim.bi_dates",
  "PRODUCT_DIM" : "main.it_core_dim.bi_product_dim",
  "ACCOUNT_DIM" : "main.it_core_dim.bi_account_dim",
  "FINANCE_PUBSEC_USAGE" : "main.fin_live_gold.pubsec_usage",
  "FINANCE_PVC_USAGE" : "main.fin_live_gold.pvc_usage",
  "ACCCOUNT_DATE_FORECAST" : "main.data_forecasting.account_date_forecast_reconciled",
  "ACCCOUNT_DATE_FORECAST_GENAI" : "main.data_forecasting.account_date_forecast_non_mct_view",
  "SFDC_ACCOUNT" : common_base_config["SFDC_DB_NAME"] + ".account",
  "SFDC_WORKSPACE_USER" : common_base_config["SFDC_DB_NAME"] + ".workspace_user__c",
  "SFDC_USECASE_MORR" : common_base_config["SFDC_DB_NAME"] + ".usecase_morr__c",
  "SFDC_USECASE" : common_base_config["SFDC_DB_NAME"] + ".usecase__c",
  "SFDC_PLATFORM_SUBSCRIPTION": common_base_config["SFDC_DB_NAME"] + ".platformsubscription__c",
  "CPQ_AWS_GCP_CONTRACTS_ORDERS_VW" : "main.it_cpq_silver.cpq_aws_gcp_contracts_orders_vw",
  "AZURE_CONTRACTS_ORDERS_PARALLEL_VW" : "main.it_cpq_silver.azure_contracts_orders_parallel_vw",
  "CPQ_AWS_GCP_CONTRACTS_ORDERS_PARALLEL_WORKSPACES_VW" : "main.it_cpq_silver.cpq_aws_gcp_contracts_orders_parallel_workspaces_vw",
}

# COMMAND ----------


OUTPUT_DB_NAME_DEV = "users.yuri_dagosto"
OUTPUT_VOLUME_DEV = "/Volumes/integration/it_consumption_silver/intermediate_files_test/"

dev_config = {  
  "USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION" : OUTPUT_VOLUME_DEV + "usagec_prod_daily_modified_adhoc",
  "USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION" : OUTPUT_VOLUME_DEV + "usagec_agg_order_daily_adhoc",  
  "USAGE_PROD_DAILY_INTERMEDIATE" : OUTPUT_DB_NAME_DEV + ".usagec_prod_daily_intermediate",  
  "USAGE_PROD_DAILY_GRANULAR_LOCATION" : OUTPUT_VOLUME_DEV + "usagec_prod_daily_granular",
  "USAGE_PROD_DAILY_GRANULAR_ADHOC_LOCATION" : OUTPUT_VOLUME_DEV + "usagec_prod_daily_granular_adhoc",
  "PARALLEL_CONTRACTS_CLEAN_LOCATION" : OUTPUT_VOLUME_DEV + "parallel_contracts_clean",
  "OVERLAPPING_PARALLEL_CONTRACTS_LOCATION" : OUTPUT_VOLUME_DEV + "process_overlapping_parallel_contracts_04152022.csv",
  "TRUE_OVERLAPPING_ORDERS_CLEANED_LOCATION" : OUTPUT_VOLUME_DEV + "trueOverlappingOrdersCleanedv7.csv",
  "ACCOUNT_USAGE_AND_FORECAST" : "main.it_consumption_silver.account_usage_and_forecast",
  "USAGE_AGGORDER_DAILY_GOLD_ADHOC_LOCATION" : OUTPUT_VOLUME_DEV + "usagec_aggorder_daily_gold_adhoc",
  "USAGE_AGG_ORDER_DAILY_ADHOC_PVC_LOCATION" : OUTPUT_VOLUME_DEV + "usagec_agg_order_daily_adhoc_pvc",
  "USAGE_AGG_ORDER_DAILY_ADHOC_PVC_BACKUP_LOCATION" : OUTPUT_VOLUME_DEV + "backup_usagec_agg_order_daily_adhoc_pvc",
  "BI_AGGORDERS_PVC_LOCATION" : OUTPUT_VOLUME_DEV + "bi_aggorders_pvc",
  "USAGEC_AGG_ORDER_DAILY_ADHOC_PVC_INTERMEDIATE_LOCATION" : OUTPUT_VOLUME_DEV + "usagec_agg_order_daily_adhoc_pvc_intermediate",
  "USAGEC_PROD_DAILY_PVC_LOCATION" : OUTPUT_VOLUME_DEV + "usagec_prod_daily_pvc",
  "USAGEC_AGGORDER_DAILY_PVC_LOCATION" : OUTPUT_VOLUME_DEV + "pvc_usagec_aggorder_daily_gold/",
  "USAGE_PLATFORM_DAILY" : OUTPUT_DB_NAME_DEV + ".usagec_platform_daily",  
  "USAGE_ACCOUNT_DAILY" : OUTPUT_DB_NAME_DEV + ".usagec_account_daily",  
  "USAGEC_AGGORDER_DAILY" : OUTPUT_DB_NAME_DEV + ".usagec_aggorder_daily",
  "USAGEC_PLATFORM_MONTHLY" : OUTPUT_DB_NAME_DEV + ".usagec_platform_monthly",
  "USAGEC_POPMETRICS" : OUTPUT_DB_NAME_DEV + ".usagec_popmetrics ",
  "USAGEC_ACCOUNT_MONTHLY" : OUTPUT_DB_NAME_DEV + ".usagec_account_monthly",
  "USAGEC_AGGORDER_MONTHLY" : OUTPUT_DB_NAME_DEV + ".usagec_aggorder_monthly",
  "USAGEC_MAXDATES" : OUTPUT_DB_NAME_DEV + ".usagec_maxdates",
  "USAGEC_SAP_PROD_DAILY" : OUTPUT_DB_NAME_DEV + ".usagec_sap_prod_daily",
  "USAGEC_SAP_ORDERS_DAILY" : OUTPUT_DB_NAME_DEV + ".usagec_sap_orders_daily",
  "USAGEC_PROD_DAILY" : OUTPUT_DB_NAME_DEV + ".usagec_prod_daily",
  "USAGEC_ACCOUNT_POPMETRICS" : OUTPUT_DB_NAME_DEV + ".usagec_account_popmetrics",
  "PVC_USAGE_DAILY_LOCATION" : OUTPUT_VOLUME_DEV + "pvc_usage_daily",
  "ORDER_CONSUMPTION_DAILY_STAGING_LOCATION" : OUTPUT_VOLUME_DEV + "order_consumption_daily_staging",  
  "ORDER_CONSUMPTION_DAILY_LOCATION" : OUTPUT_VOLUME_DEV + "order_consumption_daily",
  "USAGEC_CONSUMPTION_DAILY_STG" : OUTPUT_DB_NAME_DEV + ".usagec_consumption_daily_parallel_stg",
  "USAGEC_CONSUMPTION_DAILY" : OUTPUT_DB_NAME_DEV + ".usagec_consumption_daily",
  "FINANCE_USAGE_STAGE" : OUTPUT_DB_NAME_DEV + ".usagec_fin_staging"
}

dev_config.update(common_config)

OUTPUT_DB_NAME_TEST = "integration.it_consumption_silver"
OUTPUT_VOLUME_TEST = "/Volumes/integration/it_consumption_silver/intermediate_files_test/"
test_config = {
  "USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION" : OUTPUT_VOLUME_TEST + "usagec_prod_daily_modified_adhoc",
  "USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION" : OUTPUT_VOLUME_TEST + "usagec_agg_order_daily_adhoc",  
  "USAGE_PROD_DAILY_INTERMEDIATE" : OUTPUT_DB_NAME_TEST + ".usagec_prod_daily_intermediate",
  "USAGE_PROD_DAILY_GRANULAR_LOCATION" : OUTPUT_VOLUME_TEST + "usagec_prod_daily_granular",
  "USAGE_PROD_DAILY_GRANULAR_ADHOC_LOCATION" : OUTPUT_VOLUME_TEST + "usagec_prod_daily_granular_adhoc",
  "PARALLEL_CONTRACTS_CLEAN_LOCATION" : OUTPUT_VOLUME_TEST + "parallel_contracts_clean",
  "OVERLAPPING_PARALLEL_CONTRACTS_LOCATION" : OUTPUT_VOLUME_TEST + "process_overlapping_parallel_contracts_04152022.csv",
  "TRUE_OVERLAPPING_ORDERS_CLEANED_LOCATION" : OUTPUT_VOLUME_TEST + "trueOverlappingOrdersCleanedv7.csv",
  "ACCOUNT_USAGE_AND_FORECAST" : "main.it_consumption_silver.account_usage_and_forecast",
  "USAGE_AGGORDER_DAILY_GOLD_ADHOC_LOCATION" : OUTPUT_VOLUME_TEST + "usagec_aggorder_daily_gold_adhoc",
  "USAGE_AGG_ORDER_DAILY_ADHOC_PVC_LOCATION" : OUTPUT_VOLUME_TEST + "usagec_agg_order_daily_adhoc_pvc",
  "USAGE_AGG_ORDER_DAILY_ADHOC_PVC_BACKUP_LOCATION" : OUTPUT_VOLUME_TEST + "backup_usagec_agg_order_daily_adhoc_pvc",
  "BI_AGGORDERS_PVC_LOCATION" : OUTPUT_VOLUME_TEST + "bi_aggorders_pvc",
  "USAGEC_AGG_ORDER_DAILY_ADHOC_PVC_INTERMEDIATE_LOCATION" : OUTPUT_VOLUME_TEST + "usagec_agg_order_daily_adhoc_pvc_intermediate",
  "USAGEC_PROD_DAILY_PVC_LOCATION" : OUTPUT_VOLUME_TEST + "usagec_prod_daily_pvc",
  "USAGEC_AGGORDER_DAILY_PVC_LOCATION" : OUTPUT_VOLUME_TEST + "pvc_usagec_aggorder_daily_gold/",
  "USAGE_PLATFORM_DAILY" : OUTPUT_DB_NAME_TEST + ".usagec_platform_daily",
  "USAGE_ACCOUNT_DAILY" : OUTPUT_DB_NAME_TEST + ".usagec_account_daily",
  "USAGEC_AGGORDER_DAILY" : OUTPUT_DB_NAME_TEST + ".usagec_aggorder_daily",
  "USAGEC_PLATFORM_MONTHLY" : OUTPUT_DB_NAME_TEST + ".usagec_platform_monthly",
  "USAGEC_POPMETRICS" : OUTPUT_DB_NAME_TEST + ".usagec_popmetrics ",
  "USAGEC_ACCOUNT_MONTHLY" : OUTPUT_DB_NAME_TEST + ".usagec_account_monthly",
  "USAGEC_AGGORDER_MONTHLY" : OUTPUT_DB_NAME_TEST + ".usagec_aggorder_monthly",
  "USAGEC_MAXDATES" : OUTPUT_DB_NAME_TEST+ ".usagec_maxdates",
  "USAGEC_SAP_ORDERS_DAILY" : OUTPUT_DB_NAME_TEST + ".usagec_sap_orders_daily",
  "USAGEC_SAP_PROD_DAILY" : OUTPUT_DB_NAME_TEST + ".usagec_sap_prod_daily",
  "USAGEC_PROD_DAILY" : OUTPUT_DB_NAME_TEST + ".usagec_prod_daily",
  "USAGEC_ACCOUNT_POPMETRICS" : OUTPUT_DB_NAME_TEST + ".usagec_account_popmetrics",
  "PVC_USAGE_DAILY_LOCATION" : OUTPUT_VOLUME_TEST + "pvc_usage_daily",
  "ORDER_CONSUMPTION_DAILY_STAGING_LOCATION" : OUTPUT_VOLUME_TEST + "order_consumption_daily_staging",
  "ORDER_CONSUMPTION_DAILY_LOCATION" : OUTPUT_VOLUME_TEST + "order_consumption_daily",
  "USAGEC_CONSUMPTION_DAILY_STG" : OUTPUT_DB_NAME_TEST + ".usagec_consumption_daily_parallel_stg",
  "USAGEC_CONSUMPTION_DAILY" : OUTPUT_DB_NAME_TEST + ".usagec_consumption_daily",
  "FINANCE_USAGE_STAGE" : OUTPUT_DB_NAME_TEST + ".usagec_fin_staging"
}

test_config.update(common_config)

OUTPUT_DB_NAME_PROD = "main.it_consumption_silver"
OUTPUT_VOLUME_PROD = "/Volumes/integration/it_consumption_silver/intermediate_files/"
prod_config = {
  "USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_prod_daily_modified_adhoc",
  "USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_agg_order_daily_adhoc",  
  "USAGE_PROD_DAILY_INTERMEDIATE" : OUTPUT_DB_NAME_PROD + ".usagec_prod_daily_intermediate",  
  "USAGEC_PROD_DAILY_INTERMEDIATE_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_prod_daily_intermediate",  
  "USAGE_PROD_DAILY_GRANULAR_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_prod_daily_granular",
  "USAGE_PROD_DAILY_GRANULAR_ADHOC_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_prod_daily_granular_adhoc",
  "PARALLEL_CONTRACTS_CLEAN_LOCATION" : OUTPUT_VOLUME_PROD + "parallel_contracts_clean",
  "OVERLAPPING_PARALLEL_CONTRACTS_LOCATION" : OUTPUT_VOLUME_PROD + "process_overlapping_parallel_contracts_04152022.csv",
  "TRUE_OVERLAPPING_ORDERS_CLEANED_LOCATION" : OUTPUT_VOLUME_PROD + "trueOverlappingOrdersCleanedv7.csv",
  "USAGEC_MAX_DATES_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_maxdates",
  "ACCOUNT_USAGE_AND_FORECAST" : "main.it_consumption_silver.account_usage_and_forecast",
  "USAGE_AGGORDER_DAILY_GOLD_ADHOC_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_aggorder_daily_gold_adhoc",
  "USAGE_AGG_ORDER_DAILY_ADHOC_PVC_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_agg_order_daily_adhoc_pvc",
  "USAGE_AGG_ORDER_DAILY_ADHOC_PVC_BACKUP_LOCATION" : OUTPUT_VOLUME_PROD + "backup_usagec_agg_order_daily_adhoc_pvc",
  "BI_AGGORDERS_PVC_LOCATION" : OUTPUT_VOLUME_PROD + "bi_aggorders_pvc",
  "USAGEC_AGG_ORDER_DAILY_ADHOC_PVC_INTERMEDIATE_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_agg_order_daily_adhoc_pvc_intermediate",
  #"USAGEC_AGG_ORDER_DAILY_ADHOC_PVC_LOCATION" : "/mnt/bse-dev/usagec_agg_order_daily_adhoc_pvc",
  "USAGEC_PROD_DAILY_PVC_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_prod_daily_pvc",
  "USAGE_PROD_DAILY_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_prod_daily",
  "USAGEC_AGGORDER_DAILY_PVC_LOCATION" : OUTPUT_VOLUME_PROD + "pvc_usagec_aggorder_daily_gold",
  "USAGEC_AGG_ORDER_DAILY_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_aggorder_daily_gold",
  "USAGEC_AGGORDER_MONTHLY_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_aggorder_monthly_gold",
  "USAGE_PLATFORM_DAILY_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_platform_daily_gold",
  "USAGE_PLATFORM_MONTHLY_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_platform_monthly_gold",
  "USAGE_PLATFORM_DAILY" : OUTPUT_DB_NAME_PROD + ".usagec_platform_daily",
  "USAGE_ACCOUNT_DAILY_GOLD_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_account_daily_gold",
  "USAGE_ACCOUNT_DAILY" : OUTPUT_DB_NAME_PROD + ".usagec_account_daily",
  "USAGE_ACCOUNT_MONTHLY_GOLD_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_account_monthly_gold",
  "USAGEC_AGGORDER_DAILY" : OUTPUT_DB_NAME_PROD + ".usagec_aggorder_daily",
  "USAGEC_PLATFORM_MONTHLY" : OUTPUT_DB_NAME_PROD + ".usagec_platform_monthly",
  "USAGE_POPMETRICS_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_popmetrics",
  "USAGEC_POPMETRICS" : OUTPUT_DB_NAME_PROD + ".usagec_popmetrics ",
  "USAGEC_ACCOUNT_MONTHLY" : OUTPUT_DB_NAME_PROD + ".usagec_account_monthly",
  "USAGEC_AGGORDER_MONTHLY" : OUTPUT_DB_NAME_PROD + ".usagec_aggorder_monthly",
  "USAGEC_MAXDATES" : OUTPUT_DB_NAME_PROD + ".usagec_maxdates",
  "USAGEC_SAP_ORDERS_DAILY" : OUTPUT_DB_NAME_PROD + ".usagec_sap_orders_daily",
  "USAGEC_SAP_PROD_DAILY" : OUTPUT_DB_NAME_PROD + ".usagec_sap_prod_daily",
  "USAGEC_PROD_DAILY" : OUTPUT_DB_NAME_PROD + ".usagec_prod_daily",
  "USAGEC_ACCOUNT_POPMETRICS_LOCATION" : OUTPUT_VOLUME_PROD + "usagec_account_popmetrics",
  "USAGEC_ACCOUNT_POPMETRICS" : OUTPUT_DB_NAME_PROD + ".usagec_account_popmetrics",
  "PVC_USAGE_DAILY_LOCATION" : OUTPUT_VOLUME_PROD + "pvc_usage_daily",
  "ORDER_CONSUMPTION_DAILY_STAGING_LOCATION" : OUTPUT_VOLUME_PROD + "order_consumption_daily_staging",
  "ORDER_CONSUMPTION_DAILY_LOCATION" : OUTPUT_VOLUME_PROD + "order_consumption_daily",
  "USAGEC_CONSUMPTION_DAILY_STG" : OUTPUT_DB_NAME_PROD + ".usagec_consumption_daily_parallel_stg",
  "USAGEC_CONSUMPTION_DAILY" : OUTPUT_DB_NAME_PROD + ".usagec_consumption_daily",
  "FINANCE_USAGE_STAGE" : OUTPUT_DB_NAME_PROD + ".usagec_fin_staging"
}

prod_config.update(common_config)

# COMMAND ----------

#TABLE DEFINITIONS
config = {
            "development" : dev_config,
            "test" : test_config,
            "production" : prod_config
}

# COMMAND ----------

prod_config
