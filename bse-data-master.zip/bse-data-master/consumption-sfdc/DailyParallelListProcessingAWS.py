# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------



#todo : update burst
@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def sql_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType in ('sql', 'virtual') else 0

@udf("double")
def sql_dollars(dbu_quantity, skuType, dbuRevSharePrice):
  if dbuRevSharePrice is None:
    return 0.0
  return (dbu_quantity * dbuRevSharePrice) if skuType in ('sql', 'virtual') else 0.0

# @udf("boolean")
# def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  

#   if platform == "azure":
#       return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
#   isBurst = False  
#   if platform == 'aws':
#     if (cumDBDollars > RevShareCommit + 0.999):
#       if (usage_date > endDate):
#         isBurst = True
#     else:
#       if (usage_date > endDate):
#         isBurst = True
#   return isBurst

@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  if platform == "azure":
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  return (usage_date > endDate)

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"

@udf("string")
def forecastType(subscriptionId, contract_type):
  forecastType = 'MTM'
  if subscriptionId == 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = "SharedCommit"
  if subscriptionId != 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = 'SingleCommit'
  
  return forecastType

@udf("string")
def entitlementTier(usage_sku):
  
  entitlementTier = "NA"
  if "enterprise" in usage_sku:
    entitlementTier = "Enterprise"
  elif "premium" in usage_sku:
    entitlementTier = "Premium"
  else:
    entitlementTier = "Standard"
  
  return entitlementTier

@udf("double")
def standardDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Standard" else 0.0

@udf("double")
def premiumDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Premium" else 0.0  

@udf("double")
def enterpriseDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Enterprise" else 0.0  

@udf("double")
def moonCakeDBUs(deployedRegion, dbu_quantity):
  if deployedRegion is None:
    return 0.0
  return dbu_quantity if 'china' in deployedRegion else 0.0

@udf("double")
def moonCakeDeltaDBUs(deployedRegion, delta_dbu_quantity):
  if deployedRegion is None:
    return 0.0
  return delta_dbu_quantity if 'china' in deployedRegion else 0.0

@udf("double")
def moonCakeSQLDBUs(deployedRegion, dbu_quantity, skuType):
  if deployedRegion is None:
    return 0.0
  return dbu_quantity if ('china' in deployedRegion and skuType == 'sql') else 0.0

@udf("double")
def serverlessDBUs(usage_sku, dbu_quantity):
  return dbu_quantity if 'serverless' in usage_sku.lower() else 0.0

@udf("double")
def photonDBUs(usage_sku, dbu_quantity):
  return dbu_quantity if 'photon' in usage_sku.lower() else 0.0

@udf("double")
def dltDBUs(usage_sku, dbu_quantity):
  return dbu_quantity if 'dlt' in usage_sku.lower() else 0.0

# COMMAND ----------

spark.conf.set("spark.databricks.delta.formatCheck.enabled", "False")

# COMMAND ----------

overlapping_contracts = spark.read.format("csv").option("header", "true").load(OVERLAPPING_PARALLEL_CONTRACTS_LOCATION)
overlapping_contracts = overlapping_contracts.withColumn("endDate", col("endDate").cast("date"))\
                                             .withColumn("startDate", col("startDate").cast("date"))\
                                             .withColumn("cloudPartnerPurchase", col("cloudPartnerPurchase").cast("double"))\
                                             .withColumn("ActualPartnerCommit", col("ActualPartnerCommit").cast("double"))\
                                             .withColumn("DBShareCommit", col("DBShareCommit").cast("double"))\
                                             .withColumn("dbuCustPriceDiscount", col("dbuCustPriceDiscount").cast("float"))
overlapping_contracts.createOrReplaceTempView("overlapping_contracts")

# COMMAND ----------

# %sql
# select *
# from overlapping_contracts
# --where aggOrder not like 'MTM%'
# order by sfdcAccountID, startDate

# COMMAND ----------

clean_unprocessed = overlapping_contracts.select("sfdcAccountID").distinct()
clean_unprocessed.createOrReplaceTempView("clean_unprocessed")

aws_usage_granular_df = spark.sql(f"""
select sfdc_account_id accountID,
       sfdc_account_name accountName,
       date usage_date,
       lower(sku) usage_sku,
       round(dbu,4) dbu_quantity,
       workspace_sfdc_object_id workspaceSFDCID,
       ps.Name businessSubscriptionID,
       platform,
       type as product_type,
       NULL as product_features,
       list_price listPrice,
       dbu_price dbuRevSharePrice,
       discount_price dbuCustPrice,
       round(delta_dbu,4) delta_dbu_quantity,
       coalesce(isv_dbu,0) isv_dbu_quantity,
       coalesce(dbt_dbu,0) dbt_dbu_quantity,
       coalesce(uc_dbu_salescomp, 0) uc_dbu_quantity,
       coalesce(uc_dbu_dollars_salescomp, 0) uc_dbu_dollars,
       coalesce(ml_dbu, 0) ml_dbu_quantity,
       coalesce(fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(streaming_dlt_dbu_salescomp, 0) streaming_dlt_dbu_quantity,
       coalesce(streaming_dlt_dbu_dollars_salescomp, 0) streaming_dlt_dbu_dollars,
       0 cpu_model_serving_dollars,
       0 gpu_model_serving_dbu_quantity,
       0 gpu_model_serving_dollars,
       0 throughput_model_serving_dbu_quantity,
       0 throughput_model_serving_dollars,
       0 foundation_model_api_dbu_quantity,
       0 foundation_model_api_dollars,
       0 foundation_model_training_dollars,
       0 vector_search_dbu_quantity,
       0 vector_search_dollars,
       0 vector_search_ingestion_dollars,
       0 vector_search_serving_dollars,
       0 gen_ai_dbu_quantity,
       0 gen_ai_dbu_dollars,
       0 lakeflow_connect_dbu_quantity,
       0 lakeflow_pipelines_dbu_quantity,
       0 lakeflow_dbu_quantity,
       0 lakeflow_connect_dollars,
       0 lakeflow_pipelines_dollars,
       0 lakeflow_dollars,
       0 batch_inference_model_serving_dbu_quantity,
       0 batch_inference_model_serving_dollars,
       0 agent_framework_dbu_quantity,
       0 agent_framework_dollars,
       0 vector_search_storage_dbu_quantity,
       0 vector_search_storage_dollars,
       0 fy26_ai_dbu_quantity,
       0 fy26_ai_dollars,
       0 mct_dbu_dollars,
       0 mct_dbu_quantity,
       0 mct_model_hero_run_training_dollars,
       0 mct_model_reserved_training_dollars,
       0 mct_model_on_demand_training_dollars,
       0 as finetuning_dbu_quantity,
       0 as finetuning_dollars,
       0 as agent_evals_dbu_quantity,
       0 as agent_evals_dollars,
       0 as agent_evals_synthetic_data_dbu_quantity,
       0 as agent_evals_synthetic_data_dollars,
       0 as ai_runtime_dbu_quantity,
       0 as ai_runtime_dollars,
       0 as anthropic_throughput_model_serving_dbu_quantity,
       0 as anthropic_throughput_model_serving_dollars,
       0 as anthropic_foundation_model_api_dbu_quantity,
       0 as anthropic_foundation_model_api_dollars,
       0 as model_serving_fmapi_dbu_quantity,
       0 as model_serving_fmapi_dollars,
       0 as lakehouse_monitoring_dbu,
       0 as lakehouse_monitoring_dollars,
       0 as fm_mixtral_8_7b_instruct_dbu,
       0 as fm_llama2_70b_chat_dbu,
       0 as fm_bge_large_en_dbu,
       0 as fm_mpt_30b_instruct_dbu,
       0 as fm_mpt_7b_instruct_dbu,
       0 as fm_databricks_dbrx_chat_dbu,
       0 as fm_mixtral_8_7b_instruct_dollars,
       0 as fm_llama2_70b_chat_dollars,
       0 as fm_bge_large_en_dollars,
       0 as fm_mpt_30b_instruct_dollars,
       0 as fm_mpt_7b_instruct_dollars,
       0 as fm_databricks_dbrx_chat_dollars,
       dbu_dollars,
       shield_dollars,
       is_paying isPaying
from {FINANCE_DBU_DOLLARS} f
join clean_unprocessed cu on f.sfdc_account_id = cu.sfdcAccountID
left join {SFDC_WORKSPACE} w 
  on f.workspace_sfdc_object_id = w.id
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
left join {SFDC_PLATFORM_SUBSCRIPTION} ps
  on w.Business_Subscription__c = ps.id
  and ps.processDate = (
    select max(processDate)
    from {SFDC_PLATFORM_SUBSCRIPTION}
  )
where platform = 'aws'
  and date < '{SOURCE_SWITCH_DATE}'

UNION ALL

select sfdc_account_id accountID,
       sfdc_account_name accountName,
       p.date usage_date,
       lower(sku) usage_sku,
       round(net_usage_amount,4) dbu_quantity,
       w.Id workspaceSFDCID, -- need to join in workspace table
       business_subscription_id businessSubscriptionID,
       platform,
       product_type,
       product_features,
       round(list_price, 3) listPrice,
       rev_share_price dbuRevSharePrice,
       discount_price dbuCustPrice,      
       round(workload_insights_metric.delta_dbu,4) delta_dbu_quantity,
       coalesce(workload_insights_metric.isv_dbu,0) isv_dbu_quantity,
       coalesce(workload_insights_metric.dbt_dbu,0) dbt_dbu_quantity,
       coalesce(sales_comp_metric.uc_dbu, 0) uc_dbu_quantity,
       coalesce(sales_comp_metric.uc_dollars, 0) uc_dbu_dollars,
       coalesce(workload_insights_metric.ml_dbu, 0) ml_dbu_quantity,
       coalesce(workload_insights_metric.fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dbu, 0) streaming_dlt_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dollars, 0) streaming_dlt_dbu_dollars,
       coalesce(sales_comp_metric.cpu_model_serving_dollars, 0) cpu_model_serving_dollars,
       coalesce(sales_comp_metric.gpu_model_serving_dbu, 0) gpu_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.gpu_model_serving_dollars, 0) gpu_model_serving_dollars,
       coalesce(sales_comp_metric.throughput_model_serving_dbu, 0) throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.throughput_model_serving_dollars, 0) throughput_model_serving_dollars,
       coalesce(sales_comp_metric.foundation_model_api_dbu, 0) foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.foundation_model_api_dollars, 0) foundation_model_api_dollars,
       coalesce(sales_comp_metric.foundation_model_training_dollars, 0) foundation_model_training_dollars,
       coalesce(sales_comp_metric.vector_search_dbu, 0) vector_search_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_dollars, 0) vector_search_dollars,
       coalesce(sales_comp_metric.vector_search_ingestion_dollars, 0) vector_search_ingestion_dollars,
       coalesce(sales_comp_metric.vector_search_serving_dollars, 0) vector_search_serving_dollars,
       coalesce(sales_comp_metric.gen_ai_dbu, 0) gen_ai_dbu_quantity,
       coalesce(sales_comp_metric.gen_ai_dollars, 0) gen_ai_dbu_dollars,
       coalesce(sales_comp_metric.lakeflow_connect_dbu, 0) lakeflow_connect_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_pipelines_dbu, 0) lakeflow_pipelines_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_dbu, 0) lakeflow_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_connect_dollars, 0) lakeflow_connect_dollars,
       coalesce(sales_comp_metric.lakeflow_pipelines_dollars, 0) lakeflow_pipelines_dollars,
       coalesce(sales_comp_metric.lakeflow_dollars, 0) lakeflow_dollars,
       coalesce(sales_comp_metric.batch_inference_model_serving_dbu, 0) as batch_inference_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.batch_inference_model_serving_dollars, 0) as batch_inference_model_serving_dollars,
       coalesce(sales_comp_metric.agent_framework_dbu, 0) as agent_framework_dbu_quantity,
       coalesce(sales_comp_metric.agent_framework_dollars, 0) as agent_framework_dollars,
       coalesce(sales_comp_metric.vector_search_storage_dbu, 0) as vector_search_storage_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_storage_dollars, 0) as vector_search_storage_dollars,
       coalesce(sales_comp_metric.fy26_ai_dbu, 0) as fy26_ai_dbu_quantity,
       coalesce(sales_comp_metric.fy26_ai_dollars, 0) as fy26_ai_dollars,
       coalesce(sales_comp_metric.mct_dollars, 0) mct_dbu_dollars,
       coalesce(sales_comp_metric.mct_dbu, 0) mct_dbu_quantity,
       CASE WHEN mosaic_ml.sub_product_type = 'HERO_RUN' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END  mct_model_hero_run_training_dollars,
       CASE WHEN mosaic_ml.sub_product_type = 'RESERVED_TRAINING' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END mct_model_reserved_training_dollars,
       CASE WHEN mosaic_ml.sub_product_type = 'ON_DEMAND_TRAINING' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END  mct_model_on_demand_training_dollars,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_amount,0) as fintetuning_dbu_quantity,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_dollars,0) as 
       finetuning_dollars,
       coalesce(sales_comp_metric.agent_evaluation_dbu,0) as agent_evals_dbu_quantity,
       coalesce(sales_comp_metric.agent_evaluation_dollars,0) as agent_evals_dollars,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dbu,0) as agent_evals_synthetic_data_dbu_quantity,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dollars,0) as agent_evals_synthetic_data_dollars,
       coalesce(sales_comp_metric.ai_runtime_dbu,0) as ai_runtime_dbu_quantity,
       coalesce(sales_comp_metric.ai_runtime_dollars,0) as ai_runtime_dollars,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dbu,0) as anthropic_throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dollars,0) as anthropic_throughput_model_serving_dollars,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dbu,0) as anthropic_foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dollars,0) as anthropic_foundation_model_api_dollars,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_amount,0) as model_serving_fmapi_dbu_quantity,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_dollars,0) as model_serving_fmapi_dollars,
       coalesce(sales_comp_metric.lakehouse_monitoring_dbu, 0) as lakehouse_monitoring_dbu,
       coalesce(sales_comp_metric.lakehouse_monitoring_dollars, 0) as lakehouse_monitoring_dollars,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dbu, 0) as fm_mixtral_8_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dbu, 0) as fm_llama2_70b_chat_dbu,
       coalesce(sales_comp_metric.fm_bge_large_en_dbu, 0) as fm_bge_large_en_dbu,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dbu, 0) as fm_mpt_30b_instruct_dbu,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dbu, 0) as fm_mpt_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dbu, 0) as fm_databricks_dbrx_chat_dbu,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dollars, 0) as fm_mixtral_8_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dollars, 0) as fm_llama2_70b_chat_dollars,
       coalesce(sales_comp_metric.fm_bge_large_en_dollars, 0) as fm_bge_large_en_dollars,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dollars, 0) as fm_mpt_30b_instruct_dollars,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dollars, 0) as fm_mpt_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dollars, 0) as fm_databricks_dbrx_chat_dollars,
       usage_dollars dbu_dollars,
       add_on.shield_dollars,
       is_paying isPaying
from {FINANCE_PAID_METERING_USAGE} p
left join {SFDC_WORKSPACE} w 
  on p.sfdc_workspace_id = w.workspaceId__c
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
join clean_unprocessed cu on p.sfdc_account_id = cu.sfdcAccountID
where platform in ('aws')
  and p.date >= '{SOURCE_SWITCH_DATE}'
order by usage_date desc 
""")

wksp_query = f"""
  select distinct
         swk.workspaceId__c workspaceId,
         coalesce(swk.azureSubscriptionId__c, 'noSubscriptionID') SubscriptionID,
         swk.deployedRegion__c deployedRegion,
         swk.Id workspaceIdSFDC
  from {SFDC_WORKSPACE} swk
  where swk.processDate = (select max(processDate) from {SFDC_WORKSPACE})
"""
wksp_df = spark.sql(wksp_query)

aws_usage_granular_df = aws_usage_granular_df.join(wksp_df, aws_usage_granular_df.workspaceSFDCID==wksp_df.workspaceIdSFDC)\
                                             .drop(wksp_df.workspaceIdSFDC)\
                                             .drop(wksp_df.SubscriptionID)

aws_usage_granular_df.createOrReplaceTempView("aws_usage_granular")

aws_orders_granular_query = """
with initial_usage_orders (
select ug.*,
       agg.aggOrder,
       agg.SubscriptionID,
       agg.scope,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit,
       case when count(usage_date) over(partition by accountID, accountName, workspaceSFDCID, businessSubscriptionID, usage_date, usage_sku, dbu_quantity, product_type, product_features) > 1 then 'true'
            else 'false'
       end as usageFlag,
       case when scope = 'shared'  then 'false'
            else 'true'
       end as scopeFlag
from aws_usage_granular ug
join overlapping_contracts agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
                         and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where ug.platform = 'aws'
order by usage_date
)
select *
from initial_usage_orders
where (usageFlag='true' and scopeFlag='true') or (usageFlag='false' and scopeFlag='false')
"""

aws_orders_granular_df = spark.sql(aws_orders_granular_query)
dropColumns = ["usageFlag", "scopeFlag", "product_type", "product_features"]
aws_orders_granular_df = aws_orders_granular_df.drop(*dropColumns)

aws_orders_granular_df = aws_orders_granular_df.select(*sorted(aws_orders_granular_df.columns))

# COMMAND ----------

aws_usage_granular_df.count()

# COMMAND ----------

aws_orders_granular_df.count()

# COMMAND ----------

aws_orders_granular_df.select("accountId").distinct().count()

# COMMAND ----------

aws_orders_granular_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(USAGE_PROD_DAILY_GRANULAR_ADHOC_LOCATION)

# COMMAND ----------

prod_daily = spark.read.format("delta").load(USAGE_PROD_DAILY_GRANULAR_ADHOC_LOCATION)
prod_daily = prod_daily.withColumn("dbuRevSharePrice", col("dbuRevSharePrice").cast("double"))
# prod_daily = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_granular_adhoc")
dates_df = spark.sql(f"select * from {BI_DATES}")

product_df = spark.sql(f"""
select distinct meterSubCategory skuType, 
                meterName 
from {PRODUCT_DIM} 
where meterCategory = 'workloads'
and coalesce(meterSubCategory,'') <> 'virtual' --in ('automated', 'interactive', 'sql')
""")


# add month, dollars
prod_daily = prod_daily.withColumn("month", date_format(prod_daily.usage_date, 'yyyy-MM'))\
                       .withColumn("listDollars", round(col("listPrice")*col("dbu_quantity"), 6))\
                       .withColumn("custDollars", round(col("dbu_quantity")*col("dbuCustPrice") + when(col("platform") == "azure", col("shield_dollars")/0.85).otherwise(col("shield_dollars")), 6))\
                       .withColumn("revShareDollars", round(col("dbu_dollars"), 6))\
                       .withColumn("DeltaRevShareDollars", round(col("dbuRevSharePrice")*col("delta_dbu_quantity"), 6))\
                       .withColumn("ISVRevShareDollars", round(col("dbuRevSharePrice")*col("isv_dbu_quantity"), 6))\
                       .withColumn("DBTRevShareDollars", round(col("dbuRevSharePrice")*col("dbt_dbu_quantity"), 6))\
                       .withColumn("FivetranRevShareDollars", round(col("dbuRevSharePrice")*col("fivetran_dbu_quantity"), 6))\
                       .withColumn("StreamingDLTRevShareDollars", round(col("streaming_dlt_dbu_dollars"), 6))\
                       .withColumn("UCRevShareDollars", round(col("uc_dbu_dollars"), 6)) \
                       .withColumn("MLRevShareDollars", round(col("dbuRevSharePrice")*col("ml_dbu_quantity"), 6)) \
                       .withColumn("GenAIRevShareDollars", round(col("gen_ai_dbu_dollars"), 6))\
                       .withColumn("MCTRevShareDollars", round(col("mct_dbu_dollars"), 6))\
                       .withColumn("StreamingDLTRevShareDollars_calculated", round(col("dbuRevSharePrice")*col("streaming_dlt_dbu_quantity"), 6))\
                       .withColumn("UCRevShareDollars_calculated", round(col("dbuRevSharePrice")*col("uc_dbu_quantity"), 6))


prod_daily = prod_daily.withColumnRenamed("cloudPartnerPurchase", "ListCommit")\
                       .withColumnRenamed("ActualPartnerCommit", "DiscountedCommit")\
                       .withColumnRenamed("DBShareCommit", "RevShareCommit")


# add sku-type
prod_daily = prod_daily.join(product_df, prod_daily.usage_sku == product_df.meterName)\
                       .drop(product_df.meterName)

# add interactive/automated dbus
prod_daily = prod_daily.withColumn("InteractiveDBUs", coalesce(interactive_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("AutomatedDBUs", coalesce(automated_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaInteractiveDBUs", coalesce(interactive_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaAutomatedDBUs", coalesce(automated_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaSQLDBUs", coalesce(sql_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLAnalyticsDBUs", coalesce(sql_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLRevShareDollars", round(sql_dollars("dbu_quantity", "skuType", "dbuRevSharePrice"), 6))\
                       .withColumn("EntitlementTier", entitlementTier("usage_sku"))\
                       .withColumn("StandardDBUs", standardDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("PremiumDBUs", premiumDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("EnterpriseDBUs", enterpriseDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("StandardRevShareDollars", round(col("dbuRevSharePrice")*col("StandardDBUs"), 6))\
                       .withColumn("PremiumRevShareDollars", round(col("dbuRevSharePrice")*col("PremiumDBUs"), 6))\
                       .withColumn("EnterpriseRevShareDollars", round(col("dbuRevSharePrice")*col("EnterpriseDBUs"), 6))\
                       .withColumn("ServerlessDBUs", serverlessDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("ServerlessRevShareDollars", round(col("dbuRevSharePrice")*col("ServerlessDBUs"), 6))\
                       .withColumn("PhotonDBUs", photonDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("PhotonRevShareDollars", round(col("dbuRevSharePrice")*col("PhotonDBUs"), 6))\
                       .withColumn("DLTDBUs", dltDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("DLTRevShareDollars", round(col("dbuRevSharePrice")*col("DLTDBUs"), 6))\
                       .withColumn("GPUModelServingRevShareDollars", round(col("gpu_model_serving_dollars"), 6))\
                       .withColumn("ThroughputModelServingRevShareDollars", round(col("throughput_model_serving_dollars"), 6))\
                       .withColumn("FoundationModelAPIRevShareDollars", round(col("foundation_model_api_dollars"), 6))\
                       .withColumn("VectorSearchRevShareDollars", round(col("vector_search_dollars"), 6))\
                       .withColumn("CPUModelServingRevShareDollars", round(col("cpu_model_serving_dollars"), 6))\
                       .withColumn("FoundationModelTrainingRevShareDollars", round(col("foundation_model_training_dollars"), 6))\
                       .withColumn("VectorSearchIngestionRevShareDollars", round(col("vector_search_ingestion_dollars"), 6))\
                       .withColumn("VectorSearchServingRevShareDollars", round(col("vector_search_serving_dollars"), 6))\
                       .withColumn("MCTModelHeroRunTrainingRevShareDollars", round(col("mct_model_hero_run_training_dollars"), 6))\
                       .withColumn("MCTModelReservedTrainingRevShareDollars", round(col("mct_model_reserved_training_dollars"), 6))\
                       .withColumn("MCTModelOnDemandTrainingRevShareDollars", round(col("mct_model_on_demand_training_dollars"), 6))\
                       .withColumn("LakeflowConnectDBUs", round(col("lakeflow_connect_dbu_quantity"), 6))\
                       .withColumn("LakeflowPipelinesDBUs", round(col("lakeflow_pipelines_dbu_quantity"), 6))\
                       .withColumn("LakeflowDBUs", round(col("lakeflow_dbu_quantity"), 6))\
                       .withColumn("LakeflowConnectRevShareDollars", round(col("lakeflow_connect_dollars"), 6))\
                       .withColumn("LakeflowPipelinesRevShareDollars", round(col("lakeflow_pipelines_dollars"), 6))\
                       .withColumn("LakeflowRevShareDollars", round(col("lakeflow_dollars"), 6))\
                       .withColumn("BatchInferenceModelServingDBUs", round(col("batch_inference_model_serving_dbu_quantity"), 6))\
                       .withColumn("BatchInferenceModelServingRevShareDollars", round(col("batch_inference_model_serving_dollars"), 6))\
                       .withColumn("AgentFrameworkDBUs", round(col("agent_framework_dbu_quantity"), 6))\
                       .withColumn("AgentFrameworkRevShareDollars", round(col("agent_framework_dollars"), 6))\
                       .withColumn("VectorSearchStorageDBUs", round(col("vector_search_storage_dbu_quantity"), 6))\
                       .withColumn("VectorSearchStorageRevShareDollars", round(col("vector_search_storage_dollars"), 6))\
                       .withColumn("FY26AIDBUs", round(col("fy26_ai_dbu_quantity"), 6))\
                       .withColumn("FY26AIDollars", round(col("fy26_ai_dollars"), 6))\
                       .withColumn("FinetuningDBUs", round(col("finetuning_dbu_quantity"), 6))\
                       .withColumn("FinetuningRevShareDollars", round(col("finetuning_dollars"), 6))\
                       .withColumn("AgentEvalsDBUs", round(col("agent_evals_dbu_quantity"), 6))\
                       .withColumn("AgentEvalsRevShareDollars", round(col("agent_evals_dollars"), 6))\
                       .withColumn("AgentEvalsSyntheticDataDBUs", round(col("agent_evals_synthetic_data_dbu_quantity"), 6))\
                       .withColumn("AgentEvalsSyntheticDataRevShareDollars", round(col("agent_evals_synthetic_data_dollars"), 6))\
                       .withColumn("AIRuntimeDBUs", round(col("ai_runtime_dbu_quantity"), 6))\
                       .withColumn("AIRuntimeRevShareDollars", round(col("ai_runtime_dollars"), 6))\
                       .withColumn("AnthropicThroughputModelServingDBUs", round(col("anthropic_throughput_model_serving_dbu_quantity"), 6))\
                       .withColumn("AnthropicThroughputModelServingRevShareDollars", round(col("anthropic_throughput_model_serving_dollars"), 6))\
                       .withColumn("AnthropicFoundationModelAPIDBUs", round(col("anthropic_foundation_model_api_dbu_quantity"), 6))\
                       .withColumn("AnthropicFoundationModelAPIRevShareDollars", round(col("anthropic_foundation_model_api_dollars"), 6))\
                       .withColumn("ModelServingFMAPIDBUs", round(col("model_serving_fmapi_dbu_quantity"), 6))\
                       .withColumn("ModelServingFMAPIRevShareDollars", round(col("model_serving_fmapi_dollars"), 6))\
                       .withColumn("LakehouseMonitoringDBUs", round(col("lakehouse_monitoring_dbu"), 6))\
                       .withColumn("LakehouseMonitoringRevShareDollars", round(col("lakehouse_monitoring_dollars"), 6))\
                       .withColumn("FmMixtral87bInstructDBUs", round(col("fm_mixtral_8_7b_instruct_dbu"), 6))\
                       .withColumn("FmLlama270bChatDBUs", round(col("fm_llama2_70b_chat_dbu"), 6))\
                       .withColumn("FmBgeLargeENDBUs", round(col("fm_bge_large_en_dbu"), 6))\
                       .withColumn("FmMpt30bInstructDBUs", round(col("fm_mpt_30b_instruct_dbu"), 6))\
                       .withColumn("FmMpt7bInstructDBUs", round(col("fm_mpt_7b_instruct_dbu"), 6))\
                       .withColumn("FmDatabricksDbrxChatDBUs", round(col("fm_databricks_dbrx_chat_dbu"), 6))\
                       .withColumn("FmMixtral87bInstructRevShareDollars", round(col("fm_mixtral_8_7b_instruct_dollars"), 6))\
                       .withColumn("FmLlama270bChatRevShareDollars", round(col("fm_llama2_70b_chat_dollars"), 6))\
                       .withColumn("FmBgeLargeENRevShareDollars", round(col("fm_bge_large_en_dollars"), 6))\
                       .withColumn("FmMpt30bInstructRevShareDollars", round(col("fm_mpt_30b_instruct_dollars"), 6))\
                       .withColumn("FmMpt7bInstructRevShareDollars", round(col("fm_mpt_7b_instruct_dollars"), 6))\
                       .withColumn("FmDatabricksDbrxChatRevShareDollars", round(col("fm_databricks_dbrx_chat_dollars"), 6))


prod_daily = prod_daily.withColumn("MoonCakeDBUs", moonCakeDBUs("deployedRegion", "dbu_quantity"))\
                       .withColumn("MoonCakeDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDBUs"), 6))\
                       .withColumn("MoonCakeDeltaDBUs", moonCakeDeltaDBUs("deployedRegion", "delta_dbu_quantity"))\
                       .withColumn("MoonCakeDeltaDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDeltaDBUs"), 6))\
                       .withColumn("MoonCakeSQLDBUs", moonCakeSQLDBUs("deployedRegion", "delta_dbu_quantity", "skuType"))\
                       .withColumn("MoonCakeSQLDollars", round(col("dbuRevSharePrice")*col("MoonCakeSQLDBUs"), 6))

# Drop upstream dollar columns w/ original name
columns_to_drop = ['gen_ai_dbu_dollars','streaming_dlt_dbu_dollars','uc_dbu_dollars','gpu_model_serving_dollars'
                   ,'throughput_model_serving_dollars','foundation_model_api_dollars','vector_search_dollars'
                   ,'mct_dbu_dollars','cpu_model_serving_dollars','foundation_model_training_dollars','vector_search_ingestion_dollars','vector_search_serving_dollars','mct_model_hero_run_training_dollars','mct_model_reserved_training_dollars','mct_model_on_demand_training_dollars',
                   'lakeflow_connect_dbu_quantity', 'lakeflow_pipelines_dbu_quantity', 'lakeflow_dbu_quantity', 'lakeflow_connect_dollars', 'lakeflow_pipelines_dollars', 'lakeflow_dollars',
                   'batch_inference_model_serving_dbu_quantity', 'batch_inference_model_serving_dollars', 'agent_framework_dbu_quantity', 'agent_framework_dollars', 'vector_search_storage_dbu_quantity', 'vector_search_storage_dollars', 'fy26_ai_dbu_quantity', 'fy26_ai_dollars', 'finetuning_dbu_quantity', 'finetuning_dollars', 'agent_evals_dbu_quantity', 'agent_evals_dollars', 'agent_evals_synthetic_data_dbu_quantity', 'agent_evals_synthetic_data_dollars', 'ai_runtime_dbu_quantity', 'ai_runtime_dollars', 'anthropic_throughput_model_serving_dbu_quantity', 'anthropic_throughput_model_serving_dollars', 'anthropic_foundation_model_api_dbu_quantity', 'anthropic_foundation_model_api_dollars', 'model_serving_fmapi_dbu_quantity', 'model_serving_fmapi_dollars', 'lakehouse_monitoring_dbu', 'lakehouse_monitoring_dollars', 'fm_mixtral_8_7b_instruct_dbu', 'fm_llama2_70b_chat_dbu', 'fm_bge_large_en_dbu', 'fm_mpt_30b_instruct_dbu', 'fm_mpt_7b_instruct_dbu', 'fm_databricks_dbrx_chat_dbu', 'fm_mixtral_8_7b_instruct_dollars', 'fm_llama2_70b_chat_dollars', 'fm_bge_large_en_dollars', 'fm_mpt_30b_instruct_dollars', 'fm_mpt_7b_instruct_dollars', 'fm_databricks_dbrx_chat_dollars']

prod_daily = prod_daily.drop(*columns_to_drop)

dateSelectColumns = ["date", "isMonthEnd", "year_month"]
datesFiltered = dates_df.select(*dateSelectColumns)\
                        .filter(dates_df.isMonthEnd==1)\
                        .drop(dates_df.isMonthEnd)\
                        .withColumnRenamed("date", "month_end_date")


prod_daily = prod_daily.join(datesFiltered, prod_daily.month==datesFiltered.year_month)\
                                      .drop(datesFiltered.year_month)

prod_daily = prod_daily.drop(prod_daily.month)

# COMMAND ----------

# optimize dynamically
# todo: change cumDBDollars to cumRevShareDollars
orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

apmoller = prod_daily.orderBy(*orderByColumns)
apmoller = apmoller.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                   .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                   .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                   .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                   .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                   .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                   .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                   .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                   .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                   .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

burstColumns = ["cumListDollars", "listCommit", "endDate", "usage_date", "cumDBDollars", "RevShareCommit", "platform"]
apmoller = apmoller.withColumn("IsBurst", isBurst(*burstColumns))

# COMMAND ----------

apmoller.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGE_PROD_DAILY_INTERMEDIATE)

# COMMAND ----------

apmoller.count()

# COMMAND ----------

# DBTITLE 1,Remaining Parallel Accounts
rem_parallel_contracts = spark.read.format("csv").option("header", "true").load(TRUE_OVERLAPPING_ORDERS_CLEANED_LOCATION)
rem_parallel_contracts = rem_parallel_contracts.withColumn("endDate", col("endDate").cast("date"))\
                                               .withColumn("startDate", col("startDate").cast("date"))\
                                               .withColumn("cloudPartnerPurchase", col("cloudPartnerPurchase").cast("double"))\
                                               .withColumn("ActualPartnerCommit", col("ActualPartnerCommit").cast("double"))\
                                               .withColumn("DBShareCommit", col("DBShareCommit").cast("double"))
rem_parallel_contracts.createOrReplaceTempView("remaining_parallel_accounts")

# COMMAND ----------

aws_usage_granular_df = spark.sql(f"""
with parallel_accounts (
select distinct sfdcAccountID from remaining_parallel_accounts
)
select sfdc_account_id accountID,
       sfdc_account_name accountName,
       date usage_date,
       lower(sku) usage_sku,
       round(dbu,4) dbu_quantity,
       workspace_sfdc_object_id workspaceSFDCID,
       ps.Name businessSubscriptionID,
       platform,
       list_price listPrice,
       dbu_price dbuRevSharePrice,
       discount_price dbuCustPrice,
       round(delta_dbu,4) delta_dbu_quantity,
       coalesce(isv_dbu,0) isv_dbu_quantity,
       coalesce(dbt_dbu,0) dbt_dbu_quantity,
       coalesce(uc_dbu_salescomp, 0) uc_dbu_quantity,
       coalesce(uc_dbu_dollars_salescomp, 0) uc_dbu_dollars,
       coalesce(ml_dbu, 0) ml_dbu_quantity,
       coalesce(fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(streaming_dlt_dbu_salescomp, 0) streaming_dlt_dbu_quantity,
       coalesce(streaming_dlt_dbu_dollars_salescomp, 0) streaming_dlt_dbu_dollars,
       0 cpu_model_serving_dollars,
       0 gpu_model_serving_dbu_quantity,
       0 gpu_model_serving_dollars,
       0 throughput_model_serving_dbu_quantity,
       0 throughput_model_serving_dollars,
       0 foundation_model_api_dbu_quantity,
       0 foundation_model_api_dollars,
       0 foundation_model_training_dollars,
       0 vector_search_dbu_quantity,
       0 vector_search_dollars,
       0 vector_search_ingestion_dollars,
       0 vector_search_serving_dollars,
       0 gen_ai_dbu_quantity,
       0 gen_ai_dbu_dollars,
       0 lakeflow_connect_dbu_quantity,
       0 lakeflow_pipelines_dbu_quantity,
       0 lakeflow_dbu_quantity,
       0 lakeflow_connect_dollars,
       0 lakeflow_pipelines_dollars,
       0 lakeflow_dollars,
       0 batch_inference_model_serving_dbu_quantity,
       0 batch_inference_model_serving_dollars,
       0 agent_framework_dbu_quantity,
       0 agent_framework_dollars,
       0 vector_search_storage_dbu_quantity,
       0 vector_search_storage_dollars,
       0 fy26_ai_dbu_quantity,
       0 fy26_ai_dollars,
       0 mct_dbu_dollars,
       0 mct_dbu_quantity,
       0 mct_model_hero_run_training_dollars,
       0 mct_model_reserved_training_dollars,
       0 mct_model_on_demand_training_dollars,
       0 as finetuning_dbu_quantity,
       0 as finetuning_dollars,
       0 as agent_evals_dbu_quantity,
       0 as agent_evals_dollars,
       0 as agent_evals_synthetic_data_dbu_quantity,
       0 as agent_evals_synthetic_data_dollars,
       0 as ai_runtime_dbu_quantity,
       0 as ai_runtime_dollars,
       0 as anthropic_throughput_model_serving_dbu_quantity,
       0 as anthropic_throughput_model_serving_dollars,
       0 as anthropic_foundation_model_api_dbu_quantity,
       0 as anthropic_foundation_model_api_dollars,
       0 as model_serving_fmapi_dbu_quantity,
       0 as model_serving_fmapi_dollars,
       0 as lakehouse_monitoring_dbu,
       0 as lakehouse_monitoring_dollars,
       0 as fm_mixtral_8_7b_instruct_dbu,
       0 as fm_llama2_70b_chat_dbu,
       0 as fm_bge_large_en_dbu,
       0 as fm_mpt_30b_instruct_dbu,
       0 as fm_mpt_7b_instruct_dbu,
       0 as fm_databricks_dbrx_chat_dbu,
       0 as fm_mixtral_8_7b_instruct_dollars,
       0 as fm_llama2_70b_chat_dollars,
       0 as fm_bge_large_en_dollars,
       0 as fm_mpt_30b_instruct_dollars,
       0 as fm_mpt_7b_instruct_dollars,
       0 as fm_databricks_dbrx_chat_dollars,
       dbu_dollars,       
       shield_dollars,
       is_paying isPaying
from {FINANCE_DBU_DOLLARS} fup
join parallel_accounts pc on fup.sfdc_account_id = pc.sfdcAccountID
left join {SFDC_WORKSPACE} w 
  on fup.workspace_sfdc_object_id = w.id
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
left join {SFDC_PLATFORM_SUBSCRIPTION} ps
  on w.Business_Subscription__c = ps.id
  and ps.processDate = (
    select max(processDate)
    from {SFDC_PLATFORM_SUBSCRIPTION}
  )
where platform = 'aws'
  and date < '{SOURCE_SWITCH_DATE}'

UNION ALL

select sfdc_account_id accountID,
       sfdc_account_name accountName,
       p.date usage_date,
       lower(sku) usage_sku,
       round(net_usage_amount,4) dbu_quantity,
       w.Id workspaceSFDCID, -- need to join in workspace table
       business_subscription_id BusinessSubscriptionID,
       platform,
       round(list_price, 3) listPrice,
       rev_share_price dbuRevSharePrice,
       discount_price dbuCustPrice,      
       round(workload_insights_metric.delta_dbu,4) delta_dbu_quantity,
       coalesce(workload_insights_metric.isv_dbu,0) isv_dbu_quantity,
       coalesce(workload_insights_metric.dbt_dbu,0) dbt_dbu_quantity,
       coalesce(sales_comp_metric.uc_dbu, 0) uc_dbu_quantity,
       coalesce(sales_comp_metric.uc_dollars, 0) uc_dbu_dollars,
       coalesce(workload_insights_metric.ml_dbu, 0) ml_dbu_quantity,
       coalesce(workload_insights_metric.fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dbu, 0) streaming_dlt_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dollars, 0) streaming_dlt_dbu_dollars,
       coalesce(sales_comp_metric.cpu_model_serving_dollars, 0) cpu_model_serving_dollars,
       coalesce(sales_comp_metric.gpu_model_serving_dbu, 0) gpu_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.gpu_model_serving_dollars, 0) gpu_model_serving_dollars,
       coalesce(sales_comp_metric.throughput_model_serving_dbu, 0) throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.throughput_model_serving_dollars, 0) throughput_model_serving_dollars,
       coalesce(sales_comp_metric.foundation_model_api_dbu, 0) foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.foundation_model_api_dollars, 0) foundation_model_api_dollars,
       coalesce(sales_comp_metric.foundation_model_training_dollars, 0) foundation_model_training_dollars,
       coalesce(sales_comp_metric.vector_search_dbu, 0) vector_search_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_dollars, 0) vector_search_dollars,
       coalesce(sales_comp_metric.vector_search_ingestion_dollars, 0) vector_search_ingestion_dollars,
       coalesce(sales_comp_metric.vector_search_serving_dollars, 0) vector_search_serving_dollars,
       coalesce(sales_comp_metric.gen_ai_dbu, 0) gen_ai_dbu_quantity,
       coalesce(sales_comp_metric.gen_ai_dollars, 0) gen_ai_dbu_dollars,
       coalesce(sales_comp_metric.lakeflow_connect_dbu, 0) lakeflow_connect_dbu,
       coalesce(sales_comp_metric.lakeflow_pipelines_dbu, 0) lakeflow_pipelines_dbu,
       coalesce(sales_comp_metric.lakeflow_dbu, 0) lakeflow_dbu,
       coalesce(sales_comp_metric.lakeflow_connect_dollars, 0) lakeflow_connect_dollars,
       coalesce(sales_comp_metric.lakeflow_pipelines_dollars, 0) lakeflow_pipelines_dollars,
       coalesce(sales_comp_metric.lakeflow_dollars, 0) lakeflow_dollars,
       coalesce(sales_comp_metric.batch_inference_model_serving_dbu, 0) as batch_inference_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.batch_inference_model_serving_dollars, 0) as batch_inference_model_serving_dollars,
       coalesce(sales_comp_metric.agent_framework_dbu, 0) as agent_framework_dbu_quantity,
       coalesce(sales_comp_metric.agent_framework_dollars, 0) as agent_framework_dollars,
       coalesce(sales_comp_metric.vector_search_storage_dbu, 0) as vector_search_storage_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_storage_dollars, 0) as vector_search_storage_dollars,
       coalesce(sales_comp_metric.fy26_ai_dbu, 0) as fy26_ai_dbu_quantity,
       coalesce(sales_comp_metric.fy26_ai_dollars, 0) as fy26_ai_dollars,
       coalesce(sales_comp_metric.mct_dollars, 0) mct_dbu_dollars,
       coalesce(sales_comp_metric.mct_dbu, 0) mct_dbu_quantity,
       CASE WHEN mosaic_ml.sub_product_type = 'HERO_RUN' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END  mct_model_hero_run_training_dollars,
       CASE WHEN mosaic_ml.sub_product_type = 'RESERVED_TRAINING' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END mct_model_reserved_training_dollars,
       CASE WHEN mosaic_ml.sub_product_type = 'ON_DEMAND_TRAINING' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END  mct_model_on_demand_training_dollars,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_amount,0) as finetuning_dbu_quantity,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_dollars,0) as 
       finetuning_dollars,
       coalesce(sales_comp_metric.agent_evaluation_dbu,0) as agent_evals_dbu_quantity,
       coalesce(sales_comp_metric.agent_evaluation_dollars,0) as agent_evals_dollars,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dbu,0) as agent_evals_synthetic_data_dbu_quantity,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dollars,0) as agent_evals_synthetic_data_dollars,
       coalesce(sales_comp_metric.ai_runtime_dbu,0) as ai_runtime_dbu_quantity,
       coalesce(sales_comp_metric.ai_runtime_dollars,0) as ai_runtime_dollars,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dbu,0) as anthropic_throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dollars,0) as anthropic_throughput_model_serving_dollars,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dbu,0) as anthropic_foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dollars,0) as anthropic_foundation_model_api_dollars,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_amount,0) as model_serving_fmapi_dbu_quantity,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_dollars,0) as model_serving_fmapi_dollars,
       coalesce(sales_comp_metric.lakehouse_monitoring_dbu, 0) as lakehouse_monitoring_dbu,
       coalesce(sales_comp_metric.lakehouse_monitoring_dollars, 0) as lakehouse_monitoring_dollars,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dbu, 0) as fm_mixtral_8_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dbu, 0) as fm_llama2_70b_chat_dbu,
       coalesce(sales_comp_metric.fm_bge_large_en_dbu, 0) as fm_bge_large_en_dbu,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dbu, 0) as fm_mpt_30b_instruct_dbu,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dbu, 0) as fm_mpt_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dbu, 0) as fm_databricks_dbrx_chat_dbu,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dollars, 0) as fm_mixtral_8_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dollars, 0) as fm_llama2_70b_chat_dollars,
       coalesce(sales_comp_metric.fm_bge_large_en_dollars, 0) as fm_bge_large_en_dollars,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dollars, 0) as fm_mpt_30b_instruct_dollars,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dollars, 0) as fm_mpt_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dollars, 0) as fm_databricks_dbrx_chat_dollars,
       usage_dollars dbu_dollars,
       add_on.shield_dollars,
       is_paying isPaying
from {FINANCE_PAID_METERING_USAGE} p
left join {SFDC_WORKSPACE} w 
  on p.sfdc_workspace_id = w.workspaceId__c
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
join parallel_accounts pc on p.sfdc_account_id = pc.sfdcAccountID
where platform = 'aws'
  and p.date >= '{SOURCE_SWITCH_DATE}'
order by usage_date desc 
""")
wksp_query = f"""
  select distinct
         swk.workspaceId__c workspaceId,
         coalesce(swk.azureSubscriptionId__c, 'noSubscriptionID') SubscriptionID,
         swk.deployedRegion__c deployedRegion,
         swk.Id workspaceIdSFDC
  from {SFDC_WORKSPACE} swk
  where swk.processDate = (select max(processDate) from {SFDC_WORKSPACE})
"""
wksp_df = spark.sql(wksp_query)
aws_usage_granular = aws_usage_granular_df.join(wksp_df, aws_usage_granular_df.workspaceSFDCID==wksp_df.workspaceIdSFDC)\
                                             .drop(wksp_df.workspaceIdSFDC)\
                                             .drop(wksp_df.SubscriptionID)
aws_usage_granular.createOrReplaceTempView("aws_usage_granularV2")
print(aws_usage_granular_df.count())
print(aws_usage_granular.count())

# COMMAND ----------

aws_orders_granular_V2 = spark.sql("""
with initial_usage_orders (
select ug.*,
       agg.aggOrder,
       agg.SubscriptionID,
       agg.scope,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit
from aws_usage_granularV2 ug
join remaining_parallel_accounts agg on ug.accountID = agg.sfdcAccountID 
                                     and ug.platform = agg.platform 
                                     and ug.workspaceId = agg.workspaceId
                                     and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where ug.platform = 'aws'
order by usage_date
)
select *
from initial_usage_orders
"""
)
aws_orders_granular_V2 = aws_orders_granular_V2.select(*sorted(aws_orders_granular_V2.columns))
aws_orders_granular_V2.count()

# COMMAND ----------

mtm_usage_orders = spark.sql(f"""
with missing_usage_orders (
select ug.*,
       concat('MTMAWS', ug.accountId) aggOrder,
       'MTMSubscriptionID' SubscriptionID,
       'shared' scope
from aws_usage_granularV2 ug
left join remaining_parallel_accounts agg on ug.accountID = agg.sfdcAccountID 
                                     and ug.platform = agg.platform 
                                     and ug.workspaceId = agg.workspaceId
                                     and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where ug.platform = 'aws'
and agg.aggOrder is null and agg.sfdcAccountID is null and agg.startDate is null
order by usage_date
),
parallel_accounts (
select distinct sfdcAccountID from remaining_parallel_accounts
),
mtmorders (
select aggOrder,
       startDate,
       endDate,
       cloudPartnerPurchase,
       ActualPartnerCommit,
       DBShareCommit       
from {BI_AGGORDERS} agg
join parallel_accounts pc on agg.sfdcAccountId = pc.sfdcAccountID
where agg.aggOrder like 'MTMAWS%'
)

select m.*,
       mtm.startDate,
       mtm.endDate,
       mtm.cloudPartnerPurchase,
       mtm.ActualPartnerCommit,
       mtm.DBShareCommit
from missing_usage_orders m
join mtmorders mtm on m.aggOrder = mtm.aggOrder
order by accountId, usage_date desc
""")
mtm_usage_orders = mtm_usage_orders.select(*sorted(mtm_usage_orders.columns))

# COMMAND ----------

rem_aws_orders_granular_V2 = aws_orders_granular_V2.union(mtm_usage_orders)

# COMMAND ----------

rem_aws_orders_granular_V2.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(USAGE_PROD_DAILY_GRANULAR_ADHOC_LOCATION)

# COMMAND ----------

prod_daily = spark.read.format("delta").load(USAGE_PROD_DAILY_GRANULAR_ADHOC_LOCATION)
prod_daily = prod_daily.withColumn("dbuRevSharePrice", col("dbuRevSharePrice").cast("double"))
# prod_daily = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_granular_adhoc")
dates_df = spark.sql(f"select * from {BI_DATES}")
product_df = spark.sql(f"""
select distinct meterSubCategory skuType, 
                meterName 
from {PRODUCT_DIM}
where meterCategory = 'workloads'
and meterSubCategory <> 'virtual' -- in ('automated', 'interactive', 'sql')
""")

# add month, dollars
prod_daily = prod_daily.withColumn("month", date_format(prod_daily.usage_date, 'yyyy-MM'))\
                       .withColumn("listDollars", round(col("listPrice")*col("dbu_quantity"), 6))\
                       .withColumn("custDollars", round(col("dbu_quantity")*col("dbuCustPrice") + when(col("platform") == "azure", col("shield_dollars")/0.85).otherwise(col("shield_dollars")), 6))\
                       .withColumn("revShareDollars", round(col("dbu_dollars"), 6))\
                       .withColumn("DeltaRevShareDollars", round(col("dbuRevSharePrice")*col("delta_dbu_quantity"), 6))\
                       .withColumn("ISVRevShareDollars", round(col("dbuRevSharePrice")*col("isv_dbu_quantity"), 6))\
                       .withColumn("DBTRevShareDollars", round(col("dbuRevSharePrice")*col("dbt_dbu_quantity"), 6))\
                       .withColumn("FivetranRevShareDollars", round(col("dbuRevSharePrice")*col("fivetran_dbu_quantity"), 6))\
                       .withColumn("StreamingDLTRevShareDollars", round(col("streaming_dlt_dbu_dollars"), 6))\
                       .withColumn("GenAIRevShareDollars", round(col("gen_ai_dbu_dollars"), 6))\
                       .withColumn("MCTRevShareDollars", round(col("mct_dbu_dollars"), 6))\
                       .withColumn("StreamingDLTRevShareDollars_calculated", round(col("dbuRevSharePrice")*col("streaming_dlt_dbu_quantity"), 6))\
                       .withColumn("UCRevShareDollars_calculated", round(col("dbuRevSharePrice")*col("uc_dbu_quantity"), 6))

prod_daily = prod_daily.withColumnRenamed("cloudPartnerPurchase", "ListCommit")\
                       .withColumnRenamed("ActualPartnerCommit", "DiscountedCommit")\
                       .withColumnRenamed("DBShareCommit", "RevShareCommit")


# add sku-type
prod_daily = prod_daily.join(product_df, prod_daily.usage_sku == product_df.meterName)\
                       .drop(product_df.meterName)

# add interactive/automated dbus
prod_daily = prod_daily.withColumn("InteractiveDBUs", coalesce(interactive_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("AutomatedDBUs", coalesce(automated_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaInteractiveDBUs", coalesce(interactive_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaAutomatedDBUs", coalesce(automated_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaSQLDBUs", coalesce(sql_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLAnalyticsDBUs", coalesce(sql_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLRevShareDollars", round(sql_dollars("dbu_quantity", "skuType", "dbuRevSharePrice"), 6))\
                       .withColumn("EntitlementTier", entitlementTier("usage_sku"))\
                       .withColumn("StandardDBUs", standardDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("PremiumDBUs", premiumDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("EnterpriseDBUs", enterpriseDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("StandardRevShareDollars", round(col("dbuRevSharePrice")*col("StandardDBUs"), 6))\
                       .withColumn("PremiumRevShareDollars", round(col("dbuRevSharePrice")*col("PremiumDBUs"), 6))\
                       .withColumn("EnterpriseRevShareDollars", round(col("dbuRevSharePrice")*col("EnterpriseDBUs"), 6))\
                       .withColumn("ServerlessDBUs", serverlessDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("ServerlessRevShareDollars", round(col("dbuRevSharePrice")*col("ServerlessDBUs"), 6))\
                       .withColumn("PhotonDBUs", photonDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("PhotonRevShareDollars", round(col("dbuRevSharePrice")*col("PhotonDBUs"), 6))\
                       .withColumn("DLTDBUs", dltDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("DLTRevShareDollars", round(col("dbuRevSharePrice")*col("DLTDBUs"), 6))\
                       .withColumn("UCRevShareDollars", round(col("uc_dbu_dollars"), 6)) \
                       .withColumn("MLRevShareDollars", round(col("dbuRevSharePrice")*col("ml_dbu_quantity"), 6))\
                       .withColumn("GPUModelServingRevShareDollars", round(col("gpu_model_serving_dollars"), 6))\
                       .withColumn("ThroughputModelServingRevShareDollars", round(col("throughput_model_serving_dollars"), 6))\
                       .withColumn("FoundationModelAPIRevShareDollars", round(col("foundation_model_api_dollars"), 6))\
                       .withColumn("VectorSearchRevShareDollars", round(col("vector_search_dollars"), 6))\
                       .withColumn("CPUModelServingRevShareDollars", round(col("cpu_model_serving_dollars"), 6))\
                       .withColumn("FoundationModelTrainingRevShareDollars", round(col("foundation_model_training_dollars"), 6))\
                       .withColumn("VectorSearchIngestionRevShareDollars", round(col("vector_search_ingestion_dollars"), 6))\
                       .withColumn("VectorSearchServingRevShareDollars", round(col("vector_search_serving_dollars"), 6))\
                       .withColumn("MCTModelHeroRunTrainingRevShareDollars", round(col("mct_model_hero_run_training_dollars"), 6))\
                       .withColumn("MCTModelReservedTrainingRevShareDollars", round(col("mct_model_reserved_training_dollars"), 6))\
                       .withColumn("MCTModelOnDemandTrainingRevShareDollars", round(col("mct_model_on_demand_training_dollars"), 6))\
                       .withColumn("LakeflowConnectDBUs", round(col("lakeflow_connect_dbu_quantity"), 6))\
                       .withColumn("LakeflowPipelinesDBUs", round(col("lakeflow_pipelines_dbu_quantity"), 6))\
                       .withColumn("LakeflowDBUs", round(col("lakeflow_dbu_quantity"), 6))\
                       .withColumn("LakeflowConnectRevShareDollars", round(col("lakeflow_connect_dollars"), 6))\
                       .withColumn("LakeflowPipelinesRevShareDollars", round(col("lakeflow_pipelines_dollars"), 6))\
                       .withColumn("LakeflowRevShareDollars", round(col("lakeflow_dollars"), 6))\
                       .withColumn("BatchInferenceModelServingDBUs", round(col("batch_inference_model_serving_dbu_quantity"), 6))\
                       .withColumn("BatchInferenceModelServingRevShareDollars", round(col("batch_inference_model_serving_dollars"), 6))\
                       .withColumn("AgentFrameworkDBUs", round(col("agent_framework_dbu_quantity"), 6))\
                       .withColumn("AgentFrameworkRevShareDollars", round(col("agent_framework_dollars"), 6))\
                       .withColumn("VectorSearchStorageDBUs", round(col("vector_search_storage_dbu_quantity"), 6))\
                       .withColumn("VectorSearchStorageRevShareDollars", round(col("vector_search_storage_dollars"), 6))\
                       .withColumn("FY26AIDBUs", round(col("fy26_ai_dbu_quantity"), 6))\
                       .withColumn("FY26AIDollars", round(col("fy26_ai_dollars"), 6))\
                       .withColumn("FinetuningDBUs", round(col("finetuning_dbu_quantity"), 6))\
                       .withColumn("FinetuningRevShareDollars", round(col("finetuning_dollars"), 6))\
                       .withColumn("AgentEvalsDBUs", round(col("agent_evals_dbu_quantity"), 6))\
                       .withColumn("AgentEvalsRevShareDollars", round(col("agent_evals_dollars"), 6))\
                       .withColumn("AgentEvalsSyntheticDataDBUs", round(col("agent_evals_synthetic_data_dbu_quantity"), 6))\
                       .withColumn("AgentEvalsSyntheticDataRevShareDollars", round(col("agent_evals_synthetic_data_dollars"), 6))\
                       .withColumn("AIRuntimeDBUs", round(col("ai_runtime_dbu_quantity"), 6))\
                       .withColumn("AIRuntimeRevShareDollars", round(col("ai_runtime_dollars"), 6))\
                       .withColumn("AnthropicThroughputModelServingDBUs", round(col("anthropic_throughput_model_serving_dbu_quantity"), 6))\
                       .withColumn("AnthropicThroughputModelServingRevShareDollars", round(col("anthropic_throughput_model_serving_dollars"), 6))\
                       .withColumn("AnthropicFoundationModelAPIDBUs", round(col("anthropic_foundation_model_api_dbu_quantity"), 6))\
                       .withColumn("AnthropicFoundationModelAPIRevShareDollars", round(col("anthropic_foundation_model_api_dollars"), 6))\
                       .withColumn("ModelServingFMAPIDBUs", round(col("model_serving_fmapi_dbu_quantity"), 6))\
                       .withColumn("ModelServingFMAPIRevShareDollars", round(col("model_serving_fmapi_dollars"), 6))\
                       .withColumn("LakehouseMonitoringDBUs", round(col("lakehouse_monitoring_dbu"), 6))\
                       .withColumn("LakehouseMonitoringRevShareDollars", round(col("lakehouse_monitoring_dollars"), 6))\
                       .withColumn("FmMixtral87bInstructDBUs", round(col("fm_mixtral_8_7b_instruct_dbu"), 6))\
                       .withColumn("FmLlama270bChatDBUs", round(col("fm_llama2_70b_chat_dbu"), 6))\
                       .withColumn("FmBgeLargeENDBUs", round(col("fm_bge_large_en_dbu"), 6))\
                       .withColumn("FmMpt30bInstructDBUs", round(col("fm_mpt_30b_instruct_dbu"), 6))\
                       .withColumn("FmMpt7bInstructDBUs", round(col("fm_mpt_7b_instruct_dbu"), 6))\
                       .withColumn("FmDatabricksDbrxChatDBUs", round(col("fm_databricks_dbrx_chat_dbu"), 6))\
                       .withColumn("FmMixtral87bInstructRevShareDollars", round(col("fm_mixtral_8_7b_instruct_dollars"), 6))\
                       .withColumn("FmLlama270bChatRevShareDollars", round(col("fm_llama2_70b_chat_dollars"), 6))\
                       .withColumn("FmBgeLargeENRevShareDollars", round(col("fm_bge_large_en_dollars"), 6))\
                       .withColumn("FmMpt30bInstructRevShareDollars", round(col("fm_mpt_30b_instruct_dollars"), 6))\
                       .withColumn("FmMpt7bInstructRevShareDollars", round(col("fm_mpt_7b_instruct_dollars"), 6))\
                       .withColumn("FmDatabricksDbrxChatRevShareDollars", round(col("fm_databricks_dbrx_chat_dollars"), 6))

prod_daily = prod_daily.withColumn("MoonCakeDBUs", moonCakeDBUs("deployedRegion", "dbu_quantity"))\
                       .withColumn("MoonCakeDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDBUs"), 6))\
                       .withColumn("MoonCakeDeltaDBUs", moonCakeDeltaDBUs("deployedRegion", "delta_dbu_quantity"))\
                       .withColumn("MoonCakeDeltaDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDeltaDBUs"), 6))\
                       .withColumn("MoonCakeSQLDBUs", moonCakeSQLDBUs("deployedRegion", "delta_dbu_quantity", "skuType"))\
                       .withColumn("MoonCakeSQLDollars", round(col("dbuRevSharePrice")*col("MoonCakeSQLDBUs"), 6))                                   

# Drop upstream dollar columns w/ original name
columns_to_drop = ['gen_ai_dbu_dollars','streaming_dlt_dbu_dollars','uc_dbu_dollars','gpu_model_serving_dollars'
                   ,'throughput_model_serving_dollars','foundation_model_api_dollars','vector_search_dollars'
                   ,'mct_dbu_dollars','cpu_model_serving_dollars','foundation_model_training_dollars','vector_search_ingestion_dollars','vector_search_serving_dollars','mct_model_hero_run_training_dollars','mct_model_reserved_training_dollars','mct_model_on_demand_training_dollars',
                   'lakeflow_connect_dbu_quantity', 'lakeflow_pipelines_dbu_quantity', 'lakeflow_dbu_quantity', 'lakeflow_connect_dollars', 'lakeflow_pipelines_dollars', 'lakeflow_dollars',
                   'batch_inference_model_serving_dbu_quantity', 'batch_inference_model_serving_dollars', 'agent_framework_dbu_quantity', 'agent_framework_dollars', 'vector_search_storage_dbu_quantity', 'vector_search_storage_dollars', 'fy26_ai_dbu_quantity', 'fy26_ai_dollars', 'finetuning_dbu_quantity', 'finetuning_dollars', 'agent_evals_dbu_quantity', 'agent_evals_dollars', 'agent_evals_synthetic_data_dbu_quantity', 'agent_evals_synthetic_data_dollars', 'ai_runtime_dbu_quantity', 'ai_runtime_dollars', 'anthropic_throughput_model_serving_dbu_quantity', 'anthropic_throughput_model_serving_dollars', 'anthropic_foundation_model_api_dbu_quantity', 'anthropic_foundation_model_api_dollars', 'model_serving_fmapi_dbu_quantity', 'model_serving_fmapi_dollars', 'lakehouse_monitoring_dbu', 'lakehouse_monitoring_dollars', 'fm_mixtral_8_7b_instruct_dbu', 'fm_llama2_70b_chat_dbu', 'fm_bge_large_en_dbu', 'fm_mpt_30b_instruct_dbu', 'fm_mpt_7b_instruct_dbu', 'fm_databricks_dbrx_chat_dbu', 'fm_mixtral_8_7b_instruct_dollars', 'fm_llama2_70b_chat_dollars', 'fm_bge_large_en_dollars', 'fm_mpt_30b_instruct_dollars', 'fm_mpt_7b_instruct_dollars', 'fm_databricks_dbrx_chat_dollars']

prod_daily = prod_daily.drop(*columns_to_drop)

dateSelectColumns = ["date", "isMonthEnd", "year_month"]
datesFiltered = dates_df.select(*dateSelectColumns)\
                        .filter(dates_df.isMonthEnd==1)\
                        .drop(dates_df.isMonthEnd)\
                        .withColumnRenamed("date", "month_end_date")


prod_daily = prod_daily.join(datesFiltered, prod_daily.month==datesFiltered.year_month)\
                                      .drop(datesFiltered.year_month)

prod_daily = prod_daily.drop(prod_daily.month)

# optimize dynamically
# todo: change cumDBDollars to cumRevShareDollars
orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

apmoller = prod_daily.orderBy(*orderByColumns)
apmoller = apmoller.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                   .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                   .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                   .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                   .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                   .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                   .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                   .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                   .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                   .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

burstColumns = ["cumListDollars", "listCommit", "endDate", "usage_date", "cumDBDollars", "RevShareCommit", "platform"]
apmoller = apmoller.withColumn("IsBurst", isBurst(*burstColumns))

# COMMAND ----------

apmoller.write.option("overwriteSchema", "true").format("delta").mode("append").saveAsTable(USAGE_PROD_DAILY_INTERMEDIATE)

# COMMAND ----------

spark.read.table(USAGE_PROD_DAILY_INTERMEDIATE).count()

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))
