# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def sql_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType in ('SQL', 'virtual') else 0

@udf("double")
def sql_dollars(dbu_quantity, skuType, dbuRevSharePrice):
  return (dbu_quantity * dbuRevSharePrice) if skuType in ('SQL', 'virtual') else 0.0

@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  if platform == "azure":
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  return (cumDBDollars > RevShareCommit + 0.999) or (usage_date > endDate)

@udf("double")
def pctBurn(platform, aggOrder, ListCommit, RevShareCommit, cumListDollars, cumRevShareDollars, cumListForecastDollars, cumRevShareForecastDollars):
  pctBurn = 0.0
  if not 'MTM' in aggOrder:
    if platform == 'azure':
      return 0 if ListCommit==0 else ((cumListDollars + cumListForecastDollars) / ListCommit) * 100
    if platform == 'aws' or platform == 'gcp' or platform == 'mct':
      return 0 if RevShareCommit==0 else ((cumRevShareDollars + cumRevShareForecastDollars) / RevShareCommit) * 100
  return pctBurn

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"
  
@udf("string")
def forecastType(subscriptionId, contract_type):
  forecastType = 'MTM'
  if subscriptionId == 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = "SharedCommit"
  if subscriptionId != 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = 'SingleCommit'
  
  return forecastType

@udf("string")
def consumptionTypeForecast(aggOrder):
  consumptionTypeForecast = "MTM"
  if "Shared" in aggOrder:
    consumptionTypeForecast = "SharedCommit"
  if "Single" in aggOrder:
    consumptionTypeForecast = aggOrder
  if "AWS" in aggOrder:
    consumptionTypeForecast = "Commit"    
    
  
  return consumptionTypeForecast

# COMMAND ----------

dates_df = spark.sql(f"select * from {BI_DATES}")
pvcDaily = spark.read.format("delta").load(USAGEC_AGGORDER_DAILY_PVC_LOCATION)
sasDaily = spark.read.format("delta").load(USAGE_AGGORDER_DAILY_GOLD_ADHOC_LOCATION)

pvc_daily_columns = sorted(pvcDaily.columns)
sas_daily_columns = sorted(sasDaily.columns)

pvcDaily = pvcDaily.select(*pvc_daily_columns)
sasDaily = sasDaily.select(*sas_daily_columns)
dailyUsage = sasDaily.union(pvcDaily)

aggOrderConsumpCastDailyDedup = dailyUsage.dropDuplicates(['accountId', 'aggOrder', 'platform', 'usage_date', 'revShareDollars', 'revShareForecastDollars'])
aggOrderConsumpCastDaily = aggOrderConsumpCastDailyDedup.dropDuplicates(['accountId', 'aggOrder', 'usage_date', 'revShareDollars', 'revShareForecastDollars'])

# COMMAND ----------

orderByColumns = ["accountID", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)


aggOrderConsumpCastDaily  =  aggOrderConsumpCastDaily.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                     .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                     .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                     .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                     .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                     .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                                                     .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                                                     .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                                                     .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                                                     .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                                                     .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                     .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                     .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                     .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                     .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                                                     .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                                                     .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

aggOrderConsumpCastDaily.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(USAGE_AGGORDER_DAILY_GOLD_ADHOC_LOCATION)

# COMMAND ----------

aggOrderConsumpCastDaily = aggOrderConsumpCastDaily.join(dates_df.select("date", "month_end_date"), aggOrderConsumpCastDaily.usage_date==dates_df.date)\
                                                   .drop(dates_df.date)

aggOrderAggColumns = ["accountId", "accountName", "platform", "aggOrder", "month_end_date"]
aggOrderMonthly =  aggOrderConsumpCastDaily.groupBy(*aggOrderAggColumns)\
                                           .agg(\
                                                 round(max("ListCommit"),4).alias("ListCommit"),\
                                                 round(max("DiscountedCommit"),4).alias("DiscountedCommit"),\
                                                 round(max("RevShareCommit"),4).alias("RevShareCommit"),\
                                                 round(sum("listDollars"),4).alias("listDollars"),\
                                                 round(sum("custDollars"),4).alias("custDollars"),\
                                                 round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                 round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                 round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                 round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                 round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                 round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                 round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                 round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                 round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                 round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                 round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                 round(sum("DeltaSQLDBUs"),4).alias("DeltaSQLDBUs"),\
                                                 round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                 round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                 round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                 round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars"),\
                                                 round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                 round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                 round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                 round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                 round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                 round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                 round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                 round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                 round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                 round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars"),\
                                                 round(sum("ISVDBUs"),4).alias("ISVDBUs"),\
                                                 round(sum("ISVRevShareDollars"),4).alias("ISVRevShareDollars"),\
                                                 round(sum("DBTDBUs"),4).alias("DBTDBUs"),\
                                                 round(sum("DBTRevShareDollars"),4).alias("DBTRevShareDollars"),\
                                                 round(sum("FivetranDBUs"),4).alias("FivetranDBUs"),\
                                                 round(sum("FivetranRevShareDollars"),4).alias("FivetranRevShareDollars"),\
                                                 round(sum("ServerlessDBUs"),4).alias("ServerlessDBUs"),\
                                                 round(sum("ServerlessRevShareDollars"),4).alias("ServerlessRevShareDollars"),\
                                                 round(sum("PhotonDBUs"),4).alias("PhotonDBUs"),\
                                                 round(sum("PhotonRevShareDollars"),4).alias("PhotonRevShareDollars"),\
                                                 round(sum("DLTDBUs"),4).alias("DLTDBUs"),\
                                                 round(sum("DLTRevShareDollars"),4).alias("DLTRevShareDollars"),\
                                                 round(sum("StreamingDLTDBUs"),4).alias("StreamingDLTDBUs"),\
                                                 round(sum("StreamingDLTRevShareDollars"),4).alias("StreamingDLTRevShareDollars"),\
                                                 round(sum("MoonCakeSQLDBUs"),4).alias("MoonCakeSQLDBUs"),\
                                                 round(sum("MoonCakeSQLDollars"),4).alias("MoonCakeSQLDollars"),\
                                                 round(sum("DBUs"),6).alias("DBUs"),\
                                                 round(sum("DeltaDBUs"),6).alias("DeltaDBUs"),\
                                                 round(sum("UCDBUs"),6).alias("UCDBUs"),\
                                                 round(sum("UCRevShareDollars"),4).alias("UCRevShareDollars"),\
                                                 round(sum("MLDBUs"),6).alias("MLDBUs"),\
                                                 round(sum("MLRevShareDollars"),4).alias("MLRevShareDollars"),\
                                                 round(sum("MCTModelHeroRunTrainingRevShareDollars"),4).alias("MCTModelHeroRunTrainingRevShareDollars"),\
                                                 round(sum("MCTModelReservedTrainingRevShareDollars"),4).alias("MCTModelReservedTrainingRevShareDollars"),\
                                                 round(sum("MCTModelOnDemandTrainingRevShareDollars"),4).alias("MCTModelOnDemandTrainingRevShareDollars"),\
                                                 round(sum("GenAIDBUs"),6).alias("GenAIDBUs"),\
                                                 round(sum("GenAIRevShareDollars"),4).alias("GenAIRevShareDollars"),\
                                                 round(sum("GPUModelServingDBUs"),6).alias("GPUModelServingDBUs"),\
                                                 round(sum("GPUModelServingRevShareDollars"),4).alias("GPUModelServingRevShareDollars"),\
                                                 round(sum("ThroughputModelServingDBUs"),6).alias("ThroughputModelServingDBUs"),\
                                                 round(sum("ThroughputModelServingRevShareDollars"),4).alias("ThroughputModelServingRevShareDollars"),\
                                                 round(sum("FoundationModelAPIDBUs"),6).alias("FoundationModelAPIDBUs"),\
                                                 round(sum("FoundationModelAPIRevShareDollars"),4).alias("FoundationModelAPIRevShareDollars"),\
                                                 round(sum("VectorSearchDBUs"),6).alias("VectorSearchDBUs"),\
                                                 round(sum("VectorSearchRevShareDollars"),4).alias("VectorSearchRevShareDollars"),\
                                                 round(sum("LakeflowConnectDBUs"), 6).alias("LakeflowConnectDBUs"),
                                                 round(sum("LakeflowPipelinesDBUs"), 6).alias("LakeflowPipelinesDBUs"),
                                                 round(sum("LakeflowDBUs"), 6).alias("LakeflowDBUs"),
                                                 round(sum("LakeflowConnectRevShareDollars"), 4).alias("LakeflowConnectRevShareDollars"),
                                                 round(sum("LakeflowPipelinesRevShareDollars"), 4).alias("LakeflowPipelinesRevShareDollars"),
                                                 round(sum("LakeflowRevShareDollars"), 4).alias("LakeflowRevShareDollars"),
                                                 round(sum("BatchInferenceModelServingDBUs"), 6).alias("BatchInferenceModelServingDBUs"),
                                                 round(sum("BatchInferenceModelServingRevShareDollars"), 4).alias  ("BatchInferenceModelServingRevShareDollars"),
                                                 round(sum("AgentFrameworkDBUs"), 6).alias("AgentFrameworkDBUs"),
                                                 round(sum("AgentFrameworkRevShareDollars"), 4).alias("AgentFrameworkRevShareDollars"),
                                                 round(sum("VectorSearchStorageDBUs"), 6).alias("VectorSearchStorageDBUs"),
                                                 round(sum("VectorSearchStorageRevShareDollars"), 4).alias("VectorSearchStorageRevShareDollars"),
                                                 round(sum("FY26AIDBUs"), 6).alias("FY26AIDBUs"),
                                                 round(sum("FY26AIDollars"), 4).alias("FY26AIDollars"),
                                                 round(sum("MCTDBUs"),6).alias("MCTDBUs"),\
                                                 round(sum("MCTRevShareDollars"),4).alias("MCTRevShareDollars"),\
                                                 round(sum("StreamingDLTRevShareDollars_calculated"),4).alias("StreamingDLTRevShareDollars_calculated"),\
                                                 round(sum("UCRevShareDollars_calculated"),4).alias("UCRevShareDollars_calculated"),\
                                                 round(sum("CPUModelServingRevShareDollars"),4).alias("CPUModelServingRevShareDollars"),\
                                                 round(sum("FoundationModelTrainingRevShareDollars"),4).alias("FoundationModelTrainingRevShareDollars"),\
                                                 round(sum("VectorSearchIngestionRevShareDollars"),4).alias("VectorSearchIngestionRevShareDollars"),\
                                                 round(sum("VectorSearchServingRevShareDollars"),4).alias("VectorSearchServingRevShareDollars"),\
                                                 round(sum("FinetuningDBUs"), 6).alias("FinetuningDBUs"),\
                                                 round(sum("FinetuningRevShareDollars"), 6).alias("FinetuningRevShareDollars"),\
                                                 round(sum("AgentEvalsDBUs"), 6).alias("AgentEvalsDBUs"),\
                                                 round(sum("AgentEvalsRevShareDollars"), 6).alias("AgentEvalsRevShareDollars"),\
                                                 round(sum("AgentEvalsSyntheticDataDBUs"), 6).alias("AgentEvalsSyntheticDataDBUs"),\
                                                 round(sum("AgentEvalsSyntheticDataRevShareDollars"), 6).alias("AgentEvalsSyntheticDataRevShareDollars"),\
                                                 round(sum("AIRuntimeDBUs"), 6).alias("AIRuntimeDBUs"),\
                                                 round(sum("AIRuntimeRevShareDollars"), 6).alias("AIRuntimeRevShareDollars"),\
                                                 round(sum("AnthropicThroughputModelServingDBUs"), 6).alias("AnthropicThroughputModelServingDBUs"),\
                                                 round(sum("AnthropicThroughputModelServingRevShareDollars"), 6).alias("AnthropicThroughputModelServingRevShareDollars"),\
                                                 round(sum("AnthropicFoundationModelAPIDBUs"), 6).alias("AnthropicFoundationModelAPIDBUs"),\
                                                 round(sum("AnthropicFoundationModelAPIRevShareDollars"), 6).alias("AnthropicFoundationModelAPIRevShareDollars"),\
                                                 round(sum("ModelServingFMAPIDBUs"), 6).alias("ModelServingFMAPIDBUs"),\
                                                 round(sum("ModelServingFMAPIRevShareDollars"), 6).alias("ModelServingFMAPIRevShareDollars"),\
                                                 round(sum("LakehouseMonitoringDBUs"), 6).alias("LakehouseMonitoringDBUs"),\
                                                 round(sum("LakehouseMonitoringRevShareDollars"), 6).alias("LakehouseMonitoringRevShareDollars"),\
                                                 round(sum("FmMixtral87bInstructDBUs"), 6).alias("FmMixtral87bInstructDBUs"),\
                                                 round(sum("FmLlama270bChatDBUs"), 6).alias("FmLlama270bChatDBUs"),\
                                                 round(sum("FmBgeLargeENDBUs"), 6).alias("FmBgeLargeENDBUs"),\
                                                 round(sum("FmMpt30bInstructDBUs"), 6).alias("FmMpt30bInstructDBUs"),\
                                                 round(sum("FmMpt7bInstructDBUs"), 6).alias("FmMpt7bInstructDBUs"),\
                                                 round(sum("FmDatabricksDbrxChatDBUs"), 6).alias("FmDatabricksDbrxChatDBUs"),\
                                                 round(sum("FmMixtral87bInstructRevShareDollars"), 6).alias("FmMixtral87bInstructRevShareDollars"),\
                                                 round(sum("FmLlama270bChatRevShareDollars"), 6).alias("FmLlama270bChatRevShareDollars"),\
                                                 round(sum("FmBgeLargeENRevShareDollars"), 6).alias("FmBgeLargeENRevShareDollars"),\
                                                 round(sum("FmMpt30bInstructRevShareDollars"), 6).alias("FmMpt30bInstructRevShareDollars"),\
                                                 round(sum("FmMpt7bInstructRevShareDollars"), 6).alias("FmMpt7bInstructRevShareDollars"),\
                                                round(sum("FmDatabricksDbrxChatRevShareDollars"), 6).alias("FmDatabricksDbrxChatRevShareDollars")
                                                )
aggOrderMonthly = aggOrderMonthly.orderBy("accountId", "accountName", "platform", "aggOrder","month_end_date")

partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("month_end_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

aggOrderMonthly = aggOrderMonthly.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                 .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                 .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                                 .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                 .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                 .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                                 .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                                 .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                                 .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                                 .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                                 .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                 .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                 .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                 .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                 .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                                 .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                                 .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

pvc_orders = spark.read.format("delta").load(BI_AGGORDERS_PVC_LOCATION)
pvc_orders.createOrReplaceTempView("pvc_orders")

pvc_aggOrders_df = spark.sql("""
select aggOrder,
       sfdcAccountId,
       startDate,
       endDate,
       cloudPartnerPurchase ListCommit,
       ActualPartnerCommit DiscountedCommit,
       DBShareCommit RevShareCommit
from pvc_orders
""")

overlapping_contracts = spark.read.format("delta").load(PARALLEL_CONTRACTS_CLEAN_LOCATION)
overlapping_contracts = overlapping_contracts.withColumn("platform", lit("aws"))
overlapping_contracts.createOrReplaceTempView("process_parallel_contracts")

aggOrders_df = spark.sql(f"""
with processed_parallel_accounts(
select distinct sfdcAccountId as accountId, platform from process_parallel_contracts
)
select aggOrder,
       sfdcAccountId,
       startDate,
       endDate,
       cloudPartnerPurchase ListCommit,
       ActualPartnerCommit DiscountedCommit,
       DBShareCommit RevShareCommit
from {BI_AGGORDERS} agg
left join processed_parallel_accounts ppc on agg.sfdcAccountId = ppc.accountId and agg.platform = ppc.platform
where ppc.accountId is null

union 

select aggOrder,
       sfdcAccountId,
       startDate,
       endDate,
       ListCommit,
       DiscountedCommit,
       RevShareCommit
from process_parallel_contracts
""")

aggOrders_df = aggOrders_df.union(pvc_aggOrders_df)

# COMMAND ----------

aggOrdersdedup_df = aggOrders_df.dropDuplicates(["aggOrder"])

# COMMAND ----------

print(aggOrderMonthly.count())
aggOrderMonthlyExtended = aggOrderMonthly.join(aggOrdersdedup_df.select("aggOrder", "startDate", "endDate"), aggOrderMonthly.aggOrder==aggOrdersdedup_df.aggOrder)\
                                       .drop(aggOrdersdedup_df.aggOrder)
print(aggOrderMonthlyExtended.count())



aggOrderMonthlyExtended = aggOrderMonthlyExtended.orderBy("accountID", "accountName", "platform", "aggOrder", "month_end_date")
pctBurnColumns = ["platform", "aggOrder", "ListCommit", "RevShareCommit", "cumListDollars", "cumRevShareDollars", "cumListForecastDollars", "cumRevShareForecastDollars"]
aggOrderMonthlyMetrics = aggOrderMonthlyExtended.withColumn("pctBurn", round(pctBurn(*pctBurnColumns),2))

# COMMAND ----------

aggOrderMonthlyMetrics.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_AGGORDER_MONTHLY)

# COMMAND ----------

# DBTITLE 1,Platform Daily & Monthly 
platformDailyColumns = ["accountId", "accountName", "platform", "usage_date"]
consumptionPlatformDaily = aggOrderConsumpCastDaily.groupBy(*platformDailyColumns)\
                                                   .agg(\
                                                         max("ListCommit").alias('ListCommit'),\
                                                         max("DiscountedCommit").alias('DiscountedCommit'),\
                                                         max("RevShareCommit").alias('RevShareCommit'),\
                                                         round(sum("listDollars"),4).alias("listDollars"),\
                                                         round(sum("custDollars"),4).alias("custDollars"),\
                                                         round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                         round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                         round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                         round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                         round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                         round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                         round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                         round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                         round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                         round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                         round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                         round(sum("DeltaSQLDBUs"),4).alias("DeltaSQLDBUs"),\
                                                         round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                         round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                         round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                         round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars"),\
                                                         round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                         round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                         round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                         round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                         round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                         round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                         round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                         round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                         round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                         round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars"),\
                                                         round(sum("ISVDBUs"),4).alias("ISVDBUs"),\
                                                         round(sum("ISVRevShareDollars"),4).alias("ISVRevShareDollars"),\
                                                         round(sum("DBTDBUs"),4).alias("DBTDBUs"),\
                                                         round(sum("DBTRevShareDollars"),4).alias("DBTRevShareDollars"),\
                                                         round(sum("FivetranDBUs"),4).alias("FivetranDBUs"),\
                                                         round(sum("FivetranRevShareDollars"),4).alias("FivetranRevShareDollars"),\
                                                         round(sum("ServerlessDBUs"),4).alias("ServerlessDBUs"),\
                                                         round(sum("ServerlessRevShareDollars"),4).alias("ServerlessRevShareDollars"),\
                                                         round(sum("PhotonDBUs"),4).alias("PhotonDBUs"),\
                                                         round(sum("PhotonRevShareDollars"),4).alias("PhotonRevShareDollars"),\
                                                         round(sum("DLTDBUs"),4).alias("DLTDBUs"),\
                                                         round(sum("DLTRevShareDollars"),4).alias("DLTRevShareDollars"),\
                                                         round(sum("StreamingDLTDBUs"),4).alias("StreamingDLTDBUs"),\
                                                         round(sum("StreamingDLTRevShareDollars"),4).alias("StreamingDLTRevShareDollars"),\
                                                         round(sum("MoonCakeSQLDBUs"),4).alias("MoonCakeSQLDBUs"),\
                                                         round(sum("MoonCakeSQLDollars"),4).alias("MoonCakeSQLDollars"),\
                                                         round(sum("DBUs"),6).alias("DBUs"),\
                                                         round(sum("DeltaDBUs"),6).alias("DeltaDBUs"),\
                                                         round(sum("UCDBUs"),6).alias("UCDBUs"),\
                                                         round(sum("UCRevShareDollars"),4).alias("UCRevShareDollars"),\
                                                         round(sum("MLDBUs"),6).alias("MLDBUs"),\
                                                         round(sum("MLRevShareDollars"),4).alias("MLRevShareDollars"),\
                                                         round(sum("GenAIDBUs"),6).alias("GenAIDBUs"),\
                                                         round(sum("GenAIRevShareDollars"),4).alias("GenAIRevShareDollars"),\
                                                         round(sum("GPUModelServingDBUs"),6).alias("GPUModelServingDBUs"),\
                                                         round(sum("GPUModelServingRevShareDollars"),4).alias("GPUModelServingRevShareDollars"),\
                                                         round(sum("ThroughputModelServingDBUs"),6).alias("ThroughputModelServingDBUs"),\
                                                         round(sum("ThroughputModelServingRevShareDollars"),4).alias("ThroughputModelServingRevShareDollars"),\
                                                         round(sum("FoundationModelAPIDBUs"),6).alias("FoundationModelAPIDBUs"),\
                                                         round(sum("FoundationModelAPIRevShareDollars"),4).alias("FoundationModelAPIRevShareDollars"),\
                                                         round(sum("VectorSearchDBUs"),6).alias("VectorSearchDBUs"),\
                                                         round(sum("VectorSearchRevShareDollars"),4).alias("VectorSearchRevShareDollars"),\
                                                         round(sum("LakeflowConnectDBUs"), 6).alias("LakeflowConnectDBUs"),
                                                         round(sum("LakeflowPipelinesDBUs"), 6).alias("LakeflowPipelinesDBUs"),
                                                         round(sum("LakeflowDBUs"), 6).alias("LakeflowDBUs"),
                                                         round(sum("LakeflowConnectRevShareDollars"), 4).alias("LakeflowConnectRevShareDollars"),
                                                         round(sum("LakeflowPipelinesRevShareDollars"), 4).alias("LakeflowPipelinesRevShareDollars"),
                                                         round(sum("LakeflowRevShareDollars"), 4).alias("LakeflowRevShareDollars"),
                                                         round(sum("BatchInferenceModelServingDBUs"), 6).alias("BatchInferenceModelServingDBUs"),
                                                         round(sum("BatchInferenceModelServingRevShareDollars"), 4).alias ("BatchInferenceModelServingRevShareDollars"),
                                                         round(sum("AgentFrameworkDBUs"), 6).alias("AgentFrameworkDBUs"),
                                                         round(sum("AgentFrameworkRevShareDollars"), 4).alias("AgentFrameworkRevShareDollars"),
                                                         round(sum("VectorSearchStorageDBUs"), 6).alias("VectorSearchStorageDBUs"),
                                                         round(sum("VectorSearchStorageRevShareDollars"), 4).alias("VectorSearchStorageRevShareDollars"),
                                                         round(sum("FY26AIDBUs"), 6).alias("FY26AIDBUs"),
                                                         round(sum("FY26AIDollars"), 4).alias("FY26AIDollars"),
                                                         round(sum("MCTDBUs"),6).alias("MCTDBUs"),\
                                                         round(sum("MCTRevShareDollars"),4).alias("MCTRevShareDollars"),\
                                                         round(sum("MCTModelHeroRunTrainingRevShareDollars"),4).alias("MCTModelHeroRunTrainingRevShareDollars"),\
                                                         round(sum("MCTModelReservedTrainingRevShareDollars"),4).alias("MCTModelReservedTrainingRevShareDollars"),\
                                                         round(sum("MCTModelOnDemandTrainingRevShareDollars"),4).alias("MCTModelOnDemandTrainingRevShareDollars"),\
                                                         round(sum("StreamingDLTRevShareDollars_calculated"),4).alias("StreamingDLTRevShareDollars_calculated"),\
                                                         round(sum("UCRevShareDollars_calculated"),4).alias("UCRevShareDollars_calculated"),\
                                                         round(sum("CPUModelServingRevShareDollars"),4).alias("CPUModelServingRevShareDollars"),\
                                                         round(sum("FoundationModelTrainingRevShareDollars"),4).alias("FoundationModelTrainingRevShareDollars"),\
                                                         round(sum("VectorSearchIngestionRevShareDollars"),4).alias("VectorSearchIngestionRevShareDollars"),\
                                                         round(sum("VectorSearchServingRevShareDollars"),4).alias("VectorSearchServingRevShareDollars"),\
                                                         round(sum("FinetuningDBUs"), 6).alias("FinetuningDBUs"),\
                                                         round(sum("FinetuningRevShareDollars"), 6).alias("FinetuningRevShareDollars"),\
                                                         round(sum("AgentEvalsDBUs"), 6).alias("AgentEvalsDBUs"),\
                                                         round(sum("AgentEvalsRevShareDollars"), 6).alias("AgentEvalsRevShareDollars"),\
                                                         round(sum("AgentEvalsSyntheticDataDBUs"), 6).alias("AgentEvalsSyntheticDataDBUs"),\
                                                         round(sum("AgentEvalsSyntheticDataRevShareDollars"), 6).alias("AgentEvalsSyntheticDataRevShareDollars"),\
                                                         round(sum("AIRuntimeDBUs"), 6).alias("AIRuntimeDBUs"),\
                                                         round(sum("AIRuntimeRevShareDollars"), 6).alias("AIRuntimeRevShareDollars"),\
                                                         round(sum("AnthropicThroughputModelServingDBUs"), 6).alias("AnthropicThroughputModelServingDBUs"),\
                                                         round(sum("AnthropicThroughputModelServingRevShareDollars"), 6).alias("AnthropicThroughputModelServingRevShareDollars"),\
                                                         round(sum("AnthropicFoundationModelAPIDBUs"), 6).alias("AnthropicFoundationModelAPIDBUs"),\
                                                         round(sum("AnthropicFoundationModelAPIRevShareDollars"), 6).alias("AnthropicFoundationModelAPIRevShareDollars"),\
                                                         round(sum("ModelServingFMAPIDBUs"), 6).alias("ModelServingFMAPIDBUs"),\
                                                         round(sum("ModelServingFMAPIRevShareDollars"), 6).alias("ModelServingFMAPIRevShareDollars"),\
                                                         round(sum("LakehouseMonitoringDBUs"), 6).alias("LakehouseMonitoringDBUs"),\
                                                         round(sum("LakehouseMonitoringRevShareDollars"), 6).alias("LakehouseMonitoringRevShareDollars"),\
                                                         round(sum("FmMixtral87bInstructDBUs"), 6).alias("FmMixtral87bInstructDBUs"),\
                                                         round(sum("FmLlama270bChatDBUs"), 6).alias("FmLlama270bChatDBUs"),\
                                                         round(sum("FmBgeLargeENDBUs"), 6).alias("FmBgeLargeENDBUs"),\
                                                         round(sum("FmMpt30bInstructDBUs"), 6).alias("FmMpt30bInstructDBUs"),\
                                                         round(sum("FmMpt7bInstructDBUs"), 6).alias("FmMpt7bInstructDBUs"),\
                                                         round(sum("FmDatabricksDbrxChatDBUs"), 6).alias("FmDatabricksDbrxChatDBUs"),\
                                                         round(sum("FmMixtral87bInstructRevShareDollars"), 6).alias("FmMixtral87bInstructRevShareDollars"),\
                                                         round(sum("FmLlama270bChatRevShareDollars"), 6).alias("FmLlama270bChatRevShareDollars"),\
                                                         round(sum("FmBgeLargeENRevShareDollars"), 6).alias("FmBgeLargeENRevShareDollars"),\
                                                         round(sum("FmMpt30bInstructRevShareDollars"), 6).alias("FmMpt30bInstructRevShareDollars"),\
                                                         round(sum("FmMpt7bInstructRevShareDollars"), 6).alias("FmMpt7bInstructRevShareDollars"),\
                                                         round(sum("FmDatabricksDbrxChatRevShareDollars"), 6).alias("FmDatabricksDbrxChatRevShareDollars")
                                                         )

consumptionPlatformDaily = consumptionPlatformDaily.orderBy("accountId", "accountName", "platform", "usage_date")

orderByColumns = ["accountID", "accountName", "platform", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)


consumptionPlatformDailyCum  =   consumptionPlatformDaily.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                         .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                         .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                         .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                         .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                         .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                         .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                         .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                                                         .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

consumptionPlatformDailyCum = consumptionPlatformDailyCum.orderBy(*orderByColumns)

# COMMAND ----------

consumptionPlatformDailyCum.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGE_PLATFORM_DAILY)

# COMMAND ----------

consumptionPlatformDaily = consumptionPlatformDaily.join(dates_df.select("date", "month_end_date"), consumptionPlatformDaily.usage_date==dates_df.date)\
                                                   .drop(dates_df.date)

platAggColumns = ["accountId", "accountName", "platform", "month_end_date"]
platMonthly =  consumptionPlatformDaily.groupBy(*platAggColumns)\
                                           .agg(\
                                                 round(max("ListCommit"),4).alias("ListCommit"),\
                                                 round(max("DiscountedCommit"),4).alias("DiscountedCommit"),\
                                                 round(max("RevShareCommit"),4).alias("RevShareCommit"),\
                                                 round(sum("listDollars"),4).alias("listDollars"),\
                                                 round(sum("custDollars"),4).alias("custDollars"),\
                                                 round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                 round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                 round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                 round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                 round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                 round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                 round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                 round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                 round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                 round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                 round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                 round(sum("DeltaSQLDBUs"),4).alias("DeltaSQLDBUs"),\
                                                 round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                 round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                 round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                 round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars"),\
                                                 round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                 round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                 round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                 round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                 round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                 round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                 round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                 round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                 round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                 round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars"),\
                                                 round(sum("ISVDBUs"),4).alias("ISVDBUs"),\
                                                 round(sum("ISVRevShareDollars"),4).alias("ISVRevShareDollars"),\
                                                 round(sum("DBTDBUs"),4).alias("DBTDBUs"),\
                                                 round(sum("DBTRevShareDollars"),4).alias("DBTRevShareDollars"),\
                                                 round(sum("FivetranDBUs"),4).alias("FivetranDBUs"),\
                                                 round(sum("FivetranRevShareDollars"),4).alias("FivetranRevShareDollars"),\
                                                 round(sum("ServerlessDBUs"),4).alias("ServerlessDBUs"),\
                                                 round(sum("ServerlessRevShareDollars"),4).alias("ServerlessRevShareDollars"),\
                                                 round(sum("PhotonDBUs"),4).alias("PhotonDBUs"),\
                                                 round(sum("PhotonRevShareDollars"),4).alias("PhotonRevShareDollars"),\
                                                 round(sum("DLTDBUs"),4).alias("DLTDBUs"),\
                                                 round(sum("DLTRevShareDollars"),4).alias("DLTRevShareDollars"),\
                                                 round(sum("StreamingDLTDBUs"),4).alias("StreamingDLTDBUs"),\
                                                 round(sum("StreamingDLTRevShareDollars"),4).alias("StreamingDLTRevShareDollars"),\
                                                 round(sum("MoonCakeSQLDBUs"),4).alias("MoonCakeSQLDBUs"),\
                                                 round(sum("MoonCakeSQLDollars"),4).alias("MoonCakeSQLDollars"),\
                                                 round(sum("DBUs"),6).alias("DBUs"),\
                                                 round(sum("DeltaDBUs"),6).alias("DeltaDBUs"),\
                                                 round(sum("UCDBUs"),6).alias("UCDBUs"),\
                                                 round(sum("UCRevShareDollars"),4).alias("UCRevShareDollars"),\
                                                 round(sum("MLDBUs"),6).alias("MLDBUs"),\
                                                 round(sum("MLRevShareDollars"),4).alias("MLRevShareDollars"),\
                                                 round(sum("GenAIDBUs"),6).alias("GenAIDBUs"),\
                                                 round(sum("GenAIRevShareDollars"),4).alias("GenAIRevShareDollars"),\
                                                 round(sum("GPUModelServingDBUs"),6).alias("GPUModelServingDBUs"),\
                                                 round(sum("GPUModelServingRevShareDollars"),4).alias("GPUModelServingRevShareDollars"),\
                                                 round(sum("ThroughputModelServingDBUs"),6).alias("ThroughputModelServingDBUs"),\
                                                 round(sum("ThroughputModelServingRevShareDollars"),4).alias("ThroughputModelServingRevShareDollars"),\
                                                 round(sum("FoundationModelAPIDBUs"),6).alias("FoundationModelAPIDBUs"),\
                                                 round(sum("FoundationModelAPIRevShareDollars"),4).alias("FoundationModelAPIRevShareDollars"),\
                                                 round(sum("VectorSearchDBUs"),6).alias("VectorSearchDBUs"),\
                                                 round(sum("VectorSearchRevShareDollars"),4).alias("VectorSearchRevShareDollars"),\
                                                 round(sum("LakeflowConnectDBUs"), 6).alias("LakeflowConnectDBUs"),
                                                 round(sum("LakeflowPipelinesDBUs"), 6).alias("LakeflowPipelinesDBUs"),
                                                 round(sum("LakeflowDBUs"), 6).alias("LakeflowDBUs"),
                                                 round(sum("LakeflowConnectRevShareDollars"), 4).alias("LakeflowConnectRevShareDollars"),
                                                 round(sum("LakeflowPipelinesRevShareDollars"), 4).alias("LakeflowPipelinesRevShareDollars"),
                                                 round(sum("LakeflowRevShareDollars"), 4).alias("LakeflowRevShareDollars"),
                                                 round(sum("BatchInferenceModelServingDBUs"), 6).alias("BatchInferenceModelServingDBUs"),
                                                 round(sum("BatchInferenceModelServingRevShareDollars"), 4).alias 
                                                 ("BatchInferenceModelServingRevShareDollars"),
                                                 round(sum("AgentFrameworkDBUs"), 6).alias("AgentFrameworkDBUs"),
                                                 round(sum("AgentFrameworkRevShareDollars"), 4).alias("AgentFrameworkRevShareDollars"),
                                                 round(sum("VectorSearchStorageDBUs"), 6).alias("VectorSearchStorageDBUs"),
                                                 round(sum("VectorSearchStorageRevShareDollars"), 4).alias("VectorSearchStorageRevShareDollars"),
                                                 round(sum("FY26AIDBUs"), 6).alias("FY26AIDBUs"),
                                                 round(sum("FY26AIDollars"), 4).alias("FY26AIDollars"),
                                                 round(sum("MCTDBUs"),6).alias("MCTDBUs"),\
                                                 round(sum("MCTRevShareDollars"),4).alias("MCTRevShareDollars"),\
                                                 round(sum("MCTModelHeroRunTrainingRevShareDollars"),4).alias("MCTModelHeroRunTrainingRevShareDollars"),\
                                                 round(sum("MCTModelReservedTrainingRevShareDollars"),4).alias("MCTModelReservedTrainingRevShareDollars"),\
                                                 round(sum("MCTModelOnDemandTrainingRevShareDollars"),4).alias("MCTModelOnDemandTrainingRevShareDollars"),\
                                                 round(sum("StreamingDLTRevShareDollars_calculated"),4).alias("StreamingDLTRevShareDollars_calculated"),\
                                                 round(sum("UCRevShareDollars_calculated"),4).alias("UCRevShareDollars_calculated"),\
                                                 round(sum("CPUModelServingRevShareDollars"),4).alias("CPUModelServingRevShareDollars"),\
                                                 round(sum("FoundationModelTrainingRevShareDollars"),4).alias("FoundationModelTrainingRevShareDollars"),\
                                                 round(sum("VectorSearchIngestionRevShareDollars"),4).alias("VectorSearchIngestionRevShareDollars"),\
                                                 round(sum("VectorSearchServingRevShareDollars"),4).alias("VectorSearchServingRevShareDollars"),\
                                                 round(sum("FinetuningDBUs"), 6).alias("FinetuningDBUs"),\
                                                 round(sum("FinetuningRevShareDollars"), 6).alias("FinetuningRevShareDollars"),\
                                                 round(sum("AgentEvalsDBUs"), 6).alias("AgentEvalsDBUs"),\
                                                 round(sum("AgentEvalsRevShareDollars"), 6).alias("AgentEvalsRevShareDollars"),\
                                                 round(sum("AgentEvalsSyntheticDataDBUs"), 6).alias("AgentEvalsSyntheticDataDBUs"),\
                                                 round(sum("AgentEvalsSyntheticDataRevShareDollars"), 6).alias("AgentEvalsSyntheticDataRevShareDollars"),\
                                                 round(sum("AIRuntimeDBUs"), 6).alias("AIRuntimeDBUs"),\
                                                 round(sum("AIRuntimeRevShareDollars"), 6).alias("AIRuntimeRevShareDollars"),\
                                                 round(sum("AnthropicThroughputModelServingDBUs"), 6).alias("AnthropicThroughputModelServingDBUs"),\
                                                 round(sum("AnthropicThroughputModelServingRevShareDollars"), 6).alias("AnthropicThroughputModelServingRevShareDollars"),\
                                                 round(sum("AnthropicFoundationModelAPIDBUs"), 6).alias("AnthropicFoundationModelAPIDBUs"),\
                                                 round(sum("AnthropicFoundationModelAPIRevShareDollars"), 6).alias("AnthropicFoundationModelAPIRevShareDollars"),\
                                                 round(sum("ModelServingFMAPIDBUs"), 6).alias("ModelServingFMAPIDBUs"),\
                                                 round(sum("ModelServingFMAPIRevShareDollars"), 6).alias("ModelServingFMAPIRevShareDollars"),\
                                                 round(sum("LakehouseMonitoringDBUs"), 6).alias("LakehouseMonitoringDBUs"),\
                                                 round(sum("LakehouseMonitoringRevShareDollars"), 6).alias("LakehouseMonitoringRevShareDollars"),\
                                                 round(sum("FmMixtral87bInstructDBUs"), 6).alias("FmMixtral87bInstructDBUs"),\
                                                 round(sum("FmLlama270bChatDBUs"), 6).alias("FmLlama270bChatDBUs"),\
                                                 round(sum("FmBgeLargeENDBUs"), 6).alias("FmBgeLargeENDBUs"),\
                                                 round(sum("FmMpt30bInstructDBUs"), 6).alias("FmMpt30bInstructDBUs"),\
                                                 round(sum("FmMpt7bInstructDBUs"), 6).alias("FmMpt7bInstructDBUs"),\
                                                 round(sum("FmDatabricksDbrxChatDBUs"), 6).alias("FmDatabricksDbrxChatDBUs"),\
                                                 round(sum("FmMixtral87bInstructRevShareDollars"), 6).alias("FmMixtral87bInstructRevShareDollars"),\
                                                 round(sum("FmLlama270bChatRevShareDollars"), 6).alias("FmLlama270bChatRevShareDollars"),\
                                                 round(sum("FmBgeLargeENRevShareDollars"), 6).alias("FmBgeLargeENRevShareDollars"),\
                                                 round(sum("FmMpt30bInstructRevShareDollars"), 6).alias("FmMpt30bInstructRevShareDollars"),\
                                                 round(sum("FmMpt7bInstructRevShareDollars"), 6).alias("FmMpt7bInstructRevShareDollars"),\
                                                 round(sum("FmDatabricksDbrxChatRevShareDollars"), 6).alias("FmDatabricksDbrxChatRevShareDollars")
                                                 )
platMonthly = platMonthly.orderBy("accountId", "accountName", "platform", "month_end_date")

partitionByColumns = ["accountID", "accountName", "platform"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("month_end_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

platMonthlyCum =  platMonthly.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                             .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                             .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                             .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                             .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                             .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

platMonthlyCum.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_PLATFORM_MONTHLY)

# COMMAND ----------

# DBTITLE 1,Account Daily
consumptionPlatformDaily = spark.sql(f""" select * from {USAGE_PLATFORM_DAILY}""")

accountDailyColumns = ["accountId", "accountName", "usage_date"]
consumptionAccountDaily = consumptionPlatformDaily.groupBy(*accountDailyColumns)\
                                                   .agg(\
                                                         max("ListCommit").alias('ListCommit'),\
                                                         max("DiscountedCommit").alias('DiscountedCommit'),\
                                                         max("RevShareCommit").alias('RevShareCommit'),\
                                                         round(sum("listDollars"),4).alias("listDollars"),\
                                                         round(sum("custDollars"),4).alias("custDollars"),\
                                                         round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                         round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                         round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                         round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                         round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                         round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                         round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                         round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                         round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                         round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                         round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                         round(sum("DeltaSQLDBUs"),4).alias("DeltaSQLDBUs"),\
                                                         round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                         round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                         round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                         round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars"),\
                                                         round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                         round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                         round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                         round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                         round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                         round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                         round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                         round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                         round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                         round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars"),\
                                                         round(sum("ISVDBUs"),4).alias("ISVDBUs"),\
                                                         round(sum("ISVRevShareDollars"),4).alias("ISVRevShareDollars"),\
                                                         round(sum("DBTDBUs"),4).alias("DBTDBUs"),\
                                                         round(sum("DBTRevShareDollars"),4).alias("DBTRevShareDollars"),\
                                                         round(sum("FivetranDBUs"),4).alias("FivetranDBUs"),\
                                                         round(sum("FivetranRevShareDollars"),4).alias("FivetranRevShareDollars"),\
                                                         round(sum("ServerlessDBUs"),4).alias("ServerlessDBUs"),\
                                                         round(sum("ServerlessRevShareDollars"),4).alias("ServerlessRevShareDollars"),\
                                                         round(sum("PhotonDBUs"),4).alias("PhotonDBUs"),\
                                                         round(sum("PhotonRevShareDollars"),4).alias("PhotonRevShareDollars"),\
                                                         round(sum("DLTDBUs"),4).alias("DLTDBUs"),\
                                                         round(sum("DLTRevShareDollars"),4).alias("DLTRevShareDollars"),\
                                                         round(sum("StreamingDLTDBUs"),4).alias("StreamingDLTDBUs"),\
                                                         round(sum("StreamingDLTRevShareDollars"),4).alias("StreamingDLTRevShareDollars"),\
                                                         round(sum("MoonCakeSQLDBUs"),4).alias("MoonCakeSQLDBUs"),\
                                                         round(sum("MoonCakeSQLDollars"),4).alias("MoonCakeSQLDollars"),\
                                                         round(sum("DBUs"),6).alias("DBUs"),\
                                                         round(sum("DeltaDBUs"),6).alias("DeltaDBUs"),\
                                                         round(sum("UCDBUs"),6).alias("UCDBUs"),\
                                                         round(sum("UCRevShareDollars"),4).alias("UCRevShareDollars"),\
                                                         round(sum("MLDBUs"),6).alias("MLDBUs"),\
                                                         round(sum("MLRevShareDollars"),4).alias("MLRevShareDollars"),\
                                                         round(sum("GenAIDBUs"),6).alias("GenAIDBUs"),\
                                                         round(sum("GenAIRevShareDollars"),4).alias("GenAIRevShareDollars"),\
                                                         round(sum("GPUModelServingDBUs"),6).alias("GPUModelServingDBUs"),\
                                                         round(sum("GPUModelServingRevShareDollars"),4).alias("GPUModelServingRevShareDollars"),\
                                                         round(sum("ThroughputModelServingDBUs"),6).alias("ThroughputModelServingDBUs"),\
                                                         round(sum("ThroughputModelServingRevShareDollars"),4).alias("ThroughputModelServingRevShareDollars"),\
                                                         round(sum("FoundationModelAPIDBUs"),6).alias("FoundationModelAPIDBUs"),\
                                                         round(sum("FoundationModelAPIRevShareDollars"),4).alias("FoundationModelAPIRevShareDollars"),\
                                                         round(sum("VectorSearchDBUs"),6).alias("VectorSearchDBUs"),\
                                                         round(sum("VectorSearchRevShareDollars"),4).alias("VectorSearchRevShareDollars"),\
                                                         round(sum("LakeflowConnectDBUs"), 6).alias("LakeflowConnectDBUs"),
                                                         round(sum("LakeflowPipelinesDBUs"), 6).alias("LakeflowPipelinesDBUs"),
                                                         round(sum("LakeflowDBUs"), 6).alias("LakeflowDBUs"),
                                                         round(sum("LakeflowConnectRevShareDollars"), 4).alias("LakeflowConnectRevShareDollars"),
                                                         round(sum("LakeflowPipelinesRevShareDollars"), 4).alias("LakeflowPipelinesRevShareDollars"),
                                                         round(sum("LakeflowRevShareDollars"), 4).alias("LakeflowRevShareDollars"),
                                                         round(sum("BatchInferenceModelServingDBUs"), 6).alias("BatchInferenceModelServingDBUs"),
                                                         round(sum("BatchInferenceModelServingRevShareDollars"), 4).alias 
                                                         ("BatchInferenceModelServingRevShareDollars"),
                                                         round(sum("AgentFrameworkDBUs"), 6).alias("AgentFrameworkDBUs"),
                                                         round(sum("AgentFrameworkRevShareDollars"), 4).alias("AgentFrameworkRevShareDollars"),
                                                         round(sum("VectorSearchStorageDBUs"), 6).alias("VectorSearchStorageDBUs"),
                                                         round(sum("VectorSearchStorageRevShareDollars"), 4).alias("VectorSearchStorageRevShareDollars"),
                                                         round(sum("FY26AIDBUs"), 6).alias("FY26AIDBUs"),
                                                         round(sum("FY26AIDollars"), 4).alias("FY26AIDollars"),
                                                         round(sum("MCTDBUs"),6).alias("MCTDBUs"),\
                                                         round(sum("MCTRevShareDollars"),4).alias("MCTRevShareDollars"),\
                                                         round(sum("MCTModelHeroRunTrainingRevShareDollars"),4).alias("MCTModelHeroRunTrainingRevShareDollars"),\
                                                         round(sum("MCTModelReservedTrainingRevShareDollars"),4).alias("MCTModelReservedTrainingRevShareDollars"),\
                                                         round(sum("MCTModelOnDemandTrainingRevShareDollars"),4).alias("MCTModelOnDemandTrainingRevShareDollars"),\
                                                         round(sum("StreamingDLTRevShareDollars_calculated"),4).alias("StreamingDLTRevShareDollars_calculated"),\
                                                         round(sum("UCRevShareDollars_calculated"),4).alias("UCRevShareDollars_calculated"),\
                                                         round(sum("CPUModelServingRevShareDollars"),4).alias("CPUModelServingRevShareDollars"),\
                                                         round(sum("FoundationModelTrainingRevShareDollars"),4).alias("FoundationModelTrainingRevShareDollars"),\
                                                         round(sum("VectorSearchIngestionRevShareDollars"),4).alias("VectorSearchIngestionRevShareDollars"),\
                                                         round(sum("VectorSearchServingRevShareDollars"),4).alias("VectorSearchServingRevShareDollars"),\
                                                         round(sum("FinetuningDBUs"), 6).alias("FinetuningDBUs"),\
                                                         round(sum("FinetuningRevShareDollars"), 6).alias("FinetuningRevShareDollars"),\
                                                         round(sum("AgentEvalsDBUs"), 6).alias("AgentEvalsDBUs"),\
                                                         round(sum("AgentEvalsRevShareDollars"), 6).alias("AgentEvalsRevShareDollars"),\
                                                         round(sum("AgentEvalsSyntheticDataDBUs"), 6).alias("AgentEvalsSyntheticDataDBUs"),\
                                                         round(sum("AgentEvalsSyntheticDataRevShareDollars"), 6).alias("AgentEvalsSyntheticDataRevShareDollars"),\
                                                         round(sum("AIRuntimeDBUs"), 6).alias("AIRuntimeDBUs"),\
                                                         round(sum("AIRuntimeRevShareDollars"), 6).alias("AIRuntimeRevShareDollars"),\
                                                         round(sum("AnthropicThroughputModelServingDBUs"), 6).alias("AnthropicThroughputModelServingDBUs"),\
                                                         round(sum("AnthropicThroughputModelServingRevShareDollars"), 6).alias("AnthropicThroughputModelServingRevShareDollars"),\
                                                         round(sum("AnthropicFoundationModelAPIDBUs"), 6).alias("AnthropicFoundationModelAPIDBUs"),\
                                                         round(sum("AnthropicFoundationModelAPIRevShareDollars"), 6).alias("AnthropicFoundationModelAPIRevShareDollars"),\
                                                         round(sum("ModelServingFMAPIDBUs"), 6).alias("ModelServingFMAPIDBUs"),\
                                                         round(sum("ModelServingFMAPIRevShareDollars"), 6).alias("ModelServingFMAPIRevShareDollars"),\
                                                         round(sum("LakehouseMonitoringDBUs"), 6).alias("LakehouseMonitoringDBUs"),\
                                                         round(sum("LakehouseMonitoringRevShareDollars"), 6).alias("LakehouseMonitoringRevShareDollars"),\
                                                         round(sum("FmMixtral87bInstructDBUs"), 6).alias("FmMixtral87bInstructDBUs"),\
                                                         round(sum("FmLlama270bChatDBUs"), 6).alias("FmLlama270bChatDBUs"),\
                                                         round(sum("FmBgeLargeENDBUs"), 6).alias("FmBgeLargeENDBUs"),\
                                                         round(sum("FmMpt30bInstructDBUs"), 6).alias("FmMpt30bInstructDBUs"),\
                                                         round(sum("FmMpt7bInstructDBUs"), 6).alias("FmMpt7bInstructDBUs"),\
                                                         round(sum("FmDatabricksDbrxChatDBUs"), 6).alias("FmDatabricksDbrxChatDBUs"),\
                                                         round(sum("FmMixtral87bInstructRevShareDollars"), 6).alias("FmMixtral87bInstructRevShareDollars"),\
                                                         round(sum("FmLlama270bChatRevShareDollars"), 6).alias("FmLlama270bChatRevShareDollars"),\
                                                         round(sum("FmBgeLargeENRevShareDollars"), 6).alias("FmBgeLargeENRevShareDollars"),\
                                                         round(sum("FmMpt30bInstructRevShareDollars"), 6).alias("FmMpt30bInstructRevShareDollars"),\
                                                         round(sum("FmMpt7bInstructRevShareDollars"), 6).alias("FmMpt7bInstructRevShareDollars"),\
                                                         round(sum("FmDatabricksDbrxChatRevShareDollars"), 6).alias("FmDatabricksDbrxChatRevShareDollars")
                                                         )

consumptionAccountDaily = consumptionAccountDaily.orderBy("accountId", "accountName", "usage_date")


consumptionAccountDaily.createOrReplaceTempView('consumption_account_daily')




# orderByColumns = ["accountID", "accountName", "usage_date"]
# partitionByColumns = ["accountID", "accountName"]
# usage_window = Window.partitionBy(*partitionByColumns)\
#                      .orderBy("usage_date")\
#                      .rowsBetween(Window.unboundedPreceding, Window.currentRow)


# consumptionAccountDailyCum  =   consumptionAccountDaily.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
#                                                        .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
#                                                        .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
#                                                        .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
#                                                        .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
#                                                        .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
#                                                        .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
#                                                        .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
#                                                        .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
#                                                        .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
#                                                        .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
#                                                        .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
#                                                        .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
#                                                        .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
#                                                        .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
#                                                        .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
#                                                        .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# consumptionAccountDailyCum = consumptionAccountDailyCum.orderBy(*orderByColumns)

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists account_daily_forecast

# COMMAND ----------

spark.sql(f"""
create temp view account_daily_forecast 
as
with forecasts as (
  select
    f.sfdcAccountId as accountId,
    f.date as usage_date,
    sum(coalesce(f.forecast,0)) as revShareForecastDollars_new
  from {ACCCOUNT_DATE_FORECAST} f
  where f.runDate = (
    select max(runDate) from {ACCCOUNT_DATE_FORECAST}
    )
  group by 1, 2
)
select ad.accountId,
       ad.accountName,
       usage_date,
       0 ListCommit,
       0 DiscountedCommit,
       0 RevShareCommit,       
       0 listDollars,
       0 custDollars,
       0 revShareDollars,
       0 InteractiveDBUs,
       0 AutomatedDBUs, 
       0 listForecastDollars,
       0 custForecastDollars,
       0 revShareForecastDollars,
       0 InteractiveForecastDBUs,
       0 AutomatedForecastDBUs,
       
       0 DeltaRevShareDollars,
       0 DeltaInteractiveDBUs,
       0 DeltaAutomatedDBUs, 
       0 DeltaSQLDBUs,
       0 SQLAnalyticsDBUs,
       0 SQLRevShareDollars, 
       0 SQLAnalyticsForecastDBUs,
       0 SQLRevShareForecastDollars,
       0 StandardDBUs,
       0 PremiumDBUs,       
       0 EnterpriseDBUs,       
       0 StandardRevShareDollars,
       0 PremiumRevShareDollars,       
       0 EnterpriseRevShareDollars,
       0 MoonCakeDBUs,
       0 MoonCakeDeltaDBUs,
       0 MoonCakeDBUDollars,
       0 MoonCakeDeltaDBUDollars, 
       0 ISVDBUs,
       0 ISVRevShareDollars,
       0 DBTDBUs,
       0 DBTRevShareDollars,
       0 FivetranDBUs,
       0 FivetranRevShareDollars, 
       
       0 ServerlessDBUs,
       0 ServerlessRevShareDollars,
       0 UCDBUs,
       0 UCRevShareDollars,
       0 MLDBUs,
       0 MLRevShareDollars,
       0 GenAIDBUs,
       0 GenAIRevShareDollars,
       0 CPUModelServingRevShareDollars,
       0 GPUModelServingDBUs,
       0 GPUModelServingRevShareDollars,
       0 ThroughputModelServingDBUs,
       0 ThroughputModelServingRevShareDollars,
       0 FoundationModelAPIDBUs,
       0 FoundationModelAPIRevShareDollars,
       0 FoundationModelTrainingRevShareDollars,
       0 VectorSearchDBUs,
       0 VectorSearchRevShareDollars,
       0 VectorSearchIngestionRevShareDollars,
       0 VectorSearchServingRevShareDollars,
       0 LakeflowConnectDBUs,
       0 LakeflowPipelinesDBUs,
       0 LakeflowDBUs,
       0 LakeflowConnectRevShareDollars,
       0 LakeflowPipelinesRevShareDollars,
       0 LakeflowRevShareDollars,
       0 BatchInferenceModelServingDBUs,
       0 BatchInferenceModelServingRevShareDollars,
       0 AgentFrameworkDBUs,
       0 AgentFrameworkRevShareDollars,
       0 VectorSearchStorageDBUs,
       0 VectorSearchStorageRevShareDollars,
       0 FY26AIDBUs,
       0 FY26AIDollars,
       0 MCTDBUs,
       0 MCTRevShareDollars,
       0 mct_model_hero_run_training_dollars,
       0 mct_model_reserved_training_dollars,
       0 mct_model_on_demand_training_dollars,
       0 PhotonDBUs,
       0 PhotonRevShareDollars,
       0 DLTDBUs,
       0 DLTRevShareDollars,
       0 StreamingDLTDBUs,
       0 StreamingDLTRevShareDollars,
       0 MoonCakeSQLDBUs,
       0 MoonCakeSQLDollars,
       0 DBUs,
       0 DeltaDBUs,
       0 StreamingDLTRevShareDollars_calculated,
       0 UCRevShareDollars_calculated,
       0 FinetuningDBUs,
       0 FinetuningRevShareDollars,
       0 AgentEvalsDBUs,
       0 AgentEvalsRevShareDollars,
       0 AgentEvalsSyntheticDataDBUs,
       0 AgentEvalsSyntheticDataRevShareDollars,
       0 AIRuntimeDBUs,
       0 AIRuntimeRevShareDollars,
       0 AnthropicThroughputModelServingDBUs,
       0 AnthropicThroughputModelServingRevShareDollars,
       0 AnthropicFoundationModelAPIDBUs,
       0 AnthropicFoundationModelAPIRevShareDollars,
       0 ModelServingFMAPIDBUs,
       0 ModelServingFMAPIRevShareDollars,
       0 LakehouseMonitoringDBUs,
       0 LakehouseMonitoringRevShareDollars,
       0 FmMixtral87bInstructDBUs,
       0 FmLlama270bChatDBUs,
       0 FmBgeLargeENDBUs,
       0 FmMpt30bInstructDBUs,
       0 FmMpt7bInstructDBUs,
       0 FmDatabricksDbrxChatDBUs,
       0 FmMixtral87bInstructRevShareDollars,
       0 FmLlama270bChatRevShareDollars,
       0 FmBgeLargeENRevShareDollars,
       0 FmMpt30bInstructRevShareDollars,
       0 FmMpt7bInstructRevShareDollars,
       0 FmDatabricksDbrxChatRevShareDollars,
       revShareForecastDollars_new,
       revShareForecastDollars_new as revShareForecastDollars_genAI -- As per DS table changes in Jan 2025, GenAI is included in regular forecasts. As we cannot drop the column, we are making the columns the same.
from forecasts f
join {ACCOUNT_DIM} ad on f.accountId = ad.accountId
order by ad.accountName, usage_date
""")

# COMMAND ----------

account_daily_forecast_combined = spark.sql(""" 
with 

current_usage (
select c.*,
       0 revShareForecastDollars_new,
       0 revShareForecastDollars_genAI
from consumption_account_daily c
left join account_daily_forecast f on c.accountId = f.accountId and c.usage_date = f.usage_date
where f.accountId is null
  and f.usage_date is null
),


existing_ds (
select c.*,
       case when c.revShareDollars > 0 then 0
            else f.revShareForecastDollars_new
       end as revShareForecastDollars_new,
       case when c.revShareDollars > 0 then 0
            else f.revShareForecastDollars_genAI
        end as revShareForecastDollars_genAI
from consumption_account_daily c
join account_daily_forecast f on c.accountId = f.accountId and c.usage_date = f.usage_date
),

new_ds (

select f.*
from account_daily_forecast f 
left join consumption_account_daily c  on f.accountId = c.accountId and f.usage_date = c.usage_date 
where c.accountId is null 
and c.usage_date is null
)

select *
from current_usage
union
select *
from existing_ds
union
select *
from new_ds
""")

# COMMAND ----------

#dbutils.fs.ls(USAGE_ACCOUNT_DAILY_GOLD_LOCATION)

# COMMAND ----------

account_daily_forecast_combined.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGE_ACCOUNT_DAILY)

# COMMAND ----------

# %sql
# create table bdw.usagec_account_daily
# using delta
# location '/mnt/bse-dev/usagec_account_daily_gold'

# COMMAND ----------

# DBTITLE 1,Account Monthly
account_usage_daily = spark.sql(f"""
select uad.*,
       dt.month_end_date
from {USAGE_ACCOUNT_DAILY} uad
join {BI_DATES} dt on uad.usage_date = dt.date
""")

# COMMAND ----------

accAggColumns = ["accountId", "accountName", "month_end_date"]
accMonthly =  account_usage_daily.groupBy(*accAggColumns)\
                                           .agg(\
                                                 round(sum("listDollars"),4).alias("listDollars"),\
                                                 round(sum("custDollars"),4).alias("custDollars"),\
                                                 round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                 round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                 round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                 round(sum("listForecastDollars"),4).alias("listForecastDollars"),\
                                                 round(sum("custForecastDollars"),4).alias("custForecastDollars"),\
                                                 round(sum("revShareForecastDollars"),4).alias("revShareForecastDollars"),\
                                                 round(sum("InteractiveForecastDBUs"),4).alias("InteractiveForecastDBUs"),\
                                                 round(sum("AutomatedForecastDBUs"),4).alias("AutomatedForecastDBUs"),\
                                                 round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                 round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                 round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                 round(sum("DeltaSQLDBUs"),4).alias("DeltaSQLDBUs"),\
                                                 round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                 round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                 round(sum("SQLAnalyticsForecastDBUs"),4).alias("SQLAnalyticsForecastDBUs"),\
                                                 round(sum("SQLRevShareForecastDollars"),4).alias("SQLRevShareForecastDollars"),\
                                                 round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                 round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                 round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                 round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                 round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                 round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                 round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                 round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                 round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                 round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars"),\
                                                 round(sum("ISVDBUs"),4).alias("ISVDBUs"),\
                                                 round(sum("ISVRevShareDollars"),4).alias("ISVRevShareDollars"),\
                                                 round(sum("DBTDBUs"),4).alias("DBTDBUs"),\
                                                 round(sum("DBTRevShareDollars"),4).alias("DBTRevShareDollars"),\
                                                 round(sum("FivetranDBUs"),4).alias("FivetranDBUs"),\
                                                 round(sum("FivetranRevShareDollars"),4).alias("FivetranRevShareDollars"),\
                                                 round(sum("ServerlessDBUs"),4).alias("ServerlessDBUs"),\
                                                 round(sum("ServerlessRevShareDollars"),4).alias("ServerlessRevShareDollars"),\
                                                 round(sum("PhotonDBUs"),4).alias("PhotonDBUs"),\
                                                 round(sum("PhotonRevShareDollars"),4).alias("PhotonRevShareDollars"),\
                                                 round(sum("DLTDBUs"),4).alias("DLTDBUs"),\
                                                 round(sum("DLTRevShareDollars"),4).alias("DLTRevShareDollars"),\
                                                 round(sum("StreamingDLTDBUs"),4).alias("StreamingDLTDBUs"),\
                                                 round(sum("StreamingDLTRevShareDollars"),4).alias("StreamingDLTRevShareDollars"),\
                                                 round(sum("MoonCakeSQLDBUs"),4).alias("MoonCakeSQLDBUs"),\
                                                 round(sum("MoonCakeSQLDollars"),4).alias("MoonCakeSQLDollars"),\
                                                 round(sum("DBUs"),6).alias("DBUs"),\
                                                 round(sum("DeltaDBUs"),6).alias("DeltaDBUs"),\
                                                 round(sum("UCDBUs"),6).alias("UCDBUs"),\
                                                 round(sum("UCRevShareDollars"),4).alias("UCRevShareDollars"),\
                                                 round(sum("MLDBUs"),6).alias("MLDBUs"),\
                                                 round(sum("MLRevShareDollars"),4).alias("MLRevShareDollars"),\
                                                 round(sum("GenAIDBUs"),6).alias("GenAIDBUs"),\
                                                 round(sum("GenAIRevShareDollars"),4).alias("GenAIRevShareDollars"),\
                                                 round(sum("GPUModelServingDBUs"),6).alias("GPUModelServingDBUs"),\
                                                 round(sum("GPUModelServingRevShareDollars"),4).alias("GPUModelServingRevShareDollars"),\
                                                 round(sum("ThroughputModelServingDBUs"),6).alias("ThroughputModelServingDBUs"),\
                                                 round(sum("ThroughputModelServingRevShareDollars"),4).alias("ThroughputModelServingRevShareDollars"),\
                                                 round(sum("FoundationModelAPIDBUs"),6).alias("FoundationModelAPIDBUs"),\
                                                 round(sum("FoundationModelAPIRevShareDollars"),4).alias("FoundationModelAPIRevShareDollars"),\
                                                 round(sum("VectorSearchDBUs"),6).alias("VectorSearchDBUs"),\
                                                 round(sum("VectorSearchRevShareDollars"),4).alias("VectorSearchRevShareDollars"),\
                                                 round(sum("LakeflowConnectDBUs"), 6).alias("LakeflowConnectDBUs"),
                                                 round(sum("LakeflowPipelinesDBUs"), 6).alias("LakeflowPipelinesDBUs"),
                                                 round(sum("LakeflowDBUs"), 6).alias("LakeflowDBUs"),
                                                 round(sum("LakeflowConnectRevShareDollars"), 4).alias("LakeflowConnectRevShareDollars"),
                                                 round(sum("LakeflowPipelinesRevShareDollars"), 4).alias("LakeflowPipelinesRevShareDollars"),
                                                 round(sum("LakeflowRevShareDollars"), 4).alias("LakeflowRevShareDollars"),
                                                 round(sum("BatchInferenceModelServingDBUs"), 6).alias("BatchInferenceModelServingDBUs"),
                                                 round(sum("BatchInferenceModelServingRevShareDollars"), 4).alias 
                                                 ("BatchInferenceModelServingRevShareDollars"),
                                                 round(sum("AgentFrameworkDBUs"), 6).alias("AgentFrameworkDBUs"),
                                                 round(sum("AgentFrameworkRevShareDollars"), 4).alias("AgentFrameworkRevShareDollars"),
                                                 round(sum("VectorSearchStorageDBUs"), 6).alias("VectorSearchStorageDBUs"),
                                                 round(sum("VectorSearchStorageRevShareDollars"), 4).alias("VectorSearchStorageRevShareDollars"),
                                                 round(sum("FY26AIDBUs"), 6).alias("FY26AIDBUs"),
                                                 round(sum("FY26AIDollars"), 4).alias("FY26AIDollars"),
                                                 round(sum("MCTDBUs"),6).alias("MCTDBUs"),\
                                                 round(sum("MCTRevShareDollars"),4).alias("MCTRevShareDollars"),\
                                                 round(sum("MCTModelHeroRunTrainingRevShareDollars"),4).alias("MCTModelHeroRunTrainingRevShareDollars"),\
                                                 round(sum("MCTModelReservedTrainingRevShareDollars"),4).alias("MCTModelReservedTrainingRevShareDollars"),\
                                                 round(sum("MCTModelOnDemandTrainingRevShareDollars"),4).alias("MCTModelOnDemandTrainingRevShareDollars"),\
                                                 round(sum("StreamingDLTRevShareDollars_calculated"),4).alias("StreamingDLTRevShareDollars_calculated"),\
                                                 round(sum("UCRevShareDollars_calculated"),4).alias("UCRevShareDollars_calculated"),\
                                                 round(sum("revShareForecastDollars_new"), 6).alias("revShareForecastDollars_new"),\
                                                 round(sum("revShareForecastDollars_genAI"), 6).alias("revShareForecastDollars_genAI"),\
                                                 round(sum("CPUModelServingRevShareDollars"), 6).alias("CPUModelServingRevShareDollars"),\
                                                 round(sum("FoundationModelTrainingRevShareDollars"), 6).alias("FoundationModelTrainingRevShareDollars"),\
                                                 round(sum("VectorSearchIngestionRevShareDollars"), 6).alias("VectorSearchIngestionRevShareDollars"),\
                                                 round(sum("VectorSearchServingRevShareDollars"), 6).alias("VectorSearchServingRevShareDollars"),\
                                                 round(sum("FinetuningDBUs"), 6).alias("FinetuningDBUs"),\
                                                 round(sum("FinetuningRevShareDollars"), 6).alias("FinetuningRevShareDollars"),\
                                                 round(sum("AgentEvalsDBUs"), 6).alias("AgentEvalsDBUs"),\
                                                 round(sum("AgentEvalsRevShareDollars"), 6).alias("AgentEvalsRevShareDollars"),\
                                                 round(sum("AgentEvalsSyntheticDataDBUs"), 6).alias("AgentEvalsSyntheticDataDBUs"),\
                                                 round(sum("AgentEvalsSyntheticDataRevShareDollars"), 6).alias("AgentEvalsSyntheticDataRevShareDollars"),\
                                                 round(sum("AIRuntimeDBUs"), 6).alias("AIRuntimeDBUs"),\
                                                 round(sum("AIRuntimeRevShareDollars"), 6).alias("AIRuntimeRevShareDollars"),\
                                                 round(sum("AnthropicThroughputModelServingDBUs"), 6).alias("AnthropicThroughputModelServingDBUs"),\
                                                 round(sum("AnthropicThroughputModelServingRevShareDollars"), 6).alias("AnthropicThroughputModelServingRevShareDollars"),\
                                                 round(sum("AnthropicFoundationModelAPIDBUs"), 6).alias("AnthropicFoundationModelAPIDBUs"),\
                                                 round(sum("AnthropicFoundationModelAPIRevShareDollars"), 6).alias("AnthropicFoundationModelAPIRevShareDollars"),\
                                                 round(sum("ModelServingFMAPIDBUs"), 6).alias("ModelServingFMAPIDBUs"),\
                                                 round(sum("ModelServingFMAPIRevShareDollars"), 6).alias("ModelServingFMAPIRevShareDollars"),\
                                                 round(sum("LakehouseMonitoringDBUs"), 6).alias("LakehouseMonitoringDBUs"),\
                                                 round(sum("LakehouseMonitoringRevShareDollars"), 6).alias("LakehouseMonitoringRevShareDollars"),\
                                                 round(sum("FmMixtral87bInstructDBUs"), 6).alias("FmMixtral87bInstructDBUs"),\
                                                 round(sum("FmLlama270bChatDBUs"), 6).alias("FmLlama270bChatDBUs"),\
                                                 round(sum("FmBgeLargeENDBUs"), 6).alias("FmBgeLargeENDBUs"),\
                                                 round(sum("FmMpt30bInstructDBUs"), 6).alias("FmMpt30bInstructDBUs"),\
                                                 round(sum("FmMpt7bInstructDBUs"), 6).alias("FmMpt7bInstructDBUs"),\
                                                 round(sum("FmDatabricksDbrxChatDBUs"), 6).alias("FmDatabricksDbrxChatDBUs"),\
                                                 round(sum("FmMixtral87bInstructRevShareDollars"), 6).alias("FmMixtral87bInstructRevShareDollars"),\
                                                 round(sum("FmLlama270bChatRevShareDollars"), 6).alias("FmLlama270bChatRevShareDollars"),\
                                                 round(sum("FmBgeLargeENRevShareDollars"), 6).alias("FmBgeLargeENRevShareDollars"),\
                                                 round(sum("FmMpt30bInstructRevShareDollars"), 6).alias("FmMpt30bInstructRevShareDollars"),\
                                                 round(sum("FmMpt7bInstructRevShareDollars"), 6).alias("FmMpt7bInstructRevShareDollars"),\
                                                round(sum("FmDatabricksDbrxChatRevShareDollars"), 6).alias("FmDatabricksDbrxChatRevShareDollars")
                                                )
accMonthly = accMonthly.orderBy("accountId", "accountName", "month_end_date")

partitionByColumns = ["accountID", "accountName"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("month_end_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

accMonthlyCum =    accMonthly.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                             .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                             .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                             .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                             .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                             .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                             .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                             .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                             .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                             .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                             .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------



# COMMAND ----------

accMonthlyCum.createOrReplaceTempView("AccountMonthly")
# account_workspace_users_monthly = spark.sql("""
# with account_workspaces (
# select aws.Id AccountId,
#        wk.Id workspaceSFDCId
# from sfdc_ds.account aws
# join sfdc_ds.workspace__c wk on aws.Id = wk.account__c and aws.processDate = wk.processDate
# where aws.processDate = (select max(processDate) from sfdc_ds.account)
# ),

# workspace_logins (
# select wk.AccountId,
#        usr.workspace__c,
#        usr.email__c,
#        cast(max(usr.last_login_time__c) as date) max_last_login_time
# from sfdc_ds.workspace_user__c usr
# join account_workspaces wk on usr.workspace__c = wk.workspaceSFDCId
# where processDate >= '2020-01-01'
# and is_removed__c = 0
# group by 1,2,3
# )

# select AccountId,
#        dt.month_end_date,
#        count(*) workspace_users_count
# from workspace_logins wl
# join bdw.bi_dates dt on wl.max_last_login_time = dt.date
# where max_last_login_time >= '2020-01-01' 
# and email__c not like '%databricks.com'
# group by 1,2
# order by 3 desc
# """)
# account_workspace_users_monthly.createOrReplaceTempView("account_workspace_users_monthly")


account_workspace_users_monthly = spark.sql(f"""
with account_workspaces (
select aws.Id AccountId,
       wk.Id workspaceSFDCId
from {SFDC_ACCOUNT} aws
join {SFDC_WORKSPACE} wk on aws.Id = wk.account__c and aws.processDate = wk.processDate
where aws.processDate = (select max(processDate) from {SFDC_ACCOUNT})
),
 
workspace_logins (
select wk.AccountId,
       dt.month_end_date,
       usr.email__c,
       cast(max(usr.last_login_time__c) as date) max_last_login_time
from {SFDC_WORKSPACE_USER} usr
join account_workspaces wk on usr.workspace__c = wk.workspaceSFDCId
join {BI_DATES} dt on usr.processDate = dt.date
where processDate >= '2020-01-01'
and is_removed__c = 0
group by 1,2,3
)
 
select accountId,
       dt.month_end_date,
       count(distinct email__c) workspace_users_count
from workspace_logins wl
join {BI_DATES} dt on wl.max_last_login_time = dt.date
where max_last_login_time >= '2020-01-01' 
and email__c not like '%databricks.com'
group by 1,2
""")
account_workspace_users_monthly.createOrReplaceTempView("account_workspace_users_monthly")

account_monthly_extended = spark.sql("""
select am.*,
       coalesce(wk.workspace_users_count,0) workspace_users_count
from AccountMonthly am
left join account_workspace_users_monthly wk on am.accountId = wk.AccountId and am.month_end_date = wk.month_end_date
""")

account_monthly_extended.createOrReplaceTempView("usagec_account_monthly")

# COMMAND ----------

ae_cse_forecast = spark.sql(f"""
with 

base (
select case when ucm.RecordTypeId = "0123f000000XdPlAAK" then uc.Account__c
            when ucm.RecordTypeId = "0123f000000XdPkAAK" then ucm.Account__c
            else "other"
       end as accountId,       
       dt.month_end_date,
       ucm.RecordTypeId,
       case when ucm.RecordTypeId = "0123f000000XdPlAAK" then "cse"
            when ucm.RecordTypeId = "0123f000000XdPkAAK" then "ae"
            else "other"
       end as forecastType,
       Forecast__c AEForecastDBU,
       (Forecast__c * Effective_Rate__c) AEForecastDBUDollars,   
       Effective_Rate__c EffectiveRate,       
       case when ucm.RecordTypeId = "0123f000000XdPlAAK" then Forecast__c
            else 0
       end as CSEBaseLineForecastDBU,

       case when ucm.RecordTypeId = "0123f000000XdPlAAK" then (Forecast__c * Effective_Rate__c) 
            else 0
       end as CSEBaseLineForecastDBUDollars,
       Best_Case__c CSEUpsideDBU,
       CSE_Upside__c CSEUpsideDBUDollars
       
from {SFDC_USECASE_MORR} ucm
left join {SFDC_USECASE} uc on ucm.Use_Case__c = uc.Id and ucm.processDate = uc.processDate
join {BI_DATES} dt on ucm.Date__c = dt.date
where ucm.processDate = (select max(processDate) from {SFDC_USECASE_MORR})
     and ucm.isDeleted = False
),

final (
select accountId,
       month_end_date,
       forecastType,
       sum(CSEBaseLineForecastDBU) CSEBaseLineForecastDBU,
       round(sum(CSEBaseLineForecastDBUDollars),2) CSEBaseLineForecastDBUDollars,
       sum(CSEUpsideDBU) CSEUpsideDBU,
       round(sum(CSEUpsideDBUDollars),2) CSEUpsideDBUDollars,
       case when forecastType = 'ae' then round(sum(AEForecastDBU),2)
            else 0
       end as AEForecastDBU,
       case when forecastType = 'ae' then round(sum(AEForecastDBUDollars),2)
            else 0
       end as AEForecastDBUDollars      
from base 
group by 1,2,3
order by accountId, month_end_date desc  
)


select accountId,
       month_end_date,
       sum(CSEBaseLineForecastDBU) CSEBaseLineForecastDBU,
       round(sum(CSEBaseLineForecastDBUDollars),2) CSEBaseLineForecastDBUDollars,
       sum(CSEUpsideDBU) CSEUpsideDBU,
       round(sum(CSEUpsideDBUDollars),2) CSEUpsideDBUDollars,
       round(sum(AEForecastDBU),2) AEForecastDBU,
       round(sum(AEForecastDBUDollars),2) AEForecastDBUDollars      
from final 
group by 1,2
order by accountId, month_end_date desc
""")
print(ae_cse_forecast.count())
ae_cse_forecast.createOrReplaceTempView("aecse_forecast")

accmonthly_cseaeforecast = spark.sql("""
select acc.*,
       coalesce(CSEBaseLineForecastDBU, 0) CSEBaseLineForecastDBU,
       coalesce(CSEBaseLineForecastDBUDollars, 0) CSEBaseLineForecastDBUDollars,
       coalesce(CSEUpsideDBU, 0) CSEUpsideDBU,
       coalesce(CSEUpsideDBUDollars, 0) CSEUpsideDBUDollars,
       coalesce(AEForecastDBU, 0) AEForecastDBU,
       coalesce(AEForecastDBUDollars, 0) AEForecastDBUDollars      
from usagec_account_monthly acc
left join aecse_forecast af on acc.accountId = af.accountId and acc.month_end_date = af.month_end_date
""")

# COMMAND ----------

ae_cse_forecast.createOrReplaceTempView("usagec_account_monthly_ae_cse")

# COMMAND ----------

accmonthly_cseaeforecast.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_ACCOUNT_MONTHLY)

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))

# COMMAND ----------


