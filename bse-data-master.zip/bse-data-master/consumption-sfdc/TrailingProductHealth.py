# Databricks notebook source
'''
Trailing Product Health calculates rolling sum of numbers for revShare and various product cuts across 7, 28 and 91 days. It also calculated MTD and QTD metrics for the same.
Input sources:
- main.gtm_consumption_silver.account_consumption_daily
- main.it_lakehouse.paid_usage_metering
- main.data_product_features.customer_metrics -> ETL + Workflow dollars
- main.gtm_consumption_silver.granular_table -> DBSQL dollars
The code is generally structured as a base CTE from the above sources, followed by a trailing CTE for calculating rollups. Finally all of the trailing CTEs are combined together.
'''

# COMMAND ----------

trailing_product_health_df = spark.sql(f"""
with max_dates as (
  select
    MAX(
      CASE
        WHEN revShareDollars > 0 THEN usage_date
        ELSE NULL
      END
    ) max_usage_date,
    MAX(
      CASE
        WHEN revShareDollars > 0 THEN usage_date
        ELSE NULL
      END
    ) max_dbsql_usage_date,
    MAX(
      CASE
        WHEN UCRevShareDollars > 0 THEN usage_date
        ELSE NULL
      END
    ) max_uc_usage_date,
    MAX(
      CASE
        WHEN ServerlessRevShareDollars > 0 THEN usage_date
        ELSE NULL
      END
    ) max_serverless_usage_date,
    MAX(
      CASE
        WHEN GenAIRevShareDollars > 0 THEN usage_date
        ELSE NULL
      END
    ) as max_gen_ai_usage_date,
    MAX(
      CASE
        WHEN MCTRevShareDollars > 0 THEN usage_date
        ELSE NULL
      END
    ) as max_mct_usage_date,
    MAX(
      CASE
        WHEN LakeflowConnectRevShareDollars > 0 THEN usage_date
        ELSE NULL
      END
    ) as max_lakeflow_connect_usage_date,
    MAX(
      CASE
        WHEN LakeflowPipelinesRevShareDollars > 0 THEN usage_date
        ELSE NULL
      END
    ) as max_lakeflow_pipeline_usage_date,
    MAX(
      CASE
        WHEN FY26AIDollars > 0 THEN usage_date
        ELSE NULL
      END
    ) as max_fy26_ai_usage_date
  from
    main.gtm_consumption_silver.account_consumption_daily
  where
    usage_date between current_date() - interval '365' day and current_date()
),
revshare_maxdates as (
  select
    accountID,

    --revshare
    sum(
      if(
        usage_date between
          cast(max_usage_date as date) - INTERVAL '6' DAY
        and
          cast(max_usage_date as date),
        revShareDollars,
        0
      )
    ) as revShareDollars_t7d_maxdates,
    sum(
      if(
        usage_date between
          cast(max_usage_date as date) - INTERVAL '27' DAY
        and
          cast(max_usage_date as date),
        revShareDollars,
        0
      )
    ) as revShareDollars_t28d_maxdates,
    sum(
      if(
        usage_date between
          cast(max_usage_date as date) - INTERVAL '90' DAY
        and
          cast(max_usage_date as date),
        revShareDollars,
        0
      )
    ) as revShareDollars_t91d_maxdates,

    --UC revshare
    sum(
      if(
        usage_date between
          cast(max_uc_usage_date as date) - INTERVAL '6' DAY
        and
          cast(max_uc_usage_date as date),
        UCRevShareDollars,
        0
      )
    ) as UCRevShareDollars_t7d_maxdates,
    sum(
      if(
        usage_date between
          cast(max_uc_usage_date as date) - INTERVAL '27' DAY
        and
          cast(max_uc_usage_date as date),
        UCRevShareDollars,
        0
      )
    ) as UCRevShareDollars_t28d_maxdates,
    sum(
      if(
        usage_date between
          cast(max_uc_usage_date as date) - INTERVAL '90' DAY
        and
          cast(max_uc_usage_date as date),
        UCRevShareDollars,
        0
      )
    ) as UCRevShareDollars_t91d_maxdates,

    --Serverless
    sum(
      if(
        usage_date between
          cast(max_serverless_usage_date as date) - INTERVAL '6' DAY
        and
          cast(max_serverless_usage_date as date),
        ServerlessRevShareDollars,
        0
      )
    ) as ServerlessRevShareDollars_t7d_maxdates,
    sum(
      if(
        usage_date between
          cast(max_serverless_usage_date as date) - INTERVAL '27' DAY
        and
          cast(max_serverless_usage_date as date),
        ServerlessRevShareDollars,
        0
      )
    ) as ServerlessRevShareDollars_t28d_maxdates,
    sum(
      if(
        usage_date between
          cast(max_serverless_usage_date as date) - INTERVAL '90' DAY
        and
          cast(max_serverless_usage_date as date),
        ServerlessRevShareDollars,
        0
      )
    ) as ServerlessRevShareDollars_t91d_maxdates
  from
    main.gtm_consumption_silver.account_consumption_daily cross join max_dates
  group by
    accountID
),
trailing_dataset_main as (
select
  a.accountId,
  a.accountName,
  usage_date,
  fiscal_quarter_end_date,
  a.month_end_date,

  --revshare
  revShareDollars,
  SUM(revShareDollars) OVER (
      PARTITION BY a.accountId, d.fiscal_quarter_end_date
      ORDER BY usage_date
    ) as revShareDollarsQTD,
  SUM(revShareDollars) OVER (
      PARTITION BY a.accountId, d.month_end_date
      ORDER BY usage_date
    ) as revShareDollarsMTD,
  if(
    usage_date >= max_usage_date,
    revShareDollars_t7d_maxdates,
    sum(revShareDollars) OVER (
        PARTITION BY a.accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      )
  ) as revShareDollars_t7d,
  if(
    usage_date >= max_usage_date,
    revShareDollars_t28d_maxdates,
    sum(revShareDollars) OVER (
        PARTITION BY a.accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      )
  ) as revShareDollars_t28d,
  if(
    usage_date >= max_usage_date,
    revShareDollars_t91d_maxdates,
    sum(revShareDollars) OVER (
        PARTITION BY a.accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      )
  ) as revShareDollars_t91d,

  -- UCrevshare
  UCRevShareDollars,
  SUM(UCRevShareDollars) OVER (
      PARTITION BY a.accountId, d.fiscal_quarter_end_date
      ORDER BY usage_date
    ) as UCRevShareDollarsQTD,
  SUM(UCRevShareDollars) OVER (
      PARTITION BY a.accountId, d.month_end_date
      ORDER BY usage_date
    ) as UCRevShareDollarsMTD,
  if(
    usage_date >= max_uc_usage_date,
    UCRevShareDollars_t7d_maxdates,
    sum(UCRevShareDollars) OVER (
        PARTITION BY a.accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      )
  ) as UCRevShareDollars_t7d,
  if(
    usage_date >= max_uc_usage_date,
    UCRevShareDollars_t28d_maxdates,
    sum(UCRevShareDollars) OVER (
        PARTITION BY a.accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      )
  ) as UCRevShareDollars_t28d,
  if(
    usage_date >= max_uc_usage_date,
    UCRevShareDollars_t91d_maxdates,
    sum(UCRevShareDollars) OVER (
        PARTITION BY a.accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      )
  ) as UCRevShareDollars_t91d,

  -- Serverless
  ServerlessRevShareDollars,
  SUM(ServerlessRevShareDollars) OVER (
      PARTITION BY a.accountId, d.fiscal_quarter_end_date
      ORDER BY usage_date
    ) as ServerlessRevShareDollarsQTD,
  SUM(ServerlessRevShareDollars) OVER (
      PARTITION BY a.accountId, d.month_end_date
      ORDER BY usage_date
    ) as ServerlessRevShareDollarsMTD,
  if(
    usage_date >= max_serverless_usage_date,
    ServerlessRevShareDollars_t7d_maxdates,
    sum(ServerlessRevShareDollars) OVER (
        PARTITION BY a.accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      )
  ) as ServerlessRevShareDollars_t7d,
  if(
    usage_date >= max_serverless_usage_date,
    ServerlessRevShareDollars_t28d_maxdates,
    sum(ServerlessRevShareDollars) OVER (
        PARTITION BY a.accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      )
  ) as ServerlessRevShareDollars_t28d,
  if(
    usage_date >= max_serverless_usage_date,
    ServerlessRevShareDollars_t91d_maxdates,
    sum(ServerlessRevShareDollars) OVER (
        PARTITION BY a.accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      )
  ) as ServerlessRevShareDollars_t91d
from
  main.gtm_consumption_silver.account_consumption_daily a
    join main.it_core_dim.bi_dates d
      on d.date = usage_date
    join revshare_maxdates
      on a.accountId = revshare_maxdates.accountid
    cross join max_dates
where
  usage_date between current_date() - interval '365' day and current_date()
),
etl_workflow_dollars as (
  select salesforce_account_id as accountId
    , cm.date as usage_date
    , fiscal_quarter_end_date
    , month_end_date
    , etl_dollars as ETLRevShareDollars
    , SUM(etl_dollars) OVER (PARTITION BY salesforce_account_id, d.fiscal_quarter_end_date ORDER BY cm.date) as ETLRevShareDollarsQTD
    , SUM(etl_dollars) OVER (PARTITION BY salesforce_account_id, d.month_end_date ORDER BY cm.date) as ETLRevShareDollarsMTD
    , etl_dollars_t7d as ETLRevShareDollars_t7d
    , etl_dollars_t28d as ETLRevShareDollars_t28d
    , etl_dollars_t91d as ETLRevShareDollars_t91d
    , workflows_dollars as WorkflowRevShareDollars
    , SUM(workflows_dollars) OVER (PARTITION BY salesforce_account_id, d.fiscal_quarter_end_date ORDER BY cm.date) as WorkflowRevShareDollarsQTD
    , SUM(workflows_dollars) OVER (PARTITION BY salesforce_account_id, d.month_end_date ORDER BY cm.date) as WorkflowRevShareDollarsMTD
    , workflows_dollars_t7d as WorkflowsRevShareDollars_t7d
    , workflows_dollars_t28d as WorkflowsRevShareDollars_t28d
    , workflows_dollars_t91d as WorkflowsRevShareDollars_t91d
  from main.data_product_features.customer_metrics cm
  join main.it_core_dim.bi_dates d on d.date = cm.date
  where cm.salesforce_account_id is not null
  and cm.date between current_date() - interval '365' day and current_date()
),
dbsql_base as (
select accountId
  , usage_date
  , sum(revShareDollars) as DBSQLRevShareDollars
  , coalesce(sum(case when usage_sku like '%pro%' then revShareDollars END), 0) as DBSQLProRevShareDollars
  , coalesce(sum(case when (usage_sku NOT like '%pro%' AND usage_sku NOT like '%serverless%') then revShareDollars END), 0) as DBSQLClassicRevShareDollars
  , coalesce(sum(case when (usage_sku like '%serverless%') then revShareDollars END), 0) as DBSQLServerlessRevShareDollars
from main.gtm_consumption_silver.granular_table
where
  skuType = 'sql'
  and usage_date between current_date() - interval '365' day and current_date()
group by accountId
  , usage_date
),
dbsql_trailing as (
  select accountId
    , usage_date
    , fiscal_quarter_end_date
    , month_end_date
    -- DBSQLRevShare
    , DBSQLRevShareDollars
    , SUM(DBSQLRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as DBSQLRevShareDollarsQTD
    , SUM(DBSQLRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as DBSQLRevShareDollarsMTD
    , sum(DBSQLRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as DBSQLRevShareDollars_t7d
    , sum(DBSQLRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as DBSQLRevShareDollars_t28d
    , sum(DBSQLRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as DBSQLRevShareDollars_t91d
    -- DBSQLProRevShare
, DBSQLProRevShareDollars
    , SUM(DBSQLProRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as DBSQLProRevShareDollarsQTD
    , SUM(DBSQLProRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as DBSQLProRevShareDollarsMTD
    , sum(DBSQLProRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as DBSQLProRevShareDollars_t7d
    , sum(DBSQLProRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as DBSQLProRevShareDollars_t28d
    , sum(DBSQLProRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as DBSQLProRevShareDollars_t91d
    -- Classic
, DBSQLClassicRevShareDollars
    , SUM(DBSQLClassicRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as DBSQLClassicRevShareDollarsQTD
    , SUM(DBSQLClassicRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as DBSQLClassicRevShareDollarsMTD
    , sum(DBSQLClassicRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as DBSQLClassicRevShareDollars_t7d
    , sum(DBSQLClassicRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as DBSQLClassicRevShareDollars_t28d
    , sum(DBSQLClassicRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as DBSQLClassicRevShareDollars_t91d
    -- Serverless
, DBSQLServerlessRevShareDollars
    , SUM(DBSQLServerlessRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as DBSQLServerlessRevShareDollarsQTD
    , SUM(DBSQLServerlessRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as DBSQLServerlessRevShareDollarsMTD
    , sum(DBSQLServerlessRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as DBSQLServerlessRevShareDollars_t7d
    , sum(DBSQLServerlessRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as DBSQLServerlessRevShareDollars_t28d
    , sum(DBSQLServerlessRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as DBSQLServerlessRevShareDollars_t91d
    from dbsql_base t1
  join main.it_core_dim.bi_dates d on d.date = usage_date
),
pum_base as (
  select
  p.sfdc_account_id as accountId,
  p.date as usage_date,
  sum(coalesce(p.sales_comp_metric.model_serving_dollars, 0)) as ModelServingRevShareDollars,
  sum(coalesce(p.sales_comp_metric.throughput_model_serving_dollars, 0)) as ThroughputServingRevShareDollars,
  sum(coalesce(p.sales_comp_metric.foundation_model_api_dollars, 0)) as FoundationModelAPIRevShareDollars,
  sum(coalesce(p.sales_comp_metric.vector_search_dollars, 0)) as VectorSearchRevShareDollars,
  sum(coalesce(p.sales_comp_metric.gen_ai_dollars, 0)) as GenAIRevShareDollars,
  sum(coalesce(p.sales_comp_metric.cpu_model_serving_dollars, 0)) as CPUModelServingRevShareDollars,
  sum(coalesce(p.sales_comp_metric.foundation_model_training_dollars, 0)) as FoundationModelTrainingRevShareDollars,
  sum(coalesce(p.sales_comp_metric.vector_search_ingestion_dollars, 0)) as VectorSearchIngestionRevShareDollars,
  sum(coalesce(p.sales_comp_metric.vector_search_serving_dollars, 0)) as VectorSearchServingRevShareDollars,
  sum(case when lower(mosaic_ml.sub_product_type) = 'hero_run' and platform = 'mct' then sales_comp_metric.mct_dollars else 0 end) as MosaicHeroRevShareDollars,
  sum(case when mosaic_ml.sub_product_type = 'RESERVED_TRAINING' and platform = 'mct' then sales_comp_metric.mct_dollars else 0 end) as MosaicReservedTrainingRevShareDollars,
  sum(case when mosaic_ml.sub_product_type = 'ON_DEMAND_TRAINING' and platform = 'mct' then sales_comp_metric.mct_dollars else 0 end) as MosaicOnDemandTrainingRevShareDollars,
  sum(case when platform = 'mct' then sales_comp_metric.mct_dollars else 0 end) as MosaicRevShareDollars,
  sum(coalesce(sales_comp_metric.lakeflow_dollars,0)) as LakeflowRevShareDollars,
  sum(coalesce(sales_comp_metric.lakeflow_pipelines_dollars,0)) as LakeflowPipelineRevShareDollars,
  sum(coalesce(sales_comp_metric.lakeflow_connect_dollars,0)) as LakeflowConnectRevShareDollars,
  sum(coalesce(sales_comp_metric.batch_inference_model_serving_dollars,0)) as BatchInferenceModelRevShareDollars,
  sum(coalesce(sales_comp_metric.agent_framework_dollars,0)) as AgentFrameworkRevShareDollars,
  sum(coalesce(sales_comp_metric.vector_search_storage_dollars,0)) as VectorSearchStorageRevShareDollars,
  sum(coalesce(sales_comp_metric.fy26_ai_dollars,0)) as FY26AIRevShareDollars,
  sum(IF(product_type="FOUNDATION_MODEL_TRAINING",usage_dollars,0)) as FinetuningRevShareDollars,
  sum(coalesce(sales_comp_metric.ai_runtime_dbu,0)) as AIRuntimeRevShareDollars,
  sum(IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_dollars,0)) as ModelServingFmApiRevShareDollars,
  sum(coalesce(sales_comp_metric.agent_evaluation_dollars,0)) as AgentEvalsRevShareDollars,
  sum(coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dollars,0)) as AgentEvalsSyntheticDataRevShareDollars,
  sum(coalesce(sales_comp_metric.lakehouse_monitoring_dollars,0)) as LakehouseMonitoringRevShareDollars,
  sum(coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dollars,0)) as FmMixtral87bInstructRevShareDollars,
  sum(coalesce(sales_comp_metric.fm_llama2_70b_chat_dollars,0)) as FmLlama270bChatRevShareDollars,
  sum(coalesce(sales_comp_metric.fm_mpt_30b_instruct_dollars,0)) as FmMpt30bInstructRevShareDollars,
  sum(coalesce(sales_comp_metric.fm_mpt_7b_instruct_dollars,0)) as FmMpt7bInstructRevShareDollars,
  sum(coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dollars,0)) as DatabricksDbrxChatRevShareDollars,
  sum(coalesce(sales_comp_metric.fm_bge_large_en_dollars,0)) as FmBgeLargeEnRevShareDollars
from main.fin_live_gold.paid_usage_metering p 
where p.date between current_date() - interval '365' day and current_date()
group by 1, 2
),
pum_trailing as (
  select
    accountId
    , usage_date
    , fiscal_quarter_end_date
    , month_end_date
    -- ModelServing
    , ModelServingRevShareDollars
    , SUM(ModelServingRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as ModelServingRevShareDollarsQTD
    , SUM(ModelServingRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as ModelServingRevShareDollarsMTD
    , sum(ModelServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as ModelServingRevShareDollars_t7d
    , sum(ModelServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as ModelServingRevShareDollars_t28d
    , sum(ModelServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as ModelServingRevShareDollars_t91d
    -- CPUModelServing
    , CPUModelServingRevShareDollars
    , SUM(CPUModelServingRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as CPUModelServingRevShareDollarsQTD
    , SUM(CPUModelServingRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as CPUModelServingRevShareDollarsMTD
    , sum(CPUModelServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as CPUModelServingRevShareDollars_t7d
    , sum(CPUModelServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as CPUModelServingRevShareDollars_t28d
    , sum(CPUModelServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as CPUModelServingRevShareDollars_t91d
    -- Throughputserving
    , ThroughputServingRevShareDollars
    , SUM(ThroughputServingRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as ThroughputServingRevShareDollarsQTD
    , SUM(ThroughputServingRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as ThroughputServingRevShareDollarsMTD
    , sum(ThroughputServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as ThroughputServingRevShareDollars_t7d
    , sum(ThroughputServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as ThroughputServingRevShareDollars_t28d
    , sum(ThroughputServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as ThroughputServingRevShareDollars_t91d
    -- FoundationModelAPIRevShareDollars
    , FoundationModelAPIRevShareDollars
    , SUM(FoundationModelAPIRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as FoundationModelAPIRevShareDollarsQTD
    , SUM(FoundationModelAPIRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as FoundationModelAPIRevShareDollarsMTD
    , sum(FoundationModelAPIRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as FoundationModelAPIRevShareDollars_t7d
    , sum(FoundationModelAPIRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as FoundationModelAPIRevShareDollars_t28d
    , sum(FoundationModelAPIRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as FoundationModelAPIRevShareDollars_t91d
    -- FoundationModelTrainingRevShareDollars
    , FoundationModelTrainingRevShareDollars
    , SUM(FoundationModelTrainingRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as FoundationModelTrainingRevShareDollarsQTD
    , SUM(FoundationModelTrainingRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as FoundationModelTrainingRevShareDollarsMTD
    , sum(FoundationModelTrainingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as FoundationModelTrainingRevShareDollars_t7d
    , sum(FoundationModelTrainingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as FoundationModelTrainingRevShareDollars_t28d
    , sum(FoundationModelTrainingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as FoundationModelTrainingRevShareDollars_t91d
    -- VectorSearchRevShareDollars
    , VectorSearchRevShareDollars
    , SUM(VectorSearchRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as VectorSearchRevShareDollarsQTD
    , SUM(VectorSearchRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as VectorSearchRevShareDollarsMTD
    , sum(VectorSearchRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as VectorSearchRevShareDollars_t7d
    , sum(VectorSearchRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as VectorSearchRevShareDollars_t28d
    , sum(VectorSearchRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as VectorSearchRevShareDollars_t91d
    -- VectorSearchIngestionRevShareDollars
    , VectorSearchIngestionRevShareDollars
    , SUM(VectorSearchIngestionRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as VectorSearchIngestionRevShareDollarsQTD
    , SUM(VectorSearchIngestionRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as VectorSearchIngestionRevShareDollarsMTD
    , sum(VectorSearchIngestionRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as VectorSearchIngestionRevShareDollars_t7d
    , sum(VectorSearchIngestionRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as VectorSearchIngestionRevShareDollars_t28d
    , sum(VectorSearchIngestionRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as VectorSearchIngestionRevShareDollars_t91d
    -- VectorSearchServingRevShareDollars
    , VectorSearchServingRevShareDollars
    , SUM(VectorSearchServingRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as VectorSearchServingRevShareDollarsQTD
    , SUM(VectorSearchServingRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as VectorSearchServingRevShareDollarsMTD
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as VectorSearchServingRevShareDollars_t7d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as VectorSearchServingRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as VectorSearchServingRevShareDollars_t91d
    -- MosaicHeroRevShareDollars
    , MosaicHeroRevShareDollars
    , SUM(MosaicHeroRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as MosaicHeroRevShareDollarsQTD
    , SUM(MosaicHeroRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as MosaicHeroRevShareDollarsMTD
    , sum(MosaicHeroRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as MosaicHeroRevShareDollars_t7d
    , sum(MosaicHeroRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as MosaicHeroRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as MosaicHeroRevShareDollars_t91d

--MosaicReservedTrainingRevShareDollars
    , MosaicReservedTrainingRevShareDollars
    , SUM(MosaicReservedTrainingRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as MosaicReservedTrainingRevShareDollarsQTD
    , SUM(MosaicReservedTrainingRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as MosaicReservedTrainingRevShareDollarsMTD
    , sum(MosaicReservedTrainingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as MosaicReservedTrainingRevShareDollars_t7d
    , sum(MosaicReservedTrainingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as MosaicReservedTrainingRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as MosaicReservedTrainingRevShareDollars_t91d
    -- MosaicOnDemandTrainingRevShareDollars
    , MosaicOnDemandTrainingRevShareDollars
    , SUM(MosaicOnDemandTrainingRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as MosaicOnDemandTrainingRevShareDollarsQTD
    , SUM(MosaicOnDemandTrainingRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as MosaicOnDemandTrainingRevShareDollarsMTD
    , sum(MosaicOnDemandTrainingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as MosaicOnDemandTrainingRevShareDollars_t7d
    , sum(MosaicOnDemandTrainingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as MosaicOnDemandTrainingRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as MosaicOnDemandTrainingRevShareDollars_t91d
    --MosaicRevShareDollars
    , MosaicRevShareDollars
    , SUM(MosaicRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as MosaicRevShareDollarsQTD
    , SUM(MosaicRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as MosaicRevShareDollarsMTD
    , sum(MosaicRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as MosaicRevShareDollars_t7d
    , sum(MosaicRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as MosaicRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as MosaicRevShareDollars_t91d
    -- GenAIRevShareDollars
    , GenAIRevShareDollars
    , SUM(GenAIRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as GenAIRevShareDollarsQTD
    , SUM(GenAIRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as GenAIRevShareDollarsMTD
    , sum(GenAIRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as GenAIRevShareDollars_t7d
    , sum(GenAIRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as GenAIRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as GenAIRevShareDollars_t91d
    --LakeflowRevShareDollars
    , LakeflowRevShareDollars
    , SUM(LakeflowRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as LakeflowRevShareDollarsQTD
    , SUM(LakeflowRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as LakeflowRevShareDollarsMTD
    , sum(LakeflowRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as LakeflowRevShareDollars_t7d
    , sum(LakeflowRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as LakeflowRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as LakeflowRevShareDollars_t91d
    -- LakeflowPipelineRevShareDollars
    , LakeflowPipelineRevShareDollars
    , SUM(LakeflowPipelineRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as LakeflowPipelineRevShareDollarsQTD
    , SUM(LakeflowPipelineRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as LakeflowPipelineRevShareDollarsMTD
    , sum(LakeflowPipelineRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as LakeflowPipelineRevShareDollars_t7d
    , sum(LakeflowPipelineRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as LakeflowPipelineRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as LakeflowPipelineRevShareDollars_t91d
    -- LakeflowConnectRevShareDollars
    , LakeflowConnectRevShareDollars
    , SUM(LakeflowConnectRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as LakeflowConnectRevShareDollarsQTD
    , SUM(LakeflowConnectRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as LakeflowConnectRevShareDollarsMTD
    , sum(LakeflowConnectRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as LakeflowConnectRevShareDollars_t7d
    , sum(LakeflowConnectRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as LakeflowConnectRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as LakeflowConnectRevShareDollars_t91d
    --BatchInferenceModelRevShareDollars
    , BatchInferenceModelRevShareDollars
    , SUM(BatchInferenceModelRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as BatchInferenceModelRevShareDollarsQTD
    , SUM(BatchInferenceModelRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as BatchInferenceModelRevShareDollarsMTD
    , sum(BatchInferenceModelRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as BatchInferenceModelRevShareDollars_t7d
    , sum(BatchInferenceModelRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as BatchInferenceModelRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as BatchInferenceModelRevShareDollars_t91d
    --AgentFrameworkRevShareDollars
    , AgentFrameworkRevShareDollars
    , SUM(AgentFrameworkRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as AgentFrameworkRevShareDollarsQTD
    , SUM(AgentFrameworkRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as AgentFrameworkRevShareDollarsMTD
    , sum(AgentFrameworkRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as AgentFrameworkRevShareDollars_t7d
    , sum(AgentFrameworkRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as AgentFrameworkRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as AgentFrameworkRevShareDollars_t91d
    --VectorSearchStorageRevShareDollars
    , VectorSearchStorageRevShareDollars
    , SUM(VectorSearchStorageRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as VectorSearchStorageRevShareDollarsQTD
    , SUM(VectorSearchStorageRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as VectorSearchStorageRevShareDollarsMTD
    , sum(VectorSearchStorageRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as VectorSearchStorageRevShareDollars_t7d
    , sum(VectorSearchStorageRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as VectorSearchStorageRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as VectorSearchStorageRevShareDollars_t91d
    --FY26AIRevShareDollars
    , FY26AIRevShareDollars
    , SUM(FY26AIRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as FY26AIRevShareDollarsQTD
    , SUM(FY26AIRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as FY26AIRevShareDollarsMTD
    , sum(FY26AIRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as FY26AIRevShareDollars_t7d
    , sum(FY26AIRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as FY26AIRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as FY26AIRevShareDollars_t91d
    --FinetuningRevShareDollars
    , FinetuningRevShareDollars
    , SUM(FinetuningRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as FinetuningRevShareDollarsQTD
    , SUM(FinetuningRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as FinetuningRevShareDollarsMTD
    , sum(FinetuningRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as FinetuningRevShareDollars_t7d
    , sum(FinetuningRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as FinetuningRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as FinetuningRevShareDollars_t91d
    --AIRuntimeRevShareDollars
    , AIRuntimeRevShareDollars
    , SUM(AIRuntimeRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as AIRuntimeRevShareDollarsQTD
    , SUM(AIRuntimeRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as AIRuntimeRevShareDollarsMTD
    , sum(AIRuntimeRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as AIRuntimeRevShareDollars_t7d
    , sum(AIRuntimeRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as AIRuntimeRevShareDollar_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as AIRuntimeRevShareDollar_t91d
    --ModelServingFmApiRevShareDollars
    , ModelServingFmApiRevShareDollars
    , SUM(ModelServingFmApiRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as ModelServingFmApiRevShareDollarsQTD
    , SUM(ModelServingFmApiRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as ModelServingFmApiRevShareDollarsMTD
    , sum(ModelServingFmApiRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as ModelServingFmApiRevShareDollars_t7d
    , sum(ModelServingFmApiRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as ModelServingFmApiRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as ModelServingFmApiRevShareDollars_t91d
    --AgentEvalsRevShareDollars
    , AgentEvalsRevShareDollars
    , SUM(AgentEvalsRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as AgentEvalsRevShareDollarsQTD
    , SUM(AgentEvalsRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as AgentEvalsRevShareDollarsMTD
    , sum(AgentEvalsRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as AgentEvalsRevShareDollars_t7d
    , sum(AgentEvalsRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as AgentEvalsRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as AgentEvalsRevShareDollars_t91d
    --AgentEvalsSyntheticDataRevShareDollars
    , AgentEvalsSyntheticDataRevShareDollars
    , SUM(AgentEvalsSyntheticDataRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as AgentEvalsSyntheticDataRevShareDollarsQTD
    , SUM(AgentEvalsSyntheticDataRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as AgentEvalsSyntheticDataRevShareDollarsMTD
    , sum(AgentEvalsSyntheticDataRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as AgentEvalsSyntheticDataRevShareDollars_t7d
    , sum(AgentEvalsSyntheticDataRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as AgentEvalsSyntheticDataRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as AgentEvalsSyntheticDataRevShareDollars_t91d
    --LakehouseMonitoringRevShareDollars
    , LakehouseMonitoringRevShareDollars
    , SUM(LakehouseMonitoringRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as LakehouseMonitoringRevShareDollarsQTD
    , SUM(LakehouseMonitoringRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as LakehouseMonitoringRevShareDollarsMTD
    , sum(LakehouseMonitoringRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as LakehouseMonitoringRevShareDollars_t7d
    , sum(LakehouseMonitoringRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as LakehouseMonitoringRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as LakehouseMonitoringRevShareDollars_t91d
    --FmMixtral87bInstructRevShareDollars
    , FmMixtral87bInstructRevShareDollars
    , SUM(FmMixtral87bInstructRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as FmMixtral87bInstructRevShareDollarsQTD
    , SUM(FmMixtral87bInstructRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as FmMixtral87bInstructRevShareDollarsMTD
    , sum(FmMixtral87bInstructRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as FmMixtral87bInstructRevShareDollars_t7d
    , sum(FmMixtral87bInstructRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as FmMixtral87bInstructRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as FmMixtral87bInstructRevShareDollars_t91d
    --FmLlama270bChatRevShareDollars
    , FmLlama270bChatRevShareDollars
    , SUM(FmLlama270bChatRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as FmLlama270bChatRevShareDollarsQTD
    , SUM(FmLlama270bChatRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as FmLlama270bChatRevShareDollarsMTD
    , sum(FmLlama270bChatRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as FmLlama270bChatRevShareDollars_t7d
    , sum(FmLlama270bChatRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as FmLlama270bChatRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as FmLlama270bChatRevShareDollars_t91d
    --FmMpt30bInstructRevShareDollars
    , FmMpt30bInstructRevShareDollars
    , SUM(FmMpt30bInstructRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as FmMpt30bInstructRevShareDollarsQTD
    , SUM(FmMpt30bInstructRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as FmMpt30bInstructRevShareDollarsMTD
    , sum(FmMpt30bInstructRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as FmMpt30bInstructRevShareDollars_t7d
    , sum(FmMpt30bInstructRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as FmMpt30bInstructRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as FmMpt30bInstructRevShareDollars_t91d
    --FmMpt7bInstructRevShareDollars
    , FmMpt7bInstructRevShareDollars
    , SUM(FmMpt7bInstructRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as FmMpt7bInstructRevShareDollarsQTD
    , SUM(FmMpt7bInstructRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as FmMpt7bInstructRevShareDollarsMTD
    , sum(FmMpt7bInstructRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as FmMpt7bInstructRevShareDollars_t7d
    , sum(FmMpt7bInstructRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as FmMpt7bInstructRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as FmMpt7bInstructRevShareDollars_t91d
    --DatabricksDbrxChatRevShareDollars
    , DatabricksDbrxChatRevShareDollars
    , SUM(DatabricksDbrxChatRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as DatabricksDbrxChatRevShareDollarsQTD
    , SUM(DatabricksDbrxChatRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as DatabricksDbrxChatRevShareDollarsMTD
    , sum(DatabricksDbrxChatRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as DatabricksDbrxChatRevShareDollars_t7d
    , sum(DatabricksDbrxChatRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as DatabricksDbrxChatRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as DatabricksDbrxChatRevShareDollars_t91d
    --FmBgeLargeEnRevShareDollars
    , FmBgeLargeEnRevShareDollars
    , SUM(FmBgeLargeEnRevShareDollars) OVER (PARTITION BY accountId, d.fiscal_quarter_end_date ORDER BY usage_date) as FmBgeLargeEnRevShareDollarsQTD
    , SUM(FmBgeLargeEnRevShareDollars) OVER (PARTITION BY accountId, d.month_end_date ORDER BY usage_date) as FmBgeLargeEnRevShareDollarsMTD
    , sum(FmBgeLargeEnRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 6 PRECEDING AND CURRENT ROW
      ) as FmBgeLargeEnRevShareDollars_t7d
    , sum(FmBgeLargeEnRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 27 PRECEDING AND CURRENT ROW
      ) as FmBgeLargeEnRevShareDollars_t28d
    , sum(VectorSearchServingRevShareDollars) OVER (
        PARTITION BY accountID
        order by usage_date desc
        rows between 90 PRECEDING AND CURRENT ROW
      ) as FmBgeLargeEnRevShareDollars_t91d
  from pum_base t1
  join main.it_core_dim.bi_dates d on d.date = usage_date
)
select
m.*,
e.* except(accountId, usage_date, fiscal_quarter_end_date, month_end_date),
d.* except(accountId, usage_date, fiscal_quarter_end_date, month_end_date),
p.* except(accountId, usage_date, fiscal_quarter_end_date, month_end_date),
GenAIRevShareDollars - MosaicRevShareDollars as GenAINonMCTRevShareDollars,
GenAIRevShareDollarsQTD - MosaicRevShareDollarsQTD as GenAINonMCTRevShareDollarQTD,
GenAIRevShareDollarsMTD - MosaicRevShareDollarsMTD as GenAINonMCTRevShareDollarMTD,
GenAIRevShareDollars_t7d - MosaicRevShareDollars_t7d as GenAINonMCTRevShareDollars_t7d,
GenAIRevShareDollars_t28d  - MosaicRevShareDollars_t28d as GenAINonMCTRevShareDollars_t28d,
GenAIRevShareDollars_t91d - MosaicRevShareDollars_t91d as GenAINonMCTRevShareDollars_t91d,
max_dates.max_gen_ai_usage_date == m.usage_date as GenAILatestDate,
max_dates.max_mct_usage_date == m.usage_date as MosaicLatestDate,
max_dates.max_lakeflow_connect_usage_date == m.usage_date as LakeflowConnectLatestDate,
max_dates.max_lakeflow_pipeline_usage_date == m.usage_date as LakeflowPipelineLatestDate,
max_dates.max_fy26_ai_usage_date == m.usage_date as FY26AILatestDate,
max_dates.max_uc_usage_date == m.usage_date as UCLatestDate,
max_dates.max_dbsql_usage_date == m.usage_date as DBSQLLatestDate
from trailing_dataset_main m
left join etl_workflow_dollars e
on m.accountId = e.accountId and m.usage_date = e.usage_date and m.fiscal_quarter_end_date = e.fiscal_quarter_end_date and m.month_end_date = e.month_end_date
left join dbsql_trailing d on m.accountId = d.accountId and m.usage_date = d.usage_date and m.fiscal_quarter_end_date = d.fiscal_quarter_end_date and m.month_end_date = d.month_end_date
left join pum_trailing p on m.accountId = p.accountId and m.usage_date = p.usage_date and m.fiscal_quarter_end_date = p.fiscal_quarter_end_date and m.month_end_date = p.month_end_date
cross join max_dates
""")

# COMMAND ----------

trailing_product_health_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable("main.gtm_consumption_silver.consumption_trailing_product_health")
