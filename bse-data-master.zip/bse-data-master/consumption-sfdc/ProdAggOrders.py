# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

# backup = spark.read.format("delta").load("/mnt/bse-dev/backup_aggorders")
# backup.createOrReplaceTempView("backup")

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  db_name = "users.prabhakar_guha"
elif environment == 'test':
  db_name = "integration.it_consumption_silver"
else:
  db_name = "main.it_consumption_silver"


# COMMAND ----------

BACKUP_AGGORDERS_LOCATION = "/Volumes/integration/it_consumption_silver/intermediate_files/backup_aggorders"
USAGEC_AGGORDER_DAILY = "main.it_consumption_silver.usagec_aggorder_daily"
BI_AGGORDERS = db_name + ".bi_aggorders"
BI_AGGORDERS_LOCATION = "/Volumes/integration/it_consumption_silver/intermediate_files/bi_aggorders"
BI_AGGORDERS_PVC_LOCATION = "/Volumes/integration/it_consumption_silver/intermediate_files/bi_aggorders_pvc"
FINANCE_AWS_CONTRACTS = "main.fin_live_gold.aws_contracts"
FINANCE_USAGE_PRICING_DBU_DOLLARS = "main.it_lakehouse.dbu_dollars_prior_to_2021_vw"
FINANCE_USAGE_PRICING_PUM = "main.fin_live_gold.paid_usage_metering"
FINANCE_MSFT_RI = "main.fin_live_gold.msft_ri"
FINANCE_PUBSEC_USAGE = "main.fin_live_gold.pubsec_usage"
FINANCE_PVC_USAGE = "main.fin_live_gold.pvc_usage"
BI_DATES = "main.it_core_dim.bi_dates"
PARALLEL_CONTRACTS_CLEAN = "/Volumes/integration/it_consumption_silver/intermediate_files/parallel_contracts_clean"
BACKUP_BI_AGGORDERS_PVC = "/Volumes/integration/it_consumption_silver/intermediate_files/backup_bi_aggorders_pvc"
SOURCE_SWITCH_DATE= "2021-01-01"

# COMMAND ----------

backup_orders = spark.sql(f"select * from {BI_AGGORDERS}")
backup_orders.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(BACKUP_AGGORDERS_LOCATION)
print(backup_orders.count())

# COMMAND ----------

# dedup = spark.sql("select * from bdw.bi_aggorders").dropDuplicates()
# dedup.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/bi_aggorders")

# COMMAND ----------

burstCheck = spark.sql(f"""
with usageBurst (
select  accountId, 
        aggOrder, 
        min(usage_date) currentUsageBurstDate,
        min(pctBurn) pctBurn
from {USAGEC_AGGORDER_DAILY}
where aggOrder not like 'MTM%'
and platform = 'azure'
and pctBurn > 99.75
and usage_date < date_sub(current_date(), 1)
--and actualBurstDate is not null
group by 1,2
),

azureburst (
select u.currentUsageBurstDate usageBurstDate,
       agg.AggOrder,
       agg.sfdcAccountID,
       agg.sfdcAccountName,
       agg.Platform,
       agg.Scope,
       agg.SubscriptionID,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit,
       agg.dbuCustPriceDiscount,
       agg.orderId
from {BI_AGGORDERS} agg
left join usageBurst u on agg.sfdcAccountId = u.accountId and agg.aggOrder = u.aggOrder
where u.currentUsageBurstDate < agg.endDate
and agg.usageBurstDate is null
order by agg.sfdcAccountId, startDate
)

select *
from azureburst
""")

# COMMAND ----------

newaggorders = spark.sql(f"""
with usageBurst (
select  accountId, 
        aggOrder, 
        min(usage_date) currentUsageBurstDate,
        min(pctBurn) pctBurn
from {USAGEC_AGGORDER_DAILY}
where aggOrder not like 'MTM%'
and platform = 'azure'
and pctBurn > 99.75
and usage_date < current_date()
--and actualBurstDate is not null
group by 1,2
),

azureburst (
select u.currentUsageBurstDate usageBurstDate,
       agg.AggOrder,
       agg.sfdcAccountID,
       agg.sfdcAccountName,
       agg.Platform,
       agg.Scope,
       agg.SubscriptionID,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit,
       agg.dbuCustPriceDiscount,
       agg.orderId
from {BI_AGGORDERS} agg
left join usageBurst u on agg.sfdcAccountId = u.accountId and agg.aggOrder = u.aggOrder
where u.currentUsageBurstDate < agg.endDate
and agg.usageBurstDate is null
order by agg.sfdcAccountId, startDate
),

aggorderswithoutazureburst (

select agg.*
from {BI_AGGORDERS} agg
left join azureburst az on agg.aggorder = az.aggorder
where az.aggorder is null
),

unionedorders (
select *
from aggorderswithoutazureburst

union

select *
from azureburst
)

select *
from unionedorders
order by sfdcAccountId, startDate
""")
newaggorders.createOrReplaceTempView("newaggorders")

# COMMAND ----------

burstCheckCount = burstCheck.count()
if burstCheckCount > 0:
  display(burstCheck)

# COMMAND ----------

if burstCheckCount > 0:
  print("running the burst updates :", burstCheckCount)
  newaggorders.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(BI_AGGORDERS)

# COMMAND ----------

gcpOrders = spark.sql(f"""
with gcpCommit (
select null usageBurstDate,
       concat("GCP-", concat(coalesce(sales_order, "noOrder"), concat("-",cast(order_line_start_date as date)))) AggOrder,
       coalesce(sfdc_account_id, 'noSFDCAccount') sfdcAccountID,
       coalesce(sfdc_account_name, 'noSFDCAccount') sfdcAccountName, 
       'gcp' platform,
       'gcp-defined' scope,
       coalesce(subscription_id, 'noSubscriptionID') SubscriptionID, 
       cast(order_line_start_date as date) startDate,
       
       case  when datediff(order_effective_end_date, order_line_end_date) > 360 then cast(order_line_end_date as date)
             when order_line_status = 'Superseded' then cast(order_effective_end_date as date)
             when order_line_status = 'Completed' then cast(order_effective_end_date as date)
             when overlap_date is not NULL then cast(overlap_date as date)
             else cast(order_effective_end_date as date)
       end as endDate,
       coalesce(gross_amount, net_amount, 0) cloudPartnerPurchase,
       coalesce(gross_amount, net_amount, 0) ActualPartnerCommit,
       coalesce(gross_amount, net_amount, 0) DBShareCommit,
       cast(0 as double) dbuCustPriceDiscount,
       sales_order orderId
from {FINANCE_AWS_CONTRACTS}
where line_item = "Workload Commitment"
and platform_type = 'GCP'
),

gcpMTM (
select null usageBurstDate,
       concat("MTMGCP",coalesce(sfdc_account_id, 'noSFDCAccountID'))  AggOrder,
       coalesce(sfdc_account_id, 'noSFDCAccountID') sfdcAccountID,
       coalesce(sfdc_account_name, 'noSFDCAccountName') sfdcAccountName, 
       'gcp' Platform,
       'shared' Scope,
       'MTMSubscriptionID' SubscriptionID, 
       min(date) startDate,
       date_add(min(date), (365*25)) endDate,
       0 cloudPartnerPurchase,
       0 ActualPartnerCommit,
       0 DBShareCommit,
       cast(0 as double) dbuCustPriceDiscount,
       concat("MTMAWS",coalesce(sfdc_account_id, 'noSFDCAccountID')) orderId
from {FINANCE_USAGE_PRICING_DBU_DOLLARS}
where platform = 'gcp'
and date < '{SOURCE_SWITCH_DATE}'
group by sfdc_account_id, sfdc_account_name

UNION 

select null usageBurstDate,
       concat("MTMGCP",coalesce(sfdc_account_id, 'noSFDCAccountID'))  AggOrder,
       coalesce(sfdc_account_id, 'noSFDCAccountID') sfdcAccountID,
       coalesce(sfdc_account_name, 'noSFDCAccountName') sfdcAccountName, 
       'gcp' Platform,
       'shared' Scope,
       'MTMSubscriptionID' SubscriptionID, 
       min(date) startDate,
       date_add(min(date), (365*25)) endDate,
       0 cloudPartnerPurchase,
       0 ActualPartnerCommit,
       0 DBShareCommit,
       cast(0 as double) dbuCustPriceDiscount,
       concat("MTMAWS",coalesce(sfdc_account_id, 'noSFDCAccountID')) orderId
from {FINANCE_USAGE_PRICING_PUM}
where platform = 'gcp'
and date >= '{SOURCE_SWITCH_DATE}'
group by sfdc_account_id, sfdc_account_name
),

gcpOrders (
select *
from gcpCommit
union
select *
from gcpMTM
)

select *
from gcpOrders
order by sfdcAccountID
""")

gcpOrders = gcpOrders.withColumn("orderId", array(col("orderId")))

gcpOrders.createOrReplaceTempView("gcpOrders")
#gcpOrders.count()

# COMMAND ----------

new_gcp = spark.sql(f"""
select n.*
from gcpOrders n
left join {BI_AGGORDERS} agg on n.sfdcAccountId = agg.sfdcAccountId and n.AggOrder = agg.AggOrder and n.platform = agg.platform
where agg.AggOrder is null
and n.platform = 'gcp'
""")
display(new_gcp)

# COMMAND ----------

if new_gcp.count() > 0:
  print("running updates for new GCP orders ")
  new_gcp.write.option("overwriteSchema", "true").format("delta").mode("append").saveAsTable(BI_AGGORDERS)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window


sharedAzureQuery = f"""
select concat("SharedAzure-", concat(coalesce(sfdc_account_id, "noSFDCAccount"), concat("-",cast(start_date as date)))) AggOrder,
       sfdc_account_id sfdcAccountID,
       sfdc_account_name sfdcAccountName,
       'azure' Platform,
       'Shared' Scope,
       first(azure_sub_id) SubscriptionID,
       cast(start_date as date) startDate,
       max(cast(coalesce(effective_end_date,end_date) as date)) endDate,
       sum(msft_commitment) cloudPartnerPurchase,
       sum(purchase_price_msft) ActualPartnerCommit,
       sum(purchase_price_databricks) DBShareCommit,
       round(1 - (sum(purchase_price_msft)/sum(msft_commitment)),4) dbuCustPriceDiscount,
       collect_set(reservation_order_id) orderId
from {FINANCE_MSFT_RI}
where applied_scope_type = 'Shared'
and include_flag = 1
group by 1,2,3,4,5,7
"""
sharedAzureDF = spark.sql(sharedAzureQuery)

singleAzureQueryNew = f"""
select concat("SingleAzure-", concat(coalesce(azure_sub_id, "noSFDCAccount"), concat("-",cast(start_date as date)))) AggOrder,
       sfdc_account_id sfdcAccountID,
       sfdc_account_name sfdcAccountName,
       'azure' Platform,
       'Single' Scope,
       azure_sub_id SubscriptionID,
       cast(start_date as date) startDate,
       max(cast(coalesce(effective_end_date,end_date) as date)) endDate,
       sum(msft_commitment) cloudPartnerPurchase,
       sum(purchase_price_msft) ActualPartnerCommit,
       sum(purchase_price_databricks) DBShareCommit,
       round(1 - (sum(purchase_price_msft)/sum(msft_commitment)),4) dbuCustPriceDiscount,
       collect_set(reservation_order_id) orderId
from {FINANCE_MSFT_RI}
where applied_scope_type = 'Single'
and include_flag = 1
group by 1,2,3,4,5,6,7
"""

singleAzureNew = spark.sql(singleAzureQueryNew)

allAzureCommitDF = sharedAzureDF.union(singleAzureNew)

azurePAYGquery = f"""
select AggOrder,
       sfdcAccountID,
       sfdcAccountName, 
       Platform,
       Scope,
       SubscriptionID, 
       min(startDate) startDate,
       min(endDate) endDate,
       cloudPartnerPurchase,
       ActualPartnerCommit,
       DBShareCommit,
       dbuCustPriceDiscount,
       orderId
from (
select concat("MTMAzure",coalesce(sfdc_account_id, 'noSFDCAccountID'))  AggOrder,
       coalesce(sfdc_account_id, 'noSFDCAccountID') sfdcAccountID,
       coalesce(sfdc_account_name, 'noSFDCAccountName') sfdcAccountName, 
       'azure' platform,
       'shared' Scope,
       'MTMSubscriptionID' SubscriptionID, 
       min(date) startDate,
       date_add(min(date), (365*40)) endDate,
       0 cloudPartnerPurchase,
       0 ActualPartnerCommit,
       0 DBShareCommit,
       0 dbuCustPriceDiscount,
       collect_set(concat("MTMAzure",coalesce(sfdc_account_id, 'noSFDCAccountID'))) orderId
from {FINANCE_USAGE_PRICING_DBU_DOLLARS}
where date < '{SOURCE_SWITCH_DATE}'
group by sfdc_account_id, sfdc_account_name

UNION 

select concat("MTMAzure",coalesce(sfdc_account_id, 'noSFDCAccountID'))  AggOrder,
       coalesce(sfdc_account_id, 'noSFDCAccountID') sfdcAccountID,
       coalesce(sfdc_account_name, 'noSFDCAccountName') sfdcAccountName, 
       'azure' platform,
       'shared' Scope,
       'MTMSubscriptionID' SubscriptionID, 
       min(date) startDate,
       date_add(min(date), (365*40)) endDate,
       0 cloudPartnerPurchase,
       0 ActualPartnerCommit,
       0 DBShareCommit,
       0 dbuCustPriceDiscount,
       collect_set(concat("MTMAzure",coalesce(sfdc_account_id, 'noSFDCAccountID'))) orderId
from {FINANCE_USAGE_PRICING_PUM}
where date >= '{SOURCE_SWITCH_DATE}'
group by sfdc_account_id, sfdc_account_name
)
group by all 
"""

azurePAYGdf = spark.sql(azurePAYGquery)
azurePAYGdf = azurePAYGdf.withColumn("cloudPartnerPurchase", col("cloudPartnerPurchase").cast("double"))\
                         .withColumn("ActualPartnerCommit", col("ActualPartnerCommit").cast("double"))\
                         .withColumn("DBShareCommit", col("DBShareCommit").cast("double"))\
                         .withColumn("dbuCustPriceDiscount", col("dbuCustPriceDiscount").cast("double"))

allAzureCommitDF = allAzureCommitDF.union(azurePAYGdf)

# COMMAND ----------

awsPAYGQuery = f"""
select AggOrder,
       sfdcAccountID,
       sfdcAccountName, 
       Platform,
       Scope,
       SubscriptionID, 
       min(startDate) startDate,
       min(endDate) endDate,
       cloudPartnerPurchase,
       ActualPartnerCommit,
       DBShareCommit,
       dbuCustPriceDiscount,
       orderId
from (
select concat("MTMAWS",coalesce(sfdc_account_id, 'noSFDCAccountID'))  AggOrder,
       coalesce(sfdc_account_id, 'noSFDCAccountID') sfdcAccountID,
       coalesce(sfdc_account_name, 'noSFDCAccountName') sfdcAccountName, 
       'aws' Platform,
       'shared' Scope,
       'MTMSubscriptionID' SubscriptionID, 
       min(date) startDate,
       date_add(min(date), (365*40)) endDate,
       0 cloudPartnerPurchase,
       0 ActualPartnerCommit,
       0 DBShareCommit,
       0 dbuCustPriceDiscount,
       collect_set(concat("MTMAWS",coalesce(sfdc_account_id, 'noSFDCAccountID'))) orderId
from {FINANCE_USAGE_PRICING_DBU_DOLLARS}
where date < '{SOURCE_SWITCH_DATE}'
group by sfdc_account_id, sfdc_account_name

UNION 

select concat("MTMAWS",coalesce(sfdc_account_id, 'noSFDCAccountID'))  AggOrder,
       coalesce(sfdc_account_id, 'noSFDCAccountID') sfdcAccountID,
       coalesce(sfdc_account_name, 'noSFDCAccountName') sfdcAccountName, 
       'aws' Platform,
       'shared' Scope,
       'MTMSubscriptionID' SubscriptionID, 
       min(date) startDate,
       date_add(min(date), (365*40)) endDate,
       0 cloudPartnerPurchase,
       0 ActualPartnerCommit,
       0 DBShareCommit,
       0 dbuCustPriceDiscount,
       collect_set(concat("MTMAWS",coalesce(sfdc_account_id, 'noSFDCAccountID'))) orderId
from {FINANCE_USAGE_PRICING_PUM}
where date >= '{SOURCE_SWITCH_DATE}'
group by sfdc_account_id, sfdc_account_name
)
group by all
"""
awsPAYGdf = spark.sql(awsPAYGQuery)

awsPAYGdf = awsPAYGdf.withColumn("cloudPartnerPurchase", col("cloudPartnerPurchase").cast("double"))\
                     .withColumn("ActualPartnerCommit", col("ActualPartnerCommit").cast("double"))\
                     .withColumn("DBShareCommit", col("DBShareCommit").cast("double"))\
                     .withColumn("dbuCustPriceDiscount", col("dbuCustPriceDiscount").cast("double"))

awsCommitQuery = f"""
select concat("AWS-", concat(coalesce(sales_order, "noOrder"), concat("-",cast(order_line_start_date as date)))) AggOrder,
       coalesce(sfdc_account_id, 'noSFDCAccount') sfdcAccountID,
       coalesce(sfdc_account_name, 'noSFDCAccount') sfdcAccountName, 
       'aws' Platform,
       'aws-defined' Scope,
       coalesce(subscription_id, 'noSubscriptionID') SubscriptionID, 
       cast(order_line_start_date as date) startDate,
       
       case  when datediff(order_effective_end_date, order_line_end_date) > 360 then cast(order_line_end_date as date)
             when order_line_status = 'Superseded' then cast(order_effective_end_date as date)
             when order_line_status = 'Completed' then cast(order_effective_end_date as date)
             when overlap_date is not NULL then cast(overlap_date as date)
             else cast(order_effective_end_date as date)
       end as endDate,
       coalesce(gross_amount, net_amount, 0) cloudPartnerPurchase,
       coalesce(gross_amount, net_amount, 0) ActualPartnerCommit,
       coalesce(gross_amount, net_amount, 0) DBShareCommit,
       0 dbuCustPriceDiscount,
       sales_order orderId
from {FINANCE_AWS_CONTRACTS}
where line_item = "Workload Commitment"
--and order_line_start_date <= order_effective_end_date
"""
awsCommitDF = spark.sql(awsCommitQuery)
awsCommitDF= awsCommitDF.withColumn("orderId", array(col("orderId")))
awsCommitDF = awsCommitDF.withColumn("cloudPartnerPurchase", col("cloudPartnerPurchase").cast("double"))\
                         .withColumn("ActualPartnerCommit", col("ActualPartnerCommit").cast("double"))\
                         .withColumn("DBShareCommit", col("DBShareCommit").cast("double"))\
                         .withColumn("dbuCustPriceDiscount", col("dbuCustPriceDiscount").cast("double"))

awsOrders = awsCommitDF.union(awsPAYGdf)

# COMMAND ----------

column_names = ['sfdcAccountID', 'sfdcAccountName', 'SubscriptionID', 'cloudPartnerPurchase', 'ActualPartnerCommit', 'DBShareCommit', 'dbuCustPriceDiscount']

# COMMAND ----------

def set_df_columns_nullable(df, column_list, nullable=True):
    for struct_field in df.schema:
        if struct_field.name in column_list:
            struct_field.nullable = nullable
    df_mod = spark.createDataFrame(df.rdd, df.schema)
    return df_mod

# COMMAND ----------

awsOrders = set_df_columns_nullable(awsOrders,column_names, True)

# COMMAND ----------

newOrders = allAzureCommitDF.union(awsOrders)
print(newOrders.count())
newOrders.createOrReplaceTempView('neworders')

# COMMAND ----------

parallel_contracts = spark.read.format("delta").load(PARALLEL_CONTRACTS_CLEAN)
parallel_contracts= parallel_contracts.withColumn("platform", lit("aws"))
parallel_contracts.createOrReplaceTempView("parallel_contracts")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- with base (
# MAGIC -- select n.aggorder,
# MAGIC --        n.DBShareCommit,
# MAGIC --        p.RevShareCommit,
# MAGIC --        case when n.DBShareCommit = p.RevShareCommit then true
# MAGIC --             else false
# MAGIC --        end as commitFlag     
# MAGIC -- from neworders n
# MAGIC -- join parallel_contracts p on n.sfdcAccountId = p.sfdcAccountId and n.aggorder = p.aggorder
# MAGIC -- where p.startDate >= "2021-01-01"
# MAGIC -- and abs(n.DBShareCommit - p.RevShareCommit) > 1
# MAGIC -- ),
# MAGIC
# MAGIC -- updates (
# MAGIC -- select aggOrder, DBShareCommit
# MAGIC -- from base
# MAGIC -- where commitFlag = false
# MAGIC -- )
# MAGIC
# MAGIC -- select *
# MAGIC -- from updates
# MAGIC
# MAGIC -- MERGE INTO parallel_contracts orig
# MAGIC -- USING updates up
# MAGIC -- ON orig.aggOrder = up.aggOrder
# MAGIC -- WHEN MATCHED THEN
# MAGIC --   UPDATE SET orig.ListCommit = up.DBShareCommit, orig.DiscountedCommit = up.DBShareCommit, orig.RevShareCommit = up.DBShareCommit

# COMMAND ----------

parallel_new_aws = spark.sql(f"""
with pl_contracts (
select distinct sfdcAccountId from parallel_contracts
)
select n.*
from neworders n
left join {BI_AGGORDERS} agg on n.sfdcAccountId = agg.sfdcAccountId and n.AggOrder = agg.AggOrder and n.platform = agg.platform
join pl_contracts pl on n.sfdcAccountId = pl.sfdcAccountId
where agg.AggOrder is null
and n.sfdcAccountID != '0014N00001iGbqKQAS'
and n.platform = 'aws'
""")

parallel_new_aws.createOrReplaceTempView('parallel_new_aws')
parallel_new_aws.count()

# COMMAND ----------

display(parallel_new_aws)

# COMMAND ----------

new_aws = spark.sql(f"""
with pl_contracts (
select distinct sfdcAccountId from parallel_contracts
)
select n.*
from neworders n
left join {BI_AGGORDERS} agg on n.sfdcAccountId = agg.sfdcAccountId and n.AggOrder = agg.AggOrder and n.platform = agg.platform
left join pl_contracts pl on n.sfdcAccountId = pl.sfdcAccountId
where agg.AggOrder is null
and pl.sfdcAccountId is null
and n.sfdcAccountID != '0014N00001iGbqKQAS'
and n.platform = 'aws'
""")

new_azure = spark.sql(f"""
select n.*
from neworders n
left join {BI_AGGORDERS} agg on n.sfdcAccountId = agg.sfdcAccountId and n.AggOrder = agg.AggOrder and n.platform = agg.platform
where agg.AggOrder is null
and n.platform = 'azure'
""")

new_aws_azure_orders = new_aws.union(new_azure)
selectColumns = new_aws_azure_orders.columns
bi_aggorders = spark.sql(f"select * from {BI_AGGORDERS}").select(*selectColumns)
new_bi_aggorders = bi_aggorders.union(new_aws_azure_orders)

# COMMAND ----------

new_aws.createOrReplaceTempView("new_aws")
new_azure.createOrReplaceTempView("new_azure")
newAWSCount = new_aws.count()
newAzureCount = new_azure.count()
print(newAWSCount)
print(newAzureCount)

# COMMAND ----------

# #azure-upsert --where AggOrder not like 'MTM%'
azure_add = spark.sql("""
select   null usageBurstDate,
         *
from new_azure
order by sfdcAccountId, startDate
""")
if newAzureCount > 0:
  print("updating azure ")  
  azure_add.write.option("overwriteSchema", "true").format("delta").mode("append").saveAsTable(BI_AGGORDERS)

# COMMAND ----------

#aws-upsert 0016100000czZodAAE - waiting for parallel contract-workspace mapping
# --sfdcAccountID != '0016100000czZodAAE'
aws_add = spark.sql("""
select   null usageBurstDate,
         *
from new_aws
where aggOrder != "AWS-10160-2020-10-01" 
order by sfdcAccountId, startDate
""")
if newAWSCount > 0:
  print("updating aws ")
  aws_add.write.option("overwriteSchema", "true").format("delta").mode("append").saveAsTable(BI_AGGORDERS)

# COMMAND ----------

# parallel_aws_add = spark.sql("""
# select   null usageBurstDate,
#          *
# from parallel_new_aws
# where sfdcAccountID != '0016100000czZodAAE'
# and AggOrder not like 'MTM%'
# order by sfdcAccountId, startDate
# """)
# parallel_aws_add.write.option("overwriteSchema", "true").format("delta").mode("append").save("/mnt/bse-dev/bi_aggorders")

# COMMAND ----------

spark.sql(f"""

-- -- ****************************MERGE START DATES for MTM*************************  

with checkDates (
select agg.sfdcAccountId,
       n.aggorder newAggOrder, 
       agg.aggorder, 
       n.startDate newStartDate, 
       agg.startDate aggStartDate,       
       
       n.endDate newEndDate, 
       agg.endDate aggEndDate,
       case when n.endDate = agg.endDate then 1
            else 0
       end as endDateFlag,
       case when n.startDate = agg.startDate then 1
            else 0
       end as startDateFlag,       
       n.DBShareCommit newDBShareCommit,
       n.ActualPartnerCommit newActualPartnerCommit,
       n.cloudPartnerPurchase newcloudPartnerPurchase,
       case when n.DBShareCommit = agg.DBShareCommit then 1
            else 0
       end as DBShareCommitFlag       
from {BI_AGGORDERS} agg
join neworders n on agg.sfdcAccountId = n.sfdcAccountId and agg.AggOrder = n.AggOrder and agg.platform = n.platform
--left join pl_contracts pl on n.sfdcAccountId = pl.sfdcAccountId
--where pl.sfdcAccountId is null
--and n.platform = 'aws'
where agg.aggOrder like 'MTM%'
--and agg.startDate > "2020-01-01"
),

updates (
select *
from checkDates
where startDateFlag = 0
and newStartDate < aggStartDate
)

MERGE INTO {BI_AGGORDERS} orig
USING updates up
ON orig.aggOrder = up.aggOrder
WHEN MATCHED THEN
  UPDATE SET orig.startDate = up.newStartDate
""")

# COMMAND ----------

spark.sql(f"""
-- ****************************MERGE EndDATES *************************  

with checkEndDate (
select agg.sfdcAccountId,
       n.aggorder newAggOrder, 
       agg.aggorder, 
       n.endDate newEndDate, 
       agg.endDate aggEndDate,
       case when n.endDate = agg.endDate then 1
            else 0
       end as endDateFlag
from {BI_AGGORDERS} agg
join neworders n on agg.sfdcAccountId = n.sfdcAccountId and agg.AggOrder = n.AggOrder and agg.platform = n.platform and agg.DBShareCommit = n.DBShareCommit
where n.platform = 'aws'
and agg.aggOrder not like 'MTM%'
and agg.startDate > "2020-01-01"
),

updates (
select *
from checkEndDate
where endDateFlag = 0
)

MERGE INTO {BI_AGGORDERS} orig
USING updates up
ON orig.aggOrder = up.aggOrder
WHEN MATCHED THEN
  UPDATE SET orig.endDate = up.newEndDate
""")

# COMMAND ----------


#-- ---*****************************AZURE Commits******************************************
try:
  spark.sql(f""" 
          with 
          checkCommit (
          select agg.sfdcAccountId,
                n.aggorder newAggOrder, 
                agg.aggorder, 
                agg.DBShareCommit,
                agg.endDate,
                n.DBShareCommit newDBShareCommit,
                n.ActualPartnerCommit newActualPartnerCommit,
                n.cloudPartnerPurchase newcloudPartnerPurchase,
                case when n.DBShareCommit = agg.DBShareCommit then 1
                      else 0
                end as DBShareCommitFlag,
                (n.DBShareCommit - agg.DBShareCommit) diff
          from {BI_AGGORDERS} agg
          join neworders n on agg.sfdcAccountId = n.sfdcAccountId and agg.AggOrder = n.AggOrder and agg.platform = n.platform
          where n.platform = 'azure'
          and agg.aggOrder not like 'MTM%'
          and agg.startDate > "2020-01-01"
          ),

        updates (
        select *
        from checkCommit
        where DBShareCommitFlag = 0
        and abs(diff) > 100
        )

        MERGE INTO {BI_AGGORDERS} orig
        USING updates up
        ON orig.aggOrder = up.aggOrder
        WHEN MATCHED THEN
          UPDATE SET orig.DBShareCommit = up.newDBShareCommit, orig.ActualPartnerCommit = up.newActualPartnerCommit, orig.cloudPartnerPurchase = up.newcloudPartnerPurchase
        """)
except Exception:
  print('Merge Error')

# COMMAND ----------

display(spark.sql(f"""
with pl_contracts (
select distinct sfdcAccountId from parallel_contracts
),

checkCommit (
select agg.sfdcAccountId,
       n.aggorder newAggOrder, 
       agg.aggorder, 
       agg.DBShareCommit,
       n.DBShareCommit newDBShareCommit,
       n.ActualPartnerCommit newActualPartnerCommit,
       n.cloudPartnerPurchase newcloudPartnerPurchase,
       case when n.DBShareCommit = agg.DBShareCommit then 1
            else 0
       end as DBShareCommitFlag       
from {BI_AGGORDERS} agg
join neworders n on agg.sfdcAccountId = n.sfdcAccountId and agg.AggOrder = n.AggOrder and agg.platform = n.platform
left join pl_contracts pl on n.sfdcAccountId = pl.sfdcAccountId
where pl.sfdcAccountId is null
and n.platform = 'aws'
and agg.aggOrder not like 'MTMAWS%'
and agg.startDate > "2020-01-01"
),

base (
select count(newAggOrder) over(partition by newAggorder, sfdcAccountId) cnt, * 
from checkCommit
where DBShareCommitFlag = 0
order by aggOrder
)

select *
from base
order by sfdcAccountId, newAggorder
"""))

# COMMAND ----------

spark.sql(f"""
with pl_contracts (
select distinct sfdcAccountId from parallel_contracts
),

checkCommit (
select agg.sfdcAccountId,
       n.aggorder newAggOrder, 
       agg.aggorder, 
       n.DBShareCommit newDBShareCommit,
       n.ActualPartnerCommit newActualPartnerCommit,
       n.cloudPartnerPurchase newcloudPartnerPurchase,
       case when n.DBShareCommit = agg.DBShareCommit then 1
            else 0
       end as DBShareCommitFlag       
from {BI_AGGORDERS} agg
join neworders n on agg.sfdcAccountId = n.sfdcAccountId and agg.AggOrder = n.AggOrder and agg.platform = n.platform
left join pl_contracts pl on n.sfdcAccountId = pl.sfdcAccountId
where pl.sfdcAccountId is null
and n.platform = 'aws'
and agg.aggOrder not like 'MTMAWS%'
and agg.startDate > "2020-01-01"
),

base (
select count(newAggOrder) over(partition by newAggorder, sfdcAccountId) cnt, * 
from checkCommit
where DBShareCommitFlag = 0
order by aggOrder
),

updates (
select *
from base
where cnt = 1
)

MERGE INTO {BI_AGGORDERS} orig
USING updates up
ON orig.aggOrder = up.aggOrder
WHEN MATCHED THEN
  UPDATE SET orig.DBShareCommit = up.newDBShareCommit, orig.ActualPartnerCommit = up.newActualPartnerCommit, orig.cloudPartnerPurchase = up.newcloudPartnerPurchase
""")

# COMMAND ----------

# DBTITLE 1,delete inactive cancelled orders for Azure
canSharedAzureQuery = f"""
select concat("SharedAzure-", concat(coalesce(sfdc_account_id, "noSFDCAccount"), concat("-",cast(start_date as date)))) AggOrder,
       sfdc_account_id,
       sfdc_account_name,
       'azure' Platform,
       'Shared' Scope,
       first(azure_sub_id) SubscriptionID,
       cast(start_date as date) startDate,
       max(cast(end_date as date)) endDate,
       sum(msft_commitment) cloudPartnerPurchase,
       sum(purchase_price_msft) ActualPartnerCommit,
       sum(purchase_price_databricks) DBShareCommit,
       round(1 - (sum(purchase_price_msft)/sum(msft_commitment)),4) dbuCustPriceDiscount,
       collect_set(reservation_order_id) orderId
from {FINANCE_MSFT_RI}
where applied_scope_type = 'Shared'
and include_flag = 0
group by 1,2,3,4,5,7
"""
canSharedAzureDF = spark.sql(canSharedAzureQuery)

canSingleAzureQueryNew = f"""
select concat("SingleAzure-", concat(coalesce(azure_sub_id, "noSFDCAccount"), concat("-",cast(start_date as date)))) AggOrder,
       sfdc_account_id,
       sfdc_account_name,
       'azure' Platform,
       'Single' Scope,
       azure_sub_id SubscriptionID,
       cast(start_date as date) startDate,
       max(cast(end_date as date)) endDate,
       sum(msft_commitment) cloudPartnerPurchase,
       sum(purchase_price_msft) ActualPartnerCommit,
       sum(purchase_price_databricks) DBShareCommit,
       round(1 - (sum(purchase_price_msft)/sum(msft_commitment)),4) dbu_price_discount,
       collect_set(reservation_order_id) orderId
from {FINANCE_MSFT_RI}
where applied_scope_type = 'Single'
and include_flag = 0
group by 1,2,3,4,5,6,7
"""

canSingleAzureNew = spark.sql(canSingleAzureQueryNew)

canAllAzureCommitDF = canSharedAzureDF.union(canSingleAzureNew)
canAllAzureCommitDF.createOrReplaceTempView("can_azure")

# COMMAND ----------

spark.sql(f"""
select old.*
from {BI_AGGORDERS} old
join can_azure new on old.aggorder = new.aggorder and old.platform = new.platform
where old.platform = 'azure'
and old.aggorder not like 'MTM%'
""")

# COMMAND ----------

# DBTITLE 1,PVC Orders
pvcOrdersBackup = spark.read.format("delta").load(BI_AGGORDERS_PVC_LOCATION)
pvcOrdersBackup.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(BACKUP_BI_AGGORDERS_PVC)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0
 
@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0
 
@udf("double")
def distributeDailyRevShareDollars(revShareDollars, daysinmonth):
  return revShareDollars/daysinmonth
 
@udf("double")
def distributeDailyInteractiveDBUs(InteractiveDBUs, daysinmonth):
  return InteractiveDBUs/daysinmonth
 
@udf("double")
def distributeDailyAutomatedDBUs(AutomatedDBUs, daysinmonth):
  return AutomatedDBUs/daysinmonth
 
@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  if platform == "azure":
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  return (cumDBDollars > RevShareCommit + 0.999) or (usage_date > endDate)
 
@udf("double")
def pctBurn(platform, aggOrder, ListCommit, RevShareCommit, cumListDollars, cumRevShareDollars, cumListForecastDollars, cumRevShareForecastDollars):
  pctBurn = 0.0
  if not 'MTM' in aggOrder:
    if platform == 'azure':
      return 0 if ListCommit==0 else ((cumListDollars + cumListForecastDollars) / ListCommit) * 100
    if platform == 'aws':
      return 0 if RevShareCommit==0 else ((cumRevShareDollars + cumRevShareForecastDollars) / RevShareCommit) * 100
  return pctBurn
 
@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"



pvc_df = spark.sql(f"""
with pubsec (
select sfdc_account_id accountID,
       sfdc_account_name accountName,
       year,
       month,
       dbu,
       type,
       dbu_dollars dbuDollars
from {FINANCE_PUBSEC_USAGE}
),
common_accs (
select distinct f.sfdc_account_id accountID
from {FINANCE_PUBSEC_USAGE} f
join {FINANCE_PVC_USAGE} pvc on f.sfdc_account_id = pvc.sfdc_account_id
),

pvc_withoutcommon (
select pvc.sfdc_account_id accountID,
       pvc.sfdc_account_name accountName,
       pvc.year,
       pvc.month,
       pvc.dbu,
       pvc.type,
       pvc.dbu_dollars dbuDollars
from {FINANCE_PVC_USAGE} pvc
left join common_accs com on pvc.sfdc_account_id = com.accountId
where com.accountId is null
)

select *
from pvc_withoutcommon
union 
select *
from pubsec
""")

dbuCols = ["dbu", "type"]
pvc_df = pvc_df.withColumnRenamed("accountID", "accountId")\
               .withColumnRenamed("dbuDollars", "revShareDollars")\
               .withColumn("type", lower(col("type")))\
               .withColumn("InteractiveDBUs", coalesce(interactive_dbus(*dbuCols), lit(0)))\
               .withColumn("AutomatedDBUs", coalesce(automated_dbus(*dbuCols), lit(0)))

date_df = spark.sql(f"select date, year, month, daysinmonth from {BI_DATES}")
pvc_date = pvc_df.join(date_df, (pvc_df.year==date_df.year) & (pvc_df.month==date_df.month))\
                 .drop(date_df.year)\
                 .drop(date_df.month)
 
# dropColumns = ["ctc_flag", "year", "month", "ownerID", "OwnerName", "region", "l1Segment", "l2Segment", "l3Segment", "platform", "fiscalYear", "fiscalQtr", "type", "dbuPrice", "dbu", "adoptionYear", "adoptionMonth"]

dropColumns = ["type", "dbuPrice", "dbu"]
pvc_date = pvc_date.withColumnRenamed("date", "usage_date")\
                   .drop(*dropColumns)
 
pvc_usage = pvc_date.withColumn("revShareDollars", round(distributeDailyRevShareDollars("revShareDollars", "daysinmonth"),2) )\
                   .withColumn("InteractiveDBUs", round(distributeDailyInteractiveDBUs("InteractiveDBUs", "daysinmonth"),2) )\
                   .withColumn("AutomatedDBUs", round(distributeDailyAutomatedDBUs("AutomatedDBUs", "daysinmonth"),2) )\
                   .drop("daysinmonth")\
                   .withColumn("listDollars", col("RevShareDollars"))\
                   .withColumn("custDollars", col("RevShareDollars"))
 
orderByColumns = ['accountID','accountName','usage_date']
pvc_usage = pvc_usage.orderBy(*orderByColumns)
pvc_usage.createOrReplaceTempView("pvc_usage")

# COMMAND ----------

pvcCommit = spark.sql(f"""
with pvc_accounts (
select distinct accountId
from pvc_usage
)
select *
from {BI_AGGORDERS} agg 
join pvc_accounts pvc on agg.sfdcAccountID == pvc.accountId
where AggOrder not like 'MTM%'
order by sfdcAccountID, startDate
""")
pvcCommit = pvcCommit.drop("accountId")

pvcPAY = spark.sql("""
select null usageBurstDate,
       concat("MTMAWS",coalesce(accountID, 'noSFDCAccountID'))  AggOrder,
       coalesce(accountID, 'noSFDCAccountID') sfdcAccountID,
       coalesce(accountName, 'noSFDCAccountName') sfdcAccountName, 
       'aws' Platform,
       'shared' Scope,
       'MTMSubscriptionID' SubscriptionID, 
       min(usage_date) startDate,
       date_add(min(usage_date), (365*50)) endDate,
       0 cloudPartnerPurchase,
       0 ActualPartnerCommit,
       0 DBShareCommit,
       0 dbuCustPriceDiscount,
       collect_set(concat("MTMAWS",coalesce(accountID, 'noSFDCAccountID'))) orderId
from pvc_usage
group by accountID, accountName
""")

pvcOrders = pvcCommit.union(pvcPAY)
pvcOrders = pvcOrders.orderBy("sfdcAccountID", "startDate")

display(pvcOrders)

# COMMAND ----------

pvcOrders.createOrReplaceTempView("pvcOrders")
spark.read.format("delta").load(BI_AGGORDERS_PVC_LOCATION).createOrReplaceTempView("oldPVCOrders")

# COMMAND ----------

newPVCOrdersCheck = spark.sql("""
select new.*
from pvcOrders new
left join oldPVCOrders old on new.aggOrder = old.aggOrder and new.endDate = old.endDate and new.dbShareCommit = old.dbShareCommit
where old.aggOrder is null
""")

# COMMAND ----------

newPVCOrdersCheckCount = newPVCOrdersCheck.count()
print("new pvc orders ", newPVCOrdersCheckCount)
if newPVCOrdersCheckCount > 0:
  display(newPVCOrdersCheck)

# COMMAND ----------

if newPVCOrdersCheckCount > 0:
  print("updating pvc orders")
  pvcOrders.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(BI_AGGORDERS_PVC_LOCATION)
