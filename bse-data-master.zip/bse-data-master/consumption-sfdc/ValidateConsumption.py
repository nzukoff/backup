# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

validate_consumption = consumption_validation(FINANCE_USAGE_STAGE, FINANCE_PAID_METERING_USAGE, FINANCE_PVC_USAGE, FINANCE_PUBSEC_USAGE, USAGEC_AGGORDER_DAILY, BI_DATES, "RevShareDollars")
#consumption_validation(USAGEC_AGGORDER_DAILY)

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from validate_consumption

# COMMAND ----------

if validate_consumption.count() > 0 :
  raise Exception(" validation check failed ")
else:
  print(" validation check passed ")

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))

# COMMAND ----------


