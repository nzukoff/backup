# Databricks notebook source
# MAGIC %run ./Salesforce-HelperFunctions

# COMMAND ----------

# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

"""

1. all accounts in bdw.cpq_aws_gcp_contracts_orders_vw
2. filter all the parallel contracted accounts
3. If one of the parallel contracts has worksapces mapped
  a) all the workspaces burn through the first contract ( earliest of all the parellel contracts) until the next contract begins
  b) next contract will only burn the mapped workspaces from the start date
  c) when b) is true, then, the first contract should burn the remaining workspaces

tables:
1. bdw.cpq_contracts_bronze
2. bdw.cpq_aws_gcp_contracts_orders_vw
3. bdw.cpq_aws_gcp_usage_rates_vw

todo:
1. parallel contracts
2. pvc, pubsec
"""

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

@udf('string')
def commit_string(product_code, cpq_order_type):
  """ drops dollar from commit string  """
  commit_string = 'COMMIT'
  if cpq_order_type is None:
    cpq_order_type = ""
  if 'DOLLAR' in product_code and 'co-term' not in cpq_order_type.lower():
    commit_string = product_code.split('-')
    return '-'.join(commit_string[0:len(commit_string)-1])
  
  if 'DOLLAR' in product_code and 'co-term' in cpq_order_type.lower():
    commit_string = product_code.split('-')
    return '-'.join(commit_string[0:len(commit_string)-1]) + '-CO-TERM'
  
  if 'COMPLIMENTARY-USAGE-AWS' in product_code:
    return 'AWS-COMPLIMENTARY'
  
  return commit_string

spark.udf.register("commit_string", commit_string)


@udf('string')
def split_commit_string(order):
  if order is None:
    return None
  else:
    split_string = order.split('-')
    return '-'.join(split_string[0:len(split_string)-1])

spark.udf.register("split_commit_string", split_commit_string)

# COMMAND ----------

pvc_usage_daily = spark.read.format('delta').load(PVC_USAGE_DAILY_LOCATION)
pvc_usage_daily.createOrReplaceTempView('pvc_usage_daily')


# COMMAND ----------

spark.sql("drop view if exists finance_usage_pricing")
spark.sql(f"""
create temp view finance_usage_pricing
as
(
  select f.sfdc_account_id accountId,
       f.sfdc_workspace_id workspaceId,
       ps.Name businessSubscriptionID,
       f.sku,
       f.date,
       f.platform,
       sum(f.dbu) dbu,
       max(f.dbu_price) dbu_price,
       sum(dbu_dollars) revShareDollars,
       sum((f.dbu * f.discount_price)+if(f.platform='azure', f.shield_dollars/0.85, f.shield_dollars)) custDollars
  from {FINANCE_DBU_DOLLARS} f
  left join {SFDC_WORKSPACE} w 
    on f.workspace_sfdc_object_id = w.id
    and w.processDate = (
      select max(processDate)
      from {SFDC_WORKSPACE}
    )
  left join {SFDC_PLATFORM_SUBSCRIPTION} ps
    on w.Business_Subscription__c = ps.id
    and ps.processDate = (
      select max(processDate)
      from {SFDC_PLATFORM_SUBSCRIPTION}
    )
  where date < '{SOURCE_SWITCH_DATE}'
  group by 1,2,3,4,5,6

  union all

  select f.sfdc_account_id accountId,
       f.sfdc_workspace_id workspaceId,
       business_subscription_id businessSubscriptionID,
       f.sku,
       f.date,
       f.platform,
       sum(f.net_usage_amount) dbu,
       max(f.rev_share_price) dbu_price,
       sum(usage_dollars) revShareDollars,
       sum((f.net_usage_amount * f.discount_price)+if(f.platform='azure', f.add_on.shield_dollars/0.85, f.add_on.shield_dollars)) custDollars
  from {FINANCE_PAID_METERING_USAGE} f
  where date >= '{SOURCE_SWITCH_DATE}'
  group by 1,2,3,4,5,6

)

union all

select accountId,
       workspaceId,
       null businessSubscriptionID,
       sku,
       date,
       platform,
       dbu,
       dbu_price,
       revShareDollars,
       custDollars
from pvc_usage_daily
""")

# COMMAND ----------

# DBTITLE 1,Azure Parallel Contracts Processing
parallel_accounts_azure = spark.sql(f""" select * from {AZURE_CONTRACTS_ORDERS_PARALLEL_VW} """).dropDuplicates()
parallel_accounts_azure.createOrReplaceTempView('parallel_accounts_azure')

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists parallel_accounts_product_codes

# COMMAND ----------

spark.sql(f"""
create temp view parallel_accounts_product_codes
as
with distinct_parallel_accounts (

select distinct account_id
from parallel_accounts_azure
)

select distinct o.account_id,
                      contract_id,
                      order_id,
                      renewal_opportunity,
                      order_item_start_date,
                      order_item_end_date,
                      order_item_effective_end_date,
                      consumption_cloud,
                      product_code,
                      cpq_order_type,
                      generated_contract_number,
                      committed_quantity,
                      cpq_cloud,
                      order_number,
                      concat(o.account_id, '-', commit_string(product_code, cpq_order_type), '-', generated_contract_number, '-', order_number, '-', order_item_start_date) aggorder_key
from {CPQ_AWS_GCP_CONTRACTS_ORDERS_VW} o
join distinct_parallel_accounts d on o.account_id = d.account_id
where product_family = 'Workload Commitment'
order by account_id, order_item_start_date, product_code
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists parallel_azure_flex_contracts

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 00161000005gCW8AAM, 0016100000U5DriAAF, 0016100000cF38VAAS, 0016100000d0MxJAAU
# MAGIC create temp view parallel_azure_flex_contracts
# MAGIC as
# MAGIC with azure_flex_contracts (
# MAGIC   select account_id, contract_id, count(consumption_cloud) cnt
# MAGIC   from parallel_accounts_product_codes
# MAGIC   where lower(consumption_cloud) in ('azure', 'flex')
# MAGIC   group by 1,2
# MAGIC   having cnt > 1
# MAGIC )
# MAGIC select p.*
# MAGIC from parallel_accounts_product_codes p
# MAGIC join azure_flex_contracts a on p.account_id = a.account_id and p.contract_id = a.contract_id
# MAGIC order by p.account_id, p.contract_id, p.order_item_start_date

# COMMAND ----------

# for parallel contracts with flex, handle the flex with all the consumption cloud
# just update the orders with azure contracts with the date and process them with all the other orders

# actually adding the flex to the order of azure parallel contracts is right way to handle
# if flex exists, it should burn from flex before its 100% done
# so add the flex order to the azure-parallel-orders by row

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists ordered_azure_parallel_contracts

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view ordered_azure_parallel_contracts
# MAGIC as
# MAGIC with contracts_base (
# MAGIC select distinct account_id, 
# MAGIC                 product_code, 
# MAGIC                 cpq_order_type, 
# MAGIC                 generated_contract_number, 
# MAGIC                 contract_id, order_id, 
# MAGIC                 order_number, 
# MAGIC                 order_item_start_date, 
# MAGIC                 order_item_effective_end_date, 
# MAGIC                 committed_quantity,
# MAGIC                 consumption_cloud,
# MAGIC                 cpq_cloud,
# MAGIC                 renewal_opportunity
# MAGIC from parallel_accounts_product_codes --parallel_accounts_azure --bdw.cpq_aws_gcp_contracts_orders_parallel_workspaces_vw
# MAGIC where lower(cpq_cloud) in ('azure', 'flex')
# MAGIC order by account_id, order_item_start_date, contract_id
# MAGIC )
# MAGIC
# MAGIC select row_number() over(partition by account_id order by order_item_start_date, contract_id) row_num,
# MAGIC        concat(commit_string(product_code, cpq_order_type), '-', generated_contract_number, '-', order_number) AggOrder,
# MAGIC        concat(account_id, '-', commit_string(product_code, cpq_order_type), '-', generated_contract_number, '-', order_number, '-', order_item_start_date) aggorder_key,
# MAGIC        *
# MAGIC from  contracts_base
# MAGIC order by account_id, row_num, order_item_start_date, contract_id

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists orders_base_azure

# COMMAND ----------

spark.sql(f"""
-- distinct for parallel
create temp view orders_base_azure
as

select distinct
       null usageBurstDate,
       aggorder_key,
       concat('UNIVERSAL-COMMIT-', generated_contract_number) UniversalOrder,
       concat(commit_string(product_code, cpq_order_type), '-', generated_contract_number, '-', order_number) AggOrder,
       concat('FLEX-COMMIT-', generated_contract_number, '-', order_number) flexOrder,
       concat(consumption_cloud, '-COMPLIMENTARY-', generated_contract_number, '-', order_number) complimentary_order,
       --concat(consumption_cloud, '-COMMIT-CO-TERM-', generated_contract_number, '-', order_number) coterm_order,       
       concat(cpq_cloud, '-COMMIT-CO-TERM-', generated_contract_number, '-', order_number) coterm_order,       
       account_id sfdcAccountId,     
       acc.accountName sfdcAccountName,
       consumption_cloud Platform,
       contract_id,
       order_id,
       renewal_opportunity,
       order_item_start_date startDate,
       order_item_effective_end_date endDate,

       committed_quantity cloudPartnerPurchase,
       committed_quantity ActualPartnerCommit,
       case when lower(consumption_cloud) = 'azure' then 0.85 * committed_quantity 
            else committed_quantity end as DBShareCommit,
       case when commit_string(product_code, cpq_order_type) = 'FLEX-COMMIT' then committed_quantity else 0 end flexCommit,
       0 universalCommit,
       case when commit_string(product_code, cpq_order_type) = 'AWS-COMPLIMENTARY' then committed_quantity else 0 end complimentary_usage,
       case when commit_string(product_code, cpq_order_type) like '%COMMIT-CO-TERM' then committed_quantity else 0 end coterm_commit
from  ordered_azure_parallel_contracts c
join  {ACCOUNT_DIM} acc on c.account_id = acc.accountId             
order by sfdcAccountId, startDate, endDate
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists azure_base_consumption

# COMMAND ----------

spark.sql(f"""
create temp view azure_base_consumption
as
with distinct_parallel_contracts (

select distinct account_id
from ordered_azure_parallel_contracts

)
select f.accountId,
       f.workspaceId,
       f.sku,
       cast(f.date as string) date,
       cast(dt.month_end_date as string) month_end_date,
       f.platform,
       f.dbu,
       f.dbu_price,
       coalesce(round(revShareDollars,6),0) revShareDollars,
       coalesce(round(custDollars,6), 0) custDollars,
       False is_contracted,
       concat(f.accountId,'-MTM',upper(f.platform)) aggorder_key
from finance_usage_pricing f
join distinct_parallel_contracts d on f.accountId = d.account_id
join {BI_DATES} dt on f.date = dt.date
where lower(platform) = 'azure'
order by f.date
""")

# COMMAND ----------

azure_base_consumption_rows = spark.sql(""" select * from azure_base_consumption """).collect()

# COMMAND ----------

distinct_azure_account_rows = spark.sql(""" select distinct account_id from ordered_azure_parallel_contracts  order by account_id""").collect()
#print(distinct_azure_account_rows)

# COMMAND ----------

azure_contracts_local = spark.sql(""" select row_num, 
                                             account_id, 
                                             contract_id, 
                                             order_id, 
                                             aggorder_key, 
                                             order_item_start_date, 
                                             order_item_effective_end_date, 
                                             committed_quantity 
                                      from ordered_azure_parallel_contracts """)
azure_contracts_local = azure_contracts_local.withColumn('order_item_start_date', col('order_item_start_date').cast('string'))\
                                             .withColumn('order_item_effective_end_date', col('order_item_effective_end_date').cast('string'))


azure_contracts_local_rows = azure_contracts_local.collect()

# COMMAND ----------

#build account-contracts map
azure_contracts_local_rows_account_map = {}
for row in azure_contracts_local_rows:

  if row.account_id in azure_contracts_local_rows_account_map:
    azure_contracts_local_rows_account_map[row.account_id].append(row)
  else:
    azure_contracts_local_rows_account_map[row.account_id] = [row]

# COMMAND ----------

#build account-consumption map
azure_base_consumption_rows_as_account_dict = {}
for row in azure_base_consumption_rows:

  if row.accountId in azure_base_consumption_rows_as_account_dict:
    azure_base_consumption_rows_as_account_dict[row.accountId].append(row.asDict())
  else:
    azure_base_consumption_rows_as_account_dict[row.accountId] = [row.asDict()]

# COMMAND ----------

for d in distinct_azure_account_rows:
  print('processing..', d.account_id)
  azure_contracts_local_rows_stack = azure_contracts_local_rows_account_map[d.account_id][::-1]
  #print(azure_contracts_local_rows_stack)
  try:
    azure_base_consumption_rows_dict = azure_base_consumption_rows_as_account_dict[d.account_id]
    
    while azure_contracts_local_rows_stack:

      r = azure_contracts_local_rows_stack.pop() #current_contract
      print('             running for ', r.aggorder_key, r.order_item_start_date, r.order_item_effective_end_date, r.committed_quantity)
      running_total = 0
      for idx, c in enumerate(azure_base_consumption_rows_dict):
          is_contracted = c['is_contracted']
          if c['accountId'] == r.account_id and c['date'] >= r.order_item_start_date and c['date'] <= r.order_item_effective_end_date and not is_contracted and running_total < r.committed_quantity * 0.85:
              azure_base_consumption_rows_dict[idx]['is_contracted'] = True
              azure_base_consumption_rows_dict[idx]['aggorder_key'] = r.aggorder_key
              running_total += c['revShareDollars']
              
              c_r = azure_base_consumption_rows_dict[idx]
              c_r.update(r.asDict())
              #print(running_total)
              #azure_base_consumption_contract_rows.append(c_r)

          if running_total >= r.committed_quantity * 0.85:
            break
    azure_base_consumption_rows_as_account_dict[d.account_id] = azure_base_consumption_rows_dict
  
  except KeyError as error:
    print(f"KeyError encountered: {error}")

  #break

# COMMAND ----------

azure_base_consumption_rows_final = [x for xs in list(azure_base_consumption_rows_as_account_dict.values()) for x in xs]
del azure_base_consumption_rows_as_account_dict

# COMMAND ----------

parallel_consumption_azure = spark.createDataFrame(azure_base_consumption_rows_final)
del azure_base_consumption_rows_final
spark.sql("drop view if exists azure_base_consumption")
spark.catalog.clearCache()

# COMMAND ----------

#parallel_consumption_azure = spark.createDataFrame(azure_base_consumption_rows_as_dict)
parallel_consumption_azure = parallel_consumption_azure.drop('row_num')
parallel_consumption_azure.createOrReplaceTempView('parallel_consumption_azure')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select *
# MAGIC -- from parallel_consumption_azure
# MAGIC with azure_consumption_base (
# MAGIC select accountId,aggorder_key, sum(revShareDollars) total_consumption, min(date) min_date, max(date) max_date
# MAGIC from parallel_consumption_azure
# MAGIC --where date >= '2021-06-11'
# MAGIC group by 1,2
# MAGIC order by 1,2
# MAGIC )
# MAGIC
# MAGIC select c.*,
# MAGIC        o.order_item_effective_end_date,
# MAGIC        o.committed_quantity,
# MAGIC        round((c.total_consumption/(o.committed_quantity*0.85)) * 100, 2) burn_percentage
# MAGIC from azure_consumption_base c
# MAGIC left join ordered_azure_parallel_contracts o on c.aggorder_key = o.aggorder_key
# MAGIC order by 1,2 

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists base_consumption

# COMMAND ----------

spark.sql(f"""
create temp view base_consumption
as
select f.accountId,
       f.workspaceId,
       f.businessSubscriptionID,
       f.sku,
       f.date,
       dt.month_end_date,
       f.platform,
       f.dbu,
       f.dbu_price,
       coalesce(round(revShareDollars,6),0) revShareDollars,
       coalesce(round(custDollars,6), 0) custDollars
from finance_usage_pricing f
join {BI_DATES} dt on f.date = dt.date
order by f.date
""")

# COMMAND ----------

parallel_accounts = spark.sql(f""" select * from {CPQ_AWS_GCP_CONTRACTS_ORDERS_PARALLEL_WORKSPACES_VW} """).drop('workspace_id')
parallel_accounts.createOrReplaceTempView('parallel_accounts')

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists orders_base_workspaces

# COMMAND ----------

spark.sql(f"""
-- distinct for parallel
create temp view orders_base_workspaces
as
select distinct
       null usageBurstDate,
       concat('UNIVERSAL-COMMIT-', generated_contract_number) UniversalOrder,
       concat(commit_string(product_code, cpq_order_type), '-', generated_contract_number, '-', order_number) AggOrder,
       concat('FLEX-COMMIT-', generated_contract_number, '-', order_number) flexOrder,
       concat(consumption_cloud, '-COMPLIMENTARY-', generated_contract_number, '-', order_number) complimentary_order,
       --concat(consumption_cloud, '-COMMIT-CO-TERM-', generated_contract_number, '-', order_number) coterm_order,       
       concat(cpq_cloud, '-COMMIT-CO-TERM-', generated_contract_number, '-', order_number) coterm_order,       
       account_id sfdcAccountId,
       is_parallel_contract,       
       acc.accountName sfdcAccountName,
       consumption_cloud Platform,
       contract_id,
       order_id,
       renewal_opportunity,
       workspace_id,
       order_item_start_date startDate,
       order_item_effective_end_date endDate,

       committed_quantity cloudPartnerPurchase,
       committed_quantity ActualPartnerCommit,
       case when lower(consumption_cloud) = 'azure' then 0.85 * committed_quantity 
            else committed_quantity end as DBShareCommit,
       case when commit_string(product_code, cpq_order_type) = 'FLEX-COMMIT' then committed_quantity else 0 end flexCommit,
       0 universalCommit,
       case when commit_string(product_code, cpq_order_type) = 'AWS-COMPLIMENTARY' then committed_quantity else 0 end complimentary_usage,
       case when commit_string(product_code, cpq_order_type) like '%COMMIT-CO-TERM' then committed_quantity else 0 end coterm_commit
       
from {CPQ_AWS_GCP_CONTRACTS_ORDERS_PARALLEL_WORKSPACES_VW} c
join {ACCOUNT_DIM} acc on c.account_id = acc.accountId
where product_family = 'Workload Commitment'
order by sfdcAccountId, startDate
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists orders_base

# COMMAND ----------

spark.sql(f"""
-- distinct for parallel
create temp view orders_base
as
select distinct
       null usageBurstDate,
       concat('UNIVERSAL-COMMIT-', generated_contract_number) UniversalOrder,
       concat(commit_string(product_code, cpq_order_type), '-', generated_contract_number, '-', order_number) AggOrder,
       concat('FLEX-COMMIT-', generated_contract_number, '-', order_number) flexOrder,
       concat(consumption_cloud, '-COMPLIMENTARY-', generated_contract_number, '-', order_number) complimentary_order,
       --concat(consumption_cloud, '-COMMIT-CO-TERM-', generated_contract_number, '-', order_number) coterm_order,       
       concat(cpq_cloud, '-COMMIT-CO-TERM-', generated_contract_number, '-', order_number) coterm_order,       
       account_id sfdcAccountId,
       is_parallel_contract,       
       acc.accountName sfdcAccountName,
       consumption_cloud Platform,
       contract_id,
       order_id,
       renewal_opportunity,
       order_item_start_date startDate,
       order_item_effective_end_date endDate,

       committed_quantity cloudPartnerPurchase,
       committed_quantity ActualPartnerCommit,
       case when lower(consumption_cloud) = 'azure' then 0.85 * committed_quantity 
            else committed_quantity end as DBShareCommit,
       case when commit_string(product_code, cpq_order_type) = 'FLEX-COMMIT' then committed_quantity else 0 end flexCommit,
       0 universalCommit,
       case when commit_string(product_code, cpq_order_type) = 'AWS-COMPLIMENTARY' then committed_quantity else 0 end complimentary_usage,
       case when commit_string(product_code, cpq_order_type) like '%COMMIT-CO-TERM' then committed_quantity else 0 end coterm_commit
       
from {CPQ_AWS_GCP_CONTRACTS_ORDERS_PARALLEL_WORKSPACES_VW} c
join {ACCOUNT_DIM} acc on c.account_id = acc.accountId
where product_family = 'Workload Commitment'               
order by sfdcAccountId, startDate
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists parallel_orders_base

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view parallel_orders_base
# MAGIC as
# MAGIC with base (
# MAGIC select sfdcAccountId,
# MAGIC        sfdcAccountName,
# MAGIC        UniversalOrder,
# MAGIC        aggOrder,
# MAGIC        DBShareCommit,
# MAGIC        flexCommit,
# MAGIC        0 coterm_commit
# MAGIC from orders_base_azure
# MAGIC
# MAGIC union
# MAGIC
# MAGIC select sfdcAccountId,
# MAGIC        sfdcAccountName,
# MAGIC        UniversalOrder,
# MAGIC        aggOrder,
# MAGIC        DBShareCommit,
# MAGIC        flexCommit,
# MAGIC        coterm_commit
# MAGIC from orders_base
# MAGIC )
# MAGIC
# MAGIC select *
# MAGIC from base
# MAGIC order by sfdcAccountId, aggOrder

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists universal_commits

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view universal_commits
# MAGIC as
# MAGIC select sfdcAccountId,
# MAGIC        UniversalOrder,
# MAGIC        sum(DBShareCommit + coterm_commit) universalCommit
# MAGIC from parallel_orders_base
# MAGIC where aggOrder not like '%COMPLIMENTARY%'
# MAGIC and aggOrder not like '%CO-TERM%'  
# MAGIC group by sfdcAccountId, UniversalOrder

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists aggorders

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view aggorders
# MAGIC as
# MAGIC select l.usageBurstDate,
# MAGIC        l.UniversalOrder,
# MAGIC        l.AggOrder,
# MAGIC        l.flexOrder,
# MAGIC        case when r1.complimentary_usage is null then null else l.complimentary_order end complimentary_order,
# MAGIC        case when r2.aggOrder is null then null else r2.aggOrder end coterm_order,
# MAGIC        l.sfdcAccountId,
# MAGIC        l.Platform,
# MAGIC        l.contract_id,
# MAGIC        l.order_id,
# MAGIC        l.renewal_opportunity,
# MAGIC        l.startDate,
# MAGIC        l.endDate,
# MAGIC        l.cloudPartnerPurchase,
# MAGIC        l.ActualPartnerCommit,
# MAGIC        l.DBShareCommit,
# MAGIC        case when r.AggOrder is not null then r.flexCommit else 0 end flexCommit,
# MAGIC        coalesce(u.universalCommit +  coalesce(r2.DBShareCommit, 0), l.universalCommit +  coalesce(r2.DBShareCommit, 0)) universalCommit,
# MAGIC        coalesce(r1.complimentary_usage, 0) complimentary_usage,
# MAGIC        coalesce(r2.DBShareCommit, 0) coterm_dbshare_commit,
# MAGIC        r2.startDate coterm_startDate
# MAGIC from orders_base l
# MAGIC left join orders_base r on l.flexOrder = r.AggOrder and l.sfdcAccountId = r.sfdcAccountId
# MAGIC left join universal_commits u on l.UniversalOrder = u.UniversalOrder and l.sfdcAccountId = u.sfdcAccountId
# MAGIC left join orders_base r1 on l.complimentary_order = r1.aggOrder and l.sfdcAccountId = r1.sfdcAccountId
# MAGIC left join orders_base r2 on split_commit_string(l.coterm_order) = split_commit_string(r2.aggOrder) and l.sfdcAccountId = r2.sfdcAccountId
# MAGIC where l.AggOrder not like 'FLEX-COMMIT%'
# MAGIC   and l.AggOrder not like '%COMPLIMENTARY%'
# MAGIC   and l.AggOrder not like '%CO-TERM%'  
# MAGIC order by l.sfdcAccountId, l.startDate

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists aggorder_workspaces

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view aggorder_workspaces
# MAGIC as
# MAGIC select l.usageBurstDate,
# MAGIC        l.UniversalOrder,
# MAGIC        l.AggOrder,
# MAGIC        l.flexOrder,
# MAGIC        case when r1.complimentary_usage is null then null else l.complimentary_order end complimentary_order,
# MAGIC        case when r2.aggOrder is null then null else r2.aggOrder end coterm_order,
# MAGIC        l.sfdcAccountId,
# MAGIC        l.Platform,
# MAGIC        l.contract_id,
# MAGIC        l.order_id,
# MAGIC        l.renewal_opportunity,
# MAGIC        l.workspace_id,
# MAGIC        l.startDate,
# MAGIC        l.endDate,
# MAGIC        l.cloudPartnerPurchase,
# MAGIC        l.ActualPartnerCommit,
# MAGIC        l.DBShareCommit,
# MAGIC        case when r.AggOrder is not null then r.flexCommit else 0 end flexCommit,
# MAGIC        coalesce(u.universalCommit +  coalesce(r2.DBShareCommit, 0), l.universalCommit +  coalesce(r2.DBShareCommit, 0)) universalCommit,
# MAGIC        coalesce(r1.complimentary_usage, 0) complimentary_usage,
# MAGIC        coalesce(r2.DBShareCommit, 0) coterm_dbshare_commit,
# MAGIC        r2.startDate coterm_startDate
# MAGIC from orders_base_workspaces l
# MAGIC left join orders_base r on l.flexOrder = r.AggOrder and l.sfdcAccountId = r.sfdcAccountId
# MAGIC left join universal_commits u on l.UniversalOrder = u.UniversalOrder and l.sfdcAccountId = u.sfdcAccountId
# MAGIC left join orders_base r1 on l.complimentary_order = r1.aggOrder and l.sfdcAccountId = r1.sfdcAccountId
# MAGIC left join orders_base r2 on split_commit_string(l.coterm_order) = split_commit_string(r2.aggOrder) and l.sfdcAccountId = r2.sfdcAccountId
# MAGIC where l.AggOrder not like 'FLEX-COMMIT%'
# MAGIC   and l.AggOrder not like '%COMPLIMENTARY%'
# MAGIC   and l.AggOrder not like '%CO-TERM%'  
# MAGIC order by l.sfdcAccountId, l.startDate

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists non_azure_consumption_parallel

# COMMAND ----------

spark.sql(f"""
create temp view non_azure_consumption_parallel 
as
with base_consumption_local (
select f.accountId,
       f.workspaceId,
       f.businessSubscriptionID,
       f.sku,
       f.date,
       dt.month_end_date,
       f.platform,
       f.dbu,
       f.dbu_price,
       coalesce(round(revShareDollars,6),0) revShareDollars,
       coalesce(round(custDollars,6), 0) custDollars
from finance_usage_pricing f
join {BI_DATES} dt on f.date = dt.date
order by f.date
),

order_consumption (
select a.aggOrder,
       a.dbshareCommit,
       a.complimentary_order,
       a.complimentary_usage,
       a.flexOrder,
       a.flexCommit,
       a.UniversalOrder,
       a.universalCommit,
       a.coterm_order,
       a.coterm_dbshare_commit,
       a.ActualPartnerCommit,
       a.contract_id,
       a.order_id,
       a.renewal_opportunity,
       a.startDate,
       a.endDate,
       a.coterm_startDate,
       b.*
from base_consumption_local b
join aggorder_workspaces a on b.accountId = a.sfdcAccountId and lower(b.platform) = lower(a.Platform) and b.date between a.startDate and a.endDate
                    and b.workspaceId = a.workspace_id
where lower(b.platform) <> 'azure'                    
order by date
)

select o.*,
       sum(revShareDollars) over(partition by accountId, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_revshare_dollars,
       sum(custDollars) over(partition by accountId, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_cust_dollars
from order_consumption o
order by date, dbu
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists azure_consumption_parallel

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view azure_consumption_parallel
# MAGIC as
# MAGIC with base (
# MAGIC select account_id accountId,
# MAGIC        workspaceId,
# MAGIC        null businessSubscriptionID,
# MAGIC        sku,
# MAGIC        date,
# MAGIC        month_end_date,
# MAGIC        platform,
# MAGIC        dbu,
# MAGIC        dbu_price,
# MAGIC        revShareDollars,
# MAGIC        custDollars,
# MAGIC        aggorder_key
# MAGIC from parallel_consumption_azure       
# MAGIC ),
# MAGIC
# MAGIC order_consumption_azure (
# MAGIC select a.aggOrder,
# MAGIC        a.dbshareCommit,
# MAGIC        a.complimentary_order,
# MAGIC        a.complimentary_usage,
# MAGIC        a.flexOrder,
# MAGIC        a.flexCommit,
# MAGIC        a.UniversalOrder,
# MAGIC        a.universalCommit,
# MAGIC        a.coterm_order,
# MAGIC        0 coterm_dbshare_commit,
# MAGIC        a.ActualPartnerCommit,
# MAGIC        a.contract_id,
# MAGIC        a.order_id,
# MAGIC        a.renewal_opportunity,
# MAGIC        a.startDate,
# MAGIC        a.endDate,
# MAGIC        null coterm_startDate,
# MAGIC        b.accountId,
# MAGIC        b.workspaceId,
# MAGIC        b.businessSubscriptionID,
# MAGIC        b.sku,
# MAGIC        b.date,
# MAGIC        b.month_end_date,
# MAGIC        b.platform,
# MAGIC        b.dbu,
# MAGIC        b.dbu_price,
# MAGIC        b.revShareDollars,
# MAGIC        b.custDollars       
# MAGIC from base b
# MAGIC join orders_base_azure a on b.aggorder_key = a.aggorder_key  
# MAGIC )
# MAGIC
# MAGIC select o.*,
# MAGIC        sum(revShareDollars) over(partition by accountId, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_revshare_dollars,
# MAGIC        sum(custDollars) over(partition by accountId, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_cust_dollars
# MAGIC from order_consumption_azure o
# MAGIC order by date, dbu

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists test_consumption_parallel

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view test_consumption_parallel
# MAGIC as
# MAGIC select *
# MAGIC from non_azure_consumption_parallel
# MAGIC union
# MAGIC select *
# MAGIC from azure_consumption_parallel

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists complimentary_corrected_consumption

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view complimentary_corrected_consumption
# MAGIC as
# MAGIC with base (
# MAGIC select   
# MAGIC          case when complimentary_order is not null and rolling_sum_revshare_dollars <= complimentary_usage then complimentary_order
# MAGIC               else aggOrder end aggOrder,
# MAGIC          dbshareCommit,
# MAGIC          complimentary_usage,
# MAGIC          flexOrder,
# MAGIC          flexCommit,
# MAGIC          universalOrder,
# MAGIC          universalCommit,
# MAGIC          coterm_order,
# MAGIC          coterm_dbshare_commit,         
# MAGIC          ActualPartnerCommit,
# MAGIC          accountId,
# MAGIC          contract_id,
# MAGIC          order_id,
# MAGIC          coterm_startDate,
# MAGIC          startDate,
# MAGIC          endDate,
# MAGIC          renewal_opportunity,
# MAGIC          workspaceId,
# MAGIC          businessSubscriptionID,
# MAGIC          sku,
# MAGIC          date,
# MAGIC          month_end_date,
# MAGIC          platform,
# MAGIC          dbu,
# MAGIC          dbu_price,
# MAGIC          revShareDollars,
# MAGIC          custDollars,
# MAGIC          rolling_sum_revshare_dollars,
# MAGIC          rolling_sum_cust_dollars
# MAGIC from test_consumption_parallel
# MAGIC order by date, dbu
# MAGIC )
# MAGIC
# MAGIC select aggorder,
# MAGIC        dbshareCommit,
# MAGIC        complimentary_usage,
# MAGIC        flexOrder,
# MAGIC        flexCommit,
# MAGIC        universalOrder,
# MAGIC        universalCommit,
# MAGIC        coterm_order,
# MAGIC        coterm_dbshare_commit,       
# MAGIC        ActualPartnerCommit,
# MAGIC        accountId,
# MAGIC        contract_id,
# MAGIC        order_id,
# MAGIC        coterm_startDate,
# MAGIC        startDate,
# MAGIC        endDate,
# MAGIC        renewal_opportunity,
# MAGIC        workspaceId,
# MAGIC        businessSubscriptionID,
# MAGIC        sku,
# MAGIC        date,
# MAGIC        month_end_date,
# MAGIC        platform,
# MAGIC        dbu,
# MAGIC        dbu_price,
# MAGIC        revShareDollars,
# MAGIC        custDollars,
# MAGIC --        rolling_sum_revshare_dollars,
# MAGIC --        rolling_sum_cust_dollars,
# MAGIC        sum(revShareDollars) over(partition by accountId, platform, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_revshare_dollars,
# MAGIC        sum(custDollars) over(partition by accountId, platform, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_cust_dollars
# MAGIC
# MAGIC from base
# MAGIC order by date, dbu

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists coterm_corrected_consumption

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view coterm_corrected_consumption
# MAGIC as
# MAGIC with base (
# MAGIC select   
# MAGIC          case when coterm_startDate <= date and (coterm_order is not null and rolling_sum_revshare_dollars > dbshareCommit) then coterm_order
# MAGIC               else aggOrder end aggOrder,
# MAGIC          dbshareCommit,
# MAGIC          complimentary_usage,
# MAGIC          flexOrder,
# MAGIC          flexCommit,
# MAGIC          universalOrder,
# MAGIC          universalCommit,
# MAGIC          coterm_order,
# MAGIC          coterm_dbshare_commit,
# MAGIC          ActualPartnerCommit,
# MAGIC          accountId,
# MAGIC          contract_id,
# MAGIC          order_id,
# MAGIC          coterm_startDate,
# MAGIC          startDate,
# MAGIC          endDate,
# MAGIC          renewal_opportunity,
# MAGIC          workspaceId,
# MAGIC          businessSubscriptionID,
# MAGIC          sku,
# MAGIC          date,
# MAGIC          month_end_date,
# MAGIC          platform,
# MAGIC          dbu,
# MAGIC          dbu_price,
# MAGIC          revShareDollars,
# MAGIC          custDollars,
# MAGIC          rolling_sum_revshare_dollars,
# MAGIC          rolling_sum_cust_dollars
# MAGIC from complimentary_corrected_consumption
# MAGIC order by date, dbu
# MAGIC )
# MAGIC
# MAGIC select aggorder,
# MAGIC        dbshareCommit,
# MAGIC        complimentary_usage,
# MAGIC        flexOrder,
# MAGIC        flexCommit,
# MAGIC        universalOrder,
# MAGIC        universalCommit,
# MAGIC        coterm_order,
# MAGIC        coterm_dbshare_commit,
# MAGIC        ActualPartnerCommit,
# MAGIC        accountId,
# MAGIC        contract_id,
# MAGIC        order_id,
# MAGIC        coterm_startDate,
# MAGIC        startDate,
# MAGIC        endDate,
# MAGIC        renewal_opportunity,
# MAGIC        workspaceId,
# MAGIC        businessSubscriptionID,
# MAGIC        sku,
# MAGIC        date,
# MAGIC        month_end_date,
# MAGIC        platform,
# MAGIC        dbu,
# MAGIC        dbu_price,
# MAGIC        revShareDollars,
# MAGIC        custDollars,
# MAGIC --        rolling_sum_revshare_dollars,
# MAGIC --        rolling_sum_cust_dollars,
# MAGIC        sum(revShareDollars) over(partition by accountId, platform, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_revshare_dollars,
# MAGIC        sum(custDollars) over(partition by accountId, platform, aggOrder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) rolling_sum_cust_dollars
# MAGIC
# MAGIC from base
# MAGIC order by date, dbu

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists corrected_order_consumption

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view corrected_order_consumption
# MAGIC as
# MAGIC with base (
# MAGIC select   case when (rolling_sum_revshare_dollars <= dbShareCommit or flexCommit = 0) and coterm_order is null then aggOrder
# MAGIC               when (rolling_sum_revshare_dollars <= coterm_dbshare_commit or flexCommit = 0) and coterm_order is not null then aggOrder 
# MAGIC               else flexOrder
# MAGIC          end as correctedAggorder,
# MAGIC          *
# MAGIC from coterm_corrected_consumption
# MAGIC order by date, dbu
# MAGIC )
# MAGIC
# MAGIC select correctedAggorder,
# MAGIC        aggorder,
# MAGIC        dbshareCommit,
# MAGIC        complimentary_usage,
# MAGIC        flexOrder,
# MAGIC        flexCommit,
# MAGIC        universalOrder,
# MAGIC        universalCommit,
# MAGIC        coterm_order,
# MAGIC        coterm_dbshare_commit,       
# MAGIC        ActualPartnerCommit,
# MAGIC        accountId,
# MAGIC        contract_id,
# MAGIC        order_id,
# MAGIC        coterm_startDate,       
# MAGIC        startDate,
# MAGIC        endDate,
# MAGIC        renewal_opportunity,
# MAGIC        workspaceId,
# MAGIC        businessSubscriptionID,
# MAGIC        sku,
# MAGIC        date,
# MAGIC        month_end_date,
# MAGIC        platform,
# MAGIC        dbu,
# MAGIC        dbu_price,
# MAGIC        revShareDollars,
# MAGIC        custDollars,
# MAGIC        rolling_sum_revshare_dollars,
# MAGIC        rolling_sum_cust_dollars,
# MAGIC        sum(revShareDollars) over(partition by accountId, platform, correctedAggorder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) corrected_rolling_sum_cloud_revshare,
# MAGIC        sum(revShareDollars) over(partition by accountId, correctedAggorder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) corrected_rolling_sum_total_revshare,
# MAGIC
# MAGIC        sum(custDollars) over(partition by accountId, platform, correctedAggorder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) corrected_rolling_sum_cloud_cust,
# MAGIC        sum(custDollars) over(partition by accountId, correctedAggorder order by date, dbu ROWS BETWEEN UNBOUNDED PRECEDING AND current row ) corrected_rolling_sum_total_cust
# MAGIC
# MAGIC from base
# MAGIC order by date, dbu

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists burn_consumption

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view burn_consumption
# MAGIC as
# MAGIC with parallel_consumption as (
# MAGIC select *,
# MAGIC        case when correctedAggorder not like 'FLEX%' and correctedAggorder not like '%COMPLIMENTARY%' and correctedAggorder not like '%CO-TERM%' then corrected_rolling_sum_cloud_revshare / dbShareCommit * 100
# MAGIC             when correctedAggorder like '%COMPLIMENTARY%' then corrected_rolling_sum_cloud_revshare / complimentary_usage * 100
# MAGIC             when correctedAggorder like '%CO-TERM%' then corrected_rolling_sum_cloud_revshare / coterm_dbshare_commit * 100            
# MAGIC             else 0 end burn,
# MAGIC        case when correctedAggorder like 'FLEX%' then corrected_rolling_sum_cloud_revshare / flexCommit * 100
# MAGIC             else 0 end cloudFlexBurn,
# MAGIC        case when correctedAggorder like 'FLEX%' then corrected_rolling_sum_cloud_revshare / flexCommit * 100
# MAGIC             else 0 end FlexBurn            
# MAGIC from corrected_order_consumption
# MAGIC )
# MAGIC
# MAGIC select distinct *
# MAGIC from parallel_consumption

# COMMAND ----------

burn_consumption = spark.sql(""" select * from burn_consumption""")
burn_consumption.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_CONSUMPTION_DAILY_STG)

# COMMAND ----------

burn_consumption = spark.sql(f""" select * from {USAGEC_CONSUMPTION_DAILY_STG}""")
burn_consumption.createOrReplaceTempView("burn_consumption")
burn_consumption_stg = burn_consumption.withColumn('date', col('date').cast('date'))\
                                   .withColumn('month_end_date', col('month_end_date').cast('date'))
burn_consumption_stg.write.option("overwriteSchema", "true").format("delta").mode("append").save(ORDER_CONSUMPTION_DAILY_STAGING_LOCATION)


# COMMAND ----------

burn_consumption_full = spark.read.format('delta').load(ORDER_CONSUMPTION_DAILY_STAGING_LOCATION)
burn_consumption_full.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_CONSUMPTION_DAILY)

# COMMAND ----------

# DBTITLE 1,SFDC Push
# MAGIC %sql
# MAGIC drop view if exists order_consumption

# COMMAND ----------

spark.sql(f"""
create temp view order_consumption
as 
with base (
select universalOrder,
       correctedAggorder AggOrder__c,
       aggOrder actual_aggorder__c,
       b.accountId Account_Id__c,
       b.platform,
       acc.accountName Account_Name,
       contract_id Contract__c,
       order_id Order__c,
       renewal_opportunity Renewal_Opportunity__c,
       startDate Start_Date__c,
       endDate End_Date__c,
       max(ActualPartnerCommit) Discounted_Commit__c,
       max(dbshareCommit) RevShare_Commit__c,
       max(complimentary_usage) complimentary_usage,
       max(coterm_dbshare_commit) coterm_dbshare_commit,
       max(flexCommit)  flexCommit,
       sum(revShareDollars) RevShare_Dollars__c,
       sum(custDollars) Cust_Dollars__c,
       round(max(burn),6) PercBurn__c,
       round(max(cloudFlexBurn),6) Flex_Burn__c,
       round(max(flexBurn),6) total_flex_burn,
       max(date) max_consumption_date,
       max(coterm_startDate) coterm_startDate
from burn_consumption b
join {ACCOUNT_DIM} acc on b.accountId = acc.accountId
group by 1,2,3,4,5,6,7,8,9,10,11
order by Account_Id__c, platform, AggOrder__c
),

flexed_consumption (
select universalOrder,
       AggOrder__c,
       actual_aggorder__c,
       platform,
       Account_Id__c,
       Account_Name,
       Contract__c,
       Order__c,
       Renewal_Opportunity__c,
       case when AggOrder__c like '%CO-TERM%' then coterm_startDate else Start_Date__c end corrected_Start_Date__c,
       Start_Date__c,
       End_Date__c,
       case when AggOrder__c like 'FLEX%' then flexCommit 
            when AggOrder__c like '%COMPLIMENTARY%' then complimentary_usage
            when AggOrder__c like '%CO-TERM%' then coterm_dbshare_commit           
            else Discounted_Commit__c end Discounted_Commit__c,
       case when AggOrder__c like 'FLEX%' then flexCommit 
            when AggOrder__c like '%COMPLIMENTARY%' then complimentary_usage
            when AggOrder__c like '%CO-TERM%' then coterm_dbshare_commit             
            else RevShare_Commit__c end RevShare_Commit__c,   
       RevShare_Dollars__c,
       Cust_Dollars__c,
       case when AggOrder__c like 'FLEX%' then Flex_Burn__c else PercBurn__c end PercBurn__c,  
       max(Flex_Burn__c) over(partition by actual_aggorder__c, platform) corrected_flex_burn,
       PercBurn__c Actual_PercBurn__c,
       Flex_Burn__c Actual_Flex_Burn__c,
       total_flex_burn
from base  
)

select universalOrder Universal_Agg_Order__c,
       AggOrder__c,
       actual_aggorder__c,
       lower(platform) platform,
       Account_Id__c,
       Account_Name,
       Contract__c,
       Order__c,
       Renewal_Opportunity__c,
       Start_Date__c,
       End_Date__c,
       Discounted_Commit__c,
       RevShare_Commit__c,   
       RevShare_Dollars__c CumRevShareDollars__c,
       Cust_Dollars__c CumCustDollars__c,
       PercBurn__c,  
       case when AggOrder__c like 'FLEX%' then 0 else corrected_flex_burn end Flex_Burn__c,
       Actual_PercBurn__c,
       Actual_Flex_Burn__c,
       total_flex_burn       
from flexed_consumption     
order by Account_Id__c, AggOrder__c
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists order_consumption_full

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view non_azure_order_consumption_full 
# MAGIC as
# MAGIC select coalesce(c.Universal_Agg_Order__c, o.UniversalOrder) Universal_Agg_Order__c,
# MAGIC        coalesce(c.AggOrder__c, o.aggorder) AggOrder__c,
# MAGIC        --actual_aggorder__c,
# MAGIC        coalesce(c.platform, o.platform) platform,
# MAGIC        coalesce(c.Account_Id__c, o.sfdcAccountId) Account_Id__c,
# MAGIC        coalesce(c.Account_Name, o.sfdcAccountName) Account_Name,
# MAGIC        coalesce(c.Contract__c, o.contract_id) Contract__c,
# MAGIC        coalesce(c.Order__c, o.order_id) Order__c,
# MAGIC        coalesce(c.Renewal_Opportunity__c, o.renewal_opportunity) Renewal_Opportunity__c,
# MAGIC        coalesce(c.Start_Date__c, o.startDate) Start_Date__c,
# MAGIC        coalesce(c.End_Date__c, o.endDate) End_Date__c,
# MAGIC        coalesce(c.Discounted_Commit__c, o.ActualPartnerCommit) Discounted_Commit__c,
# MAGIC        coalesce(c.RevShare_Commit__c, o.DBShareCommit) RevShare_Commit__c,   
# MAGIC        coalesce(c.CumRevShareDollars__c, 0) CumRevShareDollars__c,
# MAGIC        coalesce(c.CumCustDollars__c, 0) CumCustDollars__c,
# MAGIC        coalesce(c.PercBurn__c, 0) PercBurn__c,  
# MAGIC        coalesce(c.Flex_Burn__c, 0) Flex_Burn__c
# MAGIC --        Actual_PercBurn__c,
# MAGIC --        Actual_Flex_Burn__c,
# MAGIC --        total_flex_burn       
# MAGIC
# MAGIC from orders_base o
# MAGIC left join order_consumption c on o.sfdcAccountId = c.account_id__c and o.aggorder = c.aggorder__c

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view azure_order_consumption_full 
# MAGIC as
# MAGIC select coalesce(c.Universal_Agg_Order__c, o.UniversalOrder) Universal_Agg_Order__c,
# MAGIC        coalesce(c.AggOrder__c, o.aggorder) AggOrder__c,
# MAGIC        --actual_aggorder__c,
# MAGIC        coalesce(c.platform, o.platform) platform,
# MAGIC        coalesce(c.Account_Id__c, o.sfdcAccountId) Account_Id__c,
# MAGIC        coalesce(c.Account_Name, o.sfdcAccountName) Account_Name,
# MAGIC        coalesce(c.Contract__c, o.contract_id) Contract__c,
# MAGIC        coalesce(c.Order__c, o.order_id) Order__c,
# MAGIC        coalesce(c.Renewal_Opportunity__c, o.renewal_opportunity) Renewal_Opportunity__c,
# MAGIC        coalesce(c.Start_Date__c, o.startDate) Start_Date__c,
# MAGIC        coalesce(c.End_Date__c, o.endDate) End_Date__c,
# MAGIC        coalesce(c.Discounted_Commit__c, o.ActualPartnerCommit) Discounted_Commit__c,
# MAGIC        coalesce(c.RevShare_Commit__c, o.DBShareCommit) RevShare_Commit__c,   
# MAGIC        coalesce(c.CumRevShareDollars__c, 0) CumRevShareDollars__c,
# MAGIC        coalesce(c.CumCustDollars__c, 0) CumCustDollars__c,
# MAGIC        coalesce(c.PercBurn__c, 0) PercBurn__c,  
# MAGIC        coalesce(c.Flex_Burn__c, 0) Flex_Burn__c
# MAGIC --        Actual_PercBurn__c,
# MAGIC --        Actual_Flex_Burn__c,
# MAGIC --        total_flex_burn       
# MAGIC
# MAGIC from orders_base_azure o
# MAGIC left join order_consumption c on o.sfdcAccountId = c.account_id__c and o.aggorder = c.aggorder__c

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view order_consumption_full
# MAGIC as
# MAGIC
# MAGIC select *
# MAGIC from azure_order_consumption_full
# MAGIC union
# MAGIC select *
# MAGIC from non_azure_order_consumption_full

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists order_consumption_aggorders

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view order_consumption_aggorders
# MAGIC as
# MAGIC select AggOrder__c,
# MAGIC        Account_Id__c,
# MAGIC        first(Universal_Agg_Order__c) Universal_Agg_Order__c,
# MAGIC        first(Account_Name) Account_Name,
# MAGIC        first(Contract__c) Contract__c,
# MAGIC        first(Order__c) Order__c,
# MAGIC        first(Renewal_Opportunity__c) Renewal_Opportunity__c,
# MAGIC        max(Start_Date__c) Start_Date__c,
# MAGIC        max(End_Date__c) End_Date__c,
# MAGIC        max(Discounted_Commit__c) Discounted_Commit__c,
# MAGIC        max(RevShare_Commit__c) RevShare_Commit__c,
# MAGIC        sum(CumRevShareDollars__c) CumRevShareDollars__c,
# MAGIC        sum(CumCustDollars__c) CumCustDollars__c
# MAGIC from   order_consumption_full
# MAGIC --where Account_Id__c = '0016100000U5DnLAAV'
# MAGIC group by AggOrder__c, Account_Id__c

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists order_consumption_universal_parallel

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view order_consumption_universal_parallel
# MAGIC as
# MAGIC with universal_orders_base (
# MAGIC select  null Universal_Agg_Order__c,
# MAGIC         Universal_Agg_Order__c AggOrder__c,
# MAGIC         Universal_Agg_Order__c Unique_Id__c,
# MAGIC         Contract__c,
# MAGIC         Renewal_Opportunity__c,
# MAGIC         Account_Id__c,
# MAGIC --        concat(AggOrder__c,'-',Account_Id__c,'-', Start_Date__c) universal_unique_key,
# MAGIC         min(Start_Date__c) Start_Date__c,
# MAGIC         max(End_Date__c) End_Date__c,
# MAGIC         sum(Discounted_Commit__c) Discounted_Commit__c,
# MAGIC         sum(RevShare_Commit__c) RevShare_Commit__c,
# MAGIC         round(sum(CumCustDollars__c),0) CumCustDollars__c,
# MAGIC         round(sum(CumRevShareDollars__c),0) CumRevShareDollars__c,
# MAGIC         round(sum(CumRevShareDollars__c)/sum(RevShare_Commit__c)*100,2) PercBurn__c,
# MAGIC         0 Flex_Burn__c
# MAGIC from order_consumption_aggorders
# MAGIC where AggOrder__c  not like '%COMPLIMENTARY%'
# MAGIC group by 1,2,3,4,5,6
# MAGIC )
# MAGIC
# MAGIC select concat(u.AggOrder__c,'-',u.Account_Id__c,'-', u.Start_Date__c) universal_unique_key,
# MAGIC        u.*
# MAGIC from universal_orders_base u

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists aggregated_order_consumption

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view aggregated_order_consumption 
# MAGIC as
# MAGIC select 
# MAGIC        Universal_Agg_Order__c,
# MAGIC        AggOrder__c,
# MAGIC        Contract__c,
# MAGIC        Order__c,
# MAGIC        Renewal_Opportunity__c,       
# MAGIC        Account_Id__c,
# MAGIC        Start_Date__c,
# MAGIC        End_Date__c,
# MAGIC        max(Discounted_Commit__c) Discounted_Commit__c,
# MAGIC        max(RevShare_Commit__c) RevShare_Commit__c,
# MAGIC        sum(CumRevShareDollars__c) CumRevShareDollars__c,
# MAGIC        sum(CumCustDollars__c) CumCustDollars__c,
# MAGIC        sum(PercBurn__c) PercBurn__c,
# MAGIC        sum(Flex_Burn__c) Flex_Burn__c
# MAGIC from order_consumption_full
# MAGIC group by 1,2,3,4,5,6,7,8

# COMMAND ----------

CONSUMPTION_RECORD_TYPE_UAT = "012560000039K5AAAU"
CONSUMPTION_RECORD_TYPE_STG = "0124C000000MG5IQAW"
CONSUMPTION_RECORD_TYPE_PRD = "0128Y000001lHMwQAM"

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from order_consumption_universal_parallel
# MAGIC where aggOrder__c in (
# MAGIC
# MAGIC  select aggOrder__c from (
# MAGIC     select aggOrder__c,
# MAGIC            Account_Id__c,
# MAGIC            Start_Date__c,
# MAGIC            count(*) cnt
# MAGIC     from order_consumption_universal_parallel
# MAGIC     group by 1,2,3
# MAGIC     having cnt > 1 )
# MAGIC )       

# COMMAND ----------

universal_aggorder_upsert_spark = spark.sql(""" select * from order_consumption_universal_parallel """)
universal_aggorder_upsert_spark = universal_aggorder_upsert_spark.withColumn('Start_Date__c', col('Start_Date__c').cast('string'))\
                                                                 .withColumn('End_Date__c', col('End_Date__c').cast('string'))\
                                                                 .drop('Flex_Burn__c','Unique_Id__c','Universal_Agg_Order__c')\
                                                                 .withColumnRenamed('universal_unique_key','Unique_Id__c')

# COMMAND ----------

universal_aggorder_upsert_spark.count()

# COMMAND ----------

universal_aggorder_upsert_df = universal_aggorder_upsert_spark.toPandas()

# COMMAND ----------

universal_aggorder_upsert_df = universal_aggorder_upsert_df.replace({np.nan: None})
universal_aggorder_upsert_df['RecordTypeId'] = universal_aggorder_upsert_df.apply(lambda row: CONSUMPTION_RECORD_TYPE_PRD, axis=1)
universal_aggorder_upsert_df = universal_aggorder_upsert_df.reindex(sorted(universal_aggorder_upsert_df.columns), axis=1)
universal_aggorder_upsert_data = [val for val in universal_aggorder_upsert_df.T.to_dict().values()]
print(len(universal_aggorder_upsert_data), universal_aggorder_upsert_data[0])

# COMMAND ----------

# universal_aggorder_upsert_spark = spark.sql(""" select * from order_consumption_universal_parallel """)
# universal_aggorder_upsert_spark = universal_aggorder_upsert_spark.withColumn('Start_Date__c', col('Start_Date__c').cast('string'))\
#                                                                  .withColumn('End_Date__c', col('End_Date__c').cast('string'))\
#                                                                  .drop('Flex_Burn__c','Unique_Id__c','Universal_Agg_Order__c')\
#                                                                  .withColumnRenamed('universal_unique_key','Unique_Id__c')
# universal_aggorder_upsert_df = universal_aggorder_upsert_spark.toPandas()
# universal_aggorder_upsert_df = universal_aggorder_upsert_df.replace({np.nan: None})
# universal_aggorder_upsert_df['RecordTypeId'] = universal_aggorder_upsert_df.apply(lambda row: CONSUMPTION_RECORD_TYPE_PRD, axis=1)
# universal_aggorder_upsert_df = universal_aggorder_upsert_df.reindex(sorted(universal_aggorder_upsert_df.columns), axis=1)
# universal_aggorder_upsert_data = [val for val in universal_aggorder_upsert_df.T.to_dict().values()]
# print(len(universal_aggorder_upsert_data), universal_aggorder_upsert_data[0])

# COMMAND ----------

if environment == 'production':
  creds = get_creds('sfdcprod')
  sf = get_sfdc_connection(creds, 'login')
  out = sf.bulk.Consumption__c.upsert(data=universal_aggorder_upsert_data, external_id_field='Unique_Id__c', batch_size=1000)

  success, failure, total = 0, 0, 0
  for o in out:
    if len(o['errors']) > 0:
      #print(o['errors'][0]['message'])
      failure += 1
    else:
      success += 1
    total += 1
  print(success, failure, total)

# COMMAND ----------

universal_id_soql = """ SELECT Account_Id__c, AggOrder__c, Id, Unique_Id__c FROM Consumption__c WHERE RecordTypeId = '{0}' AND AggOrder__c LIKE '%UNIVERSAL-COMMIT%' """.format(CONSUMPTION_RECORD_TYPE_PRD)
universal_ids = get_spark_dataframe(universal_id_soql, 'sfdcprod', 'login') #get_spark_dataframe(universal_id_soql, 'stg', 'test')
universal_ids.createOrReplaceTempView('universal_ids')

# COMMAND ----------

aggorder_upsert_spark = spark.sql("""
select u.Id Universal_Agg_Order__c,
      o.AggOrder__c,
      case when lower(o.AggOrder__c) like 'aws-mp-commit-co-term%' then 'AWS-MP-CO-TERM-COMMIT'
           when lower(o.AggOrder__c) like 'aws-mp-commit%' then 'AWS-MP-COMMIT'
           when lower(o.AggOrder__c) like 'aws-commit%' then 'AWS-COMMIT'
           when lower(o.AggOrder__c) like 'flex-commit%' then 'FLEX-COMMIT'
           when lower(o.AggOrder__c) like 'azure-commit%' then 'AZURE-COMMIT'  
           when lower(o.AggOrder__c) like 'gcp-mp-commit%' then 'GCP-MP-COMMIT'
           when lower(o.AggOrder__c) like 'gcp-commit%' then 'GCP-COMMIT'
           when lower(o.AggOrder__c) like '%co-term%' then 'CO-TERM-COMMIT'
           when lower(o.AggOrder__c) like 'aws-complimentary%' then 'AWS-COMPLIMENTARY'
           when lower(o.AggOrder__c) like 'gcp-complimentary%' then 'GCP-COMPLIMENTARY'
           else o.AggOrder__c end ConsumptionType__c,
      o.Account_Id__c,
      o.Start_Date__c,
      o.End_Date__c,
      o.Discounted_Commit__c,
      o.RevShare_Commit__c,
      o.CumRevShareDollars__c,
      o.CumCustDollars__c,
      o.PercBurn__c,
      o.Flex_Burn__c,
      o.Contract__c,
      o.Order__c,
      concat(o.Account_Id__c, '-', o.AggOrder__c, '-', coalesce(o.Contract__c, 'NA'), '-', coalesce(o.Order__c, 'NA'), '-', coalesce(Start_Date__c, '2999-01-01')) Unique_Id__c
from aggregated_order_consumption o
join universal_ids u on o.Universal_Agg_Order__c = u.aggOrder__c and o.account_id__c = u.account_id__c
""")

aggorder_upsert_spark = aggorder_upsert_spark.withColumn('Start_Date__c', col('Start_Date__c').cast('string'))\
                                             .withColumn('End_Date__c', col('End_Date__c').cast('string'))
aggorder_upsert_df = aggorder_upsert_spark.toPandas()
aggorder_upsert_df = aggorder_upsert_df.replace({np.nan: None})
aggorder_upsert_df['RecordTypeId'] = aggorder_upsert_df.apply(lambda row: CONSUMPTION_RECORD_TYPE_PRD, axis=1)
aggorder_upsert_df = aggorder_upsert_df.reindex(sorted(aggorder_upsert_df.columns), axis=1)
aggorder_upsert_data = [val for val in aggorder_upsert_df.T.to_dict().values()]

# COMMAND ----------

if environment == 'production':
  creds = get_creds('sfdcprod')
  sf = get_sfdc_connection(creds, 'login')
  aggorder_out = sf.bulk.Consumption__c.upsert(data=aggorder_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)

  success, failure, total = 0, 0, 0
  for o in aggorder_out:
    if len(o['errors']) > 0:
      #print('counter ', total)
      #print(o['errors'][0]['message'])
      failure += 1
    else:
      success += 1
    total += 1
  print(success, failure, total)
