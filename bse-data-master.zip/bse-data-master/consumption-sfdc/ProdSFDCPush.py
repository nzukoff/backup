# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

# MAGIC %sh
# MAGIC pip install simple-salesforce

# COMMAND ----------

from simple_salesforce import Salesforce
import pandas as pd
import numpy as np

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

from datetime import datetime
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

# MAGIC %md
# MAGIC #### set up salesforce

# COMMAND ----------

def get_creds(prefix):
  """
  params:
         prefix - 'uat' for uat, 'lfsf' for prod
  returns:
         list of user_name, password, security_token, client_id, client_secret
  """
  username = dbutils.secrets.get('api-creds', prefix+'_username')
  password = dbutils.secrets.get('api-creds', prefix+'_password')
  consumer_key = dbutils.secrets.get('api-creds', prefix+'_consumer_key')
  privatekey_file=dbutils.secrets.get('api-creds', prefix+'_privatekey_location')
  return [username, password, consumer_key, privatekey_file]


def get_sfdc_connection(creds, domain):
  """
  params:
         creds - connection credentials
         domain - 'test' for uat, 'login' for prod
  returns:
         sfdc connection object
  """
  return Salesforce(username=creds[0], \
                    password=creds[1], \
                    consumer_key=creds[2], \
                    privatekey_file=creds[3], \
                    domain=domain)


def get_dataframe(query, environement_prefix, domain):

    """
    calls get_creds, get_sfdc_connection functions
    uses salesforce's soql query api 
    params: query, environement_prefix, domain
    returns: pandas dataframe
    """
  
    creds = get_creds(environement_prefix)
    sf = get_sfdc_connection(creds, domain)
    
    list_data_records = []
    data = sf.query(query)
    list_data_records = data['records']
    prev_counter = 0
    cur_counter = 0
    while 'nextRecordsUrl' in data.keys():
        next_record = data['nextRecordsUrl'].split('/')[-1]
        data = sf.query_more(next_record)
        list_data_records += data['records']
        if cur_counter-prev_counter >= 50000:
          prev_counter = cur_counter
          sf = get_sfdc_connection(creds, domain) # connection reset
        cur_counter = len(list_data_records)
    return pd.DataFrame(list_data_records).drop(columns='attributes')
  
  
import numpy as np
import pandas as pd
from pyspark.sql.types import *
pandas_spark_types_map = {
                    np.int8: ByteType(),
                    np.uint8: ShortType(),
                    np.int16: ShortType(),
                    np.uint16: IntegerType(),
                    np.int32: IntegerType(),
                    np.int64: LongType(),
                    np.float32: FloatType(),
                    np.float64: DoubleType(),
                    np.string_: StringType(),
                    np.str_: StringType(),
                    np.unicode_: StringType(),
                    np.bool_: BooleanType(),
                    np.object_: StringType()
                }

def build_spark_schema(numpy_dtypes):
    """
    takes pandas dtypes and converts to Spark Schema
    parms: numpy_dtypes, pandas_spark_types_map
    returns: Pyspark Schema
    """
    return StructType([StructField(col_name, pandas_spark_types_map[col_type.type], True) for col_name, col_type in numpy_dtypes.iteritems()])

# COMMAND ----------

# DBTITLE 1,PoP Metrics
# <D><AccountId>:<AggOrder>:<YYYYMMDD>
@udf("String")
def popUniqueId(accountId, platform):
  return accountId + ":" + platform

pop_rename_column_map = {
  "accountId" : "Account_Id__c",
  "AutomatedForecastDBUs" : "AutomatedForecastDBU__c",
  "AutomatedDBUs": "Automated_DBUs__c",
  "cumAutomatedDBUs": "CumAutomatedDBU__c",
  "cumAutomatedForecastDBUs" : "CumAutomatedFcstDBU__c",
  "cumCustDollars" : "CumCustDollars__c",
  "cumCustForecastDollars" : "CumCustFcstDollars__c",
  "cumInteractiveDBUs" : "CumInteractiveDBU__c",
  "cumInteractiveForecastDBUs" : "CumInteractiveFcstDBU__c",
  "cumListDollars" : "CumListDollars__c",
  "cumListForecastDollars" : "CumListFcstDollars__c",
  "cumRevShareDollars" : "CumRevShareDollars__c",
  "cumRevShareForecastDollars" : "CumRevShareFcstDollars__c",
  "custForecastDollars" : "CustForecastDollars__c",
  "custDollars" : "Cust_Dollars__c",
  "DBUs": "ActualDBUs__c",
  "DiscountedCommit": "Discounted_Commit__c",
  "InteractiveForecastDBUs" : "InteractiveForecastDBU__c",
  "InteractiveDBUs" : "Interactive_DBUs__c",
  "listForecastDollars" : "ListForecastDollars__c",
  "ListCommit" : "List_Commit__c",
  "listDollars" : "List_Dollars__c",
  "platform" : "Platform__c",
  "revShareForecastDollars" : "RevShareForecastDollars__c",
  "RevShareCommit" : "RevShare_Commit__c",
  "revShareDollars" : "RevShare_Dollars__c",
  "RevShareLastWeek" : "RevShareLastWeek__c",
  "RevShareCurrentWeek" : "RevShareCurrentWeek__c",
  "RevShareNextWeek" : "RevShareFsctNextWeek__c",
  "RevShareLastMonth" : "RevShareLastMonth__c",
  "RevShareCurrentMonth" : "RevShareCurrentMonth__c",
  "RevShareNextMonth" : "RevShareFcstNextMonth__c",
  "RevShareLastQtr" : "RevShareLastQtr__c",
  "RevShareCurrentQtr" : "RevShareCurrentQtr__c",
  "RevShareNextQtr" : "RevShareFcstNextQtr__c",
  "RevShareDollarsQTD": "RevShareDollarsQTD__c",
  "RevShareDollarsMTD": "RevShareDollarsMTD__c",
  "RevShareDollarsWTD": "RevShareDollarsWTD__c",  
  "month_end_date" : "Usage_Date__c",
  "DeltaRevShareDollars": "DeltaRevShareDollars__c",
  "DeltaAutomatedDBUs": "DeltaAutomatedDBU__c",
  "DeltaInteractiveDBUs": "DeltaInteractiveDBU__c",
  "cumDeltaAutomatedDBUs":"cumDeltaAutomatedDBUs__c",
  "cumDeltaInteractiveDBUs":"cumDeltaInteractiveDBUs__c",
  "cumDeltaRevShareDollars":"cumDeltaRevShareDollars__c",  
  "T3MRevShareDollars": "T3MRevShareDollars__c",
  "T3MEnterpriseDBUs":"T3MEnterpriseDBU__c",
  "T3MPremiumDBUs":"T3MPremiumDBU__c",
  "T3MStandardDBUs":"T3MStandarsDBU__c",
  "T3MEnterpriseRevShareDollars":"T3MEnterpriseRevShare__c",
  "T3MPremiumRevShareDollars":"T3MPremiumRevShare__c",
  "T3MStandardRevShareDollars":"T3MStandardRevShare__c",  
  "SQLAnalyticsDBUs":"SQLAnalyticsDBU__c",
  "SQLAnalyticsForecastDBUs":"SQLAnalyticsFcstDBU__c",
  "SQLRevShareDollars":"SQLRevShareDollars__c",
  "SQLRevShareForecastDollars":"SQLRevShareFcstDollars__c",
  "cumSQLAnalyticsDBUs":"CumSQLAnalyticsDBU__c",
  "cumSQLAnalyticsForecastDBUs":"CumSQLAnalyticsFcstDBU__c",
  "cumSQLRevShareDollars":"CumSQLRevShareDollars__c",
  "cumSQLRevShareForecastDollars":"CumSQLRevShareFcstDollars__c",
  "Unique_Id__c":"Unique_Id__c"
}

# COMMAND ----------

popdf = spark.sql(f"""
select *
from {USAGEC_POPMETRICS}
""")

popdf = popdf.withColumn("SQLAnalyticsForecastDBUs", col("SQLAnalyticsForecastDBUs").cast("double"))\
             .withColumn("SQLRevShareForecastDollars", col("SQLRevShareForecastDollars").cast("double"))\
             .withColumn("cumSQLAnalyticsForecastDBUs", col("cumSQLAnalyticsForecastDBUs").cast("double"))\
             .withColumn("cumSQLRevShareForecastDollars", col("cumSQLRevShareForecastDollars").cast("double"))

popdf = popdf.drop("accountName")
popdf = popdf.dropDuplicates()


popdf = popdf.withColumn("Unique_Id__c", popUniqueId("accountId", "platform"))\
             .withColumn("month_end_date", col("month_end_date").cast("string"))\
             .drop("accountName")
pop = popdf.toPandas()
pop = pop.replace({np.nan: 0.0})

pop = pop[sorted(pop_rename_column_map.keys())]
pop = pop.rename(columns = pop_rename_column_map)
pop['RecordTypeId'] = pop.apply(lambda row: "0123f000000XdGcAAK", axis=1)
pop = pop.reindex(sorted(pop.columns), axis=1)
upsert_pop = pop.copy()

pop_upsert_data = [val for val in upsert_pop.T.to_dict().values()]
print(upsert_pop.shape)

# COMMAND ----------

if environment == 'production':
  try:
    creds = get_creds('sfdcprod')
    sf = get_sfdc_connection(creds, 'login')
    sf.bulk.Consumption__c.upsert(data=pop_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)
  except Exception as e:
    print("PoP Metrics:", e)
  #sf.bulk.Consumption__c.upsert(pop_upsert_data, 'Unique_Id__c')

# COMMAND ----------

# DBTITLE 1,Daily Map
# <D><AccountId>:<AggOrder>:<YYYYMMDD>
@udf("String")
def dailyUniqueId(accountId, aggOrder, usage_date):
  return "D:" + accountId + ":" + aggOrder + ":" + str(usage_date)

daily_rename_column_map = {
  "accountId" : "Account_Id__c",
  "aggOrder" : "AggOrder__c",
  "AutomatedForecastDBUs" : "AutomatedForecastDBU__c",
  "AutomatedDBUs": "Automated_DBUs__c",
  "consumptionType": "ConsumptionType__c",
  "cumAutomatedDBUs": "CumAutomatedDBU__c",
  "cumAutomatedForecastDBUs" : "CumAutomatedFcstDBU__c",
  "cumCustDollars" : "CumCustDollars__c",
  "cumCustForecastDollars" : "CumCustFcstDollars__c",
  "cumInteractiveDBUs" : "CumInteractiveDBU__c",
  "cumInteractiveForecastDBUs" : "CumInteractiveFcstDBU__c",
  "cumListDollars" : "CumListDollars__c",
  "cumListForecastDollars" : "CumListFcstDollars__c",
  "cumRevShareDollars" : "CumRevShareDollars__c",
  "cumRevShareForecastDollars" : "CumRevShareFcstDollars__c",
  "custForecastDollars" : "CustForecastDollars__c",
  "custDollars" : "Cust_Dollars__c",
  "DBUs": "ActualDBUs__c",
  "DiscountedCommit": "Discounted_Commit__c",
  "endDate" : "End_Date__c",
  "InteractiveForecastDBUs" : "InteractiveForecastDBU__c",
  "InteractiveDBUs" : "Interactive_DBUs__c",
  "listForecastDollars" : "ListForecastDollars__c",
  "ListCommit" : "List_Commit__c",
  "listDollars" : "List_Dollars__c",
  "pctBurn" : "PercBurn__c",
  "platform" : "Platform__c",
  "revShareForecastDollars" : "RevShareForecastDollars__c",
  "RevShareCommit" : "RevShare_Commit__c",
  "revShareDollars" : "RevShare_Dollars__c",
  "startDate" : "Start_Date__c",
  "usage_date" : "Usage_Date__c",
  "actualBurstDate" : "ActualBurstDate__c",
  "expectedBurstDate" : "ExpectedBurstDate__c",
  "DeltaRevShareDollars": "DeltaRevShareDollars__c",
  "DeltaAutomatedDBUs": "DeltaAutomatedDBU__c",
  "DeltaInteractiveDBUs": "DeltaInteractiveDBU__c",
  "cumDeltaAutomatedDBUs":"cumDeltaAutomatedDBUs__c",
  "cumDeltaInteractiveDBUs":"cumDeltaInteractiveDBUs__c",
  "cumDeltaRevShareDollars":"cumDeltaRevShareDollars__c",
  "SQLAnalyticsDBUs":"SQLAnalyticsDBU__c",
  "SQLAnalyticsForecastDBUs":"SQLAnalyticsFcstDBU__c",
  "SQLRevShareDollars":"SQLRevShareDollars__c",
  "SQLRevShareForecastDollars":"SQLRevShareFcstDollars__c",
  "ISVDBUs":"ISV_DBUs__c",
  "ISVRevShareDollars":"ISV_RevShareDollars__c",   
  "ServerlessDBUs":"ServerlessDBUs__c",
  "ServerlessRevShareDollars":"ServerlessRevShare__c",
  "PhotonDBUs":"PhotonDBUs__c",
  "PhotonRevShareDollars":"PhotonRevShare__c",
  "DLTDBUs":"DLTDBUs__c",
  "DLTRevShareDollars":"DLTRevShare__c",
  "MoonCakeSQLDBUs":"MoonCakeSQLDBUs__c",  
  "MoonCakeSQLDollars":"MoonCakeSQLRevShare__c",
  "cumSQLAnalyticsDBUs":"CumSQLAnalyticsDBU__c",
  "cumSQLAnalyticsForecastDBUs":"CumSQLAnalyticsFcstDBU__c",
  "cumSQLRevShareDollars":"CumSQLRevShareDollars__c",
  "cumSQLRevShareForecastDollars":"CumSQLRevShareFcstDollars__c",
  "Unique_Id__c":"Unique_Id__c",
  "MCTRevShareDollars": "MCTRevShareDollars__c"
}

# COMMAND ----------

# rowCommitAccounts = spark.sql("select distinct accountId from bdw.usagec_aggorder_daily where consumptionType = 'Commit'").collect()
# commitAccountIds = [row.accountId for row in rowCommitAccounts]
# print(len(commitAccountIds))
# commitAccounts = spark.sql("select distinct accountId from bdw.usagec_aggorder_daily where consumptionType = 'Commit'")
# commitAccounts.createOrReplaceTempView("commitAccounts")

# COMMAND ----------

# def upsert_account(accountId,daily_rename_column_map):
#     df = spark.sql("""
#     select d.*
#     from bdw.usagec_aggorder_daily d
#     where accountId = "{0}"
#     """.format(accountId)
#     )
#     df = df.withColumn("Unique_Id__c", dailyUniqueId("accountId", "aggOrder", "usage_date"))\
#            .withColumn("usage_date", col("usage_date").cast("string"))\
#            .withColumn("startDate", col("startDate").cast("string"))\
#            .withColumn("endDate", col("endDate").cast("string"))
#     daily_df = df.toPandas()
#     daily_df = daily_df.rename(columns = daily_rename_column_map)
#     daily_df['RecordTypeId'] = daily_df.apply(lambda row: "0123f000000XdGaAAK", axis=1)
#     daily_df = daily_df.reindex(sorted(daily_df.columns), axis=1)
#     upsert_daily = daily_df.drop(columns = ["accountName"])
#     upsert_data = [val for val in upsert_daily.T.to_dict().values()]
#     creds = get_creds('lfsf')
#     sf = get_sfdc_connection(creds, 'databricks.my')
#     sf.bulk.Consumption__c.upsert(upsert_data, 'Unique_Id__c')

# from datetime import datetime

# def commit_upsert(chunk_counter, size):
#     maxLimit = upsert_commit_daily.shape[0]
#     while chunk_counter < maxLimit:
#       commit_upsert_data = [val for val in upsert_commit_daily[chunk_counter:chunk_counter+size].T.to_dict().values()]
#       creds = get_creds('lfsf')
#       sf = get_sfdc_connection(creds, 'databricks.my')
#       try:
#           sf.bulk.Consumption__c.upsert(commit_upsert_data, 'Unique_Id__c')
#           print('processed: ', chunk_counter, '....', datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
#       except:
#           print("could not process", chunk_counter)
#       chunk_counter += size

# COMMAND ----------

# DBTITLE 1,Remaining Accounts
# from datetime import datetime

# def mtm_upsert(chunk_counter, size):
#     maxLimit = upsert_mtm_daily.shape[0]
#     while chunk_counter < maxLimit:
#       mtm_upsert_data = [val for val in upsert_mtm_daily[chunk_counter:chunk_counter+size].T.to_dict().values()]
#       creds = get_creds('lfsf')
#       sf = get_sfdc_connection(creds, 'databricks.my')
#       try:
#         sf.bulk.Consumption__c.upsert(mtm_upsert_data, 'Unique_Id__c')
#         print('processed: ', chunk_counter, '....', datetime.today().strftime('%Y-%m-%d %H:%M:%S'))
#       except:
#         print("could not process chunk", chunk_counter)
#       chunk_counter += size

# COMMAND ----------

# DBTITLE 1,Platform Monthly
@udf("String")
def platMonthlyUniqueId(accountId, platform, month_end_date):
  return accountId + ":" + platform + ":" + str(month_end_date)

platmonthly_rename_column_map = {
  "accountId" : "Account_Id__c",
  "AutomatedForecastDBUs" : "AutomatedForecastDBU__c",
  "AutomatedDBUs": "Automated_DBUs__c",
  "cumAutomatedDBUs": "CumAutomatedDBU__c",
  "cumAutomatedForecastDBUs" : "CumAutomatedFcstDBU__c",
  "cumCustDollars" : "CumCustDollars__c",
  "cumCustForecastDollars" : "CumCustFcstDollars__c",
  "cumInteractiveDBUs" : "CumInteractiveDBU__c",
  "cumInteractiveForecastDBUs" : "CumInteractiveFcstDBU__c",
  "cumListDollars" : "CumListDollars__c",
  "cumListForecastDollars" : "CumListFcstDollars__c",
  "cumRevShareDollars" : "CumRevShareDollars__c",
  "cumRevShareForecastDollars" : "CumRevShareFcstDollars__c",
  "custForecastDollars" : "CustForecastDollars__c",
  "custDollars" : "Cust_Dollars__c",
  "DBUs": "ActualDBUs__c",
  "DiscountedCommit": "Discounted_Commit__c",
  "InteractiveForecastDBUs" : "InteractiveForecastDBU__c",
  "InteractiveDBUs" : "Interactive_DBUs__c",
  "listForecastDollars" : "ListForecastDollars__c",
  "ListCommit" : "List_Commit__c",
  "listDollars" : "List_Dollars__c",
  "platform" : "Platform__c",
  "revShareForecastDollars" : "RevShareForecastDollars__c",
  "RevShareCommit" : "RevShare_Commit__c",
  "revShareDollars" : "RevShare_Dollars__c",
  "month_end_date" : "Usage_Date__c",
  "Unique_Id__c": "Unique_Id__c",
  "DeltaRevShareDollars": "DeltaRevShareDollars__c",
  "DeltaAutomatedDBUs": "DeltaAutomatedDBU__c",
  "DeltaInteractiveDBUs": "DeltaInteractiveDBU__c",
  "MoonCakeDBUs":"MoonCakeDBU__c",
  "MoonCakeDBUDollars":"MoonCakeDBUDollars__c",  
  "MoonCakeDeltaDBUs":"MoonCakeDeltaDBU__c",  
  "MoonCakeDeltaDBUDollars":"MoonCakeDeltaDBUDollars__c",  
  "cumDeltaAutomatedDBUs":"cumDeltaAutomatedDBUs__c",
  "cumDeltaInteractiveDBUs":"cumDeltaInteractiveDBUs__c",
  "cumDeltaRevShareDollars":"cumDeltaRevShareDollars__c",
  "SQLAnalyticsDBUs":"SQLAnalyticsDBU__c",
  "SQLAnalyticsForecastDBUs":"SQLAnalyticsFcstDBU__c",
  "SQLRevShareDollars":"SQLRevShareDollars__c",
  "SQLRevShareForecastDollars":"SQLRevShareFcstDollars__c",
  "ISVDBUs":"ISV_DBUs__c",
  "ISVRevShareDollars":"ISV_RevShareDollars__c",  
  "ServerlessDBUs":"ServerlessDBUs__c",
  "ServerlessRevShareDollars":"ServerlessRevShare__c",
  "PhotonDBUs":"PhotonDBUs__c",
  "PhotonRevShareDollars":"PhotonRevShare__c",
  "DLTDBUs":"DLTDBUs__c",
  "DLTRevShareDollars":"DLTRevShare__c",
  "MoonCakeSQLDBUs":"MoonCakeSQLDBUs__c",    
  "MoonCakeSQLDollars":"MoonCakeSQLRevShare__c",  
  "cumSQLAnalyticsDBUs":"CumSQLAnalyticsDBU__c",
  "cumSQLAnalyticsForecastDBUs":"CumSQLAnalyticsFcstDBU__c",
  "cumSQLRevShareDollars":"CumSQLRevShareDollars__c",
  "cumSQLRevShareForecastDollars":"CumSQLRevShareFcstDollars__c",
  "UCRevShareDollars":"UnityCatalogRevshare__c",
  "UCDBUs":"UnityCatalogDBUs__c",
  "GenAIRevShareDollars":"GenAIRevShare__c",
  "GenAIDBUs":"GenAIDBUs__c",
  "MCTRevShareDollars": "MCTRevShareDollars__c"
}

# COMMAND ----------

platmonthly_df = spark.sql(f"""
select *
from {USAGEC_PLATFORM_MONTHLY}
""")
print(platmonthly_df.columns)
platmonthly_df = platmonthly_df.withColumn("Unique_Id__c", platMonthlyUniqueId("accountId", "platform", "month_end_date"))\
                               .withColumn("month_end_date", col("month_end_date").cast("string"))
platmonthly_df = platmonthly_df.toPandas()
platmonthly_df = platmonthly_df.replace({np.nan: None})

platmonthly_df = platmonthly_df[sorted(platmonthly_rename_column_map.keys())]
platmonthly = platmonthly_df[list(platmonthly_rename_column_map.keys())]
platmonthly = platmonthly.rename(columns = platmonthly_rename_column_map)
platmonthly['RecordTypeId'] = platmonthly.apply(lambda row: "0123f000000XdGbAAK", axis=1)
platmonthly = platmonthly.reindex(sorted(platmonthly.columns), axis=1)
upsert_platmonthly = platmonthly.copy()

platmonthly_upsert_data = [val for val in upsert_platmonthly.T.to_dict().values()]

# COMMAND ----------

print(len(platmonthly_upsert_data))

# COMMAND ----------

if environment == 'production':
  try:
    creds = get_creds('sfdcprod')
    sf = get_sfdc_connection(creds, 'login')
    sf.bulk.Consumption__c.upsert(data=platmonthly_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)
  except Exception as e:
    print("Platform Monthly: ", e)

# COMMAND ----------

# DBTITLE 1,Account Monthly
@udf("String")
def accMonthlyUniqueId(accountId, month_end_date):
  return accountId + ":" + str(month_end_date)

accmonthly_rename_column_map = {
  "accountId" : "Account_Id__c",
  "AutomatedForecastDBUs" : "AutomatedForecastDBU__c",
  "AutomatedDBUs": "Automated_DBUs__c",
  "cumAutomatedDBUs": "CumAutomatedDBU__c",
  "cumAutomatedForecastDBUs" : "CumAutomatedFcstDBU__c",
  "cumCustDollars" : "CumCustDollars__c",
  "cumCustForecastDollars" : "CumCustFcstDollars__c",
  "cumInteractiveDBUs" : "CumInteractiveDBU__c",
  "cumInteractiveForecastDBUs" : "CumInteractiveFcstDBU__c",
  "cumListDollars" : "CumListDollars__c",
  "cumListForecastDollars" : "CumListFcstDollars__c",
  "cumRevShareDollars" : "CumRevShareDollars__c",
  "cumRevShareForecastDollars" : "CumRevShareFcstDollars__c",
  "custForecastDollars" : "CustForecastDollars__c",
  "custDollars" : "Cust_Dollars__c",
  "InteractiveForecastDBUs" : "InteractiveForecastDBU__c",
  "InteractiveDBUs" : "Interactive_DBUs__c",
  "listForecastDollars" : "ListForecastDollars__c",
  "listDollars" : "List_Dollars__c",
  "revShareForecastDollars" : "RevShareForecastDollars__c",
  "revShareDollars" : "RevShare_Dollars__c",
  "month_end_date" : "Usage_Date__c",
  "Unique_Id__c": "Unique_Id__c",
  "workspace_users_count":"active_users__c",
  "DeltaRevShareDollars": "DeltaRevShareDollars__c",
  "DeltaAutomatedDBUs": "DeltaAutomatedDBU__c",
  "DeltaInteractiveDBUs": "DeltaInteractiveDBU__c",
  "DeltaDBUs": "DeltaDBUs__c",
  "DeltaSQLDBUs": "DeltaSQLDBUs__c",  
  "DBUs": "ActualDBUs__c", 
  "MoonCakeDBUs":"MoonCakeDBU__c",
  "MoonCakeDBUDollars":"MoonCakeDBUDollars__c",  
  "MoonCakeDeltaDBUs":"MoonCakeDeltaDBU__c",  
  "MoonCakeDeltaDBUDollars":"MoonCakeDeltaDBUDollars__c",  
  "cumDeltaAutomatedDBUs":"cumDeltaAutomatedDBUs__c",
  "cumDeltaInteractiveDBUs":"cumDeltaInteractiveDBUs__c",
  "cumDeltaRevShareDollars":"cumDeltaRevShareDollars__c",
  "SQLAnalyticsDBUs":"SQLAnalyticsDBU__c",
  "SQLAnalyticsForecastDBUs":"SQLAnalyticsFcstDBU__c",
  "SQLRevShareDollars":"SQLRevShareDollars__c",
  "SQLRevShareForecastDollars":"SQLRevShareFcstDollars__c",
  "ISVDBUs":"ISV_DBUs__c",
  "ISVRevShareDollars":"ISV_RevShareDollars__c", 
  "ServerlessDBUs":"ServerlessDBUs__c",
  "ServerlessRevShareDollars":"ServerlessRevShare__c",
  "PhotonDBUs":"PhotonDBUs__c",
  "PhotonRevShareDollars":"PhotonRevShare__c",
  "DLTDBUs":"DLTDBUs__c",
  "DLTRevShareDollars":"DLTRevShare__c",
  "MoonCakeSQLDBUs":"MoonCakeSQLDBUs__c",    
  "MoonCakeSQLDollars":"MoonCakeSQLRevShare__c",  
  "cumSQLAnalyticsDBUs":"CumSQLAnalyticsDBU__c",
  "cumSQLAnalyticsForecastDBUs":"CumSQLAnalyticsFcstDBU__c",
  "cumSQLRevShareDollars":"CumSQLRevShareDollars__c",
  "cumSQLRevShareForecastDollars":"CumSQLRevShareFcstDollars__c",
  "AEForecastDBU":"AE_Forecast_DBU__c",
  "AEForecastDBUDollars":"AE_Forecast_Dollars__c",
  "CSEBaseLineForecastDBU":"UCBaselineDBU__c",
  "CSEBaseLineForecastDBUDollars":"UCBaselineDollars__c",  
  "CSEUpsideDBU":"UCUpsideDBU__c",
  "CSEUpsideDBUDollars":"UCUpsideDollars__c",
  "revShareForecastDollars_new": "RevShareForecastDollars_New__c",
  "revShareForecastDollars_genAI": "DSForecastWithGenAI__c",
  "RevShareAndDataScienceDollars" : "RevShareAndDataScienceDollars__c",
  "UCRevShareDollars":"UnityCatalogRevshare__c",
  "UCDBUs":"UnityCatalogDBUs__c",
  "OrganicGrowthBaseline__c":"OrganicGrowthBaseline__c",
  "GenAIRevShareDollars":"GenAIRevShare__c",
  "GenAIDBUs":"GenAIDBUs__c",
  "MCTRevShareDollars": "MCTRevShareDollars__c"
}

# COMMAND ----------

organic_baseline_df = spark.sql("""with dates_df as (
  select distinct year_month, month_end_date from main.it_core_dim.bi_dates
)
select
  account_id,
  og_forecast_t28d OrganicGrowthBaseline__c,
  month_end_date month_end_usage_date
from
  main.gtm_data.core_organic_growth_baseline_monthly o
left join  dates_df b
on o.for_calendar_year_month = b.year_month
where
fcst_run_date = (
  select
    max(fcst_run_date)
  from
    main.gtm_data.core_organic_growth_baseline_monthly
)""")

# COMMAND ----------

organic_baseline_df.filter("OrganicGrowthBaseline__c <> 0").select("account_id").distinct().count()

# COMMAND ----------

organic_baseline_df.filter("OrganicGrowthBaseline__c <> 0").count()

# COMMAND ----------

organic_baseline = organic_baseline_df.filter("OrganicGrowthBaseline__c <> 0").withColumnRenamed("OrganicGrowthBaseline__c", "OrganicGrowthBaseline")

# COMMAND ----------

pre_accmonthly_df = spark.sql(f"""
select *,
       coalesce(revShareForecastDollars_new, 0) + coalesce(revShareDollars, 0) RevShareAndDataScienceDollars
from {USAGEC_ACCOUNT_MONTHLY}
""")
accmonthly_df = pre_accmonthly_df.join(organic_baseline_df, [pre_accmonthly_df.accountId == organic_baseline_df.account_id,pre_accmonthly_df.month_end_date == organic_baseline_df.month_end_usage_date] , how = "left")\
                                 .drop("account_id","month_end_usage_date")\
                                 .withColumn("OrganicGrowthBaseline__c", coalesce(col("OrganicGrowthBaseline__c"),lit(0)))
accmonthly_df = accmonthly_df.withColumn("Unique_Id__c", accMonthlyUniqueId("accountId", "month_end_date"))\
                             .withColumn("month_end_date", col("month_end_date").cast("string"))
#accmonthly_df = accmonthly_df.select("Unique_Id__c","OrganicGrowthBaseline__c").filter("OrganicGrowthBaseline__c <> 0")


# COMMAND ----------

accmonthly_df.filter("OrganicGrowthBaseline__c <> 0").count()

# COMMAND ----------

display(accmonthly_df)

# COMMAND ----------

accmonthly = accmonthly_df.toPandas()
accmonthly = accmonthly.replace({np.nan: None})

accmonthly = accmonthly[sorted(accmonthly_rename_column_map.keys())]
accmonthly = accmonthly[list(accmonthly_rename_column_map.keys())]
accmonthly = accmonthly.rename(columns = accmonthly_rename_column_map)
accmonthly['RecordTypeId'] = accmonthly.apply(lambda row: "0123f000000XdGYAA0", axis=1)
accmonthly = accmonthly.reindex(sorted(accmonthly.columns), axis=1)
upsert_accmonthly = accmonthly.copy()

accmonthly_upsert_data = [val for val in upsert_accmonthly.T.to_dict().values()]
print(len(accmonthly_upsert_data))

# COMMAND ----------

#Bulk v1
if environment == 'production':
  creds = get_creds('sfdcprod')
  sf = get_sfdc_connection(creds, 'login')
  print("Writing data: ")
  try:
    result = sf.bulk.Consumption__c.upsert(data=accmonthly_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)
    success=0
    fail=0
    error_list=[]
    for i in result:
      if i['success'] == False:
        fail+=1
        if i['errors'] not in error_list:
          error_list.append(i['errors'])
      else:
        success+=1
    print("Successs {} failure {}".format(success, fail))
    print(error_list)
  except Exception as e:
    print("The upsert operation errored out! Error code: " + str(e))

# COMMAND ----------

#Bulk v2
# creds = get_creds('uat2')
# sf = get_sfdc_connection(creds, 'test')
# #response_data = sf.bulk.Field_Engineering_Users__c.upsert(data=pdf_data, external_id_field='Name', batch_size=3000)
# # if pdf.count().all() != 0:
# #   upsert_data = [val for val in pdf.T.to_dict().values()]
# #   print(len(upsert_data), upsert_data[0])
# print("Writing data: ")
# try:
#   #results = sf.bulk2.Consumption__c.upsert(records=accmonthly_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)
#   sf.bulk.Consumption__c.upsert(data=platmonthly_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)
#   for result in results:
#     job_id = result['job_id']
#     # also available: get_unprocessed_records, get_successful_records
#     data = sf.bulk2.Consumption__c.get_failed_records(job_id)
#   # success=0
#   # fail=0
#   # error_list=[]
#   # for i in result:
#   #   if i['success'] == False:
#   #     fail+=1
#   #     if i['errors'] not in error_list:
#   #       error_list.append(i['errors'])
#   #   else:
#   #     success+=1
#   # print("Successs {} failure {}".format(success, fail))
#   # print(error_list)
# except Exception as e:
#   print("The upsert operation errored out! Error code: " + str(e))

# COMMAND ----------

# job_processed = 0
# success = 0
# failed = 0
# for i in results:
#   job_processed = job_processed + i['numberRecordsProcessed']
#   failed = failed + i['numberRecordsFailed']

# COMMAND ----------

# if environment == 'production':
#   try:
#     creds = get_creds('uat2')
#     sf = get_sfdc_connection(creds, 'test')
#     res = sf.bulk2.Consumption__c.upsert(data=accmonthly_upsert_data, external_id_field='Unique_Id__c', batch_size=3000)
#   except Exception as e:
#     print("Account Monthly: ", e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### account monthly

# COMMAND ----------

# DBTITLE 1,cleans up any non-uniqueId records
try:  
  acc_consumption_soql_query = """
  SELECT Id, 
        Account_Id__c, 
        Usage_Date__c, 
        Unique_Id__c, 
        RevShareForecastDollars__c,
        RevShareAndDataScienceDollars__c 
  FROM Consumption__c 
  WHERE RecordTypeId = '0123f000000XdGYAA0'
  """

  acc_consumption_df = get_dataframe(acc_consumption_soql_query, 'sfdcprod', 'login')
  acc_consumption_schema = build_spark_schema(acc_consumption_df.dtypes)
  spark_acc_consumption_df = spark.createDataFrame(acc_consumption_df, acc_consumption_schema)
  spark_acc_consumption_df.createOrReplaceTempView("sfdc_account_monthly")

  # clean up non-unique records
  zeroup_removeIds = spark.sql("""
  with toberemoved (
  select *,
        concat(Account_Id__c, concat(":", Usage_Date__c)) newUniqueId,
        case when Unique_Id__c == concat(Account_Id__c, concat(":", Usage_Date__c)) then false
              else true
        end as badRecFlag
  from sfdc_account_monthly
  )
  
  select Id
  from toberemoved
  where badRecFlag = 1
  """)

  zeroup_removeIds = zeroup_removeIds.withColumn("RevShare_Dollars__c", lit("0.0"))\
                                    .withColumn("DeltaRevShareDollars__c", lit("0.0"))\
                                    .withColumn("SQLRevShareDollars__c", lit("0.0"))\
                                    .withColumn("MoonCakeDBUDollars__c", lit("0.0"))\
                                    .withColumn("Automated_DBUs__c", lit("0.0"))\
                                    .withColumn("Interactive_DBUs__c", lit("0.0"))\
                                    .withColumn("MoonCakeDBU__c", lit("0.0"))\
                                    .withColumn("SQLAnalyticsDBU__c", lit("0.0"))\
                                    .withColumn("ListForecastDollars__c", lit("0.0"))\
                                    .withColumn("CustForecastDollars__c", lit("0.0"))\
                                    .withColumn("RevShareForecastDollars__c", lit("0.0"))\
                                    .withColumn("RevShareForecastDollars_New__c", lit("0.0"))\
                                    .withColumn("DSForecastWithGenAI__c", lit("0.0"))\
                                    .withColumn("RevShareAndDataScienceDollars__c", lit("0.0"))

  zeroup_removeIds_count = zeroup_removeIds.count()
  print(zeroup_removeIds_count)

  if zeroup_removeIds_count > 0 and environment == 'production':
    zeroup_removeIds_pd = zeroup_removeIds.toPandas()
    cleanup_zeroup_removeIds_data = [val for val in zeroup_removeIds_pd.T.to_dict().values()]
    try:
      creds = get_creds('sfdcprod')
      sf = get_sfdc_connection(creds, 'login')
      sf.bulk.Consumption__c.upsert(data=cleanup_zeroup_removeIds_data, external_id_field='Id', batch_size=1000)
    except Exception as e:
      print("zero sfdc_account_monthly: ", e)  
  # cleanup existing monthly records
  zeroup_outDatedAccountMonthlyIds = spark.sql(f"""
  select sfdc.Id
  from sfdc_account_monthly sfdc
  left join {USAGEC_ACCOUNT_MONTHLY} uam on sfdc.Account_Id__c = uam.accountId and sfdc.Usage_Date__c = uam.month_end_date
  where uam.accountId is null and uam.month_end_date is null
  order by sfdc.Account_Id__c, sfdc.Usage_Date__c
  """)

  zeroup_outDatedAccountMonthlyIds = zeroup_outDatedAccountMonthlyIds.withColumn("RevShare_Dollars__c", lit("0.0"))\
                                                                    .withColumn("DeltaRevShareDollars__c", lit("0.0"))\
                                                                    .withColumn("SQLRevShareDollars__c", lit("0.0"))\
                                                                    .withColumn("MoonCakeDBUDollars__c", lit("0.0"))\
                                                                    .withColumn("Automated_DBUs__c", lit("0.0"))\
                                                                    .withColumn("Interactive_DBUs__c", lit("0.0"))\
                                                                    .withColumn("MoonCakeDBU__c", lit("0.0"))\
                                                                    .withColumn("SQLAnalyticsDBU__c", lit("0.0"))\
                                                                    .withColumn("ListForecastDollars__c", lit("0.0"))\
                                                                    .withColumn("CustForecastDollars__c", lit("0.0"))\
                                                                    .withColumn("RevShareForecastDollars__c", lit("0.0"))\
                                                                    .withColumn("RevShareForecastDollars_New__c", lit("0.0"))\
                                                                    .withColumn("DSForecastWithGenAI__c", lit("0.0"))\
                                                                    .withColumn("RevShareAndDataScienceDollars__c", lit("0.0"))

  zeroup_outDatedAccountMonthlyIds_count = zeroup_outDatedAccountMonthlyIds.count()
  print(zeroup_outDatedAccountMonthlyIds_count)

  if zeroup_outDatedAccountMonthlyIds_count > 0 and environment == 'production':
    
    zeroup_outDatedAccountMonthlyIds_pd = zeroup_outDatedAccountMonthlyIds.toPandas()
    cleanup_zeroup_outDatedAccountMonthlyIds_data = [val for val in zeroup_outDatedAccountMonthlyIds_pd.T.to_dict().values()]
    try:
      creds = get_creds('sfdcprod')
      sf = get_sfdc_connection(creds, 'login')
      sf.bulk.Consumption__c.upsert(data=cleanup_zeroup_outDatedAccountMonthlyIds_data, external_id_field='Id', batch_size=1000)  
    except Exception as e:
      print("Zero Account Monthly: ", e)  
except Exception as e:
  print("Error in cleaning up of any non-uniqueId records")



# removeIds = [ {'Id':row.Id} for row in spark.sql("""
# with toberemoved (
# select *,
#        concat(Account_Id__c, concat(":", Usage_Date__c)) newUniqueId,
#        case when Unique_Id__c == concat(Account_Id__c, concat(":", Usage_Date__c)) then false
#             else true
#        end as badRecFlag
# from sfdc_account_monthly
# )

# select Id
# from toberemoved
# where badRecFlag = 1
# """).collect()]

# print(len(removeIds))
# if len(removeIds) > 0:
#   creds = get_creds('lfsf')
#   sf = get_sfdc_connection(creds, 'databricks.my')
#   sf.bulk.Consumption__c.delete(removeIds, batch_size=3000, use_serial=True)
  
  
# outDatedAccountMonthlyIds = [ {'Id':row.Id} for row in spark.sql("""
# select sfdc.Id
# from sfdc_account_monthly sfdc
# left join bdw.usagec_account_monthly uam on sfdc.Account_Id__c = uam.accountId and sfdc.Usage_Date__c = uam.month_end_date
# where uam.accountId is null and uam.month_end_date is null
# order by sfdc.Account_Id__c, sfdc.Usage_Date__c
# """).collect()]

# print(len(outDatedAccountMonthlyIds))

# if len(outDatedAccountMonthlyIds) > 0:
#   creds = get_creds('lfsf')
#   sf = get_sfdc_connection(creds, 'databricks.my')
#   sf.bulk.Consumption__c.delete(outDatedAccountMonthlyIds, batch_size=3000, use_serial=True)

# COMMAND ----------

upsert_df = spark.sql(f"""
select *,
       coalesce(revShareForecastDollars_new, 0) + coalesce(revShareDollars, 0) RevShareAndDataScienceDollars
from {USAGEC_ACCOUNT_MONTHLY}
where month_end_date < current_date()
and revShareForecastDollars > 0
""")
upsert_df = upsert_df.withColumn("revShareForecastDollars", lit(0.0))

upsert_df = upsert_df.join(organic_baseline_df, [upsert_df.accountId == organic_baseline_df.account_id,upsert_df.month_end_date == organic_baseline_df.month_end_usage_date] , how = "left")\
                                 .drop("account_id","month_end_usage_date")\
                                 .withColumn("OrganicGrowthBaseline__c", coalesce(col("OrganicGrowthBaseline__c"),lit(0)))

upsert_df = upsert_df.withColumn("Unique_Id__c", accMonthlyUniqueId("accountId", "month_end_date"))\
                     .withColumn("month_end_date", col("month_end_date").cast("string"))
upsert_df = upsert_df.toPandas()

upsertaccmonthly = upsert_df[list(accmonthly_rename_column_map.keys())]
upsertaccmonthly = upsertaccmonthly.rename(columns = accmonthly_rename_column_map)
upsertaccmonthly['RecordTypeId'] = upsertaccmonthly.apply(lambda row: "0123f000000XdGYAA0", axis=1)
upsertaccmonthly = upsertaccmonthly.reindex(sorted(upsertaccmonthly.columns), axis=1)

upsertaccmonthly_data = [val for val in upsertaccmonthly.T.to_dict().values()]

print(len(upsertaccmonthly_data))

# COMMAND ----------



if environment == 'production' and len(upsertaccmonthly_data) > 0:
  try:
    creds = get_creds('sfdcprod')
    sf = get_sfdc_connection(creds, 'login')
    sf.bulk.Consumption__c.upsert(data=upsertaccmonthly_data, external_id_field='Unique_Id__c', batch_size=3000)
  except Exception as e:
    print("upsert monthly data: ", e)

# COMMAND ----------

# DBTITLE 1,Commit Daily Upsert
commitAccounts = spark.sql(f"select distinct accountId from {USAGEC_AGGORDER_DAILY} where consumptionType = 'Commit'")
commitAccounts.createOrReplaceTempView("commitAccounts")

# COMMAND ----------

commit_df = spark.sql(f"""
    select d.*
    from {USAGEC_AGGORDER_DAILY} d
    join commitAccounts ca on d.accountId = ca.accountId
    where d.usage_date between date_sub(current_date(), 365) and date_sub(current_date(), 1) 
    """)
commit_df = commit_df.withColumn("Unique_Id__c", dailyUniqueId("accountId", "aggOrder", "usage_date"))\
                     .withColumn("usage_date", col("usage_date").cast("string"))\
                     .withColumn("startDate", col("startDate").cast("string"))\
                     .withColumn("endDate", col("endDate").cast("string"))\
                     .withColumn("actualBurstDate", col("actualBurstDate").cast("string"))\
                     .withColumn("expectedBurstDate", col("expectedBurstDate").cast("string"))

# COMMAND ----------

commit_daily_df = commit_df.toPandas()
commit_daily_df = commit_daily_df.replace({np.nan: None})

commit_daily_df = commit_daily_df[sorted(daily_rename_column_map.keys())]
commit_daily_df = commit_daily_df.rename(columns = daily_rename_column_map)
commit_daily_df['RecordTypeId'] = commit_daily_df.apply(lambda row: "0123f000000XdGaAAK", axis=1)
commit_daily_df = commit_daily_df.reindex(sorted(commit_daily_df.columns), axis=1)
print(commit_daily_df.shape)

# COMMAND ----------

commit_upsert_data = [val for val in commit_daily_df.T.to_dict().values()]

# COMMAND ----------

if environment == 'production':
  try:
    creds = get_creds('sfdcprod')
    sf = get_sfdc_connection(creds, 'login')
    sf.bulk.Consumption__c.upsert(data=commit_upsert_data, external_id_field='Unique_Id__c', batch_size=5000)
  except Exception as e:
    print("daily commit upsert: ", e)

# COMMAND ----------

# DBTITLE 1,MTM upsert
mtm_df = spark.sql(f"""
    select d.*
    from {USAGEC_AGGORDER_DAILY} d
    left join commitAccounts ca on d.accountId = ca.accountId
    where d.usage_date between date_sub(current_date(), 365) and date_sub(current_date(), 1) 
    and ca.accountId is null
    """)
mtm_df = mtm_df.withColumn("Unique_Id__c", dailyUniqueId("accountId", "aggOrder", "usage_date"))\
               .withColumn("usage_date", col("usage_date").cast("string"))\
               .withColumn("startDate", col("startDate").cast("string"))\
               .withColumn("endDate", col("endDate").cast("string"))

# COMMAND ----------

mtm_daily_df = mtm_df.toPandas()
mtm_daily_df = mtm_daily_df.replace({np.nan: None})

mtm_daily_df = mtm_daily_df[sorted(daily_rename_column_map.keys())]
mtm_daily_df = mtm_daily_df.rename(columns = daily_rename_column_map)
mtm_daily_df['RecordTypeId'] = mtm_daily_df.apply(lambda row: "0123f000000XdGaAAK", axis=1)
mtm_daily_df = mtm_daily_df.reindex(sorted(mtm_daily_df.columns), axis=1)
print(mtm_daily_df.shape)

# COMMAND ----------

mtm_upsert_data = [val for val in mtm_daily_df.T.to_dict().values()]
print(len(mtm_upsert_data))

# COMMAND ----------

if environment == 'production':
  try:
    creds = get_creds('sfdcprod')
    sf = get_sfdc_connection(creds, 'login')
    sf.bulk.Consumption__c.upsert(data=mtm_upsert_data, external_id_field='Unique_Id__c', batch_size=5000)
  except Exception as e:
    print("daily mtm upsert: ", e)

# COMMAND ----------

# DBTITLE 1,clean popmetrics
pop_consumption_soql_query = """
SELECT Id, Account_Id__c, Platform__c, Unique_Id__c, RevShareLastQtr__c, RevShareDollarsQTD__c, RevShareDollarsMTD__c, Usage_Date__c FROM Consumption__c WHERE RecordTypeId = '0123f000000XdGcAAK'
"""

pop_consumption_df = get_dataframe(pop_consumption_soql_query, 'sfdcprod', 'login')
pop_consumption_schema = build_spark_schema(pop_consumption_df.dtypes)
spark_pop_consumption_df = spark.createDataFrame(pop_consumption_df, pop_consumption_schema)
spark_pop_consumption_df.createOrReplaceTempView("sfdc_popmetrics")

outDatedPoPMetricsIds = [ {'Id':row.Id} for row in spark.sql(f"""
select sfdc.Id
from sfdc_popmetrics sfdc
left join {USAGEC_POPMETRICS} pop on sfdc.Account_Id__c = pop.accountId and sfdc.Platform__c = pop.platform and sfdc.usage_date__c = pop.month_end_date
where pop.accountId is null and pop.platform is null and pop.month_end_date is null
and sfdc.Account_Id__c is not null
and (RevShareLastQtr__c > 0 or RevShareDollarsQTD__c > 0 or RevShareDollarsMTD__c > 0)
order by sfdc.Account_Id__c
""").collect()]

print(len(outDatedPoPMetricsIds))

if len(outDatedPoPMetricsIds) > 0 and environment == 'production':
  try:
    creds = get_creds('sfdcprod')
    sf = get_sfdc_connection(creds, 'login')
    sf.bulk.Consumption__c.delete(outDatedPoPMetricsIds, batch_size=3000, use_serial=True)
  except Exception as e:
    print("outdated pop metrics: ", e)

# COMMAND ----------

# MAGIC %md
# MAGIC #### delete outdated daily records

# COMMAND ----------

daily_success = 0
try:  
  consumption_soql_query = """
  SELECT Id,
        Unique_Id__c,
        Account_Id__c,
        Usage_Date__c 
  FROM Consumption__c 
  WHERE RecordTypeId = '0123f000000XdGaAAK'
  """
  cleanup_df = get_dataframe(consumption_soql_query, 'sfdcprod', 'login')

  cleanup_consumption_schema = build_spark_schema(cleanup_df.dtypes)
  spark_daily_consumption_df = spark.createDataFrame(cleanup_df, cleanup_consumption_schema)
  spark_daily_consumption_df.createOrReplaceTempView("sfdc_account_daily")
  daily_success = 1
except Exception as e:
  print("delete outdated daily records failed. Error code: ", e)

# COMMAND ----------

environment

# COMMAND ----------

if daily_success == 1:
  print(f"Total rows extracted: {spark_daily_consumption_df.count()}")
  spark.sql("""
            create or replace temp view tobe_deleted_daily
            as
            select sfdc.*
            from sfdc_account_daily sfdc
            left join main.it_consumption_silver.usagec_aggorder_daily uam on split(sfdc.unique_id__c, ':')[1]  = uam.accountId and split(sfdc.unique_id__c, ':')[3] = uam.usage_date
            where uam.accountId is null and uam.usage_date is null
            """)
  outdated_daily_rows = spark.sql(f"""
  select Id
  from tobe_deleted_daily
  """).collect()

  outdated_daily_data = [ {'Id':row.Id} for row in outdated_daily_rows]
  print(f"Total rows to be deleeted: {len(outdated_daily_data)}")

  if environment == "production":
    try:
        creds = get_creds('sfdcprod')
        sf = get_sfdc_connection(creds, 'login')
        delete_out = sf.bulk.Consumption__c.delete(outdated_daily_data, batch_size=3000, use_serial=True)
    except Exception as e:
        print("daily clean up failed")

# COMMAND ----------

# DBTITLE 1,daily clean up for more than 365 days
cleanup_date_lower_bound = spark.sql(""" select date_sub(current_date(), 365) clean_from_date """).collect()[0].clean_from_date

consumption_soql_query = f"""
SELECT Id 
FROM Consumption__c 
WHERE RecordTypeId = '0123f000000XdGaAAK' and Usage_Date__c < {cleanup_date_lower_bound}
"""

# generator on the results page
creds = get_creds('sfdcprod')
sf = get_sfdc_connection(creds, 'login')
fetch_results = sf.bulk.Consumption__c.query(consumption_soql_query, lazy_operation=True)

# the generator provides the list of results for every call to next()
all_results = []
for list_results in fetch_results:
  all_results.extend(list_results)

all_cleanup_ids = []
for r in all_results:
  all_cleanup_ids.append(r['Id'])
print(len(all_cleanup_ids))

cleanup_ids = [{'Id':Id} for Id in all_cleanup_ids]
if environment == "production":
  try:
      creds = get_creds('sfdcprod')
      sf = get_sfdc_connection(creds, 'login')
      delete_out = sf.bulk.Consumption__c.delete(cleanup_ids, batch_size=3000, use_serial=True)
  except Exception as e:
      print("daily clean up failed")

# COMMAND ----------

#send email
# import smtplib
# from email.mime.text import MIMEText
# from email.mime.application import MIMEApplication
# from email.mime.multipart import MIMEMultipart
# server = smtplib.SMTP('smtp.gmail.com:587')
# server.ehlo()
# server.starttls()
# mygmail = dbutils.secrets.get('mycreds', 'gmail')
# pswd = dbutils.secrets.get('mycreds', 'pwd')
# server.login(mygmail, pswd)

# sender = mygmail
# recipients = ["rk.aduri@databricks.com", "manu.shetty@databricks.com", "cory@databricks.com", "karan.shah@databricks.com"]
# msg = MIMEMultipart()
# msg['Subject'] = 'prod push completed'
# msg['From'] = sender
# msg['To'] = ", ".join(recipients)
# msg.attach(MIMEText('PoP Metrics, Daily Updated, Added Delta'))
# server.sendmail(sender, recipients, msg.as_string())
# server.close()

# COMMAND ----------

# DBTITLE 1,Clean up
# cleanup_soql = """
# SELECT Id FROM Consumption__c WHERE RecordTypeId = '0123C000000RJ64QAG'
# """
# cleanup_df = get_dataframe(cleanup_soql, 'databricks.my', 'lfsf')
# cleanup_ids = [val for val in cleanup_df.T.to_dict().values()]
# creds = get_creds('uat')
# sf = get_sfdc_connection(creds, 'test')
# sf.bulk.Consumption__c.delete(cleanup_ids,use_serial=True)

# COMMAND ----------

# consumption_soql_query = """
# SELECT Id, Account_Id__c,AggOrder__c, Usage_Date__c FROM Consumption__c WHERE RecordTypeId = '0123f000000XdGaAAK' and Usage_Date__c > 2020-11-01 and Usage_Date__c < 2021-12-31
# """

# # recordType_soql_query = """
# # SELECT BusinessProcessId,CreatedById,CreatedDate,Description,DeveloperName,Id,IsActive,LastModifiedById,LastModifiedDate,Name,NamespacePrefix,SobjectType,SystemModstamp FROM RecordType WHERE SobjectType = 'Consumption__c'
# # """

# COMMAND ----------

# # ---daily---> "D:" + accountId + ":" + aggOrder + ":" + str(usage_date)
# #recordType_df = get_dataframe(recordType_soql_query, 'lfsf', 'databricks.my')

# consumption_df = get_dataframe(consumption_soql_query, 'lfsf', 'databricks.my')
# consumption_schema = build_spark_schema(consumption_df.dtypes)
# spark_consumption_df = spark.createDataFrame(consumption_df, consumption_schema)

# COMMAND ----------

# existing_consumption_daily = spark_consumption_df.distinct()
# print(spark_consumption_df.count(), existing_consumption_daily.count())

# COMMAND ----------

# current_consumption_df = spark.sql("select distinct accountId, aggOrder, usage_date from bdw.usagec_aggorder_daily")
# print(current_consumption_df.count())

# COMMAND ----------

# tobeRemoved_df = spark_consumption_df.join(current_consumption_df, (spark_consumption_df.Account_Id__c == current_consumption_df.accountId) &\
#                                                                    (spark_consumption_df.AggOrder__c == current_consumption_df.aggOrder) &\
#                                                                    (spark_consumption_df.Usage_Date__c == current_consumption_df.usage_date), 'left')
# removeIds = tobeRemoved_df.filter(tobeRemoved_df.aggOrder.isNull())
# removeIds.count()

# COMMAND ----------

#cleanup_ids = [{'Id':row.Id} for row in removeIds.select("Id").collect()]

# COMMAND ----------

# creds = get_creds('lfsf')
# sf = get_sfdc_connection(creds, 'databricks.my')
# sf.bulk.Consumption__c.delete(cleanup_ids, batch_size=3000, use_serial=True)

# COMMAND ----------

# chunk = 0
# while chunk < len(cleanup_ids):
#     print("processing: ", chunk)
#     if chunk + 2999 > len(cleanup_ids):
#       right_limit = len(cleanup_ids)-1
#     else:
#       right_limit = chunk + 2999
#     batch_cleanup_ids = cleanup_ids[chunk:right_limit]
#     creds = get_creds('lfsf')
#     sf = get_sfdc_connection(creds, 'databricks.my')
#     sf.bulk.Consumption__c.delete(batch_cleanup_ids,use_serial=True)
#     chunk += 3000
