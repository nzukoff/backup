# Databricks notebook source
'''
The upstream source for this burndown is Universal Burndown Table. This query maps the Universal Burndown table (main.it_cra_silver.universal_burndown_daily) to the Consumption table that we currently upload to Salesforce. Here is the detailed logic:

Orders Base:
1. Use main.it_cpq_silver.cpq_aws_gcp_contracts_orders_vw to generate an orders base table. This is relevant because UB has billing related adjustments which are not relevant to CPQ.

Azure + Flex: UB has aggorders populated for Azure and Flex
1. Join with the orders base table on aggorder to get the order_number, contract_number, contract_id, order_id, startDate, endDate
2. Considering Azure royalty of 15%, usage_cust_dollars is multiplied by 0.85 to get revshare; and cust_commit is multiplied by 0.85 to get revshare_commit


Other orders: UB does not have aggorders populated; but the order_line_item_id is refreshed for all orders having an end_date after 2024-01-01 (as confirmed with Navya Gattupally)
1. Join with orders base table on order_line_item to get the aggorder, order_number, contract_number, etc
'''

# COMMAND ----------

dbutils.widgets.text("env", 'dev')
env = dbutils.widgets.get("env")

if env == "prod":
  table_name = 'main.gtm_consumption_silver.ub_based_consumption_daily'
    # Integration environment code here
else:
  table_name = 'integration.gtm_consumption_silver.ub_based_consumption_daily'
    # Default environment code here
print(table_name)

# COMMAND ----------

ub_consumption = spark.sql("""
with orderlineitem as (
  select
    Id,
    OrderItemNumber,
    OrderId
  from
    main.sfdc_bronze.orderitem
  where
    processDate = (
      select
        max(processDate)
      from
        main.sfdc_bronze.orderitem
    )
),
orders_base as (
  select
    concat(
        case 
          when product_code like '%-DOLLAR' and 'co-term' not like lower(coalesce(cpq_order_type,'')) then replace(product_code, '-DOLLAR', '')
          when product_code like '%-DOLLAR' and 'co-term' like lower(coalesce(cpq_order_type,'')) then concat(replace(product_code, '-DOLLAR', ''),'-CO-TERM')
          when product_code like 'COMPLIMENTARY-USAGE-%' then concat(replace(product_code,'COMPLIMENTARY-USAGE-',''),'','-COMPLIMENTARY')
          else 'COMMIT'
        end,
        '-', generated_contract_number, '-', order_number) as AggOrder,
       account_id,
       order_id,
       contract_id,
       order_number,
       order_item_number,
       ol.id as order_line_item_id,
       generated_contract_number as contract_number,
       cast(order_item_start_date as date) startDate,
       cast(order_item_effective_end_date as date) endDate,
       case when lower(consumption_cloud) = 'azure' then 0.85 * committed_quantity 
            else committed_quantity end as DBShareCommit
  from main.it_cpq_silver.cpq_aws_gcp_contracts_orders_vw c
  join main.it_core_dim.bi_account_dim acc on c.account_id = acc.accountId
  join orderlineitem ol on c.order_item_number = ol.OrderItemNumber
  where product_family = 'Workload Commitment'  
  and  contract_start_date__c <=  contract_effective_end_date     
  and committed_quantity > 1  
),
ub_azure_flex_base as (
  select
    upper(agg_order) as aggorder,
    usage_date,
    commit_sfdc_account_id as accountId,
    case
      when upper(agg_order) like '%AZURE%' then 'AZURE-COMMIT'
      when upper(agg_order) like '%FLEX%' then 'FLEX-COMMIT'
    end as consumption_type,
    sum(usage_cust_dollars) as cust_dollars,
    case
      when upper(agg_order) like '%AZURE%' then sum(usage_cust_dollars * 0.85)
      when upper(agg_order) like '%FLEX%' then sum(usage_cust_dollars)
    end as revshare_dollars,
    cust_commit as discounted_commit,
    case
      when upper(agg_order) like '%AZURE%' then cust_commit * 0.85
      when upper(agg_order) like '%FLEX%' then cust_commit
    end as revshare_commit,
    max(coalesce(cra_burn_percentage,0))*100 as burn,
    max(coalesce(cra_burn_percentage,0))*100 as flex_burn
  from
    main.it_cra_silver.universal_burndown_daily
  where
    agg_order is not null
    and upper(agg_order) not like '%MTM%'
    and not is_usage_support
    and coalesce(cust_commit,0) > 0
  group by
    all
),
ub_azure_flex as (
select
  ob.order_number,
  ob.contract_number,
  u.*,
  ob.startDate,
  ob.endDate,
  ob.contract_id as contract_id,
  ob.order_id as order_id,
  concat(
    u.accountId,
    '-',
    u.aggorder,
    '-',
    coalesce(contract_id, 'NA'),
    '-',
    coalesce(order_id, 'NA'),
    '-',
    coalesce(startDate, '2999-01-01')
  ) as Unique_Id__c
from
  ub_azure_flex_base u
  join orders_base ob
  on u.aggorder = ob.aggorder and u.revshare_commit = ob.DBShareCommit
),
ub_except_azure_flex_base as (
  select
    order_line_item_id,
    usage_date,
    sum(usage_cust_dollars) as usage_cust_dollars,
    cust_commit,
    commit_sfdc_account_id as accountId
  from
    main.it_cra_silver.universal_burndown_daily
  where
    agg_order is null
    and order_line_item_id is not null
    and platform is not null
    and upper(metronome_commit_name) not like '%SUPPORT%'
    and coalesce(cust_commit,0) > 0
  group by all
),
ub_except_azure_flex as (
  select
    ob.order_number,
    ob.contract_number,
    ob.AggOrder as aggorder,
    u.usage_date,
    u.accountId,
    case when lower(ob.AggOrder) like 'aws-mp-commit-co-term%' then 'AWS-MP-CO-TERM-COMMIT'
           when lower(ob.AggOrder) like 'aws-mp-commit%' then 'AWS-MP-COMMIT'
           when lower(ob.AggOrder) like 'aws-commit%' then 'AWS-COMMIT'
           when lower(ob.AggOrder) like 'flex-commit%' then 'FLEX-COMMIT'
           when lower(ob.AggOrder) like 'azure-commit%' then 'AZURE-COMMIT'  
           when lower(ob.AggOrder) like 'gcp-mp-commit%' then 'GCP-MP-COMMIT'
           when lower(ob.AggOrder) like 'gcp-commit%' then 'GCP-COMMIT'
           when lower(ob.AggOrder) like '%co-term%' then 'CO-TERM-COMMIT'
           when lower(ob.AggOrder) like 'aws-complimentary%' then 'AWS-COMPLIMENTARY'
           when lower(ob.AggOrder) like 'gcp-complimentary%' then 'GCP-COMPLIMENTARY'
           else ob.AggOrder end  as consumption_type,
    sum(usage_cust_dollars) as cust_dollars,
    sum(usage_cust_dollars) as revshare_dollars,
    cust_commit as discounted_commit,
    cust_commit as revshare_commit,
    round(sum(usage_cust_dollars)/cust_commit*100,2) as burn,
    round(sum(usage_cust_dollars)/cust_commit*100,2) as flex_burn,
    startDate,
    endDate,
    contract_id,
    order_id,
    concat(
      u.accountId,
      '-',
      ob.aggorder,
      '-',
      coalesce(contract_id, 'NA'),
      '-',
      coalesce(order_id, 'NA'),
      '-',
      coalesce(startDate, '2999-01-01')
    ) as Unique_Id__c
  from
    ub_except_azure_flex_base u
    join orders_base ob on u.order_line_item_id = ob.order_line_item_id
  group by
    all
)
select
*
from ub_azure_flex
union all
select
*
from ub_except_azure_flex
""")

# COMMAND ----------

ub_consumption.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(table_name)
