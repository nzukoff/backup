# Databricks notebook source
'''
1. Generate usage_combined cte: Union usage data sources from PUM, DBU Dollars (prior to 2021), PVC and Pubsec. PVC and Pubsec usage needs pre-processing. The query is long because of the # of products we source from PUM; but the logic is easy.
2. Generate usage_w_product_dim cte: 
  a> Join with it_core_dim.bi_product_dim to exclude 'virtual' skuType and generate product cuts for Enterprise, Premium, Standard based on skuType.
  b> Generate other product cuts based on sku, deployedRegion (China -> Mooncake dollars)
3. Generate cumulative numbers at account-platform-usage-date level
'''

# COMMAND ----------

# DBTITLE 1,Granular Table query
granular_table_df = spark.sql(f"""
with dates as (
  select
    date, year, month, daysinmonth
  from main.it_core_dim.bi_dates
),
pubsec (
  select 
    sfdc_account_id,
    sfdc_account_name,
    d.date as usage_date,
    d.year,
    d.month,
    dbu/daysinmonth as dbu,
    type,
    dbu_dollars/daysinmonth as dbu_dollars
  from main.fin_live_gold.pubsec_usage u
  join dates d on u.year = d.year and u.month = d.month
  where sfdc_account_id is not null
),
common_accs (
  select 
    distinct f.sfdc_account_id
  from main.fin_live_gold.pubsec_usage f
  join main.fin_live_gold.pvc_usage pvc 
  on f.sfdc_account_id = pvc.sfdc_account_id
),
pvc_withoutcommon (
  select 
    pvc.sfdc_account_id,
    pvc.sfdc_account_name,
    d.date as usage_date,
    -- pvc.platform,
    pvc.year,
    pvc.month,
    pvc.dbu/daysinmonth as dbu,
    pvc.type,
    pvc.dbu_dollars/daysinmonth as dbu_dollars 
  from main.fin_live_gold.pvc_usage pvc
  left join common_accs com on pvc.sfdc_account_id = com.sfdc_account_id
  join dates d on d.year = pvc.year and d.month = pvc.month
  where com.sfdc_account_id is null
),
pvc_pubsec as (
  select 
    *
  from pvc_withoutcommon
  union 
  select 
    *
  from pubsec
),
usage_combined as (
  select 
  case
    when sfdc_account_id is null and upper(region) = 'APJ' then '0013f0000063xxQAAQ'
    when sfdc_account_id is null and upper(region) = 'EMEA' then '0013f0000063xxLAAQ'
    when sfdc_account_id is null then '0013f000005RwT9AAK'
    else sfdc_account_id
  end as accountID,
  if(sfdc_account_id is null, 'Unmapped Workspace', sfdc_account_name) accountName,
  round(0,6) AgentEvalsDBUs,
  round(0,6) AgentEvalsRevShareDollars,
  round(0,6) AgentEvalsSyntheticDataDBUs,
  round(0,6) AgentEvalsSyntheticDataRevShareDollars,
  round(0,6) AgentFrameworkDBUs,
  round(0,6) AgentFrameworkRevShareDollars,
  round(0,6) AIRuntimeDBUs,
  round(0,6) AIRuntimeRevShareDollars,
  round(0,6) AnthropicFoundationModelAPIDBUs,
  round(0,6) AnthropicFoundationModelAPIRevShareDollars,
  round(0,6) AnthropicThroughputModelServingDBUs,
  round(0,6) AnthropicThroughputModelServingRevShareDollars,
  round(0,6) BatchInferenceModelServingDBUs,
  round(0,6) BatchInferenceModelServingRevShareDollars,
  ps.Name businessSubscriptionID,
  round(0,6) CPUModelServingRevShareDollars,
  coalesce(dbt_dbu,0) dbt_dbu_quantity,
  dbu_dollars revShareDollars,
  round(dbu,4) dbu_quantity,
  discount_price dbuCustPrice,
  cast(dbu_price as double) dbuRevSharePrice,
  round(delta_dbu,4) delta_dbu_quantity,
  shard_region deployedRegion,
  round(0,6) FinetuningDBUs,
  round(0,6) FinetuningRevShareDollars,
  coalesce(fivetran_dbu,0) fivetran_dbu_quantity,
  round(0,6) FmBgeLargeENDBUs,
  round(0,6) FmBgeLargeENRevShareDollars,
  round(0,6) FmDatabricksDbrxChatDBUs,
  round(0,6) FmDatabricksDbrxChatRevShareDollars,
  round(0,6) FmLlama270bChatDBUs,
  round(0,6) FmLlama270bChatRevShareDollars,
  round(0,6) FmMixtral87bInstructDBUs,
  round(0,6) FmMixtral87bInstructRevShareDollars,
  round(0,6) FmMpt30bInstructDBUs,
  round(0,6) FmMpt30bInstructRevShareDollars,
  round(0,6) FmMpt7bInstructDBUs,
  round(0,6) FmMpt7bInstructRevShareDollars,
  round(0,6) foundation_model_api_dbu_quantity,
  round(0,6) FoundationModelAPIRevShareDollars,
  round(0,6) FoundationModelTrainingRevShareDollars,
  round(0,6) FY26AIDBUs,
  round(0,6) FY26AIDollars,
  round(0,6) gen_ai_dbu_quantity,
  round(0,6) GenAIRevShareDollars,
  round(0,6) gpu_model_serving_dbu_quantity,
  round(0,6) GPUModelServingRevShareDollars,
  is_paying isPaying,
  round(coalesce(isv_dbu,0),6) isv_dbu_quantity,
  round(0,6) LakeflowConnectDBUs,
  round(0,6) LakeflowConnectRevShareDollars,
  round(0,6) LakeflowDBUs,
  round(0,6) LakeflowRevShareDollars,
  round(0,6) LakeflowPipelinesDBUs,
  round(0,6) LakeflowPipelinesRevShareDollars,
  round(0,6) LakehouseMonitoringDBUs,
  round(0,6) LakehouseMonitoringRevShareDollars,
  list_price listPrice,
  round(0,6) MCTRevShareDollars,
  round(0,6) mct_dbu_quantity,
  round(0,6) MCTModelHeroRunTrainingRevShareDollars,
  round(0,6) MCTModelOnDemandTrainingRevShareDollars,
  round(0,6) MCTModelReservedTrainingRevShareDollars,
  round(coalesce(ml_dbu, 0),6) ml_dbu_quantity,
  round(0,6) ModelServingFMAPIDBUs,
  round(0,6) ModelServingFMAPIRevShareDollars,
  platform,
  shield_dollars,
  coalesce(streaming_dlt_dbu_dollars_salescomp, 0) streaming_dlt_dbu_quantity,
  coalesce(streaming_dlt_dbu_salescomp, 0) StreamingDLTRevShareDollars,
  round(0,6) throughput_model_serving_dbu_quantity,
  round(0,6) ThroughputModelServingRevShareDollars,
  coalesce(uc_dbu_dollars_salescomp, 0) UCRevShareDollars,
  coalesce(uc_dbu_salescomp, 0) uc_dbu_quantity,
  date usage_date,
  lower(sku) usage_sku,
  round(0,6) vector_search_dbu_quantity,
  round(0,6) VectorSearchRevShareDollars,
  round(0,6) VectorSearchIngestionRevShareDollars,
  round(0,6) VectorSearchServingRevShareDollars,
  round(0,6) VectorSearchStorageDBUs,
  round(0,6) VectorSearchStorageRevShareDollars,
  sfdc_workspace_id as workspaceId,
  workspace_sfdc_object_id workspaceSFDCID,
  round(dbu*discount_price + if(platform == 'azure', shield_dollars/0.85, shield_dollars),6) as custDollars,
  round(0,6) LakebaseDBUs,
  round(0,6) LakebaseRevShareDollars,
  round(0,6) OpenAIDBUs,
  round(0,6) OpenAIRevShareDollars,
  round(0,6) GeminiDBUs,
  round(0,6) GeminiRevShareDollars
from main.it_lakehouse.dbu_dollars_prior_to_2021_vw f
left join main.sfdc_bronze.workspace__c w 
  on f.workspace_sfdc_object_id = w.id
  and w.processDate = (
    select max(processDate)
    from main.sfdc_bronze.workspace__c
  )
left join main.sfdc_bronze.platformsubscription__c ps
  on w.Business_Subscription__c = ps.id
  and ps.processDate = (
    select max(processDate)
    from main.sfdc_bronze.platformsubscription__c
  )
where date < '2021-01-01'

union all
select 
  case
    when sfdc_account_id is null and upper(region) = 'APJ' then '0013f0000063xxQAAQ'
    when sfdc_account_id is null and upper(region) = 'EMEA' then '0013f0000063xxLAAQ'
    when sfdc_account_id is null then '0013f000005RwT9AAK'
    else sfdc_account_id
  end as accountID,
  if(sfdc_account_id is null, 'Unmapped Workspace', sfdc_account_name) accountName,
  round(IF(product_type="AGENT_EVALUATION" and usage_type="JUDGE_REQUEST",usage_amount,0),6) AgentEvalsDBUs,
  round(IF(product_type="AGENT_EVALUATION" and usage_type="JUDGE_REQUEST",usage_dollars,0),6) AgentEvalsRevShareDollars,
  round(IF(product_type="AGENT_EVALUATION" and usage_type="API_OPERATION",usage_amount,0),6) AgentEvalsSyntheticDataDBUs,
  round(IF(product_type="AGENT_EVALUATION" and usage_type="API_OPERATION",usage_dollars,0),6) AgentEvalsSyntheticDataRevShareDollars,
  round(coalesce(sales_comp_metric.agent_framework_dbu, 0),6) AgentFrameworkDBUs,
  round(coalesce(sales_comp_metric.agent_framework_dollars, 0),6) AgentFrameworkRevShareDollars,
  round(coalesce(sales_comp_metric.ai_runtime_dbu,0),6) AIRuntimeDBUs,
  round(coalesce(sales_comp_metric.ai_runtime_dollars,0),6) AIRuntimeRevShareDollars,
  round(coalesce(sales_comp_metric.anthropic_foundation_model_api_dbu,0),6) as AnthropicFoundationModelAPIDBUs,
  round(coalesce(sales_comp_metric.anthropic_foundation_model_api_dollars,0),6) as AnthropicFoundationModelAPIRevShareDollars,
  round(coalesce(sales_comp_metric.anthropic_throughput_model_serving_dbu,0),6) as AnthropicThroughputModelServingDBUs,
  round(coalesce(sales_comp_metric.anthropic_throughput_model_serving_dollars,0),6) as AnthropicThroughputModelServingRevShareDollars,
  round(coalesce(sales_comp_metric.batch_inference_model_serving_dbu, 0),6) BatchInferenceModelServingDBUs,
  round(coalesce(sales_comp_metric.batch_inference_model_serving_dollars, 0),6) BatchInferenceModelServingRevShareDollars,
  business_subscription_id businessSubscriptionID,
  round(coalesce(sales_comp_metric.cpu_model_serving_dollars, 0),6) CPUModelServingRevShareDollars,
  round(coalesce(workload_insights_metric.dbt_dbu,0),6) dbt_dbu_quantity,
  round(if(platform='mct',0,usage_dollars),6) revShareDollars,
  round(net_usage_amount,4) dbu_quantity,
  discount_price dbuCustPrice,
  cast(rev_share_price as double) dbuRevSharePrice,
  round(round(workload_insights_metric.delta_dbu,4),6) delta_dbu_quantity,
  shard_region deployedRegion,
  round(IF(product_type="FOUNDATION_MODEL_TRAINING",usage_amount,0),6) FinetuningDBUs,
  round(IF(product_type="FOUNDATION_MODEL_TRAINING",usage_dollars,0),6) FinetuningRevShareDollars,
  round(coalesce(workload_insights_metric.fivetran_dbu,0),6) fivetran_dbu_quantity,
  round(coalesce(sales_comp_metric.fm_bge_large_en_dbu, 0),6) FmBgeLargeENDBUs,
  round(coalesce(sales_comp_metric.fm_bge_large_en_dollars, 0),6) FmBgeLargeENRevShareDollars,
  round(coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dbu, 0),6) FmDatabricksDbrxChatDBUs,
  round(coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dollars, 0),6) FmDatabricksDbrxChatRevShareDollars,
  round(coalesce(sales_comp_metric.fm_llama2_70b_chat_dbu, 0),6) FmLlama270bChatDBUs,
  round(coalesce(sales_comp_metric.fm_llama2_70b_chat_dollars, 0),6) FmLlama270bChatRevShareDollars,
  round(coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dbu, 0),6) FmMixtral87bInstructDBUs,
  round(coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dollars, 0),6) FmMixtral87bInstructRevShareDollars,
  round(coalesce(sales_comp_metric.fm_mpt_30b_instruct_dbu, 0),6) FmMpt30bInstructDBUs,
  round(coalesce(sales_comp_metric.fm_mpt_30b_instruct_dollars, 0),6) FmMpt30bInstructRevShareDollars,
  round(coalesce(sales_comp_metric.fm_mpt_7b_instruct_dbu, 0),6) FmMpt7bInstructDBUs,
  round(coalesce(sales_comp_metric.fm_mpt_7b_instruct_dollars, 0),6) FmMpt7bInstructRevShareDollars,
  round(coalesce(sales_comp_metric.foundation_model_api_dbu, 0),6) foundation_model_api_dbu_quantity,
  round(coalesce(sales_comp_metric.foundation_model_api_dollars, 0),6) FoundationModelAPIRevShareDollars,
  round(coalesce(sales_comp_metric.foundation_model_training_dollars, 0),6) FoundationModelTrainingRevShareDollars,
  round(coalesce(sales_comp_metric.fy26_ai_dbu, 0),6) FY26AIDBUs,
  round(coalesce(sales_comp_metric.fy26_ai_dollars, 0),6) FY26AIDollars,
  round(coalesce(sales_comp_metric.gen_ai_dbu, 0),6) gen_ai_dbu_quantity,
  round(coalesce(sales_comp_metric.gen_ai_dollars, 0),6) GenAIRevShareDollars,
  round(coalesce(sales_comp_metric.gpu_model_serving_dbu, 0),6) gpu_model_serving_dbu_quantity,
  round(coalesce(sales_comp_metric.gpu_model_serving_dollars, 0),6) GPUModelServingRevShareDollars,
  is_paying isPaying,
  round(coalesce(workload_insights_metric.isv_dbu,0),6) isv_dbu_quantity,
  round(coalesce(sales_comp_metric.lakeflow_connect_dbu, 0),6) LakeflowConnectDBUs,
  round(coalesce(sales_comp_metric.lakeflow_connect_dollars, 0),6) LakeflowConnectRevShareDollars,
  round(coalesce(sales_comp_metric.lakeflow_dbu, 0),6) LakeflowDBUs,
  round(coalesce(sales_comp_metric.lakeflow_dollars, 0),6) LakeflowRevShareDollars,
  round(coalesce(sales_comp_metric.lakeflow_pipelines_dbu, 0),6) LakeflowPipelinesDBUs,
  round(coalesce(sales_comp_metric.lakeflow_pipelines_dollars, 0),6) LakeflowPipelinesRevShareDollars,
  round(coalesce(sales_comp_metric.lakehouse_monitoring_dbu, 0),6) LakehouseMonitoringDBUs,
  round(coalesce(sales_comp_metric.lakehouse_monitoring_dollars, 0),6) LakehouseMonitoringRevShareDollars,
  round(list_price, 2) listPrice,
  round(if(platform='mct',coalesce(sales_comp_metric.mct_dollars,0),0),6) MCTRevShareDollars,
  round(if(platform='mct',coalesce(sales_comp_metric.mct_dbu, 0),0),6) mct_dbu_quantity,
  round(CASE WHEN mosaic_ml.sub_product_type = 'HERO_RUN' AND platform = 'mct' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END ,6) MCTModelHeroRunTrainingRevShareDollars,
  round(CASE WHEN mosaic_ml.sub_product_type = 'ON_DEMAND_TRAINING' AND platform = 'mct' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END ,6) MCTModelOnDemandTrainingRevShareDollars,
  round(CASE WHEN mosaic_ml.sub_product_type = 'RESERVED_TRAINING' AND platform = 'mct' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END,6) MCTModelReservedTrainingRevShareDollars,
  round(coalesce(workload_insights_metric.ml_dbu, 0),6) ml_dbu_quantity,
  round(IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_amount,0),6) ModelServingFMAPIDBUs,
  round(IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_dollars,0),6) ModelServingFMAPIRevShareDollars,
  platform,
  add_on.shield_dollars,
  round(coalesce(sales_comp_metric.streaming_dollars, 0),6) streaming_dlt_dbu_quantity,
  round(coalesce(sales_comp_metric.streaming_dbu, 0),6) StreamingDLTRevShareDollars,
  round(coalesce(sales_comp_metric.throughput_model_serving_dbu, 0),6) throughput_model_serving_dbu_quantity,
  round(coalesce(sales_comp_metric.throughput_model_serving_dollars, 0),6) ThroughputModelServingRevShareDollars,
  round(coalesce(sales_comp_metric.uc_dollars, 0),6) UCRevShareDollars,
  round(coalesce(sales_comp_metric.uc_dbu, 0),6) uc_dbu_quantity,
  p.date usage_date,
  lower(sku) usage_sku,
  round(coalesce(sales_comp_metric.vector_search_dbu, 0),6) vector_search_dbu_quantity,
  round(coalesce(sales_comp_metric.vector_search_dollars, 0),6) VectorSearchRevShareDollars,
  round(coalesce(sales_comp_metric.vector_search_ingestion_dollars, 0),6) VectorSearchIngestionRevShareDollars,
  round(coalesce(sales_comp_metric.vector_search_serving_dollars, 0),6) VectorSearchServingRevShareDollars,
  round(coalesce(sales_comp_metric.vector_search_storage_dbu, 0),6) VectorSearchStorageDBUs,
  round(coalesce(sales_comp_metric.vector_search_storage_dollars, 0),6) VectorSearchStorageRevShareDollars,
  sfdc_workspace_id as workspaceId,
  w.Id workspaceSFDCID,
  round(net_usage_amount*discount_price + if(platform == 'azure', add_on.shield_dollars/0.85, add_on.shield_dollars),6) as custDollars,
  round(coalesce(sales_comp_metric.lakebase_dbu,0),6) LakebaseDBUs,
  round(coalesce(sales_comp_metric.lakebase_dollars,0),6) LakebaseRevShareDollars,
  round(coalesce(sales_comp_metric.openai_dbu,0),6) OpenAIDBUs,
  round(coalesce(sales_comp_metric.openai_dollars,0),6) OpenAIRevShareDollars,
  round(coalesce(sales_comp_metric.gemini_dbu,0),6) GeminiDBUs,
  round(coalesce(sales_comp_metric.gemini_dollars,0),6) GeminiRevShareDollars
from main.it_lakehouse.paid_usage_metering p
left join main.sfdc_bronze.workspace__c w 
  on p.sfdc_workspace_id = w.workspaceId__c
  and w.processDate = (
    select max(processDate)
    from main.sfdc_bronze.workspace__c
  )
where p.date >= '2021-01-01'

union all

select 
  sfdc_account_id accountID,
  sfdc_account_name accountName,
  round(0,6) AgentEvalsDBUs,
  round(0,6) AgentEvalsRevShareDollars,
  round(0,6) AgentEvalsSyntheticDataDBUs,
  round(0,6) AgentEvalsSyntheticDataRevShareDollars,
  round(0,6) AgentFrameworkDBUs,
  round(0,6) AgentFrameworkRevShareDollars,
  round(0,6) AIRuntimeDBUs,
  round(0,6) AIRuntimeRevShareDollars,
  round(0,6) AnthropicFoundationModelAPIDBUs,
  round(0,6) AnthropicFoundationModelAPIRevShareDollars,
  round(0,6) AnthropicThroughputModelServingDBUs,
  round(0,6) AnthropicThroughputModelServingRevShareDollars,
  round(0,6) BatchInferenceModelServingDBUs,
  round(0,6) BatchInferenceModelServingRevShareDollars,
  Null as businessSubscriptionID,
  round(0,6) CPUModelServingRevShareDollars,
  round(0,6) dbt_dbu_quantity,
  round(dbu_dollars,6) revShareDollars,
  round(dbu,4) dbu_quantity,
  0 dbuCustPrice,
  cast(0 as double) dbuRevSharePrice,
  round(0,6) delta_dbu_quantity,
  Null as deployedRegion,
  round(0,6) FinetuningDBUs,
  round(0,6) FinetuningRevShareDollars,
  round(0,6) fivetran_dbu_quantity,
  round(0,6) FmBgeLargeENDBUs,
  round(0,6) FmBgeLargeENRevShareDollars,
  round(0,6) FmDatabricksDbrxChatDBUs,
  round(0,6) FmDatabricksDbrxChatRevShareDollars,
  round(0,6) FmLlama270bChatDBUs,
  round(0,6) FmLlama270bChatRevShareDollars,
  round(0,6) FmMixtral87bInstructDBUs,
  round(0,6) FmMixtral87bInstructRevShareDollars,
  round(0,6) FmMpt30bInstructDBUs,
  round(0,6) FmMpt30bInstructRevShareDollars,
  round(0,6) FmMpt7bInstructDBUs,
  round(0,6) FmMpt7bInstructRevShareDollars,
  round(0,6) foundation_model_api_dbu_quantity,
  round(0,6) FoundationModelAPIRevShareDollars,
  round(0,6) FoundationModelTrainingRevShareDollars,
  round(0,6) FY26AIDBUs,
  round(0,6) FY26AIDollars,
  round(0,6) gen_ai_dbu_quantity,
  round(0,6) GenAIRevShareDollars,
  round(0,6) gpu_model_serving_dbu_quantity,
  round(0,6) GPUModelServingRevShareDollars,
  null isPaying,
  round(0,6) isv_dbu_quantity,
  round(0,6) LakeflowConnectDBUs,
  round(0,6) LakeflowConnectRevShareDollars,
  round(0,6) LakeflowDBUs,
  round(0,6) LakeflowRevShareDollars,
  round(0,6) LakeflowPipelinesDBUs,
  round(0,6) LakeflowPipelinesRevShareDollars,
  round(0,6) LakehouseMonitoringDBUs,
  round(0,6) LakehouseMonitoringRevShareDollars,
  0 listPrice,
  round(0,6) MCTRevShareDollars,
  round(0,6) mct_dbu_quantity,
  round(0,6) MCTModelHeroRunTrainingRevShareDollars,
  round(0,6) MCTModelOnDemandTrainingRevShareDollars,
  round(0,6) MCTModelReservedTrainingRevShareDollars,
  round(0,6) ml_dbu_quantity,
  round(0,6) ModelServingFMAPIDBUs,
  round(0,6) ModelServingFMAPIRevShareDollars,
  'aws' platform,
  0 as shield_dollars,
  round(0,6) streaming_dlt_dbu_quantity,
  round(0,6) StreamingDLTRevShareDollars,
  round(0,6) throughput_model_serving_dbu_quantity,
  round(0,6) ThroughputModelServingRevShareDollars,
  round(0,6) UCRevShareDollars,
  round(0,6) uc_dbu_quantity,
  usage_date,
  'NA' usage_sku,
  round(0,6) vector_search_dbu_quantity,
  round(0,6) VectorSearchRevShareDollars,
  round(0,6) VectorSearchIngestionRevShareDollars,
  round(0,6) VectorSearchServingRevShareDollars,
  round(0,6) VectorSearchStorageDBUs,
  round(0,6) VectorSearchStorageRevShareDollars,
  Null as workspaceId,
  Null workspaceSFDCID,
  dbu_dollars as custDollars,
  round(0,6) LakebaseDBUs,
  round(0,6) LakebaseRevShareDollars,
  round(0,6) OpenAIDBUs,
  round(0,6) OpenAIRevShareDollars,
  round(0,6) GeminiDBUs,
  round(0,6) GeminiRevShareDollars
from pvc_pubsec
),
product_dim as (
  select distinct 
    meterSubCategory skuType, 
    meterName 
  from main.it_core_dim.bi_product_dim
  where meterCategory = 'workloads'
  and coalesce(meterSubCategory,'') <> 'virtual'
),
usage_w_product_dim as (
  select
    u.*,
    p.skuType,
    date_format(usage_date, 'yyyy-MM') as month,
    round(listPrice*dbu_quantity, 6) as listDollars,
    round(dbuRevSharePrice*delta_dbu_quantity,6) as DeltaRevShareDollars,
    round(dbuRevSharePrice*isv_dbu_quantity,6) as ISVRevShareDollars,
    round(dbuRevSharePrice*dbt_dbu_quantity,6) as DBTRevShareDollars,
    round(dbuRevSharePrice*fivetran_dbu_quantity,6) as FivetranRevShareDollars,
    round(dbuRevSharePrice*streaming_dlt_dbu_quantity,6) as StreamingDLTRevShareDollars_calculated,
    round(dbuRevSharePrice*ml_dbu_quantity,6) as MLRevShareDollars,
    round(dbuRevSharePrice*uc_dbu_quantity,6) as UCRevShareDollars_calculated,
    if(p.skuType = 'interactive',dbu_quantity,0) as InteractiveDBUs,
    if(p.skuType = 'automated',dbu_quantity,0) as AutomatedDBUs,
    if(p.skuType = 'interactive',delta_dbu_quantity,0) as DeltaInteractiveDBUs,
    if(p.skuType = 'automated',delta_dbu_quantity,0) as DeltaAutomatedDBUs,
    if(p.skuType in ('sql', 'virtual'),delta_dbu_quantity,0) as DeltaSQLDBUs,
    if(p.skuType in ('sql', 'virtual'),dbu_quantity,0) as SQLAnalyticsDBUs,
    if(p.skuType in ('sql', 'virtual'),dbuRevSharePrice*dbu_quantity,0) as SQLRevShareDollars,
    case 
      when usage_sku like '%enterprise%' then 'Enterprise'
      when usage_sku like '%premium%' then 'Premium'
      else 'Standard'
    end as EntitlementTier,
    case 
      when usage_sku like '%enterprise%' then 0.0
      when usage_sku like '%premium%' then 0.0
      else dbu_quantity
    end as StandardDBUs,
    case 
      when usage_sku like '%enterprise%' then 0.0
      when usage_sku like '%premium%' then dbu_quantity
      else 0.0
    end as PremiumDBUs,
    case 
      when usage_sku like '%enterprise%' then dbu_quantity
      when usage_sku like '%premium%' then 0.0
      else 0.0
    end as EnterpriseDBUs,
    case 
      when usage_sku like '%enterprise%' then 0.0
      when usage_sku like '%premium%' then 0.0
      else dbu_quantity*dbuRevSharePrice
    end as StandardRevShareDollars,
    case 
      when usage_sku like '%enterprise%' then 0.0
      when usage_sku like '%premium%' then dbu_quantity*dbuRevSharePrice
      else 0.0
    end as PremiumRevShareDollars,
    case 
      when usage_sku like '%enterprise%' then dbu_quantity*dbuRevSharePrice
      when usage_sku like '%premium%' then 0.0
      else 0.0
    end as EnterpriseRevShareDollars,
    if(lower(usage_sku) like '%serverless%',dbu_quantity,0) as ServerlessDBUs,
    if(lower(usage_sku) like '%serverless%',dbu_quantity*dbuRevSharePrice,0) as ServerlessRevShareDollars,
    if(lower(usage_sku) like '%photon%',dbu_quantity,0) as PhotonDBUs,
    if(lower(usage_sku) like '%photon%',dbu_quantity*dbuRevSharePrice,0) as PhotonRevShareDollars,
    if(lower(usage_sku) like '%dlt%',dbu_quantity,0) as DLTDBUs,
    if(lower(usage_sku) like '%dlt%',dbu_quantity*dbuRevSharePrice,0) as DLTRevShareDollars,
    if(deployedRegion like '%china%',dbu_quantity,0) as MoonCakeDBUs,
    if(deployedRegion like '%china%',dbu_quantity*dbuRevSharePrice,0) as MoonCakeDBUDollars,
    if(deployedRegion like '%china%',delta_dbu_quantity,0) as MoonCakeDeltaDBUs,
    if(deployedRegion like '%china%',delta_dbu_quantity*dbuRevSharePrice,0) as MoonCakeDeltaDBUDollars,
    if(deployedRegion like '%china%' and skuType = 'sql',delta_dbu_quantity,0) as MoonCakeSQLDBUs,
    if(deployedRegion like '%china%' and skuType = 'sql',round(delta_dbu_quantity*dbuRevSharePrice,6),0) as MoonCakeSQLDollars
  from usage_combined u
  left join product_dim p
  on u.usage_sku = p.meterName  
)
select
  *,
  round(sum(listDollars) over (partition by (accountID, accountName, platform) order by usage_date rows between unbounded preceding and current row),2) as cumListDollars,
  round(sum(custDollars) over (partition by (accountID, accountName, platform) order by usage_date rows between unbounded preceding and current row),2) as cumCustDollars,
  round(sum(revShareDollars) over (partition by (accountID, accountName, platform) order by usage_date rows between unbounded preceding and current row),2) as cumDBDollars,
  round(sum(DeltaRevShareDollars) over (partition by (accountID, accountName, platform) order by usage_date rows between unbounded preceding and current row),2) as cumDeltaRevShareDollars,
  round(sum(DeltaInteractiveDBUs) over (partition by (accountID, accountName, platform) order by usage_date rows between unbounded preceding and current row),2) as cumDeltaInteractiveDBUs,
  round(sum(DeltaAutomatedDBUs) over (partition by (accountID, accountName, platform) order by usage_date rows between unbounded preceding and current row),2) as cumDeltaAutomatedDBUs,
  round(sum(InteractiveDBUs) over (partition by (accountID, accountName, platform) order by usage_date rows between unbounded preceding and current row),2) as cumInteractiveDBUs,
  round(sum(AutomatedDBUs) over (partition by (accountID, accountName, platform) order by usage_date rows between unbounded preceding and current row),2) as cumAutomatedDBUs,
  round(sum(SQLAnalyticsDBUs) over (partition by (accountID, accountName, platform) order by usage_date rows between unbounded preceding and current row),2) as cumSQLAnalyticsDBUs,
  round(sum(SQLRevShareDollars) over (partition by (accountID, accountName, platform) order by usage_date rows between unbounded preceding and current row),2) as cumSQLRevShareDollars,
  last_day(usage_date) as month_end_date
from usage_w_product_dim
""")
granular_table_df.createOrReplaceTempView("granular_table_df")

# COMMAND ----------

granular_table_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable("main.gtm_consumption_silver.granular_table")

