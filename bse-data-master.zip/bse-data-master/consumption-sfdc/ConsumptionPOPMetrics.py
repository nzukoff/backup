# Databricks notebook source
'''
This code generates 2 tables: Account and Account Platform level period over period metrics. These tables are primarily used for uploading to Salesforce.
'''

# COMMAND ----------

acct_period_over_period = spark.sql("""
with dates as (
  select
    date,
    week_start_date,
    date_add(week_start_date, 7) as next_week_start_date,
    date_add(week_start_date, 14) as two_weeks_start_date,
    date_add(week_start_date, -7) as prev_week_start_date,
    date_add(week_start_date, -14) as two_weeks_ago_start_date,
    date_add(week_start_date, -21) as three_weeks_ago_start_date,
    date_add(week_start_date, -28) as four_weeks_ago_start_date,
    date_add(prior_month_end_date, 1) as month_start_date,
    next_month_start_date,
    add_months(next_month_start_date,1) as two_months_start_date,
    add_months(next_month_start_date,2) as three_months_start_date,
    prior_month_start_date,
    add_months(prior_month_start_date, -1) as two_months_ago_start_date,
    add_months(prior_month_start_date, -2) as three_months_ago_start_date,
    fiscal_quarter_start_date,
    add_months(fiscal_quarter_start_date, -3) as prev_fiscal_quarter_start_date,
    add_months(fiscal_quarter_start_date, -6) as two_fiscal_quarters_ago_start_date,
    add_months(fiscal_quarter_start_date, 3) as next_fiscal_quarter_start_date,
    add_months(fiscal_quarter_start_date, 6) as two_fiscal_quarter_start_date,
    date_add(date,-8) as week_run_rate_start_date,
    date_add(date,-1) as week_run_rate_end_date,
    daysinmonth,
    day(next_month_end_date) as daysinnextmonth,
    day(date_add(add_months(next_month_start_date,2),-1)) as daysinnext2month
  from
    main.it_core_dim.bi_dates
  where
    date = current_date()
),
revshare_w_forecast as (
  select
    accountID,
    month_end_date,
    usage_date,
    if(revShareDollars>0,revShareDollars,revShareForecastDollars_new) as revShare_w_forecast,
    revShareDollars
  from main.gtm_consumption_silver.account_consumption_daily
)
select
  accountID,
  last_day(current_date()) as month_end_date,
  -- weekly
  sum(if(usage_date>=prev_week_start_date and usage_date<week_start_date,revShareDollars,0)) as RevShareLastWeek,
  sum(if(usage_date>=week_start_date and usage_date < next_week_start_date,revShare_w_forecast,0)) as RevShareCurrentWeek,
  sum(if(usage_date>=next_week_start_date and usage_date < two_weeks_start_date,revShare_w_forecast,0)) as RevShareNextWeek,
  sum(if(usage_date>=two_weeks_ago_start_date and usage_date < prev_week_start_date,revShareDollars,0)) as 2WeekAgoActuals,
  sum(if(usage_date>=three_weeks_ago_start_date and usage_date < two_weeks_ago_start_date,revShareDollars,0)) as 3WeekAgoActuals,
  sum(if(usage_date>=four_weeks_ago_start_date and usage_date < three_weeks_ago_start_date,revShareDollars,0)) as 4WeekAgoActuals,
  sum(if(usage_date>=week_start_date and usage_date < next_week_start_date,revShareDollars,0)) as RevShareDollarsWTD,
  sum(if(usage_date>=week_run_rate_start_date and usage_date < week_run_rate_end_date,revShareDollars,0)) as weekRunRate,

  -- monthly
  sum(if(usage_date>=prior_month_start_date and usage_date<month_start_date,revShareDollars,0)) as RevShareLastMonth,
  sum(if(usage_date>=month_start_date and usage_date<next_month_start_date,revShare_w_forecast,0)) as RevShareCurrentMonth,
  sum(if(usage_date>=next_month_start_date and usage_date<two_months_start_date,revShare_w_forecast,0)) as RevShareNextMonth,
  sum(if(usage_date>=two_months_ago_start_date and usage_date<prior_month_start_date,revShareDollars,0)) as 2MonthAgoActuals,
  sum(if(usage_date>=three_months_ago_start_date and usage_date<two_months_ago_start_date,revShareDollars,0)) as 3MonthAgoActuals,
  sum(if(usage_date>=month_start_date and usage_date<next_month_start_date,revShareDollars,0)) as RevShareDollarsMTD,
  sum(if(usage_date>=month_start_date and usage_date<next_month_start_date,revShare_w_forecast,0)) as CurrentMonth_DSForecastDBUDollars,
  sum(if(usage_date>=next_month_start_date and usage_date<two_months_start_date,revShare_w_forecast,0)) as NextMonth_DSForecastDBUDollars,
  sum(if(usage_date>=two_months_start_date and usage_date<three_months_start_date,revShare_w_forecast,0)) as Next2Month_DSForecastDBUDollars,
  sum(if(usage_date>=week_run_rate_start_date and usage_date < week_run_rate_end_date,revShareDollars*daysinmonth,0))/7 as curMonthRunRate,
  sum(if(usage_date>=week_run_rate_start_date and usage_date < week_run_rate_end_date,revShareDollars*daysinnextmonth,0))/7 as nextMonthRunRate,
  sum(if(usage_date>=week_run_rate_start_date and usage_date < week_run_rate_end_date,revShareDollars*daysinnext2month,0))/7 as next2MonthRunRate,
  sum(if(usage_date>=three_months_ago_start_date and usage_date<month_start_date,revShareDollars,0)) as T3MRevShareDollars,

  -- quarter
  sum(if(usage_date>=prev_fiscal_quarter_start_date and usage_date<fiscal_quarter_start_date,revShareDollars,0)) as RevShareLastQtr,
  sum(if(usage_date>=fiscal_quarter_start_date and usage_date<next_fiscal_quarter_start_date,revShare_w_forecast,0)) as RevShareCurrentQtr,
  sum(if(usage_date>=next_fiscal_quarter_start_date and usage_date<two_fiscal_quarter_start_date,revShare_w_forecast,0)) as RevShareNextQtr,
  sum(if(usage_date>=two_fiscal_quarters_ago_start_date and usage_date<prev_fiscal_quarter_start_date,revShareDollars,0)) as 2QTRAgoActuals,
  sum(if(usage_date>=fiscal_quarter_start_date and usage_date<next_fiscal_quarter_start_date,revShareDollars,0)) as RevShareDollarsQTD

from revshare_w_forecast
cross join dates
group by all
""")

# COMMAND ----------

acct_period_over_period.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable("main.gtm_consumption_silver.account_salesforce_upload")

# COMMAND ----------

acct_plat_period_over_period = spark.sql("""
with dates as (
  select
    date,
    week_start_date,
    date_add(week_start_date, 7) as next_week_start_date,
    date_add(week_start_date, 14) as two_weeks_start_date,
    date_add(week_start_date, -7) as prev_week_start_date,
    date_add(week_start_date, -14) as two_weeks_ago_start_date,
    date_add(week_start_date, -21) as three_weeks_ago_start_date,
    date_add(week_start_date, -28) as four_weeks_ago_start_date,
    date_add(prior_month_end_date, 1) as month_start_date,
    next_month_start_date,
    add_months(next_month_start_date,1) as two_months_start_date,
    add_months(next_month_start_date,2) as three_months_start_date,
    prior_month_start_date,
    add_months(prior_month_start_date, -1) as two_months_ago_start_date,
    add_months(prior_month_start_date, -2) as three_months_ago_start_date,
    fiscal_quarter_start_date,
    add_months(fiscal_quarter_start_date, -3) as prev_fiscal_quarter_start_date,
    add_months(fiscal_quarter_start_date, -6) as two_fiscal_quarters_ago_start_date,
    add_months(fiscal_quarter_start_date, 3) as next_fiscal_quarter_start_date,
    add_months(fiscal_quarter_start_date, 6) as two_fiscal_quarter_start_date,
    date_add(date,-8) as week_run_rate_start_date,
    date_add(date,-1) as week_run_rate_end_date,
    daysinmonth,
    day(next_month_end_date) as daysinnextmonth,
    day(date_add(add_months(next_month_start_date,2),-1)) as daysinnext2month
  from
    main.it_core_dim.bi_dates
  where
    date = current_date()
),
cum_values as (
  select
  distinct
  accountID,
  platform,
  cumAutomatedDBUs,
  cumCustDollars,
  cumInteractiveDBUs,
  cumListDollars,
  cumRevShareDollars,
  cumSQLAnalyticsDBUs,
  cumRevShareDollars,
  cumDeltaAutomatedDBUs,
  cumDeltaInteractiveDBUs,
  cumDeltaRevShareDollars,
  cumSQLRevShareDollars
  from main.gtm_consumption_silver.account_platform_consumption_monthly
  where month_end_date = last_day(current_date())
),
m as (
select
  accountID,
  platform,
  concat(accountId,platform) as Unique_Id__c,
  sum(if(usage_date>=month_start_date,revShareDollars,0)) as revShareDollars,
  sum(if(usage_date>=month_start_date,AutomatedDBUs,0)) as AutomatedDBUs,
  sum(if(usage_date>=month_start_date,custDollars,0)) as custDollars,
  sum(if(usage_date>=month_start_date,DBUs,0)) as DBUs,
  sum(if(usage_date>=month_start_date,InteractiveDBUs,0)) as InteractiveDBUs,
  sum(if(usage_date>=month_start_date,listDollars,0)) as listDollars,
  sum(if(usage_date>=month_start_date,DeltaRevShareDollars,0)) as DeltaRevShareDollars,
  sum(if(usage_date>=month_start_date,DeltaAutomatedDBUs,0)) as DeltaAutomatedDBUs,
  sum(if(usage_date>=month_start_date,DeltaInteractiveDBUs,0)) as DeltaInteractiveDBUs,
  sum(if(usage_date>=month_start_date,SQLAnalyticsDBUs,0)) as SQLAnalyticsDBUs,
  sum(if(usage_date>=month_start_date,SQLRevShareDollars,0)) as SQLRevShareDollars,
  sum(if(usage_date>=prev_week_start_date and usage_date<week_start_date,revShareDollars,0)) as RevShareLastWeek,
  sum(if(usage_date>=week_start_date and usage_date < next_week_start_date,revShareDollars,0)) as RevShareDollarsWTD,
  sum(if(usage_date>=prior_month_start_date and usage_date<month_start_date,revShareDollars,0)) as RevShareLastMonth,
  sum(if(usage_date>=month_start_date and usage_date<next_month_start_date,revShareDollars,0)) as RevShareDollarsMTD,
  sum(if(usage_date>=prev_fiscal_quarter_start_date and usage_date<fiscal_quarter_start_date,revShareDollars,0)) as RevShareLastQtr,
  sum(if(usage_date>=fiscal_quarter_start_date and usage_date<next_fiscal_quarter_start_date,revShareDollars,0)) as RevShareDollarsQTD,
  sum(if(usage_date>=three_months_ago_start_date and usage_date<month_start_date,revShareDollars,0)) as T3MRevShareDollars,
  sum(if(usage_date>=three_months_ago_start_date and usage_date<month_start_date,EnterpriseDBUs,0)) as T3MEnterpriseDBUs,
  sum(if(usage_date>=three_months_ago_start_date and usage_date<month_start_date,PremiumDBUs,0)) as T3MPremiumDBUs,
  sum(if(usage_date>=three_months_ago_start_date and usage_date<month_start_date,StandardDBUs,0)) as T3MStandardDBUs,
  sum(if(usage_date>=three_months_ago_start_date and usage_date<month_start_date,EnterpriseRevShareDollars,0)) as T3MEnterpriseRevShareDollars,
  sum(if(usage_date>=three_months_ago_start_date and usage_date<month_start_date,PremiumRevShareDollars,0)) as T3MPremiumRevShareDollars,
  sum(if(usage_date>=three_months_ago_start_date and usage_date<month_start_date,StandardRevShareDollars,0)) as T3MStandardRevShareDollars
from main.gtm_consumption_silver.account_platform_consumption_daily
cross join dates
group by all
)
select
  last_day(current_date()) as month_end_date,
  m.* except (platform, accountID),
  coalesce(m.accountID,cum_values.accountID) as accountID,
  coalesce(m.platform,cum_values.platform) as platform,
  cumAutomatedDBUs,
  cumCustDollars,
  cumInteractiveDBUs,
  cumListDollars,
  cumRevShareDollars,
  cumSQLAnalyticsDBUs,
  cumDeltaAutomatedDBUs,
  cumDeltaInteractiveDBUs,
  cumDeltaRevShareDollars,
  cumSQLRevShareDollars
from m full outer join cum_values on m.platform = cum_values.platform and m.accountID = cum_values.accountID
""")

# COMMAND ----------

acct_plat_period_over_period.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable("main.gtm_consumption_silver.account_platform_salesforce_upload")
