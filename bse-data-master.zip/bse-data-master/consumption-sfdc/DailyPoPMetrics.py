# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

from datetime import datetime, timedelta
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

aggOrderConsumpCastDaily = spark.sql(f"select * from {USAGEC_AGGORDER_DAILY}")
platMonthly = spark.sql(f"select * from {USAGEC_PLATFORM_MONTHLY}")
dates_df = spark.sql(f"select date, year, fiscalYear, fiscalQuarter, month, week, week_start_date, month_end_date from {BI_DATES}")

# COMMAND ----------

current_date = datetime.today()
today = dates_df.filter(dates_df.date==current_date.date()).collect()[0]
year, fiscalYear, fiscalQuarter, month, week, month_end_date  = today.year, today.fiscalYear, today.fiscalQuarter, today.month,  today.week, today.month_end_date
print(year, fiscalYear, fiscalQuarter, month, week, month_end_date, current_date.date())

# COMMAND ----------

################# weeks
prev_week = spark.sql(f"""
select date, 
       week,
       week_start_date,
       fiscalYear
from {BI_DATES}
where date <= date_sub(current_date(), 7)
order by date desc
limit 1
""").collect()[0]
print('prev-week:', prev_week.week, 'fiscalYear: ', prev_week.fiscalYear, 'prev-week-start-date:', prev_week.week_start_date)

next_week = spark.sql(f"""
select date, 
       week,
       fiscalYear
from {BI_DATES}
where date >= date_add(current_date(), 7)
order by date
limit 1
""").collect()[0]
print('next-week:', next_week.week, 'fiscalYear: ', next_week.fiscalYear)


################# months
prev_month = spark.sql(f"""
select month_end_date,
       month,
       fiscalYear
from {BI_DATES}
where date < current_date()
and isMonthEnd = 1
order by 1 desc
limit 1
""").collect()[0]

print("prev-month: ", prev_month.month, 'fiscalYear: ', prev_month.fiscalYear, ' prev-month-end-date: ', prev_month.month_end_date)

next_month = spark.sql(f"""
select month_end_date,
       month,
       fiscalYear
from {BI_DATES}
where date >= current_date()
and isMonthEnd = 1
order by 1 
limit 2
""").collect()[1]
print("next-month: ", next_month.month, 'fiscalYear: ', next_month.fiscalYear)



################# quarters
prev_fiscal = spark.sql(f"""
select distinct
       fiscalYear,
       fiscalQuarter
from {BI_DATES}
where date <= current_date()
order by 1 desc, 2 desc
limit 2
""").collect()[1]

prev_fiscalQuarter = prev_fiscal.fiscalQuarter
prev_fiscalYear = prev_fiscal.fiscalYear
print("prev-fiscals: ", prev_fiscalQuarter, prev_fiscalYear)

next_fiscal = spark.sql(f"""
select distinct
       fiscalYear,
       fiscalQuarter
from {BI_DATES}
where date >= current_date()
order by 1, 2 
limit 2
""").collect()[1]

next_fiscalQuarter = next_fiscal.fiscalQuarter
next_fiscalYear = next_fiscal.fiscalYear
print("next-fiscals: ", next_fiscalQuarter, next_fiscalYear)

# COMMAND ----------

current_fiscal = spark.sql(f"""
select date,
       week,
       week_start_date,
       month,
       month_end_date,
       fiscalYear,
       fiscalQuarter
from {BI_DATES}
where date = current_date()
""").collect()[0]
print("current-fiscals: ", current_fiscal.date, 'current-week: ', current_fiscal.week, 'current-month: ', current_fiscal.month, 'current-fy: ', current_fiscal.fiscalYear, current_fiscal.fiscalQuarter, current_fiscal.month_end_date, 'current-week-start-date: ', current_fiscal.week_start_date)

# COMMAND ----------

display(dates_df.filter(dates_df.date == current_date.date()))

# COMMAND ----------

@udf('double')
def revShareTotalDollars(revShareDollars, revShareForecastDollars, usage_date):
  """ temporary fix, todo: fix in aggorder """
  if revShareDollars is None:
    revShareDollars = 0.0
  if usage_date < (datetime.today().date()-timedelta(days=2)):
    return revShareDollars
    
  return revShareDollars + revShareForecastDollars


currentDateMetrics = aggOrderConsumpCastDaily.join(dates_df, aggOrderConsumpCastDaily.usage_date==dates_df.date)\
                                             .drop(dates_df.date)

#currentDateMetrics = currentDateMetrics.withColumn("revShareTotalDollars", col("revShareDollars")+ col("revShareForecastDollars"))
currentDateMetrics = currentDateMetrics.withColumn("revShareTotalDollars", revShareTotalDollars("revShareDollars","revShareForecastDollars","usage_date")).dropDuplicates(['aggOrder', 'usage_date', 'revShareTotalDollars'])
currentDateMetrics.createOrReplaceTempView("currentDateMetrics")

# COMMAND ----------

#todo fix: prev and current week discovery across two fiscalYears
# the prev week, current week can be identified across either Year/fiscalYear, however, when the fiscalYear changes within the same Year, the prevweek will be incorrect.
# temp fix: changing the fiscalYear to Year for partitions

# weeknumbers 
week_numbers_query = """
with
las (
select accountId, platform, sum(revShareDollars) weekShare from currentDateMetrics where week_start_date = "{0}" group by 1,2
),
cur (
select accountId, platform, sum(revShareTotalDollars) weekShare, sum(revShareDollars) as wtd from currentDateMetrics where week_start_date = "{1}" group by 1,2
)

select coalesce(lm.accountId, cm.accountId) accountId,
       coalesce(lm.platform,cm.platform) platform,
       "{2}" as month_end_date,
       coalesce(lm.weekShare, 0) RevShareLW,
       coalesce(cm.weekShare, 0) RevShareCW,
       coalesce(cm.wtd, 0) RevShareDollarsWTD
from las lm 
full join cur cm on lm.accountId = cm.accountId and lm.platform = cm.platform
""".format(prev_week.week_start_date, current_fiscal.week_start_date, current_fiscal.month_end_date)


weeknumbers = spark.sql(week_numbers_query)
weeknumbers = weeknumbers.dropDuplicates()

# month numbers
month_numbers_query = """
with 
las (
select accountId, platform, month_end_date, sum(revShareDollars) as monthShare from currentDateMetrics where month_end_date = "{0}" group by 1,2,3
),
cur (
select accountId, platform, month_end_date, sum(revShareTotalDollars) as monthShare, sum(revShareDollars) as mtd from currentDateMetrics where month_end_date = "{1}" group by 1,2,3
)

select coalesce(lm.accountId, cm.accountId) accountId,
       coalesce(lm.platform,cm.platform) platform,
       cast(coalesce(cm.month_end_date, "{1}") as date) month_end_date,
       coalesce(lm.monthShare, 0) RevShareLM,
       coalesce(cm.monthShare, 0) RevShareCM,
       coalesce(cm.mtd, 0) RevShareDollarsMTD
from las lm 
full join cur cm on lm.accountId = cm.accountId and lm.platform = cm.platform
""".format(prev_month.month_end_date, current_fiscal.month_end_date)

monthnumbers = spark.sql(month_numbers_query)

# quarter numbers
quarternumbers = spark.sql("""
with quarternumbers (
select *,
       round(sum(revShareTotalDollars) over(partition by accountId, platform, fiscalYear, fiscalQuarter),2) quarterShare,
       round(sum(revShareDollars) over(partition by accountId, platform, fiscalYear, fiscalQuarter),2) qtd
from currentDateMetrics
order by accountId, accountName, platform, usage_date
),
las (
select distinct accountId, platform, quarterShare from quarternumbers where fiscalYear = {0} and fiscalQuarter = {1}
),
cur (
select distinct accountId, platform, quarterShare, qtd from quarternumbers where fiscalYear = {2} and fiscalQuarter = {3}
)

select coalesce(lm.accountId, cm.accountId) accountId,
       coalesce(lm.platform,cm.platform) platform,
       coalesce(lm.quarterShare, 0) RevShareLQ,
       coalesce(cm.quarterShare, 0) RevShareCQ,
       coalesce(cm.qtd, 0) RevShareDollarsQTD
from las lm 
full join cur cm on lm.accountId = cm.accountId and lm.platform = cm.platform
""".format(prev_fiscal.fiscalYear, prev_fiscal.fiscalQuarter, fiscalYear, fiscalQuarter, current_date)
)

quarter_month = quarternumbers.join(monthnumbers,\
                                    (quarternumbers.accountId==monthnumbers.accountId) & (quarternumbers.platform==monthnumbers.platform), 'left')\
                              .drop(monthnumbers.accountId)\
                              .drop(monthnumbers.platform)
quarter_month = quarter_month.withColumn("RevShareLM", coalesce(col("RevShareLM"), lit(0)))\
                             .withColumn("RevShareCM", coalesce(col("RevShareCM"), lit(0)))\
                             .withColumn("month_end_date", lit(month_end_date).cast("date"))

quarter_month_week = quarter_month.join(weeknumbers,\
                                        (quarter_month.accountId==weeknumbers.accountId) & (quarter_month.platform==weeknumbers.platform) &\
                                        (quarter_month.month_end_date==weeknumbers.month_end_date), 'left')\
                                 .withColumn("RevShareLW", coalesce(weeknumbers.RevShareLW, lit(0)))\
                                 .withColumn("RevShareCW", coalesce(weeknumbers.RevShareCW, lit(0)))\
                                 .drop(weeknumbers.accountId)\
                                 .drop(weeknumbers.platform)\
                                 .drop(weeknumbers.month_end_date).drop(weeknumbers.RevShareLW).drop(weeknumbers.RevShareCW)

# COMMAND ----------

quarter_month_week.createOrReplaceTempView('quarter_month_week')

# COMMAND ----------

nextWeek = spark.sql("""
with weeknumbers (
select *,
       round(sum(revShareTotalDollars) over(partition by accountId, platform, fiscalYear, week),2) weekShare
from currentDateMetrics
order by accountId, accountName, platform, usage_date
)

select distinct
       accountId waccountId,
       platform wplatform,
       weekShare RevShareNextWeek
from weeknumbers
where fiscalYear = {0} and week = {1}
""".format(next_week.fiscalYear, next_week.week)
)

nextMonth = spark.sql("""
with monthnumbers (
select *,
       round(sum(revShareTotalDollars) over(partition by accountId, platform, fiscalYear, month),2) monthShare
from currentDateMetrics
order by accountId, accountName, platform, usage_date
)

select distinct
       accountId maccountId,
       platform mplatform,
       monthShare RevShareNextMonth
from monthnumbers
where fiscalYear = {0} and month = {1}
""".format(next_month.fiscalYear, next_month.month)
)

if (fiscalQuarter) == 4:
  nextfiscalYear = fiscalYear + 1
  nextfiscalQuarter = 1
else:
  nextfiscalYear = fiscalYear
  nextfiscalQuarter = fiscalQuarter+1

nextQuarter = spark.sql("""
with quarternumbers (
select *,
       round(sum(revShareTotalDollars) over(partition by accountId, platform, fiscalYear, fiscalQuarter),2) quarterShare
from currentDateMetrics
order by accountId, accountName, platform, usage_date
)

select distinct
       accountId,
       platform,
       quarterShare RevShareNextQtr
from quarternumbers
where fiscalYear = {0} and fiscalQuarter = {1}
""".format(next_fiscal.fiscalYear, next_fiscal.fiscalQuarter)
)

# COMMAND ----------

print(next_fiscal.fiscalYear, next_fiscal.fiscalQuarter)

# COMMAND ----------

nextQuarterMonth = nextQuarter.join(nextMonth,\
                                    (nextQuarter.accountId==nextMonth.maccountId) & (nextQuarter.platform==nextMonth.mplatform), 'full')\
                              .withColumn("RevShareNextQtr", coalesce(nextQuarter.RevShareNextQtr, lit(0)))\
                              .withColumn("RevShareNextMonth", coalesce(nextMonth.RevShareNextMonth, lit(0)))\
                              .drop(nextMonth.maccountId)\
                              .drop(nextMonth.mplatform)

nextQuarterMonthWeek = nextQuarterMonth.join(nextWeek,\
                                    (nextQuarterMonth.accountId==nextWeek.waccountId) & (nextQuarterMonth.platform==nextWeek.wplatform), 'full')\
                              .withColumn("RevShareNextQtr", coalesce(nextQuarterMonth.RevShareNextQtr, lit(0)))\
                              .withColumn("RevShareNextMonth", coalesce(nextQuarterMonth.RevShareNextMonth, lit(0)))\
                              .withColumn("RevShareNextWeek", coalesce(nextWeek.RevShareNextWeek, lit(0)))\
                              .drop(nextWeek.waccountId)\
                              .drop(nextWeek.wplatform)


allQuarterMonthWeek = quarter_month_week.join(nextQuarterMonthWeek,\
                     (quarter_month_week.accountId==nextQuarterMonthWeek.accountId) & (quarter_month_week.platform==nextQuarterMonthWeek.platform), 'left')\
                              .withColumn("RevShareNextWeek", coalesce(nextQuarterMonthWeek.RevShareNextWeek, lit(0)))\
                              .withColumn("RevShareNextMonth", coalesce(nextQuarterMonthWeek.RevShareNextMonth, lit(0)))\
                              .withColumn("RevShareNextQtr", coalesce(nextQuarterMonthWeek.RevShareNextQtr, lit(0)))\
                              .drop(nextQuarterMonthWeek.accountId)\
                              .drop(nextQuarterMonthWeek.platform)
#display(nextQuarterMonthWeek)

# COMMAND ----------

allQuarterMonthWeek.createOrReplaceTempView("numbers")
platMonthly.createOrReplaceTempView("platMonthly")

# COMMAND ----------

accountsToBeProcessed = spark.sql("""
select n.accountId,
       n.platform,
       n.month_end_date,
       coalesce(p.Listcommit, 0) ListCommit,
       coalesce(p.Discountedcommit, 0) DiscountedCommit,
       coalesce(p.RevSharecommit, 0) RevShareCommit,
       coalesce(p.listDollars, 0) listDollars,
       coalesce(p.custDollars, 0) custDollars,
       coalesce(p.revShareDollars, 0) revShareDollars,
       coalesce(p.InteractiveDBUs, 0) InteractiveDBUs,
       coalesce(p.AutomatedDBUs, 0) AutomatedDBUs,
       coalesce(p.DeltaRevShareDollars, 0) DeltaRevShareDollars,
       coalesce(p.DeltaInteractiveDBUs, 0) DeltaInteractiveDBUs,
       coalesce(p.DeltaAutomatedDBUs, 0) DeltaAutomatedDBUs, 
       coalesce(p.SQLAnalyticsDBUs, 0) SQLAnalyticsDBUs,  
       coalesce(p.SQLRevShareDollars, 0) SQLRevShareDollars,         
       coalesce(p.listForecastDollars, 0)   listForecastDollars,
       coalesce(p.custForecastDollars, 0)   custForecastDollars,
       coalesce(p.revShareForecastDollars, 0)   revShareForecastDollars,       
       coalesce(p.InteractiveForecastDBUs, 0)   InteractiveForecastDBUs,
       coalesce(p.AutomatedForecastDBUs, 0)   AutomatedForecastDBUs,
       coalesce(p.SQLAnalyticsForecastDBUs, 0) SQLAnalyticsForecastDBUs,  
       coalesce(p.SQLRevShareForecastDollars, 0) SQLRevShareForecastDollars,        
       coalesce(p.DBUs, 0) DBUs,        
       coalesce(p.cumListDollars, 0)   cumListDollars,       
       coalesce(p.cumCustDollars, 0)   cumCustDollars,
       coalesce(p.cumRevShareDollars, 0)   cumRevShareDollars,
       coalesce(p.cumInteractiveDBUs, 0)   cumInteractiveDBUs,       
       coalesce(p.cumAutomatedDBUs, 0)   cumAutomatedDBUs,
       coalesce(p.cumListForecastDollars, 0)   cumListForecastDollars,
       coalesce(p.cumCustForecastDollars, 0)   cumCustForecastDollars,
       coalesce(p.cumRevShareForecastDollars, 0)   cumRevShareForecastDollars,
       coalesce(p.cumInteractiveForecastDBUs, 0)   cumInteractiveForecastDBUs,
       coalesce(p.cumAutomatedForecastDBUs, 0)   cumAutomatedForecastDBUs,
       coalesce(p.cumDeltaRevShareDollars, 0) cumDeltaRevShareDollars,
       coalesce(p.cumDeltaInteractiveDBUs, 0) cumDeltaInteractiveDBUs,
       coalesce(p.cumDeltaAutomatedDBUs, 0) cumDeltaAutomatedDBUs,  
       coalesce(p.cumSQLAnalyticsDBUs, 0) cumSQLAnalyticsDBUs,  
       coalesce(p.cumSQLRevShareDollars, 0) cumSQLRevShareDollars,        
       coalesce(p.cumSQLAnalyticsForecastDBUs, 0) cumSQLAnalyticsForecastDBUs,  
       coalesce(p.cumSQLRevShareForecastDollars, 0) cumSQLRevShareForecastDollars,        
       n.RevShareLQ RevShareLastQtr,
       n.RevShareCQ RevShareCurrentQtr,
       n.RevShareDollarsQTD,
       n.RevShareLM RevShareLastMonth,
       n.RevShareCM RevShareCurrentMonth,
       n.RevShareDollarsMTD,
       n.RevShareLW RevShareLastWeek,
       n.RevShareCW RevShareCurrentWeek,
       n.RevShareDollarsWTD,
       n.RevShareNextQtr,
       n.RevShareNextMonth,
       n.RevShareNextWeek
from numbers n
left join platMonthly p on n.accountId=p.accountId and n.platform=p.platform and n.month_end_date=p.month_end_date
""")
accountsToBeProcessed.createOrReplaceTempView("usagec_popmetrics")
accountsToBeProcessed.count()

# COMMAND ----------

t3mDollars = spark.sql(f"""
with last3Months (
select month_end_date
from {BI_DATES}
where date < current_date()
and isMonthEnd = 1
order by 1 desc
limit 3
)
select upm.accountId,
       upm.platform,
       round(sum(upm.revShareDollars),2) T3MRevShareDollars,
       round(sum(upm.StandardDBUs),2) T3MStandardDBUs,
       round(sum(upm.PremiumDBUs),2) T3MPremiumDBUs,
       round(sum(upm.EnterpriseDBUs),2) T3MEnterpriseDBUs,
       round(sum(upm.StandardRevShareDollars),2) T3MStandardRevShareDollars,
       round(sum(upm.PremiumRevShareDollars),2) T3MPremiumRevShareDollars,
       round(sum(upm.EnterpriseRevShareDollars),2) T3MEnterpriseRevShareDollars      
from {USAGEC_PLATFORM_MONTHLY} upm
join last3Months l3m on upm.month_end_date = l3m.month_end_date
group by 1,2
""")
t3mDollars.createOrReplaceTempView('t3mDollars')

# COMMAND ----------

popMetricsExtended = spark.sql("""
select pop.*,
       coalesce(t3m.T3MRevShareDollars, 0.0) T3MRevShareDollars,
       coalesce(t3m.T3MStandardDBUs, 0) T3MStandardDBUs,
       coalesce(t3m.T3MPremiumDBUs, 0) T3MPremiumDBUs,
       coalesce(t3m.T3MEnterpriseDBUs, 0) T3MEnterpriseDBUs,
       coalesce(t3m.T3MStandardRevShareDollars, 0.0) T3MStandardRevShareDollars,
       coalesce(t3m.T3MPremiumRevShareDollars, 0.0) T3MPremiumRevShareDollars,
       coalesce(t3m.T3MEnterpriseRevShareDollars, 0.0) T3MEnterpriseRevShareDollars
from usagec_popmetrics pop
left join t3mdollars t3m on pop.accountId = t3m.accountId and pop.platform = t3m.platform
""")

# COMMAND ----------

popMetricsExtended.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_POPMETRICS)

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))
