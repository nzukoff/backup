# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def distributeDailyRevShareDollars(revShareDollars, daysinmonth):
  return revShareDollars/daysinmonth

@udf("double")
def distributeDailyInteractiveDBUs(InteractiveDBUs, daysinmonth):
  return InteractiveDBUs/daysinmonth

@udf("double")
def distributeDailyAutomatedDBUs(AutomatedDBUs, daysinmonth):
  return AutomatedDBUs/daysinmonth

@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  if platform == "azure":
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  return (cumDBDollars > RevShareCommit + 0.999) or (usage_date > endDate)

@udf("double")
def pctBurn(platform, aggOrder, ListCommit, RevShareCommit, cumListDollars, cumRevShareDollars, cumListForecastDollars, cumRevShareForecastDollars):
  pctBurn = 0.0
  if not 'MTM' in aggOrder:
    if platform == 'azure':
      return 0 if ListCommit==0 else ((cumListDollars + cumListForecastDollars) / ListCommit) * 100
    if platform == 'aws':
      return 0 if RevShareCommit==0 else ((cumRevShareDollars + cumRevShareForecastDollars) / RevShareCommit) * 100
  return pctBurn

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"

# COMMAND ----------

backup_pvc = spark.read.format("delta").load(USAGE_AGG_ORDER_DAILY_ADHOC_PVC_LOCATION)
backup_pvc.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(USAGE_AGG_ORDER_DAILY_ADHOC_PVC_BACKUP_LOCATION)

# COMMAND ----------

pvc_df = spark.sql(f"""
with pubsec (
select sfdc_account_id accountID,
       sfdc_account_name accountName,
       year,
       month,
       dbu,
       type,
       dbu_dollars dbuDollars
from {FINANCE_PUBSEC_USAGE}
),
common_accs (
select distinct f.sfdc_account_id accountID
from {FINANCE_PUBSEC_USAGE} f
join {FINANCE_PVC_USAGE} pvc on f.sfdc_account_id = pvc.sfdc_account_id
),
pvc_withoutcommon (
select pvc.sfdc_account_id accountID,
       pvc.sfdc_account_name accountName,
       pvc.year,
       pvc.month,
       pvc.dbu,
       pvc.type,
       pvc.dbu_dollars dbuDollars
from {FINANCE_PVC_USAGE} pvc
left join common_accs com on pvc.sfdc_account_id = com.accountID
where com.accountID is null
)
select *
from pvc_withoutcommon
union 
select *
from pubsec
""")

# COMMAND ----------

pvc_df.count()

# COMMAND ----------

dbuCols = ["dbu", "type"]
#pvc_df = spark.sql("select * from finance.pvc_usage ")
pvc_df = pvc_df.withColumnRenamed("accountID", "accountId")\
               .withColumnRenamed("dbuDollars", "revShareDollars")\
               .withColumn("type", lower(col("type")))\
               .withColumn("InteractiveDBUs", coalesce(interactive_dbus(*dbuCols), lit(0)))\
               .withColumn("AutomatedDBUs", coalesce(automated_dbus(*dbuCols), lit(0)))\
               .withColumn("DBUs", coalesce("dbu", lit(0)))

# COMMAND ----------

display(pvc_df)

# COMMAND ----------

date_df = spark.sql(f"""select date, year, month, daysinmonth, month_end_date from {BI_DATES}""")

# COMMAND ----------

pvc_date = pvc_df.join(date_df, (pvc_df.year==date_df.year) & (pvc_df.month==date_df.month))\
                 .drop(date_df.year)\
                 .drop(date_df.month)

dropColumns = ["ctc_flag", "year", "month", "ownerID", "OwnerName", "region", "l1Segment", "l2Segment", "l3Segment", "platform", "fiscalYear", "fiscalQtr", "type", "dbuPrice", "dbu", "adoptionYear", "adoptionMonth"]
pvc_date = pvc_date.withColumnRenamed("date", "usage_date")\
                   .drop(*dropColumns)

pvc_usage = pvc_date.withColumn("revShareDollars", round(distributeDailyRevShareDollars("revShareDollars", "daysinmonth"),2) )\
                   .withColumn("InteractiveDBUs", round(distributeDailyInteractiveDBUs("InteractiveDBUs", "daysinmonth"),2) )\
                   .withColumn("AutomatedDBUs", round(distributeDailyAutomatedDBUs("AutomatedDBUs", "daysinmonth"),2) )\
                   .withColumn("DBUs", round(distributeDailyAutomatedDBUs("DBUs", "daysinmonth"),2) )\
                   .drop("daysinmonth")\
                   .withColumn("listDollars", col("RevShareDollars"))\
                   .withColumn("custDollars", col("RevShareDollars"))

orderByColumns = ['accountID','accountName','usage_date']
pvc_usage = pvc_usage.orderBy(*orderByColumns)
pvc_usage.createOrReplaceTempView("pvc_usage")

# COMMAND ----------

pvc_orders = spark.read.format("delta").load(BI_AGGORDERS_PVC_LOCATION)
pvc_orders.createOrReplaceTempView("pvc_orders")

# COMMAND ----------

pvc_novl_contracts = spark.sql(f"""
with pvc_accounts (
select distinct sfdc_account_id accountId 
from {FINANCE_PVC_USAGE}
),
nextAggOrders (
select agg.*,
       coalesce(lead(agg.startDate) over(partition by agg.sfdcAccountID order by agg.startDate), date_add(agg.endDate, 1)) nextStartDate
from pvc_orders agg
join pvc_accounts m on agg.sfdcAccountID == m.accountId
where platform = 'aws'
and agg.aggOrder not like 'MTM%'
order by agg.sfdcAccountID, agg.startDate 
),

cleanAggOrders (
select *,
       case when datediff(nextStartDate, endDate)=1 then 0
            when nextStartDate >= endDate then 0
            else 1
       end as overLapFlag
from nextAggOrders
)

select sfdcAccountID,
       sum(overLapFlag) totalSum
from cleanAggOrders
group by sfdcAccountID
having totalSum = 0
""")
pvc_novl_contracts = pvc_novl_contracts.drop("totalSum")
display(pvc_novl_contracts)

# COMMAND ----------

pvc_orders_granular_query = """
with initial_usage_orders (
select ug.*,
       agg.platform,
       agg.aggOrder,
       agg.SubscriptionID,
       agg.scope,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase ListCommit,
       agg.ActualPartnerCommit DiscountedCommit,
       agg.DBShareCommit RevShareCommit,
       case when count(usage_date) over(partition by accountID, accountName, usage_date, revShareDollars, InteractiveDBUs, AutomatedDBUs) > 1 then 'true'
            else 'false'
       end as usageFlag,
       case when scope = 'shared'  then 'false'
            else 'true'
       end as scopeFlag
from pvc_usage ug
join pvc_orders agg on ug.accountID = agg.sfdcAccountID 
                         and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where agg.platform = 'aws'
order by usage_date
)

select *
from initial_usage_orders
where (usageFlag='true' and scopeFlag='true') or (usageFlag='false' and scopeFlag='false')
order by usage_date
"""

pvc_orders_granular_df = spark.sql(pvc_orders_granular_query)
dropColumns = ["usageFlag", "scopeFlag"]
pvc_orders_granular_df = pvc_orders_granular_df.drop(*dropColumns)

# COMMAND ----------

pvc_orders_granular_df.createOrReplaceTempView("pvc_orders_combined")

# COMMAND ----------

pvc_orders_granular_df.join(pvc_novl_contracts, pvc_orders_granular_df.accountId==pvc_novl_contracts.sfdcAccountID).count()

# COMMAND ----------

clean_pvc_usage = spark.sql("""
with ranked_orders(
select *,
       row_number() over(partition by accountID, accountName, usage_date, revShareDollars, InteractiveDBUs, AutomatedDBUs, scope order by startDate) rno
from pvc_orders_combined
)
select *
from ranked_orders
where rno = 1
""")
clean_pvc_usage = clean_pvc_usage.drop(clean_pvc_usage.rno)

# COMMAND ----------

orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

# apmoller = prod_daily.filter( (prod_daily.platform=='azure') & (prod_daily.accountID=='0016100001G26HxAAJ')).orderBy(*orderByColumns) 
# apmoller = prod_daily.filter( (prod_daily.platform=='aws') & (prod_daily.accountID=='0016100001IuqSSAAZ')).orderBy(*orderByColumns)

clean_pvc_usage = clean_pvc_usage.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                 .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                 .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                 .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                 .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2)) 

burstColumns = ["cumListDollars", "listCommit", "endDate", "usage_date", "cumDBDollars", "RevShareCommit", "platform"]
clean_pvc_usage = clean_pvc_usage.withColumn("IsBurst", isBurst(*burstColumns))

# COMMAND ----------

clean_pvc_usage.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGE_PROD_DAILY_INTERMEDIATE)

# COMMAND ----------

dropColumns = ['cumListDollars', 'cumCustDollars', 'cumDBDollars', 'cumInteractiveDBUs', 'cumAutomatedDBUs', 'IsBurst']
clean_pvc_usage_updated = spark.sql(f"select * from {USAGE_PROD_DAILY_INTERMEDIATE}")\
                        .drop(*dropColumns)

clean_pvc_usage_updated = clean_pvc_usage_updated.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                 .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                 .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                 .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                 .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))

# COMMAND ----------

groupbyColumnsWithoutSKU = ["accountId", "accountName", "platform", "aggOrder", "usage_date", "ListCommit","DiscountedCommit", "RevShareCommit"]

clean_pvc_updated_withoutSKU = clean_pvc_usage_updated.groupBy(*groupbyColumnsWithoutSKU)\
                                              .agg(\
                                                    round(sum("listDollars"),4).alias("listDollars"),\
                                                    round(sum("custDollars"),4).alias("custDollars"),\
                                                    round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                    round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                    round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                    round(sum("DBUs"),4).alias("DBUs")                                                   
                                               )

orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)

clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                           .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                           .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                           .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                           .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2)) 

clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumnRenamed("cumDBDollars", "cumRevShareDollars")
clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumn("consumptionType", consumptionType("aggOrder"))

# COMMAND ----------

# change: added _intermediate to the location
clean_pvc_updated_withoutSKU.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(USAGEC_AGG_ORDER_DAILY_ADHOC_PVC_INTERMEDIATE_LOCATION)

# COMMAND ----------

# DBTITLE 1,Adhoc Delta Add
clean_pvc_usage_updated = spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_PVC_INTERMEDIATE_LOCATION)
clean_pvc_usage_updated = clean_pvc_usage_updated.drop("cumListDollars", "cumCustDollars", "cumRevShareDollars", "cumInteractiveDBUs", "cumAutomatedDBUs", 
                                                       "cumDeltaRevShareDollars", "cumDeltaInteractiveDBUs", "cumDeltaAutomatedDBUs","consumptionType")

# COMMAND ----------

clean_pvc_updated_withoutSKU = clean_pvc_usage_updated.withColumn("DeltaRevShareDollars", lit(0.0))\
                                                      .withColumn("DeltaInteractiveDBUs", lit(0.0))\
                                                      .withColumn("DeltaAutomatedDBUs", lit(0.0))\
                                                      .withColumn("DeltaDBUs", lit(0.0))\
                                                      .withColumn("DeltaSQLDBUs", lit(0.0))\
                                                      .withColumn("SQLAnalyticsDBUs", lit(0.0))\
                                                      .withColumn("SQLRevShareDollars", lit(0.0))\
                                                      .withColumn("StandardDBUs", lit(0.0))\
                                                      .withColumn("PremiumDBUs", lit(0.0))\
                                                      .withColumn("StandardDBUs", lit(0.0))\
                                                      .withColumn("EnterpriseDBUs", lit(0.0))\
                                                      .withColumn("StandardRevShareDollars", lit(0.0))\
                                                      .withColumn("PremiumRevShareDollars", lit(0.0))\
                                                      .withColumn("EnterpriseRevShareDollars", lit(0.0))\
                                                      .withColumn("MoonCakeDBUs", lit(0.0))\
                                                      .withColumn("MoonCakeDeltaDBUs", lit(0.0))\
                                                      .withColumn("MoonCakeDBUDollars", lit(0.0))\
                                                      .withColumn("MoonCakeDeltaDBUDollars", lit(0.0))\
                                                      .withColumn("ISVDBUs", lit(0.0))\
                                                      .withColumn("ISVRevShareDollars", lit(0.0))\
                                                      .withColumn("DBTDBUs", lit(0.0))\
                                                      .withColumn("DBTRevShareDollars", lit(0.0))\
                                                      .withColumn("FivetranDBUs", lit(0.0))\
                                                      .withColumn("FivetranRevShareDollars", lit(0.0))\
                                                      .withColumn("ServerlessDBUs", lit(0.0))\
                                                      .withColumn("ServerlessRevShareDollars", lit(0.0))\
                                                      .withColumn("PhotonDBUs", lit(0.0))\
                                                      .withColumn("PhotonRevShareDollars", lit(0.0))\
                                                      .withColumn("DLTDBUs", lit(0.0))\
                                                      .withColumn("DLTRevShareDollars", lit(0.0))\
                                                      .withColumn("MoonCakeSQLDBUs", lit(0.0))\
                                                      .withColumn("MoonCakeSQLDollars", lit(0.0))\
                                                      .withColumn("StreamingDLTDBUs", lit(0.0))\
                                                      .withColumn("StreamingDLTRevShareDollars", lit(0.0))\
                                                      .withColumn("UCDBUs", lit(0.0))\
                                                      .withColumn("UCRevShareDollars", lit(0.0))\
                                                      .withColumn("MLDBUs", lit(0.0))\
                                                      .withColumn("MLRevShareDollars", lit(0.0))\
                                                      .withColumn("GenAIDBUs", lit(0.0))\
                                                      .withColumn("GenAIRevShareDollars", lit(0.0))\
                                                      .withColumn("GPUModelServingDBUs", lit(0.0))\
                                                      .withColumn("GPUModelServingRevShareDollars", lit(0.0))\
                                                      .withColumn("ThroughputModelServingDBUs", lit(0.0))\
                                                      .withColumn("ThroughputModelServingRevShareDollars", lit(0.0))\
                                                      .withColumn("FoundationModelAPIDBUs", lit(0.0))\
                                                      .withColumn("FoundationModelAPIRevShareDollars", lit(0.0))\
                                                      .withColumn("VectorSearchDBUs", lit(0.0))\
                                                      .withColumn("VectorSearchRevShareDollars", lit(0.0))\
                                                      .withColumn("LakeflowConnectDBUs", lit(0.0))\
                                                      .withColumn("LakeflowPipelinesDBUs", lit(0.0))\
                                                      .withColumn("LakeflowDBUs", lit(0.0))\
                                                      .withColumn("LakeflowConnectRevShareDollars", lit(0.0))\
                                                      .withColumn("LakeflowPipelinesRevShareDollars", lit(0.0))\
                                                      .withColumn("LakeflowRevShareDollars", lit(0.0))\
                                                      .withColumn("BatchInferenceModelServingDBUs", lit(0.0))\
                                                      .withColumn("BatchInferenceModelServingRevShareDollars", lit(0.0))\
                                                      .withColumn("AgentFrameworkDBUs", lit(0.0))\
                                                      .withColumn("AgentFrameworkRevShareDollars", lit(0.0))\
                                                      .withColumn("VectorSearchStorageDBUs", lit(0.0))\
                                                      .withColumn("VectorSearchStorageRevShareDollars", lit(0.0))\
                                                      .withColumn("FY26AIDBUs", lit(0.0))\
                                                      .withColumn("FY26AIDollars", lit(0.0))\
                                                      .withColumn("MCTDBUs", lit(0.0))\
                                                      .withColumn("MCTRevShareDollars", lit(0.0))\
                                                      .withColumn("MCTModelHeroRunTrainingRevShareDollars", lit(0.0))\
                                                      .withColumn("MCTModelReservedTrainingRevShareDollars", lit(0.0))\
                                                      .withColumn("MCTModelOnDemandTrainingRevShareDollars", lit(0.0))\
                                                      .withColumn("StreamingDLTRevShareDollars_calculated", lit(0.0))\
                                                      .withColumn("UCRevShareDollars_calculated", lit(0.0))\
                                                      .withColumn("CPUModelServingRevShareDollars", lit(0.0))\
                                                      .withColumn("FoundationModelTrainingRevShareDollars", lit(0.0))\
                                                      .withColumn("VectorSearchIngestionRevShareDollars", lit(0.0))\
                                                      .withColumn("VectorSearchServingRevShareDollars", lit(0.0))\
                                                      .withColumn("FinetuningDBUs", lit(0.0))\
                                                      .withColumn("FinetuningRevShareDollars", lit(0.0))\
                                                      .withColumn("AgentEvalsDBUs", lit(0.0))\
                                                      .withColumn("AgentEvalsRevShareDollars", lit(0.0))\
                                                      .withColumn("AgentEvalsSyntheticDataDBUs", lit(0.0))\
                                                      .withColumn("AgentEvalsSyntheticDataRevShareDollars", lit(0.0))\
                                                      .withColumn("AIRuntimeDBUs", lit(0.0))\
                                                      .withColumn("AIRuntimeRevShareDollars", lit(0.0))\
                                                      .withColumn("AnthropicThroughputModelServingDBUs", lit(0.0))\
                                                      .withColumn("AnthropicThroughputModelServingRevShareDollars", lit(0.0))\
                                                      .withColumn("AnthropicFoundationModelAPIDBUs", lit(0.0))\
                                                      .withColumn("AnthropicFoundationModelAPIRevShareDollars", lit(0.0))\
                                                      .withColumn("ModelServingFMAPIDBUs", lit(0.0))\
                                                      .withColumn("ModelServingFMAPIRevShareDollars", lit(0.0))\
                                                      .withColumn("LakehouseMonitoringDBUs", lit(0.0))\
                                                      .withColumn("LakehouseMonitoringRevShareDollars", lit(0.0))\
                                                      .withColumn("FmMixtral87bInstructDBUs", lit(0.0))\
                                                      .withColumn("FmLlama270bChatDBUs", lit(0.0))\
                                                      .withColumn("FmBgeLargeENDBUs", lit(0.0))\
                                                      .withColumn("FmMpt30bInstructDBUs", lit(0.0))\
                                                      .withColumn("FmMpt7bInstructDBUs", lit(0.0))\
                                                      .withColumn("FmDatabricksDbrxChatDBUs", lit(0.0))\
                                                      .withColumn("FmMixtral87bInstructRevShareDollars", lit(0.0))\
                                                      .withColumn("FmLlama270bChatRevShareDollars", lit(0.0))\
                                                      .withColumn("FmBgeLargeENRevShareDollars", lit(0.0))\
                                                      .withColumn("FmMpt30bInstructRevShareDollars", lit(0.0))\
                                                      .withColumn("FmMpt7bInstructRevShareDollars", lit(0.0))\
                                                      .withColumn("FmDatabricksDbrxChatRevShareDollars", lit(0.0))

                                                      
orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)


clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                           .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                           .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                           .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                           .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                           .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                           .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                           .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                           .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                           .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumnRenamed("cumDBDollars", "cumRevShareDollars")
clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumn("consumptionType", consumptionType("aggOrder"))

# COMMAND ----------

print(clean_pvc_updated_withoutSKU.count()) 
clean_pvc_updated_withoutSKU.createOrReplaceTempView("pvc_daily")

# COMMAND ----------

clean_pvc_updated_withoutSKU.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(USAGE_AGG_ORDER_DAILY_ADHOC_PVC_LOCATION)

# COMMAND ----------

display(spark.sql(f"""
select fiscalYear, fiscalQuarter,
       sum(revShareDollars)
from pvc_daily pvc
join {BI_DATES} dt on pvc.usage_date = dt.date 
where dt.fiscalYear >= 2021
group by 1,2
order by 1 desc, 2
"""))

# COMMAND ----------

pvc_orders = spark.sql("""
with orders (
select distinct aggOrder, startDate, endDate
from pvc_orders_combined
),

orders_seq (
select aggOrder, startDate, endDate, row_number() over(partition by aggOrder order by startDate) rno
from orders
)
select *
from orders_seq
where rno = 1
""")
pvc_orders = pvc_orders.drop('rno')

# COMMAND ----------

clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.join(pvc_orders, clean_pvc_updated_withoutSKU.aggOrder == pvc_orders.aggOrder, 'left')\
                                                           .drop(pvc_orders.aggOrder)

# COMMAND ----------

clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.withColumn('EntitlementTier', lit('NA'))\
                                                           .withColumn('SubscriptionID', lit('NA'))\
                                                           .withColumn('cumDBDollars', lit(0.0))\
                                                           .withColumn('dbt_dbu_quantity', lit(0.0))\
                                                           .withColumn('dbuCustPrice', lit(0.0))\
                                                           .withColumn('dbuRevSharePrice', lit(0.0))\
                                                           .withColumn('listPrice', lit(0.0))\
                                                           .withColumn('deployedRegion', lit('NA'))\
                                                           .withColumn('fivetran_dbu_quantity', lit(0.0))\
                                                           .withColumn('isPaying', lit(True))\
                                                           .withColumn('isv_dbu_quantity', lit(0.0))\
                                                           .withColumn('scope', lit('NA'))\
                                                           .withColumn('skuType', lit('NA'))\
                                                           .withColumn('usage_sku', lit('ENTERPRISE_JOBS_COMPUTE'))\
                                                           .withColumn('workspaceSFDCID', lit('NA'))\
                                                           .withColumn('businessSubscriptionID', lit('NA'))\
                                                           .withColumnRenamed('DBUs', 'dbu_quantity')\
                                                           .withColumnRenamed('DeltaDBUs', 'delta_dbu_quantity')\
                                                           .withColumnRenamed('UCDBUs', 'uc_dbu_quantity')\
                                                           .withColumnRenamed('MLDBUs', 'ml_dbu_quantity')\
                                                           .withColumnRenamed('GenAIDBUs', 'gen_ai_dbu_quantity')\
                                                           .withColumnRenamed('GPUModelServingDBUs', 'gpu_model_serving_dbu_quantity')\
                                                           .withColumnRenamed('ThroughputModelServingDBUs', 'throughput_model_serving_dbu_quantity')\
                                                           .withColumnRenamed('FoundationModelAPIDBUs', 'foundation_model_api_dbu_quantity')\
                                                           .withColumnRenamed('VectorSearchDBUs', 'vector_search_dbu_quantity')\
                                                           .withColumnRenamed('MCTDBUs', 'mct_dbu_quantity')\
                                                           .withColumnRenamed('accountId', 'accountID')

# COMMAND ----------

clean_pvc_updated_withoutSKU = clean_pvc_updated_withoutSKU.drop('DBTDBUs', 'FivetranDBUs', 'ISVDBUs', 'consumptionType', 'cumRevShareDollars')

# COMMAND ----------

clean_pvc_updated_withoutSKU.createOrReplaceTempView('pvc_prod_daily')

# COMMAND ----------

clean_pvc_updated_with_sku = spark.sql(f"""

select concat('pvc', accountId) workspaceId,
       p.*,
       dt.month_end_date
from pvc_prod_daily p
join {BI_DATES} dt on p.usage_date = dt.date
""")

# COMMAND ----------

clean_pvc_updated_with_sku.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(USAGEC_PROD_DAILY_PVC_LOCATION)

# COMMAND ----------

pvc_df.createOrReplaceTempView('finance_pvc_usage')

# COMMAND ----------

# MAGIC %sql
# MAGIC with base (
# MAGIC select year, month, case when month in (2,3,4) then 'Q1'
# MAGIC                          when month in (5,6,7) then 'Q2'
# MAGIC                          when month in (8,9,10) then 'Q3'
# MAGIC                          else 'Q4' end fiscal_quarter,
# MAGIC        sum(revShareDollars) revShareDollars
# MAGIC from finance_pvc_usage pvc 
# MAGIC where year >= 2021 --and month > 1
# MAGIC group by 1,2,3
# MAGIC order by 1 desc, 3
# MAGIC )
# MAGIC
# MAGIC select sum(revShareDollars) over(partition by year, fiscal_quarter order by year, month) fiscal_quarter_sum,
# MAGIC        *
# MAGIC from base   
# MAGIC order by year, fiscal_quarter, month

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))
