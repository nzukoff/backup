# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

# if environment == 'production':
#   USAGE_PROD_DAILY_GRANULAR_LOCATION   = "/mnt/bse-dev/usagec_prod_daily_granular"
#   usagec_prod_daily_modified_adhoc_location = "/mnt/bse-dev/usagec_prod_daily_modified_adhoc"
#   usagec_agg_order_daily_adhoc_location = "/mnt/bse-dev/usagec_agg_order_daily_adhoc"
#   DB_NAME = 'bdw'
#   usagec_prod_daily_intermediate_location = "/mnt/bse-dev/usagec_prod_daily_intermediate"
# else:
#   USAGE_PROD_DAILY_GRANULAR_LOCATION   = "/mnt/bse-dev/usagec_prod_daily_granular_dev"
#   usagec_prod_daily_modified_adhoc_location = "/mnt/bse-dev/staging/usagec_prod_daily_modified_adhoc"
#   usagec_agg_order_daily_adhoc_location = "/mnt/bse-dev/staging/usagec_agg_order_daily_adhoc"
#   DB_NAME = 'bdw_dev'
#   usagec_prod_daily_intermediate_location = "/mnt/bse-dev/staging/usagec_prod_daily_intermediate"

# COMMAND ----------

#todo : update burst
@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def sql_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType in ('sql', 'virtual') else 0

@udf("double")
def sql_dollars(dbu_quantity, skuType, dbuRevSharePrice):
  if dbuRevSharePrice is None:
    return 0.0
  return (dbu_quantity * dbuRevSharePrice) if skuType in ('sql', 'virtual') else 0.0

# @udf("boolean")
# def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  

#   if platform == "azure":
#       return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
#   isBurst = False  
#   if platform == 'aws':
#     if (cumDBDollars > RevShareCommit + 0.999):
#       if (usage_date > endDate):
#         isBurst = True
#     else:
#       if (usage_date > endDate):
#         isBurst = True
#   return isBurst

@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform, aggOrder, cumCustDollars, DiscountedCommit):
  if platform == "azure" and 'COMMIT' not in aggOrder:
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  if platform == "azure" and 'COMMIT' in aggOrder:
      return (cumCustDollars > DiscountedCommit + 0.999) or (usage_date > endDate)
  
  return (usage_date > endDate)

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"

@udf("string")
def forecastType(subscriptionId, contract_type):
  forecastType = 'MTM'
  if subscriptionId == 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = "SharedCommit"
  if subscriptionId != 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = 'SingleCommit'
  
  return forecastType

@udf("string")
def entitlementTier(usage_sku):
  
  entitlementTier = "Unknown"
  if "enterprise" in usage_sku:
    entitlementTier = "Enterprise"
  elif "premium" in usage_sku:
    entitlementTier = "Premium"
  else:
    entitlementTier = "Standard"
  
  return entitlementTier

@udf("double")
def standardDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Standard" else 0.0

@udf("double")
def premiumDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Premium" else 0.0  

@udf("double")
def enterpriseDBUs(entitlementTier, dbu_quantity):
  return dbu_quantity if entitlementTier == "Enterprise" else 0.0  

@udf("double")
def moonCakeDBUs(deployedRegion, dbu_quantity):
  if deployedRegion is None:
    return 0.0
  return dbu_quantity if 'china' in deployedRegion else 0.0

@udf("double")
def moonCakeDeltaDBUs(deployedRegion, delta_dbu_quantity):
  if deployedRegion is None:
    return 0.0
  return delta_dbu_quantity if 'china' in deployedRegion else 0.0

@udf("double")
def moonCakeSQLDBUs(deployedRegion, dbu_quantity, skuType):
  if deployedRegion is None:
    return 0.0
  return dbu_quantity if ('china' in deployedRegion and skuType == 'sql') else 0.0

@udf("double")
def serverlessDBUs(usage_sku, dbu_quantity):
  return dbu_quantity if 'serverless' in usage_sku.lower() else 0.0

@udf("double")
def photonDBUs(usage_sku, dbu_quantity):
  return dbu_quantity if 'photon' in usage_sku.lower() else 0.0

@udf("double")
def dltDBUs(usage_sku, dbu_quantity):
  return dbu_quantity if 'dlt' in usage_sku.lower() else 0.0

# COMMAND ----------

#todo: mapping columns names to the original RI report/ AWS commits (Sandeep suggestion)
#issue-tracker: for unit testing
#announce tables on slack
#pvc usage into granular-data

# COMMAND ----------

# note: /mnt/bse-dev/usagec_prod_daily_granular_adhoc --> unprocessed aws usage
prod_daily = spark.read.format("delta").load(USAGE_PROD_DAILY_GRANULAR_LOCATION)
# prod_daily = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_granular_adhoc")
dates_df = spark.sql(f"select * from {BI_DATES}")
product_df = spark.sql(f"""
select distinct meterSubCategory skuType, 
                meterName 
from {PRODUCT_DIM}
where meterCategory = 'workloads'
and coalesce(meterSubCategory,'') <> 'virtual' --in ('automated', 'interactive', 'sql', null)
""")


prod_daily = prod_daily.withColumn("dbuRevSharePrice", col("dbuRevSharePrice").cast("double"))

# COMMAND ----------

#prod_daily.cache()
# product_df.cache()
# dates_df.cache()
prod_daily.count()

# COMMAND ----------

# add month, dollars
prod_daily = prod_daily.withColumn("month", date_format(prod_daily.usage_date, 'yyyy-MM'))\
                       .withColumn("listDollars", round(col("listPrice")*col("dbu_quantity"), 6))\
                       .withColumn("custDollars", round(col("dbu_quantity")*col("dbuCustPrice") + when(col("platform") == "azure", col("shield_dollars")/0.85).otherwise(col("shield_dollars")), 6))\
                       .withColumn("revShareDollars", round(col("dbu_dollars"), 6))\
                       .withColumn("DeltaRevShareDollars", round(col("dbuRevSharePrice")*col("delta_dbu_quantity"), 6))\
                       .withColumn("ISVRevShareDollars", round(col("dbuRevSharePrice")*col("isv_dbu_quantity"), 6))\
                       .withColumn("DBTRevShareDollars", round(col("dbuRevSharePrice")*col("dbt_dbu_quantity"), 6))\
                       .withColumn("FivetranRevShareDollars", round(col("dbuRevSharePrice")*col("fivetran_dbu_quantity"), 6))\
                       .withColumn("GenAIRevShareDollars", round(col("gen_ai_dbu_dollars"), 6))\
                       .withColumn("MCTRevShareDollars", round(col("mct_dbu_dollars"), 6))\
                       .withColumn("StreamingDLTRevShareDollars", round(col("streaming_dlt_dbu_dollars"), 6))\
                       .withColumn("StreamingDLTRevShareDollars_calculated", round(col("dbuRevSharePrice")*col("streaming_dlt_dbu_quantity"), 6))
                       

prod_daily = prod_daily.withColumnRenamed("cloudPartnerPurchase", "ListCommit")\
                       .withColumnRenamed("ActualPartnerCommit", "DiscountedCommit")\
                       .withColumnRenamed("DBShareCommit", "RevShareCommit")\
                       .withColumnRenamed("uc_dbu_quatity", "uc_dbu_quantity")

# COMMAND ----------

# add sku-type
prod_daily = prod_daily.join(product_df, prod_daily.usage_sku == product_df.meterName)\
                       .drop(product_df.meterName)

# add interactive/automated dbus
prod_daily = prod_daily.withColumn("InteractiveDBUs", coalesce(interactive_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("AutomatedDBUs", coalesce(automated_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaInteractiveDBUs", coalesce(interactive_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaAutomatedDBUs", coalesce(automated_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("DeltaSQLDBUs", coalesce(sql_dbus("delta_dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLAnalyticsDBUs", coalesce(sql_dbus("dbu_quantity", "skuType"), lit(0)))\
                       .withColumn("SQLRevShareDollars", round(sql_dollars("dbu_quantity", "skuType", "dbuRevSharePrice"), 6))\
                       .withColumn("EntitlementTier", entitlementTier("usage_sku"))\
                       .withColumn("StandardDBUs", standardDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("PremiumDBUs", premiumDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("EnterpriseDBUs", enterpriseDBUs("EntitlementTier", "dbu_quantity"))\
                       .withColumn("StandardRevShareDollars", round(col("dbuRevSharePrice")*col("StandardDBUs"), 6))\
                       .withColumn("PremiumRevShareDollars", round(col("dbuRevSharePrice")*col("PremiumDBUs"), 6))\
                       .withColumn("EnterpriseRevShareDollars", round(col("dbuRevSharePrice")*col("EnterpriseDBUs"), 6))\
                       .withColumn("ServerlessDBUs", serverlessDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("ServerlessRevShareDollars", round(col("dbuRevSharePrice")*col("ServerlessDBUs"), 6))\
                       .withColumn("PhotonDBUs", photonDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("PhotonRevShareDollars", round(col("dbuRevSharePrice")*col("PhotonDBUs"), 6))\
                       .withColumn("DLTDBUs", dltDBUs("usage_sku", "dbu_quantity"))\
                       .withColumn("DLTRevShareDollars", round(col("dbuRevSharePrice")*col("DLTDBUs"), 6))\
                       .withColumn("UCRevShareDollars", round(col("uc_dbu_dollars"), 6))\
                       .withColumn("MLRevShareDollars", round(col("dbuRevSharePrice")*col("ml_dbu_quantity"), 6))\
                       .withColumn("GPUModelServingRevShareDollars", round(col("gpu_model_serving_dollars"), 6))\
                       .withColumn("ThroughputModelServingRevShareDollars", round(col("throughput_model_serving_dollars"), 6))\
                       .withColumn("FoundationModelAPIRevShareDollars", round(col("foundation_model_api_dollars"), 6))\
                       .withColumn("VectorSearchRevShareDollars", round(col("vector_search_dollars"), 6))\
                       .withColumn("UCRevShareDollars_calculated", round(col("dbuRevSharePrice")*col("uc_dbu_quantity"), 6))\
                       .withColumn("CPUModelServingRevShareDollars", round(col("cpu_model_serving_dollars"), 6))\
                       .withColumn("FoundationModelTrainingRevShareDollars", round(col("foundation_model_training_dollars"), 6))\
                       .withColumn("VectorSearchIngestionRevShareDollars", round(col("vector_search_ingestion_dollars"), 6))\
                       .withColumn("VectorSearchServingRevShareDollars", round(col("vector_search_serving_dollars"), 6))\
                       .withColumn("MCTModelHeroRunTrainingRevShareDollars", round(col("mct_model_hero_run_training_dollars"), 6))\
                       .withColumn("MCTModelReservedTrainingRevShareDollars", round(col("mct_model_reserved_training_dollars"), 6))\
                       .withColumn("MCTModelOnDemandTrainingRevShareDollars", round(col("mct_model_on_demand_training_dollars"), 6))\
                       .withColumn("LakeflowConnectDBUs", round(col("lakeflow_connect_dbu_quantity"), 6))\
                       .withColumn("LakeflowPipelinesDBUs", round(col("lakeflow_pipelines_dbu_quantity"), 6))\
                       .withColumn("LakeflowDBUs", round(col("lakeflow_dbu_quantity"), 6))\
                       .withColumn("LakeflowConnectRevShareDollars", round(col("lakeflow_connect_dollars"), 6))\
                       .withColumn("LakeflowPipelinesRevShareDollars", round(col("lakeflow_pipelines_dollars"), 6))\
                       .withColumn("LakeflowRevShareDollars", round(col("lakeflow_dollars"), 6))\
                       .withColumn("BatchInferenceModelServingDBUs", round(col("batch_inference_model_serving_dbu_quantity"), 6))\
                       .withColumn("BatchInferenceModelServingRevShareDollars", round(col("batch_inference_model_serving_dollars"), 6))\
                       .withColumn("AgentFrameworkDBUs", round(col("agent_framework_dbu_quantity"), 6))\
                       .withColumn("AgentFrameworkRevShareDollars", round(col("agent_framework_dollars"), 6))\
                       .withColumn("VectorSearchStorageDBUs", round(col("vector_search_storage_dbu_quantity"), 6))\
                       .withColumn("VectorSearchStorageRevShareDollars", round(col("vector_search_storage_dollars"), 6))\
                       .withColumn("FY26AIDBUs", round(col("fy26_ai_dbu_quantity"), 6))\
                       .withColumn("FY26AIDollars", round(col("fy26_ai_dollars"), 6))\
                       .withColumn("FinetuningDBUs", round(col("finetuning_dbu_quantity"), 6))\
                       .withColumn("FinetuningRevShareDollars", round(col("finetuning_dollars"), 6))\
                       .withColumn("AgentEvalsDBUs", round(col("agent_evals_dbu_quantity"), 6))\
                       .withColumn("AgentEvalsRevShareDollars", round(col("agent_evals_dollars"), 6))\
                       .withColumn("AgentEvalsSyntheticDataDBUs", round(col("agent_evals_synthetic_data_dbu_quantity"), 6))\
                       .withColumn("AgentEvalsSyntheticDataRevShareDollars", round(col("agent_evals_synthetic_data_dollars"), 6))\
                       .withColumn("AIRuntimeDBUs", round(col("ai_runtime_dbu_quantity"), 6))\
                       .withColumn("AIRuntimeRevShareDollars", round(col("ai_runtime_dollars"), 6))\
                       .withColumn("AnthropicThroughputModelServingDBUs", round(col("anthropic_throughput_model_serving_dbu_quantity"), 6))\
                       .withColumn("AnthropicThroughputModelServingRevShareDollars", round(col("anthropic_throughput_model_serving_dollars"), 6))\
                       .withColumn("AnthropicFoundationModelAPIDBUs", round(col("anthropic_foundation_model_api_dbu_quantity"), 6))\
                       .withColumn("AnthropicFoundationModelAPIRevShareDollars", round(col("anthropic_foundation_model_api_dollars"), 6))\
                       .withColumn("ModelServingFMAPIDBUs", round(col("model_serving_fmapi_dbu_quantity"), 6))\
                       .withColumn("ModelServingFMAPIRevShareDollars", round(col("model_serving_fmapi_dollars"), 6))\
                       .withColumn("LakehouseMonitoringDBUs", round(col("lakehouse_monitoring_dbu"), 6))\
                       .withColumn("LakehouseMonitoringRevShareDollars", round(col("lakehouse_monitoring_dollars"), 6))\
                       .withColumn("FmMixtral87bInstructDBUs", round(col("fm_mixtral_8_7b_instruct_dbu"), 6))\
                       .withColumn("FmLlama270bChatDBUs", round(col("fm_llama2_70b_chat_dbu"), 6))\
                       .withColumn("FmBgeLargeENDBUs", round(col("fm_bge_large_en_dbu"), 6))\
                       .withColumn("FmMpt30bInstructDBUs", round(col("fm_mpt_30b_instruct_dbu"), 6))\
                       .withColumn("FmMpt7bInstructDBUs", round(col("fm_mpt_7b_instruct_dbu"), 6))\
                       .withColumn("FmDatabricksDbrxChatDBUs", round(col("fm_databricks_dbrx_chat_dbu"), 6))\
                       .withColumn("FmMixtral87bInstructRevShareDollars", round(col("fm_mixtral_8_7b_instruct_dollars"), 6))\
                       .withColumn("FmLlama270bChatRevShareDollars", round(col("fm_llama2_70b_chat_dollars"), 6))\
                       .withColumn("FmBgeLargeENRevShareDollars", round(col("fm_bge_large_en_dollars"), 6))\
                       .withColumn("FmMpt30bInstructRevShareDollars", round(col("fm_mpt_30b_instruct_dollars"), 6))\
                       .withColumn("FmMpt7bInstructRevShareDollars", round(col("fm_mpt_7b_instruct_dollars"), 6))\
                       .withColumn("FmDatabricksDbrxChatRevShareDollars", round(col("fm_databricks_dbrx_chat_dollars"), 6))
                               
prod_daily = prod_daily.withColumn("MoonCakeDBUs", moonCakeDBUs("deployedRegion", "dbu_quantity"))\
                       .withColumn("MoonCakeDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDBUs"), 6))\
                       .withColumn("MoonCakeDeltaDBUs", moonCakeDeltaDBUs("deployedRegion", "delta_dbu_quantity"))\
                       .withColumn("MoonCakeDeltaDBUDollars", round(col("dbuRevSharePrice")*col("MoonCakeDeltaDBUs"), 6))\
                       .withColumn("MoonCakeSQLDBUs", moonCakeSQLDBUs("deployedRegion", "delta_dbu_quantity", "skuType"))\
                       .withColumn("MoonCakeSQLDollars", round(col("dbuRevSharePrice")*col("MoonCakeSQLDBUs"), 6))     

# Drop upstream dollar columns w/ original name
columns_to_drop = ['gen_ai_dbu_dollars','streaming_dlt_dbu_dollars','uc_dbu_dollars','gpu_model_serving_dollars'
                   ,'throughput_model_serving_dollars','foundation_model_api_dollars','vector_search_dollars'
                   ,'mct_dbu_dollars','cpu_model_serving_dollars','foundation_model_training_dollars','vector_search_ingestion_dollars','vector_search_serving_dollars','mct_model_hero_run_training_dollars','mct_model_reserved_training_dollars','mct_model_on_demand_training_dollars', 
                   'lakeflow_connect_dbu_quantity', 'lakeflow_pipelines_dbu_quantity', 'lakeflow_dbu_quantity', 'lakeflow_connect_dollars', 'lakeflow_pipelines_dollars', 'lakeflow_dollars',
                   'batch_inference_model_serving_dbu_quantity', 'batch_inference_model_serving_dollars', 'agent_framework_dbu_quantity', 'agent_framework_dollars', 'vector_search_storage_dbu_quantity', 'vector_search_storage_dollars', 'fy26_ai_dbu_quantity', 'fy26_ai_dollars', 'finetuning_dbu_quantity', 'finetuning_dollars', 'agent_evals_dbu_quantity', 'agent_evals_dollars', 'agent_evals_synthetic_data_dbu_quantity', 'agent_evals_synthetic_data_dollars', 'ai_runtime_dbu_quantity', 'ai_runtime_dollars', 'anthropic_throughput_model_serving_dbu_quantity', 'anthropic_throughput_model_serving_dollars', 'anthropic_foundation_model_api_dbu_quantity', 'anthropic_foundation_model_api_dollars', 'model_serving_fmapi_dbu_quantity', 'model_serving_fmapi_dollars', 'lakehouse_monitoring_dbu', 'lakehouse_monitoring_dollars', 'fm_mixtral_8_7b_instruct_dbu', 'fm_llama2_70b_chat_dbu', 'fm_bge_large_en_dbu', 'fm_mpt_30b_instruct_dbu', 'fm_mpt_7b_instruct_dbu', 'fm_databricks_dbrx_chat_dbu', 'fm_mixtral_8_7b_instruct_dollars', 'fm_llama2_70b_chat_dollars', 'fm_bge_large_en_dollars', 'fm_mpt_30b_instruct_dollars', 'fm_mpt_7b_instruct_dollars', 'fm_databricks_dbrx_chat_dollars']

prod_daily = prod_daily.drop(*columns_to_drop)

# COMMAND ----------

prod_daily.count()

# COMMAND ----------

dateSelectColumns = ["date", "isMonthEnd", "year_month"]
datesFiltered = dates_df.select(*dateSelectColumns)\
                        .filter(dates_df.isMonthEnd==1)\
                        .drop(dates_df.isMonthEnd)\
                        .withColumnRenamed("date", "month_end_date")


prod_daily = prod_daily.join(datesFiltered, prod_daily.month==datesFiltered.year_month)\
                                      .drop(datesFiltered.year_month)

prod_daily = prod_daily.drop(prod_daily.month)

# COMMAND ----------

orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Azure processing
# MAGIC 1. Get all the scopes of each accounts from bi aggorders

# COMMAND ----------

rowAzureAccounts = spark.sql(f"select sfdcAccountId, collect_set(scope) scope from {BI_AGGORDERS} where platform = 'azure' and scope!= 'shared' group by 1").collect()

from collections import defaultdict
account_map = {}
account_list = defaultdict(list)
for row in rowAzureAccounts:
  if row.sfdcAccountId not in account_map and row.sfdcAccountId is not None:
    account_map[row.sfdcAccountId] = row.scope
    scope = ''.join(row.scope)
    account_list[scope].append(row.sfdcAccountId)
  else:
    print("duplicate", row.sfdcAccountId)

# COMMAND ----------

def run_notebook(notebook_name, timeout, arguments):
  try:
    return dbutils.notebook.run(notebook_name, timeout, arguments)
  except Exception as e:
    raise e

# COMMAND ----------

def getAzureUpdateQuery(accountId, aggOrder):
    return f"""
    update {USAGE_PROD_DAILY_INTERMEDIATE}
    set aggOrder = 'MTMAzure{accountId}',
        ListCommit = 0,
        DiscountedCommit = 0,
        RevShareCommit = 0,
        Scope = 'shared'
    where isBurst = 1
    and aggOrder = "{aggOrder}"
    """
  
def getSharedAWSUpdateQuery(accountId, aggOrder):
    return f"""
    update {USAGE_PROD_DAILY_INTERMEDIATE}
    set aggOrder = 'MTMAWS{accountId}',
        ListCommit = 0,
        DiscountedCommit = 0,
        RevShareCommit = 0,
        Scope = 'shared'
    where isBurst = 1
    and aggOrder = "{aggOrder}"
    """


def write_to_daily_intermediate(apmoller):
  
    # optimize dynamically
    # todo: change cumDBDollars to cumRevShareDollars
    orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
    partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]
    usage_window = Window.partitionBy(*partitionByColumns)\
                         .orderBy("usage_date")\
                         .rowsBetween(Window.unboundedPreceding, Window.currentRow)

    apmoller = apmoller.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                       .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                       .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                       .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                       .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                       .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                       .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                       .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                       .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                       .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

    burstColumns = ["cumListDollars", "listCommit", "endDate", "usage_date", "cumDBDollars", "RevShareCommit", "platform", "aggOrder", "cumCustDollars", "DiscountedCommit"]
    apmoller = apmoller.withColumn("IsBurst", isBurst(*burstColumns))
    
    write_mode = "overwrite"
    apmoller.write.option("overwriteSchema", "true").format("delta").mode(write_mode).saveAsTable(USAGE_PROD_DAILY_INTERMEDIATE)
    
    
def write_to_adhoc_daily(write_mode):
  
  dropColumns = ['cumListDollars', 'cumCustDollars', 'cumDBDollars', 'cumInteractiveDBUs', 'cumAutomatedDBUs', 'IsBurst']
  apmoller_updated = spark.sql(f"select * from {USAGE_PROD_DAILY_INTERMEDIATE}")\
                          .drop(*dropColumns)

  orderByColumns = ["accountID", "accountName", "platform", "aggOrder", "usage_date"]
  partitionByColumns = ["accountID", "accountName", "platform", "aggOrder"]

  usage_window = Window.partitionBy(*partitionByColumns)\
                       .orderBy("usage_date")\
                       .rowsBetween(Window.unboundedPreceding, Window.currentRow)

  apmoller_updated = apmoller_updated.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                     .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                     .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                     .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                     .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                     .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                     .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                     .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                     .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                     .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))
  

  groupbyColumnsWithoutSKU = ["accountId", "accountName", "platform", "aggOrder", "usage_date", "ListCommit","DiscountedCommit", "RevShareCommit"]

  apmoller_updated_withoutSKU = apmoller_updated.groupBy(*groupbyColumnsWithoutSKU)\
                                                .agg(\
                                                      round(sum("listDollars"),4).alias("listDollars"),\
                                                      round(sum("custDollars"),4).alias("custDollars"),\
                                                      round(sum("revShareDollars"),4).alias("revShareDollars"),\
                                                      round(sum("InteractiveDBUs"),4).alias("InteractiveDBUs"),\
                                                      round(sum("AutomatedDBUs"),4).alias("AutomatedDBUs"),\
                                                      round(sum("DeltaRevShareDollars"),4).alias("DeltaRevShareDollars"),\
                                                      round(sum("DeltaInteractiveDBUs"),4).alias("DeltaInteractiveDBUs"),\
                                                      round(sum("DeltaAutomatedDBUs"),4).alias("DeltaAutomatedDBUs"),\
                                                      round(sum("DeltaSQLDBUs"),4).alias("DeltaSQLDBUs"),\
                                                      round(sum("SQLAnalyticsDBUs"),4).alias("SQLAnalyticsDBUs"),\
                                                      round(sum("SQLRevShareDollars"),4).alias("SQLRevShareDollars"),\
                                                      round(sum("StandardDBUs"),4).alias("StandardDBUs"),\
                                                      round(sum("PremiumDBUs"),4).alias("PremiumDBUs"),\
                                                      round(sum("EnterpriseDBUs"),4).alias("EnterpriseDBUs"),\
                                                      round(sum("StandardRevShareDollars"),4).alias("StandardRevShareDollars"),\
                                                      round(sum("PremiumRevShareDollars"),4).alias("PremiumRevShareDollars"),\
                                                      round(sum("EnterpriseRevShareDollars"),4).alias("EnterpriseRevShareDollars"),\
                                                      round(sum("MoonCakeDBUs"),4).alias("MoonCakeDBUs"),\
                                                      round(sum("MoonCakeDeltaDBUs"),4).alias("MoonCakeDeltaDBUs"),\
                                                      round(sum("MoonCakeDBUDollars"),4).alias("MoonCakeDBUDollars"),\
                                                      round(sum("MoonCakeDeltaDBUDollars"),4).alias("MoonCakeDeltaDBUDollars"),\
                                                      round(sum("isv_dbu_quantity"),4).alias("ISVDBUs"),\
                                                      round(sum("ISVRevShareDollars"),4).alias("ISVRevShareDollars"),\
                                                      round(sum("dbt_dbu_quantity"),4).alias("DBTDBUs"),\
                                                      round(sum("DBTRevShareDollars"),4).alias("DBTRevShareDollars"),\
                                                      round(sum("fivetran_dbu_quantity"),4).alias("FivetranDBUs"),\
                                                      round(sum("FivetranRevShareDollars"),4).alias("FivetranRevShareDollars"),\
                                                      round(sum("ServerlessDBUs"),4).alias("ServerlessDBUs"),\
                                                      round(sum("ServerlessRevShareDollars"),4).alias("ServerlessRevShareDollars"),\
                                                      round(sum("PhotonDBUs"),4).alias("PhotonDBUs"),\
                                                      round(sum("PhotonRevShareDollars"),4).alias("PhotonRevShareDollars"),\
                                                      round(sum("DLTDBUs"),4).alias("DLTDBUs"),\
                                                      round(sum("DLTRevShareDollars"),4).alias("DLTRevShareDollars"),\
                                                      round(sum("MoonCakeSQLDBUs"),4).alias("MoonCakeSQLDBUs"),\
                                                      round(sum("MoonCakeSQLDollars"),4).alias("MoonCakeSQLDollars"),\
                                                      round(sum("dbu_quantity"),6).alias("DBUs"),\
                                                      round(sum("delta_dbu_quantity"),6).alias("DeltaDBUs"),\
                                                      round(sum("streaming_dlt_dbu_quantity"),6).alias("StreamingDLTDBUs"),\
                                                      round(sum("StreamingDLTRevShareDollars"),4).alias("StreamingDLTRevShareDollars"),\
                                                      round(sum("uc_dbu_quantity"),6).alias("UCDBUs"),\
                                                      round(sum("UCRevShareDollars"),4).alias("UCRevShareDollars"),\
                                                      round(sum("gen_ai_dbu_quantity"),6).alias("GenAIDBUs"),\
                                                      round(sum("GenAIRevShareDollars"),4).alias("GenAIRevShareDollars"),\
                                                      round(sum("ml_dbu_quantity"),6).alias("MLDBUs"),\
                                                      round(sum("MLRevShareDollars"),4).alias("MLRevShareDollars"),\
                                                      round(sum("gpu_model_serving_dbu_quantity"),6).alias("GPUModelServingDBUs"),\
                                                      round(sum("GPUModelServingRevShareDollars"),4).alias("GPUModelServingRevShareDollars"),\
                                                      round(sum("CPUModelServingRevShareDollars"),4).alias("CPUModelServingRevShareDollars"),\
                                                      round(sum("throughput_model_serving_dbu_quantity"),6).alias("ThroughputModelServingDBUs"),\
                                                      round(sum("ThroughputModelServingRevShareDollars"),4).alias("ThroughputModelServingRevShareDollars"),\
                                                      round(sum("foundation_model_api_dbu_quantity"),6).alias("FoundationModelAPIDBUs"),\
                                                      round(sum("FoundationModelAPIRevShareDollars"),4).alias("FoundationModelAPIRevShareDollars"),\
                                                      round(sum("FoundationModelTrainingRevShareDollars"),4).alias("FoundationModelTrainingRevShareDollars"),\
                                                      round(sum("vector_search_dbu_quantity"),6).alias("VectorSearchDBUs"),\
                                                      round(sum("VectorSearchRevShareDollars"),4).alias("VectorSearchRevShareDollars"),\
                                                      round(sum("VectorSearchIngestionRevShareDollars"),4).alias("VectorSearchIngestionRevShareDollars"),\
                                                      round(sum("VectorSearchServingRevShareDollars"),4).alias("VectorSearchServingRevShareDollars"),\
                                                      round(sum("mct_dbu_quantity"),6).alias("MCTDBUs"),\
                                                      round(sum("MCTRevShareDollars"),4).alias("MCTRevShareDollars"),\
                                                      round(sum("MCTModelHeroRunTrainingRevShareDollars"),4).alias("MCTModelHeroRunTrainingRevShareDollars"),\
                                                      round(sum("MCTModelReservedTrainingRevShareDollars"),4).alias("MCTModelReservedTrainingRevShareDollars"),\
                                                      round(sum("MCTModelOnDemandTrainingRevShareDollars"),4).alias("MCTModelOnDemandTrainingRevShareDollars"),\
                                                      round(sum("LakeflowConnectDBUs"),4).alias("LakeflowConnectDBUs"),
                                                      round(sum("LakeflowPipelinesDBUs"),4).alias("LakeflowPipelinesDBUs"),
                                                      round(sum("LakeflowDBUs"),4).alias("LakeflowDBUs"),
                                                      round(sum("LakeflowConnectRevShareDollars"),4).alias("LakeflowConnectRevShareDollars"),
                                                      round(sum("LakeflowPipelinesRevShareDollars"),4).alias("LakeflowPipelinesRevShareDollars"),
                                                      round(sum("LakeflowRevShareDollars"),4).alias("LakeflowRevShareDollars"),
                                                      round(sum("BatchInferenceModelServingDBUs"), 4).alias("BatchInferenceModelServingDBUs"),
                                                      round(sum("BatchInferenceModelServingRevShareDollars"), 4).alias("BatchInferenceModelServingRevShareDollars"),
                                                      round(sum("AgentFrameworkDBUs"), 4).alias("AgentFrameworkDBUs"),
                                                      round(sum("AgentFrameworkRevShareDollars"), 4).alias("AgentFrameworkRevShareDollars"),
                                                      round(sum("VectorSearchStorageDBUs"), 4).alias("VectorSearchStorageDBUs"),
                                                      round(sum("VectorSearchStorageRevShareDollars"), 4).alias("VectorSearchStorageRevShareDollars"),
                                                      round(sum("FY26AIDBUs"), 4).alias("FY26AIDBUs"),
                                                      round(sum("FY26AIDollars"), 4).alias("FY26AIDollars"),
                                                      round(sum("UCRevShareDollars_calculated"),4).alias("UCRevShareDollars_calculated"),\
                                                      round(sum("StreamingDLTRevShareDollars_calculated"),4).alias("StreamingDLTRevShareDollars_calculated"),
                                                      round(sum("FinetuningDBUs"), 4).alias("FinetuningDBUs"),
                                                      round(sum("FinetuningRevShareDollars"), 4).alias("FinetuningRevShareDollars"),
                                                      round(sum("AgentEvalsDBUs"), 4).alias("AgentEvalsDBUs"),
                                                      round(sum("AgentEvalsRevShareDollars"), 4).alias("AgentEvalsRevShareDollars"),
                                                      round(sum("AgentEvalsSyntheticDataDBUs"), 4).alias("AgentEvalsSyntheticDataDBUs"),
                                                      round(sum("AgentEvalsSyntheticDataRevShareDollars"), 4).alias("AgentEvalsSyntheticDataRevShareDollars"),
                                                      round(sum("AIRuntimeDBUs"), 4).alias("AIRuntimeDBUs"),
                                                      round(sum("AIRuntimeRevShareDollars"), 4).alias("AIRuntimeRevShareDollars"),
                                                      round(sum("AnthropicThroughputModelServingDBUs"), 4).alias("AnthropicThroughputModelServingDBUs"),
                                                      round(sum("AnthropicThroughputModelServingRevShareDollars"), 4).alias("AnthropicThroughputModelServingRevShareDollars"),
                                                      round(sum("AnthropicFoundationModelAPIDBUs"), 4).alias("AnthropicFoundationModelAPIDBUs"),
                                                      round(sum("AnthropicFoundationModelAPIRevShareDollars"), 4).alias("AnthropicFoundationModelAPIRevShareDollars"),
                                                      round(sum("ModelServingFMAPIDBUs"), 4).alias("ModelServingFMAPIDBUs"),
                                                      round(sum("ModelServingFMAPIRevShareDollars"), 4).alias("ModelServingFMAPIRevShareDollars"),
                                                      round(sum("LakehouseMonitoringDBUs"), 4).alias("LakehouseMonitoringDBUs"),
                                                      round(sum("LakehouseMonitoringRevShareDollars"), 4).alias("LakehouseMonitoringRevShareDollars"),
                                                      round(sum("FmMixtral87bInstructDBUs"), 4).alias("FmMixtral87bInstructDBUs"),
                                                      round(sum("FmLlama270bChatDBUs"), 4).alias("FmLlama270bChatDBUs"),
                                                      round(sum("FmBgeLargeENDBUs"), 4).alias("FmBgeLargeENDBUs"),
                                                      round(sum("FmMpt30bInstructDBUs"), 4).alias("FmMpt30bInstructDBUs"),
                                                      round(sum("FmMpt7bInstructDBUs"), 4).alias("FmMpt7bInstructDBUs"),
                                                      round(sum("FmDatabricksDbrxChatDBUs"), 4).alias("FmDatabricksDbrxChatDBUs"),
                                                      round(sum("FmMixtral87bInstructRevShareDollars"), 4).alias("FmMixtral87bInstructRevShareDollars"),
                                                      round(sum("FmLlama270bChatRevShareDollars"), 4).alias("FmLlama270bChatRevShareDollars"),
                                                      round(sum("FmBgeLargeENRevShareDollars"), 4).alias("FmBgeLargeENRevShareDollars"),
                                                      round(sum("FmMpt30bInstructRevShareDollars"), 4).alias("FmMpt30bInstructRevShareDollars"),
                                                      round(sum("FmMpt7bInstructRevShareDollars"), 4).alias("FmMpt7bInstructRevShareDollars"),
                                                      round(sum("FmDatabricksDbrxChatRevShareDollars"), 4).alias("FmDatabricksDbrxChatRevShareDollars")
                                                    )


  apmoller_updated_withoutSKU = apmoller_updated_withoutSKU.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                           .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                           .withColumn("cumDBDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                           .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                           .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                           .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                           .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                           .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                           .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                           .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))

  apmoller_updated_withoutSKU = apmoller_updated_withoutSKU.withColumnRenamed("cumDBDollars", "cumRevShareDollars")
  apmoller_updated_withoutSKU = apmoller_updated_withoutSKU.withColumn("consumptionType", consumptionType("aggOrder"))
  
  apmoller_updated.write.option("overwriteSchema", "true").format("delta").mode(write_mode).save(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION)
  apmoller_updated_withoutSKU.write.option("overwriteSchema", "true").format("delta").mode(write_mode).save(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION)

# COMMAND ----------

# DBTITLE 1,Multi Shared 
multi_shared_accounts_df = spark.sql(f"""
select sfdcAccountID,
       count(aggOrder) cnt
from {BI_AGGORDERS}
where platform = "azure"
and scope = "Shared"
group by 1
having cnt > 1
order by 2 desc
""")
multi_shared_accounts_df = multi_shared_accounts_df.drop('cnt')

apmoller = prod_daily.filter(prod_daily.platform=='azure')\
                     .join(multi_shared_accounts_df, prod_daily.accountID==multi_shared_accounts_df.sfdcAccountID)\
                     .drop(multi_shared_accounts_df.sfdcAccountID)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)

# COMMAND ----------

apmoller.select("accountID").distinct().count()

# COMMAND ----------

queries = [f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'MTMAzure0016100001BMXgcAAH',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-03-28',
    endDate = '2023-03-07'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001BMXgcAAH-2019-12-28'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-0016100001ceMOHAA2-2020-07-10',
    ListCommit = 500000,
    DiscountedCommit = 400000,
    RevShareCommit = 340000,
    startDate = '2020-07-10',
    endDate = '2020-07-11',
    Scope = 'Shared'
where isBurst = 1
and usage_date > "2020-07-13"
and aggOrder = 'SharedAzure-0016100001ceMOHAA2-2019-12-30'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'MTMAzure0016100001SRebmAAD',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-05-29',
    endDate = '2023-05-28'
where isBurst = 1
and usage_date < "2020-07-06"
and aggOrder = 'SharedAzure-0016100001SRebmAAD-2019-12-03'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-0016100001SRebmAAD-2020-07-06',
    ListCommit = 50000,
    DiscountedCommit = 46000,
    RevShareCommit = 39100,
    startDate = '2020-07-10',
    endDate = '2020-07-11',
    Scope = 'Shared'
where isBurst = 1
and usage_date >= "2020-07-06"
and aggOrder = 'SharedAzure-0016100001SRebmAAD-2019-12-03'
""",


f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'MTMAzure0016100001D4VoPAAV',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-01-31',
    endDate = '2023-01-30'
where isBurst = 1
and usage_date < "2020-05-06"
and aggOrder = 'SharedAzure-0016100001D4VoPAAV-2019-12-12'
""",


f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-0016100001D4VoPAAV-2020-05-06',
    ListCommit = 2000000,
    DiscountedCommit = 1340000,
    RevShareCommit = 1139000,
    startDate = '2020-05-06',
    endDate = '2021-05-06',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001D4VoPAAV-2019-12-12'
""",


f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-0016100000U5DvcAAF-2020-07-13',
    ListCommit = 1000000,
    DiscountedCommit = 730000,
    RevShareCommit = 620500,
    startDate = '2020-07-13',
    endDate = '2021-07-13',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100000U5DvcAAF-2019-12-27'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'MTMAzure0014N00001g7s1AQAQ',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2019-04-23',
    endDate = '2024-04-21'
where isBurst = 1
and usage_date < "2020-03-31"
and aggOrder = 'SharedAzure-0014N00001g7s1AQAQ-2019-09-30'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-0014N00001g7s1AQAQ-2020-03-31',
    ListCommit = 100000,
    DiscountedCommit = 89000,
    RevShareCommit = 75650,
    startDate = '2020-03-31',
    endDate = '2021-03-31',
    Scope = 'Shared'
where isBurst = 1
and usage_date >= "2020-03-31"
and aggOrder = 'SharedAzure-0014N00001g7s1AQAQ-2019-09-30'
""",


f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'MTMAzure0016100000U5DrkAAF',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-09-20',
    endDate = '2023-09-19'
where isBurst = 1
and usage_date < "2020-06-01"
and aggOrder = 'SharedAzure-0016100000U5DrkAAF-2019-12-27'
""",
f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-0016100000U5DrkAAF-2020-06-01',
    ListCommit = 350000,
    DiscountedCommit = 287000,
    RevShareCommit = 243950,
    startDate = '2020-06-01',
    endDate = '2021-06-01',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100000U5DrkAAF-2019-12-27'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'MTMAzure0016100001Qcv5IAAR',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-11-16',
    endDate = '2023-09-19'
where isBurst = 1
and usage_date < "2020-06-03"
and aggOrder = 'SharedAzure-0016100001Qcv5IAAR-2019-11-28'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-0016100001Qcv5IAAR-2020-06-03',
    ListCommit = 500000,
    DiscountedCommit = 400000,
    RevShareCommit = 340000,
    startDate = '2020-06-03',
    endDate = '2021-06-03',
    Scope = 'Shared'
where isBurst = 1
and usage_date >= "2020-06-03"
and aggOrder = 'SharedAzure-0016100001Qcv5IAAR-2019-11-28'
""",
f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'MTMAzure0016100001cgIbvAAE',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-07-26',
    endDate = '2023-07-25'
where isBurst = 1
and usage_date < "2020-05-29"
and aggOrder = 'SharedAzure-0016100001cgIbvAAE-2019-12-16'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-0016100001cgIbvAAE-2020-05-29',
    ListCommit = 100000,
    DiscountedCommit = 89000,
    RevShareCommit = 75650,
    startDate = '2020-05-29',
    endDate = '2021-05-29',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001cgIbvAAE-2019-12-16'
""",
f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'MTMAzure00161000014ranaAAA',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-07-26',
    endDate = '2023-07-25'
where isBurst = 1
and usage_date < "2020-08-19"
and aggOrder = 'SharedAzure-00161000014ranaAAA-2019-08-23'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-00161000014ranaAAA-2020-08-19',
    ListCommit = 200000,
    DiscountedCommit = 172000,
    RevShareCommit = 146200,
    startDate = '2020-08-19',
    endDate = '2021-08-19',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-00161000014ranaAAA-2019-08-23'
""",


f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'MTMAzure0014N00001g8CvNQAU',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2019-06-06',
    endDate = '2024-06-04'
where isBurst = 1
and usage_date < "2020-09-03"
and aggOrder = 'SharedAzure-0014N00001g8CvNQAU-2020-02-19'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-0014N00001g8CvNQAU-2020-09-03',
    ListCommit = 100000,
    DiscountedCommit = 89000,
    RevShareCommit = 75650,
    startDate = '2020-09-03',
    endDate = '2021-09-03',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0014N00001g8CvNQAU-2020-02-19'
""",


f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'SharedAzure-0016100000QKkOoAAL-2019-12-11',
    ListCommit = 2000000,
    DiscountedCommit = 1340000,
    RevShareCommit = 1139000,
    startDate = '2019-12-11',
    endDate = '2020-12-10',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SingleAzure-3e6a222a-e9a4-4a3a-bc52-ee646e2dcffd-2020-03-31'
""",
           

f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-0016100000QKkOoAAL-2020-05-22',
    ListCommit = 2000000,
    DiscountedCommit = 1340000,
    RevShareCommit = 1139000,
    startDate = '2019-12-11',
    endDate = '2020-12-10',
    Scope = 'Shared'
where isBurst = 1
and usage_date >= '2020-09-17'
and aggOrder = 'SharedAzure-0016100000QKkOoAAL-2019-12-11'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-0016100000RsHsgAAF-2020-05-29',
    ListCommit = 4000000,
    DiscountedCommit = 2680000,
    RevShareCommit = 2278000,
    startDate = '2020-05-29',
    endDate = '2021-05-29',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100000RsHsgAAF-2019-07-30'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'MTMAzure0016100001BIyGXAA1',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2019-06-03',
    endDate = '2024-06-01'
where isBurst = 1
and usage_date < "2020-03-31"
and aggOrder = 'SharedAzure-0016100001BIyGXAA1-2019-12-27'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-0016100001BIyGXAA1-2020-03-31',
    ListCommit = 1500000,
    DiscountedCommit = 1050000,
    RevShareCommit = 892500,
    startDate = '2020-03-31',
    endDate = '2021-03-31',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001BIyGXAA1-2019-12-27'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-0016100001BIyGXAA1-2020-06-26',
    ListCommit = 5000000,
    DiscountedCommit = 3149994,
    RevShareCommit = 2677496,
    startDate = '2020-06-26',
    endDate = '2021-06-26',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001BIyGXAA1-2020-03-31'
and usage_date > "2020-06-26"
""",
f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'MTMAzure0014N00001iqqJLQAY',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-09-19',
    endDate = '2023-09-19'
where isBurst = 1
and usage_date < "2020-09-14"
and aggOrder = 'SharedAzure-0014N00001iqqJLQAY-2020-03-13'
""", 
            
f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-0014N00001iqqJLQAY-2020-09-14',
    ListCommit = 100000,
    DiscountedCommit = 89000,
    RevShareCommit = 75650,
    startDate = '2020-09-14',
    endDate = '2021-09-13',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-0014N00001iqqJLQAY-2020-03-13'
and usage_date >= "2020-09-14"
""",
            
f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'MTMAzure00161000005eOkTAAU',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-02-07',
    endDate = '2023-02-06'
where isBurst = 1
and usage_date < "2020-09-25"
and aggOrder = 'SharedAzure-00161000005eOkTAAU-2019-10-29'
""",
f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-00161000005eOkTAAU-2020-09-25',
    ListCommit = 2500000,
    DiscountedCommit = 1675000,
    RevShareCommit = 1423750,
    startDate = '2020-09-25',
    endDate = '2021-09-24',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-00161000005eOkTAAU-2019-10-29'
and usage_date >= "2020-09-25"
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'MTMAzure0016100000U5DryAAF',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-04-11',
    endDate = '2023-04-10'
where isBurst = 1
and usage_date < "2020-09-25"
and aggOrder = 'SharedAzure-0016100000U5DryAAF-2019-09-27'
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-0016100000U5DryAAF-2020-09-25',
    ListCommit = 500000,
    DiscountedCommit = 400000,
    RevShareCommit = 340000,
    startDate = '2020-09-25',
    endDate = '2021-09-24',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-0016100000U5DryAAF-2019-09-27'
and usage_date >= "2020-09-25"
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'MTMAzure0016100000U5DtuAAF',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2019-07-24',
    endDate = '2024-07-22'
where isBurst = 1
and usage_date < "2020-09-28"
and aggOrder = 'SharedAzure-0016100000U5DtuAAF-2019-09-27'
""",
            
f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-0016100000U5DtuAAF-2020-09-28',
    ListCommit = 500000,
    DiscountedCommit = 328000,
    RevShareCommit = 278800,
    startDate = '2020-09-28',
    endDate = '2021-09-27',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-0016100000U5DtuAAF-2019-09-27'
and usage_date >= "2020-09-28"
""",

f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'MTMAzure0016100000U5DuHAAV',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-05-30',
    endDate = '2023-05-29'
where isBurst = 1
and usage_date < "2020-09-25"
and aggOrder = 'SharedAzure-0016100000U5DuHAAV-2019-12-20'
""",
f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-0016100000U5DuHAAV-2020-09-25',
    ListCommit = 400000,
    DiscountedCommit = 333000,
    RevShareCommit = 283050,
    startDate = '2020-09-25',
    endDate = '2021-09-24',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100000U5DuHAAV-2019-12-20'
and usage_date >= "2020-09-25"
""",
f"""update {USAGE_PROD_DAILY_INTERMEDIATE} 
set aggOrder = 'MTMAzure0016100001BKwEqAAL',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-07-20',
    endDate = '2023-07-19'
where isBurst = 1
and usage_date < "2020-09-28"
and aggOrder = 'SharedAzure-0016100001BKwEqAAL-2019-09-30'
""",
f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-0016100001BKwEqAAL-2020-09-28',
    ListCommit = 350000,
    DiscountedCommit = 287000,
    RevShareCommit = 243950,
    startDate = '2020-09-28',
    endDate = '2021-09-27',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-0016100001BKwEqAAL-2019-09-30'
and usage_date >= "2020-09-28"
""",
f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'MTMAzure0016100001XnYhuAAF',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-10-24',
    endDate = '2023-10-23'
where isBurst = 1
and usage_date < "2020-09-28"
and aggOrder = 'SharedAzure-0016100001XnYhuAAF-2019-09-17'
""",
f"""update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SharedAzure-0016100001XnYhuAAF-2020-09-28',
    ListCommit = 350000,
    DiscountedCommit = 287000,
    RevShareCommit = 243950,
    startDate = '2020-09-28',
    endDate = '2021-09-27',
    Scope = 'Shared'
where isBurst = 1
and aggOrder =  'SharedAzure-0016100001XnYhuAAF-2019-09-17'
and usage_date >= "2020-09-28"
"""
] 

# COMMAND ----------

for query in queries:
  spark.sql(query)

# COMMAND ----------

write_to_adhoc_daily("overwrite")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# DBTITLE 1,Shared 1
rowsprocessed = spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).select("accountId").distinct().collect()
azureaccountsProcessed = [row.accountId for row in rowsprocessed]
# azure shared only
shared_only = set(account_list['Shared']).difference(set(azureaccountsProcessed))
shared_only_query =f"""
select distinct sfdcAccountId
from {BI_AGGORDERS}
where platform = 'azure'
and sfdcAccountId in {tuple(shared_only)}"""
shared_accounts_df = spark.sql(shared_only_query)

apmoller = prod_daily.filter(prod_daily.platform=='azure')\
                     .join(shared_accounts_df, prod_daily.accountID==shared_accounts_df.sfdcAccountId)\
                     .drop(shared_accounts_df.sfdcAccountId)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)

# COMMAND ----------

spark.sql(f"select distinct accountId from {USAGE_PROD_DAILY_INTERMEDIATE}").count()

# COMMAND ----------

#TODO: Need to optimize this code. Can use SQL query to update the data all at once instead of using for loop.
sharedAccountsBurstRows = spark.sql(f"select distinct accountId, aggOrder from {USAGE_PROD_DAILY_INTERMEDIATE} where isBurst = 1 and aggOrder not like 'MTMAzure%'").collect()
for row in sharedAccountsBurstRows:
  print("processing...", row.accountId)
  updateQuery = getAzureUpdateQuery(row.accountId, row.aggOrder)
  spark.sql(updateQuery)

# COMMAND ----------

write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# DBTITLE 1,Single
rowsprocessed = spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).select("accountId").distinct().collect()
azureaccountsProcessed = [row.accountId for row in rowsprocessed]
# azure single only
parallel_exclude = ['0016100000cF2TtAAK']
single_only = set(account_list['Single']).difference(set(azureaccountsProcessed + parallel_exclude))
single_only_query = f"""
select distinct sfdcAccountId
from {BI_AGGORDERS}
where platform = 'azure'
and sfdcAccountId in {tuple(single_only)}"""
single_only_df = spark.sql(single_only_query)

apmoller = prod_daily.filter(prod_daily.platform=='azure')\
                     .join(single_only_df, prod_daily.accountID==single_only_df.sfdcAccountId)\
                     .drop(single_only_df.sfdcAccountId)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)

# COMMAND ----------

sharedAccountsBurstRows = spark.sql(f"select distinct accountId, aggOrder from {USAGE_PROD_DAILY_INTERMEDIATE} where isBurst = 1 and aggOrder not like 'MTMAzure%'").collect()
for row in sharedAccountsBurstRows:
  print("processing...", row.accountId)
  updateQuery = getAzureUpdateQuery(row.accountId, row.aggOrder)
  spark.sql(updateQuery)

# COMMAND ----------

write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# DBTITLE 1,Shared-Single
#len(account_list['Single'] + account_list['SharedSingle'] + account_list['Shared'])
#shared_single_only
rowsprocessed = spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).select("accountId").distinct().collect()
azureaccountsProcessed = [row.accountId for row in rowsprocessed]

parallel_exclude = ['0016100000cF2TtAAK']
shared_single_only = set(account_list['SharedSingle'] + account_list['SingleShared'] + parallel_exclude).difference(set(azureaccountsProcessed))
print(shared_single_only)

shared_single_only_query = f"""
select distinct sfdcAccountId
from {BI_AGGORDERS}
where platform = 'azure'
and sfdcAccountId in {tuple(shared_single_only)}"""

shared_single_only_df = spark.sql(shared_single_only_query)

apmoller = prod_daily.filter(prod_daily.platform=='azure')\
                     .join(shared_single_only_df, prod_daily.accountID==shared_single_only_df.sfdcAccountId)\
                     .drop(shared_single_only_df.sfdcAccountId)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)
# '0016100000cF2TtAAK', '00161000019RwocAAC', '0016100000ZbzS9AAJ', '0016100000VnnNnAAJ', '0016100001TPfNIAA1', '0016100001BMXgcAAH'

# COMMAND ----------

# DBTITLE 1,queries
import time
queries2 = [
f"""
update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'MTMAzure0016100000ZbzS9AAJ',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-01-03',
    endDate = '2023-01-02'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100000ZbzS9AAJ-2020-05-01'
""",
f"""
update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SingleAzure-0f30bd24-665b-44a2-96c7-15d3322c3ab6-2020-09-23',
    ListCommit = 150000,
    DiscountedCommit = 128250,
    RevShareCommit = 109013,
    startDate = '2020-09-23',
    endDate = '2021-09-22',
    Scope = 'Shared'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001TPfNIAA1-2020-03-09'
""",
f"""
update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'MTMAzure0016100001BMXgcAAH',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-03-28',
    endDate = '2023-03-07'
where isBurst = 1
and aggOrder = 'SharedAzure-0016100001BMXgcAAH-2019-12-28'
""",
  
f"""
update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'MTMAzure0016100000cF2TtAAK',
    ListCommit = 0,
    DiscountedCommit = 0,
    RevShareCommit = 0,
    Scope = 'shared',
    startDate = '2018-04-27',
    endDate = '2023-04-26'
where isBurst = 1
and aggOrder = 'SingleAzure-45c1c272-b31e-4c6b-a4ef-22dc7ccdbb73-2019-12-18'
and usage_date < "2020-05-07"
""",

f"""
update {USAGE_PROD_DAILY_INTERMEDIATE}
set aggOrder = 'SingleAzure-45c1c272-b31e-4c6b-a4ef-22dc7ccdbb73-2020-05-07',
    ListCommit = 25000,
    DiscountedCommit = 23500,
    RevShareCommit = 19975,
    startDate = '2020-05-07',
    endDate = '2021-05-07'
where isBurst = 1
and aggOrder = 'SingleAzure-45c1c272-b31e-4c6b-a4ef-22dc7ccdbb73-2019-12-18'
"""
]

for query in queries2:
  spark.sql(query)
  time.sleep(10)

# COMMAND ----------

write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# DBTITLE 1,MTM
mtm_accounts_df = spark.sql(f"""
select sfdcAccountID,
       count(aggOrder) cnt
from {BI_AGGORDERS}
where platform = "azure"
and scope in ("Shared", "shared", "Single")
and sfdcAccountID is not null
group by 1
having cnt = 1
order by 2 desc
""")
mtm_accounts_df = mtm_accounts_df.drop("cnt")
mtm_accounts = [row.sfdcAccountID for row in mtm_accounts_df.select("sfdcAccountID").distinct().collect()]

only_mtm_accounts = set(mtm_accounts).difference(set(account_list['Single'] + account_list['SharedSingle'] + account_list['Shared']))
print(len(only_mtm_accounts))

only_mtm_accounts_query = f"""
select distinct sfdcAccountId
from {BI_AGGORDERS}
where platform = 'azure'
and sfdcAccountId in {tuple(only_mtm_accounts)}"""
only_mtm_accounts = spark.sql(only_mtm_accounts_query)

apmoller = prod_daily.filter(prod_daily.platform=='azure')\
                     .join(only_mtm_accounts, prod_daily.accountID==only_mtm_accounts.sfdcAccountId)\
                     .drop(only_mtm_accounts.sfdcAccountId)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)
write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# DBTITLE 1,AWS novl
# done: change the join
processed = spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION)
uploaded_accounts = processed.filter(processed.platform == 'aws').select("accountId").distinct()
#spark.sql("select distinct accountId from bdw.usagec_aggorder_daily where platform = 'aws'")

# non overlapping consecutive contracts - aws
aws_novl_contracts = spark.sql(f"""
with aws_accounts_morethan1 (
select sfdcAccountID,
       count(aggOrder) cnt
from {BI_AGGORDERS}
where platform = "aws"
and scope in ("aws-defined")
group by 1
order by 2 desc

),
nextAggOrders (
select agg.*,
       coalesce(lead(agg.startDate) over(partition by agg.sfdcAccountID order by agg.startDate), date_add(agg.endDate, 1)) nextStartDate
from {BI_AGGORDERS} agg
join aws_accounts_morethan1 m on agg.sfdcAccountID == m.sfdcAccountID
where platform = 'aws'
and agg.aggOrder not like 'MTM%'
order by agg.sfdcAccountID, agg.startDate 
),

cleanAggOrders (
select *,
       case when datediff(nextStartDate, endDate)=1 then 0
            when nextStartDate > endDate then 0
            else 1
       end as overLapFlag
from nextAggOrders
)

select sfdcAccountID,
       sum(overLapFlag) totalSum
from cleanAggOrders
group by sfdcAccountID
having totalSum = 0
""")
aws_novl_contracts = aws_novl_contracts.drop("totalSum")
aws_novl_contracts = aws_novl_contracts.join(uploaded_accounts, aws_novl_contracts.sfdcAccountID==uploaded_accounts.accountId, 'left')\
                             .filter(uploaded_accounts.accountId.isNull())\
                             .drop(uploaded_accounts.accountId)

trueParallelContracts = spark.read.format("delta").load(PARALLEL_CONTRACTS_CLEAN_LOCATION).select("sfdcAccountId").distinct()
# trueParallelContracts = trueParallelContracts.withColumnRenamed("sfdcAccountId", "accountId")
# aws_novl = aws_novl.join(trueParallelContracts, aws_novl.sfdcAccountID==trueParallelContracts.accountId, 'left')\
#                              .filter(trueParallelContracts.accountId.isNull())\
#                              .drop(trueParallelContracts.accountId)
# pvc_exclude = ['00161000005eOinAAE', '0016100000d1P6mAAE', '00161000016vS8lAAE']
aws_novl_accounts = [row.sfdcAccountID for row in aws_novl_contracts.collect()]
tp_accounts = [row.sfdcAccountId for row in trueParallelContracts.collect()] #+ pvc_exclude

aws_novl_only = list(set(aws_novl_accounts).difference(set(tp_accounts)))

aws_novl_only_query = f"""
select distinct sfdcAccountId
from {BI_AGGORDERS}
where platform = 'aws'
and sfdcAccountId in {tuple(aws_novl_only)}"""

aws_novl = spark.sql(aws_novl_only_query)

apmoller = prod_daily.filter(prod_daily.platform=='aws')\
                     .join(aws_novl, prod_daily.accountID==aws_novl.sfdcAccountId)\
                     .drop(aws_novl.sfdcAccountId)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)
write_to_adhoc_daily("append")

# COMMAND ----------

aws_novl.count()

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# DBTITLE 1,include parallel processing from other-notebook
import json
job_status = run_notebook("DailyParallelListProcessingAWS", 3600,{"environment" : environment})
if json.loads(job_status)['status'] == 'OK':
  print(spark.sql(f"select * from {USAGE_PROD_DAILY_INTERMEDIATE}").count())
else:
  raise Exception("error while processing Parallel Contracts")

# COMMAND ----------

write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# aws payg
missingPAYG = spark.sql(f"""
      with commitPayGAccs (
      select sfdc_account_id accountID,
             count(distinct ctc_flag) cnt
      from {FINANCE_USAGE_PRICING}
      where platform = "aws"
            and date < '{SOURCE_SWITCH_DATE}'
      group by 1
      having cnt > 1

      UNION ALL

      select sfdc_account_id accountID,
             count(distinct ctc_flag) cnt
      from {FINANCE_PAID_METERING_USAGE}
      where platform = "aws"
            and date >= '{SOURCE_SWITCH_DATE}'
      group by 1
      having cnt > 1
      ),
      onlyPayGAccounts (
      select sfdcAccountID,
             count(AggOrder) cnt
      from {BI_AGGORDERS}
      where platform = "aws"
      group by 1
      having cnt = 1
      )
      select o.sfdcAccountID
      from onlyPayGAccounts o
      join commitPayGAccs c on o.sfdcAccountID = c.accountID
""").collect()
missingPAYG = [row.sfdcAccountID for row in missingPAYG]

payg_accounts = spark.sql(f"""select distinct sfdc_account_id accountID
from {FINANCE_USAGE_PRICING}
where platform = "aws"
and ctc_flag = 0
and sfdc_account_id is not null
and date < '{SOURCE_SWITCH_DATE}'

union all

select distinct sfdc_account_id accountID
from {FINANCE_PAID_METERING_USAGE}
where platform = "aws"
and ctc_flag = 0
and sfdc_account_id is not null
and date >= '{SOURCE_SWITCH_DATE}'
""").collect()

UNMAPPED_ACCOUNTS = ["0013f000005RwT9AAK", "0013f0000063xxQAAQ", "0013f0000063xxLAAQ"]
payg_accounts = [row.accountID for row in payg_accounts] + UNMAPPED_ACCOUNTS

commit_accounts = spark.sql(f"""select distinct sfdc_account_id accountID
from {FINANCE_USAGE_PRICING}
where platform = "aws"
and ctc_flag = 1
and sfdc_account_id is not null
and date < '{SOURCE_SWITCH_DATE}'

union all

select distinct sfdc_account_id accountID
from {FINANCE_PAID_METERING_USAGE}
where platform = "aws"
and ctc_flag = 1
and sfdc_account_id is not null
and date >= '{SOURCE_SWITCH_DATE}'
""").collect()

commit_accounts = [row.accountID for row in commit_accounts]

processed = spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION)
uploaded_accounts = processed.filter(processed.platform == 'aws').select("accountId").distinct().collect()
uploaded_accounts = [row.accountId for row in uploaded_accounts]

payg_minus_commit = list(set(payg_accounts).difference(set(commit_accounts))) + missingPAYG
notuploaded_payg = list(set(payg_minus_commit).difference(set(uploaded_accounts)))
commitButNotUploaded = list(set(commit_accounts).difference(set(uploaded_accounts)))

#PVC_EXCLUDE = ['00161000005eOinAAE', '0016100000d1P6mAAE', '00161000016vS8lAAE']
totalAccountsToBePAYG = set(notuploaded_payg + commitButNotUploaded) #.difference(set(PVC_EXCLUDE))

payg_orders = f"""
select distinct sfdcAccountID
from {BI_AGGORDERS}
where platform = "aws"
and sfdcAccountID in {tuple(totalAccountsToBePAYG)}"""

mtm_aws = spark.sql(payg_orders)

apmoller = prod_daily.filter(prod_daily.platform=='aws')\
                     .join(mtm_aws, prod_daily.accountID==mtm_aws.sfdcAccountID)\
                     .drop(mtm_aws.sfdcAccountID)\
                     .orderBy(*orderByColumns)

write_to_daily_intermediate(apmoller)
write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# ADHOC_DAILY_USAGE_LOC = usagec_prod_daily_modified_adhoc_location
# ADHOC_DAILY_AGGORDER_LOC = usagec_agg_order_daily_adhoc_location

# COMMAND ----------

# DBTITLE 1,GCP novl
gcp_novl_contracts = spark.sql(f"""
with accounts_morethan1 (

select sfdcAccountID,
       count(aggOrder) cnt
from {BI_AGGORDERS}
where platform = "gcp"
and scope in ("gcp-defined")
group by 1
order by 2 desc

),
nextAggOrders (
select agg.*,
       coalesce(lead(agg.startDate) over(partition by agg.sfdcAccountID order by agg.startDate), date_add(agg.endDate, 1)) nextStartDate
from {BI_AGGORDERS} agg
join accounts_morethan1 m on agg.sfdcAccountID == m.sfdcAccountID
where platform = 'gcp'
and agg.aggOrder not like 'MTM%'
order by agg.sfdcAccountID, agg.startDate 
),

cleanAggOrders (
select *,
       case when datediff(nextStartDate, endDate)=1 then 0
            when nextStartDate > endDate then 0
            else 1
       end as overLapFlag
from nextAggOrders
)

select sfdcAccountID,
       sum(overLapFlag) totalSum
from cleanAggOrders
group by sfdcAccountID
having totalSum = 0
""")
gcp_novl_contracts = gcp_novl_contracts.drop("totalSum")
gcp_novl_accounts = [row.sfdcAccountID for row in gcp_novl_contracts.collect()]


gcp_novl_only = tuple(list(set(gcp_novl_accounts)))

if len(gcp_novl_only) == 1:
  tuple_gcp_novl_only = '("{0}")'.format(gcp_novl_only[0])
else:
  tuple_gcp_novl_only = gcp_novl_only
  
gcp_novl_only_query = f"""
select distinct sfdcAccountId
from {BI_AGGORDERS}
where platform = 'gcp'
and sfdcAccountId in {tuple_gcp_novl_only}"""

gcp_novl = spark.sql(gcp_novl_only_query)

gcp_novl_usage = prod_daily.filter(prod_daily.platform=='gcp')\
                     .join(gcp_novl, prod_daily.accountID==gcp_novl.sfdcAccountId)\
                     .drop(gcp_novl.sfdcAccountId)\
                     .orderBy(*orderByColumns)

# COMMAND ----------

write_to_daily_intermediate(gcp_novl_usage)
write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# DBTITLE 1,GCP MTM
missingPAYG = spark.sql(f"""
      with commitPayGAccs (
      select sfdc_account_id accountID,
             count(distinct ctc_flag) cnt
      from {FINANCE_USAGE_PRICING}
      where platform = "gcp"
       and date < '{SOURCE_SWITCH_DATE}'
      group by 1
      having cnt > 1

      UNION ALL

      select sfdc_account_id accountID,
             count(distinct ctc_flag) cnt
      from {FINANCE_PAID_METERING_USAGE}
      where platform = "gcp"
       and date >= '{SOURCE_SWITCH_DATE}'
      group by 1
      having cnt > 1
      ),
      onlyPayGAccounts (
      select sfdcAccountID,
             count(AggOrder) cnt
      from {BI_AGGORDERS}
      where platform = "gcp"
      group by 1
      having cnt = 1
      )
      select o.sfdcAccountID
      from onlyPayGAccounts o
      join commitPayGAccs c on o.sfdcAccountID = c.accountID
""").collect()
missingPAYG = [row.sfdcAccountID for row in missingPAYG]

payg_accounts = spark.sql(f"""select distinct sfdc_account_id accountID
from {FINANCE_USAGE_PRICING}
where platform = "gcp"
and ctc_flag = 0
and sfdc_account_id is not null
and date < '{SOURCE_SWITCH_DATE}'

UNION ALL

select distinct sfdc_account_id accountID
from {FINANCE_PAID_METERING_USAGE}
where platform = "gcp"
and ctc_flag = 0
and sfdc_account_id is not null
and date >= '{SOURCE_SWITCH_DATE}'
""").collect()

UNMAPPED_ACCOUNT = ["0013f000005RwT9AAK"]
payg_accounts = [row.accountID for row in payg_accounts] + UNMAPPED_ACCOUNT

commit_accounts = spark.sql(f"""select distinct sfdc_account_id accountID
from {FINANCE_USAGE_PRICING}
where platform = "gcp"
and ctc_flag = 1
and sfdc_account_id is not null
and date < '{SOURCE_SWITCH_DATE}'

UNION ALL

select distinct sfdc_account_id accountID
from {FINANCE_PAID_METERING_USAGE}
where platform = "gcp"
and ctc_flag = 1
and sfdc_account_id is not null
and date >= '{SOURCE_SWITCH_DATE}'
""").collect()

commit_accounts = [row.accountID for row in commit_accounts]

processed = spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION)
uploaded_accounts = processed.filter(processed.platform == 'gcp').select("accountId").distinct().collect()
uploaded_accounts = [row.accountId for row in uploaded_accounts]

payg_minus_commit = list(set(payg_accounts).difference(set(commit_accounts))) + missingPAYG
notuploaded_payg = list(set(payg_minus_commit).difference(set(uploaded_accounts)))
commitButNotUploaded = list(set(commit_accounts).difference(set(uploaded_accounts)))

#PVC_EXCLUDE = ['00161000005eOinAAE', '0016100000d1P6mAAE', '00161000016vS8lAAE']
totalAccountsToBePAYG = set(notuploaded_payg + commitButNotUploaded) #.difference(set(PVC_EXCLUDE))

payg_orders = f"""
select distinct sfdcAccountID
from {BI_AGGORDERS}
where platform = "gcp"
and sfdcAccountID in {tuple(totalAccountsToBePAYG)}"""

mtm_gcp = spark.sql(payg_orders)

apmoller = prod_daily.filter(prod_daily.platform=='gcp')\
                     .join(mtm_gcp, prod_daily.accountID==mtm_gcp.sfdcAccountID)\
                     .drop(mtm_gcp.sfdcAccountID)\
                     .orderBy(*orderByColumns)

# COMMAND ----------

write_to_daily_intermediate(apmoller)
write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# DBTITLE 1,MCT Bi-Aggorders (MTM)
spark.sql(f'''
select null usageBurstDate,
       concat("MTMMCT",coalesce(sfdc_account_id, 'noSFDCAccountID'))  AggOrder,
       coalesce(sfdc_account_id, 'noSFDCAccountID') sfdcAccountID,
       coalesce(sfdc_account_name, 'noSFDCAccountName') sfdcAccountName, 
       'mct' Platform,
       'shared' Scope,
       'MTMSubscriptionID' SubscriptionID, 
       min(date) startDate,
       date_add(min(date), (365*25)) endDate,
       0 cloudPartnerPurchase,
       0 ActualPartnerCommit,
       0 DBShareCommit,
       cast(0 as double) dbuCustPriceDiscount,
       concat("MTM",coalesce(sfdc_account_id, 'noSFDCAccountID')) orderId
  from {FINANCE_PAID_METERING_USAGE}
  where platform = 'mct'
  group by sfdc_account_id, sfdc_account_name
''').createOrReplaceTempView('mct_bi_aggorders')

# COMMAND ----------

# DBTITLE 1,MCT Novl
mct_novl_contracts = spark.sql(f"""
with accounts_morethan1 (

select sfdcAccountID,
       count(aggOrder) cnt
from mct_bi_aggorders
where platform = "mct"
and scope in ("mct-defined")
group by 1
order by 2 desc

),
nextAggOrders (
select agg.*,
       coalesce(lead(agg.startDate) over(partition by agg.sfdcAccountID order by agg.startDate), date_add(agg.endDate, 1)) nextStartDate
from mct_bi_aggorders agg
join accounts_morethan1 m on agg.sfdcAccountID == m.sfdcAccountID
where platform = 'mct'
and agg.aggOrder not like 'MTM%'
order by agg.sfdcAccountID, agg.startDate 
),

cleanAggOrders (
select *,
       case when datediff(nextStartDate, endDate)=1 then 0
            when nextStartDate > endDate then 0
            else 1
       end as overLapFlag
from nextAggOrders
)

select sfdcAccountID,
       sum(overLapFlag) totalSum
from cleanAggOrders
group by sfdcAccountID
having totalSum = 0
""")
mct_novl_contracts = mct_novl_contracts.drop("totalSum")
mct_novl_accounts = [row.sfdcAccountID for row in mct_novl_contracts.collect()]


mct_novl_only = tuple(list(set(mct_novl_accounts)))

if len(mct_novl_only) == 1:
  tuple_mct_novl_only = '("{0}")'.format(mct_novl_only[0])
else:
  tuple_mct_novl_only = mct_novl_only
  
if len(tuple_mct_novl_only) > 0:
  mct_novl_only_query = f"""
  select distinct sfdcAccountId
  from mct_bi_aggorders
  where platform = 'mct'
  and sfdcAccountId in {tuple_mct_novl_only}"""

  mct_novl = spark.sql(mct_novl_only_query)

  mct_novl_usage = prod_daily.filter(prod_daily.platform=='mct')\
                      .join(mct_novl, prod_daily.accountID==mct_novl.sfdcAccountId)\
                      .drop(mct_novl.sfdcAccountId)\
                      .orderBy(*orderByColumns)

  write_to_daily_intermediate(mct_novl_usage)
  write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# DBTITLE 1,MCT MTM
missingPAYG = spark.sql(f"""
      with commitPayGAccs (
      select sfdc_account_id accountID,
             count(distinct ctc_flag) cnt
      from {FINANCE_USAGE_PRICING}
      where platform = "mct"
       and date < '{SOURCE_SWITCH_DATE}'
      group by 1
      having cnt > 1

      UNION ALL

      select sfdc_account_id accountID,
             count(distinct ctc_flag) cnt
      from {FINANCE_PAID_METERING_USAGE}
      where platform = "mct"
       and date >= '{SOURCE_SWITCH_DATE}'
      group by 1
      having cnt > 1
      ),
      onlyPayGAccounts (
      select sfdcAccountID,
             count(AggOrder) cnt
      from mct_bi_aggorders
      where platform = "mct"
      group by 1
      having cnt = 1
      )
      select o.sfdcAccountID
      from onlyPayGAccounts o
      join commitPayGAccs c on o.sfdcAccountID = c.accountID
""").collect()
missingPAYG = [row.sfdcAccountID for row in missingPAYG]

payg_accounts = spark.sql(f"""select distinct sfdc_account_id accountID
from {FINANCE_USAGE_PRICING}
where platform = "mct"
and ctc_flag = 0
and sfdc_account_id is not null
and date < '{SOURCE_SWITCH_DATE}'

UNION ALL

select distinct sfdc_account_id accountID
from {FINANCE_PAID_METERING_USAGE}
where platform = "mct"
and ctc_flag = 0
and sfdc_account_id is not null
and date >= '{SOURCE_SWITCH_DATE}'
""").collect()

UNMAPPED_ACCOUNT = ["0013f000005RwT9AAK"]
payg_accounts = [row.accountID for row in payg_accounts] + UNMAPPED_ACCOUNT

commit_accounts = spark.sql(f"""select distinct sfdc_account_id accountID
from {FINANCE_USAGE_PRICING}
where platform = "mct"
and ctc_flag = 1
and sfdc_account_id is not null
and date < '{SOURCE_SWITCH_DATE}'

UNION ALL

select distinct sfdc_account_id accountID
from {FINANCE_PAID_METERING_USAGE}
where platform = "mct"
and ctc_flag = 1
and sfdc_account_id is not null
and date >= '{SOURCE_SWITCH_DATE}'
""").collect()

commit_accounts = [row.accountID for row in commit_accounts]

processed = spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION)
uploaded_accounts = processed.filter(processed.platform == 'mct').select("accountId").distinct().collect()
uploaded_accounts = [row.accountId for row in uploaded_accounts]

payg_minus_commit = list(set(payg_accounts).difference(set(commit_accounts))) + missingPAYG
notuploaded_payg = list(set(payg_minus_commit).difference(set(uploaded_accounts)))
commitButNotUploaded = list(set(commit_accounts).difference(set(uploaded_accounts)))

#PVC_EXCLUDE = ['00161000005eOinAAE', '0016100000d1P6mAAE', '00161000016vS8lAAE']
totalAccountsToBePAYG = set(notuploaded_payg + commitButNotUploaded) #.difference(set(PVC_EXCLUDE))

payg_orders = f"""
select distinct sfdcAccountID
from mct_bi_aggorders
where platform = "mct"
and sfdcAccountID in {tuple(totalAccountsToBePAYG)}"""

mtm_mct = spark.sql(payg_orders)

apmoller = prod_daily.filter(prod_daily.platform=='mct')\
                     .join(mtm_mct, prod_daily.accountID==mtm_mct.sfdcAccountID)\
                     .drop(mtm_mct.sfdcAccountID)\
                     .orderBy(*orderByColumns)

# COMMAND ----------

write_to_daily_intermediate(apmoller)
write_to_adhoc_daily("append")

# COMMAND ----------

print(spark.read.format("delta").load(USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION).count())
print(spark.read.format("delta").load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION).count())

# COMMAND ----------

# daily_df = spark.read.format("delta").load("/mnt/bse-dev/usagec_prod_daily_modified_adhoc").dropDuplicates()
# daily_df.count()
# daily_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/usagec_prod_daily")

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))
