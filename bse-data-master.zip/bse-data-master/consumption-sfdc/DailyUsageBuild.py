# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TABLE {FINANCE_USAGE_STAGE}
AS SELECT * FROM {FINANCE_DBU_DOLLARS}
""")

# COMMAND ----------

aws_usage_granular_df = spark.sql(f"""
select sfdc_account_id accountID,
       sfdc_account_name accountName,
       date usage_date,
       lower(sku) usage_sku,
       round(dbu,4) dbu_quantity,
       workspace_sfdc_object_id workspaceSFDCID,
       platform,
       type as product_type,
       NULL as product_features,
       shard_region deployedRegion,
       sfdc_workspace_id as workspaceId,
       ps.Name businessSubscriptionID,
       list_price listPrice,
       dbu_price dbuRevSharePrice,
       discount_price dbuCustPrice,      
       round(delta_dbu,4) delta_dbu_quantity,
       coalesce(isv_dbu,0) isv_dbu_quantity,
       coalesce(dbt_dbu,0) dbt_dbu_quantity,
       coalesce(uc_dbu_salescomp, 0) uc_dbu_quantity,
       coalesce(uc_dbu_dollars_salescomp, 0) uc_dbu_dollars,
       coalesce(ml_dbu, 0) ml_dbu_quantity,
       coalesce(fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(streaming_dlt_dbu_salescomp, 0) streaming_dlt_dbu_quantity,
       coalesce(streaming_dlt_dbu_dollars_salescomp, 0) streaming_dlt_dbu_dollars,
       0 cpu_model_serving_dollars,
       0 gpu_model_serving_dbu_quantity,
       0 gpu_model_serving_dollars,
       0 throughput_model_serving_dbu_quantity,
       0 throughput_model_serving_dollars,
       0 foundation_model_api_dbu_quantity,
       0 foundation_model_api_dollars,
       0 foundation_model_training_dollars,
       0 vector_search_dbu_quantity,
       0 vector_search_dollars,
       0 vector_search_ingestion_dollars,
       0 vector_search_serving_dollars,
       0 gen_ai_dbu_quantity,
       0 gen_ai_dbu_dollars,
       0 lakeflow_connect_dbu_quantity,
       0 lakeflow_pipelines_dbu_quantity,
       0 lakeflow_dbu_quantity,
       0 lakeflow_connect_dollars,
       0 lakeflow_pipelines_dollars,
       0 lakeflow_dollars,
       0 batch_inference_model_serving_dbu_quantity,
       0 batch_inference_model_serving_dollars,
       0 agent_framework_dbu_quantity,
       0 agent_framework_dollars,
       0 vector_search_storage_dbu_quantity,
       0 vector_search_storage_dollars,
       0 fy26_ai_dbu_quantity,
       0 fy26_ai_dollars,
       0 mct_dbu_quantity,
       0 mct_dbu_dollars,
       0 mct_model_hero_run_training_dollars,
       0 mct_model_reserved_training_dollars,
       0 mct_model_on_demand_training_dollars,
       0 as finetuning_dbu_quantity,
       0 as finetuning_training_dollars,
       0 as agent_evals_dbu_quantity,
       0 as agent_evals_dollars,
       0 as agent_evals_synthetic_data_dbu_quantity,
       0 as agent_evals_synthetic_data_dollars,
       0 as ai_runtime_dbu_quantity,
       0 as ai_runtime_dollars,
       0 as anthropic_throughput_model_serving_dbu_quantity,
       0 as anthropic_throughput_model_serving_dollars,
       0 as anthropic_foundation_model_api_dbu_quantity,
       0 as anthropic_foundation_model_api_dollars,
       0 as model_serving_fmapi_dbu_quantity,
       0 as model_serving_fmapi_dollars,
       0 as lakehouse_monitoring_dbu,
       0 as lakehouse_monitoring_dollars,
       0 as fm_mixtral_8_7b_instruct_dbu,
       0 as fm_llama2_70b_chat_dbu,
       0 as fm_bge_large_en_dbu,
       0 as fm_mpt_30b_instruct_dbu,
       0 as fm_mpt_7b_instruct_dbu,
       0 as fm_databricks_dbrx_chat_dbu,
       0 as fm_mixtral_8_7b_instruct_dollars,
       0 as fm_llama2_70b_chat_dollars,
       0 as fm_bge_large_en_dollars,
       0 as fm_mpt_30b_instruct_dollars,
       0 as fm_mpt_7b_instruct_dollars,
       0 as fm_databricks_dbrx_chat_dollars,
       dbu_dollars,
       shield_dollars,
       is_paying isPaying
from {FINANCE_USAGE_STAGE} f
left join {SFDC_WORKSPACE} w 
  on f.workspace_sfdc_object_id = w.id
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
left join {SFDC_PLATFORM_SUBSCRIPTION} ps
  on w.Business_Subscription__c = ps.id
  and ps.processDate = (
    select max(processDate)
    from {SFDC_PLATFORM_SUBSCRIPTION}
  )
where platform in ('aws', 'gcp')
  and date < '{SOURCE_SWITCH_DATE}'

UNION ALL

select sfdc_account_id accountID,
       sfdc_account_name accountName,
       p.date usage_date,
       lower(sku) usage_sku,
       round(net_usage_amount,4) dbu_quantity,
       w.Id workspaceSFDCID, -- need to join in workspace table
       platform,
       product_type,
       product_features,
       shard_region deployedRegion,
       sfdc_workspace_id as workspaceId,
       business_subscription_id businessSubscriptionID,
       round(list_price, 2) listPrice,
       rev_share_price dbuRevSharePrice,
       discount_price dbuCustPrice,      
       round(workload_insights_metric.delta_dbu,4) delta_dbu_quantity,
       coalesce(workload_insights_metric.isv_dbu,0) isv_dbu_quantity,
       coalesce(workload_insights_metric.dbt_dbu,0) dbt_dbu_quantity,
       coalesce(sales_comp_metric.uc_dbu, 0) uc_dbu_quantity,
       coalesce(sales_comp_metric.uc_dollars, 0) uc_dbu_dollars,
       coalesce(workload_insights_metric.ml_dbu, 0) ml_dbu_quantity,
       coalesce(workload_insights_metric.fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dbu, 0) streaming_dlt_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dollars, 0) streaming_dlt_dbu_dollars,
       coalesce(sales_comp_metric.cpu_model_serving_dollars, 0) cpu_model_serving_dollars,
       coalesce(sales_comp_metric.gpu_model_serving_dbu, 0) gpu_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.gpu_model_serving_dollars, 0) gpu_model_serving_dollars,
       coalesce(sales_comp_metric.throughput_model_serving_dbu, 0) throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.throughput_model_serving_dollars, 0) throughput_model_serving_dollars,
       coalesce(sales_comp_metric.foundation_model_api_dbu, 0) foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.foundation_model_api_dollars, 0) foundation_model_api_dollars,
       coalesce(sales_comp_metric.foundation_model_training_dollars, 0) foundation_model_training_dollars,
       coalesce(sales_comp_metric.vector_search_dbu, 0) vector_search_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_dollars, 0) vector_search_dollars,
       coalesce(sales_comp_metric.vector_search_ingestion_dollars, 0) vector_search_ingestion_dollars,
       coalesce(sales_comp_metric.vector_search_serving_dollars, 0) vector_search_serving_dollars,
       coalesce(sales_comp_metric.gen_ai_dbu, 0) gen_ai_dbu_quantity,
       coalesce(sales_comp_metric.gen_ai_dollars, 0) gen_ai_dbu_dollars,
       coalesce(sales_comp_metric.lakeflow_connect_dbu, 0) lakeflow_connect_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_pipelines_dbu, 0) lakeflow_pipelines_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_dbu, 0) lakeflow_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_connect_dollars, 0) lakeflow_connect_dollars,
       coalesce(sales_comp_metric.lakeflow_pipelines_dollars, 0) lakeflow_pipelines_dollars,
       coalesce(sales_comp_metric.lakeflow_dollars, 0) lakeflow_dollars,
       coalesce(sales_comp_metric.batch_inference_model_serving_dbu, 0) as batch_inference_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.batch_inference_model_serving_dollars, 0) as batch_inference_model_serving_dollars,
       coalesce(sales_comp_metric.agent_framework_dbu, 0) as agent_framework_dbu_quantity,
       coalesce(sales_comp_metric.agent_framework_dollars, 0) as agent_framework_dollars,
       coalesce(sales_comp_metric.vector_search_storage_dbu, 0) as vector_search_storage_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_storage_dollars, 0) as vector_search_storage_dollars,
       coalesce(sales_comp_metric.fy26_ai_dbu, 0) as fy26_ai_dbu_quantity,
       coalesce(sales_comp_metric.fy26_ai_dollars, 0) as fy26_ai_dollars,
       0 mct_dbu_quantity,
       0 mct_dbu_dollars,
       0 mct_model_hero_run_training_dollars,
       0 mct_model_reserved_training_dollars,
       0 mct_model_on_demand_training_dollars,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_amount,0) as finetuning_dbu_quantity,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_dollars,0) as 
       finetuning_dollars,
       coalesce(sales_comp_metric.agent_evaluation_dbu,0) as agent_evals_dbu_quantity,
       coalesce(sales_comp_metric.agent_evaluation_dollars,0) as agent_evals_dollars,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dbu,0) as agent_evals_synthetic_data_dbu_quantity,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dollars,0) as agent_evals_synthetic_data_dollars,
       coalesce(sales_comp_metric.ai_runtime_dbu,0) as ai_runtime_dbu_quantity,
       coalesce(sales_comp_metric.ai_runtime_dollars,0) as ai_runtime_dollars,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dbu,0) as anthropic_throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dollars,0) as anthropic_throughput_model_serving_dollars,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dbu,0) as anthropic_foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dollars,0) as anthropic_foundation_model_api_dollars,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_amount,0) as model_serving_fmapi_dbu_quantity,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_dollars,0) as model_serving_fmapi_dollars,
       coalesce(sales_comp_metric.lakehouse_monitoring_dbu, 0) as lakehouse_monitoring_dbu,
       coalesce(sales_comp_metric.lakehouse_monitoring_dollars, 0) as lakehouse_monitoring_dollars,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dbu, 0) as fm_mixtral_8_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dbu, 0) as fm_llama2_70b_chat_dbu,
       coalesce(sales_comp_metric.fm_bge_large_en_dbu, 0) as fm_bge_large_en_dbu,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dbu, 0) as fm_mpt_30b_instruct_dbu,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dbu, 0) as fm_mpt_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dbu, 0) as fm_databricks_dbrx_chat_dbu,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dollars, 0) as fm_mixtral_8_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dollars, 0) as fm_llama2_70b_chat_dollars,
       coalesce(sales_comp_metric.fm_bge_large_en_dollars, 0) as fm_bge_large_en_dollars,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dollars, 0) as fm_mpt_30b_instruct_dollars,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dollars, 0) as fm_mpt_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dollars, 0) as fm_databricks_dbrx_chat_dollars,
       usage_dollars dbu_dollars,
       add_on.shield_dollars,
       is_paying isPaying
from {FINANCE_PAID_METERING_USAGE} p
left join {SFDC_WORKSPACE} w 
  on p.sfdc_workspace_id = w.workspaceId__c
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
where platform in ('aws', 'gcp')
  and p.date >= '{SOURCE_SWITCH_DATE}'
order by usage_date desc 
""")

azure_usage_granular_df = spark.sql(f"""
select sfdc_account_id accountID,
       sfdc_account_name accountName,
       coalesce(lower(azure_sub_id), 'noSubscriptionID') SubscriptionID,
       date usage_date,
       lower(sku) usage_sku,
       round(dbu,4) dbu_quantity,
       workspace_sfdc_object_id workspaceSFDCID,
       platform,
       type as product_type,
       NULL as product_features,
       shard_region as deployedRegion,
       sfdc_workspace_id as workspaceId,
       null businessSubscriptionID,
       list_price listPrice,
       dbu_price dbuRevSharePrice,
       discount_price dbuCustPrice,
       round(delta_dbu,4) delta_dbu_quantity,
       coalesce(isv_dbu,0) isv_dbu_quantity,
       coalesce(dbt_dbu,0) dbt_dbu_quantity,
       coalesce(uc_dbu_salescomp, 0) uc_dbu_quantity,
       coalesce(uc_dbu_dollars_salescomp, 0) uc_dbu_dollars,
       coalesce(ml_dbu, 0) ml_dbu_quantity,
       coalesce(fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(streaming_dlt_dbu_salescomp, 0) streaming_dlt_dbu_quantity,
       coalesce(streaming_dlt_dbu_dollars_salescomp, 0) streaming_dlt_dbu_dollars,
       0 cpu_model_serving_dollars,
       0 gpu_model_serving_dbu_quantity,
       0 gpu_model_serving_dollars,
       0 throughput_model_serving_dbu_quantity,
       0 throughput_model_serving_dollars,
       0 foundation_model_api_dbu_quantity,
       0 foundation_model_api_dollars,
       0 foundation_model_training_dollars,
       0 vector_search_dbu_quantity,
       0 vector_search_dollars,
       0 vector_search_ingestion_dollars,
       0 vector_search_serving_dollars,
       0 gen_ai_dbu_quantity,
       0 gen_ai_dbu_dollars,
       0 lakeflow_connect_dbu_quantity,
       0 lakeflow_pipelines_dbu_quantity,
       0 lakeflow_dbu_quantity,
       0 lakeflow_connect_dollars,
       0 lakeflow_pipelines_dollars,
       0 lakeflow_dollars,
       0 batch_inference_model_serving_dbu_quantity,
       0 batch_inference_model_serving_dollars,
       0 agent_framework_dbu_quantity,
       0 agent_framework_dollars,
       0 vector_search_storage_dbu_quantity,
       0 vector_search_storage_dollars,
       0 fy26_ai_dbu_quantity,
       0 fy26_ai_dollars,
       0 mct_dbu_quantity,
       0 mct_dbu_dollars,
       0 mct_model_hero_run_training_dollars,
       0 mct_model_reserved_training_dollars,
       0 mct_model_on_demand_training_dollars,
       0 as finetuning_dbu_quantity,
       0 as finetuning_dollars,
       0 as agent_evals_dbu_quantity,
       0 as agent_evals_dollars,
       0 as agent_evals_synthetic_data_dbu_quantity,
       0 as agent_evals_synthetic_data_dollars,
       0 as ai_runtime_dbu_quantity,
       0 as ai_runtime_dollars,
       0 as anthropic_throughput_model_serving_dbu_quantity,
       0 as anthropic_throughput_model_serving_dollars,
       0 as anthropic_foundation_model_api_dbu_quantity,
       0 as anthropic_foundation_model_api_dollars,
       0 as model_serving_fmapi_dbu_quantity,
       0 as model_serving_fmapi_dollars,
       0 as lakehouse_monitoring_dbu,
       0 as lakehouse_monitoring_dollars,
       0 as fm_mixtral_8_7b_instruct_dbu,
       0 as fm_llama2_70b_chat_dbu,
       0 as fm_bge_large_en_dbu,
       0 as fm_mpt_30b_instruct_dbu,
       0 as fm_mpt_7b_instruct_dbu,
       0 as fm_databricks_dbrx_chat_dbu,
       0 as fm_mixtral_8_7b_instruct_dollars,
       0 as fm_llama2_70b_chat_dollars,
       0 as fm_bge_large_en_dollars,
       0 as fm_mpt_30b_instruct_dollars,
       0 as fm_mpt_7b_instruct_dollars,
       0 as fm_databricks_dbrx_chat_dollars,
       dbu_dollars,
       shield_dollars,
       is_paying isPaying
from {FINANCE_USAGE_STAGE}
where platform = 'azure'
  and date < '{SOURCE_SWITCH_DATE}'

UNION ALL

select sfdc_account_id accountID,
       sfdc_account_name accountName,
       coalesce(lower(azure_sub_id), 'noSubscriptionID') SubscriptionID,
       p.date usage_date,
       lower(sku) usage_sku,
       round(net_usage_amount,4) dbu_quantity,
       w.Id workspaceSFDCID, -- need to join in workspace table
       platform,
       product_type,
       product_features,
       shard_region deployedRegion,
       sfdc_workspace_id as workspaceId,
       business_subscription_id businessSubscriptionID,
       round(list_price, 2) listPrice,
       rev_share_price dbuRevSharePrice,
       discount_price dbuCustPrice,      
       round(workload_insights_metric.delta_dbu,4) delta_dbu_quantity,
       coalesce(workload_insights_metric.isv_dbu,0) isv_dbu_quantity,
       coalesce(workload_insights_metric.dbt_dbu,0) dbt_dbu_quantity,
       coalesce(sales_comp_metric.uc_dbu, 0) uc_dbu_quantity,
       coalesce(sales_comp_metric.uc_dollars, 0) uc_dbu_dollars,
       coalesce(workload_insights_metric.ml_dbu, 0) ml_dbu_quantity,
       coalesce(workload_insights_metric.fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dbu, 0) streaming_dlt_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dollars, 0) streaming_dlt_dbu_dollars,
       coalesce(sales_comp_metric.cpu_model_serving_dollars, 0) cpu_model_serving_dollars,
       coalesce(sales_comp_metric.gpu_model_serving_dbu, 0) gpu_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.gpu_model_serving_dollars, 0) gpu_model_serving_dollars,
       coalesce(sales_comp_metric.throughput_model_serving_dbu, 0) throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.throughput_model_serving_dollars, 0) throughput_model_serving_dollars,
       coalesce(sales_comp_metric.foundation_model_api_dbu, 0) foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.foundation_model_api_dollars, 0) foundation_model_api_dollars,
       coalesce(sales_comp_metric.foundation_model_training_dollars, 0) foundation_model_training_dollars,
       coalesce(sales_comp_metric.vector_search_dbu, 0) vector_search_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_dollars, 0) vector_search_dollars,
       coalesce(sales_comp_metric.vector_search_ingestion_dollars, 0) vector_search_ingestion_dollars,
       coalesce(sales_comp_metric.vector_search_serving_dollars, 0) vector_search_serving_dollars,
       coalesce(sales_comp_metric.gen_ai_dbu, 0) gen_ai_dbu_quantity,
       coalesce(sales_comp_metric.gen_ai_dollars, 0) gen_ai_dbu_dollars,
       coalesce(sales_comp_metric.lakeflow_connect_dbu, 0) lakeflow_connect_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_pipelines_dbu, 0) lakeflow_pipelines_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_dbu, 0) lakeflow_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_connect_dollars, 0) lakeflow_connect_dollars,
       coalesce(sales_comp_metric.lakeflow_pipelines_dollars, 0) lakeflow_pipelines_dollars,
       coalesce(sales_comp_metric.lakeflow_dollars, 0) lakeflow_dollars,
       coalesce(sales_comp_metric.batch_inference_model_serving_dbu, 0) as batch_inference_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.batch_inference_model_serving_dollars, 0) as batch_inference_model_serving_dollars,
       coalesce(sales_comp_metric.agent_framework_dbu, 0) as agent_framework_dbu_quantity,
       coalesce(sales_comp_metric.agent_framework_dollars, 0) as agent_framework_dollars,
       coalesce(sales_comp_metric.vector_search_storage_dbu, 0) as vector_search_storage_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_storage_dollars, 0) as vector_search_storage_dollars,
       coalesce(sales_comp_metric.fy26_ai_dbu, 0) as fy26_ai_dbu_quantity,
       coalesce(sales_comp_metric.fy26_ai_dollars, 0) as fy26_ai_dollars,
       0 mct_dbu_quantity,
       0 mct_dbu_dollars,
       0 mct_model_hero_run_training_dollars,
       0 mct_model_reserved_training_dollars,
       0 mct_model_on_demand_training_dollars,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_amount,0) as finetuning_dbu_quantity,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_dollars,0) as 
       finetuning_dollars,
       coalesce(sales_comp_metric.agent_evaluation_dbu,0) as agent_evals_dbu_quantity,
       coalesce(sales_comp_metric.agent_evaluation_dollars,0) as agent_evals_dollars,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dbu,0) as agent_evals_synthetic_data_dbu_quantity,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dollars,0) as agent_evals_synthetic_data_dollars,
       coalesce(sales_comp_metric.ai_runtime_dbu,0) as ai_runtime_dbu_quantity,
       coalesce(sales_comp_metric.ai_runtime_dollars,0) as ai_runtime_dollars,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dbu,0) as anthropic_throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dollars,0) as anthropic_throughput_model_serving_dollars,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dbu,0) as anthropic_foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dollars,0) as anthropic_foundation_model_api_dollars,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_amount,0) as model_serving_fmapi_dbu_quantity,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_dollars,0) as model_serving_fmapi_dollars,
       coalesce(sales_comp_metric.lakehouse_monitoring_dbu, 0) as lakehouse_monitoring_dbu,
       coalesce(sales_comp_metric.lakehouse_monitoring_dollars, 0) as lakehouse_monitoring_dollars,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dbu, 0) as fm_mixtral_8_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dbu, 0) as fm_llama2_70b_chat_dbu,
       coalesce(sales_comp_metric.fm_bge_large_en_dbu, 0) as fm_bge_large_en_dbu,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dbu, 0) as fm_mpt_30b_instruct_dbu,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dbu, 0) as fm_mpt_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dbu, 0) as fm_databricks_dbrx_chat_dbu,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dollars, 0) as fm_mixtral_8_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dollars, 0) as fm_llama2_70b_chat_dollars,
       coalesce(sales_comp_metric.fm_bge_large_en_dollars, 0) as fm_bge_large_en_dollars,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dollars, 0) as fm_mpt_30b_instruct_dollars,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dollars, 0) as fm_mpt_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dollars, 0) as fm_databricks_dbrx_chat_dollars,
       usage_dollars dbu_dollars,
       add_on.shield_dollars,
       is_paying isPaying
from {FINANCE_PAID_METERING_USAGE} p
left join {SFDC_WORKSPACE} w 
  on p.sfdc_workspace_id = w.workspaceId__c
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
where platform = 'azure'
  and date >= '{SOURCE_SWITCH_DATE}'
order by usage_date desc 
""")

mct_usage_granular_df = spark.sql(f"""
select sfdc_account_id accountID,
       sfdc_account_name accountName,
       p.date usage_date,
       lower(sku) usage_sku,
       round(net_usage_amount, 4) dbu_quantity,
       w.Id workspaceSFDCID, -- need to join in workspace table
       platform,
       product_type,
       product_features,
       shard_region deployedRegion,
       sfdc_workspace_id as workspaceId,
       business_subscription_id businessSubscriptionID,
       round(list_price, 2) listPrice,
       rev_share_price dbuRevSharePrice,
       discount_price dbuCustPrice,      
       round(workload_insights_metric.delta_dbu,4) delta_dbu_quantity,
       coalesce(workload_insights_metric.isv_dbu,0) isv_dbu_quantity,
       coalesce(workload_insights_metric.dbt_dbu,0) dbt_dbu_quantity,
       coalesce(sales_comp_metric.uc_dbu, 0) uc_dbu_quantity,
       coalesce(sales_comp_metric.uc_dollars, 0) uc_dbu_dollars,
       coalesce(workload_insights_metric.ml_dbu, 0) ml_dbu_quantity,
       coalesce(workload_insights_metric.fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dbu, 0) streaming_dlt_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dollars, 0) streaming_dlt_dbu_dollars,
       coalesce(sales_comp_metric.cpu_model_serving_dollars, 0) cpu_model_serving_dollars,
       coalesce(sales_comp_metric.gpu_model_serving_dbu, 0) gpu_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.gpu_model_serving_dollars, 0) gpu_model_serving_dollars,
       coalesce(sales_comp_metric.throughput_model_serving_dbu, 0) throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.throughput_model_serving_dollars, 0) throughput_model_serving_dollars,
       coalesce(sales_comp_metric.foundation_model_api_dbu, 0) foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.foundation_model_api_dollars, 0) foundation_model_api_dollars,
       coalesce(sales_comp_metric.foundation_model_training_dollars, 0) foundation_model_training_dollars,
       coalesce(sales_comp_metric.vector_search_dbu, 0) vector_search_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_dollars, 0) vector_search_dollars,
       coalesce(sales_comp_metric.vector_search_ingestion_dollars, 0) vector_search_ingestion_dollars,
       coalesce(sales_comp_metric.vector_search_serving_dollars, 0) vector_search_serving_dollars,
       coalesce(sales_comp_metric.gen_ai_dbu, 0) gen_ai_dbu_quantity,
       coalesce(sales_comp_metric.gen_ai_dollars, 0) gen_ai_dbu_dollars,
       coalesce(sales_comp_metric.lakeflow_connect_dbu, 0) lakeflow_connect_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_pipelines_dbu, 0) lakeflow_pipelines_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_dbu, 0) lakeflow_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_connect_dollars, 0) lakeflow_connect_dollars,
       coalesce(sales_comp_metric.lakeflow_pipelines_dollars, 0) lakeflow_pipelines_dollars,
       coalesce(sales_comp_metric.lakeflow_dollars, 0) lakeflow_dollars,
       coalesce(sales_comp_metric.batch_inference_model_serving_dbu, 0) as batch_inference_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.batch_inference_model_serving_dollars, 0) as batch_inference_model_serving_dollars,
       coalesce(sales_comp_metric.agent_framework_dbu, 0) as agent_framework_dbu_quantity,
       coalesce(sales_comp_metric.agent_framework_dollars, 0) as agent_framework_dollars,
       coalesce(sales_comp_metric.vector_search_storage_dbu, 0) as vector_search_storage_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_storage_dollars, 0) as vector_search_storage_dollars,
       coalesce(sales_comp_metric.fy26_ai_dbu, 0) as fy26_ai_dbu_quantity,
       coalesce(sales_comp_metric.fy26_ai_dollars, 0) as fy26_ai_dollars,
       coalesce(sales_comp_metric.mct_dbu, 0) mct_dbu_quantity,
       coalesce(sales_comp_metric.mct_dollars) mct_dbu_dollars,
       CASE WHEN mosaic_ml.sub_product_type = 'HERO_RUN' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END  mct_model_hero_run_training_dollars,
       CASE WHEN mosaic_ml.sub_product_type = 'RESERVED_TRAINING' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END mct_model_reserved_training_dollars,
       CASE WHEN mosaic_ml.sub_product_type = 'ON_DEMAND_TRAINING' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END  mct_model_on_demand_training_dollars,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_amount,0) as finetuning_dbu_quantity,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_dollars,0) as 
       finetuning_dollars,
       coalesce(sales_comp_metric.agent_evaluation_dbu,0) as agent_evals_dbu_quantity,
       coalesce(sales_comp_metric.agent_evaluation_dollars,0) as agent_evals_dollars,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dbu,0) as agent_evals_synthetic_data_dbu_quantity,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dollars,0) as agent_evals_synthetic_data_dollars,
       coalesce(sales_comp_metric.ai_runtime_dbu,0) as ai_runtime_dbu_quantity,
       coalesce(sales_comp_metric.ai_runtime_dollars,0) as ai_runtime_dollars,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dbu,0) as anthropic_throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dollars,0) as anthropic_throughput_model_serving_dollars,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dbu,0) as anthropic_foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dollars,0) as anthropic_foundation_model_api_dollars,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_amount,0) as model_serving_fmapi_dbu_quantity,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_dollars,0) as model_serving_fmapi_dollars,
       coalesce(sales_comp_metric.lakehouse_monitoring_dbu, 0) as lakehouse_monitoring_dbu,
       coalesce(sales_comp_metric.lakehouse_monitoring_dollars, 0) as lakehouse_monitoring_dollars,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dbu, 0) as fm_mixtral_8_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dbu, 0) as fm_llama2_70b_chat_dbu,
       coalesce(sales_comp_metric.fm_bge_large_en_dbu, 0) as fm_bge_large_en_dbu,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dbu, 0) as fm_mpt_30b_instruct_dbu,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dbu, 0) as fm_mpt_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dbu, 0) as fm_databricks_dbrx_chat_dbu,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dollars, 0) as fm_mixtral_8_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dollars, 0) as fm_llama2_70b_chat_dollars,
       coalesce(sales_comp_metric.fm_bge_large_en_dollars, 0) as fm_bge_large_en_dollars,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dollars, 0) as fm_mpt_30b_instruct_dollars,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dollars, 0) as fm_mpt_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dollars, 0) as fm_databricks_dbrx_chat_dollars,
       0 dbu_dollars,
       add_on.shield_dollars,
       is_paying isPaying,
       mosaic_ml
from {FINANCE_PAID_METERING_USAGE} p
left join {SFDC_WORKSPACE} w 
  on p.sfdc_workspace_id = w.workspaceId__c
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
where platform = 'mct'
  and p.date >= '{SOURCE_SWITCH_DATE}'
order by usage_date desc 
""")

# COMMAND ----------

print(aws_usage_granular_df.count())
print(aws_usage_granular_df.dropDuplicates().count())

# COMMAND ----------

print(azure_usage_granular_df.count())
print(azure_usage_granular_df.filter(azure_usage_granular_df.accountID.isNotNull()).count())

# COMMAND ----------

print(mct_usage_granular_df.count())
print(mct_usage_granular_df.dropDuplicates().count())

# COMMAND ----------

aws_usage_granular_df.createOrReplaceTempView("aws_usage_granular")

# COMMAND ----------

# DBTITLE 1,AWS Order-Build up
aws_orders_granular_query = f"""
with initial_usage_orders (
select ug.*,
       agg.aggOrder,
       agg.SubscriptionID,
       agg.scope,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit,
       case when count(usage_date) over(partition by accountID, accountName, workspaceSFDCID, businessSubscriptionID, usage_date, usage_sku, product_type, dbu_quantity, product_features) > 1 then 'true'
            else 'false'
       end as usageFlag,
       case when scope = 'shared'  then 'false'
            else 'true'
       end as scopeFlag
from aws_usage_granular ug
join {BI_AGGORDERS} agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
                         and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where ug.platform in ('aws', 'gcp')
order by usage_date
)
select *
from initial_usage_orders
where (usageFlag='true' and scopeFlag='true') or (usageFlag='false' and scopeFlag='false')
"""

aws_orders_granular_df = spark.sql(aws_orders_granular_query)
dropColumns = ["usageFlag", "scopeFlag"]
aws_orders_granular_df = aws_orders_granular_df.drop(*dropColumns)

# COMMAND ----------

aws_orders_granular_df.count()

# COMMAND ----------

mct_usage_granular_df.createOrReplaceTempView("mct_usage_granular")

# COMMAND ----------

mct_orders_granular_query = f"""
with initial_usage_orders (
select ug.*,
       agg.aggOrder,
       agg.SubscriptionID,
       agg.scope,
       agg.startDate,
       agg.endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit,
       case when count(usage_date) over(partition by accountID, accountName, workspaceSFDCID, businessSubscriptionID, usage_date, usage_sku, product_type, dbu_quantity, mosaic_ml, product_features) > 1 then 'true'
            else 'false'
       end as usageFlag,
       case when scope = 'shared'  then 'false'
            else 'true'
       end as scopeFlag
from mct_usage_granular ug
join (
  select null usageBurstDate,
        concat("MTMMCT",coalesce(sfdc_account_id, 'noSFDCAccountID'))  AggOrder,
        coalesce(sfdc_account_id, 'noSFDCAccountID') sfdcAccountID,
        coalesce(sfdc_account_name, 'noSFDCAccountName') sfdcAccountName, 
        'mct' Platform,
        'shared' Scope,
        'MTMSubscriptionID' SubscriptionID, 
        min(date) startDate,
        date_add(min(date), (365*25)) endDate,
        0 cloudPartnerPurchase,
        0 ActualPartnerCommit,
        0 DBShareCommit,
        cast(0 as double) dbuCustPriceDiscount,
        concat("MTM",coalesce(sfdc_account_id, 'noSFDCAccountID')) orderId
  from {FINANCE_PAID_METERING_USAGE}
  where platform = 'mct'
  group by sfdc_account_id, sfdc_account_name
) agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
                         and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
where ug.platform in ('mct')
order by usage_date
)
select *
from initial_usage_orders
where (usageFlag='true' and scopeFlag='true') or (usageFlag='false' and scopeFlag='false')
"""

mct_orders_granular_df = spark.sql(mct_orders_granular_query)
dropColumns = ["usageFlag", "scopeFlag"]
mct_orders_granular_df = mct_orders_granular_df.drop(*dropColumns)

# COMMAND ----------

# MAGIC %md
# MAGIC AWS:
# MAGIC For an account-platform, get min(usage_date) and then, lookup for a contract for the date, until the end of the contract. 
# MAGIC                 exception: for the parallel contracts, use workspaceId to separate the contracts
# MAGIC                 In all other cases, it should be tagged as MTM/PAYG.
# MAGIC                 
# MAGIC Azure:
# MAGIC For an account-platform, get min(usage_date), 1. look for Single scoped order for the workspace and tag it if it exists                                                                  2. If not, then, look for Shared scoped subscription and tag if it doesnt exceed Quantity(MDS)
# MAGIC                                       in all other cases, it should be tagged as MTM/PAYG

# COMMAND ----------

# DBTITLE 1,Azure orders buildup
agg_azure_orders_df = spark.sql(f"""select SubscriptionID aggSubscriptionID, platform aggPlatform, sfdcAccountID, aggOrder, scope, startDate,  
                                          coalesce(usageBurstDate, endDate) endDate, cloudPartnerPurchase, ActualPartnerCommit,DBShareCommit
                                   from {BI_AGGORDERS}
                                   where platform = 'azure'
                               """)
azure_usage_orders_df = azure_usage_granular_df.join(agg_azure_orders_df, (azure_usage_granular_df.accountID == agg_azure_orders_df.sfdcAccountID)\
                                                                  & (azure_usage_granular_df.platform == agg_azure_orders_df.aggPlatform)\
                                                                  & (azure_usage_granular_df.SubscriptionID == agg_azure_orders_df.aggSubscriptionID)\
                                                                  & ((azure_usage_granular_df.usage_date >= agg_azure_orders_df.startDate)\
                                                                     & (azure_usage_granular_df.usage_date <= agg_azure_orders_df.endDate)),\
                                                                  'left')

# COMMAND ----------

azure_usage_orders_df.count()

# COMMAND ----------

#display(azure_usage_granular_df.filter((azure_usage_granular_df.accountID=='0014N00001g7s1AQAQ') & (azure_usage_granular_df.usage_date >= "2020-01-16")).orderBy("usage_date"))

# COMMAND ----------

#display(agg_azure_orders_df.filter(agg_azure_orders_df.sfdcAccountID=='0014N00001g8CvNQAU'))

# COMMAND ----------

#display(azure_usage_orders_df.filter((azure_usage_orders_df.accountID=='0014N00001g7s1AQAQ') & (azure_usage_orders_df.usage_date >= "2020-01-16")).orderBy("usage_date"))

# COMMAND ----------

azure_single_orders_df = azure_usage_orders_df.filter((azure_usage_orders_df.aggSubscriptionID.isNotNull()))

# COMMAND ----------

azure_single_orders_df.count()

# COMMAND ----------

dropColumns = ["aggSubscriptionID", "aggPlatform", "sfdcAccountID", "aggOrder", "scope", "startDate", "endDate", 
               "cloudPartnerPurchase", "ActualPartnerCommit", "DBShareCommit"]
azure_only_shared_orders_df = azure_usage_orders_df.filter(azure_usage_orders_df.aggSubscriptionID.isNull())\
                                              .drop(*dropColumns)
azure_only_shared_orders_df.createOrReplaceTempView("azure_shared_usage")

# COMMAND ----------

# %sql
# select ug.*,
#        agg.aggOrder,
#        agg.scope,
#        agg.startDate,
#        agg.endDate,
#        agg.cloudPartnerPurchase,
#        agg.ActualPartnerCommit,
#        agg.DBShareCommit
# from azure_shared_usage ug
# join bdw.bi_aggorders agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
#                          and ug.usage_date >= agg.startDate and ug.usage_date <= agg.endDate
# where agg.scope != 'Single'
# and agg.sfdcAccountID = '0014N00001g7s1AQAQ'
# and ug.usage_date = '2020-01-18'
# order by usage_date, dbu_quantity

# COMMAND ----------

# %sql
# with initial_usage_orders (
# select ug.*,
#        agg.aggOrder,
#        agg.scope,
#        agg.startDate,
#        coalesce(agg.usageBurstDate, agg.endDate) endDate,
#        agg.cloudPartnerPurchase,
#        agg.ActualPartnerCommit,
#        agg.DBShareCommit,
#        case when count(usage_date) over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, dbu_quantity) > 1 then 'true'
#             else 'false'
#        end as usageFlag,
#        case when scope = 'shared'  then 'false'
#             else 'true'
#        end as scopeFlag
# from azure_shared_usage ug
# join bdw.bi_aggorders agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
#                          and ug.usage_date >= agg.startDate and ug.usage_date <= coalesce(agg.usageBurstDate, agg.endDate)
# where agg.scope != 'Single'
# and agg.sfdcAccountID = '0014N00001g7s1AQAQ'
# and ug.usage_date = '2020-03-31'
# order by usage_date, dbu_quantity
# )

# select *,
#        row_number() over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, dbu_quantity, scope order by startDate desc) rank_order
# from initial_usage_orders
# where (usageFlag='true' and scopeFlag='true') or 
#       (usageFlag='false' and scopeFlag='false')


# COMMAND ----------

"""
-- partition: if there is same usage for more than once for the same date, then it must be both PAYG/MTM, Shared-Commit
--            in which case, put a usageFlag 'true' indicating there is 'Shared-commit', else it's just 'PAYG/MTM'

-- Rank them if same usage is tagged to 'Shared-Commit' by startDate, and then take earliest Shared-Order
-- todo: Make sure Quantity(MDS) takes precedence and transition to next Shared-Commit, if earlier Shared-Order burned down completely
"""

clean_azure_shared_orders_df = spark.sql(f"""
with initial_usage_orders (
select ug.*,
       agg.aggOrder,
       agg.scope,
       agg.startDate,
       coalesce(usageBurstDate, endDate) endDate,
       agg.cloudPartnerPurchase,
       agg.ActualPartnerCommit,
       agg.DBShareCommit,
       case when count(usage_date) over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, product_type, product_features, dbu_quantity, dbuRevSharePrice) > 1 then 'true'
            else 'false'
       end as usageFlag,
       case when scope = 'shared'  then 'false'
            else 'true'
       end as scopeFlag
from azure_shared_usage ug
join {BI_AGGORDERS} agg on ug.accountID = agg.sfdcAccountID and ug.platform = agg.platform 
                         and ug.usage_date >= agg.startDate and ug.usage_date <= coalesce(agg.usageBurstDate, agg.endDate)
where agg.scope != 'Single'
order by usage_date
),

ranked_usage_orders (
select *,
       row_number() over(partition by accountID, accountName, workspaceSFDCID, usage_date, usage_sku, product_type, product_features, dbu_quantity, scope order by startDate) rank_order
from initial_usage_orders
where (usageFlag='true' and scopeFlag='true') or (usageFlag='false' and scopeFlag='false')
)

select *
from ranked_usage_orders
where rank_order = 1
""")

# COMMAND ----------

clean_azure_shared_orders_df.count()

# COMMAND ----------

singleOrderDropColumns = ["aggSubscriptionID", "aggPlatform", "sfdcAccountID"]
azure_single_df = azure_single_orders_df.drop(*singleOrderDropColumns)

sharedOrderDropColumns = ["usageFlag", "scopeFlag", "rank_order"]
azure_shared_df = clean_azure_shared_orders_df.drop(*sharedOrderDropColumns)

# COMMAND ----------

azure_combined_orders_df = azure_shared_df.union(azure_single_df)

# COMMAND ----------

azure_combined_orders_df.createOrReplaceTempView("azure_combined_orders")
clean_azure_usage_df = spark.sql("""
with ranked_orders(
select *,
       row_number() over(partition by accountID, accountName, workspaceSFDCID, businessSubscriptionID, usage_date, usage_sku, product_type, product_features, dbu_quantity, scope order by startDate) rno
from azure_combined_orders
)
select *
from ranked_orders
where rno = 1
""")
clean_azure_usage_df = clean_azure_usage_df.drop(clean_azure_usage_df.rno)

# COMMAND ----------

clean_azure_usage_df.count() 

# COMMAND ----------

clean_azure_usage_df.createOrReplaceTempView('clean_azure_usage')

# COMMAND ----------

clean_azure_usage_ranked_df = spark.sql("""
with clean_azure_usage_ranked (
select row_number() over(partition by accountID, platform, workspaceId, businessSubscriptionID, usage_date, usage_sku, product_type, product_features, dbu_quantity order by aggOrder) rno,
       *
from clean_azure_usage
)
select *
from clean_azure_usage_ranked
where rno = 1
""")

clean_azure_usage_df = clean_azure_usage_ranked_df.drop(clean_azure_usage_ranked_df.rno)

# COMMAND ----------

clean_azure_usage_df.count()

# COMMAND ----------

aws_orders_granular_df.createOrReplaceTempView("aws_usage_orders")

clean_aws_usage_df = spark.sql("""
with ranked_orders(
select *,
       row_number() over(partition by accountID, accountName, workspaceSFDCID, businessSubscriptionID, usage_date, usage_sku,
       product_type, product_features, dbu_quantity, dbuRevSharePrice, scope order by startDate) rno
from aws_usage_orders
)
select *
from ranked_orders
where rno = 1
""")
clean_aws_usage_df = clean_aws_usage_df.drop(clean_aws_usage_df.rno)

# COMMAND ----------

mct_orders_granular_df.createOrReplaceTempView("mct_usage_orders")

clean_mct_usage_df = spark.sql("""
with ranked_orders(
select *,
       row_number() over(partition by accountID, accountName, workspaceSFDCID, businessSubscriptionID, usage_date, usage_sku, product_type, product_features, dbu_quantity, dbuRevSharePrice, scope, mosaic_ml order by startDate) rno
from mct_usage_orders
)
select *
from ranked_orders
where rno = 1
""")
dropColumns = ["mosaic_ml"]
clean_mct_usage_df = clean_mct_usage_df.drop(*dropColumns)
clean_mct_usage_df = clean_mct_usage_df.drop(clean_mct_usage_df.rno)

# COMMAND ----------

clean_aws_usage_df = clean_aws_usage_df.select(*sorted(clean_aws_usage_df.columns))
clean_mct_usage_df = clean_mct_usage_df.select(*sorted(clean_mct_usage_df.columns))
clean_azure_usage_df = clean_azure_usage_df.select(*sorted(clean_azure_usage_df.columns))
order_usage_granular_df = clean_azure_usage_df.union(clean_aws_usage_df)
order_usage_granular_df = order_usage_granular_df.union(clean_mct_usage_df)
print(order_usage_granular_df.count())

# COMMAND ----------

@udf('string')
def unmappedAggOrder(platform, accountId):
  
  if platform == 'azure':
    aggorder = 'MTMAzure' + accountId
  elif platform == 'aws':
    aggorder = 'MTMAWS' + accountId
  elif platform == 'mct':
    aggorder = 'MTMMCT' + accountId
  else:
    aggorder = 'MTMGCP' + accountId
    
  return aggorder

@udf('string')
def unmappedAccount(region):
  
  if region == 'APJ':
    accountId = '0013f0000063xxQAAQ'
  elif region == 'EMEA':
    accountId = '0013f0000063xxLAAQ'
  else:
    accountId = '0013f000005RwT9AAK'
  
  return accountId

unmapped_finance_usage = spark.sql(f"""
select sfdc_account_id accountId,
       'Unmapped Workspace' accountName, 
       date usage_date,
       lower(sku) usage_sku,
       round(dbu,4) dbu_quantity,
       workspace_sfdc_object_id workspaceSFDCID,
       f.sfdc_workspace_id workspaceId,
       ps.Name businessSubscriptionID,
       f.platform,
       type as product_type,
       NULL as product_features,
       list_price listPrice,
       dbu_price dbuRevSharePrice,
       discount_price dbuCustPrice,
       round(delta_dbu,4) delta_dbu_quantity,
       coalesce(isv_dbu,0) isv_dbu_quantity,
       coalesce(dbt_dbu,0) dbt_dbu_quantity,
       coalesce(uc_dbu_salescomp, 0) uc_dbu_quantity,
       coalesce(uc_dbu_dollars_salescomp, 0) uc_dbu_dollars,
       coalesce(ml_dbu, 0) ml_dbu_quantity,
       coalesce(fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(streaming_dlt_dbu_salescomp, 0) streaming_dlt_dbu_quantity,
       coalesce(streaming_dlt_dbu_dollars_salescomp, 0) streaming_dlt_dbu_dollars,
       0 cpu_model_serving_dollars,
       0 gpu_model_serving_dbu_quantity,
       0 gpu_model_serving_dollars,
       0 throughput_model_serving_dbu_quantity,
       0 throughput_model_serving_dollars,
       0 foundation_model_api_dbu_quantity,
       0 foundation_model_api_dollars,
       0 foundation_model_training_dollars,
       0 vector_search_dbu_quantity,
       0 vector_search_dollars,
       0 vector_search_ingestion_dollars,
       0 vector_search_serving_dollars,
       0 gen_ai_dbu_quantity,
       0 gen_ai_dbu_dollars,
       0 lakeflow_connect_dbu_quantity,
       0 lakeflow_pipelines_dbu_quantity,
       0 lakeflow_dbu_quantity,
       0 lakeflow_connect_dollars,
       0 lakeflow_pipelines_dollars,
       0 lakeflow_dollars,
       0 batch_inference_model_serving_dbu_quantity,
       0 batch_inference_model_serving_dollars,
       0 agent_framework_dbu_quantity,
       0 agent_framework_dollars,
       0 vector_search_storage_dbu_quantity,
       0 vector_search_storage_dollars,
       0 fy26_ai_dbu_quantity,
       0 fy26_ai_dollars,
       0 mct_dbu_quantity,
       0 mct_dbu_dollars,
       0 mct_model_hero_run_training_dollars,
       0 mct_model_reserved_training_dollars,
       0 mct_model_on_demand_training_dollars,
       0 as finetuning_dbu_quantity,
       0 as finetuning_dollars,
       0 as agent_evals_dbu_quantity,
       0 as agent_evals_dollars,
       0 as agent_evals_synthetic_data_dbu_quantity,
       0 as agent_evals_synthetic_data_dollars,
       0 as ai_runtime_dbu_quantity,
       0 as ai_runtime_dollars,
       0 as anthropic_throughput_model_serving_dbu_quantity,
       0 as anthropic_throughput_model_serving_dollars,
       0 as anthropic_foundation_model_api_dbu_quantity,
       0 as anthropic_foundation_model_api_dollars,
       0 as model_serving_fmapi_dbu_quantity,
       0 as model_serving_fmapi_dollars,
       0 as lakehouse_monitoring_dbu,
       0 as lakehouse_monitoring_dollars,
       0 as fm_mixtral_8_7b_instruct_dbu,
       0 as fm_llama2_70b_chat_dbu,
       0 as fm_bge_large_en_dbu,
       0 as fm_mpt_30b_instruct_dbu,
       0 as fm_mpt_7b_instruct_dbu,
       0 as fm_databricks_dbrx_chat_dbu,
       0 as fm_mixtral_8_7b_instruct_dollars,
       0 as fm_llama2_70b_chat_dollars,
       0 as fm_bge_large_en_dollars,
       0 as fm_mpt_30b_instruct_dollars,
       0 as fm_mpt_7b_instruct_dollars,
       0 as fm_databricks_dbrx_chat_dollars,
       dbu_dollars,
       shield_dollars,
       is_paying isPaying,
       'MTMSubscriptionID' SubscriptionID,
       'shared' scope,
       cast('2018-01-01' as date) startDate,
       cast('2024-12-31' as date) endDate,
       cast(0 as double) cloudPartnerPurchase,
       cast(0 as double) ActualPartnerCommit,
       cast(0 as double) DBShareCommit
from {FINANCE_USAGE_STAGE} f 
left join {SFDC_WORKSPACE} w 
  on f.workspace_sfdc_object_id = w.id
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
left join {SFDC_PLATFORM_SUBSCRIPTION} ps
  on w.Business_Subscription__c = ps.id
  and ps.processDate = (
    select max(processDate)
    from {SFDC_PLATFORM_SUBSCRIPTION}
  )
where f.sfdc_account_id is null
and f.platform in ('aws', 'azure', 'gcp','mct')
and f.date < '{SOURCE_SWITCH_DATE}'

UNION ALL

select sfdc_account_id accountId,
       'Unmapped Workspace' accountName, 
       date usage_date,
       lower(sku) usage_sku,
       round(net_usage_amount,4) dbu_quantity,
       w.Id workspaceSFDCID, -- need to join in workspace table
       p.sfdc_workspace_id workspaceId,
       business_subscription_id businessSubscriptionID, 
       p.platform,
       product_type,
       product_features,
       round(list_price, 2) listPrice,
       rev_share_price dbuRevSharePrice,
       discount_price dbuCustPrice,
       round(workload_insights_metric.delta_dbu,4) delta_dbu_quantity,
       coalesce(workload_insights_metric.isv_dbu,0) isv_dbu_quantity,
       coalesce(workload_insights_metric.dbt_dbu,0) dbt_dbu_quantity,
       coalesce(sales_comp_metric.uc_dbu, 0) uc_dbu_quantity,
       coalesce(sales_comp_metric.uc_dollars, 0) uc_dbu_dollars,
       coalesce(workload_insights_metric.ml_dbu, 0) ml_dbu_quantity,
       coalesce(workload_insights_metric.fivetran_dbu,0) fivetran_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dbu, 0) streaming_dlt_dbu_quantity,
       coalesce(sales_comp_metric.streaming_dollars, 0) streaming_dlt_dbu_dollars,
       coalesce(sales_comp_metric.cpu_model_serving_dollars, 0) cpu_model_serving_dollars,
       coalesce(sales_comp_metric.gpu_model_serving_dbu, 0) gpu_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.gpu_model_serving_dollars, 0) gpu_model_serving_dollars,
       coalesce(sales_comp_metric.throughput_model_serving_dbu, 0) throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.throughput_model_serving_dollars, 0) throughput_model_serving_dollars,
       coalesce(sales_comp_metric.foundation_model_api_dbu, 0) foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.foundation_model_api_dollars, 0) foundation_model_api_dollars,
       coalesce(sales_comp_metric.foundation_model_training_dollars, 0) foundation_model_training_dollars,
       coalesce(sales_comp_metric.vector_search_dbu, 0) vector_search_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_dollars, 0) vector_search_dollars,
       coalesce(sales_comp_metric.vector_search_ingestion_dollars, 0) vector_search_ingestion_dollars,
       coalesce(sales_comp_metric.vector_search_serving_dollars, 0) vector_search_serving_dollars,
       coalesce(sales_comp_metric.gen_ai_dbu, 0) gen_ai_dbu_quantity,
       coalesce(sales_comp_metric.gen_ai_dollars, 0) gen_ai_dbu_dollars,
       coalesce(sales_comp_metric.lakeflow_connect_dbu, 0) lakeflow_connect_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_pipelines_dbu, 0) lakeflow_pipelines_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_dbu, 0) lakeflow_dbu_quantity,
       coalesce(sales_comp_metric.lakeflow_connect_dollars, 0) lakeflow_connect_dollars,
       coalesce(sales_comp_metric.lakeflow_pipelines_dollars, 0) lakeflow_pipelines_dollars,
       coalesce(sales_comp_metric.lakeflow_dollars, 0) lakeflow_dollars,
       coalesce(sales_comp_metric.batch_inference_model_serving_dbu, 0) as batch_inference_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.batch_inference_model_serving_dollars, 0) as batch_inference_model_serving_dollars,
       coalesce(sales_comp_metric.agent_framework_dbu, 0) as agent_framework_dbu_quantity,
       coalesce(sales_comp_metric.agent_framework_dollars, 0) as agent_framework_dollars,
       coalesce(sales_comp_metric.vector_search_storage_dbu, 0) as vector_search_storage_dbu_quantity,
       coalesce(sales_comp_metric.vector_search_storage_dollars, 0) as vector_search_storage_dollars,
       coalesce(sales_comp_metric.fy26_ai_dbu, 0) as fy26_ai_dbu_quantity,
       coalesce(sales_comp_metric.fy26_ai_dollars, 0) as fy26_ai_dollars,
       coalesce(sales_comp_metric.mct_dbu, 0) mct_dbu_quantity,
       coalesce(sales_comp_metric.mct_dollars) mct_dbu_dollars,
       CASE WHEN mosaic_ml.sub_product_type = 'HERO_RUN' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END  mct_model_hero_run_training_dollars,
       CASE WHEN mosaic_ml.sub_product_type = 'RESERVED_TRAINING' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END mct_model_reserved_training_dollars,
       CASE WHEN mosaic_ml.sub_product_type = 'ON_DEMAND_TRAINING' THEN coalesce(sales_comp_metric.mct_dollars) ELSE 0 END  mct_model_on_demand_training_dollars,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_amount,0) as finetuning_dbu_quantity,
       IF(product_type="FOUNDATION_MODEL_TRAINING",usage_dollars,0) as 
       finetuning_dollars,
       coalesce(sales_comp_metric.agent_evaluation_dbu,0) as agent_evals_dbu_quantity,
       coalesce(sales_comp_metric.agent_evaluation_dollars,0) as agent_evals_dollars,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dbu,0) as agent_evals_synthetic_data_dbu_quantity,
       coalesce(sales_comp_metric.agent_eval_synthetic_data_gen_dollars,0) as agent_evals_synthetic_data_dollars,
       coalesce(sales_comp_metric.ai_runtime_dbu,0) as ai_runtime_dbu_quantity,
       coalesce(sales_comp_metric.ai_runtime_dollars,0) as ai_runtime_dollars,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dbu,0) as anthropic_throughput_model_serving_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_throughput_model_serving_dollars,0) as anthropic_throughput_model_serving_dollars,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dbu,0) as anthropic_foundation_model_api_dbu_quantity,
       coalesce(sales_comp_metric.anthropic_foundation_model_api_dollars,0) as anthropic_foundation_model_api_dollars,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_amount,0) as model_serving_fmapi_dbu_quantity,
       IF(product_type="MODEL_SERVING" and product_features.serving_type = "FOUNDATION_MODEL",usage_dollars,0) as model_serving_fmapi_dollars,
       coalesce(sales_comp_metric.lakehouse_monitoring_dbu, 0) as lakehouse_monitoring_dbu,
       coalesce(sales_comp_metric.lakehouse_monitoring_dollars, 0) as lakehouse_monitoring_dollars,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dbu, 0) as fm_mixtral_8_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dbu, 0) as fm_llama2_70b_chat_dbu,
       coalesce(sales_comp_metric.fm_bge_large_en_dbu, 0) as fm_bge_large_en_dbu,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dbu, 0) as fm_mpt_30b_instruct_dbu,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dbu, 0) as fm_mpt_7b_instruct_dbu,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dbu, 0) as fm_databricks_dbrx_chat_dbu,
       coalesce(sales_comp_metric.fm_mixtral_8_7b_instruct_dollars, 0) as fm_mixtral_8_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_llama2_70b_chat_dollars, 0) as fm_llama2_70b_chat_dollars,
       coalesce(sales_comp_metric.fm_bge_large_en_dollars, 0) as fm_bge_large_en_dollars,
       coalesce(sales_comp_metric.fm_mpt_30b_instruct_dollars, 0) as fm_mpt_30b_instruct_dollars,
       coalesce(sales_comp_metric.fm_mpt_7b_instruct_dollars, 0) as fm_mpt_7b_instruct_dollars,
       coalesce(sales_comp_metric.fm_databricks_dbrx_chat_dollars, 0) as fm_databricks_dbrx_chat_dollars,
       usage_dollars dbu_dollars,
       add_on.shield_dollars,
       is_paying isPaying,
       'MTMSubscriptionID' SubscriptionID,
       'shared' scope,
       cast('2018-01-01' as date) startDate,
       cast('2024-12-31' as date) endDate,
       cast(0 as double) cloudPartnerPurchase,
       cast(0 as double) ActualPartnerCommit,
       cast(0 as double) DBShareCommit
from {FINANCE_PAID_METERING_USAGE} p
left join {SFDC_WORKSPACE} w 
  on p.sfdc_workspace_id = w.workspaceId__c
  and w.processDate = (
    select max(processDate)
    from {SFDC_WORKSPACE}
  )
where sfdc_account_id is null
and platform in ('aws', 'azure', 'gcp','mct')
and p.date >= '{SOURCE_SWITCH_DATE}'

""")

current_wksp_snap = spark.sql(f"""
select wk.workspaceId__c,
       wk.deployedRegion__c deployedRegion
from {SFDC_WORKSPACE} wk
where processDate = (select max(processDate) from {SFDC_WORKSPACE})
""")

region_dim = spark.sql(f"select deployedRegion, region from {DIM_REGION}")

unmapped_usage = unmapped_finance_usage.join(current_wksp_snap, unmapped_finance_usage.workspaceId == current_wksp_snap.workspaceId__c, 'left')\
                                       .drop(current_wksp_snap.workspaceId__c)

unmapped_usage = unmapped_usage.join(region_dim, unmapped_usage.deployedRegion == region_dim.deployedRegion, 'left')\
                                   .drop(region_dim.deployedRegion)

unmapped_usage = unmapped_usage.withColumn("accountId", unmappedAccount("region"))\
                               .withColumn("aggOrder", unmappedAggOrder("platform", "accountId"))\
                               .drop("region")\
                               .withColumnRenamed("accountId", "accountID")

unmapped_usage = unmapped_usage.select(*sorted(unmapped_usage.columns))
order_usage_granular_df = order_usage_granular_df.union(unmapped_usage)
print(order_usage_granular_df.count())

# COMMAND ----------

order_usage_granular_df = order_usage_granular_df.drop("product_type")
order_usage_granular_df = order_usage_granular_df.drop("product_features")

# COMMAND ----------

print("Writing in {} environment location : {}".format(environment, USAGE_PROD_DAILY_GRANULAR_LOCATION))
order_usage_granular_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(USAGE_PROD_DAILY_GRANULAR_LOCATION)

# COMMAND ----------

def consumption_validation(finance_usage, finance_paid_usage_metering, finance_pvc_usage, finance_pubsec_usage, usage_table, bi_dates, dbu_dollars_col):
  spark.sql(f"""
  create or replace temporary view finance_consumption
  as 
  with pubSec (
  select fiscal_year fiscalYear, fiscal_qtr fiscalQtr, 
        round(sum(dbu_dollars),0) pubsecQtrFinance
  from {finance_pubsec_usage}
  where fiscal_year >= 'FY19'
  group by 1,2
  order by 1,2
  ), 

  pvc (
  select fiscal_year fiscalYear, fiscal_qtr fiscalQtr, 
        round(sum(dbu_dollars),0) pvcQtrFinance
  from {finance_pvc_usage}
  where fiscal_year >= 'FY19'
  group by 1,2
  order by 1,2
  ),

  allPVC(
  select case when p.fiscalYear='FY21' then 2021
              when p.fiscalYear='FY22' then 2022
              when p.fiscalYear='FY23' then 2023
              when p.fiscalYear='FY24' then 2024
              when p.fiscalYear='FY25' then 2025
              when p.fiscalYear='FY20' then 2020
              when p.fiscalYear='FY19' then 2019            
        end as fiscalYear,
        case when p.fiscalQtr='Q1' then 1
              when p.fiscalQtr='Q2' then 2
              when p.fiscalQtr='Q3' then 3
              else 4
        end as fiscalQtr,
        (pubsecQtrFinance + pvcQtrFinance) privateQtrFinance
  from pubSec pu
  join pvc p on pu.fiscalYear = p.fiscalYear and pu.fiscalQtr = p.fiscalQtr
  order by 1,2
  ),

  SAS (
  select dt.fiscalYear,
        dt.fiscalQuarter,
        sum(qtrFinance) qtrFinance
  from (
      select dt.fiscalYear, 
            dt.fiscalQuarter, 
            round(sum(dbu_dollars),2) qtrFinance
      from {finance_usage} f
      join {bi_dates} dt on f.date = dt.date
      where dt.date between '2018-02-01' and '2020-12-31'
      group by 1,2

      UNION ALL

      select dt.fiscalYear, 
            dt.fiscalQuarter, 
            round(sum(usage_dollars),2) - round(sum(sales_comp_metric.mct_dollars),2) qtrFinance
      from {finance_paid_usage_metering} f
      join {bi_dates} dt on f.date = dt.date
      where dt.date >= '2021-01-01'
      group by 1,2
      order by 1,2
      ) dt
  group by 1,2
  )

  select s.fiscalYear,
        s.fiscalQuarter,
        qtrFinance
  from SAS s
  """)


  spark.sql(f"""
  create or replace temporary view validate_consumption
  as
  with sfdc (
  select
    dt.fiscalYear,
    dt.fiscalQuarter,
    sum({dbu_dollars_col}) qtrSFDC
  from
    {usage_table} c
    join {bi_dates} dt 
    on c.usage_date = dt.date
  group by
    dt.fiscalYear,
    dt.fiscalQuarter
  order by
    dt.fiscalYear,
    dt.fiscalQuarter
  )


  select s.fiscalYear,
        s.fiscalQuarter,
        s.qtrSFDC,
        f.qtrFinance,
        (qtrSFDC - qtrFinance) diff,
        ((qtrSFDC - qtrFinance)/qtrFinance) * 100 diff_percentage
        
  from sfdc s
  join finance_consumption f on s.fiscalYear = f.fiscalYear and s.fiscalQuarter = f.fiscalQuarter
  order by s.fiscalYear, s.fiscalQuarter
  """)

  validate_consumption = spark.sql("""

    select *
    from validate_consumption 
    where abs(diff_percentage) > 2

  """)
  
  return validate_consumption

# COMMAND ----------

validate_consumption = consumption_validation(FINANCE_USAGE_STAGE, FINANCE_PAID_METERING_USAGE, FINANCE_PVC_USAGE, FINANCE_PUBSEC_USAGE, f"delta.`{USAGE_PROD_DAILY_GRANULAR_LOCATION}`", BI_DATES, "dbu_dollars")

# COMMAND ----------

error = 0
if validate_consumption.count() > 0 :
  error = 1
  display(validate_consumption)
else:
  print(" validation check passed ")

# COMMAND ----------

if error == 1:
  raise Exception(" validation check failed ")

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))
