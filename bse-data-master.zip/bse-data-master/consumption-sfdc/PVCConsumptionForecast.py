# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

@udf("double")
def interactive_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'interactive' else 0

@udf("double")
def automated_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType == 'automated' else 0

@udf("double")
def sql_dbus(dbu_quantity, skuType):
  return dbu_quantity if skuType in ('SQL', 'virtual') else 0

@udf("double")
def sql_dollars(dbu_quantity, skuType, dbuRevSharePrice):
  return (dbu_quantity * dbuRevSharePrice) if skuType in ('SQL', 'virtual') else 0.0

@udf("boolean")
def isBurst(cumListDollars, listCommit, endDate, usage_date, cumDBDollars, RevShareCommit, platform):
  if platform == "azure":
      return (cumListDollars > listCommit + 0.999) or (usage_date > endDate)
    
  return (cumDBDollars > RevShareCommit + 0.999) or (usage_date > endDate)

@udf("double")
def pctBurn(platform, aggOrder, ListCommit, RevShareCommit, cumListDollars, cumRevShareDollars, cumListForecastDollars, cumRevShareForecastDollars):
  pctBurn = 0.0
  if not 'MTM' in aggOrder:
    if platform == 'azure':
      return 0 if ListCommit==0 else ((cumListDollars + cumListForecastDollars) / ListCommit) * 100
    if platform == 'aws':
      return 0 if RevShareCommit==0 else ((cumRevShareDollars + cumRevShareForecastDollars) / RevShareCommit) * 100
  return pctBurn

@udf("string")
def consumptionType(aggOrder):
  return "MTM" if "MTM" in aggOrder else "Commit"
  
@udf("string")
def forecastType(subscriptionId, contract_type):
  forecastType = 'MTM'
  if subscriptionId == 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = "SharedCommit"
  if subscriptionId != 'Azure-Shared-Subscription' and contract_type != 'PAYG - Forecast':
    forecastType = 'SingleCommit'
  
  return forecastType

@udf("string")
def consumptionTypeForecast(aggOrder):
  consumptionTypeForecast = "MTM"
  if "Shared" in aggOrder:
    consumptionTypeForecast = "SharedCommit"
  if "Single" in aggOrder:
    consumptionTypeForecast = aggOrder
  if "AWS" in aggOrder:
    consumptionTypeForecast = "Commit"    
    
  
  return consumptionTypeForecast

# COMMAND ----------

# pvc_orders = spark.read.format("delta").load("/mnt/bse-dev/bi_aggorders_pvc")
# display(pvc_orders.orderBy("sfdcAccountID", "startDate"))

# COMMAND ----------

dates_df = spark.sql(f"select * from {BI_DATES}")
# usagec_agg_order_daily - load from location directly
dropCumColumns = ["accountName","cumListDollars", "cumCustDollars", "cumRevShareDollars", "cumInteractiveDBUs", 
                  "cumAutomatedDBUs", "cumDeltaRevShareDollars", "cumDeltaInteractiveDBUs", "cumDeltaAutomatedDBUs",
                  "cumSQLAnalyticsDBUs", "cumSQLRevShareDollars"]
# aggOrderDaily = spark.read.format("delta").load("/mnt/bse-dev/backup_agg_order_daily")
# aggOrderDaily = spark.read.format("delta").load("/mnt/bse-dev/aws_usagec_agg_order_daily")

aggOrderDaily = spark.read.format("delta").load(USAGE_AGG_ORDER_DAILY_ADHOC_PVC_LOCATION)
aggOrderDaily = aggOrderDaily.drop(*dropCumColumns)

account_dim = spark.sql(f"select distinct AccountID, AccountName from {ACCOUNT_DIM}")

# COMMAND ----------

allMaxUsageDates = aggOrderDaily.groupBy("accountId", "platform")\
                                .agg(max("usage_date").alias("maxUsageDate"))

#allMaxUsageDates.write.format("delta").mode("append").save("/mnt/bse-dev/usagec_maxdates")

# COMMAND ----------

aggOrderDaily.count()

# COMMAND ----------

# shared:  for Shared take the max usage date for each account , if the maxUsageDate < current_date(), then exclude it
# single:  for Single, take max usage date for each account, if there maxUsageDate < then, exclude it and if there are more than one such orders, then keep all of them
# MTM: Generate blanket consumptionType dollars 

date_df = spark.sql(f"select date from {BI_DATES} where date > date_sub(current_date(), 365) and date < date_add(current_date(), 365)")
maxUsageDateAggOrder = aggOrderDaily.filter(aggOrderDaily.consumptionType != 'MTM')\
                                    .groupBy("accountId", "platform", "aggOrder")\
                                    .agg(max("usage_date").alias("maxUsageDate"))

maxDates = date_df.join(maxUsageDateAggOrder, date_df.date == maxUsageDateAggOrder.maxUsageDate)

# COMMAND ----------

aggOrderDaily = aggOrderDaily.withColumn("listForecastDollars", lit(0))\
                             .withColumn("custForecastDollars", lit(0))\
                             .withColumn("revShareForecastDollars", lit(0))\
                             .withColumn("InteractiveForecastDBUs", lit(0))\
                             .withColumn("AutomatedForecastDBUs", lit(0))\
                             .withColumn("SQLAnalyticsForecastDBUs", lit(0))\
                             .withColumn("SQLRevShareForecastDollars", lit(0))

# COMMAND ----------

pvc_orders = spark.read.format("delta").load(BI_AGGORDERS_PVC_LOCATION)
pvc_orders.createOrReplaceTempView("pvc_orders")

aggOrders_df = spark.sql("""
select aggOrder,
       sfdcAccountId,
       startDate,
       endDate,
       cloudPartnerPurchase ListCommit,
       ActualPartnerCommit DiscountedCommit,
       DBShareCommit RevShareCommit
from pvc_orders
""")

aggOrderDailyExtended = aggOrderDaily.join(aggOrders_df.select("aggOrder", "startDate", "endDate"), aggOrderDaily.aggOrder==aggOrders_df.aggOrder)\
                                     .drop(aggOrders_df.aggOrder)
aggOrderDailyExtended.count()

# COMMAND ----------

maxDates = maxDates.withColumn("consumptionTypeForecast", consumptionTypeForecast("aggOrder"))\
                   .withColumnRenamed("date", "usage_date")

# COMMAND ----------

aggOrderWindow = Window.partitionBy("accountId", "consumptionTypeForecast", "platform")\
                       .orderBy(col("usage_date").desc())
maxDatesPruned = maxDates.withColumn("rno", row_number().over(aggOrderWindow))\
                         .filter(col("rno")==1)\
                         .drop("rno", "maxUsageDate")

maxDatesPrunedExtended = maxDatesPruned.join(aggOrders_df, (maxDatesPruned.accountId==aggOrders_df.sfdcAccountId) & (maxDatesPruned.aggOrder==aggOrders_df.aggOrder))\
                                       .drop(aggOrders_df.sfdcAccountId)\
                                       .drop(aggOrders_df.aggOrder)\
                                       .drop(maxDatesPruned.consumptionTypeForecast)

maxDatesPrunedExtended.createOrReplaceTempView("maxUsageDateAggOrder")
display(maxDatesPrunedExtended.orderBy("accountId", "aggOrder"))

# COMMAND ----------

aggOrderDaily = aggOrderDaily.drop("consumptionType")
aggOrderDailyExtended = aggOrderDailyExtended.drop("consumptionType")

# COMMAND ----------

forecastCommitDaily = spark.sql(f"""
select f.accountId,
       f.platform,
       m.aggOrder,
       f.date usage_date,
       m.ListCommit,
       m.DiscountedCommit,
       m.RevShareCommit,       
       0 listDollars,
       0 custDollars,
       0 revShareDollars,
       0 InteractiveDBUs,
       0 AutomatedDBUs, 
       0 DeltaRevShareDollars,
       0 DeltaInteractiveDBUs,
       0 DeltaAutomatedDBUs, 
       0 DeltaSQLDBUs,
       0 SQLAnalyticsDBUs,
       0 SQLRevShareDollars,  
       0 StandardDBUs,
       0 PremiumDBUs,       
       0 EnterpriseDBUs,       
       0 StandardRevShareDollars,
       0 PremiumRevShareDollars,       
       0 EnterpriseRevShareDollars, 
       0 MoonCakeDBUs,
       0 MoonCakeDeltaDBUs,
       0 MoonCakeDBUDollars,
       0 MoonCakeDeltaDBUDollars, 
       0 ISVDBUs,
       0 ISVRevShareDollars,
       0 DBTDBUs,
       0 DBTRevShareDollars,
       0 FivetranDBUs,
       0 FivetranRevShareDollars,
       0 ServerlessDBUs,
       0 ServerlessRevShareDollars,
       0 PhotonDBUs,
       0 PhotonRevShareDollars,
       0 DLTDBUs,
       0 DLTRevShareDollars,
       0 MoonCakeSQLDBUs,
       0 MoonCakeSQLDollars,
       0 StreamingDLTDBUs,
       0 StreamingDLTRevShareDollars,
       0 UCDBUs,
       0 UCRevShareDollars,
       0 MLDBUs,
       0 MLRevShareDollars,
       0 GenAIDBUs,
       0 GenAIRevShareDollars,
       0 CPUModelServingRevShareDollars,
       0 GPUModelServingDBUs,
       0 GPUModelServingRevShareDollars,
       0 ThroughputModelServingDBUs,
       0 ThroughputModelServingRevShareDollars,
       0 FoundationModelAPIDBUs,
       0 FoundationModelAPIRevShareDollars,
       0 FoundationModelTrainingRevShareDollars,
       0 VectorSearchDBUs,
       0 VectorSearchRevShareDollars,
       0 VectorSearchIngestionRevShareDollars,
       0 VectorSearchServingRevShareDollars,
       0 LakeflowConnectDBUs,
       0 LakeflowPipelinesDBUs,
       0 LakeflowDBUs,
       0 LakeflowConnectRevShareDollars,
       0 LakeflowPipelinesRevShareDollars,
       0 LakeflowRevShareDollars,
       0 BatchInferenceModelServingDBUs,
       0 BatchInferenceModelServingRevShareDollars,
       0 AgentFrameworkDBUs,
       0 AgentFrameworkRevShareDollars,
       0 VectorSearchStorageDBUs,
       0 VectorSearchStorageRevShareDollars,
       0 FY26AIDBUs,
       0 FY26AIDollars,
       0 MCTDBUs,
       0 MCTRevShareDollars,
       0 MCTModelHeroRunTrainingRevShareDollars,
       0 MCTModelReservedTrainingRevShareDollars,
       0 MCTModelOnDemandTrainingRevShareDollars,
       0 StreamingDLTRevShareDollars_calculated,
       0 UCRevShareDollars_calculated,      
       0 FinetuningDBUs,
       0 FinetuningRevShareDollars,
       0 AgentEvalsDBUs,
       0 AgentEvalsRevShareDollars,
       0 AgentEvalsSyntheticDataDBUs,
       0 AgentEvalsSyntheticDataRevShareDollars,
       0 AIRuntimeDBUs,
       0 AIRuntimeRevShareDollars,
       0 AnthropicThroughputModelServingDBUs,
       0 AnthropicThroughputModelServingRevShareDollars,
       0 AnthropicFoundationModelAPIDBUs,
       0 AnthropicFoundationModelAPIRevShareDollars,
       0 ModelServingFMAPIDBUs,
       0 ModelServingFMAPIRevShareDollars,
       0 LakehouseMonitoringDBUs,
       0 LakehouseMonitoringRevShareDollars,
       0 FmMixtral87bInstructDBUs,
       0 FmLlama270bChatDBUs,
       0 FmBgeLargeENDBUs,
       0 FmMpt30bInstructDBUs,
       0 FmMpt7bInstructDBUs,
       0 FmDatabricksDbrxChatDBUs,
       0 FmMixtral87bInstructRevShareDollars,
       0 FmLlama270bChatRevShareDollars,
       0 FmBgeLargeENRevShareDollars,
       0 FmMpt30bInstructRevShareDollars,
       0 FmMpt7bInstructRevShareDollars,
       0 FmDatabricksDbrxChatRevShareDollars,
       round(f.interactive_dbus + f.automated_dbus + f.sql_dbus, 0) DBUs, 
       0 DeltaDBUs,      
       round(f.DBUListSpend,2) listForecastDollars,
       round(f.DBUCustSpend,2) custForecastDollars,
       round(f.DBURevShareSpend, 2) revShareForecastDollars,
       round(f.interactive_dbus, 2) InteractiveForecastDBUs,
       round(f.automated_dbus, 2) AutomatedForecastDBUs,  
       round(f.sql_dbus, 2) SQLAnalyticsForecastDBUs,
       0 SQLRevShareForecastDollars,        
       m.startDate,
       m.endDate
from {ACCOUNT_USAGE_AND_FORECAST} f
join maxUsageDateAggOrder m on f.accountId = m.accountId and f.platform = m.platform and lower(f.orderId) = lower(m.aggOrder)
where date > m.usage_date 
order by f.accountId, f.platform, m.aggOrder, f.date
""")


forecastMTMDaily = spark.sql(f"""
with MTMOrders (
select aggOrder,
       platform,
       sfdcAccountId,
       sfdcAccountName,
       startDate,
       endDate
from pvc_orders
where aggOrder like 'MTM%'
)
select f.accountId,
       f.platform,
       m.aggOrder,
       f.date usage_date,
       0 ListCommit,
       0 DiscountedCommit,
       0 RevShareCommit,       
       0 listDollars,
       0 custDollars,
       0 revShareDollars,
       0 InteractiveDBUs,
       0 AutomatedDBUs, 
       0 DeltaRevShareDollars,
       0 DeltaInteractiveDBUs,
       0 DeltaAutomatedDBUs, 
       0 DeltaSQLDBUs,
       0 SQLAnalyticsDBUs,
       0 SQLRevShareDollars,
       0 StandardDBUs,
       0 PremiumDBUs,       
       0 EnterpriseDBUs,       
       0 StandardRevShareDollars,
       0 PremiumRevShareDollars,       
       0 EnterpriseRevShareDollars,   
       0 MoonCakeDBUs,
       0 MoonCakeDeltaDBUs,
       0 MoonCakeDBUDollars,
       0 MoonCakeDeltaDBUDollars, 
       0 ISVDBUs,
       0 ISVRevShareDollars,
       0 DBTDBUs,
       0 DBTRevShareDollars,
       0 FivetranDBUs,
       0 FivetranRevShareDollars, 
       0 ServerlessDBUs,
       0 ServerlessRevShareDollars,
       0 PhotonDBUs,
       0 PhotonRevShareDollars,
       0 DLTDBUs,
       0 DLTRevShareDollars,
       0 MoonCakeSQLDBUs,
       0 MoonCakeSQLDollars,
       0 StreamingDLTDBUs,
       0 StreamingDLTRevShareDollars,
       0 UCDBUs,
       0 UCRevShareDollars,
       0 MLDBUs,
       0 MLRevShareDollars,
       0 GenAIDBUs,
       0 GenAIRevShareDollars,
       0 CPUModelServingRevShareDollars,
       0 GPUModelServingDBUs,
       0 GPUModelServingRevShareDollars,
       0 ThroughputModelServingDBUs,
       0 ThroughputModelServingRevShareDollars,
       0 FoundationModelAPIDBUs,
       0 FoundationModelAPIRevShareDollars,
       0 FoundationModelTrainingRevShareDollars,
       0 VectorSearchDBUs,
       0 VectorSearchRevShareDollars,
       0 VectorSearchIngestionRevShareDollars,
       0 VectorSearchServingRevShareDollars,
       0 LakeflowConnectDBUs,
       0 LakeflowPipelinesDBUs,
       0 LakeflowDBUs,
       0 LakeflowConnectRevShareDollars,
       0 LakeflowPipelinesRevShareDollars,
       0 LakeflowRevShareDollars,
       0 BatchInferenceModelServingDBUs,
       0 BatchInferenceModelServingRevShareDollars,
       0 AgentFrameworkDBUs,
       0 AgentFrameworkRevShareDollars,
       0 VectorSearchStorageDBUs,
       0 VectorSearchStorageRevShareDollars,
       0 FY26AIDBUs,
       0 FY26AIDollars,
       0 MCTDBUs,
       0 MCTRevShareDollars,
       0 MCTModelHeroRunTrainingRevShareDollars,
       0 MCTModelReservedTrainingRevShareDollars,
       0 MCTModelOnDemandTrainingRevShareDollars,
       0 StreamingDLTRevShareDollars_calculated,
       0 UCRevShareDollars_calculated,    
       0 FinetuningDBUs,
       0 FinetuningRevShareDollars,
       0 AgentEvalsDBUs,
       0 AgentEvalsRevShareDollars,
       0 AgentEvalsSyntheticDataDBUs,
       0 AgentEvalsSyntheticDataRevShareDollars,
       0 AIRuntimeDBUs,
       0 AIRuntimeRevShareDollars,
       0 AnthropicThroughputModelServingDBUs,
       0 AnthropicThroughputModelServingRevShareDollars,
       0 AnthropicFoundationModelAPIDBUs,
       0 AnthropicFoundationModelAPIRevShareDollars,
       0 ModelServingFMAPIDBUs,
       0 ModelServingFMAPIRevShareDollars,
       0 LakehouseMonitoringDBUs,
       0 LakehouseMonitoringRevShareDollars,
       0 FmMixtral87bInstructDBUs,
       0 FmLlama270bChatDBUs,
       0 FmBgeLargeENDBUs,
       0 FmMpt30bInstructDBUs,
       0 FmMpt7bInstructDBUs,
       0 FmDatabricksDbrxChatDBUs,
       0 FmMixtral87bInstructRevShareDollars,
       0 FmLlama270bChatRevShareDollars,
       0 FmBgeLargeENRevShareDollars,
       0 FmMpt30bInstructRevShareDollars,
       0 FmMpt7bInstructRevShareDollars,
       0 FmDatabricksDbrxChatRevShareDollars,
       round(f.interactive_dbus + f.automated_dbus + f.sql_dbus, 0) DBUs,  
       0 DeltaDBUs,     
       round(f.DBUListSpend,2) listForecastDollars,
       round(f.DBUCustSpend,2) custForecastDollars,
       round(f.DBURevShareSpend, 2) revShareForecastDollars,
       round(f.interactive_dbus, 2) InteractiveForecastDBUs,
       round(f.automated_dbus, 2) AutomatedForecastDBUs, 
       round(f.sql_dbus, 2) SQLAnalyticsForecastDBUs,
       0 SQLRevShareForecastDollars,        
       m.startDate,
       m.endDate
from {ACCOUNT_USAGE_AND_FORECAST} f
join MTMOrders m on f.accountId = m.sfdcAccountId and f.platform = m.platform and lower(f.orderId) = lower(m.aggOrder)
where date > current_date()
order by f.accountId, f.platform, m.aggOrder, f.date
""")

# COMMAND ----------

missingForecastDaily = spark.sql(f"""

with pvc_accounts (
select distinct sfdcAccountId
from pvc_orders
),

pvc_forecast_orders (
select distinct f.orderId pvcFcstOrder, f.accountId
from {ACCOUNT_USAGE_AND_FORECAST} f 
join pvc_accounts pvc on f.accountId = pvc.sfdcAccountId
where f.date > current_date()
and f.orderId not like 'MTM%'
),

missingPvcOrders (
select pvcFcstOrder, 
       pvc.accountId, 
       agg.startDate, 
       agg.endDate, 
       coalesce(agg.cloudPartnerPurchase, 0) ListCommit,
       coalesce(agg.ActualPartnerCommit,0) DiscountedCommit,
       coalesce(agg.DBShareCommit, 0) RevShareCommit,
       agg.Platform platform
from pvc_forecast_orders pvc
left join maxUsageDateAggOrder m on lower(pvc.pvcFcstOrder) = lower(m.aggOrder)
left join {BI_AGGORDERS} agg on lower(pvc.pvcFcstOrder) = lower(agg.aggOrder)
where m.aggOrder is null
)

select f.accountId,
       f.platform,
       m.pvcFcstOrder aggOrder,
       f.date usage_date,
       m.ListCommit,
       m.DiscountedCommit,
       m.RevShareCommit,       
       0 listDollars,
       0 custDollars,
       0 revShareDollars,
       0 InteractiveDBUs,
       0 AutomatedDBUs, 
       0 DeltaRevShareDollars,
       0 DeltaInteractiveDBUs,
       0 DeltaAutomatedDBUs, 
       0 DeltaSQLDBUs,
       0 SQLAnalyticsDBUs,
       0 SQLRevShareDollars,
       0 StandardDBUs,
       0 PremiumDBUs,       
       0 EnterpriseDBUs,       
       0 StandardRevShareDollars,
       0 PremiumRevShareDollars,       
       0 EnterpriseRevShareDollars,  
       0 MoonCakeDBUs,
       0 MoonCakeDeltaDBUs,
       0 MoonCakeDBUDollars,
       0 MoonCakeDeltaDBUDollars,  
       0 ISVDBUs,
       0 ISVRevShareDollars,
       0 DBTDBUs,
       0 DBTRevShareDollars,
       0 FivetranDBUs,
       0 FivetranRevShareDollars,   
       0 ServerlessDBUs,
       0 ServerlessRevShareDollars,
       0 PhotonDBUs,
       0 PhotonRevShareDollars,
       0 DLTDBUs,
       0 DLTRevShareDollars,
       0 MoonCakeSQLDBUs,
       0 MoonCakeSQLDollars,
       0 StreamingDLTDBUs,
       0 StreamingDLTRevShareDollars,
       0 UCDBUs,
       0 UCRevShareDollars,
       0 MLDBUs,
       0 MLRevShareDollars,
       0 GenAIDBUs,
       0 GenAIRevShareDollars,
       0 CPUModelServingRevShareDollars,
       0 GPUModelServingDBUs,
       0 GPUModelServingRevShareDollars,
       0 ThroughputModelServingDBUs,
       0 ThroughputModelServingRevShareDollars,
       0 FoundationModelAPIDBUs,
       0 FoundationModelAPIRevShareDollars,
       0 FoundationModelTrainingRevShareDollars,
       0 VectorSearchDBUs,
       0 VectorSearchRevShareDollars,
       0 VectorSearchIngestionRevShareDollars,
       0 VectorSearchServingRevShareDollars,
       0 LakeflowConnectDBUs,
       0 LakeflowPipelinesDBUs,
       0 LakeflowDBUs,
       0 LakeflowConnectRevShareDollars,
       0 LakeflowPipelinesRevShareDollars,
       0 LakeflowRevShareDollars,
       0 BatchInferenceModelServingDBUs,
       0 BatchInferenceModelServingRevShareDollars,
       0 AgentFrameworkDBUs,
       0 AgentFrameworkRevShareDollars,
       0 VectorSearchStorageDBUs,
       0 VectorSearchStorageRevShareDollars,
       0 FY26AIDBUs,
       0 FY26AIDollars,
       0 MCTDBUs,
       0 MCTRevShareDollars,
       0 MCTModelHeroRunTrainingRevShareDollars,
       0 MCTModelReservedTrainingRevShareDollars,
       0 MCTModelOnDemandTrainingRevShareDollars,
       0 StreamingDLTRevShareDollars_calculated,
       0 UCRevShareDollars_calculated,    
       0 FinetuningDBUs,
       0 FinetuningRevShareDollars,
       0 AgentEvalsDBUs,
       0 AgentEvalsRevShareDollars,
       0 AgentEvalsSyntheticDataDBUs,
       0 AgentEvalsSyntheticDataRevShareDollars,
       0 AIRuntimeDBUs,
       0 AIRuntimeRevShareDollars,
       0 AnthropicThroughputModelServingDBUs,
       0 AnthropicThroughputModelServingRevShareDollars,
       0 AnthropicFoundationModelAPIDBUs,
       0 AnthropicFoundationModelAPIRevShareDollars,
       0 ModelServingFMAPIDBUs,
       0 ModelServingFMAPIRevShareDollars,
       0 LakehouseMonitoringDBUs,
       0 LakehouseMonitoringRevShareDollars,
       0 FmMixtral87bInstructDBUs,
       0 FmLlama270bChatDBUs,
       0 FmBgeLargeENDBUs,
       0 FmMpt30bInstructDBUs,
       0 FmMpt7bInstructDBUs,
       0 FmDatabricksDbrxChatDBUs,
       0 FmMixtral87bInstructRevShareDollars,
       0 FmLlama270bChatRevShareDollars,
       0 FmBgeLargeENRevShareDollars,
       0 FmMpt30bInstructRevShareDollars,
       0 FmMpt7bInstructRevShareDollars,
       0 FmDatabricksDbrxChatRevShareDollars,
       round(f.interactive_dbus + f.automated_dbus + f.sql_dbus, 0) DBUs,  
       0 DeltaDBUs,     
       round(f.DBUListSpend,2) listForecastDollars,
       round(f.DBUCustSpend,2) custForecastDollars,
       round(f.DBURevShareSpend, 2) revShareForecastDollars,
       round(f.interactive_dbus, 2) InteractiveForecastDBUs,
       round(f.automated_dbus, 2) AutomatedForecastDBUs,  
       0 SQLAnalyticsForecastDBUs,
       0 SQLRevShareForecastDollars,       
       m.startDate,
       m.endDate
from {ACCOUNT_USAGE_AND_FORECAST} f
join missingPvcOrders m on f.accountId = m.accountId and lower(f.orderId) = lower(m.pvcFcstOrder)
where f.date > '2021-03-31' 
order by f.accountId, f.platform, m.pvcFcstOrder, f.date
""")

missingForecastDaily.count()

# COMMAND ----------

forecastDaily = forecastCommitDaily.union(forecastMTMDaily) 
forecastDaily = missingForecastDaily.union(forecastDaily)
forecastDaily.count()

# COMMAND ----------

aggOrderDailyExtended = aggOrderDailyExtended.select(*sorted(aggOrderDailyExtended.columns))
forecastDaily = forecastDaily.select(*sorted(forecastDaily.columns))
aggOrderConsumpCast = aggOrderDailyExtended.union(forecastDaily)

# add month_end_date to Daily
aggOrderConsumpCastDaily = aggOrderConsumpCast.join(dates_df.select("date", "month_end_date"), aggOrderConsumpCast.usage_date==dates_df.date)\
                                         .drop(dates_df.date)
aggOrderConsumpCastDaily = aggOrderConsumpCastDaily.orderBy("accountId", "platform", "aggOrder", "usage_date")

# COMMAND ----------

orderByColumns = ["accountID", "platform", "aggOrder", "usage_date"]
partitionByColumns = ["accountID", "platform", "aggOrder"]
usage_window = Window.partitionBy(*partitionByColumns)\
                     .orderBy("usage_date")\
                     .rowsBetween(Window.unboundedPreceding, Window.currentRow)


aggOrderConsumpCastDailyCum  =   aggOrderConsumpCastDaily.withColumn("cumListDollars", round(sum("listDollars").over(usage_window),2))\
                                                         .withColumn("cumCustDollars", round(sum("custDollars").over(usage_window),2))\
                                                         .withColumn("cumRevShareDollars", round(sum("revShareDollars").over(usage_window),2))\
                                                         .withColumn("cumInteractiveDBUs", round(sum("InteractiveDBUs").over(usage_window),2))\
                                                         .withColumn("cumAutomatedDBUs", round(sum("AutomatedDBUs").over(usage_window),2))\
                                                         .withColumn("cumListForecastDollars", round(sum("listForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumCustForecastDollars", round(sum("custForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumRevShareForecastDollars", round(sum("revShareForecastDollars").over(usage_window),2))\
                                                         .withColumn("cumInteractiveForecastDBUs", round(sum("InteractiveForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumAutomatedForecastDBUs", round(sum("AutomatedForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumDeltaRevShareDollars", round(sum("DeltaRevShareDollars").over(usage_window),2))\
                                                         .withColumn("cumDeltaInteractiveDBUs", round(sum("DeltaInteractiveDBUs").over(usage_window),2))\
                                                         .withColumn("cumDeltaAutomatedDBUs", round(sum("DeltaAutomatedDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLAnalyticsDBUs", round(sum("SQLAnalyticsDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLRevShareDollars", round(sum("SQLRevShareDollars").over(usage_window),2))\
                                                         .withColumn("cumSQLAnalyticsForecastDBUs", round(sum("SQLAnalyticsForecastDBUs").over(usage_window),2))\
                                                         .withColumn("cumSQLRevShareForecastDollars", round(sum("SQLRevShareForecastDollars").over(usage_window),2))

# COMMAND ----------

aggOrderConsumpCastDailyCum = aggOrderConsumpCastDailyCum.withColumn("consumptionType", consumptionType("aggOrder"))\
                                                         .drop("month_end_date")

# COMMAND ----------

aggOrderConsumpCastDailyCum = aggOrderConsumpCastDailyCum.orderBy(*orderByColumns)

# COMMAND ----------

pctBurnColumns = ["platform", "aggOrder", "ListCommit", "RevShareCommit", "cumListDollars", "cumRevShareDollars", "cumListForecastDollars", "cumRevShareForecastDollars"]
aggOrderConsumpCastDailyCumMetrics = aggOrderConsumpCastDailyCum.withColumn("pctBurn", round(pctBurn(*pctBurnColumns),2))

# COMMAND ----------

aggOrderConsumpCastDailyCumMetricsJoin = aggOrderConsumpCastDailyCumMetrics.join(account_dim, aggOrderConsumpCastDailyCumMetrics.accountId == account_dim.AccountID)\
                                               .drop(account_dim.AccountID)

aggOrderConsumpCastDailyCumMetricsJoin = aggOrderConsumpCastDailyCumMetricsJoin.withColumnRenamed("AccountName", "accountName")

# COMMAND ----------

aggOrderConsumpCastDailyCumMetricsJoin.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save(USAGEC_AGGORDER_DAILY_PVC_LOCATION)

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))
