# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------




@udf("double")
def totalDollars(platform, cumListDollars, cumRevShareDollars, cumListForecastDollars, cumRevShareForecastDollars):
  totalDollars = 0.0
  if platform == "aws" or platform == "gcp":
    totalDollars =  cumRevShareDollars + cumRevShareForecastDollars
  
  if platform == "azure":
    totalDollars = cumListDollars + cumListForecastDollars
  
  return totalDollars

@udf("boolean")
def usageBurst(platform, ListCommit, RevShareCommit, totalDollars):
  
  usageBurstFlag = False
  if platform == "aws" or platform == "gcp":
    usageBurstFlag = totalDollars > RevShareCommit
  if platform == "azure":
    if ListCommit !=0:
      if ListCommit > totalDollars:
        pctUsage = 1-((ListCommit-totalDollars)/ListCommit)
      else:
        pctUsage = 1+((totalDollars-ListCommit)/ListCommit)

      if pctUsage > 0.9925:
        usageBurstFlag = True
    #usageBurstFlag = (1-((ListCommit-totalDollars)/ListCommit) > 0.9925) #totalDollars > ListCommit
    
  return usageBurstFlag

@udf("date")
def actualBurstDate(burstDate, currentDate):
  if burstDate is not None:
      return burstDate if burstDate < currentDate else None
  return burstDate
@udf("date")
def expectedBurstDate(burstDate, currentDate):
  if burstDate is not None:  
      return burstDate if burstDate >= currentDate else None
  return burstDate

# COMMAND ----------

aggorder_daily = spark.read.format("delta").load(USAGE_AGGORDER_DAILY_GOLD_ADHOC_LOCATION)
aggorder_daily.createOrReplaceTempView("usagec_aggorder_daily")
burst_df = spark.sql("select * from usagec_aggorder_daily where aggOrder not like 'MTM%'")
totalDollarsCols = ["platform", "cumListDollars", "cumRevShareDollars", "cumListForecastDollars", "cumRevShareForecastDollars"]
usageBurstCols = ["platform", "ListCommit", "RevShareCommit", "totalDollars"]
burst_df = burst_df.withColumn("totalDollars", totalDollars(*totalDollarsCols))\
                   .withColumn("totalDollars", round(col("totalDollars"), 2))\
                   .withColumn("usageBurst", usageBurst(*usageBurstCols))

print(burst_df.count())

# COMMAND ----------

burstDates = burst_df.filter(burst_df.usageBurst==True)\
                     .groupBy("aggOrder", "usageBurst")\
                     .agg(min("usage_date").alias("burstDate"))
burstDates = burstDates.withColumnRenamed("aggOrder", "burstAggOrder")\
                       .drop("usageBurst")

dailyConsumption = spark.sql("select * from usagec_aggorder_daily")
print(dailyConsumption.count())

# COMMAND ----------

dailyBurst = dailyConsumption.join(burstDates, dailyConsumption.aggOrder==burstDates.burstAggOrder, 'left')\
                   .drop(burstDates.burstAggOrder)

dailyBurst = dailyBurst.orderBy("accountId", "platform", "aggOrder", "usage_date")

# COMMAND ----------

from datetime import datetime
currentDate = datetime.today().date()
print(currentDate)
dailyBurstAdd = dailyBurst.withColumn("currentDate", lit(currentDate))\
                          .withColumn("actualBurstDate", actualBurstDate("burstDate", "currentDate"))\
                          .withColumn("expectedBurstDate", expectedBurstDate("burstDate", "currentDate"))\
                          .withColumn("expectedBurstDate", coalesce("expectedBurstDate", "actualBurstDate"))\
                          .drop("burstDate", "currentDate")
dailyBurstAdd.count()

# COMMAND ----------

dailyBurstAdd.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_AGGORDER_DAILY)

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))
