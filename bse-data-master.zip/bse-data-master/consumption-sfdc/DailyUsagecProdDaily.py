# Databricks notebook source
# MAGIC %run "./ConsumptionConfig"

# COMMAND ----------

import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from pprint import pprint

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'development':
  locals().update(config["development"])
  pprint(config["development"])
  #create_uc_schema(CATALOG, CORE_SCHEMA) 
elif environment == 'test':
  locals().update(config["test"])
  pprint(config["test"])
else:
  locals().update(config["production"])
  pprint(config["production"])

# COMMAND ----------

daily_df = spark.read \
                .format("delta") \
                .load(USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION) \
                .dropDuplicates() \
                .drop('dbu_dollars','shield_dollars')

# COMMAND ----------

sap_daily_df = spark.sql(f"""select * from {USAGEC_SAP_PROD_DAILY}""")

# COMMAND ----------

pvc_daily_df = spark.read.format("delta").load(USAGEC_PROD_DAILY_PVC_LOCATION)

# COMMAND ----------

# zero-out any negative dbus
pvc_daily_df = pvc_daily_df.withColumn(
    "dbu_quantity",
    expr(" CASE WHEN dbu_quantity < 0 THEN 0.0 ELSE dbu_quantity END AS dbu_quantity")
)

pvc_daily_df = pvc_daily_df.withColumnRenamed('StreamingDLTDBUs', 'streaming_dlt_dbu_quantity')

# COMMAND ----------

pvc_daily_df.count()

# COMMAND ----------

daily_df     = daily_df.select(*sorted(daily_df.columns))
pvc_daily_df = pvc_daily_df.select(*sorted(pvc_daily_df.columns))
sap_daily_df = sap_daily_df.select(*sorted(sap_daily_df.columns))



# COMMAND ----------

daily_combined = daily_df.union(pvc_daily_df).union(sap_daily_df)

# COMMAND ----------

daily_combined = daily_combined.withColumn("dbuRevSharePrice", coalesce(col("dbuRevSharePrice"), lit(0)))

# COMMAND ----------

daily_combined.count()

# COMMAND ----------

daily_combined.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(USAGEC_PROD_DAILY)

# COMMAND ----------


