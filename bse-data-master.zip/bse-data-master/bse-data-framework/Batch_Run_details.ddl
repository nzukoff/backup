CREATE TABLE spark_catalog.bdw.batch_run_details (
  Data_Source_Name STRING,
  Job_Name STRING,
  Executed_By_User STRING,
  Table_Name STRING,
  Batch_ID INT,
  Load_Type STRING,
  Dlt_From_TS TIMESTAMP,
  Dlt_To_TS TIMESTAMP,
  Status STRING,
  Affected_Rows INT,
  Batch_Start_TS TIMESTAMP,
  Batch_End_TS TIMESTAMP,
  Remarks STRING)
USING delta
PARTITIONED BY (Data_Source_Name);