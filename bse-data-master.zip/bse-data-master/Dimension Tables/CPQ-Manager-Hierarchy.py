# Databricks notebook source
# MAGIC %run ../consumption-sfdc/Salesforce-HelperFunctions

# COMMAND ----------

spark.conf.set('spark.databricks.delta.checkLatestSchemaOnRead', False)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql import functions as sqlf
from pyspark.sql import Window

# COMMAND ----------

# MAGIC %md
# MAGIC #### set up

# COMMAND ----------

sfdc_account_table = 'main.sfdc_bronze.account'
sfdc_user_table = 'main.sfdc_bronze.user'
user_role_hierarchy_table = 'main.it_core_dim.user_role_hierarchy'
cpq_manager_hierarchy_table_staging = 'main.it_core_dim.cpq_manager_hierarchy_staging'
cpq_manager_hierarchy_table = 'main.it_core_dim.cpq_manager_hierarchy'

# COMMAND ----------

# user_role_hierarchy = spark.read.format("delta").load("/mnt/bse-dev/userrolehierarchy")
# # user_role_hierarchy = user_role_hierarchy.drop("level8RoleName", "level8RoleId")/
# #                                          .withColumnRenamed("level0RoleName")
# user_role_hierarchy.createOrReplaceTempView("user_role_hierarchy")

# COMMAND ----------

spark.sql(f"""
select distinct
       u.Name as AEName,
       u.UserRoleId AEUserRoleId,
       a.OwnerId as AEOwnerId
from {sfdc_account_table} a 
left join {sfdc_user_table} u on u.Id = a.OwnerId and a.processDate = u.processDate
where a.processDate = (select max(processDate) from {sfdc_user_table})
""").createOrReplaceTempView("account_ae_dim")

spark.sql(f"""
select usr.Id,
       usr.userroleid,
       usr.name,
       usr.title,
       usr.email,
       usr.department
from {sfdc_user_table} usr
where processDate = (select max(processDate) from {sfdc_user_table})
and isActive = 'true'
and lower(usr.name) not like '%logfood%'
and usr.Email like '%databricks.com'
--and lower(usr.name) not like 'tbh%'
""").createOrReplaceTempView("users")

spark.sql("""
select AEName,
       AEOwnerId,
       AEUserRoleId
from account_ae_dim
""").createOrReplaceTempView("AEUserRoles")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SELECT ae.*
# MAGIC -- from AEUserRoles ae 
# MAGIC -- left join bdw_dev.manager_hierarchy h 
# MAGIC -- on ae.aeownerid = h.aeid
# MAGIC -- where h.aeid is null

# COMMAND ----------

# %sql
# with 

# firstLevelManagers (
# select ae.*,
#        urh.ParentRoleId AEManagerRoleId,
#        urh.RoleLevel,
#        urh.RoleDepth,
#        urh.level0RoleId,       
#        urh.level1RoleId,
#        urh.level2RoleId,
#        urh.level3RoleId,
#        urh.level4RoleId,
#        urh.level5RoleId,
#        urh.level6RoleId,
#        urh.level7RoleId       
# from bdw.user_role_hierarchy urh
# join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
# ),

# base (
# select  distinct
#         --flm.AEOwnerId,
#         flm.AEUserRoleId,
#         u1.name AEName,
#         u1.id AEId,
#         u2.name M1Name,
#         u2.id  M1Id,
#         u3.name M2Name,
#         u3.id M2Id,        
#         u4.name  M3Name,
#         u4.id M3Id,        
#         u5.name M4Name,
#         u5.id M4Id,        
#         u6.name M5Name,
#         u6.id M5Id
# from firstLevelManagers flm
# join users u on flm.AEUserRoleId = u.UserRoleId
# left join users u1 on flm.level1RoleId = u1.userroleId
# left join users u2 on flm.level2RoleId = u2.userroleId
# left join users u3 on flm.level3RoleId = u3.userroleId
# left join users u4 on flm.level4RoleId = u4.userroleId
# left join users u5 on flm.level5RoleId = u5.userroleId
# left join users u6 on flm.level6RoleId = u6.userroleId
# left join users u7 on flm.level7RoleId = u7.userroleId
# where u7.name = "Ron Gabrisko"
# and u6.name not in ("Michael Hoff")
# and u.name not in ("6Sense User", "Aha Integration")
# and lower(u.name) not like '%api user%'
# and flm.RoleLevel = 1
# and flm.RoleDepth = 1
# order by 1
# )
# select *
# from base
# -- select distinct b.AEUserRoleId,
# --                 b.AEName,
# --                 b.AEId, 
# --                 b.M1Name, 
# --                 b.M2Name, 
# --                 b.M3Name, 
# --                 b.M3Name M4Name, 
# --                 b.M3Name M5Name, 
# --                 b.M3Name CROMinus1Name,
# --                 b.M2Name CROMinus2Name,
# --                 b.M1Name CROMinus3Name,                
# --                 b.M1Id, 
# --                 b.M2Id, 
# --                 b.M3Id, 
# --                 b.M3Id M4Id, 
# --                 b.M3Id M5Id,
# --                 b.M3Id CROMinus1Id,
# --                 b.M2Id CROMinus2Id,
# --                 b.M1Id CROMinus3Id                
# -- from base b
# -- join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.AEName
# --where lower(b.M1Name) like 'dina%'

# COMMAND ----------

# DBTITLE 1,User Hierarchy Levels
spark.sql(f"""
with 
firstLevelManagers (
select ae.*,
       urh.ParentRoleId AEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {user_role_hierarchy_table} urh
join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
),

base (
select  distinct
        flm.AEOwnerId,
        flm.AEUserRoleId,
        u1.name AEName,
        u1.id AEId,
        u2.name M1Name,
        u2.id  M1Id,
        u3.name M2Name,
        u3.id M2Id,        
        u4.name  M3Name,
        u4.id M3Id,        
        u5.name M4Name,
        u5.id M4Id,        
        u6.name M5Name,
        u6.id M5Id
from firstLevelManagers flm
join users u on flm.AEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u6.name = "Ron Gabrisko"
and u5.name not in ("Michael Hoff")
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
and flm.RoleLevel = 1
and flm.RoleDepth = 1
order by 1
)

select distinct b.AEName,
                b.AEId, 
                b.M1Name, 
                b.M2Name, 
                b.M3Name, 
                b.M4Name, 
                b.M5Name,
                b.M5Name CROMinus1Name,
                b.M4Name CROMinus2Name,
                b.M3Name CROMinus3Name,                   

                b.M1Id, 
                b.M2Id, 
                b.M3Id, 
                b.M4Id, 
                b.M5Id,
                b.M5Id CROMinus1Id,
                b.M4Id CROMinus2Id,
                b.M3Id CROMinus3Id    
from base b
join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.AEName
""").createOrReplaceTempView("user_hierarchy_level1")

spark.sql(f"""
with 

firstLevelManagers (
select ae.*,
       urh.ParentRoleId AEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {user_role_hierarchy_table} urh
join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
),

base (
select  distinct
        flm.AEOwnerId,
        flm.AEUserRoleId,
        
        u2.name AEName,
        u2.id AEId,
        u3.name M1Name,
        u3.id M1Id,        
        u4.name  M2Name,
        u4.id M2Id,        
        u5.name M3Name,
        u5.id M3Id,        
        u6.name M4Name,
        u6.id M4Id
from firstLevelManagers flm
join users u on flm.AEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u6.name = "Ron Gabrisko"
and u5.name not in ("Michael Hoff")
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
and flm.RoleLevel = 2
and flm.RoleDepth = 1
order by 1
)

select distinct b.AEName,
                b.AEId, 
                b.M1Name, 
                b.M2Name, 
                b.M3Name, 
                b.M4Name, 
                b.M4Name M5Name, 
                b.M4Name CROMinus1Name,
                b.M3Name CROMinus2Name,
                b.M2Name CROMinus3Name,                  
                
                b.M1Id, 
                b.M2Id, 
                b.M3Id, 
                b.M4Id, 
                b.M4Id M5Id,


                b.M4Id CROMinus1Id,
                b.M3Id CROMinus2Id,
                b.M2Id CROMinus3Id               
from base b
join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.AEName
""").createOrReplaceTempView("user_hierarchy_level2")

# COMMAND ----------

spark.sql(f"""
with 

firstLevelManagers (
select ae.*,
       urh.ParentRoleId AEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {user_role_hierarchy_table} urh
join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
),

base (
select  distinct
        flm.AEOwnerId,
        flm.AEUserRoleId,
        
        u3.name AEName,
        u3.id AEId,
        u4.name M1Name,
        u4.id M1Id,        
        u5.name  M2Name,
        u5.id M2Id,        
        u6.name M3Name,
        u6.id M3Id
from firstLevelManagers flm
join users u on flm.AEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u6.name = "Ron Gabrisko"
and u5.name not in ("Michael Hoff")
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
and flm.RoleLevel = 3
and flm.RoleDepth = 1
order by 1
)

select distinct b.AEName,
                b.AEId, 
                b.M1Name, 
                b.M2Name, 
                b.M3Name, 
                M3Name M4Name, 
                M3Name M5Name, 
                b.M3Name CROMinus1Name,
                b.M2Name CROMinus2Name,
                b.M1Name CROMinus3Name,   
                          
                b.M1Id, 
                b.M2Id, 
                b.M3Id, 
                b.M3Id M4Id, 
                b.M3Id M5Id,
                b.M3Id CROMinus1Id,
                b.M2Id CROMinus2Id,
                b.M1Id CROMinus3Id                
from base b
join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.AEName
""").createOrReplaceTempView("user_hierarchy_level3")

# COMMAND ----------

# %sql
# select *
# from user_hierarchy_level3

# COMMAND ----------

spark.sql(f"""
with 

firstLevelManagers (
select ae.*,
       urh.ParentRoleId AEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {user_role_hierarchy_table} urh
join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
),

base (
select  distinct
        flm.AEOwnerId,
        flm.AEUserRoleId,
        
        u4.name AEName,
        u4.id AEId,
        u5.name M1Name,
        u5.id M1Id,        
        u6.name  M2Name,
        u6.id M2Id
from firstLevelManagers flm
join users u on flm.AEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u6.name = "Ron Gabrisko"
and u5.name not in ("Michael Hoff")
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
and flm.RoleLevel = 4
and flm.RoleDepth = 1
order by 1
)

select distinct b.AEName,
                b.AEId, 
                b.M1Name, 
                b.M2Name, 
                M2Name M3Name, 
                M2Name M4Name, 
                M2Name M5Name, 
                b.M2Name CROMinus1Name,
                b.M1Name CROMinus2Name,
                b.M1Name CROMinus3Name, 

                b.M1Id, 
                b.M2Id, 
                b.M2Id M3Id, 
                b.M2Id M4Id, 
                b.M2Id M5Id,
                
                b.M2Id CROMinus1Id,
                b.M1Id CROMinus2Id,
                b.M1Id CROMinus3Id                                
from base b
join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.AEName
""").createOrReplaceTempView("user_hierarchy_level4")

spark.sql(f"""
with 

firstLevelManagers (
select ae.*,
       urh.ParentRoleId AEManagerRoleId,
       urh.RoleLevel,
       urh.RoleDepth,
       urh.level0RoleId,       
       urh.level1RoleId,
       urh.level2RoleId,
       urh.level3RoleId,
       urh.level4RoleId,
       urh.level5RoleId,
       urh.level6RoleId,
       urh.level7RoleId       
from {user_role_hierarchy_table} urh
join AEUserRoles ae on urh.UserRoleId = ae.AEUserRoleId
),

base (
select  distinct
        flm.AEOwnerId,
        flm.AEUserRoleId,
        
        u5.name AEName,
        u5.id AEId,
        case when u6.id = '00561000000cnF8AAI' then null else u6.name end M1Name,
        case when u6.id = '00561000000cnF8AAI' then null else u6.id end M1Id      
from firstLevelManagers flm
join users u on flm.AEUserRoleId = u.UserRoleId
left join users u1 on flm.level1RoleId = u1.userroleId
left join users u2 on flm.level2RoleId = u2.userroleId
left join users u3 on flm.level3RoleId = u3.userroleId
left join users u4 on flm.level4RoleId = u4.userroleId
left join users u5 on flm.level5RoleId = u5.userroleId
left join users u6 on flm.level6RoleId = u6.userroleId
left join users u7 on flm.level7RoleId = u7.userroleId
where u6.name = "Ron Gabrisko"
and u5.name not in ("Michael Hoff")
and u.name not in ("6Sense User", "Aha Integration")
and lower(u.name) not like '%api user%'
and flm.RoleLevel = 5
and flm.RoleDepth = 1
order by 1
)

select distinct b.AEName,
                b.AEId, 
                b.M1Name, 
                b.M1Name M2Name, 
                b.M1Name M3Name, 
                b.M1Name M4Name, 
                b.M1Name M5Name,
                b.M1Name CROMinus1Name,
                b.M1Name CROMinus2Name,
                b.M1Name CROMinus3Name,
                
                b.M1Id, 
                b.M1Id M2Id, 
                b.M1Id M3Id, 
                b.M1Id M4Id, 
                b.M1Id M5Id,
                b.M1Id CROMinus1Id,
                b.M1Id CROMinus2Id,
                b.M1Id CROMinus3Id                  
from base b
join users u on u.id = b.aeownerid and u.userroleid = b.aeuserroleid and u.name = b.AEName
""").createOrReplaceTempView("user_hierarchy_level5")

# COMMAND ----------

# %sql
# select *
# from user_hierarchy_level4

# COMMAND ----------

sales_leaders = spark.sql("""
select *
from user_hierarchy_level1
union
select *
from user_hierarchy_level2
union
select *
from user_hierarchy_level3
union
select *
from user_hierarchy_level4
union
select *
from user_hierarchy_level5
""")

sales_leaders.createOrReplaceTempView("sales_leaders")

# COMMAND ----------

sales_h0 = spark.sql("""
select distinct AEId,
                M1Id,
                M2Id,
                M3Id,
                M4Id,
                M5Id,
                
                CROMinus1Id,
                CROMinus2Id,
                CROMinus3Id,
              
                AEName,
                M1Name,
                M2Name,
                M3Name,
                M4Name,                
                M5Name,    

                CROMinus1Name,
                CROMinus2Name,
                CROMinus3Name
                
from sales_leaders
""")

sales_h0.createOrReplaceTempView("sales_h0")

# COMMAND ----------

sales_h1 = spark.sql("""
select distinct h1.M1Id AEId,
                h1.M2Id M1Id,
                h1.M3Id M2Id,
                h1.M4Id M3Id,
                h1.M5Id M4Id,
                h1.M5Id M5Id,
                
                h1.CROMinus1Id CROMinus1Id,
                h1.CROMinus2Id CROMinus2Id,
                h1.CROMinus2Id CROMinus3Id,
                
                h1.M1Name AEName,
                h1.M2Name M1Name,
                h1.M3Name M2Name,
                h1.M4Name M3Name,
                h1.M5Name M4Name,                
                h1.M5Name M5Name,    

                h1.CROMinus1Name CROMinus1Name,
                h1.CROMinus2Name CROMinus2Name,
                h1.CROMinus2Name CROMinus3Name
                
from sales_leaders h1
left join sales_h0 h0 on h1.M1Id = h0.AEId
where h0.AEId is null
""")

sales_h1.createOrReplaceTempView("sales_h1")

# COMMAND ----------

sales_h2 = spark.sql("""

select distinct h2.M2Id AEId,
                h2.M3Id M1Id,
                h2.M4Id M2Id,
                h2.M5Id M3Id,
                h2.M5Id M4Id,
                h2.M5Id M5Id,
                
                h2.CROMinus1Id CROMinus1Id,
                h2.CROMinus1Id CROMinus2Id,
                h2.CROMinus1Id CROMinus3Id,
                
                h2.M2Name AEName,
                h2.M3Name M1Name,
                h2.M4Name M2Name,
                h2.M5Name M3Name,
                h2.M5Name M4Name,                
                h2.M5Name M5Name,    

                h2.CROMinus1Name CROMinus1Name,
                h2.CROMinus1Name CROMinus2Name,
                h2.CROMinus1Name CROMinus3Name
                
from sales_leaders h2
left join sales_h1 h1 on h2.M2Id = h1.AEId
left join sales_h0 h0 on h2.M2Id = h0.AEId
where h1.AEId is null
and h0.AEId is null
""")
sales_h2.createOrReplaceTempView("sales_h2")

# COMMAND ----------

# %sql
# select *
# from sales_h1

# COMMAND ----------

# sales_h2_fix = spark.sql("""
# with 
# fix_managers (
# select distinct M5Name, M5Id, "00561000000cnF8AAI" CROId, "Ron Gabrisko" CROName
# from sales_leaders
# )

# select          h2.AEId,
#                 coalesce(fm.CROId, h2.M1Id) M1Id,
#                 coalesce(fm.CROId, h2.M2Id) M2Id,
#                 coalesce(fm.CROId, h2.M3Id) M3Id,
#                 coalesce(fm.CROId, h2.M4Id) M4Id,
#                 coalesce(fm.CROId, h2.M5Id) M5Id,                
                
#                 h2.CROMinus1Id,
#                 h2.CROMinus2Id,
#                 h2.CROMinus3Id,
                
#                 h2.AEName,

#                 coalesce(fm.CROName, h2.M1Name) M1Name,
#                 coalesce(fm.CROName, h2.M2Name) M2Name,
#                 coalesce(fm.CROName, h2.M3Name) M3Name,
#                 coalesce(fm.CROName, h2.M4Name) M4Name,
#                 coalesce(fm.CROName, h2.M5Name) M5Name,

#                 h2.CROMinus1Name,
#                 h2.CROMinus2Name,
#                 h2.CROMinus3Name
# from sales_h2 h2
# left join fix_managers fm on h2.AEId = fm.M5Id
# order by AEName
# """)
# sales_h2_fix.createOrReplaceTempView("sales_h2_fix")

# COMMAND ----------

sales_h3 = spark.sql("""
select distinct h3.M3Id AEId,
                h3.M4Id M1Id,
                h3.M5Id M2Id,
                h3.M5Id M3Id,
                h3.M5Id M4Id,
                h3.M5Id M5Id,
                
                h3.CROMinus1Id CROMinus1Id,
                h3.CROMinus1Id CROMinus2Id,
                h3.CROMinus1Id CROMinus3Id,
                
                h3.M3Name AEName,
                h3.M4Name M1Name,
                h3.M5Name M2Name,
                h3.M5Name M3Name,
                h3.M5Name M4Name,                
                h3.M5Name M5Name,    

                h3.CROMinus1Name CROMinus1Name,
                h3.CROMinus1Name CROMinus2Name,
                h3.CROMinus1Name CROMinus3Name
                
from sales_leaders h3
left join sales_h1 h1 on h3.M3Id = h1.AEId
left join sales_h2 h2 on h3.M3Id = h2.AEId
left join sales_h0 h0 on h3.M3Id = h0.AEId
where h1.AEId is null
and h2.AEId is null
""")
sales_h3.createOrReplaceTempView("sales_h3")

# COMMAND ----------

sales_h4 = spark.sql("""

select distinct h4.M4Id AEId,
                h4.M5Id M1Id,
                h4.M5Id M2Id,
                h4.M5Id M3Id,
                h4.M5Id M4Id,
                h4.M5Id M5Id,
                
                h4.CROMinus1Id CROMinus1Id,
                h4.CROMinus1Id CROMinus2Id,
                h4.CROMinus1Id CROMinus3Id,
              
                h4.M4Name AEName,
                h4.M5Name M1Name,
                h4.M5Name M2Name,
                h4.M5Name M3Name,
                h4.M5Name M4Name,                
                h4.M5Name M5Name,    

                h4.CROMinus1Name CROMinus1Name,
                h4.CROMinus1Name CROMinus2Name,
                h4.CROMinus1Name CROMinus3Name
                
from sales_leaders h4
left join sales_h1 h1 on h4.M4Id = h1.AEId
left join sales_h2 h2 on h4.M4Id = h2.AEId
left join sales_h3 h3 on h4.M4id = h3.AEId
where h1.AEId is null
and h2.AEId is null
and h3.AEId is null
""")

sales_h4.createOrReplaceTempView("sales_h4")

# COMMAND ----------

sales_leaders_hierarchy = spark.sql("""
select *
from sales_h0
union
select *
from sales_h1
union
select *
from sales_h2
union
select *
from sales_h3
union
select *
from sales_h4
""")

sales_leaders_hierarchy.createOrReplaceTempView("sales_leaders_hierarchy")

# COMMAND ----------

# %sql
# select * --count(AEId), count(distinct AEId)
# from sales_leaders_hierarchy
# order by AEName
# --where m4name is  null

# COMMAND ----------

sales_leaders_hierarchy.write.mode('overwrite').format("delta").option("overwriteSchema", "true").saveAsTable(cpq_manager_hierarchy_table_staging)

# COMMAND ----------

spark.sql(f""" 
create or replace temp view adhoc_cpq_manager_hierarchy as 
with base_1  (
select * except(M1Id, M1Name),
      case when M1Id = '00561000000cnF8AAI' then AEId else M1Id end as M1Id,
      case when M1Id = '00561000000cnF8AAI' then AEName else M1Name end as M1Name
from {cpq_manager_hierarchy_table_staging}
),

base_2 (
select * except(M2Id, M2Name),
      case when M2Id = '00561000000cnF8AAI' then M1Id else M2Id end as M2Id,
      case when M2Id = '00561000000cnF8AAI' then M1Name else M2Name end as M2Name      
from base_1
),

base_3 (
select * except(M3Id, M3Name),
      case when M3Id = '00561000000cnF8AAI' then M2Id else M3Id end as M3Id,
      case when M3Id = '00561000000cnF8AAI' then M2Name else M3Name end as M3Name
from base_2
),


base_4 (
select * except(M4Id, M4Name),
      case when M4Id = '00561000000cnF8AAI' then M3Id else M4Id end as M4Id,
      case when M4Id = '00561000000cnF8AAI' then M3Name else M4Name end as M4Name      
from base_3
),

base_5 (
select * except(M5Id, M5Name),
      case when M5Id = '00561000000cnF8AAI' then M4Id else M5Id end as M5Id,
      case when M5Id = '00561000000cnF8AAI' then M4Name else M5Name end as M5Name       
from base_4
)


select * except(CROMinus1Id, CROMinus1Name, CROMinus2Id, CROMinus2Name, CROMinus3Id, CROMinus3Name),

       case when M4Id = M3Id then M1Id else M2Id end as CROMinus3Id,
       case when M4Id = M3Id then M1Name else M2Name end as CROMinus3Name,

       case when M4Id = M3Id then M2Id else M3Id end as CROMinus2Id,
       case when M4Id = M3Id then M2Name else M3Name end as CROMinus2Name,

       M4Id as CROMinus1Id,
       M4Name as CROMinus1Name

from base_5
""")

# COMMAND ----------

adhoc_cpq_manager_hierarchy_df = spark.table('adhoc_cpq_manager_hierarchy')
adhoc_cpq_manager_hierarchy_df.write.mode('overwrite').format("delta").option("overwriteSchema", "true").saveAsTable(cpq_manager_hierarchy_table)

# COMMAND ----------

# %sql
# create table bdw_dev.cpq_manager_hierarchy
# using delta
# location "/mnt/bse-dev/cpqsales_manager_hierarchy"

# COMMAND ----------

managers_soql = """
select Id, Sales_Rep_Id__c, Manager_1__c, Manager_2__c, Manager_3__c, Manager_4__c, Manager_5__c, CRO_1__c, CRO_2__c, CRO_3__c from SBQQ__LookupData__c where SBQQ__Category__c = 'Hierarchy'
"""

# COMMAND ----------

from simple_salesforce import Salesforce
from pyspark.sql.functions import udf, struct, lower, col
from pyspark.sql.types import BooleanType
from pyspark.sql import functions as F
import pandas as pd
import numpy as np

# COMMAND ----------

hierarchy_df = get_dataframe(managers_soql, 'sfdcprod', 'login')

# COMMAND ----------

hierarchy_schema = build_spark_schema(hierarchy_df.dtypes)
spark_hierarchy = spark.createDataFrame(hierarchy_df, hierarchy_schema)

# COMMAND ----------

spark_hierarchy.createOrReplaceTempView("existing_hierarchy")

# COMMAND ----------

# spark_hierarchy.write.mode('overwrite').format("delta").option("overwriteSchema", "true").save("/mnt/bse-dev/backup/cpqsales_manager_hierarchy")

# COMMAND ----------

display(spark.sql(f""" 
select count(Sales_Rep_Id__c),
       count(distinct Sales_Rep_Id__c),
       "existing" source
from existing_hierarchy

union

select count(AEId),
       count(distinct AEId),
       "new" source
from {cpq_manager_hierarchy_table}
"""))

# COMMAND ----------

#select Id, Sales_Rep_Id__c, Manager_1__c, Manager_2__c, Manager_3__c, Manager_4__c, Manager_5__c, CRO_1__c, CRO_2__c, CRO_3__c from SBQQ__LookupData__c where SBQQ__Category__c = 'Hierarchy'

# COMMAND ----------

@udf('boolean')
def matchIdFlag(backendId, sfdcId):
  return backendId == sfdcId

spark.udf.register('matchIdFlag', matchIdFlag)

# COMMAND ----------

existing_updates_df = spark.sql(f"""
with new_updates (
select o.Id,
       n.AEId,
       n.M1Id, 
       n.M2Id,
       n.M3Id,
       n.M4Id,
       n.M5Id,
       n.CROMinus1Id,
       n.CROMinus2Id,
       n.CROMinus3Id,
       matchIdFlag(M1Id, Manager_1__c) M1IdFlag,
       matchIdFlag(M2Id, Manager_2__c) M2IdFlag,
       matchIdFlag(M3Id, Manager_3__c) M3IdFlag,
       matchIdFlag(M4Id, Manager_4__c) M4IdFlag,
       matchIdFlag(M5Id, Manager_5__c) M5IdFlag,
       matchIdFlag(CROMinus1Id, CRO_1__c) CRO_1IdFlag,
       matchIdFlag(CROMinus2Id, CRO_2__c) CRO_2IdFlag      
from {cpq_manager_hierarchy_table} n
join existing_hierarchy o on n.AEId = o.Sales_Rep_Id__c
where o.Sales_Rep_Id__c is not null
and AEId is not null
and M1Id is not null
)

select n.Id,
       n.AEId Sales_Rep_Id__c,
       n.M1Id Manager_1__c, 
       n.M2Id Manager_2__c,
       n.M3Id Manager_3__c,
       n.M4Id Manager_4__c,
       n.M5Id Manager_5__c,
       n.CROMinus1Id CRO_1__c,
       n.CROMinus2Id CRO_2__c,
       n.CROMinus3Id CRO_3__c,
       'Hierarchy' SBQQ__Category__c   
from new_updates n
where M1IdFlag = False or M2IdFlag = False or M3IdFlag = False or M4IdFlag = False or M5IdFlag = False or CRO_1IdFlag = False or CRO_2IdFlag = False
""")
existing_updates_df.createOrReplaceTempView("existing_updates_dbr")
existing_updates = existing_updates_df.toPandas()
existing_updates_upsert_data = [val for val in existing_updates.T.to_dict().values()]
print(len(existing_updates_upsert_data))

# COMMAND ----------

# if len(existing_updates_upsert_data) > 100:
#   raise Exception("too many existing updates")

# COMMAND ----------

new_updates = spark.sql(f"""
select n.AEId Sales_Rep_Id__c,
       n.M1Id Manager_1__c, 
       n.M2Id Manager_2__c,
       n.M3Id Manager_3__c,
       n.M4Id Manager_4__c,
       n.M5Id Manager_5__c,
       n.CROMinus1Id CRO_1__c,
       n.CROMinus2Id CRO_2__c,
       n.CROMinus3Id CRO_3__c,
       'Hierarchy' SBQQ__Category__c
from {cpq_manager_hierarchy_table} n
left join existing_hierarchy o on n.AEId = o.Sales_Rep_Id__c
where o.Sales_Rep_Id__c is null
and AEId is not null
and M1Id is not null
""").toPandas()

new_updates_upsert_data = [val for val in new_updates.T.to_dict().values()]

# COMMAND ----------

print(len(new_updates_upsert_data))

# COMMAND ----------

# new updates
if len(new_updates_upsert_data) > 0:
  creds = get_creds('sfdcprod')
  sf = get_sfdc_connection(creds, 'login')
  sf.bulk.SBQQ__LookupData__c.upsert(data=new_updates_upsert_data, external_id_field='Id', batch_size=750)

# COMMAND ----------

# existing updates
if len(existing_updates_upsert_data) > 0:
  creds = get_creds('sfdcprod')
  sf = get_sfdc_connection(creds, 'login')
  existing_upsert_resp = sf.bulk.SBQQ__LookupData__c.upsert(data=existing_updates_upsert_data, external_id_field='Id', batch_size=500)

# COMMAND ----------

success = []
failure = []
for r in existing_upsert_resp:
  if not r['errors']:
    success.append(r)
  else: 
    failure.append(r)

# COMMAND ----------

failure
