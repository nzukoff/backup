# Databricks notebook source
# MAGIC %run ../consumption-sfdc/Salesforce-HelperFunctions

# COMMAND ----------

from simple_salesforce import Salesforce
import pandas as pd
import numpy as np
 
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
 
from datetime import datetime

# COMMAND ----------

def get_upsert_data(upsert_spark_df, split_map):
  """
  input: spark dataframe
  output: json upsert list
  """
  upsert_spark_pd = upsert_spark_df.toPandas()
  upsert_spark_pd = upsert_spark_pd[split_map.keys()]
  upsert_spark_pd = upsert_spark_pd.rename(columns = split_map)
  upsert_spark_pd = upsert_spark_pd.reindex(sorted(upsert_spark_pd.columns), axis=1)
  return [val for val in upsert_spark_pd.T.to_dict().values()]

# COMMAND ----------

def check_total_records(sf_object):
  """ returns records in the object"""
  zero_rocord_check_soql = """  select count() from {0} """.format(sf_object)
  creds = get_creds('lfsf')
  sf = get_sfdc_connection(creds, 'databricks.my')
  data = sf.query(zero_rocord_check_soql)  
  return data['totalSize']


# COMMAND ----------

partner_capacity_size = check_total_records('Partner_Capacity__c')
print(partner_capacity_size)

# COMMAND ----------

if partner_capacity_size > 0:
  partner_capacity_soql = """
  SELECT Id, Account__c, Category__c, Contact_Email__c, Course__c, Month__c, Fiscal_Year__c, Date__c, LastModifiedDate FROM Partner_Capacity__c
  """

  partner_capacity_df = get_dataframe(partner_capacity_soql, 'lfsf', 'databricks.my')
  partner_capacity_schema = build_spark_schema(partner_capacity_df.dtypes)
  partner_capacity = spark.createDataFrame(partner_capacity_df, partner_capacity_schema)
  partner_capacity.createOrReplaceTempView("partner_capacity")

  PartnerCapacityIds = [ {'Id':row.Id} for row in spark.sql("""
  select Id
  from partner_capacity
  """).collect()]
  print(len(PartnerCapacityIds))
  try:
    creds = get_creds('lfsf')
    sf = get_sfdc_connection(creds, 'databricks.my')
    capacity_delete_out = sf.bulk.Partner_Capacity__c.delete(PartnerCapacityIds, batch_size=3000, use_serial=True)
    for out in capacity_delete_out:
      if len(out['errors']) > 0:
        print('error in deleting')
        print(out)    
  except:
    print('delete errored out, check bulk api job')

# COMMAND ----------

partner_capability_size = check_total_records('Partner_Capability__c')
print(partner_capability_size)

# COMMAND ----------

if partner_capability_size > 0:
  partner_capability_soql = """
  SELECT Id, Account__c, Category__c, Contact_Email__c, Course__c, Month__c, Fiscal_Year__c, Date__c, LastModifiedDate FROM Partner_Capability__c
  """

  partner_capability_df = get_dataframe(partner_capability_soql, 'lfsf', 'databricks.my')
  partner_capability_schema = build_spark_schema(partner_capability_df.dtypes)
  partner_capability = spark.createDataFrame(partner_capability_df, partner_capability_schema)
  partner_capability.createOrReplaceTempView("partner_capability")


  PartnerCapabilityIds = [ {'Id':row.Id} for row in spark.sql("""
  select Id
  from partner_capability
  """).collect()]
  print(len(PartnerCapabilityIds))
  
  try:
    creds = get_creds('lfsf')
    sf = get_sfdc_connection(creds, 'databricks.my')
    capability_delete_out = sf.bulk.PartnerCapabilityIds.delete(PartnerCapabilityIds, batch_size=3000, use_serial=True)
    for out in capability_delete_out:
      if len(out['errors']) > 0:
        print('error in deleting')
        print(out)    
  except:
    print('delete errored out, check bulk api job')  

# COMMAND ----------

  # PartnerCapabilityIds = [ {'Id':row.Id} for row in spark.sql("""
  # select Id
  # from partner_capability
  # """).collect()]
  # print(len(PartnerCapabilityIds))

# COMMAND ----------

try:
  creds = get_creds('lfsf')
  sf = get_sfdc_connection(creds, 'databricks.my')
  capability_delete_out = sf.bulk.Partner_Capability__c.delete(PartnerCapabilityIds, batch_size=3000, use_serial=True)
except:
  print('delete errored out, check bulk api job')  

# COMMAND ----------

partner_capability_map = {
"partner_account_id_sfdc" : "Account__c",
"contact_email" : "Contact_Email__c",
"partner_account_name" : "Partner_Account_Name__c",
"fiscal_quarter_year" : "Fiscal_Quarter_Year__c",
"month" : "Month__c",
"week" : "Week__c",
"fiscal_quarter" : "Fiscal_Quarter__c",
"fiscal_year" : "Fiscal_Year__c",
"course" : "Course__c",
"date" : "Date__c",
"course_type" : "Course_Type__c",
"category" : "Category__c",
"partner_manager" : "Partner_Manager__c",
"partner_level" : "Partner_Level__c",
"billing_country" : "Billing_Country__c"
}

# COMMAND ----------

# MAGIC %sql
# MAGIC select max(processDate) from main.field_learning_enablement.partner_capability

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct category
# MAGIC from main.field_learning_enablement.partner_capacity 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.partner_capacity)

# COMMAND ----------

# MAGIC %sql
# MAGIC select category, count(*)
# MAGIC from main.field_learning_enablement.partner_capability 
# MAGIC where processDate = (select max(processDate) from main.field_learning_enablement.partner_capability)
# MAGIC group by 1

# COMMAND ----------

partner_capability_spark_df = spark.sql(""" select * from main.field_learning_enablement.partner_capability where processDate = (select max(processDate) from main.field_learning_enablement.partner_capability)""")
partner_capability_data = get_upsert_data(partner_capability_spark_df, partner_capability_map)

# COMMAND ----------

print(len(partner_capability_data), partner_capability_data[0])

# COMMAND ----------

creds = get_creds('lfsf')
sf = get_sfdc_connection(creds, 'databricks.my')
output = sf.bulk.Partner_Capability__c.upsert(data=partner_capability_data, external_id_field='Id', batch_size=3000)

# COMMAND ----------

success, failure = 0, 0
for out in output:
  if len(out['errors']) > 0:
    print(out)
    failure += 1
  else:
    success += 1
print('sucess: ', success, ' failed:', failure)    

# COMMAND ----------

# DBTITLE 1,Partner Capacity
partner_capacity_map = {
"partner_account_id_sfdc" : "Account__c",
"contact_email" : "Contact_Email__c",
"partner_account_name" : "Partner_Account_Name__c",
"fiscal_quarter_year" : "Fiscal_Quarter_Year__c",
"month" : "Month__c",
"week" : "Week__c",
"fiscal_quarter" : "Fiscal_Quarter__c",
"fiscal_year" : "Fiscal_Year__c",
"course" : "Course__c",
"date" : "Date__c",
"course_type" : "Course_Type__c",
"category" : "Category__c",
"partner_manager" : "Partner_Manager__c",
"partner_level" : "Partner_Level__c",
"billing_country" : "Billing_Country__c"
}

# COMMAND ----------

# MAGIC %sql
# MAGIC select max(processDate) from main.field_learning_enablement.partner_capacity

# COMMAND ----------

partner_capacity_spark_df = spark.sql(""" select * from main.field_learning_enablement.partner_capacity where processDate = (select max(processDate) from main.field_learning_enablement.partner_capacity) """)
partner_capacity_data = get_upsert_data(partner_capacity_spark_df, partner_capacity_map)

# COMMAND ----------

print(len(partner_capacity_data), partner_capacity_data[0])

# COMMAND ----------

creds = get_creds('lfsf')
sf = get_sfdc_connection(creds, 'databricks.my')
capacity_output = sf.bulk.Partner_Capacity__c.upsert(data=partner_capacity_data, external_id_field='Id', batch_size=3000)

# COMMAND ----------

success, failure = 0, 0
for out in capacity_output:
  if len(out['errors']) > 0:
    print(out)
    failure += 1
  else:
    success += 1
print('sucess: ', success, ' failed:', failure) 

# COMMAND ----------


