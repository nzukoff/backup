# Databricks notebook source
import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

# DBTITLE 1,Date Dimension
start_date, end_date = pd.Timestamp("2005-01-01"), pd.Timestamp("2050-12-31")

# COMMAND ----------

str(start_date.year)+'-'+str(start_date.strftime('%m')+str(start_date.daysinmonth))

# COMMAND ----------

date_df = pd.DataFrame({"date":pd.date_range(start_date, end_date)})

date_df['day'] = date_df["date"].apply(lambda dt: dt.day_name())
date_df['year'] = date_df["date"].apply(lambda dt: dt.year)
date_df['month'] = date_df["date"].apply(lambda dt: dt.month)
date_df['monthName'] = date_df["date"].apply(lambda dt: dt.month_name())
date_df['quarter'] = date_df["date"].apply(lambda dt: dt.quarter)
date_df['week'] = date_df["date"].apply(lambda dt: dt.week)
date_df['dayofweek'] = date_df["date"].apply(lambda dt: dt.dayofweek)
date_df['last30date'] = date_df["date"].apply(lambda dt: dt - pd.to_timedelta(30, unit='d'))
date_df['last30date'] = date_df['last30date'].apply(lambda dt: dt.date())
date_df['last60date'] = date_df["date"].apply(lambda dt: dt - pd.to_timedelta(60, unit='d'))
date_df['last60date'] = date_df['last60date'].apply(lambda dt: dt.date())
date_df['last90date'] = date_df["date"].apply(lambda dt: dt - pd.to_timedelta(90, unit='d'))
date_df['last90date'] = date_df['last90date'].apply(lambda dt: dt.date())
date_df['isMonthStart'] = date_df["date"].apply(lambda dt: dt.is_month_start)
date_df['isMonthEnd'] = date_df["date"].apply(lambda dt: dt.is_month_end)
date_df['year_month'] = date_df["date"].apply(lambda dt: str(dt.year)+'-'+str(dt.strftime('%m')))
date_df['daysinmonth'] = date_df["date"].apply(lambda dt: dt.daysinmonth)
date_df["fiscalYearDate"] = date_df["date"].apply(pd.Period, freq='A-JAN')
date_df["fiscalYear"] = date_df["fiscalYearDate"].apply(lambda dt: int(dt.strftime('%Y')))
date_df['date'] = date_df["date"].apply(lambda dt: dt.date())

date_df["date_of_prior_month"] = date_df['date'].apply(lambda dt:  (dt - pd.DateOffset(months=1)).date())
date_df["date_of_prior_quarter"] = date_df['date'].apply(lambda dt:  (dt - pd.DateOffset(months=3)).date())
date_df["date_of_prior_year"] = date_df['date'].apply(lambda dt:  (dt - pd.DateOffset(years=1)).date())

date_df['prior_month'] = date_df["date"].apply(lambda dt: (dt - pd.DateOffset(months=1)) )

# COMMAND ----------

custom_quarter_map = { 'January': 4, 
                       'February': 1,
                       'March': 1,
                       'April': 1,
                       'May': 2,
                       'June': 2,
                       'July': 2,
                       'August': 3,
                       'September': 3,
                       'October': 3,
                       'November': 4,
                       'December': 4
                     }

custom_half_year_map = { 1: 'H1', 
                         2: 'H1', 
                         3: 'H2', 
                         4: 'H2'}   

custom_fiscal_month_map = { 'January': 12, 
                       'February': 1,
                       'March': 2,
                       'April': 3,
                       'May': 4,
                       'June': 5,
                       'July': 6,
                       'August': 7,
                       'September': 8,
                       'October': 9,
                       'November': 10,
                       'December': 11
                     }                                         

# COMMAND ----------

def convert_to_custom_quarter(row):
  return custom_quarter_map[row['monthName']]

def get_fiscal_half_year(row):
  return custom_half_year_map[row['fiscalQuarter']]

def get_fiscal_month(row):
  return custom_fiscal_month_map[row['monthName']]

date_df['fiscalQuarter'] = date_df[["monthName", "quarter", "date"]].apply(lambda row: convert_to_custom_quarter(row), axis=1)
date_df['fiscal_half_year'] = date_df[["fiscalQuarter"]].apply(lambda row: get_fiscal_half_year(row), axis=1)
date_df['fiscal_month_number'] = date_df[["monthName"]].apply(lambda row: get_fiscal_month(row), axis=1)
date_df = date_df.drop(columns=['fiscalYearDate'])

# COMMAND ----------

display(date_df)

# COMMAND ----------

spark_date_dim_df = spark.createDataFrame(date_df)

# COMMAND ----------

display(spark_date_dim_df)

# COMMAND ----------

spark_date_dim_df.createOrReplaceTempView("date_dim")

# COMMAND ----------

bi_dates = spark.sql("""
with month_end_dates (
select date as month_end_date,
       year_month
from date_dim
where isMonthEnd = 1
)

select dt.*,
       mdt.month_end_date
from date_dim dt
join month_end_dates mdt on dt.year_month = mdt.year_month
order by date
""")
bi_dates.createOrReplaceTempView("date_dim")

# COMMAND ----------

"""
weekstartdate - date of the week start
weekofquarter - current week of calendar quarter
fiscalWeek - week of current fiscal quarter
isQuarterStart - start date of calendar quarter - BOOLEAN
isQuarterEnd - end date of calendar quarter - BOOLEAN
isFiscalQuarterStart start date of fiscal quarter - BOOLEAN
isFiscalQuarterEnd end date of fiscal quarter - BOOLEAN
QuarterStartDate - start date of calendar quarter
QuarterEndDate - end date of calendar quarter
FiscalQuarterStartDate start date of fiscal quarter
FiscalQuarterEndDate end date of fiscal quarter
"""

# COMMAND ----------

pd_week_start_dates = spark.sql("""
with week_start_dates (
select date week_start_date
from date_dim
where dayofweek = 0
order by date
)

select dt.date,
       week_start_date week_start_date_tobe_dropped
from date_dim dt
left join week_start_dates wsd on dt.date = wsd.week_start_date
order by 1
""").toPandas()

pd_week_start_dates['week_start_date'] = pd_week_start_dates['week_start_date_tobe_dropped'].transform(lambda dt: dt.ffill())
pd_week_start_dates = pd_week_start_dates.drop(columns=['week_start_date_tobe_dropped'])

# COMMAND ----------

week_start_dates = spark.createDataFrame(pd_week_start_dates)
week_start_dates.createOrReplaceTempView("week_start_dates")

# COMMAND ----------

dates_week_start_dt_added = spark.sql("""
select dt.*,
       wsd.week_start_date
from date_dim dt
join week_start_dates wsd on dt.date = wsd.date
order by dt.date
""")
dates_week_start_dt_added.createOrReplaceTempView("dates_week_start_date_added")

# COMMAND ----------

dates_qtr_df = spark.sql("""
with base (
select date, year, quarter, week, fiscalYear, fiscalQuarter,
       first(date) over(partition by year, quarter) cal_quarter_start_date,
       last(date) over(partition by year, quarter) cal_quarter_end_date,
       first(date) over(partition by fiscalYear, fiscalQuarter) fiscal_quarter_start_date,
       last(date) over(partition by fiscalYear, fiscalQuarter) fiscal_quarter_end_date
from dates_week_start_date_added
),

base2 (
select *,
       case when date = cal_quarter_start_date then true
            else false
       end as is_cal_quarter_start,
       case when date = cal_quarter_end_date then true
            else false
       end as is_cal_quarter_end,
       

       case when date = fiscal_quarter_start_date then true
            else false
       end as is_fiscal_quarter_start,
       case when date = fiscal_quarter_end_date then true
            else false
       end as is_fiscal_quarter_end
       
from base
)

select date,    cal_quarter_start_date, cal_quarter_end_date,is_cal_quarter_start, is_cal_quarter_end,
                fiscal_quarter_start_date, fiscal_quarter_end_date, is_fiscal_quarter_start, is_fiscal_quarter_end
from base2
""")

dates_qtr_df.createOrReplaceTempView("dates_qtr")

# COMMAND ----------

bi_dates_enhanced = spark.sql("""
select dt.*,
       dtq.cal_quarter_start_date,
       dtq.cal_quarter_end_date,
       dtq.is_cal_quarter_start, 
       dtq.is_cal_quarter_end,
       dtq.fiscal_quarter_start_date, 
       dtq.fiscal_quarter_end_date, 
       dtq.is_fiscal_quarter_start, 
       dtq.is_fiscal_quarter_end
from dates_week_start_date_added dt
join dates_qtr dtq on dt.date = dtq.date
order by dt.date 
""")
display(bi_dates_enhanced)

# COMMAND ----------

bi_dates_enhanced.createOrReplaceTempView('bi_dates_enhanced')

# COMMAND ----------

#bi_dates_enhanced.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/bi_date_dim")

# COMMAND ----------

bi_dates_add_calweek = spark.sql("""
select 
    *,
    CONCAT(
      CASE
        WHEN DATE_PART('MONTH', date) = 1  AND DATE_PART('WEEK', date) in (52, 53) THEN DATE_PART('YEAR', date) - 1
        WHEN DATE_PART('MONTH', date) = 12 AND DATE_PART('WEEK', date) in (1)      THEN DATE_PART('YEAR', date) + 1
        ELSE DATE_PART('YEAR', date)
      END
      , '-W'
      , LPAD(week, 2, '0')
    ) calendar_week,

    case when week - 4 < 1 then 49 + week    
    else week - 4
    end as fiscal_week_number,
    
    CONCAT(year, '-Q', quarter) calendar_quarter,
    CONCAT('FY', substr(fiscalYear,3,2), '-Q', fiscalQuarter) fy_quarter,
    CONCAT('FY', substr(fiscalYear,3,2)) fy_year,
    CONCAT('FY', substr(fiscalYear,3,2), '-', fiscal_half_year) fiscal_half_year_formatted,
    CONCAT('FY', substr(fiscalYear,3,2), '-', lpad(fiscal_month_number, 2, "0")) fiscal_month
from bi_dates_enhanced
""")

bi_dates_add_calweek = bi_dates_add_calweek.drop('fiscal_half_year', 'fiscal_month_number')

bi_dates_add_calweek = bi_dates_add_calweek.withColumnRenamed('fiscal_half_year_formatted', 'fiscal_half_year')

# COMMAND ----------

bi_dates_add_calweek.count()

# COMMAND ----------

bi_dates_add_calweek.createOrReplaceTempView('bi_dates_add_calweek')

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists fiscal_year_week_dates;
# MAGIC create temp view fiscal_year_week_dates 
# MAGIC as 
# MAGIC select 
# MAGIC       CASE
# MAGIC         WHEN month = 1 AND fiscal_week_number = 1        THEN fiscalYear + 1 --concat('FY', substr(fiscalYear + 1,3,2))
# MAGIC         WHEN month = 2 AND fiscal_week_number in (52,53) THEN fiscalYear - 1 --concat('FY', substr(fiscalYear - 1,3,2))
# MAGIC         ELSE fiscalYear --concat('FY', substr(fiscalYear,3,2)
# MAGIC       END fiscal_year_week,
# MAGIC     *
# MAGIC from bi_dates_add_calweek 

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists bi_dates;
# MAGIC create temp view bi_dates
# MAGIC as 
# MAGIC select *,
# MAGIC         concat('FY', 
# MAGIC               substr(fiscal_year_week,3,2), 
# MAGIC               '-W', 
# MAGIC               LPAD(fiscal_week_number, 2, '0')
# MAGIC         ) as fiscal_week
# MAGIC from fiscal_year_week_dates 
# MAGIC order by date

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists month_dates

# COMMAND ----------

# MAGIC %sql
# MAGIC create temp view month_dates as
# MAGIC with base(
# MAGIC select first(date) over(partition by year, month) month_start_date,
# MAGIC        b.*
# MAGIC from bi_dates b
# MAGIC ),
# MAGIC 
# MAGIC base2 (
# MAGIC select date_add(month_start_date, cast(daysinmonth as smallint)) next_month_start_date,
# MAGIC        date_sub(month_end_date, cast(daysinmonth as smallint)) prior_month_end_date,
# MAGIC        month_start_date,
# MAGIC        date
# MAGIC from base b
# MAGIC )
# MAGIC 
# MAGIC select n.month_end_date next_month_end_date,
# MAGIC        p.month_start_date prior_month_start_date,
# MAGIC        b.*
# MAGIC from base2 b
# MAGIC left join base n on b.next_month_start_date = n.date
# MAGIC left join base p on b.prior_month_end_date = p.date
# MAGIC order by b.date

# COMMAND ----------

bi_dates_month_dates = spark.sql("""
select b.*,
       m.prior_month_start_date,
       m.prior_month_end_date,
       m.next_month_start_date,
       m.next_month_end_date
from bi_dates b
join month_dates m on b.date = m.date
""")

# COMMAND ----------

bi_dates_month_dates.count()

# COMMAND ----------

bi_dates_month_dates.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/bi_date_dim")

# COMMAND ----------

# MAGIC %sql
# MAGIC optimize bdw.bi_dates

# COMMAND ----------

# MAGIC %sql
# MAGIC select date,
# MAGIC        fy_year,
# MAGIC        month,
# MAGIC        fiscal_month
# MAGIC from bdw.bi_dates
# MAGIC where date > current_date()
# MAGIC order by date
