# Databricks notebook source
import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

# MAGIC %md
# MAGIC #### set up

# COMMAND ----------

sfdc_account_table = 'main.sfdc_bronze.account'
sfdc_user_table = 'main.sfdc_bronze.user'
finance_dbu_dollars = 'main.fin_live_gold.dbu_dollars'
finance_paid_usage_metering = 'main.fin_live_gold.paid_usage_metering'
bi_product_dim_table = 'main.it_core_dim.bi_product_dim'
bi_account_dim_table = 'main.it_core_dim.bi_account_dim'

# COMMAND ----------

account_dim_query = f"""
with 

accounts (
select a.id AccountID,
       a.Name AccountName,
       a.Region__c AccountRegion,
       a.Sub_Region__c AccountSubRegion,
       a.Account_Status__c Account_Status,
       a.CSE__c CSEOld,
       a.BRAG_Status__c BRAGStatus,
       a.SCP_Status__c SCPStatus,
       a.Top_25__c isTop25,
       a.Owner_Role__c OwnerRole,
       a.Segment__c AccountSegment,
       a.Databricks_Vertical_Map__c DatabricksVerticalMap,
       a.Account_CS_Tier__c AccountCSTier,
       a.Last_SA_Engaged__c LastSAEngaged,
       a.OwnerId,
       a.CSE_New__c,
       a.RSAUser__c,
       a.partner_type__c partner_type
from {sfdc_account_table} a
where a.processDate = (select max(processDate) from {sfdc_account_table})
),

users (

select Id, 
       Name,
       Territory_Name__c,
       Business_Unit__c,
       Region__c,
       Email,
       Region_Level_1__c,
       Region_Level_2__c,
       Region_Level_3__c,
       Region_Level_4__c
from {sfdc_user_table}
where processDate = (select max(processDate) from {sfdc_user_table})
)

select a.AccountID,
       a.AccountName,
       a.AccountRegion,
       a.AccountSubRegion,
       a.Account_Status,
       a.partner_type,
       a.CSEOld,
       u2.Name CSENewName,
       u.Name as AEName,
       u.Business_Unit__c ae_business_unit,
       u.Email ae_email,
       u.Region_Level_1__c ae_region_Level_1__c,
       u.Region_Level_2__c ae_region_Level_2__c,
       u.Region_Level_3__c ae_region_Level_3__c,
       u.Region_Level_4__c ae_region_Level_4__c,
       a.BRAGStatus,
       a.SCPStatus,
       a.isTop25,
       u.Territory_Name__c ccountOwnerTerritoryName,
       a.OwnerRole,
       a.AccountSegment,
       a.DatabricksVerticalMap,
       a.AccountCSTier,
       a.LastSAEngaged,
       u3.Name RSA
from accounts a 
left join users u on u.Id = a.OwnerId 
left join users u2 on u2.Id = a.CSE_New__c 
left join users u3 on u3.Id = a.RSAUser__c 
"""
account_dim_df = spark.sql(account_dim_query)

# COMMAND ----------

total_count = account_dim_df.count()
print(total_count)

# COMMAND ----------

user_query = f"""
select Id UserId,
       Name UserName
from {sfdc_user_table}
where processDate = (select max(processDate) from {sfdc_user_table})
"""
user_df = spark.sql(user_query)

# COMMAND ----------

account_dim_df = account_dim_df.join(user_df, account_dim_df.LastSAEngaged==user_df.UserId, 'left')\
                               .drop(user_df.UserId)\
                               .withColumnRenamed("UserName", "LastSAEngagedName")
account_dim_count = account_dim_df.count()

# COMMAND ----------

if account_dim_count == 0:
  raise Exception("aborting the write due to empty account-dim")

# COMMAND ----------

print(total_count, account_dim_count)
if total_count == account_dim_count:
  #account_dim_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/bi_account_dim")
  account_dim_df.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(bi_account_dim_table)  
  #pass
else:
  print("counts dont match: check the job")
  raise Exception("count mismatch")

# COMMAND ----------

# product_dim_query = """
# select meterCategory,
#        meterSubCategory,
#        meterName,
#        unit,
#        first(date, True) effectiveStartDate
# from prod.usage
# where unit = 'DBUs'
# and meterSubCategory in ("automated", "interactive", "sql")
# group by 1,2,3,4
# order by 3, 5 desc
# """

# product_dim_df = spark.sql(product_dim_query)
# product_dim_df.createOrReplaceTempView("product_dim")

# COMMAND ----------

spark.sql(f""" 
create or replace temp view potential_new_skus 
as
select          'workloads' meterCategory,
                case when lower(workload_type) like '%jobs%' then 'automated'
                     when lower(workload_type) like '%purpose%' then 'interactive'
                     else lower(workload_type) end as meterSubCategory,
                lower(sku) meterName, 
                'DBUs' unit,
                first(date) effectiveStartDate
from {finance_paid_usage_metering}
where lower(sku) not like '%unknown%'     
group by all
""")   

# COMMAND ----------

# MAGIC %sql
# MAGIC select p.*
# MAGIC from potential_new_skus p
# MAGIC left anti join main.it_core_dim.bi_product_dim b on b.meterName = p.meterName

# COMMAND ----------

# product_dim_query = """
# select meterCategory,
#        meterSubCategory,
#        meterName,
#        unit,
#        first(date, True) effectiveStartDate
# from prod.usage
# where unit = 'DBUs'
# and meterCategory = 'workloads'
# and meterSubCategory <> 'virtual'
# group by 1,2,3,4
# order by 3, 5 desc
# """

product_dim_query = f""" 
select p.meterCategory,
       p.meterSubCategory,
       p.meterName,
       p.unit,
       p.effectiveStartDate
from potential_new_skus p
left anti join {bi_product_dim_table} b on b.meterName = p.meterName
"""


product_dim_df = spark.sql(product_dim_query)
product_dim_df.createOrReplaceTempView("product_dim")

# COMMAND ----------

check_update = spark.sql(f"""
select cur.*
from product_dim cur
left join {bi_product_dim_table} prod on cur.meterName = prod.meterName
where prod.meterName is null
""")


if check_update.count() > 0 :
  display(check_update)
  #check_update.write.option("overwriteSchema", "true").format("delta").mode("append").save("/mnt/bse-dev/bi_product_dim")
  check_update.write\
              .option("overwriteSchema", "true")\
              .format("delta")\
              .mode("append")\
              .saveAsTable(bi_product_dim_table)
else:
  print("no updates")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(meterName), count(distinct meterName)
# MAGIC from main.it_core_dim.bi_product_dim

# COMMAND ----------

# %sql
# create or replace temp view bi_product_dim_dedup 
# as 
# with base ( 
# select *,
#        row_number() over(partition by meterName order by effectiveStartDate) rno
# from main.it_core_dim.bi_product_dim 
# )   

# select * except(rno)
# from base
# where rno = 1

# COMMAND ----------

#df = spark.sql(""" select * from bi_product_dim_dedup """)

# COMMAND ----------

# df.write\
#   .option("overwriteSchema", "true")\
#   .format("delta")\
#   .mode("overwrite")\
#   .saveAsTable(bi_product_dim_table)
