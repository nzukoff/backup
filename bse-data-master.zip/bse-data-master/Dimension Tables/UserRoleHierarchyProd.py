# Databricks notebook source
# MAGIC %run ./HelperFunctions

# COMMAND ----------

# MAGIC %sh
# MAGIC pip install simple-salesforce

# COMMAND ----------

#dbutils.library.installPyPI("simple-salesforce")
from simple_salesforce import Salesforce
import pandas as pd
import numpy as np
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

user_role_soql_query = """
SELECT  Id,
        Name,
        ParentRoleId,
        RollupDescription,
        PortalAccountId,
        PortalAccountOwnerId,
        PortalRole,
        PortalType,
        ForecastUserId,
        DeveloperName,
        LastModifiedById,
        LastModifiedDate,
        MayForecastManagerShare,
        OpportunityAccessForAccountOwner
FROM UserRole
"""

# COMMAND ----------

user_role_df = get_dataframe(user_role_soql_query, 'sfdcprod', 'login')

# COMMAND ----------

user_role_df = user_role_df.drop(columns=['PortalAccountOwnerId'])

# COMMAND ----------

user_role_df.info()

# COMMAND ----------

spark_user_role_df = spark.createDataFrame(user_role_df)

# COMMAND ----------

spark_user_role_df.createOrReplaceTempView("roles")

# COMMAND ----------

# identify the leaves in the role-tree
# idea is to take all "ID"s and look for ParentRoleId, if there is no such ParentRoleId, then it must not have any children, which means a leaf

leaf_ids = []
for row in user_role_df.itertuples():
  if user_role_df[user_role_df.ParentRoleId==row.Id].empty:
    print(row.Name, row.PortalRole, row.RollupDescription)
    leaf_ids.append(row.Id)

# COMMAND ----------

role_level_df = user_role_df[user_role_df.Id.isin(leaf_ids)].copy()
role_level_df['depth'] = 0

# COMMAND ----------

role_level_df.shape

# COMMAND ----------

def add_level(role_level_df, user_role_df):
  max_level = role_level_df['depth'].max()
  level_parents = role_level_df[role_level_df['depth']==max_level]['ParentRoleId'].unique()
  temp = user_role_df[user_role_df.Id.isin(level_parents)].copy().reset_index(drop=True)
  temp['depth'] = max_level + 1
  return temp, max_level+1

# COMMAND ----------

max_loop_counter = 100
counter = 0
while True:
  level_df, current_level = add_level(role_level_df, user_role_df)
  print('processed up-to level: ', current_level, ' added at this level:', level_df.shape[0])
  role_level_df = role_level_df.append(level_df, ignore_index=True)
  if level_df.shape[0] <= 1 or counter > max_loop_counter:
    break
  counter += 1

# COMMAND ----------

role_level_df.info()

# COMMAND ----------

#role_level_df[role_level_df['ParentRoleId']=='00E61000000owCZEAY']
role_level_df[role_level_df['Name']=='CEO']

# COMMAND ----------

len(role_level_df['Name'].unique())

# COMMAND ----------

# sort by 'level' and pick up only one level for each 'Id'
role_level_fix_df = role_level_df.groupby('Id', as_index=False)\
                           .apply(lambda x: x.nlargest(1, columns=['depth']))\
                           .reset_index(level=1, drop=1)

# COMMAND ----------

# build true level for all the roles
# fix all the children levels from root ( CEO ) ( for example, CCO may have just a depth of 3, but it really belongs to level 6)
role_level_fix_df['level'] = 0
role_level_fix_df.loc[(role_level_fix_df.Id=='00E61000000LmLMEA0'), 'level']= role_level_fix_df['depth'].max()

# COMMAND ----------

display(role_level_fix_df[role_level_fix_df.ParentRoleId=='00E61000000LmLMEA0'][['Id','Name','level','depth', 'ParentRoleId']])

# COMMAND ----------

# idea is to find the children the propagate the (parent_level-1) to the child 
# start with max_level and iterate through all the levels except the last one

# first, fix the children of the root
max_level = role_level_fix_df['depth'].max()
root_level_df = role_level_fix_df[role_level_fix_df.depth==max_level] #role_level_fix_df[role_level_fix_df['ParentRoleId']=='00E61000000LmLMEA0']
root_id = root_level_df['Id'].values[0]
print(root_id)
role_level_fix_df.loc[(role_level_fix_df.ParentRoleId==root_id), 'level']= max_level - 1
#role_level_fix_df.loc[role_level_fix_df.index.isin(root_level_df.index)]

# COMMAND ----------

display(role_level_fix_df[role_level_fix_df['ParentRoleId']=='00E61000000LmLMEA0'])

# COMMAND ----------

# get all children of root-id,
# for each child, if it's a parent, fix it's children

for current_level in range(max_level-1, 0, -1):
  children = role_level_fix_df[role_level_fix_df['level']==current_level][['Id', 'level']].values
  print('fixing %s children at the level %s' %(len(children), current_level))
  for child in children:
    role_level_fix_df.loc[(role_level_fix_df.ParentRoleId==child[0]), 'level']= child[1] - 1

# COMMAND ----------

role_level_df = role_level_fix_df.copy()

# COMMAND ----------

pd.set_option('display.max_rows', None)

# COMMAND ----------

role_hierarchy_df = role_level_fix_df.copy()

# COMMAND ----------

# populate LEVEL0
role_hierarchy_df['level0Id'] =  None
role_hierarchy_df['level0Name'] =  None
role_hierarchy_df.loc[(role_hierarchy_df['level']==0), 'level0Id'] = role_hierarchy_df[role_hierarchy_df['level']==0]['Id']
role_hierarchy_df.loc[(role_hierarchy_df['level']==0), 'level0Name'] = role_hierarchy_df[role_hierarchy_df['level']==0]['Name']

# COMMAND ----------

# populate LEVEL1
role_hierarchy_df['level1Id'] =  None
role_hierarchy_df['level1Name'] =  None
role_hierarchy_df.loc[(role_hierarchy_df['level']==1), 'level1Id'] = role_hierarchy_df[role_hierarchy_df['level']==1]['Id']
role_hierarchy_df.loc[(role_hierarchy_df['level']==1), 'level1Name'] = role_hierarchy_df[role_hierarchy_df['level']==1]['Name']

# COMMAND ----------

# iterate through level0 s and if there is a parent, then replace level1Name, level1Id with parent values
level1_ids = role_level_fix_df[role_level_fix_df['level']==1]['Id'].values
for level1_id in level1_ids:
  print('processing', level1_id)
  children = role_hierarchy_df[role_hierarchy_df['ParentRoleId']==level1_id]
  parent = role_hierarchy_df[role_hierarchy_df['Id']==level1_id][['Id', 'Name']].values
  print('children are: ', children.empty, '  parent:', parent, len(parent))
  if not children.empty:
    role_hierarchy_df.loc[(role_hierarchy_df.ParentRoleId==level1_id), 'level1Id']= parent[0][0]
    role_hierarchy_df.loc[(role_hierarchy_df.ParentRoleId==level1_id), 'level1Name']= parent[0][1]

# COMMAND ----------

def build_level(level, parent_id_col_name, parent_name_col_name, child_id_col_name, child_name_col_name):
  parent_ids = role_level_fix_df[role_level_fix_df['level']==level]['Id'].values
  for parent_level_id in parent_ids:
    children = role_hierarchy_df[role_hierarchy_df['ParentRoleId']==parent_level_id]
    parent = role_hierarchy_df[role_hierarchy_df['Id']==parent_level_id][['Id', 'Name']].values
    if not children.empty:
      role_hierarchy_df.loc[(role_hierarchy_df.ParentRoleId==parent_level_id), parent_id_col_name]= parent[0][0]
      role_hierarchy_df.loc[(role_hierarchy_df.ParentRoleId==parent_level_id), parent_name_col_name]= parent[0][1]
      
      low_level_ids = children['Id'].values
      print(parent[0][0], parent[0][1])
      role_hierarchy_df.loc[(role_hierarchy_df[child_id_col_name].isin(low_level_ids)), parent_id_col_name] = parent[0][0]
      role_hierarchy_df.loc[(role_hierarchy_df[child_id_col_name].isin(low_level_ids)), parent_name_col_name] = parent[0][1]

# COMMAND ----------

# populate LEVEL2
role_hierarchy_df['level2Id'] =  None
role_hierarchy_df['level2Name'] =  None
role_hierarchy_df.loc[(role_hierarchy_df['level']==2), 'level2Id'] = role_hierarchy_df[role_hierarchy_df['level']==2]['Id']
role_hierarchy_df.loc[(role_hierarchy_df['level']==2), 'level2Name'] = role_hierarchy_df[role_hierarchy_df['level']==2]['Name']
#build_level(2, 'level2Id', 'level2Name', 'level1Id', 'level1Name')

# COMMAND ----------

build_level(2, 'level2Id', 'level2Name', 'level1Id', 'level1Name')

# COMMAND ----------

def backfill_level(level):
  parent_id_col_name = 'level'+str(level)+'Id'
  parent_name_col_name = 'level'+str(level)+'Name'
  child_id_col_name = 'level'+str(level-1)+'Id'
  child_name_col_name = 'level'+str(level-1)+'Name'
  role_hierarchy_df[parent_id_col_name] =  None
  role_hierarchy_df[parent_name_col_name] =  None
  role_hierarchy_df.loc[(role_hierarchy_df['level']==level), parent_id_col_name] = role_hierarchy_df[role_hierarchy_df['level']==level]['Id']
  role_hierarchy_df.loc[(role_hierarchy_df['level']==level), parent_name_col_name] = role_hierarchy_df[role_hierarchy_df['level']==level]['Name']
  build_level(level, parent_id_col_name, parent_name_col_name, child_id_col_name, child_name_col_name)

# COMMAND ----------

role_hierarchy_df =  role_hierarchy_df.drop(columns=['level2Id', 'level2Name'])
print(role_hierarchy_df.shape)

# COMMAND ----------

backfill_level(2)

# COMMAND ----------

print(max_level)

# COMMAND ----------

for level in range(3,max_level+1):
  backfill_level(level)

# COMMAND ----------

role_hierarchy_df.shape

# COMMAND ----------

role_hierarchy_df[role_hierarchy_df['ParentRoleId']=='00E4N000000ouCxUAI']

# COMMAND ----------

# low_level_ids = role_hierarchy_df[role_hierarchy_df['ParentRoleId']=='00E4N000000ouCxUAI']['Id'].values
# role_hierarchy_df.loc[(role_hierarchy_df['level1Id'].isin(low_level_ids)), 'level2Id'] = '00E4N000000ouCxUAI'
# role_hierarchy_df.loc[(role_hierarchy_df['level1Id'].isin(low_level_ids)), 'level2Name'] = 'ANZ Commercial Manager'

# COMMAND ----------

role_hierarchy_df[role_hierarchy_df['Name']=='VP of IT']

# COMMAND ----------

role_hierarchy_df.info()

# COMMAND ----------

spark_role_hierarchy_df = spark.createDataFrame(role_hierarchy_df)

# COMMAND ----------

spark_role_hierarchy_df.createOrReplaceTempView('role_hierarchy')

# COMMAND ----------

spark_role_query = """
SELECT Id UserRoleId,
       Name RoleName,
       ParentRoleId,
       RollupDescription,
       --level8Name level8RoleName,       
       level7Name level7RoleName,
       level6Name level6RoleName,
       level5Name level5RoleName,
       level4Name level4RoleName,
       level3Name level3RoleName,
       level2Name level2RoleName,
       level1Name level1RoleName,
       level0Name level0RoleName,
       --level8Id level8RoleId,
       level7Id level7RoleId,
       level6Id level6RoleId,
       level5Id level5RoleId,
       level4Id level4RoleId,
       level3Id level3RoleId,
       level2Id level2RoleId,
       level1Id level1RoleId,
       level0Id level0RoleId,
       depth RoleDepth,
       level RoleLevel,
       PortalAccountId,
       PortalRole,
       PortalType,
       ForecastUserId,
       DeveloperName,
       MayForecastManagerShare,
       OpportunityAccessForAccountOwner,
       LastModifiedById,
       LastModifiedDate
FROM role_hierarchy
"""

# COMMAND ----------

display(spark.sql(spark_role_query))

# COMMAND ----------

spark_user_role_hierarchy_df = spark.sql(spark_role_query)

# COMMAND ----------

spark_user_role_hierarchy_df.write.format("delta").mode("overwrite").saveAsTable('main.it_core_dim.user_role_hierarchy')

# COMMAND ----------

# spark_user_role_hierarchy_df.write.format("delta").mode("overwrite").save("/mnt/bse-dev/userrolehierarchy")

# COMMAND ----------

# spark_user_role_hierarchy_df.write.format("delta").mode("overwrite").save("/mnt/bdw/userrolehierarchy")

# COMMAND ----------

# MAGIC %sql
# MAGIC optimize main.it_core_dim.user_role_hierarchy

# COMMAND ----------

# %sql
# create table bdw.user_role_hierarchy
# using delta
# location '/mnt/bdw/userrolehierarchy'

# COMMAND ----------

import json
dbutils.notebook.exit(json.dumps({
  "status": "OK"
}))
