# Databricks notebook source
# MAGIC %run ./eng_ops_health_config

# COMMAND ----------

incident = spark.sql(f"select * from {unity_catalog}.it_data_pagerduty_bronze.incident")
log_entries = spark.sql(f"select * from {unity_catalog}.it_data_pagerduty_bronze.log_entries")
incident.cache()
log_entries.cache()

# COMMAND ----------

display(incident.agg({"created_at": "max"}))

# COMMAND ----------

print(incident.count())
print(log_entries.count())

# COMMAND ----------

from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, TimestampType
from pyspark.sql.functions import expr, when
from pyspark.sql.functions import min, col
from pyspark.sql.window import Window

assignee_schema = ArrayType(StructType([
    StructField("at", TimestampType(), True),
    StructField("assignee", StructType([
        StructField("id", StringType(), True),
        StructField("type", StringType(), True),
        StructField("summary", StringType(), True),
        StructField("self", StringType(), True),
        StructField("html_url", StringType(), True)
    ]), True)
]))

ack_schema = ArrayType(StructType([
    StructField("at", TimestampType(), True),
    StructField("acknowledger", StructType([
        StructField("id", StringType(), True),
        StructField("type", StringType(), True),
        StructField("summary", StringType(), True),
        StructField("self", StringType(), True),
        StructField("html_url", StringType(), True)
    ]), True)
]))

incident = incident.withColumn("assignments", from_json(col("assignments"), assignee_schema)).withColumn("acknowledgements", from_json(col("acknowledgements"), ack_schema)).withColumn("acknowledgements", when(
    col("acknowledgements").isNotNull(),
    expr("transform(acknowledgements, x -> struct(x.at, x.acknowledger, (unix_timestamp(x.at) - unix_timestamp(created_at)) as tta_seconds))")
).otherwise(None))



# COMMAND ----------

print(incident.count())
display(incident.agg({"created_at": "max"}))

# COMMAND ----------

acknowledged_df = log_entries.filter(col("summary").like("Acknowledged%"))
acknowledged_df = acknowledged_df.withColumn("min_created_at", min("created_at").over(Window.partitionBy("incident_id")))
acknowledged_df = acknowledged_df.filter(col("created_at") == col("min_created_at")).dropDuplicates(["incident_id", "created_at"]).select(
    col("agent_summary").alias("acknowledged_by"), col("agent_type").alias("acknowledgement_agent_type"), col("created_at").alias("acknowledged_at"), col("incident_id"), col("summary").alias("acknowledgement_summary")
)

# COMMAND ----------



resolution_df = log_entries.filter(col("summary").like("Resolved%"))
resolution_df = resolution_df.withColumn("min_created_at", min("created_at").over(Window.partitionBy("incident_id")))
resolution_df = resolution_df.filter(col("created_at") == col("min_created_at")).select(
    col("agent_summary").alias("resolved_by"), col("agent_type").alias("resolution_agent_type"), col("created_at").alias("resolved_at"), col("incident_id"), col("summary").alias("resolution_summary")
)

# COMMAND ----------

incident = incident.select(
        incident.id.alias("incident_id"),
        incident.created_at,
        incident.title,
        incident.service_id.alias("pd_service_id"),
        incident.acknowledgements,
        incident.assignments
    )


# COMMAND ----------

display(incident.agg({"created_at": "max"}))

# COMMAND ----------

final_incidents = incident.join(resolution_df, incident.incident_id == resolution_df.incident_id, "left").select(
        incident.incident_id,
        incident.created_at,
        incident.title,
        incident.pd_service_id,
        incident.acknowledgements,
        incident.assignments,
        resolution_df.resolved_by,
        resolution_df.resolved_at,
        resolution_df.resolution_agent_type,
        resolution_df.resolution_summary,
).join(acknowledged_df, incident.incident_id == acknowledged_df.incident_id, "left").select(
        incident.incident_id,
        incident.created_at,
        incident.title,
        incident.pd_service_id,
        incident.acknowledgements,
        incident.assignments,
        acknowledged_df.acknowledged_by,
        acknowledged_df.acknowledged_at,
        acknowledged_df.acknowledgement_agent_type,
        acknowledged_df.acknowledgement_summary,
        resolution_df.resolved_by,
        resolution_df.resolved_at,
        resolution_df.resolution_agent_type,
        resolution_df.resolution_summary
).withColumn(
    "resolution_time_seconds",
    when(col("resolved_at").isNotNull(), expr("unix_timestamp(resolved_at) - unix_timestamp(created_at)"))
).withColumn(
    "acknowledgement_time_seconds",
    when(col("acknowledged_at").isNotNull(), expr("unix_timestamp(acknowledged_at) - unix_timestamp(created_at)"))
)

# COMMAND ----------

display(final_incidents.agg({"created_at": "max"}))

# COMMAND ----------

from pyspark.sql import functions as F

final_incidents = final_incidents.withColumn(
    "first_assignee",
    F.expr("transform(assignments, x -> x.assignee)[0].summary")
).withColumn(
    "last_assignee",
    F.expr("transform(assignments, x -> x.assignee)[-1].summary")
)

display(final_incidents)

# COMMAND ----------

display(final_incidents.agg({"created_at": "max"}))

# COMMAND ----------

print(final_incidents.count())
print(log_entries.count())

# COMMAND ----------

display(final_incidents.orderBy(col('created_at').desc()))

# COMMAND ----------

final_incidents.write.mode("overwrite").option("mergeSchema", "true").saveAsTable(f"{unity_catalog}.{unity_schema}.pagerduty_incidents")

# COMMAND ----------

display(incident.agg({"created_at": "max"}))

# COMMAND ----------

display(sql(f"select * from {unity_catalog}.{unity_schema}.pagerduty_incidents order by created_at desc"))
