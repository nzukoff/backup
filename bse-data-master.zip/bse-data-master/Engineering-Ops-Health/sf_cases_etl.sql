-- Databricks notebook source
-- refresh cycle for bronze tables is once a day thus the refresh cadence for sf_case is set to oce a day
with latest_processdate as (select max(processDate) pdate from main.sfdc_bronze.case),
  Account_name_1
  (
    select id,Strategic_Account__c,SCP_Tier__c, max( name) name from main.sfdc_bronze.account 
    where processDate in (select max(processDate) pdate from main.sfdc_bronze.account )
    group by 1,2,3
  ),
  Account_name
  (
    select id,Strategic_Account__c,SCP_Tier__c, max( name) name from main.sfdc_bronze.account 
    where processDate in (select max(processDate) pdate from main.sfdc_bronze.account )
    group by 1,2,3
  ),
  backline_escalations
  (
    Select distinct Case_No__c , CreatedDate as BL_Case_AsignedDate from main.sfdc_bronze.backline_escalation__c
    where processDate in (select max(processDate) pdate from main.sfdc_bronze.backline_escalation__c )
  ),
  isEscalated
  (
    select distinct CaseNumber
    from main.sfdc_bronze.case c
    where 
    -- c.Component__c IN ('Databricks SQL','Spark','SQL Analytics','DB Connect','Delta','Delta Sharing','Storage') and 
    processDate in ( select pdate from latest_processdate)
    and ( c.Escalate_to_Level2__c
    or Id in (select Case__c from main.sfdc_bronze.escalation_request_summary__c ers 
               where ers.processDate in ( select pdate from latest_processdate)
              ) 
        )
  ),
  SF_cases
  (
  Select CAS.*, case when CAS.requestor__c is NULL then an.name else an1.name end name,
  CAS.SCP_Customer__c Strategic_Account__c, an.SCP_Tier__c from main.sfdc_bronze.case CAS join latest_processdate  on CAS.processDate=pdate
  LEFT OUTER JOIN account_name an on CAS.AccountId__c = an.id
  LEFT OUTER JOIN account_name_1 an1 on CAS.requestor__c = an1.id 
  where
  -- CAS.Component__c IN ('Databricks SQL','Spark','SQL Analytics','DB Connect','Delta','Delta Sharing','Storage') and
   CAS.createddate >= date_sub(now(), 800)
  ),
  ESCases as 
  ( select  GI_Support__IssueKey__c ES_ticket, explode(split(GI_Support__CaseNos__c,' ')) CaseNumber from main.sfdc_bronze.gi_support__jiraissue__c where processdate in
      ( select pdate from latest_processdate )
     union
   select key as ES_ticket, explode(split(coalesce(rtrim (']',ltrim('[',salesforce_case_number)),''),',')) as CaseNumber
     from main.eng_ops_health.jira_es_base where salesforce_case_number != '[]'
  ) 
insert overwrite main.eng_ops_health.sf_cases  SELECT
  CS.CaseNumber cases,
  concat('https://databricks.lightning.force.com',rtrim('" target="_blank">'||CS.CaseNumber||'</a>',ltrim('<a href="',CS.Case_URL__c))) sf_case_url,
  CS.name,
  case 
  when CS.Strategic_Account__c = 'true' THEN 'true'
  when CS.Strategic_Account__c = 'false' and CS.SCP_Tier__c in ('Participant','Top 25','Top 100' ) THEN 'true'
  else 'false'
  end as Strategic_Account,
  CS.SCP_Tier__c,
  CASE
  WHEN CS.Component__c = 'SQL Analytics' THEN 'Databricks SQL'
  ELSE CS.Component__c
  END AS Component,
  CS.Subcomponent__c SubComponent ,
  CS.Status as SF_STATUS,
  CS.LastInternalComment_DateTime__c as LastInternalComment_DateTime,
  CS.LastPublicComment_DateTime__c as LastPublicCommentDateTime,
  CS.subject subject,
  CS.priority priority,
  to_date(CS.CreatedDate, 'MM-DD-YYYY') SF_Case_CreatedDate,
  to_date(CS.ClosedDate, 'MM-DD-YYYY') SF_Case_CloseddDate,
  to_date(BE.BL_Case_AsignedDate, 'MM-DD-YYYY') BL_Case_AsignedDate,
  CASE 
      when CS.Status in ( 'Open','Pending','New','On Hold') then date_diff(now(),CS.CreatedDate) 
      when CS.Status in ( 'Closed','Solved') then date_diff(CS.ClosedDate,CS.CreatedDate ) 
  END as SF_Case_Age_in_Days,
  ESCases.ES_ticket,
  CASE
  WHen ESCases.ES_ticket is NOT NULL then 'Eng. Support'
  WHEN BE.Case_No__c IS NULL THEN 'Frontline Support'
  WHEN BE.Case_No__c IS NOT NULL THEN 'Backline Support'
  ELSE 'Undefined'
  END AS Support_team, 
  CASE
  WHEN CS.Status in ( 'Open','Pending','New','On Hold') THEN 'Open'
  WHEN CS.Status in ( 'Closed','Solved') then 'Closed'
  ELSE 'Undefined'
  END AS Overall_Status, 
  CASE
  WHEN ESCases.ES_ticket IS NULL THEN 'No'
  ELSE 'Yes'
 END AS EngSupport_Ticket_Created,
 CASE
  WHEN ESC.CaseNumber iS NULL THEN 'No'
  WHEN ESC.CaseNumber iS NOT NULL THEN 'Yes'
  ELSE 'Undefined'
END AS IsEscalated,
  case
       when BE.Case_No__c IS NULL AND (ESCases.ES_ticket IS NULL) AND CS.Status in ( 'Open','Pending','New','On Hold') then 'FL In Progress'
       when BE.Case_No__c IS NOT NULL AND (ESCases.ES_ticket IS NULL) AND CS.Status in ( 'Open','Pending','New','On Hold') then 'BL In Progress'
       when BE.Case_No__c IS NOT NULL AND (ESCases.ES_ticket IS NOT NULL) AND CS.Status in ( 'Open','Pending','New','On Hold') then 'BL + ES Ticket In Progress'
       when BE.Case_No__c IS NULL AND (ESCases.ES_ticket IS NOT NULL) AND CS.Status in ( 'Open','Pending','New','On Hold') then 'FL + ES Ticket In Progress'
       when BE.Case_No__c IS NULL AND (ESCases.ES_ticket IS NULL) AND CS.Status in ( 'Closed','Solved') then 'FL Resolved'
       when BE.Case_No__c IS NOT NULL AND (ESCases.ES_ticket IS NULL) AND CS.Status in ( 'Closed','Solved') then 'BL Resolved'
       when BE.Case_No__c IS NOT NULL AND (ESCases.ES_ticket IS NOT NULL) AND CS.Status in ( 'Closed','Solved') then 'BL + ES Ticket Resolved'
       when BE.Case_No__c IS NULL AND (ESCases.ES_ticket IS NOT NULL) AND CS.Status in ( 'Closed','Solved') then 'FL + ES Ticket Resolved'
       else 'Undefined'
      end as HandledAs,
      current_date()
       from SF_cases as CS
       LEFT OUTER JOIN backline_escalations AS BE
       ON CS.Id = BE.Case_No__c
       LEFT OUTER JOIN
       ESCases on
       CS.CaseNumber = trim(ESCases.CaseNumber)
       LEFT OUTER JOIN isEscalated as ESC
       on CS.CaseNumber = ESC.CaseNumber

       -- Alter table dbsql_sf_cases add column LastPublicCommentDateTime timestamp after LastInternalComment_DateTime
       
       -- LastPublicComment_DateTime__c

-- COMMAND ----------

-- MAGIC %sql select * from main.eng_ops_health.sf_cases limit 2
