# Databricks notebook source
# MAGIC %run ./eng_ops_health_config

# COMMAND ----------

# MAGIC %run ./jira_etl_utils

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql.functions import when, col, lit
  
def merge_postmortems_issues(issues):
    df1 = spark.createDataFrame(issues, schema=postmortems_schema)
    df1 = df1.withColumn("category_new", 
                   when(col("category") == lit("postmortem-followup"), 
                        lit("postmortem-followup-no-term")
                   ).otherwise(col("category"))
              ) \
       .drop("category") \
       .withColumnRenamed("category_new", "category")
    df1.createOrReplaceTempView("postmortems_tickets_tmp_all")
    sql("select *, row_number() over (partition by key order by updated desc) as RN from postmortems_tickets_tmp_all").createOrReplaceTempView('postmortems_tickets_tmp_rn')
    dups = sql("select count(*) as cnt from postmortems_tickets_tmp_rn where RN>1").first()['cnt']
    #print(dups)
    if dups > 0:
        print("Displaying duplicates ...")
        display(sql("select * from postmortems_tickets_tmp_rn where key in (select distinct key from postmortems_tickets_tmp_rn where RN>1) "))
    
    
    sql("select * from postmortems_tickets_tmp_rn where RN=1").drop("RN").createOrReplaceTempView('postmortems_tickets_tmp')
    
    display(sql("select * from postmortems_tickets_tmp"))
    
    print("Merging the source date into the target - postmortems_raw")
    display(spark.sql(f"""
      MERGE INTO {unity_catalog}.{unity_schema}.postmortems_raw old
      USING postmortems_tickets_tmp new
      ON old.key = new.key
      WHEN MATCHED THEN UPDATE SET *
      WHEN NOT MATCHED THEN INSERT *
   """))

# COMMAND ----------

# from concurrent.futures import ThreadPoolExecutor,wait,ALL_COMPLETED
# import timeit,time
# import math
# from pyspark.sql.functions import current_timestamp

lastUpdatedFrom,lastUpdatedTo = incremental_range('postmortems_raw_etl')

jql = f'''labels in ("postmortem-followup", "postmortem-followup-short-term", "postmortem-followup-long-term") 
  AND (updated >= "{lastUpdatedFrom}" OR created >= "{lastUpdatedFrom}") AND (updated < "{lastUpdatedTo}" OR created < "{lastUpdatedTo}")
  AND status != Cancelled AND status != Rejected'''

print(f"\nJQL - {jql}")

# COMMAND ----------

issuesCount = get_max_count(jql)
print(f"Total issues count received from source - {issuesCount}")

if int(issuesCount) == 0:
  update_checkpoint(issuesCount, 'postmortems_raw_etl', 'postmortems_raw', lastUpdatedFrom, lastUpdatedTo)
  dbutils.notebook.exit("There are no changes in the postmortems tickets in the last 30 minutes. Stopping notebook execution.")
  

# COMMAND ----------

issues_list, issues_raw_list,failed_keys_within_batch, failed_batch  = fetch_issues_from_jira(jql, parse_postmortems_issue, False)

# COMMAND ----------

merge_postmortems_issues(issues_list)

# COMMAND ----------

update_checkpoint(issuesCount, 'postmortems_raw_etl', 'postmortems_raw', lastUpdatedFrom, lastUpdatedTo) 

# COMMAND ----------

# logging failed keys
log_failed_keys(failed_keys_within_batch, 'rejected_postmortems_jira_keys')

# checking if there are any failed offsets even after retries
failed_batch_check(failed_batch)

# COMMAND ----------

display(spark.sql(f"select * from {unity_catalog}.{unity_schema}.postmortems_raw limit 10"))

# COMMAND ----------

display(spark.sql(f"select count(*) from {unity_catalog}.{unity_schema}.postmortems_raw limit 10"))

# COMMAND ----------

display(spark.sql(f"select * from {unity_catalog}.{unity_schema}.base_checkpoint order by last_refresh_ts_UTC desc limit 10"))
