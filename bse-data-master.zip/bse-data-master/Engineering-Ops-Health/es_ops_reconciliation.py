# Databricks notebook source
# MAGIC %md
# MAGIC This recon ensures that there are no missing tickets in the base tables.

# COMMAND ----------

# MAGIC %md
# MAGIC # JIRA ES Base
# MAGIC Checking for no missing tickets in the last 48 hours

# COMMAND ----------

!pip install jira==3.6
!pip install pytz==2021.3
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./eng_ops_health_config

# COMMAND ----------

# MAGIC %run ./jira_etl_utils

# COMMAND ----------

# DBTITLE 1,Jira Data Reconciliation Check
checking_from, checking_till = getReconParam('jira_es_base_etl')
print(checking_from, checking_till)


jql = f"project = ES AND (updated >= '{checking_from}') and (updated <= '{checking_till}') "
print(jql+ "\n")


sql = f"""select count(*) from {unity_catalog}.{unity_schema}.jira_es_base where date_format(from_utc_timestamp(updated, 'PST'),'yyyy-MM-dd HH:mm:ss') >= '{checking_from}'||':00' and date_format(from_utc_timestamp(updated, 'PST'),'yyyy-MM-dd HH:mm:ss') <= '{checking_till}'||':00'"""

print(sql)

issuesCountFromJira = getCountJira(jql)
issuesCountFromBaseTable = getCountBaseTables(sql)

print(issuesCountFromJira, issuesCountFromBaseTable)
raiseESUpdatedCountError = False
if issuesCountFromBaseTable < issuesCountFromJira:
  # count of updated tickets from the base tables should be more than the count from the jira
  # This expectation is based on the assumption that some tickets would have been updated in jira after the last pipeline run, and therefore, their updated timestamps would be later than the latest update timestamp in the base tables
  raiseESUpdatedCountError = True

# COMMAND ----------

# DBTITLE 1,Jira Issue Count Validator
checking_from, checking_till = getReconParam('jira_es_base_etl')
print(checking_from, checking_till)

jql = f"project = ES AND (created >= '{checking_from}') and (created <'{checking_till}' )"
print(jql)

sql = f"""select count(*) from {unity_catalog}.{unity_schema}.jira_es_base where date_format(from_utc_timestamp(created, 'PST'),'yyyy-MM-dd HH:mm:ss') >= '{checking_from}'||':00' and date_format(from_utc_timestamp(created, 'PST'),'yyyy-MM-dd HH:mm:ss') <= '{checking_till}'||':00'"""
print(sql)

issuesCountFromJira = getCountJira(jql)
issuesCountFromBaseTable = getCountBaseTables(sql)

print(issuesCountFromJira, issuesCountFromBaseTable)

raiseESCreatedCountError = False

if issuesCountFromBaseTable < issuesCountFromJira:
  # The count of created tickets from the base tables should exceed the count from Jira.
  # This is expected because a few tickets may have been deleted(moved from ES board) after the last pipeline run, meaning they would still exist in the base table but not in Jira.
  raiseESCreatedCountError = True

# COMMAND ----------

# MAGIC %md
# MAGIC # Postmortems Raw
# MAGIC Validating for no missing postmortems tickets.

# COMMAND ----------

# DBTITLE 1,Postmortem Data Sync Validator
checking_from, checking_till = getReconParam('postmortems_raw_etl')
print(checking_from, checking_till)

# The filter on updated is added because there would be few tickets created in the checkpoint range for which the labels were added later, which would not have reflecte dint he base table.
jql = f"labels in ('postmortem-followup', 'postmortem-followup-short-term', 'postmortem-followup-long-term') and (updated <= '{checking_till}') AND status != Cancelled AND status != Rejected"

sql = f"""select count(*) from {unity_catalog}.{unity_schema}.postmortems_raw where  date_format(from_utc_timestamp(updated, 'PST'),'yyyy-MM-dd HH:mm:ss') <= '{checking_till}'||':00'"""
print(sql)

issuesCountFromJira = getCountJira(jql)
issuesCountFromBaseTable = getCountBaseTables(sql)

print(issuesCountFromJira, issuesCountFromBaseTable)
raisePMCountError = False
if issuesCountFromBaseTable < issuesCountFromJira:
  # The count of updated tickets from the base tables should exceed the count from Jira.
  # This is due to the possibility that some tickets were deleted(label removed or moved from the mentioned boards) after the last pipeline run, resulting in their presence in the base table but absence in Jira.
  raisePMCountError = True

# COMMAND ----------

if raisePMCountError or raiseESUpdatedCountError or raiseESCreatedCountError:
  errorString = "The following {} validations failed: \n"
  errorCount = 0
  if raisePMCountError:
    errorCount += 1
    errorString += "Postmortem tickets count validation failed\n"
  if raiseESUpdatedCountError:
    errorCount += 1
    errorString += "ES updated tickets count validation failed\n"
  if raiseESCreatedCountError:
    errorCount += 1
    errorString += "ES created tickets count validation failed\n"
  raise Exception(errorString.format(errorCount))

# COMMAND ----------


