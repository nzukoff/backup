# Databricks notebook source
# MAGIC %run ./eng_ops_health_config

# COMMAND ----------

# secret_scope = "service-eng-ops-health"
secret_scope = "eng-ops-health-service"

# COMMAND ----------

# MAGIC %run ./jira_etl_utils

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql.functions import when, col, lit
import pyspark.sql.functions as F

def overwrite_sec_issues(issues):
    df1 = spark.createDataFrame(issues, schema=sec_schema)
    df1 = df1.withColumn('RunId', F.current_date())

    df1.createOrReplaceTempView("sec_tickets_tmp_all")

    sql("select *, row_number() over (partition by key order by updated desc) as RN from sec_tickets_tmp_all").createOrReplaceTempView('sec_tickets_tmp_rn')

    dups = sql("select count(*) as cnt from sec_tickets_tmp_rn where RN>1").first()['cnt']
    #print(dups)
    if dups > 0:
        print("Displaying duplicates ...")
        display(sql("select * from sec_tickets_tmp_rn where key in (select distinct key from sec_tickets_tmp_rn where RN>1) "))
    
    sql("select * from sec_tickets_tmp_rn where RN=1").drop("RN").createOrReplaceTempView('sec_tickets_tmp')
    
    display(sql("select * from sec_tickets_tmp"))
    
    print("Overwrite - jira_sec_base")

    display(spark.sql(f"""
    CREATE OR REPLACE TABLE {unity_catalog}.{unity_schema}.jira_sec_base as
    SELECT * FROM sec_tickets_tmp;
    """))

# COMMAND ----------

current_date = datetime.now()
formatted_current_date = current_date.strftime("%Y-%m-%d")

cleanup_start_time = sql("select current_timestamp() as cleanup_start_time ").first()['cleanup_start_time']

jql = '''project=Security and issuetype = \"Risk Issue\" and status not in (Canceled, Duplicate, \"Not A Bug\", \"Not An Issue\", \"Won\'t Fix\")'''

print(f"\nJQL - {jql}")

# COMMAND ----------

issuesCount = get_max_count(jql)
print(f"Total issues count received from source - {issuesCount}")

# COMMAND ----------

issues_list, issues_raw_list,failed_keys_within_batch, failed_batch  = fetch_issues_from_jira(jql, parse_sec_issue, False)

# COMMAND ----------

overwrite_sec_issues(issues_list)

# COMMAND ----------

update_checkpoint(issuesCount, 'jira_sec_base_etl', 'jira_sec_base', job_start_time = cleanup_start_time) 

# COMMAND ----------

#logging failed keys
log_failed_keys(failed_keys_within_batch, 'rejected_jira_sec_keys')


#checking if there are any failed offsets even after retries
failed_batch_check(failed_batch)

# COMMAND ----------

display(spark.sql(f"select count(*) from {unity_catalog}.{unity_schema}.jira_sec_base limit 10"))

# COMMAND ----------

display(spark.sql(f"select * from {unity_catalog}.{unity_schema}.base_checkpoint order by last_refresh_ts_UTC desc limit 10"))
