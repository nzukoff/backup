# Databricks notebook source
!pip install jira==3.10.5
!pip install pytz==2021.3

# COMMAND ----------

import ast
import json
import re
import math
import time
from datetime import datetime, timedelta

import pandas
import pytz
from jira import JIRA
from concurrent.futures import ThreadPoolExecutor, ALL_COMPLETED
from pyspark.sql.functions import current_timestamp, lit, to_timestamp
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    DoubleType,
    TimestampType,
    DateType,
    ArrayType,
    LongType,
    IntegerType,
    FloatType
)

# COMMAND ----------

def chunk_list(input_list, chunk_size):
    for i in range(0, len(input_list), chunk_size):
        yield input_list[i:i + chunk_size]

# COMMAND ----------

secret_scope = secret_scope if 'secret_scope' in globals() else "eng-ops-health"

# COMMAND ----------

jira_api_token = dbutils.secrets.get(secret_scope, "jira_api_token")
jira_user = dbutils.secrets.get(secret_scope, "jira_username")
jira_host = dbutils.secrets.get(secret_scope, "jira_host")
options = {"server": jira_host, "rest_api_version": "3"}
jira = JIRA(options, basic_auth=(jira_user, jira_api_token))

# COMMAND ----------

def get_max_count(jql):
    issuesCount = jira.approximate_issue_count(jql, json_result=True)["count"]
    return issuesCount

# COMMAND ----------

def fetch_issues_from_jira(jql, parse_type, make_dump=False):
    def fetch_and_update_tickets(next_page_token=None):
        time.sleep(0.5)
        RESULTS_PER_PAGE = 100
        all_issues = {}
        all_issues_raw = {}

        try:
            # Use enhanced_search_issues with nextPageToken
            issues = jira.enhanced_search_issues(
                jql, 
                nextPageToken=next_page_token, 
                maxResults=RESULTS_PER_PAGE
            )
            
            print(f"Processing issues: {len(issues)}")
            
            for issue in issues:
                try:
                    all_issues[issue.key] = parse_type(issue)
                    if make_dump:
                        all_issues_raw[issue.key] = parse_issue_raw_dump(issue)
                except Exception as e:
                    print(f"error {e} for issue {issue.key}")
                    failed_keys_within_batch.append((issue.key, str(e)))

            issues_list.extend(list(all_issues.values()))
            issues_raw_list.extend(list(all_issues_raw.values()))
            
            # Get next page token if available
            next_token = getattr(issues, 'nextPageToken', None)
            return next_token
            
        except Exception as e:
            print(f"Exception occurred with token {next_page_token}: {str(e)}")
            time.sleep(1)
            failed_batch.append(next_page_token)
            return None

    # Initialize lists to store results
    failed_batch = []
    issues_list = []
    issues_raw_list = []
    failed_keys_within_batch = []
    
    # Start fetching with no token (first page)
    current_token = None
    
    while True:
        try:
            next_token = fetch_and_update_tickets(current_token)
            if not next_token:
                break
            current_token = next_token
        except Exception as e:
            print(f"Failed to fetch page: {str(e)}")
            failed_batch.append(current_token)
            break

    print(f"Total issues processed - {len(issues_list)}")

    # Retry failed batches
    if failed_batch:
        print(f"Retrying failed tokens: {failed_batch}")
        for token in failed_batch[:]:  # Copy list to iterate
            try:
                fetch_and_update_tickets(token)
                failed_batch.remove(token)
            except Exception as e:
                print(f"Retry failed for token {token}: {str(e)}")

        print(f"Total issues processed including retry run - {len(issues_list)}")

    return issues_list, issues_raw_list, failed_keys_within_batch, failed_batch

# COMMAND ----------

def incremental_range(pipeline_name):

    lastUpdatedfrom = sql(
        f"select date_format(max(jql_lastUpdatedTo) - INTERVAL '10' minutes,'yyyy-MM-dd HH:mm') lastUpdatedfrom from {unity_catalog}.{unity_schema}.base_checkpoint where pipeline_name='{pipeline_name}' "
    ).first()["lastUpdatedfrom"]

    lastUpdatedTo = sql(
        "select date_format(from_utc_timestamp(current_timestamp(), 'PST'),'yyyy-MM-dd HH:mm') lastUpdatedTo "
    ).first()["lastUpdatedTo"]

    return lastUpdatedfrom, lastUpdatedTo

# COMMAND ----------

def update_checkpoint(issuesCount, pipeline_name, table_name, lastUpdatedFrom=None, lastUpdatedTo=None, job_start_time=None):

    if lastUpdatedFrom and lastUpdatedTo:
        sql(
            f"insert into {unity_catalog}.{unity_schema}.base_checkpoint select '{pipeline_name}' as pipeline_name,'{table_name}' as table_name,cast('{lastUpdatedFrom}'||':00' as timestamp) as jql_lastUpdatedfrom,cast('{lastUpdatedTo}'||':00' as timestamp) as jql_lastUpdatedTo, '{issuesCount}' as affected_rows, to_utc_timestamp('{lastUpdatedTo}'||':00','PST') as last_refresh_ts_UTC"
        )
    else:
        sql(
            f"insert into {unity_catalog}.{unity_schema}.base_checkpoint select '{pipeline_name}' as pipeline_name,'{table_name}' as table_name, null as jql_lastUpdatedfrom, null as jql_lastUpdatedTo, '{issuesCount}' as affected_rows, '{job_start_time}' as last_refresh_ts_UTC"
        )

    print("Added the delta entry in base_checkpoint table.")

# COMMAND ----------

def parse_issue_raw_dump(issue):
    return {
        "key": issue.key,
        "created": parse_date(issue.fields.created),
        "updated": parse_date(issue.fields.updated),
        # "data": issue.raw,
    }


jira_schema_raw_dump = StructType(
    [
        StructField("key", StringType(), True),
        StructField("updated", TimestampType(), True),
        StructField("created", TimestampType(), True),
        # StructField("data", StringType(), True),
    ]
)

# COMMAND ----------

def extract_text_from_adf(node, level=0):
    """
    Comprehensive ADF (Atlassian Document Format) text extractor
    Handles all node types and preserves formatting structure
    """
    if not node:
        return ""

    if isinstance(node, str):
        return node

    if isinstance(node, list):
        return ''.join(extract_text_from_adf(item, level) for item in node)

    if not isinstance(node, dict):
        return str(node)

    node_type = node.get('type', '')
    content = node.get('content', [])
    text = node.get('text', '')

    # Handle text nodes
    if node_type == 'text':
        # Apply formatting marks to text
        marks = node.get('marks', [])
        formatted_text = text

        # Check for link first (has priority)
        for mark in marks:
            if mark.get('type') == 'link':
                url = mark.get('attrs', {}).get('href', '')
                if url and text:
                    formatted_text = f'[{formatted_text}|{url}]'
                    return formatted_text

        # Apply other formatting marks
        for mark in marks:
            mark_type = mark.get('type', '')
            if mark_type == 'strong':
                # Only add asterisks if the text doesn't already have them
                if not (formatted_text.startswith('*') and formatted_text.endswith('*')):
                    formatted_text = f'*{formatted_text}*'
            elif mark_type == 'em':
                if not (formatted_text.startswith('_') and formatted_text.endswith('_')):
                    formatted_text = f'_{formatted_text}_'
            elif mark_type == 'underline':
                if not (formatted_text.startswith('+') and formatted_text.endswith('+')):
                    formatted_text = f'+{formatted_text}+'
            elif mark_type == 'strike':
                if not (formatted_text.startswith('-') and formatted_text.endswith('-')):
                    formatted_text = f'-{formatted_text}-'
            elif mark_type == 'code':
                if not (formatted_text.startswith('{') and formatted_text.endswith('}')):
                    formatted_text = f'{{{formatted_text}}}'

        return formatted_text

    # Handle different block types
    elif node_type == 'doc':
        return extract_text_from_adf(content, level)

    elif node_type == 'paragraph':
        para_text = extract_text_from_adf(content, level)
        # Clean up any formatting issues like "*text:\n*" -> "*text:*"
        para_text = para_text.replace(':\n*', ':*').replace('*\n\n', '*\n\n')
        return para_text + '\n\n' if para_text.strip() else ''

    elif node_type == 'heading':
        attrs = node.get('attrs', {})
        heading_level = attrs.get('level', 1)
        heading_text = extract_text_from_adf(content, level)
        prefix = '#' * heading_level + ' '
        return prefix + heading_text + '\n\n'

    elif node_type == 'blockquote':
        quoted_text = extract_text_from_adf(content, level + 1)
        lines = quoted_text.split('\n')
        quoted_lines = ['> ' + line for line in lines if line.strip()]
        return '\n'.join(quoted_lines) + '\n\n'

    elif node_type == 'codeBlock':
        attrs = node.get('attrs', {})
        language = attrs.get('language', '')
        code_text = extract_text_from_adf(content, level)
        return f'```{language}\n{code_text}\n```\n\n'

    elif node_type == 'bulletList':
        list_items = []
        for item in content:
            if item.get('type') == 'listItem':
                item_text = extract_text_from_adf(item.get('content', []), level + 1)
                list_items.append('- ' + item_text.strip())
        return '\n'.join(list_items) + '\n\n'

    elif node_type == 'orderedList':
        list_items = []
        for i, item in enumerate(content, 1):
            if item.get('type') == 'listItem':
                item_text = extract_text_from_adf(item.get('content', []), level + 1)
                list_items.append(f'{i}. ' + item_text.strip())
        return '\n'.join(list_items) + '\n\n'

    elif node_type == 'listItem':
        return extract_text_from_adf(content, level).rstrip() + '\n'

    # Table handling
    elif node_type == 'table':
        table_rows = []
        for row in content:
            if row.get('type') == 'tableRow':
                row_text = extract_text_from_adf(row, level + 1)
                table_rows.append(row_text.rstrip())
        return '\n'.join(table_rows) + '\n\n'

    elif node_type == 'tableRow':
        cells = []
        has_header = False
        for cell in content:
            if cell.get('type') == 'tableHeader':
                has_header = True
                cell_text = extract_text_from_adf(cell.get('content', []), level + 1)
                cells.append(cell_text.strip().replace('\n', ' '))
            elif cell.get('type') == 'tableCell':
                cell_text = extract_text_from_adf(cell.get('content', []), level + 1)
                cells.append(cell_text.strip().replace('\n', ' '))

        # Use JIRA table format: ||header|| for headers, |cell| for regular cells
        if has_header:
            return '||' + '||'.join(cells) + '||\n'
        else:
            return '|' + '|'.join(cells) + '|\n'

    elif node_type in ['tableCell', 'tableHeader']:
        return extract_text_from_adf(content, level)

    # Inline formatting
    elif node_type == 'hardBreak':
        return '\n'

    elif node_type == 'inlineCard':
        attrs = node.get('attrs', {})
        url = attrs.get('url', '')
        return url

    elif node_type == 'mention':
        attrs = node.get('attrs', {})
        display_name = attrs.get('text', attrs.get('displayName', ''))
        return f'@{display_name}'

    elif node_type == 'emoji':
        attrs = node.get('attrs', {})
        shortName = attrs.get('shortName', '')
        return shortName

    elif node_type == 'date':
        attrs = node.get('attrs', {})
        timestamp = attrs.get('timestamp', '')
        return timestamp

    elif node_type == 'status':
        attrs = node.get('attrs', {})
        text = attrs.get('text', '')
        return f'[{text}]'

    # Media
    elif node_type in ['mediaGroup', 'mediaSingle']:
        return extract_text_from_adf(content, level)

    elif node_type == 'media':
        attrs = node.get('attrs', {})
        alt_text = attrs.get('alt', '')
        return f'[Image: {alt_text}]' if alt_text else '[Image]'

    # Panels and layouts
    elif node_type == 'panel':
        attrs = node.get('attrs', {})
        panel_type = attrs.get('panelType', 'info')
        panel_text = extract_text_from_adf(content, level)
        return f'[{panel_type.upper()}] {panel_text}\n\n'

    elif node_type == 'expand':
        attrs = node.get('attrs', {})
        title = attrs.get('title', 'Details')
        expand_text = extract_text_from_adf(content, level)
        return f'▼ {title}\n{expand_text}\n'

    elif node_type in ['layoutSection', 'layoutColumn']:
        return extract_text_from_adf(content, level)

    # Rules and dividers
    elif node_type == 'rule':
        return '---\n\n'

    # Default case - process content if available
    elif content:
        return extract_text_from_adf(content, level)

    # If no specific handler and no content, return empty string
    return ''

def format_jira_text_field(text_data):
    """
    Extract and format any JIRA text field from ADF or plain text data
    Usage:
    - format_jira_text_field(issue.raw['fields']['description'])
    - format_jira_text_field(issue.raw['fields']['summary'])
    - format_jira_text_field(issue.raw['fields']['customfield_12300'])  # incident_tldr
    """
    try:
        # Handle None or empty text
        if not text_data:
            return ""

        # Handle string text (plain text)
        if isinstance(text_data, str):
            return text_data

        # Handle ADF format (dictionary with type/content structure)
        if isinstance(text_data, dict):
            return extract_text_from_adf(text_data)

        # Fallback for other types
        return str(text_data)

    except Exception as e:
        return f"Error extracting text: {str(e)}"    

# COMMAND ----------

# DBTITLE 1,Fetch Jira
def get_key(obj, *keys):
    if obj is None:
        return obj
    for key in keys:
        if key in obj.raw:
            return obj.raw[key]
    return None


def get_keys(obj, default, *keys):
    v = obj
    for key in keys:
        if v is None:
            return default
        v = v.get(key)
    return v


def parse_date(date_str):
    return datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S.%f%z") if date_str else None


def parse_due(due_date):
    return datetime.strptime(due_date, "%Y-%m-%d") if due_date else None


def parse_pr(issue):
    str_repr = issue.raw["fields"].get("customfield_12200", "")
    if str_repr:
        m = re.search("stateCount=(\d+)", str_repr)
        if m:
            return int(m.group(1))


def parse_sprint(i):
    sprints = i.fields.customfield_10007 or []
    return [
        {
            "name": s.name,
            "state": s.state,
            "startDate": parse_date(s.__dict__.get("startDate")),
            "completeDate": parse_date(s.__dict__.get("completeDate")),
        }
        for s in sprints
    ]


def parse_failure_cause(issue):
    field = issue.raw["fields"].get("customfield_14495")
    if field:
        return "{}-{}".format(
            field.get("value"), (field.get("child") or {}).get("value")
        )


def parse_eng_team(issue):
    field = issue.raw["fields"].get("customfield_14623")
    if field:
        txt = "{}-{}".format(
            field.get("value"), (field.get("child") or {}).get("value")
        )
        ## Currently Jira is returning a substring '-None' at the end, this is to filter it out
        ##print( txt[:-5])
        return txt[:-5]


def parse_es_components(issue):
    field = issue.raw["fields"].get("customfield_18150")
    if field:
        return field.get("value")

def parse_symptom(issue):
    field = issue.raw["fields"].get("customfield_18629")
    if field:
        return field.get("value")

def parse_engineering_rca(issue):
    field = issue.raw["fields"].get("customfield_18378")
    if field:
        return field.get("value")

def parse_oncall_triage_eng(issue):
    field = issue.raw["fields"].get("customfield_18377")
    if field:
        return field.get("value")

def parse_unintentional_breaking_change(issue):
    field = issue.raw["fields"].get("customfield_17900")
    if field:
        return field.get("value")

def parse_first_detected(issue):
    field = issue.raw["fields"].get("customfield_17901")
    if field:
        return field.get("value")

def parse_backline_triage(issue):
    field = issue.raw["fields"].get("customfield_18376")
    if field:
        return field.get("value")

def parse_version_bug_introduced(issue):
    field = issue.raw["fields"].get("customfield_18806")
    if field:
        return field.get("name")

def parse_backported_via_maintenance(issue):
    field = issue.raw["fields"].get("customfield_17902")
    if field:
        return field.get("value")

def parse_channel_detected(issue):
    field = issue.raw["fields"].get("customfield_17907")
    if field:
        return field.get("value")

def parse_mitigation_method(issue):
    field = issue.raw["fields"].get("customfield_17904")
    if field:
        return field.get("value")

def parse_pr_causing_regression(issue):
    field = issue.raw["fields"].get("customfield_18805")
    if field:
        return field.get("value")

def parse_es_product(issue):
    field = issue.raw["fields"].get("customfield_18107")
    if field:
        return field.get("value")


def parse_es_product_group(issue):
    field = issue.raw["fields"].get("customfield_18109")
    if field:
        return field.get("value")

def parse_shrtag(issue):
    field = issue.raw["fields"].get("customfield_15633")
    if field:
        return field.get("value")  

def parse_scp_customer(issue):
    field = issue.raw["fields"].get("customfield_17536")
    if(field):
        return field.get("value")

def parse_customer_escalation(issue):
    field = issue.raw["fields"].get("customfield_17537")
    if(field):
        return field.get("value")

def parse_impacted_workspaces(issue):
    field = issue.raw["fields"].get("customfield_17171")
    return field


def parse_team_lead(issue):
    field = issue.raw["fields"].get("customfield_14401")
    if(field):
        return field.get("displayName")

def parse_caused_by_cloud_provider(issue):
    field = issue.raw["fields"].get("customfield_19059")
    if(field):
        return field.get("value")
def parse_pw_estimate(issue):
    field = issue.raw["fields"].get("customfield_13503")
    if(field):
        return field
    
def parse_Related_ES_Components(issue):
    field = issue.raw["fields"].get("customfield_18152")
    if field:
        return [str(x) for x in issue.fields.customfield_18152]
    return None

def parse_issue(issue):
    return {
        "key": issue.key,
        "date": parse_date(issue.fields.created).date(),
        "summary": issue.fields.summary,
        "status": issue.fields.status.name,
        "resolution": get_key(issue.fields.resolution, "name"),
        "updated": parse_date(issue.fields.updated),
        "created": parse_date(issue.fields.created),
        "outage_start_date": parse_date(issue.fields.customfield_12301),
        "outage_end_date": parse_date(issue.fields.customfield_12302),
        "resolutiondate": parse_date(issue.fields.resolutiondate),
        "statuscategorychangedate": parse_date(issue.fields.statuscategorychangedate),
        "type": issue.fields.issuetype.name,
        "summary": issue.fields.summary,
        "description": format_jira_text_field(issue.raw['fields']['description']),
        "eng_team": parse_eng_team(issue),
        "workspace_id": issue.raw["fields"].get("customfield_11600"),
        "story_points": issue.raw["fields"].get("customfield_10004"),
        "eng_org": issue.raw["fields"].get("customfield_14400"),
        # 'creator': get_key(issue.fields.creator, 'emailAddress', 'displayName'),
        "creator": get_key(issue.fields.creator, "displayName"),
        "creator_email": get_key(issue.fields.creator, "emailAddress"),
        "labels": [] if (issue.fields.labels) is None else [str(x) for x in issue.fields.labels],
        "components": [x.name for x in issue.fields.components],
        "assignee": get_key(issue.fields.assignee, "displayName"),
        "assignee_email": get_key(issue.fields.assignee, "emailAddress"),
        "severity": get_keys(issue.raw["fields"], "Undefined", "customfield_11500", "value"),
        # 'priority': str(issue.fields.customfield_15037),
        "priority": get_keys(issue.raw["fields"], "None", "priority", "name"),
        "affectsversions": [] if (issue.fields.versions) is None else [str(x) for x in issue.fields.versions],
        "signoffconclusion": str(issue.fields.customfield_15789),
        "regression": str(issue.fields.customfield_14246),
        "regression_caused_by": str(issue.fields.customfield_14992),
        "external_customer_facing": str(issue.fields.customfield_14677),
        "fixversions": [] if (issue.fields.fixVersions) is None else [str(x) for x in issue.fields.fixVersions],
        "incident_tldr": format_jira_text_field(issue.raw['fields']['customfield_12300']),
        "postmortem_quarterly_review": str(issue.fields.customfield_14394),
        "desc_justification": str(issue.fields.customfield_14339),
        "reviewers": [] if (issue.fields.customfield_14231) is None else [str(x) for x in issue.fields.customfield_14231],
        "salesforce_case_number": [] if (issue.fields.customfield_14294) is None else [str(x) for x in issue.fields.customfield_14294],
        "linkedissues": len(issue.fields.issuelinks),
        "inwardissues": sum([hasattr(x, "inwardIssue") for x in issue.fields.issuelinks]),
        "outwardissues": sum([hasattr(x, "outwardIssue") for x in issue.fields.issuelinks]),
        "pr_count": parse_pr(issue),
        "test_failure_reason": parse_failure_cause(issue),
        "duedate": parse_due(issue.fields.duedate),
        "mitigated_time": parse_date(issue.fields.customfield_15638),
        "pw_estimate": parse_pw_estimate(issue),
        "sprints": parse_sprint(issue) or [],
        "shrtag": parse_shrtag(issue),
        "shrdate": parse_due(getattr(issue.fields, "customfield_15634", None)),
        "shrlabels": [] if (getattr(issue.fields, "customfield_16938", None)) is None else [str(x) for x in issue.fields.customfield_16938],
        "ES_Components": parse_es_components(issue),
        "Related_ES_Components": parse_Related_ES_Components(issue),
        "ES_Product_Group": parse_es_product_group(issue),
        "ES_Product": parse_es_product(issue),
        "symptom": parse_symptom(issue),
        "backline_triage": parse_backline_triage(issue),
        "oncall_triage_eng": parse_oncall_triage_eng(issue),
        "engineering_rca": parse_engineering_rca(issue),
        "unintentional_breaking_change": parse_unintentional_breaking_change(issue),
        "first_detected": parse_first_detected(issue),
        "version_bug_introduced": parse_version_bug_introduced(issue),
        "backported_via_maintenance": parse_backported_via_maintenance(issue),
        "date_bug_found": parse_due(issue.fields.customfield_17903),
        "products_affected": [] if (issue.fields.customfield_18461) is None else [str(x) for x in issue.fields.customfield_18461],
        "channel_detected": parse_channel_detected(issue),
        "shiproom_cm": issue.fields.customfield_17908,
        "mitigation_method": parse_mitigation_method(issue),
        "pr_causing_regression": issue.fields.customfield_18805,
        "cause": [] if (issue.fields.customfield_14725) is None else [str(x) for x in issue.fields.customfield_14725],
        "postmortem_url":issue.fields.customfield_11601,
        "environment_type":[] if (issue.fields.customfield_14236) is None else [str(x) for x in issue.fields.customfield_14236],
        "icm_ticktets":issue.fields.customfield_14279,
        "customer_escalation":parse_customer_escalation(issue),
        "scp_customer":parse_scp_customer(issue),
        "impacted_workspaces": parse_impacted_workspaces(issue),
        "team_lead": parse_team_lead(issue),
        "caused_by_cloud_provider":parse_caused_by_cloud_provider(issue),
        "assignee_bounce_rate": issue.fields.customfield_18151,
        "es_component_bounce_rate": issue.fields.customfield_18705,
        "last_commented_time": issue.fields.customfield_21320,
        "eng_team_bounce_rate": issue.fields.customfield_17822,
        "support_severity_bounce_rate": issue.fields.customfield_17954,
        "severity_change": getattr(issue.fields.customfield_23436, 'value', None) if issue.fields.customfield_23436 else None,
    }

jira_schema = StructType(
    [
        StructField("key", StringType(), True),
        StructField("date", DateType(), True),
        StructField("summary", StringType(), True),
        StructField("status", StringType(), True),
        StructField("resolution", StringType(), True),
        StructField("updated", TimestampType(), True),
        StructField("created", TimestampType(), True),
        StructField("outage_start_date", TimestampType(), True),
        StructField("outage_end_date", TimestampType(), True),
        StructField("statuscategorychangedate", TimestampType(), True),
        StructField("resolutiondate", TimestampType(), True),
        StructField("type", StringType(), True),
        StructField("description", StringType(), True),
        StructField("eng_team", StringType(), True),
        StructField("workspace_id", StringType(), True),
        StructField("story_points", DoubleType(), True),
        StructField("eng_org", StringType(), True),
        StructField("creator", StringType(), True),
        StructField("creator_email", StringType(), True),
        StructField("labels", ArrayType(StringType(), True), True),
        StructField("components", ArrayType(StringType(), True), True),
        StructField("assignee", StringType(), True),
        StructField("assignee_email", StringType(), True),
        StructField("severity", StringType(), True),
        StructField("priority", StringType(), True),
        StructField("affectsversions", ArrayType(StringType(), True), True),
        StructField("signoffconclusion", StringType(), True),
        StructField("regression", StringType(), True),
        StructField("regression_caused_by", StringType(), True),
        StructField("external_customer_facing", StringType(), True),
        StructField("fixversions", ArrayType(StringType(), True), True),
        StructField("incident_tldr", StringType(), True),
        StructField("postmortem_quarterly_review", StringType(), True),
        StructField("desc_justification", StringType(), True),
        StructField("reviewers", ArrayType(StringType(), True), True),
        StructField("salesforce_case_number", ArrayType(StringType(), True), True),
        StructField("linkedissues", LongType(), True),
        StructField("inwardissues", LongType(), True),
        StructField("outwardissues", LongType(), True),
        StructField("pr_count", LongType(), True),
        StructField("test_failure_reason", StringType(), True),
        StructField("duedate", TimestampType(), True),
        StructField("mitigated_time", TimestampType(), True),
        StructField("pw_estimate", DoubleType(), True),
        StructField(
            "sprints",
            ArrayType(
                StructType(
                    [
                        StructField("completeDate", TimestampType(), True),
                        StructField("name", StringType(), True),
                        StructField("startDate", TimestampType(), True),
                        StructField("state", StringType(), True),
                    ]
                ),
                True,
            ),
            True,
        ),
        StructField("shrtag", StringType(), True),
        StructField("shrdate", DateType(), True),
        StructField("shrlabels", ArrayType(StringType(), True), True),
        StructField("ES_Components", StringType(), True),
        StructField("Related_ES_Components", ArrayType(StringType(), True), True),
        StructField("ES_Product_Group", StringType(), True),
        StructField("ES_Product", StringType(), True),
        StructField("symptom", StringType(), True),
        StructField("backline_triage", StringType(), True),
        StructField("oncall_triage_eng", StringType(), True),
        StructField("engineering_rca", StringType(), True),
        StructField("unintentional_breaking_change", StringType(), True),
        StructField("first_detected", StringType(), True),
        StructField("version_bug_introduced", StringType(), True),
        StructField("backported_via_maintenance", StringType(), True),
        StructField("date_bug_found", DateType(), True),
        StructField("products_affected", ArrayType(StringType(), True), True),
        StructField("channel_detected", StringType(), True),
        StructField("shiproom_cm", StringType(), True),
        StructField("mitigation_method", StringType(), True),
        StructField("pr_causing_regression", StringType(), True),
        StructField("cause", ArrayType(StringType(), True), True),
        StructField("postmortem_url", StringType(), True),
        StructField("environment_type", ArrayType(StringType(), True), True),
        StructField("icm_ticktets", StringType(), True),
        StructField("customer_escalation", StringType(), True),
        StructField("scp_customer", StringType(), True),
        StructField("impacted_workspaces", DoubleType(), True),
        StructField("team_lead", StringType(), True),
        StructField("caused_by_cloud_provider", StringType(), True),
        StructField("assignee_bounce_rate", DoubleType(), True),
        StructField("es_component_bounce_rate", DoubleType(), True),
        StructField("last_commented_time", StringType(), True),
        StructField("eng_team_bounce_rate", DoubleType(), True),
        StructField("support_severity_bounce_rate", DoubleType(), True),
        StructField("severity_change", StringType(), True),

    ]
)

# COMMAND ----------

postmortems_schema = StructType(
    [
        StructField("key", StringType(), True),
        StructField("project", StringType(), True),
        StructField("status", StringType(), True),
        StructField("created", TimestampType(), True),
        StructField("updated", TimestampType(), True),
        StructField("resolution", StringType(), True),
        StructField("resolutiondate", TimestampType(), True),
        StructField("assignee", StringType(), True),
        StructField("assignee_email", StringType(), True),
        StructField("reporter", StringType(), True),
        StructField("parent", StringType(), True),
        StructField("components", ArrayType(StringType()), True),
        StructField("category", StringType(), True),
        StructField("duedate", TimestampType(), True),
        StructField("summary", StringType(), True),
        StructField("priority", StringType(), True),
        StructField("ES_Components", StringType(), True),
        StructField("Related_ES_Components", ArrayType(StringType(), True), True),
        StructField("ES_Product_Group", StringType(), True),
        StructField("ES_Product", StringType(), True),
        StructField("person_week_estimtate", StringType(), True)
    ]
)


def parse_postmortems_issue(ticket):
    def get_key(obj, *keys):
        if obj is None:
            return obj
        for key in keys:
            if key in obj.raw:
                return obj.raw[key]
        return None

    def get_keys(obj, default, *keys):
        v = obj
        for key in keys:
            if v is None:
                return default
            v = v.get(key)
        return v

    search_strings = [
        "postmortem-followup",
        "postmortem-followup-short-term",
        "postmortem-followup-long-term",
    ]

    pm_category = ""
    labels_string = [label for label in ticket.fields.labels]
    if any(s in labels_string for s in search_strings):
        # Filter the input list to get only the search strings that are present,
        # and then find the maximum of those
        pm_category = max(s for s in search_strings if s in labels_string)
        # print(pm_category)  # This will print: postmortem-followup-short-term
    else:
        print("None of the specified strings are present in the input list.")

    return {
        "key": ticket.key,
        "project": ticket.fields.project.key,
        "status": ticket.fields.status.name,
        "created": parse_date(ticket.fields.created),
        "updated": parse_date(ticket.fields.updated),
        "resolution": getattr(ticket.fields.resolution, "name", None),
        "resolutiondate": parse_date(
            ticket.fields.resolutiondate if ticket.fields.resolutiondate else None
        ),
        "assignee": ticket.fields.assignee.displayName if hasattr(ticket.fields, "assignee") and ticket.fields.assignee else None,
        "assignee_email": getattr(ticket.fields.assignee, "emailAddress", None),
        "reporter": ticket.fields.reporter.displayName if ticket.fields.reporter else None,
        "parent": ticket.fields.parent.key if hasattr(ticket.fields, "parent") else None,
        "components": [component.name for component in ticket.fields.components],
        "category": pm_category,
        "duedate": parse_due(ticket.fields.duedate if ticket.fields.duedate else None),
        "summary": ticket.fields.summary,
        "priority": get_keys(ticket.raw["fields"], "None", "priority", "name"),
        "ES_Components": get_keys(ticket.raw["fields"], "None", "customfield_18150", "value"),
        "Related_ES_Components": parse_Related_ES_Components(ticket),
        "ES_Product_Group": parse_es_product_group(ticket),
        "ES_Product": parse_es_product(ticket),
        "person_week_estimtate": parse_pw_estimate(ticket)
    }


# COMMAND ----------

def log_failed_keys(failed_keys_within_batch, reject_keys_table):
    if failed_keys_within_batch:
        print(f"writing failed keys to {reject_keys_table}")
        df_failed = spark.createDataFrame(failed_keys_within_batch, ["key", "error"])
        df_failed = df_failed.withColumn("processTimestamp", current_timestamp())
        df_failed.write.mode("append").saveAsTable(
            f"{unity_catalog}.{unity_schema}.{reject_keys_table}"
        )
        return df_failed

# COMMAND ----------

def failed_batch_check(failed_batch):
    if failed_batch:
        print(f"Failed to fetch all the tickets for the given offsets - {failed_batch} ")
        print("Please backfill")
        raise Exception(f"Failed to fetch all the tickets of the run.")

# COMMAND ----------

def getReconParam(pipeline_name):
    _t = spark.sql(
        f"""select 
              date_format(max(jql_lastUpdatedTo) - interval 48 hour,'yyyy-MM-dd HH:mm') as checking_from,
              date_format(max(jql_lastUpdatedTo),'yyyy-MM-dd HH:mm') as checking_till
            from
              {unity_catalog}.{unity_schema}.base_checkpoint
            where
              pipeline_name = '{pipeline_name}'
         """
    ).collect()
    checking_from = _t[0][0]
    checking_till = _t[0][1]
    return checking_from, checking_till


def getCountJira(jql):
    return get_max_count(jql)


def getCountBaseTables(sql):
    return spark.sql(sql).collect()[0][0]

# COMMAND ----------

def parse_fnf_issue(issue):
    return {
        "key": issue.key,
        "project": issue.fields.project.key,   
        "date": parse_date(issue.fields.created).date(),
        "summary": issue.fields.summary,
        "status": issue.fields.status.name,
        "resolution": get_key(issue.fields.resolution, "name"),
        "updated": parse_date(issue.fields.updated),
        "created": parse_date(issue.fields.created),
        "resolutiondate": parse_date(issue.fields.resolutiondate),
        "statuscategorychangedate": parse_date(issue.fields.statuscategorychangedate),
        "type": issue.fields.issuetype.name,
        "description": extract_description(issue.fields.description),
        "eng_team": parse_eng_team(issue),
        "workspace_id": issue.raw["fields"].get("customfield_11600"),
        "eng_org": issue.raw["fields"].get("customfield_14400"),
        "creator": get_key(issue.fields.creator, "displayName"),
        "creator_email": get_key(issue.fields.creator, "emailAddress"),
        "labels": [] if (issue.fields.labels) is None else [str(x) for x in issue.fields.labels],
        "assignee": get_key(issue.fields.assignee, "displayName"),
        # "assignee_email": get_key(issue.fields.assignee, "emailAddress"),
        "severity": get_keys(issue.raw["fields"], "Undefined", "customfield_11500", "value"),
        "priority": get_keys(issue.raw["fields"], "None", "priority", "name"),
        "ES_Components": parse_es_components(issue),
        "name_of_the_launch": getattr(issue.fields, 'customfield_18785', None),
        "likelihood": getattr(issue.fields, 'customfield_17607', None),
        "impact": getattr(issue.fields, 'customfield_14760', None),
        "score": getattr(issue.fields, 'customfield_17608', None),
        "cuj": getattr(issue.fields, 'customfield_17601', None),
        "brickReady_priority": getattr(issue.fields, 'customfield_15037', None),
    }

fnf_schema = StructType(
    [
        StructField("key", StringType(), True),
        StructField("project", StringType(), True),
        StructField("date", DateType(), True),
        StructField("summary", StringType(), True),
        StructField("status", StringType(), True),
        StructField("resolution", StringType(), True),
        StructField("updated", TimestampType(), True),
        StructField("created", TimestampType(), True),
        StructField("statuscategorychangedate", TimestampType(), True),
        StructField("resolutiondate", TimestampType(), True),
        StructField("type", StringType(), True),
        StructField("description", StringType(), True),
        StructField("eng_team", StringType(), True),
        StructField("workspace_id", StringType(), True),
        StructField("eng_org", StringType(), True),
        StructField("creator", StringType(), True),
        StructField("creator_email", StringType(), True),
        StructField("labels", ArrayType(StringType(), True), True),
        StructField("assignee", StringType(), True),
        StructField("severity", StringType(), True),
        StructField("priority", StringType(), True),
        StructField("ES_Components", StringType(), True),
        StructField("name_of_the_launch", StringType(), True),
        StructField("likelihood", StringType(), True),
        StructField("impact", StringType(), True),
        StructField("score", StringType(), True),
        StructField("cuj", StringType(), True),
        StructField("brickReady_priority", StringType(), True),
    ]
)

# COMMAND ----------

def parse_sec_issue(issue):
  json_data = issue.raw
  issue = {}
  element = json_data['fields']
  issue['key'] = json_data['key']
  issue['updated'] = parse_date(element['updated'])
  links = ''
  if(element['issuelinks']):
    for l in element['issuelinks']:
      if "outwardIssue" in l:
        links += l['outwardIssue']['key'] + ','
      if "inwardIssue" in l:
        links += l['inwardIssue']['key'] + ','
  issue['links'] = links[:-1]
  if element['assignee']:
    issue['assignee'] = element['assignee']['displayName']
  else:
    issue['assignee'] = 'None'
  if element['reporter']:
    issue['reporter'] = element['reporter']['displayName']
  else:
    issue['reporter'] = 'None'
  issue['summary'] = element['summary']
  # issue['description'] = element['description']
  issue['labels'] = element['labels']
  issue['duedate'] = parse_due(element['duedate'])
  issue['status'] = element['status']['name']
  # issue['source'] = element['customfield_14310']['value']
  # Guess work on which custom field is the RESOLUTION DATE. custom_14367 is another candidate, but it is empty in some cases.
  if element['customfield_14767']:
    issue['severity'] = element['customfield_14767']['value']
  else:
    issue['severity'] = 'None'
  if element['customfield_17157']:
    issue['business_acknowledgement'] = element['customfield_17157']['value']
  else:
    issue['business_acknowledgement'] = 'None'
  if element['customfield_15886']:
    issue['target_remediation_date'] = element['customfield_15886'].strip()
  else:
    issue['target_remediation_date'] = 'None'
  if element['customfield_15889']:
    issue['remediation_status'] = element['customfield_15889']['value']
  else:
    issue['remediation_status'] = 'TBD'
  if element['customfield_15890']:
    issue['issue_remediation_owner'] = element['customfield_15890']['displayName']
  else:
    issue['issue_remediation_owner'] = 'TBD'
  if element['customfield_15898']:
    issue['issue_source'] = element['customfield_15898']['value']
  else:
    issue['issue_source'] = 'None'
  if element['customfield_17156']:
    issue['stakeholders'] = element['customfield_17156']['value']
  else:
    issue['stakeholders'] = 'None'
  if element['customfield_17164']:
    issue['owner_commitment_status'] = element['customfield_17164']['value']
  else:
    issue['owner_commitment_status'] = 'None'
  if element['customfield_17638']:
    issue['E-Staff'] = element['customfield_17638']['value']
  else:
    issue['E-Staff'] = 'TBD'
  issue['created'] = parse_date(element['created'])
  issue['sla-duedate'] = parse_due(element['customfield_14696'])
  return issue

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, ArrayType, TimestampType

sec_schema = StructType([
    StructField("key", StringType(), True),
    StructField("updated", TimestampType(), True),
    StructField("links", StringType(), True),
    StructField("assignee", StringType(), True),
    StructField("reporter", StringType(), True),
    StructField("summary", StringType(), True),
    # StructField("description", StringType(), True),
    StructField("labels", ArrayType(StringType(), True), True),
    StructField("duedate", TimestampType(), True),
    StructField("status", StringType(), True),
    StructField("severity", StringType(), True),
    StructField("business_acknowledgement", StringType(), True),
    StructField("target_remediation_date", StringType(), True),
    StructField("remediation_status", StringType(), True),
    StructField("issue_remediation_owner", StringType(), True),
    StructField("issue_source", StringType(), True),
    StructField("stakeholders", StringType(), True),
    StructField("owner_commitment_status", StringType(), True),
    StructField("E-Staff", StringType(), True),
    StructField("created", TimestampType(), True),
    StructField("sla-duedate", TimestampType(), True)
])
