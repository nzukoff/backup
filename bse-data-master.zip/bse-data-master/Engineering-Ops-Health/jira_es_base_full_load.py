# Databricks notebook source
# MAGIC %run ./eng_ops_health_config

# COMMAND ----------

# MAGIC %run ./jira_etl_utils

# COMMAND ----------

jql = "project = ES"

# COMMAND ----------

total_tickets = get_max_count(jql)
print(f"total_tickets_updated = {total_tickets}")
if total_tickets == 0:
  dbutils.notebook.exit("There are no new tickets. Stopping notebook execution.")

# COMMAND ----------

block_size = 100
blocks = (total_tickets // block_size) + 1
data = [(i * block_size,) for i in range(blocks)]
schema = ["startAt"]
df = spark.createDataFrame(data, schema=schema)
df = df.repartition(720) #15*16*3 core_each_worker, no_of_workers, 3
display(df.orderBy("startAt"))

# COMMAND ----------

def fetch_and_update_tickets(start_at):
    all_issues = {} 
    options = {
        'server': jira_host
    }

    jira = JIRA(options, basic_auth=(jira_user, jira_api_token))
    
    # try:
    tickets = jira.search_issues(jql, startAt=start_at, maxResults=block_size)
    for ticket in tickets:
        # try:
        all_issues[ticket.key] = parse_issue(ticket)
        # except Exception as e:
            # all_issues[ticket.key] = None
    # except:
    #     pass
        # all_issues[ticket.key] = None
    
    data = list(all_issues.values())
    
    return data#[str(iss) for iss in data]

# COMMAND ----------

udf_fetch_tickets = udf(fetch_and_update_tickets, ArrayType(jira_schema))
df = df.withColumn("tickets_array", udf_fetch_tickets("startAt"))
df.cache()
count = df.count()
print(f'count = {count}')

# COMMAND ----------

display(df.orderBy("startAt"))

# COMMAND ----------

from pyspark.sql.functions import col, explode
df_normalized = df.withColumn("ticket", explode("tickets_array")).drop("tickets_array", "startAt")
df_normalized.cache()
display(df_normalized.count())

# COMMAND ----------

from pyspark.sql import functions as F
df_new = df_normalized
exploded_df = df_new.select(F.col('ticket.*'))

exploded_df = exploded_df.drop('ticket')
exploded_df.cache()
display(exploded_df.count())
display(exploded_df)

# COMMAND ----------

display(exploded_df.count())

# COMMAND ----------

from pyspark.sql.window import Window

window = Window.partitionBy('key').orderBy(F.col('updated').desc())

ranked_df = exploded_df.withColumn('rank', F.rank().over(window)).filter('rank == 1').drop('rank')

# COMMAND ----------

display(ranked_df.count())

# COMMAND ----------

ranked_df \
    .write \
    .mode('overwrite') \
    .format('delta') \
    .saveAsTable(f'{unity_catalog}.{unity_schema}.jira_es_base')

# COMMAND ----------


