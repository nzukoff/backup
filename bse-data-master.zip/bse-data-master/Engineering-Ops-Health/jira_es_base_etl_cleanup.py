# Databricks notebook source
!pip install jira==3.5.2
!pip install pytz==2021.3

# COMMAND ----------

# MAGIC %run ./eng_ops_health_config

# COMMAND ----------

# MAGIC %run ./jira_etl_utils

# COMMAND ----------

jira_api_token = dbutils.secrets.get('eng-ops-health','jira_api_token')
jira_user = dbutils.secrets.get('eng-ops-health','jira_username')
jira_host = dbutils.secrets.get('eng-ops-health','jira_host')
options = {
    'server': jira_host
}
jira = JIRA(options, basic_auth=(jira_user, jira_api_token))

# COMMAND ----------

def chunk_list(input_list, chunk_size):
    for i in range(0, len(input_list), chunk_size):
        yield input_list[i:i + chunk_size]


def merge_es_issues(issues):
    df1 = spark.createDataFrame(issues, schema=jira_schema)
    df1.createOrReplaceTempView("es_tickets_tmp")
    display(spark.sql(f"""
      MERGE INTO {unity_catalog}.{unity_schema}.jira_es_base old
      USING es_tickets_tmp new
      ON old.key = new.key
      WHEN MATCHED THEN UPDATE SET *
      WHEN NOT MATCHED THEN INSERT *
   """))

# COMMAND ----------

from concurrent.futures import ThreadPoolExecutor
import timeit
import math

# sql_string=f"""select distinct key from {unity_catalog}.{unity_schema}.jira_es_base where status in ("TO DO", "In Progress","To Do","Open","In Review","On Hold") and type in ('Incident','Test Failure') """
# sql_string=f"""select distinct key from {unity_catalog}.{unity_schema}.jira_es_base where status not in ("Resolved") and type in ('Incident','Test Failure') """
cleanup_start_time = sql("select current_timestamp() as cleanup_start_time ").first()['cleanup_start_time']

sql_string=f"""SELECT DISTINCT key FROM {unity_catalog}.{unity_schema}.jira_es_base WHERE status NOT IN ('Resolved') AND (type != 'Test Failure (sub-task)' OR (updated > date_add(now(), -2)))"""
df = spark.sql(sql_string)
table_keys=[x.key for x in df.collect()]
issuesCount = len(table_keys)
print(issuesCount)
key_chunks = [chunk for chunk in chunk_list(table_keys, 100)]
pool_size = 5

# COMMAND ----------

failed_batch = []
issues_list = []
deleted_tickets = []
updated_ticket_list = []
def fetch_and_update_tickets(chunk):
  try: 
    time.sleep(0.25)
    block_size = 100
    all_issues = {}
    jql = f"project='ES' and key in ({','.join(chunk)})"
    # print("fetching issue",chunk)
    tickets = jira.search_issues(jql,maxResults=block_size)
    for ticket in tickets:
      try:
        all_issues[ticket.key] = parse_issue(ticket)
      except Exception as e:
        # print(f"error {e} for issue {ticket.key}")
        print(f"error for issue {ticket.key}")
    # print('all_keys',list(all_issues.keys()))
    ticket_not_found_in_jira = [x for x in chunk if x not in all_issues.keys()]
    deleted_tickets.extend(ticket_not_found_in_jira)
    ticket_found_in_jira = [x for x in chunk if x in all_issues.keys()]
    update_tickets=[all_issues.get(x) for x in ticket_found_in_jira]
    updated_ticket_list.extend(ticket_found_in_jira)
    issues_list.extend(update_tickets)
    print(f"fetched {len(issues_list)} out of {issuesCount}: {round(len(issues_list)*100/issuesCount,2)}%")
  except:
    print("exception occourred at ", chunk)
    time.sleep(0.5)
    failed_batch.append(chunk)

# COMMAND ----------

with ThreadPoolExecutor(max_workers=pool_size) as pool:
    futures = [pool.submit(fetch_and_update_tickets, x) for x in key_chunks]
    for future in futures:
        future.result()
print('deleted_tickets',deleted_tickets)
# print('update_tickets',updated_ticket_list)

merge_es_issues(issues_list)
if deleted_tickets:
  display(spark.sql(f"""delete from {unity_catalog}.{unity_schema}.jira_es_base WHERE key IN ( {', '.join({f'"{value}"' for value in deleted_tickets})})"""))

processed_tickets = len(deleted_tickets)
sql(f"insert into {unity_catalog}.{unity_schema}.base_checkpoint select 'jira_es_base_etl_cleanup' as pipeline_name,'jira_es_base' as table_name, null as jql_lastUpdatedfrom, null as jql_lastUpdatedTo, {processed_tickets} as affected_rows, '{cleanup_start_time}' as last_refresh_ts_UTC")

# COMMAND ----------

df = spark.sql(f"""select distinct key from {unity_catalog}.{unity_schema}.jira_es_base""")
table_key=[x.key for x in df.collect()]
max_ticket=spark.sql(f'select  key from {unity_catalog}.{unity_schema}.jira_es_base order by created desc limit 1').collect()[0]
y = [f'ES-{i}' for i in range(1,int(max_ticket.key.split('-')[-1]))]
unfinished=list(set(y)-set(table_key))
issuesCount = len(unfinished)
print(issuesCount)
key_chunks = [chunk for chunk in chunk_list(unfinished, 100)]
failed_batch = []
issues_list = []
deleted_tickets = []
updated_ticket_list = []

# COMMAND ----------

# DBTITLE 1,There should be no insert/update logs in this block
with ThreadPoolExecutor(max_workers=pool_size) as pool:
    futures = [pool.submit(fetch_and_update_tickets, x) for x in key_chunks]
    for future in futures:
        future.result()
print('deleted_tickets',deleted_tickets)
print('update_tickets',updated_ticket_list)

merge_es_issues(issues_list)

if deleted_tickets:
  display(spark.sql(f"""delete from {unity_catalog}.{unity_schema}.jira_es_base WHERE key IN ( {', '.join({f'"{value}"' for value in deleted_tickets})})"""))


# COMMAND ----------

display(spark.sql(f"""OPTIMIZE `{unity_catalog}`.`{unity_schema}`.jira_es_base"""))

# COMMAND ----------


