# Databricks notebook source
# MAGIC %run ./eng_ops_health_config

# COMMAND ----------

# MAGIC %run ./jira_etl_utils

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql.functions import when, col, lit
  
def overwrite_fnf_issues(issues):
    df1 = spark.createDataFrame(issues, schema=fnf_schema)
    df1.createOrReplaceTempView("fnf_tickets_tmp_all")
    sql("select *, row_number() over (partition by key order by updated desc) as RN from fnf_tickets_tmp_all").createOrReplaceTempView('fnf_tickets_tmp_rn')
    dups = sql("select count(*) as cnt from fnf_tickets_tmp_rn where RN>1").first()['cnt']
    #print(dups)
    if dups > 0:
        print("Displaying duplicates ...")
        display(sql("select * from fnf_tickets_tmp_rn where key in (select distinct key from fnf_tickets_tmp_rn where RN>1) "))

    sql("select * from fnf_tickets_tmp_rn where RN=1").drop("RN").createOrReplaceTempView('fnf_tickets_tmp')
    display(sql("select * from fnf_tickets_tmp"))
    
    print("overwriting fnf table")
    
    display(spark.sql(f"""
    CREATE OR REPLACE TABLE {unity_catalog}.{unity_schema}.fnf_base as
    SELECT * FROM fnf_tickets_tmp;
    """))

# COMMAND ----------

current_date = datetime.now()
formatted_current_date = current_date.strftime("%Y-%m-%d")

cleanup_start_time = sql("select current_timestamp() as cleanup_start_time ").first()['cleanup_start_time']

jql = f'''project in (BR, BRRD, FEEDBACK)'''

print(f"\nJQL - {jql}")

# COMMAND ----------

issuesCount = get_max_count(jql)
print(f"Total issues count received from source - {issuesCount}")

# COMMAND ----------

issues_list, issues_raw_list,failed_keys_within_batch, failed_batch  = fetch_issues_from_jira(jql, parse_fnf_issue, False)

# COMMAND ----------

overwrite_fnf_issues(issues_list)

# COMMAND ----------

update_checkpoint(issuesCount, 'fnf_full_load_etl', 'fnf_base', job_start_time = cleanup_start_time) 

# COMMAND ----------

# logging failed keys
log_failed_keys(failed_keys_within_batch, 'rejected_fnf_jira_keys')

# checking if there are any failed offsets even after retries
failed_batch_check(failed_batch)

# COMMAND ----------

display(spark.sql(f"select count(*) from {unity_catalog}.{unity_schema}.fnf_base limit 10"))

# COMMAND ----------

display(spark.sql(f"select * from {unity_catalog}.{unity_schema}.base_checkpoint order by last_refresh_ts_UTC desc limit 10"))

# COMMAND ----------


