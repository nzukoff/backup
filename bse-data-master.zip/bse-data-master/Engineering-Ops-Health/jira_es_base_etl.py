# Databricks notebook source
# MAGIC %run ./eng_ops_health_config

# COMMAND ----------

# MAGIC %run ./jira_etl_utils

# COMMAND ----------

try:
  backfill_hours = dbutils.widgets.get("backfill_hours").lower()
except:
  backfill_hours = None

# COMMAND ----------

try:
  jql = dbutils.widgets.get("jql").lower()
except:
  jql = None

# COMMAND ----------

def merge_es_issues(issues):
    df1 = spark.createDataFrame(issues, schema=jira_schema)
    df1 = df1.withColumn("last_commented_time", to_timestamp("last_commented_time", "yyyy-MM-dd'T'HH:mm:ss.SSSZ"))
    df1.createOrReplaceTempView("es_tickets_tmp_all")
    sql("select *, row_number() over (partition by key order by updated desc) as RN from es_tickets_tmp_all").createOrReplaceTempView('es_tickets_tmp_rn')
    dups = sql("select count(*) as cnt from es_tickets_tmp_rn where RN>1").first()['cnt']
    #print(dups)
    if dups > 0:
        print("Displaying duplicates ...")
        display(sql("select * from es_tickets_tmp_rn where key in (select distinct key from es_tickets_tmp_rn where RN>1) "))

    sql("select * from es_tickets_tmp_rn where RN=1").drop("RN").createOrReplaceTempView('es_tickets_tmp')
    display(sql("select * from es_tickets_tmp"))
    print("Merging the source date into the target - jira_es_base")
    display(spark.sql(f"""
      MERGE INTO {unity_catalog}.{unity_schema}.jira_es_base old
      USING es_tickets_tmp new
      ON old.key = new.key
      WHEN MATCHED THEN UPDATE SET *
      WHEN NOT MATCHED THEN INSERT *
   """))

def append_es_raw_dump(issues, jql_startfrom, jql_to):
    df1 = spark.createDataFrame(issues, schema=jira_schema_raw_dump)
    df1 = df1.withColumn('jql_startfrom', lit(jql_startfrom).cast("Timestamp"))
    df1 = df1.withColumn( 'jql_to', lit(jql_to).cast("Timestamp"))
    df1 = df1.withColumn('processed_timestamp', current_timestamp())

    print("dumping into - jira_es_base_raw_dump")
    display("jira_es_base_raw_dump total issues = " + str(df1.count()))
    display(df1)
    df1.write.mode("append").saveAsTable(f"{unity_catalog}.{unity_schema}.jira_es_base_raw_dump")

# COMMAND ----------

if jql:
    jql = jql
elif backfill_hours:
    jql = f"project = ES AND updated >= -{backfill_hours}h ORDER BY created ASC"
else:
    lastUpdatedFrom,lastUpdatedTo = incremental_range('jira_es_base_etl')

    jql = f"project = ES AND (updated >= '{lastUpdatedFrom}' or created >= '{lastUpdatedFrom}') and (updated <= '{lastUpdatedTo}' or created <= '{lastUpdatedTo}') ORDER BY created ASC"

print(f"JQL - {jql}")

# COMMAND ----------

issuesCount = get_max_count(jql)
print(f"Total issues count received from source - {issuesCount}")

if int(issuesCount) == 0:
    if backfill_hours is None:
        update_checkpoint(issuesCount, 'jira_es_base_etl', 'jira_es_base', lastUpdatedFrom, lastUpdatedTo)
    dbutils.notebook.exit("There are no changes in the jira ES tickets in the last 30 minutes. Stopping notebook execution.")

# COMMAND ----------

issues_list, issues_raw_list,failed_keys_within_batch, failed_batch  = fetch_issues_from_jira(jql, parse_issue, True)

# COMMAND ----------

merge_es_issues(issues_list)

# COMMAND ----------

if not backfill_hours:
    update_checkpoint(issuesCount, 'jira_es_base_etl', 'jira_es_base', lastUpdatedFrom, lastUpdatedTo)

# COMMAND ----------

if not backfill_hours:
    try:
        append_es_raw_dump(issues_raw_list, lastUpdatedFrom, lastUpdatedTo)
    except Exception as e:
        print(f"error {e}")

# COMMAND ----------

#logging failed keys
log_failed_keys(failed_keys_within_batch, 'rejected_jira_keys')


#checking if there are any failed offsets even after retries
failed_batch_check(failed_batch)

# COMMAND ----------

display(spark.sql(f"select count(*) from {unity_catalog}.{unity_schema}.jira_es_base_raw_dump limit 10"))

# COMMAND ----------

display(spark.sql(f"select count(*) from {unity_catalog}.{unity_schema}.jira_es_base limit 10"))

# COMMAND ----------

display(spark.sql(f"select * from {unity_catalog}.{unity_schema}.base_checkpoint order by last_refresh_ts_UTC desc limit 10"))

# COMMAND ----------


