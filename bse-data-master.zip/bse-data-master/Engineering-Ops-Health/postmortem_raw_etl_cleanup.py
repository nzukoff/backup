# Databricks notebook source
# MAGIC %run ./eng_ops_health_config

# COMMAND ----------

# MAGIC %run ./jira_etl_utils

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql.functions import when, col, lit
  
def overwrite_postmortems_issues(issues):
    df1 = spark.createDataFrame(issues, schema=postmortems_schema)
    df1 = df1.withColumn("category_new", 
                   when(col("category") == lit("postmortem-followup"), 
                        lit("postmortem-followup-no-term")
                   ).otherwise(col("category"))
              ) \
       .drop("category") \
       .withColumnRenamed("category_new", "category")
    df1.createOrReplaceTempView("postmortems_tickets_tmp_all")
    sql("select *, row_number() over (partition by key order by updated desc) as RN from postmortems_tickets_tmp_all").createOrReplaceTempView('postmortems_tickets_tmp_rn')
    dups = sql("select count(*) as cnt from postmortems_tickets_tmp_rn where RN>1").first()['cnt']
    #print(dups)
    if dups > 0:
        print("Displaying duplicates ...")
        display(sql("select * from postmortems_tickets_tmp_rn where key in (select distinct key from postmortems_tickets_tmp_rn where RN>1) "))
    
    sql("select * from postmortems_tickets_tmp_rn where RN=1").drop("RN").createOrReplaceTempView('postmortems_tickets_tmp')
    
    print("Overwrite - postmortems_raw")
    
    display(spark.sql(f"""
    CREATE OR REPLACE TABLE {unity_catalog}.{unity_schema}.postmortems_raw as
    SELECT * FROM postmortems_tickets_tmp;
    """))

# COMMAND ----------

current_date = datetime.now()
formatted_current_date = current_date.strftime("%Y-%m-%d")

cleanup_start_time = sql("select current_timestamp() as cleanup_start_time ").first()['cleanup_start_time']

jql = f'''labels in ("postmortem-followup", "postmortem-followup-short-term", "postmortem-followup-long-term") AND status != Cancelled AND status != Rejected'''

print(f"\nJQL - {jql}")

# COMMAND ----------

issuesCount = get_max_count(jql)
print(f"Total issues count received from source - {issuesCount}")

# COMMAND ----------

issues_list, issues_raw_list,failed_keys_within_batch, failed_batch  = fetch_issues_from_jira(jql, parse_postmortems_issue, False)

# COMMAND ----------

overwrite_postmortems_issues(issues_list)

# COMMAND ----------

update_checkpoint(issuesCount, 'postmortems_raw_etl_cleanup', 'postmortems_raw', job_start_time = cleanup_start_time) 

# COMMAND ----------

# logging failed keys
failed_keys_count = len(failed_keys_within_batch)
print(f"failed keys count - {failed_keys_count}" )
display(log_failed_keys(failed_keys_within_batch, 'rejected_postmortems_jira_keys'))
# checking if there are any failed offsets even after retries
failed_batch_check(failed_batch)

# COMMAND ----------

display(spark.sql(f"select count(*) from {unity_catalog}.{unity_schema}.postmortems_raw limit 10"))

# COMMAND ----------

display(spark.sql(f"select * from {unity_catalog}.{unity_schema}.base_checkpoint order by last_refresh_ts_UTC desc limit 10"))
