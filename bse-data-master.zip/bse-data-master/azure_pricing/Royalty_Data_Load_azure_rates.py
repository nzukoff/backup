# Databricks notebook source
dbutils.widgets.text("env", "prod")
dbutils.widgets.text("load_type", "incremental")

dbutils.widgets.text("common_catalog", "main")
dbutils.widgets.text("royalty_catalog", "integration")
dbutils.widgets.text("catalog", "integration")
dbutils.widgets.text("schema", "it_consumption_silver")


# COMMAND ----------

# MAGIC %run "./config_azure_pricing"

# COMMAND ----------

locals().update(azure_table_config)

# COMMAND ----------

print(AZURE_RATES)

# COMMAND ----------

load_type = dbutils.widgets.get("load_type") #'incremental'

#load_type = 'incremental'

if load_type == 'incremental' :

  # For an incremental load type, the Azure rates refresh start date will be set to three months before the last date of the most recent royalty report.
  # 06/09 since - we have the royalty monthly now, changing the incremental to next day after royalty is available.

  ratesloadstartdate = spark.sql(f'''
                                      SELECT replace(string(date_add(last_day(add_months(max(effective_end_date) ,-0)),1)),"-","") FROM {AZURE_RATES} 
                                      WHERE pipeline IN ( "Royalty" ,"Royalty_Published") 
                                    ''' ) .collect()[0][0] 
  ratesloadstartdate_date = spark.sql(f'''
                                      SELECT string(date_add(last_day(add_months(max(effective_end_date) ,-0)),1)) 
                                      FROM {AZURE_RATES} 
                                      WHERE pipeline IN ( "Royalty" ,"Royalty_Published" ) 
                                      ''') .collect()[0][0]   
elif load_type == 'full' : 
  ratesloadstartdate = billingmonthstartkey
  ratesloadstartdate_date  = billingmonthstartdate
  
else :
  raise Exception("load type is incorrect")
  
print("Azure Rates Load Start Date: ",ratesloadstartdate_date,ratesloadstartdate)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Extract Royalty Data starting Azure Rates load start date
# MAGIC ###### - For Incremental Load: Last 3 months of Royalty Data
# MAGIC
# MAGIC #### Change 07/09 ###### - For Incremental ####Load: data post royalty load

# COMMAND ----------

print(maxbillingmonthkey)

# COMMAND ----------

Royaltydata = spark.sql(f'''
select 
       billingMonthKey,
       SubscriptionguID  ,
       RIConsumption RI_Consumption  , 
       meterName ,
       DatabricksSKU,
       year(date) year,
       month(date) month , 
       ListPrice,
       CustomerPrice,
       RevShareFloor,
       DataBricksRevShare databricksRevenueShare,
       totalUnits 
  From  {ROYALTY_QUARTERLY}
  Where billingMonthKey >=   {ratesloadstartdate}
  
UNION 

select 
       billingMonthKey,
       SubscriptionguID  ,
       RIConsumption RI_Consumption  , 
       meterName ,
       DatabricksSKU,
       year(date) year,
       month(date) month , 
       ListPrice as ListPrice,
       CustomerPrice as CustomerPrice,
       RevShareFloor,
       DataBricksRevShare databricksRevenueShare,
       TotalUnits totalUnits
  From  {ROYALTY_MONTHLY}
  where billingMonthKey > {maxbillingmonthkey} and billingMonthKey >=   {ratesloadstartdate}''') 

Royaltydata.createOrReplaceTempView('Royaltydata')

# COMMAND ----------

maxbillingmonthkey_inc_mnth_rylty = spark.sql (f'''select max(billingMonthkey)  From {ROYALTY_MONTHLY}''').collect()[0][0]
royatlymaxyear_inc_mnth_rylty  = maxbillingmonthkey_inc_mnth_rylty[0:4]
royatlymaxmonth_inc_mnth_rylty  = maxbillingmonthkey_inc_mnth_rylty[4:6]
royaltymaxdate_inc_mnth_rylty =    spark.sql   (  f'select LAST_DAY  ( cast( (( ({royatlymaxyear_inc_mnth_rylty}) || "-"||({royatlymaxmonth_inc_mnth_rylty})))  as  date) )' ).collect()[0][0]  
print("Month End Date of latest Royalty Data: ",royaltymaxdate_inc_mnth_rylty)
discount_percent = 20
print("Defaulty discount percent in Azure Rates: ", discount_percent)

# COMMAND ----------

# MAGIC %md
# MAGIC #### PayGo Royalty Records
# MAGIC ###### Aggregate the Royalty Data having PayGO consumption type to ensure that each combination of Subscription ID and SKU has only one record per billing month.

# COMMAND ----------

multipleenrollmentdf =  spark.sql ( f'''
                                   SELECT billingMonthKey,
                                          SubscriptionGUID,
                                          DatabricksSKU ,
                                          count(*) cnt ,
                                          min(ListPrice) ListPrice , 
                                          sum(databricksRevenueShare) databricksRevenueShare ,
                                          sum(totalUnits) totalUnits,   
                                          min(CustomerPrice) CustomerPrice,
                                          min(RevShareFloor) RevShareFloor,
                                          min(year) year ,
                                          min(month) month

                                  FROM Royaltydata  
                                  WHERE RI_Consumption = 'PAYG'
                                    AND billingMonthKey >= {billingmonthstartkey}  
                                  GROUP BY 1,2,3
                                  HAVING COUNT(*) > 1
''') 

multipleenrollmentdf.createOrReplaceTempView('multiple_enrollment_number')

# COMMAND ----------

# MAGIC %md
# MAGIC - Map Account ID associated with Subscription IDs 
# MAGIC 1. Extract PayGo Royalty Data having unique Subscription ID-SKU combinations per billing month in Royalty
# MAGIC 2. Extract PayGo Royalty Data having duplicate Subscription ID-SKU combinations per billing month in Royalty
# MAGIC 3. Compute for both : 
# MAGIC   - `RevSharePrice` = `databricksRevenueShare`/`Total Units` 
# MAGIC   - Effective Start Date = First day of the Royalty Month
# MAGIC   - Effective End Date = Last day of the Royalty Month
# MAGIC 4. Union the results.

# COMMAND ----------

paygroyalty = spark.sql(f'''

WITH account_info as 
(
  SELECT DISTINCT azureSubscriptionId__c,
                  account__c 
  FROM 
  ( 
    SELECT azureSubscriptionId__c , 
           account__c , 
           row_number() over ( partition by azureSubscriptionId__c order by case when workspaceStatus__c = 'RUNNING' THEN 1 ELSE 2 END , CreatedDate desc ) rnk 
    FROM {SFDC_WORKSPACE_TABLE}   a
    WHERE processdate =  ( select max(processdate) from  {SFDC_WORKSPACE_TABLE}  ) 
      AND account__c is not NULL 
  )  a

  WHERE rnk = 1  
)

-- Unique SubID-SKU Combination PayGo Records

SELECT royalty.SubscriptionguID as SubscriptionID,
       accnt_info.account__c accountId,
       royalty.RI_Consumption as ConsumptionType,
       royalty.DatabricksSKU Sku ,
      CAST( (CONCAT( (royalty.year),'-' , (royalty.month) ,'-','01')) as  date) as Effective_start_date,
      LAST_DAY(cast( (CONCAT( (royalty.year),'-' , (royalty.month) ,'-','01')) as  date) ) Effective_end_date,  
      (royalty.ListPrice) as listPrice ,
      (royalty.CustomerPrice) as custprice,
      royalty.RevShareFloor ,
      royalty.databricksRevenueShare ,
      royalty.totalUnits,
      coalesce(royalty.databricksRevenueShare/royalty.totalUnits ,0) revshareprice
       
FROM Royaltydata royalty
LEFT JOIN account_info accnt_info 
  ON accnt_info.azureSubscriptionId__c = royalty.SubscriptionguID

LEFT JOIN  multiple_enrollment_number  men
  ON men.SubscriptionGUID = royalty.SubscriptionGUID
    AND men.billingMonthKey = royalty.billingMonthKey
    AND men.DatabricksSKU = royalty.DatabricksSKU

WHERE  royalty.RI_Consumption = 'PAYG'
  AND royalty.billingMonthKey >=  {billingmonthstartkey}
  AND men.SubscriptionGUID is NULL 

UNION

-- Duplicate SubID-SKU Combination PayGo Records

SELECT royalty.SubscriptionguID as SubscriptionID,
       accnt_info.account__c accountId,
       'PAYG' as ConsumptionType,
       DatabricksSKU as Sku ,
      CAST( (CONCAT( (royalty.year),'-' , (royalty.month) ,'-','01')) as  date) as Effective_start_date,
      LAST_DAY(cast( (CONCAT( (royalty.year),'-' , (royalty.month) ,'-','01')) as  date) ) Effective_end_date,
      (royalty.ListPrice) as listPrice ,
      (royalty.CustomerPrice) as custprice, 
      royalty.RevShareFloor ,
      royalty.databricksRevenueShare,
      royalty.totalUnits,
      coalesce(royalty.databricksRevenueShare/royalty.totalUnits ,0) revshareprice
       
FROM multiple_enrollment_number royalty
LEFT JOIN account_info accnt_info 
  ON accnt_info.azureSubscriptionId__c = royalty.SubscriptionguID 
  
''')


paygroyalty.createOrReplaceTempView ('paygroyalty')

# COMMAND ----------

# MAGIC %md
# MAGIC #### RI Royalty Records
# MAGIC ###### Aggregate the Royalty Data having RI consumption type to ensure that each combination of Subscription ID and SKU has only one record per billing month.

# COMMAND ----------

multipleenrollmentdf =  spark.sql ( f'''
                                   SELECT billingMonthKey,
                                          SubscriptionGUID,
                                          DatabricksSKU ,
                                          count(*) cnt ,
                                          min(ListPrice) ListPrice , 
                                          min(CustomerPrice) CustomerPrice,
                                          sum(databricksRevenueShare) databricksRevenueShare , 
                                          sum(totalUnits) totalUnits, 
                                          min(RevShareFloor) RevShareFloor,
                                          min(year) year ,
                                          min(month) month
                                  FROM Royaltydata 
                                  WHERE RI_Consumption = 'RI'
                                    and billingMonthKey >= {billingmonthstartkey}
                                    GROUP BY 1,2,3
                                  HAVING count(*) > 1
                                  ''') 

multipleenrollmentdf.createOrReplaceTempView('multiple_enrollment_number_ri')


# COMMAND ----------

# MAGIC %md
# MAGIC - Map Account ID associated with Subscription IDs 
# MAGIC 1. Extract RI Royalty Data having unique Subscription ID-SKU combinations per billing month in Royalty
# MAGIC 2. Extract RI Royalty Data having duplicate Subscription ID-SKU combinations per billing month in Royalty
# MAGIC 3. Compute for both : 
# MAGIC   - `RevSharePrice` = `databricksRevenueShare`/`Total Units` 
# MAGIC   - Effective Start Date = First day of the Royalty Month
# MAGIC   - Effective End Date = Last day of the Royalty Month
# MAGIC 4. Union the results.

# COMMAND ----------

riroyalty = spark.sql(f'''

WITH account_info as 
(
  SELECT DISTINCT azureSubscriptionId__c,
                  account__c 
  FROM 
  ( 
    SELECT azureSubscriptionId__c , 
           account__c , 
           row_number() over ( partition by azureSubscriptionId__c order by case when workspaceStatus__c = 'RUNNING' THEN 1 ELSE 2 END , CreatedDate desc ) rnk 
    FROM {SFDC_WORKSPACE_TABLE}   a
    WHERE processdate =  ( select max(processdate) from  {SFDC_WORKSPACE_TABLE}  ) 
      AND account__c is not NULL 
  )  a

  WHERE rnk = 1  
)

-- Unique SubID-SKU Combination RI Records

SELECT royalty.SubscriptionguID as SubscriptionID,
       accnt_info.account__c accountId,
       royalty.RI_Consumption as ConsumptionType,
       royalty.DatabricksSKU  Sku ,
      CAST( (CONCAT( (royalty.year),'-' , (royalty.month) ,'-','01')) as  date) as Effective_start_date,
      LAST_DAY(cast( (CONCAT( (royalty.year),'-' , (royalty.month) ,'-','01')) as  date) ) Effective_end_date,  
      (royalty.ListPrice) as listPrice ,
      (royalty.CustomerPrice) as custprice,
      royalty.RevShareFloor ,
      royalty.databricksRevenueShare,
      royalty.totalUnits,
       coalesce(royalty.databricksRevenueShare/royalty.totalUnits ,0) revshareprice
       
FROM Royaltydata royalty
LEFT JOIN account_info accnt_info 
  ON accnt_info.azureSubscriptionId__c = royalty.SubscriptionguID

LEFT JOIN  multiple_enrollment_number_ri  men
  ON men.SubscriptionGUID = royalty.SubscriptionGUID
    AND men.billingMonthKey = royalty.billingMonthKey 
    AND men.DatabricksSKU = royalty.DatabricksSKU

WHERE  royalty.RI_Consumption = 'RI'  
  AND royalty.billingMonthKey >= {billingmonthstartkey} 
  AND men.SubscriptionGUID is NULL 

UNION

-- Duplicate SubID-SKU Combination RI Records

SELECT royalty.SubscriptionguID as SubscriptionID,
       accnt_info.account__c accountId,
       'RI' as ConsumptionType,
       royalty.DatabricksSKU Sku ,
      CAST( (CONCAT( (royalty.year),'-' , (royalty.month) ,'-','01')) as  date) as Effective_start_date,
      LAST_DAY(cast( (CONCAT( (royalty.year),'-' , (royalty.month) ,'-','01')) as  date) ) Effective_end_date,  
      (royalty.ListPrice) as listPrice ,
      (royalty.CustomerPrice) as custprice, 
      royalty.RevShareFloor ,
      royalty.databricksRevenueShare,
      royalty.totalUnits,
       coalesce(royalty.databricksRevenueShare/royalty.totalUnits ,0) revshareprice
       
FROM multiple_enrollment_number_ri royalty
LEFT JOIN account_info accnt_info 
  ON accnt_info.azureSubscriptionId__c = royalty.SubscriptionguID 
  
''')


riroyalty.createOrReplaceTempView ('RIroyalty')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Combine the PayGO and RI Royalty Records

# COMMAND ----------

RIpayg_royalty_combined = spark.sql(''' 

SELECT RIpayg_royalty.*, 
       count(*) over (partition by  Billing_Month ,SubscriptionID, Sku  ) cnt  
FROM 
  (
    SELECT  
      extract ( year from Effective_start_date) ||  date_format(Effective_start_date, 'MM')  as Billing_Month,
      SubscriptionID ,
      accountId,
      'PAYG' as ConsumptionType,
      Sku,
      Effective_start_date,
      Effective_end_date,
      listPrice,
      custprice,
      RevShareFloor ,
      revshareprice,
      databricksRevenueShare,
      totalUnits,
      current_timestamp as createtimestamp	,
      NULL as updateuser ,
      NULL as updatetimestamp
          
    FROM paygroyalty

    UNION 

    SELECT  
      extract ( year from Effective_start_date) || date_format(Effective_start_date, 'MM') as Billing_Month,
      SubscriptionID	,
      accountId	,
      'RI' as ConsumptionType,
      Sku	,
      Effective_start_date	,
      Effective_end_date	,
      listPrice	,
      custprice	,
      RevShareFloor ,
      revshareprice	,
      databricksRevenueShare,
      totalUnits,
      current_timestamp as createtimestamp	,
      NULL as updateuser ,
      NULL as updatetimestamp

    FROM RIroyalty ) RIpayg_royalty 

''' ) 

RIpayg_royalty_combined.createOrReplaceTempView('RIpayg_royalty_combined')


# COMMAND ----------

# MAGIC
# MAGIC
# MAGIC %md
# MAGIC #### NULL Consumption Type Royalty Records
# MAGIC ###### Aggregate Royalty Data having consumption type as NULL to compute key metrics

# COMMAND ----------

                                          
royalty_null_consumption_type = spark.sql(f'''                                         

WITH account_info as 

(
  SELECT DISTINCT azureSubscriptionId__c,
                  account__c 
  FROM 
  ( 
    SELECT azureSubscriptionId__c , 
           account__c , 
           row_number() over ( partition by azureSubscriptionId__c order by case when workspaceStatus__c = 'RUNNING' THEN 1 ELSE 2 END , CreatedDate desc ) rnk 
    FROM  {SFDC_WORKSPACE_TABLE}   a
    WHERE processdate =  ( select max(processdate) from  {SFDC_WORKSPACE_TABLE} ) 
      AND account__c IS NOT NULL 
  )  a

  WHERE rnk = 1  
)


SELECT royalty.SubscriptionguID as SubscriptionID,
       accnt_info.account__c accountId,
       royalty.RI_Consumption as ConsumptionType,
       royalty.DatabricksSKU  Sku ,
      CAST( (CONCAT( (royalty.year),'-' , (royalty.month) ,'-','01')) as  date) as Effective_start_date,
      LAST_DAY(cast( (CONCAT( (royalty.year),'-' , (royalty.month) ,'-','01')) as  date) ) Effective_end_date, 
      avg(royalty.ListPrice) as listPrice ,
      avg(royalty.CustomerPrice) as custprice,
      avg(royalty.RevShareFloor) RevShareFloor ,
      avg(royalty.databricksRevenueShare) databricksRevenueShare ,
      avg(royalty.totalUnits) totalUnits ,
      avg(coalesce(royalty.databricksRevenueShare/royalty.totalUnits ,0) ) revshareprice
       
FROM Royaltydata royalty
LEFT JOIN account_info accnt_info 
  ON accnt_info.azureSubscriptionId__c = royalty.SubscriptionguID

WHERE  royalty.RI_Consumption is NULL 

GROUP BY 1,2,3,4,5,6
''' )
royalty_null_consumption_type.createOrReplaceTempView('royalty_null_consumption_type')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Staging Table
# MAGIC 1. `Royalty (Unique) Insert PayGO` / `Royalty (Unique) Insert RI`
# MAGIC - Insert records from Royalty where each Subscription ID and SKU combination has only one consumption type in a billing month.
# MAGIC 2. `Royalty (Both PayGo/RI) Insert PayGO - DatabricksRevenueShare >= 0.1` / `Royalty (Both PayGo/RI) Insert RI - DatabricksRevenueShare >= 0.1`
# MAGIC - Insert records from Royalty where Subscription ID and SKU combination has both PayGO and RI consumption types in a billing month. 
# MAGIC - ONLY pick the having `databricksRevenueShare` >= 0.1 (Records where both PayGO and RI have `databricksRevenueShare` >= 0.1 will be handled later)
# MAGIC 3. `Royalty Insert - NULL Consumption Type`
# MAGIC - Insert records from Royalty having NULL Consumption Type

# COMMAND ----------

print(AZURE_RATES_STG)

# COMMAND ----------

deleteroyaltystg = f'''DELETE FROM {AZURE_RATES_STG}'''

sql(deleteroyaltystg)


insertroyaltystg  = f''' INSERT INTO {AZURE_RATES_STG}


SELECT  
  Billing_Month,
  SubscriptionID ,
  accountId,
  ConsumptionType,
  Sku,
  Effective_start_date,
  Effective_end_date,
  listPrice,
  custprice,
  RevShareFloor ,
  revshareprice,
  databricksRevenueShare,
  totalUnits,
  case when ConsumptionType = 'PAYG' then  'Royalty (Unique) Insert PayGO '
       when ConsumptionType = 'RI'   then 'Royalty (Unique) Insert RI '  end || current_user as createuser	,
  current_timestamp as createtimestamp	,
  NULL as updateuser ,
  NULL as updatetimestamp
       
FROM RIpayg_royalty_combined
WHERE cnt  =  1
--single consumption type - picking all

UNION 


  
  SELECT  
  Billing_Month,
  SubscriptionID ,
  accountId,
  ConsumptionType,
  Sku,
  Effective_start_date,
  Effective_end_date,
  listPrice,
  custprice,
  RevShareFloor ,
  revshareprice,
  databricksRevenueShare,
  totalUnits,
  case when ConsumptionType = 'PAYG' then  'Royalty (Both PayGo/RI) Insert PayGO - DatabricksRevenueShare >= 0.1 '
       when ConsumptionType = 'RI'   then 'Royalty (Both PayGo/RI) Insert RI - DatabricksRevenueShare >= 0.1 '  end || current_user as createuser	,
  current_timestamp as createtimestamp	,
  NULL as updateuser ,
  NULL as updatetimestamp
       
FROM RIpayg_royalty_combined
WHERE cnt  >  1 
  and  databricksRevenueShare >= 0.1
-- both payg ri - just picking the one with rev share >= 0.1


UNION 


 SELECT 
 
  extract ( year from Effective_start_date) ||  date_format(Effective_start_date, 'MM')  as Billing_Month,
  SubscriptionID ,
  accountId,
  ConsumptionType,
  Sku,
  Effective_start_date,
  Effective_end_date,
  listPrice,
  custprice,
  RevShareFloor ,
  revshareprice,
  databricksRevenueShare,
  totalUnits,
  'Royalty Insert- NULL Consumption Type '  || current_user as createuser	,
  current_timestamp as createtimestamp	,
  NULL as updateuser ,
  NULL as updatetimestamp
  
FROM royalty_null_consumption_type

-- Null consumption type

'''

sql(insertroyaltystg)

# COMMAND ----------

# MAGIC %md
# MAGIC 4. `Royalty Insert PayGO - RevShare < 0.1 : Higher Total Units` / `Royalty Insert RI - RevShare < 0.1 : Higher Total Units`
# MAGIC - Insert records from Royalty where Subscription ID and SKU combination has both PayGO and RI consumption types in a billing month and both records have databricksRevenueShare < 0.1
# MAGIC - Pick the record with the highest `Total Units` for each unique combination of `SubscriptionID`, `Sku` and `Billing Month`.

# COMMAND ----------

insertroyaltystg_bothzero  = f''' INSERT INTO {AZURE_RATES_STG}

SELECT  
  ri.Billing_Month,
  ri.SubscriptionID ,
  ri.accountId,
  ri.ConsumptionType,
  ri.Sku,
  ri.Effective_start_date,
  ri.Effective_end_date,
  ri.listPrice,
  ri.custprice,
  ri.RevShareFloor ,
  ri.revshareprice,
  ri.databricksRevenueShare,
  ri.totalUnits,
  case when ri.ConsumptionType = 'PAYG' then  'Royalty Insert PayGO - RevShare < 0.1 : Higher Total Units '
       when ri.ConsumptionType = 'RI' then 'Royalty Insert RI - RevShare < 0.1 : Higher Total Units '  end || current_user as createuser	,
  current_timestamp as createtimestamp	,
  NULL as updateuser ,
  NULL as updatetimestamp


FROM RIpayg_royalty_combined ri 
LEFT JOIN {AZURE_RATES_STG} stg
  ON (ri.Billing_Month = stg.Billing_Month AND 
      ri.SubscriptionID = stg.SubscriptionID AND 
      ri.Sku = stg.Sku) 

WHERE  stg.Billing_Month is NULL

QUALIFY ROW_NUMBER() OVER (PARTITION BY ri.billing_month,ri.SubscriptionID,ri.Sku order by ri.totalunits desc  ) = 1 '''



sql(insertroyaltystg_bothzero)
 
# inserting transactions where both payg/ri revshare is 0 - selecting with the max total units.

# COMMAND ----------

# MAGIC %md
# MAGIC Map Subscription IDs with associated Account IDs 

# COMMAND ----------

sfdcaccnount_subscription = spark.sql(f'''
                                      
  SELECT DISTINCT azureSubscriptionId__c,
                  account__c 
  FROM 
  ( 
    SELECT azureSubscriptionId__c , 
           account__c , 
           row_number() over ( partition by azureSubscriptionId__c order by case when workspaceStatus__c = 'RUNNING' THEN 1 ELSE 2 END , CreatedDate desc ) rnk 
    FROM {SFDC_WORKSPACE_TABLE}   a
    WHERE processdate =  ( select max(processdate) from  {SFDC_WORKSPACE_TABLE}  ) 
      AND account__c is not NULL 
  )  a

where rnk = 1  ''') 

sfdcaccnount_subscription.createOrReplaceTempView('sfdcaccnount_subscription')

# COMMAND ----------

# MAGIC %md
# MAGIC **Paid Usage** from `it_lakehouse.azure_carveout` and `it_consumption_silver.bi_aggorders`
# MAGIC   - Extract Subscription IDs and SKUs that are missing in Royalty but have paid usage in `it_lakehouse.azure_carveout` between the Azure Rates load start date and the last date of the Royalty data
# MAGIC     - `Usage Date` - Date from azure_carveout
# MAGIC     - `End Date` - Burst Date if it is not NULL; else, it returns the value of endDate from bi_aggorders
# MAGIC
# MAGIC     From biaggorder - we are taking just the RI/PAYG attribute

# COMMAND ----------

print(AZURE_USAGE_METERING)

# COMMAND ----------

print(BI_AGG_ORDERS)

# COMMAND ----------

azure_usage_df = sql(f"""
                    SELECT DISTINCT 
                            CASE WHEN sfdc_account_id is null 
                                    THEN "0013f000005RwT9AAK"       -- Unmapped Workspaces
                                ELSE sfdc_account_id 
                            END AS sfdc_account_id, 
                            date, 
                            lower(azure_sub_id) as azure_sub_id, 
                            sku, 
                            platform 
                    FROM {AZURE_USAGE_METERING}           -- Azure Usage
                    WHERE paid_unpaid_flag = "paid"
                     """)
azure_usage_df.createOrReplaceTempView("azure_usage_df")                     

bi_agg_single_scope_df = sql(f""" -- Granularity Subscription ID
                    
                    SELECT DISTINCT SubscriptionID aggSubscriptionID, 
                                    platform aggPlatform, 
                                    sfdcAccountID, 
                                    lower(aggOrder) as aggOrder, -- Used to determine PayGO / RI
                                    startDate,  
                                    coalesce(usageBurstDate, endDate) endDate, 
                                    scope
                    FROM {BI_AGG_ORDERS}
                    WHERE platform = 'azure' 
                        AND scope = "Single"
                               """)
bi_agg_single_scope_df.createOrReplaceTempView("bi_agg_single_scope_df")  

bi_agg_shared_scope_df = sql(f""" -- Granularity Account ID
                             
                        SELECT DISTINCT SubscriptionID aggSubscriptionID, 
                                        platform aggPlatform, 
                                        sfdcAccountID, 
                                        lower(aggOrder) as aggOrder, -- Used to determine PayGO / RI
                                        startDate,  
                                        coalesce(usageBurstDate, endDate) endDate, 
                                        scope
                        FROM {BI_AGG_ORDERS}
                        WHERE platform = 'azure' 
                            AND scope != "Single"
                                   
                               """)
bi_agg_shared_scope_df.createOrReplaceTempView("bi_agg_shared_scope_df")    

azure_usage_final_df = sql("""
                        SELECT a.sfdc_account_id as accountId, 
                               a.date as usage_date, 
                               a.azure_sub_id as SubscriptionID, 
                               lower(a.sku) as usage_Sku, 
                               a.platform, 
                               CASE when coalesce(bi_agg_sub_id.aggOrder, bi_agg_acc.aggOrder) like 'mtm%' 
                                        then 'PAYG' 
                                    else 'RI' 
                               end as aggOrder 
                        FROM azure_usage_df a

                        LEFT JOIN bi_agg_single_scope_df bi_agg_sub_id
                            on lower(a.azure_sub_id) = lower(bi_agg_sub_id.aggSubscriptionID)
                            and a.sfdc_account_id = bi_agg_sub_id.sfdcAccountID
                            and a.platform = bi_agg_sub_id.aggPlatform
                            and a.date >= bi_agg_sub_id.startDate
                            and a.date <= bi_agg_sub_id.endDate

                        LEFT JOIN bi_agg_shared_scope_df bi_agg_acc
                            on a.sfdc_account_id = bi_agg_acc.sfdcAccountID
                            and a.platform = bi_agg_acc.aggPlatform
                            and a.date >= bi_agg_acc.startDate
                            and a.date <= bi_agg_acc.endDate

                        GROUP BY ALL
                           """)    

azure_usage_final_df.write \
    .format('delta') \
    .mode('overwrite') \
    .option('mergeSchema', "true") \
    .saveAsTable(AZURE_RATED_USAGE)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Missing Royalty Records
# MAGIC For records missing in Royalty but have paid usage in `it_lakehouse.azure_carveout` between the Azure Rates load start date and the last date of the Royalty data, compute
# MAGIC - `List Price` from it_sfdc_silver.list_prices
# MAGIC - `Cust Price` = List Price * (100 - Default Discount Percent)/100
# MAGIC - `RevShare Price` = 0.85 * Cust Price
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Multiple Consumption Type - Missing Royalty Records

# COMMAND ----------

print(AZURE_RATED_USAGE,AZURE_RATES_STG)

# COMMAND ----------

missingskusubscriptionall = spark.sql(f'''
SELECT 
   (a.usage_date) usage_date,
   a.SubscriptionID,
   coalesce(ss.account__c , a.accountId) accountId ,
   a.aggorder as Consumptiontype,
   a.usage_Sku sku,
   coalesce(govlr.list_price,lr.list_price)  list_price,
   coalesce(govlr.list_price,lr.list_price)   * ( (100-{discount_percent}) /100) custprice,
   0.85 * (coalesce(govlr.list_price,lr.list_price)   * ( (100-{discount_percent}) /100)) revshareprice,
   'Missing Subscription SKU from Royalty - Insert azure_carveout ' || current_user as createuser	
   
  from {AZURE_RATED_USAGE}  a
  left join  {AZURE_RATES_STG}  ar
  on lower(usage_sku) = lower(Sku)
  and lower(ar.SubscriptionID) = lower(a.SubscriptionID)

  left join {LIST_PRICE_TABLE} lr
  on lower(a.usage_sku) = lower(lr.sku)
  and upper(lr.type) ='E2'
  and a.usage_date between lr.start_date and lr.end_date
  and lower(lr.platform) = 'azure'

  left join {LIST_PRICE_TABLE} govlr
  on lower(a.usage_sku) = lower(govlr.sku)
  and upper(govlr.type) ='GOV'
  and a.usage_date between govlr.start_Date and govlr.end_Date
  and govlr.platform = 'azure'

  LEFT JOIN sfdcaccnount_subscription ss
   on lower(ss.azureSubscriptionId__c)  = lower(a.SubscriptionID)

  WHERE 
       a.usage_date between  '{ratesloadstartdate_date}' and  '{royaltymaxdate_inc_mnth_rylty}'
   and a.platform = 'azure'
   and ar.SubscriptionID is NULL 

   order by 2,1
''')
 
missingskusubscriptionall.createOrReplaceTempView('missingskusubscriptionall')

#missing completely from the royalty data 

# COMMAND ----------

missingsubsku_multiplecomsumptiontype_grp = spark.sql ( 
                            ''' 
                                select SubscriptionID,
                                       sku   
                                From missingskusubscriptionall  
                                group by 1,2 
                                having count(distinct Consumptiontype ) >1 
                            
                            ''')

missingsubsku_multiplecomsumptiontype_grp.createOrReplaceTempView('missingsubsku_multiplecomsumptiontype_grp')

#missing completely from the royalty data - with sub sku having multiple consumption type - distinct sub sku 

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Multiple Consumption Type with same Usage Date - Missing Royalty Records

# COMMAND ----------

missingsubsku_multiplecomsumptiontype_grp_Same_day = spark.sql ( ''' 
                                  select SubscriptionID,
                                         sku ,
                                         usage_date  
                                  From missingskusubscriptionall  
                                  group by 1,2,3 
                                  having count(distinct Consumptiontype ) >1 ''')

missingsubsku_multiplecomsumptiontype_grp_Same_day.createOrReplaceTempView('missingsubsku_multiplecomsumptiontype_grp_Same_day')

# COMMAND ----------

# MAGIC %md 
# MAGIC Combine 
# MAGIC 1. `Missing Subscription SKU from Royalty(Different Usage Date RI/PAYG) - Insert azure_carveout`
# MAGIC  - Records missing from Royalty but present in it_lakehouse.azure_carveout, having multiple consumption types, each associated with a different usage date.
# MAGIC 2. `Missing Subscription SKU from Royalty(Same Usage Date RI/PAYG) - Insert azure_carveout`
# MAGIC  - Records missing from Royalty but present in it_lakehouse.azure_carveout, having multiple consumption types, each associated with same usage date.

# COMMAND ----------

missingsubsku_multiplecomsumptiontype = spark.sql( ''' 

-- Each consumption type having different usage date

SELECT 
  usage_date,
  SubscriptionID	,
  accountId,
  Consumptiontype,
  sku,
  list_price,
  custprice,
  revshareprice,
  'Missing Subscription SKU from Royalty(Different Usage Date RI/PAYG) - Insert azure_carveout ' createuser

FROM missingskusubscriptionall 
WHERE (SubscriptionID, sku) IN 
    ( 
      SELECT SubscriptionID, sku   
      FROM missingsubsku_multiplecomsumptiontype_grp 
    )
and (SubscriptionID, sku, usage_date) NOT IN 
    ( 
      SELECT * 
      FROM missingsubsku_multiplecomsumptiontype_grp_Same_day 
    )

UNION 

-- Each consumption type having same usage date
-- For default - the ranges will be autohandled since this will be new consumption type.

SELECT 
  usage_date	,
  SubscriptionID	,
  min(accountId)	,
  'RI/PAYG' as Consumptiontype	,
  sku	,
  min(list_price) list_price	,
  avg(custprice) custprice	,
  min(revshareprice) revshareprice	,
  'Missing Subscription SKU from Royalty(Same Usage Date RI/PAYG) - Insert azure_carveout ' createuser

FROM missingskusubscriptionall
WHERE (SubscriptionID,sku,usage_date) in 
  ( 
    select * 
    from missingsubsku_multiplecomsumptiontype_grp_Same_day 
  )
GROUP BY 1,2,5

''' ) 

missingsubsku_multiplecomsumptiontype.createOrReplaceTempView('missingsubsku_multiplecomsumptiontype')

#insert for this after RI logic to break royalty date with RI ,payg same month.
#missing completely from the royalty data - with sub sku having multiple consumption type - complete data for  multiple sub sku 

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Specific Month - Missing Royalty Records
# MAGIC `Missing Subscription SKU from Royalty(Specific Month) - Insert azure_carveout `
# MAGIC - `start_date`: First day of the month of `usage_date`
# MAGIC - `end_date`: Last day of the month of `usage_date`
# MAGIC - `List Price` from it_sfdc_silver.list_prices
# MAGIC - `Cust Price` = List Price * (100 - Default Discount Percent)/100
# MAGIC - `RevShare Price` = 0.85 * Cust Price
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Multiple Consumption Types in a Specific Month - Missing Royalty Records

# COMMAND ----------

missingskusubscription_specificmonth = spark.sql(f''' 
SELECT 

  date_add(last_day(add_months(usage_date, -1)),1) start_date,
  last_day(usage_date) end_date  , 
  a.usage_date,
  a.SubscriptionID,
  coalesce(ss.account__c , a.accountId) accountId ,
  a.aggorder as Consumptiontype,
  a.usage_Sku sku,

  coalesce(govlr.list_Price,lr.list_Price)  list_price,
  coalesce(govlr.list_Price,lr.list_Price)   * ( (100-{discount_percent}) /100) custprice,
  0.85 * (coalesce(govlr.list_Price,lr.list_Price)   * ( (100-{discount_percent}) /100)) revshareprice,
  'Missing Subscription SKU from Royalty(Specific Month) - Insert azure_carveout ' || current_user as createuser	
from 
{AZURE_RATED_USAGE} a 
left join  {AZURE_RATES_STG} ar
on lower(a.usage_sku) = lower(ar.Sku)
and lower(ar.SubscriptionID) = lower(a.SubscriptionID)
and usage_date between Effective_start_date and Effective_end_date

left join {LIST_PRICE_TABLE} lr
on lower(a.usage_sku) = lower(lr.sku)
and upper(lr.type) ='E2'
and a.usage_date between lr.start_date and lr.end_date
and lower(lr.platform) = 'azure'

left join {LIST_PRICE_TABLE} govlr
on lower(a.usage_sku) = lower(govlr.sku)
and upper(govlr.type) ='GOV'
and a.usage_date between govlr.start_Date and govlr.end_Date
and govlr.platform = 'azure'


left join sfdcaccnount_subscription ss
  on lower(ss.azureSubscriptionId__c)  = lower(a.SubscriptionID)

LEFT JOIN (select distinct Sku,SubscriptionID from  missingskusubscriptionall ) ms
  on lower(a.usage_SKU) = lower(ms.Sku)
  and lower(a.SubscriptionID) = lower(ms.SubscriptionID)


where  a.usage_date between '{ratesloadstartdate_date}' and  '{royaltymaxdate_inc_mnth_rylty}' 
   and a.platform = 'azure'
   and ar.SubscriptionID is NULL 
   and ms.subscriptionId is NULL          -- Filter records missing in Royalty only for a specific month

   order by 2,1
''')
 
missingskusubscription_specificmonth.createOrReplaceTempView('missingskusubscription_specificmonth')


#missing for specific months from the royalty data 

# COMMAND ----------

missingsubsku_multiplecomsumptiontype_grp_sm  =  spark.sql('''
                                        select SubscriptionID,
                                               sku   
                                        From missingskusubscription_specificmonth  
                                        group by 1,2 
                                        having count(distinct Consumptiontype ) >1 
                                        ''') 
#sm - specific month

missingsubsku_multiplecomsumptiontype_grp_sm.createOrReplaceTempView('missingsubsku_multiplecomsumptiontype_grp_sm')

#multiple consumption type for specific month missing from royalty - (Distinct sub sku)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Staging: Multiple Consumption Type in same month

# COMMAND ----------

ripaygsamemonth = spark.sql(f'''
                            select Billing_Month,
                                   subscriptionid, 
                                   accountid , 
                                   sku,
                                   Effective_start_date,
                                   Effective_end_date , 
                                   count(distinct ConsumptionType) 
                            from {AZURE_RATES_STG}

group by 1,2,3,4,5,6
having count(distinct ConsumptionType  ) > 1
order by 1,2,3,4,5,6''')

ripaygsamemonth.createOrReplaceTempView("ripaygsamemonth")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Burst Application Check
# MAGIC - Next RI Start Date `nxtRIstartdt`: The next startDate within the same group (`SubscriptionID`, `sfdcAccountID`)
# MAGIC - Burst Application Check Condition: 
# MAGIC   - Usage Burst Date is populated in bi_aggorders
# MAGIC   - OR The Next RI Start Date occurs after Usage Burst Date

# COMMAND ----------

bi_aggorders_with_notapplicableburst = spark.sql(f'''

select SubscriptionID,
        Scope,
        startDate,
        endDate ,
        usageBurstDate,  
        lead(startDate) over(partition by SubscriptionID ,sfdcAccountID order by startdate) nxtRIstartdt ,  
        case when usageBurstdate is not null 
              and  lead(startDate) over(partition by SubscriptionID ,sfdcAccountID order by startdate) < usageBurstDate 
                then 'burst not applicable' 
            else null 
        end burst_application ,
        sfdcAccountID

from {BI_AGG_ORDERS} a  
where startDate > '2018-05-01' 
and platform = 'azure'  

''' ) 

bi_aggorders_with_notapplicableburst.createOrReplaceTempView ('bi_aggorders_with_notapplicableburst') 

# COMMAND ----------

ri_daily_notapplicableburst = spark.sql(f'''
--adding this logic as per BSEDATA-4326

select SubscriptionID,
        AppliedScopeType as Scope,
        startDate,
        endDate ,
        EstimatedBurstDate usageBurstDate,  
        lead(startDate) over(partition by SubscriptionID ,sfdcAccountID order by startdate) nxtRIstartdt ,  
        case when usageBurstdate is not null 
              and  lead(startDate) over(partition by SubscriptionID ,sfdcAccountID order by startdate) < usageBurstDate 
                then 'burst not applicable' 
            else null 
        end burst_application ,
        sfdcAccountID

from {RI_TABLE} a  
where processDate = (select max(processdate) from {RI_TABLE})
--where startDate > '2018-05-01' 
--and platform = 'azure'  

''' ) 

ri_daily_notapplicableburst.createOrReplaceTempView ('ri_daily_notapplicableburst') 

# COMMAND ----------

bi_aggorders_with_notapplicableburst_with_ri = spark.sql(f'''

select * from ri_daily_notapplicableburst
UNION 
select * From bi_aggorders_with_notapplicableburst biagg
where not exists
(select 1 from ri_daily_notapplicableburst ri where    biagg.SubscriptionID = ri.SubscriptionID)
'''  )


bi_aggorders_with_notapplicableburst_with_ri.createOrReplaceTempView ('bi_aggorders_with_notapplicableburst_with_ri') 

# COMMAND ----------

biagg_dates = spark.sql('''

select ri.* ,
       ba.startdate, 
       burst_application,
       case when ba.usageBurstDate is not null 
               then NULL 
            else ba.enddate 
            end enddate, 
            ba.usageBurstDate ,
            case when ( startdate between Effective_start_date and Effective_end_date 
                     and enddate between Effective_start_date and Effective_end_date ) 
                  then 'both startdate and enddate'
                                                                
                 when  ( startdate between Effective_start_date and Effective_end_date 
                     and usageBurstDate between Effective_start_date and Effective_end_date ) 
                  then 'both startdate and usageburstdate'
                                                                
                 when ( enddate between Effective_start_date and Effective_end_date 
                     and usageBurstDate between Effective_start_date and Effective_end_date )  
                  then  'both enddate and usageburstdate'
                                                                
                 when ( enddate between Effective_start_date and Effective_end_date 
                     and usageBurstDate between Effective_start_date and Effective_end_date 
                     and  startdate between Effective_start_date and Effective_end_date ) 
                  then 'all three'
                                                                       
                 when startdate between Effective_start_date and Effective_end_date 
                  then 'startdate'
                                                                
                 when enddate between Effective_start_date and Effective_end_date 
                  then 'enddate'
               
                 when usageBurstDate between Effective_start_date and Effective_end_date  
                  then 'usageburstdate' end type

from  ripaygsamemonth ri
INNER JOIN bi_aggorders_with_notapplicableburst_with_ri ba --BSEDATA 4326
   On ri.SubscriptionID = ba.SubscriptionID

where ( coalesce(usageBurstDate,enddate) between Effective_start_date and Effective_end_date  
      or startdate between Effective_start_date and Effective_end_date 
      or usageBurstDate between Effective_start_date and Effective_end_date )

order by 1,2,3,4 ''' ) 

biagg_dates.createOrReplaceTempView('biagg_dates')

# COMMAND ----------

biagg_dates_shared_Accnt = spark.sql(
    """
    WITH single_subs AS (
        SELECT DISTINCT subscriptionid, sku, billing_month
        FROM biagg_dates
    )

    SELECT DISTINCT 
           ri.*, 
           ba.startdate, 
           burst_application,
           CASE 
               WHEN ba.usageBurstDate IS NOT NULL THEN NULL 
               ELSE ba.enddate 
           END AS enddate, 
           ba.usageBurstDate,
           CASE 
               WHEN (startdate BETWEEN Effective_start_date AND Effective_end_date 
                     AND enddate BETWEEN Effective_start_date AND Effective_end_date) THEN 'both startdate and enddate'
               WHEN (startdate BETWEEN Effective_start_date AND Effective_end_date 
                     AND usageBurstDate BETWEEN Effective_start_date AND Effective_end_date) THEN 'both startdate and usageburstdate'
               WHEN (enddate BETWEEN Effective_start_date AND Effective_end_date 
                     AND usageBurstDate BETWEEN Effective_start_date AND Effective_end_date) THEN 'both enddate and usageburstdate'
               WHEN (startdate BETWEEN Effective_start_date AND Effective_end_date 
                     AND enddate BETWEEN Effective_start_date AND Effective_end_date 
                     AND usageBurstDate BETWEEN Effective_start_date AND Effective_end_date) THEN 'all three'
               WHEN startdate BETWEEN Effective_start_date AND Effective_end_date THEN 'startdate'
               WHEN enddate BETWEEN Effective_start_date AND Effective_end_date THEN 'enddate'
               WHEN usageBurstDate BETWEEN Effective_start_date AND Effective_end_date THEN 'usageburstdate'
           END AS type

    FROM ripaygsamemonth ri
    INNER JOIN bi_aggorders_with_notapplicableburst_with_ri ba
        ON ri.accountid = ba.sfdcAccountID

    LEFT JOIN single_subs ss
        ON ri.SubscriptionID = ss.SubscriptionID
        AND ri.sku = ss.sku
        AND ri.billing_month = ss.billing_month  -- Ensure same subscription, sku, and month are not reprocessed

    WHERE Scope = 'Shared'
      AND (
            enddate BETWEEN Effective_start_date AND Effective_end_date OR
            startdate BETWEEN Effective_start_date AND Effective_end_date OR
            usageBurstDate BETWEEN Effective_start_date AND Effective_end_date
          )
      AND ss.SubscriptionID IS NULL  -- Avoid reprocessing shared records also present as single

    ORDER BY 1, 2, 3, 4
    """
)

biagg_dates_shared_Accnt.createOrReplaceTempView("biagg_dates_shared_Accnt")

# where subscriptionid = 'a6c3b779-1b87-4257-9b7a-5017a0b61aca'  
# and sku = 'PREMIUM_ALL_PURPOSE_COMPUTE' 
# and Billing_Month = 202201


# COMMAND ----------

rankedbiaggdates_single = spark.sql(
    """
    SELECT *, 
           LEAD(date_type, 1) OVER (PARTITION BY Billing_Month, subscriptionid, sku ORDER BY rnk) AS nxt_date,
           LEAD(type, 1) OVER (PARTITION BY Billing_Month, subscriptionid, sku ORDER BY rnk) AS next_type
    FROM (
        SELECT *, 
               ROW_NUMBER() OVER (PARTITION BY Billing_Month, subscriptionid, sku ORDER BY date_type, type) AS rnk
        FROM (
            SELECT Billing_Month,
                   subscriptionid,
                   CASE 
                       WHEN burst_application = 'burst not applicable' AND type LIKE '%usageburstdate%' 
                       THEN 'not_applicable_type' 
                       ELSE 'applicable_type' 
                   END AS type_application,
                   accountid,
                   sku,
                   Effective_start_date,
                   Effective_end_date,
                   date_type,
                   type
            FROM (
                SELECT Billing_Month,
                       subscriptionid,
                       burst_application,
                       accountid,
                       sku,
                       Effective_start_date,
                       Effective_end_date,
                       CASE 
                           WHEN type = 'usageburstdate' THEN usageBurstDate
                           WHEN type = 'enddate' THEN enddate
                           WHEN type = 'startdate' THEN startdate
                           WHEN type = 'both enddate and usageburstdate' THEN usageBurstDate
                           WHEN type = 'both startdate and enddate' THEN startdate
                       END AS date_type,
                       CASE 
                           WHEN type = 'both enddate and usageburstdate' THEN 'usageburstdate from enddate and usageburstdate'
                           WHEN type = 'both startdate and enddate' THEN 'startdate from both startdate and enddate'
                           ELSE type 
                       END AS type
                FROM biagg_dates

                UNION

                SELECT Billing_Month,
                       subscriptionid,
                       burst_application,
                       accountid,
                       sku,
                       Effective_start_date,
                       Effective_end_date,
                       CASE 
                           WHEN type = 'both startdate and enddate' THEN enddate 
                       END AS date_type,
                       CASE 
                           WHEN type = 'both startdate and enddate' THEN 'enddate from both startdate and enddate' 
                           ELSE NULL 
                       END AS type
                FROM biagg_dates
                WHERE type LIKE '%both%'
            ) a
            WHERE date_type IS NOT NULL
        ) 
        WHERE type_application = 'applicable_type'
        ORDER BY subscriptionid, accountid, Billing_Month, date_type, sku
    )
    """
)

rankedbiaggdates_single.createOrReplaceTempView("rankedbiaggdates_single")


# COMMAND ----------

rankedbiaggdates_shared = spark.sql('''

SELECT *, 
       LEAD(date_type, 1) OVER (PARTITION BY Billing_Month, subscriptionid, sku ORDER BY rnk) AS nxt_date,
       LEAD(type, 1) OVER (PARTITION BY Billing_Month, subscriptionid, sku ORDER BY rnk) AS next_type
FROM (

    SELECT *, 
           ROW_NUMBER() OVER (PARTITION BY Billing_Month, subscriptionid, sku ORDER BY date_type, type) AS rnk
    FROM (

        SELECT Billing_Month, 
               subscriptionid,
               CASE 
                   WHEN burst_application = 'burst not applicable' AND type LIKE '%usageburstdate%' THEN 'not_applicable_type'
                   ELSE 'applicable_type' 
               END AS type_application,
               accountid,
               sku,
               Effective_start_date,
               Effective_end_date,
               date_type,
               type
        FROM (
            SELECT Billing_Month,
                   subscriptionid,
                   burst_application,
                   accountid,
                   sku,
                   Effective_start_date,
                   Effective_end_date,
                   CASE 
                       WHEN type = 'usageburstdate' THEN usageBurstDate
                       WHEN type = 'enddate' THEN enddate
                       WHEN type = 'startdate' THEN startdate
                       WHEN type = 'both enddate and usageburstdate' THEN usageBurstDate
                       WHEN type = 'both startdate and enddate' THEN startdate
                   END AS date_type,
                   CASE 
                       WHEN type = 'both enddate and usageburstdate' THEN 'usageburstdate from enddate and usageburstdate'
                       WHEN type = 'both startdate and enddate' THEN 'startdate from both startdate and enddate'
                       ELSE type 
                   END AS type
            FROM biagg_dates_shared_Accnt

            UNION

            SELECT Billing_Month,
                   subscriptionid,
                   burst_application,
                   accountid,
                   sku,
                   Effective_start_date,
                   Effective_end_date,
                   CASE 
                       WHEN type = 'both startdate and enddate' THEN enddate 
                   END AS date_type,
                   CASE 
                       WHEN type = 'both startdate and enddate' THEN 'enddate from both startdate and enddate'
                       ELSE NULL 
                   END AS type
            FROM biagg_dates_shared_Accnt
            WHERE type LIKE '%both%'

        ) a 
        WHERE date_type IS NOT NULL

    ) 
    WHERE type_application = 'applicable_type'
    ORDER BY subscriptionid, accountid, Billing_Month, date_type, sku

)
''')

rankedbiaggdates_shared.createOrReplaceTempView('rankedbiaggdates_shared')


# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

deletesinglescopeseq  = f'''

delete from {BI_AGG_SINGLE_SCOPE_TABLE} '''

sql(deletesinglescopeseq).show()

insertsinglescopeseq = f'''

insert into {BI_AGG_SINGLE_SCOPE_TABLE}

select * From rankedbiaggdates_single where rnk  = 1 '''

sql(insertsinglescopeseq).show()

# COMMAND ----------


deletesharedscopeseq  = f'''

delete from {BI_AGG_SHARED_SCOPE_TABLE} '''

sql(deletesharedscopeseq).show()

insertsharedscopeseq = f'''

insert into {BI_AGG_SHARED_SCOPE_TABLE}

select * From rankedbiaggdates_shared where rnk  = 1 '''

sql(insertsharedscopeseq).show()



# COMMAND ----------


updatestartdate = f'''
--This is required since next start date is not applicable here since we have to take the earliest RI 
Update {BI_AGG_SINGLE_SCOPE_TABLE}
SET nxt_date = NULL
where type = 'startdate' and next_Type = 'startdate' '''

sql(updatestartdate).show()


# COMMAND ----------



updatestartdateshared = f'''
--This is required since next start date is not applicable here since we have to take the earliest RI 
Update {BI_AGG_SHARED_SCOPE_TABLE}
SET nxt_date = NULL
where type = 'startdate' and next_Type = 'startdate' '''

sql(updatestartdateshared).show()



# COMMAND ----------

mergesingleri_Nextdate_notnull = f'''MERGE INTO  {AZURE_RATES_STG}  ar
USING ( select * From {BI_AGG_SINGLE_SCOPE_TABLE} where nxt_date is not NULL ) ss
ON ar.SubscriptionID = ss.SubscriptionID
and ar.sku = ss.sku
and ar.Billing_Month = ss.Billing_Month
WHEN MATCHED THEN
UPDATE SET  
   Effective_end_date  = case 
   
                             
                                   
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = date_add(last_day(add_months(ss.date_type, -1)),1)   and  cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType = 'PAYG' then ss.nxt_date
                                   
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = date_add(last_day(add_months(ss.date_type, -1)),1)   and  cast(ss.date_type as date)  <  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType ='PAYG' then ss.nxt_date -1
   
   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and datediff(nxt_date,date_type )  =  1
                                   and ar.ConsumptionType ='RI' then ss.date_type -1
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and datediff(nxt_date,date_type )  =  1
                                   and ar.ConsumptionType = 'PAYG' then ss.nxt_date -1
                                   
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType ='RI' then ss.date_type -1
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType = 'PAYG' then ss.nxt_date 
                               
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType ='RI' then ss.date_type -1
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType = 'PAYG' then ss.nxt_date 
                               
                               
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  <>  cast(ss.nxt_date as date) 
                                    and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType ='RI' then ss.date_type
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  <>  cast(ss.nxt_date as date) 
                                   and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType = 'PAYG' then ss.nxt_date -1
                                   
                             else ss.Effective_end_date end
                                   
                               
                               ,
                               

                               
   Effective_start_date = case 
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = date_add(last_day(add_months(ss.date_type, -1)),1)   and  cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType = 'RI' then ss.nxt_date +1
                                   
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = date_add(last_day(add_months(ss.date_type, -1)),1)   and  cast(ss.date_type as date)  <  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType ='RI' then ss.nxt_date
   
   
      
                                when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and datediff(nxt_date,date_type )  =  1 
                                   and ar.ConsumptionType = 'PAYG' then ss.date_type 
   
                                when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType = 'PAYG' then ss.date_type 
                                   
                               when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                  and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType = 'PAYG' then ss.date_type 
                                   
                              
                                   
                               when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  <>  cast(ss.nxt_date as date) 
                                  and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType = 'PAYG' then ss.date_type + 1 
                               
                               
                               else ss.Effective_start_date end ,
    
   updateuser =  case  when  ss.nxt_date is not NULL then 'Updating the same end date or start date where next date is not null for single ' ||current_user
                       else  'Updating where next date is not null for single '||current_user end   ,
            
            
                updatetimestamp = current_Timestamp'''
    
sql(mergesingleri_Nextdate_notnull).show()

# COMMAND ----------

insertsingleri_nxtdate = f'''INSERt INTO  {AZURE_RATES_STG} 
 

SELECT 

  ba.Billing_Month,
  ba.SubscriptionID ,
  --NULL as reservationOrderID,
  ba.accountId,
  'RI' ConsumptionType,
  ba.Sku,
  case when  cast(ba.date_type as date)  =  cast(ba.nxt_date as date) then  ba.nxt_date +1 else ba.nxt_date end  Effective_start_date,
  last_day(ba.nxt_date) Effective_end_date,
  ars.listPrice,
  ars.custprice,
  ars.RevShareFloor ,
  ars.revshareprice,
  ars.databricksRevenueShare,
  ars.totalUnits ,
  'Single -scope - BI aggorder insert for break up and new RI' || current_user as createuser	,
  current_timestamp as createtimestamp	,
  NULL as updateuser ,
  NULL as updatetimestamp
  
FRom


{BI_AGG_SINGLE_SCOPE_TABLE}   ba
inner join 
{AZURE_RATES_STG} ars

on ba.subscriptionid = ars.subscriptionid
and ba.sku = ars.sku
and ba.Billing_Month = ars.Billing_Month

where ba.nxt_date is not null and ba.type like any ('usageburstdate%','%enddate%')
and ars.ConsumptionType  = 'RI'
-- Allow first day cases when nxt_date is next day (consecutive days)
and (
  (cast(ba.date_type as date) = date_trunc('month', cast(ba.date_type as date)) 
   and datediff(ba.nxt_date, ba.date_type) = 1)
  OR
  (cast(ba.date_type as date) <> date_trunc('month', cast(ba.date_type as date)) 
   and cast(ba.date_type as date) < last_day(cast(ba.date_type as date)))
) 

'''

    
sql(insertsingleri_nxtdate).show()

# COMMAND ----------

mergesingledri = f'''MERGE INTO  {AZURE_RATES_STG}  ar
USING ( select * From {BI_AGG_SINGLE_SCOPE_TABLE} where nxt_date is NULL ) ss
ON ar.SubscriptionID = ss.SubscriptionID
and ar.sku = ss.sku
and ar.Billing_Month = ss.Billing_Month
WHEN MATCHED THEN
UPDATE SET  
   Effective_end_date  = case when ss.nxt_date is NULL and ss.type like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and   ar.ConsumptionType ='RI' then ss.date_type
                              when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date)) and   ar.ConsumptionType ='RI' then ss.date_type -1
                              when ss.nxt_date is NULL and ss.type  = 'startdate' and cast(ss.date_type as date)  =  date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType ='PAYG' then ss.date_type 
                              when ss.nxt_date is NULL and ss.type  = 'startdate' and ar.ConsumptionType ='PAYG' then ss.date_type -1
                               else ss.Effective_end_date end ,
                               
                               
   Effective_start_date = case when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date))  and ar.ConsumptionType ='PAYG'  then ss.date_type + 1 
                               when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date))  and ar.ConsumptionType ='PAYG'  then ss.date_type  
                               when ss.nxt_date is NULL and ss.type  = 'startdate' and cast(ss.date_type as date)  =  date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType ='RI' then ss.date_type + 1 
                               when ss.nxt_date is NULL and ss.type  = 'startdate' and ar.ConsumptionType ='RI' then ss.date_type 
                               else ss.Effective_start_date end ,
    
   updateuser =  case when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and   ar.ConsumptionType ='RI' 
                              then 'Single-Updating RI enddate (to burst or end date) as burst happened or RI ended -before the last day '||current_user 
                      when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date)) and   ar.ConsumptionType ='RI' 
                              then 'Single-Updating RI enddate (as burst or enddate -1)as burst happened or RI ended -at the last day '||current_user
                      when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date))  and ar.ConsumptionType ='PAYG'  
                              then 'Single-Updating PAYG startdate(burstdate +1 or enddate +1) as burst happened or RI ended -before the last day '||current_user
                      when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date))  and ar.ConsumptionType ='PAYG' 
                              then 'Single-Updating PAYG startdate(burstdate  or enddate ) as burst happened or RI ended -at the last day '||current_user
                      when ss.nxt_date is NULL and ss.type  = 'startdate' and ar.ConsumptionType ='PAYG' then 'Single-Updating end date for PAYG as start date - 1 (since new RI has started)' ||current_user
                      when ss.nxt_date is NULL and ss.type  = 'startdate' and ar.ConsumptionType ='RI' then 'Single-Updating start date for RI as start date  (since new RI has started)' ||current_user
                      else 'Single-Updating the same end date or start date' ||current_user end ,
            
            
                updatetimestamp = current_Timestamp'''
    
sql(mergesingledri).show()

# COMMAND ----------

mergesharedri_Nextdate_notnull = f'''MERGE INTO  {AZURE_RATES_STG}  ar
USING ( select * From {BI_AGG_SHARED_SCOPE_TABLE} where nxt_date is not NULL ) ss
ON ar.SubscriptionID = ss.SubscriptionID
and ar.sku = ss.sku
and ar.Billing_Month = ss.Billing_Month
and ar.updateuser is NULL
WHEN MATCHED THEN
UPDATE SET  
   Effective_end_date  = case 
   
   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = date_add(last_day(add_months(ss.date_type, -1)),1)   and  cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType = 'PAYG' then ss.nxt_date
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = date_add(last_day(add_months(ss.date_type, -1)),1)   and  cast(ss.date_type as date)  <  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType ='PAYG' then ss.nxt_date -1
   
                             
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and datediff(nxt_date,date_type )  =  1
                                   and ar.ConsumptionType ='RI' then ss.date_type -1
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and datediff(nxt_date,date_type )  =  1
                                   and ar.ConsumptionType = 'PAYG' then ss.nxt_date -1
                                   
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                  and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType ='RI' then ss.date_type -1
                                  
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                  and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType = 'PAYG' then ss.nxt_date 
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType ='RI' then ss.date_type -1
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType = 'PAYG' then ss.nxt_date 
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  <>  cast(ss.nxt_date as date) 
                                   and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType ='RI' then ss.date_type
                                   
                              when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  <>  cast(ss.nxt_date as date) 
                                   and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType = 'PAYG' then ss.nxt_date -1
                                   
                                   
                               else ss.Effective_end_date end
                               
                 
                 
                 ,
                               
                               
   Effective_start_date = case 

                    when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = date_add(last_day(add_months(ss.date_type, -1)),1)   and  cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType = 'RI' then ss.nxt_date +1
                                   
                    when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = date_add(last_day(add_months(ss.date_type, -1)),1)   and  cast(ss.date_type as date)  <  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType ='RI' then ss.nxt_date  
   
                    when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and datediff(nxt_date,date_type )  =  1 
                                   and ar.ConsumptionType = 'PAYG' then ss.date_type 
                                   
                    when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and ar.ConsumptionType = 'PAYG' then ss.date_type 
   
                    when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  =  cast(ss.nxt_date as date) 
                                   and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType = 'PAYG' then ss.date_type 
                                   

   
   
                   when ss.nxt_date is not  NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and cast(ss.date_type as date)  <>  cast(ss.nxt_date as date) 
                                  and  cast(ss.date_type as date)  <> date_add(last_day(add_months(ss.date_type, -1)),1)  and ar.ConsumptionType = 'PAYG' then ss.date_type + 1 
                               
                               
                               
                   else ss.Effective_start_date end ,
    
   updateuser =  case  when  ss.nxt_date is not NULL then 'Shared scope - Updating the same end date or start date where next date is not null' ||current_user
                       else  'Shared Scope - Updating where next date is not null '||current_user end   ,
            
            
                updatetimestamp = current_Timestamp'''
    
sql(mergesharedri_Nextdate_notnull).show()


# COMMAND ----------

insertsharedri_nxtdate = f'''INSERt INTO  {AZURE_RATES_STG} 
 

SELECT 

  ba.Billing_Month,
  ba.SubscriptionID ,
  --NULL as reservationOrderID,
  ba.accountId,
  'RI' ConsumptionType,
  ba.Sku,
  case when  cast(ba.date_type as date)  =  cast(ba.nxt_date as date) then  ba.nxt_date +1 else ba.nxt_date end  Effective_start_date,
  last_day(ba.nxt_date) Effective_end_date,
  ars.listPrice,
  ars.custprice,
  ars.RevShareFloor ,
  ars.revshareprice,
  ars.databricksRevenueShare,
  ars.totalUnits ,
  'Shared_Scope-BI aggorder insert for break up and new RI' || current_user as createuser	,
  current_timestamp as createtimestamp	,
  NULL as updateuser ,
  NULL as updatetimestamp
  
FRom


{BI_AGG_SHARED_SCOPE_TABLE}   ba
inner join 
{AZURE_RATES_STG} ars

on ba.subscriptionid = ars.subscriptionid
and ba.sku = ars.sku
and ba.Billing_Month = ars.Billing_Month

where ba.nxt_date is not null and ba.type like any ('usageburstdate%','%enddate%')
and ars.ConsumptionType  = 'RI'
-- Allow first day cases when nxt_date is next day (consecutive days)
and (
  (cast(ba.date_type as date) = date_trunc('month', cast(ba.date_type as date)) 
   and datediff(ba.nxt_date, ba.date_type) = 1)
  OR
  (cast(ba.date_type as date) <> date_trunc('month', cast(ba.date_type as date)) 
   and cast(ba.date_type as date) < last_day(cast(ba.date_type as date)))
) 
 and ars.Updateuser not like 'Single-Updating%'

'''

    
sql(insertsharedri_nxtdate).show()

# COMMAND ----------

mergesharedri = f'''MERGE INTO  {AZURE_RATES_STG}  ar
USING ( select * From {BI_AGG_SHARED_SCOPE_TABLE} where nxt_date is NULL ) ss
ON ar.SubscriptionID = ss.SubscriptionID
and ar.sku = ss.sku
and ar.Billing_Month = ss.Billing_Month
and ar.updateuser is NULL
WHEN MATCHED THEN
UPDATE SET  
   Effective_end_date  = case when ss.nxt_date is NULL and ss.type like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and   ar.ConsumptionType ='RI' then ss.date_type
                              when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date)) and   ar.ConsumptionType ='RI' then ss.date_type -1
                              when ss.nxt_date is NULL and ss.type  = 'startdate' and cast(ss.date_type as date)  =  date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType ='PAYG' then ss.date_type 
                              when ss.nxt_date is NULL and ss.type  = 'startdate' and ar.ConsumptionType ='PAYG' then ss.date_type -1
                               else ss.Effective_end_date end ,
                               
                               
   Effective_start_date = case when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date))  and ar.ConsumptionType ='PAYG'  then ss.date_type + 1 
                               when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date))  and ar.ConsumptionType ='PAYG'  then ss.date_type  
                               when ss.nxt_date is NULL and ss.type  = 'startdate' and cast(ss.date_type as date)  =  date_add(last_day(add_months(ss.date_type, -1)),1) and ar.ConsumptionType ='RI' then ss.date_type + 1 
                               when ss.nxt_date is NULL and ss.type  = 'startdate' and ar.ConsumptionType ='RI' then ss.date_type 
                               else ss.Effective_start_date end ,
    
   updateuser =  case when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date)) and   ar.ConsumptionType ='RI' 
                              then 'Shared - Updating RI enddate (to burst or end date) as burst happened or RI ended -before the last day '||current_user 
                      when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date)) and   ar.ConsumptionType ='RI' 
                              then 'Shared -Updating RI enddate (as burst or enddate -1)as burst happened or RI ended -at the last day '||current_user
                      when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  < last_day(cast(ss.date_type as date))  and ar.ConsumptionType ='PAYG'  
                              then 'Shared -Updating PAYG startdate(burstdate +1 or enddate +1) as burst happened or RI ended -before the last day '||current_user
                      when ss.nxt_date is NULL and ss.type  like any ('usageburstdate%','%enddate%') and cast(ss.date_type as date)  = last_day(cast(ss.date_type as date))  and ar.ConsumptionType ='PAYG' 
                              then 'Shared -Updating PAYG startdate(burstdate  or enddate ) as burst happened or RI ended -at the last day '||current_user
                      when ss.nxt_date is NULL and ss.type  = 'startdate' and ar.ConsumptionType ='PAYG' then 'Shared -Updating end date for PAYG as start date - 1 (since new RI has started)' ||current_user
                      when ss.nxt_date is NULL and ss.type  = 'startdate' and ar.ConsumptionType ='RI' then 'Shared -Updating start date for RI as start date  (since new RI has started)' ||current_user
                      else 'Shared -Updating the same end date or start date' ||current_user end ,
            
            
                updatetimestamp = current_Timestamp'''
    
sql(mergesharedri).show()


# COMMAND ----------

Delete_pre  = f'''
DELETE FROM {AZURE_RATES_PRE} '''


sql(Delete_pre).show()

sql(f'''
  Insert into {AZURE_RATES_PRE}
    SELECT 
    SubscriptionID	,
    accountId	,
    ConsumptionType	,
    upper(Sku) SKU	,
    Effective_start_date	,
    Effective_end_date 	,
    listPrice	,
    custprice	,
    RevShareFloor,
    revshareprice	,
    'Royalty' as pipeline,
    createuser	,
    createtimestamp,
    case when count(*) over (partition by subscriptionid, sku, effective_start_date, effective_end_Date) > 1  
    then coalesce(Updateuser,'') || 'ranking mutiple by total units desc' else Updateuser end	as Updateuser ,
    Updatetimestamp,
    STRUCT(
              'Unknown' AS list_price_level,
              'Unknown' AS discount_level,
              ARRAY() AS billing_months
              ) AS paygo_discount_source

    FROM {AZURE_RATES_STG}
    qualify row_number() over (partition by subscriptionid,sku,effective_start_date,effective_end_Date order by totalunits desc ) = 1  
''').show()

# Still some transactions left where not able to break Payg/RI same month - hence qualifying with max total units


# COMMAND ----------

InsertpreRoyaltydefaultfrom_usage = f'''
-- Creating date range for each of the consumption types.


Insert into {AZURE_RATES_PRE}

 SELECT
       
       SubscriptionID ,
       accountId,
       Consumptiontype,
       upper(sku) sku,  
       start_dt ,
       end_Dt ,
       list_price ,
       custprice ,
       NULL as RevShareFloor,
       revshareprice,
       'Default' as pipeline,
      -- total_units,
       'Missing in royalty all multiple consumption type ' || current_user createuser,
        current_timestamp as createtimestamp	,
        NULL as  Updateuser	,
        NULL AS Updatetimestamp,
        STRUCT(
            'Unknown' AS list_price_level,
              'Unknown' AS discount_level,
              ARRAY() AS billing_months
              ) AS paygo_discount_source
        
  FROM

(

Select SubscriptionID ,
       min(accountId) accountId,
       Consumptiontype,
       sku,  
       grp2,
       min(usage_date) start_dt ,
       max(usage_date) end_Dt ,
       min(list_price) list_price ,
       avg(custprice) custprice ,
       min(list_price) * ((100-{discount_percent}) /100) * 0.85 revshareprice

from (
select *, sum(grp) over(PARTITION BY  SubscriptionID, SKU order by usage_date) grp2
FROM (
select * ,lag(consumptiontype)  OVER (PARTITION BY  SubscriptionID, SKU ORDER BY usage_date ) lg , CASE WHEN Consumptiontype =   lag(consumptiontype)  OVER (PARTITION BY  SubscriptionID, SKU ORDER BY usage_date ) THEN 0 ELSE 1 end as grp 
from missingsubsku_multiplecomsumptiontype )

--order by 2,5-- where subscriptionid = '0005674d-8251-408c-93c6-a872578469df' 
) 

group by  1,3,4,5 )


--order by SubscriptionID,sku,min(usage_date)
'''

sql(InsertpreRoyaltydefaultfrom_usage).show()

# inserting the subscription sku with multiple subsription type but missing completely from royalty

# COMMAND ----------

InsertpreRoyaltydefaultfrom_usage_all = f'''


Insert into {AZURE_RATES_PRE}


select  

       SubscriptionID ,
       min(accountId) accountId,
       Consumptiontype,
       UPPER(sku) sku,  
       min(usage_date) start_date,
       '{royaltymaxdate_inc_mnth_rylty}'  end_date,
       min(list_price) list_price ,
       avg(custprice) custprice ,
       NULL as RevShareFloor,
       min(list_price) * ((100-{discount_percent}) /100) * 0.85 revshareprice,
       'Default' as pipeline,
       'Missing in royalty all ' || current_user createuser,
        current_timestamp as createtimestamp	,
        NULL as  Updateuser	,
        NULL AS Updatetimestamp,
        STRUCT(
            'Unknown' AS list_price_level,
              'Unknown' AS discount_level,
              ARRAY() AS billing_months
              ) AS paygo_discount_source

from missingskusubscriptionall  where (SubscriptionID,sku) not in ( 
select SubscriptionID,sku   From missingsubsku_multiplecomsumptiontype_grp )  

group by 1,3,4 '''

sql(InsertpreRoyaltydefaultfrom_usage_all).show()

# inserting all other than the subscription sku with multiple subsription type -  missing completely from royalty

# COMMAND ----------

samedayripayg_for_specific_month_sub_sku = spark.sql( ''' 
select usage_date,SubscriptionID ,sku
From missingskusubscription_specificmonth where (SubscriptionID,sku)  in ( select  SubscriptionID,sku from   missingsubsku_multiplecomsumptiontype_grp_sm )
group by 1,2,3 having count(distinct Consumptiontype) > 1 ''')
                                                     

samedayripayg_for_specific_month_sub_sku.createOrReplaceTempView ('samedayripayg_for_specific_month_sub_sku')       


# even for same day we see multiple consumtion type - beaking transactions on the same day is not possible iwht multiplec consumption types.

# COMMAND ----------

InsertpreRoyaltydefaultfrom_usage_specific_month = f'''


Insert into {AZURE_RATES_PRE}

select 
       SubscriptionID ,
       min(accountId) accountId ,
       Consumptiontype,
       UPPER(sku) sku,  
       (usage_date) start_date,
       (usage_date)  end_date,
       min(list_price) list_price ,
       avg(custprice) custprice ,
       NULL as RevShareFloor,
       avg(list_price) * ((100-{discount_percent}) /100) * 0.85 revshareprice,
       'Default' as pipeline,
       'Missing in royalty specific month multiple consumption type ' || current_user createuser,
        current_timestamp as createtimestamp	,
        NULL as  Updateuser	,
        NULL AS Updatetimestamp,
        STRUCT(
            'Unknown' AS list_price_level,
              'Unknown' AS discount_level,
              ARRAY() AS billing_months
              ) AS paygo_discount_source

From missingskusubscription_specificmonth where (SubscriptionID,sku)  in ( select  SubscriptionID,sku from   missingsubsku_multiplecomsumptiontype_grp_sm )
and (usage_date,SubscriptionID ,sku )  not in ( select * from  samedayripayg_for_specific_month_sub_sku) 

group by 1,3,4,5,6 '''


sql(InsertpreRoyaltydefaultfrom_usage_specific_month).show()

# inserting the subscription sku with multiple subsription type but missing for specific months from royalty - however excluding where we have same day ri/payg

# COMMAND ----------

InsertpreRoyaltydefaultfrom_usage_specific_month_same_day_ri_payg = f'''


Insert into {AZURE_RATES_PRE}

select 
       SubscriptionID ,
       min(accountId) accountId ,
       'RI/PAYG' Consumptiontype,
       UPPER(sku) sku,  
       (usage_date) start_date,
       (usage_date)  end_date,
       min(list_price) list_price ,
       avg(custprice) custprice ,
       NULL as RevShareFloor,
       avg(list_price) * ((100-{discount_percent}) /100) * 0.85 revshareprice,
       'Default' as pipeline,
       'Missing in royalty specific month multiple consumption type with same day 2 consumption types ' || current_user createuser,
        current_timestamp as createtimestamp	,
        NULL as  Updateuser	,
        NULL AS Updatetimestamp,
        STRUCT(
            'Unknown' AS list_price_level,
              'Unknown' AS discount_level,
              ARRAY() AS billing_months
              ) AS paygo_discount_source

From missingskusubscription_specificmonth where (SubscriptionID,sku)  in ( select  SubscriptionID,sku from   missingsubsku_multiplecomsumptiontype_grp_sm )
and (usage_date,SubscriptionID ,sku )   in ( select * from  samedayripayg_for_specific_month_sub_sku) 

group by 1,4,5,6 '''


sql(InsertpreRoyaltydefaultfrom_usage_specific_month_same_day_ri_payg).show()

# inserting the subscription sku with multiple subsription type but missing for specific months from royalty - however INCLUDING where we have same day ri/payg

# COMMAND ----------

InsertpreRoyaltydefaultfrom_usage_specific_month_single_either_payg_or_ri = f'''


Insert into {AZURE_RATES_PRE}

select 
       SubscriptionID ,
       min(accountId) accountId ,
       Consumptiontype,
       UPPER(sku) sku,  
       start_date,
       end_date,
       min(list_price) list_price ,
       avg(custprice) custprice ,
       NULL as RevShareFloor,
       avg(list_price) * ((100-{discount_percent}) /100) * 0.85 revshareprice,
       'Default' as pipeline,
       'Missing in royalty specific month single consumption type ' || current_user createuser,
        current_timestamp as createtimestamp	,
        NULL as  Updateuser	,
        NULL AS Updatetimestamp,
        STRUCT(
            'Unknown' AS list_price_level,
              'Unknown' AS discount_level,
              ARRAY() AS billing_months
              ) AS paygo_discount_source

From missingskusubscription_specificmonth where (SubscriptionID,sku)  not in ( select  SubscriptionID,sku from   missingsubsku_multiplecomsumptiontype_grp_sm )


group by 1,3,4,5,6 '''


sql(InsertpreRoyaltydefaultfrom_usage_specific_month_single_either_payg_or_ri).show()

# inserting the subscription sku with single subsription type but missing for specific months from royalty 

# COMMAND ----------

InsertpreRoyaltyPublished_Royalty = f'''
                                   
Insert into {AZURE_RATES_PRE}

SELECT
SubscriptionID	,
accountId	,
ConsumptionType	,
Sku	,
Effective_start_date	,
case when Effective_end_date >= '{ratesloadstartdate_date}' then cast('{ratesloadstartdate_date}' as date) -1 else Effective_end_date end as  Effective_end_date	,
listPrice	,
custprice	,
RevShareFloor	,
revshareprice	,
'Default_Published' as pipeline,
createuser	,
createtimestamp	,
Updateuser	,
Updatetimestamp,
paygo_discount_source

from  {AZURE_RATES} where pipeline in ('Default','Default_Published') and Effective_start_date < '{ratesloadstartdate_date}'  
                                   
UNION
                                   
SELECT 

SubscriptionID	,
accountId	,
ConsumptionType	,
Sku	,
Effective_start_date	,
case when Effective_end_date >= '{ratesloadstartdate_date}' then cast('{ratesloadstartdate_date}' as date) -1 else Effective_end_date end as  Effective_end_date	,
listPrice	,
custprice	,
RevShareFloor	,
revshareprice	,
'Royalty_Published' as pipeline,
createuser	,
createtimestamp	,
Updateuser	,
Updatetimestamp,
paygo_discount_source

From  {AZURE_RATES} where pipeline in ( 'Royalty' ,'Royalty_Published') and Effective_end_date < '{ratesloadstartdate_date}' ''' 

sql(InsertpreRoyaltyPublished_Royalty).show()

# COMMAND ----------
# drop rows from AZURE_RATES_PRE where Effective_start_date > Effective_end_date
drop_roles_from_azure_rates_pre = f'''
DELETE FROM {AZURE_RATES_PRE} 
WHERE Effective_start_date > Effective_end_date
'''
sql(drop_roles_from_azure_rates_pre).show()

