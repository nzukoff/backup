# Databricks notebook source
dbutils.widgets.text("env", "dev")

dbutils.widgets.text("common_catalog", "main")
dbutils.widgets.text("royalty_catalog", "integration")
dbutils.widgets.text("catalog", "integration")
dbutils.widgets.text("schema", "it_consumption_silver")

# COMMAND ----------

# MAGIC %run "./config_azure_pricing"

# COMMAND ----------

locals().update(azure_table_config)

# COMMAND ----------

# creating a union table using workspaces_latest and workspaces_history 
# using workspaces_history as the source table for azure gov cloud data which stopped flowing into workspaces_latest table starting from 2024-07-09

from pyspark.sql.functions import lit, current_date, col

ws_latest = spark.table(WORKSPACES_LATEST)
ws_azure_gov = spark.table(WORKSPACES_HISTORY).filter("date='2024-07-09' and etl_type = 'govcloud' and cloud_type = 'azure'")

ws_latest_cols = set(ws_latest.columns)
ws_azure_gov_cols = ws_latest_cols

# Convert sorted list of column names back into Column objects
ws_latest_cols = [col(c) for c in sorted(ws_latest_cols)]
ws_azure_gov_cols = [col(c) for c in sorted(ws_azure_gov_cols)]

ws_latest_cols.insert(0, current_date().alias("date"))
ws_latest_df = ws_latest.select(ws_latest_cols)

ws_azure_gov_cols.insert(0, "date")
ws_azure_gov_df = ws_azure_gov.select(ws_azure_gov_cols)
ws_azure_gov_df = ws_azure_gov_df.withColumn("is_private_dbfs_access_enabled", col("is_private_dbfs_access_enabled").cast("STRING"))

# Final union of workspaces_latest and workspaces_history table (azure gov cloud workspaces)
ws_latest_df = ws_latest_df.select("*").unionAll(ws_azure_gov_df.select("*"))
ws_latest_df.createOrReplaceTempView("ws_latest_df")

ws_latest_inc_azure_gov = spark.sql("""
SELECT * 
FROM (
    SELECT *, ROW_NUMBER() OVER(PARTITION BY workspace_id ORDER BY date DESC) AS rn 
    FROM ws_latest_df
) 
WHERE rn = 1
""")

ws_latest_inc_azure_gov.createOrReplaceTempView("ws_latest_inc_azure_gov")

# COMMAND ----------

from pyspark.sql.functions import upper, col#change integration to main before prod migration

# added a left join to finance list price table ro calulcate weighted disocount later on using customer dollars and list dollars calculated below 02/06. - https://databricks.atlassian.net/browse/BSEDATA-1263
Royaltydata = spark.sql(f'''
select 
       billingMonthKey,
       SubscriptionguID  ,
       RIConsumption RI_Consumption  , 
       meterName ,
       DatabricksSKU,
       --substring(cast(year as string),0,4)  year ,
       year(date) year,
       month(date) month ,
       TotalUnits,
      -- month , 
       ListPrice,
       CustomerPrice,
       RevShareFloor,
       OfferId,
       case when lower(OfferId) like '%gov' then 'GOV' else 'E2' end as customer_type ,
       CASE 
        WHEN roy.processed_file = 'aug_to_mar_adjustment file' THEN roy.DataBricksRevShare/0.85
        ELSE CustomerPrice * TotalUnits 
       END AS customer_dollars,
       lp.list_price* TotalUnits list_dollars,
       lp.list_price finance_list_price

  From  {ROYALTY_QUARTERLY} roy

  left join 

    (Select sku,start_date, end_date ,type,avg(list_price) list_price FROM {LIST_PRICE_TABLE}  lp where platform =  'azure' group by all) lp

    on lp.sku = roy.DatabricksSku
    and roy.month_end_date between lp.start_date and lp.end_date
    and case when roy.OfferId like '%USGOV%' then 'GOV' else 'E2' end = lp.type


  Where billingMonthKey >=   {billingmonthstartkey}
  
UNION 
select 
       billingMonthKey,
       SubscriptionguID  ,
       RIConsumption RI_Consumption  , 
       meterName ,
       DatabricksSKU,
      -- substring(cast(year as string),0,4) year ,
       year(date) year,
       month(date) month ,
       TotalUnits,
       --month , 
       ListPrice as ListPrice,
       CustomerPrice as CustomerPrice,
       RevShareFloor,
       OfferId,
       case when lower(OfferId) like '%gov' then 'GOV' else 'E2' end as customer_type ,
       CustomerPrice * TotalUnits customer_dollars,
       lp.list_price* TotalUnits list_dollars,
       lp.list_price finance_list_price
  From  {ROYALTY_MONTHLY} roy
  left join 

    (Select sku,start_date, end_date ,type,avg(list_price) list_price FROM {LIST_PRICE_TABLE}  lp where platform =  'azure' group by all) lp

    on lp.sku = roy.DatabricksSku
    and roy.month_end_date between lp.start_date and lp.end_date
    and case when roy.OfferId like '%USGOV%' then 'GOV' else 'E2' end = lp.type 

  where billingMonthKey > {maxbillingmonthkey}''') 

Royaltydata.createOrReplaceTempView('Royaltydata')

# COMMAND ----------

gov_list_rates = spark.sql (''' 
Select distinct 

       RI_Consumption ,
       DatabricksSku Sku ,
      max(listprice)  listprice
      
 From Royaltydata  royalty  where    OfferId like '%USGOV%'  and  listprice <> 0 --and RI_Consumption = 'PAYG'
 GROUP BY 1,2 ''' ) 

gov_list_rates.createOrReplaceTempView('gov_list_rates')

# COMMAND ----------

gov_subscription_list_rates = spark.sql (''' 
Select distinct 
       RI_Consumption ,
       SubscriptionguID subscriptionid,
       DatabricksSku Sku ,
      max(listprice) listprice
      
 From Royaltydata  royalty  where    OfferId like '%USGOV%' -- and  listprice <> 0 --and RI_Consumption = 'PAYG'
 GROUP BY 1,2,3 ''' ) 

gov_subscription_list_rates.createOrReplaceTempView('gov_subscription_list_rates')

# COMMAND ----------

maxbillingmonthkey_inc_mnth_rylty = spark.sql ('select max(billingMonthkey)  From Royaltydata').collect()[0][0]
royatlymaxyear_inc_mnth_rylty  = maxbillingmonthkey_inc_mnth_rylty[0:4]
royatlymaxmonth_inc_mnth_rylty  = maxbillingmonthkey_inc_mnth_rylty[4:6]
royaltymaxdate_inc_mnth_rylty =    spark.sql   (  f'select LAST_DAY  ( cast( (( ({royatlymaxyear_inc_mnth_rylty}) || "-"||({royatlymaxmonth_inc_mnth_rylty})))  as  date) )' ).collect()[0][0]    

royalty_max_minus_twelve_month =  spark.sql(f'''select replace(substr(date_add('{royaltymaxdate_inc_mnth_rylty}',-365),0,7),'-','')||'01' ''' ).collect()[0][0] 

royalty_max_minus_three_month =  spark.sql(f'''select replace(substr(date_add('{royaltymaxdate_inc_mnth_rylty}',-92),0,7),'-','')||'01' ''' ).collect()[0][0] 

royalty_max_minus_twenty_four_month =  spark.sql(f'''select replace(substr(date_add('{royaltymaxdate_inc_mnth_rylty}',-730),0,7),'-','')||'01' ''' ).collect()[0][0] 


#last_day_prev_month = spark.sql('''select date_sub(current_date, dayofmonth(CURRENT_DATE)) ''').collect()[0][0] 

discount_percent = 20
print(maxbillingmonthkey_inc_mnth_rylty,royatlymaxyear_inc_mnth_rylty,royatlymaxmonth_inc_mnth_rylty,royaltymaxdate_inc_mnth_rylty,royalty_max_minus_twelve_month,royalty_max_minus_three_month, royalty_max_minus_twenty_four_month)

# COMMAND ----------

# for ticket https://databricks.atlassian.net/browse/BSEDATA-418
#taking last month for least from finance.listprices
#change finance.list_prices
promotional_lp_for_discount_calc = spark.sql(f''' 

select sku,type,list_Price,start_date,end_Date from {LIST_PRICE_TABLE}  where lower(platform) = 'azure' and lower(promotion) = 'yes' 
and  upper(sku) like any ( '%SQL_PRO%' ,'%SERVERLESS_SQL%')

''' )

promotional_lp_for_discount_calc.createOrReplaceTempView ('promotional_lp_for_discount_calc')

# COMMAND ----------

# for payg active get weighted discount sum(customer_dollars) /sum(list_dollars) from royalty dollars - list dollars is from finance.
# this change 02/08/2024 as per ticket https://databricks.atlassian.net/browse/BSEDATA-1263
# need to handle rev share floor 

last3monthsroyalty_weighted_discount =  spark.sql(f''' 
SELECT SubscriptionGUID , DatabricksSKU , sum(customer_dollars) /sum(list_dollars) royalty_discount,round(avg(finance_list_price),2) listprice, 
min(cast ( ( year || '-'|| month ) as date)) dt

From Royaltydata  where RI_Consumption = 'PAYG'
--and round(customerprice,3) > 0.0 
and cast ( ( year || '-'|| month ) as date) >= add_months(cast  ( '{royaltymaxdate_inc_mnth_rylty}' as date ) ,-3) -- checking past 3 months 
group by 1,2
 ''') 
last3monthsroyalty_weighted_discount.createOrReplaceTempView('last3monthsroyalty_weighted_discount')


# COMMAND ----------

RoyaltyDataUpdated = sql("""
      WITH ranked_dates AS (
          SELECT 
              *,
              dense_rank() OVER (ORDER BY BillingMonthKey DESC) AS date_rank
          FROM Royaltydata
      ),
      bucketed_data AS (
          SELECT 
              *,
              cast((ceiling(date_rank / 3) - 1) as int) AS quarter_bucket
          FROM ranked_dates
      )
      SELECT 
          bd.*,
          qm.quarter_billing_months
      FROM bucketed_data bd
      left join 
      (select quarter_bucket, collect_set(BillingMonthKey) AS quarter_billing_months from bucketed_data group by 1) qm
      on bd.quarter_bucket = qm.quarter_bucket
""")
RoyaltyDataUpdated.createOrReplaceTempView("RoyaltyDataUpdated")


# COMMAND ----------

account_info = sql(f"""
    select distinct  azureSubscriptionId__c, account__c From 
    ( 
    select lower(azureSubscriptionId__c) as azureSubscriptionId__c, account__c , row_number() over (partition by lower(azureSubscriptionId__c) order by case when workspaceStatus__c = 'RUNNING' THEN 1 ELSE 2 END, CreatedDate desc, account__c desc) rnk from {SFDC_WORKSPACE_TABLE}
    where processdate =  (select max(processdate) from  {SFDC_WORKSPACE_TABLE})
    and account__c is not NULL and azureSubscriptionId__c is not null) a
    where rnk = 1
""")

account_info.createOrReplaceTempView("account_info")

# COMMAND ----------

# This is for new subscriptions apply weighted discounts  at acct/sku level (Calculated for past 12 months) - since for new subs account/sku we can get from historical data
# least is added for ticket https://databricks.atlassian.net/browse/BSEDATA-418
accnt_sku_level_payg_discount = spark.sql(f''' 
WITH accnt_sku_lvl_discnt as
(   select account__c  accountid , 
    DatabricksSKU Sku,
    quarter_bucket,
    quarter_billing_months,
    dense_rank() over (partition by account__c, DatabricksSKU  order by quarter_bucket asc) as rank,
    round(avg(customerprice*TotalUnits),3) Totalcustomerprice ,
    round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),3) Totallistprice ,
    try_divide((round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),3) - round(avg(customerprice*TotalUnits),3)), (round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),3))) * 100 discount_percent,
    avg(least(royalty.listprice,lp.list_price)) listprice
    FROM RoyaltyDataUpdated royalty
    LEFT JOIN account_info accnt_info 
    ON lower(accnt_info.azureSubscriptionId__c) = lower(royalty.SubscriptionguID)
    LEFT JOIN promotional_lp_for_discount_calc lp
    on upper(lp.sku) = upper(royalty.DatabricksSKU)
    and upper(royalty.customer_type) = upper(lp.type)
    and cast(substr(royalty.billingmonthkey,0,4)|| '-'|| substr(royalty.billingmonthkey,5,2) ||'-' || substr(royalty.billingmonthkey,7,2) as date) between lp.start_date and lp.end_date
    where royalty.RI_Consumption = 'PAYG' and billingmonthkey > '{royalty_max_minus_twenty_four_month}'
    group by 1,2,3,4
    having  discount_percent > 0 and discount_percent is not null
    and Totalcustomerprice > 0 )

  select * except (rank) from accnt_sku_lvl_discnt where rank = 1 and accountid is not null
''')

accnt_sku_level_payg_discount.createOrReplaceTempView('accnt_sku_level_payg_discount')

# Change qty * listprice - both for customer and list price 

# COMMAND ----------

# This is for new subscriptions apply weighted discounts  at acct/sku level (Calculated for past 12 months) - since for new subs account/sku we can get from historical data
# least is added for ticket https://databricks.atlassian.net/browse/BSEDATA-418 - taking last month for least from finance.listprices
sub_sku_level_payg_discount = spark.sql(f''' 
WITH sub_sku_lvl_discnt as (
    select royalty.SubscriptionguID  SubscriptionID , 
    DatabricksSKU Sku,
    quarter_bucket,
    quarter_billing_months,
    dense_rank() over (partition by royalty.SubscriptionguID, DatabricksSKU  order by quarter_bucket asc) as rank,
    round(avg(customerprice*TotalUnits),3) Totalcustomerprice ,round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),2) Totallistprice ,
    try_divide((round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),3) - round(avg(customerprice*TotalUnits),3)), (round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),3)))  * 100 discount_percent,
    avg(least(royalty.listprice,lp.list_price)) listprice
    FROM RoyaltyDataUpdated royalty
    LEFT JOIN account_info accnt_info 
    ON lower(accnt_info.azureSubscriptionId__c) = lower(royalty.SubscriptionguID)
    LEFT JOIN promotional_lp_for_discount_calc lp
    on upper(lp.sku) = upper(royalty.DatabricksSKU)
    and upper(royalty.customer_type) = upper(lp.type)
    and cast(substr(royalty.billingmonthkey,0,4)|| '-'|| substr(royalty.billingmonthkey,5,2) ||'-' || substr(royalty.billingmonthkey,7,2) as date) between lp.start_date and lp.end_date
    where royalty.RI_Consumption = 'PAYG' and billingmonthkey > '{royalty_max_minus_twenty_four_month}'
    group by 1,2,3,4
    having  discount_percent > 0 
    and Totalcustomerprice > 0
)
select * except(rank) from sub_sku_lvl_discnt where rank = 1 and SubscriptionID is not null

''')

sub_sku_level_payg_discount.createOrReplaceTempView('sub_sku_level_payg_discount')

# display(sub_sku_level_payg_discount)

# Change qty * listprice - both for customer and list price 

# COMMAND ----------

# This is for new subscriptions apply weighted discounts  at acct/sku level (Calculated for past 12 months) - since for new subs account/sku we can get from historical data
# least is added for ticket https://databricks.atlassian.net/browse/BSEDATA-418
sub_level_payg_discount = spark.sql(f''' 
WITH sub_lvl_discnt as
(select 
SubscriptionguID SubscriptionID,
quarter_bucket,
quarter_billing_months,
dense_rank() over (partition by SubscriptionguID order by quarter_bucket asc) as rank,
round(avg(customerprice*TotalUnits),3) Totalcustomerprice ,
round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),2) Totallistprice ,
try_divide((round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),3) - round(avg(customerprice*TotalUnits),3)), (round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),3)))  * 100 discount_percent,
avg(least(royalty.listprice,lp.list_price)) listprice
FROM RoyaltyDataUpdated royalty
LEFT JOIN account_info accnt_info 
ON lower(accnt_info.azureSubscriptionId__c) = lower(royalty.SubscriptionguID)
LEFT JOIN promotional_lp_for_discount_calc lp
on upper(lp.sku) = upper(royalty.DatabricksSKU)
and upper(royalty.customer_type) = upper(lp.type)
and cast(substr(royalty.billingmonthkey,0,4)|| '-'|| substr(royalty.billingmonthkey,5,2) ||'-' || substr(royalty.billingmonthkey,7,2) as date) between lp.start_date and lp.end_date
where royalty.RI_Consumption = 'PAYG' and billingmonthkey > '{royalty_max_minus_twenty_four_month}'
group by 1,2,3
having  discount_percent > 0 
and Totalcustomerprice > 0 )

select * except(rank) from sub_lvl_discnt where rank = 1 and SubscriptionID is not null

''')

sub_level_payg_discount.createOrReplaceTempView('sub_level_payg_discount')

# Change qty * listprice - both for customer and list price 

# COMMAND ----------

#this is for completely new SKUs which are not present in royalty and came in PAYG usage data.Calculate weighted discount at account level
# least is added for ticket https://databricks.atlassian.net/browse/BSEDATA-418

accnt_level_payg_discount = spark.sql(f''' 
WITH accnt_lvl_discnt as 
(select account__c  accountid ,
quarter_bucket,
quarter_billing_months,
dense_rank() over (partition by account__c order by quarter_bucket asc) as rank,
--DatabricksSKU Sku,
round(avg(customerprice*TotalUnits),3) Totalcustomerprice ,round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),2) Totallistprice ,
try_divide((round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),3) - round(avg(customerprice*TotalUnits),3)), (round(avg(least(royalty.listprice,lp.list_price)*TotalUnits),3)))  * 100 discount_percent --- visit later 
FROM RoyaltyDataUpdated royalty
LEFT JOIN account_info accnt_info 
ON lower(accnt_info.azureSubscriptionId__c) = lower(royalty.SubscriptionguID)
LEFT JOIN promotional_lp_for_discount_calc lp
on upper(lp.sku) = upper(royalty.DatabricksSKU)
and upper(royalty.customer_type) = upper(lp.type)
and cast(substr(royalty.billingmonthkey,0,4)|| '-'|| substr(royalty.billingmonthkey,5,2) ||'-' || substr(royalty.billingmonthkey,7,2) as date) between lp.start_date and lp.end_date
where royalty.RI_Consumption = 'PAYG' and billingmonthkey > '{royalty_max_minus_twenty_four_month}'
group by 1,2,3
having  discount_percent > 0 
and Totalcustomerprice > 0 )

select * except(rank) from accnt_lvl_discnt where rank = 1 and accountid is not null

''')

accnt_level_payg_discount.createOrReplaceTempView('accnt_level_payg_discount')
# display(accnt_level_payg_discount)
# Change qty * listprice - both for customer and list price 

# COMMAND ----------

#change finance.list_prices before migration to prod
unique_skus = spark.sql(f''' select distinct sku,type from {LIST_PRICE_TABLE} where lower(platform) = 'azure' ''') 
unique_skus.createOrReplaceTempView('unique_skus')

# COMMAND ----------

billable_usage = sql(f"""
select distinct
    sku_name as sku,
    h.workspace_id as workspaceId,
    list_price as listPrice,
    cloud_customer.azure_subscription_id as azureSubscriptionId,
    i.salesforce_account_id as sfdcAccountId,
    sovereignty
  from {BILLABLE_USAGE} h
  left join ws_latest_inc_azure_gov i
  on h.workspace_id = i.workspace_id 
  where (case when h.product_type = "MOSAIC_ML" then "mct" else cloud end) = 'azure' and h.date > cast('{royaltymaxdate_inc_mnth_rylty}' as date)
""")

billable_usage.createOrReplaceTempView("billable_usage")

sql("""select distinct 
    a.azureSubscriptionId as subscriptionid,
    upper(sku) as sku,
    sfdcAccountId,
    listPrice,
    case when b.azureSubscriptionId is not null then 'GOV' else 'E2' end as type
 from billable_usage a
 left join
 (select distinct azureSubscriptionId
  from billable_usage
  where sovereignty = "GOVCLOUD") b
 on upper(a.azureSubscriptionId) = upper(b.azureSubscriptionId)
 """).createOrReplaceTempView("billable_usage_az_sub_ids")

# COMMAND ----------

sub_sku_date_all_comb = spark.sql(f'''select distinct bd.date usage_date , usg_subs.subscriptionid subscriptionid , us.sku usage_sku, usg_subs.type  Type
from 
(
select distinct 
  usg.subscriptionid as subscriptionid, 
  case when govsubs.subscriptionid is not null then 'GOV' 
  else type end as type 
from billable_usage_az_sub_ids usg 
  
LEFT JOIN 
(Select distinct subscriptionid   from  gov_subscription_list_rates ) govsubs
ON usg.subscriptionid  = govsubs.subscriptionid
  
where usg.subscriptionid <> 'MTMSubscriptionID' 

) usg_subs

INNER JOIN unique_skus us
ON upper(us.type) =  upper(usg_subs.type)

INNER JOIN {BI_DATES} bd
ON 1 = 1



WHERE 
bd.date between cast ('{royaltymaxdate_inc_mnth_rylty}' as date ) + 1  and add_months(current_date,1)''' )

sub_sku_date_all_comb.createOrReplaceTempView('sub_sku_date_all_comb')

 

# COMMAND ----------

#generating all possible subscription sku combinations from finance list prices 
#promotional list price is for the promotional period only 
#change finance.list_prices 

Payg_active_usage = spark.sql(f''' 
   select usg.subscriptionid, 
       usg.usage_date, 
       upper(usg.usage_sku) sku , 
       --first(usg.accountid) over (partition by SubscriptionID order by usage_date desc ) accountid ,
       --first(usg.accountName) over (partition by SubscriptionID order by usage_date desc ) accountName,
      'PAYG' as ConsumptionType , 
      usg.type,  
      flp.list_Price listPrice  , 
      case when  upper(flp.promotion) = 'YES' THEN flp.list_Price else NULL end as promotional_list_price
from sub_sku_date_all_comb usg


left join {LIST_PRICE_TABLE} flp
on  lower(flp.sku) = lower(usg.usage_sku)
and usg.usage_date between flp.start_date and flp.end_date
and lower(flp.platform) = 'azure'
and upper(flp.type) =  upper(usg.type)   
''') 

Payg_active_usage.createOrReplaceTempView('Payg_active_usage')


# COMMAND ----------

# handle for payg usage saw some multiple accounts for a subscription
#paygactive new 
# this logic is updaed cpl is removed as per https://databricks.atlassian.net/browse/BSEDATA-1263 - last3monthsroyalty_weighted_discount rwd join was added to use weighted discount instead of cpl (commented)

latest_discounts = spark.sql(f'''
  
WITH royalty_subscription as  
(select * from {AZURE_RATES_PRE} where ConsumptionType = 'RI' 
--and  Effective_start_date > cast ('{royaltymaxdate_inc_mnth_rylty}' as date )
) ,


 distinct_royalty_subscription as
(select  SubscriptionID ,upper(sku) sku  ,max(effective_end_Date) max_effective_End_Date from {AZURE_RATES_PRE} where ConsumptionType = 'RI' 
--and  Effective_start_date > cast ('{royaltymaxdate_inc_mnth_rylty}' as date ) 
group by 1,2  ) ,

discount_union AS (
    SELECT 
        pau.SubscriptionID AS subscriptionid,
        pau.sku AS sku,
        pau.usage_date,
        ai.account__c,
        NAMED_STRUCT(
            'discount', ssld.discount_percent,
            'quarter', ssld.quarter_bucket,
            'billing_months', ssld.quarter_billing_months,
            'discount_level', 'Subscription SKU Level Discount Percent',
            'priority', 1
        ) AS discount_struct
    FROM Payg_active_usage pau
    LEFT JOIN account_info ai 
    ON lower(ai.azureSubscriptionId__c) = lower(pau.SubscriptionID)
    LEFT JOIN sub_sku_level_payg_discount ssld 
    ON lower(ssld.subscriptionid) = lower(pau.subscriptionid) 
    AND ssld.sku = pau.sku
    WHERE ssld.discount_percent IS NOT NULL AND ssld.quarter_bucket IS NOT NULL

    UNION ALL

    SELECT 
        pau.SubscriptionID,
        pau.sku,
        pau.usage_date,
        ai.account__c,
        NAMED_STRUCT(
            'discount', sld.discount_percent,
            'quarter', sld.quarter_bucket,
            'billing_months', sld.quarter_billing_months,
            'discount_level', 'Subscription Level Discount Percent',
            'priority', 2
        )
    FROM Payg_active_usage pau
    LEFT JOIN account_info ai 
    ON lower(ai.azureSubscriptionId__c) = lower(pau.SubscriptionID)
    LEFT JOIN sub_level_payg_discount sld 
    ON lower(sld.subscriptionid) = lower(pau.subscriptionid)
    WHERE sld.discount_percent IS NOT NULL AND sld.quarter_bucket IS NOT NULL

    UNION ALL

    SELECT 
        pau.SubscriptionID,
        pau.sku,
        pau.usage_date,
        ai.account__c,
        NAMED_STRUCT(
            'discount', asld.discount_percent,
            'quarter', asld.quarter_bucket,
            'billing_months', asld.quarter_billing_months,
            'discount_level', 'Account SKU Level Discount Percent',
            'priority', 3
        )
    FROM Payg_active_usage pau
    LEFT JOIN account_info ai 
    ON lower(ai.azureSubscriptionId__c) = lower(pau.SubscriptionID)
    LEFT JOIN accnt_sku_level_payg_discount asld 
    ON COALESCE(asld.accountid, '-') = COALESCE(ai.account__c, '-') 
    AND lower(asld.sku) = lower(pau.sku)
    WHERE asld.discount_percent IS NOT NULL AND asld.quarter_bucket IS NOT NULL

    UNION ALL

    SELECT 
        pau.SubscriptionID,
        pau.sku,
        pau.usage_date,
        ai.account__c,
        NAMED_STRUCT(
            'discount', ald.discount_percent,
            'quarter', ald.quarter_bucket,
            'billing_months', ald.quarter_billing_months,
            'discount_level', 'Account Level Discount Percent',
            'priority', 4
        )
    FROM Payg_active_usage pau
    LEFT JOIN account_info ai ON lower(ai.azureSubscriptionId__c) = lower(pau.SubscriptionID)
    LEFT JOIN accnt_level_payg_discount ald ON coalesce(ald.accountid, '-') = coalesce(ai.account__c, '-')
    WHERE ald.discount_percent IS NOT NULL AND ald.quarter_bucket IS NOT NULL
),
ranked_discounts AS (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY subscriptionid, sku, usage_date
               ORDER BY discount_struct.quarter ASC, discount_struct.priority ASC
           ) AS rn
    FROM discount_union
),
latest_discount_struct AS (
    SELECT 
        subscriptionid,
        sku,
        usage_date,
        NAMED_STRUCT(
            'discount', discount_struct.discount,
            'billing_months', discount_struct.billing_months,
            'discount_level', discount_struct.discount_level
         ) as latest_discount
    FROM ranked_discounts
    WHERE rn = 1
)

SELECT 
    pau.SubscriptionID,
    ai.account__c AS accountId,
    'PAYG' AS ConsumptionType,
    pau.Sku,
    pau.usage_date,
    COALESCE(pau.promotional_list_price, pau.listPrice) AS listPrice,
    lds.latest_discount,
    pau.promotional_list_price AS pau_promotional_list_price,
    pau.listprice AS pau_listprice,
    rwd.royalty_discount AS rwd_royalty_discount,
    CASE WHEN drs.SubscriptionID IS NULL THEN 'ALL Payg' ELSE 'Present in RI' END AS RI_Presence,
    drs.max_effective_End_Date
FROM Payg_active_usage pau

LEFT JOIN account_info ai ON lower(ai.azureSubscriptionId__c) = lower(pau.SubscriptionID)

LEFT JOIN last3monthsroyalty_weighted_discount rwd 
    ON lower(rwd.SubscriptionGUID) = lower(pau.SubscriptionID)
    AND lower(rwd.databrickssku) = lower(pau.sku)

LEFT JOIN latest_discount_struct lds 
    ON lower(pau.SubscriptionID) = lower(lds.subscriptionid)
    AND pau.sku = lds.sku
    AND pau.usage_date = lds.usage_date

LEFT JOIN royalty_subscription rs 
    ON lower(rs.SubscriptionID) = lower(pau.SubscriptionID)
    AND lower(rs.sku) = lower(pau.sku)
    AND pau.usage_date BETWEEN rs.Effective_start_date AND rs.Effective_end_date

LEFT JOIN distinct_royalty_subscription drs 
    ON lower(drs.SubscriptionID) = lower(pau.SubscriptionID)
    AND lower(drs.sku) = lower(pau.sku)

WHERE rs.SubscriptionID IS NULL
  AND pau.listprice IS NOT NULL

 ''')

latest_discounts.createOrReplaceTempView ('latest_discounts')

display(latest_discounts.filter((upper(col("SubscriptionID")) == "71F9554E-90A0-4A78-B267-3FEFCEF15AE0") & (col("Sku") == "PREMIUM_ALL_PURPOSE_SERVERLESS_COMPUTE_US_WEST_2")))

# COMMAND ----------

paygactive = sql(f"""
    select SubscriptionID,
            accountId ,
            ConsumptionType ,
            Sku ,
            usage_date,
            listPrice ,
            coalesce( pau_promotional_list_price * (  (100-coalesce(latest_discount.discount,{discount_percent})) /100) ,
                        pau_listprice * rwd_royalty_discount ,
                        pau_listPrice * ( (100-coalesce(latest_discount.discount,{discount_percent})) /100) ) as customerprice ,
            
            0.85 * (coalesce
                    ( pau_promotional_list_price * ( (100-coalesce(latest_discount.discount,{discount_percent})) /100) ,
                        pau_listprice * rwd_royalty_discount ,
                        pau_listPrice * ( (100-coalesce(latest_discount.discount,{discount_percent})) /100) ) ) revshareprice,
            RI_Presence,
            max_effective_End_Date,
            CASE
            WHEN pau_promotional_list_price IS NOT NULL
                    AND COALESCE(latest_discount.discount, {discount_percent}) IS NOT NULL THEN 
                    STRUCT(
                    'Promotional List Price' AS list_price_level,
                    COALESCE(latest_discount.discount_level, 'Default Discount 20 Percent') AS discount_level,
                    ARRAY(latest_discount.billing_months) AS billing_months
                    )
            WHEN pau_listprice IS NOT NULL
                    AND rwd_royalty_discount IS NOT NULL THEN 
                    STRUCT(
                    'List Price' AS list_price_level,
                    'Average Royalty Discount' AS discount_level,
                    ARRAY() AS billing_months
                    )
            WHEN pau_listprice IS NOT NULL
                    AND COALESCE(latest_discount.discount, {discount_percent}) IS NOT NULL THEN 
                    STRUCT(
                    'List Price' AS list_price_level,
                    COALESCE(latest_discount.discount_level, 'Default Discount 20 Percent') AS discount_level,
                    ARRAY(latest_discount.billing_months) AS billing_months
                    )
            ELSE 
                    STRUCT(
                    'Unknown' AS list_price_level,
                    'Unknown' AS discount_level,
                    ARRAY() AS billing_months
                    )
            END AS paygo_discount_source
       from 
       latest_discounts            
                 """)

paygactive.createOrReplaceTempView('paygactive')

display(paygactive.filter((upper(col("SubscriptionID")) == "71F9554E-90A0-4A78-B267-3FEFCEF15AE0") & (col("Sku") == "PREMIUM_ALL_PURPOSE_SERVERLESS_COMPUTE_US_WEST_2")))

# COMMAND ----------

#rolling up dates with start and end dates

payg_all_payg_rollup = sql('''
  SELECT 
  SubscriptionID, 
  accountId,
  ConsumptionType, 
  Sku,
  listPrice,
  customerprice,
  revshareprice,
  paygo_discount_source,
  MIN(usage_date) effective_start_date, 
  max(usage_date) effective_end_date

FROM (
  SELECT SUM(cols) over(partition by SubscriptionID, sku order by Rnk) GRP,
   * FROM (
     SELECT  
     CASE WHEN concat_Col = lag(concat_Col) over(partition by SubscriptionID,sku   order by Rnk) THEN 0 ELSE 1 END cols,
     * from (
       SELECT ROW_NUMBER() OVER (partition by SubscriptionID,sku  ORDER BY usage_date) Rnk,
        listprice||customerprice||revshareprice concat_Col,
        *    
        FROM paygactive 
  where ri_presence = 'ALL Payg' 
  qualify row_number() over (partition by SubscriptionID, Sku, usage_date order by listprice) = 1  
  )))
    group by SubscriptionID, 
    accountId,
    ConsumptionType, 
    Sku,
    listPrice,
    customerprice,
    revshareprice, 
    paygo_discount_source,
    GRP
''' ) 

payg_all_payg_rollup.createOrReplaceTempView ('payg_all_payg_rollup')

# COMMAND ----------

# rolling up start and end dates

payg_Present_in_RI_rollup = spark.sql('''
  SELECT 
    SubscriptionID,
    accountId,
    ConsumptionType,
    Sku,
    listPrice,
    customerprice,
    revshareprice,
    paygo_discount_source,
    MIN(usage_date) effective_start_date, 
    max(usage_date) effective_end_date
  FROM (
    SELECT SUM(cols) over(partition by SubscriptionID, sku order by Rnk) GRP,
     * FROM (
       SELECT CASE WHEN concat_Col = lag(concat_Col) over(partition by SubscriptionID, sku order by Rnk) THEN 0 ELSE 1 END cols,
       * from (
         SELECT ROW_NUMBER() OVER (partition by SubscriptionID,sku  ORDER BY usage_date) Rnk,
        listprice||customerprice||revshareprice concat_Col,
         * FROM 
        paygactive 
    where ri_presence = 'Present in RI' 
    and usage_date > max_effective_End_Date
    qualify row_number() over (partition by SubscriptionID, Sku, usage_date order by listprice) = 1  
  )))
  group by SubscriptionID,
    accountId,
    ConsumptionType,
    Sku,
    listPrice,
    customerprice,
    revshareprice,
    paygo_discount_source,
    GRP  
''') 


payg_Present_in_RI_rollup.createOrReplaceTempView ('payg_Present_in_RI_rollup')

# COMMAND ----------



Delete_Target  = f'''
DELETE FROM {AZURE_RATES_PRE} where pipeline ='PAYG' '''


sql(Delete_Target)

sql(f'''INSERT INTO {AZURE_RATES_PRE}

--ALL Payg - for last row for sub sku + 3 months

SELECT  SubscriptionID ,
     --  NULL as reservationOrderID,
       accountId,
       'PAYG' as ConsumptionType,
       upper(Sku) Sku,
       Effective_start_date ,
       Effective_end_date,
       listPrice,
       customerprice,
       NULL as RevShareFloor,
      -- revshareprice,
       revshareprice,
       'PAYG' as pipeline,
      -- NULL as Status,
       'Active PAYG insert ALL payg' || current_user() as currentuser,
       current_timestamp,
       NULL as Updateuser,
       NULL as Updatetimestamp,
       paygo_discount_source
  FROM
   payg_all_payg_rollup

union 

--present as an RI - however for a future dates or gaps.
SELECT  SubscriptionID ,
     --  NULL as reservationOrderID,
       accountId,
       'PAYG' as ConsumptionType,
       upper(Sku) Sku,
       usage_date Effective_start_date ,
       usage_date Effective_end_date,
       listPrice,
       customerprice,
       NULL as RevShareFloor,
      -- revshareprice,
       revshareprice,
       'PAYG' as pipeline,
      -- NULL as Status,
       'Active PAYG insert Present in RI usage_date < max_effective_End_Date' || current_user() as currentuser,
       current_timestamp,
       NULL as Updateuser,
       NULL as Updatetimestamp,
       paygo_discount_source
FROM paygactive

where ri_presence = 'Present in RI' and usage_date < max_effective_End_Date 
qualify row_number() over (partition by SubscriptionID,Sku,usage_date order by listprice  ) = 1 

union 

SELECT  SubscriptionID ,
     --  NULL as reservationOrderID,
       accountId,
       'PAYG' as ConsumptionType,
       upper(Sku) Sku,
       Effective_start_date ,
       Effective_end_date  ,
       listPrice,
       customerprice,
       NULL as RevShareFloor,
      -- revshareprice,
       revshareprice,
       'PAYG' as pipeline,
      -- NULL as Status,
       'Active PAYG insert Present in RI usage_date > max_effective_End_Date' || current_user() as currentuser,
       current_timestamp,
       NULL as Updateuser,
       NULL as Updatetimestamp,
       paygo_discount_source
 FROM 
   payg_Present_in_RI_rollup
   
   ''')
