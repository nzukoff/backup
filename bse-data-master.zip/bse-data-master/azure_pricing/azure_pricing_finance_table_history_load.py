# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC INSERT INTO bdw.msft_royalty_qtrly_total_db
# MAGIC
# MAGIC SELECT 
# MAGIC billingMonthKey  as  BillingMonthKey   ,   
# MAGIC SubscriptionGUID  as  SubscriptionGUID   ,   
# MAGIC RI_Consumption  as  RIConsumption   ,   
# MAGIC OfferId  as  OfferId   ,   
# MAGIC TPID  as  TPID   ,   
# MAGIC TPName  as  TPName   ,   
# MAGIC CustomerName  as  CustomerName   ,   
# MAGIC EnrollmentNumber  as  EnrollmentNumber   ,   
# MAGIC CTC_enrollment  as  CTC   ,   
# MAGIC PostalCode  as  PostalCode   ,   
# MAGIC Country  as  Country   ,   
# MAGIC ResourceGUID  as  ResourceGUID   ,   
# MAGIC MeterName  as  MeterName   ,   
# MAGIC SKUTitle  as  SKUTitle   ,   
# MAGIC CASE WHEN raw.meterName = 'Premium Data Analytics DBU' THEN 'PREMIUM_ALL_PURPOSE_COMPUTE'
# MAGIC WHEN raw.meterName = 'Standard Data Analytics DBU' THEN 'STANDARD_ALL_PURPOSE_COMPUTE'
# MAGIC WHEN raw.meterName = 'Premium Data Engineering DBU' THEN 'PREMIUM_JOBS_COMPUTE'
# MAGIC WHEN raw.meterName = 'Standard Data Engineering DBU' THEN 'STANDARD_JOBS_COMPUTE'
# MAGIC WHEN raw.meterName = 'Premium Data Engineering Light DBU' THEN 'PREMIUM_JOBS_LIGHT_COMPUTE'
# MAGIC WHEN raw.meterName = 'Standard Data Engineering Light DBU' THEN 'STANDARD_JOBS_LIGHT_COMPUTE'
# MAGIC WHEN raw.meterName = 'Premium All-purpose Compute DBU' THEN 'PREMIUM_ALL_PURPOSE_COMPUTE'
# MAGIC WHEN raw.meterName = 'Premium Jobs Compute DBU' THEN 'PREMIUM_JOBS_COMPUTE'
# MAGIC WHEN raw.meterName = 'Premium Jobs Light Compute DBU' THEN 'PREMIUM_JOBS_LIGHT_COMPUTE'
# MAGIC WHEN raw.meterName = 'Standard All-purpose Compute DBU' THEN 'STANDARD_ALL_PURPOSE_COMPUTE'
# MAGIC WHEN raw.meterName = 'Standard Jobs Compute DBU' THEN 'STANDARD_JOBS_COMPUTE'
# MAGIC when raw.meterName = 'Standard Jobs Light Compute DBU' THEN 'STANDARD_JOBS_LIGHT_COMPUTE'
# MAGIC WHEN raw.meterName = 'Premium All-Purpose Photon DBU' THEN 'PREMIUM_ALL_PURPOSE_COMPUTE_(PHOTON)'
# MAGIC WHEN raw.meterName = 'Premium Jobs Compute Photon DBU' THEN 'PREMIUM_JOBS_COMPUTE_(PHOTON)'
# MAGIC WHEN raw.meterName = 'Standard All-Purpose Photon DBU' THEN 'STANDARD_ALL_PURPOSE_COMPUTE_(PHOTON)'
# MAGIC WHEN raw.meterName = 'Standard Jobs Compute Photon DBU' THEN 'STANDARD_JOBS_COMPUTE_(PHOTON)'
# MAGIC WHEN raw.meterName = 'Premium SQL Analytics DBU' THEN 'PREMIUM_SQL_COMPUTE'
# MAGIC WHEN raw.meterName = 'Standard SQL Analytics DBU' THEN 'STANDARD_SQL_COMPUTE'
# MAGIC ELSE raw.meterName END  as  DatabricksSku   ,  
# MAGIC date(int(raw.year)||'-'||raw.month||'-'||'01')  as  Date 	,
# MAGIC dd.calendar_year	,
# MAGIC dd.month_end_date	,
# MAGIC dd.calendar_quarter	,
# MAGIC ListPrice  as  ListPrice   ,   
# MAGIC CustomerPrice  as  CustomerPrice   ,   
# MAGIC UnitPriceDelta  as  UnitPriceDelta   ,   
# MAGIC RevShareFloor  as  RevShareFloor   ,   
# MAGIC totalUnits  as  TotalUnits   ,   
# MAGIC SumofACR_USD  as  ACR_USD   ,   
# MAGIC databricksRevenueShare  as  DataBricksRevShare   ,   
# MAGIC shareat85pct  as  RevShareat85  ,   
# MAGIC CTCAmountUSD  as  CTCAmountUSD   ,   
# MAGIC cast(CTCStartDate as timestamp)  as  CTCStartDate   ,   
# MAGIC cast(CTCEndDate as timestamp)  as  CTCEndDate   ,   
# MAGIC CTCCummACR  as  CTCCummACR   ,   
# MAGIC CTCDone  as  CTCDone   ,   
# MAGIC SumofACR_USDFinalMth  as  ACR_USDFinalMth   ,   
# MAGIC raw.`Non-CTCRevPCT`  as  NonCTCRev   ,   
# MAGIC raw.`SumofNon-CTCRevShare`  as  NonCTCRevShare   ,   
# MAGIC case when RI_Consumption ='RI' THEN NULL else raw.`SumofNon-CTCRevShare` end  as  NonCTCRevShareNoRI   ,   
# MAGIC 'Finance Table msft_royalty_pricing_q222 history'  as  processed_file   ,   
# MAGIC current_date  as  createDate   
# MAGIC
# MAGIC FROM 
# MAGIC
# MAGIC finance.msft_royalty_pricing_q222 raw
# MAGIC
# MAGIC INNER JOIN
# MAGIC
# MAGIC bdw_dev.dim_Dates dd  -- dim_Dates bdw version not available - so hard coded bdw_dev.
# MAGIC on dd.date = date(int(raw.year)||'-'||raw.month||'-'||'01')
# MAGIC
# MAGIC  
# MAGIC where billingmonthkey < '20210101'

# COMMAND ----------

# MAGIC %sql
# MAGIC select billingmonthkey, version,count(*) FRom finance.msft_royalty_pricing_q222  group by 1,2 order by 1,2

# COMMAND ----------

# MAGIC %sql
# MAGIC select billingmonthkey,count(*) from bdw.msft_royalty_qtrly_total_db group by 1 order by 1
