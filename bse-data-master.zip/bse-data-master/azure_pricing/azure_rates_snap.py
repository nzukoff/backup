# Databricks notebook source
# MAGIC %run "./config_azure_pricing"

# COMMAND ----------

process_date = spark.sql('select current_date').collect()[0][0] 
print(process_date)

# COMMAND ----------


## this is merged with the final load script .

Insertazureratessnap = f'''

insert overwrite {target_db}.azure_rates_snap partition(processDate = '{process_date}')
SELECT 
SubscriptionID	,
accountId	,
ConsumptionType	,
Sku	,
Effective_start_date	,
Effective_end_date	,
listPrice	,
custprice	,
RevShareFloor	,
revshareprice	,
pipeline	,
createuser	,
createtimestamp	,
Updateuser	,
Updatetimestamp	


FROM {target_db}.azure_rates '''

sql(Insertazureratessnap)

