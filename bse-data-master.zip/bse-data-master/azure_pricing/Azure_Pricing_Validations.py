# Databricks notebook source
dbutils.widgets.text("env", "prod")

dbutils.widgets.text("common_catalog", "main")
dbutils.widgets.text("royalty_catalog", "integration")
dbutils.widgets.text("catalog", "integration")
dbutils.widgets.text("schema", "it_consumption_silver")

# COMMAND ----------

# MAGIC %run "./config_azure_pricing"

# COMMAND ----------

locals().update(azure_table_config)

# COMMAND ----------


overlapcnt = spark.sql(f''' 
--overlap new query

with azure_rates_rw_num as (
select  row_number() over(order by  SubscriptionID,Sku,Effective_start_date,effective_end_Date ) rw_num , a.* 
 from {AZURE_RATES_PRE} a  )
 
 
 SELECT a.* FROM  azure_rates_rw_num a
INNER JOIN  azure_rates_rw_num b
ON lower(a.SubscriptionID) = lower(b.SubscriptionID)
and lower(a.sku) = lower(b.sku)
where  a.rw_num <> b.rw_num
and b.Effective_start_date between a.Effective_start_date and a.Effective_end_date ''') 

overlapcnt.createOrReplaceTempView('overlapcnt')
 

 

# COMMAND ----------

display(overlapcnt)

row = overlapcnt.count()

if row > 0 :
  raise Exception("Please check overlap in azure pricing data azure rates")


# COMMAND ----------

null_payg_discount_source = sql(f"""
                                select * from {AZURE_RATES_PRE} where pipeline = "PAYG" and paygo_discount_source.list_price_level = "Unknown"
                                """)

if null_payg_discount_source.count() >0:
  display(null_payg_discount_source)

  raise Exception("Please check unknown discount source for azure rates PAYG pipeline.")

# COMMAND ----------

#Validation for royalty missing mapping - quarterly 
#change integration to main before prod migration

royalty_qtrly_not_mapped = spark.sql(f'''select *
from {ROYALTY_QUARTERLY}
where MeterName = DatabricksSku''')


royalty_qtrly_not_mapped.createOrReplaceTempView('royalty_qtrly_not_mapped')

# COMMAND ----------

row_cnt_qtrly_rylty_not_mapped = royalty_qtrly_not_mapped.count()

if row_cnt_qtrly_rylty_not_mapped > 0 :
  raise Exception(f"Please check mapping in quarterly royalty table {ROYALTY_QUARTERLY}")

# COMMAND ----------



#Validation for royalty missing mapping -- monthly
#change integration to main before prod migration

royalty_mnthly_not_mapped = spark.sql(f''' select ResourceGUID, MeterName ,skutitle--,count(*)
from {ROYALTY_MONTHLY}
where MeterName = DatabricksSku''')

royalty_mnthly_not_mapped.createOrReplaceTempView('royalty_mnthly_not_mapped')



# COMMAND ----------

row_cnt_mnthly_rylty_not_mapped = royalty_mnthly_not_mapped.count()

if row_cnt_mnthly_rylty_not_mapped > 0 :
  raise Exception(f"Please check mapping in monthly royalty table {ROYALTY_MONTHLY}")

# COMMAND ----------

#Rev share price > List Price %125 alerts out
listprice_vs_custprice = spark.sql(f''' 
select revshareprice -listprice, listprice, custprice, revshareprice , listprice * 1.25 from {AZURE_RATES}
where custprice > listprice *1.25 and pipeline = 'PAYG' ''') 

listprice_vs_custprice.createOrReplaceTempView('listprice_vs_custprice')
 

# COMMAND ----------

# this needs to be moved to db alerts - since this should not block the ETL.
#rowlp = listprice_vs_custprice.count()


#if rowlp > 10 :
# raise Exception("Please check listprice vs cust price in azure pricing data azure rates")

# COMMAND ----------

# if royalty data is loaded within last 2 days - the snap may reflect it in 1-2 days considering the same for the first 3 days or new royalty load we have to go a quarter back  comparing only last quarter data ,however past 3 days we cna compare the latest royalty data loaded 

#ex on the first date of new quarterly royalty data - snap will have last day azure rates data (not reflecting latest royalty) however azure rates will have the rates data reflecting latest rates.


#max_quarterly_date_old = spark.sql (f'select case when int(current_date - max(createDate)) < 4 then add_months(max(month_end_date),-3) else max(month_end_date) end month_end_date   From {target_db}.{royalty_table} ').collect()[0][0]



max_quarterly_date = spark.sql   (  f'select string(date_add(last_day(add_months(max(effective_end_date) ,-4)),1)) from {AZURE_RATES} where pipeline in ( "Royalty" ,"Royalty_Published" ) ' ) .collect()[0][0] 

# 3 months behind the max royalty load in azure rates and royalty published


print(max_quarterly_date)

# COMMAND ----------

acct_name_id = spark.sql ('''select distinct acc.id id , acc.name name
from main.sfdc_bronze.account acc
where  acc.processDate = ( select max(processDate)  from main.sfdc_bronze.account )''')

acct_name_id.createOrReplaceTempView('acct_name_id')

# COMMAND ----------

live_rates = spark.sql( f'''SELECT date,Subscriptionid,SKU ,pre.accountId  ,acnt.name ,  revshareprice FROM {AZURE_RATES_PRE} pre
INNER JOIN  main.it_core_dim.bi_dates dt
ON 1=1 
LEFT JOIN acct_name_id acnt
ON pre.accountId = acnt.id
where dt.date between Effective_start_date and Effective_end_date
and dt.date < '{max_quarterly_date}' and lower(pipeline) in ('royalty_published','royalty')
group by 1,2,3,4,5,6''') 

live_rates.createOrReplaceTempView ('live_rates')

# COMMAND ----------

#change bi_dates
snap_rates = spark.sql(f'''SELECT date,Subscriptionid,SKU ,snap.accountId  ,acnt.name ,revshareprice FROM {AZURE_RATES_SNAP} snap
INNER JOIN  {BI_DATES} dt
ON 1=1
LEFT JOIN acct_name_id acnt
ON snap.accountId = acnt.id
where dt.date between Effective_start_date and Effective_end_date
and snap.processdate = (select max(processdate) from {AZURE_RATES_SNAP}   )
and  dt.date < '{max_quarterly_date}' and lower(pipeline) in ('royalty_published','royalty')
group by 1,2,3,4,5,6''')

snap_rates.createOrReplaceTempView ('snap_rates')

# COMMAND ----------

live_vs_last_day_comparison = spark.sql( '''SELECT lr.date,lr.Subscriptionid, lr.sku ,lr.accountId,lr.name, lr.revshareprice current_revshareprice,sr.revshareprice snap_revshareprice,(lr.revshareprice - sr.revshareprice) , abs(case when (lr.revshareprice - sr.revshareprice)  = 0 then 0 else ((lr.revshareprice - sr.revshareprice)/ lr.revshareprice) * 100  end ) as percent_diff FROM live_rates  lr
INNER JOIN snap_rates sr
on lr.date = sr.date
and lr.Subscriptionid = sr.Subscriptionid
and lr.sku = sr.sku

where 
abs(case when (lr.revshareprice - sr.revshareprice)  = 0 then 0 else ((lr.revshareprice - sr.revshareprice)/ lr.revshareprice) * 100  end ) > 2 
order by percent_diff desc''' )
live_vs_last_day_comparison.createOrReplaceTempView('live_vs_last_day_comparison')

# COMMAND ----------

rowcnt_live_vs_snap = live_vs_last_day_comparison.count()

if rowcnt_live_vs_snap > 0 :
  raise Exception("Please check historical rates might have changed for snap vs live azure rates")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC row_last_day_comparison = live_vs_last_day_comparison.count()
# MAGIC
# MAGIC if row_last_day_comparison > 0 :
# MAGIC   raise Exception("Please check the rates data for current vs last day in azure pre vs  azure rates snap")

# COMMAND ----------

# MAGIC %sql
# MAGIC select Subscriptionid , sku from (
# MAGIC SELECT lr.date,lr.Subscriptionid, lr.sku,lr.revshareprice current_revshareprice , sr.revshareprice snap_revshareprice,(lr.revshareprice - sr.revshareprice) , abs(case when (lr.revshareprice - sr.revshareprice)  = 0 then 0 else ((lr.revshareprice - sr.revshareprice)/ lr.revshareprice) * 100  end ) as percent_diff FROM live_rates  lr
# MAGIC INNER JOIN snap_rates sr
# MAGIC on lr.date = sr.date
# MAGIC and lr.Subscriptionid = sr.Subscriptionid
# MAGIC and lr.sku = sr.sku
# MAGIC
# MAGIC where 
# MAGIC
# MAGIC abs(case when (lr.revshareprice - sr.revshareprice)  = 0 then 0 else ((lr.revshareprice - sr.revshareprice)/ lr.revshareprice) * 100  end ) > 2 
# MAGIC order by percent_diff desc  ) 
# MAGIC  group by 1,2

# COMMAND ----------

# finance_snap_dbu_dollars = spark.sql ( '''select sfdc_account_id accountid,sfdc_account_name accountname, fiscal_year fiscalyear,fiscal_qtr fiscalqtr ,sum(dbu_dollars) dbu_dollars
#       from main.fin_snap.dbu_dollars_snap  group by 1,2,3,4 order by 3 desc ,4 desc''')

# finance_snap_dbu_dollars.createOrReplaceTempView('finance_snap_dbu_dollars')



# COMMAND ----------

# azure_pre_rates_dollars = spark.sql(f'''select fu.sfdc_account_id accountid ,fu.sfdc_account_name accountName,fu.fiscal_qtr fiscalqtr, fu.fiscal_year fiscalYear, sum (dbu*ar.revshareprice) dbu_dollars
# --sum (dbu*custprice) cust_dollars
# from  main.fin_live_gold.finance_usage fu
# left join {AZURE_RATES_PRE} ar 
# on lower(fu.azure_Sub_ID) = lower(ar.SubscriptionID)
# and lower(ar.sku) = lower(fu.sku)
# and fu.date between Effective_start_date and Effective_end_date
# --where fu.accountid in ( '0016100001BIyGXAA1'  , '0016100000U5DncAAF', '00161000010EmZoAAK') 

# where  lower(platform) = 'azure' 
# --and date >= '2018-05-01'
# group by 1,2,3,4
# order by 1,2,3,4 ''') 

# azure_pre_rates_dollars.createOrReplaceTempView('azure_pre_rates_dollars')


# COMMAND ----------

# %sql
# select fdbu.accountid,fdbu.accountname , fdbu.fiscalYear ,fdbu.fiscalqtr , fdbu.dbu_dollars finance_dbu_dollars, rdbu.dbu_dollars  rates_dbu_dollars from finance_snap_dbu_dollars fdbu
# inner join azure_pre_rates_dollars rdbu
# on fdbu.accountid = rdbu.accountid
# and fdbu.fiscalYear = rdbu.fiscalYear
# and fdbu.fiscalqtr = rdbu.fiscalqtr

# where rdbu.dbu_dollars  < fdbu.dbu_dollars 

# COMMAND ----------


