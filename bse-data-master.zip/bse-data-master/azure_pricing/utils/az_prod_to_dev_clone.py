# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE integration.it_consumption_silver.azure_rates_snap
# MAGIC CLONE main.it_consumption_silver.azure_rates_snap

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE integration.it_consumption_silver.azure_rates 
# MAGIC CLONE main.it_consumption_silver.azure_rates

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE integration.it_consumption_silver.azure_rates_royalty_pre
# MAGIC CLONE main.it_consumption_silver.azure_rates_royalty_pre

