# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE TABLE `bdw`.`azure_rates_royalty_stg` (
# MAGIC   `Billing_Month` STRING,
# MAGIC   `SubscriptionID` STRING,
# MAGIC   `accountId` STRING,
# MAGIC   `ConsumptionType` STRING,
# MAGIC   `Sku` STRING,
# MAGIC   `Effective_start_date` DATE,
# MAGIC   `Effective_end_date` DATE,
# MAGIC   `listPrice` DOUBLE,
# MAGIC   `custprice` DOUBLE,
# MAGIC   `RevShareFloor` DOUBLE,
# MAGIC   `revshareprice` DOUBLE,
# MAGIC    databricksRevenueShare DOUBLE,
# MAGIC    totalUnits DOUBLE,
# MAGIC   `createuser` STRING,
# MAGIC   `createtimestamp` TIMESTAMP,
# MAGIC   `Updateuser` STRING,
# MAGIC   `Updatetimestamp` TIMESTAMP)
# MAGIC USING delta
# MAGIC LOCATION 'dbfs:/mnt/bdw/azure_rates_royalty_stg/'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC CREATE TABLE `bdw`.`azure_rates_royalty_pre`  (
# MAGIC   `SubscriptionID` STRING,
# MAGIC   `accountId` STRING,
# MAGIC   `ConsumptionType` STRING,
# MAGIC   `Sku` STRING,
# MAGIC   `Effective_start_date` DATE,
# MAGIC   `Effective_end_date` DATE,
# MAGIC   `listPrice` DOUBLE,
# MAGIC   `custprice` DOUBLE,
# MAGIC   `RevShareFloor` DOUBLE,
# MAGIC   `revshareprice` DOUBLE,
# MAGIC    pipeline STRING,
# MAGIC   `createuser` STRING,
# MAGIC   `createtimestamp` TIMESTAMP,
# MAGIC   `Updateuser` STRING,
# MAGIC   `Updatetimestamp` TIMESTAMP)
# MAGIC USING delta
# MAGIC LOCATION 'dbfs:/mnt/bdw/azure_rates_royalty_pre/'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE TABLE `bdw`.`azure_rates` (
# MAGIC   `SubscriptionID` STRING,
# MAGIC   `accountId` STRING,
# MAGIC   `ConsumptionType` STRING,
# MAGIC   `Sku` STRING,
# MAGIC   `Effective_start_date` DATE,
# MAGIC   `Effective_end_date` DATE,
# MAGIC   `listPrice` DOUBLE,
# MAGIC   `custprice` DOUBLE,
# MAGIC   `RevShareFloor` DOUBLE,
# MAGIC   `revshareprice` DOUBLE,
# MAGIC    pipeline STRING,
# MAGIC   `createuser` STRING,
# MAGIC   `createtimestamp` TIMESTAMP,
# MAGIC   `Updateuser` STRING,
# MAGIC   `Updatetimestamp` TIMESTAMP)
# MAGIC USING delta
# MAGIC PARTITIONED BY (ConsumptionType)
# MAGIC LOCATION 'dbfs:/mnt/bdw/azure_rates/'
# MAGIC TBLPROPERTIES (
# MAGIC   'delta.logRetentionDuration' = 'interval 400 days')
# MAGIC   
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE TABLE `bdw`.`azure_rates_snap` (
# MAGIC   `SubscriptionID` STRING,
# MAGIC   `accountId` STRING,
# MAGIC   `ConsumptionType` STRING,
# MAGIC   `Sku` STRING,
# MAGIC   `Effective_start_date` DATE,
# MAGIC   `Effective_end_date` DATE,
# MAGIC   `listPrice` DOUBLE,
# MAGIC   `custprice` DOUBLE,
# MAGIC   `RevShareFloor` DOUBLE,
# MAGIC   `revshareprice` DOUBLE,
# MAGIC    pipeline STRING,
# MAGIC    processdate DATE,
# MAGIC   `createuser` STRING,
# MAGIC   `createtimestamp` TIMESTAMP,
# MAGIC   `Updateuser` STRING,
# MAGIC   `Updatetimestamp` TIMESTAMP)
# MAGIC USING delta
# MAGIC PARTITIONED BY (processdate)
# MAGIC LOCATION 'dbfs:/mnt/bdw/azure_rates_snap/'
# MAGIC
# MAGIC   
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE bdw.bi_agg_sub_single_scope_date_seq (
# MAGIC   Billing_Month STRING,
# MAGIC   subscriptionid STRING,
# MAGIC   type_application STRING,
# MAGIC   accountid STRING,
# MAGIC   sku STRING,
# MAGIC   Effective_start_date DATE,
# MAGIC   Effective_end_date DATE,
# MAGIC   date_type DATE,
# MAGIC   type STRING,
# MAGIC   rnk INT,
# MAGIC   nxt_date DATE,
# MAGIC   next_type STRING)
# MAGIC USING delta
# MAGIC LOCATION 'dbfs:/mnt/bdw/bi_agg_sub_single_scope_date_seq/'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE bdw.bi_agg_sub_shared_scope_date_seq (
# MAGIC   Billing_Month STRING,
# MAGIC   subscriptionid STRING,
# MAGIC   type_application STRING,
# MAGIC   accountid STRING,
# MAGIC   sku STRING,
# MAGIC   Effective_start_date DATE,
# MAGIC   Effective_end_date DATE,
# MAGIC   date_type DATE,
# MAGIC   type STRING,
# MAGIC   rnk INT,
# MAGIC   nxt_date DATE,
# MAGIC   next_type STRING)
# MAGIC USING delta
# MAGIC LOCATION 'dbfs:/mnt/bdw/bi_agg_sub_shared_scope_date_seq/'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE bdw.azure_rates_snap (
# MAGIC   SubscriptionID STRING,
# MAGIC   accountId STRING,
# MAGIC   ConsumptionType STRING,
# MAGIC   Sku STRING,
# MAGIC   Effective_start_date DATE,
# MAGIC   Effective_end_date DATE,
# MAGIC   listPrice DOUBLE,
# MAGIC   custprice DOUBLE,
# MAGIC   RevShareFloor DOUBLE,
# MAGIC   revshareprice DOUBLE,
# MAGIC   pipeline STRING,
# MAGIC   processdate DATE,
# MAGIC   createuser STRING,
# MAGIC   createtimestamp TIMESTAMP,
# MAGIC   Updateuser STRING,
# MAGIC   Updatetimestamp TIMESTAMP)
# MAGIC USING delta
# MAGIC PARTITIONED BY (processdate)
# MAGIC LOCATION 'dbfs:/mnt/bdw/azure_rates_snap'
# MAGIC TBLPROPERTIES (
# MAGIC   'Type' = 'EXTERNAL',
# MAGIC   'delta.minReaderVersion' = '1',
# MAGIC   'delta.minWriterVersion' = '2')

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW bdw.azure_rates_finance
# MAGIC     COMMENT 'View for additional finance logic for revshareprice'
# MAGIC     AS SELECT
# MAGIC         SubscriptionID,
# MAGIC         accountId,
# MAGIC         ConsumptionType,
# MAGIC         Sku,
# MAGIC         Effective_start_date,
# MAGIC         Effective_end_date,
# MAGIC         listPrice,
# MAGIC         custprice,
# MAGIC         RevShareFloor,
# MAGIC         revshareprice,
# MAGIC         CASE 
# MAGIC              WHEN accountId <> '00161000005eOe5AAE' and revSharePrice < 0.4 * listPrice then 0.4 * listPrice
# MAGIC              WHEN accountId = '00161000005eOe5AAE' then revshareprice
# MAGIC              -- this account is adobe
# MAGIC              WHEN revshareprice = 0 then listPrice*0.4 
# MAGIC              WHEN revshareprice > 1 then listPrice *0.8*0.85
# MAGIC              
# MAGIC              ELSE revshareprice  end AS AdjRevSharePrice ,         
# MAGIC         pipeline,
# MAGIC         createuser,
# MAGIC         createtimestamp,
# MAGIC         Updateuser,
# MAGIC         Updatetimestamp
# MAGIC     FROM bdw.azure_rates
# MAGIC     
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW bdw_dev.azure_rates_finance
# MAGIC     COMMENT 'View for additional finance logic for revshareprice'
# MAGIC     AS SELECT
# MAGIC         SubscriptionID,
# MAGIC         accountId,
# MAGIC         ConsumptionType,
# MAGIC         Sku,
# MAGIC         Effective_start_date,
# MAGIC         Effective_end_date,
# MAGIC         listPrice,
# MAGIC         custprice,
# MAGIC         RevShareFloor,
# MAGIC         revshareprice,
# MAGIC         CASE 
# MAGIC              WHEN accountId <> '00161000005eOe5AAE' and revSharePrice < 0.4 * listPrice then 0.4 * listPrice
# MAGIC              WHEN accountId = '00161000005eOe5AAE' then revshareprice
# MAGIC              -- this account is adobe
# MAGIC              WHEN revshareprice = 0 then listPrice*0.4 
# MAGIC              WHEN revshareprice > 1 then listPrice *0.8*0.85
# MAGIC              
# MAGIC              ELSE revshareprice  end AS AdjRevSharePrice ,         
# MAGIC         pipeline,
# MAGIC         createuser,
# MAGIC         createtimestamp,
# MAGIC         Updateuser,
# MAGIC         Updatetimestamp
# MAGIC     FROM bdw_dev.azure_rates
# MAGIC     
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE  bdw_dev.azure_rates_ri_list_price (
# MAGIC   SubscriptionID STRING,
# MAGIC   accountId STRING,
# MAGIC   ConsumptionType STRING,
# MAGIC   Sku STRING,
# MAGIC   Effective_start_date DATE,
# MAGIC   Effective_end_date DATE,
# MAGIC   listPrice DOUBLE,
# MAGIC   custprice DOUBLE,
# MAGIC   RevShareFloor DOUBLE,
# MAGIC   revshareprice DOUBLE,
# MAGIC   pipeline STRING,
# MAGIC   dbuPriceDiscount DOUBLE,
# MAGIC   createuser STRING,
# MAGIC   createtimestamp TIMESTAMP,
# MAGIC   Updateuser STRING,
# MAGIC   Updatetimestamp TIMESTAMP)
# MAGIC USING delta
# MAGIC LOCATION 'dbfs:/mnt/bdw_dev/azure_rates_ri_list_price'
# MAGIC TBLPROPERTIES (
# MAGIC   'Type' = 'EXTERNAL',
# MAGIC   'delta.minReaderVersion' = '1',
# MAGIC   'delta.minWriterVersion' = '2')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE  bdw.azure_rates_ri_list_price (
# MAGIC   SubscriptionID STRING,
# MAGIC   accountId STRING,
# MAGIC   ConsumptionType STRING,
# MAGIC   Sku STRING,
# MAGIC   Effective_start_date DATE,
# MAGIC   Effective_end_date DATE,
# MAGIC   listPrice DOUBLE,
# MAGIC   custprice DOUBLE,
# MAGIC   RevShareFloor DOUBLE,
# MAGIC   revshareprice DOUBLE,
# MAGIC   pipeline STRING,
# MAGIC   dbuPriceDiscount DOUBLE,
# MAGIC   createuser STRING,
# MAGIC   createtimestamp TIMESTAMP,
# MAGIC   Updateuser STRING,
# MAGIC   Updatetimestamp TIMESTAMP)
# MAGIC USING delta
# MAGIC LOCATION 'dbfs:/mnt/bdw/azure_rates_ri_list_price'
# MAGIC TBLPROPERTIES (
# MAGIC   'Type' = 'EXTERNAL',
# MAGIC   'delta.minReaderVersion' = '1',
# MAGIC   'delta.minWriterVersion' = '2')

# COMMAND ----------


