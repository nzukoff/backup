# Databricks notebook source
dbutils.widgets.text("env", "dev")

dbutils.widgets.text("common_catalog", "main")
dbutils.widgets.text("royalty_catalog", "integration")
dbutils.widgets.text("catalog", "integration")
dbutils.widgets.text("schema", "it_consumption_silver")

# COMMAND ----------

# MAGIC %run "./config_azure_pricing"

# COMMAND ----------

locals().update(azure_table_config)

# COMMAND ----------

# creating a union table using workspaces_latest and workspaces_history 
# using workspaces_history as the source table for azure gov cloud data which stopped flowing into workspaces_latest table starting from 2024-07-09

from pyspark.sql.functions import lit, current_date, col

ws_latest = spark.table(WORKSPACES_LATEST)
ws_azure_gov = spark.table(WORKSPACES_HISTORY).filter("date='2024-07-09' and etl_type = 'govcloud' and cloud_type = 'azure'")

ws_latest_cols = set(ws_latest.columns)
ws_azure_gov_cols = ws_latest_cols

# Convert sorted list of column names back into Column objects
ws_latest_cols = [col(c) for c in sorted(ws_latest_cols)]
ws_azure_gov_cols = [col(c) for c in sorted(ws_azure_gov_cols)]

ws_latest_cols.insert(0, current_date().alias("date"))
ws_latest_df = ws_latest.select(ws_latest_cols)

ws_azure_gov_cols.insert(0, "date")
ws_azure_gov_df = ws_azure_gov.select(ws_azure_gov_cols)
ws_azure_gov_df = ws_azure_gov_df.withColumn("is_private_dbfs_access_enabled", col("is_private_dbfs_access_enabled").cast("STRING"))

# Final union of workspaces_latest and workspaces_history table (azure gov cloud workspaces)
ws_latest_df = ws_latest_df.select("*").unionAll(ws_azure_gov_df.select("*"))
ws_latest_df.createOrReplaceTempView("ws_latest_df")

ws_latest_inc_azure_gov = spark.sql("""
SELECT * 
FROM (
    SELECT *, ROW_NUMBER() OVER(PARTITION BY workspace_id ORDER BY date DESC) AS rn 
    FROM ws_latest_df
) 
WHERE rn = 1
""")

ws_latest_inc_azure_gov.createOrReplaceTempView("ws_latest_inc_azure_gov")

# COMMAND ----------

#change integration to main before prod migration
Royaltydata = spark.sql(f'''
select 
       billingMonthKey,
       SubscriptionguID  ,
       RIConsumption RI_Consumption  , 
       meterName ,
       DatabricksSKU,
       --substring(cast(year as string),0,4)  year ,
       year(date) year,
       month(date) month ,
      -- month , 
       ListPrice,
       CustomerPrice,
       RevShareFloor,
       OfferId
  From  {ROYALTY_QUARTERLY}
  Where billingMonthKey >=   {billingmonthstartkey}
  
UNION 
select 
       billingMonthKey,
       SubscriptionguID  ,
       RIConsumption RI_Consumption  , 
       meterName ,
       DatabricksSKU,
      -- substring(cast(year as string),0,4) year ,
       year(date) year,
       month(date) month ,
       --month , 
       ListPrice as ListPrice,
       CustomerPrice as CustomerPrice,
       RevShareFloor,
       OfferId
  From  {ROYALTY_MONTHLY}
  where billingMonthKey > {maxbillingmonthkey}''') 

Royaltydata.createOrReplaceTempView('Royaltydata')

# COMMAND ----------

#change integration to main
maxbillingmonthkey = spark.sql(f'select max(billingmonthkey) from {ROYALTY_MONTHLY} ').collect()[0][0] 
royatlymaxyear = maxbillingmonthkey[0:4]
royatlymaxmonth = maxbillingmonthkey[4:6]

royaltymaxdate = spark.sql   (f'select LAST_DAY (cast(((({royatlymaxyear}) || "-"||({royatlymaxmonth})))  as  date) )' ).collect()[0][0]
maxbillingmonthkey_inc_mnth_rylty = spark.sql ('select max(billingMonthkey)  From Royaltydata').collect()[0][0]
royatlymaxyear_inc_mnth_rylty  = maxbillingmonthkey_inc_mnth_rylty[0:4]
royatlymaxmonth_inc_mnth_rylty  = maxbillingmonthkey_inc_mnth_rylty[4:6]
royaltymaxdate_inc_mnth_rylty =    spark.sql(f'select LAST_DAY  ( cast( (( ({royatlymaxyear_inc_mnth_rylty}) || "-"||({royatlymaxmonth_inc_mnth_rylty})))  as  date) )' ).collect()[0][0]     

print(maxbillingmonthkey_inc_mnth_rylty,royatlymaxyear_inc_mnth_rylty,royatlymaxmonth_inc_mnth_rylty,royaltymaxdate_inc_mnth_rylty)
print (royatlymaxyear,royatlymaxmonth,maxbillingmonthkey,royaltymaxdate)

# COMMAND ----------

updated_utilized_rate = spark.sql(f'''
WITH updated_utilized_rate AS
( 
  SELECT
    reservationOrderID,
    processdate,
    UtilizedPercentage,
    MAX(UtilizedPercentage) OVER (PARTITION BY reservationOrderID ORDER BY processdate ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS max_utilized_before
  FROM {RI_TABLE}
)

SELECT msft_ri.ReservationOrderId,  
      msft_ri.subscriptionid,
      msft_ri.sfdcaccountid,
      msft_ri.startdate,
      msft_ri.enddate,
      msft_ri.dbupricediscount,
      CASE 
          WHEN msft_ri.UtilizedPercentage >= 99.99 THEN msft_ri.UtilizedPercentage
          WHEN msft_ri.UtilizedPercentage < 99.99 AND utl.max_utilized_before >= 99.99 THEN 99.99
          ELSE msft_ri.UtilizedPercentage 
      END AS UtilizedPercentage,
      msft_ri.Modified_Date,
      msft_ri.modified_state,
      msft_ri.status,
      msft_ri.AppliedScopeType,
      msft_ri.Month_Start,
      msft_ri.processDate
       
FROM {RI_TABLE} msft_ri
  JOIN updated_utilized_rate utl
    ON msft_ri.reservationOrderID = utl.reservationOrderID
  AND msft_ri.processdate = utl.processdate
''')

updated_utilized_rate.createOrReplaceTempView('updated_utilized_rate')


# COMMAND ----------

azureridata_pre = spark.sql(f'''
--active data for P3s 

select reservationOrderID ,
        SubscriptionID ,
        accountId , 
        ConsumptionType , 
        Effective_start_date, 
        Effective_end_date ,
        dbupricediscount ,
        UtilizedPercentage , 
        Modified_Date ,
        Status  ,
        AppliedScopeType
from ( 
select ReservationOrderId reservationOrderID,  
       subscriptionid SubscriptionID,
       sfdcaccountid accountId,
       'RI' as ConsumptionType,
       startdate Effective_start_date,
       enddate Effective_end_date,
       dbupricediscount,
       UtilizedPercentage,
       Modified_Date,
       'Active' as Status,
       AppliedScopeType,
       row_number() over (partition by subscriptionid order by Month_Start ,cast(replace(utilizedpercentage,'%','') as double) desc, processDate desc, round(dbupricediscount, 3) desc) rnk 
       
from updated_utilized_rate
where subscriptionid is not null
and coalesce(modified_state,status,'active')  not in ( 'Cancelled','Expired')
and coalesce(utilizedpercentage,1) < 99.99
and processdate = (select max(processdate) from updated_utilized_rate )

order by 1 ) 
where rnk = 1 

''')

azureridata_pre.createOrReplaceTempView ('azureridata_pre')


# COMMAND ----------

gov_list_rates = spark.sql (''' 
Select distinct 
       RI_Consumption ,
       DatabricksSku Sku ,
      max(listprice)  listprice
      
From Royaltydata royalty
where OfferId like '%USGOV%'
and listprice <> 0
--and RI_Consumption = 'PAYG'
GROUP BY 1,2 ''' ) 

gov_list_rates.createOrReplaceTempView('gov_list_rates')

# COMMAND ----------

gov_subscription_list_rates = spark.sql (''' 
Select distinct 
       RI_Consumption ,
       SubscriptionguID subscriptionid,
       DatabricksSku Sku ,
      max(listprice) listprice
      
 From Royaltydata  royalty  where    OfferId like '%USGOV%' -- and  listprice <> 0 --and RI_Consumption = 'PAYG'
 GROUP BY 1,2,3 ''' ) 
""
gov_subscription_list_rates.createOrReplaceTempView('gov_subscription_list_rates')

# COMMAND ----------

azureridata_expired_pre  = spark.sql (f'''
--active data for P3s

select reservationOrderID ,
       modified_state,
       SubscriptionID ,
       accountId , 
       ConsumptionType , 
       Effective_start_date, 
       Effective_end_date ,
       dbupricediscount ,
       UtilizedPercentage , 
       Modified_Date ,
       Status  ,
       AppliedScopeType
from ( 
select expireddata.ReservationOrderId reservationOrderID ,  
       expireddata.modified_state modified_state,
       expireddata.subscriptionid SubscriptionID ,
       expireddata.sfdcaccountid accountId ,
       'RI' as ConsumptionType ,
       expireddata.startdate Effective_start_date ,
       expireddata.enddate Effective_end_date,
       expireddata.dbupricediscount,
       expireddata.UtilizedPercentage,
       expireddata.Modified_Date,
       'Active' as Status,
       expireddata.AppliedScopeType,
       row_number() over (partition by expireddata.subscriptionid order by expireddata.enddate desc ) rnk 
       
       from (select * from updated_utilized_rate
       where processdate = (select max(processdate) from updated_utilized_rate ) 
       and subscriptionid is not null 
       and enddate > '{royaltymaxdate_inc_mnth_rylty}') expireddata

       left join azureridata_pre activedata
       on expireddata.subscriptionid = activedata.subscriptionid

where ( coalesce(expireddata.modified_state ,expireddata.status)  in ( 'Expired') or expireddata.utilizedpercentage  >= 99.99 )   

order by 1 ) 
where rnk = 1 ''')

azureridata_expired_pre.createOrReplaceTempView ('azureridata_expired_pre')


# COMMAND ----------

azureridata_expired  = spark.sql (f'''
--looks like multiple RI purchased with same start and end dates and some of them are active - filtering this use case.
--change integraton to main before prod migration

select * 
From azureridata_expired_pre
where ( SubscriptionID ,accountId,Effective_start_date,Effective_end_date) 
      not in (
              select SubscriptionID ,sfdcAccountID,startDate,endDate 
              from updated_utilized_rate  
              where processdate = (select max(processdate) from updated_utilized_rate )  
and  UtilizedPercentage < 99.99 
and   coalesce(modified_state,status,'active')  not in ( 'Cancelled','Expired')  ) 

''')

azureridata_expired.createOrReplaceTempView ('azureridata_expired')


# COMMAND ----------

royaltymaxdate_inc_mnth_rylty

# COMMAND ----------

azureridata_expired_burst = spark.sql (f''' 

-- Joining with agg order for burst date if available
 
select   ri.reservationOrderID ,
          ri.modified_state,
          ri.SubscriptionID ,
          ri.accountId , 
          'RI' as ConsumptionType , 
          ri.Effective_start_date, 
          ri.Effective_end_date ,
          coalesce(ri_new.EstimatedBurstDate, ord.usageBurstDate,ord2.usageBurstDate) usageBurstDate ,
          least(ri.Effective_end_date ,ri_new.EstimatedBurstDate, ord.usageBurstDate,ord2.usageBurstDate) final_End_date,
          ri.dbupricediscount ,
          ri.UtilizedPercentage , 
          ri.Modified_Date ,
          ri.Status  ,
          ri.AppliedScopeType,

case when coalesce(ri_new.EstimatedBurstDate, ord.usageBurstDate,ord2.usageBurstDate)  <= '{royaltymaxdate_inc_mnth_rylty}' then 'N'
     when coalesce(ri_new.EstimatedBurstDate, ord.usageBurstDate,ord2.usageBurstDate) is not NULL then 'Y' 
     when ri.effective_end_Date < current_Date then 'Y'
     when ri.effective_end_Date > current_Date and coalesce(ri_new.EstimatedBurstDate, ord.usageburstdate,ord2.usageBurstDate) is NULL then 'N'
     else 'N' end record
  ,

  --ord.usageBurstDate,
  
  coalesce(ri_new.EstimatedBurstDate, ord2.usageBurstDate) orderidusageburstdate

from azureridata_expired ri

left join {RI_TABLE} ri_new
on ri.reservationOrderID = ri_new.reservationOrderID
and ri_new.processdate = (select max(processdate) from {RI_TABLE})
LEFT JOIN {BI_AGG_ORDERS} ord

ON ord.SubscriptionID = ri.SubscriptionID
and ri.Effective_start_date = ord.startdate
and ord.usageBurstDate is not NULL 


LEFT JOIN {BI_AGG_ORDERS} ord2 -- using order id to get burst date

ON ord2.orderid[0] = ri.reservationorderid
and ri.Effective_start_date = ord2.startdate
and ord2.usageBurstDate is not NULL 

 ''' )



azureridata_expired_burst.createOrReplaceTempView('azureridata_expired_burst')


# COMMAND ----------

azureridata_expired_active = spark.sql ('''

select 
       case when b.subscriptionid  is not null and a.subscriptionid  is not null then 'Subscription present in both active and expired' 
            when b.subscriptionid  is not null and a.subscriptionid  is  null   then  'only present in active'
            when a.subscriptionid  is not null and b.subscriptionid  is  null   then  'only present in expired'
            else 'check' end as presence,
      
       case when b.Effective_start_date <= a.final_End_date then 'overlap' else 'no overlap' end as overlap,  
       
       --b.modified_state  active_modified_state,
       --a.modified_state expired_modified_state,
       
       a.Effective_start_date expired_Effective_start_date,
       a.Effective_end_date expired_Effective_end_date ,
       a.final_End_date expired_final_end_date, 
       case when b.Effective_start_date <= a.final_End_date then a.final_End_date +1 else   b.Effective_start_date end  active_Effective_start_date,
         b.Effective_start_date as active_Effective_start_date_check,
       b.Effective_end_date  active_Effective_end_date,
       b.reservationOrderID active_reservationOrderID,
       a.reservationOrderID expired_reservationOrderID, 
       b.SubscriptionID  active_SubscriptionID,
       a.SubscriptionID expired_SubscriptionID,
       a.accountId  expired_accountid,
       b.accountId active_accountid,
       b.ConsumptionType active_ConsumptionType,
       a.ConsumptionType expired_ConsumptionType, 
       b.dbupricediscount active_dbupricediscount,
       a.dbupricediscount expired_dbupricediscount,
       b.UtilizedPercentage active_UtilizedPercentage,
       a.UtilizedPercentage expired_UtilizedPercentage,
       b.Modified_Date active_Modified_Date,
       a.Modified_Date expired_Modified_Date,
       b.Status active_Status ,
       a.Status expired_Status,
       b.AppliedScopeType active_AppliedScopeType,
       a.AppliedScopeType expired_AppliedScopeType,   
       a.usageBurstDate expired_usageBurstDate
      

From  ( select  * from azureridata_expired_burst where  record = 'Y') a
fULL OUTER JOIN   azureridata_pre b
on a.subscriptionid = b.subscriptionid ''')


azureridata_expired_active.createOrReplaceTempView('azureridata_expired_active')



# COMMAND ----------

azureridata_pre_overlap = spark.sql('''
 
 --ACTIVE 
 SELECT 
     coalesce(active_reservationOrderID ,expired_reservationOrderID)  reservationOrderID , 
       coalesce(active_SubscriptionID, expired_SubscriptionID) SubscriptionID ,
       coalesce(active_accountId,expired_accountId)  accountId ,
       coalesce(active_ConsumptionType, expired_ConsumptionType) ConsumptionType,
       coalesce(active_Effective_start_date ,expired_Effective_start_date) Effective_start_date,
       coalesce(active_Effective_end_date,expired_final_end_Date, expired_Effective_end_date  ) Effective_end_date,
       coalesce(active_dbupricediscount,expired_dbupricediscount) dbupricediscount,
       coalesce(active_UtilizedPercentage,expired_UtilizedPercentage) UtilizedPercentage,
       coalesce(active_Modified_Date , expired_Modified_Date) Modified_Date,
       coalesce(active_Status,expired_Status) Status,
       coalesce(active_AppliedScopeType,expired_AppliedScopeType)  AppliedScopeType
        
  from azureridata_expired_active 
  where presence = 'only present in active'
  
  UNION 
  
  --only in expired
   SELECT 
     coalesce(active_reservationOrderID ,expired_reservationOrderID)  reservationOrderID , 
       coalesce(active_SubscriptionID, expired_SubscriptionID) SubscriptionID ,
       coalesce(active_accountId,expired_accountId)  accountId ,
       coalesce(active_ConsumptionType, expired_ConsumptionType) ConsumptionType,
       coalesce(active_Effective_start_date ,expired_Effective_start_date) Effective_start_date,
       coalesce(active_Effective_end_date, expired_final_end_Date, expired_Effective_end_date  ) Effective_end_date, -- changing and adding final end date
       coalesce(expired_dbupricediscount ,active_dbupricediscount) dbupricediscount,
       coalesce(active_UtilizedPercentage,expired_UtilizedPercentage) UtilizedPercentage,
       coalesce(active_Modified_Date , expired_Modified_Date) Modified_Date,
       coalesce(active_Status,expired_Status) Status,
       coalesce(active_AppliedScopeType,expired_AppliedScopeType)  AppliedScopeType
        
  from azureridata_expired_active 
  where presence = 'only present in expired'
  
  
  
    UNION 
  
  --active,expired together for ovelarp of start and end dates
   SELECT 
     coalesce(active_reservationOrderID ,expired_reservationOrderID)  reservationOrderID , 
       coalesce(active_SubscriptionID, expired_SubscriptionID) SubscriptionID ,
       coalesce(active_accountId,expired_accountId)  accountId ,
       coalesce(active_ConsumptionType, expired_ConsumptionType) ConsumptionType,
       least(active_Effective_start_date ,expired_Effective_start_date) Effective_start_date,
       GREATEST(active_Effective_end_date, expired_final_end_Date,expired_Effective_end_date  ) Effective_end_date,
       coalesce(active_dbupricediscount,expired_dbupricediscount) dbupricediscount,
       coalesce(active_UtilizedPercentage,expired_UtilizedPercentage) UtilizedPercentage,
       coalesce(active_Modified_Date , expired_Modified_Date) Modified_Date,
       coalesce(active_Status,expired_Status) Status,
       coalesce(active_AppliedScopeType,expired_AppliedScopeType)  AppliedScopeType
        
  from azureridata_expired_active 
  where presence = 'Subscription present in both active and expired' and overlap = 'overlap' and active_dbupricediscount = expired_dbupricediscount
  
 UNION 
  
  -- expired for overlap 
   SELECT 
     coalesce(expired_reservationOrderID , active_reservationOrderID )  reservationOrderID , 
       coalesce(expired_SubscriptionID,active_SubscriptionID ) SubscriptionID ,
       coalesce(expired_accountId,active_accountId)  accountId ,
       coalesce(expired_ConsumptionType , active_ConsumptionType) ConsumptionType,
       expired_Effective_start_date Effective_start_date ,
       expired_final_End_date Effective_end_date,
       coalesce(expired_dbupricediscount,active_dbupricediscount) dbupricediscount,
       coalesce(expired_UtilizedPercentage,active_UtilizedPercentage) UtilizedPercentage,
       coalesce(expired_Modified_Date, active_Modified_Date  ) Modified_Date,
       coalesce(expired_Status , active_Status) Status,
       coalesce(expired_AppliedScopeType, active_AppliedScopeType)  AppliedScopeType
        
  from azureridata_expired_active 
  where presence = 'Subscription present in both active and expired' and overlap = 'overlap' and active_dbupricediscount <> expired_dbupricediscount 
  
  
   UNION 
  
  --active for overlap 
  
   SELECT 
     coalesce(active_reservationOrderID ,expired_reservationOrderID)  reservationOrderID , 
       coalesce(active_SubscriptionID, expired_SubscriptionID) SubscriptionID ,
       coalesce(active_accountId,expired_accountId)  accountId ,
       coalesce(active_ConsumptionType, expired_ConsumptionType) ConsumptionType,
       expired_final_End_date + 1  Effective_start_date ,
       active_Effective_end_date Effective_end_date,
       coalesce(active_dbupricediscount,expired_dbupricediscount) dbupricediscount,
       coalesce(active_UtilizedPercentage,expired_UtilizedPercentage) UtilizedPercentage,
       coalesce(active_Modified_Date , expired_Modified_Date) Modified_Date,
       coalesce(active_Status,expired_Status) Status,
       coalesce(active_AppliedScopeType,expired_AppliedScopeType)  AppliedScopeType
        
  from azureridata_expired_active 
  where presence = 'Subscription present in both active and expired' and overlap = 'overlap' and active_dbupricediscount <> expired_dbupricediscount 
  
  
   UNION 
  
  -- expired for no overap present in both active and expired
   SELECT 
     coalesce(expired_reservationOrderID , active_reservationOrderID )  reservationOrderID , 
       coalesce(expired_SubscriptionID,active_SubscriptionID ) SubscriptionID ,
       coalesce(expired_accountId,active_accountId)  accountId ,
       coalesce(expired_ConsumptionType , active_ConsumptionType) ConsumptionType,
       expired_Effective_start_date Effective_start_date ,
       expired_final_End_date Effective_end_date,
       coalesce(expired_dbupricediscount,active_dbupricediscount) dbupricediscount,
       coalesce(expired_UtilizedPercentage,active_UtilizedPercentage) UtilizedPercentage,
       coalesce(expired_Modified_Date, active_Modified_Date  ) Modified_Date,
       coalesce(expired_Status , active_Status) Status,
       coalesce(expired_AppliedScopeType, active_AppliedScopeType)  AppliedScopeType
        
  from azureridata_expired_active 
  where presence = 'Subscription present in both active and expired' and overlap = 'no overlap'
  
  
  
     UNION 
  -- active for no overap present in both active and expired
  
   SELECT 
     coalesce(active_reservationOrderID ,expired_reservationOrderID)  reservationOrderID , 
       coalesce(active_SubscriptionID, expired_SubscriptionID) SubscriptionID ,
       coalesce(active_accountId,expired_accountId)  accountId ,
       coalesce(active_ConsumptionType, expired_ConsumptionType) ConsumptionType,
       active_Effective_start_date Effective_start_date ,
       active_Effective_end_date Effective_end_date,
       coalesce(active_dbupricediscount,expired_dbupricediscount) dbupricediscount,
       coalesce(active_UtilizedPercentage,expired_UtilizedPercentage) UtilizedPercentage,
       coalesce(active_Modified_Date , expired_Modified_Date) Modified_Date,
       coalesce(active_Status,expired_Status) Status,
       coalesce(active_AppliedScopeType,expired_AppliedScopeType)  AppliedScopeType
        
  from azureridata_expired_active 
  where presence = 'Subscription present in both active and expired' and  overlap = 'no overlap'  ''')
  
azureridata_pre_overlap.createOrReplaceTempView ('azureridata_pre_overlap') 


# COMMAND ----------


azureridata = spark.sql(
'''
--just adding this for any pending overlaps 07/15

WITH base AS (
  SELECT *,
    ROW_NUMBER() OVER (PARTITION BY SubscriptionID, reservationOrderID ORDER BY Effective_start_date) AS rn
  FROM azureridata_pre_overlap
),

--- Assign groups where overlap doesn't happen
grouped AS (
  SELECT *,
    SUM(is_new_group) OVER (PARTITION BY SubscriptionID, reservationOrderID ORDER BY Effective_start_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS group_id
  FROM (
    SELECT *,
      CASE
        WHEN LAG(Effective_end_date) OVER (PARTITION BY SubscriptionID, reservationOrderID ORDER BY Effective_start_date) >= Effective_start_date
        THEN 0 ELSE 1
      END AS is_new_group
    FROM base
  ) t
),

-- Merge overlapping groups by picking MIN start and MAX end
merged AS (
  SELECT
    SubscriptionID,
    reservationOrderID,
    MIN(Effective_start_date) AS Effective_start_date,
    MAX(Effective_end_date) AS Effective_end_date,
    FIRST(accountId) AS accountId,
    FIRST(ConsumptionType) AS ConsumptionType,
    FIRST(dbupricediscount) AS dbupricediscount,
    FIRST(UtilizedPercentage) AS UtilizedPercentage,
    FIRST(Modified_Date) AS Modified_Date,
    FIRST(Status) AS Status,
    FIRST(AppliedScopeType) AS AppliedScopeType
  FROM grouped
  GROUP BY SubscriptionID, reservationOrderID, group_id
)

SELECT * FROM merged
ORDER BY SubscriptionID, reservationOrderID, Effective_start_date
'''
)


azureridata.createOrReplaceTempView ('azureridata') 


# COMMAND ----------

ritransactions = spark.sql(f'''
--active ri calculated data for start and end dates
with latest_royalty
(
select * from 

   ( select SubscriptionID , Effective_start_date , Effective_end_date ,row_number() over (partition by SubscriptionID  order by effective_end_date desc ) rnk from   {AZURE_RATES_PRE} where upper(pipeline) in ('DEFAULT' ,'DEFAULT_PUBLISHED', 'ROYALTY', 'ROYALTY_PUBLISHED') ) a 
 where rnk  = 1 
)
select 
ri.SubscriptionID,
ri.reservationOrderID,
ri.accountId,
ri.ConsumptionType,
--case when lr.SubscriptionID is not NULL and ri.Effective_end_date > lr.Effective_end_date and ri.Effective_start_date <= lr.Effective_start_date  then lr.Effective_end_date + 1 
  --   when lr.SubscriptionID is not NULL and ri.Effective_end_date > lr.Effective_end_date and ri.Effective_start_date > lr.Effective_start_date   then ri.Effective_start_date  
    -- else ri.Effective_start_date end as Effective_start_date,
     
     
   case 
     when lr.SubscriptionID is not NULL and ri.Effective_end_date > lr.Effective_end_date and ri.Effective_start_date > lr.Effective_end_date   then ri.Effective_start_date  
     when lr.SubscriptionID is not NULL and ri.Effective_end_date > lr.Effective_end_date  then lr.Effective_end_date  + 1 
     else ri.Effective_start_date end as Effective_start_date,
     
ri.Effective_end_date,
ri.dbupricediscount,
ri.UtilizedPercentage,
ri.Status,
ri.AppliedScopeType



from azureridata ri
left  join latest_royalty lr
on  ri.SubscriptionID = lr.SubscriptionID
where  (lr.SubscriptionID is NULL or  ri.Effective_end_date > lr.Effective_end_date ) ''') 


ritransactions.createOrReplaceTempView('ritransactions')


# COMMAND ----------

billable_usage = sql(f"""select distinct
    sku_name as sku,
    h.workspace_id as workspaceId,
    list_price as listPrice,
    cloud_customer.azure_subscription_id as azureSubscriptionId,
    case when h.product_type = "MOSAIC_ML" then bs.account_id else i.salesforce_account_id end as sfdcAccountId,
    sovereignty
  from {BILLABLE_USAGE} h
  left join ws_latest_inc_azure_gov i
  on h.workspace_id = i.workspace_id 
  left join (select business_subscription_id, max(account_id) as account_id from {SFDC_BS_ACCT_MAP_TABLE} group by all) bs
  on h.business_subscription_id = bs.business_subscription_id
  where (case when h.product_type = "MOSAIC_ML" then "mct" else cloud end) = 'azure' and h.date > cast('{royaltymaxdate_inc_mnth_rylty}' as date)
""")

billable_usage.createOrReplaceTempView("billable_usage")

sql("""select distinct 
    a.azureSubscriptionId as subscriptionid,
    upper(sku) as sku,
    sfdcAccountId,
    listPrice,
    case when b.azureSubscriptionId is not null then 'GOV' else 'E2' end as type
 from billable_usage a
 left join
 (select distinct azureSubscriptionId
  from billable_usage
  where sovereignty = "GOVCLOUD") b
 on upper(a.azureSubscriptionId) = upper(b.azureSubscriptionId)
 """).createOrReplaceTempView("billable_usage_az_sub_ids")

# COMMAND ----------

# change prod. to the required schema and integration to main done
usagedata = spark.sql(f'''

select usage.subscriptionid as subscriptionid,  
       usage.sku as sku, 
       usage.type,
       max(usage.sfdcAccountId) as accountId, 
       round(avg(coalesce(govlist.listprice, usage.listPrice)),3) as listPrice  

from billable_usage_az_sub_ids usage
inner join {RI_TABLE} ri 
on lower(usage.subscriptionid) = lower(ri.SubscriptionId)

left join gov_subscription_list_rates govlist
on lower(govlist.subscriptionid) = lower(usage.subscriptionid)
and lower(govlist.Sku) = lower(usage.sku)
and govlist.RI_Consumption = 'RI'

WHERE processdate = (select max(processdate) from {RI_TABLE})

group by 1,2,3
order by 1,2 
''')

usagedata.createOrReplaceTempView('usagedata')

# COMMAND ----------

#mapping all the subscription id from usage 
# change prod. to the required schema 
mappedsubscriptions = spark.sql(f'''
with workspace_account as
 (select account__c ,workspaceId__c  FRom  {SFDC_WORKSPACE_TABLE}  where processDate =  ( select max(processDate) from {SFDC_WORKSPACE_TABLE} ) 
and  account__c is not null  ) ,

usage as 

(SELECT distinct 
    usage.sku,
    usage.workspaceId, 
    coalesce(govlist.listPrice ,usage.listPrice) listPrice,
    usage.azureSubscriptionId,
    usage.sfdcAccountId 
  from billable_usage usage
  left join gov_subscription_list_rates govlist
  on lower(govlist.subscriptionid) = lower(usage.azureSubscriptionId)
  and lower(govlist.Sku) = lower(usage.sku)
  and govlist.RI_Consumption = 'RI'
  ) 
  

select  --workspaceId__c , 
       distinct 
      -- wa.workspaceId__c,
       
       usg.azureSubscriptionId,
       upper(usg.sku) sku,
       usg.listPrice,
       ri.accountId ,  
       ri.reservationOrderID , 
       --ri.SubscriptionID , 
       ri.Effective_start_date,
       ri.Effective_end_date ,
       ri.ConsumptionType, 
       ri.dbupricediscount ,
       ri.UtilizedPercentage,
       ri.Status,
       ri.AppliedScopeType  
FRom azureridata  ri  --using azure ri data since new subscription id in royalty data we have to recalculate start date and end date.
Left join  workspace_account wa
ON wa.account__c  = ri.accountId
left join  usage usg
ON usg.workspaceId= wa.workspaceId__c
where ri.AppliedScopeType <> 'Single'
and usg.azureSubscriptionId is not null ''')

mappedsubscriptions.createOrReplaceTempView ("mappedsubscriptions")

# COMMAND ----------

#deriving dates based on royalty data
mappedsubscriptionsroyaltycheck = spark.sql (f'''
--active ri calculated data for start and end dates
with latest_royalty
(
select * from 
-- ( select SubscriptionID , Effective_start_date , Effective_end_date ,row_number() over (partition by SubscriptionID  order by effective_end_date desc ) rnk from   {AZURE_RATES_STG} ) a
  ( select SubscriptionID , Effective_start_date , Effective_end_date ,row_number() over (partition by SubscriptionID  order by effective_end_date desc ) rnk from  {AZURE_RATES_PRE} where upper(pipeline) in ('DEFAULT' , 'DEFAULT_PUBLISHED', 'ROYALTY' ,'ROYALTY_PUBLISHED') ) a 

 where rnk  = 1 
)
select 
ri.azureSubscriptionId SubscriptionID,
ri.reservationOrderID,
ri.accountId,
ri.ConsumptionType,
--case when lr.SubscriptionID is not NULL and ri.Effective_end_date > lr.Effective_end_date and ri.Effective_start_date <= lr.Effective_start_date  then lr.Effective_end_date + 1 
  --   when lr.SubscriptionID is not NULL and ri.Effective_end_date > lr.Effective_end_date and ri.Effective_start_date > lr.Effective_start_date   then ri.Effective_start_date  
    -- else ri.Effective_start_date end as Effective_start_date,
    
    
case 
     when lr.SubscriptionID is not NULL and ri.Effective_end_date > lr.Effective_end_date and ri.Effective_start_date > lr.Effective_end_date   then ri.Effective_start_date  
     when lr.SubscriptionID is not NULL and ri.Effective_end_date > lr.Effective_end_date  then lr.Effective_end_date  + 1 
     else ri.Effective_start_date end as Effective_start_date,
     
ri.Effective_end_date,
ri.dbupricediscount,
ri.UtilizedPercentage,
ri.Status,
ri.AppliedScopeType,
upper(ri.sku) as sku,
ri.listPrice listPrice

from mappedsubscriptions ri
left  join latest_royalty lr
on  ri.azureSubscriptionId = lr.SubscriptionID
where  (lr.SubscriptionID is NULL or  ri.Effective_end_date > lr.Effective_end_date ) ''') 


mappedsubscriptionsroyaltycheck.createOrReplaceTempView('mappedsubscriptionsroyaltycheck')

# COMMAND ----------

mappedsubscriptionsroyaltycheck_rw_num = spark.sql('''select  row_number() over(order by  SubscriptionID,Sku,Effective_start_date,effective_end_Date ) rw_num , a.* 
 from mappedsubscriptionsroyaltycheck a ''')  


mappedsubscriptionsroyaltycheck_rw_num.createOrReplaceTempView('mappedsubscriptionsroyaltycheck_rw_num')

# COMMAND ----------

sql(f"""
create or replace table  {MAPPED_SUBS_ROYALTY_TABLE}
as select * from mappedsubscriptionsroyaltycheck_rw_num
""")

# COMMAND ----------

mappedsubscriptionsroyaltycheck_overlapping_rw_num =spark.sql(f''' 
--Overlapping 
--change integration to main before prod migration done

SELECT distinct b.*  FROM   {MAPPED_SUBS_ROYALTY_TABLE} a
INNER JOIN   {MAPPED_SUBS_ROYALTY_TABLE} b
ON lower(a.SubscriptionID) = lower(b.SubscriptionID)
and lower(a.sku) = lower(b.sku)
where  a.rw_num <> b.rw_num
and b.Effective_start_date between a.Effective_start_date and a.Effective_end_date 

UNION
--what is being overlapped
SELECT distinct a.*  FROM   {MAPPED_SUBS_ROYALTY_TABLE} a
INNER JOIN   {MAPPED_SUBS_ROYALTY_TABLE} b
ON lower(a.SubscriptionID) = lower(b.SubscriptionID)
and lower(a.sku) = lower(b.sku)
where  a.rw_num <> b.rw_num
and b.Effective_start_date between a.Effective_start_date and a.Effective_end_date

''')


mappedsubscriptionsroyaltycheck_overlapping_rw_num.createOrReplaceTempView ('mappedsubscriptionsroyaltycheck_overlapping_rw_num')
#and b.Effective_start_date < a.Effective_end_date 
 
# and a.SubscriptionID  = 'e54d0018-47e8-45df-bb63-ff841f24a811'
 

# COMMAND ----------

mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per_legacy_logic =spark.sql ('''
select subscriptionid,
        sku,
        accountid,
        dbupricediscount,
        listprice ,
        min(effective_start_date) over (partition by subscriptionid,sku) effective_start_date ,
        max(effective_end_date) over (partition by subscriptionid,sku) effective_end_date ,
        effective_start_date effective_start_date_orig,
        effective_end_date effective_end_date_orig,
        row_number () over (partition by subscriptionid,sku order by utilizedpercentage ) rw_num,
        utilizedpercentage,
        Consumptiontype,
        status,
        Appliedscopetype,
        reservationorderid

from mappedsubscriptionsroyaltycheck_overlapping_rw_num 
qualify row_number () over (partition by subscriptionid,sku order by utilizedpercentage )  =1''')

mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per_legacy_logic.createOrReplaceTempView ('mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per_legacy_logic')

mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per_new_logic = spark.sql('''
with date_boundaries as (
    -- Get all unique date boundaries (start and end dates) for each subscription/sku combination
    -- Track whether boundary comes from start or end date
    select distinct
        subscriptionid,
        sku,
        date_boundary,
        boundary_type
    from (
        select subscriptionid, sku, effective_start_date as date_boundary, 'start' as boundary_type
        from mappedsubscriptionsroyaltycheck_overlapping_rw_num
        union all
        select subscriptionid, sku, effective_end_date as date_boundary, 'end' as boundary_type
        from mappedsubscriptionsroyaltycheck_overlapping_rw_num
    )
),
date_segments as (
    -- Create date segments between consecutive boundaries
    -- START boundaries: create segment starting at current boundary
    -- END boundaries after END: create segment from (prev_end + 1) to current_end
    select
        subscriptionid,
        sku,
        case
            when lag(boundary_type) over (partition by subscriptionid, sku order by date_boundary) = 'end'
            then lag(date_boundary) over (partition by subscriptionid, sku order by date_boundary) + 1
            else date_boundary
        end as segment_start_date,
        case
            -- If current is END and previous is END: this segment ends at current boundary
            when boundary_type = 'end' and lag(boundary_type) over (partition by subscriptionid, sku order by date_boundary) = 'end'
            then date_boundary
            -- If next boundary is START: segment ends the day before it
            when lead(boundary_type) over (partition by subscriptionid, sku order by date_boundary) = 'start'
            then lead(date_boundary) over (partition by subscriptionid, sku order by date_boundary) - 1
            -- Otherwise: segment ends at next boundary
            else lead(date_boundary) over (partition by subscriptionid, sku order by date_boundary)
        end as segment_end_date,
        boundary_type,
        lag(boundary_type) over (partition by subscriptionid, sku order by date_boundary) as prev_boundary_type
    from date_boundaries
),
filtered_segments as (
    -- Only keep segments from START boundaries or END boundaries that follow END boundaries
    select
        subscriptionid,
        sku,
        segment_start_date,
        segment_end_date
    from date_segments
    where boundary_type = 'start' or prev_boundary_type = 'end'
),
segmented_data as (
    -- Join segments with original data where they overlap
    -- A segment overlaps with a record if: segment_start < record_end AND segment_end > record_start
    select
        s.subscriptionid,
        s.sku,
        o.accountid,
        o.dbupricediscount,
        o.listprice,
        s.segment_start_date as effective_start_date,
        s.segment_end_date as effective_end_date,
        o.effective_start_date as effective_start_date_orig,
        o.effective_end_date as effective_end_date_orig,
        o.utilizedpercentage,
        o.Consumptiontype,
        o.status,
        o.Appliedscopetype,
        o.reservationorderid
    from filtered_segments s
    inner join mappedsubscriptionsroyaltycheck_overlapping_rw_num o
        on s.subscriptionid = o.subscriptionid
        and s.sku = o.sku
        -- Containment condition: segment must be completely within subscription date range
        and s.segment_start_date >= o.effective_start_date
        and s.segment_end_date <= o.effective_end_date
    where s.segment_end_date is not null  -- Exclude the last open-ended segment
)
select
    subscriptionid,
    sku,
    accountid,
    dbupricediscount,
    listprice,
    effective_start_date,
    effective_end_date,
    effective_start_date_orig,
    effective_end_date_orig,
    row_number() over (partition by subscriptionid, sku, effective_start_date, effective_end_date
                       order by utilizedpercentage) as rw_num,
    utilizedpercentage,
    Consumptiontype,
    status,
    Appliedscopetype,
    reservationorderid
from segmented_data
qualify row_number() over (partition by subscriptionid, sku, effective_start_date, effective_end_date
                           order by utilizedpercentage) = 1
''')

mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per_new_logic.createOrReplaceTempView('mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per_new_logic')

# COMMAND ----------

# Combine new logic for specific subscription IDs with old logic for the rest
mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per = spark.sql('''
-- New logic for specific subscription IDs
select * from mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per_new_logic
where lower(subscriptionid) in (
    '982349e1-3fca-44c6-af0f-1e1c0820422f',
    'f62dd4d4-ee41-4fe5-aef3-80d0633c575b',
    '5fba7398-d7e5-4f0c-9ecd-b60a1b592787',
    '1c7863c7-7e63-4a97-910b-b94bafada097',
    'a05b3142-5e06-4ee5-8088-2d1a7475cd7e',
    'c9e78944-e7ab-4ac9-89d9-eb2bec4dbcb0',
    '6515aa06-33d4-415d-9058-f014db13f4cc',
    'cfa1e322-98a8-4e95-8f4c-888af1564399',
    'e4f38f81-6976-470c-8e97-4f86db8ba609',
    '95bd2e95-5ec1-4adf-86d3-ae18fcbf6147',
    'b5328478-c235-453d-821d-0b2c52a292c3',
    'c1d80dce-ae4b-4fd7-be41-5fb6724aec12',
    '9d959040-2b92-4f63-b4cc-7e5d540395dd'
)
UNION ALL
-- Old/Legacy logic for all other subscription IDs
select * from mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per_legacy_logic
where lower(subscriptionid) not in (
    '982349e1-3fca-44c6-af0f-1e1c0820422f',
    'f62dd4d4-ee41-4fe5-aef3-80d0633c575b',
    '5fba7398-d7e5-4f0c-9ecd-b60a1b592787',
    '1c7863c7-7e63-4a97-910b-b94bafada097',
    'a05b3142-5e06-4ee5-8088-2d1a7475cd7e',
    'c9e78944-e7ab-4ac9-89d9-eb2bec4dbcb0',
    '6515aa06-33d4-415d-9058-f014db13f4cc',
    'cfa1e322-98a8-4e95-8f4c-888af1564399',
    'e4f38f81-6976-470c-8e97-4f86db8ba609',
    '95bd2e95-5ec1-4adf-86d3-ae18fcbf6147',
    'b5328478-c235-453d-821d-0b2c52a292c3',
    'c1d80dce-ae4b-4fd7-be41-5fb6724aec12',
    '9d959040-2b92-4f63-b4cc-7e5d540395dd'
)
''')

mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per.createOrReplaceTempView('mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per')

# COMMAND ----------

# MAGIC %md 
# MAGIC  
# MAGIC Only considering cases where subscription is missing in azure rates (loaded from royalty) or new ri Effective_end_date > transaction present in azure rates from royalty
# MAGIC   -- where lr.SubscriptionID is NULL or  ri.Effective_end_date > lr.Effective_end_date 
# MAGIC   
# MAGIC   startdate > end_date 
# MAGIC   startdate < end_date 
# MAGIC   
# MAGIC   
# MAGIC case 
# MAGIC - new ri start date < azure rates start date   and new ri start date < azure rates end date then end_Date+1 (end_Date)
# MAGIC - new ri start date > azure rates start date. and new ri start date  < azure rates end date then end_Date+1 
# MAGIC - new ri start date > azure rates start date. and new ri start date  > azure rates end date then new_ri_start_date

# COMMAND ----------


#change integration to main before prod migration
Delete_Target  = f'''
DELETE FROM {AZURE_RATES_RI_LIST_PRICE}  '''


sql(Delete_Target)


InsertRI = f'''

INSERT INTO  {AZURE_RATES_RI_LIST_PRICE}  -- PARTITION (ConsumptionType = 'RI')

with usagedatarolled as 
(SELECT  SKU , avg(listprice)  listprice from usagedata group by 1) 


--mapped transactions with account


--multiple RIs consolidation
select  SubscriptionID,
       -- SubscriptionID,
    --   reservationOrderID,
       accountId,
       'RI' as ConsumptionType,
       upper(sku),
       Effective_start_date, 
       Effective_end_date,
       ms.listPrice,
       ms.listPrice - ms.listPrice * ms.dbupricediscount as custprice ,
       NULL as RevShareFloor,
       --(ms.listPrice - ms.listPrice * ms.dbupricediscount) * 0.85 origrevshareprice,
       (ms.listPrice - ms.listPrice * ms.dbupricediscount) * 0.85 revshareprice,
       'RI' as pipeline,
      -- ms.status,
      dbupricediscount,
       'Mapped usage subscription id RIs '|| current_user as createuser, 
       current_timestamp as createtimestamp ,
       NULL as updateuser ,
       NULL as updatetimestamp


from mappedsubscriptionsroyaltycheck_overlapping_rw_num_lowest_utilized_per ms 


UNION 

--
select  SubscriptionID,
       -- SubscriptionID,
    --   reservationOrderID,
       accountId,
       'RI' as ConsumptionType,
       upper(sku),
       Effective_start_date, 
       Effective_end_date,
       ms.listPrice,
       ms.listPrice - ms.listPrice * ms.dbupricediscount as custprice ,
       NULL as RevShareFloor,
       --(ms.listPrice - ms.listPrice * ms.dbupricediscount) * 0.85 origrevshareprice,
       (ms.listPrice - ms.listPrice * ms.dbupricediscount) * 0.85 revshareprice,
       'RI' as pipeline,
       dbupricediscount,
      -- ms.status,
       'Mapped usage subscription id RIs '|| current_user as createuser, 
       current_timestamp as createtimestamp ,
       NULL as updateuser ,
       NULL as updatetimestamp


from {MAPPED_SUBS_ROYALTY_TABLE} ms 
where rw_num not in (select rw_num from mappedsubscriptionsroyaltycheck_overlapping_rw_num group by 1 )

UNION

-- actual ri transactions load
select distinct ri.SubscriptionID,
     --  ri.reservationOrderID, 
       ri.accountId ,
       'RI' as ConsumptionType,
       upper(u.SKU) as Sku,
       ri.Effective_start_date, 
       ri.Effective_end_date ,
       u.listPrice,
       u.listPrice - u.listPrice * ri.dbupricediscount as custprice ,
       NULL as RevShareFloor,
      -- (ms.listPrice - ms.listPrice * ms.dbupricediscount) * 0.85 origrevshareprice,
       (u.listPrice - u.listPrice * ri.dbupricediscount) * 0.85 revshareprice,
       'RI' as pipeline,
       ri.dbupricediscount,
     --  ri.status,
       'present in usage RIs ' || current_user as createuser, 
       current_timestamp as createtimestamp ,
      NULL as updateuser ,
      NULL as updatetimestamp
from  ritransactions  ri
inner join usagedata u
on lower(u.SubscriptionID) = lower(ri.SubscriptionID)
left join mappedsubscriptions ms
on lower(ms.azureSubscriptionId) =  lower(ri.SubscriptionID)
and lower(ms.sku) = lower(u.SKU)
where ms.azureSubscriptionId is NULL 



UNION
-- for the ri transactions not in usage mapping all SKUs and loading for something which can come in
select distinct ri.SubscriptionID,
      -- ri.reservationOrderID, 
       ri.accountId ,
       'RI' as ConsumptionType,
       upper(u.SKU) as Sku,
       ri.Effective_start_date, 
       ri.Effective_end_date ,
       u.listPrice,
       u.listPrice - u.listPrice * ri.dbupricediscount as custprice ,
       NULL as RevShareFloor,
     --  (u.listPrice - u.listPrice * ri.dbupricediscount) * 0.85 revshareprice,
       (u.listPrice - u.listPrice * ri.dbupricediscount) * 0.85 revshareprice,
       'RI' as pipeline,
       ri.dbupricediscount,
    --   ri.status,
       'missing in usage RIs ' || current_user as createuser, 
       current_timestamp as createtimestamp ,
      NULL as updateuser ,
      NULL as updatetimestamp
from  ritransactions  ri
inner join usagedatarolled u
on 1 = 1 
left join usagedata ud
on ud.SubscriptionID = ri.SubscriptionID 
left join mappedsubscriptions ms
on ms.azureSubscriptionId  =  ri.SubscriptionID
and ms.sku = u.SKU

where ud.SubscriptionID is NULL
and ms.azureSubscriptionId is NULL '''



sql(InsertRI)




# COMMAND ----------


#from here apply list prices based on finance.list_prices
#change finance.list_prices
multiple_list_prices = spark.sql(f''' 
select * from {LIST_PRICE_TABLE} wheRE ( sku, coalesce(region,'E2') ) in ( 
select sku,coalesce(region,'E2')  regio from {LIST_PRICE_TABLE} where platform = 'azure' group by 1 ,2 having count(*) > 1 ) AND  platform = 'azure' ''')

multiple_list_prices.createOrReplaceTempView('multiple_list_prices')

# COMMAND ----------

single_list_prices = spark.sql(f''' 
select * from {LIST_PRICE_TABLE} wheRE ( sku, coalesce(region,'E2') ) in ( 
select sku,coalesce(region,'E2')  region from {LIST_PRICE_TABLE} where platform = 'azure' group by 1 ,2 having count(*) = 1 ) AND  platform = 'azure' ''')

single_list_prices.createOrReplaceTempView('single_list_prices')

# COMMAND ----------

govsubs = spark.sql (''' Select distinct subscriptionid   from  gov_subscription_list_rates  
                         union 
                         select distinct subscriptionid  from usagedata where type = 'GOV' ''' )


govsubs.createOrReplaceTempView('govsubs')

# COMMAND ----------

#single list prices for non gov customers
singlelistpriceazurerates  = spark.sql( f'''
select arlp.SubscriptionID,arlp.accountId, arlp.ConsumptionType ,arlp.Sku , arlp.Effective_start_date , arlp.Effective_end_date ,  slp.list_Price , slp.list_Price - slp.list_Price * arlp.dbupricediscount as custprice ,arlp.RevShareFloor ,
(slp.list_Price - slp.list_Price * arlp.dbupricediscount) *0.85 as revshareprice , arlp.pipeline ,arlp.createuser,arlp.createtimestamp,arlp.Updateuser,arlp.Updatetimestamp

From  {AZURE_RATES_RI_LIST_PRICE} arlp 
INNER JOIN single_list_prices  slp
on slp.Sku = arlp.sku


Left join govsubs gs
ON arlp.SubscriptionID = gs.SubscriptionID

where 
 slp.type = 'E2'
and gs.SubscriptionID is NULL ''') 

singlelistpriceazurerates.createOrReplaceTempView('singlelistpriceazurerates')

# COMMAND ----------

#single list prices for  gov customers/subs
singlelistpriceazurerates_gov  = spark.sql(f'''select arlp.SubscriptionID,arlp.accountId, arlp.ConsumptionType ,arlp.Sku , arlp.Effective_start_date , arlp.Effective_end_date ,  slp.list_Price , slp.list_Price - slp.list_Price * arlp.dbupricediscount as custprice ,arlp.RevShareFloor ,
(slp.list_Price - slp.list_Price * arlp.dbupricediscount) *0.85 as revshareprice , arlp.pipeline ,arlp.createuser,arlp.createtimestamp,arlp.Updateuser,arlp.Updatetimestamp

From {AZURE_RATES_RI_LIST_PRICE} arlp 
INNER JOIN  (
Select sku,list_price from single_list_prices where type = 'GOV' 
qualify row_number () over (partition by sku order by start_Date) = 1) slp
on slp.Sku = arlp.sku


inner join govsubs gs
ON arlp.SubscriptionID = gs.SubscriptionID

 ''') 

singlelistpriceazurerates_gov.createOrReplaceTempView('singlelistpriceazurerates_gov')

# COMMAND ----------

#multiple  list prices for non  gov customers/subs
#change bdw.bi_dates -before prod
multiplelistpriceazurerates = spark.sql(f''' 
select bd.date, arlp.SubscriptionID,arlp.accountId ,arlp.ConsumptionType,arlp.Sku ,

mlp.list_Price , 
mlp.list_Price - mlp.list_Price * arlp.dbupricediscount as custprice ,
arlp.RevShareFloor ,
(mlp.list_Price - mlp.list_Price * arlp.dbupricediscount) *0.85 as revshareprice,

arlp.pipeline,
arlp.dbuPriceDiscount,
arlp.createuser,
arlp.createtimestamp, 
arlp.Updateuser,
arlp.Updatetimestamp




from   {AZURE_RATES_RI_LIST_PRICE} arlp
inner join {BI_DATES} bd
on bd.date between arlp.effective_start_date and arlp.effective_end_date
inner join multiple_list_prices mlp

on mlp.sku = arlp.sku
and bd.date between mlp.start_Date and mlp.end_Date



Left join govsubs gs
ON arlp.SubscriptionID = gs.SubscriptionID

where  mlp.type = 'E2'
and gs.SubscriptionID is NULL 
''') 

multiplelistpriceazurerates.createOrReplaceTempView('multiplelistpriceazurerates')

# COMMAND ----------

#collapsing the effective start and end dates
multiplelistpriceazurerates_aggfordates = spark.sql('''

SELECT SubscriptionID ,accountId , ConsumptionType , Sku , list_Price,custprice , RevShareFloor , revshareprice ,pipeline ,  dbuPriceDiscount ,createuser,createtimestamp,Updateuser,Updatetimestamp,

min(date) effective_start_Date, max(date) effective_end_date FROM (

SELECT SUM(cols) over(partition by SubscriptionID,sku   order by Rnk) GRP , * FROM (
select  CASE WHEN list_Price = lag(list_Price) over(partition by SubscriptionID,sku   order by Rnk) THEN 0 ELSE 1 END cols  ,* from (
SELECT ROW_NUMBER() OVER (partition by SubscriptionID,sku  ORDER BY date) Rnk, *    FROM multiplelistpriceazurerates  ) ) )

GROUP BY SubscriptionID ,accountId , ConsumptionType , Sku , list_Price,custprice , RevShareFloor , revshareprice ,pipeline ,  dbuPriceDiscount ,createuser,createtimestamp,Updateuser,Updatetimestamp ,GRP ''')

multiplelistpriceazurerates_aggfordates.createOrReplaceTempView('multiplelistpriceazurerates_aggfordates')

# COMMAND ----------


#change bdw.bi_dates -before prod
multiplelistpriceazurerates_gov = spark.sql(f''' 
select bd.date, arlp.SubscriptionID,arlp.accountId ,arlp.ConsumptionType,arlp.Sku ,

mlp.list_Price , 
mlp.list_Price - mlp.list_Price * arlp.dbupricediscount as custprice ,
arlp.RevShareFloor ,
(mlp.list_Price - mlp.list_Price * arlp.dbupricediscount) *0.85 as revshareprice,

arlp.pipeline,
arlp.dbuPriceDiscount,
arlp.createuser,
arlp.createtimestamp, 
arlp.Updateuser,
arlp.Updatetimestamp




from   {AZURE_RATES_RI_LIST_PRICE} arlp
inner join {BI_DATES} bd
on bd.date between arlp.effective_start_date and arlp.effective_end_date
inner join (select sku , list_price , start_Date , end_Date from multiple_list_prices where  type = 'GOV'
            qualify row_number () over (partition by sku ,start_Date,end_Date order by start_Date) = 1 ) mlp
            
            
on mlp.sku = arlp.sku
and bd.date between mlp.start_Date and mlp.end_Date

INNER join govsubs gs
ON arlp.SubscriptionID = gs.SubscriptionID

 ''') 

multiplelistpriceazurerates_gov.createOrReplaceTempView('multiplelistpriceazurerates_gov')

# COMMAND ----------


#collapsing the effective start and end dates for gov 

multiplelistpriceazurerates_gov_aggfordates = spark.sql('''

SELECT SubscriptionID ,accountId , ConsumptionType , Sku , list_Price,custprice , RevShareFloor , revshareprice ,pipeline ,  dbuPriceDiscount ,createuser,createtimestamp,Updateuser,Updatetimestamp,

min(date) effective_start_Date, max(date) effective_end_date FROM (

SELECT SUM(cols) over(partition by SubscriptionID,sku   order by Rnk) GRP , * FROM (
select  CASE WHEN list_Price = lag(list_Price) over(partition by SubscriptionID,sku   order by Rnk) THEN 0 ELSE 1 END cols  ,* from (
SELECT ROW_NUMBER() OVER (partition by SubscriptionID,sku  ORDER BY date) Rnk, *    FROM multiplelistpriceazurerates_gov  ) ) )

GROUP BY SubscriptionID ,accountId , ConsumptionType , Sku , list_Price,custprice , RevShareFloor , revshareprice ,pipeline ,  dbuPriceDiscount ,createuser,createtimestamp,Updateuser,Updatetimestamp ,GRP ''')

multiplelistpriceazurerates_gov_aggfordates.createOrReplaceTempView('multiplelistpriceazurerates_gov_aggfordates')

# COMMAND ----------


Delete_Target  = f'''
DELETE FROM {AZURE_RATES_PRE} where pipeline ='RI' '''


sql(Delete_Target)


InsertRI = f'''

INSERT INTO  {AZURE_RATES_PRE}  -- PARTITION (ConsumptionType = 'RI')

select  SubscriptionID, 
        accountId,
        ConsumptionType,
       upper(sku),
       Effective_start_date, 
       Effective_end_date,
       list_Price listPrice,
       custprice ,
       RevShareFloor,
       revshareprice,
       pipeline,
       createuser, 
       createtimestamp ,
       updateuser ,
       updatetimestamp,
       STRUCT(
              'Unknown' AS list_price_level,
              'Unknown' AS discount_level,
              ARRAY() AS billing_months
              ) AS paygo_discount_source


from  singlelistpriceazurerates 


UNION 

select  SubscriptionID, 
        accountId,
        ConsumptionType,
       upper(sku),
       Effective_start_date, 
       Effective_end_date,
       list_Price Listprice,
       custprice ,
       RevShareFloor,
       revshareprice,
       pipeline,
       createuser, 
       createtimestamp ,
       updateuser ,
       updatetimestamp,
       STRUCT(
              'Unknown' AS list_price_level,
              'Unknown' AS discount_level,
              ARRAY() AS billing_months
              ) AS paygo_discount_source


from  singlelistpriceazurerates_gov



UNION 

select  SubscriptionID, 
        accountId,
        ConsumptionType,
       upper(sku),
       Effective_start_date, 
       Effective_end_date,
       list_Price listPrice,
       custprice ,
       RevShareFloor,
       revshareprice,
       pipeline,
       createuser, 
       createtimestamp ,
       updateuser ,
       updatetimestamp,
       STRUCT(
              'Unknown' AS list_price_level,
              'Unknown' AS discount_level,
              ARRAY() AS billing_months
              ) AS paygo_discount_source


from  multiplelistpriceazurerates_aggfordates


UNION 

select  SubscriptionID, 
        accountId,
        ConsumptionType,
       upper(sku),
       Effective_start_date, 
       Effective_end_date,
       list_Price listPrice,
       custprice ,
       RevShareFloor,
       revshareprice,
       pipeline,
       createuser, 
       createtimestamp ,
       updateuser ,
       updatetimestamp,
       STRUCT(
              'Unknown' AS list_price_level,
              'Unknown' AS discount_level,
              ARRAY() AS billing_months
              ) AS paygo_discount_source


from  multiplelistpriceazurerates_gov_aggfordates'''




sql(InsertRI)




# COMMAND ----------


overlapcnt = spark.sql(f''' 
--overlap new query

with azure_rates_rw_num as (
select  row_number() over(order by  SubscriptionID,Sku,Effective_start_date,effective_end_Date ) rw_num , a.* 
 from {AZURE_RATES_PRE} a  )
 
 
 SELECT a.* FROM  azure_rates_rw_num a
INNER JOIN  azure_rates_rw_num b
ON lower(a.SubscriptionID) = lower(b.SubscriptionID)
and lower(a.sku) = lower(b.sku)
where  a.rw_num <> b.rw_num
and b.Effective_start_date between a.Effective_start_date and a.Effective_end_date ''') 

overlapcnt.createOrReplaceTempView('overlapcnt')
 

 

# COMMAND ----------

display(overlapcnt)

row = overlapcnt.count()

if row > 0 :
  raise Exception("Please check overlap in azure pricing data azure rates")



