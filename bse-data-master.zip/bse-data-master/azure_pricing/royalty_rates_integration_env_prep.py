# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC delete from integration.it_consumption_silver.azure_rates 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC insert into  integration.it_consumption_silver.azure_rates 
# MAGIC select * from main.it_consumption_silver.azure_rates 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC --delete from integration.it_msft_silver.msft_royalty_monthly 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC --insert into  integration.it_msft_silver.msft_royalty_monthly 
# MAGIC --select * from main.it_msft_silver.msft_royalty_monthly 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC --delete from integration.it_msft_silver.msft_royalty_qtrly_total_db 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC --insert into  integration.it_msft_silver.msft_royalty_qtrly_total_db
# MAGIC --select * from main.it_msft_silver.msft_royalty_qtrly_total_db

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC delete from integration.it_consumption_silver.azure_rates_royalty_pre 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC insert into  integration.it_consumption_silver.azure_rates_royalty_pre
# MAGIC select * from main.it_consumption_silver.azure_rates_royalty_pre

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC delete from integration.it_consumption_silver.azure_rates_snap 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC insert into  integration.it_consumption_silver.azure_rates_snap
# MAGIC select * from main.it_consumption_silver.azure_rates_snap
