-- Databricks notebook source
-- MAGIC %sql
-- MAGIC --change date
-- MAGIC
-- MAGIC create table temp.azure_rates_prod_02152023 as select * FRom bdw.azure_rates

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC show create  table bdw_dev.azure_rates 

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC
-- MAGIC  --change to bdw
-- MAGIC CREATE TABLE spark_catalog.bdw_dev.azure_rates (
-- MAGIC   SubscriptionID STRING,
-- MAGIC   accountId STRING,
-- MAGIC   ConsumptionType STRING,
-- MAGIC   Sku STRING,
-- MAGIC   Effective_start_date DATE,
-- MAGIC   Effective_end_date DATE,
-- MAGIC   listPrice DOUBLE,
-- MAGIC   custprice DOUBLE,
-- MAGIC   RevShareFloor DOUBLE,
-- MAGIC   revshareprice DOUBLE,
-- MAGIC   AdjRevSharePrice DOUBLE,
-- MAGIC   pipeline STRING,
-- MAGIC   createuser STRING,
-- MAGIC   createtimestamp TIMESTAMP,
-- MAGIC   Updateuser STRING,
-- MAGIC   Updatetimestamp TIMESTAMP)
-- MAGIC USING delta
-- MAGIC PARTITIONED BY (ConsumptionType)
-- MAGIC LOCATION 'dbfs:/mnt/bdw_dev/azure_rates'
-- MAGIC TBLPROPERTIES (
-- MAGIC   'delta.logRetentionDuration' = 'interval 400 days',
-- MAGIC   'delta.minReaderVersion' = '1',
-- MAGIC   'delta.minWriterVersion' = '2')

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC INSERT INTO bdw_dev.azure_rates 
-- MAGIC
-- MAGIC SELECT 
-- MAGIC
-- MAGIC SubscriptionID		,
-- MAGIC accountId		,
-- MAGIC ConsumptionType		,
-- MAGIC Sku		,
-- MAGIC Effective_start_date		,
-- MAGIC Effective_end_date		,
-- MAGIC listPrice		,
-- MAGIC custprice		,
-- MAGIC RevShareFloor		,
-- MAGIC revshareprice		,
-- MAGIC       CASE 
-- MAGIC              WHEN accountId <> '00161000005eOe5AAE' and revSharePrice < 0.4 * listPrice then 0.4 * listPrice
-- MAGIC              WHEN accountId = '00161000005eOe5AAE' then revshareprice
-- MAGIC              
-- MAGIC              WHEN revshareprice = 0 then listPrice*0.4 
-- MAGIC              WHEN revshareprice > 1 then listPrice *0.8*0.85
-- MAGIC              
-- MAGIC              ELSE revshareprice  end as AdjRevSharePrice		,
-- MAGIC pipeline		,
-- MAGIC createuser		,
-- MAGIC createtimestamp		,
-- MAGIC Updateuser		,
-- MAGIC Updatetimestamp		
-- MAGIC
-- MAGIC FROM 
-- MAGIC
-- MAGIC temp.azure_rates_prod_02152023 

-- COMMAND ----------

CREATE or replace VIEW bdw_dev.azure_rates_finance (
  SubscriptionID,
  accountId,
  ConsumptionType,
  Sku,
  Effective_start_date,
  Effective_end_date,
  listPrice,
  custprice,
  RevShareFloor,
  revshareprice,
  AdjRevSharePrice,
  pipeline,
  createuser,
  createtimestamp,
  Updateuser,
  Updatetimestamp)
COMMENT 'View for additional finance logic for revshareprice - Logic moved to table - so this is a plain view now'
TBLPROPERTIES (
  'transient_lastDdlTime' = '1670608831')
AS SELECT
        SubscriptionID,
        accountId,
        ConsumptionType,
        Sku,
        Effective_start_date,
        Effective_end_date,
        listPrice,
        custprice,
        RevShareFloor,
        revshareprice,
        AdjRevSharePrice ,         
        pipeline,
        createuser,
        createtimestamp,
        Updateuser,
        Updatetimestamp
    FROM bdw_dev.azure_rates

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC --change date
-- MAGIC
-- MAGIC create table temp.azure_rates_snap_prod_02152023 as select * FRom bdw.azure_rates_snap

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC drop table bdw_dev.azure_rates_snap 

-- COMMAND ----------

-- MAGIC %py
-- MAGIC dbutils.fs.rm('dbfs:/mnt/bdw-dev/azure_rates_snap',True)

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC --show create table  bdw_dev.azure_rates_snap
-- MAGIC
-- MAGIC CREATE TABLE spark_catalog.bdw_dev.azure_rates_snap (
-- MAGIC   SubscriptionID STRING,
-- MAGIC   accountId STRING,
-- MAGIC   ConsumptionType STRING,
-- MAGIC   Sku STRING,
-- MAGIC   Effective_start_date DATE,
-- MAGIC   Effective_end_date DATE,
-- MAGIC   listPrice DOUBLE,
-- MAGIC   custprice DOUBLE,
-- MAGIC   RevShareFloor DOUBLE,
-- MAGIC   revshareprice DOUBLE,
-- MAGIC   AdjRevSharePrice DOUBLE,
-- MAGIC   pipeline STRING,
-- MAGIC   processdate DATE,
-- MAGIC   createuser STRING,
-- MAGIC   createtimestamp TIMESTAMP,
-- MAGIC   Updateuser STRING,
-- MAGIC   Updatetimestamp TIMESTAMP)
-- MAGIC USING delta
-- MAGIC PARTITIONED BY (processdate)
-- MAGIC LOCATION 'dbfs:/mnt/bdw-dev/azure_rates_snap'
-- MAGIC TBLPROPERTIES (
-- MAGIC   'delta.minReaderVersion' = '1',
-- MAGIC   'delta.minWriterVersion' = '2')

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC
-- MAGIC insert into spark_catalog.bdw_dev.azure_rates_snap 
-- MAGIC SELECT 
-- MAGIC
-- MAGIC SubscriptionID		,
-- MAGIC accountId		,
-- MAGIC ConsumptionType		,
-- MAGIC Sku		,
-- MAGIC Effective_start_date		,
-- MAGIC Effective_end_date		,
-- MAGIC listPrice		,
-- MAGIC custprice		,
-- MAGIC RevShareFloor		,
-- MAGIC revshareprice		,
-- MAGIC
-- MAGIC       CASE 
-- MAGIC              WHEN accountId <> '00161000005eOe5AAE' and revSharePrice < 0.4 * listPrice then 0.4 * listPrice
-- MAGIC              WHEN accountId = '00161000005eOe5AAE' then revshareprice
-- MAGIC              
-- MAGIC              WHEN revshareprice = 0 then listPrice*0.4 
-- MAGIC              WHEN revshareprice > 1 then listPrice *0.8*0.85
-- MAGIC              
-- MAGIC              ELSE revshareprice  end as AdjRevSharePrice ,
-- MAGIC
-- MAGIC 		
-- MAGIC pipeline		,
-- MAGIC processdate		,
-- MAGIC createuser		,
-- MAGIC createtimestamp		,
-- MAGIC Updateuser		,
-- MAGIC Updatetimestamp		
-- MAGIC
-- MAGIC FROM temp.azure_rates_snap_prod_02152023

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC show create table  bdw.azure_rates_snap

-- COMMAND ----------

CREATE TABLE spark_catalog.bdw_dev.azure_rates_snap (
  SubscriptionID STRING,
  accountId STRING,
  ConsumptionType STRING,
  Sku STRING,
  Effective_start_date DATE,
  Effective_end_date DATE,
  listPrice DOUBLE,
  custprice DOUBLE,
  RevShareFloor DOUBLE,
  revshareprice DOUBLE,
  pipeline STRING,
  processdate DATE,
  createuser STRING,
  createtimestamp TIMESTAMP,
  Updateuser STRING,
  Updatetimestamp TIMESTAMP)
USING delta
PARTITIONED BY (processdate)
LOCATION 'dbfs:/mnt/bdw-dev/azure_rates_snap'
TBLPROPERTIES (
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')
