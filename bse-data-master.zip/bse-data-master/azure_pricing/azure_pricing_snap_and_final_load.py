# Databricks notebook source
dbutils.widgets.text("env", "prod")

dbutils.widgets.text("common_catalog", "main")
dbutils.widgets.text("royalty_catalog", "integration")
dbutils.widgets.text("catalog", "integration")
dbutils.widgets.text("schema", "it_consumption_silver")

# COMMAND ----------

# MAGIC %run "./config_azure_pricing"

# COMMAND ----------

locals().update(azure_table_config)

# COMMAND ----------

process_date = spark.sql('select current_date').collect()[0][0] 
print(process_date)

# COMMAND ----------

print(f'{AZURE_RATES_PRE}')

# COMMAND ----------

Insertazureratessnap = f'''

insert overwrite {AZURE_RATES_SNAP} partition(processDate = '{process_date}')
SELECT 
SubscriptionID	,
accountId	,
ConsumptionType	,
Sku	,
Effective_start_date	,
Effective_end_date	,
listPrice	,
custprice	,
RevShareFloor	,
revshareprice	,
AdjRevSharePrice ,
pipeline	,
createuser	,
createtimestamp	,
Updateuser	,
Updatetimestamp,
paygo_discount_source


FROM {AZURE_RATES} '''

sql(Insertazureratessnap)




# COMMAND ----------

Delete_Target  = f'''
DELETE FROM {AZURE_RATES} '''

sql(Delete_Target)

Inserttarget  = f''' 

Insert into {AZURE_RATES}

SELECT 
  pre.SubscriptionID	,
  accountId	,
  ConsumptionType	,
  upper(pre.Sku) sku	,
  pre.Effective_start_date	,
  pre.Effective_end_date 	,
  listPrice	,
  custprice	,
  RevShareFloor,
  revshareprice	,

  CASE 
    WHEN accountId = '0016100000U5DnLAAV' AND revSharePrice < 0.3024 * listPrice 
        THEN 0.3024 * listPrice
    WHEN accountId = '0016100000U5DnLAAV' 
        THEN revSharePrice

    WHEN accountId <> '00161000005eOe5AAE' AND revSharePrice < 0.4 * listPrice 
        THEN 0.4 * listPrice

    WHEN accountId = '00161000005eOe5AAE' 
        THEN revSharePrice

    WHEN revSharePrice <= 0  
        THEN listPrice * 0.4   -- per BSEDATA-430

    WHEN revSharePrice > 1  
        THEN listPrice * 0.8 * 0.85

    ELSE revSharePrice  
END AS AdjRevSharePrice ,

  -- CASE 
  --            WHEN accountId <> '00161000005eOe5AAE' and revSharePrice < 0.4 * listPrice then 0.4 * listPrice
  --            WHEN accountId = '00161000005eOe5AAE' then revshareprice
             
  --            WHEN revshareprice <= 0 then listPrice*0.4   -- adding < as per the ticket https://databricks.atlassian.net/browse/BSEDATA-430
  --            WHEN revshareprice > 1 then listPrice *0.8*0.85
             
  --            ELSE revshareprice  end as AdjRevSharePrice ,
             
  pipeline,
  createuser	,
  createtimestamp	,
  Updateuser ,
  Updatetimestamp,
  paygo_discount_source

FROM {AZURE_RATES_PRE} pre'''



sql(Inserttarget)

# COMMAND ----------


