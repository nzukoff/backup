# Databricks notebook source
from pprint import pprint

# COMMAND ----------

# DBTITLE 1,table configs
env = dbutils.widgets.get("env") #dev
if env == "prod":
  common_catalog = "main"
  royalty_catalog = "main"
  catalog = "main"
  schema = "it_consumption_silver"
else:
  common_catalog = dbutils.widgets.get("common_catalog")
  royalty_catalog = dbutils.widgets.get("royalty_catalog")
  catalog = dbutils.widgets.get("catalog")
  schema = dbutils.widgets.get("schema")
  

common_configs = {
  "SFDC_WORKSPACE_TABLE" : f"{common_catalog}.sfdc_bronze.workspace__c",
  "LIST_PRICE_TABLE" : f"{common_catalog}.it_sfdc_silver.list_prices",
  "BI_AGG_ORDERS" : f"{common_catalog}.it_consumption_silver.bi_aggorders",
  "BILLABLE_USAGE" : f"{common_catalog}.eng_billable_usage.billable_usage",
  "WORKSPACES_LATEST" : f"{common_catalog}.certified.workspaces_latest",
  "WORKSPACES_HISTORY" : f"{common_catalog}.it_lakehouse_internal.workspaces_history_static",
  "BI_DATES" : f"{common_catalog}.it_core_dim.bi_dates",
  "RI_TABLE" : f"{common_catalog}.it_msft_silver.msft_ri_daily",
  "SFDC_BS_ACCT_MAP_TABLE" : f"{common_catalog}.it_cpq_silver.sfdc_bs_account_map",
  "AZURE_USAGE_METERING" : f"{common_catalog}.it_lakehouse.azure_carveout",
}

royalty_config = {
  "ROYALTY_MONTHLY" : f"{royalty_catalog}.it_msft_silver.msft_royalty_monthly",
  "ROYALTY_QUARTERLY" : f"{royalty_catalog}.it_msft_silver.msft_royalty_qtrly_total_db"
}

azure_table_config = {
  "AZURE_RATES" : f"{catalog}.{schema}.azure_rates",
  "AZURE_RATES_STG" : f"{catalog}.{schema}.azure_rates_royalty_stg",
  "BI_AGG_SINGLE_SCOPE_TABLE" : f"{catalog}.{schema}.bi_agg_sub_single_scope_date_seq",
  "BI_AGG_SHARED_SCOPE_TABLE" : f"{catalog}.{schema}.bi_agg_sub_shared_scope_date_seq",
  "AZURE_RATES_PRE" : f"{catalog}.{schema}.azure_rates_royalty_pre",
  "AZURE_RATES_RI_LIST_PRICE" : f"{catalog}.{schema}.azure_rates_ri_list_price",
  "AZURE_RATES_SNAP" : f"{catalog}.{schema}.azure_rates_snap",
  "MAPPED_SUBS_ROYALTY_TABLE" : f"{catalog}.{schema}.mappedsubscriptionsroyaltycheck_rw_num",
  "AZURE_RATED_USAGE" : f"{catalog}.{schema}.azure_rated_usage_with_agg_orders"
 }

azure_table_config.update(royalty_config)
azure_table_config.update(common_configs)


# COMMAND ----------

pprint(azure_table_config)

# COMMAND ----------

from dataclasses import dataclass
from typing import Callable, Optional, Sequence
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
from datetime import date
from dateutil.parser import parse
from dataclasses import dataclass, field

@dataclass(frozen=True)
class defineconfig:
  name: str
  target_db: str
  catalog : str

# COMMAND ----------

pricing_config =  { 'prod' : {
  'name' : 'Production',
  'target_db': 'it_consumption_silver',
  'catalog':'main'
  
} ,

'dev' : {
  'name':'Dev',
  'target_db': 'it_consumption_silver',
  'catalog':'integration'
  
} }

# COMMAND ----------

dbutils.widgets.dropdown("env", "dev", ['dev', 'prod'])
try:
  ENV = dbutils.widgets.get("env")
except:
  ENV = dbutils.widgets.get("env")
 
try:
  setconfig = defineconfig(
                        pricing_config[ENV]['name'],
                        pricing_config[ENV]['target_db'],
                        pricing_config[ENV]['catalog']
                        
                      )
except Exception:
  raise Exception(f'Configurations are not defined for {ENV}')

# COMMAND ----------

target_db = setconfig.target_db
catalog = setconfig.catalog

# COMMAND ----------

#constant varibles for environment

fin_db = 'finance'
bdw_db = 'it_consumption_silver'
royalty_table = 'msft_royalty_qtrly_total_db' 
royalty_monthly_table =  'msft_royalty_monthly'
#ri_table = 'msft_ri'
target_table = 'azure_rates'
stg_table = 'azure_rates_royalty_stg'
billingmonthstartkey  = '20180501' 
billingmonthstartdate  = '2018-05-01'
maxbillingmonthkey = spark.sql(f'select max(billingmonthkey) from {royalty_config["ROYALTY_QUARTERLY"]} ').collect()[0][0]
royatlymaxyear = maxbillingmonthkey[0:4]
royatlymaxmonth = maxbillingmonthkey[4:6]
royaltymaxdate = spark.sql   (  f'select LAST_DAY  ( cast( (( ({royatlymaxyear}) || "-"||({royatlymaxmonth})))  as  date) )' ).collect()[0][0]
print (billingmonthstartkey,maxbillingmonthkey)
print (royatlymaxyear,royatlymaxmonth,maxbillingmonthkey,royaltymaxdate)

# COMMAND ----------

def sql(statement):
  """
  Print and issue a Spark SQL statement. Returns the result
  of the spark.sql call.
  """
  print(statement)
  return spark.sql(statement)


# COMMAND ----------

def add_years(d, y):
    """Return a date that's `years` years after the date (or datetime)
    object `d`. Return the same calendar date (month and day) in the
    destination year, if it exists, otherwise use the following day
    (thus changing February 29 to March 1).

    """  
    if d is None or y is None :
      return None
    else :
      date1 = parse(d)
      y = int(y)
      currentTimeDate = date1 + relativedelta(years=y)
      currentTime = currentTimeDate.strftime('%Y-%m-%d')
      return  currentTime

spark.udf.register("addyears", add_years)

# COMMAND ----------

spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")

