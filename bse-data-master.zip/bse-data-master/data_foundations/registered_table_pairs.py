import os
import importlib
from pathlib import Path

# Define the directory containing the modules
MODULES_DIR = Path("user_registered_table_pairs")

# Initialize the main list to store all registered checks
MAIN_ALL_REGISTERED_CHECKS = []

# Ensure the directory exists
if MODULES_DIR.exists() and MODULES_DIR.is_dir():
    for file in os.listdir(MODULES_DIR):
        if file.endswith(".py"):
            module_name = file[:-3]  # Remove .py extension
            module = importlib.import_module(f"user_registered_table_pairs.{module_name}")
            
            # Check if ALL_REGISTERED_CHECKS exists in the module
            if hasattr(module, "ALL_REGISTERED_CHECKS"):
                print("#"*30)
                print(f"import registered checks for {module_name}... number of checks: {len(module.ALL_REGISTERED_CHECKS)}")
                print(f"All the check name: {[c['name'] for c in module.ALL_REGISTERED_CHECKS]} ")
                MAIN_ALL_REGISTERED_CHECKS.extend(module.ALL_REGISTERED_CHECKS)