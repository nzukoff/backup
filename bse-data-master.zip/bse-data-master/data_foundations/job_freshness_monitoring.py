# Databricks notebook source
START_DATE = "2024-11-01"

# COMMAND ----------

SFDC_PIPELINES = [
    {
        "name": "3pi_salesforce_daily", # The name of the pipeline, this will show up in the monitoring dashbaord
        "clf_job_id": "160574247729268", # The job ID of this pipeline in the CLF
        "sox_job_id": "163179272055368", # The job ID of this pipeline in the SOX
        "owner": "neo.ni@databricks.com", # Your own email address
        "mode": "main" # `main` or `integration`
    }
]


ALL_PIPELINES_PAIRS = [] + SFDC_PIPELINES


# COMMAND ----------

dbutils.widgets.dropdown("environment", "clf", ["clf", "sox"])

# COMMAND ----------

env = dbutils.widgets.get("environment")

# COMMAND ----------

job_id_key = f"{env}_job_id"
all_job_ids = ",".join([f"'{item[job_id_key]}'" for item in ALL_PIPELINES_PAIRS])
job_run_data_df = spark.sql(
    f"""
        WITH job_run_metadata AS (
        Select
          job_id,
          to_date(period_start_time) AS date,
          period_start_time,
          period_end_time,
          (
            unix_timestamp(period_end_time) - unix_timestamp(period_start_time)
          ) / 60 AS duration
        From
          system.lakeflow.job_run_timeline
        Where
          period_start_time > '{START_DATE}'
          AND trigger_type = "CRON"
          AND result_state = "SUCCEEDED"
          AND job_id in ({ all_job_ids })
        ),
        metadata_with_row_id AS (
            SELECT *, ROW_NUMBER() OVER (PARTITION BY date, job_id ORDER BY period_start_time) AS row_id FROM job_run_metadata
        )
        SELECT * FROM metadata_with_row_id WHERE row_id = 1
                                """
).drop("row_id")

# COMMAND ----------

pipeline_metadata = spark.createDataFrame(ALL_PIPELINES_PAIRS)
df = job_run_data_df.join(pipeline_metadata, job_run_data_df["job_id"] == pipeline_metadata[job_id_key], "left")

# COMMAND ----------

table_name_write = "main.data_df_misc.sox_migration_job_run_metadata" if env == "clf" else "integration.sox_migration_misc.sox_migration_job_run_metadata"
df.write.mode("overwrite").saveAsTable(table_name_write)

# COMMAND ----------


