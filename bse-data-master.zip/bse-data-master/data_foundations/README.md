# Testing and Monitoring for SOX Migration

For complete guidance on testing and monitoring for SOX Migration, please refer to this [wiki page](https://github.com/databricks-it/bse-data/tree/master/data_foundations/table_diff).

## Parallel Testing 101

When we migrate your pipeline in CLF to the SOX workspace and generate the table, you will likely want to verify if your SOX pipeline is generating the correct data by comparing it with the original table in CLF.

The `table-diff` library provides this functionality, allowing you to verify:
- The schemas of the two tables match (no missing fields, correct data types).
- The two tables can join without any missing rows, given their primary keys.
- For any given row (by primary keys) and column, the values in the two tables match.

The library also offers flexibility to customize your parallel checks. For more details about the `table_diff` library, visit this [wiki page](https://github.com/databricks-it/bse-data/tree/master/data_foundations/table_diff).

We have created wrappers for the `table-diff` library to simplify onboarding and enable you to register parallel testing using a configuration-driven approach.

### Prerequisites

Before proceeding, ensure you have access to the [SOX workspace](https://billing-workspace-mt-prod-aws-us-west-2.cloud.databricks.com/):
- Clone the `bse-data` repository in the SOX workspace (you'll need to configure the necessary GitHub credentials in your workspace settings).
- Add yourself to the `data-foundations-sox.readonly` group via [Opal Group](https://app.opal.dev/groups/8c31fee2-bd4b-4fe2-ba73-906071c25ad6).
- Ensure the target table you are developing and testing is present in the `share_clf_main` catalog, which is the Delta share catalog from Central Logfood. If not, add the objects to this UCRM template: [jobs/ucrm/delta_sharing/shares/eng_data_df/params.tf.jsonnet](https://github.com/databricks-eng/ds-projects/blob/master/jobs/ucrm/delta_sharing/shares/eng_data_df/params.tf.jsonnet#L106).

### During Development

During development, you might want to quickly compare your development table with the baseline table in the `share_clf_main` catalog for faster iterations.

We provide a playground notebook for this purpose. Navigate to your `bse-data` repository and open the `data_foundations/table_diff_playground.py` notebook. This notebook contains skeleton code to help you get started with the `table_diff` library.

The comments in the notebook are self-explanatory. For more details about the `table_diff` library, refer to this [wiki page](https://github.com/databricks-it/bse-data/tree/master/data_foundations/table_diff).

### Register Your Table for Daily Comparison

After completing development, you may want to configure daily tests in production (or integration) to ensure your pipeline generates correct data. Additionally, you might want notifications for test failures and a dashboard to track testing history.

To set this up, add a configuration in [the user_registered_table_pairs folder (`data_foundations/user_registered_table_pairs`)](https://github.com/databricks-it/bse-data/blob/master/data_foundations/user_registered_table_pairs/). You should create a dedicated python script with your name to onboard your checks, please see (`data_foundations/user_registered_table_pairs/template.py`)(https://github.com/databricks-it/bse-data/blob/master/data_foundations/user_registered_table_pairs/template.py) as an example.

You need to define a `ALL_REGISTERED_CHECKS` in your script, the notebook will automatically import your registered checks as long as you define `ALL_REGISTERED_CHECKS`, **You don't need to make any other changes!**

You need to provide the following field value in a dict and append that dict into `ALL_REGISTERED_CHECKS`:
 - `name`: The name of the check, used to identify the check in the monitoring dashboard
 - `table_pair_id`: Must be `{schema}--{table_name}`. If clf_table_name_overwrite/sox_table_name_overwrite/clf_sql_overwrite/sox_sql_overwrite are not provided, then we read the Dataframe based on the schema/table_name provided here.
 - `owner_email`: Your own email address
 - `environment`: The environment where the check is running, `main` or `integration`. It also determine the catalog we are reading the SOX table from.
 - `clf_table_name_overwrite` [Optional]: overwrite the CLF tables that the check read from. It should be in the `share_clf_main` catalog. For example, `share_clf_main.sfdc_bronze.pricebook2`.
 - `sox_table_name_overwrite` [Optional]: overwrite the CLF tables that the check read from. It should be in the `main`/ `integration` catalog. For example, `main.sfdc_bronze.pricebook2`.
 - `trigger_hour`: Specify at which hour (0-23) in a day that you want the `table_diff` check to trigger for your table. Please make sure that both SOX table and CLF table have been updated at the trigger hour. And please help to distribute the trigger time to avoid resource limit.
 - `clf_sql_overwrite` [Optional]: If you want to apply some transformation on the clf table before feed it into the check, you can also provide a query as alternative. Otherwise, just leave it empty.
 - `sox_sql_overwrite` [Optional]: If you want to apply some transformation on the sox table before feed it into the check, you can also provide a query as alternative. Otherwise, just leave it empty.
 - `clf_drop_columns` [Optional]: If you want to exclude any column from parallel testing in the CLF table, register them here, split by comma `,`.  
 - `sox_drop_columns` [Optional]: If you want to exclude any column from parallel testing in the SOX table, register them here, split by comma `,`. 
 - `date_partition` [Optional]: If your table is partitioned by date, and you only want to run the `table_diff` against the latest `X` date, specify the date parititon column here.
 - `date_range` [Optional]: If your table is partitioned by date, and you only want to run the `table_diff` against the latest `X` date, specify the `X` here.
 - `primary_keys`: Since we are running the row-diff check here, provide the primary_keys, splited by comma (without any space). The primary keys will be used to join between the CLF and SOX tables. No need to put `date_partition` here.
 - `mismatch_rate_threshold` [Optional]: The minimum mismatch rate for a column to be considered incorrect, and therefore included in the report. Value must be in range [0, 100).Defaults to 0.0.
 - `tolerance` [Optional]: The tolerance for numeric comparisons. Defaults to 0.0
 - `relative_tolerance` [Optional]: Whether to use relative tolerance (percent difference) instead of absolute tolerance. Defaults to True.

Check the `template.py` for details.

#### Steps to Onboard Your Check
1. Create a branch and register your check following the instructions above.
3. Run the `data_foundations/migration_obs_scheduler.py` notebook to test your registered check. Save the job run URL from the last cell. **Please read the notebook carefully! It has the instruct to target trigger checks registerd by you!**
4. Create a PR and request a review from [Neo Ni](https://databricks.enterprise.slack.com/team/U014BEL0MPW). Attach the screenshot from Step 2 and the URL from Step 3.

Once merged, your check will run daily at the specified time determined by your provided config (`trigger_hour`). If it fails, you will receive a report via email. The history of your checks can be viewed in [this Dashboard](https://billing-workspace-mt-prod-aws-us-west-2.cloud.databricks.com/dashboardsv3/01efa3095031175c9e291624b2518789/published?o=505849424492243).

## Monitor Pipeline Runtime

To monitor the runtime of your pipelines in both CLF and SOX workspaces, onboard your pipelines in [this notebook `data_foundations/job_freshness_monitoring.py`](https://github.com/databricks-it/bse-data/blob/master/data_foundations/job_freshness_monitoring.py) (no execution required).

Create a PR and get approval from [Neo Ni](https://databricks.enterprise.slack.com/team/U014BEL0MPW). Once merged, the runtime data will appear in [this Dashboard](https://billing-workspace-mt-prod-aws-us-west-2.cloud.databricks.com/dashboardsv3/01efa3095031175c9e291624b2518789/published?o=505849424492243) within a day.

## Monitor Table Landing Time

No onboarding is required for monitoring table landing times, provided the table exists in both the `main`/`integration` catalog and the `share_clf_main` catalog. Visit [this Dashboard](https://billing-workspace-mt-prod-aws-us-west-2.cloud.databricks.com/dashboardsv3/01efa3095031175c9e291624b2518789/published?o=505849424492243) to view landing times.
