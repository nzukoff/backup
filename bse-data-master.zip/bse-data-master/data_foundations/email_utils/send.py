"""
Functions for sending emails.
"""

import base64
import logging
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List, Union
from databricks.sdk.runtime import *
import boto3

logger = logging.getLogger()


def _ensure_list(possible_list: Union[str, List[str]]) -> List[str]:
    """
    Wrap arg with a list if it isn't already a list.
    """

    return possible_list if isinstance(possible_list, list) else [possible_list]


def _check_databricks_emails(emails: Union[str, List[str]]):
    """
    Raises a ValueError if any emails in the list is not a @databricks.com email.
    """

    emails = _ensure_list(emails)
    for email in emails:
        if not (email.endswith("@databricks.com") or email.endswith("@databricks.pagerduty.com")):
            raise ValueError(f"Expected an @databricks.com or @databricks.pagerduty.com email but found: {email}")


def send_email(
    *,
    from_email: str,
    to_emails: Union[str, List[str]],
    subject: str,
    body_html: Union[str, List[str]],
    cc_emails: Union[str, List[str]] = [],
    aws_access_key_id: str = "",
    aws_secret_access_key: str = "",
):
    """
    Sends an email using AWS.

    This ensures that only emails ending in @databricks.com can be for sender and receipients.
    """

    if not isinstance(body_html, list):
        body_html = [body_html]

    body_html = _ensure_list(body_html)
    to_emails = _ensure_list(to_emails)
    cc_emails = _ensure_list(cc_emails)

    _check_databricks_emails(from_email)
    _check_databricks_emails(to_emails)
    _check_databricks_emails(cc_emails)

    # calling send_email from a non-notebook context requires passing in aws-credentials manually
    # otherwise, assume calling from notebook context and get credentials via get_db_utils
    if not (aws_access_key_id and aws_secret_access_key):

        aws_access_key_id = dbutils.secrets.get(scope="eng-data-team", key="AWS_ACCESS_KEY_ID")
        aws_secret_access_key = dbutils.secrets.get(scope="eng-data-team", key="AWS_SECRET_ACCESS_KEY")

    attachment_ready_html = []
    img_id = 0
    mime_images = []
    # iterate over raw HTML
    for line in body_html:
        if line.startswith("<img"):
            image_data = line[len("<img src='data:image/png;base64,") : -2]
            mime_img = MIMEImage(base64.standard_b64decode(image_data))
            mime_img.add_header("Content-ID", f"<img-{img_id}>")
            attachment_ready_html.append(f"<center><img src='cid:img-{img_id}'></center>")
            img_id += 1
            mime_images.append(mime_img)
        else:
            attachment_ready_html.append(line)
    logger.info("Added %s images", img_id)

    msg = MIMEMultipart()
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = ", ".join(to_emails)
    msg["CC"] = ", ".join(cc_emails)
    body = MIMEText("\n".join(attachment_ready_html), "html")

    for i in mime_images:
        msg.attach(i)
    msg.attach(body)

    ses = boto3.client(
        "ses", region_name="us-west-2", aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key
    )
    logger.info("Sending Email!")

    logger.info(
        ses.send_raw_email(
            Source=msg["FROM"],
            Destinations=sorted(list(set(to_emails).union(set(cc_emails)))),
            RawMessage={"Data": msg.as_string()},
        )
    )
