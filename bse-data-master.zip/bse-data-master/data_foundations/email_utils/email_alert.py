from itertools import chain
from typing import List, Optional, Union

from pyspark.sql import DataFrame

from lib.consts import (
    ENG_DATA_TEAM_ALERTS_EMAILS,
    ENG_DATA_TEAM_CENTRAL_ONCALL_HIGH_ALERT_PAGERDUTY_EMAIL,
    ENG_DATA_TEAM_CENTRAL_ONCALL_LOW_ALERT_PAGERDUTY_EMAIL,
    ENG_DATA_TEAM_REGIONAL_ONCALL_HIGH_ALERT_PAGERDUTY_EMAIL,
    ENG_DATA_TEAM_REGIONAL_ONCALL_LOW_ALERT_PAGERDUTY_EMAIL,
)
from lib.databricks_api.jobs.context import get_job_name, get_job_run_url
from lib.email.render import (
    apply_table_attributes,
    render_content_container,
    render_email,
    render_table_container,
)
from lib.email.send import send_email
from lib.pandas.html import dataframe_to_html

INCIDENT_TRIGGER_IDENTIFIER = "PAGERDUTY_INCIDENT_TRIGGER"
INCIDENT_RESOLVE_IDENTIFIER = "PAGERDUTY_INCIDENT_RESOLVE"

TEAM_ALERT_RECIPIENT_MAPPING = {
    "central-data": {
        "low": ENG_DATA_TEAM_CENTRAL_ONCALL_LOW_ALERT_PAGERDUTY_EMAIL,
        "high": ENG_DATA_TEAM_CENTRAL_ONCALL_HIGH_ALERT_PAGERDUTY_EMAIL,
    },
    "regional-data": {
        "low": ENG_DATA_TEAM_REGIONAL_ONCALL_LOW_ALERT_PAGERDUTY_EMAIL,
        "high": ENG_DATA_TEAM_REGIONAL_ONCALL_HIGH_ALERT_PAGERDUTY_EMAIL,
    },
}


class EmailAlert:
    """
    EmailAlert class compose and send our email alert to data team pagerduty endpoint.
    Formats data frame as a table.
    See app/monitoring/send_email_alert.py for how to use it.
    """

    def __init__(
        self,
        deployment_mode: str,
        severity: str,
        team: str = "central-data",
        alert_recipient_override: Union[str, List[str]] = None,
    ):
        """

        :param deployment_mode: dev, staging or prod
        :param severity: low/high
        :param team: Only support regional-data and central-data team for now
        :param alert_recipient_override: Alert recipient override. Create your customized alert recipient here.
        """
        self.deployment_mode = deployment_mode
        if alert_recipient_override is not None:
            if type(alert_recipient_override) is str:
                alert_recipient_override = [alert_recipient_override]
            for recipient in alert_recipient_override:
                self.check_alert_recipient_override(recipient)
            self.alert_recipients = alert_recipient_override
        else:
            self.check_team_name_exists(team)
            self.check_severity_exists(team, severity)
            self.alert_recipients = [TEAM_ALERT_RECIPIENT_MAPPING[team][severity]]
        self.alert_sender = ENG_DATA_TEAM_ALERTS_EMAILS

    def check_severity_exists(self, team, severity):
        assert severity in TEAM_ALERT_RECIPIENT_MAPPING[team].keys()

    def check_team_name_exists(self, team):
        assert team in TEAM_ALERT_RECIPIENT_MAPPING.keys()

    def check_alert_recipient_override(self, alert_recipient_override):
        assert alert_recipient_override.endswith("@databricks.com") or alert_recipient_override.endswith(
            "@databricks.pagerduty.com"
        )

    def render_description_html(self, description: str) -> str:
        return render_content_container(f"<p>{description}</p>")

    def render_table_html(self, df: DataFrame) -> str:
        table_html = dataframe_to_html(df.toPandas(), [])
        return render_table_container(apply_table_attributes(table_html))

    def render_job_run_link_html(self) -> str:
        job_run_url = get_job_run_url()
        return render_content_container(
            f"""
            <h2>Alert Job Links</h2>
            <a href="{job_run_url}">{job_run_url}</a>
            """
        )

    def send_email(
        self,
        subject: str,
        description: str,
        table: DataFrame = None,
        full_body_html_override: Optional[Union[str, List[str]]] = None,
        aws_access_key_id: str = "",
        aws_secret_access_key: str = "",
    ):
        if full_body_html_override is None:
            body_html = []
            body_html.append(self.render_description_html(description))
            if table is not None:
                body_html.append(self.render_table_html(table))
            body_html.append(self.render_job_run_link_html())
        else:
            body_html = full_body_html_override
        send_email(
            from_email=self.alert_sender,
            to_emails=self.alert_recipients,
            subject=subject,
            body_html=render_email(chain(body_html)),
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
        )

    def send_auto_resolve_email_wrapper(
        self,
        subject: str,
        description: str = "",
        table: DataFrame = None,
        full_body_html_override: Optional[Union[str, List[str]]] = None,
        is_success_email: bool = False,
        dedup_key: str = None,
        auto_group_name: str = None,
        aws_access_key_id: str = "",
        aws_secret_access_key: str = "",
    ):
        if dedup_key is None:
            dedup_key = get_job_name()
        if is_success_email is False:
            subject = f"{subject} | {INCIDENT_TRIGGER_IDENTIFIER} | DEDUP_KEY:<{dedup_key}>"
        else:
            subject = f"{subject} | {INCIDENT_RESOLVE_IDENTIFIER} | DEDUP_KEY:<{dedup_key}>"
        if auto_group_name is not None:
            subject = f"{subject} | AUTO_GROUP_NAME:<{auto_group_name}>"
        self.send_email(
            subject=subject,
            description=description,
            table=table,
            full_body_html_override=full_body_html_override,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
        )
