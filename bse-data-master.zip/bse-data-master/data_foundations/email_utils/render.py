"""
Common rendering functions for emails.
"""

import logging
import os
from pathlib import Path
from typing import List

from bs4 import BeautifulSoup
from mako.template import Template


logger = logging.getLogger()


def linkify_email(email: str) -> str:
    if not email.endswith("@databricks.com"):
        raise ValueError(f"Not a databricks email: {email}")
    name_only = email.replace("@databricks.com", "")
    return f'<a href="mailto:{email}">{name_only}</a>'


def render_percentage(percent: float) -> str:
    return f"{percent:.1f}%"


def render_dbus(x: float) -> str:
    return f"{x:,.0f}"


def render_dollars(x: float) -> str:
    return f"${x:,.2f}"


def render_pluralized(s: str, c: int) -> str:
    if not isinstance(c, int):
        raise ValueError(f"Expected int: {c}")
    if not isinstance(s, str):
        raise ValueError(f"Expected str {s}")
    return f"{s}s" if c != 1 else s


def render_content_container(inner_html: str, *, div_id: str = None) -> str:
    id_attr = f""" id={div_id}""" if div_id else ""
    return f"""
        <tr>
            <td valign="top" class="bodyContent">
                <div{id_attr}>
                    {inner_html}
                </div>
            </td>
        </tr>
    """


def render_table_container(inner_html: str, *, div_id: str = None) -> str:
    id_attr = f""" id={div_id}""" if div_id else ""
    return f"""
        <tr>
            <td valign="top" style="padding-top:0; padding-bottom:0;">
                <div{id_attr}>
                    {inner_html}
                </div>
            </td>
        </tr>
    """


def apply_table_attributes(table_html: str) -> str:
    """
    Updates the table to have the appropriate attributes so it will display correctly when rendered
    with our email template.
    """

    soup = BeautifulSoup(table_html, "html.parser")

    table = soup.find("table")
    table["border"] = "0"
    table["cellpadding"] = "10"
    table["cellspacing"] = "0"
    table["width"] = "100%"
    table["class"] = "templateDataTable"

    soup.find("tr")["style"] = ""

    for th_tag in soup.find_all("th"):
        th_tag["scope"] = "col"
        th_tag["valign"] = "top"
        th_tag["class"] = "dataTableHeading"

    for th_tag in soup.find_all("td"):
        th_tag["valign"] = "top"
        th_tag["class"] = "dataTableContent"

    return soup.prettify()


def render_email(content_blocks: List[str], *, width: int = 1000) -> str:
    """
    Renders the content within the email template.
    """

    template_path = os.path.join(Path(__file__).parent, "templates/email.html.mako")
    template = Template(filename=template_path)

    html_content = template.render(width=width, main_content="\n".join(content_blocks))

    return html_content
