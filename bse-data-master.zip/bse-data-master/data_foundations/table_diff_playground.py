# Databricks notebook source
# MAGIC %pip install jinja2

# COMMAND ----------

from table_diff.table_diff import TableDiff
import pyspark.sql.functions as fn

# COMMAND ----------

# Read the dataframe from your base table
left_df = None
# Read the dataframe from your base table
right_df = None

primary_keys = ["Id"]

# COMMAND ----------

table_diff = TableDiff(left_df, right_df)
table_diff.rows_diff_report(primary_keys,
                            tolerance=0, # The (relative) tolerance for numeric comparisons. Defaults to 0.0.
                            mismatch_rate_threshold=0, # The minimum mismatch rate for a column to be considered incorrect, and therefore included in the report. Value must be in range [0, 100).Defaults to 0.0.
                            format="txt")
