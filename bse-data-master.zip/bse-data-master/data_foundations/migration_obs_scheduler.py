# Databricks notebook source
# DBTITLE 1,Import module
import requests
import time
from datetime import datetime
import pytz
from registered_table_pairs import MAIN_ALL_REGISTERED_CHECKS
from utils import trigger_check_run, get_run_status

# COMMAND ----------


utc = pytz.timezone('UTC')

current_time = datetime.now(utc)
current_hour = current_time.hour

# COMMAND ----------

# MAGIC %md
# MAGIC ### If you are running a test to trigger your own checks in this notebook, you must turn `test_run` widget to True

# COMMAND ----------

dbutils.widgets.dropdown("test_run", "False", ["True", "False"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Now select your target `owner_email` or `test_name` that you want to trigger
# MAGIC - You can select only `owner_email` **or** test_name`, not both.
# MAGIC - If `owner_email` is provided, then it will trigger all the checks registered by you.
# MAGIC - If `test_name` is provided, if only trigger that check

# COMMAND ----------

test_run = dbutils.widgets.get("test_run") == "True"

if test_run:
    dbutils.widgets.dropdown("owner_email", "", [""] + list(set([c["owner_email"] for c in MAIN_ALL_REGISTERED_CHECKS])))
    dbutils.widgets.dropdown("test_name", "", [""] + [c["name"] for c in MAIN_ALL_REGISTERED_CHECKS])
else:
    assert not ((dbutils.notebook.entry_point.getDbutils().notebook().getContext()).jobId()).isEmpty(), "You must turn `test_run` on when you running a test in notebook"

# COMMAND ----------


if test_run:
    owner_email = dbutils.widgets.get("owner_email")
    test_name = dbutils.widgets.get("test_name")

# COMMAND ----------

if test_run:
    assert (test_name == "" and owner_email != "") or (test_name != "" and owner_email == ""), "You need to provide either an owner_email or a test_name, you cannot provide both"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Trigger all the target checks.

# COMMAND ----------

# DBTITLE 1,Trigger Table Diff Job
failed_checks = []
running_checks = []
for check in MAIN_ALL_REGISTERED_CHECKS:
    schema, table_name = check["table_pair_id"].split("--")
    if 'clf_table_name_overwrite' not in check or check['clf_table_name_overwrite'] == '':
        left_table_name = f"share_clf_main.{schema}.{table_name}"
    else:
        left_table_name = check['clf_table_name_overwrite']

    if 'sox_table_name_overwrite' not in check or check['sox_table_name_overwrite'] == '':
        right_table_name = f'{check["environment"]}.{schema}.{table_name}'
    else:
        right_table_name = check['sox_table_name_overwrite']
    check_config = {
        "check_name": check["name"],
        "owner_email": check["owner_email"],
        "environment": check["environment"],
        "left_table_name": left_table_name,
        "right_table_name": right_table_name,
        "left_query": check.get("clf_sql_overwrite", ""),
        "right_query": check.get("sox_sql_overwrite", ""),
        "left_drop_cols": check.get("clf_drop_columns", ""),
        "right_drop_cols": check.get("sox_drop_columns", ""),
        "date_partition": check.get("date_partition", ""),
        "date_range": check.get("date_range", ""),
        "primary_keys": check["primary_keys"],
        "tolerance": str(check.get("tolerance", "0")),
        "mismatch_rate_threshold": str(check.get("mismatch_rate_threshold", "0")),
        "use_relative_tolerance": str(check.get("relative_tolerance", True)),
        "run_except_all": str(check.get("run_except_all", False)),
        "if_cache": str(check.get("is_dlt", False) is False),
        "allow_dups": str(check.get("allow_dups", False)),
    }
    if (test_run is False and int(check["trigger_hour"]) == int(current_hour)) or (test_run and test_name != "" and test_name == check_config["check_name"]) or (test_run and owner_email != "" and owner_email == check_config["owner_email"]):
        if check.get("is_dlt", False):
            job_id = "1030012296532797"
        else:
            job_id = "1125627783355300"
        run_id, res = trigger_check_run(check_config, job_id)
        if res is None:
            failed_checks.append(check)
        else:
            print(f"Successfully trigger the check {check_config['check_name']}:")
            print(res)
            print("-"*20)
            running_checks.append((run_id, res))
if len(failed_checks)>0:
    print(f"""
          Some checks failed to trigger:
          {failed_checks}
          """)
    assert False

# COMMAND ----------

# MAGIC %md
# MAGIC ### The next cell check the run status of the triggered job runs, please make sure all the job you you trigger are succeeded.

# COMMAND ----------

all_check_triggered = len(running_checks)
running_failure_checks = []
if test_run:
    while(len(running_checks)>0):
        print(f"Waiting for the all checks to finish... | Running checks: {len(running_checks)}/{all_check_triggered} | Failed checks: {len(running_failure_checks)}/{all_check_triggered}")
        for run_id, url in running_checks:
            status = get_run_status(run_id)
            if status == "SUCCESS":
                running_checks.remove((run_id, url))
            elif status == "RUNNING":
                continue
            else:
                running_checks.remove((run_id, url))
                running_failure_checks.append((run_id, url))
                print(f"Check run failed: {url}")
        time.sleep(60)
assert len(running_failure_checks) == 0, f"Some checks failed to trigger: {running_failure_checks}"
