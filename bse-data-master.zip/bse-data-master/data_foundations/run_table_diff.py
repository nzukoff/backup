# Databricks notebook source
# MAGIC %pip install jinja2

# COMMAND ----------

# MAGIC %pip install bs4

# COMMAND ----------

# MAGIC %pip install mako

# COMMAND ----------

from table_diff.table_diff import TableDiff
from datetime import date, datetime, timedelta, timezone
import pytz
import pyspark.sql.functions as fn
from pyspark.sql import types as T
from pyspark.sql import Row
import copy
from email_utils.send import send_email
from itertools import chain
from email_utils.render import render_email
import json
import traceback

# COMMAND ----------

dbutils.widgets.text("check_name", "")
dbutils.widgets.text("owner_email", "")
dbutils.widgets.dropdown("environment", "main", ["main", "integration"])
dbutils.widgets.text("left_table_name", "")
dbutils.widgets.text("right_table_name", "")
dbutils.widgets.text("left_query", "")
dbutils.widgets.text("right_query", "")
dbutils.widgets.text("left_drop_cols", "")
dbutils.widgets.text("right_drop_cols", "")
dbutils.widgets.text("date_partition", "")
dbutils.widgets.text("date_range", "")
dbutils.widgets.text("primary_keys", "")
dbutils.widgets.text("tolerance", "0")
dbutils.widgets.text("mismatch_rate_threshold", "0")
dbutils.widgets.text("use_relative_tolerance", "True")
dbutils.widgets.text("run_except_all", "False")
dbutils.widgets.text("if_cache", "True")
dbutils.widgets.text("allow_dups", "False")
# dbutils.widgets.text("job_id", "{{job.id}}")
# dbutils.widgets.text("run_id", "{{job.run_id}}")

# COMMAND ----------

def pre_processing_input_params(input_params):
    assert input_params["check_name"] is not None and input_params["check_name"] != "", "check_name must be provided"
    assert input_params["owner_email"] is not None and input_params["owner_email"] != "", "owner_email must be provided"
    assert input_params["environment"] is not None and input_params["environment"] in ("main", "integration"), "environment must be either main or integration"
    input_params["left_table_name"] = input_params["left_table_name"] if input_params["left_table_name"] is not None else ""
    input_params["right_table_name"] = input_params["right_table_name"] if input_params["right_table_name"] is not None else ""
    input_params["left_query"] = input_params["left_query"] if input_params["left_query"] is not None else ""
    input_params["right_query"] = input_params["right_query"] if input_params["right_query"] is not None else ""
    input_params["left_drop_cols"] = input_params["left_drop_cols"] if input_params["left_drop_cols"] is not None else ""
    input_params["right_drop_cols"] = input_params["right_drop_cols"] if input_params["right_drop_cols"] is not None else ""
    input_params["date_partition"] = input_params["date_partition"] if input_params["date_partition"] is not None else ""
    input_params["date_range"] = input_params["date_range"] if input_params["date_range"] is not None else ""
    assert input_params["primary_keys"] is not None and input_params["primary_keys"] != "", "primary_keys must be provided"
    input_params["tolerance"] = "0" if (input_params["tolerance"] is None or input_params["tolerance"] == "") else input_params["tolerance"] 
    input_params["mismatch_rate_threshold"] = "0" if (input_params["mismatch_rate_threshold"] is None or input_params["mismatch_rate_threshold"] == "") else input_params["mismatch_rate_threshold"] 
    input_params["use_relative_tolerance"] = "True" if (input_params["use_relative_tolerance"] is None or input_params["use_relative_tolerance"] == "") else input_params["use_relative_tolerance"]
    input_params["run_except_all"] = "False" if (input_params["run_except_all"] is None or input_params["run_except_all"] == "") else input_params["run_except_all"]
    input_params["if_cache"] = "True" if (input_params["if_cache"] is None or input_params["if_cache"] == "") else input_params["if_cache"]
    input_params["allow_dups"] = "False" if (input_params["allow_dups"] is None or input_params["allow_dups"] == "") else input_params["allow_dups"]


    return input_params


def send_email_for_error(error_message,
                         traceback_message,
                         input_params):
    body_html = f"""
    <h1>Table Diff Check Job Run Failure: {input_params["check_name"]}</h1>
    <h2>Job Run Links</h2>
    <a href="{job_run_url}">{job_run_url}</a>
    <p>Owner: {input_params['owner_email']}</p>
    <p>Check Timestamp: {datetime.now(pytz.timezone('US/Pacific'))}</p>
    <p>Error: {error_message}</p>
    <p>Traceback: {traceback_message}</p>
    """

    send_email(
        from_email='eng-data-team-alerts@databricks.com',
        to_emails=input_params['owner_email'],
        subject=f"Table Diff Check Job Triggered by You has Failed",
        body_html=render_email(chain([body_html])),
    )



def get_both_tables(input_params):
    DATES_PREF_FORMAT = "%Y-%m-%d"
    today = datetime.now(pytz.timezone('UTC')).strftime(DATES_PREF_FORMAT)

    if input_params["left_query"] != "":
        base_df = spark.sql(input_params["left_query"])
        if input_params["if_cache"] == "True":
            base_df = base_df.cache()
        base_name = "left_query"
    elif input_params["left_table_name"] != "":
        base_df = spark.table(input_params["left_table_name"])
        base_name = input_params["left_table_name"]
    else:
        assert False

    if input_params["right_query"] != "":
        compare_df = spark.sql(input_params["right_query"])
        if input_params["if_cache"] == "True":
            compare_df = compare_df.cache()
        compare_name = "right_query"
    elif input_params["right_table_name"] != "":
        compare_df = spark.table(input_params["right_table_name"])
        compare_name = input_params["right_table_name"]
    else:
        assert False

    if input_params["date_partition"] != "":
        end_date = today
        start_date = (datetime.strptime(today, DATES_PREF_FORMAT) - timedelta(days=int(input_params["date_range"]))).strftime(DATES_PREF_FORMAT)
        base_df = base_df.filter(fn.col(input_params["date_partition"]) >= start_date).filter(fn.col(input_params["date_partition"]) <= end_date)
        compare_df = compare_df.filter(fn.col(input_params["date_partition"]) >= start_date).filter(fn.col(input_params["date_partition"]) <= end_date)

    if input_params["left_drop_cols"]:
        drop_cols = [col for col in input_params["left_drop_cols"].split(",") if col in base_df.columns]
        base_df = base_df.drop(*drop_cols)

    if input_params["right_drop_cols"]:
        drop_cols = [col for col in input_params["right_drop_cols"].split(",") if col in compare_df.columns]
        compare_df = compare_df.drop(*drop_cols)

    primary_keys = input_params["primary_keys"].split(",") + ([] if input_params["date_partition"] == "" else [input_params["date_partition"]])
    return base_df, compare_df, base_name, compare_name, primary_keys

# COMMAND ----------

input_params = dbutils.widgets.getAll()
try:
    input_params = pre_processing_input_params(input_params)
except Exception as e:
    traceback_message = traceback.format_exc()
    send_email_for_error(str(e), traceback_message, input_params)
    raise e

try:
    job_id = (dbutils.notebook.entry_point.getDbutils().notebook().getContext()).jobId().get()
    run_id = (dbutils.notebook.entry_point.getDbutils().notebook().getContext()).jobRunId().get()
    job_run_url = f"https://billing-workspace-mt-prod-aws-us-west-2.cloud.databricks.com/jobs/{job_id}/runs/{run_id}?o=505849424492243"
except e:
    print(f"Failed to extract job_id and run_id from the context: {str(e)}")
    job_run_url = None

    

# COMMAND ----------

try:
    base_df, compare_df, base_name, compare_name, primary_keys = get_both_tables(input_params)
except Exception as e:
    traceback_message = traceback.format_exc()
    send_email_for_error(str(e), traceback_message, input_params)
    raise e
    

# COMMAND ----------

table_diff = TableDiff(base_df, compare_df, base_name=base_name, compare_name=compare_name)


# COMMAND ----------

try:
    if input_params["run_except_all"] == "True":
        compare_df = compare_df.select(base_df.columns)
        res = base_df.exceptAll(compare_df)
        if res.count() > 0:
            diff_report = "The EXCEPT ALL check has failed, please check the job run for more details"
            check_passed = False
            display(res)
        else:
            diff_report = "The EXCEPT ALL check has passed"
            check_passed = True
    else:
        row_diff_output = table_diff.rows_diff_report(primary_keys,
                                                    tolerance=float(input_params["tolerance"]), 
                                                    mismatch_rate_threshold=float(input_params["mismatch_rate_threshold"]), 
                                                    use_relative_tolerance=(input_params["mismatch_rate_threshold"]=="True"),
                                                    allow_dupslicate_rows=(input_params["allow_dups"]=="True"),
                                                    return_result=True,
                                                    format="txt")
        row_diff_res = table_diff.rows_check.passed
        schema_diff_res = table_diff.rows_check.schema_check.passed
        check_passed = row_diff_res and schema_diff_res
        diff_report = row_diff_output
    print(diff_report)
except Exception as e:
    traceback_message = traceback.format_exc()
    send_email_for_error(str(e), traceback_message, input_params)
    raise e


# COMMAND ----------


log_entry = copy.deepcopy(input_params)
log_entry.update({
  "check_result": check_passed,
  "check_timestamp": datetime.now(pytz.timezone('US/Pacific')),
  "job_run_url": job_run_url,
  "diff_report": diff_report,
  "clf_table_schema_name": input_params["left_table_name"].split(".")[1],
  "clf_table_name": input_params["left_table_name"].split(".")[2]
})
log_row = Row(**log_entry)
df = spark.createDataFrame([log_row])
df = df.withColumn("check_date", df["check_timestamp"].cast("date")).select("check_name", "environment", "owner_email", "check_result", "check_timestamp", "job_run_url", "diff_report", "clf_table_schema_name", "clf_table_name")
print("Log check result...")
df.write.mode("append").option("mergeSchema", "true").saveAsTable("integration.sox_migration_misc.table_diff_check_logs")

# COMMAND ----------

# if check_passed is False:
#     heading_html = f"""
#     <h1>Table Diff Check: {input_params['check_name']}</h1>
#     <h2>Job Run Links</h2>
#     <a href="{job_run_url}">{job_run_url}</a>
#     <p>Owner: {input_params['owner_email']}</p>
#     <p>Environment: {input_params['environment']}</p>
#     <p>Check Timestamp: {datetime.now(pytz.timezone('US/Pacific'))}</p>
#     <p>Diff Result: <span style="color:{'green' if check_passed else 'red'}">{'Success' if check_passed else 'Failed'}</span></p>
#     """

#     row_diff_html = "\n".join([f'<p>{l}</p>' for l in diff_report.split("\n")])

#     send_email(
#         from_email='eng-data-team-alerts@databricks.com',
#         to_emails=input_params['owner_email'],
#         subject=f"Table Diff Check: {input_params['check_name']} Failed",
#         body_html=render_email(chain([heading_html, row_diff_html])),
#     )
