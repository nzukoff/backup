from dataclasses import dataclass
from typing import List, Optional, Set, Union

from pandas import DataFrame as pdDataFrame
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, collect_list, count, slice, sum
from pyspark.sql.types import (
    BooleanType,
    DoubleType,
    IntegerType,
    StringType,
    StructField,
    StructType,
)

from .diff_check import DiffCheck
from .schema_diff_check import SchemaDiffCheck
from .utils import (
    COMPARABLE_SPARK_TYPES,
    COMPLEX_SPARK_TYPES,
    NUMERIC_SPARK_TYPES,
    PYSPARK_PANDAS_DTYPE_MAP,
    parse_dtype_str,
)


@dataclass
class MismatchColumnSummary:
    """
    Data class for keeping track of metadata about column mismatches that is used
    in text report
    """

    column_name: str
    num_mismatches: int
    mismatch_rate: float
    column_dtype: str
    sample_rows: Optional[pdDataFrame] = None

    @property
    def num_mismatches_str(self) -> str:
        return str(self.num_mismatches)

    @property
    def mismatch_rate_str(self) -> str:
        if self.mismatch_rate >= 0.01:
            return "{:.2f}%".format(self.mismatch_rate)
        elif self.num_mismatches > 0:
            return "<0.01%"
        else:
            return "N/A"


class RowsDiffCheck(DiffCheck):
    def __init__(
        self,
        spark: SparkSession,
        join_keys: Union[str, List[str]],
        base_df: DataFrame,
        compare_df: DataFrame,
        base_name: Optional[str] = "base_df",
        compare_name: Optional[str] = "compare_df",
        rows_check_columns: Optional[Union[List[str], str]] = None,
        tolerance: Optional[float] = 0,
        use_relative_tolerance: Optional[bool] = True,
        mismatch_rate_threshold: Optional[float] = 0.0,
        allow_dupslicate_rows: Optional[bool] = False,
        n_sample_rows: Optional[int] = 5,
        output_correct_columns: Optional[bool] = False,
        cache_intermediates: Optional[bool] = False,
        schema_check: Optional[SchemaDiffCheck] = None,
    ) -> None:
        """
        Initialize the RowsDiffCheck object.

        Args:
            spark (SparkSession): Spark session to use
            join_keys (str or list): Column/s to join base_df and compare_df on
            base_df (DataFrame): The base DataFrame for rowwise comparison.
            compare_df (DataFrame): The DataFrame to compare against the base_df
            base_name (str, optional):
                A string representing the name of the base DataFrame. Defaults to "base_df".
            compare_name (Optional[str], optional):
                A string representing the name of the compare DataFrame. Defaults to "compare_df".
            rows_check_columns (Optional[List[str]], optional):
                Columns to include in report. If None then RowsDiffCheck will
                identify and compare all comparable columns.
            tolerance (Optional[float], optional):
                The absolute or relative tolerance for numeric comparisons. Defaults to 0.0
            use_relative_tolerance (Optional[bool], optional):
                Whether to use relative tolerance (percent difference) instead of absolute tolerance. Defaults to True
            mismatch_rate_threshold (Optional[float], optional):
                Minimum mismatch rate for a column to be considered incorrect. Defaults to 0.0
            n_sample_rows (Optional[int], optional):
                The number of rows to output for each column that is mismatched in the report. If 0
                then the section of report with sample rows is omitted. Defaults to 5
            output_correct_columns: Optional[bool], optional):
                Whether or not to include output columns where all rows were equal in base_df and compare_df in
                the text report. Defaults to False
            cache_intermediates (Optional[bool], optional):
                Whether or not to cache intermediate DataFrames (deduped base/compare and joined df). Defaults to False
            schema_check (Optional[SchemaCheck], optional):
                The SchemaCheck instance to use to identify what columns can be compared row-by-row between base_df and
                compare_df. If None, then a new SchemaCheck will be created and run to identify what columns we can
                compare. Defaults to None

        Raises:
            ValueError: If tolerance is negative or n_sample_rows negative
        """
        if type(join_keys) == str:
            self.join_keys = [join_keys]
        else:
            self.join_keys = join_keys

        if type(rows_check_columns) == str:
            self.rows_check_columns = set([rows_check_columns])
        elif rows_check_columns is not None:
            self.rows_check_columns = set(rows_check_columns)
        else:
            self.rows_check_columns = rows_check_columns

        if tolerance < 0:
            raise ValueError("Please enter non-negative tolerance")
        self.tolerance = tolerance
        self.use_relative_tolerance = use_relative_tolerance

        if mismatch_rate_threshold < 0 or mismatch_rate_threshold >= 1:
            raise ValueError("Please enter mismatch_rate_threshold in range [0, 1)")

        if n_sample_rows < 0:
            raise ValueError("Please enter non-negative n_sample_rows")
        self.n_sample_rows = n_sample_rows

        self.mismatch_rate_threshold = 100 * mismatch_rate_threshold
        self.allow_dupslicate_rows = allow_dupslicate_rows
        self.output_correct_columns = output_correct_columns
        self.cache_intermediates = cache_intermediates
        self.schema_check = schema_check

        super().__init__(spark, base_df, compare_df, base_name=base_name, compare_name=compare_name)

    @property
    def templates(self):
        return {"txt": "rows_diff_report.txt", "md": "rows_diff_report_md.txt"}

    def run(self) -> None:
        """
        Run the Rows Diff Check and materialize the results as class attributes.
        This is done through 3 main steps:
            Creating the joined_df with _join_dataframe()
            Calculating counts of values for columns about unequal rows/samples with _calculate_mismatch_summaries()
            Calculating metrics on how many columns had some or all mismatch values and metrics on rows missing
                in the inner join of base_df and compare_df with _calculate_diff_metrics()

        Returns:
            None
        """

        self._preprocess()

        self._join_dataframe()

        if self.cache_intermediates:
            self._joined_df.cache()

        self._calculate_mismatch_summaries(use_sample_rows=True if self.n_sample_rows > 0 else False)

        if self._num_matched_rows > 0:
            self._calculate_diff_metrics(self._compare_columns)
            self.columns_to_report_list = sorted(
                self.columns_to_report_list,
                key=lambda key: (
                    -self.mismatch_col_summaries[key].num_mismatches,
                    self.mismatch_col_summaries[key].column_name,
                ),
            )
            self.num_columns_to_report = len(self.columns_to_report_list)
        else:
            self._num_missing_in_base = self._num_rows_base_deduped
            self._num_missing_in_compare = self._num_rows_compare_deduped
            self._num_cols_always_mismatch = 0
            self._num_cols_sometimes_mismatch = 0
            self.passed = all([
                self._num_rows_base == 0,
                self._num_rows_compare == 0
                ]
            )
            self.columns_to_report_list = sorted(self.columns_to_report)
            self.num_columns_to_report = len(self.columns_to_report_list)

    def __str__(self) -> str:
        return str(
            {
                "check_name": "rows_diff",
                "join_keys": self.join_keys,
                "tolerance": self.tolerance,
                "use_relative_tolerance": self.use_relative_tolerance,
                "mismatch_rate_threshold": self.mismatch_rate_threshold,
                "rows_check_columns": self.rows_check_columns,
                "n_sample_rows": self.n_sample_rows,
                "output_correct_columns": self.output_correct_columns,
                "cache_intermediates": self.cache_intermediates,
            }
        )

    def _preprocess(self) -> None:
        """
        Preprocess steps before running rows diff check. Materializes class attributes

        Returns:
            None

        Attributes:
            _compare_columns (List[str]):
                Columns that are common to both base_df and compare_df, which we compare row-by-row on
            _cannot_compare_dtype_columns (List[str]):
                Columns with complex datatypes (i.e. ArrayType, StructType) that we cannot compare, which
                we ignore in our check
            _cannot_compare_columns (List[str]):
                Columns that fail schema check either by being missing in base_df or compare_df, or
                having uncomparable datatypes, which we ignore in our check
            _base_df_deduped (DataFrame):
                base_df with duplicates removed
            _compare_df_deduped (DataFrame):
                compare-df with duplicates removed
            _num_rows_base (int):
                Number of rows in original base_df
            _num_rows_compare (int):
                Number of rows in original compare-df
            _num_rows_base_deduped (int):
                Number of rows in deduped base_df
            _num_rows_compare_deduped (int):
                Number of rows in deduped compare_df
            _num_dupes_in_base (int):
                Number of duplicate rows by join-key/s in base_df
            _num_dupes_in_compare (int):
                Number of duplciate rows by join-key/s in compare_df
            _columns_missing_in_base (Set[str]):
                Columns that cannot be compared because they are missing in base_df
            _columns_missing_in_compare (Set[str]):
                Columns that cannot be compared because they are missing in compare_df
            _columns_dtype_mismatch (Set[str)]):
                Columns that cannot be compared because their data types are different
                between base_df and compare_df and these types are not comparable
            _num_cols_missing_in_base (int):
                Length of _columns_missing_in_base
            _num_cols_missing_in_compare (int):
                Length of _columns_missing_in_compare
            _num_cols_dtype_mismatch (int):
                Length of _columns_dtype_mismatch
            _cannot_compare_dtype_columns (List[str]):
                Columns that cannot be compared because their data types are complex and not supported, i.e array
            _num_cols_cannot_compare_dtype (int):
                Length of _cannot_compare_dtype_columns

        Raises:
            ValueError: If a column's datatype is not recognized as comparable or a known uncomparable complex type

        """

        # Run schema check to find which columns we can compare or use the already ran schema check passed in
        if self.schema_check is None:
            self.schema_check = SchemaDiffCheck(
                self.spark, self._base_df, self._compare_df, base_name=self._base_name, compare_name=self._compare_name
            )
            self.schema_check.run()

        possible_compare_columns = self.schema_check.correct_columns.union(
            self.schema_check.dtype_comparable_columns
        ) - set(self.join_keys)

        # If user specifies columns to compare, we only check those
        if self.rows_check_columns is not None:
            possible_compare_columns = possible_compare_columns.intersection(self.rows_check_columns)
            # We also only show if these specific columns were dropped in report
            self._columns_missing_in_base = self.schema_check.missing_in_base.intersection(self.rows_check_columns)
            self._columns_missing_in_compare = self.schema_check.missing_in_compare.intersection(
                self.rows_check_columns
            )
            self._columns_dtype_mismatch = self.schema_check.dtype_mismatch_columns.intersection(
                self.rows_check_columns
            )
        else:
            self._columns_missing_in_base = self.schema_check.missing_in_base
            self._columns_missing_in_compare = self.schema_check.missing_in_compare
            self._columns_dtype_mismatch = self.schema_check.dtype_mismatch_columns

        self._num_cols_missing_in_base = len(self._columns_missing_in_base)
        self._num_cols_missing_in_compare = len(self._columns_missing_in_compare)
        self._num_cols_dtype_mismatch = len(self._columns_dtype_mismatch)

        compare_columns = set([])
        cannot_compare_dtype_columns = set([])

        # Check if columns are complex dtypes we cannot compare i.e. struct, map
        for column in possible_compare_columns:
            column_dtype = parse_dtype_str(self.schema_check.base_df_schema[column])
            if column_dtype in COMPARABLE_SPARK_TYPES:
                compare_columns.add(column)
            elif column_dtype in COMPLEX_SPARK_TYPES:
                cannot_compare_dtype_columns.add(column)
            else:
                raise ValueError(
                    f"Datatype {column_dtype} in column {column} is not recognized as a comparable or noncomparable \
(complex) datatype"
                )
        self._compare_columns = sorted(list(compare_columns))
        self._cannot_compare_dtype_columns = sorted(list(cannot_compare_dtype_columns))
        self._cannot_compare_columns = sorted(
            list(self._columns_missing_in_base | self._columns_missing_in_compare | self._columns_dtype_mismatch)
        )
        self._num_cols_cannot_compare_dtype = len(self._cannot_compare_dtype_columns)

        # Drop duplicates
        self._base_df_deduped = self._base_df.dropDuplicates(self.join_keys)
        self._compare_df_deduped = self._compare_df.dropDuplicates(self.join_keys)

        if self.cache_intermediates:
            self._base_df_deduped.cache()
            self._compare_df_deduped.cache()

        self._num_rows_base = self._base_df.count()
        self._num_rows_compare = self._compare_df.count()

        self._num_rows_base_deduped = self._base_df_deduped.count()
        self._num_rows_compare_deduped = self._compare_df_deduped.count()

        self._num_dupes_in_base = self._num_rows_base - self._num_rows_base_deduped
        self._num_dupes_in_compare = self._num_rows_compare - self._num_rows_compare_deduped

    def _join_dataframe(self) -> None:
        """
        Generate the inner joined dataframe between base_df and compare_df, joined along the
        specified join keys

        Returns:
            None

        Attributes:
            _joined_df (DataFrame):
                Inner join table of base_df and compare_df, which has schema:

                join_key1 | join_key2 | ... | join_keyN | A_col1 | B_col1 | A_col2 | B_col2 | ... | A_colN | B_colN

                Where A and B prefix base_df and compare_df columns repsectively,
                join_keys are the passed in join key/s when initializing RowsDiffCheck, and
                col1 through colN are derived from _preprocess(), and represent the common columns in
                base_df and compare_df that we are able to compare
        """

        # `A` represents base_df and `B` represents compare_df

        join_statement = " AND ".join(
            [f"A.{join_column_name}<=>B.{join_column_name}" for join_column_name in self.join_keys]
        )
        select_exprs = [f"A.{join_key} as {join_key}" for join_key in self.join_keys] + [
            f"A.{compare_column_name} AS A_{compare_column_name},"
            + f"B.{compare_column_name} AS B_{compare_column_name}"
            for compare_column_name in self._compare_columns
        ]
        select_expr_full = ", ".join(select_expr for select_expr in select_exprs)

        self._base_df_deduped.createOrReplaceTempView("base_df")
        self._compare_df_deduped.createOrReplaceTempView("compare_df")

        query = f"SELECT {select_expr_full} FROM base_df A JOIN compare_df B ON {join_statement}"

        self._joined_df = self.spark.sql(query)

    def _create_case_statement(self, column_name: str, use_sample_rows: bool = False) -> str:
        """
        Creates the `CASE` statement that is used to generate the columns for the row check, which
        are generated columns that represent whether or not the column we are comparing matches for the
        given row if use_sample_rows is False, or columns that contain samples of the mismatches for when
        the column's value for the row mismatches between base_df and compare_df, and NULL values for matches

        Args:
            column_name (str): Name of columnn being compared which we generate case statement for
            use_sample_rows (bool, optional): Whether or not to generate columns that indicate matches or columns
                that contain samples

        Returns:
            str: SQL `CASE` statement that generates a derived column from `column_name`, either of booleans
                representing matches or a column of samples for mismatches and NULL values for matches
        """
        equal_comparisons = [f"(A_{column_name} IS NULL AND B_{column_name} IS NULL)"]
        if self.schema_check.base_df_schema[column_name] in NUMERIC_SPARK_TYPES:
            equal_comparisons.append(f"(A_{column_name} == FLOAT('NaN') AND B_{column_name} == FLOAT('NaN'))")
            equal_comparisons.append(f"(A_{column_name} == FLOAT('infinity') AND B_{column_name} == FLOAT('infinity'))")
        if self.schema_check.base_df_schema[column_name] in NUMERIC_SPARK_TYPES and self.tolerance > 0:
            # Enabling matches with numeric comparison with tolerance
            if self.use_relative_tolerance:
                # Relative tolerance
                equal_comparisons.append(
                    f"(abs(B_{column_name} - A_{column_name}) <= {self.tolerance} * abs(A_{column_name}))"
                )
            else:
                # Absolute tolerance
                equal_comparisons.append(f"(abs(B_{column_name} - A_{column_name}) <= {self.tolerance})")
        else:
            equal_comparisons.append(f"(A_{column_name} = B_{column_name})")

        case_statement = "CASE WHEN " + " OR ".join(equal_comparisons)

        if use_sample_rows:
            array_cols_str = (
                ", ".join([f"CAST({join_key} as STRING)" for join_key in self.join_keys])
                + f", CAST(A_{column_name} as STRING), CAST(B_{column_name} as STRING)"
            )
            case_statement += f" THEN NULL ELSE ARRAY({array_cols_str}) END as {column_name}_sample"
        else:
            case_statement += f" THEN TRUE ELSE FALSE END as {column_name}_match"

        return case_statement

    def _calculate_mismatch_summaries(self, use_sample_rows: bool = False) -> None:
        """
        From self._joined_df which has schema:
        join_key1 | ... |  join_keyN | A_col1 | B_col1 | ... | A_colN | B_colN |

        We calculate additional columns:
            If use_sample_rows is False:

                join_key1 | ... |  join_keyN | A_col1 | B_col1 | ... | A_colN | B_colN | col1_match | ... | colN_match,

                where colX_match are flag columns representing whether or not A_colX and B_colX values match. Then
                we aggregate total row count and number of False values for match columns to calculate mismatch
                counts/rates


            If use_sample_rows is True:

            join_key1 | ... |  join_keyN | A_col1 | B_col1 | ... | A_colN | B_colN | col1_sample | ... | colN_sample,
            Where colX_sample is array of type string,
            with fixed length of number of join_keys + 2 (A_colX and B_colX), or NULL if the values do match.
            Then, we aggregate number of NULLs in sample
            columns and the first n_sample_rows of samples for each colX_sample to calculate mismatch counts and the
            required number of sample mismatch rows

        Args:
            use_sample_rows: (Optional[bool], optional):
                Whether or not to generate columns for sample rows of mismatches, instead of generating columns of
                flags indicating matches. Defaults to False.

        Returns:
            None

        Attributes:
            mismatch_col_summaries: (Dict[str, MismatchColumnSummary]):
                Dictionary that maps column names to MismatchColumnSummary objects
        """

        case_statements = ["*"] + [
            self._create_case_statement(column_name, use_sample_rows=use_sample_rows)
            for column_name in self._compare_columns
        ]
        self._joined_df.createOrReplaceTempView("joined_df")
        full_query = "SELECT " + ", ".join(case_statements) + " FROM joined_df"

        total_rows_count = [count("*").alias("num_rows")]

        mismatch_rows_count = (
            [
                sum((~col(f"{column_name}_match")).cast("int")).alias(column_name + "_uneq_count")
                for column_name in self._compare_columns
            ]
            if not use_sample_rows
            else [
                (count(col(f"{column_name}_sample"))).alias(f"{column_name}_uneq_count")
                for column_name in self._compare_columns
            ]
        )

        samples_agg = (
            []
            if not use_sample_rows
            else [
                slice(collect_list(col(f"{column_name}_sample")), 1, self.n_sample_rows).alias(f"{column_name}_samples")
                for column_name in self._compare_columns
            ]
        )
        self._joined_df_with_mismatch_data = self.spark.sql(full_query)
        if self.cache_intermediates:
            self._joined_df_with_mismatch_data.cache()

        agg_list = total_rows_count + mismatch_rows_count + samples_agg
        mismatch_data = self._joined_df_with_mismatch_data.agg(*agg_list).collect()[0]
        self._num_matched_rows = mismatch_data["num_rows"]

        self.mismatch_col_summaries = {}
        if self._num_matched_rows > 0:
            for column_name in self._compare_columns:
                num_mismatches = mismatch_data[f"{column_name}_uneq_count"]
                mismatch_summary = MismatchColumnSummary(
                    column_name,
                    num_mismatches,
                    100 * num_mismatches / self._num_matched_rows,
                    self.schema_check.base_df_schema[column_name],
                    sample_rows=None,
                )
                if use_sample_rows and num_mismatches > 0:
                    sample_column_names = (
                        self.join_keys
                        + [f"{column_name} ({self._base_name})"]
                        + [f"{column_name} ({self._compare_name})"]
                    )

                    # Get the corresponding Pandas DataFrame dtype for the sample rows pandas DataFrame
                    sample_dtypes = {
                        join_key: PYSPARK_PANDAS_DTYPE_MAP[parse_dtype_str(self.schema_check.base_df_schema[join_key])]
                        for join_key in sample_column_names[:-2]
                    }
                    sample_dtypes[sample_column_names[-2]] = PYSPARK_PANDAS_DTYPE_MAP[
                        parse_dtype_str(self.schema_check.base_df_schema[column_name])
                    ]
                    sample_dtypes[sample_column_names[-1]] = PYSPARK_PANDAS_DTYPE_MAP[
                        parse_dtype_str(self.schema_check.compare_df_schema[column_name])
                    ]

                    # If we have Int dtype, we need to convert to float first
                    sample_dtypes_intermediate = {
                        column: ("float" if "Int" in dtype else dtype) for column, dtype in sample_dtypes.items()
                    }

                    sample_mismatches = (
                        pdDataFrame(mismatch_data[f"{column_name}_samples"], columns=sample_column_names)
                        .astype(sample_dtypes_intermediate, errors="ignore")
                        .astype(sample_dtypes, errors="ignore")
                    )
                    mismatch_summary.sample_rows = sample_mismatches
                self.mismatch_col_summaries[column_name] = mismatch_summary
        self.columns_to_report = self.mismatch_col_summaries.keys()

    def _calculate_diff_metrics(self, columns_to_report: Set[str]) -> None:
        """
        Calculates metrics on row diffs as final step in rows diff report

        Returns:
            None

        Attributes:
            _num_missing_in_base (int): Number of rows missing in de-duped base_df
            _num_missing_in_compare (int): Number of rows missing in de-duped compare_df
            _num_cols_always_mismatch (int): Number of columns where all values are
                mismatched between base_df and compare_df
            _num_cols_sometimes_mismatch (int): Number of columns where some, but not all values
                are mismatched between base_df and compare_df
            passed (bool):
                Whether or not the RowsDiffCheck passsed. RowsDiffCheck is defined to be
                passing if all of the following are true

                    1. Both base_df and compare_df have no duplicates
                    2. Both base_df and compare_df do not have any rows missing from each other
                    3. All the columns compared have the exact same values on the inner joined DataFrame
        """
        self._num_missing_in_base = self._num_rows_compare_deduped - self._num_matched_rows
        self._num_missing_in_compare = self._num_rows_base_deduped - self._num_matched_rows

        self._num_cols_always_mismatch = 0
        self._num_cols_sometimes_mismatch = 0

        self.columns_to_report_list = []

        for match_column in columns_to_report:

            num_mismatches = self.mismatch_col_summaries[match_column].num_mismatches
            mismatch_rate = self.mismatch_col_summaries[match_column].mismatch_rate
            if mismatch_rate > self.mismatch_rate_threshold or self.output_correct_columns:
                self.columns_to_report_list.append(match_column)
            if num_mismatches == self._num_matched_rows:
                self._num_cols_always_mismatch += 1
            elif mismatch_rate > self.mismatch_rate_threshold:
                self._num_cols_sometimes_mismatch += 1

        self.passed = all(
            [
                (
                    self._num_dupes_in_base == 0 and
                    self._num_dupes_in_compare == 0) if not self.allow_dupslicate_rows else (
                        self._num_dupes_in_base == self._num_dupes_in_compare
                    ),
                self._num_missing_in_base == 0,
                self._num_missing_in_compare == 0,
                self._num_cols_always_mismatch == 0,
                self._num_cols_sometimes_mismatch == 0,
            ]
        )

    def _create_sample_mismatches_query(self, column_name: str) -> str:
        """
        Creates query to get all sample mismatch values for column_name

        Args:
            column_name (str): Name of column

        Returns:
            str:
                SQL query that selects join-key/s along with base_df and compare_df's
                mismatching values for all rows where base_df and compare_df have mismatching
                values for column_name
        """
        select_exprs = [
            f"CAST({column_name}_sample[{i}] as \
{self.schema_check.base_df_schema[self.join_keys[i]]}) as {self.join_keys[i]}"
            for i in range(len(self.join_keys))
        ]
        n_join_keys = len(self.join_keys)
        select_exprs = select_exprs + [
            f"CAST({column_name}_sample[{n_join_keys}] \
as {self.schema_check.base_df_schema[column_name]}) as `{column_name} ({self._base_name})`",
            f"CAST({column_name}_sample[{n_join_keys+1}] as \
{self.schema_check.compare_df_schema[column_name]}) as `{column_name} ({self._compare_name})`",
        ]
        select_query = f"SELECT {', '.join(select_expr for select_expr in select_exprs)} \
FROM temp WHERE {column_name}_sample IS NOT NULL"
        return select_query

    def get_column_mismatches(self, column_name: str) -> DataFrame:
        """
        Gets Spark DataFrame of all column mismatches for

        Args:
            column_name (str): _description_

        Raises:
            ValueError: When RowsDiffCheck was not run with sample rows
            ValueError: When column_name was not compared

        Returns:
            DataFrame:
                Spark DataFrame with columns for join-key/s, column for column_name
                values in base_df, column for column_name values in compare_df
        """
        if self.n_sample_rows < 1:
            raise ValueError(
                "TableDiff.RowsDiffCheck must be instantiated with n_sample_rows > 0 in order to get column mismatches"
            )
        if column_name not in self._compare_columns:
            raise ValueError("Column {} was not compared in check".format(column_name))

        self._joined_df_with_mismatch_data.createOrReplaceTempView("temp")
        select_query = self._create_sample_mismatches_query(column_name)
        return self.spark.sql(select_query)

    def get_results_df(self) -> DataFrame:
        """
        Returns a spark DataFrame representing the results

        Returns:
            DataFrame: Spark DataFrame of RowsDiffCheck results, with schema:
                base_column_name: string (unique)
                base_table_name: string
                compare_table_name: string
                num_rows_base: int
                num_rows_compare: int
                num_dupes_base: int
                num_dupes_compare: int
                num_rows_base_deduped: int
                num_rows_compare_deduped: int
                num_common_rows: int
                num_rows_missing_base: int
                num_rows_missing_compare: int
                base_column_type: string or NULL if the column is missing in base
                compare_column_type: string or NULL if the column is missing in compare
                mismatch_count: int or NULL if column was not compared (missing, dtype incompatible, etc)
                mismatch_rate: double or NULL if column was not compared
                passed: boolean or NULL if column was not compared
        """
        all_columns_list = sorted(
            (self.schema_check.base_columns.union(self.schema_check.compare_columns)) - set(self.join_keys)
        )
        data = []
        for column in all_columns_list:
            row = {
                "base_column_name": column,
                "base_table_name": self._base_name,
                "compare_table_name": self._compare_name,
                "num_rows_base": self._num_rows_base,
                "num_rows_compare": self._num_rows_compare,
                "num_dupes_base": self._num_dupes_in_base,
                "num_dupes_compare": self._num_dupes_in_compare,
                "num_rows_base_deduped": self._num_rows_base_deduped,
                "num_rows_compare_deduped": self._num_rows_compare_deduped,
                "num_common_rows": self._num_matched_rows,
                "num_rows_missing_base": self._num_missing_in_base,
                "num_rows_missing_compare": self._num_missing_in_compare,
                "base_column_type": self.schema_check.base_df_schema[column]
                if column not in self._columns_missing_in_base
                else None,
                "compare_column_type": self.schema_check.compare_df_schema[column]
                if column not in self._columns_missing_in_compare
                else None,
                "mismatch_count": self.mismatch_col_summaries[column].num_mismatches
                if column in self.mismatch_col_summaries
                else None,
                "mismatch_rate": self.mismatch_col_summaries[column].mismatch_rate
                if column in self.mismatch_col_summaries
                else None,
                "passed": self.mismatch_col_summaries[column].mismatch_rate <= self.mismatch_rate_threshold
                if column in self.mismatch_col_summaries
                else None,
            }
            data.append(row)

        results_df_schema = StructType(
            [
                StructField("base_column_name", StringType(), False),
                StructField("base_table_name", StringType(), False),
                StructField("compare_table_name", StringType(), False),
                StructField("num_rows_base", IntegerType(), False),
                StructField("num_rows_compare", IntegerType(), False),
                StructField("num_dupes_base", IntegerType(), False),
                StructField("num_dupes_compare", IntegerType(), False),
                StructField("num_rows_base_deduped", IntegerType(), False),
                StructField("num_rows_compare_deduped", IntegerType(), True),
                StructField("num_common_rows", IntegerType(), False),
                StructField("num_rows_missing_base", IntegerType(), False),
                StructField("num_rows_missing_compare", IntegerType(), False),
                StructField("base_column_type", StringType(), True),
                StructField("compare_column_type", StringType(), True),
                StructField("mismatch_count", IntegerType(), True),
                StructField("mismatch_rate", DoubleType(), True),
                StructField("passed", BooleanType(), True),
            ]
        )
        results_df = self.spark.createDataFrame(data, results_df_schema)
        return results_df
