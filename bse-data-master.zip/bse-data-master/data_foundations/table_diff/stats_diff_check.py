import re
from typing import Dict, List, Optional, Union

import pandas as pd
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import approx_count_distinct, col

from .diff_check import DiffCheck
from .schema_diff_check import SchemaDiffCheck
from .utils import (
    COMPARABLE_SPARK_TYPES,
    COMPLEX_SPARK_TYPES,
    DATETIME_SPARK_TYPES,
    NUMERIC_SPARK_TYPES,
    STRING_SPARK_TYPES,
    parse_dtype_str,
)

MAX_UNIQUE_CATEGORIES_IN_OUTPUT = 10


class StatsDiffCheck(DiffCheck):
    def __init__(
        self,
        spark: SparkSession,
        base_df: DataFrame,
        compare_df: DataFrame,
        base_name: Optional[str] = "base_df",
        compare_name: Optional[str] = "compare_df",
        groupby_keys: Union[str, List[str]] = [],
        stats_check_columns: Optional[Union[str, List[str]]] = None,
        use_dbutils_report: Optional[bool] = False,
        cache_intermediates: Optional[bool] = False,
        schema_check: Optional[SchemaDiffCheck] = None,
    ) -> None:
        """
        Initializes the StatsDiffCheck object.

        TODO: Handle use_dbutils_report

        Args:
            spark (SparkSession): Spark session to use
            base_df (DataFrame): The base dataframe to calculate summarizing stats on
            compare_df (DataFrame): The comapre dataframe to calculate summarizing stats on
            base_name (str, optional):
                A string representing the name of the base DataFrame. Defaults to "base_df".
            compare_name (Optional[str], optional):
                A string representing the name of the compare DataFrame. Defaults to "compare_df".
            groupby_keys (Union[str, List[str]], optional): Columns to aggregate the stats by. Defaults to [].
            stats_check_columns (Optional[Union[str, List[str]]], optional):
                Columns to calculate summarizing stats on. If None, then all comparable columns
                will be used. Defaults to None.
            use_dbutils_report (Optional[bool], optional): Whether or not to use dbutils.summarize()
                output instead of Table-diff StatsDiffCheck output. Defaults to False.
            cache_intermediates (Optional[bool], optional): hether or not to cache intermediate DataFrames.
                Defaults to False
            schema_check (Optional[SchemaCheck], optional):
                The SchemaCheck instance to use to identify what columns can be compared row-by-row between base_df and
                compare_df. If None, then a new SchemaCheck will be created and run to identify what columns we can
                compare. Defaults to None"""
        if type(groupby_keys) == str:
            self.groupby_keys = [groupby_keys]
        else:
            self.groupby_keys = groupby_keys

        if type(stats_check_columns) == str:
            self.stats_check_columns = set([stats_check_columns])
        elif stats_check_columns is not None:
            self.stats_check_columns = set(stats_check_columns)
        else:
            self.stats_check_columns = stats_check_columns

        self.use_dbutils_report = use_dbutils_report

        if use_dbutils_report is True:
            raise NotImplementedError

        self.cache_intermediates = cache_intermediates
        self.schema_check = schema_check

        self.max_unique_categories_in_output = MAX_UNIQUE_CATEGORIES_IN_OUTPUT

        super().__init__(spark, base_df, compare_df, base_name=base_name, compare_name=compare_name)

    @property
    def templates(self):
        return {"txt": "stats_diff_report.txt", "md": "stats_diff_report_md.txt"}

    def run(self) -> None:
        """
        Runs the stats diff check and materializes the results as class attributes.

        Attributes:
            stats_columns_tables (Dict[str, pd.DataFrame]):
                Dictionary mapping column names to pandas DataFrames showing the summarizing
                stats for base_df and compare_df on that column
            _columns_to_report (List[str]):
                Columns that the summary stats are calculated on, where numeric columns (in alphabetical) are first,
                then datetime columns (in alphabetical order), then categorical columns (in alphebatical order)
            _base_df_pd_stats_results (pd.DataFrame):
                Pandas DataFrame containing summary stats for all columns in base_df that the StatsDiffCheck calculates
                sats on
            _compare_df_pd_stats_results (pd.DataFrame):
                Pandas DataFrame containing summary stats for all columns in compare_df that the StatsDiffCheck
                calculates stats on

        """

        self._classify_target_columns()

        self._find_valid_categorical_columns()

        self._populate_category_unique_values()

        self._columns_to_report = (
            sorted(list(self._numeric_stats_columns))
            + sorted(list(self._datetime_stats_columns))
            + sorted(list(self._valid_categorical_stats_columns))
        )

        self._base_df_pd_stats_results = self._get_stats_results(self._base_df)
        self._compare_df_pd_stats_results = self._get_stats_results(self._compare_df)

        self.stats_column_tables = {}
        for column_name in self._columns_to_report:
            self.stats_column_tables[column_name] = self._get_column_stats_table(column_name)

    def __str__(self) -> str:
        return str(
            {
                "check_name": "stats_diff",
                "groupby_keys": self.groupby_keys,
                "stats_check_columns": self.stats_check_columns,
                "use_dbutils_report": self.use_dbutils_report,
                "cache_intermediates": self.cache_intermediates,
            }
        )

    def _classify_target_columns(self) -> None:
        """
        Identifies which columns we can calculate stats on and what type (numeric/datetime/categorical)
        and adds to materialized class attributes accordingly
        Returns:
            None

        Attributes:
            _compare_columns (Set[str]):
                Columns that are common to both base_df and compare_df that we are able calculate numeric
                or categorical summary stats on. Also the union of _numeric_stats_columns and _categorical_stats_columns
            _numeric_stats_columns (Set[str]):
                Columns from _compare_columns that we calculate numerical summary stats on, i.e. mean, min, etc
            _datetime_stats_columns (Set[str]):
                Columns from _compare_columns that we calculate datetime/timestamp summary stats on, i.e. min, max
            _categorical_stats_columns (Set[str]):
                Columns from _compare_columns that we calculate categorical/discrete summary stats on, i.e. proportion
                of each unique category
            _cannot_compare_dtype_columns (Set[str]):
                Columns with complex datatypes (i.e. ArrayType, StructType) that we cannot compare, which
                we ignore in our check
            _cannot_compare_columns (Set[str]):
                Columns that fail schema check either by being missing in base_df or compare_df, or
                having uncomparable datatypes, which we ignore in our check
            _columns_missing_in_base (Set[str]):
                Columns that cannot be compared because they are missing in base_df
            _columns_missing_in_compare (Set[str]):
                Columns that cannot be compared because they are missing in compare_df
            _columns_dtype_mismatch (Set[str)]):
                Columns that cannot be compared because their data types are different
                between base_df and compare_df and these types are not comparable
            _num_cols_missing_in_base (int):
                Length of _columns_missing_in_base
            _num_cols_missing_in_compare (int):
                Length of _columns_missing_in_compare
            _num_cols_dtype_mismatch (int):
                Length of _columns_dtype_mismatch
            _cannot_compare_dtype_columns (List[str]):
                Columns that cannot be compared because their data types are complex and not supported, i.e array
            _num_cols_cannot_compare_dtype (int):
                Length of _cannot_compare_dtype_columns

        Raises:
            ValueError: If a column's datatype is not recognized as comparable or a known uncomparable complex type

        """

        # Run schema check to find which columns we can compare or use the already ran schema check passed in
        if self.schema_check is None:
            self.schema_check = SchemaDiffCheck(
                self.spark,
                self._base_df,
                self._compare_df,
                base_name=self._base_name,
                compare_name=self._compare_name,
            )
            self.schema_check.run()

        if self.stats_check_columns is not None:
            possible_compare_columns = self.stats_check_columns - set(self.groupby_keys)
            self._columns_missing_in_base = self.schema_check.missing_in_base.intersection(self.stats_check_columns)
            self._columns_missing_in_compare = self.schema_check.missing_in_compare.intersection(
                self.stats_check_columns
            )
            self._columns_dtype_mismatch = self.schema_check.dtype_mismatch_columns.intersection(
                self.stats_check_columns
            )

        else:
            possible_compare_columns = self.schema_check.correct_columns.union(
                self.schema_check.dtype_comparable_columns
            ) - set(self.groupby_keys)
            self._columns_missing_in_base = self.schema_check.missing_in_base
            self._columns_missing_in_compare = self.schema_check.missing_in_compare
            self._columns_dtype_mismatch = self.schema_check.dtype_mismatch_columns

            for column in possible_compare_columns:
                # Check if columns user passed in all exist and are and raise error if any do not
                if column not in self.schema_check.base_df_schema:
                    raise ValueError(f"Column `{column}` not in schema")
                # Check if columns user passed in are comparable
                if (
                    column not in self.schema_check.correct_columns
                    and column not in self.schema_check.dtype_comparable_columns
                ):
                    raise ValueError(f"Column `{column}` fails schema check and is not comparable")

        compare_columns = set([])
        numeric_stats_columns = set([])
        datetime_stats_columns = set([])
        categorical_stats_columns = set([])
        cannot_compare_dtype_columns = set([])

        # Check if columns are complex dtypes we cannot compare i.e. struct, map
        for column in possible_compare_columns:
            column_dtype = parse_dtype_str(self.schema_check.base_df_schema[column])
            if column_dtype in COMPARABLE_SPARK_TYPES:
                compare_columns.add(column)
                if column_dtype in NUMERIC_SPARK_TYPES:
                    numeric_stats_columns.add(column)
                elif column_dtype in DATETIME_SPARK_TYPES:
                    datetime_stats_columns.add(column)
                else:
                    categorical_stats_columns.add(column)
            elif column_dtype in COMPLEX_SPARK_TYPES:
                cannot_compare_dtype_columns.add(column)
            else:
                raise ValueError(
                    f"Datatype {column_dtype} in column `{column}` is not recognized as a comparable or noncomparable \
(complex) datatype"
                )

        self._compare_columns = compare_columns
        self._numeric_stats_columns = numeric_stats_columns
        self._datetime_stats_columns = datetime_stats_columns
        self._categorical_stats_columns = categorical_stats_columns
        self._cannot_compare_dtype_columns = cannot_compare_dtype_columns
        self._cannot_compare_columns = self.schema_check.incorrect_columns - self.schema_check.dtype_comparable_columns

        self._num_cols_missing_in_base = len(self._columns_missing_in_base)
        self._num_cols_missing_in_compare = len(self._columns_missing_in_compare)
        self._num_cols_dtype_mismatch = len(self._columns_dtype_mismatch)
        self._num_cols_cannot_compare_dtype = len(self._cannot_compare_dtype_columns)

    def _find_valid_categorical_columns(self):
        """
        Identifies which categorical columns have too many distinct values to report,
        and materializes these as class attributes accordingly. Uses base_df as reference for
        the number of distinct values

        Args:
            None

        Returns:
            None

        Attributes:
            _valid_categorical_stats_columns (Set[str]): Columns from _categorical_stats_columns that do not
                have too many unique values to use in report (based on MAX_UNIQUE_CATEGORIES_IN_OUTPUT)
            _invalid_categorical_stats_columns (Set[str]): Columns from _categorical_stats_columns that
                have too many unique values to use in report (based on MAX_UNIQUE_CATEGORIES_IN_OUTPUT)
        """
        valid_categorical_stats_columns = set([])
        invalid_categorical_stats_columns = set([])
        if len(self._categorical_stats_columns) > 0:
            unique_counts_agg = [
                approx_count_distinct(col(column_name)).alias(f"n_unique_{column_name}")
                for column_name in self._categorical_stats_columns
            ]
            num_unique_counts = self._base_df.agg(*unique_counts_agg).collect()[0]

            for column_name in self._categorical_stats_columns:
                if num_unique_counts[f"n_unique_{column_name}"] <= self.max_unique_categories_in_output:
                    valid_categorical_stats_columns.add(column_name)
                else:
                    invalid_categorical_stats_columns.add(column_name)

            self._valid_categorical_stats_columns = valid_categorical_stats_columns
            self._invalid_categorical_stats_columns = invalid_categorical_stats_columns
        else:
            self._valid_categorical_stats_columns = set([])
            self._invalid_categorical_stats_columns = set([])

    def _populate_category_unique_values(self):
        """
        Identifies the unique values for each categorical column that we do report on from
        _valid_categorical_stats_columns and materalizes these as a dictionary. Uses base_df as
        reference for the unique values

        Args:
            None

        Returns:
            None

        Attributes:
            _category_unique_values (Dict[str, List[str]]): Dictionary mapping column names of categorical columns
                to the list of unique values for the column. Since we only look at categorical columns from
                _valid_categorical_stats_columns, the length of these lists will be <= MAX_UNIQUE_CATEGORIES_IN_OUTPUT
            _invalid_categorical_stats_columns_special_chars (Set[str]): Categorical columns that we cannot use in query
                due to special characters that are currently not supported
            _num_invalid_categorical_stats_columns:
                Length of _invalid_categorical_stats_columns. Number of categorica columns we cannot create stats
                on because they have too many distinct values
            _num_invalid_categorical_stats_columns_special_chars
                Length of _invalid_categorical_stats_columns_special_chars

        """

        self._category_unique_values = {}
        new_valid_categorical_stats_columns = set([])
        self._invalid_categorical_stats_columns_special_chars = set([])
        for column_name in self._valid_categorical_stats_columns:
            # Select unique values
            uniq_values = self._base_df.select(col(column_name)).distinct().rdd.flatMap(lambda x: x).collect()

            # Sort (should not be computational burden since we know 10 or less unique values already)
            self._category_unique_values[column_name] = sorted([item for item in uniq_values if item is not None])

            # Check for special characters in string value category columns
            if self.schema_check.base_df_schema[column_name] in STRING_SPARK_TYPES:
                if any(re.search(r"[\n\t\r']", string) for string in self._category_unique_values[column_name]):
                    self._invalid_categorical_stats_columns_special_chars.add(column_name)
                else:
                    new_valid_categorical_stats_columns.add(column_name)
            else:
                new_valid_categorical_stats_columns.add(column_name)
        self._valid_categorical_stats_columns = new_valid_categorical_stats_columns
        self._num_invalid_categorical_stats_columns = len(self._invalid_categorical_stats_columns)
        self._num_invalid_categorical_stats_columns_special_chars = len(
            self._invalid_categorical_stats_columns_special_chars
        )

    def _generate_select_expression(self, column_name: str) -> str:
        """
        Generates arguments for SELECT statement based on column type for calculating summary stats.

        Args:
            column_name (str): Name of the column to calculate stats on.

        Returns:
            str: SQL quantities representing summary stats for the specified column.
        """
        if column_name in self._numeric_stats_columns:
            # For numeric columns, we calculate stats of mean, sum, min, max, and null rate
            select_cols_str = ", ".join(
                [
                    f"AVG({column_name}) as {column_name}_mean",
                    f"SUM({column_name}) as {column_name}_sum",
                    f"MIN({column_name}) as {column_name}_min",
                    f"MAX({column_name}) as {column_name}_max",
                    f"100 * (COUNT(CASE WHEN {column_name} IS NULL THEN 1 END) / COUNT(*)) as \
{column_name}_missing_rate",
                ]
            )
        elif column_name in self._datetime_stats_columns:
            # For datetime columns, we calculate stats of min, max, and null rate
            select_cols_str = ", ".join(
                [
                    f"MIN({column_name}) as {column_name}_min",
                    f"MAX({column_name}) as {column_name}_max",
                    f"100 * (COUNT(CASE WHEN {column_name} IS NULL THEN 1 END) / COUNT(*)) as \
{column_name}_missing_rate",
                ]
            )
        elif column_name in self._valid_categorical_stats_columns:
            # For categorical columns, we calculate frequencies/proportions of each unique category
            unique_values = self._category_unique_values[column_name]
            select_cols_str = ", ".join(
                [
                    f"SUM(CASE WHEN {column_name}='{value}' THEN 1 ELSE 0 END) as `c_{column_name}_{value}`"
                    for value in unique_values
                ]
                + [f"SUM(CASE WHEN {column_name} IS NULL THEN 1 ELSE 0 END) as `c_{column_name}_null`"]
            )
        else:
            raise ValueError(f"Column `{column_name}` not identified as numeric, datetime, or categorical")

        return select_cols_str

    def _generate_full_select_statement(self, df_name: str) -> str:
        """
        Generates full SELECT statement that is used as query to calculate summary stats for all numeric and categorical
        columns.

        Args:
            df_name (str): Name of table that the columns can be selected from

        Returns:
            str: SQL statement that selects all numeric summary stats and categorical summary stats
        """
        full_select_statements = ", ".join(
            self.groupby_keys
            + ["COUNT(*) as count"]
            + [self._generate_select_expression(numeric_col) for numeric_col in self._numeric_stats_columns]
            + [self._generate_select_expression(datetime_col) for datetime_col in self._datetime_stats_columns]
            + [self._generate_select_expression(cat_col) for cat_col in self._valid_categorical_stats_columns]
        )
        query = f"SELECT {full_select_statements} FROM {df_name}"
        if len(self.groupby_keys) > 0:
            query += f" GROUP BY {', '.join(self.groupby_keys)}"
        return query

    def _get_stats_results(self, df: DataFrame) -> pd.DataFrame:
        """
        Runs query that calculates all summary stats for df, then collects and
        returns as pd.DataFrame

        Args:
            df (DataFrame): spark DataFrame to run query stats on, i.e. base_df)
            df_name (str): Name of spark DataFrame used in temp view of DataFrame in query
                i.e. "base_df"

        Returns:
            pd.DataFrame:
                pd.DataFrame of calculated stats for all the columns that we do stats diff
                on.
        """
        df.createOrReplaceTempView("temp")
        stats_query = self._generate_full_select_statement("temp")
        df_stats_results = self.spark.sql(stats_query).collect()
        df_pd_stats_results = pd.DataFrame.from_records(df_stats_results, columns=list(df_stats_results[0].asDict()))
        return df_pd_stats_results

    def _get_select_cols(self, column_name: str) -> List[str]:
        """
        Gets expressions for columns to select  for an individual column's summary stats columns
        from the pd.DataFrame that is collected from full query (from _get_stats_results() )

        Args:
            column_name (str): Name of column

        Raises:
            ValueError: When encountering column that is not previously filtered as
            numeric, datetime, or categorical

        Returns:
            List[str]: List of strings representing column names to select from the pd.DataFrame
            for the summary stats of column_name
        """
        if column_name in self._numeric_stats_columns:
            return (
                self.groupby_keys
                + ["count"]
                + [f"{column_name}_{suffix}" for suffix in ["mean", "sum", "min", "max", "missing_rate"]]
            )
        elif column_name in self._datetime_stats_columns:
            return (
                self.groupby_keys + ["count"] + [f"{column_name}_{suffix}" for suffix in ["min", "max", "missing_rate"]]
            )
        elif column_name in self._valid_categorical_stats_columns:
            uniq_classes = self._category_unique_values[column_name] + ["null"]
            return self.groupby_keys + ["count"] + [f"c_{column_name}_{value}" for value in uniq_classes]
        else:
            raise ValueError(f"Column `{column_name}` not identified as numeric, datetime, or categorical")

    def _get_rename_mapper(self, column_name: str) -> Dict[str, str]:
        """
        Returns dictionary that maps column names from the full pd.DataFrame of stats
        to the column names for the individual pd.DataFrame for each summarized
        columns' individual stats reports, i.e. {"colA_mean" : "mean"}, or
        {"colA_category1" : "category1"}

        Args:
            column_name (str): Name of column to create rename mapper for

        Raises:
            ValueError: When encountering column that is not previously filtered as
            numeric, datetime, or categorical

        Returns:
            Dict[str, str]: Dictionary that maps names of calculated columns from column_name
            from full query to the names for these columsn used in
            in column_name's pd.DataFrame in report
        """
        if column_name in self._numeric_stats_columns:
            return {f"{column_name}_{suffix}": suffix for suffix in ["mean", "sum", "min", "max", "missing_rate"]}
        elif column_name in self._datetime_stats_columns:
            return {f"{column_name}_{suffix}": suffix for suffix in ["min", "max", "missing_rate"]}
        elif column_name in self._valid_categorical_stats_columns:
            uniq_classes = self._category_unique_values[column_name] + ["null"]
            return {f"c_{column_name}_{value}": value for value in uniq_classes}
        else:
            raise ValueError(f"Column `{column_name}` not identified as numeric, datetime, or categorical")

    def _postprocess_stats_pd_df(self, column_name: str, df_combined: pd.DataFrame) -> pd.DataFrame:
        """
        Applies misc. postprocessing to the pd.DataFrame for a particular column to format for report

        Args:
            column_name (str): Name of column
            df_combined (pd.DataFrame):
                pd.DataFrame of combined summary stats for column_name from base_df and compare_df

        Returns:
            pd.DataFrame: df_combined after applied misc. postprocessing
        """
        if column_name in self._numeric_stats_columns or column_name in self._datetime_stats_columns:
            # Include percent symbol in missing rate, and use "<0.01%" or ">99.99%" for clarity on extreme values
            df_combined["missing_rate"] = df_combined["missing_rate"].apply(
                lambda x: "<0.01%" if 0 < x < 0.01 else (">99.99%" if 99.99 < x < 100 else str(round(x, 2)) + "%")
            )
        else:
            uniq_classes = self._category_unique_values[column_name] + ["null"]
            # Include proportions of categories as well as counts in same "cell" in dataframe, and use
            # "<0.01%" or ">99.99%" for clarity on extreme values
            for uniq_class in uniq_classes:

                # Temp columns for proportion and string representation for proportions
                df_combined[f"{uniq_class}_p"] = df_combined[uniq_class] * 100 / df_combined["count"]
                df_combined[f"{uniq_class}_p_str"] = df_combined[f"{uniq_class}_p"].apply(
                    lambda x: "<0.01%" if 0 < x < 0.01 else (">99.99%" if 99.99 < x < 100 else str(round(x, 2)) + "%")
                )
                # Create column that has both count and proportion, i.e "1 (20.00%)"
                df_combined[uniq_class] = (
                    df_combined[uniq_class].astype(str) + " (" + df_combined[f"{uniq_class}_p_str"] + ")"
                )
                # Drop temp columns
                df_combined = df_combined.drop([f"{uniq_class}_p", f"{uniq_class}_p_str"], axis=1)

        return df_combined

    def _get_column_stats_table(self, column_name: str) -> pd.DataFrame:
        """
        Uses the full queries for all calculated stats that are materialized as pd.DataFrame
        in self._base_df_pd_stats and self._compare_df_pd_stats, and creates a pd.DataFrame
        for the summarizing stats for column_name

        Args:
            column_name (str): Name of column to create stats summary pd.DataFrame on

        Returns:
            pd.DataFrame: pd.DataFrame that contains stats for column_name for both
                base_df and compare_df
        """

        # Identify columns to select from the full query's results
        select_cols = self._get_select_cols(column_name)
        # Define how to rename these for the pd.DataFrame we will use in report
        rename_mapper = self._get_rename_mapper(column_name)

        # Select these columns
        df_base = self._base_df_pd_stats_results[select_cols].copy()
        df_compare = self._compare_df_pd_stats_results[select_cols].copy()

        # Create the column in report showing which table, i.e base or compare
        df_base.loc[:, "Table"] = self._base_name
        df_compare.loc[:, "Table"] = self._compare_name

        # Combine, reorder columns, sort the rows, rename columns
        df_combined = pd.concat([df_base, df_compare], ignore_index=True)
        table_col = df_combined.pop("Table")
        df_combined.insert(len(self.groupby_keys), "Table", table_col)
        df_combined = df_combined.sort_values(by=self.groupby_keys + ["Table"])
        df_combined = df_combined.rename(columns=rename_mapper)
        df_combined = df_combined.reset_index(drop=True)

        # Apply misc post processing
        df_combined = self._postprocess_stats_pd_df(column_name, df_combined)
        return df_combined

    def get_results_df(self) -> DataFrame:
        return super().get_results_df()
