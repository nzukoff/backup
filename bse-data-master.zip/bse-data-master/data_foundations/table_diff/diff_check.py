from abc import ABC, abstractmethod
from typing import Dict, Optional, Union

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.connect.dataframe import DataFrame as sparkConnectDataFrame

from .utils import get_jinja_env, get_pd_dataframe_as_md


class DiffCheck(ABC):
    def __init__(
        self,
        spark: SparkSession,
        base_table: Union[DataFrame, str],
        compare_table: Union[DataFrame, str],
        base_name: Optional[str] = "base_df",
        compare_name: Optional[str] = "compare_df",
    ):
        """
        Initialize the DiffCheck object.
        Materializes base_df and compare_df or base_table and compare_table depending
        on if constructed from DataFrames or strings

        Args:
            spark (SparkSession): Spark session to use
            base_table (Union[DataFrame, str]): The base DataFrame or table name for comparison.
            compare_df (Union[DataFrame, str]): The  DataFrame or table name to compare against base_table.
            base_df_name (Optional[str], optional):
                A string representing the name of the base DataFrame. Defaults to "base_df".
            compare_df_name (Optional[str], optional):
                A string representing the name of the compare DataFrame. Defaults to "compare_df".

        Attributes:
            _base_df (DataFrame): The base DataFrame for comparison.
            _compare_df (DataFrame): The DataFrame to compare against the base DataFrame.
            _base_table (str): The base table for comparison.
            _compare_table (str): The table to compare against the base table
            _base_df_name (str): The name of the base DataFrame used in report
            _compare_df_name (str): The name of the compare DataFrame used in report
            _base_table_name (str): The name used to refer to base_table in report
            _compare_table_name (str): The name used to refer to compare_table in report
            already_run (bool): Flag indicating whether the comparison has already been performed.
        """

        if isinstance(base_table, DataFrame) or isinstance(base_table, sparkConnectDataFrame):
            self._base_df = base_table
        else:
            self._base_table = base_table

        if isinstance(compare_table, DataFrame) or isinstance(compare_table, sparkConnectDataFrame):
            self._compare_df = compare_table
        else:
            self._compare_table = compare_table

        self.spark = spark

        self._base_name = base_name
        self._compare_name = compare_name
        self.already_run = False

        self.get_pd_dataframe_as_md = get_pd_dataframe_as_md

    @abstractmethod
    def run(self) -> None:
        raise NotImplementedError

    @property
    @abstractmethod
    def templates(self) -> Dict[str, str]:
        raise NotImplementedError

    @abstractmethod
    def get_results_df(self) -> DataFrame:
        raise NotImplementedError

    def get_report(
        self,
        format: Optional[str] = "txt",
    ) -> str:
        # If format is "df", return Spark DataFrame instead of rendering Jinja tempalte
        if format == "df":
            return self.get_results_df()
        else:
            env = get_jinja_env(self.__class__.__name__)
            template_name = self.templates[format]
            template = env.get_template(template_name)
            return template.render(**self.__dict__)

    def run_and_report(
        self,
        format: Optional[str] = "txt",
    ) -> str:
        """
        Run the comparison and generate a report.

        Args:
            format (Optional[str], optional):
                The format of the generated report. Supported formats are 'txt' (text)
                and 'md' (Markdown). Defaults to 'txt'.
        Returns:
            str: The generated report as a string

        Example:
            >>> parity_check = ParityCheck(base_df, compare_df)
            >>> parity_check.run_and_report(return_result=True, format='txt')
        """
        if not self.already_run:
            self.run()
            self.already_run = True
        output = self.get_report(format=format)
        return output
