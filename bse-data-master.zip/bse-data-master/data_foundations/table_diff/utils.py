import os
import re
import sys
from io import TextIOWrapper
from typing import Dict, List, Optional, Union

import pandas as pd
from jinja2 import Environment, FileSystemLoader
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import expr
from pyspark.sql.utils import AnalysisException, ParseException

# TODO Verify string type comaptability

NUMERIC_SPARK_TYPES = [
    "tinyint",
    "smallint",
    "int",
    "bigint",
    "float",
    "double",
    "decimal",
]

STRING_SPARK_TYPES = ["string", "varchar", "char"]

DATETIME_SPARK_TYPES = ["date", "timestamp", "timestampntz"]

COMPARABLE_SPARK_TYPES = [
    "tinyint",
    "smallint",
    "int",
    "bigint",
    "float",
    "double",
    "boolean",
    "decimal",
    "string",
    "varchar",
    "char",
    "date",
    "timestamp",
    "timestampntz",
]

COMPLEX_SPARK_TYPES = ["array", "map", "struct"]

PYSPARK_PANDAS_DTYPE_MAP = {
    "string": "string",
    "boolean": "string",
    "char": "string",
    "byte": "Int8",
    "tinyint": "Int8",
    "short": "Int16",
    "smallint": "Int16",
    "int": "Int32",
    "bigint": "Int64",
    "integer": "Int64",
    "long": "Int64",
    "float": "float",
    "double": "double",
    "decimal": "double",
    "timestamp": "datetime64[ns]",
    "timestampntz": "datetime64[ns]",
    "date": "datetime64[ns]",
}


def conform_compare_df(
    compare_df: DataFrame,
    column_mapping: Optional[Dict[str, str]] = None,
    transformations: Optional[Dict[str, str]] = None,
) -> DataFrame:
    """
    Apply column mapping and transformations to the DataFrame.

    Args:
        compare_df (DataFrame): The DataFrame to apply column mapping and transformations to.
        column_mapping (Optional[Dict[str, str]], optional):
            A dictionary containing the column mapping, where the keys represent the
            original column names, and the values represent the new column names.
            Defaults to None.
        transformations (Optional[Dict[str, str]], optional):
            A dictionary containing the column transformations, where the keys represent
            the target column names, and the values represent the SQL expressions
            defining the transformations. Defaults to None.

    Returns:
        DataFrame: The DataFrame with column mapping and transformations applied.
            If both `column_mapping` and `transformations` are None, the original
            DataFrame is returned unchanged.

    Raises:
        ParseException: If there is an error parsing the SQL expression.

    Example:
        >>> column_mapping = {"col1": "col1_newname", "col2_oldname": "col2"}
        >>> transformations = {"id": "CAST(id AS BIGINT)", "col2": "col2 / 100"}
        >>> df = conform_compare_df(compare_df, column_mapping, transformations)
    """
    new_compare_df = compare_df
    if transformations is not None:
        new_compare_df = apply_transformations(new_compare_df, transformations=transformations)
    if column_mapping is not None:
        new_compare_df = apply_column_mapping(new_compare_df, column_mapping=column_mapping)
    return new_compare_df


def apply_column_mapping(compare_df: DataFrame, column_mapping: Optional[Dict[str, str]] = None) -> DataFrame:
    """
    Apply column mapping to the DataFrame.

    Args:
        compare_df (DataFrame): The DataFrame to apply column mapping to.
        column_mapping (Optional[Dict[str, str]], optional):
            A dictionary containing the column mapping, where the keys represent the
            original column names, and the values represent the new column names.
            Defaults to None.

    Returns:
        DataFrame: The DataFrame with column names updated according to the mapping.
            If `column_mapping` is None, the original DataFrame is returned unchanged.

    Example:
        >>> column_mapping = {"col1": "col1_newname", "col2_oldname": "col2"}
        >>> df = apply_column_mapping(compare_df, column_mapping)
    """

    if column_mapping is None:
        return compare_df
    new_compare_df = compare_df
    for old_name, new_name in column_mapping.items():
        new_compare_df = new_compare_df.withColumnRenamed(new_name, old_name)
    return new_compare_df


def apply_transformations(compare_df: DataFrame, transformations: Optional[Dict[str, str]] = None) -> DataFrame:
    """
    Apply column transformations to the DataFrame.

    Args:
        compare_df (DataFrame): The DataFrame to apply transformations to.
        transformations (Optional[Dict[str, str]], optional):
            A dictionary containing the column transformations, where the keys represent
            the target column names, and the values represent the SQL expressions
            defining the transformations. Defaults to None.

    Returns:
        DataFrame: The DataFrame with column transformations applied.
            If `transformations` is None, the original DataFrame is returned unchanged.

    Raises:
        ParseException: If there is an error parsing the SQL expression.

    Example:
        >>> transformations = {"id": "CAST(id AS BIGINT)", "col2": "col2 / 100"}
        >>> df = apply_transformations(compare_df, transformations)
    """
    if transformations is None:
        return compare_df
    new_compare_df = compare_df
    for col, transformation_sql in transformations.items():
        try:
            new_col = expr(transformation_sql)
        except ParseException as e:
            print(f"Failed to Parse SQL expression:\n\n{transformation_sql}")
            raise e
        new_compare_df = new_compare_df.withColumn(col, new_col)
    return new_compare_df


def parse_dtype_str(dtype_str: str) -> Optional[str]:
    """
    Parses Spark SQL's datatype string into actual datatype

    Args:
        dtype_str (str): Full datatype string, i.e. array<bigint>

    Returns:
        Optional[str]: Datatype, i.e. bigint, datetime, array
    """
    possible_dtypes = COMPARABLE_SPARK_TYPES + COMPLEX_SPARK_TYPES
    for dtype in possible_dtypes:
        if dtype_str.startswith(dtype):
            return dtype
    return None


def compatible_dtypes(base_dtype: str, compare_dtype: str) -> bool:
    """
    Check if two Spark data types are compatible for comparison.

    This static method checks if the given `base_dtype` and `compare_dtype` are
    compatible for comparison. Compatibility is determined based on predefined
    sets of numeric, string, and datetime Spark data types.

    Args:
        base_dtype (str): The data type of the base DataFrame column.
        compare_dtype (str): The data type of the compare DataFrame column.

    Returns:
        bool: True if the data types are compatible, False otherwise.

    Example:
        >>> compatible_dtypes('bigint', 'double')
        True
        >>> compatible_dtypes('string', 'float')
        False
    """
    base_dtype_parsed = parse_dtype_str(base_dtype)
    compare_dtype_parsed = parse_dtype_str(compare_dtype)
    for dtype_set in [NUMERIC_SPARK_TYPES, STRING_SPARK_TYPES, DATETIME_SPARK_TYPES]:
        if base_dtype_parsed in dtype_set and compare_dtype_parsed in dtype_set:
            return True
    return False


def create_full_diff_report(
    reports: Union[str, List[str]],
    format: str,
    return_result: Optional[bool] = False,
    file_handler: Optional[TextIOWrapper] = sys.stdout,
) -> Optional[Union[str, DataFrame, List[DataFrame]]]:
    """
    Helper function that takes in one or multiple already run diff reports as strings
    and combines these and outputs to stdout or files returns accordingly
    Args:
        reports (Union[str, List[str], DataFrame, List[DataFrame]]): Generated report(s)
        return_result (Optional[bool], optional):
            A flag indicating whether to return the comparison result as a string. Defaults to False.
            If format is "df", then the results will be returned regardless.
        file_handler (Optional[io.TextIOWrapper]):
            File to output report to. Defaults to sys.stout
    Returns:
        Optional[Union[str, DataFrame, List[DataFrame]]]:
            The full report from the passed in reports as a string if return_result
            is True, otherwise None. If format is "df", then returns a spark DataFrame \
            or list of spark DataFrames
    """

    if format == "df":
        return reports
    else:
        if type(reports) == str:
            reports = [reports]
        output = "\n\n\n".join(report for report in reports)
        if return_result:
            return output
        else:
            print(output, file=file_handler)


def table_exists(spark, table_name: str) -> bool:
    """
    Checks if table exists

    Args:
        spark (SparkSession): Spark session to use
        table_name (str): Name of SQL table

    Returns:
        bool: Whether or not the table exists
    """

    # we run dummy query to see if table exists
    try:
        spark.sql(f"SELECT 1 FROM {table_name}")
        table_exists = True
    except AnalysisException:
        table_exists = False

    return table_exists


def is_delta_table(spark: SparkSession, table_name: str) -> bool:
    """
    Checks if existing table is delta table or not

    Args:
        spark (SparkSession): Spark session to use
        table_name (str): Name of SQL table

    Returns:
        bool: Whether or not table_name is a delta table
    """
    is_delta_table = False
    try:
        query = f"DESCRIBE DETAIL {table_name}"
        df_res = spark.sql(query)
        table_type = df_res.collect()[0]["format"]
        if table_type == "delta":
            is_delta_table = True
    except Exception:
        is_delta_table = False
    return is_delta_table


def get_table_type(spark: SparkSession, table_name: str) -> str:
    """
    Get type of table for table_name. Should be "VIEW" or "delta", and if other values
    then DeltaTableDiffCheck will raise error with information on the unsupported table format

    Args:
        spark (SparkSession): Spark session to use
        table_name (str): Name of SQL table

    Returns:
        str: Type or format of table, i.e. 'VIEW', 'delta', etc.
    """
    query = f"DESCRIBE TABLE EXTENDED {table_name}"
    df_res = spark.sql(query)
    table_type_res = df_res.filter(df_res.col_name == "Type").select("data_type").collect()
    if len(table_type_res) > 0:
        table_type = table_type_res[0]["data_type"]
    else:
        table_type = "N/A"

    # If not a view, check if delta table
    if table_type != "VIEW" and len(table_type_res) > 0:
        query = f"DESCRIBE DETAIL {table_name}"
        format_res = spark.sql(query).collect()
        if len(format_res) > 0:
            table_type = format_res[0]["format"]
        else:
            table_type = "N/A"
    return table_type


def get_jinja_env(templates_folder: str):
    """
    Returns Jinja environment for templates_folder

    Args:
        templates_folder (str): Relative path for folder for a specific check's templates

    Returns:
        jinja2.Environment: Jinja Environment for templates in templates_folder
    """
    root_dir = os.path.dirname(os.path.realpath(__file__))
    template_env = Environment(loader=FileSystemLoader(os.path.join(root_dir, f"./templates/{templates_folder}")))
    return template_env


def get_pd_dataframe_as_md(df: pd.DataFrame) -> str:
    """
    Creates Markdown string of pandas DataFrame

    Args:
        df (pd.DataFrame): pandas DataFrame

    Returns:
        str: Markdown table representation of df
    """
    dtypes = df.dtypes.copy()
    for col in df.columns:
        # Cast to string
        df[col] = df[col].astype(str)

        # If was already string, do regex to remove special characters like \n
        if pd.api.types.is_string_dtype(dtypes[col]):
            df[col] = df[col].apply(lambda x: re.sub(r"[\n\t\r]", "", x))

    # Set headers to type string, needed for case when column name is boolean like False
    header_columns = df.columns.astype(str)
    md_table = "| " + " | ".join(header_columns) + " |\n"
    md_table += "| " + " | ".join(["---"] * len(header_columns)) + " |\n"

    for _, row in df.iterrows():
        md_table += "| " + " | ".join(row) + " |\n"
    return md_table
