from typing import Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import BooleanType, StringType, StructField, StructType

from .diff_check import DiffCheck
from .utils import compatible_dtypes


class SchemaDiffCheck(DiffCheck):
    def __init__(
        self,
        spark: SparkSession,
        base_df: DataFrame,
        compare_df: DataFrame,
        base_name: Optional[str] = "base_df",
        compare_name: Optional[str] = "compare_df",
        allow_comparable_mismatches: Optional[bool] = False,
    ) -> None:
        """
        Initialize the SchemaCheck object.

        Args:
            spark (SparkSession): Spark session to use
            base_df (DataFrame): The base DataFrame for schema comparison.
            compare_df (DataFrame): The DataFrame to compare against the base DataFrame schema.
            base_name (str, optional):
                A string representing the name of the base DataFrame. Defaults to "base_df".
            compare_name (Optional[str], optional):
                A string representing the name of the compare DataFrame. Defaults to "compare_df".
            allow_comparable_mismatches (Optional[bool], optional):
                Whether or not to mark columns with differing but comparable dtypes as incorrect. Defaults to False.

        Example:
            >>> base_df = spark.createDataFrame([(1, 'A'), (2, 'B')], ['id', 'name'])
            >>> compare_df = spark.createDataFrame([(1, 'X'), (2, 'Y')], ['id', 'name'])
            >>> schema_check = SchemaCheck(base_df, compare_df)
        """
        self.allow_comparable_mismatches = allow_comparable_mismatches
        super().__init__(spark, base_df, compare_df, base_name=base_name, compare_name=compare_name)

    @property
    def templates(self):
        return {"txt": "schema_diff_report.txt", "md": "schema_diff_report_md.txt"}

    def run(self) -> None:
        """
        Run the Schema Diff Check and materialize results as class attributes.

        This method compares the schemas of the base DataFrame and compare DataFrame and
        calculates various attributes related to the schema diff check. The results are
        materialized as class attributes.

        Returns:
            None

        Attributes:
            base_df_schema (Dict[str, str]): A dictionary mapping column names to their
                corresponding data types in the base DataFrame.
            compare_df_schema (Dict[str, str]): A dictionary mapping column names to their
                corresponding data types in the compare DataFrame.
            missing_in_base (Set[str]): A set of column names that are present in the compare
                DataFrame but missing in the base DataFrame.
            missing_in_compare (Set[str]): A set of column names that are present in the base
                DataFrame but missing in the compare DataFrame.
            incorrect_columns (Set[str]): A set of column names that have inconsistencies
                between the base DataFrame and the compare DataFrame (missing or data type
                mismatch).
            common_columns (Set[str]): A set of column names that are common between the base
                DataFrame and the compare DataFrame.
            correct_columns (Set[str]): A set of column names that have matching data types
                in the base DataFrame and the compare DataFrame.
            dtype_mismatch_columns (Set[str]): A set of column names that have mismatched
                data types between the base DataFrame and the compare DataFrame.
            dtype_comparable_columns (Set[str]): A set of column names that have mismatched
                data types between the base DataFrame and the compare DataFrame, but the data
                types can be compared for compatibility.
            passed (bool): A flag indicating whether the schema diff check passed. It is
                True if there are no incorrect columns, and False otherwise.
        """

        self.base_df_schema = dict(self._base_df.dtypes)
        self.compare_df_schema = dict(self._compare_df.dtypes)
        # Schema are dict with keys of column names and values of dtype for column

        self.base_columns = set(self.base_df_schema.keys())
        self.compare_columns = set(self.compare_df_schema.keys())

        self.missing_in_base = self.compare_columns - self.base_columns
        self.missing_in_compare = self.base_columns - self.compare_columns
        # Create incorrect column list
        self.incorrect_columns = self.missing_in_base.union(self.missing_in_compare)

        # Create common column list
        self.common_columns = self.base_columns.intersection(self.compare_columns)

        # For common columns, check if dtype mismatch and add to appropriate list accordingly
        self.correct_columns = set()
        self.dtype_mismatch_columns = set()
        self.dtype_comparable_columns = set()
        for common_col in self.common_columns:
            base_dtype = self.base_df_schema[common_col]
            compare_dtype = self.compare_df_schema[common_col]
            if base_dtype == compare_dtype:
                self.correct_columns.add(common_col)
            else:
                if compatible_dtypes(base_dtype, compare_dtype):
                    if not self.allow_comparable_mismatches:
                        self.incorrect_columns.add(common_col)
                        self.dtype_comparable_columns.add(common_col)
                else:
                    self.incorrect_columns.add(common_col)
                    self.dtype_mismatch_columns.add(common_col)

        self.passed = True if len(self.incorrect_columns) == 0 else False

    def get_results_df(self) -> DataFrame:
        """
        Returns a spark DataFrame representing the results

        Returns:
            DataFrame: Spark DataFrame of SchemaDiffCheck results, with schema:
                        base_dataset_name: string
                        base_column_name: string or NULL if the column is missing in base
                        base_column_type: string or NULL if the column is missing in base
                        compare_dataset_name: string
                        compare_column_name: string or NULL if the column is missing in compare
                        compare_column_type: string or NULL if the column is missing in compare
                        passed: boolean
                        fail_reason: string or NULL if passed is True
        """
        all_columns_list = sorted(self.base_columns.union(self.compare_columns))
        data = []
        for column in all_columns_list:
            row = {}
            row["base_table_name"] = self._base_name
            row["base_column_name"] = column if column not in self.missing_in_base else None
            row["base_column_dtype"] = self.base_df_schema[column] if column not in self.missing_in_base else None
            row["compare_table_name"] = self._compare_name
            row["compare_column_name"] = column if column not in self.missing_in_compare else None
            row["compare_column_dtype"] = (
                self.compare_df_schema[column] if column not in self.missing_in_compare else None
            )
            row["passed"] = True if column in self.correct_columns else False
            if column not in self.correct_columns:
                if column in self.missing_in_base:
                    fail_reason_str = "MissingBaseColumn"
                elif column in self.missing_in_compare:
                    fail_reason_str = "MissingCompareColumn"
                elif column in self.dtype_mismatch_columns:
                    fail_reason_str = "MismatchedDataType"
                elif column in self.dtype_comparable_columns:
                    fail_reason_str = "MismatchedDataTypeCompatible"
            else:
                fail_reason_str = None
            row["fail_reason"] = fail_reason_str
            data.append(row)

        results_df_schema = StructType(
            [
                StructField("base_table_name", StringType(), False),
                StructField("base_column_name", StringType(), True),
                StructField("base_column_dtype", StringType(), True),
                StructField("compare_table_name", StringType(), False),
                StructField("compare_column_name", StringType(), True),
                StructField("compare_column_dtype", StringType(), True),
                StructField("passed", BooleanType(), False),
                StructField("fail_reason", StringType(), True),
            ]
        )
        results_df = self.spark.createDataFrame(data, results_df_schema)
        return results_df

    def __str__(self) -> str:
        return str({"check_name": "schema_diff", "allow_comparable_mismatches": self.allow_comparable_mismatches})
