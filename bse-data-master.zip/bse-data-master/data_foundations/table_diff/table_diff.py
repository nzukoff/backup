import sys
from io import TextIOWrapper
from typing import Dict, List, Optional, Union

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.connect.dataframe import DataFrame as sparkConnectDataFrame

from .delta_table_diff_check import DeltaTableDiffCheck
from .rows_diff_check import RowsDiffCheck
from .schema_diff_check import SchemaDiffCheck
from .stats_diff_check import StatsDiffCheck
from .utils import conform_compare_df, create_full_diff_report, table_exists


class TableDiff:
    def __init__(
        self,
        base_table: Union[DataFrame, str],
        compare_table: Union[DataFrame, str],
        base_name: Optional[str] = None,
        compare_name: Optional[str] = None,
        column_mapping: Optional[Dict[str, str]] = None,
        transformations: Optional[Dict[str, str]] = None,
        spark_session: Optional[SparkSession] = None,
    ) -> None:
        """
        Initialize the TableDiff object.

        This method initializes the TableDiff object with the provided base DataFrame (`base_df`),
        compare DataFrame (`compare_df`), base DataFrame name (`base_name`), compare DataFrame name
        (`compare_name`), column mapping (`column_mapping`), and transformations (`transformations`).

        The `column_mapping` parameter allows for renaming columns in the compare DataFrame to match the
        base DataFrame column names. The `transformations` parameter allows for applying custom
        transformations to the compare DataFrame before performing the diff.

        Additionally, this method applies the column renaming and transformations to the compare DataFrame
        by calling the `conform_compare_df` function.

        Args:
            base_table (Union[DataFrame, str]): The base DataFrame or SQL table name for comparison.
            compare_table (Union[DataFrame. str]): The compare DataFrame or SQL table name for comparison.
            base_name (Optional[str], optional):
                The name of the base DataFrame or table to be used in diff report outputs. If None, then
                "base_df" will be used if base_table is a DataFrame and base_table will
                be used if base_table is string. Defaults to None.
            compare__name (Optional[str], optional):
                The name of the compare DataFrame or table in diff report outputs. If None, then
                "compare_df" will be used if base_table is a DataFrame and compare_table will
                be used if compare_table is string. Defaults to None.
            column_mapping (Optional[Dict[str, str]], optional):
                A dictionary mapping column names in the base DataFrame to column names in the compare DataFrame.
                Defaults to None.
            transformations (Optional[Dict[str, str]], optional):
                A dictionary specifying custom transformations to be applied to the compare DataFrame.
                The keys are column names, and the values are the transformation SQL expressions.
                Defaults to None.
            spark_session (Optional[SparkSession], optional):
                Spark session to use. If None, then TableDiff will use SparkSession.Builder.getOrCreate
                to retrieve the current session or create a new one. Defaults to None.

        Returns:
            None
        """

        # Materialize passed in Spark session or check for existing one
        if spark_session is not None:
            self.spark = spark_session
        else:
            try:
                self.spark = SparkSession.builder.getOrCreate()
            except Exception as e:
                print("No spark session specified and failed to create Spark session:")
                raise e

        if type(base_table) != type(compare_table):
            raise ValueError("base_table and compare_table must both be DataFrames or both be table names (str)")

        self.base_df, self.base_table, self.base_name = self.process_table_argument(base_table, base_name, "base_df")
        self.compare_df, self.compare_table, self.compare_name = self.process_table_argument(
            compare_table, compare_name, "compare_df"
        )

        self.column_mapping = column_mapping
        self.transformations = transformations

        # Apply column renaming and transformations
        self.compare_df = conform_compare_df(
            self.compare_df, column_mapping=self.column_mapping, transformations=self.transformations
        )

    def process_table_argument(self, table: Union[DataFrame, str], table_name: Union[str, None], default_name: str):
        """
        Processes table argument and handles differently if DataFrame or string (table_name).

        Args:
            table (Union[DataFrame, str]): DataFrame or name of SQL table
            table_name (Union[str, None]): Name to refer to table
            default_name (str): Name to default on when table_name is None if table is DataFrame,
                otherwise table becomes table_name

        Returns:
            df (DataFrame):
                Spark DataFrame created from table if table is string, otherwise existing DataFrame
            table: Union[str, None]:
                Existing SQL table name if table is string, otherwise None
            name: str:
                Name to refer to table in report
        """
        if isinstance(table, str):
            # If string, we create dataframe and name used in report
            # defaults to the table name

            # If table does not exist, raise error
            if not table_exists(self.spark, table):
                raise ValueError("Table {} does not exist".format(table_name))

            df = self.spark.table(table)
            table = table
            name = table if table_name is None else table_name
        elif isinstance(table, DataFrame) or isinstance(table, sparkConnectDataFrame):
            # If already DataFrame, then we use existing DataFrame and name
            # used in report defaults to default_name
            df = table
            table = None
            name = default_name if table_name is None else table_name
        else:
            raise ValueError("Unknown type for table, must be DataFrame or str")
        return df, table, name

    def schema_diff_report(
        self,
        allow_comparable_mismatches: Optional[bool] = False,
        return_result: Optional[bool] = False,
        format: Optional[str] = "txt",
        file_handler: Optional[TextIOWrapper] = sys.stdout,
    ) -> Optional[str]:
        """
        Generate a schema difference (parity check) report.

        Args:
            allow_comparable_mismatches (Optional[bool], optional):
                Flag indicating whether to allow comparable mismatches in the report.
                Defaults to False.
            return_result (Optional[bool], optional):
                Flag indicating whether to return the report as a string.
                Defaults to False.
            format (Optional[str], optional):
                The format of the generated report. Supported formats are 'txt' (text) and 'md' (Markdown).
                Defaults to "txt".
            file_handler (Optional[io.TextIOWrapper]):
                File to output report to. Defaults to sys.stdout

        Returns:
            Optional[Union[str, DataFrame]]: The generated report as a string if `return_result` is True,
            None otherwise. If `format` is "df", then a DataFrame is returned.

        Example:
            >>> table_diff = TableDiff(base_df, compare_df)
            >>> table_diff.schema_diff_report()
                See README.md for example report
        """
        if hasattr(self, "schema_check") is False or str(self.schema_check) != str(
            SchemaDiffCheck(
                self.spark,
                self.base_df,
                self.compare_df,
                base_name=self.base_name,
                compare_name=self.compare_name,
                allow_comparable_mismatches=allow_comparable_mismatches,
            )
        ):
            """
            If we have not already done schema check or
            we are trying to do one with different parameters, create new SchemaCheck
            """
            self.schema_check = SchemaDiffCheck(
                self.spark,
                self.base_df,
                self.compare_df,
                base_name=self.base_name,
                compare_name=self.compare_name,
                allow_comparable_mismatches=allow_comparable_mismatches,
            )
        schema_diff_report_output = self.schema_check.run_and_report(format=format)
        return create_full_diff_report(
            schema_diff_report_output, format, return_result=return_result, file_handler=file_handler
        )

    def rows_diff_report(
        self,
        join_keys: Union[str, List[str]],
        tolerance: Optional[float] = 0,
        use_relative_tolerance: Optional[bool] = True,
        mismatch_rate_threshold: Optional[float] = 0.0,
        allow_dupslicate_rows: Optional[bool] = False,
        rows_check_columns: Optional[Union[List[str], str]] = None,
        n_sample_rows: Optional[int] = 5,
        output_correct_columns: Optional[bool] = False,
        cache_intermediates: Optional[bool] = False,
        output_schema_diff_report: Optional[bool] = True,
        return_result: Optional[bool] = False,
        format: Optional[str] = "txt",
        file_handler: Optional[TextIOWrapper] = sys.stdout,
    ) -> Optional[str]:
        """
        Generate a rowwise diff (parity check) report

        Args:
            join_keys (str or list): Column/s to join base_df and compare_df on
            tolerance (Optional[float], optional):
                The tolerance for numeric comparisons. Defaults to 0.0
            use_relative_tolerance (Optional[bool], optional):
                Whether to use relative tolerance instead of absolute tolerance. Defaults to True
            mismatch_rate_threshold (Optional[float], optional):
                Minimum mismatch rate for a column to be considered incorrect. Defaults to 0.0
            rows_check_columns (Optional[List[str]], optional):
                Columns to include in report. If None then RowsDiffCheck will
                identify and compare all comparable columns.
            n_sample_rows (Optional[int], optional):
                The number of rows to output for each column that is mismatched in the report. Defaults to 5
            output_correct_columns: Optional[bool], optional):
                Whether or not to include columns where all rows were equal in base_df and compare_df in
                the text report. Defaults to False
            cache_intermediates (Optional[bool], optional):
                Whether or not to cache intermediate DataFrames (deduped base/compare and joined df). Defaults to False
            output_schema_diff_report (Optional[bool], optional):
                Whether or not to also include the SchemaDiffReport in the report. Defauls to True.
            return_result (Optional[bool], optional):
                Flag indicating whether to return the report as a string.
                Defaults to False.
            format (Optional[str], optional):
                The format of the generated report. Supported formats are 'txt' (text) and 'md' (Markdown).
                Defaults to "txt".
            file_handler (Optional[io.TextIOWrapper]):
                File to output report to. Defaults to sys.stdout

        Returns:
            Optional[Union[str, DataFrame, List[DataFrame]]]:
                The generated report as a string if `return_result` is True. None otherwise.
                If `format` is "df", then returns a DataFrame of the RowsDiffCheck results when
                `output_schema_diff_report` is False or otherwise a list containing the DataFrames of the
                SchemaDiffCheck and RowsDiffCheck results when `output_schema_diff_report` is True.

        Example:
            >>> table_diff = TableDiff(base_df, compare_df)
            >>> table_diff.rows_diff_report(id, tolerance=0.04)
                See README.md for example report
        """
        if hasattr(self, "rows_check") is False or str(self.rows_check) != str(
            RowsDiffCheck(
                self.spark,
                join_keys,
                self.base_df,
                self.compare_df,
                base_name=self.base_name,
                compare_name=self.compare_name,
                tolerance=tolerance,
                use_relative_tolerance=use_relative_tolerance,
                mismatch_rate_threshold=mismatch_rate_threshold,
                allow_dupslicate_rows=allow_dupslicate_rows,
                rows_check_columns=rows_check_columns,
                n_sample_rows=n_sample_rows,
                output_correct_columns=output_correct_columns,
                cache_intermediates=cache_intermediates,
            )
        ):
            # If we have not run RowsDiffCheck yet or we want to change the parameters or
            # the columns we want to compare on in only_compare_columns are not already run on,
            # we make a new check and run it
            self.rows_check = RowsDiffCheck(
                self.spark,
                join_keys,
                self.base_df,
                self.compare_df,
                base_name=self.base_name,
                compare_name=self.compare_name,
                tolerance=tolerance,
                use_relative_tolerance=use_relative_tolerance,
                mismatch_rate_threshold=mismatch_rate_threshold,
                allow_dupslicate_rows=allow_dupslicate_rows,
                rows_check_columns=rows_check_columns,
                n_sample_rows=n_sample_rows,
                output_correct_columns=output_correct_columns,
                cache_intermediates=cache_intermediates,
                schema_check=None if hasattr(self, "schema_check") is False else self.schema_check,
            )
        rows_diff_report_output = self.rows_check.run_and_report(format=format)
        if output_schema_diff_report:
            schema_diff_report_output = self.rows_check.schema_check.run_and_report(format=format)
            reports = [schema_diff_report_output, rows_diff_report_output]
        else:
            reports = rows_diff_report_output
        return create_full_diff_report(reports, format, return_result=return_result, file_handler=file_handler)

    def get_column_mismatches(
        self,
        column_name: str,
        join_keys: Optional[Union[str, List[str]]] = None,
        tolerance: Optional[float] = None,
        use_relative_tolerance: Optional[bool] = None,
    ):
        """
        Get Spark DataFrame of all unequal rows compared for column_name.

        Default behavior is to use existing check that is already run.

        If user specifies join_keys, tolerance, or use_relative_tolerance, then a new comparison
        is run with any unspecified parameters (tolerance or use_relative_tolerance)
        inferred from any existing check or set to default value.

        If user does not specify join_keys but no check
        is already run, then this parameter can not be inferred or defaulted and an
        error is raised.


        Args:
            column_name (str): Name of column
            join_keys (Optional[Union[str, List[str]]], optional):
                Column/s to join base_table and compare_table on. If None, then RowsDiffCheck must already
                have been run with rows_diff_report method. Defaults to None
            tolerance (Optional[float], optional):
                The tolerance for numeric comparisons. If None, then will be inferred from
                already created RowsDiffCheck or set to 0.0. Defaults to None
            use_relative_tolerance (Optional[bool], optional):
                Whether to use relative tolerance instead of absolute tolerance. If None, then
                will be inferred from already created RowsDiffCheck or set to True. Defaults to None

        Raises:
            ValueError: When join_keys is None and no existing check has been created


        Returns:
            DataFrame:
                Spark DataFrame containing all mismatch values for column_name, along with the
                corresponding join key/s
        """

        # User specifies no new comparison parameters
        if all(param is None for param in [join_keys, tolerance, use_relative_tolerance]):
            # Check if we can use existing check, otherwise raise error
            if hasattr(self, "rows_check") and self.rows_check.already_run:
                return self.rows_check.get_column_mismatches(column_name)
            else:
                raise ValueError("Must specify join-keys or run TableDiff.rows_diff_report first")

        # User wants new comparison to be run, we must infer parameters

        # If user does not specify join-key but specifies other parameters,
        # and the check is not already run, raise error
        if join_keys is None:
            if hasattr(self, "rows_check"):
                join_keys = self.rows_check.join_keys
            else:
                raise ValueError("Must specify join-keys or run TableDiff.rows_diff_report first")

        # Infer tolerance and use_relative_tolerance if not specified as the values from the already-run
        # check or defaults of 0.0 and True
        tolerance = (
            (self.rows_check.tolerance if hasattr(self, "rows_check") else 0.0) if tolerance is None else tolerance
        )
        use_relative_tolerance = (
            (self.rows_check.use_relative_tolerance if hasattr(self, "rows_check") else True)
            if use_relative_tolerance is None
            else use_relative_tolerance
        )

        rows_check = RowsDiffCheck(
            self.spark,
            join_keys,
            self.base_df,
            self.compare_df,
            base_name=self.base_name,
            compare_name=self.compare_name,
            rows_check_columns=column_name,
            tolerance=tolerance,
            use_relative_tolerance=use_relative_tolerance,
            n_sample_rows=5,
            schema_check=None if hasattr(self, "schema_check") is False else self.schema_check,
        )
        rows_check.run()
        return rows_check.get_column_mismatches(column_name)

    def stats_diff_report(
        self,
        groupby_keys: Union[str, List[str]] = [],
        stats_check_columns: Optional[Union[str, List[str]]] = None,
        use_dbutils_report: Optional[bool] = False,
        cache_intermediates: Optional[bool] = False,
        output_schema_diff_report: Optional[bool] = True,
        return_result: Optional[bool] = False,
        format: Optional[str] = "txt",
        file_handler: Optional[TextIOWrapper] = sys.stdout,
    ) -> Optional[str]:
        """
        Generate a stats diff (parity check) report

        Args:
            groupby_keys (Union[str, List[str]], optional):
                Columns to aggregate the stats by. Defaults to [].
            stats_check_columns (Optional[Union[str, List[str]]], optional):
                Columns to calculate summarizing stats on. If None, then all comparable columns
                will be used. Defaults to None.
            use_dbutils_report (Optional[bool], optional): Whether or not to use dbutils.summarize()
                output instead of Table-diff StatsDiffCheck output. Defaults to False.
            cache_intermediates (Optional[bool], optional):
                Whether or not to cache intermediate DataFrames (deduped base/compare and joined df). Defaults to False
            output_schema_diff_report (Optional[bool], optional):
                Whether or not to also include the SchemaDiffReport in the report. Defauls to True.
            return_result (Optional[bool], optional):
                Flag indicating whether to return the report as a string.
                Defaults to False.
            format (Optional[str], optional):
                The format of the generated report. Supported formats are 'txt' (text) and 'md' (Markdown).
                Defaults to "txt".
            file_handler (Optional[io.TextIOWrapper]):
                File to output report to. Defaults to sys.stdout

        Returns:
            Optional[str]: The generated report as a string if `return_result` is True,
            None otherwise.

        Example:
            >>> table_diff = TableDiff(base_df, compare_df)
            >>> table_diff.stats_diff_report()
                See README.md for example report
        """

        if hasattr(self, "stats_check") is False or str(self.stats_check) != str(
            StatsDiffCheck(
                self.spark,
                self.base_df,
                self.compare_df,
                base_name=self.base_name,
                compare_name=self.compare_name,
                cache_intermediates=cache_intermediates,
            )
        ):

            self.stats_check = StatsDiffCheck(
                self.spark,
                self.base_df,
                self.compare_df,
                base_name=self.base_name,
                compare_name=self.compare_name,
                groupby_keys=groupby_keys,
                stats_check_columns=stats_check_columns,
                use_dbutils_report=use_dbutils_report,
                cache_intermediates=cache_intermediates,
                schema_check=None if hasattr(self, "schema_check") is False else self.schema_check,
            )
        stats_diff_report_output = self.stats_check.run_and_report(format=format)
        if output_schema_diff_report:
            schema_diff_report_output = self.stats_check.schema_check.run_and_report(format=format)
            reports = [schema_diff_report_output, stats_diff_report_output]
        else:
            reports = stats_diff_report_output
        return create_full_diff_report(reports, format, return_result=return_result, file_handler=file_handler)

    def delta_table_diff_report(
        self,
        n_sample_partitions: Optional[int] = 5,
        return_result: Optional[bool] = False,
        format: Optional[str] = "txt",
        file_handler: Optional[TextIOWrapper] = sys.stdout,
    ) -> str:
        """
        Generate a delta table diff (parity check) report.

        Args:
            n_sample_partitions (Optional[int], optional):
                Number of sample partitions (rows) to output in report for missing or common partitions. Defaults to 5.
            return_result (Optional[bool], optional): _description_. Defaults to False.
            format (Optional[str], optional): _description_. Defaults to "txt".
            file_handler (Optional[TextIOWrapper], optional): _description_. Defaults to sys.stdout.

        Returns:
            Optional[str]: The generated report as a string if `return_result` is True,
            None otherwise.

        Example:
            >>> table_diff = TableDiff("base_delta_table", "compare_delta_table")
            >>> table_diff.delta_table_diff_report()
                See README.md for example report
        """
        if self.base_table is None or self.compare_table is None:
            raise ValueError(
                "TableDiff must be instantiated from table names (str) in order to run delta_table_diff_report"
            )

        if hasattr(self, "delta_table_check") is False or str(self.delta_table_check) != str(
            DeltaTableDiffCheck(
                self.spark,
                self.base_table,
                self.compare_table,
                base_name=self.base_name,
                compare_name=self.compare_name,
                column_mapping=self.column_mapping,
                n_sample_partitions=n_sample_partitions,
            )
        ):
            self.delta_table_check = DeltaTableDiffCheck(
                self.spark,
                self.base_table,
                self.compare_table,
                base_name=self.base_name,
                compare_name=self.compare_name,
                column_mapping=self.column_mapping,
                n_sample_partitions=n_sample_partitions,
            )
        delta_table_diff_report = self.delta_table_check.run_and_report(format=format)
        return create_full_diff_report(
            delta_table_diff_report, format, return_result=return_result, file_handler=file_handler
        )
