from typing import Dict, List, Optional

import pandas as pd
from pyspark.sql import DataFrame, SparkSession

from .diff_check import DiffCheck
from .utils import get_table_type


class DeltaTableDiffCheck(DiffCheck):
    def __init__(
        self,
        spark: SparkSession,
        base_table: str,
        compare_table: str,
        base_name: Optional[str] = "base",
        compare_name: Optional[str] = "compare",
        column_mapping: Optional[Dict[str, str]] = None,
        n_sample_partitions: Optional[int] = 5,
    ):
        """
        Initialize the DeltaTableDiffCheck object.

        Args:
            spark (SparkSession): Spark session to use
            base_table (str):
                Name of base delta table as referenced in SQL database
            compare_table (str):
                Name of compare delta table as referenced in SQL database
            base_name (Optional[str], optional):
                Name to use for base delta table in report. Defaults to "base_table".
            compare_name (Optional[str], optional):
                Name to use for compare delta table in report. Defaults to "compare_table".
            column_mapping (Optional[Dict[str, str]], optional):
                A dictionary mapping column names in the base table to column names in the compare DataFrame.
                Defaults to None.
            n_sample_partitions (Optional[int], optional):
                Number of sample partitions (rows) to output in report for missing or common partitions. Defaults to 5.
            output_correct_partitions (Optional[int], optional):
                Whether or not to output sample common partitions even if the check passes. Defaults to False.
        """
        self.base_table = base_table
        self.compare_table = compare_table
        self.column_mapping = column_mapping
        self.n_sample_partitions = n_sample_partitions

        super().__init__(spark, base_table, compare_table, base_name=base_name, compare_name=compare_name)

    @property
    def templates(self):
        return {"txt": "delta_table_diff_report.txt", "md": "delta_table_diff_report_md.txt"}

    def run(self) -> None:
        """
        Runs the Delta Table Diff Check and materializes the results as class attributes. Additional
        class attribtues are materialized during this method through calls to _check_same_partition_columns() and
        _check_same_partition_values()

        Args:
            None

        Returns:
            None

        Attributes:
            same_partition_columns (bool):
                Whether or not base table and compare table are partitioned by same columns. Is False
                if partition columns are unknown becuase base and/or compare are views and not
                delta tables
            _both_delta_tables (bool):
                Whether or not both base table and compare table are delta tables. If False, then
                at least one is a view
            _base_table_partition_columns (List[str]):
                List of columns that base table is partitioned by
            _compare_table_partition_columns (List[str]):
                List of columns that compare table is partitioned by
            _can_check_partition_values (bool):
                Whether or not we can check partition values, is True if _both_delta_tables
                and same_partition_columns are both True
            _base_table_partitions (pd.DataFrame):
                pd.DataFrame of partitions existing in base table, which has columns
                of the partition-by columns in base
            _compare_table_partitions (pd.DataFrame):
                pd.DataFrame of partitions existing in compare table, which has columns
                of the partition-by columns in compare
        """

        # Get partition-by columns for base if base is delta table
        self._base_table_type = get_table_type(self.spark, self._base_table)
        if self._base_table_type == "delta":
            self._base_table_partition_columns = self._get_partition_columns(self.base_table)
        elif self._base_table_type == "VIEW":
            self._base_table_partition_columns = None
        else:
            raise NotImplementedError(
                "Delta Table Diff Check is not implemented for tables of format {}".format(self._base_table_type)
            )

        # Get partition-by columns for compare if compare is delta table
        self._compare_table_type = get_table_type(self.spark, self._compare_table)
        if self._compare_table_type == "delta":
            self._compare_table_partition_columns = self._get_partition_columns(self.compare_table)
        elif self._compare_table_type == "VIEW":
            self._compare_table_partition_columns = None
        else:
            raise NotImplementedError(
                "Delta Table Diff Check is not implemented for tables of format {}".format(self._compare_table_type)
            )

        if self._base_table_type == "delta" and self._compare_table_type == "delta":
            self._check_same_partition_columns()
            self._both_delta_tables = True
        else:
            self.same_partition_columns = False
            self._both_delta_tables = False
            self.passed = False

        # If both delta tables, we can check partition values, otherwise we can
        # only check the partition-by columns
        self._can_check_partition_values = self._both_delta_tables and self.same_partition_columns

        # If same partition columns used and tables are delta tables (not views),
        # now check that both tables have same partitions
        if self._can_check_partition_values and self.same_partition_columns:
            self._base_table_partitions = self._get_partitions(self.base_table, self._base_table_partition_columns)
            self._compare_table_partitions = self._get_partitions(
                self.compare_table, self._base_table_partition_columns
            )
            self._check_same_partition_values()

    def _get_partition_columns(self, table_name: str) -> List[str]:
        """
        Returns list of columns that are used as partition columns in table

        Args:
            table_name (str): Name of delta table

        Returns:
            List[str]: Partition columns for table_name
        """
        metadata_list = list(pd.DataFrame(self.spark.sql(f"DESCRIBE TABLE EXTENDED {table_name}").collect())[0])
        if "# Partition Information" in metadata_list:
            start_idx = metadata_list.index("# Partition Information") + 2
            end_idx = metadata_list.index("# Detailed Table Information") - 1

            partition_cols = metadata_list[start_idx:end_idx]
        else:
            partition_cols = []
        return partition_cols

    def _check_same_partition_columns(self):
        """
        Checks if base and compare tables have are partitioned by same column/s

        Args:
            None

        Returns:
            None

        Attributes:
            same_partition_columns (bool):
                Whether or not base and compare are partitioned by the same columns
            passed (bool):
                Whether or not the check is currently passing (can fail later when we see
                if same columns but different values for the partitions in base and compare)
        """
        base_table_partition_columns_with_col_map = self._base_table_partition_columns.copy()

        # Apply column mapping before checking if the same partition columns are used
        if self.column_mapping is not None:
            for i in range(len(base_table_partition_columns_with_col_map)):
                if base_table_partition_columns_with_col_map[i] in self.column_mapping:
                    base_table_partition_columns_with_col_map[i] = self.column_mapping[
                        base_table_partition_columns_with_col_map[i]
                    ]

        self.same_partition_columns = (
            True if base_table_partition_columns_with_col_map == self._compare_table_partition_columns else False
        )
        self.passed = self.same_partition_columns

    def _get_partitions(self, table_name: str, partition_column_names: List[str]) -> pd.DataFrame:
        """
        Returns pandas DataFrame representing partitions in table

        Args:
            table_name (str): Name of delta table
            partition_column_names (List[str]): Name of partition columns in delta table

        Returns:
            pd.DataFrame: pandas DataFrame of partitions in the delta table, where each row
            represents a partition and the columns are partition columns
        """
        df_partitions = pd.DataFrame(
            self.spark.sql(f"SHOW PARTITIONS {table_name}").collect(), columns=partition_column_names
        ).astype(str)

        return df_partitions

    def _check_same_partition_values(self):
        """
        Check is base and table have same partitions. Materializes results as class attributes

        Args:
            None

        Returns:
            None

        Attributes:
            passed (bool):
                Whether or not the check passed. DeltaTableDiffCheck is passing
                when both tables are partitioned by the same columns and no partitions
                are missing in base or compare
            _num_partitions_missing_in_base (int):
                Number of partitions missing in base table
            _num_partitions_missing_in_compare (int):
                Number of partitions missing in compare table
            _num_partitions_common (int):
                Number of partitions common to both base and compare
            _missing_in_base_samples (pd.DataFrame):
                pd.DataFrame of sample partitions missing in base. Rows are partitions and columns
                are the partition columns. Number of rows is based on n_sample_partitions
            _missing_in_compare_samples (pd.DataFrame):
                pd.DataFrame of sample partitions missing in compare. Rows are partitions and columns
                are the partition columns. Number of rows is based on n_sample_partitions
            _common_partitions_samples (pd.DataFrame):
                pd.DataFrame of sample partitions common to both and compare. Rows are partitions and columns
                are the partition columns. Number of rows is based on n_sample_partitions
            _num_common_partitions_samples (int):
                Number of rows in _common_partitions_samples
            _num_missing_in_base_samples (int):
                Number of rows in _missing_in_base_samples
            _num_missing_in_compare_samples (int):
                Number of rows in _missing_in_compare_samples

        """

        # Apply column mapping
        if self.column_mapping is not None:
            compare_table_partitions_with_col_map = self._compare_table_partitions.rename(
                columns={value: key for key, value in self.column_mapping.items()}
            )
        else:
            compare_table_partitions_with_col_map = self._compare_table_partitions

        # Outer join on partition columns
        join_keys = self._base_table_partition_columns
        joined_df = self._base_table_partitions.merge(
            compare_table_partitions_with_col_map, on=join_keys, how="outer", indicator=True
        )

        missing_in_base = joined_df[joined_df["_merge"] == "right_only"][join_keys]
        missing_in_compare = joined_df[joined_df["_merge"] == "left_only"][join_keys]
        common_partitions = joined_df[joined_df["_merge"] == "both"][join_keys]

        self._num_partitions_missing_in_base = missing_in_base.shape[0]
        self._num_partitions_missing_in_compare = missing_in_compare.shape[0]
        self._num_partitions_common = common_partitions.shape[0]

        self._missing_in_base_samples = missing_in_base.head(self.n_sample_partitions)
        self._missing_in_compare_samples = missing_in_compare.head(self.n_sample_partitions)
        self._common_partitions_samples = common_partitions.head(self.n_sample_partitions)

        self._num_common_partitions_samples = len(self._common_partitions_samples)
        self._num_missing_in_base_samples = len(self._missing_in_base_samples)
        self._num_missing_in_compare_samples = len(self._missing_in_compare_samples)

        # Fail if any partitions missing from base or compare
        if self._num_partitions_missing_in_base > 0 or self._num_partitions_missing_in_compare > 0:
            self.passed = False
        else:
            self.passed = True

    def get_results_df(self) -> DataFrame:
        return super().get_results_df()

    def __str__(self) -> str:
        return str(
            {
                "check_name": "delta_table_diff",
                "column_mapping": self.column_mapping,
                "n_sample_partitions": self.n_sample_partitions,
            }
        )
