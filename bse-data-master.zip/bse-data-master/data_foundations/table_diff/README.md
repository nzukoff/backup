# Table-Diff

Table-Diff is a Python library that efficiently verifies the parity between two tables and provides detailed, human-readable reports on the discrepencies between the tables. It runs on Spark, and supports comparing both Spark DataFrames and tables in SQL context. Users instantiate the interface through the TableDiff class, and can compare tables in various ways through this interface.

- [TableDiff](#table-diff)
    - [DeltaTableDiffCheck](#deltatablediffcheck): Verifies that both tables are partitioned by the same columns and all the partitions are common to both tables *(only can be run on delta tables)*
    - [SchemaDiffCheck](#schemadiffcheck): Verifies the columns exist in both tables and are the same data type
    - [RowsDiffCheck](#rowsdiffcheck): Matches rows of each table by join-key/s and verifies the values of each column are equal across tables
    - [StatsDiffCheck](#statsdiffcheck): Outputs summary stats on numerical, datetime, and categorical columns of each table, with optional aggregations
    - [Supported Report Formats](#supported-report-formats)

## TableDiff

Parity checks are run from the TableDiff class, which is instantiated from two Spark DataFrames or SQL tables (strings). The first table, which should represent the gold-standard table is referred to as "base", while the second table which is being compared against base, is referred to as "compare"

### class TableDiff


### Args

- `base_table` (DataFrame or str): The 'base' DataFrame or SQL table name for comparison

- `compare_table` (DataFrame or str): The 'compare' DataFrame or SQL table name for comparison. Must be same type as *base_table*

- `base_name` (str, optional): Custom name to refer to *base_table* in report outputs. If None, then "base_df" will be used if *base_table* is a DataFrame and *base_table* will be used if *base_table* is string. Defaults to None.

- `compare_name`: (str, optional): Custom name to refer to *compare_table* in report outputs. If None, then "compare_df" will be used if *compare_df* is a DataFrame and *compare_table* will be used if *compare_table* is string. Defaults to None.

- `column_mapping` (Dict[str, str], optional): A dictionary mapping column names in the base table to column names in the compare table, where keys are the column names in base table and values are the corresponding column names in the compare table. Defaults to None.

- `transformations`: (Dict[str, str], optional): A dictionary specifying custom transformations to be applied to the compare table before comparing, where keys are column names and values are SQL expressions representing transformations to apply on the column. Defaults to None.

- `spark_session`: (SparkSession, optional): Spark session to use. If None, then TableDiff will use *SparkSession.Builder.getOrCreate* to retrieve the current session or create a new one. Defaults to None.

### Returns

None

#### Example usage

```python
df1 = spark.createDataFrame(
    [
        Row(id=1, col1="c1", col2=0, col4=0),
        Row(id=2, col1="c2", col2=5, col4=1),
        Row(id=3, col1="c3", col2=10, col4=-2),
    ]
)
df2 = spark.createDataFrame(
    [
        Row(id="1", col1_newname="c1", col2=0, col4=0),
        Row(id="2", col1_newname="c2", col2=5, col4=0),
        Row(id="3", col1_newname="c3", col2=10, col4=0),
    ]
)
table_diff = TableDiff(df1, df2, base_name="old_table", compare_name="new_table", column_mapping={"col1": "col1_newname"}, transformations={"id": "CAST(id AS BIGINT)"})
```

Instantiates TableDiff for df1 and df2, which will have names in reports of "old_table" and "new_table", and defines the known differences between column names *(col1 --> col1_newname)* with optional argument `column_mapping` and the values of column *id* (id <-- CAST(id AS BIGINT)) with optional argument `transformations`

## DeltaTableDiffCheck

Parity check which verifies that both *base* and *compare* are partitioned by the same column, and that both tbales contain the same partition values; can only be run if TableDiff is instantiated from table names (str), and not DataFrames. This parity check is defined in class `DeltaTableDiffCheck`, and is run with method `TableDiff.delta_table_diff_report`.

### TableDiff.delta_table_diff_report

#### Args

- `n_sample_partitions` (int, optional): Number of sample partitions to output in report for missing or common partitions. Defaults to 5.

- `return_result` (bool, optional): Whether or not to return the report as a string. Defaults to False..

- `format` (str, optional). Format for the report. Current supported values are "txt" and "md". Defaults to "txt".

- `file_handler` (TextIOWrapper, optional). File to write to. If sys.stdout, then reports will be printed to sys.stdout. Defaults to sys.stdout.

#### Returns

- (str, optional) The generated report as a string if *return_result* is True, otherwise returns None 

#### Example usage

```
table_diff = TableDiff("hive_metastore.old_table", "main.new_table")
table_diff.delta_table_diff_report()
```

#### Example report

```
***** Delta Table Partitions Diff Check: FAIL *****

Table hive_metastore.old_table is format 'delta'
Table main.new_table is format 'delta'

Partition column(s) for hive_metastore.old_table are `processDate`
Partition column(s) for main.new_table are `processDate`

Partitions in common: 56
processDate
 2023-06-22
 2023-06-18
 2023-06-23
 2023-06-24
 2023-07-18

Partitions missing in hive_metastore.old_table: 1
processDate
 2023-06-01

Partitions missing in main.new_table: 1363
processDate
 2021-01-27
 2021-08-27
 2021-11-13
 2021-12-18
 2022-03-28

Some partitions missing in hive_metastore.old_table and/or main.new_table, Delta Table Diff Check failed
```

## SchemaDiffCheck

Parity check which verifies that all the columns in *base* also exist in *compare*, and vice versa, and that the datatypes of the columns are the same in base and compare. In the report, columns with mismatching datatypes that are incompatible (i.e. string vs double) are differentiated from mismatching datatypes that are compatible (i.e. bigint vs double). This parity check is defined in class `SchemaDiffCheck`, and is run with method `TableDiff.schema_diff_report`

### TableDiff.schema_diff_report

### Args

- `allow_comparable_mismatches` (bool, optional): Flag indicating whether to include datatype mismatches between compatable datatypes in the report and count these towards the check failing. Defaults to False.

- `return_result` (bool, optional): Whether or not to return the report as a string. Defaults to False.

- `format` (str, optional). Format for the report. Current supported values are "txt", "md", and "df". Defaults to "txt".

- `file_handler` (TextIOWrapper, optional). File to write to. If sys.stdout, then reports will be printed to sys.stdout. Defaults to sys.stdout.

### Returns

- (str or DataFrame, optional) The generated report as a string if *return_result* is True, otherwise returns None. If *format* is "df", then returns a Spark DataFrame of the results.

#### Example usage

```python
df1 = spark.createDataFrame(
    [
        Row(id=1, col1="c1", col2=datetime.datetime(2000, 1, 1), col3=1.0),
        Row(id=2, col1="c2", col2=datetime.datetime(2000, 1, 2), col3=2.0),
        Row(id=3, col1="c3", col2=datetime.datetime(2005, 10, 11), col3=-1.0),
    ]
)

df2 = spark.createDataFrame(
    [
        Row(id="1", col1="c1", col2=datetime.date(2000, 1, 1), col4=0),
        Row(id="2", col1="c2", col2=datetime.date(2000, 1, 2), col4=0),
        Row(id="3", col1="c3", col2=datetime.date(2005, 10, 11), col4=0),
    ]
)
table_diff = TableDiff(df1, df2)
table_diff.schema_diff_report()
```

#### Example report

```
***** Schema Diff Check: FAIL *****
             base_df.___ <--> compare_df.col4 (bigint)  x (missing in base_df)
   base_df.col3 (double) <--> compare_df.___            x (missing in compare_df)      
     base_df.id (bigint) <--> compare_df.id (string)    x (dtype mismatch)
base_df.col2 (timestamp) <--> compare_df.col2 (date)    x (dtype mismatch but compatible)
```

## RowsDiffCheck

Parity check which verifies that the values of the rows of *base* and *compare* match. This check requires defining one or more join-keys to join *base* and *compare* on, which is used to compare the columns of the joined rows. This check runs a `SchemaDiffCheck` first if no `SchemaDiffCheck` has already been run in the `TableDiff` instance, which is used to identify columns that are missing in either table or have incomparable datatypes, as these cannot be compared in `RowsDiffCheck`. Similarly, columns with complex datatypes (i.e. array, struct), are not compared in this check. This parity check is defined in class `RowsDiffCheck`, and is run with method `TableDiff.rows_diff_report`. After this check is run, the full series of mismatched values for particular compared column can be retrieved with method `RowsDiffCheck.get_column_mismatches`

### TableDiff.rows_diff_report

#### Args

- `join_keys` (str or List[str]): Column(s) to join *base* and *compare* on

- `tolerance` (float, optional): The tolerance for numeric comparisons. Defaults to 0.0.

- `use_relative_tolerance` (bool, optional): Whether to use relative tolerance (percent difference) instead of absolute tolerance. Defaults to True.

- `mismatch_rate_threshold` (float, optional): The minimum mismatch rate for a column to be considered incorrect, and therefore included in the report. Value must be in range \[0, 100\).Defaults to 0.0.

- `rows_check_columns` (str or List[str], optional): Columns to compare and include in report. If None, then all comparable columns will be used. Defaults to None.

- `n_sample_rows` (int, optional): Number of sample rows of mismatch values to output for each column in the report. Defaults to 5.

- `output_correct_columns` (bool, optional): Whether or not to include columns where all rows were equal (or > *mismatch_rate_threshold*) in the text report. Defaults to False.

- `cache_intermediates` (bool, optional): Whether ot not to cache intermediate DataFrames in the check. Defaults to False.

- `output_schema_diff_report` (bool, optional): Whether or not to also include the report from SchemaDiffCheck in the output. Defaults to True.

- `return_result` (bool, optional): Whether or not to return the report as a string. Defaults to False.

- `format` (str or DataFrame, optional). Format for the report. Current supported values are "txt", "md", and "df". Defaults to "txt".

- `file_handler` (TextIOWrapper, optional). File to write to. If sys.stdout, then reports will be printed to sys.stdout. Defaults to sys.stdout.

#### Returns

- (str, DataFrame, or List[DataFrame], optional) The generated report as a string if *return_result* is True, otherwise returns None. If *format* is "df", then returns a Spark DataFrame of the results when *output_schema_diff_report* is False or a list containing 2 Spark DataFrames, which contain the DataFrames for the SchemaDiffCheck and RowsDiffCheck results respectively.



#### Example usage

```python
df1 = spark.createDataFrame(
    [
        Row(id=1, col1="c1", col2="2021-01-09", col3=2.1, col4="a", col6=1, col7=[2, 2], col8=1, col9=5.0),
        Row(id=1, col1="c1", col2="2021-01-10", col3=2.1, col4="aa", col6=1, col7=[2, 2], col8=1, col9=5.0),
        Row(id=2, col1="c2", col2="2021-01-10", col3=1.1, col4="b", col6=2, col7=[5, 4, 3], col8=1, col9=10.0),
        Row(id=3, col1="c3", col2="2021-01-11", col3=3.1, col4="c", col6=3, col7=[1, 2, 3], col8=1, col9=11.0),
        Row(id=4, col1="c3", col2="2021-01-11", col3=4.1, col4="d", col6=4, col7=[], col8=1, col9=3.0),
    ]
)
df2 = spark.createDataFrame(
    [
        Row(id=1, col1="c1", col2="2020-01-09", col3=2.0, col5=0, col6=1.0, col7=[2, 1], col8="1", col9=5),
        Row(id=2, col1="c2", col2="2020-01-01", col3=1.1, col5=0, col6=2.0, col7=[], col8="1", col9=10),
        Row(id=3, col1="c3", col2="2020-01-11", col3=3.0, col5=0, col6=-3.0, col7=[0], col8="1", col9=11),
        Row(id=5, col1="c4", col2="2020-01-11", col3=4.0, col5=0, col6=4.0, col7=[5, 4, 3], col8="1", col9=12),
    ]
)
table_diff = TableDiff(df1, df2)
table_diff.rows_diff_report("id", n_sample_rows=2, output_schema_diff_report=False)
```

#### Example report
```
***** Rows Diff Check: FAIL *****
Dropping columns `compare_df.col5` because they are missing in base_df
Dropping columns `base_df.col4` because they are missing in compare_df
Dropping columns `base_df.col8`(bigint) <--> `compare_df.col8` (string) because the data types are not compatible
Dropping columns `base_df.col7` (array<bigint>) <--> `compare_df.col7` (array<bigint>) because data types are not supported in row diff report

Matched on: `id`
Number of rows in base_df: 5
Number of rows in compare_df: 4
Number of duplicates removed in base_df: 1
Number of duplicates removed in compare_df: 0
Number of rows in de-duped base_df: 4
Number of rows in de-duped compare_df: 4
Number of rows successfully matched on with key(s) `id`: 3
Number of rows in base_df but not in compare_df: 1
Number of rows in compare_df but not in base_df: 1

Number of columns compared with some rows unequal: 2
Number of columns compared with all rows unequal: 1

Column name                                                            Number of mismatches    Rate of mismatch
col2                                                                                     3             100.00%
col3                                                                                     2              66.67%
col6                                                                                     1              33.33% 


Sample rows with column mismatches:

__________________________________________________________________________________________
** Column: col2                                                     Number of mismatches: 3
 id col2 (base_df) col2 (compare_df)
 1    2021-01-10       2020-01-09   
 2    2021-01-10       2020-01-01   

__________________________________________________________________________________________
** Column: col3                                                     Number of mismatches: 2
 id  col3 (base_df)  col3 (compare_df)
 1        2.1              2.0        
 3        3.1              3.0        

__________________________________________________________________________________________
** Column: col6                                                     Number of mismatches: 1
 id  col6 (base_df)  col6 (compare_df)
 3         3               -3.0       
```

### TableDiff.get_column_mismatches
Gets Spark DataFrame of all column mismatches for a specified column. Default behavior is to use existing RowsDiffCheck that was already created and run with `TableDiff.rows_diff_report`.

If user specifies join_keys, tolerance, or use_relative_tolerance, then a new comparison is run with any unspecified parameters (tolerance or use_relative_tolerance) inferred from the existing check or set to default value. If user does not specify join_keys but no check is already run, then an error is raised, as this parameter can not be inferred nor has a default value.

#### Args

- `column_name` (str): Name of column
- `join_keys` (str or List[str], optional): Column/s to join base table and compare table on. If None, then RowsDiffCheck must already been created and run with `TableDiff.rows_diff_report` method
- `tolerance` (float, optional):  The tolerance for numeric comparisons. If None, then will be inferred from an already created RowsDiffCheck or set to 0.0. Defaults to None
- `use_relative_tolerance` (bool, optional): Whether to use relative tolerance instead of absolute tolerance. If None, then will be inferred from already created RowsDiffCheck or set to True. Defaults to None

#### Returns

- (spark.DataFrame) Spark DataFrame of mismatched values for *column_name* between *base* and *compare*. Columns of this DataFrame are the join-key/s, a column for the values of *column_name* in *base*, and a column for the values of *column_name* in *compare*

#### Example usage

```
df = table_diff.get_column_mismatches("col2")
df.show()
```

```
+---+--------------+-----------------+
| id|col2 (base_df)|col2 (compare_df)|
+---+--------------+-----------------+
|  1|    2021-01-10|       2020-01-09|
|  2|    2021-01-10|       2020-01-01|
|  3|    2021-01-11|       2020-01-11|
+---+--------------+-----------------+
```

## StatsDiffCheck

Parity check which outputs summarizing stats for numerical, datetime, and categorical columns for *base* and *compare*. Stats for numeric columns are count, mean, sum, min, max, and missing rate. Stats for datetime columns are count, min, mix, and missing rate. Stats for categorical columns are proportions of each class as well as proportion of nulls. Can also aggregate these columns by one or more group-by keys, and output the summarizing stats aggregated by the groups. This check runs a `SchemaDiffCheck` first, if no `SchemaDiffCheck` has already been run in the `TableDiff` instance. The `SchemaDiffCheck` identifies columns that are missing in either table or have incomparable datatypes, as these cannot be compared. Similarly, columns with complex datatypes (i.e. array, struct), are not compared in this check. This check also does not calculate summarizing stats on categoricla columns with more than 10 unique classes or if they contain certain special characters (i.e. \n, \t, etc.). This parity check is defined in class `StatsDiffCheck`, and is run with method `TableDiff.stats_diff_report`.

### TableDiff.stats_diff_report

#### Args

- `groupby_keys` (str or List[str], optional): Columns to aggregate the stats by. If [], then the summarizing stats are calculated and reported for each entire table, meaning the entire table is treated as one group. Defaults to [].

- `stats_check_columns` (str or List[str], optional): Columns to calculate summarizing stats on. If None, then all comparable columns will be used. Defaults to None.

- `use_dbutils_report` (bool, optional): Whether or not to use dbutils.data.summarize() output instead of StatsDiffCheck output. Defaults to False. **NOT IMPLEMENTED**

- `cache_intermediates` (bool, optional): Whether ot not to cache intermediate DataFrames in the check. Defaults to False.

- `output_schema_diff_report` (bool, optional): Whether or not to also include the report from SchemaDiffCheck in the output. Defaults to True.

- `return_result` (bool, optional): Whether or not to return the report as a string. Defaults to False.

- `format` (str, optional). Format for the report. Current supported values are "txt" and "md". Defaults to "txt"

- `file_handler` (TextIOWrapper, optional). File to write to. If sys.stdout, then reports will be printed to sys.stdout. Defaults to sys.stdout

#### Returns

- (str, optional) The generated report as a string if *return_result* is True, otherwise returns None 

#### Example usage

```python
df1 = spark.createDataFrame(
    [
        Row(col1=2.0, col2="X", col3=datetime.datetime(2023, 7, 15), group="A"),
        Row(col1=3.0, col2="Y", col3=datetime.datetime(2023, 7, 16), group="B"),
        Row(col1=-1.0, col2="X", col3=None, group="A"),
        Row(col1=None, col2="Y", col3=datetime.datetime(2023, 7, 17), group="B"),
        Row(col1=7.0, col2=None, col3=datetime.datetime(2023, 7, 18), group="A"),
    ]
)
df2 = spark.createDataFrame(
    [
        Row(col1=20.0, col2="X", col3=datetime.datetime(2023, 7, 15), group="A"),
        Row(col1=35.0, col2="Y", col3=datetime.datetime(2023, 7, 16), group="B"),
        Row(col1=-15.0, col2="X", col3=None, group="B"),
        Row(col1=None, col2="Y", col3=datetime.datetime(2023, 7, 17), group="B"),
        Row(col1=79.0, col2=None, col3=datetime.datetime(2023, 7, 18), group="A"),
    ]
)
table_diff = TableDiff(df1, df2)
table_diff.stats_diff_report(groupby_keys="group", output_schema_diff_report=False)
```

#### Example report

```
***** Stats Diff Check *****

Stats for `col1`
group   Table     count    mean    sum   min  max missing_rate
  A      base_df   3     2.666667  8.0  -1.0  7.0      0.0%   
  A   compare_df   2    49.500000 99.0  20.0 79.0      0.0%   
  B      base_df   2     3.000000  3.0   3.0  3.0     50.0%   
  B   compare_df   3    10.000000 20.0 -15.0 35.0    33.33%   

Stats for `col3`
group   Table     count    min        max     missing_rate
  A      base_df   3    2023-07-15 2023-07-18    33.33%   
  A   compare_df   2    2023-07-15 2023-07-18      0.0%   
  B      base_df   2    2023-07-16 2023-07-17      0.0%   
  B   compare_df   3    2023-07-16 2023-07-17    33.33%   

Stats for `col2`
group   Table     count     X          Y         null   
  A      base_df   3    2 (66.67%)   0 (0.0%) 1 (33.33%)
  A   compare_df   2     1 (50.0%)   0 (0.0%)  1 (50.0%)
  B      base_df   2      0 (0.0%) 2 (100.0%)   0 (0.0%)
  B   compare_df   3    1 (33.33%) 2 (66.67%)   0 (0.0%)
```

## Supported Report Formats

Parity check reports can be created in several formats, by specifying parameter `format` when running the check from the TableDiff class. Readable text-like formats that are supported are `"txt"` (plain-text) and `"md"` (Markdown), and structured results can be generated as Spark DataFrames with format `"df"`. We also aim to support a visualization format for reports.

### DataFrame Structured Results
The following parity checks can be generated with format `"df"` and return Spark DataFrames with the following schemas.


#### SchemaDiffCheck
Each row in this table represents a comparison of a column from base to the corresponding column in compare.

| Column | Data type | Nullable | Description |
|--------|-----------|----------|-------------|
base_table_name | string | no | Name of base table |
base_column_name | string | yes | Column of base table, NULL when column is missing in base
base_column_type | string | yes | Data type of base_column_name, NULL when column is missing in base |
compare_table_name | string | no | Name of compare table |
compare_column_name | string | yes | Column of compare table, NULL when column is missing in compare |
compare_column_type | string | yes | Data type of compare_column_name, NULL when column is missing in base |
passed | boolean | no | Whether or not the schema for this column matches in base and compare |
fail_reason | string | yes | Reason why the column is considered incorrect ("MissingBaseColumn", "MissingCompareColumn", "MismatchedDataType", "MismatchedDataTypeCompatible"), NULL when *passed* is True |

### RowsDiffCheck
Each row in this table represents the comparison of the values for a column.

| Column | Data type | Nullable | Description |
|--------|-----------|----------|-------------|
base_column_name | string | no | Name of column in base table
base_table_name | string | no | Name of base table |
compare_table_name | string | no | Name of compare table |
num_rows_base | int | no | Number of rows in base |
num_rows_compare | int | no | Number of rows in compare |
num_dupes_base | int | no | Number of duplicate rows (by join-key/s) in base |
num_dupes_compare | int | no | Number of duplicate rows (by join-key/s) in compare |
num_rows_base_deduped | int | no | Number of rows in base after duplicates removed |
num_rows_compare_deduped | int | no | Number of rows in compare after duplicates removed |
num_common_rows | int | no | Number of rows common to both base and compare (by join-key/s)|
num_rows_missing_base | int | no | Number of rows in compare but not in base (by join-key/s) |
num_rows_missing_compare | int | no | Number of rows in base but not in compare (by join-key/s) |
base_column_type | string | yes | Data type of base_column_name, NULL when column is missing in base |
compare_column_type | string | yes | Data type of the corresponding column in compare, NULL when column is missing in compare |
mismatch_count | int | yes | Number of rows with unequal values in the column, NULL if the column was not compared |
mismatch_rate | double | yes | Percent of rows with unequal values in the column, NULL if the column was not compared |
passed | boolean | yes | Whether or not the column is considered correct (when *mismatch_rate* < `mismatch_rate_threshold (default: 0.0)`), NULL if the column was not compared|
