# Databricks notebook source
# Import necessary libraries
%pip install gspread
%pip install pygsheets

# COMMAND ----------

# DBTITLE 1,Gsheet Functions

import json
import pandas as pd
import gspread
from dataclasses import dataclass
from pyspark.sql import DataFrame
import pygsheets
from tempfile import NamedTemporaryFile

# Define a data class to hold GCP service account information
@dataclass(frozen=True)
class GCPServiceAccount:
    name: str
    secrets_scope: str
    creds_key: str

# Configuration for accessing GCP service account credentials stored in Databricks secrets
env_configs = {
    "dev": GCPServiceAccount(
        name='dev-bse-storage-access-sa',
        secrets_scope='bse-dev-creds',
        creds_key='gcp_dev_bse_creds'
    ),
    "prod": GCPServiceAccount(
        name='dev-bse-storage-access-sa',
        secrets_scope='bse-dev-creds',
        creds_key='gcp_dev_bse_creds'
    )
}

def retrieve_gcp_dev_bse_serv_acc_creds(sa: GCPServiceAccount, dbutils) -> dict:
    """
    Retrieves GCP service account credentials from Databricks secrets.
    
    Parameters:
        - sa: An instance of GCPServiceAccount containing the service account details.
    
    Returns:
        - A dictionary containing the service account credentials.
    """
    return (json.loads(dbutils.secrets.get(scope=sa.secrets_scope, key=sa.creds_key)))

def open_gsheet_by_id(gsheet_id: str, service_account: GCPServiceAccount, dbutils):
    """
    Opens a Google Sheet by its ID using credentials of a specified GCP service account.
    
    Parameters:
        - gsheet_id (str):  The ID of the Google Sheet to be accessed.
        - service_account:  An instance of GCPServiceAccount to use for authentication.
    
    Returns:
        - An instance of gspread.models.Spreadsheet representing the opened Google Sheet.
    """
    gc = gspread.service_account_from_dict(retrieve_gcp_dev_bse_serv_acc_creds(service_account, dbutils))
    return gc.open_by_key(gsheet_id)

def read_google_worksheet_data(gsheet_id: str, worksheet_id: str, dbutils, spark, env: str='dev', data_range : str=None, columnList: list = None) -> DataFrame:
    """
    This function reads data from a specified worksheet within a Google Sheet and returns it as a Spark DataFrame. It utilizes a GCP service account to access the Google Sheet data, so you'll need to ensure that the provided GCP service account has the necessary permissions (view) to the Google Sheet.
        - dev: dev-bse-storage-access-sa@gcp-dev-bse.iam.gserviceaccount.com
        - prod: prd-bse-storage-access-sa@gcp-prod-bse.iam.gserviceaccount.com

    Deficiencies:
        - Considers 1st row as header by default


    Parameters:
        - gsheet_id (str):              This parameter represents the unique identifier for the Google Sheets document. 
                                        You can find this ID    within the Google Sheets URL. It is the part of the URL that immediately follows 'https://docs.google.com/spreadsheets/d/' and precedes 'edit#gid=<worksheet_id>'. For instance, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then 'abc123' is the gsheet_id.

        - worksheet_id (str):           This parameter refers to the specific worksheet within the Google Sheets document from 
                                        which you want to retrieve data. It can be identified from the Google Sheets URL. It comes after 'gid=' in the URL. For example, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then '456' is the worksheet_id.

        - dbutils and spark:            Imported Python modules don't have access to the notebook context (i.e., can't see things like the
                                        global "spark" and "dbutils" objects), so we have to pass dbutils & spark in.

        - env (str):                    The environment to use ('dev' or 'prod'). Determines which service account to use.

        - data_range (str, optional):   A specific range of cells to read from the worksheet.

        - columnList (str, optional):   Please mention the list of columns that you want to extract from the gsheet.
    

    Returns:
        - A Spark DataFrame containing the data read from the worksheet.
    """
    # Select the service account based on the environment
    service_account = env_configs[env]
    gsheet = open_gsheet_by_id(gsheet_id, service_account, dbutils)
    worksheet = gsheet.get_worksheet_by_id(int(worksheet_id))

    if data_range:
        ws_data = worksheet.get_values(data_range)
    else:
        ws_data = worksheet.get_values()
    if not ws_data:
      raise ValueError("The worksheet is empty or does not exist.")

    header = ws_data[0] # Considering 1st row as header
    # Checking if all the columns mentioned in columnList are present
    if columnList is None:
        columnList = []
    missing_columns = [col for col in columnList if col not in header]
    if missing_columns:
        raise ValueError(f"The following columns are missing in the worksheet: {', '.join(missing_columns)}")

    if not columnList:
        columnList = header

    selected_indices = [header.index(col) for col in columnList]
    filtered_data = [[row[i] for i in selected_indices] for row in ws_data[1:]]

    # Use the first row as header and the rest as data
    pd_df = pd.DataFrame(filtered_data, columns=columnList)
    pd_df.fillna("", inplace=True)  # Convert None to empty string

    # Convert column names to lowercase and replace spaces with underscores
    pd_df.columns = [x.lower().replace(" ", "_") for x in pd_df.columns]

    # Create a Spark DataFrame from the pandas DataFrame
    spark_df = spark.createDataFrame(pd_df)
    return spark_df
  
def write_to_google_sheet(gsheet_id: str, worksheet_id: str, pandasDF, dbutils, env: str='dev'):
    """
    This function writes pandas dataframe to a Google Sheet. It utilizes a GCP service account to access the Google Sheet data, so you'll need to ensure that the provided GCP service account has the necessary permissions (edit) to the Google Sheet.
        - dev: dev-bse-storage-access-sa@gcp-dev-bse.iam.gserviceaccount.com
        - prod: prd-bse-storage-access-sa@gcp-prod-bse.iam.gserviceaccount.com

    Parameters:
        - gsheet_id (str):              This parameter represents the unique identifier for the Google Sheets document. 
                                        You can find this ID    within the Google Sheets URL. It is the part of the URL that immediately follows 'https://docs.google.com/spreadsheets/d/' and precedes 'edit#gid=<worksheet_id>'. For instance, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then 'abc123' is the gsheet_id.

        - worksheet_id (str):           This parameter refers to the specific worksheet within the Google Sheets document from 
                                        which you want to retrieve data. It can be identified from the Google Sheets URL. It comes after 'gid=' in the URL. For example, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then '456' is the worksheet_id.

        - pandasDF:                     pandas dataframe containing the data to be written to the worksheet.

        - dbutils:                      Imported Python modules don't have access to the notebook context (i.e., can't see things like the
                                        global "spark" and "dbutils" objects), so we have to pass dbutils & spark in.

        - env (str):                    The environment to use ('dev' or 'prod'). Determines which service account to use.
    """
    # Select the service account based on the environment
    service_account = env_configs[env]

    with NamedTemporaryFile(mode='w+') as f:
      f.write(json.dumps(retrieve_gcp_dev_bse_serv_acc_creds(service_account, dbutils)))
      f.flush()
      auth = pygsheets.authorize(service_file=f.name)

    # Open the spreadsheet and the worksheet
    sh = auth.open_by_key(gsheet_id)
    wks = sh.worksheet('id', worksheet_id)
    wks.set_dataframe(pandasDF, (1, 1), fit=True)
    print('Data upload complete.')

# COMMAND ----------



# COMMAND ----------

# Example usage of the read_google_worksheet_data function

gsheet_id ='1kZnqRQU3wRRj6EeDCDtHj38PgJO4VVsBSOd4WSnJCr4'
worksheet_id1 = '1953597819'


# Define the environment ('dev' or 'prod')
env = 'dev'


# Read data from the Google Sheet
FY26_Overlay_Roster = read_google_worksheet_data(gsheet_id, worksheet_id1, dbutils, spark, env)




# COMMAND ----------

from pyspark.sql.functions import current_date

# Function to add current date column
def add_date_column(df):
    return df.withColumn("current_date", current_date())

# Add current date column to each DataFrame
FY26_Overlay_Roster = add_date_column(FY26_Overlay_Roster)

# COMMAND ----------

# Function to rename columns and save as table
def rename_and_save(df, table_name):
    df = df.toDF(*[c if c else f"col_{i}" for i, c in enumerate(df.columns)])
    df.write.mode("overwrite").option("mergeSchema", "true").saveAsTable(f"main.it_aibi_bronze.{table_name}")

# Save FY26_Roster
rename_and_save(FY26_Overlay_Roster, "FY26_Overlay_Roster")




# COMMAND ----------



# COMMAND ----------

# %sql

# show tables in main.team_gtm_sales_compensation like '*FY26_Overlay_Input*'

# COMMAND ----------

# MAGIC %md
# MAGIC #Bronze & Silver Creation
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import col, current_date, regexp_replace, lit

# Read the source table
FY26_Overlay_Roster = spark.table("main.it_aibi_bronze.FY26_Overlay_Roster")

# Apply transformations
FY26_Overlay_Rosterr = FY26_Overlay_Roster.select(
        "plan_id",
        "group",
        "eid",
        "role",
        "aligment",
        "geo",
        "plan_type",
        "total",
        "legal_name",
        "start_date",
        "salesforce_iD",
        "termination_date",
        "status",
        "strategy_submission",
        "sent_to_xactly",
        "ready_for_upload",
        "published",
        "manager_approved_xactly",
        "fully_accepted",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
FY26_Overlay_Roster.write.mode("overwrite").saveAsTable("main.it_aibi_silver.FY26_Overlay_Roster")

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold Creation

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.FY26_Overlay_Roster AS
# MAGIC SELECT * FROM main.it_aibi_silver.FY26_Overlay_Roster;
