# Databricks notebook source
# MAGIC %md
# MAGIC ##### Create Backup Table 

# COMMAND ----------

# %sql

# CREATE TABLE hive_metastore.bdw.msft_royalty_qtrly_total_db__PROD AS
# SELECT * FROM hive_metastore.bdw.msft_royalty_qtrly_total_db

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM hive_metastore.bdw.msft_royalty_qtrly_total_db__PROD

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM hive_metastore.bdw.msft_royalty_qtrly_total_db__PROD

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Updation of enrollment number

# COMMAND ----------

df_updated = spark.sql('''
                       SELECT DISTINCT rr.EnrollmentNumber NEW_ENROLLMENT_NUMBER, rr.BillingMonth, rr.OfferId, rr.TPID, rr.ResourceGUID, rr.SubscriptionGUID, rr.SKUTitle
                       FROM hive_metastore.bdw.msft_royalty_qtrly_total_db rq INNER JOIN hive_metastore.bdw_dev.royalty_report_cumulative rr 
                       ON (lower(rr.SubscriptionGUID) = lower(rq.SubscriptionGUID) AND
                          lower(rr.OfferId) = lower(rq.OfferId) AND
                          lower(rr.ResourceGUID) = lower(rq.ResourceGUID) AND
                          lower(rr.BillingMonth) = lower(rq.BillingMonthKey) AND
                          COALESCE(lower(rr.TPID), 'NO_VALUE') = COALESCE(lower(rq.TPID), 'NO_VALUE') AND
                          COALESCE(lower(rr.SKUTitle), 'NO_VALUE') = COALESCE(lower(rq.SKUTitle), 'NO_VALUE') AND
                          -- ROUND(COALESCE(DOUBLE(REPLACE(TRIM(rr.TotalUnits), ',', '')), 99999),2) = ROUND(COALESCE(DOUBLE(rq.TotalUnits), 99999),2) AND
                          SUBSTRING(STRING(rr.EnrollmentNumber),0,1) =  SUBSTRING(STRING(rq.EnrollmentNumber),0,1)  
                          )
                        WHERE rq.EnrollmentNumber LIKE '%E+%'
                       ''')
df_updated.createOrReplaceTempView('df_updated')
display(df_updated)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM df_updated

# COMMAND ----------

# MAGIC %sql
# MAGIC select SubscriptionGUID, OfferId, ResourceGUID, BillingMonth, COALESCE(lower(TPID), 'NO_VALUE'), COALESCE(lower(SKUTitle), 'NO_VALUE'),NEW_ENROLLMENT_NUMBER, COUNT(*) from df_updated
# MAGIC GROUP BY 1,2,3,4,5,6,7
# MAGIC HAVING COUNT(*)>1
# MAGIC ORDER BY SubscriptionGUID

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 1. With Total Units
# MAGIC ##### 2. Without Total Units and removing upper(rq.SubscriptionGUID) NOT LIKE 'CC742B8F-7911-4902-85CB-A1C52EEB142D' and upper(rq.SubscriptionGUID) NOT LIKE 'D4FE9BE1-A9E4-4091-AC24-6737A528855D'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC MERGE INTO hive_metastore.bdw.msft_royalty_qtrly_total_db rq
# MAGIC USING df_updated rr
# MAGIC ON lower(rr.SubscriptionGUID) = lower(rq.SubscriptionGUID) AND
# MAGIC   lower(rr.OfferId) = lower(rq.OfferId) AND
# MAGIC   lower(rr.ResourceGUID) = lower(rq.ResourceGUID) AND
# MAGIC   string(rr.BillingMonth) = rq.BillingMonthKey AND
# MAGIC   COALESCE(lower(rr.TPID), 'NO_VALUE') = COALESCE(lower(rq.TPID), 'NO_VALUE') AND
# MAGIC   COALESCE(lower(rr.SKUTitle), 'NO_VALUE') = COALESCE(lower(rq.SKUTitle), 'NO_VALUE') AND
# MAGIC   -- ROUND(COALESCE(DOUBLE(REPLACE(TRIM(rr.TotalUnits), ',', '')), 99999),2) = ROUND(COALESCE(DOUBLE(rq.TotalUnits), 99999),2) AND
# MAGIC   rq.EnrollmentNumber LIKE '%E+%' and upper(rq.SubscriptionGUID) NOT LIKE 'CC742B8F-7911-4902-85CB-A1C52EEB142D' and upper(rq.SubscriptionGUID) NOT LIKE 'D4FE9BE1-A9E4-4091-AC24-6737A528855D'
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     rq.EnrollmentNumber = rr.NEW_ENROLLMENT_NUMBER

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO hive_metastore.bdw.msft_royalty_qtrly_total_db rq
# MAGIC USING df_updated rr
# MAGIC ON lower(rr.SubscriptionGUID) = 'cc742b8f-7911-4902-85cb-a1c52eeb142d' AND
# MAGIC   lower(rr.OfferId) = lower('MS-AZR-0145P') AND
# MAGIC   lower(rr.ResourceGUID) = lower('aad24629-5578-4bfb-b890-62e2779afe8a') AND
# MAGIC   string(rr.BillingMonth) = '20201201' AND
# MAGIC   COALESCE(lower(rr.TPID), 'NO_VALUE') = '63980181' AND
# MAGIC   COALESCE(lower(rr.SKUTitle), 'NO_VALUE') = 'Azure Databricks - Premium - All-purpose Compute' AND
# MAGIC   -- ROUND(COALESCE(DOUBLE(REPLACE(TRIM(rr.TotalUnits), ',', '')), 99999),2) = ROUND(COALESCE(DOUBLE(rq.TotalUnits), 99999),2) AND
# MAGIC   rq.EnrollmentNumber LIKE '2.16E+%'
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET
# MAGIC     rq.EnrollmentNumber = '216334174500001'

# COMMAND ----------

# MAGIC %md
# MAGIC #### Validations

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*)
# MAGIC FROM hive_metastore.temp.msft_royalty_qtrly_total_db_test
# MAGIC WHERE EnrollmentNumber LIKE '%E+%' 

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*)
# MAGIC FROM hive_metastore.bdw.msft_royalty_qtrly_total_db
# MAGIC WHERE EnrollmentNumber LIKE '%E+%' 

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM hive_metastore.bdw.msft_royalty_qtrly_total_db
# MAGIC WHERE EnrollmentNumber LIKE '%E+%' 
# MAGIC ORDER BY SubscriptionGUID

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM hive_metastore.temp.msft_royalty_qtrly_total_db_test

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM hive_metastore.bdw.msft_royalty_qtrly_total_db

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM df_updated 
# MAGIC WHERE upper(SubscriptionGUID) = 'CC742B8F-7911-4902-85CB-A1C52EEB142D' or upper(SubscriptionGUID) = 'D4FE9BE1-A9E4-4091-AC24-6737A528855D'

# COMMAND ----------

# MAGIC %md
# MAGIC ###### msft_royalty_qtrly_total_db_test

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT SubscriptionGUID, EnrollmentNumber, OfferId, BillingMonthKey, ResourceGUID, COALESCE(lower(TPID), 'NO_VALUE'), COALESCE(lower(SKUTitle), 'NO_VALUE'), ROUND(COALESCE(DOUBLE(REPLACE(TRIM(TotalUnits), ',', '')), 99999),2) FROM hive_metastore.temp.msft_royalty_qtrly_total_db_test 
# MAGIC WHERE EnrollmentNumber LIKE '%E+%' and 
# MAGIC (upper(SubscriptionGUID) = 'CC742B8F-7911-4902-85CB-A1C52EEB142D' or upper(SubscriptionGUID) = 'D4FE9BE1-A9E4-4091-AC24-6737A528855D')
# MAGIC ORDER BY SubscriptionGUID,EnrollmentNumber,OfferId, BillingMonthKey, ResourceGUID

# COMMAND ----------

# MAGIC %md
# MAGIC ###### royalty_report_cumulative

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT SubscriptionGUID, EnrollmentNumber, OfferId, BillingMonth, ResourceGUID, COALESCE(lower(TPID), 'NO_VALUE'), COALESCE(lower(SKUTitle), 'NO_VALUE')
# MAGIC -- , ROUND(COALESCE(DOUBLE(REPLACE(TRIM(TotalUnits), ',', '')), 99999),2)
# MAGIC FROM hive_metastore.bdw_dev.royalty_report_cumulative
# MAGIC WHERE (upper(SubscriptionGUID) = 'CC742B8F-7911-4902-85CB-A1C52EEB142D')
# MAGIC -- or upper(SubscriptionGUID) = 'D4FE9BE1-A9E4-4091-AC24-6737A528855D')
# MAGIC ORDER BY SubscriptionGUID, EnrollmentNumber, OfferId, BillingMonth, ResourceGUID

# COMMAND ----------


