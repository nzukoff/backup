# Databricks notebook source
# MAGIC %run ./configs

# COMMAND ----------

def sql(query):
  return spark.sql(query)

# COMMAND ----------

def checkpoint(ID):
  flag = sql(f""" SELECT COUNT(0) 
           FROM {CHECKPOINT_HISTORY_TABLE}
           WHERE table_name = '{ID}' AND run_date = current_date""").collect()[0][0]
  if flag == 0:
    return True
  else:
    return False


# COMMAND ----------

def addCheckPointhistory(ID):
  sql(f"""
      INSERT INTO {CHECKPOINT_HISTORY_TABLE}
      SELECT 'ADDING CHECKPOINT' as event_name,
             '{ID}' as table_name,
             current_date as run_date,
             current_timestamp as updated_at,
             'SUCCESSFULL' as status
      """)
  print(f"Checkpoint History Added for {ID}\n")


# COMMAND ----------

def tableWriter(Configs):
  for ID, parameters in Configs.items():
    if OVERRIDE_CHECKPOINT == True:
      print(f"Overriding today's checkpoint for {ID}\n")
      check = True
    else:
      check = checkpoint(ID)
    if check:
      if 'csv' in parameters['source']:
        print(f"Source is a CSV file: {parameters['source']}\n")
        df = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(parameters['source'])
        print(f"For {ID}, Writing from location {parameters['source']} to {parameters['target']}\n")
        try:
          df.write.format("delta").mode("overwrite").option('overwriteSchema', 'true').saveAsTable(parameters['target'])
        except Exception as e:
          raise RuntimeError(f"Failed to write from location {parameters['source']} to {parameters['target']} due to {e} 😢")
        addCheckPointhistory(ID)
      else:
        df = spark.read.format("delta").load(parameters['source'])
        print(f"For {ID}, Writing from location {parameters['source']} to {parameters['target']}\n")
        try:
          df.write.format("delta").mode("overwrite").option('overwriteSchema', 'true').saveAsTable(parameters['target'])
        except Exception as e:
          raise RuntimeError(f"Failed to write {parameters['source']} to {parameters['target']} due to {e} 😢")
        addCheckPointhistory(ID)
        print('--------------------------------------------------------\n')
    else:
      print(f"Skipping {ID}, Already completed for today!\n")
      print('--------------------------------------------------------\n')
  print("All tables are saved succesfully 😊")

# COMMAND ----------

def main():
  tableWriter(extractLocationMapping)
