# Databricks notebook source
# MAGIC %run ./utils

# COMMAND ----------

OVERRIDE_CHECKPOINT = True if dbutils.widgets.get("override_checkpoint") == "True" else False
print(f"OVERRIDE_CHECKPOINT: {OVERRIDE_CHECKPOINT}")

# COMMAND ----------

main()
