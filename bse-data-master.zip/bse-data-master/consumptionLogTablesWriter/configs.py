# Databricks notebook source
# MAGIC %md
# MAGIC Add new tables if required in below extractLocationMapping

# COMMAND ----------

extractLocationMapping = {

'ORDER_CONSUMPTION_DAILY_LOCATION': {'source': '/mnt/bse-dev/order_consumption_daily','target': 'integration.it_consumption_silver.order_consumption_daily_location'},

'ORDER_CONSUMPTION_DAILY_STAGING_LOCATION': {'source': '/mnt/bse-dev/order_consumption_daily_staging','target': 'integration.it_consumption_silver.order_consumption_daily_staging_location'},

'OVERLAPPING_PARALLEL_CONTRACTS_LOCATION': {'source': '/mnt/bse-dev/process_overlapping_parallel_contracts_04152022.csv','target': 'integration.it_consumption_silver.overlapping_parallel_contracts_location'},

'PARALLEL_CONTRACTS_CLEAN_LOCATION': {'source': '/mnt/bse-dev/parallel_contracts_clean','target': 'integration.it_consumption_silver.parallel_contracts_clean_location'},

#Below location is mentioned in the code, but there does not exist any location, hence commented
#'PVC_USAGE_DAILY_LOCATION': {'source': '/mnt/bse-dev/pvc_usage_daily','target': 'integration.it_consumption_silver.#pvc_usage_daily_location'},

'TRUE_OVERLAPPING_ORDERS_CLEANED_LOCATION': {'source': '/mnt/bse-dev/trueOverlappingOrdersCleanedv7.csv','target': 'integration.it_consumption_silver.true_overlapping_orders_cleaned_location'},

'USAGEC_ACCOUNT_POPMETRICS_LOCATION': {'source': '/mnt/bse-dev/usagec_account_popmetrics','target': 'integration.it_consumption_silver.usagec_account_popmetrics_location'},

'USAGEC_AGGORDER_DAILY_PVC_LOCATION': {'source': '/mnt/bse-dev/pvc_usagec_aggorder_daily_gold','target': 'integration.it_consumption_silver.usagec_aggorder_daily_pvc_location'},

'USAGEC_AGGORDER_MONTHLY_LOCATION': {'source': '/mnt/bse-dev/usagec_aggorder_monthly_gold','target': 'integration.it_consumption_silver.usagec_aggorder_monthly_location'},

'USAGEC_AGG_ORDER_DAILY_ADHOC_LOCATION': {'source': '/mnt/bse-dev/usagec_agg_order_daily_adhoc','target': 'integration.it_consumption_silver.usagec_agg_order_daily_adhoc_location'},

'USAGEC_AGG_ORDER_DAILY_ADHOC_PVC_INTERMEDIATE_LOCATION': {'source': '/mnt/bse-dev/usagec_agg_order_daily_adhoc_pvc_intermediate','target': 'integration.it_consumption_silver.usagec_agg_order_daily_adhoc_pvc_intermediate_location'},

'USAGEC_AGG_ORDER_DAILY_LOCATION': {'source': '/mnt/bse-dev/usagec_aggorder_daily_gold','target': 'integration.it_consumption_silver.usagec_agg_order_daily_location'},

'USAGEC_MAX_DATES_LOCATION': {'source': '/mnt/bse-dev/usagec_maxdates','target': 'integration.it_consumption_silver.usagec_max_dates_location'},

'USAGEC_PROD_DAILY_INTERMEDIATE_LOCATION': {'source': '/mnt/bse-dev/usagec_prod_daily_intermediate','target': 'integration.it_consumption_silver.usagec_prod_daily_intermediate_location'},

'USAGEC_PROD_DAILY_MODIFIED_ADHOC_LOCATION': {'source': '/mnt/bse-dev/usagec_prod_daily_modified_adhoc','target': 'integration.it_consumption_silver.usagec_prod_daily_modified_adhoc_location'},

'USAGEC_PROD_DAILY_PVC_LOCATION': {'source': '/mnt/bse-dev/usagec_prod_daily_pvc','target': 'integration.it_consumption_silver.usagec_prod_daily_pvc_location'},

'USAGE_ACCOUNT_DAILY_GOLD_LOCATION': {'source': '/mnt/bse-dev/usagec_account_daily_gold','target': 'integration.it_consumption_silver.usage_account_daily_gold_location'},

'USAGE_ACCOUNT_MONTHLY_GOLD_LOCATION': {'source': '/mnt/bse-dev/usagec_account_monthly_gold','target': 'integration.it_consumption_silver.usage_account_monthly_gold_location'},

'USAGE_AGGORDER_DAILY_GOLD_ADHOC_LOCATION': {'source': '/mnt/bse-dev/usagec_aggorder_daily_gold_adhoc','target': 'integration.it_consumption_silver.usage_aggorder_daily_gold_adhoc_location'},

'USAGE_AGG_ORDER_DAILY_ADHOC_PVC_BACKUP_LOCATION': {'source': '/mnt/bse-dev/backup_usagec_agg_order_daily_adhoc_pvc','target': 'integration.it_consumption_silver.usage_agg_order_daily_adhoc_pvc_backup_location'},

'USAGE_AGG_ORDER_DAILY_ADHOC_PVC_LOCATION': {'source': '/mnt/bse-dev/usagec_agg_order_daily_adhoc_pvc','target': 'integration.it_consumption_silver.usage_agg_order_daily_adhoc_pvc_location'},

'USAGE_PLATFORM_DAILY_LOCATION': {'source': '/mnt/bse-dev/usagec_platform_daily_gold','target': 'integration.it_consumption_silver.usage_platform_daily_location'},

'USAGE_PLATFORM_MONTHLY_LOCATION': {'source': '/mnt/bse-dev/usagec_platform_monthly_gold','target': 'integration.it_consumption_silver.usage_platform_monthly_location'},

'USAGE_POPMETRICS_LOCATION': {'source': '/mnt/bse-dev/usagec_popmetrics','target': 'integration.it_consumption_silver.usage_popmetrics_location'},

'USAGE_PROD_DAILY_GRANULAR_ADHOC_LOCATION': {'source': '/mnt/bse-dev/usagec_prod_daily_granular_adhoc','target': 'integration.it_consumption_silver.usage_prod_daily_granular_adhoc_location'},

'USAGE_PROD_DAILY_GRANULAR_LOCATION': {'source': '/mnt/bse-dev/usagec_prod_daily_granular','target': 'integration.it_consumption_silver.usage_prod_daily_granular_location'},

'USAGE_PROD_DAILY_LOCATION': {'source': '/mnt/bse-dev/usagec_prod_daily','target': 'integration.it_consumption_silver.usage_prod_daily_location'}

}

# COMMAND ----------

display(extractLocationMapping)

# COMMAND ----------

# MAGIC %md
# MAGIC Checkpoint Configs

# COMMAND ----------

CHECKPOINT_HISTORY_TABLE = 'integration.it_consumption_silver.CLTWCheckpoint'
OVERRIDE_CHECKPOINT = False

print(f'CHECKPOINT_HISTORY_TABLE: {CHECKPOINT_HISTORY_TABLE}')
print(f'OVERRIDE_CHECKPOINT: {OVERRIDE_CHECKPOINT}')
