# BSE Data Lake Pipelines

This repo will hold all BSE Data related notebooks and tools.

Phase 1 design document :
https://docs.google.com/document/d/1nvFs59BlZN8vYqApSX7SI5MlEN8fy9tsoxSaCqOTf6Y/edit

* Depends on FA tables for contracts, usage-pricing info
* Depends on Field Forecast table for DS forecast
* Uses SFDC Snapshot data for AE/CSE forecast and Workspace-Users-Count

