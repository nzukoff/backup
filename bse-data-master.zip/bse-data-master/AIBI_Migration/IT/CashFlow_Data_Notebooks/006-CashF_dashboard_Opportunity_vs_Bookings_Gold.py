# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.cashflow_dashboard_Opportunity_vs_Bookings_gold as
# MAGIC
# MAGIC SELECT 
# MAGIC   Platform,
# MAGIC   Account_ID,
# MAGIC   Account_Name,
# MAGIC   Opportunity_Id,
# MAGIC   Opportunity_Name,
# MAGIC   Fy_Quarter,
# MAGIC   Fiscal_Month,
# MAGIC   Fiscal_Quarter_End_Date,
# MAGIC   Estimated_Close_Date,
# MAGIC   Renewal_Date,
# MAGIC   Close_Or_Renewal_Date,
# MAGIC   Estimated_Close_Or_Renewal_Month,
# MAGIC   Opportunity_Stage,
# MAGIC   Pipeline_Or_Actual,
# MAGIC   Manager_Forecast,
# MAGIC   TCV,
# MAGIC   Final_TCV,
# MAGIC   Term,
# MAGIC   Primary_Quote,
# MAGIC   Billing_Schedule,
# MAGIC   Type,
# MAGIC   Quote_Approval_Stage,
# MAGIC   Min_Invoice_Date,
# MAGIC   Month1_Billing_Amount,
# MAGIC   Qtr1_Billing_Amount,
# MAGIC   Billing_Source,
# MAGIC   Ri_Purchase,
# MAGIC   Incremental_Dollars,
# MAGIC   Renewal_Dollars,
# MAGIC   Booking_Dollars,
# MAGIC   Debook_Flag,
# MAGIC   Bookings_Billed_Upfront,
# MAGIC   Bookings_Billed_Non_Upfront,
# MAGIC   Derived_Frequency,
# MAGIC   process_date,
# MAGIC   Month2_Billing_Amount,
# MAGIC   Business_Unit__c,
# MAGIC   prior_closed_deal,
# MAGIC   prior_closed_deal_ratio,
# MAGIC   Bookings_Billed_Upfront_Month_1,
# MAGIC   Billing_Amount_Within_30_days,
# MAGIC   Bookings_Billed_Upfront_Within_30days,
# MAGIC   Platform_Simplified,
# MAGIC   Renewal_Date_UPD,
# MAGIC   Billing_Frequency,
# MAGIC   Billing_Frequency_Revised,
# MAGIC   close_date_SNAP,
# MAGIC   close_date_FINAL,
# MAGIC   close_month_SNAP,
# MAGIC   close_month_FINAL,
# MAGIC   booking_amount_SNAP,
# MAGIC   booking_amount_FINAL,
# MAGIC   Renewal_Dollars_SNAP,
# MAGIC   Renewal_Dollars_FINAL,
# MAGIC   Incremental_Dollars_SNAP,
# MAGIC   Incremental_Dollars_FINAL,
# MAGIC   CASE 
# MAGIC     WHEN Platform = 'Azure' THEN 'Azure'
# MAGIC     ELSE 'Non Azure'
# MAGIC   END AS Platform_Type,
# MAGIC   COALESCE(prior_closed_deal_ratio, 0) AS Prior_Closed_Deal_Ratio_second,
# MAGIC   CASE Platform_Simplified
# MAGIC     WHEN 'Azure' THEN 'Azure'
# MAGIC     WHEN 'MCT' THEN 'Mosaic'
# MAGIC     ELSE 'Non Azure'
# MAGIC   END AS Platform_Type_Simplified
# MAGIC FROM main.it_aibi_silver.cashflow_dashboard_Opportunity_vs_Bookings_silver
