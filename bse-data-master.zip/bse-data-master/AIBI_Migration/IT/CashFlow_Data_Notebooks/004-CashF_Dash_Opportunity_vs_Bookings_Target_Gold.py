# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.cashflow_dashboard_Opportunity_vs_Bookings_target_gold AS
# MAGIC
# MAGIC SELECT 
# MAGIC   platform,
# MAGIC   fy_quarter,
# MAGIC   type,
# MAGIC   Actual_value,
# MAGIC   Pipeline_value,
# MAGIC   grand_total,
# MAGIC   Actual_value_percentage,
# MAGIC   pipeline_value_percentage,
# MAGIC   grand_total_percentage,
# MAGIC   value,
# MAGIC   value_per,
# MAGIC   grand_total - value AS Variance_With_Total,
# MAGIC   grand_total_percentage - value_per AS Variance_with_Total_Percentage
# MAGIC FROM 
# MAGIC   main.it_aibi_silver.cashflow_dashboard_Opportunity_vs_Bookings_target_silver

# COMMAND ----------


