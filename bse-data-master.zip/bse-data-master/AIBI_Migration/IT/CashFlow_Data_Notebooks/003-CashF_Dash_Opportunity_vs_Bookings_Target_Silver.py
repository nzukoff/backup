# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.cashflow_dashboard_Opportunity_vs_Bookings_target_silver as 
# MAGIC
# MAGIC
# MAGIC
# MAGIC WITH original_data AS (
# MAGIC     SELECT
# MAGIC         CASE
# MAGIC             WHEN Platform_Simplified = 'Azure' THEN 'Azure'
# MAGIC             WHEN Platform_Simplified = 'MCT' THEN 'Mosaic'
# MAGIC             ELSE 'Non-Azure'
# MAGIC         END AS derived_platform,
# MAGIC         fy_quarter,
# MAGIC         fiscal_quarter_end_date,
# MAGIC         'Bookings Billed Upfront' AS type,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END) AS Actual_value,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END) AS Pipeline_value,
# MAGIC         SUM(Bookings_Billed_Upfront_Within_30days) AS grand_total,
# MAGIC         try_divide(
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END),
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN booking_dollars ELSE 0 END)
# MAGIC         ) * 100 AS Actual_value_percentage,
# MAGIC         try_divide(
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END),
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN booking_dollars ELSE 0 END)
# MAGIC         ) * 100 AS pipeline_value_percentage,
# MAGIC         try_divide(
# MAGIC             SUM(Bookings_Billed_Upfront_Within_30days),
# MAGIC             SUM(booking_dollars)
# MAGIC         ) * 100 AS grand_total_percentage
# MAGIC     FROM
# MAGIC         main.it_finance_silver.opp_bookings_billing_agg
# MAGIC     WHERE
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         AND LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('omitted')
# MAGIC     GROUP BY
# MAGIC         1, 2, 3, 4
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         CASE
# MAGIC             WHEN Platform_Simplified = 'Azure' THEN 'Azure'
# MAGIC             WHEN Platform_Simplified = 'MCT' THEN 'Mosaic'
# MAGIC             ELSE 'Non-Azure'
# MAGIC         END AS derived_platform,
# MAGIC         fy_quarter,
# MAGIC         fiscal_quarter_end_date,
# MAGIC         'Bookings Billed Non Upfront' AS type,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Non_Upfront ELSE 0 END) AS Actual_value,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Non_Upfront ELSE 0 END) AS Pipeline_value,
# MAGIC         SUM(Bookings_Billed_Non_Upfront) AS grand_total,
# MAGIC         try_divide(
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Non_Upfront ELSE 0 END),
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN booking_dollars ELSE 0 END)
# MAGIC         ) * 100 AS Actual_value_percentage,
# MAGIC         try_divide(
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Non_Upfront ELSE 0 END),
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN booking_dollars ELSE 0 END)
# MAGIC         ) * 100 AS pipeline_value_percentage,
# MAGIC         try_divide(
# MAGIC             SUM(Bookings_Billed_Non_Upfront),
# MAGIC             SUM(booking_dollars)
# MAGIC         ) * 100 AS grand_total_percentage
# MAGIC     FROM
# MAGIC         main.it_finance_silver.opp_bookings_billing_agg
# MAGIC     WHERE
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         AND LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('omitted')
# MAGIC     GROUP BY
# MAGIC         1, 2, 3, 4
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         CASE
# MAGIC             WHEN Platform_Simplified = 'Azure' THEN 'Azure'
# MAGIC             WHEN Platform_Simplified = 'MCT' THEN 'Mosaic'
# MAGIC             ELSE 'Non-Azure'
# MAGIC         END AS derived_platform,
# MAGIC         fy_quarter,
# MAGIC         fiscal_quarter_end_date,
# MAGIC         'Grand Total' AS type,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN booking_dollars ELSE 0 END) AS Actual_value,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN booking_dollars ELSE 0 END) AS Pipeline_value,
# MAGIC         SUM(booking_dollars) AS grand_total,
# MAGIC         100 AS Actual_value_percentage,
# MAGIC         100 AS pipeline_value_percentage,
# MAGIC         100 AS grand_total_percentage
# MAGIC     FROM
# MAGIC         main.it_finance_silver.opp_bookings_billing_agg
# MAGIC     WHERE
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         AND LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('omitted')
# MAGIC     GROUP BY
# MAGIC         1, 2, 3, 4
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         CASE
# MAGIC             WHEN Platform_Simplified = 'Azure' THEN 'Azure'
# MAGIC             WHEN Platform_Simplified = 'MCT' THEN 'Mosaic'
# MAGIC             ELSE 'Non-Azure'
# MAGIC         END AS derived_platform,
# MAGIC         fy_quarter,
# MAGIC         fiscal_quarter_end_date,
# MAGIC         'New Bookings' AS type,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Incremental_Dollars ELSE 0 END) AS Actual_value,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Incremental_Dollars ELSE 0 END) AS Pipeline_value,
# MAGIC         SUM(Incremental_Dollars) AS grand_total,
# MAGIC         100 AS Actual_value_percentage,
# MAGIC         100 AS pipeline_value_percentage,
# MAGIC         100 AS grand_total_percentage
# MAGIC     FROM
# MAGIC         main.it_finance_silver.opp_bookings_billing_agg
# MAGIC     WHERE
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         AND LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('omitted')
# MAGIC     GROUP BY
# MAGIC         1, 2, 3, 4
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         CASE
# MAGIC             WHEN Platform_Simplified = 'Azure' THEN 'Azure'
# MAGIC             WHEN Platform_Simplified = 'MCT' THEN 'Mosaic'
# MAGIC             ELSE 'Non-Azure'
# MAGIC         END AS derived_platform,
# MAGIC         fy_quarter,
# MAGIC         fiscal_quarter_end_date,
# MAGIC         'Renewal Bookings' AS type,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Renewal_Dollars ELSE 0 END) AS Actual_value,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Renewal_Dollars ELSE 0 END) AS Pipeline_value,
# MAGIC         SUM(Renewal_Dollars) AS grand_total,
# MAGIC         100 AS Actual_value_percentage,
# MAGIC         100 AS pipeline_value_percentage,
# MAGIC         100 AS grand_total_percentage
# MAGIC     FROM
# MAGIC         main.it_finance_silver.opp_bookings_billing_agg
# MAGIC     WHERE
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         AND LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('omitted')
# MAGIC     GROUP BY
# MAGIC         1, 2, 3, 4
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         'Total' AS derived_platform,
# MAGIC         fy_quarter,
# MAGIC         fiscal_quarter_end_date,
# MAGIC         'Bookings Billed Upfront' AS type,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END) AS Actual_value,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END) AS Pipeline_value,
# MAGIC         SUM(Bookings_Billed_Upfront_Within_30days) AS grand_total,
# MAGIC         try_divide(
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END),
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN booking_dollars ELSE 0 END)
# MAGIC         ) * 100 AS Actual_value_percentage,
# MAGIC         try_divide(
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END),
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN booking_dollars ELSE 0 END)
# MAGIC         ) * 100 AS pipeline_value_percentage,
# MAGIC         try_divide(
# MAGIC             SUM(Bookings_Billed_Upfront_Within_30days),
# MAGIC             SUM(booking_dollars)
# MAGIC         ) * 100 AS grand_total_percentage
# MAGIC     FROM
# MAGIC         main.it_finance_silver.opp_bookings_billing_agg
# MAGIC     WHERE
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         AND LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('omitted')
# MAGIC     GROUP BY
# MAGIC         1, 2, 3, 4
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         'Total' AS derived_platform,
# MAGIC         fy_quarter,
# MAGIC         fiscal_quarter_end_date,
# MAGIC         'Bookings Billed Non Upfront' AS type,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Non_Upfront ELSE 0 END) AS Actual_value,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Non_Upfront ELSE 0 END) AS Pipeline_value,
# MAGIC         SUM(Bookings_Billed_Non_Upfront) AS grand_total,
# MAGIC         try_divide(
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Non_Upfront ELSE 0 END),
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN booking_dollars ELSE 0 END)
# MAGIC         ) * 100 AS Actual_value_percentage,
# MAGIC         try_divide(
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Non_Upfront ELSE 0 END),
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN booking_dollars ELSE 0 END)
# MAGIC         ) * 100 AS pipeline_value_percentage,
# MAGIC         try_divide(
# MAGIC             SUM(Bookings_Billed_Non_Upfront),
# MAGIC             SUM(booking_dollars)
# MAGIC         ) * 100 AS grand_total_percentage
# MAGIC     FROM
# MAGIC         main.it_finance_silver.opp_bookings_billing_agg
# MAGIC     WHERE
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         AND LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('omitted')
# MAGIC     GROUP BY
# MAGIC         1, 2, 3, 4
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         'Total' AS derived_platform,
# MAGIC         fy_quarter,
# MAGIC         fiscal_quarter_end_date,
# MAGIC         'Grand Total' AS type,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN booking_dollars ELSE 0 END) AS Actual_value,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN booking_dollars ELSE 0 END) AS Pipeline_value,
# MAGIC         SUM(booking_dollars) AS grand_total,
# MAGIC         100 AS Actual_value_percentage,
# MAGIC         100 AS pipeline_value_percentage,
# MAGIC         100 AS grand_total_percentage
# MAGIC     FROM
# MAGIC         main.it_finance_silver.opp_bookings_billing_agg
# MAGIC     WHERE
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         AND LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('omitted')
# MAGIC     GROUP BY
# MAGIC         1, 2, 3, 4
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         'Total' AS derived_platform,
# MAGIC         fy_quarter,
# MAGIC         fiscal_quarter_end_date,
# MAGIC         'New Bookings' AS type,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Incremental_Dollars ELSE 0 END) AS Actual_value,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Incremental_Dollars ELSE 0 END) AS Pipeline_value,
# MAGIC         SUM(Incremental_Dollars) AS grand_total,
# MAGIC         100 AS Actual_value_percentage,
# MAGIC         100 AS pipeline_value_percentage,
# MAGIC         100 AS grand_total_percentage
# MAGIC     FROM
# MAGIC         main.it_finance_silver.opp_bookings_billing_agg
# MAGIC     WHERE
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         AND LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('omitted')
# MAGIC     GROUP BY
# MAGIC         1, 2, 3, 4
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT
# MAGIC         'Total' AS derived_platform,
# MAGIC         fy_quarter,
# MAGIC         fiscal_quarter_end_date,
# MAGIC         'Renewal Bookings' AS type,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Renewal_Dollars ELSE 0 END) AS Actual_value,
# MAGIC         SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Renewal_Dollars ELSE 0 END) AS Pipeline_value,
# MAGIC         SUM(Renewal_Dollars) AS grand_total,
# MAGIC         100 AS Actual_value_percentage,
# MAGIC         100 AS pipeline_value_percentage,
# MAGIC         100 AS grand_total_percentage
# MAGIC     FROM
# MAGIC         main.it_finance_silver.opp_bookings_billing_agg
# MAGIC     WHERE
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         AND LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('omitted')
# MAGIC     GROUP BY
# MAGIC         1, 2, 3, 4
# MAGIC ),
# MAGIC
# MAGIC new_data AS (
# MAGIC     SELECT 
# MAGIC         platform,
# MAGIC         d.fy_quarter,
# MAGIC         type,
# MAGIC         SUM(value) AS value,
# MAGIC         (SUM(value) / SUM(CASE WHEN type IN ('Renewal Bookings', 'New Bookings') THEN SUM(value) ELSE 0 END) OVER (PARTITION BY d.fy_quarter, platform)) * 100 AS value_per
# MAGIC     FROM 
# MAGIC         main.it_finance_silver.cashflow_bookings_targets target
# MAGIC     INNER JOIN 
# MAGIC         main.it_core_dim.bi_dates d ON target.Period = d.`date`
# MAGIC     WHERE 
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.cashflow_bookings_targets)
# MAGIC     GROUP BY 
# MAGIC         platform, d.fy_quarter, type
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT 
# MAGIC         platform,
# MAGIC         d.fy_quarter,
# MAGIC         'Grand Total' AS type,
# MAGIC         SUM(CASE WHEN type IN ('Renewal Bookings', 'New Bookings') THEN value ELSE 0 END) AS value,
# MAGIC         0 AS value_per
# MAGIC     FROM 
# MAGIC         main.it_finance_silver.cashflow_bookings_targets target
# MAGIC     INNER JOIN 
# MAGIC         main.it_core_dim.bi_dates d ON target.Period = d.`date`
# MAGIC     WHERE 
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.cashflow_bookings_targets)
# MAGIC     GROUP BY 
# MAGIC         platform, d.fy_quarter, type
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT 
# MAGIC         'Total' AS platform,
# MAGIC         d.fy_quarter,
# MAGIC         type,
# MAGIC         SUM(value) AS value,
# MAGIC         (SUM(value) / SUM(CASE WHEN type IN ('Renewal Bookings', 'New Bookings') THEN SUM(value) ELSE 0 END) OVER (PARTITION BY d.fy_quarter)) * 100 AS value_per
# MAGIC     FROM 
# MAGIC         main.it_finance_silver.cashflow_bookings_targets target
# MAGIC     INNER JOIN 
# MAGIC         main.it_core_dim.bi_dates d ON target.Period = d.`date`
# MAGIC     WHERE 
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.cashflow_bookings_targets)
# MAGIC     GROUP BY 
# MAGIC         d.fy_quarter, type
# MAGIC
# MAGIC     UNION ALL
# MAGIC
# MAGIC     SELECT 
# MAGIC         'Total' AS platform,
# MAGIC         d.fy_quarter,
# MAGIC         'Grand Total' AS type,
# MAGIC         SUM(CASE WHEN type IN ('Renewal Bookings', 'New Bookings') THEN value ELSE 0 END) AS value,
# MAGIC         0 AS value_per
# MAGIC     FROM 
# MAGIC         main.it_finance_silver.cashflow_bookings_targets target
# MAGIC     INNER JOIN 
# MAGIC         main.it_core_dim.bi_dates d ON target.Period = d.`date`
# MAGIC     WHERE 
# MAGIC         process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.cashflow_bookings_targets)
# MAGIC     GROUP BY 
# MAGIC         d.fy_quarter, type
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC     COALESCE(o.derived_platform, n.platform) AS platform,
# MAGIC     COALESCE(o.fy_quarter, n.fy_quarter) AS fy_quarter,
# MAGIC     COALESCE(o.type, n.type) AS type,
# MAGIC     o.Actual_value,
# MAGIC     o.Pipeline_value,
# MAGIC     o.grand_total,
# MAGIC     o.Actual_value_percentage,
# MAGIC     o.pipeline_value_percentage,
# MAGIC     o.grand_total_percentage,
# MAGIC     n.value,
# MAGIC     n.value_per
# MAGIC FROM 
# MAGIC     original_data o
# MAGIC FULL JOIN 
# MAGIC     new_data n
# MAGIC ON 
# MAGIC     o.derived_platform = n.platform
# MAGIC     AND o.type = n.type
# MAGIC     AND o.fy_quarter = n.fy_quarter
# MAGIC ORDER BY 
# MAGIC     platform, fy_quarter, type
# MAGIC
# MAGIC
# MAGIC
# MAGIC
