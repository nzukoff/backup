# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.cashflow_dashboard_upside_silver as
# MAGIC
# MAGIC WITH query1 AS (
# MAGIC     SELECT
# MAGIC         CASE
# MAGIC             WHEN Platform_Simplified = 'Azure' THEN 'Azure'
# MAGIC             WHEN Platform_Simplified = 'MCT' THEN 'Mosaic'
# MAGIC             ELSE 'Non-Azure'
# MAGIC         END AS platform,
# MAGIC         fy_quarter,
# MAGIC         type,
# MAGIC         SUM(Actual_value) AS Actual_value,
# MAGIC         SUM(Pipeline_value) AS Pipeline_value,
# MAGIC         SUM(grand_total) AS grand_total,
# MAGIC         AVG(Actual_value_percentage) AS Actual_value_percentage,
# MAGIC         AVG(pipeline_value_percentage) AS pipeline_value_percentage,
# MAGIC         AVG(grand_total_percentage) AS grand_total_percentage
# MAGIC     FROM (
# MAGIC         SELECT
# MAGIC             Platform_Simplified,
# MAGIC             fy_quarter,
# MAGIC             'Bookings Billed Upfront' AS type,
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END) AS Actual_value,
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END) AS Pipeline_value,
# MAGIC             SUM(Bookings_Billed_Upfront_Within_30days) AS grand_total,
# MAGIC             try_divide(
# MAGIC                 SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END),
# MAGIC                 SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN booking_dollars ELSE 0 END)
# MAGIC             ) * 100 AS Actual_value_percentage,
# MAGIC             try_divide(
# MAGIC                 SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Upfront_Within_30days ELSE 0 END),
# MAGIC                 SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN booking_dollars ELSE 0 END)
# MAGIC             ) * 100 AS pipeline_value_percentage,
# MAGIC             try_divide(
# MAGIC                 SUM(Bookings_Billed_Upfront_Within_30days),
# MAGIC                 SUM(booking_dollars)
# MAGIC             ) * 100 AS grand_total_percentage
# MAGIC         FROM main.it_finance_silver.opp_bookings_billing_agg
# MAGIC         WHERE LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('upside', 'omitted')
# MAGIC             AND process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         GROUP BY Platform_Simplified, fy_quarter
# MAGIC
# MAGIC         UNION ALL
# MAGIC
# MAGIC         SELECT
# MAGIC             Platform_Simplified,
# MAGIC             fy_quarter,
# MAGIC             'Bookings Billed Non Upfront' AS type,
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Non_Upfront ELSE 0 END) AS Actual_value,
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Non_Upfront ELSE 0 END) AS Pipeline_value,
# MAGIC             SUM(Bookings_Billed_Non_Upfront) AS grand_total,
# MAGIC             try_divide(
# MAGIC                 SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Bookings_Billed_Non_Upfront ELSE 0 END),
# MAGIC                 SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN booking_dollars ELSE 0 END)
# MAGIC             ) * 100 AS Actual_value_percentage,
# MAGIC             try_divide(
# MAGIC                 SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Bookings_Billed_Non_Upfront ELSE 0 END),
# MAGIC                 SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN booking_dollars ELSE 0 END)
# MAGIC             ) * 100 AS pipeline_value_percentage,
# MAGIC             try_divide(
# MAGIC                 SUM(Bookings_Billed_Non_Upfront),
# MAGIC                 SUM(booking_dollars)
# MAGIC             ) * 100 AS grand_total_percentage
# MAGIC         FROM main.it_finance_silver.opp_bookings_billing_agg
# MAGIC         WHERE LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('upside', 'omitted')
# MAGIC             AND process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         GROUP BY Platform_Simplified, fy_quarter
# MAGIC
# MAGIC         UNION ALL
# MAGIC
# MAGIC         SELECT
# MAGIC             Platform_Simplified,
# MAGIC             fy_quarter,
# MAGIC             'Grand Total' AS type,
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN booking_dollars ELSE 0 END) AS Actual_value,
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN booking_dollars ELSE 0 END) AS Pipeline_value,
# MAGIC             SUM(booking_dollars) AS grand_total,
# MAGIC             100 AS Actual_value_percentage,
# MAGIC             100 AS pipeline_value_percentage,
# MAGIC             100 AS grand_total_percentage
# MAGIC         FROM main.it_finance_silver.opp_bookings_billing_agg
# MAGIC         WHERE LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('upside', 'omitted')
# MAGIC             AND process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         GROUP BY Platform_Simplified, fy_quarter
# MAGIC
# MAGIC         UNION ALL
# MAGIC
# MAGIC         SELECT
# MAGIC             Platform_Simplified,
# MAGIC             fy_quarter,
# MAGIC             'New Bookings' AS type,
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Incremental_Dollars ELSE 0 END) AS Actual_value,
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Incremental_Dollars ELSE 0 END) AS Pipeline_value,
# MAGIC             SUM(Incremental_Dollars) AS grand_total,
# MAGIC             100 AS Actual_value_percentage,
# MAGIC             100 AS pipeline_value_percentage,
# MAGIC             100 AS grand_total_percentage
# MAGIC         FROM main.it_finance_silver.opp_bookings_billing_agg
# MAGIC         WHERE LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('upside', 'omitted')
# MAGIC             AND process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         GROUP BY Platform_Simplified, fy_quarter
# MAGIC
# MAGIC         UNION ALL
# MAGIC
# MAGIC         SELECT
# MAGIC             Platform_Simplified,
# MAGIC             fy_quarter,
# MAGIC             'Renewal Bookings' AS type,
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Actual' THEN Renewal_Dollars ELSE 0 END) AS Actual_value,
# MAGIC             SUM(CASE WHEN pipeline_or_actual = 'Pipeline' THEN Renewal_Dollars ELSE 0 END) AS Pipeline_value,
# MAGIC             SUM(Renewal_Dollars) AS grand_total,
# MAGIC             100 AS Actual_value_percentage,
# MAGIC             100 AS pipeline_value_percentage,
# MAGIC             100 AS grand_total_percentage
# MAGIC         FROM main.it_finance_silver.opp_bookings_billing_agg
# MAGIC         WHERE LOWER(COALESCE(manager_forecast, 'Unknown')) NOT IN ('upside', 'omitted')
# MAGIC             AND process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.opp_bookings_billing_agg)
# MAGIC         GROUP BY Platform_Simplified, fy_quarter
# MAGIC     ) AS subquery1
# MAGIC     GROUP BY platform, fy_quarter, type
# MAGIC ),
# MAGIC
# MAGIC query2 AS (
# MAGIC     SELECT 
# MAGIC         platform,
# MAGIC         fy_quarter,
# MAGIC         type,
# MAGIC         value,
# MAGIC         value_per
# MAGIC     FROM (
# MAGIC         SELECT 
# MAGIC             platform,
# MAGIC             d.fy_quarter,
# MAGIC             type,
# MAGIC             SUM(value) AS value,
# MAGIC             (SUM(value) / SUM(CASE WHEN type IN ('Renewal Bookings', 'New Bookings') THEN SUM(value) ELSE 0 END) OVER (PARTITION BY d.fy_quarter, platform)) * 100 AS value_per
# MAGIC         FROM 
# MAGIC             main.it_finance_silver.cashflow_bookings_targets target
# MAGIC         INNER JOIN 
# MAGIC             main.it_core_dim.bi_dates d ON target.Period = d.`date`
# MAGIC         WHERE 
# MAGIC             process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.cashflow_bookings_targets)
# MAGIC         GROUP BY 
# MAGIC             platform, d.fy_quarter, type
# MAGIC
# MAGIC         UNION ALL
# MAGIC
# MAGIC         SELECT 
# MAGIC             platform,
# MAGIC             d.fy_quarter,
# MAGIC             'Grand Total' AS type,
# MAGIC             SUM(CASE WHEN type IN ('Renewal Bookings', 'New Bookings') THEN value ELSE 0 END) AS value,
# MAGIC             0 AS value_per
# MAGIC         FROM 
# MAGIC             main.it_finance_silver.cashflow_bookings_targets target
# MAGIC         INNER JOIN 
# MAGIC             main.it_core_dim.bi_dates d ON target.Period = d.`date`
# MAGIC         WHERE 
# MAGIC             process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.cashflow_bookings_targets)
# MAGIC         GROUP BY 
# MAGIC             platform, d.fy_quarter
# MAGIC
# MAGIC         UNION ALL
# MAGIC
# MAGIC         SELECT 
# MAGIC             'Total' AS platform,
# MAGIC             d.fy_quarter,
# MAGIC             type,
# MAGIC             SUM(value) AS value,
# MAGIC             (SUM(value) / SUM(CASE WHEN type IN ('Renewal Bookings', 'New Bookings') THEN SUM(value) ELSE 0 END) OVER (PARTITION BY d.fy_quarter)) * 100 AS value_per
# MAGIC         FROM 
# MAGIC             main.it_finance_silver.cashflow_bookings_targets target
# MAGIC         INNER JOIN 
# MAGIC             main.it_core_dim.bi_dates d ON target.Period = d.`date`
# MAGIC         WHERE 
# MAGIC             process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.cashflow_bookings_targets)
# MAGIC         GROUP BY 
# MAGIC             d.fy_quarter, type
# MAGIC
# MAGIC         UNION ALL
# MAGIC
# MAGIC         SELECT 
# MAGIC             'Total' AS platform,
# MAGIC             d.fy_quarter,
# MAGIC             'Grand Total' AS type,
# MAGIC             SUM(CASE WHEN type IN ('Renewal Bookings', 'New Bookings') THEN value ELSE 0 END) AS value,
# MAGIC             0 AS value_per
# MAGIC         FROM 
# MAGIC             main.it_finance_silver.cashflow_bookings_targets target
# MAGIC         INNER JOIN 
# MAGIC             main.it_core_dim.bi_dates d ON target.Period = d.`date`
# MAGIC         WHERE 
# MAGIC             process_date = (SELECT MAX(process_date) FROM main.it_finance_silver.cashflow_bookings_targets)
# MAGIC         GROUP BY 
# MAGIC             d.fy_quarter
# MAGIC     ) AS subquery2
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC     COALESCE(q1.platform, q2.platform) AS platform,
# MAGIC     COALESCE(q1.fy_quarter, q2.fy_quarter) AS fy_quarter,
# MAGIC     COALESCE(q1.type, q2.type) AS type,
# MAGIC     q1.Actual_value,
# MAGIC     q1.Pipeline_value,
# MAGIC     q1.grand_total,
# MAGIC     q1.Actual_value_percentage,
# MAGIC     q1.pipeline_value_percentage,
# MAGIC     q1.grand_total_percentage,
# MAGIC     q2.value AS target_value,
# MAGIC     q2.value_per AS target_value_percentage
# MAGIC FROM query1 q1
# MAGIC FULL JOIN query2 q2
# MAGIC     ON q1.platform = q2.platform
# MAGIC     AND q1.fy_quarter = q2.fy_quarter
# MAGIC     AND q1.type = q2.type
# MAGIC ORDER BY 
# MAGIC     COALESCE(q1.platform, q2.platform),
# MAGIC     COALESCE(q1.fy_quarter, q2.fy_quarter),
# MAGIC     COALESCE(q1.type, q2.type)
