# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.cashflow_dashboard_Opportunity_vs_Bookings_silver as 
# MAGIC
# MAGIC SELECT * 
# MAGIC FROM main.it_finance_silver.opp_bookings_billing_agg
# MAGIC WHERE process_date = (
# MAGIC     SELECT MAX(process_date)
# MAGIC     FROM main.it_finance_silver.opp_bookings_billing_agg
# MAGIC )
