# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.cashflow_dashboard_upside_gold as
# MAGIC
# MAGIC SELECT 
# MAGIC   platform,
# MAGIC   fy_quarter,
# MAGIC   type,
# MAGIC   Actual_value,
# MAGIC   Pipeline_value,
# MAGIC   grand_total,
# MAGIC   Actual_value_percentage,
# MAGIC   pipeline_value_percentage,
# MAGIC   grand_total_percentage,
# MAGIC   target_value,
# MAGIC   target_value_percentage,
# MAGIC   grand_total - target_value AS Variance_With_Total,
# MAGIC   grand_total_percentage - target_value_percentage AS Variance_with_Total_Percentage
# MAGIC FROM main.it_aibi_silver.cashflow_dashboard_upside_silver
