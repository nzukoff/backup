# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.audience_profiler_silver
# MAGIC
# MAGIC select
# MAGIC account_name,
# MAGIC business_unit,
# MAGIC cloud,
# MAGIC cloud_type,
# MAGIC country,
# MAGIC state,
# MAGIC city,
# MAGIC dbx,
# MAGIC emailable,
# MAGIC is_real_customer,
# MAGIC marketable,
# MAGIC marketable_tier,
# MAGIC marketing_funnel_stage,
# MAGIC partner_type,
# MAGIC postal_code,
# MAGIC prospect_vs_customer,
# MAGIC region,
# MAGIC sub_region,
# MAGIC sales_subregion_level_1,
# MAGIC sales_subregion_level_2,
# MAGIC serverless_adoption_stage,
# MAGIC subscription_events_education,
# MAGIC subscription_feedback_surveys,
# MAGIC subscription_newsletter,
# MAGIC subscription_product_updates,
# MAGIC subscription_training_certification,
# MAGIC uc_adoption_stage,
# MAGIC vertical,
# MAGIC persona_bi as bi,
# MAGIC persona_business_execs as business_execs,
# MAGIC persona_cdo as cdo,
# MAGIC persona_cio as cio,
# MAGIC persona_data_architect as data_architect,
# MAGIC persona_data_engineer as data_engineer,
# MAGIC persona_data_scientist as data_scienctist,
# MAGIC persona_other as other,
# MAGIC workspace_user_type
# MAGIC from main.marketing_lakehouse.gold_audience_profile_contact
# MAGIC
