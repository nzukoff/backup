# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.audience_profiler_gold as
# MAGIC
# MAGIC SELECT
# MAGIC     CASE WHEN country = 'Antarctica' THEN 'Unknown' ELSE country END AS country,
# MAGIC     CASE WHEN country = 'United States' THEN state ELSE 'Other' END AS state,
# MAGIC     account_name,
# MAGIC     business_unit,
# MAGIC     cloud,
# MAGIC     cloud_type,
# MAGIC     city,
# MAGIC     dbx,
# MAGIC     emailable,
# MAGIC     is_real_customer,
# MAGIC     marketable,
# MAGIC     marketable_tier,
# MAGIC     marketing_funnel_stage,
# MAGIC     partner_type,
# MAGIC     postal_code,
# MAGIC     prospect_vs_customer,
# MAGIC     region,
# MAGIC     sub_region,
# MAGIC     sales_subregion_level_1,
# MAGIC     sales_subregion_level_2,
# MAGIC     serverless_adoption_stage,
# MAGIC     subscription_events_education,
# MAGIC     subscription_feedback_surveys,
# MAGIC     subscription_newsletter,
# MAGIC     subscription_product_updates,
# MAGIC     subscription_training_certification,
# MAGIC     uc_adoption_stage,
# MAGIC     vertical,
# MAGIC     bi,
# MAGIC     business_execs,
# MAGIC     cdo,
# MAGIC     cio,
# MAGIC     data_architect,
# MAGIC     data_engineer,
# MAGIC     data_scienctist,
# MAGIC     other,
# MAGIC     workspace_user_type
# MAGIC FROM main.it_aibi_silver.audience_profiler_silver
# MAGIC WHERE emailable = 'Yes'
# MAGIC   AND IFNULL(marketable = 'Yes', FALSE)
