# Databricks notebook source
# %sql


# CREATE OR REPLACE VIEW main.it_aibi_silver.fact_funnel_audience_reporting_silver_view as

# WITH lead_contact_id_marketing_cte AS (
#     SELECT
#         dim_account_id,
#         week_start_date,
#         COUNT(CASE WHEN marketable_tier IS NOT NULL THEN 1 END) AS lead_contact_id_marketing
#     FROM 
#         main.it_aibi_silver.fact_funnel_reporting_performance slr_ffrp
#     LEFT JOIN
#         main.marketing_lakehouse.gold_audience_profile_contact_detail ml_gapcd
#     ON
#         slr_ffrp.dim_account_id = ml_gapcd.account_id
#     GROUP BY dim_account_id, week_start_date
# ),
# share_general_cte AS (
#     SELECT
#         dim_account_id,
#         lead_contact_id_marketing / SUM(lead_contact_id_marketing) OVER () AS share_general
#     FROM lead_contact_id_marketing_cte
# ),
# qoq_lead_created_cte AS (
#     SELECT
#         dim_account_id,
#         week_start_date,
#         lead_contact_id_marketing AS current_quarter_leads,
#         LAG(lead_contact_id_marketing) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) AS prev_quarter_leads,
#         LEAD(lead_contact_id_marketing) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) AS next_quarter_leads,
#         LAG(lead_contact_id_marketing, 4) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) AS prev_year_leads,
#         LEAD(lead_contact_id_marketing, 4) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) AS next_year_leads,
#         CASE 
#             WHEN LAG(lead_contact_id_marketing) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) > 0 
#             THEN (lead_contact_id_marketing - LAG(lead_contact_id_marketing) OVER (PARTITION BY dim_account_id ORDER BY week_start_date)) / 
#                  LAG(lead_contact_id_marketing) OVER (PARTITION BY dim_account_id ORDER BY week_start_date)
#             ELSE NULL
#         END AS qoq_lead_created_id,
#         CASE 
#             WHEN LAG(lead_contact_id_marketing, 4) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) > 0 
#             THEN (lead_contact_id_marketing - LAG(lead_contact_id_marketing, 4) OVER (PARTITION BY dim_account_id ORDER BY week_start_date)) / 
#                  LAG(lead_contact_id_marketing, 4) OVER (PARTITION BY dim_account_id ORDER BY week_start_date)
#             ELSE NULL
#         END AS yoy_lead_created_id
#     FROM lead_contact_id_marketing_cte
# )
# SELECT
#     slr_ffrp.*,  -- Select all columns fact_funnel_reporting_performance
#     ml_gapcd.mkto_created_date,
#     ml_gapcd.audience_persona AS gapcd_audience_persona,
#     CASE 
#         WHEN ml_gapcd.audience_persona IN ('Business Execs', 'BI', 'Other') THEN 'Other'
#         ELSE ml_gapcd.audience_persona
#     END AS ml_gapcd_persona_cal_other,
#     ml_gapcd.title,
#     ml_gapcd.account_id,
#     ml_gapcd.account_name AS gapcd_account_name,
#     ml_gapcd.business_unit AS gapcd_bu,
#     ml_gapcd.sales_region,
#     ml_gapcd.sales_subregion_level_1 AS sales_subregion_1,
#     ml_gapcd.sales_subregion_level_2 AS sales_subregion_2,
#     ml_gapcd.lead_region,
#     ml_gapcd.lead_sub_region,
#     ml_gapcd.lead_country,
#     ml_gapcd.lead_state,
#     ml_gapcd.lead_city,
#     ml_gapcd.vertical AS gapcd_vertical,
#     ml_gapcd.cloud AS gapcd_cloud,
#     ml_gapcd.cloud_fact,
#     ml_gapcd.marketable,
#     ml_gapcd.emailable,
#     ml_gapcd.prospect_vs_customer,
#     ml_gapcd.workspace_user_type,
#     ml_gapcd.partner_type,
#     ml_gapcd.marketable_tier,
#     lcim.lead_contact_id_marketing,
#     ml_gapcd.seniority_level,
#     ml_gapcd.account_industry,
#     ml_gapcd.opt_in_status,
#     ml_gapcd.email_domain,
#     ml_gapcd.campaign_type,
#     ml_gapcd.lead_status AS gapcd_lead_status,
#     ml_gapcd.dbx AS gapcd_dbx,
#     ml_gapcd.region_level_1,
#     ml_gapcd.region_level_2,
#     ml_gapcd.region_level_3,
#     ml_gapcd.last_campaign_touch_date,
#     ml_gapcd.mops_analytics_id,
#     ml_gapcd.custom_cdo_cio_cto,
#     ml_gapcd.Details AS gapcd_details,
#     sgc.share_general,
#     qoq.qoq_lead_created_id,
#     qoq.yoy_lead_created_id,
#     CASE 
#         WHEN '[QOQ/YOY]' = 'QOQ' THEN qoq.qoq_lead_created_id
#         ELSE qoq.yoy_lead_created_id
#     END AS tableau_qoq_yoy_lead_created_id,
#     CASE 
#         WHEN qoq.qoq_lead_created_id < 0 THEN qoq.qoq_lead_created_id
#         ELSE NULL
#     END AS qoq_lead_created_id_negative,
#     CASE 
#         WHEN qoq.qoq_lead_created_id > 0 THEN qoq.qoq_lead_created_id
#         ELSE NULL
#     END AS qoq_lead_created_id_positive,
#     qoq.current_quarter_leads,
#     qoq.prev_quarter_leads,
#     qoq.next_quarter_leads,
#     qoq.prev_year_leads,
#     qoq.next_year_leads
# FROM 
#     main.it_aibi_silver.fact_funnel_reporting_performance slr_ffrp
# LEFT JOIN
#     main.marketing_lakehouse.gold_audience_profile_contact_detail ml_gapcd
# ON
#     slr_ffrp.dim_account_id = ml_gapcd.account_id
# LEFT JOIN
#     lead_contact_id_marketing_cte lcim
# ON
#     slr_ffrp.dim_account_id = lcim.dim_account_id
#     AND slr_ffrp.week_start_date = lcim.week_start_date
# LEFT JOIN
#     share_general_cte sgc
# ON
#     slr_ffrp.dim_account_id = sgc.dim_account_id
# LEFT JOIN
#     qoq_lead_created_cte qoq
# ON
#     slr_ffrp.dim_account_id = qoq.dim_account_id
#     AND slr_ffrp.week_start_date = qoq.week_start_date




# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE VIEW main.it_aibi_silver.fact_funnel_audience_reporting_silver_view AS
# MAGIC
# MAGIC WITH lead_contact_id_marketing_cte AS (
# MAGIC     SELECT
# MAGIC         slr_ffrp.dim_account_id,
# MAGIC         slr_ffrp.week_start_date,
# MAGIC         COUNT(CASE WHEN ml_gapcd.marketable_tier IS NOT NULL THEN 1 END) AS lead_contact_id_marketing
# MAGIC     FROM 
# MAGIC         main.it_aibi_silver.fact_funnel_reporting_performance slr_ffrp
# MAGIC     LEFT JOIN
# MAGIC         main.marketing_lakehouse.gold_audience_profile_contact_detail ml_gapcd
# MAGIC     ON
# MAGIC         slr_ffrp.dim_account_id = ml_gapcd.account_id
# MAGIC     GROUP BY slr_ffrp.dim_account_id, slr_ffrp.week_start_date
# MAGIC ),
# MAGIC share_general_cte AS (
# MAGIC     SELECT
# MAGIC         dim_account_id,
# MAGIC         lead_contact_id_marketing / SUM(lead_contact_id_marketing) OVER () AS share_general
# MAGIC     FROM lead_contact_id_marketing_cte
# MAGIC ),
# MAGIC qoq_lead_created_cte AS (
# MAGIC     SELECT
# MAGIC         dim_account_id,
# MAGIC         week_start_date,
# MAGIC         lead_contact_id_marketing AS current_quarter_leads,
# MAGIC         LAG(lead_contact_id_marketing) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) AS prev_quarter_leads,
# MAGIC         LEAD(lead_contact_id_marketing) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) AS next_quarter_leads,
# MAGIC         LAG(lead_contact_id_marketing, 4) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) AS prev_year_leads,
# MAGIC         LEAD(lead_contact_id_marketing, 4) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) AS next_year_leads,
# MAGIC         CASE 
# MAGIC             WHEN LAG(lead_contact_id_marketing) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) > 0 
# MAGIC             THEN (lead_contact_id_marketing - LAG(lead_contact_id_marketing) OVER (PARTITION BY dim_account_id ORDER BY week_start_date)) / 
# MAGIC                  LAG(lead_contact_id_marketing) OVER (PARTITION BY dim_account_id ORDER BY week_start_date)
# MAGIC             ELSE NULL
# MAGIC         END AS qoq_lead_created_id,
# MAGIC         CASE 
# MAGIC             WHEN LAG(lead_contact_id_marketing, 4) OVER (PARTITION BY dim_account_id ORDER BY week_start_date) > 0 
# MAGIC             THEN (lead_contact_id_marketing - LAG(lead_contact_id_marketing, 4) OVER (PARTITION BY dim_account_id ORDER BY week_start_date)) / 
# MAGIC                  LAG(lead_contact_id_marketing, 4) OVER (PARTITION BY dim_account_id ORDER BY week_start_date)
# MAGIC             ELSE NULL
# MAGIC         END AS yoy_lead_created_id
# MAGIC     FROM lead_contact_id_marketing_cte
# MAGIC )
# MAGIC SELECT
# MAGIC     slr_ffrp.*,  -- Select all columns from fact_funnel_reporting_performance
# MAGIC     ml_gapcd.mkto_created_date,
# MAGIC     ml_gapcd.audience_persona AS gapcd_audience_persona,
# MAGIC     CASE 
# MAGIC         WHEN ml_gapcd.audience_persona IN ('Business Execs', 'BI', 'Other') THEN 'Other'
# MAGIC         ELSE ml_gapcd.audience_persona
# MAGIC     END AS ml_gapcd_persona_cal_other,
# MAGIC     ml_gapcd.title,
# MAGIC     ml_gapcd.account_id,
# MAGIC     ml_gapcd.account_name AS gapcd_account_name,
# MAGIC     ml_gapcd.business_unit AS gapcd_bu,
# MAGIC     ml_gapcd.sales_region,
# MAGIC     ml_gapcd.sales_subregion_level_1 AS sales_subregion_1,
# MAGIC     ml_gapcd.sales_subregion_level_2 AS sales_subregion_2,
# MAGIC     ml_gapcd.lead_region,
# MAGIC     ml_gapcd.lead_sub_region,
# MAGIC     ml_gapcd.lead_country,
# MAGIC     ml_gapcd.lead_state,
# MAGIC     ml_gapcd.lead_city,
# MAGIC     ml_gapcd.vertical AS gapcd_vertical,
# MAGIC     ml_gapcd.cloud AS gapcd_cloud,
# MAGIC     ml_gapcd.cloud_fact,
# MAGIC     ml_gapcd.marketable,
# MAGIC     ml_gapcd.emailable,
# MAGIC     ml_gapcd.prospect_vs_customer,
# MAGIC     ml_gapcd.workspace_user_type,
# MAGIC     ml_gapcd.partner_type,
# MAGIC     ml_gapcd.marketable_tier,
# MAGIC     lcim.lead_contact_id_marketing,
# MAGIC     ml_gapcd.seniority_level,
# MAGIC     ml_gapcd.account_industry,
# MAGIC     ml_gapcd.opt_in_status,
# MAGIC     ml_gapcd.email_domain,
# MAGIC     ml_gapcd.campaign_type,
# MAGIC     ml_gapcd.lead_status AS gapcd_lead_status,
# MAGIC     ml_gapcd.dbx AS gapcd_dbx,
# MAGIC     ml_gapcd.region_level_1,
# MAGIC     ml_gapcd.region_level_2,
# MAGIC     ml_gapcd.region_level_3,
# MAGIC     ml_gapcd.last_campaign_touch_date,
# MAGIC     ml_gapcd.mops_analytics_id,
# MAGIC     ml_gapcd.custom_cdo_cio_cto,
# MAGIC     ml_gapcd.Details AS gapcd_details,
# MAGIC     sgc.share_general,
# MAGIC     qoq.qoq_lead_created_id,
# MAGIC     qoq.yoy_lead_created_id,
# MAGIC     CASE 
# MAGIC         WHEN '[QOQ/YOY]' = 'QOQ' THEN qoq.qoq_lead_created_id
# MAGIC         ELSE qoq.yoy_lead_created_id
# MAGIC     END AS tableau_qoq_yoy_lead_created_id,
# MAGIC     CASE 
# MAGIC         WHEN qoq.qoq_lead_created_id < 0 THEN qoq.qoq_lead_created_id
# MAGIC         ELSE NULL
# MAGIC     END AS qoq_lead_created_id_negative,
# MAGIC     CASE 
# MAGIC         WHEN qoq.qoq_lead_created_id > 0 THEN qoq.qoq_lead_created_id
# MAGIC         ELSE NULL
# MAGIC     END AS qoq_lead_created_id_positive,
# MAGIC     qoq.current_quarter_leads,
# MAGIC     qoq.prev_quarter_leads,
# MAGIC     qoq.next_quarter_leads,
# MAGIC     qoq.prev_year_leads,
# MAGIC     qoq.next_year_leads
# MAGIC FROM 
# MAGIC     main.it_aibi_silver.fact_funnel_reporting_performance slr_ffrp
# MAGIC LEFT JOIN
# MAGIC     main.marketing_lakehouse.gold_audience_profile_contact_detail ml_gapcd
# MAGIC ON
# MAGIC     slr_ffrp.dim_account_id = ml_gapcd.account_id
# MAGIC LEFT JOIN
# MAGIC     lead_contact_id_marketing_cte lcim
# MAGIC ON
# MAGIC     slr_ffrp.dim_account_id = lcim.dim_account_id
# MAGIC     AND slr_ffrp.week_start_date = lcim.week_start_date
# MAGIC LEFT JOIN
# MAGIC     share_general_cte sgc
# MAGIC ON
# MAGIC     slr_ffrp.dim_account_id = sgc.dim_account_id
# MAGIC LEFT JOIN
# MAGIC     qoq_lead_created_cte qoq
# MAGIC ON
# MAGIC     slr_ffrp.dim_account_id = qoq.dim_account_id
# MAGIC     AND slr_ffrp.week_start_date = qoq.week_start_date
