# Databricks notebook source
print("Gold table is not having data")




