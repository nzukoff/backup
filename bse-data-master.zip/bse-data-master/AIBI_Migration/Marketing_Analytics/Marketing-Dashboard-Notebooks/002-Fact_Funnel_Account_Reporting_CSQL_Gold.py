# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.FactFunnelAccountReporting_CSQL_gold as
# MAGIC
# MAGIC WITH calculated_columns AS (
# MAGIC     SELECT
# MAGIC         business_unit,
# MAGIC         account_name,
# MAGIC         account_owner_name,
# MAGIC         region,
# MAGIC         sub_region,
# MAGIC         cloud_type,
# MAGIC         engagement_type,
# MAGIC         dbx,
# MAGIC         account_status,
# MAGIC         has_genai_usecase,
# MAGIC         has_serverless,
# MAGIC         has_uc,
# MAGIC         fiscal_year_quarter_eng,
# MAGIC         u2_unit,
# MAGIC         uc_unit,
# MAGIC         CASE 
# MAGIC             WHEN has_serverless = TRUE THEN 'Serverless Adopted'
# MAGIC             ELSE 'Non Serverless Adopted'
# MAGIC         END AS Has_Serverless_alias,
# MAGIC         serverless_unit,
# MAGIC         CASE 
# MAGIC             WHEN has_trial = TRUE THEN 'Has Trial'
# MAGIC             ELSE 'No Trial'
# MAGIC         END AS Has_Trial_alias,
# MAGIC         date_oua,
# MAGIC         CASE 
# MAGIC             WHEN has_uc = TRUE THEN 'UC Adopted'
# MAGIC             ELSE 'Non UC Adopted'
# MAGIC         END AS Has_UC_alias,
# MAGIC         CASE 
# MAGIC             WHEN has_uc = TRUE THEN u2_unit 
# MAGIC         END AS uc_u2_unit,
# MAGIC         CASE 
# MAGIC             WHEN has_serverless = TRUE THEN u2_unit 
# MAGIC         END AS serverless_u2_unit,
# MAGIC         CASE 
# MAGIC             WHEN has_genai_usecase = TRUE THEN u2_unit 
# MAGIC         END AS genai_u2_unit,
# MAGIC         engagements,
# MAGIC         date_eng,
# MAGIC         engagement_group,
# MAGIC         vertical,
# MAGIC         has_trial,
# MAGIC         is_real_customer,
# MAGIC         CASE 
# MAGIC             WHEN UPPER(engagement_group) = 'EMAIL' THEN engagements 
# MAGIC         END AS email_open,
# MAGIC         CASE 
# MAGIC             WHEN UPPER(engagement_group) = 'FORM FILL' THEN engagements 
# MAGIC         END AS form_fills,
# MAGIC         t3m_dbu_consumption,
# MAGIC         t6m_dbu_consumption,
# MAGIC         t3m_dollars_bucket,
# MAGIC         CASE 
# MAGIC             WHEN t3m_dollars_bucket IN ('$1-250', '$250-500', '$500-1K') THEN TRUE 
# MAGIC             ELSE FALSE 
# MAGIC         END AS 1k_mrr,
# MAGIC         trial_unit,
# MAGIC         mql_unit,
# MAGIC         u3_unit,
# MAGIC         u6_unit,
# MAGIC         subregion_level_1,
# MAGIC         subregion_level_2,
# MAGIC         subregion_level_3,
# MAGIC         account_owner_manager,
# MAGIC         first_trial_date,
# MAGIC         dim_account_id,
# MAGIC         account_owner_role,
# MAGIC         account_segment,
# MAGIC         account_spend_tier,
# MAGIC         account_profile_fit_6sense_databricks,
# MAGIC         parent_account_id,
# MAGIC         t1m_dollars_bucket,
# MAGIC         event_asset,
# MAGIC         program_name,
# MAGIC         CASE 
# MAGIC             WHEN UPPER(event_asset) = 'EVENT' THEN 'Events'
# MAGIC             WHEN UPPER(event_asset) = 'EBOOK' THEN 'eBook'
# MAGIC             WHEN UPPER(event_asset) = 'WEBINER' THEN 'Webinar'
# MAGIC             WHEN UPPER(event_asset) = 'TRAINING' THEN 'Training'
# MAGIC             WHEN UPPER(event_asset) = 'WORKSHOP' THEN 'Workshop'
# MAGIC             WHEN UPPER(event_asset) = 'PARTNER' THEN 'Partner'
# MAGIC             WHEN UPPER(program_name) LIKE '%TRIAL%' THEN 'Trial'
# MAGIC             ELSE 'Others' 
# MAGIC         END AS event_asset_grouping,
# MAGIC         first_uc_date,
# MAGIC         first_serverless_date,
# MAGIC         first_1kmrr_date,
# MAGIC         total_unique_engaged_contacts_t30d,
# MAGIC         total_unique_engaged_contacts_t60d,
# MAGIC         total_unique_engaged_contacts_t90d,
# MAGIC         total_unique_contacts,
# MAGIC         CASE 
# MAGIC             WHEN SUM(engagements) OVER (PARTITION BY account_name) IS NULL THEN 1 
# MAGIC             ELSE NULL 
# MAGIC         END AS is_non_engaged,
# MAGIC         -- Added missing columns
# MAGIC         parent_account_name,
# MAGIC         top_level_account_id,
# MAGIC         top_level_account_name,
# MAGIC         account_owner_department,
# MAGIC         account_company_size,
# MAGIC         last_trial_date,
# MAGIC         first_genai_usecase_date,
# MAGIC         last_genai_usecase_date,
# MAGIC         has_genai_u6,
# MAGIC         first_genai_u6_date,
# MAGIC         last_genai_u6_date,
# MAGIC         t1m_dbu_consumption,
# MAGIC         cdo,
# MAGIC         other,
# MAGIC         data_scientist,
# MAGIC         cio,
# MAGIC         bi,
# MAGIC         data_architect,
# MAGIC         business_execs,
# MAGIC         data_engineer,
# MAGIC         decision_maker,
# MAGIC         c_level,
# MAGIC         executive,
# MAGIC         unknown,
# MAGIC         decision_maker_c_1,
# MAGIC         decision_maker_c_2_plus,
# MAGIC         practitioner,
# MAGIC         14d_trial_launched_retention,
# MAGIC         30d_trial_launched_retention,
# MAGIC         channel_type,
# MAGIC         channel_detail,
# MAGIC         fiscal_month_start_date,
# MAGIC         fiscal_year_quarter_oua,
# MAGIC         fiscalyear_oua,
# MAGIC         fiscalyear_eng,
# MAGIC         nnn_unit,
# MAGIC         u1_amount,
# MAGIC         u1_unit,
# MAGIC         u2_amount,
# MAGIC         u3_amount,
# MAGIC         u6_amount
# MAGIC     FROM 
# MAGIC         main.it_aibi_silver.FactFunnelAccountReporting_CSQL_silver
# MAGIC ),
# MAGIC distinct_account_counts AS (
# MAGIC     SELECT
# MAGIC         COUNT(DISTINCT account_name) AS total_distinct_accounts
# MAGIC     FROM 
# MAGIC         calculated_columns
# MAGIC ),
# MAGIC engagement_metrics AS (
# MAGIC     SELECT
# MAGIC         *,
# MAGIC         COUNT(DISTINCT account_name) AS total_distinct_accounts,
# MAGIC         SUM(is_non_engaged) OVER () AS total_non_engaged_accounts,
# MAGIC         CASE 
# MAGIC             WHEN SUM(engagements) OVER (PARTITION BY account_name) > 0 
# MAGIC                  AND t3m_dbu_consumption = 'NO'
# MAGIC                  AND (t3m_dbu_consumption = 'NO' OR t6m_dbu_consumption = 'NO')
# MAGIC             THEN 1
# MAGIC             ELSE 0
# MAGIC         END AS engaged_no_dbu_flag
# MAGIC     FROM calculated_columns
# MAGIC     GROUP BY ALL
# MAGIC )
# MAGIC SELECT
# MAGIC     *,
# MAGIC     
# MAGIC     -- % Penetration
# MAGIC     (CAST(COUNT(DISTINCT account_name) AS FLOAT) - SUM(is_non_engaged)) / 
# MAGIC     NULLIF(CAST(COUNT(DISTINCT account_name) AS FLOAT), 0) AS Penetration_Percentage,
# MAGIC     
# MAGIC     -- Overall Account with Engagements (copy)
# MAGIC     SUM(engaged_no_dbu_flag) AS Overall_Account_with_Engagements,
# MAGIC     
# MAGIC     -- % Penetration for Eng and No Dbu
# MAGIC     (CAST(COUNT(DISTINCT account_name) AS FLOAT) - SUM(engaged_no_dbu_flag)) / 
# MAGIC     NULLIF(CAST(COUNT(DISTINCT account_name) AS FLOAT), 0) AS Penetration_Percentage_Eng_No_Dbu
# MAGIC
# MAGIC FROM 
# MAGIC     engagement_metrics
# MAGIC GROUP BY ALL
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select
# MAGIC engagement_group,
# MAGIC region,
# MAGIC sub_region,
# MAGIC Date_Eng,
# MAGIC sum(engagements)
# MAGIC from --main.it_aibi_gold.FactFunnelAccountReporting_CSQL_gold
# MAGIC main.it_aibi_silver.FactFunnelAccountReporting_CSQL_silver
# MAGIC where fiscal_year_quarter_eng='2025Q2'
# MAGIC and date_eng!='2024-05-01'
# MAGIC and engagement_group in ('Form Fill')
# MAGIC and region='AMER'
# MAGIC --and region is not null
# MAGIC group by all
# MAGIC order by engagement_group, date_eng, region, sub_region

# COMMAND ----------


