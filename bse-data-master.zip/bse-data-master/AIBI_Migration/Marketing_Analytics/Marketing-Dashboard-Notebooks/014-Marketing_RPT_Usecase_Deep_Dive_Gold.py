# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.marketing_rpt_usecase_deep_dive_gold 
# MAGIC
# MAGIC SELECT audience_persona,
# MAGIC     business_unit,
# MAGIC     campaign_category,
# MAGIC     channel_detail,
# MAGIC     event_asset_type,
# MAGIC     program_name,
# MAGIC     tactic_name,
# MAGIC     touch_month,
# MAGIC     mql_before_usecase,
# MAGIC     sal_before_usecase,
# MAGIC     dim_account_id,
# MAGIC     account_name,
# MAGIC     event_asset,
# MAGIC     usecase_id,
# MAGIC     stage,
# MAGIC     is_contact,
# MAGIC     usecase_name,
# MAGIC     primary_lead_or_contact_id,
# MAGIC     COUNT(DISTINCT primary_lead_or_contact_id) AS Contact_Count,
# MAGIC     COUNT(DISTINCT count_campaign_id) AS Campaign_Count
# MAGIC FROM it_aibi_silver.marketing_rpt_usecase_deep_dive_silver
# MAGIC WHERE usecase_name="Gen AI for Commercial" and month(touch_month)=1 and audience_persona='CDO'
# MAGIC GROUP BY ALL
