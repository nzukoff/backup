# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.fact_funnel_lead_reporting as
# MAGIC
# MAGIC SELECT 
# MAGIC     rmad.account_owner_role,
# MAGIC     rmad.account_group,
# MAGIC     rmfv.is_creator_owner_role_ae,
# MAGIC     rmfv.is_creator_owner_role_xdr,
# MAGIC     rmfv.date_cadence,
# MAGIC     rmfv.index_date_name,
# MAGIC     rmfv.index_date,
# MAGIC     rmfv.dim_account_id,
# MAGIC     rmfv.leadstatus,
# MAGIC     rmfv.mql_date_bucket,
# MAGIC     CASE 
# MAGIC         WHEN rmfv.leadstatus = 'Outreach Complete Connected' 
# MAGIC         AND rmfv.index_date_name = 'MQL Date' 
# MAGIC         AND rmfv.index_date IS NOT NULL 
# MAGIC         THEN rmfv.mql_count
# MAGIC         ELSE 0
# MAGIC     END AS outreach_complete_connected_mql_count,
# MAGIC     CASE 
# MAGIC         WHEN rmfv.leadstatus = 'Open' 
# MAGIC         AND rmfv.index_date_name = 'MQL Date' 
# MAGIC         AND rmfv.index_date IS NOT NULL 
# MAGIC         THEN rmfv.mql_count
# MAGIC         ELSE 0
# MAGIC     END AS open_mql_count,
# MAGIC     CASE 
# MAGIC         WHEN rmfv.leadstatus = 'Unknown' 
# MAGIC         AND rmfv.index_date_name = 'MQL Date' 
# MAGIC         AND rmfv.index_date IS NOT NULL 
# MAGIC         THEN rmfv.mql_count
# MAGIC         ELSE 0
# MAGIC     END AS unknown_mql_count,
# MAGIC     CASE 
# MAGIC         WHEN rmfv.leadstatus = 'Other' 
# MAGIC         AND rmfv.index_date_name = 'MQL Date' 
# MAGIC         AND rmfv.index_date IS NOT NULL 
# MAGIC         THEN rmfv.mql_count
# MAGIC         ELSE 0
# MAGIC     END AS other_mql_count,
# MAGIC     CASE 
# MAGIC         WHEN rmfv.leadstatus = 'Outreach Completed Did Not Connect' 
# MAGIC         AND rmfv.index_date_name = 'MQL Date' 
# MAGIC         AND rmfv.index_date IS NOT NULL 
# MAGIC         THEN rmfv.mql_count
# MAGIC         ELSE 0
# MAGIC     END AS outreach_completed_not_connected_mql_count,
# MAGIC     CASE 
# MAGIC         WHEN rmfv.leadstatus = 'Could Not Sequence' 
# MAGIC         AND rmfv.index_date_name = 'MQL Date' 
# MAGIC         AND rmfv.index_date IS NOT NULL 
# MAGIC         THEN rmfv.mql_count
# MAGIC         ELSE 0
# MAGIC     END AS could_not_sequence_mql_count,
# MAGIC     CASE 
# MAGIC         WHEN rmfv.leadstatus = 'Attempting Contact' 
# MAGIC         AND rmfv.index_date_name = 'MQL Date' 
# MAGIC         AND rmfv.index_date IS NOT NULL 
# MAGIC         THEN rmfv.mql_count
# MAGIC         ELSE 0
# MAGIC     END AS attempting_contact_mql_count,
# MAGIC     CASE 
# MAGIC         WHEN rmfv.leadstatus = 'Suspect' 
# MAGIC         AND rmfv.index_date_name = 'MQL Date' 
# MAGIC         AND rmfv.index_date IS NOT NULL 
# MAGIC         THEN rmfv.mql_count
# MAGIC         ELSE 0
# MAGIC     END AS suspect_mql_count,
# MAGIC     CASE 
# MAGIC         WHEN rmfv.leadstatus = 'Connected' 
# MAGIC         AND rmfv.index_date_name = 'MQL Date' 
# MAGIC         AND rmfv.index_date IS NOT NULL 
# MAGIC         THEN rmfv.mql_count
# MAGIC         ELSE 0
# MAGIC     END AS connected_mql_count,
# MAGIC     rmfv.audience_persona,
# MAGIC     rmfv.last_touch_channel,
# MAGIC     rmfv.last_touch_campaign,
# MAGIC     rmfv.last_touch_subtype,
# MAGIC     rmfv.last_touch_campaign_category,
# MAGIC     rmfv.lead_owner_name,
# MAGIC     rmfv.lead_owner_role,
# MAGIC     rmfv.follow_up_team,
# MAGIC     CASE
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'AMER SDR' THEN 'AMER SDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'AMER BDR' THEN 'AMER BDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'AMER PDR' THEN 'AMER PDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'AMER GDR' THEN 'AMER GDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'EMEA SDR' THEN 'EMEA SDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'EMEA BDR' THEN 'EMEA BDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'EMEA PDR' THEN 'EMEA PDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'EMEA GDR' THEN 'EMEA GDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'APJ SDR' THEN 'APJ SDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'APJ BDR' THEN 'APJ BDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'APJ PDR' THEN 'APJ PDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'APJ GDR' THEN 'APJ GDR'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'AMER XDR Manager' THEN 'AMER XDR Manager'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'APJ XDR Manager' THEN 'APJ XDR Manager'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'EMEA XDR Manager' THEN 'EMEA XDR Manager'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'AMER AE' THEN 'AMER AE'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'APJ AE' THEN 'APJ AE'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'EMEA AE' THEN 'EMEA AE'
# MAGIC         WHEN TRIM(rmfv.follow_up_team) = 'Uncategorized' THEN 'Uncategorized'
# MAGIC         ELSE 'Other'
# MAGIC     END AS categorized_follow_up_team,
# MAGIC     rmfv.end_state,
# MAGIC     rmfv.disposition_reason,
# MAGIC     rmfv.has_phone_number,
# MAGIC     CASE
# MAGIC         WHEN rmfv.has_phone_number = 1 THEN 'Yes'
# MAGIC         ELSE 'No'
# MAGIC     END AS has_phone,
# MAGIC     rmfv.details,
# MAGIC     rmfv.mql_count,
# MAGIC     rmfv.sal_count,
# MAGIC     rmfv.u1_funnel,
# MAGIC     rmfv.u1_funnel_validated,
# MAGIC     rmfv.u2_funnel,
# MAGIC     rmfv.u3_funnel,
# MAGIC     rmfv.mqa_account_id,
# MAGIC     COUNT(DISTINCT rmfv.mqa_account_id) AS distinct_mqa_account_count,
# MAGIC     rmfv.saa_account_id,
# MAGIC     COUNT(DISTINCT rmfv.saa_account_id) AS saa_count,
# MAGIC     CASE 
# MAGIC         WHEN COUNT(DISTINCT rmfv.mqa_account_id) = 0 THEN NULL 
# MAGIC         ELSE COUNT(DISTINCT rmfv.saa_account_id) * 1.0 / COUNT(DISTINCT rmfv.mqa_account_id) 
# MAGIC     END AS mqa_saa_ratio,
# MAGIC     CASE 
# MAGIC         WHEN COUNT(DISTINCT rmfv.mqa_account_id) = 0 THEN NULL 
# MAGIC         ELSE COUNT(DISTINCT rmfv.u1_account_id) * 1.0 / COUNT(DISTINCT rmfv.mqa_account_id) 
# MAGIC     END AS mqa_u1_ratio,
# MAGIC     CASE 
# MAGIC         WHEN COUNT(DISTINCT rmfv.mqa_account_id) = 0 THEN NULL 
# MAGIC         ELSE COUNT(DISTINCT rmfv.u2_account_id) * 1.0 / COUNT(DISTINCT rmfv.mqa_account_id) 
# MAGIC     END AS mqa_u2_ratio,
# MAGIC     CASE 
# MAGIC         WHEN SUM(rmfv.mql_count) = 0 THEN NULL 
# MAGIC         ELSE SUM(rmfv.sal_count) * 1.0 / SUM(rmfv.mql_count) 
# MAGIC     END AS mql_sal_ratio,
# MAGIC     rmfv.u1_account_id,
# MAGIC     rmfv.u2_account_id,
# MAGIC     rmfv.u3_account_id,
# MAGIC     COUNT(DISTINCT rmfv.u1_account_id) AS u1_account_count,
# MAGIC     COUNT(DISTINCT rmfv.u2_account_id) AS u2_account_count,
# MAGIC     COUNT(DISTINCT rmfv.u3_account_id) AS u3_account_count,
# MAGIC     rmfv.avg_days_mql_to_u1,
# MAGIC     rmfv.median_days_mql_to_u1,
# MAGIC     rmfv.avg_days_mql_to_u2,
# MAGIC     rmfv.median_days_mql_to_u2,
# MAGIC     CASE 
# MAGIC         WHEN SUM(rmfv.mql_count) = 0 THEN NULL 
# MAGIC         ELSE SUM(rmfv.u1_funnel) * 1.0 / SUM(rmfv.mql_count) 
# MAGIC     END AS mql_u1_ratio,
# MAGIC     CASE 
# MAGIC         WHEN SUM(rmfv.mql_count) = 0 THEN NULL 
# MAGIC         ELSE SUM(rmfv.u1_funnel_validated) * 1.0 / SUM(rmfv.mql_count) 
# MAGIC     END AS mql_vu1_ratio,
# MAGIC     CASE 
# MAGIC         WHEN SUM(rmfv.mql_count) = 0 THEN NULL 
# MAGIC         ELSE SUM(rmfv.u2_funnel) * 1.0 / SUM(rmfv.mql_count) 
# MAGIC     END AS mql_u2_ratio,
# MAGIC     CASE 
# MAGIC         WHEN COUNT(DISTINCT rmfv.saa_account_id) = 0 THEN NULL 
# MAGIC         ELSE COUNT(DISTINCT rmfv.u1_account_id) * 1.0 / COUNT(DISTINCT rmfv.saa_account_id) 
# MAGIC     END AS saa_u1_ratio,
# MAGIC     CASE 
# MAGIC         WHEN COUNT(DISTINCT rmfv.saa_account_id) = 0 THEN NULL 
# MAGIC         ELSE COUNT(DISTINCT rmfv.u2_account_id) * 1.0 / COUNT(DISTINCT rmfv.saa_account_id) 
# MAGIC     END AS saa_u2_ratio,
# MAGIC     CASE 
# MAGIC         WHEN SUM(rmfv.sal_count) = 0 THEN NULL 
# MAGIC         ELSE SUM(rmfv.u1_funnel) * 1.0 / SUM(rmfv.sal_count) 
# MAGIC     END AS sal_u1_ratio,
# MAGIC     CASE 
# MAGIC         WHEN SUM(rmfv.sal_count) = 0 THEN NULL 
# MAGIC         ELSE SUM(rmfv.u2_funnel) * 1.0 / SUM(rmfv.sal_count) 
# MAGIC     END AS sal_u2_ratio,
# MAGIC     CASE 
# MAGIC         WHEN SUM(rmfv.sal_count) = 0 THEN NULL 
# MAGIC         ELSE SUM(rmfv.u1_funnel_validated) * 1.0 / SUM(rmfv.sal_count) 
# MAGIC     END AS sal_vu1_ratio,
# MAGIC     CASE 
# MAGIC         WHEN SUM(rmfv.u1_funnel) = 0 THEN NULL 
# MAGIC         ELSE SUM(rmfv.u2_funnel) * 1.0 / SUM(rmfv.u1_funnel) 
# MAGIC     END AS u1_u2_ratio,
# MAGIC     CASE 
# MAGIC         WHEN COUNT(DISTINCT rmfv.u1_account_id) = 0 THEN NULL 
# MAGIC         ELSE COUNT(DISTINCT rmfv.u2_account_id) * 1.0 / COUNT(DISTINCT rmfv.u1_account_id) 
# MAGIC     END AS u1_u2_account_ratio,
# MAGIC     CASE 
# MAGIC         WHEN SUM(rmfv.u2_funnel) = 0 THEN NULL 
# MAGIC         ELSE SUM(rmfv.u3_funnel) * 1.0 / SUM(rmfv.u2_funnel) 
# MAGIC     END AS u2_u3_ratio,
# MAGIC     CASE 
# MAGIC         WHEN COUNT(DISTINCT rmfv.u2_account_id) = 0 THEN NULL 
# MAGIC         ELSE COUNT(DISTINCT rmfv.u3_account_id) * 1.0 / COUNT(DISTINCT rmfv.u2_account_id) 
# MAGIC     END AS u2_u3_account_ratio,
# MAGIC     rmad.account_name, 
# MAGIC     rmad.account_status,
# MAGIC     rmad.country, 
# MAGIC     rmad.dbx, 
# MAGIC     rmad.business_unit, 
# MAGIC     rmad.region, 
# MAGIC     rmad.subregion_level_1,
# MAGIC     rmad.subregion_level_2, 
# MAGIC     rmad.subregion_level_3, 
# MAGIC     rmad.account_spend_tier, 
# MAGIC     rmad.account_record_type
# MAGIC FROM 
# MAGIC     main.marketing_lakehouse.rpt_mpd_funnel_view rmfv
# MAGIC LEFT JOIN 
# MAGIC     main.marketing_lakehouse.rpt_mpd_account_details rmad
# MAGIC ON 
# MAGIC     rmfv.dim_account_id = rmad.dim_account_id
# MAGIC GROUP BY 
# MAGIC     ALL
