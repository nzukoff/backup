# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.Fact_Funnel_Usecase_Reporting
# MAGIC
# MAGIC SELECT
# MAGIC     usecase_id,
# MAGIC     usecase_name,
# MAGIC     stage,
# MAGIC     dim_account_id,
# MAGIC     account_name,
# MAGIC     business_unit,
# MAGIC     tactic_name,
# MAGIC     program_name,
# MAGIC     campaign_category,
# MAGIC     event_asset_type,
# MAGIC     channel_detail,
# MAGIC     event_asset,
# MAGIC     audience_persona,
# MAGIC     primary_lead_or_contact_id,
# MAGIC     COALESCE(SUM(attribution_amount) / SUM(SUM(attribution_amount)) OVER (), 0) AS att_percent,
# MAGIC     COUNT(DISTINCT primary_lead_or_contact_id) AS number_of_leads,
# MAGIC     touch_month,
# MAGIC     usecase_created_month,
# MAGIC     u1_stage_date,
# MAGIC     u2_stage_date,
# MAGIC     is_contact,
# MAGIC     attribution_amount,
# MAGIC     amount,
# MAGIC     count_campaign_id,
# MAGIC     mql_before_usecase,
# MAGIC     sal_before_usecase
# MAGIC FROM
# MAGIC     main.marketing_lakehouse.rpt_usecase_deep_dive
# MAGIC GROUP BY
# MAGIC ALL
