# Databricks notebook source
print("Gold is not having any data")
