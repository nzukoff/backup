# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.FactFunnelAccountReporting_CSQL_silver
# MAGIC
# MAGIC WITH Engagement AS (
# MAGIC     SELECT 
# MAGIC         Att.*, 
# MAGIC         CAST(NULL AS STRING) AS channel_type, 
# MAGIC         CAST(NULL AS STRING) AS channel_detail, 
# MAGIC         eng.* EXCEPT (dim_account_id, date_month, source_name, marketing_channel), 
# MAGIC         DDA.Date AS Date_Eng, 
# MAGIC         DDA.fiscal_year_quarter AS fiscal_year_quarter_eng, 
# MAGIC         DDA.fiscalYear AS fiscalYear_eng, 
# MAGIC         DDA.Date AS Date_oua, 
# MAGIC         DDA.fiscal_month_start_date, 
# MAGIC         DDA.fiscal_year_quarter AS fiscal_year_quarter_oua, 
# MAGIC         DDA.fiscalYear AS fiscalYear_oua, 
# MAGIC         CAST(NULL AS INT) AS mql_unit, 
# MAGIC         CAST(NULL AS INT) AS nnn_unit, 
# MAGIC         CAST(NULL AS INT) AS trial_unit, 
# MAGIC         CAST(NULL AS INT) AS serverless_unit, 
# MAGIC         CAST(NULL AS INT) AS uc_unit, 
# MAGIC         CAST(NULL AS DECIMAL) AS u1_amount, 
# MAGIC         CAST(NULL AS INT) AS u1_unit, 
# MAGIC         CAST(NULL AS DECIMAL) AS u2_amount, 
# MAGIC         CAST(NULL AS INT) AS u2_unit, 
# MAGIC         CAST(NULL AS DECIMAL) AS u3_amount, 
# MAGIC         CAST(NULL AS INT) AS u3_unit, 
# MAGIC         CAST(NULL AS DECIMAL) AS u6_amount, 
# MAGIC         CAST(NULL AS INT) AS u6_unit 
# MAGIC     FROM 
# MAGIC         main.marketing_lakehouse.rpt_account_attributes Att 
# MAGIC     INNER JOIN 
# MAGIC         main.marketing_lakehouse.rpt_account_engagement_metrics eng 
# MAGIC     ON 
# MAGIC         Att.dim_account_id = eng.dim_account_id 
# MAGIC     INNER JOIN 
# MAGIC         main.marketing_lakehouse.dim_date_attributes DDA 
# MAGIC     ON 
# MAGIC         eng.date_month = DDA.date
# MAGIC ), 
# MAGIC Outcomes AS (
# MAGIC     SELECT 
# MAGIC         Att.*, 
# MAGIC         oua.channel_type, 
# MAGIC         oua.channel_detail, 
# MAGIC         CAST(NULL AS INT) AS total_unique_contacts, 
# MAGIC         oua.program_name, 
# MAGIC         oua.event_asset, 
# MAGIC         oua.engagement_group, 
# MAGIC         oua.engagement_type, 
# MAGIC         CAST(NULL AS INT) AS engagements, 
# MAGIC         CAST(NULL AS INT) AS total_unique_engaged_contacts_t30d, 
# MAGIC         CAST(NULL AS INT) AS total_unique_engaged_contacts_t60d, 
# MAGIC         CAST(NULL AS INT) AS total_unique_engaged_contacts_t90d, 
# MAGIC         DDA.Date AS Date_Eng, 
# MAGIC         DDA.fiscal_year_quarter AS fiscal_year_quarter_eng, 
# MAGIC         DDA.fiscalYear AS fiscalYear_eng, 
# MAGIC         DDA.Date AS Date_oua, 
# MAGIC         DDA.fiscal_month_start_date, 
# MAGIC         DDA.fiscal_year_quarter AS fiscal_year_quarter_oua, 
# MAGIC         DDA.fiscalYear AS fiscalYear_oua, 
# MAGIC         oua.mql_unit, 
# MAGIC         oua.nnn_unit, 
# MAGIC         oua.trial_unit, 
# MAGIC         oua.serverless_unit, 
# MAGIC         oua.uc_unit, 
# MAGIC         oua.u1_amount, 
# MAGIC         oua.u1_unit, 
# MAGIC         oua.u2_amount, 
# MAGIC         oua.u2_unit, 
# MAGIC         oua.u3_amount, 
# MAGIC         oua.u3_unit, 
# MAGIC         oua.u6_amount, 
# MAGIC         oua.u6_unit 
# MAGIC     FROM 
# MAGIC         main.marketing_lakehouse.rpt_account_attributes Att 
# MAGIC     RIGHT JOIN 
# MAGIC         main.marketing_lakehouse.rpt_mpd_performance_deep_dive oua 
# MAGIC     ON 
# MAGIC         Att.dim_account_id = oua.dim_account_id 
# MAGIC     LEFT JOIN 
# MAGIC         main.marketing_lakehouse.dim_date_attributes DDA 
# MAGIC     ON 
# MAGIC         oua.fiscal_month_start_date = DDA.date
# MAGIC ) 
# MAGIC SELECT * 
# MAGIC FROM Engagement 
# MAGIC UNION ALL 
# MAGIC SELECT * 
# MAGIC FROM Outcomes
# MAGIC
