# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.rpt_mpd_executive_snapshot_silver AS
# MAGIC SELECT 
# MAGIC     *
# MAGIC FROM 
# MAGIC     main.marketing_lakehouse.rpt_mpd_executive_snapshot
# MAGIC
# MAGIC
# MAGIC
# MAGIC
