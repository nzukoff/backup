# Databricks notebook source
print("Gold Data is not there")
