# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE  main.it_aibi_silver.marketing_rpt_usecase_deep_dive_silver as
# MAGIC select * from main.marketing_lakehouse.rpt_usecase_deep_dive
