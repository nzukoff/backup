# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.fact_funnel_reporting_performance as
# MAGIC
# MAGIC SELECT 
# MAGIC     rmpdd.week_start_date,
# MAGIC     rmpdd.fiscal_month_start_date,
# MAGIC     rmpdd.reporting_group,
# MAGIC     rmpdd.dim_account_id,
# MAGIC     CASE 
# MAGIC         WHEN rmpdd.dim_account_id IS NULL THEN 'Unmatched'
# MAGIC         WHEN rmpdd.dim_account_id IS NOT NULL AND rmad.account_owner_role = 'Unknown' THEN 'Unassigned'
# MAGIC         ELSE 'Assigned'
# MAGIC     END AS Account_Segment_Copy_2,
# MAGIC     rmpdd.record_type,
# MAGIC     rmpdd.engagement_type,
# MAGIC     rmpdd.product_type,
# MAGIC     rmpdd.usecase_name,
# MAGIC     rmpdd.usecase_source_type,
# MAGIC     rmpdd.usecase_created_by,
# MAGIC     rmpdd.execution_team,
# MAGIC     rmpdd.tactic_partners,
# MAGIC     rmpdd.tactic_vertical,
# MAGIC     rmpdd.campaign_category,
# MAGIC     rmpdd.tactic_owner,
# MAGIC     rmpdd.tactic_name,
# MAGIC     rmpdd.event_asset_details,
# MAGIC     rmpdd.event_asset,
# MAGIC     rmpdd.event_asset_type,
# MAGIC     rmpdd.program_name,
# MAGIC     rmpdd.program_group,
# MAGIC     rmpdd.sfdc_campaign_name,
# MAGIC     rmpdd.program_owner,
# MAGIC     rmpdd.channel_detail,
# MAGIC     rmpdd.channel_type,
# MAGIC     rmpdd.end_date,
# MAGIC     rmpdd.topic,
# MAGIC     rmpdd.targeted_audience,
# MAGIC     rmpdd.lead_source,
# MAGIC     rmpdd.lead_status,
# MAGIC     rmpdd.audience_persona,
# MAGIC     rmpdd.account_owner_ae_type,
# MAGIC     rmpdd.is_zero_one_account,
# MAGIC     rmpdd.zero_one_unit,
# MAGIC     rmpdd.member_status,
# MAGIC     CASE 
# MAGIC         WHEN rmpdd.audience_persona IN ('Others', 'CDO') THEN 0
# MAGIC         WHEN rmpdd.audience_persona IN ('CIO', 'Data Scientist') THEN 1
# MAGIC         ELSE 2
# MAGIC     END AS Column_Value_Audience_Persona_group,
# MAGIC     CASE 
# MAGIC         WHEN rmpdd.audience_persona IN ('BI', 'Other', 'Business Execs') THEN 'Other'
# MAGIC         ELSE rmpdd.audience_persona
# MAGIC     END AS Persona_Cal_Other,
# MAGIC     CASE 
# MAGIC         WHEN 'Campaign Name' = 'Campaign Name' THEN rmpdd.tactic_name
# MAGIC         WHEN 'Campaign Theme' = 'Campaign Theme' THEN rmpdd.campaign_category
# MAGIC         WHEN 'Persona' = 'Persona' THEN 
# MAGIC             CASE 
# MAGIC                 WHEN rmpdd.audience_persona IN ('BI', 'Other', 'Business Execs') THEN 'Other'
# MAGIC                 ELSE rmpdd.audience_persona
# MAGIC             END
# MAGIC         WHEN 'Event/Asset Family' = 'Event/Asset Family' THEN rmpdd.event_asset_details
# MAGIC         WHEN 'Program Name' = 'Program Name' THEN rmpdd.program_name
# MAGIC         WHEN 'Targeted Audience' = 'Targeted Audience' THEN rmpdd.targeted_audience
# MAGIC     END AS Personal_DD_cal_1,
# MAGIC     'FY' || CAST(YEAR(DATEADD(MONTH, 11, rmpdd.fiscal_month_start_date)) AS VARCHAR(4)) || ' Q' ||
# MAGIC     CAST(QUARTER(DATEADD(MONTH, 11, rmpdd.fiscal_month_start_date)) AS VARCHAR(1)) AS quarter_value,
# MAGIC     rmpdd.databricks_vertical,
# MAGIC     rmpdd.xdr_role,
# MAGIC     rmpdd.cdo_cio_cto,
# MAGIC     rmpdd.details,
# MAGIC     rmpdd.engagement_group,
# MAGIC     rmpdd.team_target_setting,
# MAGIC     rmpdd.responder_audience_id,
# MAGIC     rmpdd.engagement,
# MAGIC     rmpdd.mql_unit,
# MAGIC     rmpdd.nnn_unit,
# MAGIC     rmpdd.u1_unit,
# MAGIC     rmpdd.u2_unit,
# MAGIC     rmpdd.u3_unit,
# MAGIC     rmpdd.u6_unit,
# MAGIC     rmpdd.u1_amount,
# MAGIC     rmpdd.u2_amount,
# MAGIC     rmpdd.u3_amount,
# MAGIC     rmpdd.u6_amount,
# MAGIC     rmpdd.uc_unit,
# MAGIC     rmpdd.serverless_unit,
# MAGIC     rmpdd.trial_unit,
# MAGIC     rmpdd.1kMRR_unit,
# MAGIC     rmpdd.custom_lead_quality,
# MAGIC     rmpdd.email_flag,
# MAGIC     rmpdd.is_dbsql_adopted,
# MAGIC     CASE 
# MAGIC         WHEN rmpdd.is_dbsql_adopted = 'true' THEN 'DBSQL Adoption Campaign'
# MAGIC         WHEN rmpdd.is_uc_adopted = 'true' THEN 'UC Adoption Campaign'
# MAGIC         WHEN rmpdd.Program_Name LIKE '%GenAI%' 
# MAGIC              OR rmpdd.Program_Name LIKE '%LLM%' 
# MAGIC              OR rmpdd.Program_Name LIKE '%Mosaic%' 
# MAGIC              OR rmpdd.Program_Name LIKE '%Dolly%' THEN 'GenAI Campaign'
# MAGIC         ELSE 'Non-Product Specific Campaign'
# MAGIC     END AS Campaign_Product,
# MAGIC     rmpdd.is_uc_adopted,
# MAGIC     rmpdd.qnnn_unit,
# MAGIC     rmpdd.usecase_id,
# MAGIC     rmpdd.uc_pipe_gen_amount_u2,
# MAGIC     rmpdd.dbsql_pipe_gen_amount_u2,
# MAGIC     rmpdd.nonmct_pipe_gen_amount_u2,
# MAGIC     rmpdd.mct_pipe_gen_amount_u2,
# MAGIC     rmpdd.genai_pipe_amount_u2,
# MAGIC     rmpdd.uc_pipe_gen_amount,
# MAGIC     rmpdd.dbsql_pipe_gen_amount,
# MAGIC     rmpdd.nonmct_pipe_gen_amount,
# MAGIC     rmpdd.mct_pipe_gen_amount,
# MAGIC     rmpdd.genai_pipe_amount,
# MAGIC     rmpdd.uc_pipe_gen_unit_u2,
# MAGIC     rmpdd.dbsql_pipe_gen_unit_u2,
# MAGIC     rmpdd.nonmct_pipe_gen_unit_u2,
# MAGIC     rmpdd.mct_pipe_gen_unit_u2,
# MAGIC     rmpdd.genai_pipe_unit_u2,
# MAGIC     rmpdd.uc_pipe_gen_unit_u3,
# MAGIC     rmpdd.dbsql_pipe_gen_unit_u3,
# MAGIC     rmpdd.nonmct_pipe_gen_unit_u3,
# MAGIC     rmpdd.mct_pipe_gen_unit_u3,
# MAGIC     rmpdd.genai_pipe_unit_u3,
# MAGIC     rmpdd.product_adoption_campaign,
# MAGIC     rmad.account_name, 
# MAGIC     rmad.account_status,
# MAGIC     rmad.country,
# MAGIC     rmad.dbx,
# MAGIC     rmad.business_unit, 
# MAGIC     rmad.region, 
# MAGIC     rmad.subregion_level_1,
# MAGIC     rmad.subregion_level_2, 
# MAGIC     rmad.subregion_level_3, 
# MAGIC     rmad.account_spend_tier, 
# MAGIC     rmad.account_owner_name, 
# MAGIC     rmad.account_owner_role, 
# MAGIC     CASE 
# MAGIC         WHEN rmad.business_unit IS NULL OR rmad.business_unit = 'Unknown' OR rmpdd.dim_account_id IS NULL THEN 'Unmatched'
# MAGIC         WHEN rmpdd.dim_account_id IS NOT NULL AND rmad.account_owner_role IS NULL THEN 'Unassigned'
# MAGIC         ELSE 'Assigned'
# MAGIC     END AS Account_Segment,
# MAGIC     rmad.global_top_account, 
# MAGIC     rmad.databricks_vertical_segment, 
# MAGIC     rmad.cloud, 
# MAGIC     rmad.vertical,
# MAGIC     COUNT(DISTINCT CASE WHEN rmpdd.reporting_group = 'Responder' THEN rmpdd.dim_account_id END) AS unique_account_form_fill,
# MAGIC     COUNT(DISTINCT CASE WHEN rmpdd.reporting_group = 'Responder' THEN rmpdd.responder_audience_id END) AS unique_responder_form_fill,
# MAGIC     SUM(CASE WHEN rmpdd.reporting_group = 'Engagement' AND rmpdd.engagement_group = 'Form Fill' THEN rmpdd.engagement ELSE 0 END) AS form_fill,
# MAGIC     COUNT(DISTINCT CASE WHEN rmpdd.reporting_group = 'Engagement' THEN rmpdd.dim_account_id END) AS unique_account_attributable_engagement,
# MAGIC     COUNT(DISTINCT CASE WHEN rmpdd.engagement > 0 THEN rmpdd.dim_account_id END) AS unique_accounts,
# MAGIC     COUNT(DISTINCT rmpdd.dim_account_id) AS total_accounts
# MAGIC FROM 
# MAGIC     main.marketing_lakehouse.rpt_mpd_performance_deep_dive rmpdd
# MAGIC LEFT JOIN 
# MAGIC     main.marketing_lakehouse.rpt_mpd_account_details rmad
# MAGIC ON 
# MAGIC     rmpdd.dim_account_id = rmad.dim_account_id
# MAGIC GROUP BY ALL
# MAGIC

# COMMAND ----------


