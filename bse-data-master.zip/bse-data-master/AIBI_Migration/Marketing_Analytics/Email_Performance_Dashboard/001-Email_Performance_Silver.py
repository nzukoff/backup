# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.email_performance_silver
# MAGIC
# MAGIC select
# MAGIC account_status_c,
# MAGIC activity_date,
# MAGIC asset_family,
# MAGIC audience_persona,
# MAGIC BU_plus_1,
# MAGIC BU_plus_2,
# MAGIC business_unit_c,
# MAGIC cloud,
# MAGIC country,
# MAGIC cse_tier_c,
# MAGIC databricks_vertical_map_new_c,
# MAGIC dbx_account_type,
# MAGIC job_function_c,
# MAGIC lead_source,
# MAGIC lead_created_date,
# MAGIC persona_c,
# MAGIC program,
# MAGIC region_c,
# MAGIC seniority_level_c,
# MAGIC team,
# MAGIC workspace_user_type_c,
# MAGIC click_individuals,
# MAGIC clicks,
# MAGIC delivers,
# MAGIC opens,
# MAGIC sends,
# MAGIC unsub,
# MAGIC title_c,
# MAGIC custom_cdo_cio_cto,
# MAGIC deliver_individuals,
# MAGIC open_individuals,
# MAGIC send_individuals,
# MAGIC unsub_individuals,
# MAGIC cost_per_email,
# MAGIC nurture_score
# MAGIC from main.marketing_lakehouse.gold_email_performance
# MAGIC
