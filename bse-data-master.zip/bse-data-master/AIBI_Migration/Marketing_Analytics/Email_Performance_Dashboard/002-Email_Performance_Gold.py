# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.email_performance_gold as
# MAGIC
# MAGIC SELECT
# MAGIC     account_status_c,
# MAGIC     activity_date,
# MAGIC     asset_family,
# MAGIC     audience_persona,
# MAGIC     BU_plus_1,
# MAGIC     BU_plus_2,
# MAGIC     business_unit_c,
# MAGIC     cloud,
# MAGIC     country,
# MAGIC     cse_tier_c,
# MAGIC     databricks_vertical_map_new_c,
# MAGIC     dbx_account_type,
# MAGIC     job_function_c,
# MAGIC     lead_source,
# MAGIC     lead_created_date,
# MAGIC     persona_c,
# MAGIC     program,
# MAGIC     region_c,
# MAGIC     seniority_level_c,
# MAGIC     team,
# MAGIC     workspace_user_type_c,
# MAGIC     click_individuals,
# MAGIC     clicks,
# MAGIC     delivers,
# MAGIC     opens,
# MAGIC     sends,
# MAGIC     unsub,
# MAGIC     custom_cdo_cio_cto as custom_c3,
# MAGIC     deliver_individuals,
# MAGIC     open_individuals,
# MAGIC     send_individuals,
# MAGIC     unsub_individuals,
# MAGIC     cost_per_email,
# MAGIC     nurture_score,
# MAGIC     CASE
# MAGIC         WHEN LOWER(title_c) LIKE "cio" THEN "CIO"
# MAGIC         WHEN LOWER(title_c) LIKE "cdo" THEN "CDO"
# MAGIC         WHEN LOWER(title_c) LIKE "cao" THEN "CAO"
# MAGIC         WHEN LOWER(title_c) LIKE "chief information officer" THEN "CIO"
# MAGIC         WHEN LOWER(title_c) LIKE "chief data officer" THEN "CDO"
# MAGIC         WHEN LOWER(title_c) LIKE "chief analytics officer" THEN "CAO"
# MAGIC         WHEN LOWER(title_c) LIKE "chief data and analytics officer" THEN "CDAO"
# MAGIC         WHEN LOWER(title_c) LIKE "chief data & analytics officer" THEN "CDAO"
# MAGIC         WHEN LOWER(title_c) LIKE "chief data, analytics officer" THEN "CDAO"
# MAGIC         ELSE "Other"
# MAGIC     END AS c4_exec_titles,
# MAGIC     CASE
# MAGIC         WHEN LOWER(program) LIKE '%confirm%' THEN 'Confirmation'
# MAGIC         WHEN LOWER(program) LIKE '%test%' THEN 'Test'
# MAGIC         WHEN LOWER(program) LIKE '%response%' OR LOWER(program) LIKE '%auto respon%' THEN 'Auto Response'
# MAGIC         WHEN LOWER(program) LIKE '%no show%' OR LOWER(program) LIKE '%sorry%' THEN 'No Show'
# MAGIC         WHEN LOWER(program) LIKE '%thank%' OR LOWER(program) LIKE '% ty%' OR LOWER(program) LIKE '%.ty.%' THEN 'Thank You'
# MAGIC         WHEN LOWER(program) LIKE '%reject%' THEN 'Rejected'
# MAGIC         WHEN LOWER(program) LIKE '%cancellation%' THEN 'Cancellation'
# MAGIC         WHEN LOWER(program) LIKE '%waitlist%' OR LOWER(program) LIKE '%pending%' THEN 'Waitlisted'
# MAGIC         WHEN LOWER(program) LIKE '%follow%' THEN 'Follow Up'
# MAGIC         WHEN LOWER(program) LIKE '%instructions%' THEN 'Instructions'
# MAGIC         WHEN LOWER(program) LIKE '%reminder%' OR LOWER(program) LIKE '%digest%' THEN 'Reminder'
# MAGIC         WHEN LOWER(program) LIKE '%contact us%' THEN 'Contact Us'
# MAGIC         WHEN LOWER(program) LIKE '%operational%' THEN 'Other Operational'
# MAGIC         WHEN LOWER(program) LIKE '%null%' THEN 'Null'
# MAGIC         WHEN program IS NULL THEN 'Null'
# MAGIC         WHEN LOWER(program) LIKE '%sales internal%' OR LOWER(program) LIKE '%internal sales%' THEN 'Sales Internal'
# MAGIC         WHEN LOWER(program) LIKE '%opt-in%' OR LOWER(program) LIKE '%opt in%' THEN 'Opt-In'
# MAGIC         WHEN LOWER(program) LIKE '%voucher%' THEN 'Voucher'
# MAGIC         ELSE 'Promotional'
# MAGIC     END AS email_type,
# MAGIC     CASE
# MAGIC         WHEN DATEDIFF(DAY, lead_created_date, CURRENT_DATE) > 60 THEN '> 60 Days'
# MAGIC         WHEN DATEDIFF(DAY, lead_created_date, CURRENT_DATE) > 30 AND DATEDIFF(DAY, lead_created_date, CURRENT_DATE) <= 60 THEN 'Last 31-60 Days'
# MAGIC         WHEN DATEDIFF(DAY, lead_created_date, CURRENT_DATE) <= 30 THEN 'Last 30 Days'
# MAGIC         ELSE NULL
# MAGIC     END AS lead_create_date_range,
# MAGIC     CASE
# MAGIC         WHEN program LIKE '%Pre-Trial%' OR program LIKE '%Nuture-Pre-Trial%' THEN 'Pre-Trial'
# MAGIC         WHEN program LIKE '%Recycled MQL Nurture%' THEN 'Recycled MQL'
# MAGIC         WHEN program LIKE '%Pre-MQL Nurture%' THEN 'Pre-MQL'
# MAGIC         WHEN program LIKE '%Always-on-Nurture%' OR program LIKE '%Always-on%' THEN 'Always-On'
# MAGIC         WHEN program LIKE '%Nurture-Welcome%' THEN 'Welcome'
# MAGIC         ELSE NULL
# MAGIC     END AS nurture_path,
# MAGIC     CASE
# MAGIC         WHEN sends > 100 AND sends < 1000 THEN '100 - 1000'
# MAGIC         WHEN sends >= 1000 AND sends < 10000 THEN '1000 - 10000'
# MAGIC         WHEN sends >= 10000 AND sends < 50000 THEN '10000 - 50000'
# MAGIC         WHEN sends >= 50000 AND sends < 100000 THEN '50000 - 100000'
# MAGIC         WHEN sends >= 100000 THEN '>=100000'
# MAGIC         ELSE '<100'
# MAGIC     END AS send_volume_range,
# MAGIC     SUM(click_individuals) OVER (PARTITION BY program) / NULLIF(SUM(delivers) OVER (PARTITION BY program), 0) AS click_rate,
# MAGIC     SUM(click_individuals) OVER (PARTITION BY program) / NULLIF(SUM(opens) OVER (PARTITION BY program), 0) AS click_to_open_rate,
# MAGIC     SUM(opens) OVER (PARTITION BY program) / NULLIF(SUM(delivers) OVER (PARTITION BY program), 0) AS open_rate,
# MAGIC     SUM(sends) OVER (PARTITION BY program) AS send_volume,
# MAGIC     SUM(delivers) OVER (PARTITION BY program) - SUM(opens) OVER (PARTITION BY program) AS unopened,
# MAGIC     SUM(unsub) OVER (PARTITION BY program) / NULLIF(SUM(delivers) OVER (PARTITION BY program), 0) AS unsubscribe_rate
# MAGIC FROM main.it_aibi_silver.email_performance_silver
