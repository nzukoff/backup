# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.global_daiwt_dais_marketing_silver
# MAGIC
# MAGIC with usecase as (
# MAGIC   select
# MAGIC   Account_AE_Owner_Manager,
# MAGIC   account_owner_name,
# MAGIC   campaign_member_id,
# MAGIC   campaign_name,
# MAGIC   current_mql_promote_date,
# MAGIC   first_name,
# MAGIC   is_contact_a_uc_contact,
# MAGIC   last_name,
# MAGIC   lead_or_contact_id,
# MAGIC   member_first_associated_date_time,
# MAGIC   sum(mql_response) as mql_response,
# MAGIC   sum(net_new_names) as net_new_names,
# MAGIC   region,
# MAGIC   region_level_1,
# MAGIC   region_level_2,
# MAGIC   usecase_created_by,
# MAGIC   usecase_id,
# MAGIC   usecase_name,
# MAGIC   usecase_xdr_name,
# MAGIC   u1_stage_date,
# MAGIC   u2_stage_date,
# MAGIC   sum(u2_amount) as u2_amount,
# MAGIC   sum(u2_unit) as u2_unit
# MAGIC   from main.marketing_lakehouse.gold_campaign_funnel_by_usecase
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC review as (
# MAGIC   select
# MAGIC   usecase_id,
# MAGIC   usecase_name,
# MAGIC   xdr_demand_validated_by
# MAGIC   from main.it_aibi_bronze.usecase_review_dash_bronze
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC   Account_AE_Owner_Manager,
# MAGIC   account_owner_name,
# MAGIC   campaign_member_id,
# MAGIC   campaign_name,
# MAGIC   current_mql_promote_date,
# MAGIC   first_name,
# MAGIC   is_contact_a_uc_contact,
# MAGIC   last_name,
# MAGIC   lead_or_contact_id,
# MAGIC   member_first_associated_date_time,
# MAGIC   mql_response,
# MAGIC   net_new_names,
# MAGIC   region,
# MAGIC   region_level_1,
# MAGIC   region_level_2,
# MAGIC   usecase_created_by,
# MAGIC   u.usecase_id,
# MAGIC   u.usecase_name,
# MAGIC   usecase_xdr_name,
# MAGIC   u1_stage_date,
# MAGIC   u2_stage_date,
# MAGIC   u2_amount,
# MAGIC   u2_unit,
# MAGIC   xdr_demand_validated_by
# MAGIC from usecase u
# MAGIC left join review r
# MAGIC on u.usecase_id=r.usecase_id
