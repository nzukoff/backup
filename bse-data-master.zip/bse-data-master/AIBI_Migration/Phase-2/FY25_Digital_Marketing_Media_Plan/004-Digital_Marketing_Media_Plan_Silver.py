# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.fy25_digital_marketing_media_plan_silver
# MAGIC
# MAGIC select
# MAGIC audience,
# MAGIC budget_type,
# MAGIC campaign,
# MAGIC channel,
# MAGIC objective_bucket,
# MAGIC quarter,
# MAGIC region,
# MAGIC source,
# MAGIC subregion,
# MAGIC working_budget as planned_working_budget,
# MAGIC 'FY24' as fiscal_year,
# MAGIC CASE
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%AO%' THEN 'Demand Generation'
# MAGIC     WHEN Campaign LIKE '%POINT IN TIME: Partner/DW Big Rock%' THEN 'Demand Generation'
# MAGIC     WHEN Budget_Type LIKE '%CB%' THEN 'Corporate Brand'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%ABM%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%LW%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%AO%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%ABM%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%LW%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%AO%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%ABM%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%LW%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%VE%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%EV%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%VE%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%EV%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%VE%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%EV%' THEN 'Field Marketing'
# MAGIC     WHEN Budget_Type LIKE '%SUM%' THEN 'Summit'
# MAGIC     ELSE 'Other'
# MAGIC END as cost_center
# MAGIC from main.it_aibi_bronze.FY24_Consolidated_Media_worksheet_Gsheet
# MAGIC
# MAGIC UNION
# MAGIC
# MAGIC select
# MAGIC audience,
# MAGIC budget_type,
# MAGIC campaign,
# MAGIC channel,
# MAGIC objective_bucket,
# MAGIC quarter,
# MAGIC region,
# MAGIC source,
# MAGIC subregion,
# MAGIC planned_working_budget as planned_working_budget,
# MAGIC 'FY25' as fiscal_year,
# MAGIC CASE
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%AO%' THEN 'Demand Generation'
# MAGIC     WHEN Campaign LIKE '%POINT IN TIME: Partner/DW Big Rock%' THEN 'Demand Generation'
# MAGIC     WHEN Budget_Type LIKE '%CB%' THEN 'Corporate Brand'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%ABM%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%LW%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%AO%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%ABM%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%LW%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%AO%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%ABM%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%LW%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%VE%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%EV%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%VE%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%EV%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%VE%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%EV%' THEN 'Field Marketing'
# MAGIC     WHEN Budget_Type LIKE '%SUM%' THEN 'Summit'
# MAGIC     ELSE 'Other'
# MAGIC END as cost_center
# MAGIC from main.it_aibi_bronze.FY25_Consolidated_Media_Plan_Gsheet
# MAGIC
# MAGIC UNION 
# MAGIC
# MAGIC select
# MAGIC audience,
# MAGIC budget_type,
# MAGIC campaign,
# MAGIC channel,
# MAGIC objective_bucket,
# MAGIC quarter,
# MAGIC region,
# MAGIC source,
# MAGIC subregion,
# MAGIC planned_working_budget as planned_working_budget,
# MAGIC 'FY26' as fiscal_year,
# MAGIC CASE
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%AO%' THEN 'Demand Generation'
# MAGIC     WHEN Campaign LIKE '%POINT IN TIME: Partner/DW Big Rock%' THEN 'Demand Generation'
# MAGIC     WHEN Budget_Type LIKE '%CB%' THEN 'Corporate Brand'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%ABM%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%LW%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%AO%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%ABM%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%LW%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%AO%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%ABM%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%LW%' THEN 'Demand Generation'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%VE%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%AMER%' AND Budget_Type LIKE '%EV%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%VE%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%APJ%' AND Budget_Type LIKE '%EV%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%VE%' THEN 'Field Marketing'
# MAGIC     WHEN Region LIKE '%EMEA%' AND Budget_Type LIKE '%EV%' THEN 'Field Marketing'
# MAGIC     WHEN Budget_Type LIKE '%SUM%' THEN 'Summit'
# MAGIC     ELSE 'Other'
# MAGIC END as cost_center
# MAGIC from main.it_aibi_bronze.FY26_Consolidated_Media_Plan_Gsheet
# MAGIC
