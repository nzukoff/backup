# Databricks notebook source
# MAGIC %md
# MAGIC ### Digital Marketing Report Data
# MAGIC
# MAGIC This sheet contains data from the Digital Marketing report. We are extracting data from the Google Sheets Excel file. In this notebook, we write code to get specific tab data and place it in the bronze layer.
# MAGIC
# MAGIC #### Sheet: FY24 Digital Media Budget
# MAGIC - **Tab Names:**
# MAGIC   - FY24 Consolidated Media
# MAGIC   - Q1 Global Media Plan
# MAGIC   - Q2 Global Media Plan
# MAGIC   - Q3 Global Media Plan
# MAGIC   - Q4 Global Media Plan
# MAGIC   - Change Log
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #FY24 Digital Media Budget
# MAGIC

# COMMAND ----------

# Import necessary libraries
%pip install gspread
%pip install pygsheets

# COMMAND ----------

# Databricks notebook source
# DBTITLE 1,Gsheet Functions

import json
import pandas as pd
import gspread
from dataclasses import dataclass
from pyspark.sql import DataFrame
import pygsheets
from tempfile import NamedTemporaryFile

# Define a data class to hold GCP service account information
@dataclass(frozen=True)
class GCPServiceAccount:
    name: str
    secrets_scope: str
    creds_key: str

# Configuration for accessing GCP service account credentials stored in Databricks secrets
env_configs = {
    "dev": GCPServiceAccount(
        name='dev-bse-storage-access-sa',
        secrets_scope='bse-dev-creds',
        creds_key='gcp_dev_bse_creds'
    ),
    "prod": GCPServiceAccount(
        name='dev-bse-storage-access-sa',
        secrets_scope='bse-dev-creds',
        creds_key='gcp_dev_bse_creds'
    )
}

def retrieve_gcp_dev_bse_serv_acc_creds(sa: GCPServiceAccount, dbutils) -> dict:
    """
    Retrieves GCP service account credentials from Databricks secrets.
    
    Parameters:
        - sa: An instance of GCPServiceAccount containing the service account details.
    
    Returns:
        - A dictionary containing the service account credentials.
    """
    return (json.loads(dbutils.secrets.get(scope=sa.secrets_scope, key=sa.creds_key)))

def open_gsheet_by_id(gsheet_id: str, service_account: GCPServiceAccount, dbutils):
    """
    Opens a Google Sheet by its ID using credentials of a specified GCP service account.
    
    Parameters:
        - gsheet_id (str):  The ID of the Google Sheet to be accessed.
        - service_account:  An instance of GCPServiceAccount to use for authentication.
    
    Returns:
        - An instance of gspread.models.Spreadsheet representing the opened Google Sheet.
    """
    gc = gspread.service_account_from_dict(retrieve_gcp_dev_bse_serv_acc_creds(service_account, dbutils))
    return gc.open_by_key(gsheet_id)

def read_google_worksheet_data(gsheet_id: str, worksheet_id: str, dbutils, spark, env: str='dev', data_range : str=None, columnList: list = None) -> DataFrame:
    """
    This function reads data from a specified worksheet within a Google Sheet and returns it as a Spark DataFrame. It utilizes a GCP service account to access the Google Sheet data, so you'll need to ensure that the provided GCP service account has the necessary permissions (view) to the Google Sheet.
        - dev: dev-bse-storage-access-sa@gcp-dev-bse.iam.gserviceaccount.com
        - prod: prd-bse-storage-access-sa@gcp-prod-bse.iam.gserviceaccount.com

    Deficiencies:
        - Considers 1st row as header by default


    Parameters:
        - gsheet_id (str):              This parameter represents the unique identifier for the Google Sheets document. 
                                        You can find this ID    within the Google Sheets URL. It is the part of the URL that immediately follows 'https://docs.google.com/spreadsheets/d/' and precedes 'edit#gid=<worksheet_id>'. For instance, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then 'abc123' is the gsheet_id.

        - worksheet_id (str):           This parameter refers to the specific worksheet within the Google Sheets document from 
                                        which you want to retrieve data. It can be identified from the Google Sheets URL. It comes after 'gid=' in the URL. For example, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then '456' is the worksheet_id.

        - dbutils and spark:            Imported Python modules don't have access to the notebook context (i.e., can't see things like the
                                        global "spark" and "dbutils" objects), so we have to pass dbutils & spark in.

        - env (str):                    The environment to use ('dev' or 'prod'). Determines which service account to use.

        - data_range (str, optional):   A specific range of cells to read from the worksheet.

        - columnList (str, optional):   Please mention the list of columns that you want to extract from the gsheet.
    

    Returns:
        - A Spark DataFrame containing the data read from the worksheet.
    """
    # Select the service account based on the environment
    service_account = env_configs[env]
    gsheet = open_gsheet_by_id(gsheet_id, service_account, dbutils)
    worksheet = gsheet.get_worksheet_by_id(int(worksheet_id))

    if data_range:
        ws_data = worksheet.get_values(data_range)
    else:
        ws_data = worksheet.get_values()
    if not ws_data:
      raise ValueError("The worksheet is empty or does not exist.")

    header = ws_data[0] # Considering 1st row as header
    # Checking if all the columns mentioned in columnList are present
    if columnList is None:
        columnList = []
    missing_columns = [col for col in columnList if col not in header]
    if missing_columns:
        raise ValueError(f"The following columns are missing in the worksheet: {', '.join(missing_columns)}")

    if not columnList:
        columnList = header

    selected_indices = [header.index(col) for col in columnList]
    filtered_data = [[row[i] for i in selected_indices] for row in ws_data[1:]]

    # Use the first row as header and the rest as data
    pd_df = pd.DataFrame(filtered_data, columns=columnList)
    pd_df.fillna("", inplace=True)  # Convert None to empty string

    # Convert column names to lowercase and replace spaces with underscores
    pd_df.columns = [x.lower().replace(" ", "_") for x in pd_df.columns]

    # Create a Spark DataFrame from the pandas DataFrame
    spark_df = spark.createDataFrame(pd_df)
    return spark_df
  
def write_to_google_sheet(gsheet_id: str, worksheet_id: str, pandasDF, dbutils, env: str='dev'):
    """
    This function writes pandas dataframe to a Google Sheet. It utilizes a GCP service account to access the Google Sheet data, so you'll need to ensure that the provided GCP service account has the necessary permissions (edit) to the Google Sheet.
        - dev: dev-bse-storage-access-sa@gcp-dev-bse.iam.gserviceaccount.com
        - prod: prd-bse-storage-access-sa@gcp-prod-bse.iam.gserviceaccount.com

    Parameters:
        - gsheet_id (str):              This parameter represents the unique identifier for the Google Sheets document. 
                                        You can find this ID    within the Google Sheets URL. It is the part of the URL that immediately follows 'https://docs.google.com/spreadsheets/d/' and precedes 'edit#gid=<worksheet_id>'. For instance, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then 'abc123' is the gsheet_id.

        - worksheet_id (str):           This parameter refers to the specific worksheet within the Google Sheets document from 
                                        which you want to retrieve data. It can be identified from the Google Sheets URL. It comes after 'gid=' in the URL. For example, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then '456' is the worksheet_id.

        - pandasDF:                     pandas dataframe containing the data to be written to the worksheet.

        - dbutils:                      Imported Python modules don't have access to the notebook context (i.e., can't see things like the
                                        global "spark" and "dbutils" objects), so we have to pass dbutils & spark in.

        - env (str):                    The environment to use ('dev' or 'prod'). Determines which service account to use.
    """
    # Select the service account based on the environment
    service_account = env_configs[env]

    with NamedTemporaryFile(mode='w+') as f:
      f.write(json.dumps(retrieve_gcp_dev_bse_serv_acc_creds(service_account, dbutils)))
      f.flush()
      auth = pygsheets.authorize(service_file=f.name)

    # Open the spreadsheet and the worksheet
    sh = auth.open_by_key(gsheet_id)
    wks = sh.worksheet('id', worksheet_id)
    wks.set_dataframe(pandasDF, (1, 1), fit=True)
    print('Data upload complete.')

# COMMAND ----------

# FY24_Consolidated_Media
# Q1 Global Media Plan
# Q2 Global Media Plan
# Q3 Global Media Plan
# Q4 Global Media Plan
# Change Log

# COMMAND ----------

# Example usage of the read_google_worksheet_data function

# Define the Google Sheet ID and Worksheet ID
gsheet_id_r = '1cRKPZKj5YVYDqyFNd-U-LTE57kBjh4iZJjuyIi4ypiQ'

FY24_Consolidated_Media_worksheet_id_r_0 = '913744825'
Q1_Global_Media_Plan_worksheet_id_r_1=  '1671195747'
Q2_Global_Media_Plan_worksheet_id_r_2=  '2018328677'
Q3_Global_Media_Plan_worksheet_id_r_3=  '1055331450'
Q4_Global_Media_Plan_worksheet_id_r_4=  '1716315288'
Change_Log_worksheet_id_r_5=  '1978537247'
# Define the environment ('dev' or 'prod')
env = 'dev'

# Read data from the Google Sheet
FY24_Consolidated_Media_worksheet_Gsheet = read_google_worksheet_data(gsheet_id_r, FY24_Consolidated_Media_worksheet_id_r_0, dbutils, spark, env)
Q1_Global_Media_Plan_Gsheet = read_google_worksheet_data(gsheet_id_r, Q1_Global_Media_Plan_worksheet_id_r_1, dbutils, spark, env)
Q2_Global_Media_Plan_Gsheet = read_google_worksheet_data(gsheet_id_r, Q2_Global_Media_Plan_worksheet_id_r_2, dbutils, spark, env)
Q3_Global_Media_Plan_Gsheet = read_google_worksheet_data(gsheet_id_r, Q3_Global_Media_Plan_worksheet_id_r_3, dbutils, spark, env)
Q4_Global_Media_Plan_Gsheet = read_google_worksheet_data(gsheet_id_r, Q4_Global_Media_Plan_worksheet_id_r_4, dbutils, spark, env)
Change_Log_Gsheet = read_google_worksheet_data(gsheet_id_r, Change_Log_worksheet_id_r_5, dbutils, spark, env)

# COMMAND ----------

from pyspark.sql.functions import current_date

# Function to add current date column
def add_date_column(df):
    return df.withColumn("datebricks_data_ingest_date", current_date())

# Add current date column to each DataFrame
FY24_Consolidated_Media_worksheet_Gsheet = add_date_column(FY24_Consolidated_Media_worksheet_Gsheet)
Q1_Global_Media_Plan_Gsheet = add_date_column(Q1_Global_Media_Plan_Gsheet)
Q2_Global_Media_Plan_Gsheet = add_date_column(Q2_Global_Media_Plan_Gsheet)
Q3_Global_Media_Plan_Gsheet = add_date_column(Q3_Global_Media_Plan_Gsheet)
Q4_Global_Media_Plan_Gsheet = add_date_column(Q4_Global_Media_Plan_Gsheet)
Change_Log_Gsheet = add_date_column(Change_Log_Gsheet)

# COMMAND ----------

import re
from pyspark.sql.functions import col, regexp_replace, when
from pyspark.sql.types import IntegerType

def clean_column_name(name):
    # Replace problematic characters with underscores
    cleaned = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    # Remove leading digits and underscores
    cleaned = re.sub(r'^[0-9_]+', '', cleaned)
    # Ensure the name is not empty and doesn't start with a digit
    if not cleaned or cleaned[0].isdigit():
        cleaned = 'col_' + cleaned
    return cleaned

def convert_budget_to_int(df, column):
    # Remove '$' and ',' from the string and convert to integer type
    return df.withColumn(column, 
                         regexp_replace(col(column), r'[$,]', '').cast(IntegerType()))

def rename_and_save(df, table_name):
    col_count = {}
    new_columns = []
    
    for col in df.columns:
        new_col = clean_column_name(col)
        
        if new_col in col_count:
            col_count[new_col] += 1
            new_col = f"{new_col}_{col_count[new_col]}"
        else:
            col_count[new_col] = 1
        
        new_columns.append(new_col)
    
    # Rename columns all at once
    df = df.toDF(*new_columns)
    
    # Convert budget columns to integer type, excluding 'budget_type'
    # for column in df.columns:
    #     if (('budget' in column.lower() or 'spend' in column.lower()) 
    #         and column.lower() != 'budget_type'):
    #         df = convert_budget_to_int(df, column)
    for column in df.columns:
        if (('budget' in column.lower() or 'spend' in column.lower() or column in [
            'adjustments', 'incremental__3_17_', 'incremental__4_5_', 'transfers__4_21_', 
            'transfers__04_24_', 'incremental__05_10_', 'incremental__6_5_', 'incremental__6_16_', 
            'incremental__06_27_', 'transfers_week_of_7_10', 'incremental_week_of__7_10_', 
            'incremental_7_20', 'transfers_week_of_7_26', 'incremental__7_27_', 'incremental__8_5_', 
            'transfer_from_lg_to_aw', 'transfers__9_12_', 'k_incremental_minus__50k_from_google_credit__10_2_', 
            'transfers_10_20____40k_incremental_from_pk', 'approved_incremental_for_brand_core__9_12_', 
            'cpls2o__2_1_6_30_', 'cpls2o___new_mta__2_1_6_30_', 'delta']) 
            and column.lower() != 'budget_type'):
            df = convert_budget_to_int(df, column)
    # Write the DataFrame to a table
    df.write.mode("overwrite").saveAsTable(f"main.it_aibi_bronze.{table_name}")

# Save all tables
rename_and_save(FY24_Consolidated_Media_worksheet_Gsheet, "FY24_Consolidated_Media_worksheet_Gsheet")
rename_and_save(Q1_Global_Media_Plan_Gsheet, "Q1_Global_Media_Plan_Gsheet")
rename_and_save(Q2_Global_Media_Plan_Gsheet, "Q2_Global_Media_Plan_Gsheet")
rename_and_save(Q3_Global_Media_Plan_Gsheet, "Q3_Global_Media_Plan_Gsheet")
rename_and_save(Change_Log_Gsheet, "Change_Log_Gsheet")

