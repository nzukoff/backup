# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.fy25_digital_marketing_media_plan_gold
# MAGIC
# MAGIC select
# MAGIC audience,
# MAGIC budget_type,
# MAGIC campaign,
# MAGIC channel,
# MAGIC objective_bucket,
# MAGIC quarter,
# MAGIC region,
# MAGIC source,
# MAGIC subregion,
# MAGIC planned_working_budget,
# MAGIC fiscal_year,
# MAGIC cost_center,
# MAGIC CASE
# MAGIC     WHEN cost_center IN ('Demand Generation','Field Marketing','Summit') THEN 'Demand Generation, Field Marketing, Summit'
# MAGIC     WHEN cost_center = 'Corporate Brand' THEN 'Corporate Brand'
# MAGIC END as cost_center_group,
# MAGIC CASE
# MAGIC     WHEN budget_type IN ('AO','LW','TC','VE') THEN 'Demand Generation'
# MAGIC     WHEN budget_type IN ('CB') THEN 'Brand Campaign'
# MAGIC     WHEN budget_type IN ('SUM') THEN 'DAIS'
# MAGIC END as program,
# MAGIC CASE 
# MAGIC     WHEN quarter IN ('Q1','Q2') THEN 'Q1 & Q2'
# MAGIC     WHEN quarter IN ('Q3','Q4') THEN 'Q3 & Q4'
# MAGIC END as quarter_group,
# MAGIC CASE
# MAGIC     WHEN source IN ('Google Display','Google Search') THEN 'Google'
# MAGIC     WHEN source IN ('ActualTech','Bidtellect','Bloomberg','Bluewhale Research','Bython','Conde Nast','Demand Science','DemandScience','DemandWorks','DigitalZone','DZone','Forbes','Foundry','Global Tech Media','Headley','Headley Media','iDev News','IDG','InBoxInsight','Integrate','Intentsify','Lead Crunch','LeadCrunch','MachIQ','MadisonLogic','Naver','Netline','Nikkei','NRC','ODN','Outfront','PharosIQ','Pure AI','Spotify','TBC','TCI','TDWI','TechTarget','The Trade Desk','TrueInfluence','VentureBeat','WSJ') THEN 'Just Global / Third Party'
# MAGIC     ELSE source
# MAGIC END as source_group
# MAGIC from main.it_aibi_silver.fy25_digital_marketing_media_plan_silver
