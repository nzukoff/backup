# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.jens_master_gold AS
# MAGIC
# MAGIC select 
# MAGIC cloudType,
# MAGIC date,
# MAGIC dollars,
# MAGIC featureTier,
# MAGIC sfdcAccountName,
# MAGIC workspaceName,
# MAGIC azure_customer_id,
# MAGIC enrollment_number,
# MAGIC tp_id,
# MAGIC tp_name,
# MAGIC product_account_id,
# MAGIC sfdc_workspace_id,
# MAGIC
# MAGIC
# MAGIC CASE TRUE
# MAGIC
# MAGIC ----Volkswagen
# MAGIC --unknown
# MAGIC WHEN CONTAINS(workspaceName,"dbw-poi") THEN "VW-poi"
# MAGIC WHEN CONTAINS(workspaceName,"datavur-") THEN "VW-China-datavur"
# MAGIC
# MAGIC ----Volkswagen
# MAGIC --VW-VW
# MAGIC WHEN CONTAINS(workspaceName,"vwag-it4it-databricksworkspace-") THEN "VW-IT4IT"
# MAGIC WHEN (workspaceName="Eventhandlerfashafdev" OR
# MAGIC workspaceName="eventhandleradasstg" OR
# MAGIC workspaceName="eventhandleradasprd" OR
# MAGIC workspaceName="ezzo2pzto3xu2adasstg") THEN "VW-ADAS"
# MAGIC
# MAGIC ----VW-N - Ocean
# MAGIC WHEN (workspaceName="dev-dbr-lkh" OR
# MAGIC workspaceName="prod-dbr-lkh" OR
# MAGIC workspaceName="qa-dbr-lkh" OR
# MAGIC workspaceName="sbx-dab-tst") THEN "VW-N-Ocean"
# MAGIC
# MAGIC ----AUDI
# MAGIC --Audi - UDE
# MAGIC WHEN workspaceName="dblytics-userdbw-prod-col3edt70als73bdv99g" THEN "Audi-UDE-Battery"
# MAGIC
# MAGIC ----Cariad
# MAGIC --Cariad - LLM Garages
# MAGIC WHEN workspaceName="gdc-copilot" THEN "Cariad-LLM-Garages"
# MAGIC
# MAGIC --Caraid - Streets Maps - AT
# MAGIC WHEN (workspaceName="rcd-dev-eu-databricks" OR
# MAGIC workspaceName="rcd-prd-eu-databricks" OR
# MAGIC workspaceName="rcd-prd-na-databricks") THEN "Caraid-Maps"
# MAGIC
# MAGIC --Cariad X5 - CAP
# MAGIC WHEN (workspaceName="AWS CAP Databirkcs Workspace1" OR
# MAGIC workspaceName="eu-west-1-dev" OR
# MAGIC workspaceName="eu-west-1-prd" OR
# MAGIC workspaceName="eu-west-1-pre-prd") THEN "Cariad-X5-CAP"
# MAGIC
# MAGIC --Cariad DPL
# MAGIC WHEN CONTAINS(workspaceName,"dplcore-") THEN "Cariad-DPL-DPL"
# MAGIC WHEN CONTAINS(workspaceName,"datacat-") THEN "Cariad-DPL-DPL"
# MAGIC WHEN CONTAINS(workspaceName,"dpldpt-") THEN "Cariad-DPL-DPL"
# MAGIC WHEN CONTAINS(workspaceName,"datacmp-") THEN "Cariad-DPL-CPM"
# MAGIC WHEN CONTAINS(workspaceName,"dataprm-") THEN "Cariad-DPL-PRM"
# MAGIC WHEN CONTAINS(workspaceName,"datadrm-") THEN "Cariad-DPL-DRM"
# MAGIC WHEN CONTAINS(workspaceName,"datarmid-") THEN "Cariad-DPL-RMID"
# MAGIC WHEN CONTAINS(workspaceName,"gdcclm--") THEN "Cariad-DPL-GDCCLM"
# MAGIC WHEN CONTAINS(workspaceName,"datahvb-") THEN "Cariad-DPL-HVB"
# MAGIC WHEN CONTAINS(workspaceName,"datacat-") THEN "Cariad-DPL-DataCAT"
# MAGIC WHEN CONTAINS(workspaceName,"datagda-") THEN "Cariad-DPL-GDA"
# MAGIC WHEN CONTAINS(workspaceName,"dataecs-") THEN "Cariad-DPL-ECS"
# MAGIC WHEN CONTAINS(workspaceName,"dataubi-") THEN "Cariad-DPL-UBI"
# MAGIC WHEN CONTAINS(workspaceName,"datadash-") THEN "Cariad-DPL-GIS"
# MAGIC
# MAGIC --Cariad T1
# MAGIC WHEN CONTAINS(workspaceName,"ude-") THEN "Caraiad-T1-UDE"
# MAGIC WHEN CONTAINS(workspaceName,"arl-north-eu-lakehouse") THEN "Caraiad-T1-UDE"
# MAGIC WHEN CONTAINS(workspaceName,"dlcm-") THEN "Caraid-T1-DLCM"
# MAGIC WHEN (CONTAINS(workspaceName,"ws-ids") OR
# MAGIC CONTAINS(workspaceName,"dbw_35362-")OR
# MAGIC CONTAINS(workspaceName,"dbw_dev-dev_")) THEN "Caraiad-T1-UDE-IDS"
# MAGIC WHEN (CONTAINS(workspaceName,"data-azdb-") OR
# MAGIC workspaceName="d-cor-dpcmp-eu2-dbw") THEN "Caraiad-T1-US"
# MAGIC WHEN workspaceName="ude-chatbot-dev" THEN "Caraid-UDE-Chatbot"
# MAGIC
# MAGIC --Cariad T3
# MAGIC WHEN (workspaceName="dblytics-userdbw-prod-cpanugo89r0s73bodnpg" OR
# MAGIC workspaceName="dblytics-userdbw-prod-cpul6g1e6bfc7388cjkg") THEN "Cariad-T3-ICS"
# MAGIC
# MAGIC --Cariad T4
# MAGIC WHEN (workspaceName="db-gdc-workbench" OR
# MAGIC workspaceName="adb-art-ta-gdc-7az44" OR
# MAGIC workspaceName="adb-art-ta-gdc-unity" OR
# MAGIC workspaceName="art-ta-db-workspace") THEN "Cariad-T4-artta"
# MAGIC
# MAGIC --Cariad TZ
# MAGIC WHEN (workspaceName="dblytics-userdbw-prod-crp5a4dp36us73fgvio0" OR
# MAGIC workspaceName="dblytics-userdbw-prod-co9r06veebds73efgkm0") THEN "Cariad-TZ-ATA"
# MAGIC
# MAGIC ----Porsche
# MAGIC WHEN (CONTAINS(workspaceName,"default-dbws") OR
# MAGIC workspaceName="dbs-datalakeadmin-dbws" OR
# MAGIC CONTAINS(workspaceName,"sndbx-") OR
# MAGIC CONTAINS(workspaceName,"-dataservice-dbws")) THEN "Porsche-SZ-PHS"
# MAGIC WHEN CONTAINS(workspaceName,"sndbx-aiforsvn-dbws") THEN "Porsche-SZ-LLM"
# MAGIC WHEN CONTAINS(workspaceName,"-scc-dbws") THEN "Porsche-SZ-SFDC"
# MAGIC WHEN (CONTAINS(workspaceName,"kvm-databricks") OR
# MAGIC workspaceName="kvmDevDatabricks" OR
# MAGIC workspaceName="kvmProdData") THEN "Porsche-KVM"
# MAGIC WHEN CONTAINS(workspaceName,"pcon-ibi-") THEN "Porsche-Consulting"
# MAGIC WHEN CONTAINS(workspaceName,"dblytics-userdbw-prod-cnlg1m77ur5s738la570") THEN "Porsche-ADAS on DBlytics"
# MAGIC
# MAGIC ----Skoda
# MAGIC ---Initial Skoda-DPA by Adastra
# MAGIC WHEN (CONTAINS(workspaceName,"dapadbanalytics") OR
# MAGIC CONTAINS(workspaceName,"dapadbprocessing")) THEN "Skoda-DAP-Adastra"
# MAGIC
# MAGIC ---New Use Case by Trask H1-24
# MAGIC ---Skoda-DAP-Trask
# MAGIC WHEN (CONTAINS(workspaceName,"AICC-E") OR
# MAGIC CONTAINS(workspaceName,"AICC-Mlops")) THEN "Skoda-DAP-Trask"
# MAGIC
# MAGIC --Skoda-Car-Config
# MAGIC WHEN (workspaceName="Recommengine-training-dev-dabr" OR
# MAGIC workspaceName="Recommengine-training-dev2-dabr" OR
# MAGIC workspaceName="Recommengine-training-uat-dabr" OR
# MAGIC workspaceName="Recommengine-training-PROD-dabr" OR
# MAGIC workspaceName="Recommengine-training-QA-dabr" OR
# MAGIC workspaceName="Recommengine-training-PERSO-dabr") THEN "Skoda-DAP-CarConfig"
# MAGIC
# MAGIC --Skoda-Online-Ads
# MAGIC WHEN (workspaceName="Recommengine-training-UAT-PERSO1-dabr" OR
# MAGIC workspaceName="Recommengine-training-PERSO-dabr") THEN "Skoda-DAP-Trask"
# MAGIC
# MAGIC --Skoda-Virtual-Build-To-Order
# MAGIC WHEN CONTAINS(workspaceName,"VBtO2-") THEN "Skoda-VTBO/ISP-Trask"
# MAGIC
# MAGIC ----PowerCO
# MAGIC ---Account ID - 2975c2d8-9987-47a4-bb25-eae2023e8bdc
# MAGIC WHEN (CONTAINS(workspaceName,"dbw-rnd-") OR
# MAGIC CONTAINS(workspaceName,"dbw-operations-")OR
# MAGIC CONTAINS(workspaceName,"dbw-powercap-")OR
# MAGIC workspaceName="dbw-409cecdc38f41-ops-domain-dev" OR
# MAGIC workspaceName="dbw-673876f78d122-rnd-domain-dev" OR
# MAGIC workspaceName="dbw-bd1cf8c4c096d-ops-domain-qa" OR
# MAGIC workspaceName="dbw-cc90eceaa0700-ingst-domain-qa" OR
# MAGIC workspaceName="dbw-e4e1423edecff-ingst-domain-dev" OR
# MAGIC workspaceName="dbw-it-analytics-box" OR
# MAGIC workspaceName="dbx-operations-analytics-box" OR
# MAGIC workspaceName="dbx-procurement-analytics-box" OR
# MAGIC workspaceName="dbx-rnd-analytics-box") THEN "PowerCo"
# MAGIC
# MAGIC ----VWFS
# MAGIC WHEN workspaceName="cmod-s-weu-db-001-belg-dbw" THEN "VWFS"
# MAGIC
# MAGIC ----BMW
# MAGIC WHEN CONTAINS(workspaceName,"computing-unit-") THEN "Computing-Unit"
# MAGIC WHEN CONTAINS(workspaceName,"atsproddatabricks") THEN "BMW-ATS"
# MAGIC WHEN CONTAINS(workspaceName,"ats-databricks-") THEN "BMW-ATS"
# MAGIC WHEN CONTAINS(workspaceName,"EF-530_Databricks") THEN "EF-530"
# MAGIC WHEN CONTAINS(workspaceName,"gen5iotdb") THEN "BMW-Gen5"
# MAGIC WHEN CONTAINS(workspaceName,"qsfa-databricks-") THEN "BMW-Gen6"
# MAGIC WHEN (CONTAINS(workspaceName,"epm-datatransform") OR
# MAGIC CONTAINS(workspaceName,"epm-data-transformations-int")) THEN "BMW-EPM"
# MAGIC WHEN (CONTAINS(workspaceName,"mdr-") OR
# MAGIC workspaceName="mdr" OR
# MAGIC workspaceName="mdrdatabricks" OR
# MAGIC workspaceName="mdrErrorPatternSearch_databricks") THEN "BMW-MDR"
# MAGIC WHEN CONTAINS(workspaceName,"predima") THEN "BMW-Predima"
# MAGIC WHEN (CONTAINS(workspaceName,"UisDatabricks")OR
# MAGIC CONTAINS(workspaceName,"DB_App_Analytics") OR
# MAGIC CONTAINS(workspaceName,"Analytics_Prod_") OR
# MAGIC workspaceName="DB_AppAnalytics_Prod"	OR
# MAGIC workspaceName="countly-computing-unit") THEN "BMW-UIS"
# MAGIC WHEN (workspaceName="ad-dc-tae6-dev-001" OR
# MAGIC workspaceName="DatabricksService_BCCC") THEN "BMW-BCA"
# MAGIC WHEN workspaceName="dev-databricks-dwh" THEN "BMW-Digital-Charging"
# MAGIC
# MAGIC
# MAGIC ELSE "Other"
# MAGIC
# MAGIC END as use_case_vw_and_bmw
# MAGIC
# MAGIC
# MAGIC from main.it_aibi_silver.jens_master_silver
# MAGIC group by all
