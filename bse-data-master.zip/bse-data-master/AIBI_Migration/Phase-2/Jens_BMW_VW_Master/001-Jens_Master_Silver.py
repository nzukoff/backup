# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.jens_master_silver AS
# MAGIC
# MAGIC with workloads as (
# MAGIC   select 
# MAGIC   cloudType,
# MAGIC   `date` as date,
# MAGIC   sum(dollars) as dollars,
# MAGIC   featureTier,
# MAGIC   sfdcAccountName,
# MAGIC   workspaceId,
# MAGIC   workspaceName
# MAGIC   from main.data_df_metering.workloads_sku_agg
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC usage as (
# MAGIC   SELECT 
# MAGIC   max(azure_customer_id) as azure_customer_id,
# MAGIC   max(enrollment_number) as enrollment_number,
# MAGIC   max(tp_id) as tp_id,
# MAGIC   max(tp_name) as tp_name,
# MAGIC   max(product_account_id) as product_account_id,
# MAGIC   sfdc_workspace_id 
# MAGIC   FROM main.fin_live_gold.paid_usage_metering 
# MAGIC   GROUP BY sfdc_workspace_id
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC cloudType,
# MAGIC date,
# MAGIC dollars,
# MAGIC featureTier,
# MAGIC sfdcAccountName,
# MAGIC workspaceName,
# MAGIC azure_customer_id,
# MAGIC enrollment_number,
# MAGIC tp_id,
# MAGIC tp_name,
# MAGIC product_account_id,
# MAGIC sfdc_workspace_id 
# MAGIC from workloads w
# MAGIC left join usage u
# MAGIC on w.workspaceId = u.sfdc_workspace_id
# MAGIC group by all
