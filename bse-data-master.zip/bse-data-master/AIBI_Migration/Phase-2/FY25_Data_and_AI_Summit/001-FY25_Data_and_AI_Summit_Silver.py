# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.fy25_data_ai_summit_silver AS
# MAGIC
# MAGIC select 
# MAGIC   date_fy,
# MAGIC   date,
# MAGIC   tactic_id,
# MAGIC   tactic_name,
# MAGIC   medium,
# MAGIC   source,
# MAGIC   source_medium,
# MAGIC   offer,
# MAGIC   term,
# MAGIC   campaign_id,
# MAGIC   campaign_name,
# MAGIC   budget_type,
# MAGIC   budget_audience,
# MAGIC   region,
# MAGIC   sub_region,
# MAGIC   language,
# MAGIC   objective,
# MAGIC   objective_bucket,
# MAGIC   audience,
# MAGIC   sub_audience,
# MAGIC   cloud,
# MAGIC   status,
# MAGIC   sfdc_utm_campaign,
# MAGIC   sfdc_campaign_id,
# MAGIC   audience_persona,
# MAGIC   member_status,
# MAGIC   opportunity_stage,
# MAGIC   cost,
# MAGIC   impressions,
# MAGIC   view_through_conversions,
# MAGIC   clicks,
# MAGIC   conversions,
# MAGIC   engagements,
# MAGIC   responders,
# MAGIC   mql_response,
# MAGIC   net_new_names,
# MAGIC   u2_unit,
# MAGIC   u2_amount,
# MAGIC
# MAGIC   CASE
# MAGIC     WHEN LOWER(member_status) LIKE '%virtual%' OR LOWER(member_status) LIKE '%on-demand%' OR LOWER(member_status) LIKE '%ondemand%' THEN 'Virtual'
# MAGIC     ELSE 'In-Person'
# MAGIC   END AS DAIS_Virtual_vs_Physical,
# MAGIC   CASE
# MAGIC     WHEN ad_name = 'EN - EV - DAIS24 AMER - Social - 1080x1080 - IMG - vA - The Must-Attend Conference of the Year - black - NON - NON - NON' THEN 'Must Attend Conference - Black - 1080x1080'
# MAGIC     WHEN ad_name = 'EN - EV - DAIS24 AMER - Social - 1080x1080 - IMG - vB - Data Intelligence for All - blue - NON - NON - NON' THEN 'Data Intelligence for All - Blue - 1080x1080'
# MAGIC     WHEN ad_name = 'EN - EV - DAIS24 AMER - Social - 1080x1080 - VID - Video - NON - multi - NON - NON - NON' THEN 'Video - 1080x1080'
# MAGIC     WHEN ad_name = 'EN - EV - DAIS24 AMER - Social - 1080x1080 - IMG - vA - NonVoucher - black - NON - NON - NON' THEN 'Must Attend Conference - Black - 1080x1080'
# MAGIC     WHEN ad_name = 'EN - EV - DAIS24 AMER - Social - 1080x1080 - IMG - vB - NonVoucher - blue - NON - NON - NON' THEN 'Data Intelligence for All - Blue - 1080x1080'
# MAGIC     WHEN ad_name = 'EN - EV - DAIS24 AMER - Social - 1080x1080 - VID - Video - NON - NonVoucher - NON - NON - NON' THEN 'Video - 1080x1080'
# MAGIC     WHEN ad_name = 'DAIS - 2023' THEN 'DAIS - 2023'
# MAGIC     WHEN ad_name = 'DAIS Register Now - 2024' THEN 'DAIS Register Now - 2024'
# MAGIC     WHEN ad_name = 'DAIS Register Now Video - 2024' THEN 'DAIS Register Now Video - 2024'
# MAGIC     WHEN ad_name = 'EN - EV - DAIS 24 Keynote - Social - 1080x1080 - IMG - vA - Meet the brains - black_yellow - Speakers - NON - NON' THEN 'Keynote - Black'
# MAGIC     WHEN ad_name = 'EN - EV - DAIS 24 Keynote - Social - 1080x1080 - IMG - vB - Meet the brains - blue - Speakers - NON - NON' THEN 'Keynote - Blue'
# MAGIC     WHEN ad_name = 'DAIS Keynote Video - vB - 2024' THEN 'Keynote - Video'
# MAGIC     WHEN ad_name = 'DAIS Keynote Video - vA - 2024' THEN 'Keynote - Video'
# MAGIC     WHEN ad_name = 'DAIS Keynote - 2024' THEN 'Keynote - Static'
# MAGIC     ELSE ad_name
# MAGIC   END AS DAIS_Ad_Name
# MAGIC from main.marketing_lakehouse.rpt_digital_performance_deepdive 
# MAGIC
