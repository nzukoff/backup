# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.fy25_media_review__view_digital_silver
# MAGIC
# MAGIC select
# MAGIC audience_persona,
# MAGIC cost,
# MAGIC date,
# MAGIC language,
# MAGIC medium,
# MAGIC net_new_names,
# MAGIC objective,
# MAGIC objective_bucket,
# MAGIC offer,
# MAGIC quality_net_new_names,
# MAGIC region,
# MAGIC sub_region,
# MAGIC u2_amount,
# MAGIC u2_unit,
# MAGIC (u2_amount*12) as u2_amount_arr
# MAGIC from main.marketing_lakehouse.rpt_digital_performance_deepdive

# COMMAND ----------


