# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.web_analytics_summary_gold as
# MAGIC
# MAGIC WITH cte AS (
# MAGIC   SELECT 
# MAGIC     account_name,
# MAGIC     mops_analytics_id,
# MAGIC     audience_persona,
# MAGIC     browser,
# MAGIC     country,
# MAGIC     custom_channel_group,
# MAGIC     `date`,
# MAGIC     dbx_account_group,
# MAGIC     device,
# MAGIC     event_type,
# MAGIC     experiment_viewed,
# MAGIC     fiscal_quarter,
# MAGIC     fiscal_year_quarter,
# MAGIC     host_name,
# MAGIC     industry,
# MAGIC     inferred_marketing_channel,
# MAGIC     itm_data,
# MAGIC     language,
# MAGIC     local_site_language,
# MAGIC     new_visitor,
# MAGIC     os,
# MAGIC     page_path,
# MAGIC     referrer_hostname,
# MAGIC     region,
# MAGIC     returning_visitor,
# MAGIC     scid,
# MAGIC     scid_marketing_channel_detail,
# MAGIC     scid_marketing_channel_type,
# MAGIC     session_id,
# MAGIC     subregion,
# MAGIC     utm_medium,
# MAGIC     utm_source,
# MAGIC     Visit_Before_Form_Submit,
# MAGIC     visit_before_MQL,
# MAGIC     visit_before_QNNN,
# MAGIC     visit_before_U2_opp,
# MAGIC     entrance,
# MAGIC     exit,
# MAGIC     fiscal_year,
# MAGIC     form_submit_success,
# MAGIC     session_duration,
# MAGIC     COALESCE(
# MAGIC       CASE 
# MAGIC         WHEN SPLIT((REGEXP_SUBSTR(page_path, '\/([^\/]+)\/([^\/]+)')), '/')[1] = 'resources'
# MAGIC         THEN SPLIT((REGEXP_SUBSTR(page_path, '\/([^\/]+)\/([^\/]+)')), '/')[2]
# MAGIC       END,
# MAGIC       'NA'
# MAGIC     ) AS Asset_Type_Extract,
# MAGIC     CONCAT('FY', RIGHT(CAST(fiscal_year AS VARCHAR(4)), 2)) AS Fiscal_Year_Format_Para,
# MAGIC     (YEAR(DATEADD(MONTH, 12, `date`)) * 100 + 
# MAGIC      RIGHT('0' + CAST(MONTH(DATEADD(MONTH, 12, `date`)) AS VARCHAR(2)), 2)) AS Fiscal_Year_Month,
# MAGIC     CASE 
# MAGIC       WHEN MONTH(`date`) < 10 
# MAGIC       THEN CONCAT('FY', 
# MAGIC                   RIGHT(CAST(YEAR(DATEADD(MONTH, 12, `date`)) AS VARCHAR(4)), 2),
# MAGIC                   'M0',
# MAGIC                   CAST(MONTH(`date`) AS VARCHAR(1)))
# MAGIC       ELSE CONCAT('FY', 
# MAGIC                   RIGHT(CAST(YEAR(DATEADD(MONTH, 12, `date`)) AS VARCHAR(4)), 2),
# MAGIC                   'M',
# MAGIC                   CAST(MONTH(`date`) AS VARCHAR(2)))
# MAGIC     END AS Fiscal_Year_Month_Format,
# MAGIC     CONCAT('FY', RIGHT(CAST(fiscal_year AS VARCHAR(4)), 2), CAST(fiscal_quarter AS VARCHAR(1))) AS Fiscal_Year_QTR_Format,
# MAGIC     CAST(LEFT(fiscal_year_quarter, 4) + RIGHT(fiscal_year_quarter, 1) AS INT) AS Fiscal_Year_QTR_Int,
# MAGIC     (YEAR(DATEADD(MONTH, 12, `date`)) * 100 + 
# MAGIC      RIGHT('0' + CAST(WEEKOFYEAR(DATEADD(MONTH, 12, `date`)) AS VARCHAR(2)), 2)) AS Fiscal_Year_Week,
# MAGIC     CASE 
# MAGIC       WHEN WEEKOFYEAR(DATEADD(MONTH, 12, `date`)) < 10
# MAGIC       THEN CONCAT('FY', RIGHT(CAST(YEAR(DATEADD(MONTH, 12, `date`)) AS VARCHAR(4)), 2), 'W0', CAST(WEEKOFYEAR(DATEADD(MONTH, 12, `date`)) AS VARCHAR(1)))
# MAGIC       ELSE CONCAT('FY', RIGHT(CAST(YEAR(DATEADD(MONTH, 12, `date`)) AS VARCHAR(4)), 2), 'W', CAST(WEEKOFYEAR(DATEADD(MONTH, 12, `date`)) AS VARCHAR(2)))
# MAGIC     END AS Fiscal_Year_Week_Format,
# MAGIC     CASE 
# MAGIC       WHEN inferred_marketing_channel <> 'Internal Referral' OR inferred_marketing_channel IS NULL
# MAGIC       THEN 'Internal Referral Exclude'
# MAGIC       ELSE 'Only Internal Referral'
# MAGIC     END AS Internal_Referral_True,
# MAGIC     CASE 
# MAGIC       WHEN audience_persona IS NULL
# MAGIC       THEN 'Nulls'
# MAGIC       ELSE 'Non-Nulls'
# MAGIC     END AS Null_vs_Non_Null_Audience
# MAGIC   FROM main.it_aibi_silver.web_analytics_summary_silver
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   account_name,
# MAGIC   mops_analytics_id,
# MAGIC   audience_persona,
# MAGIC   browser,
# MAGIC   country,
# MAGIC   custom_channel_group,
# MAGIC   `date`,
# MAGIC   dbx_account_group,
# MAGIC   device,
# MAGIC   event_type,
# MAGIC   experiment_viewed,
# MAGIC   fiscal_quarter,
# MAGIC   fiscal_year_quarter,
# MAGIC   host_name,
# MAGIC   industry,
# MAGIC   inferred_marketing_channel,
# MAGIC   itm_data,
# MAGIC   language,
# MAGIC   local_site_language,
# MAGIC   new_visitor,
# MAGIC   os,
# MAGIC   page_path,
# MAGIC   referrer_hostname,
# MAGIC   region,
# MAGIC   returning_visitor,
# MAGIC   scid,
# MAGIC   scid_marketing_channel_detail,
# MAGIC   scid_marketing_channel_type,
# MAGIC   session_id,
# MAGIC   subregion,
# MAGIC   utm_medium,
# MAGIC   utm_source,
# MAGIC   Visit_Before_Form_Submit,
# MAGIC   visit_before_MQL,
# MAGIC   visit_before_QNNN,
# MAGIC   visit_before_U2_opp,
# MAGIC   entrance,
# MAGIC   exit,
# MAGIC   fiscal_year,
# MAGIC   form_submit_success,
# MAGIC   session_duration,
# MAGIC   Asset_Type_Extract,
# MAGIC   Fiscal_Year_Format_Para,
# MAGIC   Fiscal_Year_Month,
# MAGIC   Fiscal_Year_Month_Format,
# MAGIC   Fiscal_Year_QTR_Format,
# MAGIC   Fiscal_Year_QTR_Int,
# MAGIC   Fiscal_Year_Week,
# MAGIC   Fiscal_Year_Week_Format,
# MAGIC   Internal_Referral_True,
# MAGIC   Null_vs_Non_Null_Audience,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN new_visitor = true AND event_type IS NOT NULL THEN mops_analytics_id END) AS Current_Period_New_Visitors,
# MAGIC   COUNT(DISTINCT CASE WHEN new_visitor = true THEN mops_analytics_id END) AS All_Time_New_Visitors,
# MAGIC   COUNT(DISTINCT CASE WHEN new_visitor = true AND event_type IS NOT NULL THEN mops_analytics_id END) AS PP_New_Visitors,
# MAGIC
# MAGIC   CAST(SUM(CASE WHEN entrance = 1 AND exit = 1 THEN 1 ELSE 0 END) AS FLOAT) / 
# MAGIC   NULLIF(SUM(CASE WHEN entrance = 1 THEN 1 ELSE 0 END), 0) AS Current_Period_Bounce_Rate,
# MAGIC
# MAGIC   CAST(SUM(CASE WHEN entrance = 1 AND exit = 1 THEN 1 ELSE 0 END) AS FLOAT) / 
# MAGIC   NULLIF(SUM(CASE WHEN entrance = 1 THEN 1 ELSE 0 END), 0) AS PP_Bounce_Rate,
# MAGIC
# MAGIC   CAST(SUM(CASE WHEN entrance = 1 AND exit = 1 THEN 1 ELSE 0 END) AS FLOAT) / 
# MAGIC   NULLIF(COUNT(mops_analytics_id), 0) AS All_Time_Bounce_Rate,
# MAGIC
# MAGIC   (
# MAGIC     (CAST(SUM(CASE WHEN entrance = 1 AND exit = 1 THEN 1 ELSE 0 END) AS FLOAT) / 
# MAGIC      NULLIF(SUM(CASE WHEN entrance = 1 THEN 1 ELSE 0 END), 0)) -
# MAGIC     (CAST(SUM(CASE WHEN entrance = 1 AND exit = 1 THEN 1 ELSE 0 END) AS FLOAT) / 
# MAGIC      NULLIF(SUM(CASE WHEN entrance = 1 THEN 1 ELSE 0 END), 0))
# MAGIC   ) / 
# MAGIC   NULLIF((CAST(SUM(CASE WHEN entrance = 1 AND exit = 1 THEN 1 ELSE 0 END) AS FLOAT) / 
# MAGIC           NULLIF(SUM(CASE WHEN entrance = 1 THEN 1 ELSE 0 END), 0)), 0) AS QOQ_Bounce_Rate_Change,
# MAGIC
# MAGIC   -- New calculations based on Tableau queries
# MAGIC   COUNT(CASE WHEN entrance = 1 AND exit = 1 THEN mops_analytics_id END) AS Bounced,
# MAGIC
# MAGIC   (COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success'  THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0)) -
# MAGIC   (COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success'  THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0)) /
# MAGIC   NULLIF((COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success'  THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0)), 0) AS QOQ_Form_Submit_Conversion_Rate,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success'  THEN mops_analytics_id END) * 1.0 / 
# MAGIC   NULLIF(COUNT(DISTINCT mops_analytics_id), 0) AS Form_Submit_Conversion_Rate,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success'  THEN mops_analytics_id END) AS Count_of_Mops_before_form_submits,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success' THEN mops_analytics_id END) * 1.0 / 
# MAGIC   NULLIF(COUNT(DISTINCT mops_analytics_id), 0) AS Form_Submit_Conversion_Rate_PP,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success' THEN mops_analytics_id END) AS Count_of_Mops_before_form_submits_PP,
# MAGIC
# MAGIC   (COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success'  THEN mops_analytics_id END) -
# MAGIC    COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success'  THEN mops_analytics_id END)) * 1.0 /
# MAGIC   NULLIF(COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success'  THEN mops_analytics_id END), 0) AS QOQ_Form_Submits,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success'  THEN mops_analytics_id END) AS Unique_Form_Submits,
# MAGIC
# MAGIC   COALESCE(COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success' THEN mops_analytics_id END), 0) AS Form_Submits,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN event_type = 'Form Submit Success' THEN mops_analytics_id END) AS PP_Form_Submits,
# MAGIC
# MAGIC     -- New calculations based on the additional Tableau queries
# MAGIC   (COUNT(DISTINCT CASE WHEN visit_before_MQL = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0) -
# MAGIC    COUNT(DISTINCT CASE WHEN visit_before_MQL = TRUE  THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0)) /
# MAGIC   NULLIF(COUNT(DISTINCT CASE WHEN visit_before_MQL = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0), 0) AS QOQ_MQL_Conversion_Rate,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN visit_before_MQL = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC   NULLIF(COUNT(DISTINCT mops_analytics_id), 0) AS MQL_Conversion_Rate,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN visit_before_MQL = TRUE THEN mops_analytics_id END) AS Count_of_events_that_lead_to_MQL,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN visit_before_MQL = TRUE  THEN mops_analytics_id END) * 1.0 / 
# MAGIC   NULLIF(COUNT(DISTINCT mops_analytics_id), 0) AS MQL_Conversion_Rate_PP,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN visit_before_MQL = TRUE THEN mops_analytics_id END) AS Count_of_events_that_lead_to_MQL_PP,
# MAGIC
# MAGIC     COUNT(CASE WHEN event_type = 'Page Viewed' THEN session_id END) * 1.0 /
# MAGIC   NULLIF(COUNT(DISTINCT session_id), 0) AS Pages_viewed_by_sessions1,
# MAGIC
# MAGIC   COUNT(CASE WHEN event_type = 'Page Viewed' THEN session_id END) * 1.0 /
# MAGIC   NULLIF(COUNT(DISTINCT session_id), 0) AS All_time_pages_viewed_by_sessions2,
# MAGIC
# MAGIC   COUNT(CASE WHEN event_type = 'Page Viewed' THEN page_path END) AS Page_Views,
# MAGIC
# MAGIC   COUNT(CASE WHEN event_type = 'Page Viewed' THEN page_path END) AS Current_period_page_views,
# MAGIC
# MAGIC   COUNT(session_id) * 1.0 /
# MAGIC   NULLIF(COUNT(DISTINCT CASE WHEN new_visitor = true AND event_type IS NOT NULL THEN mops_analytics_id END), 0) AS Pages_viewed_by_sessions3,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN new_visitor = true AND event_type IS NOT NULL THEN mops_analytics_id END) AS Pages_viewed,
# MAGIC
# MAGIC   (COUNT(DISTINCT CASE WHEN visit_before_QNNN = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0) -
# MAGIC    COUNT(DISTINCT CASE WHEN visit_before_QNNN = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0)) /
# MAGIC   NULLIF(COUNT(DISTINCT CASE WHEN visit_before_QNNN = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0), 0) AS QOQ_QNNN_Conv,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN visit_before_QNNN = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC   NULLIF(COUNT(DISTINCT mops_analytics_id), 0) AS QNNN_Conversion_rate,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN visit_before_QNNN = TRUE THEN mops_analytics_id END) AS QNNN,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN visit_before_QNNN = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC   NULLIF(COUNT(DISTINCT mops_analytics_id), 0) AS PP_QNNN_Conversion_rate,
# MAGIC
# MAGIC    -- New calculations based on the additional Tableau queries
# MAGIC   (COUNT(DISTINCT CASE WHEN returning_visitor = true AND event_type IS NOT NULL THEN mops_analytics_id END) -
# MAGIC    COUNT(DISTINCT CASE WHEN returning_visitor = true AND event_type IS NOT NULL THEN mops_analytics_id END)) /
# MAGIC   NULLIF(COUNT(DISTINCT CASE WHEN returning_visitor = true AND event_type IS NOT NULL THEN mops_analytics_id END), 0) AS QOQ_Returning_Visitors,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN returning_visitor = true AND event_type IS NOT NULL THEN mops_analytics_id END) AS Returning_Visitors,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN returning_visitor = true AND event_type IS NOT NULL THEN mops_analytics_id END) AS Current_period_returning_visitors,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN returning_visitor = true AND event_type IS NOT NULL THEN mops_analytics_id END) AS All_time_returning_visitors,
# MAGIC
# MAGIC   (SUM(session_duration) / NULLIF(COUNT(DISTINCT CASE WHEN entrance = 1 THEN session_id END), 0) / 60000000 -
# MAGIC    SUM(session_duration) / NULLIF(COUNT(DISTINCT CASE WHEN entrance = 1 THEN session_id END), 0) / 60000000) /
# MAGIC   NULLIF(SUM(session_duration) / NULLIF(COUNT(DISTINCT CASE WHEN entrance = 1 THEN session_id END), 0) / 60000000, 0) AS QOQ_Session_Duration_in_Mins,
# MAGIC
# MAGIC   SUM(session_duration) / NULLIF(COUNT(DISTINCT CASE WHEN entrance = 1 THEN session_id END), 0) / 60000000 AS Session_Duration_in_Mins,
# MAGIC
# MAGIC   (COUNT(DISTINCT CASE WHEN event_type IS NOT NULL THEN session_id END) -
# MAGIC    COUNT(DISTINCT CASE WHEN event_type IS NOT NULL THEN session_id END)) /
# MAGIC   NULLIF(COUNT(DISTINCT CASE WHEN event_type IS NOT NULL THEN session_id END), 0) AS QOQ_Sessions,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN event_type IS NOT NULL THEN session_id END) AS Sessions,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN event_type IS NOT NULL THEN session_id END) AS Current_period_sessions,
# MAGIC
# MAGIC   COUNT(session_id) AS All_time_sessions,
# MAGIC
# MAGIC   (COUNT(DISTINCT CASE WHEN visit_before_U2_opp = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0) -
# MAGIC    COUNT(DISTINCT CASE WHEN visit_before_U2_opp = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0)) /
# MAGIC   NULLIF(COUNT(DISTINCT CASE WHEN visit_before_U2_opp = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC    NULLIF(COUNT(DISTINCT mops_analytics_id), 0), 0) AS QOQ_U2_Conversion_Rate,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN visit_before_U2_opp = TRUE THEN mops_analytics_id END) * 1.0 / 
# MAGIC   NULLIF(COUNT(DISTINCT mops_analytics_id), 0) AS U2_Conversion_Rate,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN visit_before_U2_opp = TRUE THEN mops_analytics_id END) AS Count_of_events_that_lead_to_U2,
# MAGIC
# MAGIC   (COUNT(DISTINCT CASE WHEN event_type IS NOT NULL THEN mops_analytics_id END) -
# MAGIC    COUNT(DISTINCT CASE WHEN event_type IS NOT NULL THEN mops_analytics_id END)) /
# MAGIC   NULLIF(COUNT(DISTINCT CASE WHEN event_type IS NOT NULL THEN mops_analytics_id END), 0) AS QOQ_Unique_Visitors,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN event_type IS NOT NULL THEN mops_analytics_id END) AS Unique_Visitors,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN event_type IS NOT NULL THEN mops_analytics_id END) AS Current_period_unique_visitors,
# MAGIC
# MAGIC   SUM(CASE WHEN exit = 1 THEN session_duration END) /
# MAGIC   NULLIF(COUNT(DISTINCT CASE WHEN entrance = 1 THEN session_id END), 0) AS Avg_Session_Duration,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN Visit_Before_Form_Submit = TRUE THEN mops_analytics_id END) AS Count_of_Mops_before_Session_Form_Submit_Conversion_Rate,
# MAGIC
# MAGIC   COUNT(DISTINCT CASE WHEN Visit_Before_Form_Submit = TRUE THEN mops_analytics_id END) * 1.0 /
# MAGIC   NULLIF(COUNT(DISTINCT mops_analytics_id), 0) AS Session_Form_Submit_Conv,
# MAGIC
# MAGIC   COUNT(DISTINCT mops_analytics_id) AS Distinct_MOP_ID,
# MAGIC
# MAGIC   MONTH(DATEADD(MONTH, 12, date)) AS Month_extract_from_Date
# MAGIC
# MAGIC
# MAGIC FROM cte
# MAGIC GROUP BY 
# MAGIC   account_name, mops_analytics_id, audience_persona, browser, country, custom_channel_group, 
# MAGIC   `date`, dbx_account_group, device, event_type, experiment_viewed, fiscal_quarter, 
# MAGIC   fiscal_year_quarter, host_name, industry, inferred_marketing_channel, itm_data, language, 
# MAGIC   local_site_language, new_visitor, os, page_path, referrer_hostname, region, returning_visitor, 
# MAGIC   scid, scid_marketing_channel_detail, scid_marketing_channel_type, session_id, subregion, 
# MAGIC   utm_medium, utm_source, Visit_Before_Form_Submit, visit_before_MQL, visit_before_QNNN, 
# MAGIC   visit_before_U2_opp, entrance, exit, fiscal_year, form_submit_success, session_duration,
# MAGIC   Asset_Type_Extract, Fiscal_Year_Format_Para, Fiscal_Year_Month, Fiscal_Year_Month_Format,
# MAGIC   Fiscal_Year_QTR_Format, Fiscal_Year_QTR_Int, Fiscal_Year_Week, Fiscal_Year_Week_Format,
# MAGIC   Internal_Referral_True, Null_vs_Non_Null_Audience

# COMMAND ----------


