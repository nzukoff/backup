# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.web_analytics_summary_silver as
# MAGIC
# MAGIC select 
# MAGIC account_name,
# MAGIC audience_persona,
# MAGIC browser,
# MAGIC country,
# MAGIC custom_channel_group,
# MAGIC `date`,
# MAGIC dbx_account_group,
# MAGIC device,
# MAGIC event_type,
# MAGIC experiment_viewed,
# MAGIC fiscal_quarter,
# MAGIC fiscal_year_quarter,
# MAGIC host_name,
# MAGIC industry,
# MAGIC inferred_marketing_channel,
# MAGIC itm_data,
# MAGIC language,
# MAGIC local_site_language,
# MAGIC new_visitor,
# MAGIC os,
# MAGIC page_path,
# MAGIC referrer_hostname,
# MAGIC region,
# MAGIC returning_visitor,
# MAGIC scid,
# MAGIC scid_marketing_channel_detail,
# MAGIC scid_marketing_channel_type,
# MAGIC session_id,
# MAGIC subregion,
# MAGIC utm_medium,
# MAGIC utm_source,
# MAGIC Visit_Before_Form_Submit,
# MAGIC visit_before_MQL,
# MAGIC visit_before_QNNN,
# MAGIC visit_before_U2_opp,
# MAGIC entrance,
# MAGIC exit,
# MAGIC fiscal_year,
# MAGIC form_submit_success,
# MAGIC mops_analytics_id,
# MAGIC session_duration
# MAGIC from main.marketing_lakehouse.gold_web_event
# MAGIC
