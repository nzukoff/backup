# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.web_analytics_overview_silver as
# MAGIC
# MAGIC select
# MAGIC `date`,
# MAGIC device,
# MAGIC full_country,
# MAGIC page,
# MAGIC query,
# MAGIC search_type,
# MAGIC clicks,
# MAGIC impressions,
# MAGIC position
# MAGIC from main.marketing_lakehouse.gold_google_search_console_page
