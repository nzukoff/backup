# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.web_analytics_overview_gold as
# MAGIC
# MAGIC SELECT
# MAGIC   date,
# MAGIC   device,
# MAGIC   full_country,
# MAGIC   page,
# MAGIC   query,
# MAGIC   search_type,
# MAGIC   clicks,
# MAGIC   impressions,
# MAGIC   position,
# MAGIC   -- Fiscal Year Date
# MAGIC   YEAR(DATEADD(MONTH, 11, date)) AS fiscal_year_date,
# MAGIC   -- Fiscal YR Month
# MAGIC   (YEAR(DATEADD(MONTH, 11, date)) * 100) + MONTH(DATEADD(MONTH, 11, date)) AS fiscal_yr_month,
# MAGIC   -- Fiscal Month Date
# MAGIC   MONTH(DATEADD(MONTH, 11, date)) AS fiscal_month_date,
# MAGIC   -- Fiscal Year Week
# MAGIC   (YEAR(DATEADD(MONTH, 11, date)) * 100) + WEEKOFYEAR(DATEADD(MONTH, 11, date)) AS fiscal_year_week,
# MAGIC   -- Fiscal Week Date
# MAGIC   WEEKOFYEAR(DATEADD(MONTH, 11, date)) AS fiscal_week_date,
# MAGIC   -- Fiscal YR QTR
# MAGIC   (YEAR(DATEADD(MONTH, 11, date)) * 10) + QUARTER(DATEADD(MONTH, 11, date)) AS fiscal_yr_qtr,
# MAGIC   -- Fiscal QTR Date
# MAGIC   QUARTER(DATEADD(MONTH, 11, date)) AS fiscal_qtr_date,
# MAGIC   -- CTR (Click-Through Rate)
# MAGIC   CASE 
# MAGIC     WHEN SUM(impressions) OVER (PARTITION BY date, device, full_country, page, query, search_type) > 0 
# MAGIC     THEN CAST(SUM(clicks) OVER (PARTITION BY date, device, full_country, page, query, search_type) AS FLOAT) / 
# MAGIC          SUM(impressions) OVER (PARTITION BY date, device, full_country, page, query, search_type)
# MAGIC     ELSE NULL
# MAGIC   END AS ctr
# MAGIC FROM main.it_aibi_silver.web_analytics_overview_silver
