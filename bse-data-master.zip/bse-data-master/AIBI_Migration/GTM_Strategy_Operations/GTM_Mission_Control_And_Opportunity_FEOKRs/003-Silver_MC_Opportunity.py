# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.femissioncontrol_opp_silver as
# MAGIC
# MAGIC SELECT
# MAGIC   opad.opportunity_id,
# MAGIC   opad.opportunity_name,
# MAGIC   opad.opportunity_stage,
# MAGIC   opad.opportunity_start_date,
# MAGIC   opad.opportunity_end_date,
# MAGIC   opad.oppty_contract_length,
# MAGIC   opad.opportunity_type,
# MAGIC   opad.forecast_category,
# MAGIC   opad.opportunity_owner,
# MAGIC   opad.opportunity_owner_role,
# MAGIC   opad.opportunity_region,
# MAGIC   opad.opportunity_role_region,
# MAGIC   opad.opportunity_subregion_level_1,
# MAGIC   opad.opportunity_subregion_level_2,
# MAGIC   opad.opportunity_subregion_level_3,
# MAGIC   opad.close_date,
# MAGIC   opad.opportunity_close_fiscal_month,
# MAGIC   opad.opportunity_close_fiscal_quarter,
# MAGIC   opad.opportunity_close_fiscal_year,
# MAGIC   opad.opportunity_close_fiscal_year_month,
# MAGIC   opad.opportunity_close_fiscal_year_quarter,
# MAGIC   opad.commit_start_date,
# MAGIC   opad.created_date,
# MAGIC   opad.account_id,
# MAGIC   opad.CSE_Subscription_Tier__c AS cse_subscription_tier,
# MAGIC   opad.Subscription_End_Date__c AS subscription_end_date,
# MAGIC   opad.unused_success_credits_quantity,
# MAGIC   opad.unused_success_credits_value,
# MAGIC   opad.business_unit,
# MAGIC   opad.account_executive,
# MAGIC   opad.sales_leader,
# MAGIC   opad.sales_manager,
# MAGIC   opad.solution_architect,
# MAGIC   opad.field_manager,
# MAGIC   opad.field_leader,
# MAGIC   opad.account_name,
# MAGIC   opad.account_region,
# MAGIC   opad.account_subregion_level_1,
# MAGIC   opad.account_subregion_level_2,
# MAGIC   opad.account_subregion_level_3,
# MAGIC   opad.account_status,
# MAGIC   opad.t3_annualized_band,
# MAGIC   opad.success_credits_attached,
# MAGIC   opad.dsa_attached,
# MAGIC   opad.services_attached,
# MAGIC   opad.training_attached,
# MAGIC   opad.has_dsa_dollars,
# MAGIC   opad.has_services_dollars,
# MAGIC   opad.has_success_credit_dollars,
# MAGIC   opad.has_training_dollars,
# MAGIC   opad.dsa_incremental_booking,
# MAGIC   opad.ps_bookings_incremental_booking,
# MAGIC   opad.success_credits_incremental_booking,
# MAGIC   opad.training_incremental_booking,
# MAGIC   opad.total_opportunity_amount,
# MAGIC   opad.commit_booking_amount,
# MAGIC   opad.incremental_booking_total_forecast,
# MAGIC   opad.implementation_partner_name,
# MAGIC   cop.product_name AS cop_product_name
# MAGIC FROM 
# MAGIC   main.gtm_data.opportunity_product_attach_details opad
# MAGIC LEFT JOIN 
# MAGIC   (SELECT DISTINCT opportunity_id, product_name
# MAGIC    FROM main.gtm_data.core_opportunity_product
# MAGIC    WHERE product_name IN ('CS Subscription Gold', 'CS Subscription Platinum', 'CS Subscription Silver')
# MAGIC    AND snapshot_date = (SELECT MAX(snapshot_date) FROM main.gtm_data.core_opportunity_product)) cop
# MAGIC ON 
# MAGIC   opad.opportunity_id = cop.opportunity_id
