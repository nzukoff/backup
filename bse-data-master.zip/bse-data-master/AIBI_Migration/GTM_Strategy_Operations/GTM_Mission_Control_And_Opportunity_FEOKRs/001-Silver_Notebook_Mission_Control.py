# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE  main.it_aibi_silver.femissioncontrol_silver
# MAGIC
# MAGIC with investment as (
# MAGIC   SELECT
# MAGIC    a.account_id
# MAGIC   ,SUM(a.investment_amount) as investment_amount
# MAGIC   FROM main.gtm_data.core_fund_request a
# MAGIC   WHERE
# MAGIC   snapshot_date = (SELECT MAX(snapshot_date) FROM main.gtm_data.core_fund_request)
# MAGIC   AND account_name NOT ILIKE '%Test%'
# MAGIC   AND approval_status IN ('Approved')
# MAGIC   GROUP BY 1 
# MAGIC )
# MAGIC
# MAGIC
# MAGIC , customer_portfolio_account_base AS (
# MAGIC select
# MAGIC   a.account_id
# MAGIC , account_name
# MAGIC , use_case_pipe_count
# MAGIC , use_case_pipe_dbu_dollar_monthly
# MAGIC , use_case_live_count
# MAGIC , use_case_live_dbu_dollars_monthly
# MAGIC , open_use_case_count_poc_needed
# MAGIC , open_use_case_count_poc_needed_w_30_days_since_modification
# MAGIC , bif_bookings
# MAGIC , bif_billings
# MAGIC , ps_rev_cq  
# MAGIC , training_rev_cq  
# MAGIC , ps_rev_nq 
# MAGIC , training_rev_nq 
# MAGIC , dsa_type 
# MAGIC , dsa_active_project_count
# MAGIC , tech_svcs_engaged
# MAGIC , tech_svcs_engaged_enablement
# MAGIC , certification_count
# MAGIC , ssa_tickets
# MAGIC , has_dsa
# MAGIC , arr
# MAGIC , delivery_partners
# MAGIC , business_unit
# MAGIC , sales_subregion_level_1 as BU_plus1
# MAGIC , sales_subregion_level_2 as BU_plus2
# MAGIC , sales_subregion_level_3 as BU_plus3
# MAGIC , sa_manager
# MAGIC , last_solution_architect_engaged AS sa_name
# MAGIC , account_executive
# MAGIC , sales_manager
# MAGIC , sales_leader
# MAGIC , rank_global
# MAGIC , rank_bu
# MAGIC , rank_bu_plus1
# MAGIC , IFNULL(dbu_dollars_t3m_annualized,0) AS dbu_dollars_t3m_annualized
# MAGIC , IFNULL(commit_amount,0) AS commit_amount
# MAGIC , largest_contract_commit_12m
# MAGIC , ae_forecast_cq
# MAGIC , ds_forecast_cq
# MAGIC , target_cq
# MAGIC , ae_forecast_cq_attainment
# MAGIC , ds_forecast_cq_attainment
# MAGIC , og_forecast_cq_attainment
# MAGIC , og_forecast_plus_pipe_weighted_cq as og_forecast_cq
# MAGIC , ae_forecast_nq
# MAGIC , null as target_nq --- no targets available
# MAGIC , unused_success_credits_value
# MAGIC , dbu_dollars_total_latest_completed_quarter
# MAGIC , dbu_dollars_t3m
# MAGIC , dbu_dollars_t3m_annualized_bucket
# MAGIC , ps_unscheduled_backlog
# MAGIC , open_use_case_count_poc_in_progress
# MAGIC , b.investment_amount
# MAGIC FROM main.gtm_data.customer_portfolio_account_list a
# MAGIC LEFT JOIN investment b on b.account_id = a.account_id 
# MAGIC )
# MAGIC
# MAGIC ,
# MAGIC
# MAGIC dates_base AS (
# MAGIC select 
# MAGIC distinct
# MAGIC a.date,
# MAGIC b.fiscal_quarter_start_date AS current_date_fiscal_quarter_start_date,
# MAGIC b.fiscal_quarter_end_date AS current_date_fiscal_quarter_end_date,
# MAGIC c.fiscal_quarter_start_date AS next_fiscal_quarter_start_date,
# MAGIC c.fiscal_quarter_end_date AS next_fiscal_quarter_end_date,
# MAGIC d.fiscal_quarter_start_date AS next_next_fiscal_quarter_start_date,
# MAGIC d.fiscal_quarter_end_date AS next_next_fiscal_quarter_end_date,
# MAGIC e.fiscal_quarter_start_date AS prior_fiscal_quarter_start_date,
# MAGIC e.fiscal_quarter_end_date AS prior_fiscal_quarter_end_date,
# MAGIC f.fiscal_quarter_start_date AS prior_prior_fiscal_quarter_start_date,
# MAGIC f.fiscal_quarter_end_date AS prior_prior_fiscal_quarter_end_date
# MAGIC FROM main.it_core_dim.dim_dates a LEFT JOIN main.it_core_dim.dim_dates b ON current_date() = b.date 
# MAGIC LEFT JOIN main.it_core_dim.dim_dates c ON DATEADD(day,1,b.fiscal_quarter_end_date) = c.fiscal_quarter_start_date ---JOIN to get the next quarter's start date and end date
# MAGIC LEFT JOIN main.it_core_dim.dim_dates d ON DATEADD(day,1,c.fiscal_quarter_end_date) = d.fiscal_quarter_start_date ---JOIN to get next next quarter's start date and end date
# MAGIC LEFT JOIN main.it_core_dim.dim_dates e ON b.date_of_prior_quarter = e.date ---JOIN to get the prior quarter's start date and end date
# MAGIC LEFT JOIN main.it_core_dim.dim_dates f ON e.date_of_prior_quarter = f.date---JOIN to get the prior prior quarter's 
# MAGIC )
# MAGIC
# MAGIC , contracts AS(
# MAGIC SELECT 
# MAGIC *
# MAGIC   FROM (
# MAGIC   select distinct 
# MAGIC   account_id, 
# MAGIC   is_in_progress_ind,
# MAGIC   is_primary_contract_ind,
# MAGIC   contract_start_date,
# MAGIC   contract_end_date,
# MAGIC   ---End Date window
# MAGIC   CASE WHEN contract_end_date >= b.current_date_fiscal_quarter_start_date AND contract_end_date <= b.current_date_fiscal_quarter_end_date 
# MAGIC   THEN 'Ends current quarter' 
# MAGIC   WHEN contract_end_date >= b.next_fiscal_quarter_start_date AND contract_end_date <= b.next_fiscal_quarter_end_date 
# MAGIC   THEN 'Ends next fiscal quarter' 
# MAGIC   WHEN contract_end_date >= b.next_next_fiscal_quarter_start_date AND a.contract_end_date <= b.next_next_fiscal_quarter_end_date
# MAGIC   THEN 'Ends next next fiscal quarter' 
# MAGIC   WHEN contract_end_date >= b.prior_fiscal_quarter_start_date AND a.contract_end_date <= b.prior_fiscal_quarter_end_date THEN 
# MAGIC   'Ended prior fiscal quarter'
# MAGIC   WHEN contract_end_date >= b.prior_prior_fiscal_quarter_start_date AND a.contract_end_date <= b.prior_prior_fiscal_quarter_end_date
# MAGIC   THEN 'Ended prior prior fiscal quarter'
# MAGIC   WHEN a.contract_end_date >= b.next_next_fiscal_quarter_end_date THEN 'Ends beyond next next fiscal quarter'
# MAGIC   END as contract_end_date_window,
# MAGIC   ---Start Date window
# MAGIC   CASE WHEN contract_start_date >= c.current_date_fiscal_quarter_start_date AND contract_start_date <= c.current_date_fiscal_quarter_end_date 
# MAGIC   THEN 'Starts current quarter' 
# MAGIC   WHEN contract_start_date >= c.next_fiscal_quarter_start_date AND contract_start_date <= c.next_fiscal_quarter_end_date 
# MAGIC   THEN 'Starts next fiscal quarter' 
# MAGIC   WHEN contract_start_date >= c.next_next_fiscal_quarter_start_date AND contract_start_date <= c.next_next_fiscal_quarter_end_date
# MAGIC   THEN 'Starts next next fiscal quarter' 
# MAGIC   WHEN contract_start_date >= c.prior_fiscal_quarter_start_date AND contract_start_date <= c.prior_fiscal_quarter_end_date THEN 
# MAGIC   'Started prior fiscal quarter'
# MAGIC   WHEN contract_start_date >= c.prior_prior_fiscal_quarter_start_date AND contract_start_date <= c.prior_prior_fiscal_quarter_end_date
# MAGIC   THEN 'Started prior prior fiscal quarter'
# MAGIC   WHEN contract_start_date >= c.next_next_fiscal_quarter_end_date THEN 'Starts beyond next next fiscal quarter'
# MAGIC   END as contract_start_date_window
# MAGIC   ,ROW_NUMBER() OVER (PARTITION BY a.account_id ORDER BY IFNULL(commit_trr_annualized,0) desc) as row_num
# MAGIC   FROM main.gtm_data.core_commit_measures a 
# MAGIC   LEFT JOIN dates_base b ON a.contract_end_date = b.date
# MAGIC   LEFT JOIN dates_base c ON a.contract_start_date = c.date
# MAGIC   WHERE is_in_progress_ind = 'true'
# MAGIC   AND is_primary_contract_ind = 'true'
# MAGIC   )
# MAGIC   WHERE 1=1
# MAGIC   AND row_num =1
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC  a.account_id
# MAGIC ,a.account_name
# MAGIC ,a.dsa_type 
# MAGIC ,a.has_dsa
# MAGIC ,a.business_unit
# MAGIC ,a.BU_plus1
# MAGIC ,a.BU_plus2
# MAGIC ,a.BU_plus3
# MAGIC ,a.sa_manager
# MAGIC ,a.sa_name
# MAGIC ,a.account_executive
# MAGIC ,a.sales_manager
# MAGIC ,a.sales_leader
# MAGIC ,a.rank_global
# MAGIC ,a.rank_bu
# MAGIC ,a.rank_bu_plus1
# MAGIC ,a.ps_unscheduled_backlog
# MAGIC ,b.contract_end_date_window
# MAGIC ,b.contract_start_date_window
# MAGIC ,IFNULL(a.use_case_pipe_count,0) as use_case_pipe_count
# MAGIC ,IFNULL(a.use_case_pipe_dbu_dollar_monthly,0) as use_case_pipe_dbu_dollar_monthly
# MAGIC ,IFNULL(a.use_case_live_count,0) as use_case_live_count
# MAGIC ,IFNULL(a.use_case_live_dbu_dollars_monthly,0) as use_case_live_dbu_dollars_monthly
# MAGIC ,IFNULL(a.open_use_case_count_poc_needed,0) as open_use_case_count_poc_needed
# MAGIC ,IFNULL(a.open_use_case_count_poc_in_progress,0) as open_use_case_count_poc_in_progress
# MAGIC ,IFNULL(a.open_use_case_count_poc_needed_w_30_days_since_modification,0) as open_use_case_count_poc_needed_w_30_days_since_modification
# MAGIC -- ,IFNULL(a.bif_bookings,0) as bif_bookings
# MAGIC -- ,IFNULL(a.bif_billings,0) as bif_billings
# MAGIC ,IFNULL(a.ps_rev_cq,0) as ps_rev_cq  
# MAGIC ,IFNULL(a.training_rev_cq,0) as training_rev_cq  
# MAGIC ,IFNULL(a.ps_rev_nq,0) as ps_rev_nq 
# MAGIC ,IFNULL(a.training_rev_nq,0) as training_rev_nq 
# MAGIC ,IFNULL(a.tech_svcs_engaged,0) as tech_svcs_engaged
# MAGIC ,IFNULL(a.tech_svcs_engaged_enablement,0) as tech_svcs_engaged_enablement
# MAGIC ,IFNULL(a.certification_count,0) as certification_count
# MAGIC ,IFNULL(a.ssa_tickets,0) as ssa_tickets
# MAGIC ,IFNULL(a.arr,0) as arr
# MAGIC ,IFNULL(a.dsa_active_project_count,0) as dsa_active_project_count
# MAGIC ,IFNULL(a.delivery_partners,0) as delivery_partners
# MAGIC ,IFNULL(a.dbu_dollars_t3m_annualized,0) as dbu_dollars_t3m_annualized
# MAGIC -- ,IFNULL(a.commit_amount,0) as commit_amount
# MAGIC -- ,IFNULL(a.largest_contract_commit_12m,0) as largest_contract_commit_12m
# MAGIC ,IFNULL(a.ae_forecast_cq,0) as ae_forecast_cq
# MAGIC ,IFNULL(a.ds_forecast_cq,0) as ds_forecast_cq
# MAGIC ,IFNULL(a.target_cq,0) as target_cq
# MAGIC ,IFNULL(a.ae_forecast_cq_attainment,0) as ae_forecast_cq_attainment
# MAGIC ,IFNULL(a.ds_forecast_cq_attainment,0) as ds_forecast_cq_attainment
# MAGIC ,IFNULL(a.og_forecast_cq_attainment,0) as og_forecast_cq_attainment
# MAGIC ,IFNULL(a.og_forecast_cq,0) as og_forecast_cq
# MAGIC ,IFNULL(a.ae_forecast_nq,0) as ae_forecast_nq
# MAGIC ,IFNULL(a.unused_success_credits_value,0) as unused_success_credits_value
# MAGIC ,IFNULL(a.dbu_dollars_total_latest_completed_quarter,0) as dbu_dollars_total_latest_completed_quarter
# MAGIC ,IFNULL(a.dbu_dollars_t3m,0) as dbu_dollars_t3m
# MAGIC ,IFNULL(TRY_CAST(a.dbu_dollars_t3m_annualized_bucket AS BIGINT),0) as dbu_dollars_t3m_annualized_bucket
# MAGIC ,IFNULL(a.investment_amount,0) as investment_amount
# MAGIC ,CASE WHEN a.arr > 60000 AND a.sa_name is null THEN 1 ELSE 0 END as accounts_greater_than_60k_w_no_sa
# MAGIC ,current_date() as run_date 
# MAGIC FROM customer_portfolio_account_base a 
# MAGIC LEFT JOIN contracts b ON a.account_id = b.account_id
