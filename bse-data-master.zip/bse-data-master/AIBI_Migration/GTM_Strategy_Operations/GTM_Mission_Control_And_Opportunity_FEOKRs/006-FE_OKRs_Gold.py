# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.feokr_gold as
# MAGIC
# MAGIC select 
# MAGIC customer_account_id as account_id,
# MAGIC customer_account_executive as ae, --AE
# MAGIC customer_brag_status as brag, --BRAG
# MAGIC customer_business_unit as bu, --BU
# MAGIC customer_customer_success_engineer_tier as cse_tier, --CSE Tier
# MAGIC customer_sales_subregion_level_1 as bu_1, --BU+1
# MAGIC DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365.0 AS cust_age_years, --cust age (years)
# MAGIC CASE 
# MAGIC   WHEN FLOOR(DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365) < 1 THEN 0
# MAGIC   WHEN FLOOR(DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365) < 2 THEN 1
# MAGIC   WHEN FLOOR(DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365) < 3 THEN 2
# MAGIC   WHEN FLOOR(DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365) < 4 THEN 3
# MAGIC   WHEN FLOOR(DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365) < 5 THEN 4
# MAGIC   ELSE 5
# MAGIC   END AS cust_age_bucket, --cust age buckets
# MAGIC customer_customer_type as customer_type,
# MAGIC customer_dbu_dollars_t3m_annualized_bucket as dbu_dollars_t3m_annualized_bucket,
# MAGIC customer_has_cloud_migration as has_cloud_migration,
# MAGIC customer_is_pvc_pubsec as is_pvc_pubsec,
# MAGIC customer_manager_name as manager_name,
# MAGIC customer_account_name as name, --Name
# MAGIC customer_partner_sales_manager as partner_sales_manager,
# MAGIC customer_rank_global as rank_global,
# MAGIC customer_sales_leader as sales_leader,
# MAGIC customer_sales_manager as sales_manager,
# MAGIC customer_last_solution_architect_engaged as sa, --SA
# MAGIC sales_region as region, --Region
# MAGIC customer_account_status as status, --Status
# MAGIC customer_sales_subregion_level_2 as subregion_level_2, --Subregion Level 2
# MAGIC customer_sales_subregion_level_3 as subregion_level_3, --Subregion Level 3
# MAGIC customer_support_tier as support_tier,
# MAGIC customer_vertical as vertical,
# MAGIC customer_dbu_dollars_t3m_annualized as dbu_dollars_t3m_annualized,
# MAGIC customer_dbu_dollars_last30_current as dbu_dollars_total_last30_current, --dbu_dollars_total_last30_current
# MAGIC customer_dbu_dollars_last90_current as dbu_dollars_total_last90_current, --dbu_dollars_total_last90_current
# MAGIC CASE 
# MAGIC     WHEN dbu_dollars_total_last90_current > 0 THEN 'Yes'
# MAGIC     ELSE 'No'
# MAGIC END AS account_has_uc_enabled, --Account has UC Enabled
# MAGIC customer_dbu_dollars_unity_catalog_30d_diff as dbu_dollars_unity_catalog_30d_diff,
# MAGIC customer_dbu_dollars_unity_catalog_30d_growth_pct as dbu_dollars_unity_catalog_30d_growth_pct,
# MAGIC customer_dbu_dollars_unity_catalog_last30_current as dbu_dollars_unity_catalog_last30_current,
# MAGIC customer_mau_latest_date as mau_latest_date,
# MAGIC customer_rank_bu as rank_bu,
# MAGIC customer_rank_bu_plus1 as rank_bu_plus1,
# MAGIC customer_UC_MAU as uc_mau,
# MAGIC customer_UC_MAU_growth as uc_mau_growth,
# MAGIC customer_UC_MAU_over_DB_MAU as uc_mau_over_du_mau,
# MAGIC customer_UC_WAU as uc_wau,
# MAGIC business_unit,
# MAGIC date_grain,
# MAGIC DATE(CASE date_grain
# MAGIC     WHEN 'Monthly' THEN DATE_TRUNC('MONTH', month_start_date)
# MAGIC     WHEN 'Daily' THEN DATE_TRUNC('DAY', month_start_date)
# MAGIC     WHEN 'Weekly' THEN DATE_TRUNC('WEEK', month_start_date)
# MAGIC END) AS consumption_date_parameterized, --Consumption Date (Parameterized)
# MAGIC month_start_date,
# MAGIC uc_mau_over_time,
# MAGIC uc_wau_over_time,
# MAGIC unity_catalog_dollars,
# MAGIC COUNT(DISTINCT CASE WHEN unity_catalog_dollars > 0 THEN customer_account_id END) AS accounts_w_uc_enabled_trending, --Accounts w/ UC Enabled (trending) (for % Accounts w/ UC Enabled)
# MAGIC COUNT(DISTINCT CASE WHEN customer_dbu_dollars_t3m_annualized > 0 THEN customer_account_id END) AS total_accounts, --Total Accounts (for % Accounts w/ UC Enabled)
# MAGIC COUNT(DISTINCT CASE WHEN customer_dbu_dollars_unity_catalog_last30_current > 0 THEN customer_account_id END) AS accounts_w_uc_enabled_static, --Accounts w/ UC Enabled (static) (for % Accounts w/ UC Enabled (copy))
# MAGIC COUNT(DISTINCT customer_account_id) AS account_count,
# MAGIC SUM(customer_uc_mau)/SUM(customer_mau_latest_date) AS uc_mau_pct_of_total --UC MAUs / Total MAUs
# MAGIC from main.it_aibi_silver.feokr_silver 
# MAGIC GROUP BY ALL
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.feokr_gold_view as
# MAGIC SELECT 
# MAGIC     customer_account_id AS account_id,
# MAGIC     customer_account_executive AS ae, -- AE
# MAGIC     customer_brag_status AS brag, -- BRAG
# MAGIC     customer_business_unit AS bu, -- BU
# MAGIC     customer_customer_success_engineer_tier AS cse_tier, -- CSE Tier
# MAGIC     customer_sales_subregion_level_1 AS bu_1, -- BU+1
# MAGIC     DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365.0 AS cust_age_years, -- cust age (years)
# MAGIC     CASE 
# MAGIC         WHEN FLOOR(DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365) < 1 THEN 0
# MAGIC         WHEN FLOOR(DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365) < 2 THEN 1
# MAGIC         WHEN FLOOR(DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365) < 3 THEN 2
# MAGIC         WHEN FLOOR(DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365) < 4 THEN 3
# MAGIC         WHEN FLOOR(DATE_DIFF(CURRENT_DATE(), customer_start_date) / 365) < 5 THEN 4
# MAGIC         ELSE 5
# MAGIC     END AS cust_age_bucket, -- cust age buckets
# MAGIC     customer_customer_type AS customer_type,
# MAGIC     customer_dbu_dollars_t3m_annualized_bucket AS dbu_dollars_t3m_annualized_bucket,
# MAGIC     customer_has_cloud_migration AS has_cloud_migration,
# MAGIC     customer_is_pvc_pubsec AS is_pvc_pubsec,
# MAGIC     customer_manager_name AS manager_name,
# MAGIC     customer_account_name AS name, -- Name
# MAGIC     customer_partner_sales_manager AS partner_sales_manager,
# MAGIC     customer_rank_global AS rank_global,
# MAGIC     customer_sales_leader AS sales_leader,
# MAGIC     customer_sales_manager AS sales_manager,
# MAGIC     customer_last_solution_architect_engaged AS sa, -- SA
# MAGIC     sales_region AS region, -- Region
# MAGIC     customer_account_status AS status, -- Status
# MAGIC     customer_sales_subregion_level_2 AS subregion_level_2, -- Subregion Level 2
# MAGIC     customer_sales_subregion_level_3 AS subregion_level_3, -- Subregion Level 3
# MAGIC     customer_support_tier AS support_tier,
# MAGIC     customer_vertical AS vertical,
# MAGIC     customer_dbu_dollars_t3m_annualized AS dbu_dollars_t3m_annualized,
# MAGIC     customer_dbu_dollars_last30_current AS dbu_dollars_total_last30_current, -- dbu_dollars_total_last30_current
# MAGIC     customer_dbu_dollars_last90_current AS dbu_dollars_total_last90_current, -- dbu_dollars_total_last90_current
# MAGIC     CASE 
# MAGIC         WHEN dbu_dollars_total_last90_current > 0 THEN 'Yes'
# MAGIC         ELSE 'No'
# MAGIC     END AS account_has_uc_enabled, -- Account has UC Enabled
# MAGIC     customer_dbu_dollars_unity_catalog_30d_diff AS dbu_dollars_unity_catalog_30d_diff,
# MAGIC     customer_dbu_dollars_unity_catalog_30d_growth_pct AS dbu_dollars_unity_catalog_30d_growth_pct,
# MAGIC     customer_dbu_dollars_unity_catalog_last30_current AS dbu_dollars_unity_catalog_last30_current,
# MAGIC     customer_mau_latest_date AS mau_latest_date,
# MAGIC     customer_rank_bu AS rank_bu,
# MAGIC     customer_rank_bu_plus1 AS rank_bu_plus1,
# MAGIC     customer_UC_MAU AS uc_mau,
# MAGIC     customer_UC_MAU_growth AS uc_mau_growth,
# MAGIC     customer_UC_MAU_over_DB_MAU AS uc_mau_over_du_mau,
# MAGIC     customer_UC_WAU AS uc_wau,
# MAGIC     business_unit,
# MAGIC     date_grain,
# MAGIC     DATE(
# MAGIC         CASE date_grain
# MAGIC             WHEN 'Monthly' THEN DATE_TRUNC('MONTH', month_start_date)
# MAGIC             WHEN 'Daily' THEN DATE_TRUNC('DAY', month_start_date)
# MAGIC             WHEN 'Weekly' THEN DATE_TRUNC('WEEK', month_start_date)
# MAGIC         END
# MAGIC     ) AS consumption_date_parameterized, -- Consumption Date (Parameterized)
# MAGIC     month_start_date,
# MAGIC     uc_mau_over_time,
# MAGIC     uc_wau_over_time,
# MAGIC     unity_catalog_dollars,
# MAGIC     COUNT(DISTINCT CASE WHEN unity_catalog_dollars > 0 THEN customer_account_id END) AS accounts_w_uc_enabled_trending, -- Accounts w/ UC Enabled (trending) (for % Accounts w/ UC Enabled)
# MAGIC     COUNT(DISTINCT CASE WHEN customer_dbu_dollars_t3m_annualized > 0 THEN customer_account_id END) AS total_accounts, -- Total Accounts (for % Accounts w/ UC Enabled)
# MAGIC     COUNT(DISTINCT CASE WHEN customer_dbu_dollars_unity_catalog_last30_current > 0 THEN customer_account_id END) AS accounts_w_uc_enabled_static, -- Accounts w/ UC Enabled (static) (for % Accounts w/ UC Enabled (copy))
# MAGIC     COUNT(DISTINCT customer_account_id) AS account_count,
# MAGIC     SUM(customer_uc_mau) / SUM(customer_mau_latest_date) AS uc_mau_pct_of_total -- UC MAUs / Total MAUs
# MAGIC FROM 
# MAGIC     main.it_aibi_silver.feokr_silver
# MAGIC GROUP BY 
# MAGIC     ALL
