# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.femissioncontrol_opp_gold
# MAGIC
# MAGIC SELECT
# MAGIC   business_unit AS account_bu,
# MAGIC   cse_subscription_tier AS account_dsa_subscription_tier,
# MAGIC   account_name,
# MAGIC   account_subregion_level_1 AS account_subregion_lvl_1,
# MAGIC   account_subregion_level_2 AS account_subregion_lvl_2,
# MAGIC   account_subregion_level_3 AS account_subregion_lvl_3,
# MAGIC   try_cast(t3_annualized_band AS BIGINT) AS acct_t3m_annualized_brand,
# MAGIC   account_executive AS ae,
# MAGIC   nullif(sum(oppty_contract_length / 31), 0) AS contract_length_months,
# MAGIC   dsa_attached,
# MAGIC   forecast_category AS fcst_category,
# MAGIC   field_leader,
# MAGIC   field_manager,
# MAGIC   CASE WHEN has_dsa_dollars = 'No' OR has_dsa_dollars IS NULL THEN 'No' ELSE 'Yes' END AS has_dsa_dollars,
# MAGIC   CASE WHEN implementation_partner_name = 'No Implementation Partner Involved' THEN 'No' ELSE 'Yes' END AS has_implementation_partner,
# MAGIC   CASE WHEN has_services_dollars = 'No' OR has_services_dollars IS NULL THEN 'No' ELSE 'Yes' END as has_ps_bookings_dollars,
# MAGIC   CASE WHEN has_success_credit_dollars = 'No' or has_success_credit_dollars IS NULL THEN 'No' ELSE 'Yes' END as has_success_credit_dollars,
# MAGIC   CASE WHEN 
# MAGIC     (CASE WHEN training_incremental_booking > 0 THEN "Yes" Else "No" END) = 'No' or (CASE WHEN training_incremental_booking > 0 THEN "Yes" Else "No" END) IS NULL THEN 'No' ELSE 'Yes' END as has_training_dollars,
# MAGIC   opportunity_subregion_level_1,
# MAGIC   opportunity_subregion_level_2,
# MAGIC   opportunity_subregion_level_3,
# MAGIC   close_date as oppty_close_date,
# MAGIC   date_trunc('MONTH', close_date) as oppty_close_date_months,
# MAGIC   date_trunc('QUARTER', close_date) as oppty_close_date_quarters,
# MAGIC   date_trunc('WEEK NUMBER', close_date) as oppty_close_date_week_numbers,
# MAGIC   date_trunc('YEAR', close_date) as oppty_close_date_years,
# MAGIC   CASE WHEN training_incremental_booking > 0 then "Yes" ELSE "No" END as oppty_has_training_attached,
# MAGIC   opportunity_id as oppty_id,
# MAGIC   opportunity_name as oppty_name,
# MAGIC   opportunity_owner as oppty_owner,
# MAGIC   opportunity_owner_role as oppty_owner_role,
# MAGIC   opportunity_region as oppty_region,
# MAGIC   opportunity_stage as oppty_stage,
# MAGIC   opportunity_type as oppty_type,
# MAGIC   CASE 
# MAGIC     WHEN opportunity_type='PAYG - Azure' then "PAYG"
# MAGIC     WHEN opportunity_type='PAYG' then "PAYG"
# MAGIC     WHEN opportunity_type='PAYG - Upload' then "PAYG"
# MAGIC     WHEN opportunity_type='Partner Fee' then "Partner"
# MAGIC     WHEN opportunity_type='Partner' then "Partner"
# MAGIC     WHEN opportunity_type='Partner Training' then "Partner"
# MAGIC     WHEN opportunity_type='MTM' then "MTM"
# MAGIC     WHEN opportunity_type='MTM Adjustment' then "MTM"
# MAGIC     WHEN opportunity_type='MTM Burst Clawback' then "MTM"
# MAGIC     WHEN opportunity_type='Burst' then "Other"
# MAGIC     WHEN opportunity_type='Churn' then "Other"
# MAGIC     WHEN opportunity_type='Pilot' then "Other"
# MAGIC     ELSE opportunity_type end as oppty_type_grounded,
# MAGIC   sales_leader,
# MAGIC   sales_manager,
# MAGIC   solution_architect,
# MAGIC   success_credits_attached,
# MAGIC   dsa_incremental_booking,
# MAGIC   coalesce(dsa_incremental_booking, 0) as dsa_attach_dollar,
# MAGIC   incremental_booking_total_forecast as incremental_booking,
# MAGIC   coalesce(incremental_booking_total_forecast, 0) as incremental_booking_dollar,
# MAGIC   ps_bookings_incremental_booking as ps_incremental_booking,
# MAGIC   coalesce(ps_bookings_incremental_booking, 0) as ps_bookings_attach_dollar,
# MAGIC   success_credits_incremental_booking,
# MAGIC   coalesce(success_credits_incremental_booking, 0) as success_credits_attach_dollar,
# MAGIC   total_opportunity_amount,
# MAGIC   coalesce(total_opportunity_amount, 0) as total_attach_dollar,
# MAGIC   training_incremental_booking,
# MAGIC   coalesce(training_incremental_booking, 0) as training_attach_dollar,
# MAGIC   unused_success_credits_value,
# MAGIC   coalesce(unused_success_credits_value, 0) as unused_success_credits_value_attach_dollar
# MAGIC FROM
# MAGIC   main.it_aibi_silver.femissioncontrol_opp_silver
# MAGIC GROUP BY ALL
