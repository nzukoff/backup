# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.femissioncontrol_gold
# MAGIC SELECT 
# MAGIC     account_id,
# MAGIC     account_name,
# MAGIC     account_executive,
# MAGIC     BU_plus1,
# MAGIC     BU_plus2,
# MAGIC     BU_plus3,
# MAGIC     business_unit,
# MAGIC     contract_end_date_window,
# MAGIC     contract_start_date_window,
# MAGIC     dsa_type,
# MAGIC     has_dsa,
# MAGIC     rank_global,
# MAGIC     rank_bu,
# MAGIC     rank_bu_plus1,
# MAGIC     run_date,
# MAGIC     sa_name AS sa_last_engaged,
# MAGIC     sa_manager,
# MAGIC     sales_leader,
# MAGIC     sales_manager,
# MAGIC     dbu_dollars_t3m_annualized_bucket AS t3m_annualized_bucket,
# MAGIC     accounts_greater_than_60k_w_no_sa AS accounts_w_out_SA,
# MAGIC     ds_forecast_cq AS dbus_cq_forecast_ds_account_rollup,
# MAGIC     og_forecast_cq AS dbus_cq_forecast_og,
# MAGIC     dbu_dollars_t3m_annualized AS dbus_t3m_annualized,
# MAGIC     target_cq AS dbus_target_cq_account_rollup,
# MAGIC     dbu_dollars_total_latest_completed_quarter AS dbus_total_pq,
# MAGIC     investment_amount AS acc_dollar_invested,
# MAGIC     tech_svcs_engaged_enablement AS asqs_enablement_last90,
# MAGIC     ssa_tickets AS asqs_ssa_created_last90,
# MAGIC     tech_svcs_engaged AS asqs_sts_created_last90,
# MAGIC     delivery_partners AS implementation_parters_cq_nq_live_date,
# MAGIC     certification_count AS l_e_certifications,
# MAGIC     unused_success_credits_value AS ps_success_credits_total_unused,
# MAGIC     use_case_live_count,
# MAGIC     use_case_pipe_count,
# MAGIC     open_use_case_count_poc_in_progress AS use_case_poc_in_progress,
# MAGIC     open_use_case_count_poc_needed AS use_case_poc_needed,
# MAGIC     open_use_case_count_poc_needed_w_30_days_since_modification AS use_case_stale_poc_needed,
# MAGIC     use_case_live_dbu_dollars_monthly,
# MAGIC     use_case_pipe_dbu_dollar_monthly,
# MAGIC     SUM(CASE WHEN dsa_active_project_count > 0 THEN arr ELSE 0 END) AS arr_w_dsa_paid,
# MAGIC     SUM(CASE WHEN has_dsa = 1 THEN arr ELSE 0 END) AS arr_w_dsa,
# MAGIC     SUM(CASE WHEN dsa_active_project_count > 0 THEN arr ELSE 0 END) / NULLIF(SUM(arr), 0) AS dsa_percent_account_w_dsa_paid_only_weighted,
# MAGIC     SUM(CASE WHEN has_dsa = 1 THEN arr ELSE 0 END) / NULLIF(SUM(arr), 0) AS dsa_percent_account_w_dsa_paid_or_invested_weighted,
# MAGIC     ((SUM(ds_forecast_cq) - SUM(dbu_dollars_total_latest_completed_quarter)) / NULLIF(SUM(dbu_dollars_total_latest_completed_quarter), 0)) AS forecasted_qoq_growth_ds,
# MAGIC     ((SUM(og_forecast_cq) - SUM(dbu_dollars_total_latest_completed_quarter)) / NULLIF(SUM(dbu_dollars_total_latest_completed_quarter), 0)) AS forecasted_qoq_growth_og
# MAGIC
# MAGIC FROM 
# MAGIC     main.it_aibi_silver.femissioncontrol_silver 
# MAGIC
# MAGIC GROUP BY 
# MAGIC     ALL

# COMMAND ----------


