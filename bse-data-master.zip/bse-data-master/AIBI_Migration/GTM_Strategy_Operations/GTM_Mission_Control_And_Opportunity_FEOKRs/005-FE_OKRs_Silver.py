# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.feokr_silver
# MAGIC SELECT 
# MAGIC a.customer_type as customer_customer_type
# MAGIC ,a.account_id as customer_account_id
# MAGIC ,a.customer_start_date as customer_start_date
# MAGIC ,FLOOR(date_diff(current_date(),a.customer_start_date) / 365) as age_years
# MAGIC ,CASE WHEN a.sales_region = 'LATAM' THEN 'AMER' ELSE a.sales_region END as sales_region
# MAGIC ,DATE_DIFF(current_date(),a.next_renewal_date) as days_to_renewal
# MAGIC ,a.account_executive as customer_account_executive
# MAGIC ,a.account_name as customer_account_name
# MAGIC ,a.account_status as customer_account_status
# MAGIC ,a.commit_amount_bucket as customer_commit_amount_bucket
# MAGIC ,a.commit_fc_burn_bucket as customer_commit_fc_burn_bucket
# MAGIC ,a.customer_success_engineer as customer_customer_success_engineer
# MAGIC ,a.customer_success_engineer_tier as customer_customer_success_engineer_tier
# MAGIC -- ,customer_success_leader
# MAGIC ,a.dbu_dollars_delta_30d_pct_of_total as customer_dbu_dollars_delta_30d_pct_of_total
# MAGIC ,a.dbu_dollars_sql_30d_pct_of_total as customer_dbu_dollars_sql_30d_pct_of_total
# MAGIC ,a.dbu_dollars_t3m_annualized_bucket as customer_dbu_dollars_t3m_annualized_bucket
# MAGIC ,a.dbu_dollars_t3m as customer_dbu_dollars_t3m
# MAGIC ,a.dbu_dollars_t3m_annualized as customer_dbu_dollars_t3m_annualized
# MAGIC ,a.fc_growth_pct_qoq_ds_bucket as customer_fc_growth_pct_qoq_ds_bucket
# MAGIC ,a.has_cloud_migration as customer_has_cloud_migration
# MAGIC ,a.has_hadoop_migration as customer_has_hadoop_migration
# MAGIC ,a.has_snowflake_migration as customer_has_snowflake_migration
# MAGIC ,a.is_pvc_pubsec as customer_is_pvc_pubsec
# MAGIC ,a.lakehouse_score_bucket as customer_lakehouse_score_bucket
# MAGIC ,a.lakehouse_score_growth_bucket as customer_lakehouse_score_growth_bucket
# MAGIC ,a.last_solution_architect_engaged as customer_last_solution_architect_engaged
# MAGIC ,a.sa_manager as customer_manager_name 
# MAGIC ,a.partner_sales_manager as customer_partner_sales_manager
# MAGIC ,a.sales_leader as customer_sales_leader
# MAGIC ,a.sales_manager as customer_sales_manager
# MAGIC ,a.sales_subregion_level_1 as customer_sales_subregion_level_1
# MAGIC ,a.sales_subregion_level_2 as customer_sales_subregion_level_2
# MAGIC ,a.sales_subregion_level_3 as customer_sales_subregion_level_3
# MAGIC ,a.scp_status as customer_scp_status
# MAGIC ,a.support_tier as customer_support_tier
# MAGIC ,a.unused_success_credit_bucket as customer_sunused_success_credit_bucket
# MAGIC ,a.vertical as customer_vertical
# MAGIC ,a.wau_bucket as customer_wau_bucket
# MAGIC ,a.brag_status as customer_brag_status
# MAGIC ,a.business_unit as customer_business_unit
# MAGIC ,a.fc_growth_pct_qoq_ae_bucket as customer_fc_growth_pct_qpq_ae_bucket
# MAGIC ,a.ds_forecast_cq as customer_ds_forecast_cq
# MAGIC ,a.ae_forecast_cq as customer_ae_forecast_cq
# MAGIC ,a.ds_forecast_cq_pct_change as customer_ds_forecast_cq_pct_change
# MAGIC ,a.ds_forecast_cq_as_of_quarter_start as customer_ds_forecast_cq_as_of_quarter_start
# MAGIC ,a.DS_AE_fcst_diff as customer_DS_AE_fsct_diff
# MAGIC ,a.dbu_dollars_unity_catalog as customer_dbu_dollars_unity_catalog ---total unity catalog dollars
# MAGIC ,a.dbu_dollars_unity_catalog_qtd as customer_dbu_dollars_unity_catalog_qtd ---total unity catalog dollars qtd
# MAGIC ,a.dbu_dollars_unity_catalog_last30_current as customer_dbu_dollars_unity_catalog_last30_current ---last 30 days unity catalog dollars
# MAGIC ,a.dbu_dollars_unity_catalog_last30_previous as customer_dbu_dollars_unity_catalog_last30_previous ---previous 30 days unity catalog dollars
# MAGIC ,a.dbu_dollars_unity_catalog_30d_diff as customer_dbu_dollars_unity_catalog_30d_diff ---current 30 days - previous 30 days
# MAGIC ,a.dbu_dollars_unity_catalog_30d_pct_of_total as customer_dbu_dollars_unity_catalog_30d_pct_of_total ---percent of total dbu dollars from unity catalog
# MAGIC --,dbu_dollars_unity_catalog_last90_current
# MAGIC ,a.dbu_dollars_unity_catalog_last90_previous as customer_dbu_dollars_unity_catalog_last90_previous ----previous 90 days unity catalog dollars
# MAGIC ,a.dbu_dollars_unity_catalog_90d_pct_of_total as customer_dbu_dollars_unity_catalog_90d_pct_of_total ---percent of total dbu dollars 90 days
# MAGIC ,a.dbu_dollars_unity_catalog_90d_growth_pct as customer_dbu_dollars_unity_catalog_90d_growth_pct ----percent growth 90 day growth
# MAGIC ,a.dbu_dollars_unity_catalog_90d_diff as customer_dbu_dollars_unity_catalog_90d_diff ----90 day difference
# MAGIC ,a.dbu_dollars_unity_catalog_30d_growth_pct as customer_dbu_dollars_unity_catalog_30d_growth_pct
# MAGIC ,a.dbu_dollars_unity_catalog_last90_current  as customer_dbu_dollars_unity_catalog_last90_current
# MAGIC ,a.UC_WAU as customer_UC_WAU
# MAGIC ,a.UC_WAU_previous as customer_UC_WAU_previous
# MAGIC ,a.UC_WAU_growth as customer_UC_WAU_growth
# MAGIC ,a.UC_MAU as customer_UC_MAU
# MAGIC ,a.UC_MAU_previous as customer_UC_MAU_previuos
# MAGIC ,a.UC_MAU_growth as customer_UC_MAU_growth
# MAGIC ,a.UC_WAU_over_DB_WAU as customer_UC_WAU_over_DB_WAU
# MAGIC ,a.UC_MAU_over_DB_MAU as customer_UC_MAU_over_DB_MAU
# MAGIC ,a.uc_active_user_count_all_time as customer_uc_active_user_count_all_time
# MAGIC ,a.uc_enabled_w_active_user as customer_uc_enabled_w_active_user
# MAGIC ,a.uc_enabled_okr as customer_uc_enabled_okr
# MAGIC ,a.mau_latest_date as customer_mau_latest_date
# MAGIC ,a.wau_latest_date as customer_wau_latest_date
# MAGIC ,a.dbu_dollars_total_last30_current as customer_dbu_dollars_last30_current
# MAGIC ,a.dbu_dollars_total_last90_current as customer_dbu_dollars_last90_current
# MAGIC ,a.rank_bu as customer_rank_bu
# MAGIC ,a.rank_bu_plus1 as customer_rank_bu_plus1
# MAGIC ,a.rank_global as customer_rank_global
# MAGIC ,current_date() as run_date
# MAGIC ,f.*
# MAGIC from main.gtm_data.customer_portfolio_account_list a
# MAGIC left join
# MAGIC main.gtm_data.feokrs_uc_customers__drill_down f
# MAGIC on a.account_id=f.account_id
