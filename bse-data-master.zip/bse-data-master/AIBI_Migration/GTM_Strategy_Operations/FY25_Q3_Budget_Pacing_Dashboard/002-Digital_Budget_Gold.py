# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.digital_budget_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     ad_campaign_name,
# MAGIC     audience,
# MAGIC     budget_type,
# MAGIC     campaign,
# MAGIC     date,
# MAGIC     fiscal_year_quarter,
# MAGIC     medium,
# MAGIC     objective_bucket,
# MAGIC     region,
# MAGIC     scid,
# MAGIC     source,
# MAGIC     source_type,
# MAGIC     subregion,
# MAGIC     cost,
# MAGIC     CASE WHEN source_type = 'Budget' THEN cost ELSE NULL END AS adjusted_budget,
# MAGIC     CASE WHEN source_type = 'Actual' THEN cost ELSE NULL END AS cost_star,
# MAGIC     CASE 
# MAGIC       WHEN fiscal_year_quarter = '2024Q3' THEN DATE '2023-10-31'
# MAGIC       WHEN fiscal_year_quarter = '2024Q4' THEN DATE '2024-01-31'
# MAGIC       WHEN fiscal_year_quarter = '2025Q1' THEN DATE '2024-04-30'
# MAGIC       WHEN fiscal_year_quarter = '2025Q2' THEN DATE '2024-07-31'
# MAGIC       WHEN fiscal_year_quarter = '2025Q3' THEN DATE '2024-10-31'
# MAGIC     END AS end_date,
# MAGIC     CASE 
# MAGIC       WHEN fiscal_year_quarter = '2024Q3' THEN DATE '2023-08-01'
# MAGIC       WHEN fiscal_year_quarter = '2024Q4' THEN DATE '2023-11-01'
# MAGIC       WHEN fiscal_year_quarter = '2025Q1' THEN DATE '2024-02-01'
# MAGIC       WHEN fiscal_year_quarter = '2025Q2' THEN DATE '2024-05-01'
# MAGIC       WHEN fiscal_year_quarter = '2025Q3' THEN DATE '2024-08-01'
# MAGIC     END AS start_date
# MAGIC   FROM main.it_aibi_silver.digital_budget_silver
# MAGIC ),
# MAGIC aggregated_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     COALESCE(MAX(CASE WHEN source_type = 'Budget' THEN audience END) OVER (PARTITION BY scid), 'Other') AS budget_audience,
# MAGIC     COALESCE(MAX(CASE WHEN source_type = 'Budget' THEN objective_bucket END) OVER (PARTITION BY scid), 'Other') AS budget_objective_bucket,
# MAGIC     COALESCE(MAX(CASE WHEN source_type = 'Budget' THEN budget_type END) OVER (PARTITION BY scid), 'Other') AS budget_type_star,
# MAGIC     COALESCE(MAX(CASE WHEN source_type = 'Budget' THEN campaign END) OVER (PARTITION BY scid), 'Other') AS campaign_star,
# MAGIC     COALESCE(MAX(CASE WHEN source_type = 'Budget' THEN medium END) OVER (PARTITION BY scid), 'Other') AS medium_star,
# MAGIC     COALESCE(MAX(CASE WHEN source_type = 'Budget' THEN region END) OVER (PARTITION BY scid), 'Other') AS region_star,
# MAGIC     COALESCE(MAX(CASE WHEN source_type = 'Budget' THEN source END) OVER (PARTITION BY scid), 'Other') AS source_star,
# MAGIC     COALESCE(MAX(CASE WHEN source_type = 'Budget' THEN subregion END) OVER (PARTITION BY scid), 'Other') AS subregion_star,
# MAGIC     AVG(cost_star) OVER () AS average_qtd_cost,
# MAGIC     COUNT(scid) OVER (PARTITION BY scid, source_type, fiscal_year_quarter) as scid_count,
# MAGIC     SUM(cost) OVER (PARTITION BY scid, source_type, fiscal_year_quarter) as scid_sum,
# MAGIC     CASE 
# MAGIC       WHEN SUM(adjusted_budget) OVER (PARTITION BY scid) >= 0 AND SUM(cost_star) OVER (PARTITION BY scid) >= 0 THEN 'In Both'
# MAGIC       WHEN COALESCE(SUM(adjusted_budget) OVER (PARTITION BY scid), 0) = 0 AND SUM(cost_star) OVER (PARTITION BY scid) > 0 THEN 'Not in Budget, Has Cost'
# MAGIC       WHEN SUM(adjusted_budget) OVER (PARTITION BY scid) > 0 AND COALESCE(SUM(cost_star) OVER (PARTITION BY scid), 0) = 0 THEN 'In Budget, Not in Cost'
# MAGIC     END AS exception_star,
# MAGIC     SUM(adjusted_budget) OVER (PARTITION BY scid) > 0 OR SUM(cost_star) OVER (PARTITION BY scid) > 0 AS has_cost_or_budget
# MAGIC     --(SUM(adjusted_budget) OVER (PARTITION BY scid) - SUM(cost_star) OVER (PARTITION BY scid)) / NULLIF(DATEDIFF(DAY, CURRENT_DATE, MAX(end_date) OVER (PARTITION BY scid)), 0) AS new_daily_target,
# MAGIC     --SUM(cost_star) OVER (PARTITION BY scid) / NULLIF(SUM(adjusted_budget) OVER (PARTITION BY scid), 0) AS run_rate,
# MAGIC     --(SUM(cost_star) OVER (PARTITION BY scid) / NULLIF(DATEDIFF(DAY, MIN(start_date) OVER (PARTITION BY scid), CURRENT_DATE), 0)) * 
# MAGIC     --DATEDIFF(DAY, MIN(start_date) OVER (PARTITION BY scid), MAX(end_date) OVER (PARTITION BY scid)) AS projected_spend,
# MAGIC     --LEAST(DATEDIFF(DAY, DATEADD(MONTH, -1, MIN(start_date) OVER (PARTITION BY scid)), DATEADD(MONTH, -1, CURRENT_DATE)) /
# MAGIC     --NULLIF(DATEDIFF(DAY, DATEADD(MONTH, -1, MIN(start_date) OVER (PARTITION BY scid)), DATEADD(MONTH, -1, MAX(end_date) OVER (PARTITION BY scid))), 0), 1) AS percentage_of_campaign
# MAGIC   FROM base_data
# MAGIC ),
# MAGIC final_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     CONCAT(
# MAGIC       budget_audience, budget_objective_bucket, budget_type_star, campaign_star,
# MAGIC       medium_star, region_star, source_star, subregion_star
# MAGIC     ) AS all_dimensions,
# MAGIC     CONCAT(region_star, ' - ', budget_type_star, ' - ', medium_star) AS budget_line_region,
# MAGIC     CONCAT(region_star, ' - ', subregion_star, ' - ', budget_type_star, ' - ', medium_star) AS budget_line_subregion,
# MAGIC     CASE 
# MAGIC       WHEN budget_audience = 'Other' OR budget_objective_bucket = 'Other' OR budget_type_star = 'Other' OR 
# MAGIC            campaign_star = 'Other' OR medium_star = 'Other' OR region_star = 'Other' OR 
# MAGIC            source_star = 'Other' OR subregion_star = 'Other' THEN TRUE
# MAGIC       ELSE FALSE
# MAGIC     END AS other_scid,
# MAGIC     CASE 
# MAGIC       WHEN ((scid_count > 1) AND (scid_sum > 0)) 
# MAGIC       THEN TRUE ELSE FALSE 
# MAGIC     END AS duplicate_budget_issue
# MAGIC     --projected_spend / NULLIF(SUM(adjusted_budget) OVER (PARTITION BY scid), 0) AS projected_run_rate,
# MAGIC     --new_daily_target - AVG(cost_star) OVER (PARTITION BY scid ORDER BY date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS reco_target_change,
# MAGIC     --CASE 
# MAGIC     --  WHEN ROUND(run_rate * 100, 0) - ROUND(MAX(percentage_of_campaign) OVER (PARTITION BY scid) * 100, 0) <= 5 
# MAGIC     --       AND ROUND(run_rate * 100, 0) - ROUND(percentage_of_campaign * 100, 0) >= -5 THEN 'On Pace'
# MAGIC     --  WHEN ROUND(run_rate * 100, 0) - ROUND(MAX(percentage_of_campaign) OVER (PARTITION BY scid) * 100, 0) > 5 THEN 'Over Pace'
# MAGIC     --  WHEN ROUND(run_rate * 100, 0) - ROUND(MAX(percentage_of_campaign) OVER (PARTITION BY scid) * 100, 0) < -5 THEN 'Under Pace'
# MAGIC     --END AS campaign_pacing_colors,
# MAGIC     --CASE 
# MAGIC     --  WHEN ROUND(run_rate * 100, 0) - ROUND(percentage_of_campaign * 100, 0) <= 5 
# MAGIC     --       AND ROUND(run_rate * 100, 0) - ROUND(percentage_of_campaign * 100, 0) >= -5 THEN 'On Pace'
# MAGIC     --  WHEN ROUND(run_rate * 100, 0) - ROUND(percentage_of_campaign * 100, 0) > 5 THEN 'Over Pace'
# MAGIC     --  WHEN ROUND(run_rate * 100, 0) - ROUND(percentage_of_campaign * 100, 0) < -5 THEN 'Under Pace'
# MAGIC     --  ELSE 'Over Pace'
# MAGIC     --END AS pacing_colors
# MAGIC   FROM aggregated_data
# MAGIC ),
# MAGIC distinct_dimensions AS (
# MAGIC   SELECT 
# MAGIC     scid,
# MAGIC     COUNT(DISTINCT all_dimensions) AS number_of_types
# MAGIC   FROM final_data
# MAGIC   GROUP BY scid
# MAGIC )
# MAGIC SELECT 
# MAGIC   final_data.*,
# MAGIC   distinct_dimensions.number_of_types
# MAGIC FROM final_data
# MAGIC FULL JOIN distinct_dimensions
# MAGIC ON final_data.scid = distinct_dimensions.scid
