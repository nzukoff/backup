# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.digital_budget_silver as
# MAGIC
# MAGIC select
# MAGIC ad_campaign_name,
# MAGIC audience,
# MAGIC budget_type,
# MAGIC campaign,
# MAGIC `date`,
# MAGIC fiscal_year_quarter,
# MAGIC medium,
# MAGIC objective_bucket,
# MAGIC region,
# MAGIC scid,
# MAGIC source,
# MAGIC source_type,
# MAGIC subregion,
# MAGIC cost
# MAGIC from main.marketing_lakehouse.gold_digital_budget_pacing
