# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE  main.it_aibi_gold.planning_insights_bound_Gold AS 
# MAGIC
# MAGIC SELECT
# MAGIC     audiences,
# MAGIC     author,
# MAGIC     bound,
# MAGIC     bu_plus_1,
# MAGIC     call_your_shot,
# MAGIC     channel_type,
# MAGIC     email_to_database,
# MAGIC     event_asset,
# MAGIC     event_asset_detail,
# MAGIC     event_asset_type,
# MAGIC     final_approved,
# MAGIC     fiscal_year,
# MAGIC     forecast,
# MAGIC     free_field,
# MAGIC     function_approved,
# MAGIC     mdf,
# MAGIC     overall_sales_play,
# MAGIC     partner,
# MAGIC     product_focus,
# MAGIC     program,
# MAGIC     program_acronym,
# MAGIC     program_duration,
# MAGIC     program_owner,
# MAGIC     program_start_date,
# MAGIC     quarter,
# MAGIC     region,
# MAGIC     region_team_planning,
# MAGIC     `row`,
# MAGIC     sfdc_campaign_name,
# MAGIC     theme,
# MAGIC     theme_1,
# MAGIC     vertical,
# MAGIC     num_tactics,
# MAGIC     planned_spend,
# MAGIC     CASE
# MAGIC         WHEN event_asset_type LIKE '%DAIWT%' THEN 'Yes'
# MAGIC         ELSE 'No'
# MAGIC     END AS DAIWT_Cal,
# MAGIC     CASE
# MAGIC         WHEN program LIKE '%LLM%' OR program LIKE '%AI%' OR program LIKE '%GenAI%' THEN 'Yes'
# MAGIC         ELSE 'No'
# MAGIC     END AS Is_GenAI_Related,
# MAGIC     CASE
# MAGIC         WHEN region_team_planning IN ('Partner Marketing (MDF)', 'Partner - APJ') THEN 'MDF Program'
# MAGIC         WHEN event_asset_type = ' Webinar' AND event_asset_type = 'Partner' THEN 'MDF Program'
# MAGIC         WHEN author = 'Partner' THEN 'MDF Program'
# MAGIC         WHEN event_asset_type = 'In-Person Event' AND event_asset_type = 'Webinar - Partner' THEN 'MDF Program'
# MAGIC         ELSE 'Non-MDF Programs'
# MAGIC     END AS MDF_Program,
# MAGIC     CASE
# MAGIC         WHEN fiscal_year LIKE '%FY24%' THEN
# MAGIC             CASE
# MAGIC                 WHEN region_team_planning IN ('Partner Marketing (MDF)', 'Partner - APJ') THEN 'MDF Program'
# MAGIC                 WHEN event_asset_type = ' Webinar' AND event_asset_type = 'Partner' THEN 'MDF Program'
# MAGIC                 WHEN author = 'Partner' THEN 'MDF Program'
# MAGIC                 WHEN event_asset_type = 'In-Person Event' AND event_asset_type = 'Webinar - Partner' THEN 'MDF Program'
# MAGIC                 ELSE 'Non-MDF Programs'
# MAGIC             END
# MAGIC         WHEN fiscal_year LIKE '%FY25%' THEN
# MAGIC             CASE
# MAGIC                 WHEN mdf = 'Yes' THEN 'MDF Program'
# MAGIC                 ELSE 'Non-MDF Program'
# MAGIC             END
# MAGIC         ELSE NULL
# MAGIC     END AS MDF_Program_new,
# MAGIC     COALESCE(audiences, 'Null') AS Null_Audience,
# MAGIC     DATE_ADD(program_start_date, 11 * 30) AS program_start_date_date,
# MAGIC     CASE
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '12' THEN 'January'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '01' THEN 'February'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '02' THEN 'March'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '03' THEN 'April'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '04' THEN 'May'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '05' THEN 'June'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '06' THEN 'July'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '07' THEN 'August'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '08' THEN 'September'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '09' THEN 'October'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '10' THEN 'November'
# MAGIC         WHEN date_format(DATE_ADD(program_start_date, 11 * 30), 'MM') = '11' THEN 'December'
# MAGIC     END AS program_start_date_month_name,
# MAGIC     LPAD(
# MAGIC         CASE
# MAGIC             WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) > 1 THEN CAST(MONTH(DATE_ADD(program_start_date, 11 * 30)) - 1 AS CHAR(2))
# MAGIC             ELSE '12'
# MAGIC         END,
# MAGIC         2, '0'
# MAGIC     ) AS program_start_date_month_no_offset,
# MAGIC     RIGHT(YEAR(DATE_ADD(program_start_date, 11 * 30)), 4) AS program_start_date_year_no,
# MAGIC     RIGHT(YEAR(DATE_ADD(program_start_date, 12 * 30)), 4) AS program_start_date_year_no_copy,
# MAGIC     CASE
# MAGIC         WHEN YEAR(DATE_ADD(program_start_date, 11 * 30)) != 2023 THEN
# MAGIC             CONCAT(
# MAGIC                 'FY', 
# MAGIC                 RIGHT(YEAR(DATE_ADD(program_start_date, 11 * 30)), 2),
# MAGIC                 ' ',
# MAGIC                 LPAD(
# MAGIC                     CASE
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) > 1 THEN CAST(MONTH(DATE_ADD(program_start_date, 11 * 30)) - 1 AS CHAR(2))
# MAGIC                         ELSE '12'
# MAGIC                     END,
# MAGIC                     2, '0'
# MAGIC                 ),
# MAGIC                 ' ',
# MAGIC                 LEFT(
# MAGIC                     CASE
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 12 THEN 'January'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 1 THEN 'February'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 2 THEN 'March'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 3 THEN 'April'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 4 THEN 'May'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 5 THEN 'June'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 6 THEN 'July'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 7 THEN 'August'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 8 THEN 'September'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 9 THEN 'October'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 10 THEN 'November'
# MAGIC                         WHEN MONTH(DATE_ADD(program_start_date, 11 * 30)) = 11 THEN 'December'
# MAGIC                     END,
# MAGIC                     3
# MAGIC                 )
# MAGIC             )
# MAGIC     END AS program_start_date_Year_month,
# MAGIC     CASE
# MAGIC         WHEN bound = 'Inbound' THEN '1:Many'
# MAGIC         WHEN bound = 'Outbound' THEN '1:1'
# MAGIC         ELSE bound
# MAGIC     END AS Program_type_Filter,
# MAGIC     CAST(program_start_date AS DATE) AS Sample_test,
# MAGIC     CASE
# MAGIC         WHEN planned_spend > 0 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS spend_greater_than_0,
# MAGIC     CASE
# MAGIC         WHEN vertical = 'N/A' THEN 'Not Industry'
# MAGIC         WHEN vertical IS NULL THEN 'Not Industry'
# MAGIC         WHEN LOWER(vertical) = 'null' THEN 'Not Industry'
# MAGIC         ELSE 'Industry'
# MAGIC     END AS Vertical_Industry_Status,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%AI%' THEN program END) / COUNT(DISTINCT program) AS AI_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%AI%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS AI_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Data Sharing%' THEN program END) / COUNT(DISTINCT program) AS Data_Sharing_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Data Sharing%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Data_Sharing_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Databricks SQL%' THEN program END) / COUNT(DISTINCT program) AS Databricks_SQL_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Databricks SQL%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Databricks_SQL_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Databricks Workflows%' THEN program END) / COUNT(DISTINCT program) AS Databricks_Workflows_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Databricks Workflows%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Databricks_Workflows_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Delta Live Tables%' THEN program END) / COUNT(DISTINCT program) AS Delta_Live_Tables_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Delta Live Tables%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Delta_Live_Tables_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Delta Sharing%' THEN program END) / COUNT(DISTINCT program) AS Delta_Sharing_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Delta Sharing%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Delta_Sharing_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Delta Sharing & Marketplace%' THEN program END) / COUNT(DISTINCT program) AS Delta_Sharing_Marketplace_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Delta Sharing & Marketplace%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Delta_Sharing_Marketplace_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Delta Lake%' THEN program END) / COUNT(DISTINCT program) AS DeltaLake_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Delta Lake%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS DeltaLake_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%DLT & Streaming%' THEN program END) / COUNT(DISTINCT program) AS DLT_Streaming_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%DLT & Streaming%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS DLT_Streaming_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Lakehouse AI%' THEN program END) / COUNT(DISTINCT program) AS Lakehouse_AI_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Lakehouse AI%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Lakehouse_AI_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Lakehouse Platform%' THEN program END) / COUNT(DISTINCT program) AS Lakehouse_Platform_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Lakehouse Platform%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Lakehouse_Platform_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%LakehouseIQ%' THEN program END) / COUNT(DISTINCT program) AS LakehouseIQ_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%LakehouseIQ%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS LakehouseIQ_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Machine Learning%' THEN program END) / COUNT(DISTINCT program) AS MachineLearning_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Machine Learning%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS MachineLearning_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%MLflow%' THEN program END) / COUNT(DISTINCT program) AS MLflow_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%MLflow%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS MLflow_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Model Serving%' THEN program END) / COUNT(DISTINCT program) AS Model_Serving_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Model Serving%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Model_Serving_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%MosaicML%' THEN program END) / COUNT(DISTINCT program) AS MosaicML_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%MosaicML%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS MosaicML_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Notebooks%' THEN program END) / COUNT(DISTINCT program) AS Notebooks_program_ratio,
# MAGIC
# MAGIC     CASE
# MAGIC         WHEN COUNT(DISTINCT program) > 0 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS prog_count_greater_than_0,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Serverless%' THEN program END) / COUNT(DISTINCT program) AS Serverless_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Serverless%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Serverless_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT `row`) AS Total_count_of_Program,
# MAGIC
# MAGIC     SUM(COUNT(DISTINCT program)) OVER (PARTITION BY channel_type) AS Total_Programs_for_the_Channel_Type,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Unity Catalog%' THEN program END) / COUNT(DISTINCT program) AS UnityCatalog_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Unity Catalog%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS UnityCatalog_spend_ratio,
# MAGIC
# MAGIC     COUNT(DISTINCT CASE WHEN product_focus LIKE '%Workflows%' THEN program END) / COUNT(DISTINCT program) AS Workflows_program_ratio,
# MAGIC
# MAGIC     SUM(CASE WHEN product_focus LIKE '%Workflows%' THEN planned_spend ELSE 0 END) / SUM(planned_spend) AS Workflows_spend_ratio
# MAGIC
# MAGIC FROM
# MAGIC     main.it_aibi_silver.planning_insights_bound_silver
# MAGIC GROUP BY
# MAGIC     audiences,
# MAGIC     author,
# MAGIC     bound,
# MAGIC     bu_plus_1,
# MAGIC     call_your_shot,
# MAGIC     channel_type,
# MAGIC     email_to_database,
# MAGIC     event_asset,
# MAGIC     event_asset_detail,
# MAGIC     event_asset_type,
# MAGIC     final_approved,
# MAGIC     fiscal_year,
# MAGIC     forecast,
# MAGIC     free_field,
# MAGIC     function_approved,
# MAGIC     mdf,
# MAGIC     overall_sales_play,
# MAGIC     partner,
# MAGIC     product_focus,
# MAGIC     program,
# MAGIC     program_acronym,
# MAGIC     program_duration,
# MAGIC     program_owner,
# MAGIC     program_start_date,
# MAGIC     quarter,
# MAGIC     region,
# MAGIC     region_team_planning,
# MAGIC     `row`,
# MAGIC     sfdc_campaign_name,
# MAGIC     theme,
# MAGIC     theme_1,
# MAGIC     vertical,
# MAGIC     num_tactics,
# MAGIC     planned_spend
