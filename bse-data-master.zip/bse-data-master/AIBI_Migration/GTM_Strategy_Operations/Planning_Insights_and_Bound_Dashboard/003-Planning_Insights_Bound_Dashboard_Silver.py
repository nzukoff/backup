# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.planning_insights_bound_silver as
# MAGIC
# MAGIC select
# MAGIC audiences,
# MAGIC author,
# MAGIC bound,
# MAGIC bu_plus_1,
# MAGIC call_your_shot,
# MAGIC channel_type,
# MAGIC email_to_database,
# MAGIC event_asset,
# MAGIC event_asset_detail,
# MAGIC event_asset_type,
# MAGIC final_approved,
# MAGIC fiscal_year,
# MAGIC forecast,
# MAGIC free_field,
# MAGIC function_approved,
# MAGIC mdf,
# MAGIC overall_sales_play,
# MAGIC partner,
# MAGIC product_focus,
# MAGIC program,
# MAGIC program_acronym,
# MAGIC program_duration,
# MAGIC program_owner,
# MAGIC program_start_date,
# MAGIC quarter,
# MAGIC region,
# MAGIC region_team_planning,
# MAGIC `row`,
# MAGIC sfdc_campaign_name,
# MAGIC theme,
# MAGIC theme_1,
# MAGIC vertical,
# MAGIC num_tactics,
# MAGIC planned_spend
# MAGIC from main.marketing_lakehouse.gold_marketing_plan_bound
# MAGIC
# MAGIC
