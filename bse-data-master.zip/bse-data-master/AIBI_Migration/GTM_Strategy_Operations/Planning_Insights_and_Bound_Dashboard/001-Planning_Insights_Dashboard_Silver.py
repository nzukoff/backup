# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.planning_insights_silver AS
# MAGIC
# MAGIC SELECT
# MAGIC     audience_status,
# MAGIC     audiences,
# MAGIC     author,
# MAGIC     bu_plus_1,
# MAGIC     call_your_shot,
# MAGIC     channel_detail,
# MAGIC     channel_type,
# MAGIC     country,
# MAGIC     digital_flag,
# MAGIC     email_to_database,
# MAGIC     event_asset,
# MAGIC     event_asset_detail,
# MAGIC     event_asset_type,
# MAGIC     execution_team,
# MAGIC     final_approved,
# MAGIC     fiscal_year AS fiscal_year_old,
# MAGIC     forecast,
# MAGIC     function_approved,
# MAGIC     funnel_stage,
# MAGIC     mdf,
# MAGIC     parent_campaign,
# MAGIC     partner,
# MAGIC     product_focus,
# MAGIC     program,
# MAGIC     program_duration,
# MAGIC     program_owner,
# MAGIC     program_start_date,
# MAGIC     quarter,
# MAGIC     record_type,
# MAGIC     region,
# MAGIC     region_team_planning,
# MAGIC     `row`,
# MAGIC     sfdc_campaign_name,
# MAGIC     start_date,
# MAGIC     tactic_child_campaign,
# MAGIC     tactic_owner,
# MAGIC     theme,
# MAGIC     theme_1,
# MAGIC     vertical,
# MAGIC     planned_spend
# MAGIC FROM
# MAGIC     main.marketing_lakehouse.gold_marketing_plan
