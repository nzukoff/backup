# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.planning_insights_gold AS
# MAGIC
# MAGIC WITH base_query AS (
# MAGIC     SELECT
# MAGIC         audience_status,
# MAGIC         audiences,
# MAGIC         author,
# MAGIC         bu_plus_1,
# MAGIC         call_your_shot,
# MAGIC         channel_detail,
# MAGIC         channel_type,
# MAGIC         country,
# MAGIC         digital_flag,
# MAGIC         email_to_database,
# MAGIC         event_asset,
# MAGIC         event_asset_detail,
# MAGIC         event_asset_type,
# MAGIC         execution_team,
# MAGIC         final_approved,
# MAGIC         fiscal_year_old,
# MAGIC         forecast,
# MAGIC         function_approved,
# MAGIC         funnel_stage,
# MAGIC         mdf,
# MAGIC         parent_campaign,
# MAGIC         partner,
# MAGIC         product_focus,
# MAGIC         program,
# MAGIC         program_duration,
# MAGIC         program_owner,
# MAGIC         program_start_date,
# MAGIC         quarter,
# MAGIC         record_type,
# MAGIC         region,
# MAGIC         region_team_planning,
# MAGIC         `row`,
# MAGIC         sfdc_campaign_name,
# MAGIC         start_date,
# MAGIC         tactic_child_campaign,
# MAGIC         tactic_owner,
# MAGIC         theme,
# MAGIC         theme_1,
# MAGIC         vertical,
# MAGIC         planned_spend
# MAGIC     FROM
# MAGIC         main.it_aibi_silver.planning_insights_silver
# MAGIC ),
# MAGIC calculated_fields AS (
# MAGIC     SELECT
# MAGIC         *,
# MAGIC         -- Audience Status - Customer
# MAGIC         CASE 
# MAGIC             WHEN INSTR(audience_status, 'Customer') > 0 THEN 'Customer' 
# MAGIC             ELSE 'Prospect'
# MAGIC         END AS audience_status_customer,
# MAGIC
# MAGIC         -- Call your shot group
# MAGIC         CASE
# MAGIC             WHEN INSTR(LOWER(TRIM(call_your_shot)), 'upsell') > 0 THEN 'Upsell'
# MAGIC             WHEN INSTR(LOWER(TRIM(call_your_shot)), 'consumption') > 0 THEN 'Consumption'
# MAGIC             WHEN INSTR(LOWER(TRIM(call_your_shot)), 'exec engagement') > 0 THEN 'Exec Engagement'
# MAGIC             WHEN INSTR(LOWER(TRIM(call_your_shot)), 'accreditation') > 0 THEN 'Accreditation/Training'
# MAGIC             ELSE call_your_shot
# MAGIC         END AS call_your_shot_group,
# MAGIC
# MAGIC         -- Channel Detail Group
# MAGIC         CASE
# MAGIC             WHEN INSTR(LOWER(TRIM(channel_detail)), 'thirdparty') > 0 OR INSTR(LOWER(TRIM(channel_detail)), 'third party') > 0 THEN 'Third Party'
# MAGIC             WHEN INSTR(LOWER(TRIM(channel_detail)), 'paidsocial') > 0 OR INSTR(LOWER(TRIM(channel_detail)), 'paid social') > 0 THEN 'Paid Social'
# MAGIC             WHEN INSTR(LOWER(TRIM(channel_detail)), 'paidsearch') > 0 OR INSTR(LOWER(TRIM(channel_detail)), 'paid search') > 0 THEN 'Paid Search'
# MAGIC             WHEN INSTR(LOWER(TRIM(channel_detail)), 'programmatic') > 0 THEN 'Programmatic'
# MAGIC             ELSE 'other'
# MAGIC         END AS channel_detail_group,
# MAGIC
# MAGIC         -- CP PP Text
# MAGIC         CASE
# MAGIC             WHEN INSTR(quarter, 'Q') > 0 THEN
# MAGIC                 CASE
# MAGIC                     WHEN RIGHT(quarter, 2) = 'Q1' THEN CONCAT('FY', LPAD(TRY_CAST(CAST(SUBSTRING(quarter, 3, 2) AS INT) - 1 AS STRING), 2, '0'), ' - Q4')
# MAGIC                     ELSE CONCAT(LEFT(quarter, 4), ' - Q', TRY_CAST(CAST(RIGHT(quarter, 1) AS INT) - 1 AS STRING))
# MAGIC                 END
# MAGIC             WHEN SUBSTRING(quarter, 8, 1) = 'H' THEN
# MAGIC                 CASE
# MAGIC                     WHEN RIGHT(quarter, 2) = 'H2' THEN CONCAT(SUBSTRING(quarter, 1, 7), 'H1')
# MAGIC                     WHEN RIGHT(quarter, 2) = 'H1' THEN CONCAT('FY', LPAD(TRY_CAST(CAST(SUBSTRING(quarter, 3, 2) AS INT) - 1 AS STRING), 2, '0'), ' - H2')
# MAGIC                 END
# MAGIC             ELSE CONCAT('FY', LPAD(TRY_CAST(CAST(SUBSTRING(quarter, 3, 2) AS INT) - 1 AS STRING), 2, '0'), ' - ', quarter)
# MAGIC         END AS cp_pp_text,
# MAGIC
# MAGIC         -- CP Qtr (copy)
# MAGIC         CASE
# MAGIC             WHEN quarter = fiscal_year_old OR fiscal_year_old = 'All' THEN TRUE
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - H1') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter IN ('Q1', 'Q2')) OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter IN ('Q1', 'Q2'))
# MAGIC             ) THEN TRUE
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - H2') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter IN ('Q3', 'Q4')) OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter IN ('Q3', 'Q4'))
# MAGIC             ) THEN TRUE
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - Q1') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter = 'Q1') OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter = 'Q1')
# MAGIC             ) THEN TRUE
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - Q2') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter = 'Q2') OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter = 'Q2')
# MAGIC             ) THEN TRUE
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - Q3') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter = 'Q3') OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter = 'Q3')
# MAGIC             ) THEN TRUE
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - Q4') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter = 'Q4') OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter = 'Q4')
# MAGIC             ) THEN TRUE
# MAGIC             ELSE FALSE
# MAGIC         END AS cp_qtr_copy,
# MAGIC         -- Digital Non Digital Flag(investments)
# MAGIC         CASE
# MAGIC             WHEN digital_flag = 'Y' THEN 'Digital'
# MAGIC             ELSE 'Non Digital'
# MAGIC         END AS digital_non_digital_flag_investments,
# MAGIC
# MAGIC         -- Digital non digital flag - all qtrs
# MAGIC         CASE
# MAGIC             WHEN LEFT(fiscal_year_old, 4) = 'FY24' AND channel_type = 'Digital Media' THEN 'Digital'
# MAGIC             WHEN LEFT(fiscal_year_old, 4) = 'FY25' AND quarter IN ('Q1', 'Q2') AND channel_type = 'Digital Media' THEN 'Digital'
# MAGIC             ELSE 
# MAGIC                 CASE
# MAGIC                     WHEN digital_flag = 'Y' THEN 'Digital'
# MAGIC                     ELSE 'Non Digital'
# MAGIC                 END
# MAGIC         END AS digital_non_digital_flag_all_qtrs,
# MAGIC
# MAGIC          -- Execution Team
# MAGIC         CASE
# MAGIC             WHEN execution_team = 'Global DG' AND channel_type = 'Digital Media' THEN 'Digital'
# MAGIC             ELSE execution_team
# MAGIC         END AS execution_team_calc,
# MAGIC
# MAGIC         -- Fiscal year
# MAGIC         CASE
# MAGIC             WHEN fiscal_year_old = 'All' THEN 'FY24-All'
# MAGIC             ELSE fiscal_year_old
# MAGIC         END AS fiscal_year_calc,
# MAGIC
# MAGIC         -- Fiscal Year Para input
# MAGIC         CASE
# MAGIC             WHEN INSTR(UPPER(
# MAGIC                 CASE
# MAGIC                     WHEN fiscal_year_old = 'All' THEN 'FY24-All'
# MAGIC                     ELSE fiscal_year_old
# MAGIC                 END
# MAGIC             ), 'FY') > 0
# MAGIC             THEN 
# MAGIC                 CASE
# MAGIC                     WHEN fiscal_year_old = 'All' THEN 'FY24-All'
# MAGIC                     ELSE fiscal_year_old
# MAGIC                 END
# MAGIC         END AS fiscal_year_para_input,
# MAGIC
# MAGIC         -- fy25h2 flag
# MAGIC         CASE
# MAGIC             WHEN quarter IN ('Q3', 'Q4') AND fiscal_year_old='FY25' THEN 1
# MAGIC             ELSE 0
# MAGIC         END AS fy25h2_flag,
# MAGIC
# MAGIC         -- FYQ
# MAGIC         CONCAT(LEFT(
# MAGIC             CASE
# MAGIC                 WHEN fiscal_year_old = 'All' THEN 'FY24-All'
# MAGIC                 ELSE fiscal_year_old
# MAGIC             END, 4), ' - ', quarter) AS fyq,
# MAGIC
# MAGIC         -- FYQ_H
# MAGIC         CASE
# MAGIC             WHEN quarter = 'Null' THEN ''
# MAGIC             ELSE 
# MAGIC                 CASE
# MAGIC                     WHEN RIGHT(quarter, 1) IN ('1', '2') THEN CONCAT(LEFT(
# MAGIC                         CASE
# MAGIC                             WHEN fiscal_year_old = 'All' THEN 'FY24-All'
# MAGIC                             ELSE fiscal_year_old
# MAGIC                         END, 4), ' - H1')
# MAGIC                     ELSE CONCAT(LEFT(
# MAGIC                         CASE
# MAGIC                             WHEN fiscal_year_old = 'All' THEN 'FY24-All'
# MAGIC                             ELSE fiscal_year_old
# MAGIC                         END, 4), ' - H2')
# MAGIC                 END
# MAGIC         END AS fyq_h,
# MAGIC
# MAGIC   -- MDF Programs
# MAGIC         CASE
# MAGIC             WHEN INSTR(fiscal_year_old, 'FY24') > 0 THEN
# MAGIC                 CASE
# MAGIC                     WHEN region_team_planning IN ('Partner Marketing (MDF)', 'Partner - APJ') THEN 'MDF Program'
# MAGIC                     WHEN event_asset_type = 'Webinar' AND event_asset_type = 'Partner' THEN 'MDF Program'
# MAGIC                     WHEN author = 'Partner' THEN 'MDF Program'
# MAGIC                     WHEN event_asset_type = 'In-Person Event' AND event_asset_type = 'Webinar - Partner' THEN 'MDF Program'
# MAGIC                     ELSE 'Non-MDF Programs'
# MAGIC                 END
# MAGIC             WHEN INSTR(fiscal_year_old, 'FY25') > 0 THEN
# MAGIC                 CASE
# MAGIC                     WHEN mdf = 'Yes' THEN 'MDF Program'
# MAGIC                     ELSE 'Non-MDF Program'
# MAGIC                 END
# MAGIC         END AS mdf_programs,
# MAGIC
# MAGIC         -- Null Audience
# MAGIC         COALESCE(audiences, 'Null') AS null_audience,
# MAGIC
# MAGIC         -- Parameter push dynamic
# MAGIC         CONCAT(fiscal_year_old, ' - ', quarter) AS parameter_push_dynamic,
# MAGIC
# MAGIC         -- Partner_channel
# MAGIC         CASE
# MAGIC             WHEN INSTR(channel_detail, ' - ') > 0 THEN 
# MAGIC                 SPLIT(channel_detail, ' - ')[1]
# MAGIC             ELSE 
# MAGIC                 channel_detail
# MAGIC         END AS partner_channel,
# MAGIC         -- planned_spend(prog)flag
# MAGIC         CASE
# MAGIC             WHEN fiscal_year_old IN ('All', 'FY24') AND quarter IN ('Q1', 'Q2', 'Q3', 'Q4') AND channel_type = 'Digital Media' AND channel_type != 'Null' THEN '24DM'
# MAGIC             WHEN fiscal_year_old IN ('FY25-All', 'FY25') AND quarter IN ('Q1', 'Q2') AND channel_type = 'Digital Media' AND channel_type != 'Null' THEN '25H1'
# MAGIC             WHEN fiscal_year_old IN ('FY25-All', 'FY25') AND quarter IN ('Q3', 'Q4') AND digital_flag = 'Y' THEN '25H2D'
# MAGIC             WHEN fiscal_year_old IN ('FY25-All', 'FY25') AND quarter IN ('Q3', 'Q4') AND digital_flag = 'N' THEN '25H2ND'
# MAGIC             ELSE 'other'
# MAGIC         END AS planned_spend_prog_flag,
# MAGIC
# MAGIC         -- PP Qtr
# MAGIC         CASE
# MAGIC             WHEN INSTR(quarter, 'Q') > 0 THEN
# MAGIC                 CASE
# MAGIC                     WHEN RIGHT(quarter, 2) = 'Q1' THEN 
# MAGIC                         CONCAT('FY', TRY_CAST(CAST(SUBSTRING(quarter, 3, 2) AS INT) - 1 AS STRING), ' - Q4') = fyq
# MAGIC                     ELSE
# MAGIC                         CONCAT(LEFT(quarter, 4), ' - Q', TRY_CAST(CAST(RIGHT(quarter, 1) AS INT) - 1 AS STRING)) = fyq
# MAGIC                 END
# MAGIC             WHEN SUBSTRING(quarter, 8, 1) = 'H' THEN
# MAGIC                 CASE
# MAGIC                     WHEN RIGHT(quarter, 2) = 'H2' THEN CONCAT(SUBSTRING(quarter, 1, 7), 'H1') = fyq_h
# MAGIC                     WHEN RIGHT(quarter, 2) = 'H1' THEN CONCAT('FY', TRY_CAST(CAST(SUBSTRING(quarter, 3, 2) AS INT) - 1 AS STRING), ' - H2') = fyq_h
# MAGIC                 END
# MAGIC             ELSE
# MAGIC                 CONCAT('FY', TRY_CAST(CAST(SUBSTRING(quarter, 3, 2) AS INT) - 1 AS STRING), ' - ', quarter) = fyq
# MAGIC         END AS pp_qtr,
# MAGIC          -- Program Group
# MAGIC         CASE
# MAGIC             WHEN INSTR(LOWER(TRIM(program)), 'always on') > 0 OR INSTR(LOWER(TRIM(program)), 'alwayson') > 0 OR INSTR(LOWER(program), 'always-on') > 0 THEN 'Always On'
# MAGIC             WHEN INSTR(LOWER(TRIM(program)), 'brand') > 0 THEN 'Brand Campaign'
# MAGIC             WHEN INSTR(LOWER(TRIM(program)), 'aws') > 0 THEN 'AWS'
# MAGIC             WHEN INSTR(LOWER(TRIM(program)), 'data+aisummit') > 0 OR INSTR(LOWER(TRIM(program)), 'data + ai summit') > 0
# MAGIC                 OR INSTR(LOWER(TRIM(program)), 'data + aisummit') > 0 OR INSTR(LOWER(TRIM(program)), 'data+ai summit') > 0 
# MAGIC                 OR INSTR(LOWER(TRIM(program)), 'data aisummit') > 0 OR INSTR(LOWER(TRIM(program)), 'data ai summit') > 0 THEN 'Data + AI Summit'
# MAGIC             WHEN INSTR(LOWER(TRIM(program)), 'daiwt') > 0 OR INSTR(LOWER(TRIM(program)), 'data + ai worldtour') > 0
# MAGIC                 OR INSTR(LOWER(TRIM(program)), 'data + aiworldtour') > 0 OR INSTR(LOWER(TRIM(program)), 'data + ai world tour') > 0 THEN 'Data + AI World Tour'
# MAGIC             WHEN INSTR(LOWER(TRIM(program)), 'virtualevent') > 0 OR INSTR(LOWER(TRIM(program)), 'virtual event') > 0 
# MAGIC                 OR INSTR(LOWER(TRIM(program)), 'dedarchve') > 0 THEN 'Virtual Event'
# MAGIC             ELSE program
# MAGIC         END AS program_group,
# MAGIC
# MAGIC                 -- Start Date (date)
# MAGIC         TRY_CAST(start_date AS DATE) AS start_date_date,
# MAGIC
# MAGIC         -- Tactic Name
# MAGIC         CASE
# MAGIC             WHEN record_type = 'Tactic' THEN tactic_child_campaign
# MAGIC             ELSE NULL
# MAGIC         END AS tactic_name,
# MAGIC
# MAGIC -- Vertical Industry vs Not Industry
# MAGIC         CASE
# MAGIC             WHEN vertical = 'N/A' THEN 'Not Industry'
# MAGIC             WHEN vertical IS NULL THEN 'Not Industry'
# MAGIC             WHEN vertical = 'null' THEN 'Not Industry'
# MAGIC             ELSE 'Industry'
# MAGIC         END AS vertical_industry_vs_not_industry,
# MAGIC
# MAGIC                 -- AI - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'AI') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS ai_t,
# MAGIC
# MAGIC         -- Calculation6
# MAGIC         CASE WHEN planned_spend > 0 THEN TRUE ELSE FALSE END AS calculation6,
# MAGIC
# MAGIC         -- Data Sharing - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Data Sharing') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS data_sharing_t,
# MAGIC
# MAGIC         -- Databricks SQL
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Databricks SQL') > 0 THEN program END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT program), 0) AS databricks_sql,
# MAGIC
# MAGIC         -- Databricks SQL - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Databricks SQL') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS databricks_sql_t,
# MAGIC
# MAGIC         -- Databricks Workflows - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Databricks Workflows') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS databricks_workflows_t,
# MAGIC
# MAGIC         -- Delta Live Tables - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Delta Live Tables') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS delta_live_tables_t,
# MAGIC
# MAGIC         -- Delta Sharing - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Delta Sharing') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS delta_sharing_t,
# MAGIC
# MAGIC         -- Delta Sharing & Marketplace
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Delta Sharing & Marketplace') > 0 THEN program END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT program), 0) AS delta_sharing_marketplace,
# MAGIC
# MAGIC         -- Delta Sharing & Marketplace - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Delta Sharing & Marketplace') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS delta_sharing_marketplace_t,
# MAGIC
# MAGIC         -- DeltaLake
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Delta Lake') > 0 THEN program END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT program), 0) AS deltalake,
# MAGIC
# MAGIC         -- DeltaLake - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Delta Lake') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS deltalake_t,
# MAGIC
# MAGIC         -- DLT & Streaming
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'DLT & Streaming') > 0 THEN program END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT program), 0) AS dlt_streaming,
# MAGIC
# MAGIC         -- DLT & Streaming - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'DLT & Streaming') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS dlt_streaming_t,
# MAGIC
# MAGIC         -- Lakehouse
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Lakehouse Platform') > 0 THEN program END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT program), 0) AS lakehouse,
# MAGIC
# MAGIC         -- Lakehouse AI - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Lakehouse AI') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS lakehouse_ai_t,
# MAGIC
# MAGIC         -- Lakehouse Platform - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Lakehouse Platform') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS lakehouse_platform_t,
# MAGIC
# MAGIC         -- LakehouseIQ - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'LakehouseIQ') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS lakehouseiq_t,
# MAGIC
# MAGIC         -- MachineLearning
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Machine Learning') > 0 THEN program END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT program), 0) AS machinelearning,
# MAGIC
# MAGIC         -- MachineLearning - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Machine Learning') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS machinelearning_t,
# MAGIC
# MAGIC                 -- MLflow - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'MLflow') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS mlflow_t,
# MAGIC
# MAGIC         -- Model Serving - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Model Serving') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS model_serving_t,
# MAGIC
# MAGIC         -- MosaicML - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'MosaicML') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS mosaicml_t,
# MAGIC
# MAGIC         -- Notebook - T
# MAGIC         TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Notebooks') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC         NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS notebook_t,
# MAGIC
# MAGIC         -- planned spend (tactic)
# MAGIC         CASE
# MAGIC             WHEN record_type = 'Tactic' AND channel_type = 'Digital Media' THEN planned_spend
# MAGIC             ELSE 0
# MAGIC         END AS planned_spend_tactic,
# MAGIC
# MAGIC
# MAGIC                 -- Planned Spend CP
# MAGIC         SUM(CASE
# MAGIC             WHEN quarter = fiscal_year_old OR fiscal_year_old = 'All' THEN planned_spend
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - H1') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter IN ('Q1', 'Q2')) OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter IN ('Q1', 'Q2'))
# MAGIC             ) THEN planned_spend
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - H2') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter IN ('Q3', 'Q4')) OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter IN ('Q3', 'Q4'))
# MAGIC             ) THEN planned_spend
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - Q1') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter = 'Q1') OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter = 'Q1')
# MAGIC             ) THEN planned_spend
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - Q2') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter = 'Q2') OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter = 'Q2')
# MAGIC             ) THEN planned_spend
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - Q3') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter = 'Q3') OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter = 'Q3')
# MAGIC             ) THEN planned_spend
# MAGIC             WHEN quarter = CONCAT(fiscal_year_old, ' - Q4') AND (
# MAGIC                 (fiscal_year_old = SUBSTRING(quarter, 1, 4) AND quarter = 'Q4') OR
# MAGIC                 (fiscal_year_old = CONCAT(SUBSTRING(quarter, 1, 4), '-All') AND quarter = 'Q4')
# MAGIC             ) THEN planned_spend
# MAGIC             ELSE 0
# MAGIC         END) AS planned_spend_cp
# MAGIC
# MAGIC     FROM base_query
# MAGIC     GROUP BY 
# MAGIC         -- Include all columns from calculated_fields here
# MAGIC         audience_status,
# MAGIC         audiences,
# MAGIC         author,
# MAGIC         bu_plus_1,
# MAGIC         call_your_shot,
# MAGIC         channel_detail,
# MAGIC         channel_type,
# MAGIC         country,
# MAGIC         digital_flag,
# MAGIC         email_to_database,
# MAGIC         event_asset,
# MAGIC         event_asset_detail,
# MAGIC         event_asset_type,
# MAGIC         execution_team,
# MAGIC         final_approved,
# MAGIC         fiscal_year_old,
# MAGIC         forecast,
# MAGIC         function_approved,
# MAGIC         funnel_stage,
# MAGIC         mdf,
# MAGIC         parent_campaign,
# MAGIC         partner,
# MAGIC         product_focus,
# MAGIC         program,
# MAGIC         program_duration,
# MAGIC         program_owner,
# MAGIC         program_start_date,
# MAGIC         quarter,
# MAGIC         record_type,
# MAGIC         region,
# MAGIC         region_team_planning,
# MAGIC         `row`,
# MAGIC         sfdc_campaign_name,
# MAGIC         start_date,
# MAGIC         tactic_child_campaign,
# MAGIC         tactic_owner,
# MAGIC         theme,
# MAGIC         theme_1,
# MAGIC         vertical,
# MAGIC         planned_spend
# MAGIC         -- Include all calculated fields here
# MAGIC ),
# MAGIC additional_calculations AS (
# MAGIC     SELECT *,
# MAGIC      -- Planned Spend PP
# MAGIC         IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0) AS planned_spend_pp,
# MAGIC         
# MAGIC         -- Planned Spend QoQ
# MAGIC         CASE 
# MAGIC             WHEN IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0) = 0 THEN 
# MAGIC                 CASE 
# MAGIC                     WHEN planned_spend_cp = 0 THEN 0
# MAGIC                     ELSE NULL
# MAGIC                 END
# MAGIC             ELSE 
# MAGIC                 (planned_spend_cp - IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0)) / 
# MAGIC                 NULLIF(IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0), 0)
# MAGIC         END AS planned_spend_qoq,
# MAGIC
# MAGIC                 -- Planned Spend QoQ -ve
# MAGIC         CASE 
# MAGIC             WHEN (planned_spend_cp - IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0)) / 
# MAGIC                  NULLIF(IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0), 0) < 0 
# MAGIC             THEN (planned_spend_cp - IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0)) / 
# MAGIC                  NULLIF(IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0), 0)
# MAGIC             ELSE NULL
# MAGIC         END AS planned_spend_qoq_negative,
# MAGIC
# MAGIC         -- Planned Spend QoQ -ve symbol
# MAGIC         CASE 
# MAGIC             WHEN (planned_spend_cp - IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0)) / 
# MAGIC                  NULLIF(IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0), 0) < 0 
# MAGIC             THEN '▼'
# MAGIC             ELSE NULL
# MAGIC         END AS planned_spend_qoq_negative_symbol,
# MAGIC
# MAGIC         -- Planned Spend QoQ +ve
# MAGIC         CASE 
# MAGIC             WHEN (planned_spend_cp - IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0)) / 
# MAGIC                  NULLIF(IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0), 0) > 0 
# MAGIC             THEN (planned_spend_cp - IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0)) / 
# MAGIC                  NULLIF(IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0), 0)
# MAGIC             ELSE NULL
# MAGIC         END AS planned_spend_qoq_positive,
# MAGIC
# MAGIC         -- Planned Spend QoQ +ve symbol
# MAGIC         CASE 
# MAGIC             WHEN (planned_spend_cp - IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0)) / 
# MAGIC                  NULLIF(IFNULL(SUM(CASE WHEN pp_qtr THEN planned_spend ELSE 0 END), 0), 0) > 0 
# MAGIC             THEN '▲'
# MAGIC             ELSE NULL
# MAGIC         END AS planned_spend_qoq_positive_symbol,
# MAGIC
# MAGIC          -- Planned Spend total cp
# MAGIC         IFNULL(SUM(CASE 
# MAGIC             WHEN cp_qtr_copy = TRUE THEN planned_spend 
# MAGIC             ELSE 0 
# MAGIC         END), 0) AS planned_spend_total_cp,
# MAGIC
# MAGIC         -- Planned Spend total cp (copy)
# MAGIC         CASE
# MAGIC             WHEN SUM(fy25h2_flag) > 1 THEN
# MAGIC                 IFNULL(SUM(CASE 
# MAGIC                     WHEN cp_qtr_copy = TRUE AND record_type = 'Program' THEN planned_spend 
# MAGIC                     ELSE 0 
# MAGIC                 END), 0)
# MAGIC             WHEN SUM(fy25h2_flag) = 0 THEN
# MAGIC                 IFNULL(SUM(CASE 
# MAGIC                     WHEN cp_qtr_copy = TRUE THEN planned_spend 
# MAGIC                     ELSE 0 
# MAGIC                 END), 0)
# MAGIC             ELSE 0
# MAGIC         END AS planned_spend_total_cp_copy,
# MAGIC
# MAGIC             -- planned_spend(prog)
# MAGIC     SUM(CASE
# MAGIC         WHEN planned_spend_prog_flag = '24DM' THEN planned_spend
# MAGIC         WHEN planned_spend_prog_flag = '25H1' THEN planned_spend
# MAGIC         WHEN planned_spend_prog_flag = '25H2D' THEN planned_spend
# MAGIC         WHEN planned_spend_prog_flag = '25H2ND' THEN 0
# MAGIC         WHEN LOWER(planned_spend_prog_flag) = 'other' THEN 0
# MAGIC         ELSE 0
# MAGIC     END) AS planned_spend_prog,
# MAGIC
# MAGIC     -- Serverless - T
# MAGIC     TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Serverless') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC     NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS serverless_t,
# MAGIC
# MAGIC     -- Spend >0
# MAGIC     CASE
# MAGIC         WHEN SUM(CASE
# MAGIC             WHEN planned_spend_prog_flag = '24DM' THEN planned_spend
# MAGIC             WHEN planned_spend_prog_flag = '25H1' THEN planned_spend
# MAGIC             WHEN planned_spend_prog_flag = '25H2D' THEN planned_spend
# MAGIC             WHEN planned_spend_prog_flag = '25H2ND' THEN 0
# MAGIC             WHEN LOWER(planned_spend_prog_flag) = 'other' THEN 0
# MAGIC             ELSE 0
# MAGIC         END) > 0 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS spend_greater_than_zero,
# MAGIC
# MAGIC       -- spend_tactic > 0
# MAGIC     CASE WHEN planned_spend_tactic > 0 THEN TRUE ELSE FALSE END AS spend_tactic_gt_0,
# MAGIC
# MAGIC     -- Planned Spend total cp (M)
# MAGIC     planned_spend_total_cp / 1000000 AS planned_spend_total_cp_m,
# MAGIC
# MAGIC     -- spend_tactic > 0 (based on Planned Spend total cp (M))
# MAGIC     CASE WHEN (planned_spend_total_cp / 1000000) > 0 THEN TRUE ELSE FALSE END AS spend_tactic_gt_0_m,
# MAGIC
# MAGIC     -- tactic count > 0
# MAGIC     CASE 
# MAGIC         WHEN COUNT(CASE WHEN record_type = 'Tactic' THEN `row` END) > 0 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS tactic_count_gt_0,
# MAGIC
# MAGIC     -- Total count of Parent Camp
# MAGIC     COUNT(DISTINCT parent_campaign) AS total_count_parent_camp,
# MAGIC
# MAGIC     -- Total count of Program - New
# MAGIC     COUNT(DISTINCT CASE WHEN record_type = 'Program' THEN `row` END) AS total_count_program_new,
# MAGIC
# MAGIC     -- Total count of Tactic Camp - New
# MAGIC     COUNT(CASE WHEN record_type = 'Tactic' THEN `row` END) AS total_count_tactic_camp_new,
# MAGIC
# MAGIC     -- UnityCatalog
# MAGIC     TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Unity Catalog') > 0 THEN program END) AS FLOAT) /
# MAGIC     NULLIF(COUNT(DISTINCT program), 0) AS unity_catalog,
# MAGIC
# MAGIC     -- UnityCatalog - T
# MAGIC     TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Unity Catalog') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC     NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS unity_catalog_t,
# MAGIC
# MAGIC     -- Workflows
# MAGIC     TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Workflows') > 0 THEN program END) AS FLOAT) /
# MAGIC     NULLIF(COUNT(DISTINCT program), 0) AS workflows,
# MAGIC
# MAGIC     -- Workflows - T
# MAGIC     TRY_CAST(COUNT(DISTINCT CASE WHEN INSTR(product_focus, 'Workflows') > 0 THEN tactic_child_campaign END) AS FLOAT) /
# MAGIC     NULLIF(COUNT(DISTINCT tactic_child_campaign), 0) AS workflows_t
# MAGIC
# MAGIC
# MAGIC     FROM calculated_fields
# MAGIC
# MAGIC     GROUP BY
# MAGIC          audience_status,
# MAGIC         audiences,
# MAGIC         author,
# MAGIC         bu_plus_1,
# MAGIC         call_your_shot,
# MAGIC         channel_detail,
# MAGIC         channel_type,
# MAGIC         country,
# MAGIC         digital_flag,
# MAGIC         email_to_database,
# MAGIC         event_asset,
# MAGIC         event_asset_detail,
# MAGIC         event_asset_type,
# MAGIC         execution_team,
# MAGIC         final_approved,
# MAGIC         fiscal_year_old,
# MAGIC         forecast,
# MAGIC         function_approved,
# MAGIC         funnel_stage,
# MAGIC         mdf,
# MAGIC         parent_campaign,
# MAGIC         partner,
# MAGIC         product_focus,
# MAGIC         program,
# MAGIC         program_duration,
# MAGIC         program_owner,
# MAGIC         program_start_date,
# MAGIC         quarter,
# MAGIC         record_type,
# MAGIC         region,
# MAGIC         region_team_planning,
# MAGIC         `row`,
# MAGIC         sfdc_campaign_name,
# MAGIC         start_date,
# MAGIC         tactic_child_campaign,
# MAGIC         tactic_owner,
# MAGIC         theme,
# MAGIC         theme_1,
# MAGIC         vertical,
# MAGIC         planned_spend,
# MAGIC         audience_status_customer,
# MAGIC         call_your_shot_group,
# MAGIC         channel_detail_group,
# MAGIC         cp_pp_text,
# MAGIC         cp_qtr_copy,
# MAGIC         digital_non_digital_flag_investments,
# MAGIC         digital_non_digital_flag_all_qtrs,
# MAGIC         execution_team_calc,
# MAGIC         fiscal_year_calc,
# MAGIC         fiscal_year_para_input,
# MAGIC         fy25h2_flag,
# MAGIC         fyq,
# MAGIC         fyq_h,
# MAGIC         mdf_programs,
# MAGIC         null_audience,
# MAGIC         parameter_push_dynamic,
# MAGIC         partner_channel,
# MAGIC         planned_spend_prog_flag,
# MAGIC         pp_qtr,
# MAGIC         program_group,
# MAGIC         start_date_date,
# MAGIC         tactic_name,
# MAGIC         vertical_industry_vs_not_industry,
# MAGIC         ai_t,
# MAGIC         calculation6,
# MAGIC         data_sharing_t,
# MAGIC         databricks_sql,
# MAGIC         databricks_sql_t,
# MAGIC         databricks_workflows_t,
# MAGIC         delta_live_tables_t,
# MAGIC         delta_sharing_t,
# MAGIC         delta_sharing_marketplace,
# MAGIC         delta_sharing_marketplace_t,
# MAGIC         deltalake,
# MAGIC         deltalake_t,
# MAGIC         dlt_streaming,
# MAGIC         dlt_streaming_t,
# MAGIC         lakehouse,
# MAGIC         lakehouse_ai_t,
# MAGIC         lakehouse_platform_t,
# MAGIC         lakehouseiq_t,
# MAGIC         machinelearning,
# MAGIC         machinelearning_t,
# MAGIC         mlflow_t,
# MAGIC         model_serving_t,
# MAGIC         mosaicml_t,
# MAGIC         notebook_t,
# MAGIC         planned_spend_tactic,
# MAGIC         planned_spend_cp
# MAGIC )
# MAGIC
# MAGIC SELECT * FROM additional_calculations;
