# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.dbu_calculator_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     Account_CaseSafe_ID,
# MAGIC     Account_Name,
# MAGIC     Partner_Name,
# MAGIC     PSM,
# MAGIC     Region,
# MAGIC     Region_2,
# MAGIC     Region_3,
# MAGIC     Region_4,
# MAGIC     partner_dbu,
# MAGIC     partner_uc_dbu,
# MAGIC     split_percent,
# MAGIC     -- Existing Split
# MAGIC     split_percent / 100 AS existing_split,
# MAGIC     -- Partner $DBU
# MAGIC     COALESCE(partner_dbu, 0) AS partner_dbu_dollars,
# MAGIC     -- Partner Use Case $DBU
# MAGIC     COALESCE(partner_uc_dbu, 0) AS partner_use_case_dbu_dollars,
# MAGIC     -- Total Partner $DBU
# MAGIC     COALESCE(partner_uc_dbu, 0) + COALESCE(partner_dbu, 0) AS total_partner_dbu_dollars
# MAGIC   FROM main.it_aibi_silver.dbu_calculator_silver
# MAGIC )
# MAGIC SELECT 
# MAGIC   *,
# MAGIC   -- Recommended Split %
# MAGIC   total_partner_dbu_dollars / SUM(total_partner_dbu_dollars) OVER () AS recommended_split_percent
# MAGIC FROM base_data
