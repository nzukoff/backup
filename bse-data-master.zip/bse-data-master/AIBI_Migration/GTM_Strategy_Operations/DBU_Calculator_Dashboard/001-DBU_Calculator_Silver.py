# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.dbu_calculator_silver
# MAGIC
# MAGIC select
# MAGIC Account_CaseSafe_ID,
# MAGIC Account_Name,
# MAGIC Partner_Name,
# MAGIC PSM,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Region_3,
# MAGIC Region_4,
# MAGIC partner_dbu,
# MAGIC partner_uc_dbu,
# MAGIC split_percent
# MAGIC from main.gtm_partner_data.csi_partner_dbu_calculator
# MAGIC
