# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.csi_pvs_graudations_silver AS
# MAGIC SELECT
# MAGIC     Calculated_Tier AS current_calculated_tier,
# MAGIC     Membership_Start_Date,
# MAGIC     ParentId,
# MAGIC     Parent_Account AS partner_parent,
# MAGIC     Stamped_Tier_Past AS starting_assigned_tier,
# MAGIC     Calculated_Tier_Past AS starting_calculated_tier,
# MAGIC     Certs_Difference AS num_certs_difference,
# MAGIC     JointCustomers_Difference AS num_joint_customers_change,
# MAGIC     SourcedUseCases_Difference AS num_sourced_use_cases_change,
# MAGIC     Tier_Movement AS num_tier_movement,
# MAGIC     DBU_Difference AS dbu_change,
# MAGIC     dbu_points_difference AS dbu_points_change,
# MAGIC     Certs_Points_Difference AS cert_points_change,
# MAGIC     partner_value_score AS current_pvs,
# MAGIC     pvs_difference AS pvs_change,
# MAGIC     Partner_Value_Score_past AS starting_pvs
# MAGIC FROM
# MAGIC     main.gtm_partner_data.csi_partner_pvs_graduations;
