# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.csi_pvs_graudations_gold as
# MAGIC
# MAGIC SELECT
# MAGIC   current_calculated_tier,
# MAGIC   Membership_Start_Date,
# MAGIC   DATE(Membership_Start_Date) AS Program_Start_Date,
# MAGIC   ParentId,
# MAGIC   partner_parent,
# MAGIC   starting_assigned_tier,
# MAGIC   starting_calculated_tier,
# MAGIC   num_certs_difference,
# MAGIC   num_joint_customers_change,
# MAGIC   num_sourced_use_cases_change,
# MAGIC   num_tier_movement,
# MAGIC   dbu_change,
# MAGIC   dbu_points_change,
# MAGIC   cert_points_change,
# MAGIC   current_pvs,
# MAGIC   pvs_change,
# MAGIC   starting_pvs
# MAGIC FROM main.it_aibi_silver.csi_pvs_graudations_silver
# MAGIC
# MAGIC
