# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.csi_pvs_silver AS
# MAGIC SELECT
# MAGIC     stamped_partner_tier AS assigned_tier_fy24_performance,
# MAGIC     ParentId,
# MAGIC     BillingCountry AS partner_billing_country,
# MAGIC     parent_account AS partner_parent,
# MAGIC     Partner_Region,
# MAGIC     Partner_Manager__c,
# MAGIC     Period,
# MAGIC     Membership_Start_Date AS program_start_date,
# MAGIC     Calculated_Tier AS trending_tier_ytd_performance,
# MAGIC     Certs_Points,
# MAGIC     DBU_Points,
# MAGIC     Partner_Value_Score,
# MAGIC     Total_Certs AS total_tech_certs,
# MAGIC     Total_TTM_DBU AS ttm_dbu,
# MAGIC     Total_TTM_JointCustomers AS ttm_joint_customers
# MAGIC FROM
# MAGIC     main.gtm_partner_data.csi_partner_pvs
