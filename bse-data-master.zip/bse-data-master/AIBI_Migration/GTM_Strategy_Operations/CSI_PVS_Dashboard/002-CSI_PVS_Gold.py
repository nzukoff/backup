# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.csi_pvs_gold
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     assigned_tier_fy24_performance,
# MAGIC     ParentId,
# MAGIC     partner_billing_country,
# MAGIC     partner_parent,
# MAGIC     Partner_Region,
# MAGIC     Partner_Manager__c,
# MAGIC     Period,
# MAGIC     program_start_date,
# MAGIC     trending_tier_ytd_performance,
# MAGIC     Certs_Points,
# MAGIC     DBU_Points,
# MAGIC     Partner_Value_Score,
# MAGIC     total_tech_certs,
# MAGIC     ttm_dbu,
# MAGIC     ttm_joint_customers
# MAGIC   FROM main.it_aibi_silver.csi_pvs_silver
# MAGIC ),
# MAGIC active_partners AS (
# MAGIC   SELECT
# MAGIC     ParentId,
# MAGIC     Period,
# MAGIC     CASE WHEN SUM(total_tech_certs) > 0 THEN 1 ELSE 0 END AS Active_Cert_Partners,
# MAGIC     CASE WHEN SUM(ttm_dbu) > 0 THEN 1 ELSE 0 END AS Active_Consumption_Partners
# MAGIC   FROM base_data
# MAGIC   GROUP BY ParentId, Period
# MAGIC ),
# MAGIC pvs_rank AS (
# MAGIC   SELECT
# MAGIC     ParentId,
# MAGIC     Period,
# MAGIC     RANK() OVER (ORDER BY SUM(Partner_Value_Score) DESC) AS PVS_Rank
# MAGIC   FROM base_data
# MAGIC   GROUP BY ParentId, Period
# MAGIC )
# MAGIC SELECT 
# MAGIC   b.*,
# MAGIC   a.Active_Cert_Partners,
# MAGIC   a.Active_Consumption_Partners,
# MAGIC   p.PVS_Rank
# MAGIC FROM base_data b
# MAGIC LEFT JOIN active_partners a ON b.ParentId = a.ParentId AND b.Period = a.Period
# MAGIC LEFT JOIN pvs_rank p ON b.ParentId = p.ParentId AND b.Period = p.Period
