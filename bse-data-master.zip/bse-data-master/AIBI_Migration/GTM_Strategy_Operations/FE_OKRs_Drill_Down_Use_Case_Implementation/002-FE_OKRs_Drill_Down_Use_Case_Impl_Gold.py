# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.feokrs_use_case_implementation_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT
# MAGIC     snapshot_fiscal_quarter_start_date,
# MAGIC     snapshot_fiscal_quarter_end_date,
# MAGIC     snapshot_fiscal_year_quarter,
# MAGIC     account_id,
# MAGIC     account_name,
# MAGIC     t3m_annualized,
# MAGIC     t3m_annualized_band,
# MAGIC     t3m_business_unit_rank,
# MAGIC     t3m_sales_subregion_level_1_rank,
# MAGIC     t3m_global_rank,
# MAGIC     business_unit,
# MAGIC     sales_subregion_level_1,
# MAGIC     usecase_ID,
# MAGIC     usecase_name,
# MAGIC     CONCAT(usecase_ID, usecase_name) AS use_case_unique_identifier,
# MAGIC     stage,
# MAGIC     validation_date,
# MAGIC     evaluating_date,
# MAGIC     onboarding_date,
# MAGIC     target_live_date,
# MAGIC     live_date,
# MAGIC     lost_date,
# MAGIC     use_case_rank_overall,
# MAGIC     target_live_date_fiscal_quarter_start_date,
# MAGIC     target_live_date_fiscal_quarter_end_date,
# MAGIC     target_live_date_fiscal_year_quarter,
# MAGIC     estimated_monthly_dollar_dbus,
# MAGIC     implementation_partner_name,
# MAGIC     COALESCE(blockers, 'N/A') AS blockers,
# MAGIC     has_ps_project,
# MAGIC     days_in_stage,
# MAGIC     Has_Partner,
# MAGIC     Has_PS_or_Implementation_Partner,
# MAGIC     included_in_okr,
# MAGIC     has_ps_or_implementation_partner_account,
# MAGIC     customer_type,
# MAGIC     customer_start_date,
# MAGIC     DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 AS age_years,
# MAGIC     CASE 
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 < 1 THEN 0
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 < 2 THEN 1
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 < 3 THEN 2
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 < 4 THEN 3
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 < 5 THEN 4
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 >= 5 THEN 5
# MAGIC     END AS cust_age_buckets,
# MAGIC     CASE 
# MAGIC       WHEN sales_region = 'LATAM' THEN 'AMER'
# MAGIC       ELSE sales_region 
# MAGIC     END AS region,
# MAGIC     account_executive,
# MAGIC     account_status,
# MAGIC     customer_success_engineer,
# MAGIC     dbu_dollars_t3m_annualized_bucket,
# MAGIC     dbu_dollars_t3m,
# MAGIC     dbu_dollars_t3m_annualized,
# MAGIC     sales_subregion_level_2,
# MAGIC     sales_subregion_level_3,
# MAGIC     has_snowflake_migration,
# MAGIC     last_solution_architect_engaged,
# MAGIC     partner_sales_manager,
# MAGIC     sales_leader,
# MAGIC     sales_manager,
# MAGIC     scp_status,
# MAGIC     support_tier,
# MAGIC     vertical,
# MAGIC     manager_name,
# MAGIC     rank_bu,
# MAGIC     rank_bu_plus1,
# MAGIC     rank_global,
# MAGIC     max_date
# MAGIC   FROM main.it_aibi_silver.feokrs_use_case_implementation_silver
# MAGIC ),
# MAGIC distinct_counts AS (
# MAGIC   SELECT
# MAGIC     business_unit,
# MAGIC     COUNT(DISTINCT usecase_ID) AS total_use_cases_bu,
# MAGIC     COUNT(DISTINCT CASE WHEN Has_PS_or_Implementation_Partner = 'Yes' THEN account_id END) AS use_case_accounts_with_partner_bu,
# MAGIC     COUNT(DISTINCT usecase_ID) AS global_total_use_cases,
# MAGIC     COUNT(DISTINCT CASE WHEN Has_PS_or_Implementation_Partner = 'Yes' THEN account_id END) AS global_use_case_accounts_with_partner
# MAGIC   FROM base_data
# MAGIC   GROUP BY business_unit
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   bd.*,
# MAGIC   dc.total_use_cases_bu,
# MAGIC   dc.use_case_accounts_with_partner_bu / NULLIF(dc.total_use_cases_bu, 0) AS use_case_pct_accounts_with_partner_bu,
# MAGIC   SUM(CASE WHEN bd.Has_PS_or_Implementation_Partner = 'Yes' THEN bd.estimated_monthly_dollar_dbus ELSE 0 END) OVER (PARTITION BY bd.business_unit) / 
# MAGIC     NULLIF(SUM(bd.estimated_monthly_dollar_dbus) OVER (PARTITION BY bd.business_unit), 0) AS use_case_pct_dollar_with_partner_bu,
# MAGIC   COUNT(CASE WHEN bd.Has_PS_or_Implementation_Partner = 'Yes' THEN bd.usecase_ID END) OVER (PARTITION BY bd.business_unit) / 
# MAGIC     NULLIF(COUNT(bd.usecase_ID) OVER (PARTITION BY bd.business_unit), 0) AS use_case_pct_with_partner_bu,
# MAGIC   SUM(CASE WHEN bd.Has_PS_or_Implementation_Partner = 'Yes' THEN bd.estimated_monthly_dollar_dbus ELSE 0 END) OVER (PARTITION BY bd.business_unit) AS use_case_dollar_with_partner_bu,
# MAGIC   SUM(bd.estimated_monthly_dollar_dbus) OVER (PARTITION BY bd.business_unit) AS total_estimated_monthly_dbu_dollars_bu,
# MAGIC   
# MAGIC   dc.global_total_use_cases,
# MAGIC   dc.global_use_case_accounts_with_partner / NULLIF(dc.global_total_use_cases, 0) AS global_use_case_pct_accounts_with_partner,
# MAGIC   SUM(CASE WHEN bd.Has_PS_or_Implementation_Partner = 'Yes' THEN bd.estimated_monthly_dollar_dbus ELSE 0 END) OVER () / 
# MAGIC     NULLIF(SUM(bd.estimated_monthly_dollar_dbus) OVER (), 0) AS global_use_case_pct_dollar_with_partner,
# MAGIC   COUNT(CASE WHEN bd.Has_PS_or_Implementation_Partner = 'Yes' THEN bd.usecase_ID END) OVER () / 
# MAGIC     NULLIF(COUNT(bd.usecase_ID) OVER (), 0) AS global_use_case_pct_with_partner,
# MAGIC   SUM(CASE WHEN bd.Has_PS_or_Implementation_Partner = 'Yes' THEN bd.estimated_monthly_dollar_dbus ELSE 0 END) OVER () AS global_use_case_dollar_with_partner,
# MAGIC   SUM(bd.estimated_monthly_dollar_dbus) OVER () AS global_total_estimated_monthly_dbu_dollars
# MAGIC FROM base_data bd
# MAGIC JOIN distinct_counts dc
# MAGIC ON bd.business_unit = dc.business_unit
