# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.feokrs_use_case_implementation_silver
# MAGIC
# MAGIC WITH base AS (
# MAGIC     SELECT 
# MAGIC         * 
# MAGIC     FROM 
# MAGIC         main.gtm_data.okrs_use_case_implementation_attach_detail
# MAGIC ),
# MAGIC
# MAGIC account_base AS (
# MAGIC     SELECT 
# MAGIC         customer_type,
# MAGIC         account_id,
# MAGIC         customer_start_date,
# MAGIC         customer_age_years AS age_years,
# MAGIC         CASE 
# MAGIC             WHEN sales_region = 'LATAM' THEN 'AMER' 
# MAGIC             ELSE sales_region 
# MAGIC         END AS sales_region,
# MAGIC         account_executive,
# MAGIC         account_name,
# MAGIC         account_status,
# MAGIC         dsa AS customer_success_engineer,
# MAGIC         -- customer_success_leader,
# MAGIC         t3m_annualized_band AS dbu_dollars_t3m_annualized_bucket,
# MAGIC         t3m_annualized / 4 AS dbu_dollars_t3m,
# MAGIC         t3m_annualized AS dbu_dollars_t3m_annualized,
# MAGIC         has_snowflake_migration,
# MAGIC         last_solution_architect_engaged,
# MAGIC         partner_sales_manager,
# MAGIC         sales_leader,
# MAGIC         sales_manager,
# MAGIC         sales_subregion_level_1,
# MAGIC         sales_subregion_level_2,
# MAGIC         sales_subregion_level_3,
# MAGIC         scp_status,
# MAGIC         support_tier,
# MAGIC         vertical,
# MAGIC         sales_business_unit,
# MAGIC         sa_manager AS manager_name,
# MAGIC         consumption_commit_business_unit_rank AS rank_bu,
# MAGIC         consumption_commit_sales_subregion_level_1_rank AS rank_bu_plus1,
# MAGIC         consumption_commit_global_rank AS rank_global
# MAGIC     FROM 
# MAGIC         main.gtm_data.core_accounts_curated
# MAGIC     WHERE 
# MAGIC         1=1
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC     a.*, 
# MAGIC     a.Has_PS_or_Implementation_Partner AS has_ps_or_implementation_partner_account,
# MAGIC     b.customer_type,
# MAGIC     b.customer_start_date,
# MAGIC     b.age_years,
# MAGIC     b.sales_region,
# MAGIC     b.account_executive,
# MAGIC     b.account_status,
# MAGIC     b.customer_success_engineer,
# MAGIC     --b.customer_success_leader,
# MAGIC     b.dbu_dollars_t3m_annualized_bucket,
# MAGIC     b.dbu_dollars_t3m,
# MAGIC     b.dbu_dollars_t3m_annualized,
# MAGIC     b.sales_subregion_level_2,
# MAGIC     b.sales_subregion_level_3,
# MAGIC     b.has_snowflake_migration,
# MAGIC     b.last_solution_architect_engaged,
# MAGIC     b.partner_sales_manager,
# MAGIC     b.sales_leader,
# MAGIC     b.sales_manager,
# MAGIC     b.scp_status,
# MAGIC     b.support_tier,
# MAGIC     b.vertical,
# MAGIC     b.manager_name,
# MAGIC     b.rank_bu,
# MAGIC     b.rank_bu_plus1,
# MAGIC     b.rank_global,
# MAGIC     current_date() AS max_date
# MAGIC FROM 
# MAGIC     main.gtm_data.okrs_use_case_implementation_attach_detail a 
# MAGIC LEFT JOIN 
# MAGIC     account_base b 
# MAGIC ON 
# MAGIC     a.account_id = b.account_id
