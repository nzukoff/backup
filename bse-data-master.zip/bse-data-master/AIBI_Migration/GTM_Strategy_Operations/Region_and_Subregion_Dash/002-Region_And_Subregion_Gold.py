# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.region_and_subregion_gold AS
# MAGIC
# MAGIC SELECT 
# MAGIC     ad_creative_name,
# MAGIC     ad_creative_size,
# MAGIC     ad_group_name,
# MAGIC     ad_name,
# MAGIC     ad_offer_name,
# MAGIC     ad_offer_type,
# MAGIC     ad_version,
# MAGIC     audience,
# MAGIC     brand_filter,
# MAGIC     budget_type,
# MAGIC     cloud,
# MAGIC     creative_ad_type,
# MAGIC     date,
# MAGIC     isv,
# MAGIC     language,
# MAGIC     medium,
# MAGIC     objective,
# MAGIC     offer,
# MAGIC     region,
# MAGIC     source,
# MAGIC     sub_region,
# MAGIC     vertical,
# MAGIC     sum(clicks) as clicks,
# MAGIC     sum(cost) as cost,
# MAGIC     sum(impressions) as impressions,
# MAGIC     sum(mql_response) as mql_response,
# MAGIC     sum(net_new_names) as net_new_names,
# MAGIC     sum(quality_net_new_names) as quality_net_new_names,
# MAGIC     sum(responders) as responders,
# MAGIC     sum(responses) as responses,
# MAGIC     sum(u2_amount) as u2_amount,
# MAGIC     sum(u2_unit) as u2_unit,
# MAGIC     sum(validate_date_O1_land_amount) as validate_date_O1_land_amount,
# MAGIC     
# MAGIC     -- Date FY
# MAGIC     date AS Date_FY,
# MAGIC     
# MAGIC     -- Yesterday
# MAGIC     DATEADD(day, -1, CURRENT_DATE) AS Yesterday,
# MAGIC     
# MAGIC     -- % of Total Cost
# MAGIC     SUM(cost) / SUM(SUM(cost)) OVER () AS Percent_of_Total_Cost,
# MAGIC     
# MAGIC     -- CPC
# MAGIC     SUM(cost) / NULLIF(SUM(clicks), 0) AS CPC,
# MAGIC     
# MAGIC     -- CPMQL
# MAGIC     SUM(cost) / NULLIF(SUM(mql_response), 0) AS CPMQL,
# MAGIC     
# MAGIC     -- CPNNN
# MAGIC     SUM(cost) / NULLIF(SUM(net_new_names), 0) AS CPNNN,
# MAGIC     
# MAGIC     -- CPQNNN
# MAGIC     SUM(cost) / NULLIF(SUM(quality_net_new_names), 0) AS CPQNNN,
# MAGIC     
# MAGIC     -- CPR
# MAGIC     SUM(cost) / NULLIF(SUM(responders), 0) AS CPR,
# MAGIC     
# MAGIC     -- CPU2 (Use Cases)
# MAGIC     SUM(cost) / NULLIF(SUM(u2_unit), 0) AS CPU2,
# MAGIC     
# MAGIC     -- CVR
# MAGIC     SUM(responders) / NULLIF(SUM(clicks), 0) AS CVR,
# MAGIC     
# MAGIC     -- O1 ROI
# MAGIC     SUM(validate_date_O1_land_amount) / NULLIF(SUM(cost), 0) AS O1_ROI,
# MAGIC     
# MAGIC     -- U2 Pipe to Spend Ratio* (Use Cases)
# MAGIC     SUM(u2_amount) / NULLIF(SUM(cost), 0) AS U2_Pipe_to_Spend_Ratio,
# MAGIC     
# MAGIC     -- MQL Rate
# MAGIC     SUM(mql_response) / NULLIF(SUM(responders), 0) AS MQL_Rate,
# MAGIC     
# MAGIC     -- Contains LGF
# MAGIC     CASE 
# MAGIC         WHEN ad_campaign_name LIKE '%LGF%' THEN 'True'
# MAGIC         ELSE 'False'
# MAGIC     END AS Contains_LGF
# MAGIC
# MAGIC FROM 
# MAGIC     main.it_aibi_silver.region_and_subregion_silver
# MAGIC GROUP BY
# MAGIC     ad_creative_name,
# MAGIC     ad_creative_size,
# MAGIC     ad_group_name,
# MAGIC     ad_name,
# MAGIC     ad_offer_name,
# MAGIC     ad_offer_type,
# MAGIC     ad_version,
# MAGIC     audience,
# MAGIC     brand_filter,
# MAGIC     budget_type,
# MAGIC     cloud,
# MAGIC     creative_ad_type,
# MAGIC     date,
# MAGIC     isv,
# MAGIC     language,
# MAGIC     medium,
# MAGIC     objective,
# MAGIC     offer,
# MAGIC     region,
# MAGIC     source,
# MAGIC     sub_region,
# MAGIC     vertical,
# MAGIC     ad_campaign_name

# COMMAND ----------



# COMMAND ----------


