# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, coalesce, avg, max, when, expr, lit
from pyspark.sql.window import Window


# Load the data from the source table
main_df = spark.table("main.it_aibi_silver.tranche_movement_silver")

# Base Data Calculation
base_data = main_df.select(
    "bu", "fiscal_year", "fiscal_qtr", "fyfq", "platform", "sfdc_account_id",
    "sfdc_account_name", "sub_bu", "dbu_dollars", "year", "Business_Unit__c",
    "Account_Record_Type_Name__c", "Segment__c", "Serverless_compute_acceptable__c",
    "accountid_casesafe__c",
    expr("fiscal_year || '-' || fiscal_qtr").alias("Fiscal_Quarter"),
    coalesce(col("dbu_dollars"), lit(0)).alias("DBU_DOLLARS_Calculated"),
    (coalesce(col("dbu_dollars"), lit(0)) * 4).alias("DBUs_Annualized"),
    when(expr("RIGHT(fyfq, 1)") == '1', expr("CAST(year || '-01-01' AS DATE)"))
    .when(expr("RIGHT(fyfq, 1)") == '2', expr("CAST(year || '-04-01' AS DATE)"))
    .when(expr("RIGHT(fyfq, 1)") == '3', expr("CAST(year || '-07-01' AS DATE)"))
    .when(expr("RIGHT(fyfq, 1)") == '4', expr("CAST(year || '-10-01' AS DATE)"))
    .alias("Date")
)

# FY24 Q2 Calculation
fy24_q2_calc = base_data.filter(col("Fiscal_Quarter") == 'FY24-Q2') \
    .groupBy("sfdc_account_id") \
    .agg(coalesce(avg(col("DBUs_Annualized")), lit(0)).alias("FY24_Q2_Dollars_x4"))

# QoQ and YoY Calculation
qoq_yoy_calc = base_data.alias('b').join(
    fy24_q2_calc.alias('f'), on='sfdc_account_id', how='left'
).select(
    'b.*', 'f.FY24_Q2_Dollars_x4',
    max(when(col('Fiscal_Quarter') == 'FY25-Q1', col('DBUs_Annualized'))).over(Window.partitionBy('b.sfdc_account_id')).alias('CQ_Dollars_x4'),
    max(when(col('Fiscal_Quarter') == 'FY24-Q4', col('DBUs_Annualized'))).over(Window.partitionBy('b.sfdc_account_id')).alias('PQ_Dollars_x4'),
    max(when(col('b.fiscal_year') == '2025', col('b.DBU_DOLLARS'))).over(Window.partitionBy('b.sfdc_account_id')).alias('CY_Dollars'),
    max(when(col('b.fiscal_year') == '2024', col('b.DBU_DOLLARS'))).over(Window.partitionBy('b.sfdc_account_id')).alias('PY_Dollars')
)

# Tranche Calculation
tranche_calc = qoq_yoy_calc.select(
    '*',
    when(col('DBUs_Annualized') >= 5000000, '1. $5M+')
    .when(col('DBUs_Annualized') >= 1000000, '2. $1M - 5M')
    .when(col('DBUs_Annualized') >= 500000, '3. $500K - 1M+')
    .when(col('DBUs_Annualized') >= 100000, '4. $100K - 500K')
    .when(col('DBUs_Annualized') >= 12000, '5. $12K - 100K')
    .when(col('DBUs_Annualized') >= 5000, '6. $5k - 12K')
    .when(col('DBUs_Annualized') >= 1000, '7. $1k - 5K')
    .when(col('DBUs_Annualized') >= 500, '8. $500 - 1k')
    .when(col('DBUs_Annualized') > 0.01, '9. $1 - 500')
    .otherwise('10. $0').alias('Tranche_w_Greenfield'),
    
    when(col('DBUs_Annualized') >= 5000000, '1. $5M+')
    .when(col('DBUs_Annualized') >= 1000000, '2. $1M - 5M')
    .when(col('DBUs_Annualized') >= 500000, '3. $500K - 1M+')
    .when(col('DBUs_Annualized') >= 100000, '4. $100K - 500K')
    .when(col('DBUs_Annualized') > 0, '6. $1 - 12K')
    .otherwise('6. $0 - 12K').alias('Tranche')
)

# Tranche Changes Calculation
tranche_changes = tranche_calc.select(
    '*',
    (col('CQ_Dollars_x4') - col('PQ_Dollars_x4')).alias('QoQ_Difference'),
    (col('CY_Dollars') - col('PY_Dollars')).alias('YoY_Difference'),
    
    max(when(tranche_calc.fiscal_year == '2025', tranche_calc.Tranche)).over(Window.partitionBy(tranche_calc.sfdc_account_id)).alias("CY_Tranche"),
    
    max(when(tranche_calc.fiscal_year == '2024', tranche_calc.Tranche)).over(Window.partitionBy(tranche_calc.sfdc_account_id)).alias("PY_Tranche"),

    max(when(tranche_calc.Fiscal_Quarter == 'FY25-Q1', tranche_calc.Tranche)).over(Window.partitionBy(tranche_calc.sfdc_account_id)).alias("CQ_Tranche"),

    max(when(tranche_calc.Fiscal_Quarter == 'FY24-Q4', tranche_calc.Tranche)).over(Window.partitionBy(tranche_calc.sfdc_account_id)).alias("PQ_Tranche")
)

# Final Selection with Calculations
final_df = tranche_changes.select(
    '*',
    when(tranche_changes.PQ_Dollars_x4 > lit(0), 
         (tranche_changes.CQ_Dollars_x4 - tranche_changes.PQ_Dollars_x4) / tranche_changes.PQ_Dollars_x4
    ).otherwise(lit(None)).alias("QoQ_Change"),

    when(tranche_changes.PY_Dollars > lit(0), 
         (tranche_changes.CY_Dollars - tranche_changes.PY_Dollars) / tranche_changes.PY_Dollars
    ).otherwise(lit(None)).alias("YoY_Change"),

    col("Business_Unit__c").alias("Business_Unit"),

    when(col("Business_Unit__c") != col("bu"), lit(1)).otherwise(lit(0)).alias("bu_match"),

    max(when(tranche_changes.Fiscal_Quarter == "FY24-Q2", tranche_changes.Tranche_w_Greenfield)).over(Window.partitionBy(tranche_changes.sfdc_account_id)).alias("FY24_Q2_Tranche_w_greenfield"),

    max(when(tranche_changes.Fiscal_Quarter == "FY24-Q4", tranche_changes.Tranche_w_Greenfield)).over(Window.partitionBy(tranche_changes.sfdc_account_id)).alias("FY24_Q4_Tranche_w_greenfield"),

    max(when(tranche_changes.Fiscal_Quarter == "FY25-Q1", tranche_changes.Tranche_w_Greenfield)).over(Window.partitionBy(tranche_changes.sfdc_account_id)).alias("FY25_Q1_Tranche_w_greenfield"),

    max(
        when((tranche_changes.YoY_Difference > lit(0)) & 
             ((tranche_changes.PY_Tranche != tranche_changes.CY_Tranche) | 
              (tranche_changes.PY_Tranche.isNull() & ~tranche_changes.CY_Tranche.isNull())), 
             lit("Moved Up")
        ).when((tranche_changes.YoY_Difference < lit(0)) & 
               ((tranche_changes.PY_Tranche != tranche_changes.CY_Tranche) | 
                (~tranche_changes.PY_Tranche.isNull() & tranche_changes.CY_Tranche.isNull())), 
               lit("Moved Down")
        ).when((tranche_changes.PY_Tranche == tranche_changes.CY_Tranche) | 
               (tranche_changes.PY_Tranche.isNull() & tranche_changes.CY_Tranche.isNull()), 
               lit("No Change")
        ).otherwise(lit("aSomething Wrong"))
    ).over(Window.partitionBy(tranche_changes.sfdc_account_id)).alias("YoY_Tranchanges"),

    max(
        when((tranche_changes.QoQ_Difference > lit(0)) & 
             ((tranche_changes.PQ_Tranche != tranche_changes.CQ_Tranche) | 
              (tranche_changes.PQ_Tranche.isNull() & ~tranche_changes.CQ_Tranche.isNull())), 
             lit("Moved Up")
        ).when((tranche_changes.QoQ_Difference < lit(0)) & 
               ((tranche_changes.PQ_Tranche != tranche_changes.CQ_Tranche) | 
                (~tranche_changes.PQ_Tranche.isNull() & tranche_changes.CQ_Tranche.isNull())), 
               lit("Moved Down")
        ).when((tranche_changes.PQ_Tranche == tranche_changes.CQ_Tranche) | 
               (tranche_changes.PQ_Tranche.isNull() & tranche_changes.CQ_Tranche.isNull()), 
               lit("No Change")
        ).otherwise(lit("aSomething Wrong"))
    ).over(Window.partitionBy(tranche_changes.sfdc_account_id)).alias("FY25_Q1_QoQ_Tranchchanges")
)




# COMMAND ----------

final_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable("main.it_aibi_gold.tranche_movement_gold")
