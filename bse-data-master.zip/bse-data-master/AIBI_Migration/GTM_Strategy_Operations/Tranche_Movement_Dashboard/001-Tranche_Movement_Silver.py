# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.tranche_movement_silver as
# MAGIC
# MAGIC WITH actual_and_ds_forecast_dollardbu AS (
# MAGIC     SELECT
# MAGIC         bu,
# MAGIC         fiscal_year,
# MAGIC         fiscal_qtr,
# MAGIC         fyfq,
# MAGIC         platform,
# MAGIC         sfdc_account_id,
# MAGIC         sfdc_account_name,
# MAGIC         sub_bu,
# MAGIC         dbu_dollars,
# MAGIC         year
# MAGIC     FROM main.fin_live_gold.actual_and_ds_forecast_dollardbu
# MAGIC ),
# MAGIC
# MAGIC account AS (
# MAGIC     SELECT 
# MAGIC         a.Business_Unit__c, 
# MAGIC         a.Account_Record_Type_Name__c, 
# MAGIC         a.Segment__c,
# MAGIC         a.Serverless_compute_acceptable__c,
# MAGIC         a.accountid_casesafe__c
# MAGIC     FROM main.sfdc_bronze.account a
# MAGIC     WHERE processdate = (SELECT MAX(processdate) FROM main.sfdc_bronze.account)
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC     *
# MAGIC FROM 
# MAGIC     actual_and_ds_forecast_dollardbu d
# MAGIC LEFT JOIN 
# MAGIC     account ac
# MAGIC ON 
# MAGIC     d.sfdc_account_id = ac.accountid_casesafe__c
