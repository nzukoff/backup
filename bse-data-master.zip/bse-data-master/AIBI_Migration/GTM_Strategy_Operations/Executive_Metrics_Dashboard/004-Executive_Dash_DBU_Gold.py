# Databricks notebook source
# MAGIC %sql
# MAGIC SELECT 
# MAGIC     target_region,
# MAGIC     target_region2,
# MAGIC     target_region3,
# MAGIC     target_fiscal_quarter,
# MAGIC     target_fiscal_year,
# MAGIC     Target_DBUs,
# MAGIC     Partner_DBUs,
# MAGIC     Account_Name,
# MAGIC     Account_Vertical,
# MAGIC     Account__c,
# MAGIC     DBX__c,
# MAGIC     fiscal_quarter,
# MAGIC     FiscalYear,
# MAGIC     managed_coverage,
# MAGIC     Owner_Role__c,
# MAGIC     PAM,
# MAGIC     Parent_Account,
# MAGIC     Parent_ID,
# MAGIC     Partner_Tier,
# MAGIC     Region,
# MAGIC     Region_2,
# MAGIC     Region_3,
# MAGIC     Region_4,
# MAGIC     month,
# MAGIC     Usage_Date__c,
# MAGIC     Split_RevShare_Dollars,
# MAGIC     fiscal_quarter_use_case,
# MAGIC     region_use_case,
# MAGIC     region2_use_case,
# MAGIC     region3_use_case,
# MAGIC     region4_use_case,
# MAGIC     stage_use_case,
# MAGIC     fiscal_quarter_target,
# MAGIC     fiscal_year_target,
# MAGIC     region_target,
# MAGIC     region2_target,
# MAGIC     region3_target,
# MAGIC     dbu_target
# MAGIC FROM 
# MAGIC     main.it_aibi_silver.exec_dash_dbu_silver

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.exec_dash_dbu_gold as
# MAGIC
# MAGIC WITH yearly_totals AS (
# MAGIC     SELECT 
# MAGIC         FiscalYear,
# MAGIC         SUM(Split_RevShare_Dollars) AS Total_RevShare_Dollars,
# MAGIC         COUNT(DISTINCT CASE WHEN Partner_Account <> 'No Partner' THEN Account__c END) AS Partner_Joint_Customers
# MAGIC     FROM main.it_aibi_silver.exec_dash_dbu_silver
# MAGIC     GROUP BY FiscalYear
# MAGIC ),
# MAGIC previous_year_data AS (
# MAGIC     SELECT 
# MAGIC         FiscalYear,
# MAGIC         SUM(CASE WHEN Partner_Account <> 'No Partner' THEN Split_RevShare_Dollars ELSE 0 END) AS Previous_Year_Partner_DBU,
# MAGIC         SUM(Split_RevShare_Dollars) AS Previous_Year_Total_DBU,
# MAGIC         COUNT(DISTINCT CASE WHEN Partner_Account <> 'No Partner' THEN Account__c END) AS Previous_Year_Partner_Joint_Customers
# MAGIC     FROM main.it_aibi_silver.exec_dash_dbu_silver
# MAGIC     GROUP BY FiscalYear
# MAGIC )
# MAGIC SELECT 
# MAGIC     e.*,
# MAGIC     CASE 
# MAGIC         WHEN e.Partner_Account = 'No Partner' THEN 0
# MAGIC         ELSE e.Split_RevShare_Dollars
# MAGIC     END AS Partner_Impacted_DBU,
# MAGIC     CASE 
# MAGIC         WHEN yt.Total_RevShare_Dollars = 0 THEN NULL
# MAGIC         ELSE 
# MAGIC             CASE 
# MAGIC                 WHEN e.Partner_Account = 'No Partner' THEN 0
# MAGIC                 ELSE e.Split_RevShare_Dollars
# MAGIC             END / yt.Total_RevShare_Dollars
# MAGIC     END AS Current_Year_PE_Percentage,
# MAGIC     CASE 
# MAGIC         WHEN e.Partner_Account <> 'No Partner' THEN e.Account__c 
# MAGIC         ELSE NULL
# MAGIC     END AS Partner_Joint_Customer,
# MAGIC     CASE 
# MAGIC         WHEN py.Previous_Year_Partner_DBU = 0 THEN NULL
# MAGIC         ELSE (CASE 
# MAGIC             WHEN e.Partner_Account = 'No Partner' THEN 0
# MAGIC             ELSE e.Split_RevShare_Dollars
# MAGIC         END / py.Previous_Year_Partner_DBU) - 1
# MAGIC     END AS Partner_YoY_Percentage,
# MAGIC     -- Adding PE% YoY
# MAGIC     CASE 
# MAGIC         WHEN yt.Total_RevShare_Dollars = 0 OR py.Previous_Year_Total_DBU = 0 THEN NULL
# MAGIC         ELSE (CASE 
# MAGIC             WHEN e.Partner_Account = 'No Partner' THEN 0
# MAGIC             ELSE e.Split_RevShare_Dollars
# MAGIC         END / yt.Total_RevShare_Dollars) - (py.Previous_Year_Partner_DBU / py.Previous_Year_Total_DBU)
# MAGIC     END AS PE_Percentage_YoY,
# MAGIC     -- Adding Previous Year PE%
# MAGIC     CASE 
# MAGIC         WHEN py.Previous_Year_Total_DBU = 0 THEN NULL
# MAGIC         ELSE py.Previous_Year_Partner_DBU / py.Previous_Year_Total_DBU
# MAGIC     END AS Previous_Year_PE_Percentage,
# MAGIC     -- Adding Current Year PE% 
# MAGIC     -- Adding JC YoY%
# MAGIC     CASE 
# MAGIC         WHEN py.Previous_Year_Partner_Joint_Customers = 0 THEN NULL
# MAGIC         ELSE (yt.Partner_Joint_Customers * 1.0 / py.Previous_Year_Partner_Joint_Customers) - 1
# MAGIC     END AS JC_YoY_Percentage
# MAGIC FROM 
# MAGIC     main.it_aibi_silver.exec_dash_dbu_silver e
# MAGIC JOIN 
# MAGIC     yearly_totals yt ON e.FiscalYear = yt.FiscalYear
# MAGIC LEFT JOIN
# MAGIC     previous_year_data py ON e.FiscalYear = py.FiscalYear + 1
