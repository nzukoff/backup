# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.exec_dash_use_case_silver as
# MAGIC
# MAGIC select
# MAGIC Account_CaseSafe_ID,
# MAGIC Sales_Split,
# MAGIC sales_count,
# MAGIC Account_Name,
# MAGIC Account_Owner,
# MAGIC Account_Vertical,
# MAGIC ARR_Band,
# MAGIC DBX__c,
# MAGIC FiscalQuarter,
# MAGIC FiscalYear,
# MAGIC Implementation_Strategy__c as implementation_strategy,
# MAGIC Is_Migration__c as migration,
# MAGIC PAM,
# MAGIC Partner_Name,
# MAGIC Partner_Sales_Manager,
# MAGIC Partner_Tech_Lead__c as partner_tech_lead,
# MAGIC Partner_Tier,
# MAGIC PartnerImpact__c,
# MAGIC PartnerPSImplementation__c,
# MAGIC PartnerRole__c,
# MAGIC Project_Lead,
# MAGIC has_ps_project as ps_project,
# MAGIC redfish,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Implementation_split,
# MAGIC Region_3,
# MAGIC Region_4,
# MAGIC Stages__c as stage,
# MAGIC Full_Production_Date__c as target_live_date,
# MAGIC Use_Case_Id,
# MAGIC Use_Case_Name,
# MAGIC Use_Case_Type__c,
# MAGIC Split_Percent as acct_partner_split_percent,
# MAGIC Total_Split,
# MAGIC MonthlyTotalDollarDBUs__c as monthly_dbu_est
# MAGIC from main.gtm_partner_data.csi_partner_use_case
# MAGIC
# MAGIC
# MAGIC
