# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import sum, when, coalesce, col, lit



# Read the input tables
csi_partner_use_case = spark.table("gtm_partner_data.csi_partner_use_case")
csi_partner_dbu = spark.table("gtm_partner_data.csi_partner_dbu_live")

# Create the USE_CASE DataFrame
use_case = csi_partner_use_case \
    .groupBy(
        "FiscalQuarter", "FiscalYear", "Partner_Sales_Manager", "PartnerRole__c",
        "Region", "Region_2", "Region_3", col("Stages__c").alias("stage")
    ) \
    .agg(
        sum(when(col("PartnerRole__c") == "Implementation (SI)", col("MonthlyTotalDollarDBUs__c")).otherwise(0)).alias("partner_implementation_use_case"),
        sum("MonthlyTotalDollarDBUs__c").alias("MonthlyTotalDollarDBUs")
    )

# Create the DBU DataFrame
dbu = csi_partner_dbu \
    .groupBy("Region", "Region_2", "Region_3", "fiscal_quarter", "FiscalYear") \
    .agg(
        sum("Split_RevShare_Dollars").alias("Split_RevShare_Dollars"),
        sum(when(col("Partner_Account") != "No Partner", col("Split_RevShare_Dollars")).otherwise(0)).alias("Partner_DBUs")
    )

# Perform the final join and aggregation
exec_dash_close_the_gap_silver = use_case.alias("use_case") \
    .join(
        dbu.alias("dbu"),
        (col("use_case.Region") == col("dbu.Region")) &
        (col("use_case.Region_2") == col("dbu.Region_2")) &
        (col("use_case.Region_3") == col("dbu.Region_3")),
        "left"
    ) \
    .select(
        coalesce(col("use_case.MonthlyTotalDollarDBUs"), lit(0)).alias("MonthlyTotalDollarDBUs"),
        coalesce(col("use_case.partner_implementation_use_case"), lit(0)).alias("partner_implementation_use_case"),
        coalesce(col("dbu.Split_RevShare_Dollars"), lit(0)).alias("Split_RevShare_Dollars"),
        coalesce(col("dbu.Partner_DBUs"), lit(0)).alias("Partner_DBUs"),
        col("dbu.Region").alias("dbu_region"),
        col("dbu.Region_2").alias("dbu_region2"),
        col("dbu.Region_3").alias("dbu_region3"),
        col("dbu.fiscal_quarter").alias("dbu_fiscal_quarter"),
        col("dbu.FiscalYear").alias("dbu_fiscal_year"),
        col("use_case.FiscalQuarter"),
        col("use_case.FiscalYear"),
        col("use_case.Partner_Sales_Manager"),
        col("use_case.PartnerRole__c"),
        col("use_case.Region"),
        col("use_case.Region_2"),
        col("use_case.Region_3"),
        col("use_case.stage")
    )

# Show the result
#exec_dash_close_the_gap_silver.display()

# COMMAND ----------

exec_dash_close_the_gap_silver.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.exec_dash_close_the_gap_silver")
