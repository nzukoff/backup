# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.exec_dash_pam_gold AS
# MAGIC
# MAGIC WITH joint_customer_counts AS (
# MAGIC   SELECT
# MAGIC     Partner_Account,
# MAGIC     FiscalYear,
# MAGIC     COUNT(CASE WHEN Partner_Account <> 'No Partner' THEN Account__c END) AS joint_customer_count
# MAGIC   FROM main.it_aibi_silver.exec_dash_pam_silver
# MAGIC   GROUP BY Partner_Account, FiscalYear
# MAGIC ),
# MAGIC subquery AS (
# MAGIC   SELECT
# MAGIC     e.*,
# MAGIC     -- Partner Y/Y%
# MAGIC     COALESCE(try_divide(e.Split_RevShare_Dollars, NULLIF(LAG(e.Split_RevShare_Dollars) OVER (PARTITION BY e.Partner_Account ORDER BY e.FiscalYear), 0)), 0) - 1 AS Partner_YoY_Percent,
# MAGIC     -- Partner Joint Customer
# MAGIC     CASE WHEN e.Partner_Account <> 'No Partner' THEN e.Account__c END AS Partner_Joint_Customer,
# MAGIC     -- JC YoY%
# MAGIC     COALESCE(try_divide(jcc.joint_customer_count, NULLIF(LAG(jcc.joint_customer_count) OVER (PARTITION BY e.Partner_Account ORDER BY e.FiscalYear), 0)), 0) - 1 AS JC_YoY_Percent
# MAGIC   FROM main.it_aibi_silver.exec_dash_pam_silver e
# MAGIC   LEFT JOIN joint_customer_counts jcc ON e.Partner_Account = jcc.Partner_Account AND e.FiscalYear = jcc.FiscalYear
# MAGIC )
# MAGIC SELECT
# MAGIC   Account_Name,
# MAGIC   Account_Vertical,
# MAGIC   Account__c,
# MAGIC   DBX__c,
# MAGIC   fiscal_quarter,
# MAGIC   FiscalYear,
# MAGIC   managed_coverage,
# MAGIC   --Owner_Role__c,
# MAGIC   --PAM,
# MAGIC   Partner_Account,
# MAGIC   Parent_ID,
# MAGIC   Partner_Tier,
# MAGIC   Region,
# MAGIC   Region_2,
# MAGIC   Region_3,
# MAGIC   Region_4,
# MAGIC   Usage_Date__c,
# MAGIC   SUM(Split_RevShare_Dollars) AS Split_RevShare_Dollars,
# MAGIC   --fiscal_quarter_target,
# MAGIC   --fiscal_year_target,
# MAGIC   --parent_account_target,
# MAGIC   --Portfolio,
# MAGIC   --SUM(dbu_target) AS dbu_target,
# MAGIC   MAX(Partner_YoY_Percent) AS Partner_YoY_Percent,
# MAGIC   Partner_Joint_Customer,
# MAGIC   MAX(JC_YoY_Percent) AS JC_YoY_Percent
# MAGIC   -- Attainment % PAM
# MAGIC   --COALESCE(try_divide(SUM(Split_RevShare_Dollars), NULLIF(SUM(dbu_target), 0)), 0) AS Attainment_Percent_PAM
# MAGIC FROM subquery
# MAGIC GROUP BY 
# MAGIC   Account_Name, Account_Vertical, Account__c, DBX__c, fiscal_quarter, FiscalYear, managed_coverage, 
# MAGIC --PAM,
# MAGIC   Partner_Account, Parent_ID, Partner_Tier, Region, Region_2, Region_3, Region_4, 
# MAGIC   Usage_Date__c,   
# MAGIC   --Portfolio, 
# MAGIC   Partner_Joint_Customer
# MAGIC   --fiscal_quarter_target
# MAGIC   --fiscal_year_target
# MAGIC   --parent_account_target
# MAGIC   --Owner_Role__c
