# Databricks notebook source
##FROM DYLAN -- Splitting out target by account

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

# Load the data from the respective tables
aggregated_dbu_df = spark.table("gtm_partner_data.csi_partner_dbu_live")
target_df = spark.table("gtm_partner_data.csi_partner_dbu_target_bu")

# Step 1: Calculate the total Split_RevShare_Dollars at the Region_2 level
region2_totals = aggregated_dbu_df.groupBy(
    "Region_2", "FiscalYear", "fiscal_quarter"
).agg(
    F.sum("Split_RevShare_Dollars").alias("Region2_Total_RevShare_Dollars")
)

# Step 2: Join totals back to the original dataset and calculate account weights
aggregated_dbu_with_totals = aggregated_dbu_df.join(
    region2_totals,
    on=["Region_2", "FiscalYear", "fiscal_quarter"],
    how="left"
).withColumn(
    "Account_Weight",
    F.when(F.col("Region2_Total_RevShare_Dollars") != 0, 
           F.col("Split_RevShare_Dollars") / F.col("Region2_Total_RevShare_Dollars"))
    .otherwise(0)
)

# Step 3: Group the target data by Region, Region_2, Fiscal Quarter, and Fiscal Year
grouped_target_df = target_df.groupBy(
    "Region",
    "Region_2",
    "Fiscal Quarter",
    "Fiscal Year"
).agg(
    F.sum(F.col("$DBU_Target")).alias("Total_DBU_Target")
)

# Step 3.1: Join with the aggregated DBU data
dbu_with_target = aggregated_dbu_with_totals.join(
    grouped_target_df,
    (grouped_target_df.Region == aggregated_dbu_with_totals.Region) &
    (grouped_target_df.Region_2 == aggregated_dbu_with_totals.Region_2) &
    (grouped_target_df["Fiscal Quarter"] == aggregated_dbu_with_totals.fiscal_quarter) &
    (grouped_target_df["Fiscal Year"] == aggregated_dbu_with_totals.FiscalYear),
    "left"
).withColumn(
    "Adjusted_Target_DBUs",
    F.col("Total_DBU_Target") * F.col("Account_Weight")
)


# Step 4: Final aggregation
exec_dash_dbu_silver = dbu_with_target.groupBy(
    aggregated_dbu_with_totals.Account_Name,
    aggregated_dbu_with_totals.Account_Vertical,
    aggregated_dbu_with_totals.Account__c,
    aggregated_dbu_with_totals.DBX__c,
    aggregated_dbu_with_totals.fiscal_quarter,
    aggregated_dbu_with_totals.FiscalYear,
    aggregated_dbu_with_totals.Managed_Coverage,
    aggregated_dbu_with_totals.Owner_Role,
    aggregated_dbu_with_totals.Partner_Manager,
    aggregated_dbu_with_totals.Partner_Account,
    aggregated_dbu_with_totals.Parent_ID,
    aggregated_dbu_with_totals.Partner_Tier,
    aggregated_dbu_with_totals.Region,
    aggregated_dbu_with_totals.Region_2,
    aggregated_dbu_with_totals.Region_3,
    aggregated_dbu_with_totals.Region_4,
    aggregated_dbu_with_totals.Usage_Date__c,
    aggregated_dbu_with_totals.Usage_Date__c.alias('month')
).agg(
    F.sum(F.when(F.col("Partner_Account") != 'No Partner', F.col("Split_RevShare_Dollars")).otherwise(0)).alias("Partner_DBUs"),
    F.coalesce(F.sum("Split_RevShare_Dollars"), F.lit(0)).alias("Split_RevShare_Dollars"),
    F.coalesce(F.sum("Adjusted_Target_DBUs"), F.lit(0)).alias('Target_DBUs')
)

# Show or write the result
exec_dash_dbu_silver.display(2)
exec_dash_dbu_silver.createOrReplaceTempView('exec_dash_dbu_silver')

# COMMAND ----------

exec_dash_dbu_silver.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.exec_dash_dbu_silver")
