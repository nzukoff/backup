# Databricks notebook source
# MAGIC %md
# MAGIC #Final

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.exec_dash_commit_target_gold AS
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     Account_Vertical,
# MAGIC     Commit_ID,
# MAGIC     commit_type,
# MAGIC     dbx,
# MAGIC     fiscal_quarter,
# MAGIC     FiscalYear,
# MAGIC     Manager_Forecast,
# MAGIC     Migration_Commit,
# MAGIC     Nafr,
# MAGIC     New_Logo,
# MAGIC     Opportunity_Name,
# MAGIC     Owner_Role,
# MAGIC     PAM_Name,
# MAGIC     Parent_Account,
# MAGIC     Partner_Impact,
# MAGIC     Partner_Tier,
# MAGIC     Platform,
# MAGIC     primary,
# MAGIC     Region,
# MAGIC     Region_2,
# MAGIC     Region_3,
# MAGIC     Region_4,
# MAGIC     Stage,
# MAGIC     Attributable_Subscription,
# MAGIC     Subscription_Total,
# MAGIC     fiscal_quarter_target,
# MAGIC     fiscal_year_target,
# MAGIC     region_target,
# MAGIC     region2_target,
# MAGIC     region3_target,
# MAGIC     dbu_target
# MAGIC   FROM main.it_aibi_silver.exec_dash_commit_target_silver
# MAGIC ),
# MAGIC
# MAGIC partner_impact_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     CASE 
# MAGIC       WHEN Partner_Impact = 'Partner Sourced' THEN Attributable_Subscription 
# MAGIC       ELSE 0 
# MAGIC     END AS Sourced_Dollar,
# MAGIC     CASE 
# MAGIC       WHEN Partner_Impact = 'Partner Influenced' THEN Attributable_Subscription 
# MAGIC       ELSE 0 
# MAGIC     END AS Influenced_Dollar,
# MAGIC     CASE 
# MAGIC       WHEN Partner_Impact IN ('Partner Sourced', 'Partner Influenced') THEN Attributable_Subscription 
# MAGIC       ELSE 0 
# MAGIC     END AS All_In_Commits
# MAGIC   FROM base_data
# MAGIC ),
# MAGIC
# MAGIC yearly_data AS (
# MAGIC   SELECT 
# MAGIC     fiscal_year_target,
# MAGIC     Region,
# MAGIC     SUM(Sourced_Dollar) AS Year_Sourced,
# MAGIC     SUM(Influenced_Dollar) AS Year_Influenced,
# MAGIC     SUM(All_In_Commits) AS Year_All_In,
# MAGIC     SUM(Subscription_Total) AS Year_Subscription_Total
# MAGIC   FROM partner_impact_data
# MAGIC   GROUP BY fiscal_year_target, Region
# MAGIC ),
# MAGIC
# MAGIC final_data AS (
# MAGIC   SELECT 
# MAGIC     pid.*,
# MAGIC     yd.Year_Sourced AS Current_Year_Sourced,
# MAGIC     yd.Year_Influenced AS Current_Year_Influenced,
# MAGIC     yd.Year_All_In AS Current_Year_All_In,
# MAGIC     yd.Year_Subscription_Total AS Current_Year_Subscription_Total,
# MAGIC     LAG(yd.Year_Sourced) OVER (PARTITION BY pid.Region ORDER BY pid.fiscal_year_target) AS Previous_Year_Sourced,
# MAGIC     LAG(yd.Year_Influenced) OVER (PARTITION BY pid.Region ORDER BY pid.fiscal_year_target) AS Previous_Year_Influenced,
# MAGIC     LAG(yd.Year_All_In) OVER (PARTITION BY pid.Region ORDER BY pid.fiscal_year_target) AS Previous_Year_All_In,
# MAGIC     LAG(yd.Year_Subscription_Total) OVER (PARTITION BY pid.Region ORDER BY pid.fiscal_year_target) AS Previous_Year_Subscription_Total
# MAGIC   FROM partner_impact_data pid
# MAGIC   JOIN yearly_data yd ON pid.fiscal_year_target = yd.fiscal_year_target AND pid.Region = yd.Region
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   *,
# MAGIC   -- Sourced YoY%
# MAGIC   CASE 
# MAGIC     WHEN Previous_Year_Sourced > 0 
# MAGIC     THEN (Current_Year_Sourced / Previous_Year_Sourced) - 1 
# MAGIC     ELSE NULL 
# MAGIC   END AS Sourced_YoY_Percentage,
# MAGIC   
# MAGIC   -- Sourced PE%
# MAGIC   CASE 
# MAGIC     WHEN Current_Year_Subscription_Total > 0 
# MAGIC     THEN Current_Year_Sourced / Current_Year_Subscription_Total 
# MAGIC     ELSE NULL 
# MAGIC   END AS Sourced_PE_Percentage,
# MAGIC   
# MAGIC   -- Sourced PE% YoY
# MAGIC   CASE 
# MAGIC     WHEN Current_Year_Subscription_Total > 0 AND Previous_Year_Subscription_Total > 0
# MAGIC     THEN (Current_Year_Sourced / Current_Year_Subscription_Total) - (Previous_Year_Sourced / Previous_Year_Subscription_Total)
# MAGIC     ELSE NULL 
# MAGIC   END AS Sourced_PE_Percentage_YoY,
# MAGIC   
# MAGIC   -- Influenced YoY%
# MAGIC   CASE 
# MAGIC     WHEN Previous_Year_Influenced > 0 
# MAGIC     THEN (Current_Year_Influenced / Previous_Year_Influenced) - 1 
# MAGIC     ELSE NULL 
# MAGIC   END AS Influenced_YoY_Percentage,
# MAGIC   
# MAGIC   -- Influenced PE%
# MAGIC   CASE 
# MAGIC     WHEN Current_Year_Subscription_Total > 0 
# MAGIC     THEN Current_Year_Influenced / Current_Year_Subscription_Total 
# MAGIC     ELSE NULL 
# MAGIC   END AS Influenced_PE_Percentage,
# MAGIC   
# MAGIC   -- Influenced PE% YoY
# MAGIC   CASE 
# MAGIC     WHEN Current_Year_Subscription_Total > 0 AND Previous_Year_Subscription_Total > 0
# MAGIC     THEN (Current_Year_Influenced / Current_Year_Subscription_Total) - (Previous_Year_Influenced / Previous_Year_Subscription_Total)
# MAGIC     ELSE NULL 
# MAGIC   END AS Influenced_PE_Percentage_YoY,
# MAGIC   
# MAGIC   -- All-In Commits
# MAGIC   Influenced_Dollar + Sourced_Dollar AS All_In_Commits_added,
# MAGIC   
# MAGIC   -- All-In YoY%
# MAGIC   CASE 
# MAGIC     WHEN Previous_Year_All_In > 0 
# MAGIC     THEN (Current_Year_All_In / Previous_Year_All_In) - 1 
# MAGIC     ELSE NULL 
# MAGIC   END AS All_In_YoY_Percentage,
# MAGIC   
# MAGIC   -- All-In PE%
# MAGIC   CASE 
# MAGIC     WHEN Current_Year_Subscription_Total > 0 
# MAGIC     THEN (Current_Year_Sourced + Current_Year_Influenced) / Current_Year_Subscription_Total 
# MAGIC     ELSE NULL 
# MAGIC   END AS All_In_PE_Percentage,
# MAGIC   
# MAGIC   -- All-In PE% YoY
# MAGIC   CASE 
# MAGIC     WHEN Current_Year_Subscription_Total > 0 AND Previous_Year_Subscription_Total > 0
# MAGIC     THEN ((Current_Year_Sourced + Current_Year_Influenced) / Current_Year_Subscription_Total) - 
# MAGIC          (Previous_Year_All_In / Previous_Year_Subscription_Total)
# MAGIC     ELSE NULL 
# MAGIC   END AS All_In_PE_Percentage_YoY
# MAGIC FROM final_data

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.exec_dash_commits_gold AS
# MAGIC
# MAGIC WITH yearly_data AS (
# MAGIC   SELECT 
# MAGIC     FiscalYear,
# MAGIC     SUM(CASE WHEN Partner_Impact = 'Partner Influenced' THEN Subscription_Total ELSE 0 END) AS influenced_total,
# MAGIC     SUM(CASE WHEN Partner_Impact = 'Partner Sourced' THEN Subscription_Total ELSE 0 END) AS sourced_total,
# MAGIC     SUM(Subscription_Total) AS subscription_total,
# MAGIC     COUNT(DISTINCT CASE WHEN New_Logo = TRUE AND Commit_Type = 'New Business' AND Subscription_Total >= 12000 AND Partner_Impact = 'Partner Sourced' THEN Commit_ID END) AS partner_sourced_new_logo_count
# MAGIC   FROM main.it_aibi_silver.exec_dash_commits_silver
# MAGIC   GROUP BY FiscalYear
# MAGIC ),
# MAGIC fiscal_years AS (
# MAGIC   SELECT DISTINCT FiscalYear
# MAGIC   FROM main.it_aibi_silver.exec_dash_commits_silver
# MAGIC ),
# MAGIC year_pairs AS (
# MAGIC   SELECT 
# MAGIC     current_year.FiscalYear AS current_year,
# MAGIC     LAG(current_year.FiscalYear) OVER (ORDER BY current_year.FiscalYear) AS previous_year
# MAGIC   FROM fiscal_years current_year
# MAGIC )
# MAGIC SELECT 
# MAGIC   m.*,
# MAGIC   CASE WHEN m.Partner_Impact = 'Partner Influenced' THEN m.Subscription_Total ELSE 0 END AS Influenced_Dollars,
# MAGIC   CASE WHEN m.Partner_Impact = 'Partner Sourced' THEN m.Subscription_Total ELSE 0 END AS Sourced_Dollars,
# MAGIC   COALESCE((cy.influenced_total / NULLIF(py.influenced_total, 0)) - 1, 0) AS Influenced_YoY_Percentage,
# MAGIC   COALESCE(cy.influenced_total / NULLIF(cy.subscription_total, 0), 0) AS Influenced_PE_Percentage,
# MAGIC   COALESCE((cy.influenced_total / NULLIF(cy.subscription_total, 0)) - (py.influenced_total / NULLIF(py.subscription_total, 0)), 0) AS Influenced_PE_Percentage_YoY,
# MAGIC   COALESCE((cy.sourced_total / NULLIF(py.sourced_total, 0)) - 1, 0) AS Sourced_YoY_Percentage,
# MAGIC   COALESCE(cy.sourced_total / NULLIF(cy.subscription_total, 0), 0) AS Sourced_PE_Percentage,
# MAGIC   cy.influenced_total + cy.sourced_total AS Current_Year_All_In,
# MAGIC   py.influenced_total + py.sourced_total AS Previous_Year_All_In,
# MAGIC   COALESCE(((cy.influenced_total + cy.sourced_total) / NULLIF((py.influenced_total + py.sourced_total), 0)) - 1, 0) AS All_In_YoY_Percentage,
# MAGIC   COALESCE((cy.sourced_total / NULLIF(cy.subscription_total, 0)) + (cy.influenced_total / NULLIF(cy.subscription_total, 0)), 0) AS All_In_PE_Percentage,
# MAGIC   COALESCE(
# MAGIC     ((cy.sourced_total / NULLIF(cy.subscription_total, 0)) + (cy.influenced_total / NULLIF(cy.subscription_total, 0))) -
# MAGIC     ((py.influenced_total + py.sourced_total) / NULLIF(py.subscription_total, 0)),
# MAGIC     0
# MAGIC   ) AS All_In_PE_Percentage_YoY,
# MAGIC   CASE WHEN m.New_Logo = TRUE AND m.Commit_Type = 'New Business' AND m.Subscription_Total >= 12000 THEN m.Commit_ID ELSE NULL END AS New_Logo_Oppty,
# MAGIC   COALESCE((cy.partner_sourced_new_logo_count / NULLIF(py.partner_sourced_new_logo_count, 0)) - 1, 0) AS Sourced_New_Logo_YoY_Percentage
# MAGIC FROM main.it_aibi_silver.exec_dash_commits_silver m
# MAGIC JOIN year_pairs yp ON m.FiscalYear = yp.current_year
# MAGIC LEFT JOIN yearly_data cy ON m.FiscalYear = cy.FiscalYear
# MAGIC LEFT JOIN yearly_data py ON yp.previous_year = py.FiscalYear
