# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.exec_dash_csi_acc_gold
# MAGIC
# MAGIC WITH partner_acc AS (
# MAGIC     SELECT 
# MAGIC         acc_month,
# MAGIC         account_name,
# MAGIC         account__c,
# MAGIC         fiscal_qtr,
# MAGIC         fiscal_year,
# MAGIC         managed_coverage,
# MAGIC         partner,
# MAGIC         region,
# MAGIC         region2,
# MAGIC         region3,
# MAGIC         sfdc_account_id,
# MAGIC         threshold,
# MAGIC         CASE 
# MAGIC             WHEN partner != 'No Partner' AND partner IS NOT NULL 
# MAGIC             THEN account__c 
# MAGIC         END AS partner_acc
# MAGIC     FROM main.it_aibi_silver.exec_dash_csi_acc_silver
# MAGIC ),
# MAGIC
# MAGIC acc_pe_percentage AS (
# MAGIC     SELECT 
# MAGIC         acc_month,
# MAGIC         fiscal_qtr,
# MAGIC         fiscal_year,
# MAGIC         region,
# MAGIC         region2,
# MAGIC         region3,
# MAGIC         COUNT(DISTINCT partner_acc) * 1.0 / COUNT(DISTINCT sfdc_account_id) AS acc_pe_percent
# MAGIC     FROM partner_acc
# MAGIC     GROUP BY acc_month, fiscal_qtr, fiscal_year, region, region2, region3
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC     pa.*,
# MAGIC     ape.acc_pe_percent
# MAGIC FROM partner_acc pa
# MAGIC LEFT JOIN acc_pe_percentage ape
# MAGIC     ON pa.acc_month = ape.acc_month
# MAGIC     AND pa.fiscal_qtr = ape.fiscal_qtr
# MAGIC     AND pa.fiscal_year = ape.fiscal_year
# MAGIC     AND pa.region = ape.region
# MAGIC     AND pa.region2 = ape.region2
# MAGIC     AND pa.region3 = ape.region3
