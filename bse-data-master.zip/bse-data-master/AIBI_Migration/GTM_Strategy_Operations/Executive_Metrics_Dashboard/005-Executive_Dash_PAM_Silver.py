# Databricks notebook source
# MAGIC %md
# MAGIC #Final Updated Code

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import col

# Assuming you have a SparkSession named 'spark'

# Dim CTE
dim = spark.table("main.gtm_partner_data.csi_partner_dbu_live").select(
    F.coalesce(F.col("Account__c"), F.lit("Unknown")).alias("Account__c"),
    F.coalesce(F.col("Account_Name"), F.lit("Unknown")).alias("Account_Name"),
    F.coalesce(F.col("Account_Vertical"), F.lit("Unknown")).alias("Account_Vertical"),
    F.coalesce(F.col("Region"), F.lit("Unknown")).alias("Region"),
    F.coalesce(F.col("Region_2"), F.lit("Unknown")).alias("Region_2"),
    F.coalesce(F.col("Region_3"), F.lit("Unknown")).alias("Region_3"),
    F.coalesce(F.col("Region_4"), F.lit("Unknown")).alias("Region_4"),
    F.coalesce(F.col("DBX__c"), F.lit("Unknown")).alias("DBX__c"),
    F.coalesce(F.col("Partner_Tier"), F.lit("Unknown")).alias("Partner_Tier"),
    F.coalesce(F.col("Partner_Account"), F.lit("Unknown")).alias("Partner_Account"),
    F.coalesce(F.col("Parent_ID"), F.lit("Unknown")).alias("Parent_ID"),
    F.coalesce(F.col("Managed_Coverage"), F.lit("Unknown")).alias("Managed_Coverage"),
    F.coalesce(F.col("Partner_Manager"), F.lit("Unknown")).alias("Partner_Manager"),
    F.coalesce(F.col("Usage_Date__c"), F.lit("Unknown")).alias("Usage_Date__c")    
).distinct()

# Timeframe CTE
timeframe = spark.table("main.gtm_partner_data.csi_partner_dbu_live").select("FiscalYear", "fiscal_quarter").distinct()

# AllData CTE
all_data = dim.crossJoin(timeframe)

# TableData CTE
table_data = spark.table("main.gtm_partner_data.csi_partner_dbu_live").groupBy(
    F.coalesce(F.col("Account__c"), F.lit("Unknown")).alias("Account__c"),
    F.coalesce(F.col("Account_Name"), F.lit("Unknown")).alias("Account_Name"),
    F.coalesce(F.col("Account_Vertical"), F.lit("Unknown")).alias("Account_Vertical"),
    F.coalesce(F.col("Region"), F.lit("Unknown")).alias("Region"),
    F.coalesce(F.col("Region_2"), F.lit("Unknown")).alias("Region_2"),
    F.coalesce(F.col("Region_3"), F.lit("Unknown")).alias("Region_3"),
    F.coalesce(F.col("Region_4"), F.lit("Unknown")).alias("Region_4"),
    F.coalesce(F.col("DBX__c"), F.lit("Unknown")).alias("DBX__c"),
    F.coalesce(F.col("Partner_Tier"), F.lit("Unknown")).alias("Partner_Tier"),
    F.coalesce(F.col("Partner_Account"), F.lit("Unknown")).alias("Partner_Account"),
    F.coalesce(F.col("Parent_ID"), F.lit("Unknown")).alias("Parent_ID"),
    F.coalesce(F.col("Managed_Coverage"), F.lit("Unknown")).alias("Managed_Coverage"),
    F.coalesce(F.col("Partner_Manager"), F.lit("Unknown")).alias("Partner_Manager"),
    F.coalesce(F.col("Usage_Date__c"), F.lit("Unknown")).alias("Usage_Date__c"),
    "FiscalYear",
    "fiscal_quarter"
).agg(F.sum("Split_RevShare_Dollars").alias("Split_RevShare_Dollars"))

# Dollars CTE
dollars = all_data.alias("a").join(
    table_data.alias("b"),
    (F.col("a.Account__c") == F.col("b.Account__c")) &
    (F.col("a.Account_Name") == F.col("b.Account_Name")) &
    (F.col("a.Account_Vertical") == F.col("b.Account_Vertical")) &
    (F.col("a.Region") == F.col("b.Region")) &
    (F.col("a.Region_2") == F.col("b.Region_2")) &
    (F.col("a.Region_3") == F.col("b.Region_3")) &
    (F.col("a.Region_4") == F.col("b.Region_4")) &
    (F.col("a.DBX__c") == F.col("b.DBX__c")) &
    (F.col("a.Partner_Tier") == F.col("b.Partner_Tier")) &
    (F.col("a.Partner_Account") == F.col("b.Partner_Account")) &
    (F.col("a.Parent_ID") == F.col("b.Parent_ID")) &
    (F.col("a.Managed_Coverage") == F.col("b.Managed_Coverage")) &
    (F.col("a.Partner_Manager") == F.col("b.Partner_Manager")) &
    (F.col("a.Usage_Date__c") == F.col("b.Usage_Date__c")) &
    (F.col("a.FiscalYear") == F.col("b.FiscalYear")) &
    (F.col("a.fiscal_quarter") == F.col("b.fiscal_quarter")),
    "left"
).select(
    "a.*",
    F.when(F.col("b.Partner_Account") != "No Partner", F.col("b.Split_RevShare_Dollars")).otherwise(0).alias("Partner_DBU"),
    F.col("b.Split_RevShare_Dollars")
)

# Dates CTE
dates = spark.table("main.it_core_dim.dim_dates").select(
    F.col("fiscal_year"),
    F.concat(F.lit("Q"), F.col("fiscal_quarter")).alias("FQ"),
    F.col("fiscal_quarter_start_date")
).distinct()

# Targets CTE
targets = spark.table("gtm_partner_data.csi_partner_DBU_target_partner_portfolio").groupBy(
    F.col("`Fiscal Year`"),
    F.col("`Fiscal Quarter`"),
    F.col("`Portfolio`"),
    F.col("`Parent Account`")
).agg(F.sum(F.col("`$DBU_Target`")).alias("Target_DBUs"))

# FinalData CTE
final_data = dollars.alias("d").join(
    dates.alias("dt"),
    (F.col("d.FiscalYear") == F.col("dt.fiscal_year")) & (F.col("d.fiscal_quarter") == F.col("dt.FQ")),
    "left"
).join(
    targets.alias("t"),
    (F.col("d.Managed_Coverage") == F.col("t.`Portfolio`")) &
    (F.col("d.Partner_Account") == F.col("t.`Parent Account`")) &
    (F.col("d.fiscal_quarter") == F.col("t.`Fiscal Quarter`")) &
    (F.col("d.FiscalYear") == F.col("t.`Fiscal Year`")),
    "left"
).groupBy(
    [F.col(f"d.{c}") for c in dollars.columns] + [F.col("dt.fiscal_quarter_start_date")]
).agg(F.sum("t.Target_DBUs").alias("Target_DBUs"))

# Final_Data CTE
window_spec = Window.partitionBy(
    "Account__c", "Account_Name", "Account_Vertical", "Region", "Region_2", "Region_3", "Region_4",
    "DBX__c", "Partner_Tier", "Partner_Account", "Managed_Coverage", "Partner_Manager", "Usage_Date__c"
).orderBy("fiscal_quarter_start_date")

final_data = final_data.select(
    F.when(F.col("Partner_Account") != "No Partner", F.col("Account__c")).alias("Account__c"),
    "Account_Name", "Account_Vertical", "Region", "Region_2", "Region_3", "Region_4",
    "DBX__c", "Partner_Tier", "Partner_Account", "Parent_ID", "Managed_Coverage", "Partner_Manager", "Usage_Date__c",
    "FiscalYear", "fiscal_quarter", "fiscal_quarter_start_date",
    "Split_RevShare_Dollars", "Partner_DBU", "Target_DBUs",
    F.lag("Partner_DBU", 4, 0).over(window_spec).alias("PY_Partner_DBU")
)

# Final select
exec_dash_pam_silver = final_data.select("*")

# Function to rename duplicate columns
def rename_duplicate_columns(df):
    columns = df.columns
    column_counts = {}
    for column in columns:
        if column in column_counts:
            column_counts[column] += 1
            new_name = f"{column}_{column_counts[column]}"
            df = df.withColumnRenamed(column, new_name)
        else:
            column_counts[column] = 0
    return df

# Rename duplicate columns
exec_dash_pam_silver = rename_duplicate_columns(exec_dash_pam_silver)

# Print the new column names
print("Column names after renaming:", exec_dash_pam_silver.columns)




# COMMAND ----------

exec_dash_pam_silver.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.exec_dash_pam_silver")
