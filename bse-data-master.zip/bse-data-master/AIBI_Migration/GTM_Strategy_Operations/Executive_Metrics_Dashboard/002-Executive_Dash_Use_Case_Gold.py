# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.exec_dash_use_case_gold AS
# MAGIC
# MAGIC WITH partner_sourced_count AS (
# MAGIC   SELECT 
# MAGIC     FiscalYear,
# MAGIC     COUNT(*) AS total_partner_sourced
# MAGIC   FROM main.it_aibi_silver.exec_dash_use_case_silver
# MAGIC   WHERE PartnerRole__c = 'Partner Sourced'
# MAGIC   GROUP BY FiscalYear
# MAGIC ),
# MAGIC total_count AS (
# MAGIC   SELECT 
# MAGIC     FiscalYear,
# MAGIC     COUNT(*) AS total_records
# MAGIC   FROM main.it_aibi_silver.exec_dash_use_case_silver
# MAGIC   GROUP BY FiscalYear
# MAGIC ),
# MAGIC partner_implementation_count AS (
# MAGIC   SELECT 
# MAGIC     FiscalYear,
# MAGIC     COUNT(*) AS total_partner_implementation
# MAGIC   FROM main.it_aibi_silver.exec_dash_use_case_silver
# MAGIC   WHERE PartnerPSImplementation__c = 'Yes'
# MAGIC   GROUP BY FiscalYear
# MAGIC )
# MAGIC SELECT 
# MAGIC   s.Account_CaseSafe_ID,
# MAGIC   s.Account_Name,
# MAGIC   s.Account_Owner,
# MAGIC   s.Account_Vertical,
# MAGIC   s.ARR_Band,
# MAGIC   s.DBX__c,
# MAGIC   s.FiscalQuarter,
# MAGIC   s.FiscalYear,
# MAGIC   s.implementation_strategy,
# MAGIC   s.migration,
# MAGIC   s.PAM,
# MAGIC   s.Partner_Name,
# MAGIC   s.Partner_Sales_Manager,
# MAGIC   s.partner_tech_lead,
# MAGIC   s.Partner_Tier,
# MAGIC   s.PartnerImpact__c,
# MAGIC   s.PartnerPSImplementation__c,
# MAGIC   s.PartnerRole__c,
# MAGIC   s.Project_Lead,
# MAGIC   s.ps_project,
# MAGIC   s.redfish,
# MAGIC   s.Region,
# MAGIC   s.Region_2,
# MAGIC   s.Region_3,
# MAGIC   s.Region_4,
# MAGIC   s.stage,
# MAGIC   s.target_live_date,
# MAGIC   s.Use_Case_Id,
# MAGIC   s.Use_Case_Name,
# MAGIC   s.Use_Case_Type__c,
# MAGIC   s.acct_partner_split_percent,
# MAGIC   s.monthly_dbu_est,
# MAGIC   s.Sales_Split,
# MAGIC   s.Total_Split,
# MAGIC   s.sales_count,
# MAGIC   s.Implementation_split,
# MAGIC   COALESCE(psc.total_partner_sourced, 0) AS total_partner_sourced,
# MAGIC   COALESCE(tc.total_records, 0) AS total_records,
# MAGIC   CASE 
# MAGIC     WHEN COALESCE(tc.total_records, 0) > 0 THEN
# MAGIC       ROUND(CAST(COALESCE(psc.total_partner_sourced, 0) AS DECIMAL(10,4)) / CAST(tc.total_records AS DECIMAL(10,4)) * 100, 2)
# MAGIC     ELSE 0 
# MAGIC   END AS Partner_Sourced_PE,
# MAGIC   LAG(COALESCE(psc.total_partner_sourced, 0)) OVER (ORDER BY s.FiscalYear) AS prev_year_partner_sourced,
# MAGIC   CASE
# MAGIC     WHEN LAG(COALESCE(psc.total_partner_sourced, 0)) OVER (ORDER BY s.FiscalYear) > 0 THEN
# MAGIC       ROUND((CAST(COALESCE(psc.total_partner_sourced, 0) AS DECIMAL(10,4)) / 
# MAGIC              CAST(LAG(COALESCE(psc.total_partner_sourced, 0)) OVER (ORDER BY s.FiscalYear) AS DECIMAL(10,4))) - 1, 4) * 100
# MAGIC     ELSE NULL
# MAGIC   END AS Partner_Sourced_YoY,
# MAGIC   COALESCE(pic.total_partner_implementation, 0) AS total_partner_implementation,
# MAGIC   CASE 
# MAGIC     WHEN COALESCE(tc.total_records, 0) > 0 THEN
# MAGIC       ROUND(CAST(COALESCE(pic.total_partner_implementation, 0) AS DECIMAL(10,4)) / CAST(tc.total_records AS DECIMAL(10,4)) * 100, 2)
# MAGIC     ELSE 0 
# MAGIC   END AS Partner_Implementation_PE,
# MAGIC   LAG(COALESCE(pic.total_partner_implementation, 0)) OVER (ORDER BY s.FiscalYear) AS prev_year_partner_implementation,
# MAGIC   CASE
# MAGIC     WHEN LAG(COALESCE(pic.total_partner_implementation, 0)) OVER (ORDER BY s.FiscalYear) > 0 THEN
# MAGIC       ROUND((CAST(COALESCE(pic.total_partner_implementation, 0) AS DECIMAL(10,4)) / 
# MAGIC              CAST(LAG(COALESCE(pic.total_partner_implementation, 0)) OVER (ORDER BY s.FiscalYear) AS DECIMAL(10,4))) - 1, 4) * 100
# MAGIC     ELSE NULL
# MAGIC   END AS Partner_Implementation_YoY
# MAGIC FROM 
# MAGIC   main.it_aibi_silver.exec_dash_use_case_silver s
# MAGIC   LEFT JOIN partner_sourced_count psc ON s.FiscalYear = psc.FiscalYear
# MAGIC   LEFT JOIN total_count tc ON s.FiscalYear = tc.FiscalYear
# MAGIC   LEFT JOIN partner_implementation_count pic ON s.FiscalYear = pic.FiscalYear
# MAGIC ORDER BY 
# MAGIC   s.FiscalYear, 
# MAGIC   s.PartnerRole__c
# MAGIC
