# Databricks notebook source
# MAGIC %md
# MAGIC ##there are two tbales one is commit silver and commit silver target so created both
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as F

# Assuming you have already created a SparkSession called 'spark'

# Read the tables into DataFrames
commits_df = spark.table("main.gtm_partner_data.csi_partner_commits")
targets_df = spark.table("main.gtm_partner_data.csi_partner_dbu_target_bu")

# Perform the left join and select the required columns
exec_dash_commit_target_silver = commits_df.alias("c").join(
    targets_df.alias("t"),
    (F.col("c.Region") == F.col("t.Region")) &
    (F.col("c.Region_2") == F.col("t.Region_2")) &
    (F.col("c.Region_3") == F.col("t.Region_3")) &
    (F.col("c.fiscal_quarter") == F.col("t.`Fiscal Quarter`")) &
    (F.col("c.FiscalYear") == F.col("t.`Fiscal Year`")),
    "left"
).select(
    F.col("c.Account_Vertical"),
    F.col("c.FiscalYear"),
    F.col("c.Commit_ID"),
    F.col("c.commit_type"),
    F.col("c.dbx__c").alias("dbx"),
    F.col("c.fiscal_quarter"),
    F.col("c.Manager_Forecast"),
    F.col("c.Migration_Commit"),
    F.col("c.Nafr"),
    F.col("c.New_Logo"),
    F.col("c.Opportunity_Name"),
    F.col("c.Owner_Role"),
    F.col("c.PAM_Name"),
    F.col("c.Parent_Account"),
    F.col("c.Partner_Impact"),
    F.col("c.Partner_Tier"),
    F.col("c.Platform"),
    F.col("c.primary"),
    F.col("c.Region"),
    F.col("c.Region_2"),
    F.col("c.Region_3"),
    F.col("c.Region_4"),
    F.col("c.Stage"),
    F.col("c.Attributable_Subscription"),
    F.col("c.Subscription_Total"),
    F.col("t.`Fiscal Quarter`").alias("fiscal_quarter_target"),
    F.col("t.`Fiscal Year`").alias("fiscal_year_target"),
    F.col("t.Region").alias("region_target"),
    F.col("t.Region_2").alias("region2_target"),
    F.col("t.Region_3").alias("region3_target"),
    F.col("t.`$DBU_Target`").alias("dbu_target")
)

# To execute the query and see the results, you can use:
#exec_dash_commit_target_silver.display()



# COMMAND ----------

exec_dash_commit_target_silver.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.exec_dash_commit_target_silver")



# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Here is another table 

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql import functions as F


# Read the input DataFrame
csi_partner_commits = spark.table("gtm_partner_data.csi_partner_commits")

# Create Aggregated_DBU DataFrame
Aggregated_DBU = csi_partner_commits.filter(F.col("FiscalYear") == 2025) \
    .groupBy("Account_Vertical", "Commit_id", "Commit_type", "DBX__c", "fiscal_quarter", 
             "FiscalYear", "manager_forecast", "migration_commit", "new_logo", 
             "Opportunity_Name", "Owner_Role", "PAM_name", "Parent_Account", 
             "Partner_Impact", "Partner_tier", "Region", "Region_2", "Region_3", 
             "Region_4", "Stage") \
    .agg(F.sum(F.when(F.col("Partner_Impact") == "Partner Sourced", F.col("Attributable_Subscription")).otherwise(0)).alias("Sourced_DBUs"),
         F.sum(F.when(F.col("Partner_Impact") == "Partner Influenced", F.col("Attributable_Subscription")).otherwise(0)).alias("Influenced_DBUs"),
         F.sum("Subscription_Total").alias("Subscription_Total"))

# Perform the final selection and aggregation
exec_dash_commits_silver = Aggregated_DBU.select(
    F.coalesce(F.col("Sourced_DBUs"), F.lit(0)).alias("Sourced_DBUs"),
    F.coalesce(F.col("Influenced_DBUs"), F.lit(0)).alias("Influenced_DBUs"),
    F.coalesce(F.col("Subscription_Total"), F.lit(0)).alias("Subscription_Total"),
    "Account_Vertical", "Commit_id", "Commit_type", "DBX__c", "fiscal_quarter",
    "FiscalYear", "manager_forecast", "migration_commit", "new_logo",
    "Opportunity_Name", "Owner_Role", "PAM_name", "Parent_Account",
    "Partner_Impact", "Partner_tier", "Region", "Region_2", "Region_3",
    "Region_4", "Stage"
)


#exec_dash_commits_silver.display()

# COMMAND ----------

exec_dash_commits_silver.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.exec_dash_commits_silver")
