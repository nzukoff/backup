# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.exec_dash_csi_acc_silver as
# MAGIC
# MAGIC select
# MAGIC month_end_date as acc_month,
# MAGIC sfdc_account_name as account_name,
# MAGIC account__c,
# MAGIC fiscal_qtr,
# MAGIC fiscal_year,
# MAGIC managed_coverage,
# MAGIC bu as region,
# MAGIC partner_account as partner,
# MAGIC sfdc_region_l1,
# MAGIC sfdc_region_l1 as region2,
# MAGIC sfdc_region_l2 as region3,
# MAGIC sfdc_account_id,
# MAGIC threshold,
# MAGIC DBX__c as DBX
# MAGIC from main.gtm_partner_data.csi_partner_activated_customer
# MAGIC
