# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW main.it_aibi_gold.exec_dash_close_the_gap_gold AS
# MAGIC
# MAGIC WITH partner_dbu AS (
# MAGIC     SELECT
# MAGIC         Account__c,
# MAGIC         SUM(CASE 
# MAGIC             WHEN Parent_Account = 'No Partner' THEN 0
# MAGIC             ELSE Split_RevShare_Dollars
# MAGIC         END) AS Partner_DBU
# MAGIC     FROM main.it_aibi_silver.exec_dash_close_the_gap_silver
# MAGIC     GROUP BY Account__c
# MAGIC ),
# MAGIC
# MAGIC pe_account_partner AS (
# MAGIC     SELECT
# MAGIC         Account__c,
# MAGIC         SUM(Partner_DBU) / NULLIF(SUM(Split_RevShare_Dollars), 0) AS PE_Account_Partner
# MAGIC     FROM partner_dbu
# MAGIC     JOIN main.it_aibi_silver.exec_dash_close_the_gap_silver USING (Account__c)
# MAGIC     GROUP BY Account__c
# MAGIC ),
# MAGIC
# MAGIC partner_implementation_use_case AS (
# MAGIC     SELECT
# MAGIC         Account__c,
# MAGIC         SUM(CASE 
# MAGIC             WHEN PartnerRole__c = 'Implementation (SI)' THEN monthly_dbu_est
# MAGIC             ELSE 0
# MAGIC         END) AS Partner_Implementation_Use_Case
# MAGIC     FROM main.it_aibi_silver.exec_dash_close_the_gap_silver
# MAGIC     GROUP BY Account__c
# MAGIC ),
# MAGIC
# MAGIC partner_implemented_pe AS (
# MAGIC     SELECT
# MAGIC         a.Account__c,
# MAGIC         p.Partner_Implementation_Use_Case / NULLIF(SUM(a.monthly_dbu_est), 0) AS Partner_Implemented_PE
# MAGIC     FROM main.it_aibi_silver.exec_dash_close_the_gap_silver a
# MAGIC     JOIN partner_implementation_use_case p USING (Account__c)
# MAGIC     GROUP BY a.Account__c, p.Partner_Implementation_Use_Case
# MAGIC ),
# MAGIC
# MAGIC gap_to_acct_partner_pe AS (
# MAGIC     SELECT
# MAGIC         a.Account__c,
# MAGIC         pe.PE_Account_Partner - pi.Partner_Implemented_PE AS Gap_to_Acct_Partner_PE
# MAGIC     FROM main.it_aibi_silver.exec_dash_close_the_gap_silver a
# MAGIC     JOIN pe_account_partner pe USING (Account__c)
# MAGIC     JOIN partner_implemented_pe pi USING (Account__c)
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     m.*,
# MAGIC     p.Partner_DBU,
# MAGIC     pe.PE_Account_Partner,
# MAGIC     pi.Partner_Implementation_Use_Case AS Partner_Implementation_Use_Case_Alias,
# MAGIC     pip.Partner_Implemented_PE,
# MAGIC     g.Gap_to_Acct_Partner_PE,
# MAGIC     RANK() OVER (ORDER BY g.Gap_to_Acct_Partner_PE ASC) AS Rank
# MAGIC FROM main.it_aibi_silver.exec_dash_close_the_gap_silver m
# MAGIC LEFT JOIN partner_dbu p USING (Account__c)
# MAGIC LEFT JOIN pe_account_partner pe USING (Account__c)
# MAGIC LEFT JOIN partner_implementation_use_case pi USING (Account__c)
# MAGIC LEFT JOIN partner_implemented_pe pip USING (Account__c)
# MAGIC LEFT JOIN gap_to_acct_partner_pe g USING (Account__c)
