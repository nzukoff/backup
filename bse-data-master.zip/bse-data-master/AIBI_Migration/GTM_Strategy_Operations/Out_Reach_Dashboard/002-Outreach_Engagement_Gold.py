# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.outreach_engagement_gold as 
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     brd_type,
# MAGIC     custom_order,
# MAGIC     enabled_at,
# MAGIC     engagement_date,
# MAGIC     event_type,
# MAGIC     helper_col,
# MAGIC     industry,
# MAGIC     marketing_channel,
# MAGIC     outreach_activity_id,
# MAGIC     outreach_teams,
# MAGIC     prospects_added_at,
# MAGIC     prospects_contacted_at,
# MAGIC     prospects_contacted,
# MAGIC     prospects_responded_at,
# MAGIC     region,
# MAGIC     relationship_opportunity_id,
# MAGIC     relationship_task_id,
# MAGIC     rep_name,
# MAGIC     role_owner_name,
# MAGIC     role_owner_SFDC_ID,
# MAGIC     sequence_id,
# MAGIC     sequence_name,
# MAGIC     sequence_step_id,
# MAGIC     step_category,
# MAGIC     step_name,
# MAGIC     sub_region,
# MAGIC     tags,
# MAGIC     task_state,
# MAGIC     task_type,
# MAGIC     template_id,
# MAGIC     template_name,
# MAGIC     depth,
# MAGIC     prospects_added,
# MAGIC     prospects_responded,
# MAGIC     step_time_diff,
# MAGIC     template_deliver_count,
# MAGIC     step_name || sequence_name AS calculation2,
# MAGIC     CASE
# MAGIC       WHEN role_owner_name LIKE '%BDR%' THEN 'BDR'
# MAGIC       WHEN role_owner_name LIKE '%GDR%' THEN 'GDR'
# MAGIC       WHEN role_owner_name LIKE '%SDR%' THEN 'SDR'
# MAGIC       WHEN role_owner_name LIKE '%AE%' THEN 'AE'
# MAGIC       ELSE 'Other Role'
# MAGIC     END AS role_grouping,
# MAGIC     SUM(CASE WHEN step_category = 'Social' THEN 1 ELSE 0 END) AS num_of_social,
# MAGIC     COUNT(DISTINCT sequence_step_id) AS count_distinct_sq_step_id,
# MAGIC     MIN(template_deliver_count) OVER (PARTITION BY template_name, template_id) AS deliver_count,
# MAGIC     SUM(CASE WHEN event_type = 'Email Deliver' THEN 1 ELSE 0 END) AS email_delivered_gb_logic,
# MAGIC     SUM(CASE WHEN event_type = 'Email Reply' THEN 1 ELSE 0 END) AS reply_email_gb_logic,
# MAGIC     SUM(CASE WHEN event_type = 'Email Unsubscribe' THEN 1 ELSE 0 END) AS unsubscribed_gb_logic,
# MAGIC     SUM(CASE WHEN event_type = 'Email Open' THEN 1 ELSE 0 END) AS open_email_gb_logic,
# MAGIC     SUM(CASE WHEN event_type = 'Meeting Scheduled' THEN 1 ELSE 0 END) AS meeting_scheduled_email_gb_logic,
# MAGIC     SUM(CASE WHEN event_type = 'Call Complete' THEN 1 ELSE 0 END) AS call_completed_email_gb_logic,
# MAGIC     SUM(CASE WHEN event_type = 'Call Not Complete' THEN 1 ELSE 0 END) AS call_not_completed_email_gb_logic,
# MAGIC     SUM(CASE WHEN event_type = 'Call Complete' THEN 1 ELSE 0 END) AS call_answer_rate_num,
# MAGIC     SUM(CASE WHEN event_type LIKE '%Call%' THEN 1 ELSE 0 END) AS call_answer_rate_denom
# MAGIC   FROM main.it_aibi_silver.outreach_engagement_silver
# MAGIC   GROUP BY 
# MAGIC     brd_type, custom_order, enabled_at, engagement_date, event_type, helper_col, industry, marketing_channel,
# MAGIC     outreach_activity_id, outreach_teams, prospects_added_at, prospects_contacted_at, prospects_contacted,
# MAGIC     prospects_responded_at, region, relationship_opportunity_id, relationship_task_id, rep_name, role_owner_name,
# MAGIC     role_owner_SFDC_ID, sequence_id, sequence_name, sequence_step_id, step_category, step_name, sub_region, tags,
# MAGIC     task_state, task_type, template_id, template_name, depth, prospects_added, prospects_responded, step_time_diff,
# MAGIC     template_deliver_count
# MAGIC )
# MAGIC SELECT 
# MAGIC   *,
# MAGIC   CAST(call_answer_rate_num AS FLOAT) / NULLIF(call_answer_rate_denom, 0) AS call_answer_rate,
# MAGIC   CASE
# MAGIC     WHEN CAST(call_answer_rate_num AS FLOAT) / NULLIF(call_answer_rate_denom, 0) >= 0.5 THEN 'Green'
# MAGIC     WHEN CAST(call_answer_rate_num AS FLOAT) / NULLIF(call_answer_rate_denom, 0) BETWEEN 0.25 AND 0.49 THEN 'Orange'
# MAGIC     ELSE 'Red'
# MAGIC   END AS calculation1,
# MAGIC   CAST(reply_email_gb_logic AS FLOAT) / NULLIF(email_delivered_gb_logic, 0) AS email_reply_rate,
# MAGIC   CAST(unsubscribed_gb_logic AS FLOAT) / NULLIF(email_delivered_gb_logic, 0) AS email_unsub_rate
# MAGIC FROM base_data

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------


