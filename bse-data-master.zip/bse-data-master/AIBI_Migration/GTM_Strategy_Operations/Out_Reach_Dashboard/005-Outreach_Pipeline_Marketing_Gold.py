# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.outreach_pipeline_marketing_gold AS 
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     is_closed,
# MAGIC     opportunity_id,
# MAGIC     opportunity_name,
# MAGIC     sequence_id,
# MAGIC     sequence_name,
# MAGIC     touched_at,
# MAGIC     total_amount,
# MAGIC     brd_type,
# MAGIC     engagement_date,
# MAGIC     event_type,
# MAGIC     first_touch_source_date,
# MAGIC     industry,
# MAGIC     last_campaign_name,
# MAGIC     mql,
# MAGIC     outreach_status,
# MAGIC     region,
# MAGIC     relationship_prospect_id,
# MAGIC     role_name,
# MAGIC     marketing_sequence_id,
# MAGIC     marketing_sequence_name,
# MAGIC     sub_region,
# MAGIC     title,
# MAGIC     program_start_date,
# MAGIC     CASE 
# MAGIC       WHEN DATEDIFF(day, program_start_date, engagement_date) < 0 THEN 'Sequence Created Before Campaign'
# MAGIC       WHEN DATEDIFF(day, program_start_date, engagement_date) > 0 THEN 'Sequence Created After Campaign'
# MAGIC     END AS date_flag,
# MAGIC     CAST(touched_at AS DATE) AS touched_at_date
# MAGIC   FROM main.it_aibi_silver.outreach_pipeline_marketing_silver
# MAGIC ),
# MAGIC distinct_counts AS (
# MAGIC   SELECT
# MAGIC     COUNT(DISTINCT mql) AS distinct_mql_count,
# MAGIC     COUNT(DISTINCT CASE WHEN event_type = 'Call Complete' AND outreach_status = 'touched inside Sequence' THEN relationship_prospect_id END) AS call_complete_inside,
# MAGIC     COUNT(DISTINCT CASE WHEN event_type = 'Call Complete' AND outreach_status = 'touched Outside Sequence' THEN relationship_prospect_id END) AS call_complete_outside,
# MAGIC     COUNT(DISTINCT CASE WHEN event_type = 'Email Deliver' AND outreach_status = 'touched inside Sequence' THEN relationship_prospect_id END) AS email_deliver_inside,
# MAGIC     COUNT(DISTINCT CASE WHEN event_type = 'Email Deliver' AND outreach_status = 'touched Outside Sequence' THEN relationship_prospect_id END) AS email_deliver_outside,
# MAGIC     COUNT(DISTINCT CASE WHEN event_type = 'Email Open' AND outreach_status = 'touched inside Sequence' THEN relationship_prospect_id END) AS email_open_inside,
# MAGIC     COUNT(DISTINCT CASE WHEN event_type = 'Email Open' AND outreach_status = 'touched Outside Sequence' THEN relationship_prospect_id END) AS email_open_outside,
# MAGIC     COUNT(DISTINCT CASE WHEN event_type = 'Email Reply' AND outreach_status = 'touched inside Sequence' THEN relationship_prospect_id END) AS email_reply_inside,
# MAGIC     COUNT(DISTINCT CASE WHEN event_type = 'Email Reply' AND outreach_status = 'touched Outside Sequence' THEN relationship_prospect_id END) AS email_reply_outside,
# MAGIC     COUNT(DISTINCT CASE WHEN event_type = 'Meeting Scheduled' AND outreach_status = 'touched inside Sequence' THEN relationship_prospect_id END) AS meeting_scheduled_inside,
# MAGIC     COUNT(DISTINCT CASE WHEN event_type = 'Meeting Scheduled' AND outreach_status = 'touched Outside Sequence' THEN relationship_prospect_id END) AS meeting_scheduled_outside
# MAGIC   FROM base_data
# MAGIC ),
# MAGIC aggregated_data AS (
# MAGIC   SELECT
# MAGIC     base_data.*,
# MAGIC     (SELECT COUNT(*) FROM base_data) AS total_count,
# MAGIC     distinct_counts.*
# MAGIC   FROM base_data
# MAGIC   CROSS JOIN distinct_counts
# MAGIC )
# MAGIC SELECT
# MAGIC   *,
# MAGIC   total_count * 1.0 / NULLIF(distinct_mql_count, 0) AS avg_mql_touches,
# MAGIC   call_complete_inside AS call_complete_rate_not_null,
# MAGIC   call_complete_outside AS call_complete_rate_null,
# MAGIC   CASE 
# MAGIC     WHEN call_complete_inside = 0 THEN NULL 
# MAGIC     ELSE call_complete_outside * 1.0 / call_complete_inside 
# MAGIC   END AS call_complete_rate_within_vs_outside,
# MAGIC   email_deliver_inside AS email_delivered_rate_not_null,
# MAGIC   email_deliver_outside AS email_delivered_rate_null,
# MAGIC   CASE 
# MAGIC     WHEN email_deliver_inside = 0 THEN NULL 
# MAGIC     ELSE email_deliver_outside * 1.0 / email_deliver_inside 
# MAGIC   END AS email_delivered_rate_within_vs_outside,
# MAGIC   email_open_inside AS email_open_rate_not_null,
# MAGIC   email_open_outside AS email_open_rate_null,
# MAGIC   CASE 
# MAGIC     WHEN email_open_inside = 0 THEN NULL 
# MAGIC     ELSE email_open_outside * 1.0 / email_open_inside 
# MAGIC   END AS email_open_rate_within_vs_outside,
# MAGIC   email_reply_inside AS email_reply_rate_not_null,
# MAGIC   email_reply_outside AS email_reply_rate_null,
# MAGIC   CASE 
# MAGIC     WHEN email_reply_inside = 0 THEN NULL 
# MAGIC     ELSE email_reply_outside * 1.0 / email_reply_inside 
# MAGIC   END AS email_reply_rate_within_vs_outside,
# MAGIC   meeting_scheduled_inside AS meeting_set_rate_not_null,
# MAGIC   meeting_scheduled_outside AS meeting_set_rate_null,
# MAGIC   CASE 
# MAGIC     WHEN meeting_scheduled_inside = 0 THEN NULL 
# MAGIC     ELSE meeting_scheduled_outside * 1.0 / meeting_scheduled_inside 
# MAGIC   END AS meeting_set_rate_within_vs_outside
# MAGIC FROM aggregated_data;

# COMMAND ----------



# COMMAND ----------


