# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.outreach_marketing_silver as
# MAGIC
# MAGIC select 
# MAGIC a.brd_type,
# MAGIC a.engagement_date,
# MAGIC a.event_type,
# MAGIC a.first_touch_source_date,
# MAGIC a.industry,
# MAGIC a.last_campaign_name,
# MAGIC a.mql,
# MAGIC a.outreach_status,
# MAGIC a.region,
# MAGIC a.relationship_prospect_id,
# MAGIC a.role_name,
# MAGIC a.sequence_id,
# MAGIC a.sequence_name,
# MAGIC a.sub_region,
# MAGIC a.title,
# MAGIC b.program_start_date 
# MAGIC from main.marketing_lakehouse.gold_outreach_mql a 
# MAGIC left join  main.marketing_lakehouse.gold_marketing_plan b on 
# MAGIC a.last_campaign_id = b.existing_campaign_id
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.outreach_pipeline_silver as
# MAGIC
# MAGIC select 
# MAGIC is_closed,
# MAGIC opportunity_id,
# MAGIC opportunity_name,
# MAGIC sequence_id,
# MAGIC sequence_name,
# MAGIC touched_at,
# MAGIC amount
# MAGIC from main.marketing_lakehouse.gold_outreach_pipeline
# MAGIC
# MAGIC
# MAGIC
