# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.outreach_engagement_silver as
# MAGIC
# MAGIC select
# MAGIC brd_type,
# MAGIC custom_order,
# MAGIC enabled_at,
# MAGIC engagement_date,
# MAGIC event_type,
# MAGIC helper_col,
# MAGIC industry,
# MAGIC marketing_channel,
# MAGIC outreach_activity_id,
# MAGIC outreach_teams,
# MAGIC prospects_added_at,
# MAGIC prospects_contacted_at,
# MAGIC prospects_contacted,
# MAGIC prospects_responded_at,
# MAGIC region,
# MAGIC relationship_opportunity_id,
# MAGIC relationship_task_id,
# MAGIC rep_name,
# MAGIC role_owner_name,
# MAGIC role_owner_SFDC_ID,
# MAGIC sequence_id,
# MAGIC sequence_name,
# MAGIC sequence_step_id,
# MAGIC step_category,
# MAGIC step_name,
# MAGIC sub_region,
# MAGIC tags,
# MAGIC task_state,
# MAGIC task_type,
# MAGIC template_id,
# MAGIC template_name,
# MAGIC depth,
# MAGIC prospects_added,
# MAGIC prospects_responded,
# MAGIC step_time_diff,
# MAGIC template_deliver_count
# MAGIC from main.marketing_lakehouse.gold_outreach_engagement
# MAGIC
# MAGIC
# MAGIC
