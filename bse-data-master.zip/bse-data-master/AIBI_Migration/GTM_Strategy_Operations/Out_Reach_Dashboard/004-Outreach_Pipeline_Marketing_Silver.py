# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.outreach_marketing_silver
# MAGIC
# MAGIC select 
# MAGIC a.brd_type,
# MAGIC a.engagement_date,
# MAGIC a.event_type,
# MAGIC a.first_touch_source_date,
# MAGIC a.industry,
# MAGIC a.last_campaign_name,
# MAGIC a.mql,
# MAGIC a.outreach_status,
# MAGIC a.region,
# MAGIC a.relationship_prospect_id,
# MAGIC a.role_name,
# MAGIC a.sequence_id,
# MAGIC a.sequence_name,
# MAGIC a.sub_region,
# MAGIC a.title,
# MAGIC b.program_start_date 
# MAGIC from main.marketing_lakehouse.gold_outreach_mql a 
# MAGIC full join main.marketing_lakehouse.gold_marketing_plan b on 
# MAGIC a.last_campaign_id = b.existing_campaign_id

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.outreach_pipeline_silver
# MAGIC
# MAGIC select 
# MAGIC is_closed,
# MAGIC opportunity_id,
# MAGIC opportunity_name,
# MAGIC sequence_id,
# MAGIC sequence_name,
# MAGIC touched_at,
# MAGIC amount
# MAGIC from main.marketing_lakehouse.gold_outreach_pipeline

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.outreach_pipeline_marketing_silver AS
# MAGIC
# MAGIC WITH marketing AS (
# MAGIC   SELECT 
# MAGIC     brd_type,
# MAGIC     engagement_date,
# MAGIC     event_type,
# MAGIC     first_touch_source_date,
# MAGIC     industry,
# MAGIC     last_campaign_name,
# MAGIC     mql,
# MAGIC     outreach_status,
# MAGIC     region,
# MAGIC     relationship_prospect_id,
# MAGIC     role_name,
# MAGIC     sequence_id AS marketing_sequence_id,
# MAGIC     sequence_name AS marketing_sequence_name,
# MAGIC     sub_region,
# MAGIC     title,
# MAGIC     program_start_date
# MAGIC   FROM main.it_aibi_silver.outreach_marketing_silver
# MAGIC ),
# MAGIC
# MAGIC pipeline AS (
# MAGIC   SELECT 
# MAGIC     is_closed,
# MAGIC     opportunity_id,
# MAGIC     opportunity_name,
# MAGIC     sequence_id,
# MAGIC     sequence_name,
# MAGIC     touched_at,
# MAGIC     SUM(amount) AS total_amount
# MAGIC   FROM main.it_aibi_silver.outreach_pipeline_silver
# MAGIC   GROUP BY 
# MAGIC     is_closed,
# MAGIC     opportunity_id,
# MAGIC     opportunity_name,
# MAGIC     sequence_id,
# MAGIC     sequence_name,
# MAGIC     touched_at
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   p.*,
# MAGIC   m.brd_type,
# MAGIC   m.engagement_date,
# MAGIC   m.event_type,
# MAGIC   m.first_touch_source_date,
# MAGIC   m.industry,
# MAGIC   m.last_campaign_name,
# MAGIC   m.mql,
# MAGIC   m.outreach_status,
# MAGIC   m.region,
# MAGIC   m.relationship_prospect_id,
# MAGIC   m.role_name,
# MAGIC   m.marketing_sequence_id,
# MAGIC   m.marketing_sequence_name,
# MAGIC   m.sub_region,
# MAGIC   m.title,
# MAGIC   m.program_start_date
# MAGIC FROM marketing m
# MAGIC FULL JOIN pipeline p
# MAGIC ON p.sequence_id = m.marketing_sequence_id
