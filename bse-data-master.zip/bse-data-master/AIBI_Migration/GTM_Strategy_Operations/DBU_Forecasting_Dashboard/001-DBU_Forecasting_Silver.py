# Databricks notebook source
from pyspark.sql import Window
from pyspark.sql.functions import sum, when, col, max, concat, ceil, month, year, date_add, coalesce, lit

# Read the necessary tables
csi_partner_sales_account_forecast = spark.table("gtm_partner_data.csi_partner_sales_account_forecast")
csi_forecast_use_case_details = spark.table("gtm_partner_data.csi_forecast_use_case_details")
csi_partner_dbu_target_bu = spark.table("gtm_partner_data.csi_partner_dbu_target_bu")

# Define the window specification
window_spec = Window.partitionBy('account_id').orderBy(col('snapshot_date').desc())

# Create account_forecast DataFrame
account_forecast = csi_partner_sales_account_forecast.groupBy(
    "account_id", "Account_Name", "fiscal_quarter", "fiscal_year", "account_in_consumption_plan",
    "Managed_Coverage", "Parent_ID", "Partner_Name", "Partner_Sales_Manager",
    "Region", "Region_2", "Region_3", "Region_4", "snapshot_date"
).agg(
    sum(when(col("Parent_ID") != "No Partner", col("partner_current_adjustment")).otherwise(0)).alias("Partner_adjustment"),
    sum(when(col("Parent_ID") != "No Partner", col("partner_current_ae_forecast")).otherwise(0)).alias("Partner_ae_forecast"),
    sum("partner_current_adjustment").alias("partner_current_adjustment"),
    sum("partner_current_ds_forecast").alias("partner_current_ds_forecast"),
    sum("partner_current_open_in_plan_usecases").alias("partner_current_open_in_plan_usecases"),
    sum("partner_current_organic_growth_baseline").alias("partner_current_organic_growth_baseline"),
    sum(when(col("Parent_ID") != "No Partner", col("partner_current_ds_forecast")).otherwise(0)).alias("Partner_ds_forecast"),
    sum(when(col("Parent_ID") != "No Partner", col("partner_current_organic_growth_baseline")).otherwise(0)).alias("Partner_og_growth_baseline"),
    sum(when(col("Parent_ID") != "No Partner", col("partner_current_open_in_plan_usecases")).otherwise(0)).alias("Partner_open_in_plan_use_cases")
).withColumn(
    "forecast_snap_date",
    when(col("snapshot_date") == max("snapshot_date").over(Window.partitionBy(lit(1))), "Latest")
    .otherwise(col("snapshot_date").cast("string"))
).withColumnRenamed("account_in_consumption_plan", "in_plan")

# Create details DataFrame
details = csi_forecast_use_case_details.groupBy(
    "account_name", "is_use_case_in_plan", "partner_name", "projection_month_end_date",
    "region", "region_2", "region_3", "snapshot_date", "use_case_name", "usecase_id"
).agg(
    sum("attributed_projected_monthly_dollars_w_month_pro_rata").alias("attributed_projected_monthly_dollars_w_month_pro_rata")
).withColumn(
    "details_snap_date",
    when(col("snapshot_date") == max("snapshot_date").over(Window.partitionBy(lit(1))), "Latest")
    .otherwise(col("snapshot_date").cast("string"))
).withColumn(
    "details_fiscal_quarter",
    when(month("projection_month_end_date") >= 2,
         concat(lit("Q"), ceil((month(date_add("projection_month_end_date", -1)) - 1) / 3).cast("string")))
    .otherwise(concat(lit("Q"), ceil((month(date_add("projection_month_end_date", 11)) - 1) / 3).cast("string")))
).withColumn(
    "details_fiscal_year",
    when(month("projection_month_end_date") >= 2,
         year(date_add("projection_month_end_date", 1)).cast("string"))
    .otherwise(year("projection_month_end_date").cast("string"))
)

# Perform the final join and aggregation
result = csi_partner_dbu_target_bu.alias("target") \
    .join(account_forecast.alias("a"),
          (col("target.Region") == col("a.Region")) &
          (col("target.Region_2") == col("a.Region_2")) &
          (col("target.Region_3") == col("a.Region_3")) &
          (col("target.`Fiscal Quarter`") == col("a.fiscal_quarter")) &
          (col("target.`Fiscal Year`") == col("a.fiscal_year")),
          "left") \
    .join(details.alias("d"),
          (col("a.Account_Name") == col("d.account_name")) &
          (col("a.snapshot_date") == col("d.snapshot_date")) &
          (col("a.Region") == col("d.region")) &
          (col("a.Region_2") == col("d.region_2")) &
          (col("a.Region_3") == col("d.region_3")) &
          (col("a.Partner_Name") == col("d.partner_name")) &
          (col("a.fiscal_quarter") == col("d.details_fiscal_quarter")) &
          (col("a.fiscal_year") == col("d.details_fiscal_year")),
          "left") \
    .select(
        col("target.Region").alias("target_region"),
        col("target.Region_2").alias("target_region2"),
        col("target.Region_3").alias("target_region3"),
        col("target.`Fiscal Quarter`").alias("target_fiscal_quarter"),
        col("target.`Fiscal Year`").alias("target_fiscal_year"),
        col("target.`$DBU_Target`").alias("Target_DBUs"),
        coalesce(col("a.Partner_ae_forecast"), lit(0)).alias("Partner_ae_forecast"),
        coalesce(col("a.Partner_adjustment"), lit(0)).alias("Partner_adjustment"),
        coalesce(col("a.Partner_ds_forecast"), lit(0)).alias("Partner_ds_forecast"),
        coalesce(col("a.Partner_og_growth_baseline"), lit(0)).alias("Partner_og_growth_baseline"),
        coalesce(col("a.Partner_open_in_plan_use_cases"), lit(0)).alias("Partner_open_in_plan_use_cases"),
        coalesce(col("a.partner_current_adjustment"), lit(0)).alias("partner_current_adjustment"),
        coalesce(col("a.partner_current_ds_forecast"), lit(0)).alias("partner_current_ds_forecast"),
        coalesce(col("a.partner_current_open_in_plan_usecases"), lit(0)).alias("partner_current_open_in_plan_usecases"),
        coalesce(col("a.partner_current_organic_growth_baseline"), lit(0)).alias("partner_current_organic_growth_baseline"),
        coalesce(col("d.attributed_projected_monthly_dollars_w_month_pro_rata"), lit(0)).alias("attributed_projected_monthly_dollars_w_month_pro_rata"),
        col("a.account_id"),
        col("a.Account_Name").alias("forecast_account_name"),
        col("a.fiscal_quarter"),
        col("a.fiscal_year"),
        col("a.in_plan"),
        col("a.Managed_Coverage"),
        col("a.Parent_ID"),
        col("a.Partner_Name").alias("forecast_partner_name"),
        col("a.Partner_Sales_Manager"),
        col("a.Region").alias("forecast_region"),
        col("a.Region_2").alias("forecast_region2"),
        col("a.Region_3").alias("forecast_region3"),
        col("a.Region_4").alias("forecast_region4"),
        col("a.snapshot_date").alias("forecast_snapshot_date"),
        col("a.forecast_snap_date"),
        col("d.account_name").alias("details_account_name"),
        col("d.is_use_case_in_plan"),
        col("d.partner_name").alias("details_partner_name"),
        col("d.projection_month_end_date"),
        col("d.region").alias("details_region"),
        col("d.region_2").alias("details_region2"),
        col("d.region_3").alias("details_region3"),
        col("d.snapshot_date").alias("details_snapshot_date"),
        col("d.use_case_name"),
        col("d.usecase_id"),
        col("d.details_fiscal_quarter"),
        col("d.details_fiscal_year"),
        col("d.details_snap_date")
    ).groupBy(
        "target_region", "target_region2", "target_region3", "target_fiscal_quarter", "target_fiscal_year",
        "account_id", "forecast_account_name", "fiscal_quarter", "fiscal_year", "in_plan",
        "Managed_Coverage", "Parent_ID", "forecast_partner_name", "Partner_Sales_Manager",
        "forecast_region", "forecast_region2", "forecast_region3", "forecast_region4",
        "forecast_snapshot_date", "forecast_snap_date", "details_account_name", "is_use_case_in_plan",
        "details_partner_name", "projection_month_end_date", "details_region", "details_region2",
        "details_region3", "details_snapshot_date", "use_case_name", "usecase_id",
        "details_fiscal_quarter", "details_fiscal_year", "details_snap_date"
    ).agg(
        sum("Target_DBUs").alias("Target_DBUs"),
        sum("Partner_ae_forecast").alias("Partner_ae_forecast"),
        sum("Partner_adjustment").alias("Partner_adjustment"),
        sum("Partner_ds_forecast").alias("Partner_ds_forecast"),
        sum("Partner_og_growth_baseline").alias("Partner_og_growth_baseline"),
        sum("Partner_open_in_plan_use_cases").alias("Partner_open_in_plan_use_cases"),
        sum("partner_current_adjustment").alias("partner_current_adjustment"),
        sum("partner_current_ds_forecast").alias("partner_current_ds_forecast"),
        sum("partner_current_open_in_plan_usecases").alias("partner_current_open_in_plan_usecases"),
        sum("partner_current_organic_growth_baseline").alias("partner_current_organic_growth_baseline"),
        sum("attributed_projected_monthly_dollars_w_month_pro_rata").alias("attributed_projected_monthly_dollars_w_month_pro_rata")
    )



# COMMAND ----------

result.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable("main.it_aibi_silver.dbu_forecasting_silver")
