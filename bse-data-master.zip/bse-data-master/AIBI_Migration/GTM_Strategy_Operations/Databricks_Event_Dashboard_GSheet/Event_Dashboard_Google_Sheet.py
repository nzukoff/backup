# Databricks notebook source
# Import necessary libraries
%pip install gspread
%pip install pygsheets

# COMMAND ----------

# Databricks notebook source
# DBTITLE 1,Gsheet Functions

import json
import pandas as pd
import gspread
from dataclasses import dataclass
from pyspark.sql import DataFrame
import pygsheets
from tempfile import NamedTemporaryFile

# Define a data class to hold GCP service account information
@dataclass(frozen=True)
class GCPServiceAccount:
    name: str
    secrets_scope: str
    creds_key: str

# Configuration for accessing GCP service account credentials stored in Databricks secrets
env_configs = {
    "dev": GCPServiceAccount(
        name='dev-bse-storage-access-sa',
        secrets_scope='bse-dev-creds',
        creds_key='gcp_dev_bse_creds'
    ),
    "prod": GCPServiceAccount(
        name='dev-bse-storage-access-sa',
        secrets_scope='bse-dev-creds',
        creds_key='gcp_dev_bse_creds'
    )
}

def retrieve_gcp_dev_bse_serv_acc_creds(sa: GCPServiceAccount, dbutils) -> dict:
    """
    Retrieves GCP service account credentials from Databricks secrets.
    
    Parameters:
        - sa: An instance of GCPServiceAccount containing the service account details.
    
    Returns:
        - A dictionary containing the service account credentials.
    """
    return (json.loads(dbutils.secrets.get(scope=sa.secrets_scope, key=sa.creds_key)))

def open_gsheet_by_id(gsheet_id: str, service_account: GCPServiceAccount, dbutils):
    """
    Opens a Google Sheet by its ID using credentials of a specified GCP service account.
    
    Parameters:
        - gsheet_id (str):  The ID of the Google Sheet to be accessed.
        - service_account:  An instance of GCPServiceAccount to use for authentication.
    
    Returns:
        - An instance of gspread.models.Spreadsheet representing the opened Google Sheet.
    """
    gc = gspread.service_account_from_dict(retrieve_gcp_dev_bse_serv_acc_creds(service_account, dbutils))
    return gc.open_by_key(gsheet_id)

def read_google_worksheet_data(gsheet_id: str, worksheet_id: str, dbutils, spark, env: str='dev', data_range : str=None, columnList: list = None) -> DataFrame:
    """
    This function reads data from a specified worksheet within a Google Sheet and returns it as a Spark DataFrame. It utilizes a GCP service account to access the Google Sheet data, so you'll need to ensure that the provided GCP service account has the necessary permissions (view) to the Google Sheet.
        - dev: dev-bse-storage-access-sa@gcp-dev-bse.iam.gserviceaccount.com
        - prod: prd-bse-storage-access-sa@gcp-prod-bse.iam.gserviceaccount.com

    Deficiencies:
        - Considers 1st row as header by default


    Parameters:
        - gsheet_id (str):              This parameter represents the unique identifier for the Google Sheets document. 
                                        You can find this ID    within the Google Sheets URL. It is the part of the URL that immediately follows 'https://docs.google.com/spreadsheets/d/' and precedes 'edit#gid=<worksheet_id>'. For instance, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then 'abc123' is the gsheet_id.

        - worksheet_id (str):           This parameter refers to the specific worksheet within the Google Sheets document from 
                                        which you want to retrieve data. It can be identified from the Google Sheets URL. It comes after 'gid=' in the URL. For example, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then '456' is the worksheet_id.

        - dbutils and spark:            Imported Python modules don't have access to the notebook context (i.e., can't see things like the
                                        global "spark" and "dbutils" objects), so we have to pass dbutils & spark in.

        - env (str):                    The environment to use ('dev' or 'prod'). Determines which service account to use.

        - data_range (str, optional):   A specific range of cells to read from the worksheet.

        - columnList (str, optional):   Please mention the list of columns that you want to extract from the gsheet.
    

    Returns:
        - A Spark DataFrame containing the data read from the worksheet.
    """
    # Select the service account based on the environment
    service_account = env_configs[env]
    gsheet = open_gsheet_by_id(gsheet_id, service_account, dbutils)
    worksheet = gsheet.get_worksheet_by_id(int(worksheet_id))

    if data_range:
        ws_data = worksheet.get_values(data_range)
    else:
        ws_data = worksheet.get_values()
    if not ws_data:
      raise ValueError("The worksheet is empty or does not exist.")

    header = ws_data[0] # Considering 1st row as header
    # Checking if all the columns mentioned in columnList are present
    if columnList is None:
        columnList = []
    missing_columns = [col for col in columnList if col not in header]
    if missing_columns:
        raise ValueError(f"The following columns are missing in the worksheet: {', '.join(missing_columns)}")

    if not columnList:
        columnList = header

    selected_indices = [header.index(col) for col in columnList]
    filtered_data = [[row[i] for i in selected_indices] for row in ws_data[1:]]

    # Use the first row as header and the rest as data
    pd_df = pd.DataFrame(filtered_data, columns=columnList)
    pd_df.fillna("", inplace=True)  # Convert None to empty string

    # Convert column names to lowercase and replace spaces with underscores
    pd_df.columns = [x.lower().replace(" ", "_") for x in pd_df.columns]

    # Create a Spark DataFrame from the pandas DataFrame
    spark_df = spark.createDataFrame(pd_df)
    return spark_df
  
def write_to_google_sheet(gsheet_id: str, worksheet_id: str, pandasDF, dbutils, env: str='dev'):
    """
    This function writes pandas dataframe to a Google Sheet. It utilizes a GCP service account to access the Google Sheet data, so you'll need to ensure that the provided GCP service account has the necessary permissions (edit) to the Google Sheet.
        - dev: dev-bse-storage-access-sa@gcp-dev-bse.iam.gserviceaccount.com
        - prod: prd-bse-storage-access-sa@gcp-prod-bse.iam.gserviceaccount.com

    Parameters:
        - gsheet_id (str):              This parameter represents the unique identifier for the Google Sheets document. 
                                        You can find this ID    within the Google Sheets URL. It is the part of the URL that immediately follows 'https://docs.google.com/spreadsheets/d/' and precedes 'edit#gid=<worksheet_id>'. For instance, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then 'abc123' is the gsheet_id.

        - worksheet_id (str):           This parameter refers to the specific worksheet within the Google Sheets document from 
                                        which you want to retrieve data. It can be identified from the Google Sheets URL. It comes after 'gid=' in the URL. For example, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then '456' is the worksheet_id.

        - pandasDF:                     pandas dataframe containing the data to be written to the worksheet.

        - dbutils:                      Imported Python modules don't have access to the notebook context (i.e., can't see things like the
                                        global "spark" and "dbutils" objects), so we have to pass dbutils & spark in.

        - env (str):                    The environment to use ('dev' or 'prod'). Determines which service account to use.
    """
    # Select the service account based on the environment
    service_account = env_configs[env]

    with NamedTemporaryFile(mode='w+') as f:
      f.write(json.dumps(retrieve_gcp_dev_bse_serv_acc_creds(service_account, dbutils)))
      f.flush()
      auth = pygsheets.authorize(service_file=f.name)

    # Open the spreadsheet and the worksheet
    sh = auth.open_by_key(gsheet_id)
    wks = sh.worksheet('id', worksheet_id)
    wks.set_dataframe(pandasDF, (1, 1), fit=True)
    print('Data upload complete.')

# COMMAND ----------

# Example usage of the read_google_worksheet_data function

# Define the Google Sheet ID and Worksheet ID

#DAIS24_Survey_Data_Results 
gsheet_id_ags = '1SzlJYJQk5Ef_NQv5IuX8OsVaK4O95kr9Xsht00LZXYI'

worksheet_id_ags_1 = '620467342'
worksheet_id_ags_2 = '303766546'
worksheet_id_ags_3 = '1359001544'
worksheet_id_ags_4 = '1221990615'




env = 'dev'


# Read data from the Google Sheet
#DAIS24_Survey_Data_Results 
DAIS24_Speaker_Survey_Compilation = read_google_worksheet_data(gsheet_id_ags, worksheet_id_ags_1, dbutils, spark, env)
DAIS24_Session_Survey_Compilation = read_google_worksheet_data(gsheet_id_ags, worksheet_id_ags_2, dbutils, spark, env) 
DAIS24_RawData = read_google_worksheet_data(gsheet_id_ags, worksheet_id_ags_3, dbutils, spark, env) 
DAIS24_Speaker_Specific = read_google_worksheet_data(gsheet_id_ags, worksheet_id_ags_4, dbutils, spark, env) 



# COMMAND ----------


#Rainfocus Session Metadata
gsheet_id_Rainfocus='1xJSf9Kjc-2skHui1denwiueR1g44iqPzNxNkJZmHvaw'
worksheet_id_Rainfocus_1 = '810409466'
worksheet_id_Rainfocus_2 = '927228836'
# Define the environment ('dev' or 'prod')




env = 'dev'


#Rainfocus Session Metadata
Rainfocus_Master_Speaker_Report = read_google_worksheet_data(gsheet_id_Rainfocus, worksheet_id_Rainfocus_1, dbutils, spark, env) 
Rainfocus_Master_Sessions_Report = read_google_worksheet_data(gsheet_id_Rainfocus, worksheet_id_Rainfocus_2, dbutils, spark, env) 



# COMMAND ----------



#Event_Targets
gsheet_id_Targets_Overall='1aoVUv8sE3IvaRB62ORbeeMRwOWjZsyq3uB9zuRlY780'
worksheet_id_Targets_Overall_1 = '464836579'
worksheet_id_Targets_Overall_2 = '252814248'
worksheet_id_Targets_Overall_3 = '1549347479'
worksheet_id_Targets_Overall_4 = '1811951888'
worksheet_id_Targets_Overall_5 = '715987266'
worksheet_id_Targets_Overall_6 = '891014438'
worksheet_id_Targets_Overall_7 = '180245262'



env = 'dev'





#Event_Targets
Event_Targets_Overall = read_google_worksheet_data(gsheet_id_Targets_Overall, worksheet_id_Targets_Overall_1, dbutils, spark, env) 
Event_Targets_by_Attendee_Type = read_google_worksheet_data(gsheet_id_Targets_Overall, worksheet_id_Targets_Overall_2, dbutils, spark, env) 
Event_Targets_by_Date = read_google_worksheet_data(gsheet_id_Targets_Overall, worksheet_id_Targets_Overall_3, dbutils, spark, env) 
Event_Targets_by_BU = read_google_worksheet_data(gsheet_id_Targets_Overall, worksheet_id_Targets_Overall_4, dbutils, spark, env) 
Event_Targets_by_Region_1 = read_google_worksheet_data(gsheet_id_Targets_Overall, worksheet_id_Targets_Overall_5, dbutils, spark, env) 
Event_Targets_by_Region_2 = read_google_worksheet_data(gsheet_id_Targets_Overall, worksheet_id_Targets_Overall_6, dbutils, spark, env) 
Event_Targets_by_Vertical = read_google_worksheet_data(gsheet_id_Targets_Overall, worksheet_id_Targets_Overall_7, dbutils, spark, env) 


# COMMAND ----------

from pyspark.sql.functions import current_date

# Function to add current date column
def add_date_column(df):
    return df.withColumn("datebricks_data_ingest_date", current_date())

# Add current date column to each DataFrame



DAIS24_Speaker_Survey_Compilation=add_date_column(DAIS24_Speaker_Survey_Compilation)
DAIS24_Session_Survey_Compilation=add_date_column(DAIS24_Session_Survey_Compilation)
DAIS24_RawData=add_date_column(DAIS24_RawData)
DAIS24_Speaker_Specific=add_date_column(DAIS24_Speaker_Specific)

Rainfocus_Master_Speaker_Report=add_date_column(Rainfocus_Master_Speaker_Report)
Rainfocus_Master_Sessions_Report=add_date_column(Rainfocus_Master_Sessions_Report)

Event_Targets_Overall=add_date_column(Event_Targets_Overall)
Event_Targets_by_Attendee_Type=add_date_column(Event_Targets_by_Attendee_Type)
Event_Targets_by_Date=add_date_column(Event_Targets_by_Date)
Event_Targets_by_BU=add_date_column(Event_Targets_by_BU)
Event_Targets_by_Region_1=add_date_column(Event_Targets_by_Region_1)
Event_Targets_by_Region_2=add_date_column(Event_Targets_by_Region_2)
Event_Targets_by_Vertical=add_date_column(Event_Targets_by_Vertical)



# COMMAND ----------

from collections import Counter
import re

# Function to rename columns, ensuring unique names, and save as table
def rename_and_save(df, table_name):
    # Generate new column names, appending a suffix if duplicates exist
    new_columns = []
    col_counts = Counter([c if c else f"col_{i}" for i, c in enumerate(df.columns)])
    for col, count in col_counts.items():
        # Remove invalid characters
        col = re.sub(r'[ ,;{}()\n\t=]', '_', col)
        if count > 1:  # If the column name would be duplicated
            for i in range(count):
                new_columns.append(f"{col}_{i}")
        else:
            new_columns.append(col)
    
    # Rename columns ensuring uniqueness
    df = df.toDF(*new_columns)
    
    # Save the DataFrame as a table
    df.write.mode("overwrite").option("mergeSchema","True").saveAsTable(f"main.it_aibi_bronze.{table_name}")

# Example usage
rename_and_save(DAIS24_Speaker_Survey_Compilation, "DAIS24_Speaker_Survey_Compilation")
rename_and_save(DAIS24_Session_Survey_Compilation, "DAIS24_Session_Survey_Compilation")
rename_and_save(DAIS24_RawData, "DAIS24_RawData")
rename_and_save(DAIS24_Speaker_Specific, "DAIS24_Speaker_Specific")
rename_and_save(Rainfocus_Master_Speaker_Report, "Rainfocus_Master_Speaker_Report")
rename_and_save(Rainfocus_Master_Sessions_Report, "Rainfocus_Master_Sessions_Report")
rename_and_save(Event_Targets_Overall, "Targets_Overall")
rename_and_save(Event_Targets_by_Attendee_Type, "Targets_by_Attendee_Type")
rename_and_save(Event_Targets_by_Date, "Targets_by_Date")
rename_and_save(Event_Targets_by_BU, "Targets_by_BU")
rename_and_save(Event_Targets_by_Region_1, "Targets_by_Region_1")
rename_and_save(Event_Targets_by_Region_2, "Targets_by_Region_2")
rename_and_save(Event_Targets_by_Vertical, "Targets_by_Vertical")

# COMMAND ----------

# MAGIC %md
# MAGIC #silver

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.dais24_rawdata AS SELECT * FROM main.it_aibi_bronze.dais24_rawdata;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.dais24_session_survey_compilation AS SELECT * FROM main.it_aibi_bronze.dais24_session_survey_compilation;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.dais24_speaker_specific AS SELECT * FROM main.it_aibi_bronze.dais24_speaker_specific;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.dais24_speaker_survey_compilation AS SELECT * FROM main.it_aibi_bronze.dais24_speaker_survey_compilation;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.rainfocus_master_sessions_report AS SELECT * FROM main.it_aibi_bronze.rainfocus_master_sessions_report;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.rainfocus_master_speaker_report AS SELECT * FROM main.it_aibi_bronze.rainfocus_master_speaker_report;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.targets_by_attendee_type AS SELECT * FROM main.it_aibi_bronze.targets_by_attendee_type;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.targets_by_bu AS SELECT * FROM main.it_aibi_bronze.targets_by_bu;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.targets_by_date AS SELECT * FROM main.it_aibi_bronze.targets_by_date;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.targets_by_region_1 AS SELECT * FROM main.it_aibi_bronze.targets_by_region_1;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.targets_by_region_2 AS SELECT * FROM main.it_aibi_bronze.targets_by_region_2;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.targets_by_vertical AS SELECT * FROM main.it_aibi_bronze.targets_by_vertical;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.targets_overall AS SELECT * FROM main.it_aibi_bronze.targets_overall;

# COMMAND ----------

# MAGIC %md
# MAGIC #gold

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.dais24_rawdata AS SELECT * FROM main.it_aibi_silver.dais24_rawdata;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.dais24_session_survey_compilation AS SELECT * FROM main.it_aibi_silver.dais24_session_survey_compilation;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.dais24_speaker_specific AS SELECT * FROM main.it_aibi_silver.dais24_speaker_specific;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.dais24_speaker_survey_compilation AS SELECT * FROM main.it_aibi_silver.dais24_speaker_survey_compilation;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.rainfocus_master_sessions_report AS SELECT * FROM main.it_aibi_silver.rainfocus_master_sessions_report;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.rainfocus_master_speaker_report AS SELECT * FROM main.it_aibi_silver.rainfocus_master_speaker_report;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.targets_by_attendee_type AS SELECT * FROM main.it_aibi_silver.targets_by_attendee_type;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.targets_by_bu AS SELECT * FROM main.it_aibi_silver.targets_by_bu;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.targets_by_date AS SELECT * FROM main.it_aibi_silver.targets_by_date;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.targets_by_region_1 AS SELECT * FROM main.it_aibi_silver.targets_by_region_1;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.targets_by_region_2 AS SELECT * FROM main.it_aibi_silver.targets_by_region_2;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.targets_by_vertical AS SELECT * FROM main.it_aibi_silver.targets_by_vertical;
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.targets_overall AS SELECT * FROM main.it_aibi_silver.targets_overall;
