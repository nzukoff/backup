# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.emea_smart_commit_silver as
# MAGIC
# MAGIC WITH opportunity as (  
# MAGIC   select
# MAGIC   o.accountid as Opportunity_Account_ID,
# MAGIC   o.FiscalYear as Fiscal_Year,
# MAGIC   o.ForecastCategory as Forecast_Category,
# MAGIC   o.OpportunityID_CaseSafe__c as Opportunity_ID,
# MAGIC   o.Type as Opportunity_Type,
# MAGIC   o.Platform_Type__c as Platform_Type,
# MAGIC   o.StageName as Stage,
# MAGIC   sum(o.IncrementalUpsideAmount__c)  as Incremental_Upside_Amount,
# MAGIC   sum(o.Subscription_Total_RH__c) as Subscription_Total
# MAGIC   from main.sfdc_bronze.opportunity o
# MAGIC   where o.processDate = (select max(o2.processDate) from main.sfdc_bronze.opportunity o2)
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC account as (
# MAGIC   select 
# MAGIC   a.id as Account_ID,
# MAGIC   a.ownerId as Owner_ID
# MAGIC   from main.sfdc_bronze.account a
# MAGIC   where a.processDate = (select max(a2.processDate) from main.sfdc_bronze.account a2)
# MAGIC ),
# MAGIC
# MAGIC user as (
# MAGIC   select 
# MAGIC   u.id as User_ID,
# MAGIC   u.Business_Unit__c as Business_Unit,
# MAGIC   u.Region_Level_1__c as Region_Level_1,
# MAGIC   u.Region_Level_2__c as Region_Level_2,
# MAGIC   u.Region_Level_3__c as Region_Level_3,
# MAGIC   u.Region_Level_4__c as Region_Level_4
# MAGIC   from main.sfdc_bronze.user u
# MAGIC   where u.processDate = (select max(u2.processDate) from main.sfdc_bronze.user u2)
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC o.Opportunity_Account_ID,
# MAGIC o.Fiscal_Year,
# MAGIC o.Forecast_Category,
# MAGIC o.Opportunity_ID,
# MAGIC o.Opportunity_Type,
# MAGIC o.Platform_Type,
# MAGIC o.Stage,
# MAGIC o.Incremental_Upside_Amount,
# MAGIC o.Subscription_Total,
# MAGIC u.Business_Unit,
# MAGIC u.Region_Level_1,
# MAGIC u.Region_Level_2,
# MAGIC u.Region_Level_3,
# MAGIC u.Region_Level_4
# MAGIC from opportunity o
# MAGIC left join account a on o.Opportunity_Account_ID = a.Account_ID
# MAGIC left join user u on a.Owner_ID = u.User_ID
# MAGIC

# COMMAND ----------



# COMMAND ----------


