# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Read the data from the source table
df = spark.table("main.it_aibi_silver.emea_smart_commit_silver")

# Create a function for Deal Size calculation
def deal_size(col):
    return F.when((col > 0) & (col <= 50000), 'A. < $50k')\
            .when((col > 50000) & (col <= 100000), 'B. $50k-$100k')\
            .when((col > 100000) & (col <= 250000), 'C. $100k-$250k')\
            .when((col > 250000) & (col <= 500000), 'D. $250k-$500k')\
            .when((col > 500000) & (col <= 1000000), 'E. $500k-$1M')\
            .when((col > 1000000) & (col <= 3000000), 'F. $1M-$3M')\
            .when((col > 3000000) & (col <= 5000000), 'G. $3M-$5M')\
            .when((col > 5000000) & (col <= 10000000), 'H. $5M-$10M')\
            .when((col > 10000000) & (col <= 15000000), 'I. $10M-$15M')\
            .when(col > 15000000, 'J. $15M+')\
            .otherwise('NA')

# Apply transformations
df_transformed = df.select(
    "*",
    deal_size(F.col("Subscription_Total")).alias("Deal_Size"),
    F.col("Fiscal_Year").cast("string").alias("FY"),
    F.when(F.col("Forecast_Category") == "Commit", F.col("Incremental_Upside_Amount")).otherwise(0).alias("Commit_Upside"),
    (F.coalesce(F.col("Subscription_Total"), F.lit(0)) + 
     F.coalesce(F.when(F.col("Forecast_Category") == "Commit", F.col("Incremental_Upside_Amount")).otherwise(0), F.lit(0))
    ).alias("Total_with_Commit_Upside")
)

# Calculate window functions
window_spec = Window.partitionBy()
total_deals = df_transformed.select(F.countDistinct("Opportunity_ID")).first()[0]

emea_smart_commit_gold = df_transformed.select(
    "*",
    F.sum("Subscription_Total").over(window_spec).alias("Filtered_Total_Booking"),
    F.sum("Total_with_Commit_Upside").over(window_spec).alias("Filtered_Total_with_Commit_Upside"),
    (F.sum("Subscription_Total").over(window_spec) / F.lit(total_deals)).alias("ASP"),
    (F.sum("Total_with_Commit_Upside").over(window_spec) / F.lit(total_deals)).alias("ASP_Total_with_Commit_Upside"),
    # % of Total Booking
    (F.col("Subscription_Total") / F.sum("Subscription_Total").over(window_spec)).alias("Percent_of_Total_Booking"),
    # % of Total Deals
    (F.lit(1) / F.count("Opportunity_ID").over(window_spec)).alias("Percent_of_Total_Deals"),
    # % Total with Commit Upside
    (F.col("Total_with_Commit_Upside") / F.sum("Total_with_Commit_Upside").over(window_spec)).alias("Percent_Total_with_Commit_Upside")
)

# # Show the result
# emea_smart_commit_gold.display()


# COMMAND ----------

# MAGIC %md
# MAGIC ##Creating Gold table

# COMMAND ----------

emea_smart_commit_gold.write.format("delta").mode("overwrite").saveAsTable("main.it_aibi_gold.emea_smart_commit_gold")
