# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.isv_telemetry_partners_silver as
# MAGIC
# MAGIC select
# MAGIC bu,
# MAGIC canonicalCustomerId,
# MAGIC countsTowardsOkr,
# MAGIC Customer_Name,
# MAGIC owner_name as account_owner,
# MAGIC canonicalPartnerName as partner_name,
# MAGIC partnerCategory,
# MAGIC `date`,
# MAGIC isCommercialProductOnly,
# MAGIC isManagedPartner,
# MAGIC partnerProductAlias,
# MAGIC partnerProductName,
# MAGIC sub_bu,
# MAGIC attributedDbus,
# MAGIC attributedRevenue,
# MAGIC numApiCalls
# MAGIC from main.gtm_partner_data.tech_partner_telemtry
# MAGIC
# MAGIC
