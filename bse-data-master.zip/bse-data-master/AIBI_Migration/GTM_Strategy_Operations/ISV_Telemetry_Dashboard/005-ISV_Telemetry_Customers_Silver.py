# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.isv_telemetry_customers_silver as
# MAGIC
# MAGIC select
# MAGIC ae_name,
# MAGIC bu,
# MAGIC customer_id,
# MAGIC customer_name,
# MAGIC delta_share_edge_id,
# MAGIC edge_type,
# MAGIC is_customer,
# MAGIC is_real_customer,
# MAGIC is_stable_edge,
# MAGIC recipient_provider,
# MAGIC sub_bu
# MAGIC from main.gtm_partner_data.customers_with_delta_share_edges
# MAGIC
# MAGIC
