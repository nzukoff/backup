# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.isv_telemetry_use_case_silver as
# MAGIC
# MAGIC select
# MAGIC account_name,
# MAGIC bu,
# MAGIC created_date,
# MAGIC data_warehousing,
# MAGIC genai,
# MAGIC is_migration_usecase,
# MAGIC migration_source_platform,
# MAGIC partner_category,
# MAGIC partner_name,
# MAGIC partner_role,
# MAGIC partner_attach_date as partner_tag_date,
# MAGIC partner_attached_by_name as partner_tagged_by,
# MAGIC stage,
# MAGIC sub_bu,
# MAGIC target_live_date,
# MAGIC target_live_fiscal_quarter,
# MAGIC target_live_fiscal_year,
# MAGIC usecase_id,
# MAGIC governance as governance_use_case,
# MAGIC non_split_estimated_monthly_dollar_dbus,
# MAGIC non_split_estimated_monthly_dollar_dbus_dbsql,
# MAGIC non_split_estimated_monthly_dollar_dbus_uc,
# MAGIC serverless as serverless_use_case,
# MAGIC split_estimated_monthly_dollar_dbus,
# MAGIC streaming as streaming_use_case
# MAGIC from main.gtm_partner_data.isv_split_usecases
# MAGIC
# MAGIC
