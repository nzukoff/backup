# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.isv_telemetry_use_case_gold as
# MAGIC
# MAGIC SELECT
# MAGIC     account_name,
# MAGIC     bu,
# MAGIC     created_date,
# MAGIC     data_warehousing,
# MAGIC     genai,
# MAGIC     is_migration_usecase,
# MAGIC     migration_source_platform,
# MAGIC     partner_category,
# MAGIC     partner_name,
# MAGIC     partner_role,
# MAGIC     partner_tag_date,
# MAGIC     partner_tagged_by,
# MAGIC     stage,
# MAGIC     sub_bu,
# MAGIC     target_live_date,
# MAGIC     target_live_fiscal_quarter,
# MAGIC     target_live_fiscal_year,
# MAGIC     usecase_id,
# MAGIC     governance_use_case,
# MAGIC     non_split_estimated_monthly_dollar_dbus,
# MAGIC     non_split_estimated_monthly_dollar_dbus_dbsql,
# MAGIC     non_split_estimated_monthly_dollar_dbus_uc,
# MAGIC     serverless_use_case,
# MAGIC     split_estimated_monthly_dollar_dbus,
# MAGIC     streaming_use_case,
# MAGIC     -- Adding the Tableau calculations
# MAGIC     CAST(data_warehousing AS INTEGER) AS Data_Warehousing_Use_Cases,
# MAGIC     CAST(genai AS INTEGER) AS Genai_Use_Cases
# MAGIC FROM main.it_aibi_silver.isv_telemetry_use_case_silver
