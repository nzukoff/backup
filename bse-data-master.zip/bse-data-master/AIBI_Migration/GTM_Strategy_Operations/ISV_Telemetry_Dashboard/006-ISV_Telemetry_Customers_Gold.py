# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.isv_telemetry_customers_gold as
# MAGIC
# MAGIC select * from main.it_aibi_silver.isv_telemetry_customers_silver
# MAGIC
# MAGIC
