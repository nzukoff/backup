# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.isv_telemetry_partners_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC     SELECT
# MAGIC         bu,
# MAGIC         canonicalCustomerId,
# MAGIC         countsTowardsOkr,
# MAGIC         Customer_Name,
# MAGIC         account_owner,
# MAGIC         partner_name,
# MAGIC         partnerCategory,
# MAGIC         `date`,
# MAGIC         isCommercialProductOnly,
# MAGIC         isManagedPartner,
# MAGIC         partnerProductAlias,
# MAGIC         partnerProductName,
# MAGIC         sub_bu,
# MAGIC         attributedDbus,
# MAGIC         attributedRevenue,
# MAGIC         numApiCalls
# MAGIC     FROM main.it_aibi_silver.isv_telemetry_partners_silver
# MAGIC ),
# MAGIC monthly_integrations AS (
# MAGIC     SELECT
# MAGIC         canonicalCustomerId,
# MAGIC         DATE_TRUNC('MONTH', `date`) AS month_date,
# MAGIC         COUNT(DISTINCT partnerProductAlias) AS total_active_monthly_partner_product_integrations,
# MAGIC         COUNT(DISTINCT partner_name) AS total_active_monthly_partners_integrated
# MAGIC     FROM base_data
# MAGIC     GROUP BY canonicalCustomerId, DATE_TRUNC('MONTH', `date`)
# MAGIC )
# MAGIC SELECT
# MAGIC     b.*,
# MAGIC     CASE 
# MAGIC         WHEN (EXTRACT(YEAR FROM b.`date`) * 100 + EXTRACT(MONTH FROM b.`date`)) < 
# MAGIC              (EXTRACT(YEAR FROM CURRENT_DATE()) * 100 + EXTRACT(MONTH FROM CURRENT_DATE()))
# MAGIC         THEN 'Y' ELSE 'N' 
# MAGIC     END AS exclude_current_month,
# MAGIC     m.total_active_monthly_partner_product_integrations,
# MAGIC     m.total_active_monthly_partners_integrated,
# MAGIC     CASE 
# MAGIC         WHEN m.total_active_monthly_partner_product_integrations >= 3 THEN '>= 3'
# MAGIC         WHEN m.total_active_monthly_partner_product_integrations = 2 THEN '2'
# MAGIC         WHEN m.total_active_monthly_partner_product_integrations = 1 THEN '1'
# MAGIC         ELSE NULL
# MAGIC     END AS monthly_partner_product_integrations_groupings,
# MAGIC     CASE 
# MAGIC         WHEN m.total_active_monthly_partners_integrated >= 3 THEN '>= 3'
# MAGIC         WHEN m.total_active_monthly_partners_integrated = 2 THEN '2'
# MAGIC         WHEN m.total_active_monthly_partners_integrated = 1 THEN '1'
# MAGIC         ELSE NULL
# MAGIC     END AS monthly_partners_integrated_groupings
# MAGIC FROM base_data b
# MAGIC LEFT JOIN monthly_integrations m 
# MAGIC     ON b.canonicalCustomerId = m.canonicalCustomerId 
# MAGIC     AND DATE_TRUNC('MONTH', b.`date`) = m.month_date
