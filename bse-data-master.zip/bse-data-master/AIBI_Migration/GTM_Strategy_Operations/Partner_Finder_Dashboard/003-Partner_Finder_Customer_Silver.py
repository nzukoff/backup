# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.partner_finder_customer_silver as
# MAGIC
# MAGIC select
# MAGIC Account_Name,
# MAGIC Accelerator_Concatenated as BB_Accelerators,
# MAGIC Brickbuilder_Migration as BB_Migrations,
# MAGIC Migration_Capabilities as Brickbuilder_Migration,
# MAGIC brickbuilder_accelerators,
# MAGIC Cloud,
# MAGIC Contact_Email,
# MAGIC data_warehouse,
# MAGIC dpp,
# MAGIC gen_ai,
# MAGIC Industry_Solution,
# MAGIC Partner_Manager__c as Partner_Manager,
# MAGIC Partner_Name,
# MAGIC stamped_partner_tier as Partner_Tier,
# MAGIC Primary_Contact,
# MAGIC Recognized_Partner as Recognized,
# MAGIC Solution_Name,
# MAGIC TopCustomers,
# MAGIC unity_catalog,
# MAGIC url,
# MAGIC Joint_Customers,
# MAGIC Split_RevShare_Dollars,
# MAGIC Total_Certs
# MAGIC from main.gtm_partner_data.csi_customer_partner_finder
# MAGIC
# MAGIC
