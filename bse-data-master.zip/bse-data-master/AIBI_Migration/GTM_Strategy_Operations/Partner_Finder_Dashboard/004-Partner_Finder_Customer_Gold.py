# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.partner_finder_customer_gold as
# MAGIC
# MAGIC SELECT
# MAGIC     Account_Name,
# MAGIC     BB_Accelerators,
# MAGIC     BB_Migrations,
# MAGIC     brickbuilder_accelerators,
# MAGIC     Brickbuilder_Migration,
# MAGIC     Cloud,
# MAGIC     Contact_Email,
# MAGIC     data_warehouse,
# MAGIC     dpp,
# MAGIC     gen_ai,
# MAGIC     Industry_Solution,
# MAGIC     Partner_Manager,
# MAGIC     Partner_Name,
# MAGIC     Partner_Tier,
# MAGIC     Primary_Contact,
# MAGIC     Recognized,
# MAGIC     Solution_Name,
# MAGIC     TopCustomers,
# MAGIC     unity_catalog,
# MAGIC     url,
# MAGIC     Joint_Customers,
# MAGIC     Split_RevShare_Dollars,
# MAGIC     Total_Certs,
# MAGIC     CASE
# MAGIC         WHEN Partner_Manager IS NULL THEN 'Partner Development Center'
# MAGIC         WHEN Partner_Manager = 'Chelsea Weintraub' THEN 'Partner Development Center'
# MAGIC         ELSE Partner_Manager
# MAGIC     END AS PAM,
# MAGIC     Primary_Contact || ' (' || Contact_Email || ')' AS Primary_Partner_Contacts,
# MAGIC     MAX(Joint_Customers) OVER (PARTITION BY Partner_Name) AS Max_Joint_Customers,
# MAGIC     MAX(Total_Certs) OVER (PARTITION BY Partner_Name) AS Max_Technical_Certifications
# MAGIC FROM main.it_aibi_silver.partner_finder_customer_silver
