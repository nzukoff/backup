# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.partner_finder_gold as
# MAGIC
# MAGIC SELECT
# MAGIC     BB_Accelerators,
# MAGIC     BB_Migrations,
# MAGIC     Brickbuilder_Migration,
# MAGIC     brickbuilder_accelerators,
# MAGIC     BU_Plus_1,
# MAGIC     Cloud,
# MAGIC     Contact_Email,
# MAGIC     data_warehouse,
# MAGIC     dpp,
# MAGIC     gen_ai,
# MAGIC     Industry_Solution,
# MAGIC     partner_contact,
# MAGIC     Partner_Manager,
# MAGIC     Partner_Name,
# MAGIC     Partner_Tier,
# MAGIC     Primary_Region,
# MAGIC     Recognized,
# MAGIC     Solution_Name,
# MAGIC     TopCustomers,
# MAGIC     unity_catalog,
# MAGIC     url,
# MAGIC     Joint_Customers,
# MAGIC     Total_Certs,
# MAGIC     CASE 
# MAGIC         WHEN Primary_Region IS NULL THEN 0 
# MAGIC         ELSE 1 
# MAGIC     END AS Filter_Check,
# MAGIC     CASE
# MAGIC         WHEN Partner_Manager IS NULL THEN 'Partner Development Center'
# MAGIC         WHEN Partner_Manager = 'Chelsea Weintraub' THEN 'Partner Development Center'
# MAGIC         ELSE Partner_Manager
# MAGIC     END AS PAM,
# MAGIC     partner_contact || ' (' || Contact_Email || ')' AS Primary_Partner_Contacts,
# MAGIC     MAX(Joint_Customers) OVER (PARTITION BY Partner_Name) AS Max_Joint_Customers,
# MAGIC     MAX(Total_Certs) OVER (PARTITION BY Partner_Name) AS Max_Technical_Certifications
# MAGIC FROM main.it_aibi_silver.partner_finder_silver
# MAGIC
