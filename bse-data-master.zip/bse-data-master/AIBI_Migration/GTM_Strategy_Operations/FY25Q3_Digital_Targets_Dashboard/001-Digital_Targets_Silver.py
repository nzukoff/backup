# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.digital_targets_silver
# MAGIC
# MAGIC select
# MAGIC campaign_name,
# MAGIC `date`,
# MAGIC medium,
# MAGIC offer,
# MAGIC region,
# MAGIC source_medium,
# MAGIC team,
# MAGIC net_new_names,
# MAGIC quality_net_new_names,
# MAGIC u2_unit
# MAGIC from main.marketing_lakehouse.rpt_digital_performance_deepdive
