# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.digital_targets_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     campaign_name,
# MAGIC     date,
# MAGIC     medium,
# MAGIC     offer,
# MAGIC     region,
# MAGIC     source_medium,
# MAGIC     team,
# MAGIC     net_new_names,
# MAGIC     quality_net_new_names,
# MAGIC     u2_unit,
# MAGIC     CASE 
# MAGIC       WHEN region = 'APJ' THEN 'APJ'
# MAGIC       WHEN region = 'EMEA' THEN 'EMEA'
# MAGIC       ELSE 'AMER'
# MAGIC     END AS Region_star,
# MAGIC     CASE 
# MAGIC       WHEN date >= '2024-08-01' AND date <= '2024-10-31'
# MAGIC       AND team IN ('Demand Gen', 'Demand Generation', 'Trial, CE and Web', 'Global DG')
# MAGIC       THEN net_new_names 
# MAGIC     END AS QTD_Net_New_Names,
# MAGIC     CASE 
# MAGIC       WHEN date >= '2024-08-01' AND date <= '2024-10-31'
# MAGIC       AND team IN ('Demand Gen', 'Demand Generation', 'Trial, CE and Web', 'Global DG')
# MAGIC       THEN quality_net_new_names 
# MAGIC     END AS QTD_QNNN
# MAGIC   FROM main.it_aibi_silver.digital_targets_silver
# MAGIC ),
# MAGIC aggregated_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     SUM(QTD_Net_New_Names) OVER () AS Total_QTD_NNN,
# MAGIC     SUM(QTD_Net_New_Names) OVER (PARTITION BY medium) AS Medium_QTD_NNN,
# MAGIC     SUM(QTD_Net_New_Names) OVER (PARTITION BY Region_star) AS Region_QTD_NNN,
# MAGIC     SUM(QTD_QNNN) OVER () AS Total_QTD_QNNN,
# MAGIC     SUM(QTD_QNNN) OVER (PARTITION BY medium) AS Medium_QTD_QNNN,
# MAGIC     SUM(QTD_QNNN) OVER (PARTITION BY Region_star) AS Region_QTD_QNNN,
# MAGIC     SUM(u2_unit) OVER () AS Total_U2,
# MAGIC     SUM(u2_unit) OVER (PARTITION BY medium) AS Medium_U2,
# MAGIC     SUM(u2_unit) OVER (PARTITION BY Region_star) AS Region_U2,
# MAGIC     MAX(CASE 
# MAGIC       WHEN medium = 'Paid Search' THEN 29368
# MAGIC       WHEN medium = 'Paid Social' THEN 27108
# MAGIC       WHEN medium = 'Programmatic' THEN 5103
# MAGIC       WHEN medium = 'Third Party' THEN 23231
# MAGIC       ELSE 0
# MAGIC     END) OVER (PARTITION BY medium) AS FY25_Q3_NNN_Targets_by_Medium,
# MAGIC     MAX(CASE 
# MAGIC       WHEN Region_star = 'AMER' THEN 54818
# MAGIC       WHEN Region_star = 'APJ' THEN 12421
# MAGIC       WHEN Region_star = 'EMEA' THEN 17571
# MAGIC       ELSE 0
# MAGIC     END) OVER (PARTITION BY Region_star) AS FY25_Q3_NNN_Targets_by_Region,
# MAGIC     MAX(CASE 
# MAGIC       WHEN medium = 'Paid Search' THEN 4105
# MAGIC       WHEN medium = 'Paid Social' THEN 5239
# MAGIC       WHEN medium = 'Programmatic' THEN 685
# MAGIC       WHEN medium = 'Third Party' THEN 10687
# MAGIC       ELSE 0
# MAGIC     END) OVER (PARTITION BY medium) AS FY25_Q3_QNNN_Targets_by_Medium,
# MAGIC     MAX(CASE 
# MAGIC       WHEN Region_star = 'AMER' THEN 12656
# MAGIC       WHEN Region_star = 'APJ' THEN 2630
# MAGIC       WHEN Region_star = 'EMEA' THEN 4766
# MAGIC       ELSE 0
# MAGIC     END) OVER (PARTITION BY Region_star) AS FY25_Q3_QNNN_Targets_by_Region,
# MAGIC     MAX(CASE 
# MAGIC       WHEN medium = 'Paid Search' THEN 2001
# MAGIC       WHEN medium = 'Paid Social' THEN 662
# MAGIC       WHEN medium = 'Programmatic' THEN 176
# MAGIC       WHEN medium = 'Third Party' THEN 710
# MAGIC       ELSE 0
# MAGIC     END) OVER (PARTITION BY medium) AS FY25Q3_U2_Targets_by_Medium,
# MAGIC     MAX(CASE 
# MAGIC       WHEN Region_star = 'AMER' THEN 2425
# MAGIC       WHEN Region_star = 'APJ' THEN 451
# MAGIC       WHEN Region_star = 'EMEA' THEN 672
# MAGIC       ELSE 0
# MAGIC     END) OVER (PARTITION BY Region_star) AS FY25Q3_U2_Targets_by_Region
# MAGIC   FROM base_data
# MAGIC ),
# MAGIC final_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     Total_QTD_NNN / 84810 AS Net_New_Names_Target_Attainment_FY25Q3,
# MAGIC     Medium_QTD_NNN / NULLIF(FY25_Q3_NNN_Targets_by_Medium, 0) AS NNN_Target_Attainment_Medium_FY25Q3,
# MAGIC     Region_QTD_NNN / NULLIF(FY25_Q3_NNN_Targets_by_Region, 0) AS NNN_Target_Attainment_Region_FY25Q3,
# MAGIC     Medium_QTD_QNNN / NULLIF(FY25_Q3_QNNN_Targets_by_Medium, 0) AS QNNN_Target_Attainment_Medium_FY25Q3,
# MAGIC     Region_QTD_QNNN / NULLIF(FY25_Q3_QNNN_Targets_by_Region, 0) AS QNNN_Target_Attainment_Region_FY25Q3,
# MAGIC     Total_QTD_QNNN / 20715 AS QNNN_Target_Attainment_FY25Q3,
# MAGIC     CASE 
# MAGIC       WHEN CURRENT_DATE <= '2024-10-31' 
# MAGIC       THEN CAST(DATEDIFF(DAY, '2024-08-01', CURRENT_DATE - 1) AS FLOAT) / 90
# MAGIC       ELSE 1.0
# MAGIC     END AS Progress_thru_Q,
# MAGIC     Total_U2 / 3548 AS FY25Q3_U2_Target_Attainment,
# MAGIC     Medium_U2 / NULLIF(FY25Q3_U2_Targets_by_Medium, 0) AS FY25Q3_U2_Target_Attainment_by_Medium,
# MAGIC     Region_U2 / NULLIF(FY25Q3_U2_Targets_by_Region, 0) AS FY25Q3_U2_Target_Attainment_by_Region
# MAGIC   FROM aggregated_data
# MAGIC )
# MAGIC SELECT 
# MAGIC   *,
# MAGIC   CASE 
# MAGIC     WHEN NNN_Target_Attainment_Medium_FY25Q3 >= Progress_thru_Q THEN 'Ahead of Pace'
# MAGIC     WHEN NNN_Target_Attainment_Medium_FY25Q3 >= Progress_thru_Q * 0.8 
# MAGIC          AND NNN_Target_Attainment_Medium_FY25Q3 < Progress_thru_Q THEN '80-90 % to Pace'
# MAGIC     ELSE '< 80 % to Pace'
# MAGIC   END AS NNN_Medium_Pacing_Colors,
# MAGIC   CASE 
# MAGIC     WHEN NNN_Target_Attainment_Region_FY25Q3 >= Progress_thru_Q THEN 'Ahead of Pace'
# MAGIC     WHEN NNN_Target_Attainment_Region_FY25Q3 >= Progress_thru_Q * 0.8 
# MAGIC          AND NNN_Target_Attainment_Region_FY25Q3 < Progress_thru_Q THEN '80-90% to Pace'
# MAGIC     ELSE '< 80% to Pace'
# MAGIC   END AS NNN_Region_Pacing_Colors,
# MAGIC   CASE 
# MAGIC     WHEN Net_New_Names_Target_Attainment_FY25Q3 >= Progress_thru_Q THEN 'Ahead of Pace'
# MAGIC     WHEN Net_New_Names_Target_Attainment_FY25Q3 >= Progress_thru_Q * 0.8 
# MAGIC          AND Net_New_Names_Target_Attainment_FY25Q3 < Progress_thru_Q THEN '80-90% to Pace'
# MAGIC     ELSE '< 80% to Pace'
# MAGIC   END AS NNN_Pacing_Colors,
# MAGIC   CASE 
# MAGIC     WHEN QNNN_Target_Attainment_Medium_FY25Q3 >= Progress_thru_Q THEN 'Ahead of Pace'
# MAGIC     WHEN QNNN_Target_Attainment_Medium_FY25Q3 >= Progress_thru_Q * 0.8 
# MAGIC          AND QNNN_Target_Attainment_Medium_FY25Q3 < Progress_thru_Q THEN '80-90% to Pace'
# MAGIC     ELSE '< 80% to Pace'
# MAGIC   END AS QNNN_Medium_Pacing_Colors,
# MAGIC   CASE 
# MAGIC     WHEN QNNN_Target_Attainment_Region_FY25Q3 >= Progress_thru_Q THEN 'Ahead of Pace'
# MAGIC     WHEN QNNN_Target_Attainment_Region_FY25Q3 >= Progress_thru_Q * 0.8 
# MAGIC          AND QNNN_Target_Attainment_Region_FY25Q3 < Progress_thru_Q THEN '80-90% to Pace'
# MAGIC     ELSE '< 80% to Pace'
# MAGIC   END AS QNNN_Region_Pacing_Colors,
# MAGIC   CASE 
# MAGIC     WHEN QNNN_Target_Attainment_FY25Q3 >= Progress_thru_Q THEN 'Ahead of Pace'
# MAGIC     WHEN QNNN_Target_Attainment_FY25Q3 >= Progress_thru_Q * 0.8 
# MAGIC          AND QNNN_Target_Attainment_FY25Q3 < Progress_thru_Q THEN '80-90% to Pace'
# MAGIC     ELSE '< 80% to Pace'
# MAGIC   END AS QNNN_Pacing_Colors,
# MAGIC   CASE 
# MAGIC     WHEN FY25Q3_U2_Target_Attainment >= Progress_thru_Q THEN 'Ahead of Pace'
# MAGIC     WHEN FY25Q3_U2_Target_Attainment >= Progress_thru_Q * 0.8 
# MAGIC          AND FY25Q3_U2_Target_Attainment < Progress_thru_Q THEN '80-90% to Pace'
# MAGIC     ELSE '< 80% to Pace'
# MAGIC   END AS U2_Pacing_Colors,
# MAGIC   CASE 
# MAGIC     WHEN FY25Q3_U2_Target_Attainment_by_Medium >= Progress_thru_Q THEN 'Ahead of Pace'
# MAGIC     WHEN FY25Q3_U2_Target_Attainment_by_Medium >= Progress_thru_Q * 0.8 
# MAGIC          AND FY25Q3_U2_Target_Attainment_by_Medium < Progress_thru_Q THEN '80-90% to Pace'
# MAGIC     ELSE '< 80% to Pace'
# MAGIC   END AS U2_Pacing_Colors_Medium,
# MAGIC   CASE 
# MAGIC     WHEN FY25Q3_U2_Target_Attainment_by_Region >= Progress_thru_Q THEN 'Ahead of Pace'
# MAGIC     WHEN FY25Q3_U2_Target_Attainment_by_Region >= Progress_thru_Q * 0.8 
# MAGIC          AND FY25Q3_U2_Target_Attainment_by_Region < Progress_thru_Q THEN '80-90% to Pace'
# MAGIC     ELSE '< 80% to Pace'
# MAGIC   END AS U2_Pacing_Colors_Region
# MAGIC FROM final_data
