# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.project_redfish_account_summary_silver as
# MAGIC
# MAGIC select
# MAGIC account_executive,
# MAGIC bu,
# MAGIC sub_bu,
# MAGIC Databricks_Cloud_Sales_Manager,
# MAGIC deployable_account_id,
# MAGIC deployable_account_name,
# MAGIC sales_manager,
# MAGIC sfdc_account_id,
# MAGIC sfdc_account_name,
# MAGIC current_fy_estimated_monthly_dollar_dbus,
# MAGIC current_fy_use_case_count,
# MAGIC current_quarter_ae_forecast,
# MAGIC current_quarter_non_genai_consumption,
# MAGIC prior_quarter_non_genai_consumption,
# MAGIC prior_year_current_quarter_non_gen_ai_dbu_dollars,
# MAGIC prior_ytd_non_gen_ai_dbu_dollars,
# MAGIC ytd_change_non_gen_ai_dbu_dollars,
# MAGIC ytd_dbsql_dollars,
# MAGIC ytd_non_genai_consumption,
# MAGIC ytd_uc_dollars
# MAGIC from main.gtm_partner_data.project_redfish_account_summary
