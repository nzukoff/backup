# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.project_redfish_core_usecase_curated_silver
# MAGIC select *
# MAGIC /*c.account_executive,
# MAGIC c.account_id,
# MAGIC c.account_name,
# MAGIC c.account_solution_architect,
# MAGIC c.business_unit,
# MAGIC c.created_date,
# MAGIC c.migration_source_platform,
# MAGIC c.sales_manager,
# MAGIC c.stage,
# MAGIC c.stage_name_ui,
# MAGIC c.stage_number,
# MAGIC c.target_live_date,
# MAGIC c.snapshot_date,
# MAGIC c.target_live_fiscal_year,
# MAGIC c.usecase_id,
# MAGIC c.custom_monthly_total_dollar_dbus,
# MAGIC c.estimated_monthly_dollar_dbus,
# MAGIC c.estimated_monthly_dollar_dbus_dbsql,
# MAGIC c.estimated_monthly_dollar_dbus_uc,
# MAGIC d.`date`,
# MAGIC r.1st_line_manager,
# MAGIC r.account_id as redfish_account_id,
# MAGIC r.Account_Name as redfish_account_name,
# MAGIC r.databricks_bu,
# MAGIC r.databricks_sub_bu*/
# MAGIC from main.gtm_data.core_usecase_curated c
# MAGIC /*inner join main.gtm_partner_data.redfish_top_200 r
# MAGIC on c.account_id=r.account_id
# MAGIC left join main.it_core_dim.dim_dates d
# MAGIC on c.created_date=d.`date`*/
