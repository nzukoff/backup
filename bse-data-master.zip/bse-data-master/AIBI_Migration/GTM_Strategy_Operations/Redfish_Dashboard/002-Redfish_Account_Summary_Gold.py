# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.project_redfish_account_summary_gold as 
# MAGIC
# MAGIC SELECT 
# MAGIC   account_executive,
# MAGIC   bu,
# MAGIC   sub_bu,
# MAGIC   Databricks_Cloud_Sales_Manager,
# MAGIC   deployable_account_id,
# MAGIC   deployable_account_name,
# MAGIC   sales_manager,
# MAGIC   sfdc_account_id,
# MAGIC   sfdc_account_name,
# MAGIC   current_fy_estimated_monthly_dollar_dbus,
# MAGIC   current_fy_use_case_count,
# MAGIC   current_quarter_ae_forecast,
# MAGIC   current_quarter_non_genai_consumption,
# MAGIC   prior_quarter_non_genai_consumption,
# MAGIC   prior_year_current_quarter_non_gen_ai_dbu_dollars,
# MAGIC   prior_ytd_non_gen_ai_dbu_dollars,
# MAGIC   ytd_change_non_gen_ai_dbu_dollars,
# MAGIC   ytd_dbsql_dollars,
# MAGIC   ytd_non_genai_consumption,
# MAGIC   ytd_uc_dollars,
# MAGIC  
# MAGIC   ytd_dbsql_dollars / NULLIF(ytd_non_genai_consumption, 0) AS percent_dbsql_dollars,
# MAGIC   ytd_uc_dollars / NULLIF(ytd_non_genai_consumption, 0) AS percent_uc_dollars,
# MAGIC   (current_quarter_ae_forecast / NULLIF(prior_quarter_non_genai_consumption, 0)) - 1 AS forecast_qoq_percent_change,
# MAGIC   ytd_change_non_gen_ai_dbu_dollars / NULLIF(prior_ytd_non_gen_ai_dbu_dollars, 0) AS ytd_percent_change
# MAGIC FROM main.it_aibi_silver.project_redfish_account_summary_silver
