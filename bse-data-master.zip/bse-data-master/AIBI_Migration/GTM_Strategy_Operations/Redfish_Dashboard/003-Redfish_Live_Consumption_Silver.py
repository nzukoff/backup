# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.project_redfish_live_consumption_silver as
# MAGIC
# MAGIC SELECT
# MAGIC   sfdc_account_id,
# MAGIC   sfdc_account_name,
# MAGIC   region,
# MAGIC   bu,
# MAGIC   sub_bu,
# MAGIC   calendar_month,
# MAGIC   year,
# MAGIC   month_start_date,
# MAGIC   month_end_date,
# MAGIC   fiscal_qtr,
# MAGIC   fiscal_year,
# MAGIC   redfish_account,
# MAGIC   deployable_redfish_account,
# MAGIC   deployable_t500,
# MAGIC   t500,
# MAGIC   exclude_current_month,
# MAGIC   total_azure_consumption,
# MAGIC   non_genai_consumption,
# MAGIC   uc_dollars,
# MAGIC   dbsql_dollars,
# MAGIC   sql_serverless_dollars,
# MAGIC   sql_classic_dollars,
# MAGIC   serverless_dollars,
# MAGIC   classic_dollars,
# MAGIC   current_fytd_consumption,
# MAGIC   prior_fytd_consumption,
# MAGIC   current_fytd_dbsql_consumption,
# MAGIC   prior_fytd_dbsql_consumption,
# MAGIC   current_fytd_uc_consumption,
# MAGIC   prior_fytd_uc_consumption
# MAGIC FROM main.gtm_partner_data.project_redfish_live_consumption 
