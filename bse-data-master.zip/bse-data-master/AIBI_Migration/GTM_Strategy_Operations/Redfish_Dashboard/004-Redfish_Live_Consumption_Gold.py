# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.project_redfish_live_consumption_gold
# MAGIC
# MAGIC
# MAGIC SELECT 
# MAGIC   bu,
# MAGIC   sub_bu,
# MAGIC   deployable_t500,
# MAGIC   month_end_date,
# MAGIC   month_start_date,
# MAGIC   redfish_account,
# MAGIC   sfdc_account_id,
# MAGIC   t500,
# MAGIC   total_azure_consumption,
# MAGIC   -- New columns
# MAGIC   SUM(dbsql_dollars) OVER (PARTITION BY sfdc_account_id) / NULLIF(SUM(total_azure_consumption) OVER (PARTITION BY sfdc_account_id), 0) AS percent_dbsql,
# MAGIC   SUM(uc_dollars) OVER (PARTITION BY sfdc_account_id) / NULLIF(SUM(total_azure_consumption) OVER (PARTITION BY sfdc_account_id), 0) AS percent_unity_catalog
# MAGIC FROM main.it_aibi_silver.project_redfish_live_consumption_silver
# MAGIC
# MAGIC
