# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.feokrs_target_run_rate_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT
# MAGIC     account_name,
# MAGIC     account_id,
# MAGIC     account_executive,
# MAGIC     account_status,
# MAGIC     customer_start_date,
# MAGIC     has_snowflake_migration,
# MAGIC     last_solution_architect_engaged,
# MAGIC     partner_sales_manager,
# MAGIC     sa_manager,
# MAGIC     sales_leader,
# MAGIC     sales_manager,
# MAGIC     _bu_plus1,
# MAGIC     sales_subregion_level_2,
# MAGIC     sales_subregion_level_3,
# MAGIC     support_tier,
# MAGIC     vertical,
# MAGIC     rank_global,
# MAGIC     rank_bu,
# MAGIC     rank_bu_plus1,
# MAGIC     contract_num,
# MAGIC     contract_start_quarter,
# MAGIC     current_risk_classification,
# MAGIC     fiscal_year_month,
# MAGIC     is_active,
# MAGIC     max_date,
# MAGIC     metric_qualified,
# MAGIC     risk_classification,
# MAGIC     startdate,
# MAGIC     usage_date_month_start,
# MAGIC     dbu_dollars,
# MAGIC     contract_commit,
# MAGIC     term_months,
# MAGIC     current_month,
# MAGIC     dbu_dollars_total,
# MAGIC     target_run_rate,
# MAGIC     term_month_okr,
# MAGIC     trr_attainment,
# MAGIC     trr_risk_threshold,
# MAGIC     bu,
# MAGIC     DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 AS Cust_Age_years,
# MAGIC     CASE
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 < 1 THEN 0
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 < 2 THEN 1
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 < 3 THEN 2
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 < 4 THEN 3
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 < 5 THEN 4
# MAGIC       WHEN DATEDIFF(day, customer_start_date, CURRENT_DATE()) / 365.0 >= 5 THEN 5
# MAGIC     END AS Cust_Age_Buckets,
# MAGIC     CASE WHEN risk_classification = 'Not at Risk' THEN 1 ELSE 0 END AS Contract_Periods_Reached_Threshold,
# MAGIC     'Global' AS Global_Region
# MAGIC   FROM main.it_aibi_silver.feokrs_target_run_rate_silver
# MAGIC )
# MAGIC SELECT 
# MAGIC   *,
# MAGIC   SUM(CASE WHEN trr_attainment >= trr_risk_threshold THEN target_run_rate ELSE 0 END) OVER () / SUM(target_run_rate) OVER () AS Attainment_Percentage_Dollars,
# MAGIC   SUM(Contract_Periods_Reached_Threshold) OVER () / COUNT(*) OVER () AS Attainment_Percentage_Contract_Periods,
# MAGIC   SUM(CASE WHEN trr_attainment >= trr_risk_threshold THEN target_run_rate ELSE 0 END) OVER () AS Dollars_Meeting_Threshold,
# MAGIC   0 AS Filler,
# MAGIC   COUNT(*) OVER () AS Total_Contract_Periods
# MAGIC FROM base_data
