# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.feokrs_target_run_rate_silver
# MAGIC
# MAGIC WITH base as (
# MAGIC WITH trr_accounts as (
# MAGIC   SELECT  
# MAGIC   account_id
# MAGIC   FROM main.gtm_data.gtm_okr_fy25__trr_new_customers__detail
# MAGIC   GROUP BY 1
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC  a.customer_type as customer_type
# MAGIC ,a.account_id as account_id
# MAGIC ,a.customer_start_date as customer_start_date
# MAGIC ,a.customer_age_years as age_years
# MAGIC -- ,FLOOR(date_diff(current_date(),customer_start_date) / 365) as  as age_years
# MAGIC ,a.sales_region
# MAGIC -- ,CASE WHEN sales_region = 'LATAM' THEN 'AMER' ELSE sales_region END as  as sales_region
# MAGIC ,DATE_DIFF(current_date(),a.next_renewal_date)  as days_to_renewal
# MAGIC ,a.account_executive as account_executive
# MAGIC ,a.account_name as account_name
# MAGIC ,a.account_status
# MAGIC ,b.commit_amount_bucket
# MAGIC ,b.commit_fc_burn_bucket as commit_fc_burn_bucket
# MAGIC ,a.dsa as customer_success_engineer
# MAGIC ,a.cse_tier as customer_success_engineer_tier
# MAGIC ,a.dsa_leader as customer_success_leader
# MAGIC ,b.dbu_dollars_delta_30d_pct_of_total as dbu_dollars_delta_30d_pct_of_total
# MAGIC ,b.dbu_dollars_sql_30d_pct_of_total
# MAGIC ,b.dbu_dollars_t3m_annualized_bucket
# MAGIC ,a.t3m_annualized/4 as dbu_dollars_t3m
# MAGIC ,a.t3m_annualized as dbu_dollars_t3m_annualized
# MAGIC ,b.fc_growth_pct_qoq_ds_bucket as fc_growth_pct_qoq_ds_bucket
# MAGIC ,a.has_cloud_migration as has_cloud_migration
# MAGIC ,a.has_hadoop_migration as has_hadoop_migration
# MAGIC ,a.has_snowflake_migration as has_snowflake_migration
# MAGIC ,b.is_pvc_pubsec
# MAGIC ,b.lakehouse_score
# MAGIC ,b.lakehouse_score_bucket
# MAGIC ,b.lakehouse_score_growth_bucket
# MAGIC ,a.last_solution_architect_engaged
# MAGIC ,a.partner_sales_manager
# MAGIC ,a.sales_leader
# MAGIC ,a.sales_manager
# MAGIC ,a.sales_subregion_level_1
# MAGIC ,a.sales_subregion_level_2
# MAGIC ,a.sales_subregion_level_3
# MAGIC ,a.scp_status
# MAGIC ,a.support_tier
# MAGIC ,b.unused_success_credit_bucket
# MAGIC ,a.vertical 
# MAGIC ,b.wau_bucket
# MAGIC ,a.brag_status
# MAGIC ,a.business_unit
# MAGIC ,b.fc_growth_pct_qoq_ae_bucket
# MAGIC ,b.ds_forecast_cq
# MAGIC ,b.ae_forecast_cq
# MAGIC ,b.ds_forecast_cq_pct_change
# MAGIC ,b.ds_forecast_cq_as_of_quarter_start
# MAGIC ,b.DS_AE_fcst_diff
# MAGIC ,a.sa_manager
# MAGIC ,a.consumption_commit_business_unit_rank as rank_bu
# MAGIC ,a.consumption_commit_sales_subregion_level_1_rank rank_bu_plus1
# MAGIC ,a.consumption_commit_global_rank as rank_global
# MAGIC FROM main.gtm_data.core_accounts_curated a
# MAGIC LEFT JOIN main.gtm_data.customer_portfolio_account_list b ON b.account_id = a.account_id 
# MAGIC JOIN trr_accounts c on c.account_id = a.account_id 
# MAGIC WHERE 1=1
# MAGIC ),
# MAGIC
# MAGIC commit as (SELECT 
# MAGIC *
# MAGIC FROM main.gtm_data.gtm_okr_fy25__trr_new_customers__dashboard_detail)
# MAGIC
# MAGIC SELECT 
# MAGIC     b.account_name,
# MAGIC     b.account_id,
# MAGIC     b.account_executive,
# MAGIC     b.account_status,
# MAGIC     b.customer_start_date,
# MAGIC     b.has_snowflake_migration,
# MAGIC     b.last_solution_architect_engaged,
# MAGIC     b.partner_sales_manager,
# MAGIC     b.sa_manager,
# MAGIC     b.sales_leader,
# MAGIC     b.sales_manager,
# MAGIC     b.sales_subregion_level_1 as _bu_plus1,
# MAGIC     b.sales_subregion_level_2,
# MAGIC     b.sales_subregion_level_3,
# MAGIC     b.support_tier,
# MAGIC     b.vertical,
# MAGIC     b.rank_global,
# MAGIC     b.rank_bu,
# MAGIC     b.rank_bu_plus1,
# MAGIC     c.contract_number as contract_num,
# MAGIC     c.commit_customer_start_date_month_start as contract_start_quarter,
# MAGIC     c.current_risk_classification,
# MAGIC     c.usage_date_fiscal_year_month as fiscal_year_month,
# MAGIC     c.is_active_contract as is_active,
# MAGIC     c.max_date,
# MAGIC     c.metric_qualified,
# MAGIC     c.risk_classification,
# MAGIC     c.startdate,
# MAGIC     c.usage_date_month_start,
# MAGIC     c.dbu_dollars,
# MAGIC     c.RevShareCommit as contract_commit,
# MAGIC     c.term_months,
# MAGIC     c.current_month,
# MAGIC     c.dbu_dollars_total,
# MAGIC     c.target_run_rate,
# MAGIC     c.term_month_okr,
# MAGIC     c.target_run_rate_attainment as trr_attainment,
# MAGIC     c.trr_at_risk_thresholds as trr_risk_threshold,
# MAGIC     b.business_unit as bu
# MAGIC FROM 
# MAGIC     base b
# MAGIC FULL JOIN 
# MAGIC     commit c
# MAGIC ON 
# MAGIC     b.account_id = c.account_id
# MAGIC
