# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE  main.it_aibi_gold.databricks_events_3p_events_gold as
# MAGIC
# MAGIC SELECT 
# MAGIC   account_business_unit,
# MAGIC   account_dbx,
# MAGIC   account_industry,
# MAGIC   account_owner_name,
# MAGIC   account_sales_region,
# MAGIC   audience_custom_audience_persona,
# MAGIC   audience_leadstatus,
# MAGIC   campaign_id,
# MAGIC   campaign_name,
# MAGIC   date,
# MAGIC   engagement_channel_type,
# MAGIC   engagement_sfdc_campaign_start_date,
# MAGIC   event_category,
# MAGIC   event_name,
# MAGIC   engagement,
# MAGIC   mql_unit,
# MAGIC   nnn_unit,
# MAGIC   u2_amount,
# MAGIC   u2_unit,
# MAGIC CASE
# MAGIC     WHEN campaign_name = 'FY25-EE-MWC' OR campaign_id = '' THEN 'MWC 2024'
# MAGIC     WHEN campaign_name = 'FY250226-EV-MWCExecDinner' OR campaign_id = '701Vp000000lKy3IAE' THEN 'MWC 2024'
# MAGIC     WHEN campaign_name = 'FY250311-EV-GartnerDA-Orlando' OR campaign_id = '701Vp000000lI1KIAU' THEN 'Gartner Data & Analytics Summit 2024'
# MAGIC     WHEN campaign_name = 'FY25-EE-Gartner D&A-Mini Briefing' OR campaign_id = '701Vp000002ZhsFIAS' THEN 'Gartner Data & Analytics Summit 2024'
# MAGIC     WHEN campaign_name = 'FY25-EE-Gartner D&A-Sales Meeting' OR campaign_id = '701Vp000002ZyWhIAK' THEN 'Gartner Data & Analytics Summit 2024'
# MAGIC     WHEN campaign_name = 'FY25-EE-Gartner D&A-Social Request' OR campaign_id = '701Vp000002jHI7IAM' THEN 'Gartner Data & Analytics Summit 2024'
# MAGIC     WHEN campaign_name = 'FY250311-EV-HIMSS2024-Orlando' OR campaign_id = '701Vp000000lKxmIAE' THEN 'HIMSS 2024'
# MAGIC     WHEN campaign_name = 'FY250312-EV-HIMSS-ExecutiveRoundtable' OR campaign_id = '701Vp000002jF0JIAU' THEN 'HIMSS 2024'
# MAGIC     WHEN campaign_name = 'FY250312-EV-HIMSS-NetworkingEvent' OR campaign_id = '701Vp000002jOUrIAM' THEN 'HIMSS 2024'
# MAGIC     WHEN campaign_name = 'FY25-EE-HIMSS-Mini Briefing' OR campaign_id = '701Vp000002V1WXIA0' THEN 'HIMSS 2024'
# MAGIC     WHEN campaign_name = 'FY25-EE-HIMSS-Sales Meeting' OR campaign_id = '701Vp000002V1oHIAS' THEN 'HIMSS 2024'
# MAGIC     WHEN campaign_name = 'FY25-EE-HIMSS-Partner Meeting' OR campaign_id = '701Vp000002V2NlIAK' THEN 'HIMSS 2024'
# MAGIC     WHEN campaign_name = 'FY25-EE-HIMSS-Social Request' OR campaign_id = '701Vp000002j5FRIAY' THEN 'HIMSS 2024'
# MAGIC     WHEN campaign_name = 'FY250318-EV-GDC2024-SF' OR campaign_id = '701Vp000000lI1LIAU' THEN 'GDC 2024'
# MAGIC     WHEN campaign_name = 'FY25-EE-GDC-Sales Meeting' OR campaign_id = '701Vp000002x74RIAQ' THEN 'GDC 2024'
# MAGIC     WHEN campaign_name = 'FY25-EE-GDC-Partner Meeting' OR campaign_id = '701Vp000002x3FPIAY' THEN 'GDC 2024'
# MAGIC     WHEN campaign_name = 'FY25-EE-GDC-Social Request' OR campaign_id = '701Vp000002xHTXIA2' THEN 'GDC 2024'
# MAGIC     WHEN campaign_name = 'FY250326-EV-MSFTDataAI2024-LasVegas' OR campaign_id = '701Vp000000lKy2IAE' THEN 'Fabric Conference 2024'
# MAGIC     WHEN campaign_name = 'FY250409-EV-GoogleCloudNext2024-LasVegas' OR campaign_id = '701Vp000001jDJpIAM' THEN 'Google Cloud Next 2024'
# MAGIC     WHEN campaign_name = 'FY250429-EV-AMER-TableauConference-SanDiego' OR campaign_id = '701Vp000004UrshIAC' THEN 'Tableau Conference 2024'
# MAGIC     WHEN campaign_name = 'FY250721-EV-SEEMEAICML2024-Vienna' OR campaign_id = '701Vp000003vRkcIAE' THEN 'ICML 2024'
# MAGIC     WHEN campaign_name = 'FY25 H2' OR campaign_id = '' THEN ''
# MAGIC     WHEN campaign_name = 'FY251021-EV-GartnerITSymposium/Xpo' OR campaign_id = '701Vp000004gxXnIAI' THEN 'Gartner IT 2024'
# MAGIC     WHEN campaign_name = 'FY251021-EV-GartnerITSymposium/Xpo-Reception' OR campaign_id = '701Vp000004gxXoIAI' THEN 'Gartner IT 2024'
# MAGIC     WHEN campaign_name = 'FY251021-EV-GartnerITSymposium/Xpo-TheatreSession' OR campaign_id = '701Vp000004gxXpIAI' THEN 'Gartner IT 2024'
# MAGIC     WHEN campaign_name = 'FY251027-EV-Money2020' OR campaign_id = '701Vp000004gxXfIAI' THEN 'Money 20/20 2024'
# MAGIC     WHEN campaign_name = 'FY251118-EV-MicrosoftIgnite' OR campaign_id = '701Vp000004gxXgIAI' THEN 'Microsoft Ignite 2024'
# MAGIC     WHEN campaign_name = 'FY251202-EV-AWSre:Invent' OR campaign_id = '701Vp000004gxXhIAI' THEN 'AWS re:Invent 2024'
# MAGIC     WHEN campaign_name = 'FY251202-EV-AWSre:Invent-ExecutiveRoundtable' OR campaign_id = '701Vp000004gxYjIAI' THEN 'AWS re:Invent 2024'
# MAGIC     WHEN campaign_name = 'FY251209-EV-NeurIPS' OR campaign_id = '701Vp000004gxXiIAI' THEN 'NeurIPS 2024'
# MAGIC     WHEN campaign_name = 'FY250112-EV-NRF' OR campaign_id = '701Vp000004gxXjIAI' THEN 'NRF 2025'
# MAGIC     WHEN campaign_name = '202303-Global-Sponsored-Gartner-Data-and-Analytics-Summit' OR campaign_id = '' THEN 'Gartner Data & Analytics Summit 2023'
# MAGIC     WHEN campaign_name = '202304-NORAM-Sponsored-MDScon-Fivetran' OR campaign_id = '' THEN 'Fivetran MDSCon 2023'
# MAGIC     WHEN campaign_name = '202304-Global-Sponsored-HIMSS' OR campaign_id = '' THEN 'HIMSS 2023'
# MAGIC     WHEN campaign_name = '202304-AMER-Sponsored-HIMSS-2023-Pre-Event-Meetings-List' OR campaign_id = '' THEN 'HIMSS 2023'
# MAGIC     WHEN campaign_name = '202304-AMER-Sponsored-HIMSS23-Databricks-Executive-Happy-Hour' OR campaign_id = '' THEN 'HIMSS 2023'
# MAGIC     WHEN campaign_name = '202304-AMER-Sponsored-Qlik-World-2023' OR campaign_id = '' THEN 'Qlik World 2023'
# MAGIC     WHEN campaign_name = '202305-Global-Sponsored-Tableau Conference' OR campaign_id = '' THEN 'Tableau Conference 2023'
# MAGIC     WHEN campaign_name = '202305-Global-Sponsored-Alteryx-Inspire' OR campaign_id = '' THEN 'Alteryx Inspire 2023'
# MAGIC     WHEN campaign_name = 'FY24-SE-GoogleCloudNext' OR campaign_id = '7018Y0000017MbYQAU' THEN 'Google Cloud Next 2023'
# MAGIC     WHEN campaign_name = 'FY24-SE-DataikuConference' OR campaign_id = '7018Y0000017MXJQA2' THEN 'Dataiku 2023'
# MAGIC     WHEN campaign_name = 'FY24-SE-dbtCoalesce' OR campaign_id = '7018Y0000017N1EQAU' THEN 'dbt Coalesce 2023'
# MAGIC     WHEN campaign_name = 'FY2410/16-SE-GartnerITSymposium/Xpo' OR campaign_id = '7018Y00000146uRQAQ' THEN 'Gartner IT 2023'
# MAGIC     WHEN campaign_name = 'FY241016-SE-GartnerITSymposium/XpoBoothVisits' OR campaign_id = '7018Y000001470aQAA' THEN 'Gartner IT 2023'
# MAGIC     WHEN campaign_name = 'FY241018-SE-GartnerITSymposium/XpoTheaterSessionScans' OR campaign_id = '7018Y000001470bQAA' THEN 'Gartner IT 2023'
# MAGIC     WHEN campaign_name = 'FY241018-SE-GartnerITSymposium/XpoPubSec+RegulatedIndustriesReception' OR campaign_id = '7018Y000001470cQAA' THEN 'Gartner IT 2023'
# MAGIC     WHEN campaign_name = 'FY24-EE-Gartner-Mini Briefing' OR campaign_id = '7018Y00000146LcQAI' THEN 'Gartner IT 2023'
# MAGIC     WHEN campaign_name = 'FY24Q3-SE-Money2020-2017' OR campaign_id = '7018Y0000017N32QAE' THEN 'Money 20/20 2023'
# MAGIC     WHEN campaign_name = 'FY24Q3-FE-Money2020AncillaryEvent-1731' OR campaign_id = '7018Y0000017N34QAE' THEN 'Money 20/20 2023'
# MAGIC     WHEN campaign_name = 'FY241024-FE-Money2020ExecutiveBreakfast-Las Vegas Money 2020' OR campaign_id = '7018Y00000146uUQAQ' THEN 'Money 20/20 2023'
# MAGIC     WHEN campaign_name = 'FY24-EE-Money 20/20-Sales Meeting' OR campaign_id = '7018Y000001465uQAA' THEN 'Money 20/20 2023'
# MAGIC     WHEN campaign_name = 'FY24-EE-Money 20/20-Mini Briefing' OR campaign_id = '7018Y000001465tQAA' THEN 'Money 20/20 2023'
# MAGIC     WHEN campaign_name = 'FY241101-SE-MicrosoftIgnite' OR campaign_id = '7018Y00000146hCQAQ' THEN 'Microsoft Ignite 2023'
# MAGIC     WHEN campaign_name = 'FY241101-SE-AWSre:Invent' OR campaign_id = '7018Y00000146gDQAQ' THEN 'AWS re:Invent 2023'
# MAGIC     WHEN campaign_name = 'FY241101-SE-AWSre:Invent-Events' OR campaign_id = '7018Y00000146jRQAQ' THEN 'AWS re:Invent 2023'
# MAGIC     WHEN campaign_name = 'FY24-EE-AWS re:Invent-Mini Briefing' OR campaign_id = '7018Y00000146ULQAY' THEN 'AWS re:Invent 2023'
# MAGIC     WHEN campaign_name = 'FY24-EE-AWS re:Invent-Sales Meeting' OR campaign_id = '7018Y00000146UHQAY' THEN 'AWS re:Invent 2023'
# MAGIC     WHEN campaign_name = 'FY24-EE-AWS re:Invent-Partner Meeting' OR campaign_id = '7018Y00000146UQQAY' THEN 'AWS re:Invent 2023'
# MAGIC     WHEN campaign_name = 'FY241129-FE-AWSreInventGSE+DNB-Dinner' OR campaign_id = '7018Y00000147DzQAI' THEN 'AWS re:Invent 2023'
# MAGIC     WHEN campaign_name = 'FY241129-FE-AWSre:Invent-CMEExecutiveDinner' OR campaign_id = '7018Y00000146g9QAA' THEN 'AWS re:Invent 2023'
# MAGIC     WHEN campaign_name = 'FY241127-SE-AWS-ReInvent-Q4-MDF-KR-Megazone' OR campaign_id = '7018Y000001f7dLQAQ' THEN 'AWS re:Invent 2023'
# MAGIC     WHEN campaign_name = 'FY241101-FE-FSExecDinneratAWSreInvent' OR campaign_id = '7018Y00000146gEQAQ' THEN 'AWS re:Invent 2023'
# MAGIC     WHEN campaign_name = 'FY241129-FE-MFGExecutiveDinneratAWSre:invent' OR campaign_id = '7018Y00000146h3QAA' THEN 'AWS re:Invent 2023'
# MAGIC     WHEN campaign_name = 'FY240101-SE-NRF' OR campaign_id = '7018Y00000146nFQAQ' THEN 'NRF 2024'
# MAGIC     WHEN campaign_name = 'FY24-EE-NRF-Mini Briefing' OR campaign_id = '7018Y00000146UaQAI' THEN 'NRF 2024'
# MAGIC     WHEN campaign_name = 'FY24-EE-NRF-Sales Meeting' OR campaign_id = '7018Y00000146UfQAI' THEN 'NRF 2024'
# MAGIC     WHEN campaign_name = 'FY24-EE-NRF-Partner Meeting' OR campaign_id = '7018Y00000146UkQAI' THEN 'NRF 2024'
# MAGIC     WHEN campaign_name = 'FY240101-FE-NRF2024ExecutiveReception' OR campaign_id = '7018Y00000146msQAA' THEN 'NRF 2024'
# MAGIC WHEN campaign_name = '202109-US-EV-MDSCON' OR campaign_id = '202109-US-EV-MDSCON' THEN 'MDSCON'
# MAGIC WHEN campaign_name = '202110-US-EV-Google Cloud Next' OR campaign_id = '202110-US-EV-Google Cloud Next' THEN 'Google Cloud Next'
# MAGIC WHEN campaign_name = '202111-Global-Sponsored-AWS-reinvent-BoothScans' OR campaign_id = '202111-Global-Sponsored-AWS-reinvent-BoothScans' THEN 'AWS Reinvent'
# MAGIC WHEN campaign_name = '202202-Global-Sponsored-AWS SKO' OR campaign_id = '202202-Global-Sponsored-AWS SKO' THEN 'AWS SKO'
# MAGIC WHEN campaign_name = '202204-Global-Sponsored-Google Data Cloud Summit' OR campaign_id = '202204-Global-Sponsored-Google Data Cloud Summit' THEN 'Google Data Cloud Summit'
# MAGIC WHEN campaign_name = '202205-Global-Sponsored-Tableau Conference' OR campaign_id = '202205-Global-Sponsored-Tableau Conference' THEN 'Tableau Conference'
# MAGIC WHEN campaign_name = '202205-Global-Sponsored-ThoughtSpot Beyond' OR campaign_id = '202205-Global-Sponsored-ThoughtSpot Beyond' THEN 'ThoughtSpot Beyond'
# MAGIC WHEN campaign_name = '202208-Global-Sponsored-Gartner-Data-&-Analytics-Summit---Booth-Scans' OR campaign_id = '202208-Global-Sponsored-Gartner-Data-&-Analytics-Summit---Booth-Scans' THEN 'Gartner Data & Analytics Summit'
# MAGIC WHEN campaign_name = '202210-Global-Sponsored-Confluent-Current' OR campaign_id = '202210-Global-Sponsored-Confluent-Current' THEN 'Confluent'
# MAGIC WHEN campaign_name = '202210-Global-Sponsored-Google-Cloud-Next-' OR campaign_id = '202210-Global-Sponsored-Google-Cloud-Next-' THEN 'Google Cloud Next'
# MAGIC WHEN campaign_name = '202210-Global-Sponsored-Microsoft-Ignite' OR campaign_id = '202210-Global-Sponsored-Microsoft-Ignite' THEN 'Microsoft Ignite'
# MAGIC WHEN campaign_name = '202211-Global-Sponsored-AWS-reinvent' OR campaign_id = '202211-Global-Sponsored-AWS-reinvent' THEN 'AWS Reinvent'
# MAGIC WHEN campaign_name = '202301-Global-Sponsored-NRF' OR campaign_id = '202301-Global-Sponsored-NRF' THEN 'NRF'
# MAGIC WHEN campaign_name = '202210-NORAM-Sponsored-dbt-Coalesce-Parent' OR campaign_id = '202210-NORAM-Sponsored-dbt-Coalesce-Parent' THEN 'dbt Coalesce'
# MAGIC WHEN campaign_name = '202111-Global-Sponsored-AWS-reinvent-Party' OR campaign_id = '202111-Global-Sponsored-AWS-reinvent-Party' THEN 'AWS Reinvent'
# MAGIC WHEN campaign_name = '202111-Global-Sponsored-AWS-reinvent-Sessions' OR campaign_id = '202111-Global-Sponsored-AWS-reinvent-Sessions' THEN 'AWS Reinvent'
# MAGIC WHEN campaign_name = '202111-Global-Sponsored-AWS-reinvent-SlalomEvent' OR campaign_id = '202111-Global-Sponsored-AWS-reinvent-SlalomEvent' THEN 'AWS Reinvent'
# MAGIC WHEN campaign_name = '202205-Global-Sponsored-Tableau-Conference-Guaranteed-Leads' OR campaign_id = '202205-Global-Sponsored-Tableau-Conference-Guaranteed-Leads' THEN 'Tableau Conference'
# MAGIC WHEN campaign_name = '202205-Global-Sponsored-Tableau-Conference-Virtual-Session' OR campaign_id = '202205-Global-Sponsored-Tableau-Conference-Virtual-Session' THEN 'Tableau Conference'
# MAGIC WHEN campaign_name = '202205-Global-Sponsored-In-Person-Session' OR campaign_id = '202205-Global-Sponsored-In-Person-Session' THEN 'ThoughtSpot Beyond'
# MAGIC WHEN campaign_name = '202205-Global-Sponsored-Session' OR campaign_id = '202205-Global-Sponsored-Session' THEN 'ThoughtSpot Beyond'
# MAGIC WHEN campaign_name = '202208-Global-Sponsored-Gartner-Data-&-Analytics-Summit---Session' OR campaign_id = '202208-Global-Sponsored-Gartner-Data-&-Analytics-Summit---Session' THEN 'Gartner Data & Analytics Summit'
# MAGIC WHEN campaign_name = '202211-Global-Sponsored-AWS-reinvent-party' OR campaign_id = '202211-Global-Sponsored-AWS-reinvent-party' THEN 'AWS Reinvent'
# MAGIC WHEN campaign_name = '202211-Global-Sponsored-AWS-reinvent-slalom-party' OR campaign_id = '202211-Global-Sponsored-AWS-reinvent-slalom-party' THEN 'AWS Reinvent'
# MAGIC WHEN campaign_name = '202212-AMER-ABM-Retail BDR-Sendoso-NRF Canada Mailer' OR campaign_id = '202212-AMER-ABM-Retail BDR-Sendoso-NRF Canada Mailer' THEN 'NRF'
# MAGIC WHEN campaign_name = '202212-AMER-ABM-Retail BDR-Sendoso-NRF Mailer' OR campaign_id = '202212-AMER-ABM-Retail BDR-Sendoso-NRF Mailer' THEN 'NRF'
# MAGIC WHEN campaign_name = '202301-AMER-FE-NRF-Executive-Networking-Reception-with-Databricks' OR campaign_id = '202301-AMER-FE-NRF-Executive-Networking-Reception-with-Databricks' THEN 'NRF'
# MAGIC WHEN campaign_name = '202301-Global-Sponsored-NRF-2023---ZoomInfo-Supplemental-List' OR campaign_id = '202301-Global-Sponsored-NRF-2023---ZoomInfo-Supplemental-List' THEN 'NRF'
# MAGIC WHEN campaign_name = '202301-Global-Sponsored-NRF-2023-Center-Booth-Activation-Coffee-and-Tech-Bar' OR campaign_id = '202301-Global-Sponsored-NRF-2023-Center-Booth-Activation-Coffee-and-Tech-Bar' THEN 'NRF'
# MAGIC WHEN campaign_name = '202301-Global-Sponsored-NRF-2023-Databricks-Booth-Theater' OR campaign_id = '202301-Global-Sponsored-NRF-2023-Databricks-Booth-Theater' THEN 'NRF'
# MAGIC WHEN campaign_name = '202301-Global-Sponsored-NRF-2023-Demo-Pods' OR campaign_id = '202301-Global-Sponsored-NRF-2023-Demo-Pods' THEN 'NRF'
# MAGIC WHEN campaign_name = '202301-Global-Sponsored-NRF-2023-Offsite-Customer-Meetings' OR campaign_id = '202301-Global-Sponsored-NRF-2023-Offsite-Customer-Meetings' THEN 'NRF'
# MAGIC WHEN campaign_name = '202301-Global-Sponsored-NRF-2023-Partner-Influenced-Customer-Deal-Meetings' OR campaign_id = '202301-Global-Sponsored-NRF-2023-Partner-Influenced-Customer-Deal-Meetings' THEN 'NRF'
# MAGIC WHEN campaign_name = '202301-Global-Sponsored-NRF-2023-Sales-Meetings-and-EBCs' OR campaign_id = '202301-Global-Sponsored-NRF-2023-Sales-Meetings-and-EBCs' THEN 'NRF'
# MAGIC WHEN campaign_name = '202301-Global-Sponsored-NRF-2023-Welcome-Desk' OR campaign_id = '202301-Global-Sponsored-NRF-2023-Welcome-Desk' THEN 'NRF'
# MAGIC WHEN campaign_name = '202303-Global-WB-The-Lakehouse-for-Retail-NRF' OR campaign_id = '202303-Global-WB-The-Lakehouse-for-Retail-NRF' THEN 'NRF'
# MAGIC WHEN campaign_name = '202210-NORAM-Sponsored-dbt-Coalesce-Activation-Hall' OR campaign_id = '202210-NORAM-Sponsored-dbt-Coalesce-Activation-Hall' THEN ''
# MAGIC WHEN campaign_name = '202210-NORAM-Sponsored-dbt-Coalesce-opt-in-list' OR campaign_id = '202210-NORAM-Sponsored-dbt-Coalesce-opt-in-list' THEN ''
# MAGIC WHEN campaign_name = '202210-NORAM-Sponsored-dbt-Coalesce-Party' OR campaign_id = '202210-NORAM-Sponsored-dbt-Coalesce-Party' THEN ''
# MAGIC WHEN campaign_name = '202210-NORAM-Sponsored-dbt-Coalesce-Session-Scans' OR campaign_id = '202210-NORAM-Sponsored-dbt-Coalesce-Session-Scans' THEN ''
# MAGIC WHEN campaign_name = '202210-NORAM-Sponsored-dbt-Coalesce-Trial' OR campaign_id = '202210-NORAM-Sponsored-dbt-Coalesce-Trial' THEN ''
# MAGIC WHEN campaign_name = '202210-NORAM-Sponsored-dbt-Coalesce-Workshop-Scans' OR campaign_id = '202210-NORAM-Sponsored-dbt-Coalesce-Workshop-Scans' THEN ''
# MAGIC ELSE event_category END as Event_Name_Parent,
# MAGIC
# MAGIC CASE
# MAGIC     WHEN campaign_name = 'FY25-EE-MWC' OR campaign_id = '' THEN 30000
# MAGIC     WHEN campaign_name = 'FY250226-EV-MWCExecDinner' OR campaign_id = '701Vp000000lKy3IAE' THEN NULL
# MAGIC     WHEN campaign_name = 'FY250311-EV-GartnerDA-Orlando' OR campaign_id = '701Vp000000lI1KIAU' THEN 359603.77
# MAGIC     WHEN campaign_name = 'FY25-EE-Gartner D&A-Mini Briefing' OR campaign_id = '701Vp000002ZhsFIAS' THEN 359603.77
# MAGIC     WHEN campaign_name = 'FY25-EE-Gartner D&A-Sales Meeting' OR campaign_id = '701Vp000002ZyWhIAK' THEN 359603.77
# MAGIC     WHEN campaign_name = 'FY25-EE-Gartner D&A-Social Request' OR campaign_id = '701Vp000002jHI7IAM' THEN 359603.77
# MAGIC     WHEN campaign_name = 'FY250311-EV-HIMSS2024-Orlando' OR campaign_id = '701Vp000000lKxmIAE' THEN 391348.53
# MAGIC     WHEN campaign_name = 'FY250312-EV-HIMSS-ExecutiveRoundtable' OR campaign_id = '701Vp000002jF0JIAU' THEN 391348.53
# MAGIC     WHEN campaign_name = 'FY250312-EV-HIMSS-NetworkingEvent' OR campaign_id = '701Vp000002jOUrIAM' THEN 391348.53
# MAGIC     WHEN campaign_name = 'FY25-EE-HIMSS-Mini Briefing' OR campaign_id = '701Vp000002V1WXIA0' THEN 391348.53
# MAGIC     WHEN campaign_name = 'FY25-EE-HIMSS-Sales Meeting' OR campaign_id = '701Vp000002V1oHIAS' THEN 391348.53
# MAGIC     WHEN campaign_name = 'FY25-EE-HIMSS-Partner Meeting' OR campaign_id = '701Vp000002V2NlIAK' THEN 391348.53
# MAGIC     WHEN campaign_name = 'FY25-EE-HIMSS-Social Request' OR campaign_id = '701Vp000002j5FRIAY' THEN 391348.53
# MAGIC     WHEN campaign_name = 'FY250318-EV-GDC2024-SF' OR campaign_id = '701Vp000000lI1LIAU' THEN 68710.84
# MAGIC     WHEN campaign_name = 'FY25-EE-GDC-Sales Meeting' OR campaign_id = '701Vp000002x74RIAQ' THEN 68710.84
# MAGIC     WHEN campaign_name = 'FY25-EE-GDC-Partner Meeting' OR campaign_id = '701Vp000002x3FPIAY' THEN 68710.84
# MAGIC     WHEN campaign_name = 'FY25-EE-GDC-Social Request' OR campaign_id = '701Vp000002xHTXIA2' THEN 68710.84
# MAGIC     WHEN campaign_name = 'FY250326-EV-MSFTDataAI2024-LasVegas' OR campaign_id = '701Vp000000lKy2IAE' THEN 125147.73
# MAGIC     WHEN campaign_name = 'FY250409-EV-GoogleCloudNext2024-LasVegas' OR campaign_id = '701Vp000001jDJpIAM' THEN 284235.88
# MAGIC     WHEN campaign_name = 'FY250429-EV-AMER-TableauConference-SanDiego' OR campaign_id = '701Vp000004UrshIAC' THEN 122667.3
# MAGIC     WHEN campaign_name = 'FY250721-EV-SEEMEAICML2024-Vienna' OR campaign_id = '701Vp000003vRkcIAE' THEN 30797.15
# MAGIC     WHEN campaign_name = '202303-Global-Sponsored-Gartner-Data-and-Analytics-Summit' OR campaign_id = 'null' THEN 359882.3
# MAGIC     WHEN campaign_name = '202304-NORAM-Sponsored-MDScon-Fivetran' OR campaign_id = 'null' THEN 21091.2
# MAGIC     WHEN campaign_name = '202304-Global-Sponsored-HIMSS' OR campaign_id = 'null' THEN 358116.65
# MAGIC     WHEN campaign_name = '202304-AMER-Sponsored-Qlik-World-2023' OR campaign_id = 'null' THEN 18663.99
# MAGIC     WHEN campaign_name = '202305-Global-Sponsored-Tableau Conference' OR campaign_id = 'null' THEN 110916.2
# MAGIC     WHEN campaign_name = '202305-Global-Sponsored-Alteryx-Inspire' OR campaign_id = 'null' THEN 59438.23
# MAGIC     WHEN campaign_name = 'FY24-SE-GoogleCloudNext' OR campaign_id = '7018Y0000017MbYQAU' THEN 119997.62
# MAGIC     WHEN campaign_name = 'FY24-SE-DataikuConference' OR campaign_id = '7018Y0000017MXJQA2' THEN 39800
# MAGIC     WHEN campaign_name = 'FY24-SE-dbtCoalesce' OR campaign_id = '7018Y0000017N1EQAU' THEN 171894.15
# MAGIC     WHEN campaign_name = 'FY2410/16-SE-GartnerITSymposium/Xpo' OR campaign_id = '7018Y00000146uRQAQ' THEN 356377.6
# MAGIC     WHEN campaign_name = 'FY24Q3-SE-Money2020-2017' OR campaign_id = '7018Y0000017N32QAE' THEN 196664.83
# MAGIC     WHEN campaign_name = 'FY241101-SE-MicrosoftIgnite' OR campaign_id = '7018Y00000146hCQAQ' THEN 167100
# MAGIC     WHEN campaign_name = 'FY241101-SE-AWSre:Invent' OR campaign_id = '7018Y00000146gDQAQ' THEN 1240018.78
# MAGIC     WHEN campaign_name = 'FY240101-SE-NRF' OR campaign_id = '7018Y00000146nFQAQ' THEN 325000
# MAGIC     WHEN campaign_name = '202109-US-EV-MDSCON' THEN 12000
# MAGIC     WHEN campaign_name = '202110-US-EV-Google Cloud Next' THEN 90000
# MAGIC     WHEN campaign_name = '202111-Global-Sponsored-AWS-reinvent-BoothScans' THEN 857396.94
# MAGIC     WHEN campaign_name = '202202-Global-Sponsored-AWS SKO' THEN 52000
# MAGIC     WHEN campaign_name = '202204-Global-Sponsored-Google Data Cloud Summit' THEN 35000
# MAGIC     WHEN campaign_name = '202205-Global-Sponsored-Tableau Conference' THEN 65000
# MAGIC     WHEN campaign_name = '202205-Global-Sponsored-ThoughtSpot Beyond' THEN 60250
# MAGIC     WHEN campaign_name = '202208-Global-Sponsored-Gartner-Data-&-Analytics-Summit---Booth-Scans' THEN 302105
# MAGIC     WHEN campaign_name = '202210-Global-Sponsored-Confluent-Current' THEN 107119.75
# MAGIC     WHEN campaign_name = '202210-Global-Sponsored-Google-Cloud-Next-' THEN 51500
# MAGIC     WHEN campaign_name = '202210-Global-Sponsored-Microsoft-Ignite' THEN 109747.89
# MAGIC     WHEN campaign_name = '202211-Global-Sponsored-AWS-reinvent' THEN 1039915.56
# MAGIC     WHEN campaign_name = '202301-Global-Sponsored-NRF' THEN 593312.13
# MAGIC     WHEN campaign_name = '202210-NORAM-Sponsored-dbt-Coalesce-Parent' THEN 172405
# MAGIC     ELSE NULL
# MAGIC END as 3P_Event_Spend,
# MAGIC
# MAGIC CASE
# MAGIC     WHEN event_name IN ('HIMMS 2024 - Mini Briefing', 'HIMMS 2024 - Partner Meeting',
# MAGIC                         'HIMMS 2024 - Sales Meeting', 'HIMMS 2024 - Social Request')
# MAGIC     THEN DATE('2024-03-12')
# MAGIC     ELSE engagement_sfdc_campaign_start_date
# MAGIC   END AS engagement_sfdc_campaign_start_date_fy
# MAGIC
# MAGIC FROM main.it_aibi_silver.databricks_events_3p_events_silver 
# MAGIC

# COMMAND ----------



# COMMAND ----------


