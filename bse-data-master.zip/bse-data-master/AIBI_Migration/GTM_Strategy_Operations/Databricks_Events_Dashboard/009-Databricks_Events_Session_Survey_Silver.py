# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.databricks_events_session_survey_silver as
# MAGIC
# MAGIC with attendees as (
# MAGIC   select 
# MAGIC   rf_attendee_id,
# MAGIC   event_name,
# MAGIC   attended_event,
# MAGIC   attendee_company,
# MAGIC   attendee_type,
# MAGIC   sf_business_unit,
# MAGIC   rf_rainfocus_event_attendee_id,
# MAGIC   rainfocus_event_name
# MAGIC   from main.marketing_lakehouse.event_attendee_detail_table
# MAGIC ),
# MAGIC
# MAGIC rainfocus as (
# MAGIC   select 
# MAGIC   attendee_id,
# MAGIC   audience_persona,
# MAGIC   event_name as event_name_rainfocus,
# MAGIC   session_code,
# MAGIC   session_speakers,
# MAGIC   session_title,
# MAGIC   session_type,
# MAGIC   track,
# MAGIC   sum(session_attended) as session_attended,
# MAGIC   sum(session_registered) as session_registered
# MAGIC   from main.marketing_lakehouse.gold_rainfocus_session
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC master_sessions as (
# MAGIC   select 
# MAGIC   `date`,
# MAGIC   industry,
# MAGIC   event_name as event_name1,
# MAGIC   technologies,
# MAGIC   venue,
# MAGIC   code,
# MAGIC   room,
# MAGIC   level,
# MAGIC   start_time,
# MAGIC   session_type as session_type1,
# MAGIC   track as track_1,
# MAGIC   sponsor_session,
# MAGIC   sum(try_cast(`#_of_scheduled_attendees` as double)) as num_of_scheduled_attendees
# MAGIC   from main.it_aibi_bronze.rainfocus_master_sessions_report
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC master_session_survey as (
# MAGIC   select 
# MAGIC   event_name_survey,
# MAGIC   session_code as session_code_survey,
# MAGIC   attendee_id as attendee_id1,
# MAGIC   `time`,
# MAGIC   submission_id,
# MAGIC   sum(try_cast(please_rate_the_overall_quality_of_the_materials as double)) as please_rate_the_overall_quality_of_the_materials,
# MAGIC   sum(try_cast(please_rate_the_overall_quality_of_the_session as double)) as please_rate_the_overall_quality_of_the_session,
# MAGIC   sum(try_cast(`how_likely_is_it_that_you_would_recommend_this_session_to_a_friend_or_colleague?` as double)) as how_likely_is_it_that_you_would_recommend_this_session_to_a_friend_or_colleague,
# MAGIC   `do_you_have_any_additional_feedback?` as do_you_have_any_additional_feedback
# MAGIC   from main.it_aibi_bronze.dais24_rawdata
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC master_speaker_survey as (
# MAGIC   select 
# MAGIC   session_title as session_title_master_speaker,
# MAGIC   attendee_id as attendee_id_master_speaker,
# MAGIC   sum(try_cast(please_rate_the_overall_quality_of_the_speaker as double)) as please_rate_the_overall_quality_of_the_speaker,
# MAGIC   speaker_name,
# MAGIC   'Data + AI Summit 2024' as event_name_master_speaker_survey
# MAGIC   from main.it_aibi_bronze.dais24_speaker_specific
# MAGIC   group by all
# MAGIC )
# MAGIC
# MAGIC select *
# MAGIC from attendees a 
# MAGIC left join rainfocus r on a.rf_attendee_id=r.attendee_id and a.rainfocus_event_name=r.event_name_rainfocus
# MAGIC left join master_sessions ms on r.event_name_rainfocus=ms.event_name1 and r.session_code=ms.code
# MAGIC left join master_session_survey mses on r.event_name_rainfocus=mses.event_name_survey and r.session_code=mses.session_code_survey and r.attendee_id=mses.attendee_id1
# MAGIC left join master_speaker_survey msps on r.session_title=msps.session_title_master_speaker and r.event_name_rainfocus=msps.event_name_master_speaker_survey and r.attendee_id=msps.attendee_id_master_speaker
