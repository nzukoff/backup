# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.databricks_events_di_days_silver
# MAGIC
# MAGIC
# MAGIC with attendees as (
# MAGIC   select 
# MAGIC   attendee_account_name,
# MAGIC   attendee_account_status,
# MAGIC   attendee_company,
# MAGIC   attended_event,
# MAGIC   event_category,
# MAGIC   event_name,
# MAGIC   sf_account_name,
# MAGIC   sf_company,
# MAGIC   sf_lead_contact_status,
# MAGIC   sf_lead_or_contact_id,
# MAGIC   sf_member_industry,
# MAGIC   sf_member_channel,
# MAGIC   sf_is_dbx_account,
# MAGIC   sf_dbx_account_type,
# MAGIC   sf_account_owner_name,
# MAGIC   sf_program_name
# MAGIC   from main.marketing_lakehouse.event_attendee_detail_table
# MAGIC ),
# MAGIC
# MAGIC performance as (
# MAGIC   select 
# MAGIC   account_record_type,
# MAGIC   audience_primary_lead_or_contact_id,
# MAGIC   engagement_program_name,
# MAGIC   engagement_tactic_name,
# MAGIC   usecase_name,
# MAGIC   usecase_id,
# MAGIC   usecase_owner,
# MAGIC   u1_stage_date,
# MAGIC   u2_stage_date,
# MAGIC   u3_stage_date,
# MAGIC   engagement_channel_type,
# MAGIC   sum(u1_unit) as u1_unit,
# MAGIC   sum(u1_amount) as u1_amount,
# MAGIC   sum(u2_unit) as u2_unit,
# MAGIC   sum(u2_amount) as u2_amount,
# MAGIC   sum(u3_unit) as u3_unit,
# MAGIC   sum(u3_amount) as u3_amount,
# MAGIC   sum(mql_unit) as mql_unit
# MAGIC   from main.marketing_lakehouse.rpt_mpd_performance_deep_dive_event
# MAGIC   group by all
# MAGIC )
# MAGIC
# MAGIC select *
# MAGIC from attendees a 
# MAGIC left join performance p on a.sf_program_name=p.engagement_program_name and a.sf_lead_or_contact_id=p.audience_primary_lead_or_contact_id
