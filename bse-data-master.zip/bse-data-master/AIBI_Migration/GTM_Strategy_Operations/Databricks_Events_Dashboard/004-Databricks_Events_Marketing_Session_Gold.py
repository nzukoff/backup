# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.databricks_events_marketing_session_gold
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     rf_attendee_id,
# MAGIC     attendee_event_name,
# MAGIC     attended_event,
# MAGIC     attendee_company,
# MAGIC     sf_business_unit,
# MAGIC     sf_bu_plus_1,
# MAGIC     sf_bu_plus_2,
# MAGIC     sf_bu_plus_3,
# MAGIC     sf_databricks_vertical,
# MAGIC     sf_account_name,
# MAGIC     sf_is_dbx_account,
# MAGIC     sf_dbx_account_type,
# MAGIC     sf_account_owner_name,
# MAGIC     sf_parent_account_ae_owner,
# MAGIC     sf_account_ae_owner_manager,
# MAGIC     sf_account_sdr,
# MAGIC     sf_company,
# MAGIC     sf_lead_contact_status,
# MAGIC     sf_lightning_url,
# MAGIC     sf_member_audience_persona,
# MAGIC     sf_member_full_name,
# MAGIC     sf_member_job_title,
# MAGIC     sf_city,
# MAGIC     sf_member_channel,
# MAGIC     rf_partner,
# MAGIC     rf_attendee_type,
# MAGIC     rf_rainfocus_event_attendee_id,
# MAGIC     rainfocus_event_name,
# MAGIC     rf_total_free_training_registered,
# MAGIC     rf_total_free_training_attended,
# MAGIC     rf_total_session_attended,
# MAGIC     rf_total_session_registered,
# MAGIC     rf_total_paid_training_attended,
# MAGIC     rf_total_paid_training_registered,
# MAGIC     attendee_id,
# MAGIC     partner_type,
# MAGIC     attendee_category,
# MAGIC     event_name_rainfocus,
# MAGIC     session_code,
# MAGIC     session_title,
# MAGIC     session_type,
# MAGIC     scheduled_date,
# MAGIC     track,
# MAGIC     free_training_attended,
# MAGIC     free_training_registered,
# MAGIC     session_attended,
# MAGIC     session_registered,
# MAGIC     paid_training_attended,
# MAGIC     paid_training_registered,
# MAGIC     event_name1,
# MAGIC     code,
# MAGIC     start_time,
# MAGIC     end_time,
# MAGIC     public_session_for_website,
# MAGIC     session_type1,
# MAGIC     hash_of_scheduled_attendees,
# MAGIC     capacity,
# MAGIC     date,
# MAGIC     CASE 
# MAGIC       WHEN LOWER(session_type1) NOT IN ('keynote', 'special interest') 
# MAGIC       THEN FALSE 
# MAGIC       ELSE TRUE 
# MAGIC     END AS keynote_evening_private_session,
# MAGIC     CASE 
# MAGIC       WHEN LOWER(attendee_company) LIKE '%databricks%' OR LOWER(attendee_company) LIKE '%test%' 
# MAGIC       THEN TRUE 
# MAGIC       ELSE FALSE 
# MAGIC     END AS databricks_employee
# MAGIC   FROM main.it_aibi_silver.databricks_events_marketing_session_silver
# MAGIC ),
# MAGIC distinct_counts AS (
# MAGIC   SELECT
# MAGIC     COUNT(DISTINCT CASE WHEN attended_event THEN rf_rainfocus_event_attendee_id END) AS rainfocus_attendees,
# MAGIC     COUNT(DISTINCT rf_rainfocus_event_attendee_id) AS rainfocus_registrants,
# MAGIC     COUNT(DISTINCT CASE WHEN rf_total_session_registered > 0 THEN rf_rainfocus_event_attendee_id END) AS rf_unique_session_registered,
# MAGIC     COUNT(DISTINCT CASE WHEN rf_total_session_registered > 0 AND NOT keynote_evening_private_session THEN rf_rainfocus_event_attendee_id END) AS rf_unique_session_builder_registered,
# MAGIC     COUNT(DISTINCT CASE WHEN hash_of_scheduled_attendees >= capacity THEN code END) AS total_session_builder_full_sessions,
# MAGIC     COUNT(DISTINCT CASE WHEN NOT keynote_evening_private_session THEN code END) AS total_session_builder_sessions,
# MAGIC     COUNT(DISTINCT CASE WHEN rf_total_session_attended > 0 THEN rf_rainfocus_event_attendee_id END) AS rf_unique_session_attended,
# MAGIC     COUNT(DISTINCT CASE WHEN rf_total_paid_training_attended > 0 THEN rf_rainfocus_event_attendee_id END) AS rf_unique_paid_training_attended,
# MAGIC     COUNT(DISTINCT CASE WHEN rf_total_paid_training_registered > 0 THEN rf_rainfocus_event_attendee_id END) AS rf_unique_paid_training_registered,
# MAGIC     COUNT(DISTINCT CASE WHEN sf_is_dbx_account AND attended_event THEN sf_account_name END) AS rf_unique_attended_dbx,
# MAGIC     COUNT(DISTINCT CASE WHEN sf_is_dbx_account THEN sf_account_name END) AS rf_unique_registered_dbx,
# MAGIC     COUNT(DISTINCT CASE WHEN rf_total_session_registered > 0 AND sf_is_dbx_account THEN sf_account_name END) AS rf_unique_session_registered_dbx,
# MAGIC     COUNT(DISTINCT CASE WHEN rf_total_session_attended > 0 AND sf_is_dbx_account THEN sf_account_name END) AS rf_unique_session_attended_dbx,
# MAGIC     COUNT(DISTINCT CASE WHEN rf_total_paid_training_attended > 0 AND sf_is_dbx_account THEN sf_account_name END) AS rf_unique_paid_training_attended_dbx,
# MAGIC     COUNT(DISTINCT CASE WHEN rf_total_paid_training_registered > 0 AND sf_is_dbx_account THEN sf_account_name END) AS rf_unique_paid_training_registered_dbx
# MAGIC   FROM base_data
# MAGIC ),
# MAGIC attended_dais_2023 AS (
# MAGIC   SELECT
# MAGIC     rf_attendee_id,
# MAGIC     CASE 
# MAGIC       WHEN COUNT(DISTINCT CASE 
# MAGIC                    WHEN rainfocus_event_name = 'Data + AI Summit 2023' AND attended_event = TRUE 
# MAGIC                    THEN rf_attendee_id 
# MAGIC                  END) > 0
# MAGIC       THEN 1
# MAGIC       ELSE 0
# MAGIC     END AS attended_dais_2023_flag
# MAGIC   FROM base_data
# MAGIC   GROUP BY rf_attendee_id
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   base_data.*,
# MAGIC   SUM(CASE WHEN NOT keynote_evening_private_session THEN session_registered ELSE 0 END) OVER () AS session_builder_total_sessions,
# MAGIC   distinct_counts.rainfocus_attendees,
# MAGIC   distinct_counts.rainfocus_registrants,
# MAGIC   distinct_counts.rf_unique_session_registered,
# MAGIC   distinct_counts.rf_unique_session_builder_registered,
# MAGIC   SUM(CASE WHEN NOT keynote_evening_private_session THEN capacity ELSE 0 END) OVER (PARTITION BY event_name1) AS session_builder_room_capacity,
# MAGIC   SUM(CASE WHEN NOT keynote_evening_private_session THEN hash_of_scheduled_attendees ELSE 0 END) OVER (PARTITION BY event_name1) AS session_builder_room_attendance,
# MAGIC   distinct_counts.total_session_builder_full_sessions,
# MAGIC   distinct_counts.total_session_builder_sessions,
# MAGIC   MIN(CASE WHEN event_name_rainfocus = 'Data + AI Summit 2024' AND NOT keynote_evening_private_session AND LOWER(session_type) NOT LIKE '%training%' THEN scheduled_date END) OVER (PARTITION BY attendee_id) AS first_scheduled_date_session_builder,
# MAGIC   (unix_timestamp(to_timestamp(end_time, 'hh:mm a')) - unix_timestamp(to_timestamp(start_time, 'hh:mm a'))) / 60 AS duration_minutes,
# MAGIC   CASE WHEN rf_total_session_attended > 0 THEN TRUE ELSE FALSE END AS rf_session_attended,
# MAGIC   distinct_counts.rf_unique_session_attended,
# MAGIC   distinct_counts.rf_unique_paid_training_attended,
# MAGIC   distinct_counts.rf_unique_paid_training_registered,
# MAGIC   distinct_counts.rf_unique_attended_dbx,
# MAGIC   distinct_counts.rf_unique_registered_dbx,
# MAGIC   distinct_counts.rf_unique_session_registered_dbx,
# MAGIC   distinct_counts.rf_unique_session_attended_dbx,
# MAGIC   distinct_counts.rf_unique_paid_training_attended_dbx,
# MAGIC   distinct_counts.rf_unique_paid_training_registered_dbx,
# MAGIC
# MAGIC   CASE 
# MAGIC     WHEN distinct_counts.rf_unique_paid_training_registered > 0 
# MAGIC     THEN distinct_counts.rf_unique_paid_training_attended / distinct_counts.rf_unique_paid_training_registered 
# MAGIC     ELSE NULL 
# MAGIC   END AS rf_unique_paid_training_attendance_rate,
# MAGIC   CASE 
# MAGIC     WHEN distinct_counts.rf_unique_session_registered > 0 
# MAGIC     THEN distinct_counts.rf_unique_session_attended / distinct_counts.rf_unique_session_registered 
# MAGIC     ELSE NULL 
# MAGIC   END AS rf_unique_session_attendance_rate,
# MAGIC   CASE 
# MAGIC     WHEN distinct_counts.rf_unique_registered_dbx > 0 
# MAGIC     THEN distinct_counts.rf_unique_attended_dbx / distinct_counts.rf_unique_registered_dbx 
# MAGIC     ELSE NULL 
# MAGIC   END AS rf_unique_attendance_rate_dbx,
# MAGIC   CASE 
# MAGIC     WHEN distinct_counts.rf_unique_session_registered_dbx > 0 
# MAGIC     THEN distinct_counts.rf_unique_session_attended_dbx / distinct_counts.rf_unique_session_registered_dbx 
# MAGIC     ELSE NULL 
# MAGIC   END AS rf_unique_session_attendance_rate_dbx,
# MAGIC   CASE 
# MAGIC     WHEN distinct_counts.rf_unique_paid_training_registered_dbx > 0 
# MAGIC     THEN distinct_counts.rf_unique_paid_training_attended_dbx / distinct_counts.rf_unique_paid_training_registered_dbx 
# MAGIC     ELSE NULL 
# MAGIC   END AS rf_unique_paid_training_attendance_rate_dbx,
# MAGIC   ad.attended_dais_2023_flag
# MAGIC FROM base_data
# MAGIC CROSS JOIN distinct_counts
# MAGIC LEFT JOIN attended_dais_2023 ad ON base_data.rf_attendee_id = ad.rf_attendee_id

# COMMAND ----------

# %sql

# show columns in main.it_aibi_gold.databricks_events_marketing_session_gold

# COMMAND ----------

# %sql

# --CREATE OR REPLACE TABLE main.it_aibi_gold.databricks_events_marketing_session_gold
# WITH base_data AS (
#   SELECT 
#     rf_attendee_id,
#     attendee_event_name,
#     attended_event,
#     attendee_company,
#     sf_business_unit,
#     sf_bu_plus_1,
#     sf_bu_plus_2,
#     sf_bu_plus_3,
#     sf_databricks_vertical,
#     sf_account_name,
#     sf_is_dbx_account,
#     sf_dbx_account_type,
#     sf_account_owner_name,
#     sf_parent_account_ae_owner,
#     sf_account_ae_owner_manager,
#     sf_account_sdr,
#     sf_company,
#     sf_lead_contact_status,
#     sf_member_audience_persona,
#     sf_member_full_name,
#     sf_member_job_title,
#     sf_city,
#     sf_member_channel,
#     rf_partner,
#     rf_attendee_type,
#     rf_rainfocus_event_attendee_id,
#     rainfocus_event_name,
#     rf_total_session_attended,
#     rf_total_session_registered,
#     rf_total_paid_training_attended,
#     rf_total_paid_training_registered,
#     attendee_id,
#     partner_type,
#     attendee_category,
#     event_name_rainfocus,
#     session_code,
#     session_title,
#     session_type,
#     scheduled_date,
#     track,
#     session_attended,
#     session_registered,
#     paid_training_attended,
#     paid_training_registered,
#     event_name1,
#     code,
#     start_time,
#     end_time,
#     session_type1,
#     hash_of_scheduled_attendees,
#     capacity,
#     date,
#     CASE 
#       WHEN LOWER(session_type1) NOT IN ('keynote', 'special interest') 
#       THEN FALSE 
#       ELSE TRUE 
#     END AS keynote_evening_private_session,
#     CASE 
#       WHEN LOWER(attendee_company) LIKE '%databricks%' OR LOWER(attendee_company) LIKE '%test%' 
#       THEN TRUE 
#       ELSE FALSE 
#     END AS databricks_employee
#   FROM main.it_aibi_silver.databricks_events_marketing_session_silver
# ),
# distinct_counts AS (
#   SELECT
#     COUNT(DISTINCT CASE WHEN attended_event THEN rf_rainfocus_event_attendee_id END) AS rainfocus_attendees,
#     COUNT(DISTINCT rf_rainfocus_event_attendee_id) AS rainfocus_registrants,
#     COUNT(DISTINCT CASE WHEN rf_total_session_registered > 0 THEN rf_rainfocus_event_attendee_id END) AS rf_unique_session_registered,
#     COUNT(DISTINCT CASE WHEN rf_total_session_registered > 0 AND NOT keynote_evening_private_session THEN rf_rainfocus_event_attendee_id END) AS rf_unique_session_builder_registered,
#     COUNT(DISTINCT CASE WHEN hash_of_scheduled_attendees >= capacity THEN code END) AS total_session_builder_full_sessions,
#     COUNT(DISTINCT CASE WHEN NOT keynote_evening_private_session THEN code END) AS total_session_builder_sessions,
#     COUNT(DISTINCT CASE WHEN rf_total_session_attended > 0 THEN rf_rainfocus_event_attendee_id END) AS rf_unique_session_attended,
#     COUNT(DISTINCT CASE WHEN rf_total_paid_training_attended > 0 THEN rf_rainfocus_event_attendee_id END) AS rf_unique_paid_training_attended,
#     COUNT(DISTINCT CASE WHEN rf_total_paid_training_registered > 0 THEN rf_rainfocus_event_attendee_id END) AS rf_unique_paid_training_registered,
#     COUNT(DISTINCT CASE WHEN sf_is_dbx_account AND attended_event THEN sf_account_name END) AS rf_unique_attended_dbx,
#     COUNT(DISTINCT CASE WHEN sf_is_dbx_account THEN sf_account_name END) AS rf_unique_registered_dbx,
#     COUNT(DISTINCT CASE WHEN rf_total_session_registered > 0 AND sf_is_dbx_account THEN sf_account_name END) AS rf_unique_session_registered_dbx,
#     COUNT(DISTINCT CASE WHEN rf_total_session_attended > 0 AND sf_is_dbx_account THEN sf_account_name END) AS rf_unique_session_attended_dbx,
#     COUNT(DISTINCT CASE WHEN rf_total_paid_training_attended > 0 AND sf_is_dbx_account THEN sf_account_name END) AS rf_unique_paid_training_attended_dbx,
#     COUNT(DISTINCT CASE WHEN rf_total_paid_training_registered > 0 AND sf_is_dbx_account THEN sf_account_name END) AS rf_unique_paid_training_registered_dbx
#   FROM base_data
# ),

# attended_dais_2023 AS (
#   SELECT
#     rf_attendee_id,
#     CASE 
#       WHEN COUNT(DISTINCT CASE 
#                    WHEN rainfocus_event_name = 'Data + AI Summit 2023' AND attended_event = TRUE 
#                    THEN rf_attendee_id 
#                  END) > 0
#       THEN 1
#       ELSE 0
#     END AS attended_dais_2023_flag
#   FROM base_data
#   GROUP BY rf_attendee_id
# )

# SELECT 
#   base_data.*,
#   ad.attended_dais_2023_flag,
#   SUM(CASE WHEN NOT keynote_evening_private_session THEN session_registered ELSE 0 END) OVER () AS session_builder_total_sessions,
#   distinct_counts.rainfocus_attendees,
#   distinct_counts.rainfocus_registrants,
#   distinct_counts.rf_unique_session_registered,
#   distinct_counts.rf_unique_session_builder_registered,
#   SUM(CASE WHEN NOT keynote_evening_private_session THEN capacity ELSE 0 END) OVER (PARTITION BY event_name1) AS session_builder_room_capacity,
#   SUM(CASE WHEN NOT keynote_evening_private_session THEN hash_of_scheduled_attendees ELSE 0 END) OVER (PARTITION BY event_name1) AS session_builder_room_attendance,
#   distinct_counts.total_session_builder_full_sessions,
#   distinct_counts.total_session_builder_sessions,
#   MIN(CASE WHEN event_name_rainfocus = 'Data + AI Summit 2024' AND NOT keynote_evening_private_session AND LOWER(session_type) NOT LIKE '%training%' THEN scheduled_date END) OVER (PARTITION BY attendee_id) AS first_scheduled_date_session_builder,
#   (unix_timestamp(to_timestamp(end_time, 'hh:mm a')) - unix_timestamp(to_timestamp(start_time, 'hh:mm a'))) / 60 AS duration_minutes,
#   CASE WHEN rf_total_session_attended > 0 THEN TRUE ELSE FALSE END AS rf_session_attended,
#   distinct_counts.rf_unique_session_attended,
#   distinct_counts.rf_unique_paid_training_attended,
#   distinct_counts.rf_unique_paid_training_registered,
#   distinct_counts.rf_unique_attended_dbx,
#   distinct_counts.rf_unique_registered_dbx,
#   distinct_counts.rf_unique_session_registered_dbx,
#   distinct_counts.rf_unique_session_attended_dbx,
#   distinct_counts.rf_unique_paid_training_attended_dbx,
#   distinct_counts.rf_unique_paid_training_registered_dbx,

#   CASE 
#     WHEN distinct_counts.rf_unique_paid_training_registered > 0 
#     THEN distinct_counts.rf_unique_paid_training_attended / distinct_counts.rf_unique_paid_training_registered 
#     ELSE NULL 
#   END AS rf_unique_paid_training_attendance_rate,
#   CASE 
#     WHEN distinct_counts.rf_unique_session_registered > 0 
#     THEN distinct_counts.rf_unique_session_attended / distinct_counts.rf_unique_session_registered 
#     ELSE NULL 
#   END AS rf_unique_session_attendance_rate,
#   CASE 
#     WHEN distinct_counts.rf_unique_registered_dbx > 0 
#     THEN distinct_counts.rf_unique_attended_dbx / distinct_counts.rf_unique_registered_dbx 
#     ELSE NULL 
#   END AS rf_unique_attendance_rate_dbx,
#   CASE 
#     WHEN distinct_counts.rf_unique_session_registered_dbx > 0 
#     THEN distinct_counts.rf_unique_session_attended_dbx / distinct_counts.rf_unique_session_registered_dbx 
#     ELSE NULL 
#   END AS rf_unique_session_attendance_rate_dbx,
#   CASE 
#     WHEN distinct_counts.rf_unique_paid_training_registered_dbx > 0 
#     THEN distinct_counts.rf_unique_paid_training_attended_dbx / distinct_counts.rf_unique_paid_training_registered_dbx 
#     ELSE NULL 
#   END AS rf_unique_paid_training_attendance_rate_dbx
# FROM base_data, distinct_counts
