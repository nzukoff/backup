# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.databricks_events_3p_events_silver
# MAGIC
# MAGIC select 
# MAGIC account_business_unit,
# MAGIC account_dbx,
# MAGIC account_industry,
# MAGIC account_owner_name,
# MAGIC account_sales_region,
# MAGIC audience_custom_audience_persona,
# MAGIC audience_leadstatus,
# MAGIC campaign_id,
# MAGIC campaign_name,
# MAGIC `date`,
# MAGIC engagement_channel_type,
# MAGIC engagement_sfdc_campaign_start_date,
# MAGIC event_category,
# MAGIC event_name,
# MAGIC sum(engagement) as engagement,
# MAGIC sum(mql_unit) as mql_unit,
# MAGIC sum(nnn_unit) as nnn_unit,
# MAGIC sum(u2_amount) as u2_amount,
# MAGIC sum(u2_unit) as u2_unit
# MAGIC from main.marketing_lakehouse.rpt_mpd_performance_deep_dive_3p
# MAGIC group by all
