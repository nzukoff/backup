# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.databricks_events_session_survey_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     date,
# MAGIC     rf_attendee_id,
# MAGIC     event_name,
# MAGIC     attended_event,
# MAGIC     attendee_company,
# MAGIC     attendee_type,
# MAGIC     sf_business_unit,
# MAGIC     rf_rainfocus_event_attendee_id,
# MAGIC     rainfocus_event_name,
# MAGIC     attendee_id,
# MAGIC     audience_persona,
# MAGIC     event_name_rainfocus,
# MAGIC     session_code,
# MAGIC     session_speakers,
# MAGIC     session_title,
# MAGIC     session_type,
# MAGIC     track,
# MAGIC     session_attended,
# MAGIC     session_registered,
# MAGIC     industry,
# MAGIC     event_name1,
# MAGIC     technologies,
# MAGIC     venue,
# MAGIC     code,
# MAGIC     room,
# MAGIC     level,
# MAGIC     start_time,
# MAGIC     session_type1,
# MAGIC     track_1,
# MAGIC     sponsor_session,
# MAGIC     num_of_scheduled_attendees,
# MAGIC     event_name_survey,
# MAGIC     session_code_survey,
# MAGIC     attendee_id1,
# MAGIC     time,
# MAGIC     submission_id,
# MAGIC     please_rate_the_overall_quality_of_the_materials,
# MAGIC     please_rate_the_overall_quality_of_the_session,
# MAGIC     how_likely_is_it_that_you_would_recommend_this_session_to_a_friend_or_colleague,
# MAGIC     do_you_have_any_additional_feedback,
# MAGIC     session_title_master_speaker,
# MAGIC     attendee_id_master_speaker,
# MAGIC     please_rate_the_overall_quality_of_the_speaker,
# MAGIC     speaker_name,
# MAGIC     event_name_master_speaker_survey 
# MAGIC   FROM main.it_aibi_silver.databricks_events_session_survey_silver 
# MAGIC ),
# MAGIC calculated_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     CASE 
# MAGIC       WHEN LOWER(attendee_company) LIKE '%databricks%' OR LOWER(attendee_company) LIKE '%test%' 
# MAGIC       THEN TRUE 
# MAGIC       ELSE FALSE 
# MAGIC     END AS databricks_employee,
# MAGIC     TO_TIMESTAMP(start_time, 'hh:mm a') AS start_time_parsed,
# MAGIC     COALESCE(sponsor_session, 'false') AS is_sponsor_session,
# MAGIC     CASE 
# MAGIC       WHEN how_likely_is_it_that_you_would_recommend_this_session_to_a_friend_or_colleague <= 6 THEN 'Detractor'
# MAGIC       WHEN how_likely_is_it_that_you_would_recommend_this_session_to_a_friend_or_colleague <= 8 THEN 'Passive'
# MAGIC       WHEN how_likely_is_it_that_you_would_recommend_this_session_to_a_friend_or_colleague <= 10 THEN 'Promoter'
# MAGIC       ELSE NULL 
# MAGIC     END AS nps_category,
# MAGIC     session_registered - session_attended AS session_attrition,
# MAGIC     CASE 
# MAGIC       WHEN session_type1 IN ('Keynote', 'Special Interest') THEN TRUE
# MAGIC       ELSE FALSE 
# MAGIC     END AS exclude_keynote_evening_private,
# MAGIC     TRIM(SPLIT(track_1, ',')[0]) AS session_track
# MAGIC   FROM base_data
# MAGIC ),
# MAGIC distinct_counts AS (
# MAGIC   SELECT
# MAGIC     COUNT(DISTINCT session_title) AS total_sessions,
# MAGIC     COUNT(DISTINCT CASE WHEN nps_category = 'Promoter' THEN submission_id END) AS nps_promoters,
# MAGIC     COUNT(DISTINCT CASE WHEN nps_category = 'Detractor' THEN submission_id END) AS nps_detractors,
# MAGIC     COUNT(DISTINCT submission_id) AS total_submissions,
# MAGIC     COUNT(DISTINCT attendee_id1) AS unique_survey_submissions,
# MAGIC     COUNT(DISTINCT CASE WHEN attended_event = TRUE THEN rf_rainfocus_event_attendee_id END) AS rainfocus_attendees,
# MAGIC     COUNT(DISTINCT rf_rainfocus_event_attendee_id) AS rainfocus_registrants,
# MAGIC     SUM(CASE WHEN session_attended > 0 AND session_type IN ('Breakout Session', 'Lightning Talk', 'Deep Dive') THEN session_attended ELSE 0 END) AS rf_sessions_attended_breakout_lightning_deep_dive,
# MAGIC     COUNT(DISTINCT CASE WHEN session_attended > 0 AND session_type IN ('Breakout Session', 'Lightning Talk', 'Deep Dive') THEN rf_rainfocus_event_attendee_id END) AS rf_unique_attendees_breakout_lightning_deep_dive
# MAGIC   FROM calculated_data
# MAGIC ),
# MAGIC aggregated_data AS (
# MAGIC   SELECT 
# MAGIC     cd.*,
# MAGIC     dc.total_sessions,
# MAGIC     dc.nps_promoters,
# MAGIC     dc.nps_detractors,
# MAGIC     dc.total_submissions,
# MAGIC     dc.unique_survey_submissions,
# MAGIC     dc.rainfocus_attendees,
# MAGIC     dc.rainfocus_registrants,
# MAGIC     dc.rf_sessions_attended_breakout_lightning_deep_dive,
# MAGIC     dc.rf_unique_attendees_breakout_lightning_deep_dive,
# MAGIC     SUM(CASE WHEN NOT exclude_keynote_evening_private THEN num_of_scheduled_attendees ELSE 0 END) OVER (PARTITION BY event_name1) AS session_builder_room_attendance,
# MAGIC     SUM(CASE WHEN NOT exclude_keynote_evening_private THEN num_of_scheduled_attendees ELSE 0 END) OVER (PARTITION BY event_name1) AS session_builder_room_capacity
# MAGIC   FROM calculated_data cd
# MAGIC   CROSS JOIN distinct_counts dc
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   *,
# MAGIC   (nps_promoters - nps_detractors) / NULLIF(total_submissions, 0) * 100 AS nps_score,
# MAGIC   session_attrition / NULLIF(session_registered, 0) AS session_attrition_percent,
# MAGIC   session_builder_room_attendance / NULLIF(session_builder_room_capacity, 0) AS session_room_capacity_percent,
# MAGIC   rf_unique_attendees_breakout_lightning_deep_dive / NULLIF(rainfocus_attendees, 0) AS percent_attended_sessions,
# MAGIC   rf_sessions_attended_breakout_lightning_deep_dive / NULLIF(rainfocus_attendees, 0) AS avg_sessions_attended
# MAGIC FROM aggregated_data
