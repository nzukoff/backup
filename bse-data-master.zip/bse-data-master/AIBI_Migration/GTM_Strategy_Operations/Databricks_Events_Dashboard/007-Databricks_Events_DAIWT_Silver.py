# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.databricks_events_daiwt_silver as
# MAGIC
# MAGIC with attendee as (
# MAGIC   select 
# MAGIC   account_bu_plus_1,
# MAGIC   account_bu_plus_2,
# MAGIC   account_bu_plus_3,
# MAGIC   account_dbx,
# MAGIC   account_industry,
# MAGIC   account_last_sa_engaged,
# MAGIC   account_owner_manager,
# MAGIC   account_owner_name,
# MAGIC   account_owner_sdr_name,
# MAGIC   account_partner_type,
# MAGIC   attendee_account_id,
# MAGIC   attendee_account_status,
# MAGIC   attendee_audience_persona,
# MAGIC   attendee_business_unit,
# MAGIC   attendee_status,
# MAGIC   campaign_id,
# MAGIC   event_category,
# MAGIC   event_name,
# MAGIC   first_name,
# MAGIC   last_name,
# MAGIC   lead_or_contact_id,
# MAGIC   lead_status,
# MAGIC   parent_account_owner_name,
# MAGIC   registration_date,
# MAGIC   sum(try_cast(registered as double)) as registered,
# MAGIC   sum(try_cast(attended as double)) as attended,
# MAGIC   sum(try_cast(mql_unit as double)) as mql_unit,
# MAGIC   sum(try_cast(u1_unit as double)) as u1_unit,
# MAGIC   sum(try_cast(u2_unit as double)) as u2_unit,
# MAGIC   sum(try_cast(u3_unit as double)) as u3_unit,
# MAGIC   sum(try_cast(u2_amount as double)) as u2_amount
# MAGIC   from main.marketing_lakehouse.event_attendee_detail_v1
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC targets as (
# MAGIC   select 
# MAGIC   salesforce_campaign_id,
# MAGIC   sum(try_cast(target_attendees_overall as double)) as target_attendees_overall,
# MAGIC   sum(try_cast(target_registrants_overall as double)) as target_registrants_overall,
# MAGIC   sum(try_cast(target_u2_overall as double)) as target_u2_overall,
# MAGIC   sum(try_cast(target_db3000_reg as double)) as target_db3000_reg,
# MAGIC   sum(try_cast(target_poi_overall as double)) as target_poi_overall,
# MAGIC   sum(try_cast(2024_net_investment as double)) as 2024_net_investment
# MAGIC   from main.it_aibi_bronze.targets_overall
# MAGIC   group by all
# MAGIC )
# MAGIC
# MAGIC select * from attendee a 
# MAGIC left join targets t on a.campaign_id=t.salesforce_campaign_id
