# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.databricks_events_marketing_session_silver
# MAGIC
# MAGIC with attendees as (
# MAGIC   select 
# MAGIC   rf_attendee_id, 
# MAGIC   event_name as attendee_event_name,
# MAGIC   attended_event,
# MAGIC   attendee_company,
# MAGIC   sf_business_unit,
# MAGIC   sf_bu_plus_1,
# MAGIC   sf_bu_plus_2,
# MAGIC   sf_bu_plus_3,
# MAGIC   sf_databricks_vertical,
# MAGIC   sf_account_name,
# MAGIC   sf_is_dbx_account,
# MAGIC   sf_dbx_account_type,
# MAGIC   sf_account_owner_name,
# MAGIC   sf_parent_account_ae_owner,
# MAGIC   sf_account_ae_owner_manager, 
# MAGIC   sf_account_sdr,
# MAGIC   sf_company,
# MAGIC   sf_lead_contact_status,
# MAGIC   sf_lightning_url,
# MAGIC   sf_member_audience_persona,
# MAGIC   sf_member_full_name,
# MAGIC   sf_member_job_title,
# MAGIC   sf_city,
# MAGIC   sf_member_channel,
# MAGIC   rf_partner,
# MAGIC   rf_attendee_type,
# MAGIC   rf_rainfocus_event_attendee_id,
# MAGIC   rainfocus_event_name, 
# MAGIC   sum(rf_total_session_attended) as rf_total_session_attended,
# MAGIC   sum(rf_total_session_registered) as rf_total_session_registered,
# MAGIC   sum(rf_total_paid_training_attended) as rf_total_paid_training_attended,
# MAGIC   sum(rf_total_paid_training_registered) as rf_total_paid_training_registered,
# MAGIC   sum(rf_total_free_training_attended) as rf_total_free_training_attended,
# MAGIC   sum(rf_total_free_training_registered) as rf_total_free_training_registered
# MAGIC   from main.marketing_lakehouse.event_attendee_detail_table
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC rainfocus as (
# MAGIC   select 
# MAGIC   attendee_id, 
# MAGIC   partner_type,
# MAGIC   attendee_category, 
# MAGIC   event_name as event_name_rainfocus, 
# MAGIC   session_code,
# MAGIC   session_title,
# MAGIC   session_type,
# MAGIC   scheduled_date,
# MAGIC   track,
# MAGIC   sum(free_training_attended) as free_training_attended,
# MAGIC   sum(free_training_registered) as free_training_registered,
# MAGIC   sum(session_attended) as session_attended,
# MAGIC   sum(session_registered) as session_registered,
# MAGIC   sum(paid_training_attended) as paid_training_attended,
# MAGIC   sum(paid_training_registered) as paid_training_registered
# MAGIC   from main.marketing_lakehouse.gold_rainfocus_session
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC master_sessions as (
# MAGIC   select 
# MAGIC   event_name as event_name1,
# MAGIC   code, 
# MAGIC   start_time,
# MAGIC   end_time,
# MAGIC   public_session_for_website,
# MAGIC   session_type as session_type1,
# MAGIC   `#_of_scheduled_attendees` as hash_of_scheduled_attendees,
# MAGIC   capacity,
# MAGIC   `date`
# MAGIC   from main.it_aibi_bronze.rainfocus_master_sessions_report
# MAGIC   group by all
# MAGIC )
# MAGIC
# MAGIC select *
# MAGIC from attendees a 
# MAGIC left join rainfocus r on a.rf_attendee_id=r.attendee_id and a.rainfocus_event_name=r.event_name_rainfocus
# MAGIC left join master_sessions ms on r.event_name_rainfocus=ms.event_name1 and r.session_code=ms.code
