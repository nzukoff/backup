# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.databricks_events_daiwt_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     account_bu_plus_1,
# MAGIC     account_bu_plus_2,
# MAGIC     account_bu_plus_3,
# MAGIC     account_dbx,
# MAGIC     account_industry,
# MAGIC     account_last_sa_engaged,
# MAGIC     account_owner_manager,
# MAGIC     account_owner_name,
# MAGIC     account_owner_sdr_name,
# MAGIC     account_partner_type,
# MAGIC     attendee_account_id,
# MAGIC     attendee_account_status,
# MAGIC     attendee_audience_persona,
# MAGIC     attendee_business_unit,
# MAGIC     attendee_status,
# MAGIC     campaign_id,
# MAGIC     event_category,
# MAGIC     event_name,
# MAGIC     first_name,
# MAGIC     last_name,
# MAGIC     lead_or_contact_id,
# MAGIC     lead_status,
# MAGIC     parent_account_owner_name,
# MAGIC     registration_date,
# MAGIC     registered,
# MAGIC     attended,
# MAGIC     mql_unit,
# MAGIC     u1_unit,
# MAGIC     u2_unit,
# MAGIC     u3_unit,
# MAGIC     u2_amount,
# MAGIC     salesforce_campaign_id,
# MAGIC     target_attendees_overall,
# MAGIC     target_registrants_overall,
# MAGIC     target_u2_overall,
# MAGIC     target_db3000_reg,
# MAGIC     target_poi_overall,
# MAGIC     2024_net_investment 
# MAGIC   FROM main.it_aibi_silver.databricks_events_daiwt_silver 
# MAGIC ),
# MAGIC calculated_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     CASE WHEN event_category = 'DAIWT - 2024' THEN event_name ELSE NULL END AS event_names_daiwt,
# MAGIC     CASE 
# MAGIC       WHEN account_dbx = 'Unknown' THEN 'Non DBX Accounts'
# MAGIC       ELSE 'DBX Accounts'
# MAGIC     END AS is_dbx_account,
# MAGIC     CASE 
# MAGIC       WHEN account_partner_type IS NULL OR account_partner_type = 'Unknown' THEN FALSE
# MAGIC       ELSE TRUE
# MAGIC     END AS partner_flag,
# MAGIC     CASE WHEN INSTR(event_name, 'Exec') > 0 THEN TRUE ELSE FALSE END AS exec_forum_event,
# MAGIC     CONCAT(first_name, ' ', last_name) AS member_full_name,
# MAGIC     CASE 
# MAGIC       WHEN event_category = 'DAIWT - 2024' THEN DATE '2024-11-20'
# MAGIC       WHEN event_category = 'DAIWT - 2023' THEN DATE '2023-11-30'
# MAGIC       ELSE NULL
# MAGIC     END AS daiwt_event_end_date,
# MAGIC     MIN(registration_date) OVER (PARTITION BY lead_or_contact_id, event_category) AS bottom_trend_difference
# MAGIC   FROM base_data
# MAGIC ),
# MAGIC aggregated_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     SUM(registered) OVER () / NULLIF(SUM(target_registrants_overall) OVER (), 0) AS percent_attainment_reg,
# MAGIC     SUM(attended) OVER () / NULLIF(SUM(registered) OVER (), 0) AS sf_percent_attended,
# MAGIC     SUM(u1_unit) OVER () / NULLIF(SUM(mql_unit) OVER (), 0) AS mqls_u1_percent,
# MAGIC     SUM(u2_unit) OVER () / NULLIF(SUM(mql_unit) OVER (), 0) AS mqls_u2_percent,
# MAGIC     SUM(u3_unit) OVER () / NULLIF(SUM(mql_unit) OVER (), 0) AS mqls_u3_percent,
# MAGIC     SUM(attended) OVER () / NULLIF(SUM(target_attendees_overall) OVER (), 0) AS percent_attainment_attendees,
# MAGIC     SUM(CASE WHEN is_dbx_account = 'DBX Accounts' THEN registered ELSE 0 END) OVER () / NULLIF(SUM(registered) OVER (), 0) AS dbx_registrant_percent,
# MAGIC     SUM(CASE WHEN is_dbx_account = 'DBX Accounts' THEN attended ELSE 0 END) OVER () / NULLIF(SUM(attended) OVER (), 0) AS dbx_attendee_percent,
# MAGIC     SUM(u2_unit) OVER () / NULLIF(SUM(target_u2_overall) OVER (), 0) AS percent_u2_attainment,
# MAGIC     SUM(CASE WHEN account_dbx = 'DB3000' THEN registered ELSE 0 END) OVER () / NULLIF(SUM(target_db3000_reg) OVER (), 0) AS percent_db3k_attainment_daiwt_24,
# MAGIC     (SUM(u2_amount) OVER () * 12) / NULLIF(SUM(2024_net_investment) OVER (), 0) AS actual_fpoi,
# MAGIC     MIN(CASE WHEN event_category = 'DAIWT - 2024' THEN registration_date END) OVER (PARTITION BY lead_or_contact_id, event_category) AS first_registration_date
# MAGIC   FROM calculated_data
# MAGIC ),
# MAGIC distinct_dbx_accounts AS (
# MAGIC   SELECT COUNT(DISTINCT attendee_account_id) AS unique_dbx_accounts
# MAGIC   FROM calculated_data
# MAGIC   WHERE is_dbx_account = 'DBX Accounts'
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   a.*,
# MAGIC   SUBSTR(event_names_daiwt, INSTR(event_names_daiwt, '- ') + 2) AS event_names_daiwt_city_event,
# MAGIC   d.unique_dbx_accounts,
# MAGIC   actual_fpoi / NULLIF(AVG(target_poi_overall) OVER (), 0) AS percent_poi_attainment,
# MAGIC   CASE 
# MAGIC     WHEN DATEDIFF(DAY, bottom_trend_difference, daiwt_event_end_date) < 0 THEN 0 
# MAGIC     ELSE DATEDIFF(DAY, bottom_trend_difference, daiwt_event_end_date) 
# MAGIC   END AS days_until_daiwt
# MAGIC FROM aggregated_data a
# MAGIC CROSS JOIN distinct_dbx_accounts d
