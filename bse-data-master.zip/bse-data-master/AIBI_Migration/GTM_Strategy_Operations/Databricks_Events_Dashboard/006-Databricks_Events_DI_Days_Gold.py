# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.databricks_events_di_days_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     attendee_account_name,
# MAGIC     attendee_account_status,
# MAGIC     attendee_company,
# MAGIC     attended_event,
# MAGIC     event_category,
# MAGIC     event_name,
# MAGIC     sf_account_name,
# MAGIC     sf_company,
# MAGIC     sf_lead_contact_status,
# MAGIC     sf_lead_or_contact_id,
# MAGIC     sf_member_industry,
# MAGIC     sf_member_channel,
# MAGIC     sf_is_dbx_account,
# MAGIC     sf_dbx_account_type,
# MAGIC     sf_account_owner_name,
# MAGIC     sf_program_name,
# MAGIC     account_record_type,
# MAGIC     audience_primary_lead_or_contact_id,
# MAGIC     engagement_program_name,
# MAGIC     engagement_tactic_name,
# MAGIC     usecase_name,
# MAGIC     usecase_id,
# MAGIC     usecase_owner,
# MAGIC     u1_stage_date,
# MAGIC     u2_stage_date,
# MAGIC     u3_stage_date,
# MAGIC     u1_unit,
# MAGIC     u1_amount,
# MAGIC     u2_unit,
# MAGIC     u2_amount,
# MAGIC     u3_unit,
# MAGIC     u3_amount,
# MAGIC     mql_unit,
# MAGIC     engagement_channel_type
# MAGIC   FROM main.it_aibi_silver.databricks_events_di_days_silver 
# MAGIC ),
# MAGIC calculated_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     CASE 
# MAGIC       WHEN event_category = 'DI Days' THEN event_name 
# MAGIC       ELSE NULL 
# MAGIC     END AS event_names_di_days,
# MAGIC     CASE 
# MAGIC       WHEN INSTR(event_name, '- ') > 0 THEN 
# MAGIC         SUBSTR(event_name, INSTR(event_name, '- ') + 2)
# MAGIC       ELSE event_name 
# MAGIC     END AS event_names_di_days_city_event,
# MAGIC     CASE 
# MAGIC       WHEN sf_account_owner_name IS NOT NULL AND account_record_type != 'Partner' THEN TRUE 
# MAGIC       ELSE FALSE 
# MAGIC     END AS is_quality_registrant,
# MAGIC     COALESCE(u1_unit, u2_unit, u3_unit, 0) > 0 AS at_least_1_unit,
# MAGIC     COALESCE(u1_unit, u2_unit, u3_unit, 0) AS units,
# MAGIC     COALESCE(u1_amount, u2_amount, u3_amount, 0) AS unit_amount,
# MAGIC     CASE 
# MAGIC       WHEN u1_stage_date IS NOT NULL AND u2_stage_date IS NULL AND u3_stage_date IS NULL THEN TRUE 
# MAGIC       ELSE FALSE 
# MAGIC     END AS is_u1,
# MAGIC     CASE 
# MAGIC       WHEN u2_stage_date IS NOT NULL AND u3_stage_date IS NULL THEN TRUE 
# MAGIC       ELSE FALSE 
# MAGIC     END AS is_u2,
# MAGIC     CASE 
# MAGIC       WHEN u3_stage_date IS NOT NULL THEN TRUE 
# MAGIC       ELSE FALSE 
# MAGIC     END AS is_u3
# MAGIC   FROM base_data
# MAGIC ),
# MAGIC distinct_count AS (
# MAGIC   SELECT COUNT(DISTINCT sf_lead_or_contact_id) AS sf_registrants_lead_id
# MAGIC   FROM calculated_data
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   cd.*,
# MAGIC   CASE 
# MAGIC     WHEN INSTR(cd.event_names_di_days_city_event, '-') > 0 THEN 
# MAGIC       SUBSTR(cd.event_names_di_days_city_event, 1, INSTR(cd.event_names_di_days_city_event, ' ') - 1)
# MAGIC     ELSE cd.event_names_di_days_city_event 
# MAGIC   END AS event_names_di_days_city,
# MAGIC   SUM(cd.u1_unit) OVER () / NULLIF(SUM(cd.mql_unit) OVER (), 0) AS mqls_u1_percent,
# MAGIC   SUM(cd.u2_unit) OVER () / NULLIF(SUM(cd.mql_unit) OVER (), 0) AS mqls_u2_percent,
# MAGIC   SUM(cd.u3_unit) OVER () / NULLIF(SUM(cd.mql_unit) OVER (), 0) AS mqls_u3_percent,
# MAGIC   dc.sf_registrants_lead_id,
# MAGIC   cd.unit_amount / NULLIF(cd.units, 0) AS amt_per_unit
# MAGIC FROM calculated_data cd
# MAGIC CROSS JOIN distinct_count dc
