# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.mql_lead_passing_silver as
# MAGIC
# MAGIC SELECT 
# MAGIC   lead_or_contact_id,
# MAGIC   lead_owner_name,
# MAGIC   lead_owner_title,
# MAGIC   prev_lead_owner_title,
# MAGIC   lead_owner_role,
# MAGIC   lead_owner_manager_name,
# MAGIC   prev_lead_owner_name,
# MAGIC   prev_lead_owner_role,
# MAGIC   lead_owner_change_date,
# MAGIC   current_mql_promote_date,
# MAGIC   region,
# MAGIC   business_unit,
# MAGIC   lead_owner_changed_by 
# MAGIC FROM main.marketing_lakehouse.rpt_mpd_lead_passing 
# MAGIC
