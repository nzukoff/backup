# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.mql_lead_passing_gold as
# MAGIC
# MAGIC SELECT 
# MAGIC   lead_or_contact_id,
# MAGIC   lead_owner_name,
# MAGIC   lead_owner_title,
# MAGIC   prev_lead_owner_title,
# MAGIC   lead_owner_role,
# MAGIC   lead_owner_manager_name,
# MAGIC   prev_lead_owner_name,
# MAGIC   prev_lead_owner_role,
# MAGIC   lead_owner_change_date,
# MAGIC   current_mql_promote_date,
# MAGIC   region,
# MAGIC   business_unit,
# MAGIC   lead_owner_changed_by,
# MAGIC   CASE 
# MAGIC     WHEN lead_owner_role LIKE '%AE%' THEN 'AE'
# MAGIC     WHEN lead_owner_role LIKE '%BDR%' THEN 'BDR'
# MAGIC     WHEN lead_owner_role LIKE '%SDR%' THEN 'SDR'
# MAGIC     WHEN lead_owner_role LIKE '%PDR%' THEN 'PDR'
# MAGIC     WHEN lead_owner_role LIKE '%GDR%' THEN 'GDR'
# MAGIC     WHEN lead_owner_role LIKE '%XDR%' THEN 'XDR'
# MAGIC     WHEN lead_owner_role IS NOT NULL THEN 'Other Role'
# MAGIC   END AS current_mql_owner_category,
# MAGIC   CASE 
# MAGIC     WHEN prev_lead_owner_role LIKE '%AE%' THEN 'AE'
# MAGIC     WHEN prev_lead_owner_role LIKE '%BDR%' THEN 'BDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%SDR%' THEN 'SDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%PDR%' THEN 'PDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%GDR%' THEN 'GDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%XDR%' THEN 'XDR'
# MAGIC     WHEN prev_lead_owner_role IS NOT NULL THEN 'Other Role'
# MAGIC   END AS original_mql_owner_category,
# MAGIC   CASE 
# MAGIC     WHEN current_mql_promote_date <= lead_owner_change_date THEN true
# MAGIC     ELSE false
# MAGIC   END AS pass_date_after_mql_date,
# MAGIC   CASE
# MAGIC     WHEN (prev_lead_owner_role IS NULL AND lead_owner_role LIKE '%AE%') 
# MAGIC       OR (prev_lead_owner_role LIKE '%AE%' AND lead_owner_role IS NULL) 
# MAGIC       OR (lead_owner_role LIKE '%AE%' AND current_mql_promote_date > lead_owner_change_date)
# MAGIC       OR (prev_lead_owner_role LIKE '%CEO%' AND lead_owner_role LIKE '%AE%')
# MAGIC     THEN 'AE - NOT PASSED'
# MAGIC     WHEN (prev_lead_owner_role IS NULL AND lead_owner_role LIKE '%BDR%') 
# MAGIC       OR (prev_lead_owner_role LIKE '%BDR%' AND lead_owner_role IS NULL) 
# MAGIC       OR (lead_owner_role LIKE '%BDR%' AND current_mql_promote_date > lead_owner_change_date)
# MAGIC       OR (prev_lead_owner_role LIKE '%CEO%' AND lead_owner_role LIKE '%BDR%')
# MAGIC     THEN 'BDR - NOT PASSED'
# MAGIC     WHEN (prev_lead_owner_role IS NULL AND lead_owner_role LIKE '%SDR%') 
# MAGIC       OR (prev_lead_owner_role LIKE '%SDR%' AND lead_owner_role IS NULL) 
# MAGIC       OR (lead_owner_role LIKE '%SDR%' AND current_mql_promote_date > lead_owner_change_date)
# MAGIC       OR (prev_lead_owner_role LIKE '%CEO%' AND lead_owner_role LIKE '%SDR%')
# MAGIC     THEN 'SDR - NOT PASSED'
# MAGIC     WHEN (prev_lead_owner_role IS NULL AND lead_owner_role LIKE '%GDR%') 
# MAGIC       OR (prev_lead_owner_role LIKE '%GDR%' AND lead_owner_role IS NULL) 
# MAGIC       OR (lead_owner_role LIKE '%GDR%' AND current_mql_promote_date > lead_owner_change_date)
# MAGIC       OR (prev_lead_owner_role LIKE '%CEO%' AND lead_owner_role LIKE '%GDR%')
# MAGIC     THEN 'GDR - NOT PASSED'
# MAGIC     WHEN (prev_lead_owner_role IS NULL AND lead_owner_role LIKE '%PDR%') 
# MAGIC       OR (prev_lead_owner_role LIKE '%PDR%' AND lead_owner_role IS NULL) 
# MAGIC       OR (lead_owner_role LIKE '%PDR%' AND current_mql_promote_date > lead_owner_change_date)
# MAGIC       OR (prev_lead_owner_role LIKE '%CEO%' AND lead_owner_role LIKE '%PDR%')
# MAGIC     THEN 'PDR - NOT PASSED'
# MAGIC     WHEN (prev_lead_owner_role IS NULL AND lead_owner_role LIKE '%XDR%') 
# MAGIC       OR (prev_lead_owner_role LIKE '%XDR%' AND lead_owner_role IS NULL) 
# MAGIC       OR (lead_owner_role LIKE '%XDR%' AND current_mql_promote_date > lead_owner_change_date)
# MAGIC       OR (prev_lead_owner_role LIKE '%CEO%' AND lead_owner_role LIKE '%XDR%')
# MAGIC     THEN 'XDR - NOT PASSED'
# MAGIC     WHEN prev_lead_owner_role IS NULL OR lead_owner_role IS NULL 
# MAGIC       OR (lead_owner_role NOT LIKE '%AE%' AND lead_owner_role NOT LIKE '%BDR%' 
# MAGIC           AND lead_owner_role NOT LIKE '%SDR%' AND lead_owner_role NOT LIKE '%GDR%' 
# MAGIC           AND lead_owner_role NOT LIKE '%PDR%' AND lead_owner_role NOT LIKE '%XDR%' 
# MAGIC           AND current_mql_promote_date > lead_owner_change_date)
# MAGIC     THEN 'Other Role - NOT PASSED'
# MAGIC     WHEN prev_lead_owner_role LIKE '%AE%' AND lead_owner_role LIKE '%AE%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'AE pass to AE'
# MAGIC     WHEN prev_lead_owner_role LIKE '%AE%' AND lead_owner_role LIKE '%BDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'AE pass to BDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%AE%' AND lead_owner_role LIKE '%SDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'AE pass to SDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%AE%' AND lead_owner_role LIKE '%GDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'AE pass to GDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%AE%' AND lead_owner_role LIKE '%PDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'AE pass to PDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%AE%' AND lead_owner_role LIKE '%XDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'AE pass to XDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%AE%' AND lead_owner_role NOT LIKE '%AE%' 
# MAGIC       AND lead_owner_role NOT LIKE '%BDR%' AND lead_owner_role NOT LIKE '%SDR%'
# MAGIC       AND lead_owner_role NOT LIKE '%GDR%' AND lead_owner_role NOT LIKE '%PDR%'
# MAGIC       AND lead_owner_role NOT LIKE '%XDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'AE pass to Other Role'
# MAGIC     WHEN prev_lead_owner_role LIKE '%BDR%' AND lead_owner_role LIKE '%AE%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'BDR pass to AE'
# MAGIC     WHEN prev_lead_owner_role LIKE '%BDR%' AND lead_owner_role LIKE '%BDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'BDR pass to BDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%BDR%' AND lead_owner_role LIKE '%SDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'BDR pass to SDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%BDR%' AND lead_owner_role LIKE '%GDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'BDR pass to GDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%BDR%' AND lead_owner_role LIKE '%PDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'BDR pass to PDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%BDR%' AND lead_owner_role LIKE '%XDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'BDR pass to XDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%BDR%' AND lead_owner_role NOT LIKE '%AE%' 
# MAGIC       AND lead_owner_role NOT LIKE '%BDR%' AND lead_owner_role NOT LIKE '%SDR%'
# MAGIC       AND lead_owner_role NOT LIKE '%GDR%' AND lead_owner_role NOT LIKE '%PDR%'
# MAGIC       AND lead_owner_role NOT LIKE '%XDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'BDR pass to Other Role'
# MAGIC     WHEN prev_lead_owner_role LIKE '%SDR%' AND lead_owner_role LIKE '%AE%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'SDR pass to AE'
# MAGIC     WHEN prev_lead_owner_role LIKE '%SDR%' AND lead_owner_role LIKE '%BDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'SDR pass to BDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%SDR%' AND lead_owner_role LIKE '%SDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'SDR pass to SDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%SDR%' AND lead_owner_role LIKE '%GDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'SDR pass to GDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%SDR%' AND lead_owner_role LIKE '%PDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'SDR pass to PDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%SDR%' AND lead_owner_role LIKE '%XDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'SDR pass to XDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%SDR%' AND lead_owner_role NOT LIKE '%AE%' 
# MAGIC       AND lead_owner_role NOT LIKE '%BDR%' AND lead_owner_role NOT LIKE '%SDR%'
# MAGIC       AND lead_owner_role NOT LIKE '%GDR%' AND lead_owner_role NOT LIKE '%PDR%'
# MAGIC       AND lead_owner_role NOT LIKE '%XDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'SDR pass to Other Role'
# MAGIC     WHEN prev_lead_owner_role LIKE '%PDR%' AND lead_owner_role LIKE '%AE%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'PDR pass to AE'
# MAGIC     WHEN prev_lead_owner_role LIKE '%PDR%' AND lead_owner_role LIKE '%BDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'PDR pass to BDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%PDR%' AND lead_owner_role LIKE '%SDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'PDR pass to SDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%PDR%' AND lead_owner_role LIKE '%GDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'PDR pass to GDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%PDR%' AND lead_owner_role LIKE '%PDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'PDR pass to PDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%PDR%' AND lead_owner_role LIKE '%XDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'PDR pass to XDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%GDR%' AND lead_owner_role LIKE '%AE%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'GDR pass to AE'
# MAGIC     WHEN prev_lead_owner_role LIKE '%GDR%' AND lead_owner_role LIKE '%BDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'GDR pass to BDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%GDR%' AND lead_owner_role LIKE '%SDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'GDR pass to SDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%GDR%' AND lead_owner_role LIKE '%GDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'GDR pass to GDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%GDR%' AND lead_owner_role LIKE '%PDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'GDR pass to PDR'
# MAGIC     WHEN prev_lead_owner_role LIKE '%GDR%' AND lead_owner_role LIKE '%XDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'GDR pass to XDR'
# MAGIC     WHEN prev_lead_owner_role NOT LIKE '%AE%' AND prev_lead_owner_role NOT LIKE '%BDR%' 
# MAGIC       AND prev_lead_owner_role NOT LIKE '%SDR%' AND prev_lead_owner_role NOT LIKE '%GDR%'
# MAGIC       AND prev_lead_owner_role NOT LIKE '%PDR%' AND prev_lead_owner_role NOT LIKE '%XDR%'
# MAGIC       AND lead_owner_role LIKE '%AE%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'GDR pass to XDR'
# MAGIC     WHEN prev_lead_owner_role NOT LIKE '%AE%' AND prev_lead_owner_role NOT LIKE '%BDR%' 
# MAGIC       AND prev_lead_owner_role NOT LIKE '%SDR%' AND prev_lead_owner_role NOT LIKE '%GDR%'
# MAGIC       AND prev_lead_owner_role NOT LIKE '%PDR%' AND prev_lead_owner_role NOT LIKE '%XDR%'
# MAGIC       AND lead_owner_role LIKE '%AE%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'Other Role pass to AE'
# MAGIC     WHEN prev_lead_owner_role NOT LIKE '%AE%' AND prev_lead_owner_role NOT LIKE '%BDR%' 
# MAGIC       AND prev_lead_owner_role NOT LIKE '%SDR%' AND prev_lead_owner_role NOT LIKE '%GDR%'
# MAGIC       AND prev_lead_owner_role NOT LIKE '%PDR%' AND prev_lead_owner_role NOT LIKE '%XDR%'
# MAGIC       AND lead_owner_role LIKE '%BDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'Other Role pass to BDR'
# MAGIC     WHEN prev_lead_owner_role NOT LIKE '%AE%' AND prev_lead_owner_role NOT LIKE '%BDR%' 
# MAGIC       AND prev_lead_owner_role NOT LIKE '%SDR%' AND prev_lead_owner_role NOT LIKE '%GDR%'
# MAGIC       AND prev_lead_owner_role NOT LIKE '%PDR%' AND prev_lead_owner_role NOT LIKE '%XDR%'
# MAGIC       AND lead_owner_role LIKE '%SDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'Other Role pass to SDR'
# MAGIC     WHEN prev_lead_owner_role NOT LIKE '%AE%' AND prev_lead_owner_role NOT LIKE '%BDR%' 
# MAGIC       AND prev_lead_owner_role NOT LIKE '%SDR%' AND prev_lead_owner_role NOT LIKE '%GDR%'
# MAGIC       AND prev_lead_owner_role NOT LIKE '%PDR%' AND prev_lead_owner_role NOT LIKE '%XDR%'
# MAGIC       AND lead_owner_role LIKE '%GDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'Other Role pass to GDR'
# MAGIC     WHEN prev_lead_owner_role NOT LIKE '%AE%' AND prev_lead_owner_role NOT LIKE '%BDR%' 
# MAGIC       AND prev_lead_owner_role NOT LIKE '%SDR%' AND prev_lead_owner_role NOT LIKE '%GDR%'
# MAGIC       AND prev_lead_owner_role NOT LIKE '%PDR%' AND prev_lead_owner_role NOT LIKE '%XDR%'
# MAGIC       AND lead_owner_role LIKE '%PDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'Other Role pass to PDR'
# MAGIC     WHEN prev_lead_owner_role NOT LIKE '%AE%' AND prev_lead_owner_role NOT LIKE '%BDR%' 
# MAGIC       AND prev_lead_owner_role NOT LIKE '%SDR%' AND prev_lead_owner_role NOT LIKE '%GDR%'
# MAGIC       AND prev_lead_owner_role NOT LIKE '%PDR%' AND prev_lead_owner_role NOT LIKE '%XDR%'
# MAGIC       AND lead_owner_role LIKE '%XDR%' AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'Other Role pass to XDR'
# MAGIC     WHEN prev_lead_owner_role NOT LIKE '%AE%' AND prev_lead_owner_role NOT LIKE '%BDR%' 
# MAGIC       AND prev_lead_owner_role NOT LIKE '%SDR%' AND prev_lead_owner_role NOT LIKE '%GDR%'
# MAGIC       AND prev_lead_owner_role NOT LIKE '%PDR%' AND prev_lead_owner_role NOT LIKE '%XDR%'
# MAGIC       AND lead_owner_role NOT LIKE '%AE%' AND lead_owner_role NOT LIKE '%BDR%'
# MAGIC       AND lead_owner_role NOT LIKE '%SDR%' AND lead_owner_role NOT LIKE '%GDR%'
# MAGIC       AND lead_owner_role NOT LIKE '%PDR%' AND lead_owner_role NOT LIKE '%XDR%'
# MAGIC       AND current_mql_promote_date <= lead_owner_change_date
# MAGIC     THEN 'Other Role pass to Other Role'
# MAGIC     ELSE 'Other Role pass to Other Role'
# MAGIC   END AS passing_categories,
# MAGIC   CASE 
# MAGIC     WHEN current_mql_promote_date IS NOT NULL THEN 1
# MAGIC     ELSE 0
# MAGIC   END AS mql_count,
# MAGIC     CASE 
# MAGIC     WHEN passing_categories LIKE '%NOT PASSED%' THEN 'Not Passed'
# MAGIC     ELSE 'Passed'
# MAGIC   END AS passed
# MAGIC FROM main.it_aibi_silver.mql_lead_passing_silver
