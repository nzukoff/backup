# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.cloud_performance_commits_silver as
# MAGIC
# MAGIC select
# MAGIC bu,
# MAGIC calendar_month,
# MAGIC cloud,
# MAGIC fiscal_month,
# MAGIC fiscal_qtr,
# MAGIC fiscal_year,
# MAGIC platform,
# MAGIC sfdc_account_id,
# MAGIC sfdc_account_name,
# MAGIC sfdc_opportunity_id,
# MAGIC sub_bu,
# MAGIC type,
# MAGIC incr_booking
# MAGIC from main.gtm_partner_data.cloud_performance_commit_snap
