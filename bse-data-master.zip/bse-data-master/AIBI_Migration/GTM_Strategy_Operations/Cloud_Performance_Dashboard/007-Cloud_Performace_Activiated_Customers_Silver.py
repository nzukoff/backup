# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.cloud_performance_activated_customers_silver as
# MAGIC
# MAGIC select
# MAGIC bu,
# MAGIC cloud,
# MAGIC dbu_dollars,
# MAGIC month_end_date,
# MAGIC owner_name,
# MAGIC primary_platform,
# MAGIC region,
# MAGIC sfdc_account_id,
# MAGIC sfdc_account_name,
# MAGIC sub_bu,
# MAGIC threshold
# MAGIC from main.gtm_partner_data.cloud_activated_customers
