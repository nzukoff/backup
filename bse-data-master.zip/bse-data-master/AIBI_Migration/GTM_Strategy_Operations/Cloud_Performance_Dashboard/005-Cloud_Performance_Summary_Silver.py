# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.cloud_performance_summary_silver as
# MAGIC
# MAGIC select
# MAGIC ytd_actual_plus_ae_forecast,
# MAGIC BU,
# MAGIC Calendar_month,
# MAGIC Calendar_month_date,
# MAGIC Cloud,
# MAGIC Fiscal_qtr,
# MAGIC Fiscal_year,
# MAGIC Fiscal_year_month,
# MAGIC FY24_actual,
# MAGIC FY25_Actual,
# MAGIC Metric,
# MAGIC Platform,
# MAGIC Region,
# MAGIC Split_metric,
# MAGIC Sub_BU,
# MAGIC Target
# MAGIC from main.gtm_partner_data.cloud_performance_summary_snap

# COMMAND ----------


