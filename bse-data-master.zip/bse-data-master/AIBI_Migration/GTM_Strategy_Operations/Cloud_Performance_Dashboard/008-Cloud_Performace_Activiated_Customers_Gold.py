# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.cloud_performance_activated_customers_gold as
# MAGIC
# MAGIC select
# MAGIC *
# MAGIC from main.it_aibi_silver.cloud_performance_activated_customers_silver
