# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.cloud_performance_summary_gold as
# MAGIC
# MAGIC WITH current_fiscal_month AS (
# MAGIC     SELECT 
# MAGIC         CASE 
# MAGIC             WHEN EXTRACT(MONTH FROM CURRENT_DATE) = 1 THEN 12
# MAGIC             ELSE EXTRACT(MONTH FROM CURRENT_DATE) - 1
# MAGIC         END AS Current_Fiscal_Month
# MAGIC )
# MAGIC SELECT
# MAGIC     ytd_actual_plus_ae_forecast,
# MAGIC     BU,
# MAGIC     Calendar_month,
# MAGIC     Calendar_month_date,
# MAGIC     Cloud,
# MAGIC     Fiscal_qtr,
# MAGIC     Fiscal_year,
# MAGIC     Fiscal_year_month,
# MAGIC     FY24_actual,
# MAGIC     FY25_Actual,
# MAGIC     Metric,
# MAGIC     Platform,
# MAGIC     Region,
# MAGIC     Split_metric,
# MAGIC     Sub_BU,
# MAGIC     Target,
# MAGIC     CASE 
# MAGIC         WHEN SUM(Target) OVER () = 0 THEN NULL
# MAGIC         ELSE SUM(FY25_Actual) OVER () / SUM(Target) OVER ()
# MAGIC     END AS Attainment_Percentage,
# MAGIC     CASE 
# MAGIC         WHEN SUM(Target) OVER () = 0 THEN NULL
# MAGIC         ELSE SUM(ytd_actual_plus_ae_forecast) OVER () / SUM(Target) OVER ()
# MAGIC     END AS Forecast_Attainment_Percentage,
# MAGIC     (SELECT Current_Fiscal_Month FROM current_fiscal_month) AS Current_Fiscal_Month,
# MAGIC     FY25_Actual AS FY25_Actual_copy,
# MAGIC     CASE 
# MAGIC         WHEN SUM(FY24_Actual) OVER () = 0 THEN NULL
# MAGIC         ELSE (SUM(FY25_Actual) OVER () / SUM(FY24_Actual) OVER ()) - 1
# MAGIC     END AS YoY
# MAGIC FROM main.it_aibi_silver.cloud_performance_summary_silver
