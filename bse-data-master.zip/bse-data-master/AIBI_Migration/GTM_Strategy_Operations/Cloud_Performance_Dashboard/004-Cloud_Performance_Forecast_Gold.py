# Databricks notebook source
# MAGIC %sql
# MAGIC  
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.cloud_performance_forecast_gold as
# MAGIC
# MAGIC SELECT
# MAGIC     account_executive,
# MAGIC     actual_plus_forecast,
# MAGIC     aws_top_accounts,
# MAGIC     azure_account_cohort,
# MAGIC     bu,
# MAGIC     cloud_target_account,
# MAGIC     current_ds_forecast_out_of_plan,
# MAGIC     current_in_plan_adjustment,
# MAGIC     current_open_in_plan_usecases,
# MAGIC     current_organic_growth_baseline_in_plan,
# MAGIC     current_quarter_non_genai_dbu_dollar_target,
# MAGIC     deployable_account_id,
# MAGIC     deployable_account_name,
# MAGIC     fiscal_year,
# MAGIC     gcp_target_grouping,
# MAGIC     non_genai_dbu_dollar_target,
# MAGIC     redfish_account,
# MAGIC     sfdc_account_name,
# MAGIC     sub_bu,
# MAGIC     SUM(actual_plus_forecast) OVER() / NULLIF(SUM(non_genai_dbu_dollar_target) OVER(), 0) AS Forecasted_Attainment
# MAGIC FROM main.it_aibi_silver.cloud_performance_forecast_silver
# MAGIC
