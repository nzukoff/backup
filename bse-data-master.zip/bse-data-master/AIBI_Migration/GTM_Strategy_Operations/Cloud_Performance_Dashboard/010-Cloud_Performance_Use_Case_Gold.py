# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.cloud_performance_use_case_gold as
# MAGIC
# MAGIC SELECT
# MAGIC     Account_Dsa,
# MAGIC     Account_Id,
# MAGIC     Account_Name,
# MAGIC     Account_Solution_Architect,
# MAGIC     Business_Unit,
# MAGIC     Cloud_Provider,
# MAGIC     Created_Date,
# MAGIC     Dsa,
# MAGIC     days_in_stage,
# MAGIC     Estimated_Monthly_Dollar_Dbus,
# MAGIC     Estimated_Monthly_Dollar_Dbus_Dbsql,
# MAGIC     Estimated_Monthly_Dollar_Dbus_Mct,
# MAGIC     Estimated_Monthly_Dollar_Dbus_Nonmct,
# MAGIC     Estimated_Monthly_Dollar_Dbus_Uc,
# MAGIC     Is_Migration_Usecase,
# MAGIC     Migration_Source_Platform,
# MAGIC     Migration_Type,
# MAGIC     Sales_Subregion_Level_1,
# MAGIC     Solution_Architect,
# MAGIC     Stage,
# MAGIC     Stage_Name_Ui,
# MAGIC     Target_Live_Date,
# MAGIC     Target_Live_Fiscal_Year_Quarter,
# MAGIC     target_live_date_slippage,
# MAGIC     Use_Case_Product,
# MAGIC     Usecase_Id,
# MAGIC     Usecase_Name,
# MAGIC     Usecase_Owner,
# MAGIC     DENSE_RANK() OVER (ORDER BY SUM(Estimated_Monthly_Dollar_Dbus) DESC) AS Use_Case_Dollar_Rank,
# MAGIC     CASE WHEN Use_Case_Product LIKE '%Unity Catalog%' THEN 1 ELSE 0 END AS Unity_Catalog_Use_Case,
# MAGIC     CASE WHEN Use_Case_Product LIKE '%Unity Catalog%' THEN 'Y' ELSE 'N' END AS Has_Unity_Catalog,
# MAGIC     CASE WHEN Use_Case_Product LIKE '%DBSQL%' THEN 1 ELSE 0 END AS DBSQL_Use_Case,
# MAGIC     CASE WHEN Use_Case_Product LIKE '%DBSQL%' THEN 'Y' ELSE 'N' END AS Has_DBSQL,
# MAGIC     CASE 
# MAGIC         WHEN Migration_Source_Platform IN ('SAP', 'SAP HANA', 'Netezza', 'Oracle/Exadata', 'SQL Server', 
# MAGIC             'Teradata', 'Teradata Onprem', 'Teradata Vantage', 'Teradata Onprem & Vantage',
# MAGIC             'Cloudera', 'Cloudera / Hortonworks - On Prem', 'Cloudera / Hortonworks - On Cloud',
# MAGIC             'Hortonworks', 'MapR', 'SAS', 'SAS Viya', 'Legacy SAS (SAS 9 or older)',
# MAGIC             'Legacy SAS & SAS Viya', 'EMR', 'Apache Hadoop OSS', 'Qubole', 'Pivotal HD',
# MAGIC             'Vertica', 'Microsoft SQL Server', 'IBM DB2', 'IBM Datastage', 'IBM BigInsights',
# MAGIC             'Informatica', 'Splunk', 'Talend', '') THEN 'Y'
# MAGIC         WHEN Migration_Source_Platform IS NULL THEN NULL
# MAGIC         ELSE 'N'
# MAGIC     END AS Appliance_DW_Migration,
# MAGIC     CASE 
# MAGIC         WHEN Migration_Source_Platform IN ('Amazon Glue', 'Amazon EMR', 'AWS Redshift & Athena', 'AWS Sagemaker') THEN 'Y'
# MAGIC         WHEN Migration_Source_Platform IS NULL THEN NULL
# MAGIC         ELSE 'N'
# MAGIC     END AS AWS_Native_Service_Migration,
# MAGIC
# MAGIC     Stage || '-' || Stage_Name_Ui AS Stage_Desc,
# MAGIC     Sales_Subregion_Level_1 AS Sub_BU,
# MAGIC     Cloud_Provider AS Cloud
# MAGIC
# MAGIC
# MAGIC FROM main.it_aibi_silver.cloud_performance_use_case_silver
# MAGIC GROUP BY
# MAGIC     Account_Dsa,
# MAGIC     Account_Id,
# MAGIC     Account_Name,
# MAGIC     Account_Solution_Architect,
# MAGIC     Business_Unit,
# MAGIC     Cloud_Provider,
# MAGIC     Created_Date,
# MAGIC     Dsa,
# MAGIC     days_in_stage,
# MAGIC     Estimated_Monthly_Dollar_Dbus,
# MAGIC     Estimated_Monthly_Dollar_Dbus_Dbsql,
# MAGIC     Estimated_Monthly_Dollar_Dbus_Mct,
# MAGIC     Estimated_Monthly_Dollar_Dbus_Nonmct,
# MAGIC     Estimated_Monthly_Dollar_Dbus_Uc,
# MAGIC     Is_Migration_Usecase,
# MAGIC     Migration_Source_Platform,
# MAGIC     Migration_Type,
# MAGIC     Sales_Subregion_Level_1,
# MAGIC     Solution_Architect,
# MAGIC     Stage,
# MAGIC     Stage_Name_Ui,
# MAGIC     Target_Live_Date,
# MAGIC     Target_Live_Fiscal_Year_Quarter,
# MAGIC     target_live_date_slippage,
# MAGIC     Use_Case_Product,
# MAGIC     Usecase_Id,
# MAGIC     Usecase_Name,
# MAGIC     Usecase_Owner
