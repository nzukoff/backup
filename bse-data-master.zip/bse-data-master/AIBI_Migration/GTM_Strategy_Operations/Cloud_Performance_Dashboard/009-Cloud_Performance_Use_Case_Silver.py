# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.cloud_performance_use_case_silver as
# MAGIC
# MAGIC select
# MAGIC Account_Dsa,
# MAGIC Account_Id,
# MAGIC Account_Name,
# MAGIC Account_Solution_Architect,
# MAGIC Business_Unit,
# MAGIC Cloud_Provider,
# MAGIC Created_Date,
# MAGIC Dsa,
# MAGIC days_in_stage,
# MAGIC Estimated_Monthly_Dollar_Dbus,
# MAGIC Estimated_Monthly_Dollar_Dbus_Dbsql,
# MAGIC Estimated_Monthly_Dollar_Dbus_Mct,
# MAGIC Estimated_Monthly_Dollar_Dbus_Nonmct,
# MAGIC Estimated_Monthly_Dollar_Dbus_Uc,
# MAGIC Is_Migration_Usecase,
# MAGIC Migration_Source_Platform,
# MAGIC Migration_Type,
# MAGIC Sales_Subregion_Level_1,
# MAGIC Solution_Architect,
# MAGIC Stage,
# MAGIC Stage_Name_Ui,
# MAGIC Target_Live_Date,
# MAGIC Target_Live_Fiscal_Year_Quarter,
# MAGIC target_live_date_slippage,
# MAGIC Use_Case_Product,
# MAGIC Usecase_Id,
# MAGIC Usecase_Name,
# MAGIC Usecase_Owner
# MAGIC from main.gtm_data.core_usecase_curated
