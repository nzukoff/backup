# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.cloud_performance_commits_gold as
# MAGIC
# MAGIC SELECT
# MAGIC     bu,
# MAGIC     calendar_month,
# MAGIC     cloud,
# MAGIC     fiscal_month,
# MAGIC     fiscal_qtr,
# MAGIC     fiscal_year,
# MAGIC     platform,
# MAGIC     sfdc_account_id,
# MAGIC     sfdc_account_name,
# MAGIC     sfdc_opportunity_id,
# MAGIC     sub_bu,
# MAGIC     type,
# MAGIC     incr_booking,
# MAGIC     CASE WHEN type = 'New Business' THEN incr_booking ELSE 0 END AS New_Business,
# MAGIC     CASE WHEN type = 'Upsell' THEN incr_booking ELSE 0 END AS Upsell,
# MAGIC     DENSE_RANK() OVER (ORDER BY SUM(incr_booking) DESC) AS Rank
# MAGIC FROM main.it_aibi_silver.cloud_performance_commits_silver
# MAGIC GROUP BY
# MAGIC     bu,
# MAGIC     calendar_month,
# MAGIC     cloud,
# MAGIC     fiscal_month,
# MAGIC     fiscal_qtr,
# MAGIC     fiscal_year,
# MAGIC     platform,
# MAGIC     sfdc_account_id,
# MAGIC     sfdc_account_name,
# MAGIC     sfdc_opportunity_id,
# MAGIC     sub_bu,
# MAGIC     type,
# MAGIC     incr_booking
