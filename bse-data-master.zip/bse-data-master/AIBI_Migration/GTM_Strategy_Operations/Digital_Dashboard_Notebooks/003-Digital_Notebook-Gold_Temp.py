# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.temp_digital_dashboard_gold
# MAGIC SELECT
# MAGIC   -- Date and Time Related Columns
# MAGIC   date_fy,
# MAGIC   date,
# MAGIC   DATE(DATE_TRUNC('MONTH', CURRENT_DATE())) AS current_date_month,
# MAGIC   DATE(CURRENT_DATE()) AS current_date_today,
# MAGIC   DATE_ADD(DATE_TRUNC('WEEK', CURRENT_DATE()), 3) AS current_date_week_ending_thursday,
# MAGIC   DATE(DATE_TRUNC('YEAR', CURRENT_DATE())) AS current_date_year,
# MAGIC   DATE(DATE_TRUNC('MONTH', date)) AS date_month,
# MAGIC   DATE(DATE_TRUNC('YEAR', date)) AS date_year,
# MAGIC   DATE(
# MAGIC     CASE 
# MAGIC       WHEN MONTH(Date) = 1 THEN DATE_TRUNC('MONTH', DATE_ADD(MONTH, 10, DATE_ADD(YEAR, -1, Date)))
# MAGIC       WHEN MONTH(Date) IN (2, 3, 4) THEN DATE_TRUNC('MONTH', DATE_ADD(MONTH, 1, DATE_TRUNC('YEAR', Date)))
# MAGIC       WHEN MONTH(Date) IN (5, 6, 7) THEN DATE_TRUNC('MONTH', DATE_ADD(MONTH, 4, DATE_TRUNC('YEAR', Date)))
# MAGIC       WHEN MONTH(Date) IN (8, 9, 10) THEN DATE_TRUNC('MONTH', DATE_ADD(MONTH, 7, DATE_TRUNC('YEAR', Date)))
# MAGIC       WHEN MONTH(Date) IN (11, 12) THEN DATE_TRUNC('MONTH', DATE_ADD(MONTH, 10, DATE_TRUNC('YEAR', Date)))
# MAGIC       ELSE NULL 
# MAGIC     END
# MAGIC   ) AS quarter_start_date,
# MAGIC   
# MAGIC   -- Campaign and Tactic Related Columns
# MAGIC   tactic_id,
# MAGIC   campaign_id,
# MAGIC   campaign_name,
# MAGIC   tactic_name,
# MAGIC   sfdc_campaign_id,
# MAGIC   tactic_vertical,
# MAGIC   tactic_theme,
# MAGIC   
# MAGIC   -- Medium and Source Related Columns
# MAGIC   medium,
# MAGIC   source,
# MAGIC   source_medium,
# MAGIC   
# MAGIC   -- Audience and Targeting Related Columns
# MAGIC   audience,
# MAGIC   sub_audience,
# MAGIC   targeting_tactic,
# MAGIC   targeting_theme,
# MAGIC   targeting_sub_theme,
# MAGIC   
# MAGIC   -- Region and Language Related Columns
# MAGIC   region,
# MAGIC   sub_region,
# MAGIC   language,
# MAGIC   CASE 
# MAGIC     WHEN region = 'APJ' THEN 'APJ'
# MAGIC     WHEN region = 'EMEA' THEN 'EMEA'
# MAGIC     ELSE 'AMER'
# MAGIC   END AS region_group,
# MAGIC   
# MAGIC   -- Offer and Product Related Columns
# MAGIC   offer,
# MAGIC   term,
# MAGIC   product_focus,
# MAGIC   
# MAGIC   -- Budget and Objective Related Columns
# MAGIC   budget_type,
# MAGIC   budget_audience,
# MAGIC   objective,
# MAGIC   objective_bucket,
# MAGIC   
# MAGIC   -- Ad Group and Ad Related Columns
# MAGIC   ad_group_id,
# MAGIC   ad_group_name,
# MAGIC   ad_id,
# MAGIC   ad_name,
# MAGIC   ad_offer_type,
# MAGIC   ad_offer_name,
# MAGIC   ad_creative_name,
# MAGIC   ad_creative_size,
# MAGIC   ad_version,
# MAGIC   
# MAGIC   -- Account Related Columns
# MAGIC   digital_account_id,
# MAGIC   digital_account_name,
# MAGIC   account_type,
# MAGIC   
# MAGIC   -- Creative and Ad Type Related Columns
# MAGIC   creative_ad_type,
# MAGIC   ad_type,
# MAGIC   description,
# MAGIC   description_2,
# MAGIC   headline_part_1,
# MAGIC   headline_part_2,
# MAGIC   headline_part_3,
# MAGIC   path_1,
# MAGIC   path_2,
# MAGIC   
# MAGIC   -- Status Related Columns
# MAGIC   status,
# MAGIC   ad_group_status,
# MAGIC   ad_campaign_status,
# MAGIC   
# MAGIC   -- Channel Related Columns
# MAGIC   channel_type,
# MAGIC   channel_detail,
# MAGIC   
# MAGIC   -- Lead and Quality Related Columns
# MAGIC   lead_quality,
# MAGIC   lead_form,
# MAGIC   person_lead_quality,
# MAGIC   account_lead_quality,
# MAGIC   
# MAGIC   -- Miscellaneous Columns
# MAGIC   cloud,
# MAGIC   isv,
# MAGIC   vertical,
# MAGIC   device,
# MAGIC   brand_filter,
# MAGIC   match_type,
# MAGIC   dbx,
# MAGIC   sfdc_utm_campaign,
# MAGIC   event_asset,
# MAGIC   event_asset_type,
# MAGIC   team,
# MAGIC   business_unit,
# MAGIC   days_between_dates,
# MAGIC   marketable,
# MAGIC   cdo_cio_cto,
# MAGIC   why_do_it_now,
# MAGIC   databricks_vertical,
# MAGIC   audience_persona,
# MAGIC   member_status,
# MAGIC   opportunity_stage,
# MAGIC   
# MAGIC   -- Performance Metrics
# MAGIC   cost,
# MAGIC   impressions,
# MAGIC   view_through_conversions,
# MAGIC   clicks,
# MAGIC   conversions,
# MAGIC   engagements,
# MAGIC   responders,
# MAGIC   mql_response,
# MAGIC   net_new_names,
# MAGIC   quality_net_new_names,
# MAGIC   
# MAGIC   -- O1 Related Metrics
# MAGIC   O1_land_unit,
# MAGIC   O1_land_amount,
# MAGIC   O1_expand_unit,
# MAGIC   O1_expand_amount,
# MAGIC   O1_total_unit,
# MAGIC   O1_total_amount,
# MAGIC   validate_date_O1_land_unit,
# MAGIC   validate_date_O1_land_amount,
# MAGIC   validate_date_O1_expand_unit,
# MAGIC   validate_date_O1_expand_amount,
# MAGIC   validate_date_O1_total_unit,
# MAGIC   validate_date_O1_total_amount,
# MAGIC   
# MAGIC   -- U2 Related Metrics
# MAGIC   u2_unit,
# MAGIC   u2_amount,
# MAGIC   u2_unit_by_response_date,
# MAGIC   u2_amount_by_response_date,
# MAGIC   
# MAGIC   -- Calculated Metrics
# MAGIC   (SUM(cost) / NULLIF(SUM(clicks), 0)) AS cpc,
# MAGIC   (SUM(cost) / NULLIF(SUM(mql_response), 0)) AS cpmql,
# MAGIC   (SUM(cost) / NULLIF(SUM(net_new_names), 0)) AS cpnnn,
# MAGIC   (SUM(cost) / NULLIF(SUM(quality_net_new_names), 0)) AS cpqnnn,
# MAGIC   (SUM(cost) / NULLIF(SUM(responders), 0)) AS cpr,
# MAGIC   (SUM(cost) / NULLIF(SUM(u2_unit), 0)) AS cpu2,
# MAGIC   (SUM(clicks) / NULLIF(SUM(impressions), 0)) AS ctr,
# MAGIC   (SUM(responders) / NULLIF(SUM(clicks), 0)) AS cvr,
# MAGIC   (SUM(u2_unit) / 3487) AS fy25q2_u2_target_attainment,
# MAGIC   (SUM(mql_response) / NULLIF(SUM(responders), 0)) AS mql_rate,
# MAGIC   (SUM(quality_net_new_names) / NULLIF(SUM(net_new_names), 0)) AS nnn_to_qnnn_rate,
# MAGIC   (SUM(u2_unit) / NULLIF(SUM(quality_net_new_names), 0)) AS qnnn_to_u2_rate,
# MAGIC   (SUM(net_new_names) / NULLIF(SUM(responders), 0)) AS response_to_nnn_rate,
# MAGIC   u2_amount * 12 AS u2_amount_arr,
# MAGIC   (SUM(u2_amount * 12) / NULLIF(SUM(cost), 0)) AS u2_pipe_to_spent_ratio_arr,
# MAGIC   
# MAGIC   -- Attendance Type
# MAGIC   CASE 
# MAGIC     WHEN LOWER(member_status) LIKE '%virtual%' 
# MAGIC       OR LOWER(member_status) LIKE '%on-demand%'
# MAGIC       OR LOWER(member_status) LIKE '%ondemand%'
# MAGIC     THEN 'Virtual'
# MAGIC     ELSE 'In-Person'
# MAGIC   END AS attendance_type,
# MAGIC   
# MAGIC   -- Authorization Check
# MAGIC   CASE CURRENT_USER()
# MAGIC     WHEN 'allison.harris@databricks.com' THEN TRUE
# MAGIC     WHEN 'mo.derakhshanian@databricks.com' THEN TRUE
# MAGIC     WHEN 'hannah.beck@databricks.com' THEN TRUE
# MAGIC     WHEN 'clay.anderson@databricks.com' THEN TRUE
# MAGIC     WHEN 'riya.dhanju@databricks.com' THEN TRUE
# MAGIC     WHEN 'tanner.bromer@databricks.com' THEN TRUE
# MAGIC     WHEN 'emily.betts@databricks.com' THEN TRUE
# MAGIC     WHEN 'sara.pierson@databricks.com' THEN TRUE
# MAGIC     WHEN 'marisa.baptista@databricks.com' THEN TRUE
# MAGIC     WHEN 'leslie.files@databricks.com' THEN TRUE
# MAGIC     WHEN 'lynsey.johnson@databricks.com' THEN TRUE
# MAGIC     WHEN 'sam.brown@databricks.com' THEN TRUE
# MAGIC     WHEN 'alex.dartt@databricks.com' THEN TRUE
# MAGIC     WHEN 'michael.valeri@databricks.com' THEN TRUE
# MAGIC     ELSE FALSE
# MAGIC   END AS is_authorized_user,
# MAGIC   
# MAGIC   -- Time-based Ratio
# MAGIC   CASE 
# MAGIC     WHEN DATEDIFF(DAY, DATE '2024-07-31', CURRENT_DATE()) <= 0 
# MAGIC     THEN CAST(DATEDIFF(DAY, DATE '2024-05-01', DATE_SUB(CURRENT_DATE(), 1)) AS FLOAT) / 90
# MAGIC     ELSE 1.0
# MAGIC   END AS time_based_ratio,
# MAGIC   
# MAGIC   -- Target Values
# MAGIC   CASE 
# MAGIC     WHEN Medium = 'Paid Search' THEN 31155
# MAGIC     WHEN Medium = 'Paid Social' THEN 25283
# MAGIC     WHEN Medium = 'Programmatic' THEN 4602
# MAGIC     WHEN Medium = 'Third Party' THEN 25298
# MAGIC     ELSE 0
# MAGIC   END AS medium_value_FY25_Q2_NNN_Targetsby_medium,
# MAGIC   
# MAGIC   CASE 
# MAGIC     WHEN Region = 'AMER' THEN 54266
# MAGIC     WHEN Region = 'APJ' THEN 13236
# MAGIC     WHEN Region = 'EMEA' THEN 18836
# MAGIC     ELSE 0
# MAGIC   END AS region_value_FY25_Q2_NNN_Targets_by_region,
# MAGIC   
# MAGIC   CASE 
# MAGIC     WHEN Medium = 'Paid Search' THEN 3143
# MAGIC     WHEN Medium = 'Paid Social' THEN 4056
# MAGIC     WHEN Medium = 'Programmatic' THEN 457
# MAGIC     WHEN Medium = 'Third Party' THEN 9549
# MAGIC     ELSE 0
# MAGIC   END AS medium_value_FY25_Q2_QNNN_Targetsby_medium,
# MAGIC   
# MAGIC   CASE 
# MAGIC     WHEN Region = 'AMER' THEN 10108
# MAGIC     WHEN Region = 'APJ' THEN 2490
# MAGIC     WHEN Region = 'EMEA' THEN 4609
# MAGIC     ELSE 0
# MAGIC   END AS region_value_FY25_Q2_QNNN_Targets_by_region,
# MAGIC   
# MAGIC   CASE 
# MAGIC     WHEN Medium = 'Paid Search' THEN 1751
# MAGIC     WHEN Medium = 'Paid Social' THEN 564
# MAGIC     WHEN Medium = 'Programmatic' THEN 177
# MAGIC     WHEN Medium = 'Third Party' THEN 995
# MAGIC     ELSE 0
# MAGIC   END AS FY25Q2_U2_Targets_by_Medium,
# MAGIC   
# MAGIC   CASE 
# MAGIC     WHEN Region = 'AMER' THEN 2468
# MAGIC     WHEN Region = 'APJ' THEN 361
# MAGIC     WHEN Region = 'EMEA' THEN 659
# MAGIC     ELSE 0
# MAGIC   END AS FY25Q2_U2_Targets_by_region
# MAGIC   
# MAGIC
# MAGIC
# MAGIC FROM main.it_aibi_silver.rpt_digital_performance_deepdive
# MAGIC GROUP BY ALL
