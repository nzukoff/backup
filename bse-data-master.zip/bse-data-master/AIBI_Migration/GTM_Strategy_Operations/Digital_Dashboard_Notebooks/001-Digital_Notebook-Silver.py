# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.rpt_digital_performance_deepdive as
# MAGIC
# MAGIC select
# MAGIC   *
# MAGIC from
# MAGIC main.marketing_lakehouse.rpt_digital_performance_deepdive
# MAGIC   
