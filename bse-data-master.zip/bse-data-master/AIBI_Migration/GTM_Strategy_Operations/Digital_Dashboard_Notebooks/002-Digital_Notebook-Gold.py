# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.digital_dashboard_gold AS
# MAGIC
# MAGIC SELECT 
# MAGIC     account_type,
# MAGIC     --ad_campaign_name,
# MAGIC     ad_offer_name,
# MAGIC     ad_offer_type,
# MAGIC     audience,
# MAGIC     audience_persona,
# MAGIC     business_unit,
# MAGIC     budget_type,
# MAGIC     cloud,
# MAGIC     `date`,
# MAGIC     dbx,
# MAGIC     language,
# MAGIC     medium,
# MAGIC     member_status,
# MAGIC     objective,
# MAGIC     offer,
# MAGIC     region,
# MAGIC     sfdc_campaign_id,
# MAGIC     --sfdc_team,
# MAGIC     source,
# MAGIC     sub_region,
# MAGIC     clicks,
# MAGIC     cost,
# MAGIC     impressions,
# MAGIC     mql_response,
# MAGIC     net_new_names,
# MAGIC     quality_net_new_names,
# MAGIC     responders,
# MAGIC     u2_amount,
# MAGIC     u2_unit,
# MAGIC     DATE(DATE_TRUNC('MONTH', CURRENT_DATE())) AS current_date_month,
# MAGIC     DATE(CURRENT_DATE()) AS current_date_today,
# MAGIC     --DATE_ADD(DATE_TRUNC('WEEK', CURRENT_DATE()), 3) AS current_date_week_ending_thursday,
# MAGIC     DATE(DATE_TRUNC('YEAR', CURRENT_DATE())) AS current_date_year,
# MAGIC     DATE(DATE_TRUNC('MONTH', `date`)) AS date_month,
# MAGIC     DATE(DATE_TRUNC('YEAR', `date`)) AS date_year,
# MAGIC     (SUM(cost) / NULLIF(SUM(clicks), 0)) AS cpc,
# MAGIC     (SUM(cost) / NULLIF(SUM(mql_response), 0)) AS cpmql,
# MAGIC     (SUM(cost) / NULLIF(SUM(net_new_names), 0)) AS cpnnn,
# MAGIC     (SUM(cost) / NULLIF(SUM(quality_net_new_names), 0)) AS cpqnnn,
# MAGIC     (SUM(cost) / NULLIF(SUM(responders), 0)) AS cpr,
# MAGIC     (SUM(cost) / NULLIF(SUM(u2_unit), 0)) AS cpu2,
# MAGIC     (SUM(clicks) / NULLIF(SUM(impressions), 0)) AS ctr,
# MAGIC     (SUM(responders) / NULLIF(SUM(clicks), 0)) AS cvr,
# MAGIC     (SUM(u2_unit) / 3487) AS fy25q2_u2_target_attainment,
# MAGIC     (SUM(mql_response) / NULLIF(SUM(responders), 0)) AS mql_rate,
# MAGIC     (SUM(quality_net_new_names) / NULLIF(SUM(net_new_names), 0)) AS nnn_to_qnnn_rate, --and quality rate?
# MAGIC     (SUM(u2_unit) / NULLIF(SUM(quality_net_new_names), 0)) AS qnnn_to_u2_rate,
# MAGIC     (SUM(net_new_names) / NULLIF(SUM(responders), 0)) AS response_to_nnn_rate,
# MAGIC     u2_amount * 12 AS u2_amount_arr,
# MAGIC     (SUM(u2_amount * 12) / NULLIF(SUM(cost), 0)) AS u2_pipe_to_spent_ratio_arr --and U2 ROI?
# MAGIC FROM 
# MAGIC     main.it_aibi_silver.rpt_digital_performance_deepdive
# MAGIC GROUP BY 
# MAGIC    ALL
