# Databricks notebook source
# Import necessary libraries
%pip install gspread
%pip install pygsheets

# COMMAND ----------

# DBTITLE 1,Gsheet Functions

import json
import pandas as pd
import gspread
from dataclasses import dataclass
from pyspark.sql import DataFrame
import pygsheets
from tempfile import NamedTemporaryFile

# Define a data class to hold GCP service account information
@dataclass(frozen=True)
class GCPServiceAccount:
    name: str
    secrets_scope: str
    creds_key: str

# Configuration for accessing GCP service account credentials stored in Databricks secrets
env_configs = {
    "dev": GCPServiceAccount(
        name='dev-bse-storage-access-sa',
        secrets_scope='bse-dev-creds',
        creds_key='gcp_dev_bse_creds'
    ),
    "prod": GCPServiceAccount(
        name='dev-bse-storage-access-sa',
        secrets_scope='bse-dev-creds',
        creds_key='gcp_dev_bse_creds'
    )
}

def retrieve_gcp_dev_bse_serv_acc_creds(sa: GCPServiceAccount, dbutils) -> dict:
    """
    Retrieves GCP service account credentials from Databricks secrets.
    
    Parameters:
        - sa: An instance of GCPServiceAccount containing the service account details.
    
    Returns:
        - A dictionary containing the service account credentials.
    """
    return (json.loads(dbutils.secrets.get(scope=sa.secrets_scope, key=sa.creds_key)))

def open_gsheet_by_id(gsheet_id: str, service_account: GCPServiceAccount, dbutils):
    """
    Opens a Google Sheet by its ID using credentials of a specified GCP service account.
    
    Parameters:
        - gsheet_id (str):  The ID of the Google Sheet to be accessed.
        - service_account:  An instance of GCPServiceAccount to use for authentication.
    
    Returns:
        - An instance of gspread.models.Spreadsheet representing the opened Google Sheet.
    """
    gc = gspread.service_account_from_dict(retrieve_gcp_dev_bse_serv_acc_creds(service_account, dbutils))
    return gc.open_by_key(gsheet_id)

def read_google_worksheet_data(gsheet_id: str, worksheet_id: str, dbutils, spark, env: str='dev', data_range : str=None, columnList: list = None) -> DataFrame:
    """
    This function reads data from a specified worksheet within a Google Sheet and returns it as a Spark DataFrame. It utilizes a GCP service account to access the Google Sheet data, so you'll need to ensure that the provided GCP service account has the necessary permissions (view) to the Google Sheet.
        - dev: dev-bse-storage-access-sa@gcp-dev-bse.iam.gserviceaccount.com
        - prod: prd-bse-storage-access-sa@gcp-prod-bse.iam.gserviceaccount.com

    Deficiencies:
        - Considers 1st row as header by default


    Parameters:
        - gsheet_id (str):              This parameter represents the unique identifier for the Google Sheets document. 
                                        You can find this ID    within the Google Sheets URL. It is the part of the URL that immediately follows 'https://docs.google.com/spreadsheets/d/' and precedes 'edit#gid=<worksheet_id>'. For instance, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then 'abc123' is the gsheet_id.

        - worksheet_id (str):           This parameter refers to the specific worksheet within the Google Sheets document from 
                                        which you want to retrieve data. It can be identified from the Google Sheets URL. It comes after 'gid=' in the URL. For example, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then '456' is the worksheet_id.

        - dbutils and spark:            Imported Python modules don't have access to the notebook context (i.e., can't see things like the
                                        global "spark" and "dbutils" objects), so we have to pass dbutils & spark in.

        - env (str):                    The environment to use ('dev' or 'prod'). Determines which service account to use.

        - data_range (str, optional):   A specific range of cells to read from the worksheet.

        - columnList (str, optional):   Please mention the list of columns that you want to extract from the gsheet.
    

    Returns:
        - A Spark DataFrame containing the data read from the worksheet.
    """
    # Select the service account based on the environment
    service_account = env_configs[env]
    gsheet = open_gsheet_by_id(gsheet_id, service_account, dbutils)
    worksheet = gsheet.get_worksheet_by_id(int(worksheet_id))

    if data_range:
        ws_data = worksheet.get_values(data_range)
    else:
        ws_data = worksheet.get_values()
    if not ws_data:
      raise ValueError("The worksheet is empty or does not exist.")

    header = ws_data[0] # Considering 1st row as header
    # Checking if all the columns mentioned in columnList are present
    if columnList is None:
        columnList = []
    missing_columns = [col for col in columnList if col not in header]
    if missing_columns:
        raise ValueError(f"The following columns are missing in the worksheet: {', '.join(missing_columns)}")

    if not columnList:
        columnList = header

    selected_indices = [header.index(col) for col in columnList]
    filtered_data = [[row[i] for i in selected_indices] for row in ws_data[1:]]

    # Use the first row as header and the rest as data
    pd_df = pd.DataFrame(filtered_data, columns=columnList)
    pd_df.fillna("", inplace=True)  # Convert None to empty string

    # Convert column names to lowercase and replace spaces with underscores
    pd_df.columns = [x.lower().replace(" ", "_") for x in pd_df.columns]

    # Create a Spark DataFrame from the pandas DataFrame
    spark_df = spark.createDataFrame(pd_df)
    return spark_df
  
def write_to_google_sheet(gsheet_id: str, worksheet_id: str, pandasDF, dbutils, env: str='dev'):
    """
    This function writes pandas dataframe to a Google Sheet. It utilizes a GCP service account to access the Google Sheet data, so you'll need to ensure that the provided GCP service account has the necessary permissions (edit) to the Google Sheet.
        - dev: dev-bse-storage-access-sa@gcp-dev-bse.iam.gserviceaccount.com
        - prod: prd-bse-storage-access-sa@gcp-prod-bse.iam.gserviceaccount.com

    Parameters:
        - gsheet_id (str):              This parameter represents the unique identifier for the Google Sheets document. 
                                        You can find this ID    within the Google Sheets URL. It is the part of the URL that immediately follows 'https://docs.google.com/spreadsheets/d/' and precedes 'edit#gid=<worksheet_id>'. For instance, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then 'abc123' is the gsheet_id.

        - worksheet_id (str):           This parameter refers to the specific worksheet within the Google Sheets document from 
                                        which you want to retrieve data. It can be identified from the Google Sheets URL. It comes after 'gid=' in the URL. For example, if your Google Sheets URL is 'https://docs.google.com/spreadsheets/d/abc123/edit#gid=456', then '456' is the worksheet_id.

        - pandasDF:                     pandas dataframe containing the data to be written to the worksheet.

        - dbutils:                      Imported Python modules don't have access to the notebook context (i.e., can't see things like the
                                        global "spark" and "dbutils" objects), so we have to pass dbutils & spark in.

        - env (str):                    The environment to use ('dev' or 'prod'). Determines which service account to use.
    """
    # Select the service account based on the environment
    service_account = env_configs[env]

    with NamedTemporaryFile(mode='w+') as f:
      f.write(json.dumps(retrieve_gcp_dev_bse_serv_acc_creds(service_account, dbutils)))
      f.flush()
      auth = pygsheets.authorize(service_file=f.name)

    # Open the spreadsheet and the worksheet
    sh = auth.open_by_key(gsheet_id)
    wks = sh.worksheet('id', worksheet_id)
    wks.set_dataframe(pandasDF, (1, 1), fit=True)
    print('Data upload complete.')

# COMMAND ----------

# gsheet_id ='1ZbuXTRTqhh5eTw5e8ePXuqfx2ElenAKwBixO0UecK0g'
# worksheet_id4 = '2100431409'
# env='dev'
# FY25_SA_Customer_Activation_Existing_Spend_SPIF = read_google_worksheet_data(gsheet_id, worksheet_id4, dbutils, spark, env)

# from pyspark.sql.functions import current_date

# # Function to add current date column
# def add_date_column(df):
#     return df.withColumn("current_date", current_date())
  
# FY25_SA_Customer_Activation_Existing_Spend_SPIF = add_date_column(FY25_SA_Customer_Activation_Existing_Spend_SPIF)

# # Function to rename columns and save as table
# def rename_and_save(df, table_name):
#     df = df.toDF(*[c if c else f"col_{i}" for i, c in enumerate(df.columns)])
#     #df.write.mode("overwrite").option("mergeSchema", "true").saveAsTable(f"main.it_aibi_bronze.{table_name}")
#     df.write.mode("overwrite").saveAsTable(f"main.it_aibi_bronze.{table_name}")



# # Save FY25_SA_Customer_Activation_Existing_Spend_SPIF
# rename_and_save(FY25_SA_Customer_Activation_Existing_Spend_SPIF, "FY25_SA_Customer_Activation_Existing_Spend_SPIF")

# COMMAND ----------

# Example usage of the read_google_worksheet_data function
gsheet_id ='11xODGOjVXn9w5dxOcwiHD1ewKk7UKkiKRIJ5WxhVELQ'
worksheet_id1 = '0'
worksheet_id2 = '960098306'
worksheet_id3 = '153887782'
worksheet_id4 = '1866718842'
worksheet_id5 = '1799628620'
worksheet_id6 = '1515373976'
worksheet_id7 = '1732133571'
worksheet_id8 = '2001199862'
worksheet_id9 = '1652754096'
worksheet_id10 = '238161238'
worksheet_id11 = '25392358'

# Define the environment ('dev' or 'prod')
env = 'dev'


# Read data from the Google Sheet
SAP_Databricks = read_google_worksheet_data(gsheet_id, worksheet_id1, dbutils, spark, env) 

SAP_Databricks_Customer_Provisioning = read_google_worksheet_data(gsheet_id, worksheet_id2, dbutils, spark, env)

Stable_Edges = read_google_worksheet_data(gsheet_id, worksheet_id3, dbutils, spark, env)

Active_Edges = read_google_worksheet_data(gsheet_id, worksheet_id4, dbutils, spark, env)

Built_On_Commit = read_google_worksheet_data(gsheet_id, worksheet_id5, dbutils, spark, env)

Built_On_Consumption = read_google_worksheet_data(gsheet_id, worksheet_id6, dbutils, spark, env)

dbtLabs = read_google_worksheet_data(gsheet_id, worksheet_id7, dbutils, spark, env)

WAU_Growth = read_google_worksheet_data(gsheet_id, worksheet_id8, dbutils, spark, env)

DB500_UC_Growth = read_google_worksheet_data(gsheet_id, worksheet_id9, dbutils, spark, env)

Competitive_References = read_google_worksheet_data(gsheet_id, worksheet_id10, dbutils, spark, env)

GenAI_Stories = read_google_worksheet_data(gsheet_id, worksheet_id11, dbutils, spark, env)




# COMMAND ----------

from pyspark.sql.functions import current_date

# Function to add current date column
def add_date_column(df):
    return df.withColumn("current_date", current_date())

SAP_Databricks = add_date_column(SAP_Databricks)
SAP_Databricks_Customer_Provisioning = add_date_column(SAP_Databricks_Customer_Provisioning)
Stable_Edges = add_date_column(Stable_Edges)
Active_Edges = add_date_column(Active_Edges)
Built_On_Commit = add_date_column(Built_On_Commit)
Built_On_Consumption = add_date_column(Built_On_Consumption)
dbtLabs = add_date_column(dbtLabs)
WAU_Growth = add_date_column(WAU_Growth)
DB500_UC_Growth = add_date_column(DB500_UC_Growth)
Competitive_References = add_date_column(Competitive_References)
GenAI_Stories = add_date_column(GenAI_Stories)

# COMMAND ----------

# MAGIC %md
# MAGIC #SPIF BRONZE LAYER
# MAGIC

# COMMAND ----------

# Function to rename columns and save as table
def rename_and_save(df, table_name):
    df = df.toDF(*[c if c else f"col_{i}" for i, c in enumerate(df.columns)])
    df.write.mode("overwrite").option("mergeSchema", "true").saveAsTable(f"main.it_aibi_bronze.{table_name}")

# Save SAP_Databricks
rename_and_save(SAP_Databricks, "SAP_Databricks_FY26")

# Save SAP_Databricks_Customer_Provisioning
rename_and_save(SAP_Databricks_Customer_Provisioning, "SAP_Databricks_Customer_Provisioning_FY26")

# Stable_Edges
rename_and_save(Stable_Edges, "Stable_Edges_FY26")

# Save Active_Edges
rename_and_save(Active_Edges, "Active_Edges_FY26")

# Save Built_On_Commit
rename_and_save(Built_On_Commit, "Built_On_Commit_FY26")

# Save Built_On_Consumption
rename_and_save(Built_On_Consumption, "Built_On_Consumption_FY26")

# Save dbtLabs
rename_and_save(dbtLabs, "dbtLabs_FY26")

# Save WAU_Growth
rename_and_save(WAU_Growth, "WAU_Growth_FY26")

# Save DB500_UC_Growth
rename_and_save(DB500_UC_Growth, "DB500_UC_Growth_FY26")

# Save Competitive_References
rename_and_save(Competitive_References, "Competitive_References_FY26")

# Save GenAI_Stories
rename_and_save(GenAI_Stories, "GenAI_Stories_FY26")


# COMMAND ----------

# MAGIC %md
# MAGIC #SPIF SILVER LAYER
# MAGIC

# COMMAND ----------

# DBTITLE 1,SAP_Databricks
from pyspark.sql.functions import col, current_date, regexp_replace

# Read the source table
sap_databricks = spark.table("main.it_aibi_bronze.sap_databricks_fy26")

# Apply transformations
sap_databricks = sap_databricks.withColumn("quota_credit", regexp_replace(col("quota_credit"), "^\$", "")) \
    .withColumn("quota_credit", regexp_replace(col("quota_credit"), ",", "")) \
    .withColumn("quota_credit", col("quota_credit").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "quota_credit",
        "currency",
        "country",
        "ldow",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
sap_databricks.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.sap_databricks_fy26")

# COMMAND ----------

# DBTITLE 1,SAP_Databricks_Customer_Provisioning
from pyspark.sql.functions import col, current_date, regexp_replace, lit

# Read the source table
sap_databricks_customer_provisioning = spark.table("main.it_aibi_bronze.sap_databricks_customer_provisioning_fy26")

# Apply transformations
sap_databricks_customer_provisioning = sap_databricks_customer_provisioning.withColumn("amount", regexp_replace(col("amount"), "^\$", "")) \
    .withColumn("amount", regexp_replace(col("amount"), ",", "")) \
    .withColumn("amount", col("amount").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "amount",
        "currency",
        "country",
        "ldow",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
sap_databricks_customer_provisioning.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.sap_databricks_customer_provisioning_fy26")

# COMMAND ----------

# DBTITLE 1,Stable_Edges
from pyspark.sql.functions import col, current_date, regexp_replace

# Read the source table
stable_edges = spark.table("main.it_aibi_bronze.stable_edges_fy26")

# Apply transformations
stable_edges = stable_edges.withColumn("amount", regexp_replace(col("amount"), "^\$", "")) \
    .withColumn("amount", regexp_replace(col("amount"), ",", "")) \
    .withColumn("amount", col("amount").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "amount",
        "currency",
        "country",
        "ldow",
        "consumer_name",
        "provider_or_consumer",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
stable_edges.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.stable_edges_fy26")


# COMMAND ----------

# DBTITLE 1,Active_Edges
from pyspark.sql.functions import col, current_date, regexp_replace

# Read the source table
active_edges = spark.table("main.it_aibi_bronze.active_edges_fy26")

# Apply transformations
active_edges = active_edges.withColumn("amount", regexp_replace(col("amount"), "^\$", "")) \
    .withColumn("amount", regexp_replace(col("amount"), ",", "")) \
    .withColumn("amount", col("amount").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "amount",
        "currency",
        "country",
        "ldow",
        "consumer_name",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
active_edges.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.active_edges_fy26")


# COMMAND ----------

# DBTITLE 1,Built_On_Commit
from pyspark.sql.functions import col, current_date, regexp_replace

# Read the source table
built_on_commit = spark.table("main.it_aibi_bronze.built_on_commit_fy26")

# Apply transformations
built_on_commit = built_on_commit.withColumn("quota_credit", regexp_replace(col("quota_credit"), "^\$", "")) \
    .withColumn("quota_credit", regexp_replace(col("quota_credit"), ",", "")) \
    .withColumn("quota_credit", col("quota_credit").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "quota_credit",
        "currency",
        "country",
        "ldow",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
built_on_commit.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.built_on_commit_fy26")


# COMMAND ----------

# DBTITLE 1,Built_On_Consumption
from pyspark.sql.functions import col, current_date, regexp_replace

# Read the source table
built_on_consumption = spark.table("main.it_aibi_bronze.built_on_consumption_fy26")

# Apply transformations
built_on_consumption = built_on_consumption.withColumn("quota_credit", regexp_replace(col("quota_credit"), "^\$", "")) \
    .withColumn("quota_credit", regexp_replace(col("quota_credit"), ",", "")) \
    .withColumn("quota_credit", col("quota_credit").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "quota_credit",
        "currency",
        "country",
        "ldow",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
built_on_consumption.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.built_on_consumption_fy26")

# COMMAND ----------

# DBTITLE 1,dbtLabs
from pyspark.sql.functions import col, current_date, regexp_replace

# Read the source table
dbtLabs = spark.table("main.it_aibi_bronze.dbtLabs_fy26")

# Apply transformations
dbtLabs = dbtLabs.withColumn("quota_credit", regexp_replace(col("quota_credit"), "^\$", "")) \
    .withColumn("quota_credit", regexp_replace(col("quota_credit"), ",", "")) \
    .withColumn("quota_credit", col("quota_credit").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "quota_credit",
        "currency",
        "country",
        "ldow",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
dbtLabs.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.dbtLabs_fy26")

# COMMAND ----------

# DBTITLE 1,WAU_Growth
from pyspark.sql.functions import col, current_date, regexp_replace

# Read the source table
wau_growth = spark.table("main.it_aibi_bronze.wau_growth_fy26")

# Apply transformations
wau_growth = wau_growth.withColumn("amount", regexp_replace(col("amount"), "^\$", "")) \
    .withColumn("amount", regexp_replace(col("amount"), ",", "")) \
    .withColumn("amount", col("amount").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "amount",
        "currency",
        "country",
        "ldow",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
wau_growth.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.wau_growth_fy26")



# COMMAND ----------

# DBTITLE 1,DB500_UC_Growth
from pyspark.sql.functions import col, current_date, regexp_replace

# Read the source table
db500_uc_growth = spark.table("main.it_aibi_bronze.db500_uc_growth_fy26")

# Apply transformations
db500_uc_growth = db500_uc_growth.withColumn("amount", regexp_replace(col("amount"), "^\$", "")) \
    .withColumn("amount", regexp_replace(col("amount"), ",", "")) \
    .withColumn("amount", col("amount").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "amount",
        "currency",
        "country",
        "ldow",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
db500_uc_growth.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.db500_uc_growth_fy26")

# COMMAND ----------

# DBTITLE 1,Competitive_References
from pyspark.sql.functions import col, current_date, regexp_replace

# Read the source table
competitive_references = spark.table("main.it_aibi_bronze.competitive_references_fy26")

# Apply transformations
competitive_references = competitive_references.withColumn("amount", regexp_replace(col("amount"), "^\$", "")) \
    .withColumn("amount", regexp_replace(col("amount"), ",", "")) \
    .withColumn("amount", col("amount").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "amount",
        "currency",
        "country",
        "ldow",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
competitive_references.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.competitive_references_fy26")

# COMMAND ----------

# DBTITLE 1,GenAI_Stories
from pyspark.sql.functions import col, current_date, regexp_replace

# Read the source table
genai_stories = spark.table("main.it_aibi_bronze.genai_stories_fy26")

# Apply transformations
genai_stories = genai_stories.withColumn("amount", regexp_replace(col("amount"), "^\$", "")) \
    .withColumn("amount", regexp_replace(col("amount"), ",", "")) \
    .withColumn("amount", col("amount").cast("float")) \
    .select(
        "spif_program_name",
        "customer_name",
        "opportunity_id",
        "rep_name",
        "half",
        col("`rep's_role`"),
        "workday_id",
        "sfdc_id",
        "eligible_period",
        "amount",
        "currency",
        "country",
        "ldow",
        current_date().alias("ingest_date")
    )

# Write the result to a new table
genai_stories.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("main.it_aibi_silver.genai_stories_fy26")

# COMMAND ----------

# MAGIC %md
# MAGIC #Gold Creation

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.sap_databricks_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.sap_databricks_fy26;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.sap_databricks_customer_provisioning_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.sap_databricks_customer_provisioning_fy26;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.stable_edges_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.stable_edges_fy26;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.active_edges_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.active_edges_fy26;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.built_on_commit_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.built_on_commit_fy26;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.built_on_consumption_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.built_on_consumption_fy26;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.dbtLabs_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.dbtLabs_fy26;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.wau_growth_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.wau_growth_fy26;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.db500_uc_growth_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.db500_uc_growth_fy26;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.competitive_references_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.competitive_references_fy26;
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS main.it_aibi_gold.genai_stories_fy26 AS
# MAGIC SELECT * FROM main.it_aibi_silver.genai_stories_fy26;
# MAGIC
