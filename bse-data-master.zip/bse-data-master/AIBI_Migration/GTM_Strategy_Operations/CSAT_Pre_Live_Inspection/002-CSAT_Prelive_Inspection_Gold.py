# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.csat_prelive_inspection_gold
# MAGIC
# MAGIC select
# MAGIC Account_Name,
# MAGIC Account_Owner,
# MAGIC CSAT_Opt_out,
# MAGIC DSA,
# MAGIC Implementation_Strategy,
# MAGIC Last_SA_Engaged,
# MAGIC Partner_Name,
# MAGIC PartnerRole,
# MAGIC ProjectInitiative_Name,
# MAGIC PS_Owner,
# MAGIC PS_Project,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Stage,
# MAGIC Target_Live_Date,
# MAGIC TechProject_Lead,
# MAGIC Use_Case_Id,
# MAGIC Use_Case_Name,
# MAGIC MonthlyTotalDollarDBUs,
# MAGIC COUNT(DISTINCT Use_Case_Id) as Count
# MAGIC from main.it_aibi_silver.csat_prelive_inspection_silver
# MAGIC group by ALL
# MAGIC
