# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.csat_prelive_inspection_silver
# MAGIC
# MAGIC select
# MAGIC Account_Name,
# MAGIC Account_Owner,
# MAGIC CSAT_Opt_out__c as CSAT_Opt_out,
# MAGIC DSA,
# MAGIC Implementation_Strategy__c as Implementation_Strategy,
# MAGIC Last_SA_Engaged,
# MAGIC Partner_Name,
# MAGIC PartnerRole__c as PartnerRole,
# MAGIC Project_Name__c as ProjectInitiative_Name,
# MAGIC PS_Owner__c as PS_Owner,
# MAGIC has_ps_project as PS_Project,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Stages__c as Stage,
# MAGIC Full_Production_Date__c as Target_Live_Date,
# MAGIC Project_Lead as TechProject_Lead,
# MAGIC Use_Case_Id,
# MAGIC Use_Case_Name,
# MAGIC MonthlyTotalDollarDBUs__c as MonthlyTotalDollarDBUs
# MAGIC from main.gtm_partner_data.csi_partner_use_case
# MAGIC
