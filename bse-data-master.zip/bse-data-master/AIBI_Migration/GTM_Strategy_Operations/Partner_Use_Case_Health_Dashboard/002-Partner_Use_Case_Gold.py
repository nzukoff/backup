# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.partner_use_case_gold as
# MAGIC
# MAGIC select
# MAGIC Account_Name,
# MAGIC Account_Owner,
# MAGIC ARR_Band,
# MAGIC DBX,
# MAGIC FiscalQuarter,
# MAGIC FiscalYear,
# MAGIC CONCAT(CAST(FiscalYear AS STRING), '-', FiscalQuarter) AS fiscal_quarter_year,
# MAGIC has_ps_project,
# MAGIC managed_coverage,
# MAGIC Partner_Name,
# MAGIC Partner_Tech_Lead,
# MAGIC PartnerImpact__c,
# MAGIC PartnerRole__c,
# MAGIC Products_Utilized,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Region_3,
# MAGIC Region_4,
# MAGIC Stage,
# MAGIC Use_Case_Id,
# MAGIC Use_Case_Name,
# MAGIC Days_U2_to_U3,
# MAGIC Days_U3_to_U4,
# MAGIC Days_U4_to_U5,
# MAGIC Days_U5_to_U6,
# MAGIC MonthlyTotalDollarDBUs__c,
# MAGIC Total_Days_U2_to_U6
# MAGIC from main.it_aibi_silver.partner_use_case_silver
