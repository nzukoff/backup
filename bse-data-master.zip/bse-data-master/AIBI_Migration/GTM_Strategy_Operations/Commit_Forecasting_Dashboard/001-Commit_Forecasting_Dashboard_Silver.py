# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.commit_forecasting_silver
# MAGIC
# MAGIC select
# MAGIC FQ,
# MAGIC FiscalYear,
# MAGIC Forecast_Category,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Region_3,
# MAGIC Region_4,
# MAGIC Commit_ID,
# MAGIC New_Logo,
# MAGIC Manager_Forecast,
# MAGIC Stage,
# MAGIC Partner_Tier,
# MAGIC Parent_Account,
# MAGIC Partner_Impact,
# MAGIC PAM_Name,
# MAGIC Commit_Type,
# MAGIC `Primary`,
# MAGIC Opportunity_Name,
# MAGIC Migration_Commit,
# MAGIC Brickbuilder_Migration,
# MAGIC Close_Date,
# MAGIC Partner_Weighted_Amount as attr_sub_total_weighted,
# MAGIC Attributable_Subscription as attr_sub_total
# MAGIC from main.gtm_partner_data.csi_partner_commit_fcst
# MAGIC group by all
# MAGIC
