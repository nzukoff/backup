# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.commit_forecasting_gold as
# MAGIC
# MAGIC SELECT
# MAGIC FQ,
# MAGIC FiscalYear,
# MAGIC Forecast_Category,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Region_3,
# MAGIC Region_4,
# MAGIC Commit_ID,
# MAGIC New_Logo,
# MAGIC Manager_Forecast,
# MAGIC Stage,
# MAGIC Partner_Tier,
# MAGIC Parent_Account,
# MAGIC Partner_Impact,
# MAGIC PAM_Name,
# MAGIC Commit_Type,
# MAGIC `Primary`,
# MAGIC Opportunity_Name,
# MAGIC Migration_Commit,
# MAGIC Brickbuilder_Migration,
# MAGIC Close_Date,
# MAGIC attr_sub_total_weighted,
# MAGIC attr_sub_total,
# MAGIC SUM(
# MAGIC   CASE
# MAGIC     WHEN Partner_Impact = "Partner Sourced" THEN attr_sub_total_weighted 
# MAGIC     ELSE 0
# MAGIC   END
# MAGIC ) AS sourced_fc_dollars,
# MAGIC COUNT(DISTINCT
# MAGIC   CASE
# MAGIC     WHEN new_logo=true
# MAGIC     AND manager_forecast in ('Commit','Closed')
# MAGIC     THEN commit_id
# MAGIC   END
# MAGIC ) AS total_nls,
# MAGIC COUNT(DISTINCT
# MAGIC   CASE
# MAGIC     WHEN new_logo=true
# MAGIC     AND partner_impact='Partner Sourced'
# MAGIC     AND manager_forecast in ('Commit','Closed')
# MAGIC     THEN commit_id
# MAGIC   END
# MAGIC ) AS sourced_nls
# MAGIC FROM
# MAGIC   main.it_aibi_silver.commit_forecasting_silver
# MAGIC GROUP BY
# MAGIC FQ,
# MAGIC FiscalYear,
# MAGIC Forecast_Category,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Region_3,
# MAGIC Region_4,
# MAGIC Commit_ID,
# MAGIC New_Logo,
# MAGIC Manager_Forecast,
# MAGIC Stage,
# MAGIC Partner_Tier,
# MAGIC Parent_Account,
# MAGIC Partner_Impact,
# MAGIC PAM_Name,
# MAGIC Commit_Type,
# MAGIC `Primary`,
# MAGIC Opportunity_Name,
# MAGIC Migration_Commit,
# MAGIC Brickbuilder_Migration,
# MAGIC Close_Date,
# MAGIC attr_sub_total_weighted,
# MAGIC attr_sub_total
