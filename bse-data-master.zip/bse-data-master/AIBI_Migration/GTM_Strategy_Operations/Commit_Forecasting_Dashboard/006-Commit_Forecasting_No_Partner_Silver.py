# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.commit_forecasting_no_partner_gold as
# MAGIC
# MAGIC SELECT
# MAGIC *
# MAGIC from main.it_aibi_silver.commit_forecasting_no_partner_silver
