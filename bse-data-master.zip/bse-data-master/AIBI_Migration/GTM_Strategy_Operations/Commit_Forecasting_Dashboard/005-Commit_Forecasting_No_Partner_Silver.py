# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.commit_forecasting_no_partner_silver
# MAGIC
# MAGIC select
# MAGIC Stage,
# MAGIC Manager_Forecast,
# MAGIC FQ,
# MAGIC Weighted_Amount,
# MAGIC Subscription_Total,
# MAGIC Opportunity_Name,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Region_3,
# MAGIC Region_4,
# MAGIC Migration_Commit,
# MAGIC New_Logo,
# MAGIC Close_Date,
# MAGIC Commit_ID
# MAGIC from main.gtm_partner_data.csi_partner_nopartner_commits
# MAGIC group by all
