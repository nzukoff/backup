# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.commit_forecasting_direct_silver
# MAGIC
# MAGIC with direct as(
# MAGIC   select
# MAGIC   FQ,
# MAGIC   Commit_Type,
# MAGIC   Commit_ID,
# MAGIC   Region,
# MAGIC   Region_2,
# MAGIC   Region_3,
# MAGIC   Region_4,
# MAGIC   sum(Weighted_Amount) as direct_sales_weighted
# MAGIC   from main.gtm_partner_data.csi_partner_direct_commits_fcst
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC commits as (
# MAGIC   select
# MAGIC   Region,
# MAGIC   Region_2,
# MAGIC   Region_3,
# MAGIC   Region_4,
# MAGIC   commit_id,
# MAGIC   fq,
# MAGIC   sum(Partner_Weighted_Amount) as attr_sub_total_weighted,
# MAGIC   SUM(
# MAGIC     CASE
# MAGIC       WHEN Partner_Impact = "Partner Sourced" THEN Partner_Weighted_Amount 
# MAGIC       ELSE 0
# MAGIC     END
# MAGIC   ) AS sourced_fc_dollars
# MAGIC   from main.gtm_partner_data.csi_partner_commit_fcst
# MAGIC   group by all
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC d.FQ,
# MAGIC d.Commit_Type,
# MAGIC d.Region,
# MAGIC d.Region_2,
# MAGIC d.Region_3,
# MAGIC d.Region_4,
# MAGIC d.commit_id,
# MAGIC d.direct_sales_weighted,
# MAGIC c.attr_sub_total_weighted,
# MAGIC c.sourced_fc_dollars
# MAGIC from direct d
# MAGIC left join commits c
# MAGIC on d.fq=c.fq
# MAGIC and d.commit_id=c.commit_id
# MAGIC AND d.region=c.region
# MAGIC AND d.region_2=c.region_2
# MAGIC AND d.region_3=c.region_3
# MAGIC AND d.region_4=c.region_4
# MAGIC
