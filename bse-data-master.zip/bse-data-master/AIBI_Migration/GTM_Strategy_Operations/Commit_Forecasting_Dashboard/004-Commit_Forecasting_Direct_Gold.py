# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.commit_forecasting_direct_gold as
# MAGIC
# MAGIC SELECT
# MAGIC FQ,
# MAGIC Commit_Type,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Region_3,
# MAGIC Region_4,
# MAGIC commit_id,
# MAGIC direct_sales_weighted,
# MAGIC attr_sub_total_weighted,
# MAGIC sourced_fc_dollars
# MAGIC
# MAGIC /*
# MAGIC   -- FC PE% Sourced
# MAGIC   (SUM(sourced_fc_dollars) / NULLIF(SUM(direct_sales_weighted),0)) AS FC_PE_Percent_Sourced,
# MAGIC
# MAGIC   -- FC PE% Total
# MAGIC   (SUM(attr_sub_total_weighted) / NULLIF(SUM(direct_sales_weighted),0)) AS FC_PE_Percent_Total
# MAGIC */
# MAGIC
# MAGIC FROM
# MAGIC   main.it_aibi_silver.commit_forecasting_direct_silver
# MAGIC GROUP BY
# MAGIC FQ,
# MAGIC Commit_Type,
# MAGIC Region,
# MAGIC Region_2,
# MAGIC Region_3,
# MAGIC Region_4,
# MAGIC commit_id,
# MAGIC direct_sales_weighted,
# MAGIC attr_sub_total_weighted,
# MAGIC sourced_fc_dollars
