# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.general_analysis_gold AS
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     account_type,
# MAGIC     ad_group_name,
# MAGIC     ad_type,
# MAGIC     audience,
# MAGIC     budget_type,
# MAGIC     campaign_name,
# MAGIC     date,
# MAGIC     dbx,
# MAGIC     medium,
# MAGIC     objective,
# MAGIC     offer,
# MAGIC     region,
# MAGIC     source,
# MAGIC     sub_audience,
# MAGIC     sub_region,
# MAGIC     COALESCE(clicks, 0) as clicks,
# MAGIC     COALESCE(cost, 0) as cost,
# MAGIC     COALESCE(engagements, 0) as engagements,
# MAGIC     COALESCE(impressions, 0) as impressions,
# MAGIC     COALESCE(mql_response, 0) as mql_response,
# MAGIC     COALESCE(net_new_names, 0) as net_new_names,
# MAGIC     COALESCE(quality_net_new_names, 0) as quality_net_new_names,
# MAGIC     COALESCE(responders, 0) as responders,
# MAGIC     COALESCE(u2_amount, 0) as u2_amount,
# MAGIC     COALESCE(u2_unit, 0) as u2_unit,
# MAGIC     SUM(COALESCE(cost, 0)) OVER (PARTITION BY date) AS total_cost,
# MAGIC     SUM(COALESCE(u2_amount, 0) * 12) OVER (PARTITION BY date) AS total_u2_amount_arr,
# MAGIC     SUM(COALESCE(clicks, 0)) OVER (PARTITION BY date) AS total_clicks,
# MAGIC     SUM(COALESCE(mql_response, 0)) OVER (PARTITION BY date) AS total_mql_response,
# MAGIC     SUM(COALESCE(net_new_names, 0)) OVER (PARTITION BY date) AS total_net_new_names,
# MAGIC     SUM(COALESCE(quality_net_new_names, 0)) OVER (PARTITION BY date) AS total_quality_net_new_names,
# MAGIC     SUM(COALESCE(responders, 0)) OVER (PARTITION BY date) AS total_responders,
# MAGIC     SUM(COALESCE(u2_unit, 0)) OVER (PARTITION BY date) AS total_u2_unit,
# MAGIC     SUM(COALESCE(impressions, 0)) OVER (PARTITION BY date) AS total_impressions
# MAGIC   FROM main.it_aibi_silver.general_analysis_silver
# MAGIC ),
# MAGIC lagged_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     LAG(total_cost) OVER (ORDER BY date) AS prev_total_cost
# MAGIC   FROM base_data
# MAGIC )
# MAGIC SELECT 
# MAGIC   account_type,
# MAGIC   ad_group_name,
# MAGIC   ad_type,
# MAGIC   audience,
# MAGIC   budget_type,
# MAGIC   campaign_name,
# MAGIC   date AS Date_FY,
# MAGIC   dbx,
# MAGIC   medium,
# MAGIC   objective,
# MAGIC   offer,
# MAGIC   region,
# MAGIC   source,
# MAGIC   sub_audience,
# MAGIC   sub_region,
# MAGIC   clicks,
# MAGIC   cost,
# MAGIC   engagements,
# MAGIC   impressions,
# MAGIC   mql_response,
# MAGIC   net_new_names,
# MAGIC   quality_net_new_names,
# MAGIC   responders,
# MAGIC   u2_amount,
# MAGIC   u2_unit,
# MAGIC   CASE 
# MAGIC     WHEN prev_total_cost = 0 OR prev_total_cost IS NULL THEN NULL
# MAGIC     ELSE (total_cost - prev_total_cost) / ABS(prev_total_cost)
# MAGIC   END AS Percentage_Change_in_cost,
# MAGIC   CASE WHEN total_cost = 0 THEN NULL ELSE total_u2_amount_arr / total_cost END AS ARR_Pipe_Spend,
# MAGIC   CASE WHEN total_clicks = 0 THEN NULL ELSE total_cost / total_clicks END AS CPC,
# MAGIC   CASE WHEN total_mql_response = 0 THEN NULL ELSE total_cost / total_mql_response END AS CPMQL,
# MAGIC   CASE WHEN total_net_new_names = 0 THEN NULL ELSE total_cost / total_net_new_names END AS CPNNN,
# MAGIC   CASE WHEN total_quality_net_new_names = 0 THEN NULL ELSE total_cost / total_quality_net_new_names END AS CPQNNN,
# MAGIC   CASE WHEN total_quality_net_new_names = 0 THEN NULL ELSE (total_responders * 25) / total_quality_net_new_names END AS CPQNNN_3P_Calc_BlueWhale,
# MAGIC   CASE WHEN total_quality_net_new_names = 0 THEN NULL ELSE (total_responders * 18) / total_quality_net_new_names END AS CPQNNN_3P_Calc_DigitalZone,
# MAGIC   CASE WHEN total_responders = 0 THEN NULL ELSE total_cost / total_responders END AS CPR,
# MAGIC   CASE WHEN total_u2_unit = 0 THEN NULL ELSE total_cost / total_u2_unit END AS CPU2,
# MAGIC   CASE WHEN total_u2_unit = 0 THEN NULL ELSE (total_responders * 25) / total_u2_unit END AS CPU2_3P_Calc_BlueWhale,
# MAGIC   CASE WHEN total_u2_unit = 0 THEN NULL ELSE (total_responders * 18) / total_u2_unit END AS CPU2_3P_Calc_DigitalZone,
# MAGIC   CASE WHEN total_impressions = 0 THEN NULL ELSE total_clicks / total_impressions END AS CTR,
# MAGIC   CASE WHEN total_clicks = 0 THEN NULL ELSE total_responders / total_clicks END AS CVR,
# MAGIC   CASE WHEN total_responders = 0 THEN NULL ELSE total_mql_response / total_responders END AS MQL_Rate,
# MAGIC   CASE WHEN total_mql_response = 0 THEN NULL ELSE total_u2_unit / total_mql_response END AS MQL_to_U2_Rate,
# MAGIC   CASE WHEN total_net_new_names = 0 THEN NULL ELSE total_quality_net_new_names / total_net_new_names END AS Quality_Net_New_Name_Rate,
# MAGIC   CASE WHEN total_responders = 0 THEN NULL ELSE total_net_new_names / total_responders END AS Response_to_NNN_Rate,
# MAGIC   u2_amount * 12 AS u2_amount_arr
# MAGIC FROM lagged_data
# MAGIC ORDER BY date
