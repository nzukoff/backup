# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.general_analysis_silver as
# MAGIC
# MAGIC select
# MAGIC account_type,
# MAGIC ad_group_name,
# MAGIC ad_type,
# MAGIC audience,
# MAGIC budget_type,
# MAGIC campaign_name,
# MAGIC `date`,
# MAGIC dbx,
# MAGIC medium,
# MAGIC objective,
# MAGIC offer,
# MAGIC region,
# MAGIC source,
# MAGIC sub_audience,
# MAGIC sub_region,
# MAGIC clicks,
# MAGIC cost,
# MAGIC engagements,
# MAGIC impressions,
# MAGIC mql_response,
# MAGIC net_new_names,
# MAGIC quality_net_new_names,
# MAGIC responders,
# MAGIC u2_amount,
# MAGIC u2_unit
# MAGIC from main.marketing_lakehouse.rpt_digital_performance_deepdive
