# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.vertical_revenue_backlog_gold as
# MAGIC
# MAGIC SELECT 
# MAGIC   account_id,
# MAGIC   account_name,
# MAGIC   is_bif,
# MAGIC   opportunity_billing_schedule,
# MAGIC   opportunity_id,
# MAGIC   opportunity_name,
# MAGIC   project_start_date,
# MAGIC   project_id,
# MAGIC   project_name,
# MAGIC   project_service_type,
# MAGIC   sales_region,
# MAGIC   sales_subregion_level_1,
# MAGIC   sales_subregion_level_2,
# MAGIC   sales_subregion_level_3,
# MAGIC   snapshot_date,
# MAGIC   unscheduled_backlog,
# MAGIC   DATEDIFF(project_end_date, CURRENT_DATE()) AS days_to_expiry
# MAGIC
# MAGIC FROM main.it_aibi_silver.vertical_revenue_backlog_silver 
