# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.vertical_revenue_accounts_silver AS
# MAGIC
# MAGIC WITH backlog_full as (  
# MAGIC   select
# MAGIC   account_id,
# MAGIC   account_name,
# MAGIC   is_bif,
# MAGIC   project_service_type,
# MAGIC   sales_subregion_level_1,
# MAGIC   sales_subregion_level_2,
# MAGIC   snapshot_date,
# MAGIC   SUM(unscheduled_backlog) AS unscheduled_backlog
# MAGIC   from main.it_aibi_silver.vertical_revenue_backlog_silver b
# MAGIC   where snapshot_date=current_date()
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC backlog_part as (
# MAGIC   select
# MAGIC   account_id,
# MAGIC   snapshot_date,
# MAGIC   sum(unscheduled_backlog) as unscheduled_backlog
# MAGIC   from main.it_aibi_silver.vertical_revenue_backlog_silver b
# MAGIC   where snapshot_date=current_date()
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC backlog as (
# MAGIC   select
# MAGIC   f.account_id,
# MAGIC   sum(f.unscheduled_backlog) as unscheduled_backlog
# MAGIC   from backlog_full f
# MAGIC   left join backlog_part p
# MAGIC   on f.account_id=p.account_id
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC reporting AS (
# MAGIC   SELECT 
# MAGIC     r.account_id AS revenue_account_id,
# MAGIC     r.account_name,
# MAGIC     r.delivered_date,
# MAGIC     r.delivered_fiscal_quarter_start_date,
# MAGIC     r.delivered_fiscal_year,
# MAGIC     r.delivered_fiscal_year_quarter,
# MAGIC     r.delivered_month_end_date,
# MAGIC     r.delivered_month_start_date,
# MAGIC     r.is_bif,
# MAGIC     r.project_service_type,
# MAGIC     r.row_type,
# MAGIC     r.sales_subregion_level_1,
# MAGIC     r.sales_subregion_level_2,
# MAGIC     SUM(r.cs_delivered_revenue) AS cs_delivered_revenue,
# MAGIC     SUM(r.ps_delivered_revenue) AS ps_delivered_revenue,
# MAGIC     SUM(r.total_delivered_revenue) AS total_delivered_revenue,
# MAGIC     SUM(r.training_delivered_revenue) AS training_delivered_revenue,
# MAGIC     r.t3m_annualized, 
# MAGIC     r.arr
# MAGIC   FROM main.it_aibi_silver.vertical_revenue_reporting_silver r
# MAGIC   WHERE r.delivered_month_start_date>='2023-02-01'
# MAGIC   GROUP BY 
# MAGIC     r.account_id,
# MAGIC     r.account_name,
# MAGIC     r.delivered_date,
# MAGIC     r.delivered_fiscal_quarter_start_date,
# MAGIC     r.delivered_fiscal_year,
# MAGIC     r.delivered_fiscal_year_quarter,
# MAGIC     r.delivered_month_end_date,
# MAGIC     r.delivered_month_start_date,
# MAGIC     r.is_bif,
# MAGIC     r.project_service_type,
# MAGIC     r.row_type,
# MAGIC     r.sales_subregion_level_1,
# MAGIC     r.sales_subregion_level_2,
# MAGIC     r.t3m_annualized, 
# MAGIC     r.arr
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   b.account_id,
# MAGIC   b.unscheduled_backlog,
# MAGIC   r.revenue_account_id,
# MAGIC   r.account_name,
# MAGIC   r.delivered_date,
# MAGIC   r.delivered_fiscal_quarter_start_date,
# MAGIC   r.delivered_fiscal_year,
# MAGIC   r.delivered_fiscal_year_quarter,
# MAGIC   r.delivered_month_end_date,
# MAGIC   r.delivered_month_start_date,
# MAGIC   r.is_bif,
# MAGIC   r.project_service_type,
# MAGIC   r.row_type,
# MAGIC   r.sales_subregion_level_1,
# MAGIC   r.sales_subregion_level_2,
# MAGIC   r.cs_delivered_revenue,
# MAGIC   r.ps_delivered_revenue,
# MAGIC   r.total_delivered_revenue,
# MAGIC   r.training_delivered_revenue,
# MAGIC   r.arr,
# MAGIC   r.t3m_annualized
# MAGIC FROM reporting r
# MAGIC LEFT JOIN backlog b
# MAGIC   ON r.revenue_account_id = b.account_id
# MAGIC GROUP BY 
# MAGIC   b.account_id,
# MAGIC   b.unscheduled_backlog,
# MAGIC   r.revenue_account_id,
# MAGIC   r.account_name,
# MAGIC   r.delivered_date,
# MAGIC   r.delivered_fiscal_quarter_start_date,
# MAGIC   r.delivered_fiscal_year,
# MAGIC   r.delivered_fiscal_year_quarter,
# MAGIC   r.delivered_month_end_date,
# MAGIC   r.delivered_month_start_date,
# MAGIC   r.is_bif,
# MAGIC   r.project_service_type,
# MAGIC   r.row_type,
# MAGIC   r.sales_subregion_level_1,
# MAGIC   r.sales_subregion_level_2,
# MAGIC   r.cs_delivered_revenue,
# MAGIC   r.ps_delivered_revenue,
# MAGIC   r.total_delivered_revenue,
# MAGIC   r.training_delivered_revenue,
# MAGIC   r.arr,
# MAGIC   r.t3m_annualized

# COMMAND ----------

# %sql

# /*CREATE OR REPLACE TABLE main.it_aibi_silver.vertical_revenue_accounts_silver AS

# WITH backlog AS (
#   SELECT 
#     b.account_id,
#     b.account_name,
#     b.is_bif,
#     b.project_service_type,
#     b.sales_subregion_level_1,
#     b.sales_subregion_level_2,
#     b.snapshot_date,
#     SUM(b.unscheduled_backlog) AS unscheduled_backlog
#   FROM main.it_aibi_silver.vertical_revenue_backlog_silver b
#   where b.snapshot_date = current_date()
#   GROUP BY 
#     b.account_id,
#     b.account_name,
#     b.is_bif,
#     b.project_service_type,
#     b.sales_subregion_level_1,
#     b.sales_subregion_level_2,
#     b.snapshot_date
# ),

# reporting AS (
#   SELECT 
#     r.account_id AS revenue_account_id,
#     r.account_name AS revenue_account_name,
#     r.delivered_date,
#     r.delivered_fiscal_quarter_start_date,
#     r.delivered_fiscal_year,
#     r.delivered_fiscal_year_quarter,
#     r.delivered_month_end_date,
#     r.delivered_month_start_date,
#     r.is_bif,
#     r.project_service_type,
#     r.row_type,
#     r.sales_subregion_level_1,
#     r.sales_subregion_level_2,
#     SUM(r.cs_delivered_revenue) AS cs_delivered_revenue,
#     SUM(r.ps_delivered_revenue) AS ps_delivered_revenue,
#     SUM(r.total_delivered_revenue) AS total_delivered_revenue,
#     SUM(r.training_delivered_revenue) AS training_delivered_revenue,
#     r.t3m_annualized, 
#     r.arr
#   FROM main.it_aibi_silver.vertical_revenue_reporting_silver r
#   WHERE r.delivered_month_start_date>='2023-02-01'
#   GROUP BY 
#     r.account_id,
#     r.account_name,
#     r.delivered_date,
#     r.delivered_fiscal_quarter_start_date,
#     r.delivered_fiscal_year,
#     r.delivered_fiscal_year_quarter,
#     r.delivered_month_end_date,
#     r.delivered_month_start_date,
#     r.is_bif,
#     r.project_service_type,
#     r.row_type,
#     r.sales_subregion_level_1,
#     r.sales_subregion_level_2,
#     r.t3m_annualized, 
#     r.arr
# )

# SELECT
#   b.account_id,
#   b.account_name,
#   b.project_service_type AS backlog_project_service_type,
#   b.sales_subregion_level_1 AS backlog_sales_subregion_level_1,
#   b.sales_subregion_level_2 AS backlog_sales_subregion_level_2,
#   b.snapshot_date,
#   b.unscheduled_backlog,
#   r.revenue_account_id,
#   r.revenue_account_name,
#   r.delivered_date,
#   r.delivered_fiscal_quarter_start_date,
#   r.delivered_fiscal_year,
#   r.delivered_fiscal_year_quarter,
#   r.delivered_month_end_date,
#   r.delivered_month_start_date,
#   r.is_bif,
#   r.project_service_type,
#   r.row_type,
#   r.sales_subregion_level_1,
#   r.sales_subregion_level_2,
#   r.cs_delivered_revenue,
#   r.ps_delivered_revenue,
#   r.total_delivered_revenue,
#   r.training_delivered_revenue,
#   r.arr,
#   r.t3m_annualized
# FROM reporting r
# LEFT JOIN backlog b
#   ON r.revenue_account_id = b.account_id
#   AND r.sales_subregion_level_2 = b.sales_subregion_level_2
# GROUP BY 
#   b.account_id,
#   b.account_name,
#   b.project_service_type,
#   b.sales_subregion_level_1,
#   b.sales_subregion_level_2,
#   b.snapshot_date,
#   b.unscheduled_backlog,
#   r.revenue_account_id,
#   r.revenue_account_name,
#   r.delivered_date,
#   r.delivered_fiscal_quarter_start_date,
#   r.delivered_fiscal_year,
#   r.delivered_fiscal_year_quarter,
#   r.delivered_month_end_date,
#   r.delivered_month_start_date,
#   r.is_bif,
#   r.project_service_type,
#   r.row_type,
#   r.sales_subregion_level_1,
#   r.sales_subregion_level_2,
#   r.cs_delivered_revenue,
#   r.ps_delivered_revenue,
#   r.total_delivered_revenue,
#   r.training_delivered_revenue,
#   r.arr,
#   r.t3m_annualized
