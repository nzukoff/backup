# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.vertical_revenue_region_silver as
# MAGIC
# MAGIC with backlog as (
# MAGIC   select
# MAGIC   b.sales_subregion_level_1,
# MAGIC   b.sales_subregion_level_2,
# MAGIC   sum(unscheduled_backlog) as unscheduled_backlog
# MAGIC   from main.it_aibi_silver.vertical_revenue_backlog_silver b
# MAGIC   where b.snapshot_date=current_date()
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC reporting as (
# MAGIC   select 
# MAGIC   r.sales_subregion_level_1,
# MAGIC   r.sales_subregion_level_2,
# MAGIC   r.is_bif
# MAGIC   from main.it_aibi_silver.vertical_revenue_reporting_silver r
# MAGIC   group by all
# MAGIC )
# MAGIC
# MAGIC   select 
# MAGIC   r.sales_subregion_level_1,
# MAGIC   r.sales_subregion_level_2,
# MAGIC   r.is_bif,
# MAGIC   sum(b.unscheduled_backlog) as unscheduled_backlog
# MAGIC   from reporting r
# MAGIC   left join backlog b
# MAGIC   on r.sales_subregion_level_2=b.sales_subregion_level_2
# MAGIC   and r.sales_subregion_level_1=b.sales_subregion_level_1
# MAGIC   GROUP BY all

# COMMAND ----------


