# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.vertical_revenue_region_arr_gold as
# MAGIC
# MAGIC
# MAGIC SELECT 
# MAGIC   account_executive,
# MAGIC   account_name,
# MAGIC   sales_subregion_level_1,
# MAGIC   snapshot_date,
# MAGIC   arr,
# MAGIC   t3m_annualized,
# MAGIC   revenue_account_name,
# MAGIC   delivered_date,
# MAGIC   delivered_fiscal_year,
# MAGIC   delivered_month_end_date,
# MAGIC   is_bif,
# MAGIC   project_service_type,
# MAGIC   row_type,
# MAGIC   total_delivered_revenue,
# MAGIC   -- Last Update Date
# MAGIC   MAX(snapshot_date) OVER () AS last_update_date,
# MAGIC   -- Total PS Rev v3
# MAGIC   CASE 
# MAGIC     WHEN row_type = 'milestone' AND delivered_date > CURRENT_DATE THEN 0
# MAGIC     WHEN row_type = 'scheduled backlog' AND delivered_month_end_date < CURRENT_DATE THEN 0
# MAGIC     ELSE total_delivered_revenue 
# MAGIC   END AS total_ps_rev_v3,
# MAGIC   -- FY 2024 PS Revenue
# MAGIC   CASE 
# MAGIC     WHEN delivered_fiscal_year = 2024 THEN 
# MAGIC       CASE 
# MAGIC         WHEN row_type = 'milestone' AND delivered_date > CURRENT_DATE THEN 0
# MAGIC         WHEN row_type = 'scheduled backlog' AND delivered_month_end_date < CURRENT_DATE THEN 0
# MAGIC         ELSE total_delivered_revenue 
# MAGIC       END
# MAGIC     ELSE 0 
# MAGIC   END AS fy_2024_ps_revenue,
# MAGIC   -- FY 2025 PS Revenue
# MAGIC   CASE 
# MAGIC     WHEN delivered_fiscal_year = 2025 THEN 
# MAGIC       CASE 
# MAGIC         WHEN row_type = 'milestone' AND delivered_date > CURRENT_DATE THEN 0
# MAGIC         WHEN row_type = 'scheduled backlog' AND delivered_month_end_date < CURRENT_DATE THEN 0
# MAGIC         ELSE total_delivered_revenue 
# MAGIC       END
# MAGIC     ELSE 0 
# MAGIC   END AS fy_2025_ps_revenue
# MAGIC FROM main.it_aibi_silver.vertical_revenue_region_arr_silver

# COMMAND ----------



# COMMAND ----------


