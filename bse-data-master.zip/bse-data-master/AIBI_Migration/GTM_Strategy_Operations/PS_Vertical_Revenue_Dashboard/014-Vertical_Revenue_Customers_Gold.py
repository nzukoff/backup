# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.vertical_revenue_customers_gold as
# MAGIC
# MAGIC with revenue as (
# MAGIC   SELECT 
# MAGIC     r.account_name,
# MAGIC     r.business_unit,
# MAGIC     r.delivered_date,
# MAGIC     r.delivered_fiscal_year,
# MAGIC     r.delivered_fiscal_year_quarter,
# MAGIC     r.delivered_month_end_date,
# MAGIC     r.delivered_month_start_date,
# MAGIC     r.is_bif,
# MAGIC     r.row_type,
# MAGIC     r.sales_subregion_level_1,
# MAGIC     r.sales_subregion_level_2,
# MAGIC     SUM(r.total_delivered_revenue) AS total_delivered_revenue
# MAGIC   FROM main.it_aibi_silver.vertical_revenue_customers_silver r
# MAGIC   WHERE r.delivered_month_start_date >= '2023-02-01'
# MAGIC   GROUP BY 
# MAGIC     all
# MAGIC )
# MAGIC
# MAGIC select 
# MAGIC r.account_name,
# MAGIC r.business_unit,
# MAGIC r.delivered_date,
# MAGIC r.delivered_fiscal_year,
# MAGIC r.delivered_fiscal_year_quarter,
# MAGIC r.delivered_month_end_date,
# MAGIC r.delivered_month_start_date,
# MAGIC r.is_bif,
# MAGIC r.row_type,
# MAGIC r.sales_subregion_level_1,
# MAGIC r.sales_subregion_level_2,
# MAGIC SUM(r.total_delivered_revenue) AS total_delivered_revenue,
# MAGIC sum(case 
# MAGIC     when row_type = 'milestone' and delivered_date > current_date() then 0
# MAGIC     when row_type = 'scheduled backlog' and delivered_month_end_date < current_date() then 0
# MAGIC     else total_delivered_revenue
# MAGIC end) as Total_Rev_V3
# MAGIC from revenue r
# MAGIC group by all
# MAGIC
