# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.vertical_revenue_accounts_gold as
# MAGIC
# MAGIC SELECT 
# MAGIC   account_id,
# MAGIC   account_name,
# MAGIC   -- backlog_project_service_type,
# MAGIC   -- backlog_sales_subregion_level_1,
# MAGIC   -- backlog_sales_subregion_level_2,
# MAGIC   --snapshot_date,
# MAGIC   unscheduled_backlog,
# MAGIC   revenue_account_id,
# MAGIC   -- revenue_account_name,
# MAGIC   delivered_date,
# MAGIC   delivered_fiscal_quarter_start_date,
# MAGIC   delivered_fiscal_year,
# MAGIC   delivered_fiscal_year_quarter,
# MAGIC   delivered_month_end_date,
# MAGIC   delivered_month_start_date,
# MAGIC   is_bif,
# MAGIC   project_service_type,
# MAGIC   row_type,
# MAGIC   sales_subregion_level_1,
# MAGIC   sales_subregion_level_2,
# MAGIC   cs_delivered_revenue,
# MAGIC   ps_delivered_revenue,
# MAGIC     training_delivered_revenue,
# MAGIC   arr,
# MAGIC   t3m_annualized,
# MAGIC    CAST(delivered_fiscal_year AS STRING) AS delivered_fy_string,
# MAGIC   CASE 
# MAGIC     WHEN row_type = 'milestone' AND delivered_date > CURRENT_DATE THEN 0
# MAGIC     WHEN row_type = 'scheduled backlog' AND delivered_month_end_date < CURRENT_DATE THEN 0
# MAGIC     ELSE total_delivered_revenue 
# MAGIC   END AS total_delivered_revenue
# MAGIC
# MAGIC  
# MAGIC FROM main.it_aibi_silver.vertical_revenue_accounts_silver

# COMMAND ----------


