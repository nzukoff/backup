# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.vertical_revenue_customers_silver as
# MAGIC
# MAGIC
# MAGIC   SELECT 
# MAGIC     r.account_name,
# MAGIC     r.business_unit,
# MAGIC     r.delivered_date,
# MAGIC     r.delivered_fiscal_year,
# MAGIC     r.delivered_fiscal_year_quarter,
# MAGIC     r.delivered_month_end_date,
# MAGIC     r.delivered_month_start_date,
# MAGIC     r.is_bif,
# MAGIC     r.row_type,
# MAGIC     r.sales_subregion_level_1,
# MAGIC     r.sales_subregion_level_2,
# MAGIC     SUM(r.total_delivered_revenue) AS total_delivered_revenue
# MAGIC   FROM main.gtm_data.core_professional_services_delivered_revenue_metrics r
# MAGIC   WHERE r.delivered_month_start_date >= '2023-02-01'
# MAGIC   GROUP BY 
# MAGIC     all
