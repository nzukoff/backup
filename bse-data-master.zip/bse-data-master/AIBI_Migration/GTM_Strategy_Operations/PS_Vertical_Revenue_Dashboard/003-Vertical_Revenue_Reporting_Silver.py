# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.vertical_revenue_reporting_silver as
# MAGIC
# MAGIC WITH revenue AS (
# MAGIC   SELECT 
# MAGIC     r.account_id,
# MAGIC     r.account_name,
# MAGIC     r.business_unit,
# MAGIC     r.delivered_date,
# MAGIC     r.delivered_fiscal_quarter_start_date,
# MAGIC     r.delivered_fiscal_year,
# MAGIC     r.delivered_fiscal_year_quarter,
# MAGIC     r.delivered_month_end_date,
# MAGIC     r.delivered_month_start_date,
# MAGIC     r.is_bif,
# MAGIC     r.opportunity_id,
# MAGIC     r.project_id,
# MAGIC     r.project_name,
# MAGIC     r.project_service_type,
# MAGIC     r.row_type,
# MAGIC     r.sales_region,
# MAGIC     r.sales_subregion_level_1,
# MAGIC     r.sales_subregion_level_2,
# MAGIC     r.sales_subregion_level_3,
# MAGIC     SUM(r.cs_delivered_revenue) AS cs_delivered_revenue,
# MAGIC     SUM(r.ps_delivered_revenue) AS ps_delivered_revenue,
# MAGIC     SUM(r.total_delivered_revenue) AS total_delivered_revenue,
# MAGIC     SUM(r.training_delivered_revenue) AS training_delivered_revenue
# MAGIC   FROM main.gtm_data.core_professional_services_delivered_revenue_metrics r
# MAGIC   GROUP BY 
# MAGIC     r.account_id,
# MAGIC     r.account_name,
# MAGIC     r.business_unit,
# MAGIC     r.delivered_date,
# MAGIC     r.delivered_fiscal_quarter_start_date,
# MAGIC     r.delivered_fiscal_year,
# MAGIC     r.delivered_fiscal_year_quarter,
# MAGIC     r.delivered_month_end_date,
# MAGIC     r.delivered_month_start_date,
# MAGIC     r.is_bif,
# MAGIC     r.opportunity_id,
# MAGIC     r.project_id,
# MAGIC     r.project_name,
# MAGIC     r.project_service_type,
# MAGIC     r.row_type,
# MAGIC     r.sales_region,
# MAGIC     r.sales_subregion_level_1,
# MAGIC     r.sales_subregion_level_2,
# MAGIC     r.sales_subregion_level_3
# MAGIC ),
# MAGIC
# MAGIC accounts AS (
# MAGIC   SELECT 
# MAGIC     A.Account_Name, 
# MAGIC     A.sales_business_unit, 
# MAGIC     SUM(A.t3m_annualized) AS t3m_annualized, 
# MAGIC     SUM(A.arr) AS arr
# MAGIC   FROM main.gtm_Data.core_accounts_curated A 
# MAGIC   WHERE 
# MAGIC     A.t3m_annualized > 0
# MAGIC     AND A.sales_business_unit IS NOT NULL
# MAGIC   GROUP BY 
# MAGIC     A.Account_Name, 
# MAGIC     A.sales_business_unit
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   r.account_id,
# MAGIC   r.account_name AS revenue_account_name,
# MAGIC   r.business_unit,
# MAGIC   r.delivered_date,
# MAGIC   r.delivered_fiscal_quarter_start_date,
# MAGIC   r.delivered_fiscal_year,
# MAGIC   r.delivered_fiscal_year_quarter,
# MAGIC   r.delivered_month_end_date,
# MAGIC   r.delivered_month_start_date,
# MAGIC   r.is_bif,
# MAGIC   r.opportunity_id,
# MAGIC   r.project_id,
# MAGIC   r.project_name,
# MAGIC   r.project_service_type,
# MAGIC   r.row_type,
# MAGIC   r.sales_region,
# MAGIC   r.sales_subregion_level_1,
# MAGIC   r.sales_subregion_level_2,
# MAGIC   r.sales_subregion_level_3,
# MAGIC   r.cs_delivered_revenue,
# MAGIC   r.ps_delivered_revenue,
# MAGIC   r.total_delivered_revenue,
# MAGIC   r.training_delivered_revenue,
# MAGIC   A.Account_Name, 
# MAGIC   A.sales_business_unit, 
# MAGIC   A.t3m_annualized, 
# MAGIC   A.arr
# MAGIC FROM revenue r
# MAGIC LEFT JOIN accounts a
# MAGIC   ON r.account_name = a.Account_Name
# MAGIC WHERE r.delivered_month_start_date >= '2023-02-01'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.vertical_revenue_reporting_totals_silver as
# MAGIC
# MAGIC WITH revenue AS (
# MAGIC   SELECT 
# MAGIC     r.account_id,
# MAGIC     r.account_name,
# MAGIC     r.business_unit,
# MAGIC     r.delivered_date,
# MAGIC     r.delivered_fiscal_quarter_start_date,
# MAGIC     r.delivered_fiscal_year,
# MAGIC     r.delivered_fiscal_year_quarter,
# MAGIC     r.delivered_month_end_date,
# MAGIC     r.delivered_month_start_date,
# MAGIC     r.is_bif,
# MAGIC     r.opportunity_id,
# MAGIC     r.project_id,
# MAGIC     r.project_name,
# MAGIC     r.project_service_type,
# MAGIC     r.row_type,
# MAGIC     r.sales_region,
# MAGIC     r.sales_subregion_level_1,
# MAGIC     r.sales_subregion_level_2,
# MAGIC     r.sales_subregion_level_3,
# MAGIC     SUM(r.cs_delivered_revenue) AS cs_delivered_revenue,
# MAGIC     SUM(r.ps_delivered_revenue) AS ps_delivered_revenue,
# MAGIC     SUM(r.total_delivered_revenue) AS total_delivered_revenue,
# MAGIC     SUM(r.training_delivered_revenue) AS training_delivered_revenue
# MAGIC   FROM main.gtm_data.core_professional_services_delivered_revenue_metrics r
# MAGIC   GROUP BY 
# MAGIC     r.account_id,
# MAGIC     r.account_name,
# MAGIC     r.business_unit,
# MAGIC     r.delivered_date,
# MAGIC     r.delivered_fiscal_quarter_start_date,
# MAGIC     r.delivered_fiscal_year,
# MAGIC     r.delivered_fiscal_year_quarter,
# MAGIC     r.delivered_month_end_date,
# MAGIC     r.delivered_month_start_date,
# MAGIC     r.is_bif,
# MAGIC     r.opportunity_id,
# MAGIC     r.project_id,
# MAGIC     r.project_name,
# MAGIC     r.project_service_type,
# MAGIC     r.row_type,
# MAGIC     r.sales_region,
# MAGIC     r.sales_subregion_level_1,
# MAGIC     r.sales_subregion_level_2,
# MAGIC     r.sales_subregion_level_3
# MAGIC ),
# MAGIC
# MAGIC accounts AS (
# MAGIC   SELECT 
# MAGIC     A.Account_Name, 
# MAGIC     A.sales_business_unit, 
# MAGIC     SUM(A.t3m_annualized) AS t3m_annualized, 
# MAGIC     SUM(A.arr) AS arr
# MAGIC   FROM main.gtm_Data.core_accounts_curated A 
# MAGIC   WHERE 
# MAGIC     A.t3m_annualized > 0
# MAGIC     AND A.sales_business_unit IS NOT NULL
# MAGIC   GROUP BY 
# MAGIC     A.Account_Name, 
# MAGIC     A.sales_business_unit
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   r.account_id,
# MAGIC   r.account_name AS revenue_account_name,
# MAGIC   r.business_unit,
# MAGIC   r.delivered_date,
# MAGIC   r.delivered_fiscal_quarter_start_date,
# MAGIC   r.delivered_fiscal_year,
# MAGIC   r.delivered_fiscal_year_quarter,
# MAGIC   r.delivered_month_end_date,
# MAGIC   r.delivered_month_start_date,
# MAGIC   r.is_bif,
# MAGIC   r.opportunity_id,
# MAGIC   r.project_id,
# MAGIC   r.project_name,
# MAGIC   r.project_service_type,
# MAGIC   r.row_type,
# MAGIC   r.sales_region,
# MAGIC   r.sales_subregion_level_1,
# MAGIC   r.sales_subregion_level_2,
# MAGIC   r.sales_subregion_level_3,
# MAGIC   r.cs_delivered_revenue,
# MAGIC   r.ps_delivered_revenue,
# MAGIC   r.total_delivered_revenue,
# MAGIC   r.training_delivered_revenue,
# MAGIC   A.Account_Name, 
# MAGIC   A.sales_business_unit, 
# MAGIC   A.t3m_annualized, 
# MAGIC   A.arr
# MAGIC FROM revenue r
# MAGIC LEFT JOIN accounts a
# MAGIC   ON r.account_name = a.Account_Name
# MAGIC   AND r.business_unit=a.sales_business_unit
# MAGIC WHERE r.delivered_month_start_date >= '2023-02-01'

# COMMAND ----------

# %sql

# CREATE OR REPLACE TABLE main.it_aibi_silver.vertical_revenue_reporting_silver as

# WITH revenue AS (
#   SELECT 
#     r.account_id,
#     r.account_name,
#     r.business_unit,
#     r.delivered_date,
#     r.delivered_fiscal_quarter_start_date,
#     r.delivered_fiscal_year,
#     r.delivered_fiscal_year_quarter,
#     r.delivered_month_end_date,
#     r.delivered_month_start_date,
#     r.is_bif,
#     r.opportunity_id,
#     r.project_id,
#     r.project_name,
#     r.project_service_type,
#     r.row_type,
#     r.sales_region,
#     r.sales_subregion_level_1,
#     r.sales_subregion_level_2,
#     r.sales_subregion_level_3,
#     SUM(r.cs_delivered_revenue) AS cs_delivered_revenue,
#     SUM(r.ps_delivered_revenue) AS ps_delivered_revenue,
#     SUM(r.total_delivered_revenue) AS total_delivered_revenue,
#     SUM(r.training_delivered_revenue) AS training_delivered_revenue
#   FROM main.gtm_data.core_professional_services_delivered_revenue_metrics r
#   GROUP BY 
#     r.account_id,
#     r.account_name,
#     r.business_unit,
#     r.delivered_date,
#     r.delivered_fiscal_quarter_start_date,
#     r.delivered_fiscal_year,
#     r.delivered_fiscal_year_quarter,
#     r.delivered_month_end_date,
#     r.delivered_month_start_date,
#     r.is_bif,
#     r.opportunity_id,
#     r.project_id,
#     r.project_name,
#     r.project_service_type,
#     r.row_type,
#     r.sales_region,
#     r.sales_subregion_level_1,
#     r.sales_subregion_level_2,
#     r.sales_subregion_level_3
# ),

# accounts AS (
#   SELECT 
#     A.Account_Name, 
#     A.sales_business_unit, 
#     SUM(A.t3m_annualized) AS t3m_annualized, 
#     SUM(A.arr) AS arr
#   FROM main.gtm_Data.core_accounts_curated A 
#   WHERE 
#     A.t3m_annualized > 0
#     AND A.sales_business_unit IS NOT NULL
#   GROUP BY 
#     A.Account_Name, 
#     A.sales_business_unit
# )

# SELECT 
#   r.account_id,
#   r.account_name AS revenue_account_name,
#   r.business_unit,
#   r.delivered_date,
#   r.delivered_fiscal_quarter_start_date,
#   r.delivered_fiscal_year,
#   r.delivered_fiscal_year_quarter,
#   r.delivered_month_end_date,
#   r.delivered_month_start_date,
#   r.is_bif,
#   r.opportunity_id,
#   r.project_id,
#   r.project_name,
#   r.project_service_type,
#   r.row_type,
#   r.sales_region,
#   r.sales_subregion_level_1,
#   r.sales_subregion_level_2,
#   r.sales_subregion_level_3,
#   r.cs_delivered_revenue,
#   r.ps_delivered_revenue,
#   r.total_delivered_revenue,
#   r.training_delivered_revenue,
#   A.Account_Name, 
#   A.sales_business_unit, 
#   A.t3m_annualized, 
#   A.arr
# FROM revenue r
# LEFT JOIN accounts a
#   ON r.account_name = a.Account_Name
# WHERE r.delivered_month_start_date >= '2023-02-01'
# GROUP BY 
#   r.account_id,
#   r.account_name,
#   r.business_unit,
#   r.delivered_date,
#   r.delivered_fiscal_quarter_start_date,
#   r.delivered_fiscal_year,
#   r.delivered_fiscal_year_quarter,
#   r.delivered_month_end_date,
#   r.delivered_month_start_date,
#   r.is_bif,
#   r.opportunity_id,
#   r.project_id,
#   r.project_name,
#   r.project_service_type,
#   r.row_type,
#   r.sales_region,
#   r.sales_subregion_level_1,
#   r.sales_subregion_level_2,
#   r.sales_subregion_level_3,
#   r.cs_delivered_revenue,
#   r.ps_delivered_revenue,
#   r.total_delivered_revenue,
#   r.training_delivered_revenue,
#   A.Account_Name, 
#   A.sales_business_unit, 
#   A.t3m_annualized, 
#   A.arr
