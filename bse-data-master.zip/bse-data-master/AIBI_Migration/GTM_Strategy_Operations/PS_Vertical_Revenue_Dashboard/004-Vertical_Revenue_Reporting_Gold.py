# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.vertical_revenue_reporting_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC   SELECT 
# MAGIC     account_id,
# MAGIC     account_name,
# MAGIC     project_name,
# MAGIC     delivered_fiscal_year,
# MAGIC     delivered_fiscal_year_quarter,
# MAGIC     delivered_date,
# MAGIC     delivered_month_end_date,
# MAGIC     row_type,
# MAGIC     total_delivered_revenue,
# MAGIC     -- other relevant columns
# MAGIC     CASE 
# MAGIC       WHEN row_type = 'milestone' AND delivered_date > CURRENT_DATE THEN 0
# MAGIC       WHEN row_type = 'scheduled backlog' AND delivered_month_end_date < CURRENT_DATE THEN 0
# MAGIC       ELSE total_delivered_revenue 
# MAGIC     END AS total_rev_v3
# MAGIC   FROM main.it_aibi_silver.vertical_revenue_reporting_silver
# MAGIC ),
# MAGIC account_qtr_revenue AS (
# MAGIC   SELECT 
# MAGIC     account_name,
# MAGIC     delivered_fiscal_year_quarter,
# MAGIC     SUM(total_rev_v3) AS fixed_account_qtr_revenue
# MAGIC   FROM base_data
# MAGIC   GROUP BY account_name, delivered_fiscal_year_quarter
# MAGIC ),
# MAGIC project_fy_revenue AS (
# MAGIC   SELECT 
# MAGIC     project_name,
# MAGIC     delivered_fiscal_year,
# MAGIC     SUM(total_rev_v3) AS fixed_project_fy_revenue
# MAGIC   FROM base_data
# MAGIC   GROUP BY project_name, delivered_fiscal_year
# MAGIC ),
# MAGIC ranked_data AS (
# MAGIC   SELECT 
# MAGIC     b.*,
# MAGIC     a.fixed_account_qtr_revenue,
# MAGIC     p.fixed_project_fy_revenue,
# MAGIC     RANK() OVER (PARTITION BY b.delivered_fiscal_year_quarter ORDER BY a.fixed_account_qtr_revenue DESC) AS ranked_revenue,
# MAGIC     RANK() OVER (PARTITION BY b.delivered_fiscal_year ORDER BY p.fixed_project_fy_revenue DESC) AS calculation2,
# MAGIC     SUM(b.total_rev_v3) OVER () AS total_rev_v4
# MAGIC   FROM base_data b
# MAGIC   JOIN account_qtr_revenue a ON b.account_name = a.account_name AND b.delivered_fiscal_year_quarter = a.delivered_fiscal_year_quarter
# MAGIC   JOIN project_fy_revenue p ON b.project_name = p.project_name AND b.delivered_fiscal_year = p.delivered_fiscal_year
# MAGIC )
# MAGIC SELECT * FROM ranked_data
# MAGIC
