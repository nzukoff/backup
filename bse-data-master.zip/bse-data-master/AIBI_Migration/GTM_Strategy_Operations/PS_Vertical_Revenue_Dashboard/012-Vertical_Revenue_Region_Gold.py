# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.vertical_revenue_region_gold as
# MAGIC
# MAGIC SELECT * from main.it_aibi_silver.vertical_revenue_region_silver
# MAGIC

# COMMAND ----------


