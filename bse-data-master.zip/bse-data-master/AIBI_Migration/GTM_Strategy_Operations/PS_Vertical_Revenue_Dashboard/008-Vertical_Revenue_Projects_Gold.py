# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.vertical_revenue_projects_gold as
# MAGIC
# MAGIC SELECT 
# MAGIC   delivered_fiscal_year,
# MAGIC   delivered_fiscal_year_quarter,
# MAGIC   sales_subregion_level_1,
# MAGIC   sales_subregion_level_2,
# MAGIC   is_bif,
# MAGIC   project_service_type,
# MAGIC   account_name,
# MAGIC   account_id,
# MAGIC   arr,
# MAGIC   row_type,
# MAGIC   delivered_date,
# MAGIC   delivered_month_end_date,
# MAGIC   t3m_annualized,
# MAGIC   total_delivered_revenue,
# MAGIC   training_delivered_revenue,
# MAGIC   cs_delivered_revenue,
# MAGIC   ps_delivered_revenue,
# MAGIC   unscheduled_backlog,
# MAGIC   CAST(delivered_fiscal_year AS STRING) AS delivered_fy_string,
# MAGIC   CASE 
# MAGIC     WHEN row_type = 'milestone' AND delivered_date > CURRENT_DATE THEN 0
# MAGIC     WHEN row_type = 'scheduled backlog' AND delivered_month_end_date < CURRENT_DATE THEN 0
# MAGIC     ELSE total_delivered_revenue 
# MAGIC   END AS total_rev_v3
# MAGIC FROM main.it_aibi_silver.vertical_revenue_projects_silver 
# MAGIC

# COMMAND ----------


