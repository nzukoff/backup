# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.vertical_revenue_region_arr_silver
# MAGIC
# MAGIC WITH accounts AS (
# MAGIC   SELECT 
# MAGIC     A.account_executive, 
# MAGIC     A.Account_Name, 
# MAGIC     A.sales_subregion_level_1, 
# MAGIC     A.snapshot_date,
# MAGIC     A.arr, 
# MAGIC     A.t3m_annualized
# MAGIC   FROM main.gtm_Data.core_accounts_curated A 
# MAGIC   WHERE A.t3m_annualized > 0
# MAGIC     AND A.sales_business_unit IS NOT NULL
# MAGIC   ORDER BY A.account_name DESC
# MAGIC ),
# MAGIC
# MAGIC revenue AS (
# MAGIC   SELECT 
# MAGIC     r.account_name,
# MAGIC     r.delivered_date,
# MAGIC     r.delivered_fiscal_year,
# MAGIC     r.delivered_month_end_date,
# MAGIC     r.is_bif,
# MAGIC     r.project_service_type,
# MAGIC     r.row_type,
# MAGIC     r.total_delivered_revenue
# MAGIC   FROM main.gtm_data.core_professional_services_delivered_revenue_metrics r
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   A.account_executive, 
# MAGIC   A.Account_Name AS account_name, 
# MAGIC   A.sales_subregion_level_1, 
# MAGIC   A.snapshot_date,
# MAGIC   A.arr, 
# MAGIC   A.t3m_annualized,
# MAGIC   r.account_name AS revenue_account_name,
# MAGIC   r.delivered_date,
# MAGIC   r.delivered_fiscal_year,
# MAGIC   r.delivered_month_end_date,
# MAGIC   r.is_bif,
# MAGIC   r.project_service_type,
# MAGIC   r.row_type,
# MAGIC   r.total_delivered_revenue
# MAGIC FROM accounts a
# MAGIC LEFT JOIN revenue r
# MAGIC   ON a.account_name = r.account_name
