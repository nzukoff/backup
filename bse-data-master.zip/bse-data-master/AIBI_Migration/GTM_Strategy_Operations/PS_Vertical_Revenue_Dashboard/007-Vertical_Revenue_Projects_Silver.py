# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.vertical_revenue_projects_silver as
# MAGIC
# MAGIC WITH backlog_full as (  
# MAGIC   select
# MAGIC   account_id,
# MAGIC   account_name,
# MAGIC   is_bif,
# MAGIC   project_service_type,
# MAGIC   sales_subregion_level_1,
# MAGIC   sales_subregion_level_2,
# MAGIC   snapshot_date,
# MAGIC   SUM(unscheduled_backlog) AS unscheduled_backlog
# MAGIC   from main.it_aibi_silver.vertical_revenue_backlog_silver b
# MAGIC   where snapshot_date=current_date()
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC backlog_part as (
# MAGIC   select
# MAGIC   account_id,
# MAGIC   snapshot_date,
# MAGIC   sum(unscheduled_backlog) as unscheduled_backlog
# MAGIC   from main.it_aibi_silver.vertical_revenue_backlog_silver b
# MAGIC   where snapshot_date=current_date()
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC backlog as (
# MAGIC   select
# MAGIC   f.account_id,
# MAGIC   sum(f.unscheduled_backlog) as unscheduled_backlog
# MAGIC   from backlog_full f
# MAGIC   left join backlog_part p
# MAGIC   on f.account_id=p.account_id
# MAGIC   group by all
# MAGIC ),
# MAGIC
# MAGIC reporting AS (
# MAGIC   SELECT 
# MAGIC     delivered_fiscal_year,
# MAGIC     delivered_fiscal_year_quarter,
# MAGIC     sales_subregion_level_1,
# MAGIC     sales_subregion_level_2,
# MAGIC     is_bif,
# MAGIC     project_service_type,
# MAGIC     account_name,
# MAGIC     account_id,
# MAGIC     arr,
# MAGIC     row_type,
# MAGIC     delivered_date,
# MAGIC     delivered_month_end_date,
# MAGIC     t3m_annualized,
# MAGIC     SUM(total_delivered_revenue) AS total_delivered_revenue,
# MAGIC     SUM(training_delivered_revenue) AS training_delivered_revenue,
# MAGIC     SUM(ps_delivered_revenue) AS ps_delivered_revenue,
# MAGIC     SUM(cs_delivered_revenue) AS cs_delivered_revenue
# MAGIC   FROM main.it_aibi_silver.vertical_revenue_reporting_silver
# MAGIC   GROUP BY 
# MAGIC     delivered_fiscal_year,
# MAGIC     delivered_fiscal_year_quarter,
# MAGIC     sales_subregion_level_1,
# MAGIC     sales_subregion_level_2,
# MAGIC     is_bif,
# MAGIC     project_service_type,
# MAGIC     account_name,
# MAGIC     account_id,
# MAGIC     arr,
# MAGIC     row_type,
# MAGIC     delivered_date,
# MAGIC     delivered_month_end_date,
# MAGIC     t3m_annualized
# MAGIC )
# MAGIC
# MAGIC SELECT 
# MAGIC   r.delivered_fiscal_year,
# MAGIC   r.delivered_fiscal_year_quarter,
# MAGIC   r.sales_subregion_level_1,
# MAGIC   r.sales_subregion_level_2,
# MAGIC   r.is_bif,
# MAGIC   r.project_service_type,
# MAGIC   r.account_name,
# MAGIC   r.account_id,
# MAGIC   r.arr,
# MAGIC   r.row_type,
# MAGIC   r.delivered_date,
# MAGIC   r.delivered_month_end_date,
# MAGIC   r.t3m_annualized,
# MAGIC   r.total_delivered_revenue,
# MAGIC   r.training_delivered_revenue,
# MAGIC   r.cs_delivered_revenue,
# MAGIC   r.ps_delivered_revenue,
# MAGIC   b.unscheduled_backlog
# MAGIC FROM reporting r
# MAGIC LEFT JOIN backlog b
# MAGIC   ON r.account_id = b.account_id
# MAGIC GROUP BY 
# MAGIC   r.delivered_fiscal_year,
# MAGIC   r.delivered_fiscal_year_quarter,
# MAGIC   r.sales_subregion_level_1,
# MAGIC   r.sales_subregion_level_2,
# MAGIC   r.is_bif,
# MAGIC   r.project_service_type,
# MAGIC   r.account_name,
# MAGIC   r.account_id,
# MAGIC   r.arr,
# MAGIC   r.row_type,
# MAGIC   r.delivered_date,
# MAGIC   r.delivered_month_end_date,
# MAGIC   r.t3m_annualized,
# MAGIC   r.total_delivered_revenue,
# MAGIC   r.training_delivered_revenue,
# MAGIC   r.cs_delivered_revenue,
# MAGIC   r.ps_delivered_revenue,
# MAGIC   b.unscheduled_backlog
