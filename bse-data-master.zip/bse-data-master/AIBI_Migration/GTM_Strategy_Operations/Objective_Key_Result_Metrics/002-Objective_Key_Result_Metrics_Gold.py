# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.objective_key_results_gold as
# MAGIC
# MAGIC SELECT 
# MAGIC     account_name,
# MAGIC     account_owner_territory,
# MAGIC     account_region,
# MAGIC     account_segment,
# MAGIC     auto_approved,
# MAGIC     aws_marketplace_deal,
# MAGIC     business_unit,
# MAGIC     close_date,
# MAGIC     closed_won,
# MAGIC     cpq_revops_booking_pending,
# MAGIC     date_sent_for_signature,
# MAGIC     dd_review_date,
# MAGIC     deal,
# MAGIC     forecast_category,
# MAGIC     gcp_marketplace_deal,
# MAGIC     id,
# MAGIC     is_ironclad_workflow,
# MAGIC     ns_integration_time_stamp,
# MAGIC     opportunity_closed_by,
# MAGIC     oppty_owner,
# MAGIC     owner_role_view,
# MAGIC     primary_quote,
# MAGIC     quote_approved,
# MAGIC     quote_sent_for_approval,
# MAGIC     quote_stage,
# MAGIC     rpa_close_eligible,
# MAGIC     short_term_renewal,
# MAGIC     signed_stage_date,
# MAGIC     stage,
# MAGIC     upsell_sub_type,
# MAGIC     amount,
# MAGIC     accountId,
# MAGIC     incremental_booking_revenue,
# MAGIC     primary_competitor,
# MAGIC     expected_close_date,
# MAGIC     sales_ops_validated,
# MAGIC     oppty_type,
# MAGIC     order_form_signature_date,
# MAGIC     signed_stage_date_stamp__c,
# MAGIC     platform_type,
# MAGIC     sales_ops_reviewed_date,
# MAGIC     salesforce_order,
# MAGIC     pricebook_id,
# MAGIC     oppty_region_level_1,
# MAGIC     oppty_region_level_2,
# MAGIC     oppty_region_level_3,
# MAGIC     quote_total_contract_value,
# MAGIC     quote_type,
# MAGIC     quote_sent_for_approval_old,
# MAGIC     quote_sfdc_id,
# MAGIC     approval_id,
# MAGIC     approval_step,
# MAGIC     approval_chain,
# MAGIC     approval_rule,
# MAGIC     approver,
# MAGIC     assigned_to,
# MAGIC     approved_by,
# MAGIC     justification,
# MAGIC     approval_status,
# MAGIC     cpq_order_number,
# MAGIC     ns_order_id,
# MAGIC     cpq_order_created_by,
# MAGIC     contract_id,
# MAGIC     renewal_opportunity,
# MAGIC     ironclad_workflow_id,
# MAGIC     ironclad_workflow_step,
# MAGIC     ironclad_workflow_title,
# MAGIC     ironclad_workflow_type,
# MAGIC     ironclad_workflow_activity_message,
# MAGIC     ironclad_workflow_activity_timestamp_dt,
# MAGIC     edited_by,
# MAGIC     field_event,
# MAGIC     old_value,
# MAGIC     new_value,
# MAGIC     opp_level_incremental_booking_total_fcst,
# MAGIC     clari_opp_id,
# MAGIC     process_date,
# MAGIC     -- AWS + GCP Markertplace True
# MAGIC     CASE WHEN aws_marketplace_deal = TRUE OR gcp_marketplace_deal = TRUE THEN TRUE ELSE FALSE END AS aws_gcp_marketplace_true,
# MAGIC     -- Amount
# MAGIC     MAX(amount) OVER (PARTITION BY id) AS max_amount,
# MAGIC     -- AWS + GCP Marketplace %
# MAGIC     100.0 * COUNT(CASE WHEN aws_marketplace_deal = TRUE OR gcp_marketplace_deal = TRUE THEN 1 END) OVER (PARTITION BY stage) / 
# MAGIC     NULLIF(COUNT(*) OVER (PARTITION BY stage), 0) AS aws_gcp_marketplace_percentage,
# MAGIC  -- CPQ RevOps Booking %
# MAGIC     COALESCE(
# MAGIC         ROUND(
# MAGIC             100.0 * COUNT(CASE WHEN cpq_revops_booking_pending = TRUE THEN 1 END) OVER (PARTITION BY stage) / 
# MAGIC             NULLIF(COUNT(*) OVER (PARTITION BY stage), 0),
# MAGIC             2
# MAGIC         ),
# MAGIC         0
# MAGIC     ) AS cpq_revops_booking_percentage,
# MAGIC     -- Is Ironclad %
# MAGIC     100.0 * COUNT(CASE WHEN is_ironclad_workflow = TRUE THEN 1 END) OVER (PARTITION BY stage) / 
# MAGIC     NULLIF(COUNT(*) OVER (PARTITION BY stage), 0) AS is_ironclad_percentage,
# MAGIC
# MAGIC         -- Pre Approved %
# MAGIC     COALESCE(
# MAGIC         ROUND(
# MAGIC             100.0 * COUNT(CASE WHEN auto_approved = TRUE THEN 1 END) OVER (PARTITION BY stage) / 
# MAGIC             NULLIF(COUNT(*) OVER (PARTITION BY stage), 0),
# MAGIC             2
# MAGIC         ),
# MAGIC         0
# MAGIC     ) AS pre_approved_percentage,
# MAGIC     
# MAGIC     -- RPA Close Eligible %
# MAGIC     COALESCE(
# MAGIC         ROUND(
# MAGIC             100.0 * COUNT(CASE WHEN rpa_close_eligible = TRUE THEN 1 END) OVER (PARTITION BY stage) / 
# MAGIC             NULLIF(COUNT(*) OVER (PARTITION BY stage), 0),
# MAGIC             2
# MAGIC         ),
# MAGIC         0
# MAGIC     ) AS rpa_close_eligible_percentage,
# MAGIC     
# MAGIC     -- RPA User %
# MAGIC     COALESCE(
# MAGIC         ROUND(
# MAGIC             100.0 * COUNT(CASE WHEN opportunity_closed_by IS NOT NULL THEN 1 END) OVER (PARTITION BY stage) / 
# MAGIC             NULLIF(COUNT(*) OVER (PARTITION BY stage), 0),
# MAGIC             2
# MAGIC         ),
# MAGIC         0
# MAGIC     ) AS rpa_user_percentage,
# MAGIC     
# MAGIC     -- Time spent in approval stage AGG
# MAGIC     MAX(
# MAGIC         DATEDIFF(
# MAGIC             HOUR,
# MAGIC             quote_sent_for_approval,
# MAGIC             COALESCE(quote_approved, CURRENT_DATE)
# MAGIC         )
# MAGIC     ) OVER (PARTITION BY id) / 24.0 AS time_spent_in_approval_stage_agg,
# MAGIC     
# MAGIC     -- Time Spent in Closed to NetSuite
# MAGIC     MAX(
# MAGIC         DATEDIFF(
# MAGIC             HOUR,
# MAGIC             closed_won,
# MAGIC             COALESCE(ns_integration_time_stamp, CURRENT_DATE)
# MAGIC         )
# MAGIC     ) OVER (PARTITION BY id) / 24.0 AS time_spent_closed_to_netsuite,
# MAGIC     
# MAGIC     -- Time spent in customer queue
# MAGIC     DATEDIFF(
# MAGIC         HOUR,
# MAGIC         date_sent_for_signature,
# MAGIC         COALESCE(signed_stage_date, CURRENT_DATE)
# MAGIC     ) / 24.0 AS time_spent_in_customer_queue,
# MAGIC     
# MAGIC     -- Time spent in customer queue AGG
# MAGIC     MAX(
# MAGIC         DATEDIFF(
# MAGIC             HOUR,
# MAGIC             date_sent_for_signature,
# MAGIC             COALESCE(signed_stage_date, CURRENT_DATE)
# MAGIC         )
# MAGIC     ) OVER (PARTITION BY id) / 24.0 AS time_spent_in_customer_queue_agg,
# MAGIC     
# MAGIC     -- Time spent in DD review
# MAGIC     DATEDIFF(
# MAGIC         HOUR,
# MAGIC         signed_stage_date,
# MAGIC         COALESCE(dd_review_date, CURRENT_DATE)
# MAGIC     ) / 24.0 AS time_spent_in_dd_review,
# MAGIC
# MAGIC         -- Time spent in DD review AGG
# MAGIC     MAX(
# MAGIC         DATEDIFF(
# MAGIC             HOUR,
# MAGIC             signed_stage_date,
# MAGIC             COALESCE(dd_review_date, CURRENT_DATE)
# MAGIC         )
# MAGIC     ) OVER (PARTITION BY id) / 24.0 AS time_spent_in_dd_review_agg,
# MAGIC     
# MAGIC     -- Time spent in OM review
# MAGIC     DATEDIFF(
# MAGIC         HOUR,
# MAGIC         dd_review_date,
# MAGIC         COALESCE(closed_won, CURRENT_DATE)
# MAGIC     ) / 24.0 AS time_spent_in_om_review,
# MAGIC     
# MAGIC     -- Time spent in OM review AGG
# MAGIC     MAX(
# MAGIC         DATEDIFF(
# MAGIC             HOUR,
# MAGIC             dd_review_date,
# MAGIC             COALESCE(closed_won, CURRENT_DATE)
# MAGIC         )
# MAGIC     ) OVER (PARTITION BY id) / 24.0 AS time_spent_in_om_review_agg,
# MAGIC     
# MAGIC     -- Time spent in OM review AGG - (closed-signed)
# MAGIC     MAX(
# MAGIC         DATEDIFF(
# MAGIC             HOUR,
# MAGIC             signed_stage_date,
# MAGIC             COALESCE(closed_won, CURRENT_DATE)
# MAGIC         )
# MAGIC     ) OVER (PARTITION BY id) / 24.0 AS time_spent_in_om_review_agg_closed_signed,
# MAGIC     
# MAGIC     -- Time Spent in Signed to Closed
# MAGIC     MAX(
# MAGIC         DATEDIFF(
# MAGIC             HOUR,
# MAGIC             signed_stage_date,
# MAGIC             COALESCE(closed_won, CURRENT_DATE)
# MAGIC         )
# MAGIC     ) OVER (PARTITION BY id) / 24.0 AS time_spent_signed_to_closed
# MAGIC
# MAGIC     
# MAGIC FROM 
# MAGIC     main.it_aibi_silver.objective_key_results_silver

# COMMAND ----------



# COMMAND ----------

# %sql

# CREATE OR REPLACE TABLE main.it_aibi_gold.objective_key_results_gold as

# WITH stage_totals AS (
#     SELECT
#         stage,
#         COUNT(DISTINCT deal) AS total_deals
#     FROM main.it_aibi_silver.objective_key_results_silver
#     GROUP BY stage
# ),
# stage_metrics AS (
#     SELECT
#         stage,
#         COUNT(DISTINCT CASE WHEN cpq_revops_booking_pending = TRUE THEN deal END) AS cpq_revops_booking_count,
#         COUNT(DISTINCT CASE WHEN is_ironclad_workflow = TRUE THEN deal END) AS ironclad_count,
#         COUNT(DISTINCT CASE WHEN auto_approved = TRUE THEN deal END) AS auto_approved_count,
#         COUNT(DISTINCT CASE WHEN rpa_close_eligible = TRUE THEN deal END) AS rpa_close_eligible_count,
#         COUNT(DISTINCT CASE WHEN opportunity_closed_by IS NOT NULL THEN deal END) AS rpa_user_count,
#         COUNT(DISTINCT CASE WHEN aws_marketplace_deal = TRUE OR gcp_marketplace_deal = TRUE THEN deal END) AS marketplace_deals
#     FROM main.it_aibi_silver.objective_key_results_silver
#     GROUP BY stage
# ),
# approval_time AS (
#     SELECT
#         id,
#         MAX(
#             CASE 
#                 WHEN quote_approved IS NOT NULL THEN DATEDIFF(HOUR, quote_sent_for_approval, quote_approved)
#                 ELSE DATEDIFF(HOUR, quote_sent_for_approval, CURRENT_DATE())
#             END
#         ) / 24.0 AS time_in_approval_stage
#     FROM main.it_aibi_silver.objective_key_results_silver
#     WHERE quote_sent_for_approval IS NOT NULL
#     GROUP BY id
# ),
# time_metrics AS (
#     SELECT
#         id,
#         MAX(DATEDIFF(HOUR, closed_won, COALESCE(ns_integration_time_stamp, CURRENT_DATE()))) / 24.0 AS time_spent_closed_to_netsuite,
#         MAX(DATEDIFF(HOUR, date_sent_for_signature, COALESCE(signed_stage_date, CURRENT_DATE()))) / 24.0 AS time_spent_customer_queue,
#         MAX(DATEDIFF(HOUR, signed_stage_date, COALESCE(dd_review_date, CURRENT_DATE()))) / 24.0 AS time_spent_dd_review,
#         MAX(DATEDIFF(HOUR, dd_review_date, COALESCE(closed_won, CURRENT_DATE()))) / 24.0 AS time_spent_om_review,
#         MAX(DATEDIFF(HOUR, signed_stage_date, COALESCE(closed_won, CURRENT_DATE()))) / 24.0 AS time_spent_signed_to_closed
#     FROM main.it_aibi_silver.objective_key_results_silver
#     GROUP BY id
# )

# SELECT
#     o.*,
#     MAX(o.amount) OVER (PARTITION BY o.id) AS max_amount,
#     100.0 * COALESCE(m.cpq_revops_booking_count, 0) / s.total_deals AS cpq_revops_booking_percentage,
#     100.0 * COALESCE(m.ironclad_count, 0) / s.total_deals AS ironclad_percentage,
#     100.0 * COALESCE(m.auto_approved_count, 0) / s.total_deals AS pre_approved_percentage,
#     100.0 * COALESCE(m.rpa_close_eligible_count, 0) / s.total_deals AS rpa_close_eligible_percentage,
#     100.0 * COALESCE(m.rpa_user_count, 0) / s.total_deals AS rpa_user_percentage,
#     100.0 * COALESCE(m.marketplace_deals, 0) / s.total_deals AS aws_gcp_marketplace_percentage,
#     COALESCE(a.time_in_approval_stage, 0) AS time_in_approval_stage,
#     COALESCE(t.time_spent_closed_to_netsuite, 0) AS time_spent_closed_to_netsuite,
#     COALESCE(t.time_spent_customer_queue, 0) AS time_spent_customer_queue,
#     COALESCE(t.time_spent_dd_review, 0) AS time_spent_dd_review,
#     COALESCE(t.time_spent_om_review, 0) AS time_spent_om_review,
#     COALESCE(t.time_spent_signed_to_closed, 0) AS time_spent_signed_to_closed
# FROM 
#     main.it_aibi_silver.objective_key_results_silver o
# LEFT JOIN 
#     stage_metrics m ON o.stage = m.stage
# LEFT JOIN 
#     stage_totals s ON o.stage = s.stage
# LEFT JOIN
#     approval_time a ON o.id = a.id
# LEFT JOIN
#     time_metrics t ON o.id = t.id
