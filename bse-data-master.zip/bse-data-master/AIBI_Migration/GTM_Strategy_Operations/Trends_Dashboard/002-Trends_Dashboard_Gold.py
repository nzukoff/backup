# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.trends_gold as
# MAGIC
# MAGIC WITH base_data AS (
# MAGIC     SELECT
# MAGIC         account_id,
# MAGIC         account_name,
# MAGIC         consumption_based_primary_cloud,
# MAGIC         join_date,
# MAGIC         sales_subregion_level_1,
# MAGIC         sales_subregion_level_2,
# MAGIC         sales_subregion_level_3,
# MAGIC         sales_subregion_level_4,
# MAGIC         sku_type,
# MAGIC         t3m_annualized_band,
# MAGIC         usage_date,
# MAGIC         account_forecast_date_rate,
# MAGIC         dbu_dollars,
# MAGIC         submitted_ae_forecast,
# MAGIC         sum_dbu_dollars_28d,
# MAGIC         sum_dbu_dollars_63d,
# MAGIC         sum_dbu_dollars_7d,
# MAGIC         sum_dbu_dollars_7d_LY,
# MAGIC         sum_dbu_dollars_91d,
# MAGIC         sum_dbu_dollars_91d_LY,
# MAGIC         sum_dbu_quantity_28d,
# MAGIC         sum_dbu_quantity_63d,
# MAGIC         sum_dbu_quantity_7d,
# MAGIC         sum_dbu_quantity_91d,
# MAGIC         sum_dbu_quantity_91d_LY
# MAGIC     FROM main.it_aibi_silver.trends_silver
# MAGIC ),
# MAGIC fixed_cohort AS (
# MAGIC     SELECT
# MAGIC         account_name AS Account_Name_group,
# MAGIC         MAX(t3m_annualized_band) AS T3M_Annualized_Band_group
# MAGIC     FROM base_data
# MAGIC     GROUP BY account_name
# MAGIC ),
# MAGIC latest_record AS (
# MAGIC     SELECT MAX(usage_date) AS max_usage_date
# MAGIC     FROM base_data
# MAGIC ),
# MAGIC yoy_growth AS (
# MAGIC     SELECT
# MAGIC         account_id,
# MAGIC         (SUM(sum_dbu_dollars_91d) / NULLIF(SUM(sum_dbu_dollars_91d_LY), 0)) - 1 AS YoY_growth_91D_percentage,
# MAGIC         (SUM(sum_dbu_quantity_91d) / NULLIF(SUM(sum_dbu_quantity_91d_LY), 0)) - 1 AS YoY_growth_91D_DBU_percentage,
# MAGIC         (SUM(sum_dbu_dollars_91d) / NULLIF(SUM(sum_dbu_quantity_91d), 0)) AS Net_effective_rate_91D,
# MAGIC         (SUM(sum_dbu_dollars_91d_LY) / NULLIF(SUM(sum_dbu_quantity_91d_LY), 0)) AS Net_effective_rate_91D_LY
# MAGIC     FROM base_data
# MAGIC     GROUP BY account_id
# MAGIC ),
# MAGIC day_rate_forecast AS (
# MAGIC     SELECT
# MAGIC         account_id,
# MAGIC         join_date,
# MAGIC         MIN(account_forecast_date_rate) AS Day_rate_for_account_forecast
# MAGIC     FROM base_data
# MAGIC     GROUP BY account_id, join_date
# MAGIC ),
# MAGIC fixed_ae_forecast AS (
# MAGIC     SELECT
# MAGIC         account_id,
# MAGIC         join_date,
# MAGIC         MIN(submitted_ae_forecast) AS Fixed_AE_Forecast
# MAGIC     FROM base_data
# MAGIC     GROUP BY account_id, join_date
# MAGIC ),
# MAGIC net_effective_rates AS (
# MAGIC     SELECT
# MAGIC         account_id,
# MAGIC         SUM(sum_dbu_dollars_28d) / NULLIF(SUM(sum_dbu_quantity_28d), 0) AS Net_effective_rate_28D,
# MAGIC         SUM(sum_dbu_dollars_63d) / NULLIF(SUM(sum_dbu_quantity_63d), 0) AS Net_effective_rate_63D,
# MAGIC         SUM(sum_dbu_dollars_7d) / NULLIF(SUM(sum_dbu_quantity_7d), 0) AS Net_effective_rate_7D,
# MAGIC         SUM(sum_dbu_dollars_91d) / NULLIF(SUM(sum_dbu_quantity_91d), 0) AS Net_effective_rate_91D,
# MAGIC         SUM(sum_dbu_dollars_91d_LY) / NULLIF(SUM(sum_dbu_quantity_91d_LY), 0) AS Net_effective_rate_91D_LY
# MAGIC     FROM base_data
# MAGIC     GROUP BY account_id
# MAGIC ),
# MAGIC rate_of_change AS (
# MAGIC     SELECT
# MAGIC         account_id,
# MAGIC         SUM(sum_dbu_dollars_28d) / NULLIF(SUM(sum_dbu_dollars_63d), 0) - 1 AS Rate_of_change_28_vs_63,
# MAGIC         SUM(sum_dbu_quantity_28d) / NULLIF(SUM(sum_dbu_quantity_63d), 0) - 1 AS Rate_of_change_28_vs_63_DBU
# MAGIC     FROM base_data
# MAGIC     GROUP BY account_id
# MAGIC )
# MAGIC SELECT
# MAGIC     b.*,
# MAGIC     fc.T3M_Annualized_Band_group AS fixed_cohort,
# MAGIC     CASE WHEN b.usage_date = lr.max_usage_date THEN 1 ELSE 0 END AS is_latest_record,
# MAGIC     yg.YoY_growth_91D_percentage,
# MAGIC     yg.YoY_growth_91D_DBU_percentage,
# MAGIC     (yg.Net_effective_rate_91D / NULLIF(yg.Net_effective_rate_91D_LY, 0)) - 1 AS YoY_growth_91D_net_effective_rate_percentage,
# MAGIC     drf.Day_rate_for_account_forecast,
# MAGIC     faf.Fixed_AE_Forecast,
# MAGIC     ner.Net_effective_rate_28D,
# MAGIC     ner.Net_effective_rate_63D,
# MAGIC     ner.Net_effective_rate_7D,
# MAGIC     ner.Net_effective_rate_91D,
# MAGIC     ner.Net_effective_rate_91D_LY,
# MAGIC     roc.Rate_of_change_28_vs_63,
# MAGIC     roc.Rate_of_change_28_vs_63_DBU,
# MAGIC     (ner.Net_effective_rate_28D / NULLIF(ner.Net_effective_rate_63D, 0)) - 1 AS Rate_of_change_28_vs_63_effective_rate
# MAGIC FROM base_data b
# MAGIC LEFT JOIN fixed_cohort fc ON b.account_name = fc.Account_Name_group
# MAGIC CROSS JOIN latest_record lr
# MAGIC LEFT JOIN yoy_growth yg ON b.account_id = yg.account_id
# MAGIC LEFT JOIN day_rate_forecast drf ON b.account_id = drf.account_id AND b.join_date = drf.join_date
# MAGIC LEFT JOIN fixed_ae_forecast faf ON b.account_id = faf.account_id AND b.join_date = faf.join_date
# MAGIC LEFT JOIN net_effective_rates ner ON b.account_id = ner.account_id
# MAGIC LEFT JOIN rate_of_change roc ON b.account_id = roc.account_id
