# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.trends_silver as
# MAGIC
# MAGIC select
# MAGIC account_id,
# MAGIC account_name,
# MAGIC consumption_based_primary_cloud,
# MAGIC join_date,
# MAGIC sales_subregion_level_1,
# MAGIC sales_subregion_level_2,
# MAGIC sales_subregion_level_3,
# MAGIC sales_subregion_level_4,
# MAGIC sku_type,
# MAGIC t3m_annualized_band,
# MAGIC usage_date,
# MAGIC account_forecast_date_rate,
# MAGIC dbu_dollars,
# MAGIC submitted_ae_forecast,
# MAGIC sum_dbu_dollars_28d,
# MAGIC sum_dbu_dollars_63d,
# MAGIC sum_dbu_dollars_7d,
# MAGIC sum_dbu_dollars_7d_LY,
# MAGIC sum_dbu_dollars_91d,
# MAGIC sum_dbu_dollars_91d_LY,
# MAGIC sum_dbu_quantity_28d,
# MAGIC sum_dbu_quantity_63d,
# MAGIC sum_dbu_quantity_7d,
# MAGIC sum_dbu_quantity_91d,
# MAGIC sum_dbu_quantity_91d_LY
# MAGIC from main.it_aibi_bronze.306090180_trends
