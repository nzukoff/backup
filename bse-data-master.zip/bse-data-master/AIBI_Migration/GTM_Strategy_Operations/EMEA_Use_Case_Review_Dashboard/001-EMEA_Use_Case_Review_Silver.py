# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.emea_use_case_review_silver
# MAGIC
# MAGIC select
# MAGIC account_executive,
# MAGIC account_id,
# MAGIC account_name,
# MAGIC business_unit,
# MAGIC sales_subregion_level_1,
# MAGIC sales_subregion_level_2,
# MAGIC sales_subregion_level_3,
# MAGIC sales_subregion_level_4,
# MAGIC is_migration_usecase,
# MAGIC migration_type,
# MAGIC migration_source_platform,
# MAGIC stage,
# MAGIC target_live_date,
# MAGIC target_live_fiscal_quarter,
# MAGIC target_live_fiscal_year,
# MAGIC target_live_fiscal_year_quarter,
# MAGIC target_onboarding_date,
# MAGIC use_case_product,
# MAGIC usecase_id,
# MAGIC usecase_name,
# MAGIC estimated_monthly_dollar_dbus,
# MAGIC num_of_blockers,
# MAGIC num_partners,
# MAGIC T3M_DBU_Annualised__c
# MAGIC from main.it_aibi_bronze.usecase_review_dash_bronze
# MAGIC
