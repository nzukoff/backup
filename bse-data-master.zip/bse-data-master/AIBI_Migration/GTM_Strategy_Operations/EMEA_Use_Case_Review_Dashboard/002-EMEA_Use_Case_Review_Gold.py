# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.emea_use_case_review_gold as
# MAGIC
# MAGIC
# MAGIC WITH distinct_use_cases AS (
# MAGIC     SELECT COUNT(DISTINCT usecase_id) AS use_cases
# MAGIC     FROM main.it_aibi_silver.emea_use_case_review_silver
# MAGIC )
# MAGIC SELECT
# MAGIC     a.*,
# MAGIC     CASE
# MAGIC         WHEN a.use_case_product LIKE '%DBSQL%' THEN a.estimated_monthly_dollar_dbus
# MAGIC         ELSE NULL
# MAGIC     END AS DBSQL,
# MAGIC     CASE
# MAGIC         WHEN a.use_case_product LIKE '%DBSQL%' AND a.estimated_monthly_dollar_dbus > 0 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS DBSQL_attached,
# MAGIC     'FY' || CAST(a.target_live_fiscal_year AS VARCHAR(10)) || 'Q' || CAST(a.target_live_fiscal_quarter AS VARCHAR(10)) AS fiscal_period,
# MAGIC     CASE
# MAGIC         WHEN a.use_case_product LIKE '%GenAI%' THEN a.estimated_monthly_dollar_dbus
# MAGIC         ELSE NULL
# MAGIC     END AS GenAI,
# MAGIC     CASE
# MAGIC         WHEN a.use_case_product LIKE '%GenAI%' AND a.estimated_monthly_dollar_dbus > 0 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS GenAI_attached,
# MAGIC     CASE
# MAGIC         WHEN a.use_case_product LIKE '%Unity Catalog%' THEN a.estimated_monthly_dollar_dbus
# MAGIC         ELSE NULL
# MAGIC     END AS Unity_Catalog,
# MAGIC     CASE
# MAGIC         WHEN a.use_case_product LIKE '%Unity Catalog%' AND a.estimated_monthly_dollar_dbus > 0 THEN TRUE
# MAGIC         ELSE FALSE
# MAGIC     END AS Unity_Catalog_attached,
# MAGIC     a.estimated_monthly_dollar_dbus * 3 AS quarterized_DBU,
# MAGIC     a.estimated_monthly_dollar_dbus * 3 * 
# MAGIC     CASE
# MAGIC         WHEN a.stage = 'U1' THEN 0
# MAGIC         WHEN a.stage = 'U2' THEN 0.1
# MAGIC         WHEN a.stage = 'U3' THEN 0.5
# MAGIC         WHEN a.stage = 'U4' THEN 0.65
# MAGIC         WHEN a.stage = 'U5' THEN 0.8
# MAGIC         WHEN a.stage = 'U6' THEN 1
# MAGIC         ELSE 1
# MAGIC     END AS weighted_quarterized_DBU,
# MAGIC     (SELECT use_cases FROM distinct_use_cases) AS use_cases,
# MAGIC     CASE
# MAGIC         WHEN a.stage = 'U1' THEN 0
# MAGIC         WHEN a.stage = 'U2' THEN 0.1
# MAGIC         WHEN a.stage = 'U3' THEN 0.5
# MAGIC         WHEN a.stage = 'U4' THEN 0.65
# MAGIC         WHEN a.stage = 'U5' THEN 0.8
# MAGIC         WHEN a.stage = 'U6' THEN 1
# MAGIC         ELSE 1
# MAGIC     END AS weight
# MAGIC FROM main.it_aibi_silver.emea_use_case_review_silver a
