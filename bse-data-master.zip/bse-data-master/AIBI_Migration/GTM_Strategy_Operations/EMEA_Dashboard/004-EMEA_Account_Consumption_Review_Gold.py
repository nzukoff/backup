# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.emea_account_consumption_review_gold AS
# MAGIC
# MAGIC WITH current_fiscal_period AS (
# MAGIC   SELECT 
# MAGIC     'FY' || 
# MAGIC     CASE 
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) = 1 THEN EXTRACT(YEAR FROM CURRENT_DATE) % 100
# MAGIC       ELSE (EXTRACT(YEAR FROM CURRENT_DATE) + 1) % 100
# MAGIC     END ||
# MAGIC     'Q' ||
# MAGIC     CASE 
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) BETWEEN 2 AND 4 THEN 1
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) BETWEEN 5 AND 7 THEN 2
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) BETWEEN 8 AND 10 THEN 3
# MAGIC       ELSE 4
# MAGIC     END AS current_fiscal_period
# MAGIC ),
# MAGIC fiscal_periods AS (
# MAGIC   SELECT 
# MAGIC     CONCAT(FiscalYear, FiscalQuarter) AS FiscalPeriod,
# MAGIC     try_cast(SUBSTRING(FiscalYear, 3, 2) || FiscalQuarter AS INTEGER) AS FiscalPeriod_Sort,
# MAGIC     LAG(CONCAT(FiscalYear, FiscalQuarter), 1) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ_1_FiscalPeriod,
# MAGIC     LAG(CONCAT(FiscalYear, FiscalQuarter), 2) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ_2_FiscalPeriod,
# MAGIC     LAG(CONCAT(FiscalYear, FiscalQuarter), 3) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ_3_FiscalPeriod,
# MAGIC     LAG(CONCAT(FiscalYear, FiscalQuarter), 4) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ_4_FiscalPeriod,
# MAGIC     LAG(CONCAT(FiscalYear, FiscalQuarter), 5) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ_5_FiscalPeriod,
# MAGIC     LAG(CONCAT(FiscalYear, FiscalQuarter), 6) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ_6_FiscalPeriod,
# MAGIC     LAG(CONCAT(FiscalYear, FiscalQuarter), 7) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ_7_FiscalPeriod,
# MAGIC     LAG(CONCAT(FiscalYear, FiscalQuarter), 8) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ_8_FiscalPeriod,
# MAGIC     LEAD(CONCAT(FiscalYear, FiscalQuarter), 1) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ1_FiscalPeriod,
# MAGIC     LEAD(CONCAT(FiscalYear, FiscalQuarter), 2) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ2_FiscalPeriod,
# MAGIC     LEAD(CONCAT(FiscalYear, FiscalQuarter), 3) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ3_FiscalPeriod,
# MAGIC     LEAD(CONCAT(FiscalYear, FiscalQuarter), 4) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ4_FiscalPeriod,
# MAGIC     LEAD(CONCAT(FiscalYear, FiscalQuarter), 5) OVER (ORDER BY FiscalYear, FiscalQuarter) AS CQ5_FiscalPeriod
# MAGIC   FROM main.it_aibi_silver.emea_account_consumption_review_silver
# MAGIC   GROUP BY FiscalYear, FiscalQuarter
# MAGIC ),
# MAGIC main_data AS (
# MAGIC   SELECT 
# MAGIC     m.*,
# MAGIC     fp.*,
# MAGIC     CASE 
# MAGIC       WHEN fp.FiscalPeriod < (SELECT current_fiscal_period FROM current_fiscal_period)
# MAGIC       THEN m.actual_plus_ds
# MAGIC       ELSE m.og_forecast_plus_pipe_weighted / 3
# MAGIC     END AS OG_Weighted,
# MAGIC     CASE 
# MAGIC       WHEN fp.FiscalPeriod < (SELECT current_fiscal_period FROM current_fiscal_period)
# MAGIC       THEN m.actual_plus_ds
# MAGIC       ELSE m.AE_fcst
# MAGIC     END AS AE_Forecast,
# MAGIC     (SELECT current_fiscal_period FROM current_fiscal_period) AS Current_FiscalPeriod,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ_1_FiscalPeriod THEN m.actual_plus_ds ELSE 0 END AS CQ_1_Actual,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ_2_FiscalPeriod THEN m.actual_plus_ds ELSE 0 END AS CQ_2_Actual,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ_3_FiscalPeriod THEN m.actual_plus_ds ELSE 0 END AS CQ_3_Actual,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ_4_FiscalPeriod THEN m.actual_plus_ds ELSE 0 END AS CQ_4_Actual,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ_5_FiscalPeriod THEN m.actual_plus_ds ELSE 0 END AS CQ_5_Actual,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ_6_FiscalPeriod THEN m.actual_plus_ds ELSE 0 END AS CQ_6_Actual,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ_7_FiscalPeriod THEN m.actual_plus_ds ELSE 0 END AS CQ_7_Actual,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ_8_FiscalPeriod THEN m.actual_plus_ds ELSE 0 END AS CQ_8_Actual,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ1_FiscalPeriod THEN m.AE_fcst ELSE 0 END AS CQ1_AE,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ2_FiscalPeriod THEN m.AE_fcst ELSE 0 END AS CQ2_AE,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ3_FiscalPeriod THEN m.AE_fcst ELSE 0 END AS CQ3_AE,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ4_FiscalPeriod THEN m.AE_fcst ELSE 0 END AS CQ4_AE,
# MAGIC     CASE WHEN fp.FiscalPeriod = fp.CQ5_FiscalPeriod THEN m.AE_fcst ELSE 0 END AS CQ5_AE
# MAGIC   FROM 
# MAGIC     main.it_aibi_silver.emea_account_consumption_review_silver m
# MAGIC   JOIN
# MAGIC     fiscal_periods fp ON CONCAT(m.FiscalYear, m.FiscalQuarter) = fp.FiscalPeriod
# MAGIC ),
# MAGIC calculated_data AS (
# MAGIC   SELECT 
# MAGIC     *,
# MAGIC     CASE
# MAGIC       WHEN FiscalPeriod = Current_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_1_Actual) OVER (PARTITION BY ReportingID, CQ_1_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ5_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ4_AE) OVER (PARTITION BY ReportingID, CQ4_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ4_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ3_AE) OVER (PARTITION BY ReportingID, CQ3_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ3_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ2_AE) OVER (PARTITION BY ReportingID, CQ2_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ2_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ1_AE) OVER (PARTITION BY ReportingID, CQ1_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ1_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(AE_Forecast) OVER (PARTITION BY ReportingID, Current_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_1_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_2_Actual) OVER (PARTITION BY ReportingID, CQ_2_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_2_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_3_Actual) OVER (PARTITION BY ReportingID, CQ_3_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_3_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_4_Actual) OVER (PARTITION BY ReportingID, CQ_4_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_4_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_5_Actual) OVER (PARTITION BY ReportingID, CQ_5_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_5_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_6_Actual) OVER (PARTITION BY ReportingID, CQ_6_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_6_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_7_Actual) OVER (PARTITION BY ReportingID, CQ_7_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_7_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_8_Actual) OVER (PARTITION BY ReportingID, CQ_8_FiscalPeriod), 0)) - 1, 0)
# MAGIC       ELSE 0
# MAGIC     END AS AE_Forecast_QoQ_Percentage,
# MAGIC     CASE
# MAGIC        WHEN FiscalPeriod = Current_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_4_Actual) OVER (PARTITION BY ReportingID, CQ_4_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ5_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ1_AE) OVER (PARTITION BY ReportingID, CQ1_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ4_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(AE_Forecast) OVER (PARTITION BY ReportingID, Current_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ3_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_1_Actual) OVER (PARTITION BY ReportingID, CQ_1_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ2_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_2_Actual) OVER (PARTITION BY ReportingID, CQ_2_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ1_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_3_Actual) OVER (PARTITION BY ReportingID, CQ_3_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_1_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_5_Actual) OVER (PARTITION BY ReportingID, CQ_5_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_2_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_6_Actual) OVER (PARTITION BY ReportingID, CQ_6_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_3_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_7_Actual) OVER (PARTITION BY ReportingID, CQ_7_FiscalPeriod), 0)) - 1, 0)
# MAGIC       WHEN FiscalPeriod = CQ_4_FiscalPeriod THEN 
# MAGIC         COALESCE((SUM(AE_Forecast) OVER (PARTITION BY ReportingID, FiscalPeriod) / NULLIF(SUM(CQ_8_Actual) OVER (PARTITION BY ReportingID, CQ_8_FiscalPeriod), 0)) - 1, 0)
# MAGIC       ELSE 0
# MAGIC     END AS AE_Forecast_YOY_Percentage
# MAGIC FROM main_data
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   SUBSTRING(FiscalYear, 3, 2) AS Year,
# MAGIC   FiscalQuarter,
# MAGIC   EMEA_BU_Cohort,
# MAGIC   EMEA_L1_Cohort,
# MAGIC   EMEA_Lighthouse_Account,
# MAGIC   ownerName,
# MAGIC   ReportingName,
# MAGIC   sfdc_region_l1,
# MAGIC   sfdc_region_l2,
# MAGIC   sfdc_region_l3,
# MAGIC   AE_Forecast AS Current,
# MAGIC   LAG(AE_Forecast) OVER (PARTITION BY ReportingID ORDER BY FiscalPeriod_Sort) AS Previous,
# MAGIC   LAG(AE_Forecast, 2) OVER (PARTITION BY ReportingID ORDER BY FiscalPeriod_Sort) AS Previous2,
# MAGIC   AE_Forecast - LAG(AE_Forecast) OVER (PARTITION BY ReportingID ORDER BY FiscalPeriod_Sort) AS Diff,
# MAGIC   AE_Forecast_QoQ_Percentage,
# MAGIC   AE_Forecast_YOY_Percentage
# MAGIC FROM calculated_data
# MAGIC ORDER BY ReportingID, FiscalPeriod_Sort
