# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.emea_consumption_trend_gold
# MAGIC
# MAGIC
# MAGIC WITH cte AS (
# MAGIC   SELECT
# MAGIC     date,
# MAGIC     accountid,
# MAGIC     accountname,
# MAGIC     dbudollars,
# MAGIC     t7d,
# MAGIC     t28d,
# MAGIC     t90d,
# MAGIC     t365d,
# MAGIC     l1_static_cohort,
# MAGIC     l2_static_cohort,
# MAGIC     l3_static_cohort,
# MAGIC     l4_static_cohort,
# MAGIC     fiscalyear,
# MAGIC     fiscalqtr,
# MAGIC     sfdc_region_l1,
# MAGIC     sfdc_region_l2,
# MAGIC     sfdc_region_l3,
# MAGIC     sfdc_region_l4,
# MAGIC     bu,
# MAGIC     previous_fy_consumption,
# MAGIC     bu_static_cohort,
# MAGIC     t7d * 365 AS t7d_annualized,
# MAGIC     t28d * 365 AS t28d_annualized,
# MAGIC     t90d * 365 AS t90d_annualized,  -- Added T90D annualized
# MAGIC     t365d * 365 AS t365d_annualized,  -- Added T365D annualized
# MAGIC     CURRENT_DATE AS today,
# MAGIC     MAX(date) OVER () AS max_date,
# MAGIC     CASE 
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) IN (2, 3, 4) THEN DATE(EXTRACT(YEAR FROM CURRENT_DATE) || '-04-30')
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) IN (5, 6, 7) THEN DATE(EXTRACT(YEAR FROM CURRENT_DATE) || '-07-31')
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) IN (8, 9, 10) THEN DATE(EXTRACT(YEAR FROM CURRENT_DATE) || '-10-31')
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) IN (11, 12) THEN DATE((EXTRACT(YEAR FROM CURRENT_DATE) + 1) || '-01-31')
# MAGIC       ELSE DATE(EXTRACT(YEAR FROM CURRENT_DATE) || '-01-31')
# MAGIC     END AS cq_end_date,
# MAGIC     CASE 
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) = 1 THEN DATE(EXTRACT(YEAR FROM CURRENT_DATE) || '-01-31')
# MAGIC       ELSE DATE((EXTRACT(YEAR FROM CURRENT_DATE) + 1) || '-01-31')
# MAGIC     END AS cy_end_date,
# MAGIC     CASE 
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) = 1 THEN EXTRACT(YEAR FROM CURRENT_DATE)
# MAGIC       ELSE EXTRACT(YEAR FROM CURRENT_DATE) + 1
# MAGIC     END AS current_fiscalyear,
# MAGIC     CASE 
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) IN (2, 3, 4) THEN 'Q1'
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) IN (5, 6, 7) THEN 'Q2'
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) IN (8, 9, 10) THEN 'Q3'
# MAGIC       ELSE 'Q4'
# MAGIC     END AS current_fq
# MAGIC   FROM main.it_aibi_silver.emea_consumption_trend_silver
# MAGIC ),
# MAGIC calculations AS (
# MAGIC   SELECT
# MAGIC     *,
# MAGIC     'FY' || (fiscalyear - 2000) || ' ' || fiscalqtr AS fiscalperiod,
# MAGIC     CASE 
# MAGIC       WHEN date = max_date THEN t7d_annualized
# MAGIC       ELSE 0
# MAGIC     END AS latest_t7d_annualized,
# MAGIC     CASE 
# MAGIC       WHEN date = max_date THEN t28d_annualized
# MAGIC       ELSE 0
# MAGIC     END AS latest_t28d_annualized,
# MAGIC     CASE 
# MAGIC       WHEN date = max_date - INTERVAL '28 days' THEN t28d_annualized
# MAGIC       ELSE 0
# MAGIC     END AS previous_t28d_annualized,
# MAGIC     CASE 
# MAGIC       WHEN date = max_date THEN t90d_annualized
# MAGIC       ELSE 0
# MAGIC     END AS latest_t90d_annualized,  -- Added latest T90D annualized
# MAGIC     CASE 
# MAGIC       WHEN date = max_date THEN t365d_annualized
# MAGIC       ELSE 0
# MAGIC     END AS latest_t365d_annualized,  -- Added latest T365D annualized
# MAGIC     DATEDIFF(cq_end_date, today) AS cq_days_left,
# MAGIC     DATEDIFF(cy_end_date, today) AS cy_days_left,
# MAGIC     CASE 
# MAGIC       WHEN fiscalyear = current_fiscalyear AND fiscalqtr = current_fq AND date <= today
# MAGIC       THEN dbudollars
# MAGIC       ELSE 0
# MAGIC     END AS qtd_consumption,
# MAGIC     CASE 
# MAGIC       WHEN fiscalyear = current_fiscalyear AND date <= today
# MAGIC       THEN dbudollars
# MAGIC       ELSE 0
# MAGIC     END AS ytd_consumption,
# MAGIC     CASE 
# MAGIC       WHEN (current_fq = 'Q1' AND fiscalqtr = 'Q4' AND fiscalyear < current_fiscalyear) OR
# MAGIC            (current_fq = 'Q2' AND fiscalqtr = 'Q1' AND fiscalyear = current_fiscalyear) OR
# MAGIC            (current_fq = 'Q3' AND fiscalqtr = 'Q2' AND fiscalyear = current_fiscalyear) OR
# MAGIC            (current_fq = 'Q4' AND fiscalqtr = 'Q3' AND fiscalyear = current_fiscalyear)
# MAGIC       THEN dbudollars
# MAGIC       ELSE 0
# MAGIC     END AS pq_consumption
# MAGIC   FROM cte
# MAGIC ),
# MAGIC projections AS (
# MAGIC   SELECT
# MAGIC     *,
# MAGIC     SUM(qtd_consumption) OVER () + ((SUM(latest_t7d_annualized) OVER () / 365) * MAX(cq_days_left) OVER ()) AS cq_projection_by_t7d,
# MAGIC     SUM(qtd_consumption) OVER () + ((SUM(latest_t28d_annualized) OVER () / 365) * MAX(cq_days_left) OVER ()) AS cq_projection_by_t28d,
# MAGIC     SUM(ytd_consumption) OVER () + ((SUM(latest_t28d_annualized) OVER () / 365) * MAX(cy_days_left) OVER ()) AS cy_projection_by_t28d,
# MAGIC     (SUM(CASE WHEN date = max_date THEN t7d_annualized ELSE 0 END) OVER ()) /
# MAGIC     NULLIF(SUM(CASE WHEN date = max_date - INTERVAL '7 days' THEN t7d_annualized ELSE 0 END) OVER (), 0) - 1 AS t7d_wow_percentage,
# MAGIC     (SUM(CASE WHEN date = max_date THEN t28d_annualized ELSE 0 END) OVER ()) /
# MAGIC     NULLIF(SUM(CASE WHEN date = max_date - INTERVAL '28 days' THEN t28d_annualized ELSE 0 END) OVER (), 0) - 1 AS t28d_mom_percentage
# MAGIC   FROM calculations
# MAGIC )
# MAGIC SELECT
# MAGIC   *,
# MAGIC   (SUM(cq_projection_by_t7d) OVER () / NULLIF(SUM(pq_consumption) OVER (), 0)) - 1 AS implied_qoq_by_t7d,
# MAGIC   (SUM(cq_projection_by_t28d) OVER () / NULLIF(SUM(pq_consumption) OVER (), 0)) - 1 AS implied_qoq_by_t28d,
# MAGIC   (SUM(cy_projection_by_t28d) OVER () / NULLIF(SUM(previous_fy_consumption) OVER (), 0)) - 1 AS implied_yoy_by_t28d,
# MAGIC   CASE
# MAGIC     WHEN (SUM(cq_projection_by_t7d) OVER () / NULLIF(SUM(pq_consumption) OVER (), 0)) - 1 < 0.1 THEN 'Red'
# MAGIC     WHEN (SUM(cq_projection_by_t7d) OVER () / NULLIF(SUM(pq_consumption) OVER (), 0)) - 1 < 0.15 THEN 'Yellow'
# MAGIC     ELSE 'Green'
# MAGIC   END AS t7d_implied_qoq_color,
# MAGIC   CASE
# MAGIC     WHEN (SUM(cq_projection_by_t28d) OVER () / NULLIF(SUM(pq_consumption) OVER (), 0)) - 1 < 0.1 THEN 'Red'
# MAGIC     WHEN (SUM(cq_projection_by_t28d) OVER () / NULLIF(SUM(pq_consumption) OVER (), 0)) - 1 < 0.15 THEN 'Yellow'
# MAGIC     ELSE 'Green'
# MAGIC   END AS t28d_implied_qoq_color,
# MAGIC   CASE
# MAGIC     WHEN (SUM(cy_projection_by_t28d) OVER () / NULLIF(SUM(previous_fy_consumption) OVER (), 0)) - 1 IS NULL THEN 'NULL'
# MAGIC     WHEN (SUM(cy_projection_by_t28d) OVER () / NULLIF(SUM(previous_fy_consumption) OVER (), 0)) - 1 < 0.46 THEN 'Red'
# MAGIC     WHEN (SUM(cy_projection_by_t28d) OVER () / NULLIF(SUM(previous_fy_consumption) OVER (), 0)) - 1 < 0.75 THEN 'Yellow'
# MAGIC     ELSE 'Green'
# MAGIC   END AS t28d_yoy_color,
# MAGIC   CASE
# MAGIC     WHEN t7d_wow_percentage < 0.0074 THEN 'Red'
# MAGIC     WHEN t7d_wow_percentage < 0.0109 THEN 'Yellow'
# MAGIC     ELSE 'Green'
# MAGIC   END AS t7d_wow_color,
# MAGIC   CASE
# MAGIC     WHEN t28d_mom_percentage < 0.0301 THEN 'Red'
# MAGIC     WHEN t28d_mom_percentage < 0.0445 THEN 'Yellow'
# MAGIC     ELSE 'Green'
# MAGIC   END AS t28d_mom_color
# MAGIC FROM projections
