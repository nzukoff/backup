# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.emea_account_consumption_use_case_overview_gold as
# MAGIC
# MAGIC WITH current_fiscal_period AS (
# MAGIC   SELECT 
# MAGIC     'FY' || 
# MAGIC     CASE 
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) = 1 THEN EXTRACT(YEAR FROM CURRENT_DATE) % 100
# MAGIC       ELSE (EXTRACT(YEAR FROM CURRENT_DATE) + 1) % 100
# MAGIC     END ||
# MAGIC     'Q' ||
# MAGIC     CASE 
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) BETWEEN 2 AND 4 THEN 1
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) BETWEEN 5 AND 7 THEN 2
# MAGIC       WHEN EXTRACT(MONTH FROM CURRENT_DATE) BETWEEN 8 AND 10 THEN 3
# MAGIC       ELSE 4
# MAGIC     END AS current_fiscal_period
# MAGIC ),
# MAGIC fiscal_periods AS (
# MAGIC   SELECT 
# MAGIC     CONCAT('FY', 
# MAGIC            CASE 
# MAGIC              WHEN EXTRACT(MONTH FROM Date) = 1 THEN EXTRACT(YEAR FROM Date) % 100
# MAGIC              ELSE (EXTRACT(YEAR FROM Date) + 1) % 100
# MAGIC            END,
# MAGIC            'Q',
# MAGIC            CASE 
# MAGIC              WHEN EXTRACT(MONTH FROM Date) BETWEEN 2 AND 4 THEN 1
# MAGIC              WHEN EXTRACT(MONTH FROM Date) BETWEEN 5 AND 7 THEN 2
# MAGIC              WHEN EXTRACT(MONTH FROM Date) BETWEEN 8 AND 10 THEN 3
# MAGIC              ELSE 4
# MAGIC            END) AS FiscalPeriod,
# MAGIC     Date
# MAGIC   FROM main.it_aibi_silver.emea_account_consumption_use_case_overview_silver
# MAGIC   GROUP BY Date
# MAGIC )
# MAGIC SELECT
# MAGIC   m.*,
# MAGIC   fp.FiscalPeriod,
# MAGIC   (SELECT current_fiscal_period FROM current_fiscal_period) AS Current_FiscalPeriod,
# MAGIC   CASE 
# MAGIC     WHEN m.bu_rank <= 20 THEN 'Top 20'
# MAGIC     WHEN m.bu_rank <= 100 THEN 'Middle Tier'
# MAGIC     WHEN m.previous_fy_consumption = 0 OR m.previous_fy_consumption IS NULL THEN 'CY Net New'
# MAGIC     ELSE 'Long Tail'
# MAGIC   END AS Filtered_Cohort,
# MAGIC   CASE 
# MAGIC     WHEN m.stage IN ('Onboarding','U5','U4') THEN 'Committed'
# MAGIC     WHEN m.stage IN ('Evaluation','U3') THEN 'Best Case'
# MAGIC     WHEN m.stage IN ('Live','U6') THEN 'Live'
# MAGIC     WHEN m.stage IN('Lost') THEN 'Lost'
# MAGIC     WHEN m.stage_name_ui IN('Disqualified') THEN 'Disqualified'
# MAGIC     ELSE 'Pipeline'
# MAGIC   END AS Forecast_Type,
# MAGIC   CONCAT('FY', 
# MAGIC          CASE 
# MAGIC            WHEN EXTRACT(MONTH FROM m.created_date) = 1 THEN EXTRACT(YEAR FROM m.created_date) % 100
# MAGIC            ELSE (EXTRACT(YEAR FROM m.created_date) + 1) % 100
# MAGIC          END,
# MAGIC          'Q',
# MAGIC          CASE 
# MAGIC            WHEN EXTRACT(MONTH FROM m.created_date) BETWEEN 2 AND 4 THEN 1
# MAGIC            WHEN EXTRACT(MONTH FROM m.created_date) BETWEEN 5 AND 7 THEN 2
# MAGIC            WHEN EXTRACT(MONTH FROM m.created_date) BETWEEN 8 AND 10 THEN 3
# MAGIC            ELSE 4
# MAGIC          END) AS Created_FiscalPeriod,
# MAGIC   CONCAT('FY', 
# MAGIC          CASE 
# MAGIC            WHEN EXTRACT(MONTH FROM COALESCE(m.target_onboarding_date, m.target_live_date)) = 1 
# MAGIC            THEN EXTRACT(YEAR FROM COALESCE(m.target_onboarding_date, m.target_live_date)) % 100
# MAGIC            ELSE (EXTRACT(YEAR FROM COALESCE(m.target_onboarding_date, m.target_live_date)) + 1) % 100
# MAGIC          END,
# MAGIC          'Q',
# MAGIC          CASE 
# MAGIC            WHEN EXTRACT(MONTH FROM COALESCE(m.target_onboarding_date, m.target_live_date)) BETWEEN 2 AND 4 THEN 1
# MAGIC            WHEN EXTRACT(MONTH FROM COALESCE(m.target_onboarding_date, m.target_live_date)) BETWEEN 5 AND 7 THEN 2
# MAGIC            WHEN EXTRACT(MONTH FROM COALESCE(m.target_onboarding_date, m.target_live_date)) BETWEEN 8 AND 10 THEN 3
# MAGIC            ELSE 4
# MAGIC          END) AS Cal_Onboarding_FiscalPeriod,
# MAGIC   CASE 
# MAGIC     WHEN fp.FiscalPeriod = (SELECT current_fiscal_period FROM current_fiscal_period) THEN m.forecast_usage
# MAGIC     ELSE 0
# MAGIC   END AS CQ_Estimated_DBU,
# MAGIC   CASE 
# MAGIC     WHEN fp.FiscalPeriod = (
# MAGIC       SELECT 
# MAGIC         CASE 
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q4' THEN CONCAT('FY', CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1, 'Q1')
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q3' THEN CONCAT('FY', SUBSTRING(current_fiscal_period, 3, 2), 'Q4')
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q2' THEN CONCAT('FY', SUBSTRING(current_fiscal_period, 3, 2), 'Q3')
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q1' THEN CONCAT('FY', SUBSTRING(current_fiscal_period, 3, 2), 'Q2')
# MAGIC         END
# MAGIC       FROM current_fiscal_period
# MAGIC     ) THEN m.forecast_usage
# MAGIC     ELSE 0
# MAGIC   END AS CQ1_Estimated_DBU,
# MAGIC   CASE 
# MAGIC     WHEN fp.FiscalPeriod = (
# MAGIC       SELECT 
# MAGIC         CASE 
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q4' THEN CONCAT('FY', CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1, 'Q2')
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q3' THEN CONCAT('FY', CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1, 'Q1')
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q2' THEN CONCAT('FY', SUBSTRING(current_fiscal_period, 3, 2), 'Q4')
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q1' THEN CONCAT('FY', SUBSTRING(current_fiscal_period, 3, 2), 'Q3')
# MAGIC         END
# MAGIC       FROM current_fiscal_period
# MAGIC     ) THEN m.forecast_usage
# MAGIC     ELSE 0
# MAGIC   END AS CQ2_Estimated_DBU,
# MAGIC   CASE 
# MAGIC     WHEN fp.FiscalPeriod = (
# MAGIC       SELECT 
# MAGIC         CASE 
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q4' THEN CONCAT('FY', CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1, 'Q3')
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q3' THEN CONCAT('FY', CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1, 'Q2')
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q2' THEN CONCAT('FY', CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1, 'Q1')
# MAGIC           WHEN RIGHT(current_fiscal_period, 2) = 'Q1' THEN CONCAT('FY', SUBSTRING(current_fiscal_period, 3, 2), 'Q4')
# MAGIC         END
# MAGIC       FROM current_fiscal_period
# MAGIC     ) THEN m.forecast_usage
# MAGIC     ELSE 0
# MAGIC   END AS CQ3_Estimated_DBU
# MAGIC FROM 
# MAGIC   main.it_aibi_silver.emea_account_consumption_use_case_overview_silver m
# MAGIC JOIN
# MAGIC   fiscal_periods fp ON m.Date = fp.Date
