# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.emea_account_consumption_use_case_overview_silver as
# MAGIC
# MAGIC select
# MAGIC bu,
# MAGIC ownerName,
# MAGIC sfdc_region_l1,
# MAGIC sfdc_region_l2,
# MAGIC sfdc_region_l3,
# MAGIC bu_rank,
# MAGIC l1_rank,
# MAGIC l2_rank,
# MAGIC l3_rank,
# MAGIC previous_fy_consumption,
# MAGIC u.account_executive,
# MAGIC u.account_name,
# MAGIC u.business_unit,
# MAGIC u.created_date,
# MAGIC u.`Date`,
# MAGIC u.has_ps_project,
# MAGIC u.implementation_partner,
# MAGIC u.is_migration_usecase,
# MAGIC u.migration_type,
# MAGIC u.ramp_type,
# MAGIC u.sales_subregion_level_1,
# MAGIC u.sales_subregion_level_2,
# MAGIC u.sales_subregion_level_3,
# MAGIC u.stage,
# MAGIC u.stage_name_ui,
# MAGIC u.target_live_date,
# MAGIC u.target_onboarding_date,
# MAGIC u.usecase_id,
# MAGIC u.usecase_name,
# MAGIC u.usecase_owner,
# MAGIC u.days_in_stage,
# MAGIC u.estimated_monthly_dollar_dbus,
# MAGIC u.forecast_usage,
# MAGIC u.num_of_blockers
# MAGIC from main.it_aibi_bronze.cohort_usecases_monthly_ramping_usage_bronze c
# MAGIC left join main.it_aibi_bronze.usecases_monthly_ramping_usage_bronze u
# MAGIC on c.ReportingID=u.ReportingID
# MAGIC
