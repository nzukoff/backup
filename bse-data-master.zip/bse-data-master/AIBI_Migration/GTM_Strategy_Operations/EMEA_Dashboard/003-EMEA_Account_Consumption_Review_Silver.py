# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.emea_account_consumption_review_silver
# MAGIC
# MAGIC select
# MAGIC EMEA_BU_Cohort,
# MAGIC EMEA_L1_Cohort,
# MAGIC EMEA_Lighthouse_Account,
# MAGIC fiscal_year_quarter,
# MAGIC FiscalQuarter,
# MAGIC FiscalYear,
# MAGIC ownerName,
# MAGIC ReportingID,
# MAGIC ReportingName,
# MAGIC sfdc_region_l1,
# MAGIC sfdc_region_l2,
# MAGIC sfdc_region_l3,
# MAGIC actual_plus_ds,
# MAGIC AE_fcst,
# MAGIC og_forecast_plus_pipe_weighted
# MAGIC from main.it_aibi_bronze.account_consumption_review_revamp_bronze
# MAGIC
