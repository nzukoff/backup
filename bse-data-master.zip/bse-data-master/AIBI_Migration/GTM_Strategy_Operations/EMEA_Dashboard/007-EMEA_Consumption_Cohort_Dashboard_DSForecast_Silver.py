# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.emea_consumption_cohort_silver
# MAGIC
# MAGIC select
# MAGIC billingCountry,
# MAGIC ReportingID,
# MAGIC ReportingName,
# MAGIC ownerName,
# MAGIC FiscalYear,
# MAGIC bu,
# MAGIC sfdc_region_l1,
# MAGIC sfdc_region_l2,
# MAGIC sfdc_region_l3,
# MAGIC bu_cloud,
# MAGIC L1_cloud,
# MAGIC L2_cloud,
# MAGIC L3_cloud,
# MAGIC CY_DS,
# MAGIC actual_plus_ds,
# MAGIC FiscalPeriod,
# MAGIC primary_cloud,
# MAGIC bu_rank,
# MAGIC l1_rank,
# MAGIC l2_rank,
# MAGIC l3_rank,
# MAGIC bu_cloud_rank,
# MAGIC L1_cloud_rank,
# MAGIC L2_cloud_rank,
# MAGIC L3_cloud_rank,
# MAGIC CY_bu_rank,
# MAGIC CY_l1_rank,
# MAGIC CY_l2_rank,
# MAGIC CY_l3_rank
# MAGIC from main.it_aibi_bronze.emea_salesstrat_cohort_dash_bronze
# MAGIC
