# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.emea_consumption_trend_silver
# MAGIC
# MAGIC select
# MAGIC date,
# MAGIC accountid,
# MAGIC accountname,
# MAGIC dbudollars,
# MAGIC t7d,
# MAGIC t28d,
# MAGIC t90d,
# MAGIC t365d,
# MAGIC l1_static_cohort,
# MAGIC l2_static_cohort,
# MAGIC l3_static_cohort,
# MAGIC l4_static_cohort,
# MAGIC fiscalyear,
# MAGIC fiscalqtr,
# MAGIC sfdc_region_l1,
# MAGIC sfdc_region_l2,
# MAGIC sfdc_region_l3,
# MAGIC sfdc_region_l4,
# MAGIC bu,
# MAGIC previous_fy_consumtion as previous_fy_consumption,
# MAGIC bu_static_cohort
# MAGIC from main.it_aibi_bronze.emea_salesstrat_trend_dash_bronze
