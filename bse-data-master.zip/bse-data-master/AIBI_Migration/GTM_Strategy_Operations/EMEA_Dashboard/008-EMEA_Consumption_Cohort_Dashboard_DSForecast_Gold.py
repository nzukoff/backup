# Databricks notebook source
# MAGIC %md
# MAGIC #final

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.emea_consumption_cohort_gold as
# MAGIC
# MAGIC WITH current_fiscal_data AS (
# MAGIC     SELECT
# MAGIC         'FY' ||
# MAGIC         CASE
# MAGIC             WHEN EXTRACT(MONTH FROM CURRENT_DATE) = 1 THEN EXTRACT(YEAR FROM CURRENT_DATE) % 100
# MAGIC             ELSE (EXTRACT(YEAR FROM CURRENT_DATE) + 1) % 100
# MAGIC         END ||
# MAGIC         'Q' ||
# MAGIC         CASE
# MAGIC             WHEN EXTRACT(MONTH FROM CURRENT_DATE) BETWEEN 2 AND 4 THEN 1
# MAGIC             WHEN EXTRACT(MONTH FROM CURRENT_DATE) BETWEEN 5 AND 7 THEN 2
# MAGIC             WHEN EXTRACT(MONTH FROM CURRENT_DATE) BETWEEN 8 AND 10 THEN 3
# MAGIC             ELSE 4
# MAGIC         END AS current_fiscal_period,
# MAGIC         'FY' ||
# MAGIC         CASE
# MAGIC             WHEN EXTRACT(MONTH FROM CURRENT_DATE) = 1 THEN EXTRACT(YEAR FROM CURRENT_DATE) % 100
# MAGIC             ELSE (EXTRACT(YEAR FROM CURRENT_DATE) + 1) % 100
# MAGIC         END AS current_fiscal_year
# MAGIC ),
# MAGIC fiscal_periods AS (
# MAGIC     SELECT
# MAGIC         current_fiscal_period,
# MAGIC         CASE 
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC     END AS cq_minus_1,
# MAGIC     CASE 
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC     END AS cq_minus_2,
# MAGIC     CASE 
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC     END AS cq_minus_3,
# MAGIC     'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || SUBSTRING(current_fiscal_period, 5, 2) AS cq_minus_4,
# MAGIC     CASE 
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC     END AS cq_minus_5,
# MAGIC     CASE 
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC     END AS cq_minus_6,
# MAGIC     CASE 
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 1 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC     END AS cq_minus_7,
# MAGIC     'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || SUBSTRING(current_fiscal_period, 5, 2) AS cq_minus_8,
# MAGIC     CASE 
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 3 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC     END AS cq_minus_9,
# MAGIC     CASE 
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 3 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 3 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC     END AS cq_minus_10,
# MAGIC     CASE 
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 3 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 3 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 3 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC       WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 2 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC     END AS cq_minus_11,
# MAGIC         CASE 
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC             ELSE 'Error'
# MAGIC         END AS cq_plus_1,
# MAGIC
# MAGIC         CASE 
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC             ELSE 'Error'
# MAGIC         END AS cq_plus_2,
# MAGIC
# MAGIC         CASE 
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q4' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1 AS VARCHAR(2)), 2, '0') || 'Q3'
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q3' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1 AS VARCHAR(2)), 2, '0') || 'Q2'
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q2' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) + 1 AS VARCHAR(2)), 2, '0') || 'Q1'
# MAGIC             WHEN SUBSTRING(current_fiscal_period, 5, 2) = 'Q1' THEN 'FY' || LPAD(CAST(CAST(SUBSTRING(current_fiscal_period, 3, 2) AS INT) - 0 AS VARCHAR(2)), 2, '0') || 'Q4'
# MAGIC             ELSE 'Error'
# MAGIC         END AS cq_plus_3
# MAGIC
# MAGIC     FROM (
# MAGIC         SELECT DISTINCT FiscalPeriod AS current_fiscal_period
# MAGIC         FROM main.it_aibi_silver.emea_consumption_cohort_silver
# MAGIC         UNION ALL
# MAGIC         SELECT current_fiscal_period FROM current_fiscal_data
# MAGIC     )
# MAGIC ),
# MAGIC yoy_calculation AS (
# MAGIC     SELECT
# MAGIC         *,
# MAGIC         SUM(actual_plus_ds) OVER (PARTITION BY ReportingID, FiscalYear) AS current_year_sum,
# MAGIC         SUM(CASE WHEN FiscalYear = 'FY23' THEN actual_plus_ds END) OVER (PARTITION BY ReportingID) AS fy23_sum,
# MAGIC         SUM(CASE WHEN FiscalYear = 'FY22' THEN actual_plus_ds END) OVER (PARTITION BY ReportingID) AS fy22_sum,
# MAGIC         SUM(CASE WHEN FiscalYear = 'FY21' THEN actual_plus_ds END) OVER (PARTITION BY ReportingID) AS fy21_sum,
# MAGIC         SUM(CASE WHEN FiscalYear = 'FY24' THEN actual_plus_ds END) OVER (PARTITION BY ReportingID) AS fy24_sum
# MAGIC     FROM main.it_aibi_silver.emea_consumption_cohort_silver
# MAGIC )
# MAGIC SELECT
# MAGIC
# MAGIC   y.*,
# MAGIC   (SELECT current_fiscal_period FROM current_fiscal_data) AS Current_FiscalPeriod,
# MAGIC   LEFT((SELECT current_fiscal_period FROM current_fiscal_data), 4) AS Current_Fiscal_Year,
# MAGIC   f.cq_plus_1 AS CQ_plus_1_Fiscal_Period,
# MAGIC   f.cq_plus_2 AS CQ_plus_2_Fiscal_Period,
# MAGIC   f.cq_plus_3 AS CQ_plus_3_Fiscal_Period,
# MAGIC
# MAGIC
# MAGIC     CASE
# MAGIC         WHEN SUM(y.CY_DS) OVER (PARTITION BY y.ReportingID) = 0 OR SUM(y.CY_DS) OVER (PARTITION BY y.ReportingID) IS NULL THEN '0. No consumption'
# MAGIC         WHEN SUM(y.CY_DS) OVER (PARTITION BY y.ReportingID) > 0 AND SUM(y.CY_DS) OVER (PARTITION BY y.ReportingID) <= 150000 THEN '1. Long Tail Spender'
# MAGIC         WHEN SUM(y.CY_DS) OVER (PARTITION BY y.ReportingID) > 150000 AND SUM(y.CY_DS) OVER (PARTITION BY y.ReportingID) <= 1000000 THEN '2. Middle Spender'
# MAGIC         WHEN SUM(y.CY_DS) OVER (PARTITION BY y.ReportingID) > 1000000 THEN '3. Top Spender'
# MAGIC     END AS CY_Spending_Bucket_collapsed,
# MAGIC     CASE
# MAGIC         WHEN y.FiscalYear = (SELECT MAX(FiscalYear) FROM main.it_aibi_silver.emea_consumption_cohort_silver) THEN y.actual_plus_ds
# MAGIC         ELSE 0
# MAGIC     END AS CY_DS_Calculated,
# MAGIC     -- YoY_Percentage_Yearly calculation
# MAGIC     CASE
# MAGIC         WHEN y.FiscalYear = 'FY24' AND y.fy23_sum > 0 THEN (y.current_year_sum / y.fy23_sum) - 1
# MAGIC         WHEN y.FiscalYear = 'FY23' AND y.fy22_sum > 0 THEN (y.current_year_sum / y.fy22_sum) - 1
# MAGIC         WHEN y.FiscalYear = 'FY22' AND y.fy21_sum > 0 THEN (y.current_year_sum / y.fy21_sum) - 1
# MAGIC         WHEN y.FiscalYear = 'FY25' AND y.fy24_sum > 0 THEN (y.current_year_sum / y.fy24_sum) - 1
# MAGIC         ELSE NULL
# MAGIC     END AS YoY_Percentage_Yearly,
# MAGIC     -- YoY_Color_Scheme_Yearly calculation
# MAGIC     CASE
# MAGIC         WHEN YoY_Percentage_Yearly IS NULL THEN NULL
# MAGIC         WHEN YoY_Percentage_Yearly < 0.46 THEN 'Red'
# MAGIC         WHEN YoY_Percentage_Yearly < 0.75 THEN 'Yellow'
# MAGIC         ELSE 'Green'
# MAGIC     END AS YoY_Color_Scheme_Yearly,
# MAGIC     -- QoQ_Percentage calculation
# MAGIC     (y.actual_plus_ds / NULLIF(LAG(y.actual_plus_ds) OVER (PARTITION BY y.ReportingID ORDER BY y.FiscalPeriod), 0)) - 1 AS QoQ_Percentage,
# MAGIC     -- QoQ_Color calculation
# MAGIC     CASE
# MAGIC         WHEN QoQ_Percentage IS NULL THEN NULL
# MAGIC         WHEN QoQ_Percentage < 0.1 THEN 'Red'
# MAGIC         WHEN QoQ_Percentage < 0.15 THEN 'Yellow'
# MAGIC         ELSE 'Green'
# MAGIC     END AS QoQ_Color,
# MAGIC     -- YoY_Percentage calculation
# MAGIC     (y.actual_plus_ds / NULLIF(LAG(y.actual_plus_ds, 4) OVER (PARTITION BY y.ReportingID ORDER BY y.FiscalPeriod), 0)) - 1 AS YoY_Percentage,
# MAGIC     -- YoY_Color_Scheme calculation
# MAGIC     CASE
# MAGIC         WHEN YoY_Percentage IS NULL THEN NULL
# MAGIC         WHEN YoY_Percentage < 0.46 THEN 'Red'
# MAGIC         WHEN YoY_Percentage < 0.75 THEN 'Yellow'
# MAGIC         ELSE 'Green'
# MAGIC     END AS YoY_Color_Scheme,
# MAGIC     -- Country calculation
# MAGIC     CASE
# MAGIC         WHEN y.billingCountry IN ('United Kingdom', 'Ireland') THEN 'United Kingdom'
# MAGIC         WHEN y.billingCountry = 'United States' THEN 'Other'
# MAGIC         WHEN y.billingCountry IN ('Netherlands', 'Germany', 'Denmark', 'Switzerland', 'France', 'Italy', 'Sweden', 'Israel', 'Belgium', 'Norway') THEN y.billingCountry
# MAGIC         WHEN y.billingCountry IN ('Portugal', 'Spain') THEN 'Spain'
# MAGIC         WHEN y.billingCountry IN ('Estonia', 'Greece', 'Luxembourg', 'Austria', 'Serbia', 'Hungary', 'Poland', 'Turkey',
# MAGIC             'Czech Republic', 'Russian Federation', 'Iceland', 'Cyprus', 'Malta', 'Slovenia', 'Jersey',
# MAGIC             'Gibraltar', 'Bulgaria', 'Slovakia', 'Lithuania', 'Georgia', 'Croatia', 'Macedonia',
# MAGIC             'Belarus', 'Romania', 'Ukraine', 'Azerbaijan', 'Armenia', 'Macedonia, the former Yugoslav Republic of',
# MAGIC             'Kosovo', 'Kazakhstan', 'Isle of Man', 'Moldova, Republic of', 'Albania', 'Latvia', 'Guernsey') THEN 'Rest of Europe'
# MAGIC         WHEN y.billingCountry IN ('South Africa', 'Nigeria', 'Morocco', 'Togo', 'Kenya', 'Mauritius', 'Zimbabwe', 'Tunisia', 'Ghana', 'Namibia') THEN 'Rest of Africa'
# MAGIC         WHEN y.billingCountry = 'United Arab Emirates' THEN 'UAE'
# MAGIC         WHEN y.billingCountry IN ('Qatar', 'Kuwait', 'Saudi Arabia', 'Oman', 'Lebanon', 'Jordan', 'Bahrain') THEN 'Rest of ME'
# MAGIC         WHEN y.billingCountry IN ('China', 'India', 'Brazil', 'Korea, Republic of', 'Korea', 'Canada', 'Australia', 'Singapore', 'Bermuda', 'Indonesia') THEN 'Other'
# MAGIC         ELSE y.billingCountry
# MAGIC     END AS Country,
# MAGIC     -- Period_filter calculation
# MAGIC     CASE
# MAGIC         WHEN y.FiscalPeriod = f.current_fiscal_period THEN 'CQ'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_1 THEN 'CQ-1'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_2 THEN 'CQ-2'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_3 THEN 'CQ-3'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_4 THEN 'CQ-4'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_5 THEN 'CQ-5'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_6 THEN 'CQ-6'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_7 THEN 'CQ-7'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_8 THEN 'CQ-8'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_9 THEN 'CQ-9'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_10 THEN 'CQ-10'
# MAGIC         WHEN y.FiscalPeriod = f.cq_minus_11 THEN 'CQ-11'
# MAGIC         ELSE 'None'
# MAGIC     END AS Period_filter,
# MAGIC     f.cq_minus_1 AS CQ_minus_1_Fiscal_Period,
# MAGIC     f.cq_minus_2 AS CQ_minus_2_Fiscal_Period,
# MAGIC     f.cq_minus_3 AS CQ_minus_3_Fiscal_Period,
# MAGIC     f.cq_minus_4 AS CQ_minus_4_Fiscal_Period,
# MAGIC     f.cq_minus_5 AS CQ_minus_5_Fiscal_Period,
# MAGIC     f.cq_minus_6 AS CQ_minus_6_Fiscal_Period,
# MAGIC     f.cq_minus_7 AS CQ_minus_7_Fiscal_Period,
# MAGIC     f.cq_minus_8 AS CQ_minus_8_Fiscal_Period,
# MAGIC     f.cq_minus_9 AS CQ_minus_9_Fiscal_Period,
# MAGIC     f.cq_minus_10 AS CQ_minus_10_Fiscal_Period,
# MAGIC     f.cq_minus_11 AS CQ_minus_11_Fiscal_Period
# MAGIC FROM yoy_calculation y
# MAGIC CROSS JOIN fiscal_periods f
# MAGIC WHERE f.current_fiscal_period = (SELECT current_fiscal_period FROM current_fiscal_data)
# MAGIC ORDER BY y.ReportingID, y.FiscalYear, y.FiscalPeriod
# MAGIC
# MAGIC
# MAGIC
# MAGIC
