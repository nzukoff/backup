# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.total_addressable_market_blend_gold as
# MAGIC
# MAGIC with funnel as (
# MAGIC     select 
# MAGIC     rff.account_region,
# MAGIC     CASE
# MAGIC         WHEN account_region IN ('AMER', 'LATAM') THEN 'AMER'
# MAGIC         WHEN account_region = 'EMEA' THEN 'EMEA'
# MAGIC         WHEN account_region = 'APJ' THEN 'APJ'
# MAGIC         ELSE 'Other'
# MAGIC     END as region,
# MAGIC     rff.audience_custom_audience_persona, 
# MAGIC     CASE
# MAGIC         WHEN audience_custom_audience_persona = 'BI' THEN 'BI/Analyst'
# MAGIC         WHEN audience_custom_audience_persona IN ('CDO', 'CIO', 'Business Execs') THEN 'Data Leaders'
# MAGIC         WHEN audience_custom_audience_persona = 'Data Scientist' THEN 'Data Scientist'
# MAGIC         WHEN audience_custom_audience_persona = 'Data Architect' THEN 'Data Architect'
# MAGIC         WHEN audience_custom_audience_persona = 'Data Engineer' THEN 'Data Engineer'
# MAGIC         ELSE 'Other'
# MAGIC     END as audience,
# MAGIC     COUNT(DISTINCT rff.audience_primary_lead_or_contact_id) AS contacts,
# MAGIC     rff.audience_primary_lead_or_contact_id,
# MAGIC     d.fiscal_month_start_date,
# MAGIC     d.fiscalYear,
# MAGIC     d.fiscal_year_quarter,
# MAGIC     d.cal_year_quarter,
# MAGIC     MIN(d.fiscal_month_start_date) AS min_date,
# MAGIC     date_trunc('MONTH', MIN(d.fiscal_month_start_date)) as month_year_blend
# MAGIC     from main.marketing_lakehouse.rpt_fact_funnel_for_analyst rff
# MAGIC     left join main.marketing_lakehouse.dim_date_attributes d 
# MAGIC     on d.`date` = rff.`date`
# MAGIC     where rff.`date` >= '2024-02-01' 
# MAGIC     and rff.`date` <= '2024-07-31'
# MAGIC     group by 
# MAGIC     rff.account_region,
# MAGIC     CASE
# MAGIC         WHEN account_region IN ('AMER', 'LATAM') THEN 'AMER'
# MAGIC         WHEN account_region = 'EMEA' THEN 'EMEA'
# MAGIC         WHEN account_region = 'APJ' THEN 'APJ'
# MAGIC         ELSE 'Other'
# MAGIC     END,
# MAGIC     rff.audience_custom_audience_persona, 
# MAGIC     CASE
# MAGIC         WHEN audience_custom_audience_persona = 'BI' THEN 'BI/Analyst'
# MAGIC         WHEN audience_custom_audience_persona IN ('CDO', 'CIO', 'Business Execs') THEN 'Data Leaders'
# MAGIC         WHEN audience_custom_audience_persona = 'Data Scientist' THEN 'Data Scientist'
# MAGIC         WHEN audience_custom_audience_persona = 'Data Architect' THEN 'Data Architect'
# MAGIC         WHEN audience_custom_audience_persona = 'Data Engineer' THEN 'Data Engineer'
# MAGIC         ELSE 'Other'
# MAGIC     END,
# MAGIC     rff.audience_primary_lead_or_contact_id,
# MAGIC     d.fiscal_month_start_date,
# MAGIC     d.fiscalYear,
# MAGIC     d.fiscal_year_quarter,
# MAGIC     d.cal_year_quarter
# MAGIC ),
# MAGIC
# MAGIC sheet as (
# MAGIC   select 
# MAGIC   account,
# MAGIC   advertiser,
# MAGIC   audience,
# MAGIC   month,
# MAGIC   quarter,
# MAGIC   region,
# MAGIC   sum(reach) as reach,
# MAGIC   sum(audience_size) as TAM
# MAGIC   from main.it_aibi_bronze.quarterly_tam_reach
# MAGIC   group by 
# MAGIC   account,
# MAGIC   advertiser,
# MAGIC   audience,
# MAGIC   month,
# MAGIC   quarter,
# MAGIC   region
# MAGIC )
# MAGIC
# MAGIC select
# MAGIC f.account_region,
# MAGIC f.region,
# MAGIC f.audience_custom_audience_persona,
# MAGIC f.audience,
# MAGIC f.contacts,
# MAGIC f.audience_primary_lead_or_contact_id,
# MAGIC f.fiscal_month_start_date,
# MAGIC f.fiscalYear,
# MAGIC f.fiscal_year_quarter,
# MAGIC f.cal_year_quarter,
# MAGIC f.min_date,
# MAGIC f.month_year_blend,
# MAGIC s.account,
# MAGIC s.advertiser,
# MAGIC s.audience as audience2,
# MAGIC s.month,
# MAGIC s.quarter,
# MAGIC s.region as region2
# MAGIC from funnel f
# MAGIC left join sheet s on f.region = s.region and f.audience=s.audience
