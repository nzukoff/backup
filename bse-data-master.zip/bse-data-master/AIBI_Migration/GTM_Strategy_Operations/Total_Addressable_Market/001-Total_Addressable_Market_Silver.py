# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_silver.total_addressable_market_silver as
# MAGIC
# MAGIC select 
# MAGIC rff.account_region,
# MAGIC rff.audience_custom_audience_persona, 
# MAGIC rff.audience_primary_lead_or_contact_id,
# MAGIC d.fiscal_month_start_date,
# MAGIC d.fiscalYear,
# MAGIC d.fiscal_year_quarter,
# MAGIC d.cal_year_quarter
# MAGIC from main.marketing_lakehouse.rpt_fact_funnel_for_analyst rff
# MAGIC left join main.marketing_lakehouse.dim_date_attributes d 
# MAGIC on d.`date` = rff.`date`
# MAGIC where rff.`date` >= '2024-02-01' 
# MAGIC and rff.`date` <= '2024-07-31'
# MAGIC AND rff.audience_custom_audience_persona != 'Other' and
# MAGIC rff.account_region NOT IN ('Other','Unknown')
# MAGIC group by all
# MAGIC
# MAGIC

# COMMAND ----------


