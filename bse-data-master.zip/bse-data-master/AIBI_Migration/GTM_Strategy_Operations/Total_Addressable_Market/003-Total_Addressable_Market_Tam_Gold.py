# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TABLE main.it_aibi_gold.total_addressable_market_tam_gold as
# MAGIC
# MAGIC SELECT 
# MAGIC     region,
# MAGIC     audience,
# MAGIC     account,
# MAGIC     advertiser,
# MAGIC     quarter,
# MAGIC     month,
# MAGIC     COALESCE(audience_size, 0) AS audience_size,
# MAGIC     COALESCE(reach, 0) AS reach,
# MAGIC     -- Date
# MAGIC     COALESCE(
# MAGIC         to_date(
# MAGIC             CONCAT(month, ' ', 
# MAGIC                 CASE 
# MAGIC                     WHEN month = 'January' THEN CAST(SUBSTR(quarter, 3, 2) AS INT) + 2001
# MAGIC                     ELSE CAST(SUBSTR(quarter, 3, 2) AS INT) + 2000
# MAGIC                 END
# MAGIC             ), 'MMMM yyyy'
# MAGIC         ), '1900-01-01'
# MAGIC     ) AS date,
# MAGIC     -- Extracted Year
# MAGIC     COALESCE(CAST(SUBSTR(quarter, 3, 2) AS INT) + 2000, 0) AS extracted_year,
# MAGIC     -- % of TAM Quarterly
# MAGIC     COALESCE(reach / NULLIF(AVG(audience_size) OVER (PARTITION BY quarter), 0), 0) AS pct_of_tam_quarterly,
# MAGIC     -- BAN % TAM
# MAGIC     COALESCE(SUM(reach) OVER (ORDER BY quarter) / NULLIF(SUM(audience_size) OVER (ORDER BY quarter), 0), 0) AS ban_pct_tam,
# MAGIC     -- BAN DIFF*
# MAGIC     COALESCE(SUM(audience_size) OVER (ORDER BY quarter), 0) - COALESCE(SUM(reach) OVER (ORDER BY quarter), 0) AS ban_diff,
# MAGIC     -- BAN Reach
# MAGIC     COALESCE(SUM(reach) OVER (ORDER BY quarter), 0) AS ban_reach,
# MAGIC     -- BAN TAM
# MAGIC     COALESCE(SUM(audience_size) OVER (ORDER BY quarter), 0) AS ban_tam,
# MAGIC     -- Diff Quarterly
# MAGIC     COALESCE(audience_size, 0) - COALESCE(reach, 0) AS diff_quarterly,
# MAGIC     -- Last = 0
# MAGIC     CASE WHEN ROW_NUMBER() OVER (ORDER BY quarter DESC) = 1 THEN 0 ELSE 1 END AS last_zero,
# MAGIC     -- Quarterly Average TAM
# MAGIC     COALESCE(AVG(audience_size) OVER (PARTITION BY quarter), 0) AS quarterly_average_tam,
# MAGIC     -- Quarterly Reach
# MAGIC     COALESCE(AVG(reach) OVER (PARTITION BY quarter), 0) AS quarterly_reach,
# MAGIC     -- TAM - Global - DL %
# MAGIC     COALESCE(SUM(reach) OVER (ORDER BY quarter) / NULLIF(SUM(audience_size) OVER (), 0), 0) AS tam_global_dl_pct
# MAGIC
# MAGIC FROM main.it_aibi_bronze.quarterly_tam_reach

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------


