# Databricks notebook source
# MAGIC %md
# MAGIC ## Column Metadata Annotation Script
# MAGIC This Databricks notebook automates the process of identifying and populating missing column-level metadata (comments) for tables in a specified catalog and schema. The script pulls existing metadata from the information schema and a metadata registry table, identifies columns with missing or vague descriptions, and uses AI (via `ai_query`) to generate enhanced column descriptions. It then applies these changes directly to the Delta table/view using SQL `ALTER` or `COMMENT ON` statements.
# MAGIC ### Workflow Overview
# MAGIC 1. **Input Widgets**
# MAGIC   - Accepts `catalog_name`, `schema_name`, and optional `table_names`.
# MAGIC 2. **Metadata Extraction**:
# MAGIC   - Fetches column-level metadata from the information schema.
# MAGIC   - Fetches existing metadata from a metadata registry (`team_it_data.bse_metadata_registry`).
# MAGIC 3. **Filter Incomplete Metadata**:
# MAGIC   - Identifies columns with null/empty or placeholder comments.
# MAGIC 4. **Registry Fallback**:
# MAGIC   - Looks up comments for incomplete columns in the metadata registry.
# MAGIC 5. **AI-Powered Description**:
# MAGIC   - For remaining columns, queries an AI model to generate improved descriptions.
# MAGIC 6. **SQL ALTER Execution**:
# MAGIC   - Constructs and executes SQL `ALTER` statements to apply the new descriptions.
# MAGIC 7. **Registry Update**:
# MAGIC   - Merges updates back into the metadata registry for traceability and reuse.
# MAGIC

# COMMAND ----------

# MAGIC %pip install ruamel.yaml
# MAGIC %pip install openpyxl

# COMMAND ----------

import os
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
import yaml
from ruamel.yaml import YAML

from pyspark.sql import DataFrame, Row, functions as F
from pyspark.sql.functions import (
    col,
    collect_list,
    concat,
    current_date,
    current_timestamp,
    date_format,
    isnull,
    lit,
    lower,
    regexp_replace,
    udf,
    when,
)
from pyspark.sql.types import StringType, StructField, StructType

# COMMAND ----------

# MAGIC %md
# MAGIC ### UDFs

# COMMAND ----------

# MAGIC %md
# MAGIC ##### AI Column Definitions

# COMMAND ----------

def aiQuery_column_definitions(tables_df, columns_df, schema_name, catalog_name):
    """
    Generates enhanced column descriptions using AI for all tables/views provided.

    Parameters
    ----------
    tables_df : pd.DataFrame
        DataFrame with table_name and table_type columns.
    columns_df : pd.DataFrame
        DataFrame with table_name and column_name columns.
    schema_name : str
        Schema name used to build ALTER statements.
    catalog_name : str
        Catalog name used to build COMMENT statements.

    Returns
    -------
    pd.DataFrame
        DataFrame with table_name, column_name, description, and ALTER statements.
    """
    import math

    column_level_rows = []
    batch_size = 15  # Number of columns per AI call

    for _, row in tables_df.iterrows():
        table_name = row["table_name"]
        print("Currently processing:", table_name)
        table_type = row["table_type"].upper()
        object_keyword = "TABLE" if (table_type != "VIEW" and table_type != "MATERIALIZED_VIEW") else "VIEW"

        table_cols = columns_df[columns_df["table_name"] == table_name]["column_name"].tolist()
        if not table_cols:
            continue

        # Batch processing to handle long column lists
        for i in range(0, len(table_cols), batch_size):
            col_batch = table_cols[i:i + batch_size]
            col_prompt_input = "\n".join(f"{col}:" for col in col_batch)

            col_prompt = f"""
You are enhancing column descriptions for {object_keyword.lower()} {table_name}.
You MUST generate a description for EVERY column listed below.

DO NOT:
- Invent business meaning
- Add vague boilerplate like "used for analytics", "boolean flag"
- Add examples, commas, apostrophes or PII data
- Add any special characters

DO:
- Improve grammar and clarity
- Keep output factual and concise
- Add [AI Generated] at the end of each
- Not add apostrophes

Return rows as:
column_name | enhanced_description
No headers, no comments.

Input:
{col_prompt_input}
""".strip().replace("'", "''")

            col_sql = f"""
            SELECT ai_query(
                'databricks-claude-3-7-sonnet',
                '{col_prompt}',
                modelParameters => named_struct('max_tokens', 2000, 'temperature', 0.3)
            ) AS enhanced_output
            """
            try:
                col_result = spark.sql(col_sql).collect()[0]["enhanced_output"]
            except Exception as e:
                print(f"AI query failed for {table_name} batch {i//batch_size + 1}: {e}")
                continue

            parsed_lines = [line for line in col_result.split("\n") if "|" in line]
            for line in parsed_lines:
                parts = line.split("|", maxsplit=1)
                if len(parts) == 2:
                    column_name = parts[0].strip()
                    description = parts[1].strip()
                    if column_name and description:
                        column_level_rows.append({
                            "table_name": table_name,
                            "column_name": column_name,
                            "description": description,
                            "object_keyword": object_keyword
                        })

        # === Check if any columns were missed
        generated_columns = {
            row["column_name"] for row in column_level_rows if row["table_name"] == table_name
        }
        missing_columns = set(table_cols) - generated_columns
        if missing_columns:
            print(f"[Warning] Missing definitions for {table_name}: {missing_columns}")

    # Convert to DataFrame
    column_level_df = pd.DataFrame(column_level_rows)

    # Add catalog_name and schema_name columns
    column_level_df["catalog_name"] = catalog_name
    column_level_df["schema_name"] = schema_name

    # Add ALTER statements
    if not column_level_df.empty:
        column_level_df["alter_statement"] = column_level_df.apply(
            lambda row: (
                f"""COMMENT ON COLUMN `{catalog_name}`.`{schema_name}`.`{row['table_name']}`.`{row['column_name']}` IS '{row['description'].replace("'", "''")}'"""
                if row["object_keyword"] == "VIEW" else
                f"""ALTER {row["object_keyword"]} `{catalog_name}`.`{schema_name}`.`{row["table_name"]}` ALTER COLUMN `{row["column_name"]}` COMMENT '{row["description"].replace("'", "''")}'"""
            ), axis=1
        )

        # Drop helper column
        column_level_df.drop(columns=["object_keyword"], inplace=True)

    return column_level_df

# COMMAND ----------

# MAGIC %md
# MAGIC ### Schema and Catalog Inputs

# COMMAND ----------

dbutils.widgets.text("catalog_name", "", "Catalog Name")

# Get the catalog name from the widget
catalog_name = dbutils.widgets.get("catalog_name").lower()
print(catalog_name)

# COMMAND ----------

dbutils.widgets.text("schema_name", "", "Schema Names Val1,Val2")

# Get the schema name from the widget
schema_name = dbutils.widgets.get("schema_name")
print(schema_name)

# COMMAND ----------

dbutils.widgets.text("table_names", "", "Table Names Val1,Val2")

# Get the catalog name from the widget
table_names = dbutils.widgets.get("table_names").lower()
print(table_names)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Column Definition Steps

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1: Store Pre-Metadata from Information Schema and Metadata Registry

# COMMAND ----------

# Convert comma-separated string to clean list
schema_list = [s.strip() for s in schema_name.split(",")]

# Quote each schema name for SQL
formatted_schemas = ", ".join([f"'{s}'" for s in schema_list])

if not table_names:
    
    pre_column_meta = spark.sql(f"""
        SELECT clm.table_catalog, clm.table_schema, clm.table_name, tbl.table_type, clm.column_name, clm.comment
        FROM `{catalog_name}`.information_schema.columns clm
          JOIN `{catalog_name}`.information_schema.tables tbl
            ON tbl.table_schema = clm.table_schema
            AND tbl.table_name = clm.table_name
            AND tbl.table_catalog = clm.table_catalog
        WHERE clm.table_catalog = '{catalog_name}'
          AND clm.table_schema IN ({formatted_schemas})
    """)

    pre_metadata_registry = spark.sql(f"""
            SELECT *
            FROM `{catalog_name}`.team_it_data.bse_metadata_registry
            WHERE table_catalog = '{catalog_name}'
              AND table_schema IN ({formatted_schemas})
    """)

    pre_table_meta = spark.sql(f"""
      SELECT table_schema, table_name, table_type, comment
      FROM `{catalog_name}`.information_schema.tables
      WHERE table_catalog = '{catalog_name}'
        AND table_schema IN ({formatted_schemas})
      """)

else:
    # Convert comma-separated string to clean list
    table_list = [t.strip() for t in table_names.split(",")]

    # Quote each table name for SQL
    formatted_tables = ", ".join([f"'{t}'" for t in table_list])

    # Use the formatted list in SQL query
    pre_column_meta = spark.sql(f"""
        SELECT clm.table_catalog, clm.table_schema, clm.table_name, tbl.table_type, clm.column_name, clm.comment
        FROM `{catalog_name}`.information_schema.columns clm
          JOIN `{catalog_name}`.information_schema.tables tbl
            ON tbl.table_schema = clm.table_schema
            AND tbl.table_name = clm.table_name
            AND tbl.table_catalog = clm.table_catalog
        WHERE clm.table_catalog = '{catalog_name}'
          AND clm.table_schema IN ({formatted_schemas})
          AND clm.table_name IN ({formatted_tables})
    """)

    pre_metadata_registry = spark.sql(f"""
            SELECT *
            FROM `{catalog_name}`.team_it_data.bse_metadata_registry
            WHERE table_catalog = '{catalog_name}'
              AND table_schema IN ({formatted_schemas})
              AND table_name IN ({formatted_tables})
    """)

    pre_table_meta = spark.sql(f"""
      SELECT table_schema, table_name, table_type, comment
      FROM `{catalog_name}`.information_schema.tables
      WHERE table_catalog = '{catalog_name}'
        AND table_schema IN ({formatted_schemas})
        AND table_name IN ({formatted_tables})
      """)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2: Extract NULL column comments from Information Schema

# COMMAND ----------

filtered_pre_column_meta = pre_column_meta.filter(
    isnull(col('comment')) |
    (col('comment') == '') |
    lower(col('comment')).contains('column definition') |
    lower(col('comment')).contains('please refer to go/sfdc-knowledge-base')
)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3: Extract column comments from Metadata Registry for NULL column comments

# COMMAND ----------

# Define the schema
schema = StructType([
    StructField("table_catalog", StringType(), True),
    StructField("table_schema", StringType(), True),
    StructField("table_name", StringType(), True),
    StructField("table_type", StringType(), True),
    StructField("column_name", StringType(), True),
    StructField("column_comment", StringType(), True),
    StructField("alter_statement", StringType(), True)
])
MDR_df = spark.createDataFrame([], schema)

if filtered_pre_column_meta.count() > 0:
    MDR_df = filtered_pre_column_meta.join(
        pre_metadata_registry,
        on=[
            filtered_pre_column_meta.table_schema == pre_metadata_registry.table_schema,
            filtered_pre_column_meta.table_name == pre_metadata_registry.table_name,
            filtered_pre_column_meta.column_name == pre_metadata_registry.column_name
        ],
        how='left'
    ).select(
        filtered_pre_column_meta['*'],
        pre_metadata_registry.column_comment,
        pre_metadata_registry.alter_statement
    )

    # Filter the joined DataFrame to check if column_comment is populated
    MDR_df = MDR_df.filter(~isnull(col('column_comment')) & (col('column_comment') != '')).drop('comment')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4: Generate Column Definitions using AI Query

# COMMAND ----------

# Rename column_comment to comment in MDR_df
renamed_MDR_df = MDR_df.withColumnRenamed("column_comment", "comment")

# Alias the DataFrames
filtered_pre_column_meta_alias = filtered_pre_column_meta.alias("fpcm")
renamed_MDR_df_alias = renamed_MDR_df.alias("rm")

# Perform a left anti join to get rows in filtered_pre_column_meta that are not in renamed_MDR_df
not_in_MDR_df = filtered_pre_column_meta_alias.join(
    renamed_MDR_df_alias,
    on=[
        filtered_pre_column_meta_alias["table_catalog"] == renamed_MDR_df_alias["table_catalog"],
        filtered_pre_column_meta_alias["table_schema"] == renamed_MDR_df_alias["table_schema"],
        filtered_pre_column_meta_alias["table_name"] == renamed_MDR_df_alias["table_name"],
        filtered_pre_column_meta_alias["table_type"] == renamed_MDR_df_alias["table_type"],
        filtered_pre_column_meta_alias["column_name"] == renamed_MDR_df_alias["column_name"]
    ],
    how='left_anti'
).select(
    filtered_pre_column_meta_alias["table_catalog"],
    filtered_pre_column_meta_alias["table_schema"],
    filtered_pre_column_meta_alias["table_name"],
    filtered_pre_column_meta_alias["table_type"],
    filtered_pre_column_meta_alias["column_name"],
    filtered_pre_column_meta_alias["comment"]
)

# COMMAND ----------

col_schema = StructType([
    StructField("table_name", StringType(), True),
    StructField("column_name", StringType(), True),
    StructField("column_comment", StringType(), True),
    StructField("table_catalog", StringType(), True),
    StructField("table_schema", StringType(), True),
    StructField("alter_statement", StringType(), True)
])
column_level_df = spark.createDataFrame([], col_schema)

if not_in_MDR_df.count() > 0:
  # Generate descriptions
  pre_table_meta_pd = pre_table_meta.toPandas()
  not_in_MDR_df_pd = not_in_MDR_df.toPandas()
  column_level_df = aiQuery_column_definitions(pre_table_meta_pd, not_in_MDR_df_pd, schema_name, catalog_name)
  column_level_df = spark.createDataFrame(column_level_df)
  column_level_df = column_level_df.withColumnRenamed("description", "column_comment").withColumnRenamed("catalog_name", "table_catalog").withColumnRenamed("schema_name", "table_schema")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 5: Combine Metadata Registry and AI Query Alter Commands

# COMMAND ----------

# Define the schema
comb_schema = StructType([
    StructField("table_catalog", StringType(), True),
    StructField("table_schema", StringType(), True),
    StructField("table_name", StringType(), True),
    StructField("table_type", StringType(), True),
    StructField("column_name", StringType(), True),
    StructField("column_comment", StringType(), True),
    StructField("alter_statement", StringType(), True)
])

# Check if combined_df exists and has rows
if column_level_df.count() > 0 and MDR_df.count() > 0:
    combined_df = column_level_df.unionByName(MDR_df, allowMissingColumns=True)
elif column_level_df.count() > 0:
    combined_df = column_level_df
elif MDR_df.count() > 0:
    combined_df = MDR_df
else:
    combined_df = spark.createDataFrame([], comb_schema)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 6: Run Alter Commands

# COMMAND ----------

# Initialize a list to store rows with failed ALTER commands
failed_commands = []

# Function to execute ALTER commands and log failures
def execute_alter_commands(df, column_name):
    for row in df.collect():
        alter_command = row[column_name]
        if alter_command:
            try:
                print(alter_command)
                spark.sql(alter_command)
            except Exception as e:
                print(f"Failed to execute: {alter_command}, Error: {e}")
                failed_commands.append(Row(alter_command=alter_command, error=str(e)))
                
if combined_df.count() > 0:
    # Execute ALTER commands based on catalog_name
    execute_alter_commands(combined_df, 'alter_statement')

    # Create a DataFrame from the failed commands
    if failed_commands:
        failed_commands_df = spark.createDataFrame(failed_commands)
        display(failed_commands_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 7: Update Metadata Registry for Columns

# COMMAND ----------

if combined_df.count()>0:
# Add process timestamp to combined_df
    final_combined_df = combined_df.withColumn("process_timestamp", current_timestamp())

    # Select the relevant columns
    final_combined_df = final_combined_df.select(
        "table_catalog", "table_schema", "table_name", "column_name", "column_comment", "alter_statement", "process_timestamp"
    )

    # Create a temporary view for the final_combined_df
    final_combined_df.createOrReplaceTempView("temp_combined_df")

    # Perform the merge operation
    spark.sql(f"""
        MERGE INTO {catalog_name}.team_it_data.bse_metadata_registry AS target
        USING temp_combined_df AS source
        ON target.table_schema = source.table_schema 
        AND target.table_name = source.table_name
        AND target.column_name = source.column_name
        WHEN MATCHED THEN
            UPDATE SET
                target.table_catalog = source.table_catalog,
                target.column_name = source.column_name,
                target.column_comment = source.column_comment,
                target.alter_statement = source.alter_statement,
                target.process_timestamp = source.process_timestamp
        WHEN NOT MATCHED THEN
            INSERT (table_catalog, table_schema, table_name, column_name, column_comment, alter_statement, process_timestamp)
            VALUES (source.table_catalog, source.table_schema, source.table_name, source.column_name, source.column_comment, source.alter_statement, source.process_timestamp)
    """)
