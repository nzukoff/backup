# Databricks notebook source
# MAGIC %python
# MAGIC from typing import Callable, Optional, Sequence
# MAGIC from pyspark.sql import DataFrame
# MAGIC from pyspark.sql.functions import col, lit
# MAGIC from datetime import datetime, date
# MAGIC from dataclasses import dataclass, field

# COMMAND ----------

from dataclasses import dataclass

@dataclass(frozen=True)
class defineconfig:
  name: str
  tgt_db_nm: str
  catalog_nm: str
  pre_tbl_nm: str
  post_tbl_nm: str
  load_type: str
  process_date: str

# COMMAND ----------

dbutils.widgets.dropdown("Environment", "prod", ["dev", "prod"])

# COMMAND ----------

config =  { 

  'prod' : {
    'name' : 'Production',
    'tgt_db_nm': 'it_finance_silver',
    'catalog_nm': 'main',
    'pre_tbl_nm' : 'opp_bookings_ln_dtl_pre',
    'post_tbl_nm' : 'opp_bookings_ln_dtl',
    'load_type' : 'delta',
    'process_date': 'process_date'
  } ,

  'dev' : {
    'name' : 'Production',
    'tgt_db_nm': 'it_finance_silver',
    'catalog_nm': 'integration',
    'pre_tbl_nm' : 'opp_bookings_ln_dtl_pre',
    'post_tbl_nm' : 'opp_bookings_ln_dtl',
    'load_type' : 'delta',
    'process_date': 'process_date'
  } 
}

# COMMAND ----------

ENV = dbutils.widgets.get("Environment") 
#ENV = 'dev'

try:
  setconfig = defineconfig(
                        config[ENV]['name'],
                        config[ENV]['tgt_db_nm'],
                        config[ENV]['catalog_nm'],
                        config[ENV]['pre_tbl_nm'],
                        config[ENV]['post_tbl_nm'],
                        config[ENV]['load_type'],
                        config[ENV]['process_date']
                      )
except Exception as e:
  print(e)
  raise Exception(f'Configurations are not defined for {ENV}')

# COMMAND ----------

name = setconfig.name            
tgt_db_nm = setconfig.tgt_db_nm
catalog_nm = setconfig.catalog_nm
pre_tbl_nm = setconfig.pre_tbl_nm
post_tbl_nm = setconfig.post_tbl_nm
load_type = setconfig.load_type
process_date = setconfig.process_date

# COMMAND ----------

from datetime import datetime, timedelta

def add_audit_attributes(df ):
  """
  Add process date

  """
  now = datetime.utcnow().date()
  
  df2 = (df
    .withColumn(process_date, lit(now))
    )
  
  return (df2, now)
