# Databricks notebook source
# MAGIC %sh
# MAGIC pip install pandas boto3 openpyxl

# COMMAND ----------

from dataclasses import dataclass
from typing import Callable, Optional, Sequence
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit
from datetime import datetime, date
from dataclasses import dataclass, field
from pyspark.sql import functions as F
from pyspark.sql.types import *
import boto3
import os

# COMMAND ----------

dbutils.widgets.dropdown("environment", "dev", ["dev", "prod"])
ENV = dbutils.widgets.get("environment")

if ENV == 'prod':
  target_catalog = 'main'
else:
  target_catalog = 'integration'

# COMMAND ----------

# Amazon S3 Parameters

S3_Secret_Scope = 'anaplan-logfood'
AWS_S3_Access_key = 'anaplan-accesskey'
AWS_S3_Secret_key = 'anaplan-secretskey'

S3_Bucket_Name = 'anaplan-datahub'
S3_Folder_Name = 'Cashflow Bookings Target'
S3_Processed_Folder_Name = 'Processed Cashflow Booking Targets'
S3_Region = 'us-west-2'
full_raw_table_name = f'{target_catalog}.it_finance_silver.cashflow_bookings_targets'

S3_Access_Key = dbutils.secrets.get(scope = S3_Secret_Scope, key = AWS_S3_Access_key)
S3_Secret_Key = dbutils.secrets.get(scope = S3_Secret_Scope, key = AWS_S3_Secret_key)

# COMMAND ----------

def list_of_files(folder) :

  s3 = boto3.resource('s3',aws_access_key_id=S3_Access_Key, aws_secret_access_key=S3_Secret_Key)
  my_bucket = s3.Bucket(S3_Bucket_Name)
  files_in_s3 = [f.key.split(folder + "/")[1] for f in my_bucket.objects.filter(Prefix=folder).all()  ]
  files_in_s3 = [i for i in files_in_s3 if i != '']
  return files_in_s3

# COMMAND ----------

def read_csv_into_df(FilePath) :
  return spark.read.format("csv").\
    option("header","true").\
    load(FilePath)

# COMMAND ----------

def copy_to_archive(S3_Folder_Name, S3_Processed_Folder_Name) :

  s3 = boto3.resource('s3',aws_access_key_id=S3_Access_Key, aws_secret_access_key=S3_Secret_Key)
  my_bucket = s3.Bucket(S3_Bucket_Name)
  todays_date = datetime.today().strftime('%Y-%m-%d')
  files_in_s3 = [f.key.split(S3_Folder_Name + "/")[1] for f in my_bucket.objects.filter(Prefix=S3_Folder_Name).all()  ]
  files_in_s3 = [i for i in files_in_s3 if i != '']
  for filename in files_in_s3 : 
    print ('copying file' + filename )
    copy_source = { 'Bucket': S3_Bucket_Name , 'Key': f'{S3_Folder_Name}/{filename}' }
    new_filename =f'{todays_date}_{filename}'
    target =  f'{S3_Processed_Folder_Name}/{new_filename}'
    my_bucket.copy(copy_source, target)
    print(f'copied over {new_filename} to the folder {S3_Processed_Folder_Name} ')
    print (f'now deleting the original file  {S3_Folder_Name}/{filename}' )
    s3.Object(S3_Bucket_Name, f'{S3_Folder_Name}/{filename}' ).delete()
    print (f'delete successful for {S3_Folder_Name}/{filename}' )

# COMMAND ----------

# List files present on Amazon S3

print("Bucket Name: ", S3_Bucket_Name)
files = list_of_files(S3_Folder_Name)

if not files:
  raise Exception("No file is present in S3 bucket")

elif len(files)>1:
  raise Exception("Multiple files are present in S3 bucket")

else:
  filename = files[0]
  print("File Name: ", filename)

# COMMAND ----------

s3 = boto3.client('s3', region_name=S3_Region)
s3_extract_filepath = f's3a://{S3_Access_Key}:{S3_Secret_Key}@{S3_Bucket_Name}/{S3_Folder_Name}/{filename}'

# df_raw = read_csv_into_df(s3_extract_filepath)
# df_raw.createOrReplaceTempView("raw_data")

# COMMAND ----------

spark.conf.set("fs.s3a.access.key", S3_Access_Key)
spark.conf.set("fs.s3a.secret.key", S3_Secret_Key)

aws_bucket_name = S3_Bucket_Name
aws_region = S3_Region
spark.conf.set("fs.s3a.endpoint", f"s3.{aws_region}.amazonaws.com")

files = dbutils.fs.ls("s3a://" + aws_bucket_name + "/" + S3_Folder_Name + "/" + filename)
file_path = files[0].path

#Add process date and file name
df_raw = spark.read.format("csv").option("header", "true").load(file_path)
df_raw.createOrReplaceTempView("raw_data")

# COMMAND ----------

df_bronze_data = spark.sql('''
                           SELECT Version,	
                                  `Platform Alternate` as Platform, 
                                  CAST(Period as DATE),
                                  Type,	
                                  CAST(Value as DOUBLE), 
                                  current_Date() as process_date
                           FROM raw_data
                           ''')

df_bronze_data.createOrReplaceTempView("bronze_data")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM bronze_data

# COMMAND ----------

print (f'Updating data in {full_raw_table_name} for {filename}')
(df_bronze_data
  .write
  .mode("append")
  .format('delta')
  .option("overwriteSchema", "true")
  .saveAsTable(full_raw_table_name))

# COMMAND ----------

# Move the processed file to Archive folder on Amazon S3

files = list_of_files(S3_Folder_Name)

if len(files) == 0 :
  print('No files to be copied over today')
else :
  print('Monthly file loaded in logFood - now transfering bookings target files to archive on Amazon S3')
  copy_to_archive (S3_Folder_Name, S3_Processed_Folder_Name)

# COMMAND ----------


