# Databricks notebook source
# MAGIC %run "./cashflow_config"

# COMMAND ----------

opp_booking_full_table_name = f'{catalog_nm}.{tgt_db_nm}.opp_bookings_billing'
print(opp_booking_full_table_name)

billings_segment_actuals_full_table_name = f'{catalog_nm}.{tgt_db_nm}.opp_billings_segment_actuals'
print(billings_segment_actuals_full_table_name) 

# COMMAND ----------

# DBTITLE 1,Opportunity Data Segmentation Query
opp_data_breakup  = spark.sql(f'''
                              
select  com.opportunity_id sfdc_opportunity_id ,
        label,
        com.opportunity_name sfdc_opportunity_name ,
        debook,
        case when stage in ('Closed Won', 'Signed') then 'Actual' 
            when stage in ("Prospecting", "Validate", "POC Scoping", "Evaluation", "Proposal", "Negotiation / Procurement") then 'Pipeline'
            else 'other' end as pipeline_or_actual,

        com.account_id sfdc_account_id, 
        com.Billing_Schedule__c billing_schedule ,
        com.primary_quote , 
        com.term_cpq term,

        case when lower(com.manager_forecast) ='best case' then 'Upside' 
            when lower(com.manager_forecast) ='commit' then 'Commit'
            when lower(com.manager_forecast) = 'closed' then 'Closed' 
            else 'Omitted' 
        end as manager_forecast,

        com.account_name sfdc_account_name,
        com.Close_Date opp_close_date ,
        d.fiscal_month,
        d.fy_quarter,
        com.Renewal_Date, 
        com.Renewal_Date_UPD, 
        sum(case when com.label = "Renewal ARR (non PS)" then 0 else  com.TCV__c end) Tcv, 
        max(com.opp_tcv) opp_tcv,
        com.fiscalYear, 
        com.type,
        com.fiscalQtr,
        com.close_month, 
        com.stage,
        com.platform,
        com.Platform_Simplified ,
        com.Business_Unit__c,
        min(com.start_date) start_date,
        sum( case when com.label = "Renewal ARR (non PS)" then com.final_renewal_booking  
                  when com.label = 'Incremental Booking ARR' then com.Incr_booking else 0 end )  Booking_Dollars,
        SUM (CASE 
                WHEN com.Product_Name IN ('MCT Direct Commit', 'Complimentary Usage - MCT', 'MCT Hero Run Support', 'Mosaic Direct Commit', 'MCT Business Support') THEN (com.final_renewal_booking + com.Incr_booking)
                ELSE 0 
            END
            ) MCT_Booking_Dollars,
        Sum(com.final_booking_amount) final_booking_amount

FROM {catalog_nm}.{tgt_db_nm}.opp_bookings_ln_dtl com
    inner join main.it_core_dim.bi_dates d
        on com.Close_Date = d.`date`

WHERE label IN (  'Renewal ARR (non PS)' ,'Incremental Booking ARR') 

and case when com.label = "Renewal ARR (non PS)" then 1 
         when com.label = 'Incremental Booking ARR' and lower(com.manager_forecast) in ('best case' , 'commit' ,'closed') then 1
         else 0 end = 1  

and process_Date = (Select max(process_Date) from  {catalog_nm}.{tgt_db_nm}.opp_bookings_ln_dtl )

GROUP BY all ''')

opp_data_breakup.createOrReplaceTempView('opp_data_breakup_temp')

# COMMAND ----------

# DBTITLE 1,Opportunity Close Date Enrichment
opp_data_breakup_2 = spark.sql('''

WITH CTE AS 
(
  SELECT *,
         TO_DATE(LAST_DAY(CAST(opp_close_date AS DATE)) + INTERVAL 1 DAY) AS opp_close_date_next_month
  FROM opp_data_breakup_temp 
)


SELECT ct.*,
       d.fiscal_month fiscal_month_2,
       d.fy_quarter fiscal_quarter_2
FROM CTE ct 
  LEFT JOIN main.it_core_dim.bi_dates d
        on ct.opp_close_date_next_month = d.`date`

''')

opp_data_breakup_2.createOrReplaceTempView('opp_data_breakup')

# COMMAND ----------

# DBTITLE 1,Invoice Billing Data Aggregator
invoice_billing_pre =spark.sql(f'''
select
      opp_id,
      transaction_type_date as invoice_date,
      netsuite_tranid invoice_number,
      product_family,
      item_displayname,
      min(platform) platform,
      min(quote_id) quote_id,
      min(opp_close_date) opp_close_date,
      sum(transaction_type_amount) as invoice_amount

    from
      main.it_finance_silver.so_installment_billing
    where
      process_date =  ( select max(process_date) from main.it_finance_silver.so_installment_billing)
      and transaction_type = "INVOICE"
      and opp_id is not null 

    group by all ''' ) 

invoice_billing_pre.createOrReplaceTempView('invoice_billing_pre')

# COMMAND ----------

# DBTITLE 1,Monthly Invoice Summary Generator
invoice_billing  = spark.sql('''
                             
select opp_id,
       d.fiscal_month , 
       d.fy_quarter, 
       invoice_number, 
       min(invoice_date) min_invoice_date,
       sum(invoice_amount) month_invoice_amount

from invoice_billing_pre  bill
      inner join main.it_core_dim.bi_dates d
            
            on bill.invoice_date = d.`date`
where lower(product_family) in  ( 'expense', 'license' , 'support' , 'usage' ) 
      and lower(item_displayname) not like '%tax%'

group by all''')

invoice_billing.createOrReplaceTempView('invoice_billing')

# COMMAND ----------

ri_data_pre  = spark.sql('''
select OppId,
       (startDate) startDate ,
       min(reservationorderid) reservationorderid, 
       sum(
           CASE WHEN startDate < '2025-01-01' 
                THEN 1YR_Rev_Share
            ELSE purchasePriceDatabricks 
        END) as 1YR_Rev_Share

from main.it_msft_silver.msft_ri_daily

where processDate = (select max(processDate) from main.it_msft_silver.msft_ri_daily)
    and action != "Cancelled"
    
group by 1,2''' ) 

ri_data_pre.createOrReplaceTempView('ri_data_pre')

# COMMAND ----------

# DBTITLE 1,Revenue Share Aggregation Query
ri_data = spark.sql('''
select distinct
       OppId, 
       d.fiscal_month ,
       d.fy_quarter, 
       min(reservationorderid) reservationorderid, 
       min(startDate) startDate , 
       sum(1YR_Rev_Share) as 1YR_Rev_Share
from ri_data_pre bill
    inner join main.it_core_dim.bi_dates d
        on bill.startDate = d.`date`

group by 1,2,3''') 

ri_data.createOrReplaceTempView('ri_data')

# COMMAND ----------

line_tcv = spark.sql(f''' 
 select Opportunity_Id,
        sum(line_tcv) final_Tcv
 from ( select id, Opportunity_Id, max(TCV__c) line_tcv 
        from {catalog_nm}.{tgt_db_nm}.opp_bookings_ln_dtl 
        where process_date = 
              (select max(process_date) from {catalog_nm}.{tgt_db_nm}.opp_bookings_ln_dtl)
        group by 1,2 ) 
 group by 1 ''')

line_tcv.createOrReplaceTempView('line_tcv')

# COMMAND ----------

billing_segment_data_pre = spark.sql('''

WITH CTE AS (
  select seg.Opportunity__c,
         seg.Invoice_Date__c invoice_date,
         seg.CPQ_Quote__c,
         Billed_By__c,
         product_family__c,
         min(seg.id) segmentid,
         sum(seg.Amount__c) invoice_amount ,

         sum( case when Billed_By__c = 'AWS Marketplace' then (seg.Amount__c - (seg.Amount__c * 1.5/100) )  
                   when Billed_By__c = 'GCP Marketplace' then (seg.Amount__c - (seg.Amount__c * 3/100)  )
                   when Billed_By__c = 'AZURE' then 0
                   else seg.Amount__c end  ) non_azure_invoice_amount_post_mp_fees,

         sum( case when Billed_By__c = 'AZURE' then (seg.Amount__c - (seg.Amount__c * 15/100) )
                  else 0 end  ) azure_invoice_amount_post_mp_fees,
                  
         sum( case when Billed_By__c = 'AWS Marketplace' then (seg.Amount__c - (seg.Amount__c * 1.5/100) )  
                   when Billed_By__c = 'GCP Marketplace' then (seg.Amount__c - (seg.Amount__c * 3/100)  )
                   when Billed_By__c = 'AZURE' then (seg.Amount__c - (seg.Amount__c * 15/100) )
                   else seg.Amount__c end  ) invoice_amount_post_mp_fees

FROM main.sfdc_bronze.billing_segment__c seg
INNER JOIN main.sfdc_bronze.sbqq__quote__c quote
  on seg.CPQ_Quote__c = quote.Id 

where seg.processDate = (Select max(processDate) from main.sfdc_bronze.billing_segment__c  ) 
and quote.processDate = (Select max(processDate) from main.sfdc_bronze.sbqq__quote__c  ) 
and  seg.Opportunity__c is not null
and lower(quote.SBQQ__Primary__c) ='true'
and lower(product_family__c) in  ( 'expense', 'license' , 'support' , 'usage' ) 

GROUP BY ALL
)                                     

SELECT Opportunity__c,
       invoice_date, 
       CPQ_Quote__c,
       Billed_By__c,
       product_family__c,
       segmentid,
       invoice_amount,
       non_azure_invoice_amount_post_mp_fees,
       azure_invoice_amount_post_mp_fees,
       invoice_amount_post_mp_fees
      
FROM CTE

''')

billing_segment_data_pre.createOrReplaceTempView('billing_segment_data_pre')

# COMMAND ----------

billing_segment_inv_upd = spark.sql('''
WITH MIN_INVOICE AS (
        SELECT Opportunity__c, 
              MIN(invoice_date) first_invoice_date
        FROM billing_segment_data_pre
        GROUP BY Opportunity__c
),

CTE AS (
        SELECT 
              bill.*,
              MIN(bill.invoice_date) OVER (PARTITION BY bill.Opportunity__c) as first_invoice_date,
              opp.opp_close_date,
              CASE WHEN (min_inv.first_invoice_date < DATEADD(day, -30, opp.opp_close_date)) 
                        AND opp.pipeline_or_actual = 'Pipeline'
                      THEN datediff(opp.opp_close_date, min_inv.first_invoice_date) 
                    ELSE 0
                END AS Shifted_Days
                
        FROM billing_segment_data_pre bill 
          LEFT JOIN 
                (SELECT DISTINCT sfdc_opportunity_id, opp_close_date, pipeline_or_actual
                FROM opp_data_breakup) opp
            ON bill.Opportunity__c = opp.sfdc_opportunity_id
          LEFT JOIN MIN_INVOICE min_inv
            ON bill.Opportunity__c = min_inv.Opportunity__c
    
),

CTE2 AS (
          SELECT CTE.*,
                CAST(DATEADD(day,  Shifted_Days, invoice_date) as DATE) as new_invoice_date,
                CASE
                    WHEN SUM(CASE WHEN Billed_By__c = 'AZURE' THEN 1 ELSE 0 END) OVER (PARTITION BY Opportunity__c) > 0
                      THEN true
                    ELSE false
                  END as azure_flag,
                  CASE
                    WHEN SUM(CASE WHEN Billed_By__c <> 'AZURE' THEN 1 ELSE 0 END) OVER (PARTITION BY Opportunity__c) > 0
                      THEN true
                    ELSE false
                  END as non_azure_flag

FROM CTE
)

SELECT *
FROM CTE2

''') 

billing_segment_inv_upd = billing_segment_inv_upd.drop('opp_close_date')
billing_segment_inv_upd.createOrReplaceTempView('billing_segment_inv_upd')

# COMMAND ----------

billing_segment_data = spark.sql('''
select Opportunity__c,
       azure_flag,
       non_azure_flag,
       d.fiscal_month,
       d.fy_quarter, 
       min(segmentid) segmentid , 
       min(new_invoice_date) min_invoice_date,
       sum(non_azure_invoice_amount_post_mp_fees) non_azure_invoice_amount_post_mp_fees, 
       sum(azure_invoice_amount_post_mp_fees) azure_invoice_amount_post_mp_fees, 
       sum(invoice_amount_post_mp_fees) invoice_amount_post_mp_fees,
       sum(invoice_amount) invoice_amount 
       
from billing_segment_inv_upd  bill
left join main.it_core_dim.bi_dates d
on bill.new_invoice_date = d.`date`

group by all''') 
billing_segment_data.createOrReplaceTempView('billing_segment_data' )

# COMMAND ----------

opp_data_breakup_with_source  = spark.sql ('''
           
SELECT 
  CASE 
    WHEN netsuite.opp_id IS NOT NULL                                    -- Netsuite Invoice is generated
      AND ri.Oppid IS NOT NULL                                          -- RI is clicked
        THEN 'Netsuite Invoices and RI'

    WHEN netsuite.opp_id IS NOT NULL                                    -- Netsuite Invoice is generated 
      AND ri.Oppid IS NULL                                              -- No RI Click
      AND current_date() <= DATE_ADD(bookings.opp_close_date, 30)       -- Current date is less than Close date + 30 days
      AND billing_seg.azure_flag = true                                 -- SFDC Billing Segment has Azure record
        THEN 'SFDC Billing Segment (Azure) and Netsuite Invoices' 

    WHEN netsuite.opp_id IS NOT NULL                                    -- Netsuite Invoice is generated
      AND ri.Oppid IS NULL                                              -- No RI Click
      AND (current_date() > DATE_ADD(bookings.opp_close_date, 30)       -- Either Current date is greater than Close date + 30 days
        OR billing_seg.azure_flag = false)                              -- OR SFDC Billing Segment doesn't have Azure record
        THEN 'Netsuite Invoices'

    WHEN netsuite.opp_id IS NULL                                        -- No Netsuite Invoice is generated
      AND ri.Oppid IS NOT NULL                                          -- RI is clicked
      AND billing_seg.Opportunity__c is not null                        -- SFDC Billing Segment record is present
        THEN 'SFDC Billing Segment (Non-Azure) and RI'

    WHEN billing_seg.Opportunity__c IS NOT NULL 
      AND current_date() <= DATE_ADD(bookings.opp_close_date, 30)       -- Current date is less than Close date + 30 days
      AND billing_seg.azure_flag = true                                 -- SFDC Billing Segment has Azure record
        THEN 'SFDC Billing Segment (Azure + Non-Azure)'   

    WHEN billing_seg.Opportunity__c IS NOT NULL 
        AND billing_seg.azure_flag = false                              -- SFDC Billing Segment only has Non Azure record
        THEN 'SFDC Billing Segment (Non-Azure)'

    WHEN billing_seg.Opportunity__c IS NOT NULL 
        AND billing_seg.azure_flag = true                               -- SFDC Billing Segment only has Azure record
        AND billing_seg.non_azure_flag = false                              
        THEN 'SFDC Billing Segment (Azure)'

    WHEN ri.Oppid is not null 
        THEN 'RI Only'

    else 'Not Available' 
      
    end as Billing_source,
          *
 
FROM opp_data_breakup bookings

LEFT JOIN (SELECT DISTINCT opp_id from invoice_billing)  netsuite
ON substr(trim(netsuite.opp_id),0,15) = substr(trim(bookings.sfdc_Opportunity_Id) ,0,15)

LEFT JOIN (SELECT DISTINCT Opportunity__c, azure_flag, non_azure_flag from  billing_segment_data ) billing_seg
ON substr(trim(billing_seg.Opportunity__c),0,15) = substr(trim(bookings.sfdc_Opportunity_Id) ,0,15)

LEFT JOIN (Select distinct Oppid from ri_data ) ri
ON  bookings.sfdc_Opportunity_Id = ri.OppId 

''') 


opp_data_breakup_with_source.createOrReplaceTempView('opp_data_breakup_with_source')

# COMMAND ----------

# DBTITLE 1,Opportunity Bookings Billing Analysis
opp_bookings_billing_pre = spark.sql('''

select 
  bookings.Platform,
  bookings.Platform_Simplified ,
  bookings.Sfdc_Account_Id Account_ID,
  bookings.Sfdc_Account_Name Account_Name,
  bookings.Sfdc_Opportunity_Id Opportunity_Id,
  bookings.Sfdc_Opportunity_Name Opportunity_Name,
  bookings.Label,
  bookings.Opp_Close_Date Estimated_Close_Date,
  bookings.renewal_date Renewal_Date,
  bookings.Renewal_Date_UPD,
  case when pipeline_or_actual ='Actual' then bookings.opp_close_date
       when pipeline_or_actual = 'Pipeline' and label = "Renewal ARR (non PS)" then bookings.renewal_date
       when pipeline_or_actual = 'Pipeline' and label = "Incremental Booking ARR" then bookings.opp_close_date
       else bookings.opp_close_date end as Close_Or_Renewal_Date,
       
 date_add(last_day(add_months( case when pipeline_or_actual ='Actual' then bookings.opp_close_date
       when pipeline_or_actual = 'Pipeline' and label = "Renewal ARR (non PS)" then bookings.renewal_date
       when pipeline_or_actual = 'Pipeline' and label = "Incremental Booking ARR" then bookings.opp_close_date
       else bookings.opp_close_date end , -1)),1) Estimated_Close_or_Renewal_Month,

  bookings.stage Opportunity_Stage,
  bookings.Pipeline_Or_Actual,
  bookings.Manager_Forecast,
  bookings.opp_tcv TCV,
  lntcv.final_tcv Final_TCV,
  bookings.term Term,
  bookings.Primary_Quote,
  bookings.Billing_Schedule,
  bookings.Type,
  quote.ApprovalStatus__c as Quote_Approval_Stage,
  bookings.Booking_Dollars Booking_Dollars,
  bookings.MCT_Booking_Dollars MCT_Booking_Dollars,
  bookings.debook Debook_Flag ,
  bookings.Business_Unit__c,
  coalesce(billing.min_invoice_date,billing_seg.min_invoice_date) Min_Invoice_Date,


  CASE 
      WHEN lower(debook) = 'true' 
        THEN 0 

      WHEN Bookings.Billing_Source = 'Netsuite Invoices and RI' 
        THEN coalesce(billing.month_invoice_amount,0) + coalesce(ri.1YR_Rev_Share,0) 

      WHEN Bookings.Billing_Source = 'SFDC Billing Segment (Azure) and Netsuite Invoices' 
        THEN coalesce(billing_seg.azure_invoice_amount_post_mp_fees ,0) + coalesce(billing.month_invoice_amount,0)

      WHEN Bookings.Billing_Source = 'Netsuite Invoices' 
        THEN coalesce(billing.month_invoice_amount,0)

      WHEN Bookings.Billing_Source = 'SFDC Billing Segment (Non-Azure) and RI' 
        THEN coalesce(billing_seg.non_azure_invoice_amount_post_mp_fees ,0) + coalesce(ri.1YR_Rev_Share,0)

      WHEN Bookings.Billing_Source = 'SFDC Billing Segment (Azure + Non-Azure)'
        THEN coalesce(billing_seg.invoice_amount_post_mp_fees ,0)

      WHEN Bookings.Billing_Source = 'SFDC Billing Segment (Azure)' and current_date() <= DATE_ADD(bookings.Opp_Close_Date, 30) 
        THEN coalesce(billing_seg.azure_invoice_amount_post_mp_fees ,0)

      WHEN Bookings.Billing_Source = 'SFDC Billing Segment (Non-Azure)' 
        THEN coalesce(billing_seg.non_azure_invoice_amount_post_mp_fees ,0)

      WHEN Bookings.Billing_Source =  'RI Only' 
        THEN coalesce(ri.1YR_Rev_Share,0) 

      else 0 
  END AS Month1_Billing_Amount,
  
       
       bookings.fiscal_month_2,

  Bookings.Billing_Source,
  ri.1YR_Rev_Share as RI_Purchase
  

From opp_data_breakup_with_source bookings


left join (select opp_id , 
                  fiscal_month,
                  min(min_invoice_date)  min_invoice_date , 
                  sum(month_invoice_amount) month_invoice_amount 
           from  invoice_billing 
           group by 1,2 ) billing
ON substr(trim(billing.opp_id),0,15) = substr(trim(bookings.sfdc_Opportunity_Id) ,0,15)
and bookings.fiscal_month = billing.fiscal_month

left join ( select Opportunity__c,
                   fiscal_month ,
                   min(min_invoice_date)  min_invoice_date, 
                   sum(invoice_amount_post_mp_fees)   invoice_amount_post_mp_fees  ,
                   sum(azure_invoice_amount_post_mp_fees) azure_invoice_amount_post_mp_fees,
                   sum(non_azure_invoice_amount_post_mp_fees) non_azure_invoice_amount_post_mp_fees
            from  billing_segment_data group by all ) billing_seg
ON substr(trim(billing_seg.Opportunity__c),0,15) = substr(trim(bookings.sfdc_Opportunity_Id) ,0,15)
and billing_seg.fiscal_month = bookings.fiscal_month

left join (select OppId , 
                  fiscal_month ,
                  sum(1YR_Rev_Share) 1YR_Rev_Share 
                  from  ri_data group by 1,2 ) ri
on bookings.sfdc_Opportunity_Id = ri.OppId
and ri.fiscal_month = bookings.fiscal_month

left join main.sfdc_bronze.sbqq__quote__c	quote
on quote.Id = bookings.primary_quote
and quote.processDate = (select max(processDate) from main.sfdc_bronze.sbqq__quote__c )

left join line_tcv lntcv
on lntcv.Opportunity_Id = bookings.sfdc_opportunity_id


''') 

opp_bookings_billing_pre.createOrReplaceTempView('opp_bookings_billing_pre')

# COMMAND ----------

# DBTITLE 1,Audit Attributes Addition Functionality
opp_bookings_billing, processDate = add_audit_attributes(opp_bookings_billing_pre)

# COMMAND ----------

# DBTITLE 1,Delta Table Overwrite Manager
date_str = processDate.strftime('%Y-%m-%d')

print (f'Updating data in {opp_booking_full_table_name} for {processDate}')
(opp_bookings_billing
  .write
  .mode('overwrite')
  .format('delta')
  #.option('overwriteSchema', 'true')
  .option("mergeSchema", "true")
  .option('replaceWhere', f"process_date = '{date_str}'")
  .partitionBy("process_date")
  .saveAsTable(opp_booking_full_table_name))

# COMMAND ----------

# DBTITLE 1,Billing Segments Data Union
opportunities_pre =spark.sql(f'''
SELECT 
      opportunity__c Opportunity_Id,
      coalesce(opp.platform, 
            case when upper(Billed_By__c) like '%AWS%' then 'AWS' 
                  when upper(Billed_By__c) like '%GCP%' then 'Google Cloud'  
                  when upper(Billed_By__c) like '%AZURE%' then 'Azure' 
      else 'OTHER' end )  
            Platform,
      product_family__c Product_family,
      debook Debook_Flag,
      segmentid Trans_Id,
      invoice_date Trans_Date,
      Shifted_Days, 
      new_invoice_date as New_Trans_Date,
      CPQ_Quote__c Quote_Id,
      Invoice_Amount Trans_Amount,
      Invoice_Amount_Post_mp_Fees Final_Trans_Amount,
      'Billing_Segment' as Type
FROM billing_segment_inv_upd pre
Left JOIN ( select Opportunity_Id,debook, min(Platform) Platform from {catalog_nm}.{tgt_db_nm}.opp_bookings_ln_dtl  group by 1 ,2)  opp
on pre.opportunity__c = opp.Opportunity_Id

UNION 

 SELECT
      Opp_id Opportunity_Id,
      coalesce(opp.platform , pre.platform) Platform,
      Product_Family,
      debook Debook_Flag ,
      invoice_number as Trans_id,
      invoice_date as Trans_date,
      0 Shifted_Days, 
      invoice_date as New_Trans_Date,
      Quote_Id,
      invoice_amount Trans_Amount , 
      Invoice_amount Final_Trans_Amount , 
      'Actuals' as Type  
From invoice_billing_pre pre

Left join ( select Opportunity_Id,debook, min(Platform) Platform from {catalog_nm}.{tgt_db_nm}.opp_bookings_ln_dtl   group by 1,2 ) opp
      on pre.opp_id = opp.Opportunity_Id



UNION 

select 
      oppId AS Opportunity_Id,
      'Azure' as Platform,
      null as Product_Family ,
      debook Debook_Flag ,
      reservationorderid as Trans_id,
      startdate as Trans_Date,
      0 Shifted_Days, 
      startdate as New_Trans_Date,
      null as Quote_Id,
      `1YR_Rev_Share` as  Trans_Amount , 
      `1YR_Rev_Share` as  Final_Trans_Amount , 
      'RI Purchase' as Type  

 from ri_data_pre pre

 Left join ( select Opportunity_Id,min(debook) debook  from {catalog_nm}.{tgt_db_nm}.opp_bookings_ln_dtl  group by 1 ) opp
      on pre.oppId = opp.Opportunity_Id ''')


opportunities_pre.createOrReplaceTempView('opportunities_pre')

# COMMAND ----------

opportunities_actuals, processDate = add_audit_attributes(opportunities_pre)

# COMMAND ----------

# DBTITLE 1,Delta Table Overwrite Script
date_str = processDate.strftime('%Y-%m-%d')

print (f'Updating data in {billings_segment_actuals_full_table_name} for {processDate}')
(opportunities_actuals
  .write
  .mode('overwrite')
  .format('delta')
  #.option('overwriteSchema', 'true')
  .option("mergeSchema", "true")
  .option('replaceWhere', f"process_date = '{date_str}'")
  .partitionBy("process_date")
  .saveAsTable(billings_segment_actuals_full_table_name))

# COMMAND ----------


