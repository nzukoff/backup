# Databricks notebook source
from datetime import date
from urllib.parse import quote as urlencode
import pandas as pd
from io import StringIO

# COMMAND ----------

dbutils.widgets.text(label='Source Catalog', name='logFood_source_catalog', defaultValue='')
dbutils.widgets.text(label='Source Schema', name='logFood_source_schema', defaultValue='')
dbutils.widgets.text(label='Source Table', name='logFood_source_table', defaultValue='')
dbutils.widgets.text(label='Source Process Date', name='logFood_process_date', defaultValue='')

dbutils.widgets.text(label='S3 Secrets Scope', name='S3_Scope', defaultValue='')
dbutils.widgets.text(label='S3 Access Key', name='S3_Access_key', defaultValue='')
dbutils.widgets.text(label='S3 Secret Key', name='S3_Secret_key', defaultValue='')

dbutils.widgets.text(label='S3 Bucket Name', name='S3_Bucket_Name', defaultValue='')
dbutils.widgets.text(label='S3 Folder Name', name='S3_Folder_Name', defaultValue='')
dbutils.widgets.text(label='S3 Region', name='S3_Region', defaultValue='')
dbutils.widgets.text(label='S3 File Name', name='S3_File_Name', defaultValue='')

# COMMAND ----------

#LogFood Parameters
LogFood_Source_Catalog = dbutils.widgets.get("logFood_source_catalog")
LogFood_Source_Schema = dbutils.widgets.get("logFood_source_schema")
LogFood_Source_Table = dbutils.widgets.get("logFood_source_table")
LogFood_Process_Date = dbutils.widgets.get("logFood_process_date")

#Amazon S3 Parameters
S3_Secret_Scope = dbutils.widgets.get("S3_Scope")
AWS_S3_Access_key = dbutils.widgets.get("S3_Access_key")
AWS_S3_Secret_key = dbutils.widgets.get("S3_Secret_key")

S3_Access_Key = dbutils.secrets.get(scope = S3_Secret_Scope, key = AWS_S3_Access_key)
S3_Secret_Key = dbutils.secrets.get(scope = S3_Secret_Scope, key = AWS_S3_Secret_key)

S3_Bucket_Name = dbutils.widgets.get("S3_Bucket_Name")
S3_Folder_Name = dbutils.widgets.get("S3_Folder_Name")
S3_Region = dbutils.widgets.get("S3_Region")
S3_File_Name = dbutils.widgets.get("S3_File_Name")

# COMMAND ----------

#Extract Latest Process Date for the LogFood Table

latestProcessDate = spark.sql (f'''
                               SELECT max({LogFood_Process_Date}) 
                               FROM {LogFood_Source_Catalog}.{LogFood_Source_Schema}.{LogFood_Source_Table}''').collect()[0][0]

latestProcessDate = latestProcessDate.strftime('%Y-%m-%d')
latestProcessDate

# COMMAND ----------

def get_data_from_query(query):
  data_pandas_df = pd.DataFrame()
  try:
    data_pandas_df = spark.sql(query).toPandas()
  except:
    pass
  return data_pandas_df

# COMMAND ----------

df_LogFood = f''' 
                SELECT *
                FROM {LogFood_Source_Catalog}.{LogFood_Source_Schema}.{LogFood_Source_Table}
                WHERE {LogFood_Process_Date} = '{latestProcessDate}' 
              '''     
df_LogFood_pd = get_data_from_query(df_LogFood)

# COMMAND ----------

import boto3
s3_resource = boto3.client("s3",
                  region_name=S3_Region,
                  aws_access_key_id=S3_Access_Key,
                  aws_secret_access_key=S3_Secret_Key)

csv_buf = StringIO()

df_LogFood_pd.to_csv(csv_buf, header=True, index=False)
csv_buf.seek(0)
target_path = f'''{S3_Folder_Name}/{S3_File_Name}.csv'''
res = s3_resource.put_object(Bucket=S3_Bucket_Name, Body=csv_buf.getvalue(), Key= target_path)
