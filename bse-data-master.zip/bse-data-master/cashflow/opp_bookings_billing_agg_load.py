# Databricks notebook source
# DBTITLE 1,Cashflow Configuration Loader
# MAGIC %run "./cashflow_config"

# COMMAND ----------

full_table_name = f'{catalog_nm}.{tgt_db_nm}.opp_bookings_billing_agg'
print(full_table_name)

# COMMAND ----------

# DBTITLE 1,Latest Bookings Zero Filter
opp_bookings_zero_filtering = spark.sql(f'''
                                        
SELECT * 
FROM {catalog_nm}.{tgt_db_nm}.opp_bookings_billing 
WHERE Booking_dollars >0 
AND process_date = (SELECT max(process_Date) FROM {catalog_nm}.{tgt_db_nm}.opp_bookings_billing  )

UNION

SELECT * 
FROM {catalog_nm}.{tgt_db_nm}.opp_bookings_billing
WHERE Booking_dollars <= 0  
AND process_date = (SELECT max(process_Date) FROM {catalog_nm}.{tgt_db_nm}.opp_bookings_billing)  
AND Opportunity_Id NOT IN ( SELECT Opportunity_Id 
                            FROM {catalog_nm}.{tgt_db_nm}.opp_bookings_billing 
                            WHERE Booking_dollars >0 
                            AND process_date = (SELECT max(process_Date) FROM {catalog_nm}.{tgt_db_nm}.opp_bookings_billing  ))
                            
qualify row_number() OVER (PARTITION BY Opportunity_Id ORDER BY label DESC )  = 1 ''')

opp_bookings_zero_filtering.createOrReplaceTempView('opp_bookings_zero_filtering')

# COMMAND ----------

opp_with_both_renewal_and_inc = spark.sql('''
                                          
SELECT Opportunity_Id 
from opp_bookings_zero_filtering 
GROUP BY 1 
HAVING count(*) >1 ''')

opp_with_both_renewal_and_inc.createOrReplaceTempView('opp_with_both_renewal_and_inc')

# COMMAND ----------

# DBTITLE 1,Opportunity Bookings Dataset Query
final_opp_bookings_dataset = spark.sql( ''' 
                              SELECT 
                                    Platform	,
                                    Platform_Simplified ,
                                    Account_ID	,
                                    Account_Name	,
                                    Opportunity_Id	,
                                    Opportunity_Name	,
                                    label	,
                                    estimated_close_date	,
                                    renewal_date	,
                                    Renewal_Date_UPD, 
                                    coalesce(close_or_renewal_date, estimated_close_date) close_or_renewal_date	,
                                    estimated_close_or_renewal_month	,
                                    Opportunity_stage	,
                                    pipeline_or_actual	,
                                    manager_forecast	,
                                    TCV	,
                                    Final_TCV	,
                                    term	,
                                    primary_quote	,
                                    billing_schedule	,
                                    type	,
                                    Quote_Approval_Stage	,
                                    Booking_dollars	,
                                    MCT_Booking_Dollars ,
                                    debook_flag,
                                    Min_invoice_date	,
                                    Month1_Billing_amount	,
                                    Billing_Source,
                                    ri_purchase	,
                                    Business_Unit__c

                                  From
                                    opp_bookings_zero_filtering book

                                  where not exists (select 1 from opp_with_both_renewal_and_inc du where du.Opportunity_Id = book.Opportunity_Id)

                              UNION 

                                select 
                                    Platform	,
                                    Platform_Simplified ,
                                    Account_ID	,
                                    Account_Name	,
                                    Opportunity_Id	,
                                    Opportunity_Name	,
                                    label	,
                                    estimated_close_date	,
                                    renewal_date	,
                                    Renewal_Date_UPD ,
                                    coalesce( estimated_close_date,renewal_date) as close_or_renewal_date	,
                                    estimated_close_or_renewal_month	,
                                    Opportunity_stage	,
                                    pipeline_or_actual	,
                                    manager_forecast	,
                                    TCV	,
                                    Final_TCV	,
                                    term	,
                                    primary_quote	,
                                    billing_schedule	,
                                    type	,
                                    Quote_Approval_Stage	,
                                    Booking_dollars	,
                                    MCT_Booking_Dollars ,
                                    debook_flag,
                                    Min_invoice_date	,
                                    Month1_Billing_amount	,
                                    Billing_Source,
                                    ri_purchase,
                                    Business_Unit__c	

                                  From
                                    opp_bookings_zero_filtering book

                                  where  exists (select 1 from opp_with_both_renewal_and_inc du where du.Opportunity_Id = book.Opportunity_Id) ''')

final_opp_bookings_dataset.createOrReplaceTempView('final_opp_bookings_dataset')


# COMMAND ----------

# DBTITLE 1,Opportunity Billing Aggregation Preprocess
opp_bookings_billing_agg_pre  = spark.sql(''' 
select 
  bookings.Platform,
  bookings.Platform_Simplified ,
  bookings.Account_ID,
  bookings.Account_Name,
  bookings.Opportunity_Id,
  bookings.Opportunity_Name,
  d.fy_quarter,
  d.fiscal_month,
  d.fiscal_quarter_end_date,
  bookings.estimated_close_date,
  bookings.renewal_date,
  bookings.Renewal_Date_UPD,
  bookings.close_or_renewal_date,
  date_add(last_day(add_months( bookings.close_or_renewal_date , -1)),1) estimated_close_or_renewal_month,
  bookings.Opportunity_stage,
  bookings.pipeline_or_actual,
  bookings.manager_forecast,
  bookings.TCV,
  bookings.Final_TCV,
  bookings.term,
  bookings.primary_quote,
  bookings.billing_schedule,
  bookings.type,
  bookings.Quote_Approval_Stage,
  bookings.min_invoice_date ,
  bookings.Month1_Billing_amount,
  bookings.Billing_Source,
  bookings.ri_purchase  as ri_purchase,
  sum(case when label = 'Incremental Booking ARR' then Booking_Dollars else 0 end ) as Incremental_Dollars,
  sum(case when label = 'Renewal ARR (non PS)' then Booking_Dollars else 0 end ) as Renewal_Dollars,
  SUM(bookings.Booking_Dollars) Booking_dollars,
  SUM(bookings.MCT_Booking_Dollars) MCT_Booking_Dollars ,
  debook_flag,
  Business_Unit__c

FROM final_opp_bookings_dataset bookings
INNER JOIN main.it_core_dim.bi_dates d
  ON bookings.close_or_renewal_date = d.`date`

GROUP BY all''' )

opp_bookings_billing_agg_pre.createOrReplaceTempView('opp_bookings_billing_agg_pre')


# COMMAND ----------

# DBTITLE 1,Opportunity Billings Aggregation Report
opp_bookings_billing_agg_final =spark.sql(''' 
  SELECT 
  bookings.Platform,
  bookings.Platform_Simplified ,
  bookings.Account_ID,
  bookings.Account_Name,
  bookings.Opportunity_Id,
  bookings.Opportunity_Name,
  bookings.Fy_Quarter,
  bookings.Fiscal_Month,
  bookings.Fiscal_Quarter_End_Date,
  bookings.Estimated_Close_Date,
  bookings.Renewal_Date,
  bookings.Renewal_Date_UPD,
  bookings.Close_Or_Renewal_Date,
  bookings.Estimated_Close_Or_Renewal_Month,
  bookings.Opportunity_Stage,
  bookings.Pipeline_Or_Actual,
  bookings.Manager_Forecast,
  bookings.TCV,
  bookings.Final_TCV,
  bookings.Term,
  bookings.Primary_Quote,
  bookings.Billing_Schedule,
  bookings.Type,
  bookings.Quote_Approval_Stage,
  bookings.Min_Invoice_Date ,
  bookings.Month1_Billing_Amount,
  bookings.Billing_Source,
  bookings.ri_purchase  as Ri_Purchase,
  Incremental_Dollars,
  Renewal_Dollars,
  Booking_Dollars,
  MCT_Booking_Dollars,
  Debook_Flag,
  Business_Unit__c,
  SUM(case when lower(debook_flag) = 'true' then 0 
           when bookings.Platform = 'Azure' and bookings.Billing_Schedule = '100% upfront' and bookings.Term>12 then bookings.Booking_Dollars
           when bookings.Billing_Source  = 'Not Available'  and bookings.Platform = 'Azure' then 0 
           when bookings.Billing_Source  = 'Not Available' and bookings.Platform <> 'Azure' then  bookings.Booking_Dollars
           else bookings.Month1_Billing_amount end) 
  as Bookings_Billed_Upfront_Month_1,
        
  SUM(case when lower(debook_flag) = 'true' then 0 
           when bookings.Billing_Source  = 'Not Available'  and bookings.Platform = 'Azure' then bookings.Booking_Dollars 
           when bookings.Billing_Source  = 'Not Available'  and bookings.Platform <> 'Azure' then  0
           else Booking_dollars - bookings.Month1_Billing_amount end) 
  as Bookings_Billed_Non_Upfront
  
FROM opp_bookings_billing_agg_pre bookings
GROUP BY all

''')

opp_bookings_billing_agg_final = opp_bookings_billing_agg_final.drop('Billing_Schedule')
opp_bookings_billing_agg_final.createOrReplaceTempView('opp_bookings_billing_agg_final')

# COMMAND ----------

# DBTITLE 1,Opportunity Billing Aggregation Update
opp_bookings_billing_agg_prior_close = spark.sql('''
WITH CTE AS (
SELECT 
    opp.Opportunity_Id,
    CASE 
        WHEN opp.Billing_Source = 'Not Available' AND opp.Platform != 'Azure' THEN prior_closed_deal 
        ELSE NULL 
    END AS prior_closed_deal
FROM  
    opp_bookings_billing_agg_final opp 
LEFT JOIN  
    (SELECT SBQQ__RenewalOpportunity__c, 
            MAX(SBQQ__Opportunity__c) AS prior_closed_deal -- This is done since 1 SBQQ__RenewalOpportunity__c can be mapped to multiple SBQQ__Opportunity__c but here we just need values for Billing_Source = 'Not Available' AND Platform != 'Azure' that doesn't have duplicates
     FROM main.sfdc_bronze.contract cnt
     WHERE cnt.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.contract)
     GROUP BY SBQQ__RenewalOpportunity__c) cnt_agg
ON opp.Opportunity_Id = cnt_agg.SBQQ__RenewalOpportunity__c
),

CTE2 AS (
SELECT ct.Opportunity_Id,
       ct.prior_closed_deal,
       opp_final.Bookings_Billed_Upfront_Month_1 as prior_closed_deal_bookings_billed_upfront,
       opp_final.Booking_Dollars as prior_closed_deal_booking_dollars
FROM opp_bookings_billing_agg_final opp_final 
  LEFT JOIN CTE ct
    ON ct.prior_closed_deal = opp_final.Opportunity_Id)

SELECT 
    opp_final_2.*,
    ct2.prior_closed_deal,

    CASE 
      WHEN (prior_closed_deal_booking_dollars IS NOT NULL OR prior_closed_deal_booking_dollars != '0')
          THEN (prior_closed_deal_bookings_billed_upfront/prior_closed_deal_booking_dollars)
        ELSE NULL
    END AS prior_closed_deal_ratio,

    CASE 
        WHEN opp_final_2.Billing_Source = 'Not Available' 
            AND opp_final_2.Platform <> 'Azure' 
            AND (prior_closed_deal_booking_dollars IS NOT NULL OR prior_closed_deal_booking_dollars != '0')
          THEN (prior_closed_deal_bookings_billed_upfront/prior_closed_deal_booking_dollars) * opp_final_2.Booking_Dollars

        WHEN opp_final_2.Billing_Source = 'Not Available' 
            AND opp_final_2.Platform <> 'Azure' 
            AND (prior_closed_deal_booking_dollars IS NULL OR prior_closed_deal_booking_dollars = '0')
          THEN opp_final_2.Booking_Dollars 

        ELSE Bookings_Billed_Upfront_Month_1 
    END AS Bookings_Billed_Upfront_UPD

FROM opp_bookings_billing_agg_final opp_final_2 
  LEFT JOIN CTE2 ct2
    ON opp_final_2.Opportunity_Id = ct2.Opportunity_Id

''')

opp_bookings_billing_agg_prior_close = opp_bookings_billing_agg_prior_close.drop("Bookings_Billed_Upfront_Month_1")
opp_bookings_billing_agg_prior_close = opp_bookings_billing_agg_prior_close.withColumnRenamed("Bookings_Billed_Upfront_UPD","Bookings_Billed_Upfront_Month_1")
opp_bookings_billing_agg_prior_close.createOrReplaceTempView("opp_bookings_billing_agg_prior_close")

# COMMAND ----------

# DBTITLE 1,Spark Invoice Aggregation Routine
invoice_billing_pre =spark.sql(f'''
    WITH CTE AS (
    select
      opp_id,
      transaction_type_date as invoice_date,
      netsuite_tranid invoice_number,
      product_family,
      item_displayname,
      min(platform) platform,
      min(quote_id) quote_id,
      min(opp_close_date) opp_close_date,
      sum(transaction_type_amount) as invoice_amount

    from
      main.it_finance_silver.so_installment_billing
    where
      process_date =  ( select max(process_date) from main.it_finance_silver.so_installment_billing)
      and transaction_type = "INVOICE"
      and opp_id is not null 

    group by all )
    
select opp_id, 
       invoice_number, 
       min(invoice_date) invoice_date,
       sum(invoice_amount) month_invoice_amount

from CTE bill

where lower(product_family) in  ( 'expense', 'license' , 'support' , 'usage' ) 
      and lower(item_displayname) not like '%tax%'

group by all
    
    ''' ) 

invoice_billing_pre.createOrReplaceTempView('invoice_billing')

# COMMAND ----------

# DBTITLE 1,Reservation Revenue Summary Query
ri_data_pre  = spark.sql('''
select OppId,
       (startDate) startDate ,
       min(reservationorderid) reservationorderid, 
       sum(
           CASE WHEN startDate < '2025-01-01' 
                THEN 1YR_Rev_Share
            ELSE purchasePriceDatabricks 
        END) as 1YR_Rev_Share

from main.it_msft_silver.msft_ri_daily

where processDate = (select max(processDate) from main.it_msft_silver.msft_ri_daily)
    and action != "Cancelled"
    
group by 1,2''' ) 

ri_data_pre.createOrReplaceTempView('ri_data')

# COMMAND ----------

# DBTITLE 1,Marketplace Billing Data Aggregator
billing_segment_data = spark.sql('''
                                 
WITH billing_segment_data_pre AS (
  SELECT seg.Opportunity__c,
          seg.Invoice_Date__c invoice_date,
          seg.CPQ_Quote__c,
          product_family__c ,
          min(seg.id) segmentid, 
          sum(seg.Amount__c) invoice_amount ,
          min(Billed_By__c)Billed_By__c,

          sum( case when Billed_By__c = 'AWS Marketplace' then (seg.Amount__c - (seg.Amount__c * 1.5/100) )  
                    when Billed_By__c = 'GCP Marketplace' then (seg.Amount__c - (seg.Amount__c * 3/100)  )
                    when Billed_By__c = 'AZURE' then 0
                    else seg.Amount__c end  ) non_azure_invoice_amount_post_mp_fees,

          sum( case when Billed_By__c = 'AZURE' then (seg.Amount__c - (seg.Amount__c * 15/100) )
                    else 0 end  ) azure_invoice_amount_post_mp_fees,

          sum( case when Billed_By__c = 'AWS Marketplace' then (seg.Amount__c - (seg.Amount__c * 1.5/100) )  
                    when Billed_By__c = 'GCP Marketplace' then (seg.Amount__c - (seg.Amount__c * 3/100)  )
                    when Billed_By__c = 'AZURE' then (seg.Amount__c - (seg.Amount__c * 15/100) )
                    else seg.Amount__c end  ) invoice_amount_post_mp_fees

  FROM main.sfdc_bronze.billing_segment__c seg
  INNER JOIN main.sfdc_bronze.sbqq__quote__c quote
  on seg.CPQ_Quote__c = quote.Id   

  where seg.processDate = (Select max(processDate) from main.sfdc_bronze.billing_segment__c  ) 
    and quote.processDate = (Select max(processDate) from main.sfdc_bronze.sbqq__quote__c  ) 
    and  seg.Opportunity__c is not null
    and lower(quote.SBQQ__Primary__c) ='true'
    and lower(product_family__c) in  ( 'expense', 'license' , 'support' , 'usage' ) 

  GROUP BY ALL
  ),

  MIN_INVOICE AS (
          SELECT Opportunity__c, 
                MIN(invoice_date) first_invoice_date
          FROM billing_segment_data_pre
          GROUP BY Opportunity__c
  ),

  CTE AS (
          SELECT 
                bill.*,
                MIN(bill.invoice_date) OVER (PARTITION BY bill.Opportunity__c) as first_invoice_date,
                opp.Close_Or_Renewal_Date,
                CASE WHEN (min_inv.first_invoice_date < DATEADD(day, -30, opp.Close_Or_Renewal_Date)) 
                          AND opp.Pipeline_Or_Actual = 'Pipeline'
                        THEN datediff(opp.Close_Or_Renewal_Date, min_inv.first_invoice_date) 
                      ELSE 0
                  END AS Shifted_Days
                  
          FROM billing_segment_data_pre bill 
            LEFT JOIN 
                  (SELECT DISTINCT Opportunity_Id, Close_Or_Renewal_Date, Pipeline_Or_Actual
                  FROM opp_bookings_billing_agg_prior_close) opp
              ON bill.Opportunity__c = opp.Opportunity_Id
            LEFT JOIN MIN_INVOICE min_inv
              ON bill.Opportunity__c = min_inv.Opportunity__c
      
  ),

  CTE2 AS (
            SELECT CTE.*,
                  CAST(DATEADD(day,  Shifted_Days, invoice_date) as DATE) as new_invoice_date
  FROM CTE)

  SELECT *
  FROM CTE2
                                 
''')
  
billing_segment_data.createOrReplaceTempView('billing_segment_data' )

# COMMAND ----------

# DBTITLE 1,Opportunity Billing Summary Query
df_amount_billed_30_days = spark.sql(f'''

WITH Opportunity AS (
  SELECT opp.Opportunity_Id, 
        opp.Billing_Source,
        opp.Close_Or_Renewal_Date,
        CAST(DATEADD(DAY, 30, opp.Close_Or_Renewal_Date) as DATE) AS Close_or_Renewal_Date_plus_30,
        CAST(DATEADD(DAY, -30, opp.Close_Or_Renewal_Date) as DATE) AS Close_or_Renewal_Date_minus_30
  FROM opp_bookings_billing_agg_prior_close opp
),

Opportunity_Invoice AS (
  SELECT opp.Opportunity_Id,
         opp.Billing_Source,
         opp.Close_Or_Renewal_Date,
         opp.Close_or_Renewal_Date_minus_30,
         opp.Close_or_Renewal_Date_plus_30,
         COALESCE(SUM(netsuite.month_invoice_amount), 0) as Total_Invoice_Amount
         
  FROM Opportunity opp LEFT JOIN invoice_billing netsuite
    ON (opp.Opportunity_Id = netsuite.opp_id 
      AND netsuite.invoice_date BETWEEN opp.Close_or_Renewal_Date_minus_30 AND opp.Close_or_Renewal_Date_plus_30)
  GROUP BY ALL
),

Opportunity_RI AS (
  SELECT opp.Opportunity_Id,
         opp.Billing_Source,
         opp.Close_Or_Renewal_Date,
         opp.Close_or_Renewal_Date_minus_30,
         opp.Close_or_Renewal_Date_plus_30,
         COALESCE(SUM(ri.1YR_Rev_Share), 0) Total_RI_Amount
         
  FROM Opportunity opp LEFT JOIN ri_data ri 
     ON (opp.Opportunity_Id = ri.OppId 
       AND ri.startDate BETWEEN opp.Close_or_Renewal_Date_minus_30 AND opp.Close_or_Renewal_Date_plus_30)
  GROUP BY ALL
),

Opportunity_Billing AS (
  SELECT opp.Opportunity_Id,
         opp.Billing_Source,
         opp.Close_Or_Renewal_Date,
         opp.Close_or_Renewal_Date_minus_30,
         opp.Close_or_Renewal_Date_plus_30,

         COALESCE(SUM(
              CASE 
                WHEN (opp.Billing_Source = 'SFDC Billing Segment (Azure) and Netsuite Invoices' 
                  OR opp.Billing_Source = 'SFDC Billing Segment (Azure)')
                  AND current_date() <= DATE_ADD(opp.Close_Or_Renewal_Date, 30)
                    THEN billing.azure_invoice_amount_post_mp_fees 

                WHEN opp.Billing_Source = 'SFDC Billing Segment (Azure + Non-Azure)'
                    THEN billing.invoice_amount_post_mp_fees

                WHEN opp.Billing_Source = 'SFDC Billing Segment (Non-Azure) and RI' 
                  OR opp.Billing_Source = 'SFDC Billing Segment (Non-Azure)'
                    THEN billing.non_azure_invoice_amount_post_mp_fees
                    
                ELSE 0
              END 
         ), 0) AS Total_Billing_Amount
         
  FROM Opportunity opp LEFT JOIN billing_segment_data billing 
    ON (opp.Opportunity_Id = billing.Opportunity__c 
      AND billing.new_invoice_date BETWEEN opp.Close_or_Renewal_Date_minus_30 AND opp.Close_or_Renewal_Date_plus_30)
  GROUP BY ALL
)

SELECT 
      op.Opportunity_Id,
      op.Billing_Source,
      op.Close_Or_Renewal_Date,
      op.Close_or_Renewal_Date_minus_30,
      op.Close_or_Renewal_Date_plus_30,
      CASE
        WHEN op.Billing_Source = 'SFDC Billing Segment (Azure + Non-Azure)'
          OR  op.Billing_Source = 'SFDC Billing Segment (Azure)'
          OR  op.Billing_Source = 'SFDC Billing Segment (Non-Azure)'
          THEN Ob.Total_Billing_Amount
        WHEN op.Billing_Source = 'Netsuite Invoices'
          THEN Oi.Total_Invoice_Amount
        WHEN op.Billing_Source = 'RI Only'
          THEN Ori.Total_RI_Amount
        WHEN op.Billing_Source = 'Netsuite Invoices and RI'
          THEN Oi.Total_Invoice_Amount + Ori.Total_RI_Amount
        WHEN op.Billing_Source = 'SFDC Billing Segment (Non-Azure) and RI'
          THEN Ob.Total_Billing_Amount + Ori.Total_RI_Amount
        WHEN op.Billing_Source = 'SFDC Billing Segment (Azure) and Netsuite Invoices'
          THEN Ob.Total_Billing_Amount + Oi.Total_Invoice_Amount
        ELSE 0
        END
      AS Billing_Amount_Within_30_days

FROM Opportunity Op
  LEFT JOIN Opportunity_Invoice Oi
    ON Op.Opportunity_Id = Oi.Opportunity_Id
      AND Op.Billing_Source = Oi.Billing_Source
      AND Op.Close_Or_Renewal_Date = Oi.Close_Or_Renewal_Date

  LEFT JOIN Opportunity_RI Ori
    ON Op.Opportunity_Id = Ori.Opportunity_Id
      AND Op.Billing_Source = Ori.Billing_Source
      AND Op.Close_Or_Renewal_Date = Ori.Close_Or_Renewal_Date

  LEFT JOIN Opportunity_Billing Ob
    ON Op.Opportunity_Id = Ob.Opportunity_Id
      AND Op.Billing_Source = Ob.Billing_Source
      AND Op.Close_Or_Renewal_Date = Ob.Close_Or_Renewal_Date
''')

df_amount_billed_30_days.createOrReplaceTempView("df_amount_billed_30_days")

# COMMAND ----------

# DBTITLE 1,Enhanced Billing Data Merge
df_final = spark.sql('''
                     
              SELECT agg.*,
                     amt_30.Billing_Amount_Within_30_days as Billing_Amount_Within_30_days,
              (case 
                     when lower(debook_flag) = 'true' then 0 

                     when agg.Billing_Source = 'Not Available'  and agg.Platform = 'Azure' 
                            then 0

                     when  agg.Billing_Source  = 'Not Available' and agg.Platform <> 'Azure' and agg.prior_closed_deal_ratio is null
                            then agg.Booking_Dollars

                     when agg.Billing_Source  = 'Not Available' and agg.Platform <> 'Azure' and agg.prior_closed_deal_ratio is not null
                            then  (agg.prior_closed_deal_ratio * agg.Booking_Dollars)

                     when agg.Platform = 'Azure' 
                          and (
                                 agg.Billing_Source = 'SFDC Billing Segment (Azure + Non-Azure)'
                              or agg.Billing_Source = 'SFDC Billing Segment (Azure)'
                              or agg.Billing_Source = 'SFDC Billing Segment (Non-Azure)'
                             ) 
                          and agg.Term>12
                          and amt_30.Billing_Amount_Within_30_days > agg.Booking_Dollars 
                          and agg.Close_Or_Renewal_Date <= '2024-12-31'
                            then agg.Booking_Dollars

                     else amt_30.Billing_Amount_Within_30_days 

              end) as Bookings_Billed_Upfront_Within_30days

                     FROM opp_bookings_billing_agg_prior_close agg 
                      LEFT JOIN df_amount_billed_30_days amt_30 
                     ON agg.Opportunity_Id = amt_30.Opportunity_Id 
                      AND agg.Close_Or_Renewal_Date = amt_30.Close_Or_Renewal_Date

                     ''')
                     
df_final = df_final.drop('Month1_Billing_Amount', 'Bookings_Billed_Upfront_Month_1', 'Billing_Amount_Within_30_days', 'Bookings_Billed_Non_Upfront')
df_final.createOrReplaceTempView("df_final")

# COMMAND ----------

df_BB_Non_Upfront = spark.sql('''

SELECT *,
      case when lower(debook_flag) = 'true' then 0 
           when Billing_Source  = 'Not Available'  and Platform = 'Azure' then Booking_Dollars 
           when Billing_Source  = 'Not Available'  and Platform <> 'Azure' then  0
           else Booking_dollars - Bookings_Billed_Upfront_Within_30days 
      end 
      as Bookings_Billed_Non_Upfront
FROM df_final


''')

df_BB_Non_Upfront.createOrReplaceTempView('df_BB_Non_Upfront')

# COMMAND ----------

df_billing_frequency = spark.sql('''
    WITH bill_freq (  
          SELECT seg.Opportunity__c as OpportunityId,
                  seg.Billing_Frequency__c as Billing_Freq,
                  SUM(seg.TCV_Amount__c) OVER (PARTITION BY seg.Opportunity__c, seg.Billing_Frequency__c) as Billing_Freq_TCV,
                  SUM(seg.TCV_Amount__c) OVER (PARTITION BY seg.Opportunity__c) as Total_TCV
          FROM main.sfdc_bronze.billing_segment__c seg
          INNER JOIN main.sfdc_bronze.sbqq__quote__c quote
            on seg.CPQ_Quote__c = quote.Id 

          WHERE seg.processDate = (Select max(processDate) from main.sfdc_bronze.billing_segment__c  ) 
          and quote.processDate = (Select max(processDate) from main.sfdc_bronze.sbqq__quote__c  ) 
          and  seg.Opportunity__c is not null
          and lower(quote.SBQQ__Primary__c) ='true'
          and lower(product_family__c) in  ('license', 'support') 
    ),

    bill_frequency as (
          SELECT OpportunityId,
                 Billing_Freq, 
                 Billing_Freq_TCV,
                 Total_TCV,
                 (Billing_Freq_TCV/Total_TCV) * 100 as TCV_percentage
          FROM bill_freq
    
    ),

    ranked_bill_frequency as (
          SELECT OpportunityId,
                 Billing_Freq, 
                 Billing_Freq_TCV,
                 Total_TCV,
                 TCV_percentage,
                 RANK() OVER (PARTITION BY OpportunityId ORDER BY TCV_percentage DESC) as TCV_rank
          FROM bill_frequency
    ),

    final_frequency as (
          SELECT DISTINCT
           OpportunityId,
           CASE
                  WHEN TCV_percentage >= 80 THEN Billing_Freq
                  ELSE 'Custom'
            END as Billing_Frequency
          FROM ranked_bill_frequency
          WHERE TCV_rank = 1
    )

    SELECT bookings.*,
        CASE 
              WHEN bookings.Type = "Azure P3-Only" 
                THEN "Annual"
              WHEN billing_seg.Billing_Frequency IS NULL 
                THEN "No Billing Type"
              ELSE billing_seg.Billing_Frequency
        END AS Billing_Frequency

      FROM df_BB_Non_Upfront bookings 
            LEFT JOIN final_frequency billing_seg
                  ON bookings.Opportunity_Id = billing_seg.OpportunityId      
''')

df_billing_frequency.createOrReplaceTempView("df_billing_frequency")

# COMMAND ----------

df_anaplan_snap = spark.sql('''
WITH Renewal AS (
    SELECT sfdc_opportunity_id, 
          SUM(booking_amount) AS Renewal_Dollars_SNAP
    FROM main.fin_snap.bookings_anaplan_snap
    WHERE sfdc_opportunity_id IS NOT NULL
      AND label = 'Renewal ARR (non PS)'
    GROUP BY sfdc_opportunity_id
),

Increm AS (
    SELECT sfdc_opportunity_id, 
          SUM(booking_amount) AS Incremental_Dollars_SNAP
    FROM main.fin_snap.bookings_anaplan_snap
    WHERE sfdc_opportunity_id IS NOT NULL
      AND label = 'Incremental Booking ARR'
   GROUP BY sfdc_opportunity_id
),

Opp_Check AS (
  SELECT DISTINCT 
         bill.Opportunity_Id,
         CASE WHEN ana.sfdc_opportunity_id IS NULL THEN 'No' ELSE 'Yes' END AS is_anaplan_snap
  FROM df_billing_frequency bill 
  LEFT JOIN main.fin_snap.bookings_anaplan_snap ana
      ON bill.Opportunity_Id = ana.sfdc_opportunity_id
),

CTE AS (
    SELECT DISTINCT 
            snp.sfdc_opportunity_id, 
            MAX(close_date) OVER (PARTITION BY snp.sfdc_opportunity_id) as close_date_SNAP, 
            MAX(close_month) OVER (PARTITION BY snp.sfdc_opportunity_id) as close_month_SNAP, 
            SUM(booking_amount) OVER (PARTITION BY snp.sfdc_opportunity_id) as booking_amount_SNAP,
            SUM(
              CASE 
                WHEN snp.product_name IN ('MCT Direct Commit', 'Complimentary Usage - MCT', 'MCT Hero Run Support', 'Mosaic Direct Commit', 'MCT Business Support') THEN booking_amount
                ELSE 0 
            END
            ) OVER (PARTITION BY snp.sfdc_opportunity_id)  MCT_Booking_Amount_SNAP, 
            rnw.Renewal_Dollars_SNAP,
            icr.Incremental_Dollars_SNAP
    FROM main.fin_snap.bookings_anaplan_snap snp
      LEFT JOIN Renewal rnw
        ON snp.sfdc_opportunity_id = rnw.sfdc_opportunity_id
      LEFT JOIN Increm icr
        ON  snp.sfdc_opportunity_id = icr.sfdc_opportunity_id
    WHERE snp.sfdc_opportunity_id IS NOT NULL
      AND label NOT LIKE 'Services Bookings'
)

SELECT fn.*,
        ct.close_date_SNAP,
        CASE
          WHEN is_anaplan_snap = 'No' THEN fn.Close_Or_Renewal_Date
          ELSE ct.close_date_SNAP
        END AS close_date_FINAL,

        ct.close_month_SNAP,
        CASE
          WHEN is_anaplan_snap = 'No' THEN fn.Estimated_Close_Or_Renewal_Month
          ELSE ct.close_month_SNAP
        END AS close_month_FINAL,

        ct.booking_amount_SNAP,
        CASE
          WHEN is_anaplan_snap = 'No' THEN fn.Booking_Dollars
          ELSE ct.booking_amount_SNAP
        END AS booking_amount_FINAL,

        ct.Renewal_Dollars_SNAP,
        CASE
          WHEN is_anaplan_snap = 'No' THEN fn.Renewal_Dollars
          ELSE ct.Renewal_Dollars_SNAP
        END AS Renewal_Dollars_FINAL,

        ct.Incremental_Dollars_SNAP,
        CASE
          WHEN is_anaplan_snap = 'No' THEN fn.Incremental_Dollars
          ELSE ct.Incremental_Dollars_SNAP
        END AS Incremental_Dollars_FINAL,

        ct.MCT_Booking_Amount_SNAP

FROM df_billing_frequency fn
  JOIN Opp_Check oc
    ON fn.Opportunity_Id = oc.Opportunity_Id
  LEFT JOIN CTE ct
    ON fn.Opportunity_Id = ct.sfdc_opportunity_id
'''
)

df_anaplan_snap.createOrReplaceTempView("df_anaplan_snap")

# COMMAND ----------

df_azure_rebate = spark.sql(f'''
                            
SELECT asp.*, 
       quot.SBQQ__EffectiveQuantity__c as Azure_Rebate

FROM df_anaplan_snap asp
  LEFT JOIN main.sfdc_bronze.sbqq__quoteline__c quot
    ON asp.Primary_Quote = quot.SBQQ__Quote__c
    AND quot.processDate = (SELECT MAX(processDate) FROM main.sfdc_bronze.sbqq__quoteline__c)
    AND quot.SBQQ__ProductName__c = 'Azure Rebate'

''')

df_azure_rebate.createOrReplaceTempView('df_azure_rebate')

# COMMAND ----------

df_TCV = spark.sql(f'''

WITH CTE AS 
(
SELECT azr.*, 
       SUM(opp_line.CPQ_Net_Total_after_Service_Adjustment__c) TCV_total

FROM df_azure_rebate azr
  LEFT JOIN main.sfdc_bronze.opportunitylineitem opp_line
    ON azr.Opportunity_Id = opp_line.opportunityId
    AND opp_line.processDate = (select max(processDate) from main.sfdc_bronze.opportunitylineitem )
    AND opp_line.Product_Family__c IN ('Training', 'Training - Non Customer', 'Training - Recurring', 'Professional Services', 'Professional Services - Non Customer', 'Professional Services - Recurring', 'License', 'Support')
GROUP BY ALL
)    

SELECT *,
       CASE 
          WHEN Type = 'Azure P3-Only' AND TCV_total IS NULL
            THEN Booking_Dollars
          ELSE
            TCV_total
        END AS TCV_updated
FROM CTE


''')

df_TCV = df_TCV.drop('TCV_total')
df_TCV.createOrReplaceTempView('df_TCV')

# COMMAND ----------

opp_bookings_billing_agg, processDate = add_audit_attributes(df_TCV)

# COMMAND ----------

# DBTITLE 1,Delta Table Overwrite Scheduler
date_str = processDate.strftime('%Y-%m-%d')

print (f'Updating data in {full_table_name} for {processDate}')
(opp_bookings_billing_agg
  .write
  .mode('overwrite')
  .format('delta')
  #.option('overwriteSchema', 'true')
  .option("mergeSchema", "true")
  .option('replaceWhere', f"process_date = '{date_str}'")
  .partitionBy("process_date")
  .saveAsTable(full_table_name))

# COMMAND ----------


