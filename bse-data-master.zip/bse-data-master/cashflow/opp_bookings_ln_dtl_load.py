# Databricks notebook source
# DBTITLE 1,Cashflow Config Execution Script
# MAGIC %run "./cashflow_config"

# COMMAND ----------

full_table_name = f'{catalog_nm}.{tgt_db_nm}.opp_bookings_ln_dtl'
print(full_table_name)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Incremental

# COMMAND ----------

booking_commit = spark.sql (f""" 
SELECT 
    opp_line.id
  , opp_line.opportunityid as Opportunity_Id
  , opp_line.Opportunity_Line_Item_ID__c
  , opp.SBQQ__PrimaryQuote__c	as primary_quote
  , opp_line.Name as line_item_name
  , opp.Name as Opportunity_Name
  , opp.Type as type_raw
  , opp.AccountId as Account_ID
  , acc.Name as Account_Name
  , prodid.name as product_name
  , opp.`OwnerId` as Opportunity_Owner_ID  
  , opp.CloseDate as Close_Date 
  , opp.Original_Expected_Renewal_Date__c Renewal_Date
  , CASE 
        WHEN opp.IsClosed = TRUE 
          THEN opp.CloseDate
        WHEN opp.IsClosed = FALSE AND 
             opp.Renewal_Extension_Approved_Flag__c = TRUE AND 
             opp.Extension_Request_Close_Date__c IS NOT NULL 
          THEN opp.Extension_Request_Close_Date__c
        WHEN opp.IsClosed = FALSE AND 
            (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
             opp.Extension_Request_Close_Date__c IS NULL) AND 
             opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
             LOWER(opp.VP_Forecast__c) IN ('closed', 'commit') AND 
             opp.CloseDate < opp.Original_Expected_Renewal_Date__c 
          THEN opp.CloseDate
        WHEN opp.IsClosed = FALSE AND 
            (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
             opp.Extension_Request_Close_Date__c IS NULL) AND 
             opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
             LOWER(opp.VP_Forecast__c) IN ('closed', 'commit') AND 
             opp.CloseDate > opp.Original_Expected_Renewal_Date__c 
          THEN opp.CloseDate
        WHEN opp.IsClosed = FALSE AND 
            (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
             opp.Extension_Request_Close_Date__c IS NULL) AND 
             opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
             LOWER(opp.VP_Forecast__c) NOT IN ('closed', 'commit') AND 
             opp.CloseDate < opp.Original_Expected_Renewal_Date__c 
          THEN opp.Original_Expected_Renewal_Date__c 
        WHEN opp.IsClosed = FALSE AND 
            (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
            opp.Extension_Request_Close_Date__c IS NULL) AND 
            opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
            LOWER(opp.VP_Forecast__c) NOT IN ('closed', 'commit') AND 
            opp.CloseDate > opp.Original_Expected_Renewal_Date__c 
          THEN opp.CloseDate 
        ELSE opp.Original_Expected_Renewal_Date__c
      END AS Renewal_Date_UPD
  , to_date(concat(int(opp.Close_Year_Indicator__c), "-", lpad(int(opp.Close_Month_Indicator__c), 2, 0), "-01")) as Close_Month
  , opp.Start_Date__c as Start_Date
  , opp.End_Date__c as End_Date
  , opp.CreatedDate
  , opp.Prospecting_Stage_Date_Stamp__c
  , opp.Proposal_Stage_Date_Stamp__c
  , opp.Negotiation_Stage_Date_Stamp__c
  , opp.Term__c as term_non_cpq
  , opp.NumberOfTerms__c as term_cpq
  , opp.Billing_Schedule__c
  , opp.CurrencyIsoCode as opportunity_currency
  , opp_line.ListPrice
  , opp_line.UnitPrice as salesPrice
  , opp_line.TotalPrice
  , opp.Term_Num__c
  , opp_line.Cloud_Type__c
  , opp.Total_Contract_Value__c
  , opp_line.CPQ_Net_Total_after_Service_Adjustment__c as TCV__c
  , coalesce( opp.Total_Contract_Value__c , opp.TCV__c ,opp.Total_Contract_ValueNewBuss__c ) as opp_tcv
  , concat(case
      when month(opp.CloseDate) in (2,3,4) then 'Q1'
      when month(opp.CloseDate) in (5,6,7) then 'Q2'
      when month(opp.CloseDate) in (8,9,10) then 'Q3'
      else 'Q4' end, "-"
  , case
      when month(opp.CloseDate) > 1 then (year(opp.CloseDate) + 1)
      else year(opp.CloseDate) end) as Fiscal_Quarter
  , opp.CPQ_Incremental_Booking_ARR__c
  , ifnull(opp_line.Incremental_Booking_Total_Fcst__c, 0) as Incr_booking
  , ifnull(opp_line.Renewal_Booking_Total_Fcst__c, 0) as Renewal_booking
  , ifnull(opp.Amount, 0) as amount
  , ifnull(opp.Churn_Amount__c,0) as Churn_Amount__c
  , case
      when month(opp.CloseDate) in (2,3,4) then 'Q1'
      when month(opp.CloseDate) in (5,6,7) then 'Q2'
      when month(opp.CloseDate) in (8,9,10) then 'Q3'
      else 'Q4' end as fiscalQtr
  , case
      when month(opp.CloseDate) > 1 then concat('FY', substr((year(opp.CloseDate) + 1), 3, 2))
      else concat('FY', substr(year(opp.CloseDate), 3, 2)) end as fiscalYear
  , case 
      when opp.Platform_Type__c LIKE '%Azure%' then 'Azure'
      when opp.Platform_Type__c = 'Google Cloud' then 'GCP'
      when opp.Platform_Type__c = 'Private Cloud' then 'PVC'
      when LOWER(opp.Platform_Type__c) LIKE '%mosaic%' THEN 'MCT'
      else 'AWS'
    end as Platform
  , case 
      when opp.Platform_Type__c LIKE '%Azure%' then 'Azure'
      when LOWER(opp.Platform_Type__c) LIKE '%mosaic%' THEN 'MCT' 
      else 'Non-Azure'
    end as Platform_Simplified
  , case
      when opp.type = 'Pilot' then 'New Business'
      when opp.type = 'Renewal' then 'Upsell'
      else opp.type
    end as Type
  , opp_line.Product_Family__c
  , opp.StageName as Stage      
  , opp_line.Quantity as quantity
  , VP_Forecast__c as manager_forecast
  , UniversalCommitRollover__c as universal_commit_rollover
  , New_Logo_All__c as new_logo_all
  , Original_Expected_Renewal_Date__c as original_expected_renewal_date  
  , opp.Secondary_AE__c as secondary_ae_id
  , opp.P3_Click_Amount__c as p3_click_amount
  , opp.P3_Click_Date__c as p3_click_date
  , opp.P3_Executed__c as p3_executed
  , opp.Split_Percentage__c as split_percentage
  , opp.PrimaryOwnerSplit__c as primary_owner_split
  , opp.Secondary_AE_2__c as secondary_ae_2
  , opp.Split_Percentage_2__c as split_percentage_2  
  , opp.Debook__c as debook
  , acc.Business_Unit__c

FROM main.sfdc_bronze.opportunitylineitem opp_line
  INNER join main.sfdc_bronze.opportunity opp
    ON opp_line.opportunityId = opp.id

LEFT JOIN  main.sfdc_bronze.account acc
  ON opp.accountid = acc.AccountID_CaseSafe__c

LEFT JOIN main.sfdc_bronze.product2 prodid
  ON opp_line.product2id = prodid.id

WHERE 
 opp.processDate = (select max(processDate) from main.sfdc_bronze.opportunity) AND 
 opp_line.processDate = (select max(processDate) from main.sfdc_bronze.opportunitylineitem ) AND 
 acc.processDate = (SELECT MAX(processDate) from main.sfdc_bronze.account) AND
 prodid.processDate = (select max(processDate) from main.sfdc_bronze.product2) AND

(

  (
    opp.Type IN ("Pilot", "New Business", "Renewal", "Upsell", "Azure P3-Only") AND 
    
    opp.StageName in ("Prospecting", "Validate", "POC Scoping", "Evaluation", "Proposal", "Negotiation / Procurement",  "Closed Won", "Signed" )  AND
    
    opp_line.Product_Family__c in ('License', 'Support' ) AND 
    
    Debook__c = True
  )

  OR

  (
    opp.Type in ("Pilot", "New Business", "Renewal", "Upsell", "Azure P3-Only") AND 
    
    opp.StageName in ("Prospecting", "Validate", "POC Scoping", "Evaluation", "Proposal", "Negotiation / Procurement",  "Closed Won", "Signed", "Disqualified", "") AND
    
    opp_line.Product_Family__c IN ('License', 'Support') AND

    Debook__c = False AND
    
    ROUND(opp.CPQ_Incremental_Booking_ARR__c, 2) >= 0)  
  ) 
  
  AND
  
  opp_line.isDeleted = False AND
  opp.isDeleted = False
  

""" )

booking_commit.createOrReplaceTempView('booking_commit')
  

# COMMAND ----------

# MAGIC %md
# MAGIC ### Services

# COMMAND ----------

# DBTITLE 1,Opportunity Booking Data Query
booking_services  = spark.sql ('''
  SELECT 
      opp_line.id
      , opp_line.opportunityid as Opportunity_Id
      , opp_line.Opportunity_Line_Item_ID__c
      , opp.SBQQ__PrimaryQuote__c	as primary_quote
      , opp_line.Name as line_item_name
      , opp.Name as Opportunity_Name
      , opp.Type as type_raw
      , opp.AccountId as Account_ID
      , acc.Name as Account_Name
      , prodid.name as product_name
      , opp.`OwnerId` as Opportunity_Owner_ID  
      , opp.CloseDate as Close_Date  
      , opp.Original_Expected_Renewal_Date__c Renewal_Date
      , CASE 
          WHEN opp.IsClosed = TRUE 
            THEN opp.CloseDate
          WHEN opp.IsClosed = FALSE AND 
              opp.Renewal_Extension_Approved_Flag__c = TRUE AND 
              opp.Extension_Request_Close_Date__c IS NOT NULL 
            THEN opp.Extension_Request_Close_Date__c
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) IN ('closed', 'commit') AND 
              opp.CloseDate < opp.Original_Expected_Renewal_Date__c 
            THEN opp.CloseDate
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) IN ('closed', 'commit') AND 
              opp.CloseDate > opp.Original_Expected_Renewal_Date__c 
            THEN opp.CloseDate
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) NOT IN ('closed', 'commit') AND 
              opp.CloseDate < opp.Original_Expected_Renewal_Date__c 
            THEN opp.Original_Expected_Renewal_Date__c 
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) NOT IN ('closed', 'commit') AND 
              opp.CloseDate > opp.Original_Expected_Renewal_Date__c 
            THEN opp.CloseDate 
          ELSE opp.Original_Expected_Renewal_Date__c
        END AS Renewal_Date_UPD
      , to_date(concat(int(opp.Close_Year_Indicator__c), "-", lpad(int(opp.Close_Month_Indicator__c), 2, 0), "-01")) as Close_Month
      , opp.Start_Date__c as Start_Date
      , opp.End_Date__c as End_Date
      , opp.CreatedDate
      , opp.Prospecting_Stage_Date_Stamp__c
      , opp.Proposal_Stage_Date_Stamp__c
      , opp.Negotiation_Stage_Date_Stamp__c
      , opp.Term__c as term_non_cpq
      , opp.NumberOfTerms__c as term_cpq
      , opp.Billing_Schedule__c
      , opp.CurrencyIsoCode as opportunity_currency
      , opp_line.ListPrice
      , opp_line.UnitPrice as salesPrice
      , opp_line.TotalPrice
      , opp.Term_Num__c
      , opp_line.Cloud_Type__c
      , opp.Total_Contract_Value__c
      , opp_line.CPQ_Net_Total_after_Service_Adjustment__c as TCV__c
      , coalesce( opp.Total_Contract_Value__c , opp.TCV__c ,opp.Total_Contract_ValueNewBuss__c ) as opp_tcv 
      , concat(case
          when month(opp.CloseDate) in (2,3,4) then 'Q1'
          when month(opp.CloseDate) in (5,6,7) then 'Q2'
          when month(opp.CloseDate) in (8,9,10) then 'Q3'
          else 'Q4' end, "-"
      , case
          when month(opp.CloseDate) > 1 then (year(opp.CloseDate) + 1)
          else year(opp.CloseDate) end) as Fiscal_Quarter
      , opp.CPQ_Incremental_Booking_ARR__c
      , ifnull(opp_line.Incremental_Booking_Total_Fcst__c, 0) as Incr_booking
      , ifnull(opp_line.Renewal_Booking_Total_Fcst__c, 0) as Renewal_booking
      , ifnull(opp.Amount, 0) as amount
      , ifnull(opp.Churn_Amount__c,0) as Churn_Amount__c 
      , case
          when month(opp.CloseDate) in (2,3,4) then 'Q1'
          when month(opp.CloseDate) in (5,6,7) then 'Q2'
          when month(opp.CloseDate) in (8,9,10) then 'Q3'
          else 'Q4' end as fiscalQtr
      , case
          when month(opp.CloseDate) > 1 then concat('FY', substr((year(opp.CloseDate) + 1), 3, 2))
          else concat('FY', substr(year(opp.CloseDate), 3, 2)) end as fiscalYear
      , case 
          when opp.Platform_Type__c LIKE '%Azure%' then 'Azure'
          when opp.Platform_Type__c = 'Google Cloud' then 'GCP'
          when opp.Platform_Type__c = 'Private Cloud' then 'PVC'
          when LOWER(opp.Platform_Type__c) LIKE '%mosaic%' THEN 'MCT' 
        else 'AWS'
      end as Platform
      , case 
          when opp.Platform_Type__c LIKE '%Azure%' then 'Azure'
          when LOWER(opp.Platform_Type__c) LIKE '%mosaic%' THEN 'MCT' 
          else 'Non-Azure'
        end as Platform_Simplified
      , case
        when opp.type = 'Pilot' then 'New Business'
        when opp.type = 'Renewal' then 'Upsell'
        else opp.type
          end as Type
      , opp_line.Product_Family__c
      , opp.StageName as Stage      
      , opp_line.Quantity as quantity
      , VP_Forecast__c as manager_forecast
      , UniversalCommitRollover__c as universal_commit_rollover
      , New_Logo_All__c as new_logo_all
      , Original_Expected_Renewal_Date__c as original_expected_renewal_date  
      , opp.Secondary_AE__c as secondary_ae_id
      , opp.P3_Click_Amount__c as p3_click_amount
      , opp.P3_Click_Date__c as p3_click_date
      , opp.P3_Executed__c as p3_executed
      , opp.Split_Percentage__c as split_percentage
      , opp.PrimaryOwnerSplit__c as primary_owner_split
      , opp.Secondary_AE_2__c as secondary_ae_2
      , opp.Split_Percentage_2__c as split_percentage_2  
      , opp.Debook__c as debook
      , acc.Business_Unit__c

FROM main.sfdc_bronze.opportunitylineitem opp_line
  INNER join  main.sfdc_bronze.opportunity opp
    on opp_line.opportunityId = opp.id

  LEFT JOIN  main.sfdc_bronze.account acc
    on opp.accountid = acc.AccountID_CaseSafe__c

  LEFT JOIN main.sfdc_bronze.product2 prodid
    on opp_line.product2id = prodid.id

WHERE 
  opp.processDate = (select max(processDate) from main.sfdc_bronze.opportunity) AND 
  opp_line.processDate = (select max(processDate) from main.sfdc_bronze.opportunitylineitem ) AND
  acc.processDate = (select max(processDate) from main.sfdc_bronze.account) AND
  prodid.processDate = (select max(processDate) from main.sfdc_bronze.product2) AND

  ( 
  
  opp.Type NOT IN ('PAYG - Upload', 'PAYG', 'PAYG - Azure', 'LMS Generated', 'Burst', 'MTM', 'MTM Adjustment') AND
  
  opp.StageName in  ("Prospecting", "Validate", "POC Scoping", "Evaluation", "Proposal", "Negotiation / Procurement",  "Closed Won", "Signed") AND

    (
      opp_line.Product_Family__c IN ('Training', 'Training - Non Customer', 'Training - Recurring', 'Professional Services', 'Professional Services - Non Customer', 'Professional Services - Recurring')
      
      OR
      
      LOWER(opp_line.name) LIKE '%complimentary success credits%'
      
    )
    
  )

  AND opp_line.isDeleted = False
  AND opp.isDeleted = False

 ''' )

booking_services.createOrReplaceTempView('booking_services')
  

# COMMAND ----------

# MAGIC %md
# MAGIC ### Renewal

# COMMAND ----------

# DBTITLE 1,Opportunity Renewal Data Extract
booking_renewals  = spark.sql ('''
SELECT 
    1 || '_'|| opp.id as id
  , opp.id as Opportunity_Id
  , null as Opportunity_Line_Item_ID__c
  , opp.SBQQ__PrimaryQuote__c	as primary_quote
  , NULL  line_item_name
  , opp.Name as Opportunity_Name
  , opp.Type as type_raw
  , opp.AccountId as Account_ID
  , acc.Name as Account_Name
  , NULL as product_name
  , opp.`OwnerId` as Opportunity_Owner_ID  
  , opp.CloseDate as Close_Date  
  , opp.Original_Expected_Renewal_Date__c Renewal_Date
  , CASE 
          WHEN opp.IsClosed = TRUE 
            THEN opp.CloseDate
          WHEN opp.IsClosed = FALSE AND 
              opp.Renewal_Extension_Approved_Flag__c = TRUE AND 
              opp.Extension_Request_Close_Date__c IS NOT NULL 
            THEN opp.Extension_Request_Close_Date__c
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) IN ('closed', 'commit') AND 
              opp.CloseDate < opp.Original_Expected_Renewal_Date__c 
            THEN opp.CloseDate
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) IN ('closed', 'commit') AND 
              opp.CloseDate > opp.Original_Expected_Renewal_Date__c 
            THEN opp.CloseDate
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) NOT IN ('closed', 'commit') AND 
              opp.CloseDate < opp.Original_Expected_Renewal_Date__c 
            THEN opp.Original_Expected_Renewal_Date__c 
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) NOT IN ('closed', 'commit') AND 
              opp.CloseDate > opp.Original_Expected_Renewal_Date__c 
            THEN opp.CloseDate 
          ELSE opp.Original_Expected_Renewal_Date__c
        END AS Renewal_Date_UPD
  , to_date(concat(int(opp.Close_Year_Indicator__c), "-", lpad(int(opp.Close_Month_Indicator__c), 2, 0), "-01")) as Close_Month
  , opp.Start_Date__c as Start_Date
  , opp.End_Date__c as End_Date
  , opp.CreatedDate
  , opp.Prospecting_Stage_Date_Stamp__c
  , opp.Proposal_Stage_Date_Stamp__c
  , opp.Negotiation_Stage_Date_Stamp__c
  , opp.Term__c as term_non_cpq
  , opp.NumberOfTerms__c as term_cpq
  , opp.Billing_Schedule__c
  , opp.CurrencyIsoCode as opportunity_currency
  , null as ListPrice
  , null  as salesPrice
  , null as TotalPrice
  , opp.Term_Num__c
  , Null as Cloud_Type__c
  , opp.Total_Contract_Value__c
  , NULL  as TCV__c
  , coalesce( opp.Total_Contract_Value__c , opp.TCV__c ,opp.Total_Contract_ValueNewBuss__c ) as opp_tcv
  , concat(case
      when month(opp.CloseDate) in (2,3,4) then 'Q1'
      when month(opp.CloseDate) in (5,6,7) then 'Q2'
      when month(opp.CloseDate) in (8,9,10) then 'Q3'
      else 'Q4' end, "-"
  , case
      when month(opp.CloseDate) > 1 then (year(opp.CloseDate) + 1)
      else year(opp.CloseDate) end) as Fiscal_Quarter
  , opp.CPQ_Incremental_Booking_ARR__c
  , NULL as Incr_booking
  , CASE
      WHEN opp.Converting_to_PAYG__c = TRUE THEN 0 
      WHEN opp.CPQ_Incremental_Booking_ARR__c < 0 THEN (opp.CPQ_Incremental_Booking_ARR__c + ifnull(opp.CPQ_ATR__c,0))
      ELSE ifnull(opp.CPQ_ATR__c,0) 
    END as Renewal_booking
  , ifnull(opp.Amount, 0) as amount
  , ifnull(opp.Churn_Amount__c,0) as Churn_Amount__c
  , case
      when month(opp.CloseDate) in (2,3,4) then 'Q1'
      when month(opp.CloseDate) in (5,6,7) then 'Q2'
      when month(opp.CloseDate) in (8,9,10) then 'Q3'
      else 'Q4' end as fiscalQtr
  , case
      when month(opp.CloseDate) > 1 then concat('FY', substr((year(opp.CloseDate) + 1), 3, 2))
      else concat('FY', substr(year(opp.CloseDate), 3, 2)) end as fiscalYear
  , case 
      when opp.Platform_Type__c LIKE '%Azure%' then 'Azure'
      when opp.Platform_Type__c = 'Google Cloud' then 'GCP'
      when opp.Platform_Type__c = 'Private Cloud' then 'PVC'
      when LOWER(opp.Platform_Type__c) LIKE '%mosaic%' THEN 'MCT'
      else 'AWS'
    end as Platform
  , case 
          when opp.Platform_Type__c LIKE '%Azure%' then 'Azure'
          when LOWER(opp.Platform_Type__c) LIKE '%mosaic%' THEN 'MCT' 
          else 'Non-Azure'
        end as Platform_Simplified
  , case
    when opp.type = 'Pilot' then 'New Business'
    when opp.type = 'Renewal' then 'Upsell'
    else opp.type
      end as Type
  , NULL as Product_Family__c
  , opp.StageName as Stage      
  , NULL  as quantity
  , VP_Forecast__c as manager_forecast
  , UniversalCommitRollover__c as universal_commit_rollover
  , New_Logo_All__c as new_logo_all
  , Original_Expected_Renewal_Date__c as original_expected_renewal_date  
  , opp.Secondary_AE__c as secondary_ae_id
  , opp.P3_Click_Amount__c as p3_click_amount
  , opp.P3_Click_Date__c as p3_click_date
  , opp.P3_Executed__c as p3_executed
  , opp.Split_Percentage__c as split_percentage
  , opp.PrimaryOwnerSplit__c as primary_owner_split
  , opp.Secondary_AE_2__c as secondary_ae_2
  , opp.Split_Percentage_2__c as split_percentage_2  
  , opp.Debook__c as debook
  , acc.Business_Unit__c

FROM main.sfdc_bronze.opportunity opp
  LEFT JOIN  main.sfdc_bronze.account acc
    on opp.accountid = acc.AccountID_CaseSafe__c

WHERE

 opp.processDate = (select max(processDate) from main.sfdc_bronze.opportunity) and 
 acc.processDate = (select max(processDate) from main.sfdc_bronze.account) and
 
 opp.StageName NOT in ('Closed Lost','Disqualified') and
 
 SBQQ__RenewedContract__c is not null and

 opp.type NOT LIKE "Azure P3-Only" and
    
 Debook__c = False and 
 
 opp.isDeleted = False
 ''' )

booking_renewals.createOrReplaceTempView('booking_renewals')
  

# COMMAND ----------

# MAGIC %md
# MAGIC ### Azure P3-Only Renewals

# COMMAND ----------

booking_p3_renewals = spark.sql (f""" 
SELECT 
    opp_line.id
  , opp_line.opportunityid as Opportunity_Id
  , opp_line.Opportunity_Line_Item_ID__c
  , opp.SBQQ__PrimaryQuote__c	as primary_quote
  , opp_line.Name as line_item_name
  , opp.Name as Opportunity_Name
  , opp.Type as type_raw
  , opp.AccountId as Account_ID
  , acc.Name as Account_Name
  , prodid.name as product_name
  , opp.`OwnerId` as Opportunity_Owner_ID  
  , opp.CloseDate as Close_Date 
  , opp.Original_Expected_Renewal_Date__c Renewal_Date
  , CASE 
          WHEN opp.IsClosed = TRUE 
            THEN opp.CloseDate
          WHEN opp.IsClosed = FALSE AND 
              opp.Renewal_Extension_Approved_Flag__c = TRUE AND 
              opp.Extension_Request_Close_Date__c IS NOT NULL 
            THEN opp.Extension_Request_Close_Date__c
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) IN ('closed', 'commit') AND 
              opp.CloseDate < opp.Original_Expected_Renewal_Date__c 
            THEN opp.CloseDate
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) IN ('closed', 'commit') AND 
              opp.CloseDate > opp.Original_Expected_Renewal_Date__c 
            THEN opp.CloseDate
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) NOT IN ('closed', 'commit') AND 
              opp.CloseDate < opp.Original_Expected_Renewal_Date__c 
            THEN opp.Original_Expected_Renewal_Date__c 
          WHEN opp.IsClosed = FALSE AND 
              (opp.Renewal_Extension_Approved_Flag__c = FALSE OR 
              opp.Extension_Request_Close_Date__c IS NULL) AND 
              opp.CPQ_Incremental_Booking_ARR__c > 0 AND 
              LOWER(opp.VP_Forecast__c) NOT IN ('closed', 'commit') AND 
              opp.CloseDate > opp.Original_Expected_Renewal_Date__c 
            THEN opp.CloseDate 
          ELSE opp.Original_Expected_Renewal_Date__c
        END AS Renewal_Date_UPD
  , to_date(concat(int(opp.Close_Year_Indicator__c), "-", lpad(int(opp.Close_Month_Indicator__c), 2, 0), "-01")) as Close_Month
  , opp.Start_Date__c as Start_Date
  , opp.End_Date__c as End_Date
  , opp.CreatedDate
  , opp.Prospecting_Stage_Date_Stamp__c
  , opp.Proposal_Stage_Date_Stamp__c
  , opp.Negotiation_Stage_Date_Stamp__c
  , opp.Term__c as term_non_cpq
  , opp.NumberOfTerms__c as term_cpq
  , opp.Billing_Schedule__c
  , opp.CurrencyIsoCode as opportunity_currency
  , opp_line.ListPrice
  , opp_line.UnitPrice as salesPrice
  , opp_line.TotalPrice
  , opp.Term_Num__c
  , opp_line.Cloud_Type__c
  , opp.Total_Contract_Value__c
  , opp_line.CPQ_Net_Total_after_Service_Adjustment__c as TCV__c
  , coalesce( opp.Total_Contract_Value__c , opp.TCV__c ,opp.Total_Contract_ValueNewBuss__c ) as opp_tcv
  , concat(case
      when month(opp.CloseDate) in (2,3,4) then 'Q1'
      when month(opp.CloseDate) in (5,6,7) then 'Q2'
      when month(opp.CloseDate) in (8,9,10) then 'Q3'
      else 'Q4' end, "-"
  , case
      when month(opp.CloseDate) > 1 then (year(opp.CloseDate) + 1)
      else year(opp.CloseDate) end) as Fiscal_Quarter
  , opp.CPQ_Incremental_Booking_ARR__c
  , ifnull(opp_line.Incremental_Booking_Total_Fcst__c, 0) as Incr_booking
  , CASE 
      WHEN ifnull(opp_line.Incremental_Booking_Total_Fcst__c, 0) < 0 THEN (ifnull(opp_line.Incremental_Booking_Total_Fcst__c, 0) + ifnull(opp_line.Renewal_Booking_Total_Fcst__c, 0))
      ELSE  ifnull(opp_line.Renewal_Booking_Total_Fcst__c, 0) 
    END as Renewal_booking
  , ifnull(opp.Amount, 0) as amount
  , ifnull(opp.Churn_Amount__c,0) as Churn_Amount__c
  , case
      when month(opp.CloseDate) in (2,3,4) then 'Q1'
      when month(opp.CloseDate) in (5,6,7) then 'Q2'
      when month(opp.CloseDate) in (8,9,10) then 'Q3'
      else 'Q4' end as fiscalQtr
  , case
      when month(opp.CloseDate) > 1 then concat('FY', substr((year(opp.CloseDate) + 1), 3, 2))
      else concat('FY', substr(year(opp.CloseDate), 3, 2)) end as fiscalYear
  , case 
      when opp.Platform_Type__c LIKE '%Azure%' then 'Azure'
      when opp.Platform_Type__c = 'Google Cloud' then 'GCP'
      when opp.Platform_Type__c = 'Private Cloud' then 'PVC'
      when LOWER(opp.Platform_Type__c) LIKE '%mosaic%' THEN 'MCT'
      else 'AWS'
    end as Platform
  , case 
          when opp.Platform_Type__c LIKE '%Azure%' then 'Azure'
          when LOWER(opp.Platform_Type__c) LIKE '%mosaic%' THEN 'MCT' 
          else 'Non-Azure'
        end as Platform_Simplified
  , case
      when opp.type = 'Pilot' then 'New Business'
      when opp.type = 'Renewal' then 'Upsell'
      else opp.type
    end as Type
  , opp_line.Product_Family__c
  , opp.StageName as Stage      
  , opp_line.Quantity as quantity
  , VP_Forecast__c as manager_forecast
  , UniversalCommitRollover__c as universal_commit_rollover
  , New_Logo_All__c as new_logo_all
  , Original_Expected_Renewal_Date__c as original_expected_renewal_date  
  , opp.Secondary_AE__c as secondary_ae_id
  , opp.P3_Click_Amount__c as p3_click_amount
  , opp.P3_Click_Date__c as p3_click_date
  , opp.P3_Executed__c as p3_executed
  , opp.Split_Percentage__c as split_percentage
  , opp.PrimaryOwnerSplit__c as primary_owner_split
  , opp.Secondary_AE_2__c as secondary_ae_2
  , opp.Split_Percentage_2__c as split_percentage_2  
  , opp.Debook__c as debook
  , acc.Business_Unit__c

FROM main.sfdc_bronze.opportunitylineitem opp_line
  INNER join main.sfdc_bronze.opportunity opp
    ON opp_line.opportunityId = opp.id

LEFT JOIN  main.sfdc_bronze.account acc
  ON opp.accountid = acc.AccountID_CaseSafe__c

LEFT JOIN main.sfdc_bronze.product2 prodid
  ON opp_line.product2id = prodid.id

WHERE 
 opp.processDate = (select max(processDate) from main.sfdc_bronze.opportunity) AND 
 opp_line.processDate = (select max(processDate) from main.sfdc_bronze.opportunitylineitem ) AND 
 acc.processDate = (SELECT MAX(processDate) from main.sfdc_bronze.account) AND
 prodid.processDate = (select max(processDate) from main.sfdc_bronze.product2) AND

 opp.Type IN ("Azure P3-Only") AND 
 opp.StageName NOT in ('Closed Lost','Disqualified') AND
 opp_line.Renewal_Booking_Total_Fcst__c IS NOT NULL AND
 opp_line.Renewal_Booking_Total_Fcst__c != 0 AND
 Debook__c = False AND 
 opp_line.isDeleted = False AND
 opp.isDeleted = False
  

""" )

booking_p3_renewals.createOrReplaceTempView('booking_p3_renewals')

# COMMAND ----------

# DBTITLE 1,Unified Bookings Query Analysis
bookings_all= spark.sql (''' 
                         
SELECT 
                         
    id	,
    Opportunity_Id	,
    Opportunity_Line_Item_ID__c	,
    primary_quote	,
    line_item_name	,
    Opportunity_Name	,
    type_raw	,
    Account_ID	,
    Account_Name	,
    product_name	,
    Opportunity_Owner_ID	,
    Close_Date	,
    Renewal_Date,
    Renewal_Date_UPD ,
    Close_Month	,
    Start_Date	,
    End_Date	,
    CreatedDate	,
    Prospecting_Stage_Date_Stamp__c	,
    Proposal_Stage_Date_Stamp__c	,
    Negotiation_Stage_Date_Stamp__c	,
    term_non_cpq	,
    term_cpq	,
    Billing_Schedule__c	,
    opportunity_currency	,
    ListPrice	,
    salesPrice	,
    TotalPrice	,
    Term_Num__c	,
    Cloud_Type__c	,
    Total_Contract_Value__c	,
    TCV__c	,
    opp_tcv	,
    Fiscal_Quarter	,
    CPQ_Incremental_Booking_ARR__c	,
    Incr_booking	,
    Renewal_booking	,
    Incr_booking as booking_amount,
    amount	,
    Churn_Amount__c churn_amount,
    fiscalQtr	,
    fiscalYear	,
    Platform	,
    Platform_Simplified ,
    Type	,
    Product_Family__c	,
    Stage	,
    quantity	,
    manager_forecast	,
    universal_commit_rollover	,
    new_logo_all	,
    original_expected_renewal_date	,
    secondary_ae_id	,
    p3_click_amount	,
    p3_click_date	,
    p3_executed	,
    split_percentage	,
    primary_owner_split	,
    secondary_ae_2	,
    split_percentage_2	,
    debook	,
    'Incremental Booking ARR' as label ,
    Business_Unit__c

    FROM booking_commit

UNION ALL

SELECT 

    id	,
    Opportunity_Id	,
    Opportunity_Line_Item_ID__c	,
    primary_quote	,
    line_item_name	,
    Opportunity_Name	,
    type_raw	,
    Account_ID	,
    Account_Name	,
    product_name	,
    Opportunity_Owner_ID	,
    Close_Date	,
    Renewal_Date,
    Renewal_Date_UPD ,
    Close_Month	,
    Start_Date	,
    End_Date	,
    CreatedDate	,
    Prospecting_Stage_Date_Stamp__c	,
    Proposal_Stage_Date_Stamp__c	,
    Negotiation_Stage_Date_Stamp__c	,
    term_non_cpq	,
    term_cpq	,
    Billing_Schedule__c	,
    opportunity_currency	,
    ListPrice	,
    salesPrice	,
    TotalPrice	,
    Term_Num__c	,
    Cloud_Type__c	,
    Total_Contract_Value__c	,
    TCV__c	,
    opp_tcv	,
    Fiscal_Quarter	,
    CPQ_Incremental_Booking_ARR__c	,
    Incr_booking	,
    Renewal_booking	,
    coalesce(Renewal_booking ,0) as booking_amount,
    amount	,
    Churn_Amount__c churn_amount,
    fiscalQtr	,
    fiscalYear	,
    Platform	,
    Platform_Simplified ,
    Type	,
    Product_Family__c	,
    Stage	,
    quantity	,
    manager_forecast	,
    universal_commit_rollover	,
    new_logo_all	,
    original_expected_renewal_date	,
    secondary_ae_id	,
    p3_click_amount	,
    p3_click_date	,
    p3_executed	,
    split_percentage	,
    primary_owner_split	,
    secondary_ae_2	,
    split_percentage_2	,
    debook	,
    'Renewal ARR (non PS)' as label ,
    Business_Unit__c

    FROM booking_renewals  

UNION ALL

SELECT 
    id	,
    Opportunity_Id	,
    Opportunity_Line_Item_ID__c	,
    primary_quote	,
    line_item_name	,
    Opportunity_Name	,
    type_raw	,
    Account_ID	,
    Account_Name	,
    product_name	,
    Opportunity_Owner_ID	,
    Close_Date	,
    Renewal_Date,
    Renewal_Date_UPD ,
    Close_Month	,
    Start_Date	,
    End_Date	,
    CreatedDate	,
    Prospecting_Stage_Date_Stamp__c	,
    Proposal_Stage_Date_Stamp__c	,
    Negotiation_Stage_Date_Stamp__c	,
    term_non_cpq	,
    term_cpq	,
    Billing_Schedule__c	,
    opportunity_currency	,
    ListPrice	,
    salesPrice	,
    TotalPrice	,
    Term_Num__c	,
    Cloud_Type__c	,
    Total_Contract_Value__c	,
    TCV__c	,
    opp_tcv	,
    Fiscal_Quarter	,
    CPQ_Incremental_Booking_ARR__c	,
    Incr_booking	,
    Renewal_booking	,
    coalesce(Renewal_booking ,0) + coalesce(Incr_booking,0) as booking_amount,
    amount	,
    Churn_Amount__c churn_amount,
    fiscalQtr	,
    fiscalYear	,
    Platform	,
    Platform_Simplified ,
    Type	,
    Product_Family__c	,
    Stage	,
    quantity	,
    manager_forecast	,
    universal_commit_rollover	,
    new_logo_all	,
    original_expected_renewal_date	,
    secondary_ae_id	,
    p3_click_amount	,
    p3_click_date	,
    p3_executed	,
    split_percentage	,
    primary_owner_split	,
    secondary_ae_2	,
    split_percentage_2	,
    debook	,
    'Services Bookings' as label ,
    Business_Unit__c

FROM booking_services

UNION ALL

SELECT 

    id	,
    Opportunity_Id	,
    Opportunity_Line_Item_ID__c	,
    primary_quote	,
    line_item_name	,
    Opportunity_Name	,
    type_raw	,
    Account_ID	,
    Account_Name	,
    product_name	,
    Opportunity_Owner_ID	,
    Close_Date	,
    Renewal_Date,
    Renewal_Date_UPD,
    Close_Month	,
    Start_Date	,
    End_Date	,
    CreatedDate	,
    Prospecting_Stage_Date_Stamp__c	,
    Proposal_Stage_Date_Stamp__c	,
    Negotiation_Stage_Date_Stamp__c	,
    term_non_cpq	,
    term_cpq	,
    Billing_Schedule__c	,
    opportunity_currency	,
    ListPrice	,
    salesPrice	,
    TotalPrice	,
    Term_Num__c	,
    Cloud_Type__c	,
    Total_Contract_Value__c	,
    TCV__c	,
    opp_tcv	,
    Fiscal_Quarter	,
    CPQ_Incremental_Booking_ARR__c	,
    Incr_booking	,
    Renewal_booking	,
    coalesce(Renewal_booking ,0) + coalesce(Incr_booking,0) as booking_amount,
    amount	,
    Churn_Amount__c churn_amount,
    fiscalQtr	,
    fiscalYear	,
    Platform	,
    Platform_Simplified ,
    Type	,
    Product_Family__c	,
    Stage	,
    quantity	,
    manager_forecast	,
    universal_commit_rollover	,
    new_logo_all	,
    original_expected_renewal_date	,
    secondary_ae_id	,
    p3_click_amount	,
    p3_click_date	,
    p3_executed	,
    split_percentage	,
    primary_owner_split	,
    secondary_ae_2	,
    split_percentage_2	,
    debook	,
    'Renewal ARR (non PS)' as label ,
    Business_Unit__c

    FROM booking_p3_renewals
    

''')

bookings_all.createOrReplaceTempView('bookings_all')

# COMMAND ----------

# DBTITLE 1,Opportunity Bookings Line Detail Query
opp_bookings_line_details_pre = spark.sql( '''
select  
id	,
Opportunity_Id	,
Opportunity_Line_Item_ID__c 	,
primary_quote Primary_Quote	,
line_item_name Line_Item_Name	,
Opportunity_Name	,
type_raw	Type_Raw,
Account_ID	,
Account_Name	,
product_name	 Product_Name,
Opportunity_Owner_ID	,
Close_Date	,
Renewal_Date    ,
Renewal_Date_UPD ,
Close_Month	,
Start_Date	,
End_Date	,
CreatedDate	,
Prospecting_Stage_Date_Stamp__c	,
Proposal_Stage_Date_Stamp__c	,
Negotiation_Stage_Date_Stamp__c	,
Term_Non_Cpq	,
Term_Cpq	,
Billing_Schedule__c	,
Opportunity_Currency	,
ListPrice	,
salesPrice	,
TotalPrice	,
Term_Num__c	,
Cloud_Type__c	,
Total_Contract_Value__c	,
TCV__c	,
Opp_Tcv	,
Fiscal_Quarter	,
CPQ_Incremental_Booking_ARR__c	,
Incr_booking	,
Renewal_booking	,
booking_amount,
Churn_Amount,

case when a.label = "Renewal ARR (non PS)" and round(12*date_diff(a.end_date, a.start_date)/365, 1) < 12 
        then round(12*date_diff(a.end_date, a.start_date)/365, 1)/12 * a.booking_amount 
        else a.booking_amount end as Final_Booking_Amount,

case when a.label = "Renewal ARR (non PS)" 
        and round(12*date_diff(a.end_date, a.start_date)/365, 1) < 12 
        and (Incr_booking >= 0 OR Incr_booking IS NULL)
                then round(12*date_diff(a.end_date, a.start_date)/365, 1)/12 * (a.renewal_booking)
       when a.label = "Renewal ARR (non PS)" 
        and round(12*date_diff(a.end_date, a.start_date)/365, 1) < 12 
        and Incr_booking < 0
                then round(12*date_diff(a.end_date, a.start_date)/365, 1)/12 * (a.renewal_booking + a.incr_booking)
        else (a.renewal_booking) end as Final_Renewal_Booking,

Amount	,
FiscalQtr	,
FiscalYear	,
Platform	,
Platform_Simplified ,
Type	,
Product_Family__c	,
Stage	,
Quantity	,
Manager_Forecast	,
Universal_Commit_Rollover	,
New_Logo_All	,
Original_Expected_Renewal_Date	,
Secondary_Ae_Id	,
P3_Click_Amount	,
P3_Click_date	,
P3_Executed	,
Split_Percentage	,
Primary_Owner_Split	,
Secondary_Ae_2	,
Split_Percentage_2	,
Debook	,
Label ,
Business_Unit__c
from bookings_all  a
where lower(Opportunity_Name) not  like '%anysphere%invoice%'

 ''')


opp_bookings_line_details_pre.createOrReplaceTempView ('opp_bookings_line_details_pre')

# COMMAND ----------

opp_bookings_line_details, processDate = add_audit_attributes(opp_bookings_line_details_pre)

# COMMAND ----------

print(full_table_name)

# COMMAND ----------

# DBTITLE 1,Delta Table Overwrite Scheduler
date_str = processDate.strftime('%Y-%m-%d')

print (f'Updating data in {full_table_name} for {processDate}')
(opp_bookings_line_details
  .write
  .mode('overwrite')
  .format('delta')
  #.option('overwriteSchema', 'true')
  .option("mergeSchema", "true")
  .option('replaceWhere', f"process_date = '{date_str}'")
  .partitionBy("process_date")
  .saveAsTable(full_table_name))
