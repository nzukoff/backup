# Databricks notebook source
from dataclasses import dataclass
import requests
from datetime import datetime
from pyspark.sql import DataFrame
from typing import Optional, Sequence as Seq, Tuple
import logging
from it_data_lib import make_sql, configure_logging, get_log_levels, table_exists

# COMMAND ----------

@dataclass(frozen=True)
class Config:
  name: str
  uc_catalog: str
  uc_schema: str

# COMMAND ----------

PRODUCTION_SCHEMA = Config("prod", "main", "it_data_insights")
DEVELOPMENT_SCHEMA = Config("dev", "integration", "it_data_insights")
CONFIGS = dict(
  ( cfg.name, cfg) for cfg in [PRODUCTION_SCHEMA, DEVELOPMENT_SCHEMA]
)

# COMMAND ----------

def config_keys():
  return (list(CONFIGS),'dev')
def get_configuration(name):
  try:
    return CONFIGS[name]
  except KeyError:
    raise ValueError(f"Invalid configuration name: {name}")

# COMMAND ----------

def get_process_date() -> datetime.date:
  """
  Get the process date (which is added as a metadata column to all bronze, silver, and gold tables.)
  """
  return datetime.utcnow().date()

# COMMAND ----------

logger = configure_logging('INFO')
