# Databricks notebook source
# MAGIC %run "./Config-Defs"

# COMMAND ----------

import it_data_lib
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime, date
import requests
from pprint import pprint
from typing import Any, Optional
import uuid
import json
import pandas as pd
import logging
import re

# COMMAND ----------

from dataclasses import dataclass
import requests
from datetime import datetime
from pyspark.sql import DataFrame
from typing import Optional, Sequence as Seq, Tuple
import logging
from it_data_lib import make_sql, configure_logging, get_log_levels, table_exists

# COMMAND ----------

configuration_keys, default_key = config_keys()
dbutils.widgets.dropdown(
    name="configuration",
    label="Configuration",
    choices=configuration_keys,
    defaultValue=default_key
)
env = dbutils.widgets.get("configuration")
TARGET_CATALOG = get_configuration(env).uc_catalog
TARGET_SCHEMA = get_configuration(env).uc_schema
print(TARGET_CATALOG,TARGET_SCHEMA)

# COMMAND ----------

logger = configure_logging('INFO')

# COMMAND ----------

METADATA_PROCESS_DATE_COLUMN = 'processDate' 

# COMMAND ----------

def add_gold_metadata(df: DataFrame, process_date: Optional[date] = None) -> DataFrame:
    """
    Add desired gold metadata to a DataFrame, prior to writing it
    to the Delta gold table.

    Returns a (DataFrame, processDate) tuple
    """
    now = process_date or get_process_date()
    df2 = df.withColumn(METADATA_PROCESS_DATE_COLUMN, lit(now))
    return (df2, now)

# COMMAND ----------

spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

# COMMAND ----------


def update_gold_table(table_name: str, source_df: DataFrame, process_date: Optional[date] = None) -> None:
    """
    Take a source DataFrame containing new data for a gold table, and
    update the gold table. This function assumes the gold table already exists.

    Parameters:

    table_name:   The name of the (Delta) table to create or update
    source_df:    DataFrame with source data
    process_date: Optional date to override the process date (which defaults to today)
    """
    full_table_name =  f"{TARGET_CATALOG}.{TARGET_SCHEMA}.{table_name}"#f"{users}.dhananjay_gavade.{table_name}"

    rows = source_df.count()
    logger.info(f"{rows:,} row(s) in update data set")
    if rows == 0:
        print(f'Skipping "{table_name}". New data has no rows.')
        return
    
    # Add metadata columns.
    final_df, process_date = add_gold_metadata(source_df, process_date)
    
    date_str = process_date.strftime("%Y-%m-%d")
    (
        final_df
            .write
            .format('delta')
            .mode('overwrite')
            .option('mergeSchema', 'true')
            .option('replaceWhere', f"{METADATA_PROCESS_DATE_COLUMN} = '{date_str}'")
            .saveAsTable(full_table_name)
    )
    logger.info(f"wrote {final_df.count()} rows to {full_table_name}")

# COMMAND ----------

def update_from_view(
    table_name: str,
    view_name: str,
    additional_views: Seq[str] = [],
    process_date: Optional[date] = None,
) -> None:
    """
    Given a view that contains new data, use the view to update the specified table. Then delete the view.
    Also deletes any additional views passed in.

    Parameters:

    table_name:       The name of the (Delta) table to create or update
    view_name:        Name of view with new data
    additional_views: Names of additional views you want to be deleted
    process_date:     Optional date to override the process date (which defaults to today)
    """
    try:
        logger.info(f"Updating {table_name} using data from view {view_name}")
        update_gold_table(
            table_name=table_name,
            source_df=spark.table(view_name),
            process_date=process_date,
        )
    finally:
        #for v in [view_name] + additional_views:
            #logger.debug(f"Dropping view {v}")
            #spark.catalog.dropTempView(v)
        pass

# COMMAND ----------

# Get dashboard details and the owner details
sql(f"""
CREATE OR REPLACE TEMP VIEW silver_dashboard_details AS
WITH dashboard_details AS 
( 
SELECT *, 
CASE WHEN creator = 'Unavailable'
THEN CASE WHEN owner = "Unavailable"
     THEN 
        CASE WHEN managed_by[0] != 'admins' 
        THEN managed_by[0]
        ELSE
        managed_by[1]
        END
     ELSE 
     owner
     END
ELSE
creator
END 
AS dashboard_owner 
from data_df_misc.central_logfood_dashboards_latest),

workday_cost_center AS (
  SELECT 
        a.name,
        a.email,
        m.email as manager_email,
        effective_date,
        location,
        job_profile,
        business_title,
        cost_center
    FROM  
    main.workday.active_workers a 
    LEFT JOIN 
    (SELECT name, email, workday_id FROM main.workday.active_workers 
    WHERE effective_date =  (SELECT max(effective_date) FROM main.workday.active_workers)
    ) m
    on a.manager_workday_id = m.workday_id
    WHERE effective_date = (SELECT max(effective_date) FROM main.workday.active_workers)
    
 
)
SELECT d.*, w.manager_email, w.cost_center FROM dashboard_details d JOIN workday_cost_center w ON d.dashboard_owner = w.email
"""
)

# COMMAND ----------

# Dashboard usage log mapped to dashboard and dashboard owner details
sql(f"""
CREATE OR REPLACE TEMP VIEW silver_dashboard_stats AS
WITH dashboard_id_title_map AS 
(
select DISTINCT title,id, dashboard_owner,manager_email, version from silver_dashboard_details 
   WHERE (cost_center = '151 Business Applications' or cost_center like '%IT%')
),
metric_usage_stats AS (
  SELECT 
  tags.assetId AS id,
  pseudoUserId,
  eventTime
  FROM 
  main.data_usage_log.stream 
  WHERE metric = 'assetView'
  AND date >= DATE_ADD(CURRENT_DATE(), -366)
  AND tags.assetType = 'DASHBOARD_V3'
)
SELECT 
title,
m.id,
dashboard_owner,
manager_email,
version,
m.pseudoUserId,
eventTime
FROM dashboard_id_title_map d
JOIN
metric_usage_stats m
ON d.id = m.id
""")



# COMMAND ----------

# Dashboard daily, weekly, monthly and 90 days usage summary
sql(f"""
CREATE OR REPLACE TEMP VIEW silver_dashboard_daily_monthly_stats AS
WITH dashboard_id_title_map AS 
(
select DISTINCT title,id, dashboard_owner, manager_email, version from silver_dashboard_details WHERE (cost_center = '151 Business Applications' or cost_center like '%IT%')
),
metric_usage_stats_90d AS (
SELECT 
tags.assetId AS id,
COUNT(*) AS t90_views,
COUNT(DISTINCT pseudoUserId) AS t90_users
FROM 
main.data_usage_log.stream s
WHERE metric = 'assetView'
AND date >= DATE_ADD(CURRENT_DATE(), -89)
AND tags.assetType = 'DASHBOARD_V3'

GROUP BY 1

),
metric_usage_stats_weekly AS (
SELECT 
    tags.assetId AS id,
    COUNT(*) AS weekly_views,
    COUNT(DISTINCT pseudoUserId) AS wau -- Weekly Active Users
FROM 
    main.data_usage_log.stream s
WHERE 
    metric = 'assetView'
    AND date BETWEEN DATE_SUB(CURRENT_DATE(), DAYOFWEEK(CURRENT_DATE()) + 6) 
                  AND DATE_SUB(CURRENT_DATE(), DAYOFWEEK(CURRENT_DATE()))
    AND tags.assetType = 'DASHBOARD_V3'
GROUP BY 
    1
),
metric_usage_stats_monthly AS (
SELECT 
tags.assetId AS id,
COUNT(*) AS monthly_views,
COUNT(DISTINCT pseudoUserId) AS mau
FROM 
main.data_usage_log.stream s
WHERE metric = 'assetView'
AND date >= DATE_ADD(CURRENT_DATE(), -29)
AND tags.assetType = 'DASHBOARD_V3'

GROUP BY 1

),
metric_usage_stats_daily AS (
SELECT 
tags.assetId AS id,
COUNT(*) AS daily_views,
COUNT(DISTINCT pseudoUserId) AS dau
FROM 
main.data_usage_log.stream s
WHERE metric = 'assetView'
AND date >= DATE_ADD(CURRENT_DATE(), -1)
AND tags.assetType = 'DASHBOARD_V3'

GROUP BY 1

),
metric_usage_stats_previous_day_daily AS (
  SELECT 
tags.assetId AS id,
COUNT(*) AS prev_daily_views,
COUNT(DISTINCT pseudoUserId) AS prev_dau
FROM 
main.data_usage_log.stream s
WHERE metric = 'assetView'
AND date = DATE_ADD(CURRENT_DATE(), -3)
AND tags.assetType = 'DASHBOARD_V3'

GROUP BY 1
)
SELECT title, st.id, version, dashboard_owner, manager_email, monthly_views, daily_views, weekly_views, mau, wau, dau, prev_daily_views, prev_dau, t90_views, t90_users FROM dashboard_id_title_map dash
LEFT JOIN
metric_usage_stats_monthly st 
on
st.id = dash.id
LEFT JOIN
metric_usage_stats_daily da on
dash.id = da.id
LEFT JOIN
metric_usage_stats_previous_day_daily dap on
dash.id = dap.id
LEFT JOIN
metric_usage_stats_weekly w on
dash.id = w.id
LEFT JOIN metric_usage_stats_90d nt on
dash.id = nt.id
""")



# COMMAND ----------

# Dashboard action log mapped to dashboard and dashboard owner detail
sql(f"""
CREATE OR REPLACE TEMP VIEW dashboard_action_details_view AS
WITH it_dashboards AS (
  SELECT a.*, d.id, d.title, d.dashboard_owner, d.manager_email FROM  `system`.access.audit  a
JOIN
(SELECT * FROM silver_dashboard_details WHERE (cost_center = '151 Business Applications' or cost_center like '%IT%')
) d
ON
a.request_params.dashboard_id = d.id
)

SELECT a.id,a.title, user_identity.email, a.dashboard_owner, a.manager_email, d.cost_center, action_name,event_time,event_date,  month(event_date) AS event_month,
year(event_date) AS event_year, 
day(event_date) AS event_day FROM (
  SELECT * FROM  it_dashboards) a
JOIN
main.workday.active_workers d
ON
a.user_identity.email = d.email
""")

# COMMAND ----------

sql(f"""
CREATE TABLE IF NOT EXISTS {TARGET_CATALOG}.{TARGET_SCHEMA}.it_dashboard_daily_monthly_stats
(
  title STRING COMMENT "Dashboard title",
  id STRING COMMENT "Id of the dashboard",
  dashboard_owner STRING COMMENT "Dashboard owner email",
  manager_email STRING COMMENT "Dashboard owner manager email",
  Version STRING COMMENT "Dashboard Version
  Valid Values:
  'legacy',
  'lakeview'",
  monthly_views LONG COMMENT "Dashboard views for last 30 days",
  daily_views LONG COMMENT "Dashboard view count for past day",
  weekly_views LONG COMMENT "Dashboard view count for previous week",
  mau LONG COMMENT "Dashboard active users for last 30 days",
  wau LONG COMMENT "Dashboard active users for previous week",
  dau LONG COMMENT "Dashboard active users for past day",
  prev_daily_views LONG "Last daily view count",
  prev_dau LONG "Last daily active users count",
  t90_views LONG "90 days view count",
  t90_users LONG "90 days active users count",
  processDate date "The date this record was processed"
)
COMMENT "IT dashboard daily and monthly stats"
PARTITIONED BY (processDate)
""")

# COMMAND ----------

sql(f"""
CREATE TABLE IF NOT EXISTS {TARGET_CATALOG}.{TARGET_SCHEMA}.it_dashboard_stats
(
  title STRING COMMENT "Dashboard title",
  id STRING COMMENT "Dashboard id",
  dashboard_owner STRING COMMENT "Dashboard owner email",
  manager_email STRING COMMENT "Dashboard owner manager email",
  Version STRING COMMENT "Dashboard Version
  Valid Values:
  'legacy',
  'lakeview'",
  pseudoUserId STRING COMMENT "Unique pseudo user id",
eventTime TIMESTAMP COMMENT "Activity time",
  processDate date COMMENT "The date this record was processed"
)
COMMENT "IT dashboard daily and monthly stats"
PARTITIONED BY (processDate)
""")

# COMMAND ----------

sql(f"""
    CREATE TABLE IF NOT EXISTS {TARGET_CATALOG}.{TARGET_SCHEMA}.it_dashboards_action_details
    (
      id STRING COMMENT "Dashboard id",
      title STRING COMMENT "Dashboard title",
      email STRING COMMENT "Dashboard user email",
      dashboard_owner STRING COMMENT "Dashboard owner email",
      manager_email STRING COMMENT "Dashboard owner manager email",
      cost_center STRING COMMENT "User Cost Center",
      action_name STRING COMMENT "User action name",
      event_time TIMESTAMP "Time of the activity",
      event_date date "Date of the activity",
      event_month INT "Month of the activity",
      event_year INT "Year of the activity",
      event_day INT "Day of the activity",
      processDate date "The date this record was processed"

    )
    COMMENT 'IT Dashboard query stats'
    PARTITIONED BY (processDate) 
     """)

# COMMAND ----------

update_from_view(table_name="it_dashboard_daily_monthly_stats", view_name="silver_dashboard_daily_monthly_stats")

# COMMAND ----------

update_from_view(table_name="it_dashboard_stats", view_name="silver_dashboard_stats")

# COMMAND ----------

update_from_view(table_name="it_dashboards_action_details", view_name="dashboard_action_details_view")
