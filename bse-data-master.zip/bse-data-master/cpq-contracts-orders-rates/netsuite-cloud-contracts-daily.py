# Databricks notebook source
dbutils.widgets.text("environment", 'integration') # development, integration, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'production':
  print("Environment: Production")
  SOURCE_CATALOG = 'main'

  TARGET_CATALOG = 'main'
  TARGET_SCHEMA = 'it_finance_silver'
elif environment == 'soxdev':
  print("Environment: Sox Dev")
  SOURCE_CATALOG = 'integration'

  TARGET_CATALOG = 'integration'
  TARGET_SCHEMA = 'it_cpq_silver'
else: 
  print("Environment: Integration/UAT")
  SOURCE_CATALOG = 'main'

  TARGET_CATALOG = 'integration'
  TARGET_SCHEMA = 'it_finance_silver'
print(f'Using {SOURCE_CATALOG}')
#spark.sql(f"use catalog {SOURCE_CATALOG}")

# COMMAND ----------


def update_zab_workspaces_mapping():
       zab_workspaces_mapping = spark.sql(f"""
       with base(
       select distinct 
              zab_subscription_name,
              cast(sub_start_date as date) sub_start_date,
              cast(sub_end_date as date) sub_end_date
       from {TARGET_CATALOG}.{TARGET_SCHEMA}.zabsubscription_salesorders
       ),

       workspace_subs (

       select concat(wk.name, '-', cast(wksub.subscription_id as long))  workspace_subscription_external_id,
              wksub.subscription_id 
       from {SOURCE_CATALOG}.it_finance_silver.netsuite_workspaces wk
       join {SOURCE_CATALOG}.it_finance_silver.netsuite_workspace_subscriptions wksub on --wk.subscription_id = wksub.subscription_id and
                                                        wk.workspace_id = wksub.workspace_id 
                                                        and wk.processDate = wksub.processDate
       where wk.processDate = (select max(processDate) from {SOURCE_CATALOG}.it_finance_silver.netsuite_workspaces)
       and wksub.workspace_subscription_external_id is null

       union

       select workspace_subscription_external_id,
              subscription_id 
       from {SOURCE_CATALOG}.it_finance_silver.netsuite_workspace_subscriptions wksub 
       where wksub.processDate = (select max(processDate) from {SOURCE_CATALOG}.it_finance_silver.netsuite_workspace_subscriptions)
       and wksub.workspace_subscription_external_id is not null
       ),

       zab_wk_mapping (
       select distinct subscription_name zab_subscription, 
                     wksub.workspace_subscription_external_id workspaceId_raw,
                     split(workspace_subscription_external_id, '-')[0] workspaceId
       from {SOURCE_CATALOG}.it_finance_silver.netsuite_subscriptions sub
       join workspace_subs wksub on sub.subscription_id = wksub.subscription_id
       where sub.processDate = (select max(processDate) from {SOURCE_CATALOG}.it_finance_silver.netsuite_subscriptions)
       order by 1
       )
       select zab.*,
              sub_start_date,
              sub_end_date
       from zab_wk_mapping zab
       left join base b on zab.zab_subscription = b.zab_subscription_name
       """)

       #zab_workspaces_mapping.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/test_zab_workspace_mapping")
       zab_workspaces_mapping.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(f"{TARGET_CATALOG}.{TARGET_SCHEMA}.zab_worspace_mapping")

# COMMAND ----------

update_flag = 0

# COMMAND ----------

if spark.catalog.tableExists(f"{TARGET_CATALOG}.{TARGET_SCHEMA}.zabsubscription_salesorders"):
  update_zab_workspaces_mapping()
else:
  update_flag = 1

# COMMAND ----------

# %sql
# create or replace table main.it_finance_silver.zab_worspace_mapping
# as select * from delta.`/mnt/bse-dev/test_zab_workspace_mapping`

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

rawSalesOrders = spark.sql(f"""
with orderTypes as (
  select distinct id, name
  from {SOURCE_CATALOG}.netsuite2_bronze_hourly.customlist_order_type_list
  where processTimestamp = (
    select max(processTimestamp)
    from {SOURCE_CATALOG}.netsuite2_bronze_hourly.customlist_order_type_list
  )
),

NSSFDCAccounts as (
  select distinct c.id as customer_id, c.custentity_sfdc_account_id, ct.name as customer_type
  from {SOURCE_CATALOG}.netsuite2_bronze_hourly.customer c
  left join {SOURCE_CATALOG}.netsuite2_bronze_hourly.customercategory ct
    on c.category = ct.id
    and c.processTimestamp = ct.processTimestamp
  where c.processTimestamp = (
    select max(processTimestamp)
    from {SOURCE_CATALOG}.netsuite2_bronze_hourly.customer
  )
  and c.custentity_sfdc_account_id is not null
),

statusMap as (
  select id, name, trantype, processTimestamp
  from main.netsuite2_bronze_hourly.transactionstatus
  where processTimestamp = (
    select max(processTimestamp)
    from main.netsuite2_bronze_hourly.transactionstatus
  )
),

prev_link AS (
  SELECT previousdoc, nextdoc 
  FROM main.netsuite2_bronze_hourly.previoustransactionlink
  WHERE processTimestamp = (
    SELECT MAX(processTimestamp)
    FROM main.netsuite2_bronze_hourly.previoustransactionlink
  )
),

next_link AS (
  SELECT previousdoc, nextdoc, linktype  
  FROM main.netsuite2_bronze_hourly.nexttransactionlink
  -- WHERE linktype = 'SalesOrd'
  WHERE processTimestamp = (
    SELECT MAX(processTimestamp)
    FROM main.netsuite2_bronze_hourly.nexttransactionlink
  )
)

select
  nsf.custentity_sfdc_account_id as sfdc_account_id,
  CAST(nsf.customer_id AS double),
  nsf.customer_type,
  ns.custbody_so_subscription as zab_subscription,
  ns.tranid,
  case when substr(ns.tranid, 1, 2) != 'SO' then ns.tranid
       else substr(ns.tranid, 3)
  end as SalesOrder,
  ot.name as OrderType,
  ns.transactionnumber AS transaction_number,
  CAST(ns.id AS double) as lineitem_id,
  ns.trandate AS TRANDATE,
  ns.startdate AS start_date,
  ns.enddate AS end_date,
  CAST(pl.previousdoc AS double) as supersedes_order_id,
  CAST(nl.nextdoc AS double) as superseded_by_id,
  ts.name as status,
  ns.prevdate AS sales_effective_date,
  ns.createddate as create_date,
  ns.custbody_company_name_sourced as company_name_sourced,
  ns.custbody_multiyear as multiyear,
  ns.custbody_multicloud_so as multicloud,
  ns.custbody_sub_internal_id as zab_subscription_internal_id
from main.netsuite2_bronze_hourly.transaction ns
left join orderTypes ot on ns.custbody_order_type = ot.id
left join NSSFDCAccounts nsf on ns.entity = nsf.customer_id
left join statusMap ts on ns.status = ts.id and ns.type = ts.trantype
left join prev_link pl on pl.nextdoc = ns.id 
left join next_link nl on nl.previousdoc = ns.id AND nl.linktype = 'SalesOrd'
WHERE ns.type = 'SalesOrd'
AND ns.processTimestamp = (
  select max(processTimestamp)
  from main.netsuite2_bronze_hourly.transaction
)
""").dropDuplicates()

#rawSalesOrders.count() 
rawSalesOrders.createOrReplaceTempView("rawSalesOrders")

# COMMAND ----------

# add superseded order info
allSalesOrders = spark.sql(f"""
select orig1.*,
       orig2.SalesOrder SupersedesOrder,
       case when orig1.lineitem_id = orig3.supersedes_order_id then 1
            else 0
       end as is_superseded
from rawSalesOrders orig1
left join rawSalesOrders orig2 on orig1.supersedes_order_id = orig2.lineitem_id
left join rawSalesOrders orig3 on orig1.lineitem_id = orig3.supersedes_order_id
""")
allSalesOrders.createOrReplaceTempView("allSalesOrders")

# COMMAND ----------

@udf("string")
def cleanSKUItemName(skuItemName):
  
  if skuItemName is None:
    return skuItemName
  else:
    if ":" in skuItemName:
      return skuItemName.split(":")[1].strip()
    else:
      return skuItemName

spark.udf.register("cleanSKUItemName", cleanSKUItemName)

@udf("string")
def cleanSKUCategory(cleanSKUItemName):
  SKUS =   ["Enterprise All-purpose Compute", "Enterprise Jobs Compute", "Enterprise Jobs Light Compute",
            "Premium All-purpose Compute", "Premium Jobs Compute", "Premium Jobs Light Compute",
            "Standard All-purpose Compute", "Standard Jobs Compute", "Standard Jobs Light Compute",
            "Dedicated All-purpose Compute", "Dedicated Jobs Compute", "Dedicated Jobs Light Compute",
            "Standard SQL Compute", "Premium SQL Compute", "Enterprise SQL Compute"
            ]
  if cleanSKUItemName is None:
    return cleanSKUItemName
  else:
    cleanSKUCategory = "NA"
    if cleanSKUItemName in SKUS:
      cleanSKUCategory = "dbuSKU"
    else:
      if 'Commitment' in cleanSKUItemName:
        cleanSKUCategory = "Workloads Commitment"
      elif 'Support' in cleanSKUItemName:
        cleanSKUCategory = "Support"
      elif 'Platform Fee' in cleanSKUItemName:
        cleanSKUCategory = "Platform Fee"
      elif 'Professional Services' in cleanSKUItemName:
        cleanSKUCategory = "Professional Services"
      elif 'Time Discount'  in cleanSKUItemName:
        cleanSKUCategory = "OneTime Discount"
      else:
        cleanSKUCategory = cleanSKUItemName
  return cleanSKUCategory
spark.udf.register("cleanSKUCategory", cleanSKUCategory)

@udf("string")
def cleanSKUMapping(cleanSKUItemName):
  
  skuMap = {
             "Enterprise All-purpose Compute":"ENTERPRISE_ALL_PURPOSE_COMPUTE", 
             "Enterprise Jobs Compute": "ENTERPRISE_JOBS_COMPUTE", 
             "Enterprise Jobs Light Compute": "ENTERPRISE_JOBS_LIGHT_COMPUTE",
             "Premium All-purpose Compute": "PREMIUM_ALL_PURPOSE_COMPUTE", 
             "Premium Jobs Compute": "PREMIUM_JOBS_COMPUTE", 
             "Premium Jobs Light Compute": "PREMIUM_JOBS_LIGHT_COMPUTE",
             "Standard All-purpose Compute": "STANDARD_ALL_PURPOSE_COMPUTE", 
             "Standard Jobs Compute" : "STANDARD_JOBS_COMPUTE", 
             "Standard Jobs Light Compute" : "STANDARD_JOBS_LIGHT_COMPUTE",
             "Dedicated All-purpose Compute" : "DEDICATED_ALL_PURPOSE_COMPUTE", 
             "Dedicated Jobs Compute" : "DEDICATED_JOBS_COMPUTE", 
             "Dedicated Jobs Light Compute" : "DEDICATED_JOBS_LIGHT_COMPUTE",
             "Standard SQL Compute" : "STANDARD_SQL_COMPUTE", 
             "Premium SQL Compute" : "PREMIUM_SQL_COMPUTE", 
             "Enterprise SQL Compute" : "ENTERPRISE_SQL_COMPUTE"
          }
  
  if cleanSKUItemName in skuMap.keys():
    return skuMap[cleanSKUItemName]
  else:
    return cleanSKUItemName


@udf("string")
def memoSanitizer(memoSanitizer):
  if memoSanitizer is not None:
    import re  
    return re.sub('[^A-Za-z0-9]+', ' ', memoSanitizer).strip().lower()
  
  return memoSanitizer

@udf("string")  
def memoCategory(memoCategory):
  
  if memoCategory is None:
    memoCategory = []
  
  category = 'uncategorized'
  if 'year 1' in memoCategory:
    category = 'year-1'
  elif 'year 2' in memoCategory:
    category = 'year-2'
  elif 'year 3' in memoCategory:
    category = 'year-3'
  elif 'year 4' in memoCategory:
    category = 'year-4'
  elif 'year 5' in memoCategory:
    category = 'year-5'
  else:
    pass
  
  return category

# COMMAND ----------

allSalesOrderLineItems = spark.sql(f"""
WITH baseTransactionLines AS (
  SELECT
      tl.transaction                 AS transaction_id,
      tl.class                       AS class_id,
      tl.quantity                    AS item_count,
      tl.rate                        AS item_unit_price,
      tl.quantity                    AS quantity_picked,
      tl.item                        AS item_id,
      COALESCE(itm.displayname, itm.fullname) AS skuItemName,
      tl.memo                        AS memo,
      tai.amount                     AS amount,
      tl.netamount                   AS net_amount,
      tl.custcol_ava_gross_amount    AS gross_amount,
      tl.rate                        AS list_rate,
      tl.custcolzab_term_rate        AS term_rate,
      tl.custcolcustcoldb_startdate  AS term_start_date,
      tl.custcolcustcoldb_enddate    AS term_end_date,
      LOWER(cl.name)                 AS Cloud
  FROM main.netsuite2_bronze_hourly.transactionline tl
  LEFT JOIN main.netsuite2_bronze.item itm
    ON tl.item = itm.id
   AND itm.processDate = (SELECT MAX(processDate) FROM main.netsuite2_bronze.item)
  LEFT JOIN main.netsuite2_bronze_hourly.transactionaccountingline tai
    ON tai.transaction = tl.transaction
   AND tai.transactionline = tl.id
   AND tai.processTimestamp = (SELECT MAX(processTimestamp)
                               FROM main.netsuite2_bronze_hourly.transactionaccountingline)
  LEFT JOIN main.netsuite2_bronze_hourly.classification cl
    ON tl.class = cl.id
   AND cl.processTimestamp = (SELECT MAX(processTimestamp)
                              FROM main.netsuite2_bronze_hourly.classification)
  WHERE tl.processTimestamp = (SELECT MAX(processTimestamp)
                               FROM main.netsuite2_bronze_hourly.transactionline)
)
SELECT
  oso.*,
  btl.*
FROM allSalesOrders oso
JOIN baseTransactionLines btl
  ON oso.lineitem_id = btl.transaction_id
ORDER BY oso.SalesOrder, oso.sales_effective_date
""")

allSalesOrderLineItems = allSalesOrderLineItems.withColumn("cleanSKUItemName", cleanSKUItemName("skuItemName"))\
 .withColumn("cleanSKUCategory", cleanSKUCategory("cleanSKUItemName"))\
 .withColumn("memoSanitized", memoSanitizer("memo"))\
 .withColumn("memoCategory", memoCategory("memoSanitized"))\
 .withColumn("normalizedSKU", cleanSKUMapping("cleanSKUItemName"))\
 .drop("memoSanitized")

allSalesOrderLineItems.createOrReplaceTempView("allSalesOrderLineItems")

# COMMAND ----------

#allSalesOrderLineItems.write.option("overwriteSchema", "true").format("delta").mode("overwrite").save("/mnt/bse-dev/test_commit_order_bronze")

# COMMAND ----------

onlySalesOrderLineItems = allSalesOrderLineItems.filter(allSalesOrderLineItems.zab_subscription.isNull())
onlySalesOrderLineItems.createOrReplaceTempView("onlySalesOrderLineItems")

# COMMAND ----------

# DBTITLE 1,OnlySalesOrders
aws_contracts_only_sales_orders = spark.sql(f"""
WITH acc_line AS (
  SELECT
    al.transaction,
    al.transactionline,
    al.account,
    ROW_NUMBER() OVER (
      PARTITION BY al.transaction, al.transactionline
      ORDER BY al.processTimestamp DESC
    ) AS rn
  FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.transactionaccountingline al
  WHERE al.processTimestamp = (
    SELECT MAX(processTimestamp)
    FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.transactionaccountingline
  )
),
baseTransactionLines AS (
  SELECT
      tl.transaction                      AS transaction_id,
      al.account                          AS account_id,
      tl.quantity                         AS item_count,
      tl.rate                             AS item_unit_price,
      tl.quantity                         AS quantity_picked,
      tl.item                             AS item_id,
      itm.displayname                     AS skuItemName,
      tl.memo                             AS memo,
      tl.rateamount                       AS amount,         
      tl.netamount                        AS net_amount,
      tl.custcol_ava_gross_amount         AS gross_amount,
      tl.rate                             AS list_rate,
      tl.custcoldb_startdate              AS term_start_date
  FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.transactionline tl
  LEFT JOIN (SELECT transaction, transactionline, account
             FROM acc_line WHERE rn = 1) al
    ON al.transaction    = tl.transaction
   AND al.transactionline = tl.id
  LEFT JOIN {SOURCE_CATALOG}.netsuite2_bronze.item itm
    ON tl.item = itm.id
   AND itm.processDate = (
        SELECT MAX(processDate)
        FROM {SOURCE_CATALOG}.netsuite2_bronze.item
      )
  WHERE tl.processTimestamp = (
    SELECT MAX(processTimestamp)
    FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.transactionline
  )
)
SELECT
  oso.lineitem_id,
  oso.salesOrder,
  oso.sales_effective_date,
  btl.transaction_id AS btl_transaction_id,
  btl.account_id,
  btl.item_count,
  btl.item_unit_price,
  btl.quantity_picked,
  btl.item_id AS btl_item_id,
  btl.skuItemName,
  btl.memo,
  btl.amount,
  btl.net_amount,
  btl.gross_amount,
  btl.list_rate,
  btl.term_start_date
FROM onlySalesOrderLineItems oso
JOIN baseTransactionLines btl
  ON oso.lineitem_id = btl.transaction_id
""")

aws_contracts_only_sales_orders.createOrReplaceTempView("aws_only_sales_orders")

# COMMAND ----------

# DBTITLE 1,ZAB Subscriptions
zabSubscriptionOrders = allSalesOrders.filter(~allSalesOrders.zab_subscription.isNull())
#print(zabSubscriptionOrders.count())
zabSubscriptionOrders.createOrReplaceTempView("zabSubscriptionSalesOrders")

# COMMAND ----------

spark.sql(f"""
SELECT
  zs.custrecordzab_s_customer              AS customer_id,
  zs.name                                  AS zab_subscription_name,
  zs.id                                    AS zab_subscription_id,
  zs.custrecordzab_s_start_date            AS start_date,
  zs.custrecordzab_s_end_date              AS end_date,
  zs.custrecord_supersede_contract         AS supersede,
  zsi.name                                 AS zab_subscription_item_name,
  zsi.custrecordzab_si_overage_rate        AS overageusage_rate,
  zsi.custrecordzab_si_rate                AS rate,
  zsi.custrecordzab_si_included_units      AS included_units,
  zsi.custrecordzab_si_item_description    AS item_description,
  zsi.custrecordzab_si_class               AS class_id,
  cl.name                                  AS Cloud

FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.customrecordzab_subscription zs
LEFT JOIN {SOURCE_CATALOG}.netsuite2_bronze_hourly.customrecordzab_subscription_item zsi
  ON zsi.custrecordzab_si_subscription = zs.id
 AND zsi.processTimestamp = (
       SELECT MAX(processTimestamp)
       FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.customrecordzab_subscription_item
     )
LEFT JOIN {SOURCE_CATALOG}.netsuite2_bronze_hourly.classification cl
  ON zsi.custrecordzab_si_class = cl.id
 AND cl.processTimestamp = (
       SELECT MAX(processTimestamp)
       FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.classification
     )
WHERE zs.processTimestamp = (
  SELECT MAX(processTimestamp)
  FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.customrecordzab_subscription
)
""").createOrReplaceTempView("subscriptions")

# COMMAND ----------

@udf("string")
def zabCleanItemName(skuItemName):
  
  if skuItemName is None:
    return skuItemName
  else:
    if "(" in skuItemName:
      return skuItemName.split("(")[0].strip()
    else:
      return skuItemName

  

@udf("string")
def zabCleanSKUCategory(cleanSKUItemName):
  SKUS =   [
            "Enterprise All-purpose Compute", "Enterprise Jobs Compute", "Enterprise Jobs Light Compute",
            "Premium All-purpose Compute", "Premium Jobs Compute", "Premium Jobs Light Compute",
            "Standard All-purpose Compute", "Standard Jobs Compute", "Standard Jobs Light Compute",
            "Dedicated All-purpose Compute", "Dedicated Jobs Compute", "Dedicated Jobs Light Compute",
            "Standard SQL Compute", "Premium SQL Compute", "Enterprise SQL Compute",

            "AWS Enterprise All-purpose Compute", "AWS Enterprise Jobs Compute", "AWS Enterprise Jobs Light Compute",
            "AWS Premium All-purpose Compute", "AWS Premium Jobs Compute", "AWS Premium Jobs Light Compute",
            "AWS Standard All-purpose Compute", "AWS Standard Jobs Compute", "AWS Standard Jobs Light Compute",
            "AWS Dedicated All-purpose Compute", "AWS Dedicated Jobs Compute", "AWS Dedicated Jobs Light Compute",
            "AWS Standard SQL Compute", "AWS Premium SQL Compute", "AWS Enterprise SQL Compute",
    
            "GCP Enterprise All-purpose Compute", "GCP Enterprise Jobs Compute", "GCP Enterprise Jobs Light Compute",
            "GCP Premium All-purpose Compute", "GCP Premium Jobs Compute", "GCP Premium Jobs Light Compute",
            "GCP Standard All-purpose Compute", "GCP Standard Jobs Compute", "GCP Standard Jobs Light Compute",
            "GCP Dedicated All-purpose Compute", "GCP Dedicated Jobs Compute", "GCP Dedicated Jobs Light Compute",
            "GCP Standard SQL Compute", "GCP Premium SQL Compute", "GCP Enterprise SQL Compute",
    
            "PAYG Enterprise All-purpose Compute", "PAYG Enterprise Jobs Compute", "PAYG Enterprise Jobs Light Compute",
            "PAYG Premium All-purpose Compute", "PAYG Premium Jobs Compute", "PAYG Premium Jobs Light Compute",
            "PAYG Standard All-purpose Compute", "PAYG Standard Jobs Compute", "PAYG Standard Jobs Light Compute",
            "PAYG Dedicated All-purpose Compute", "PAYG Dedicated Jobs Compute", "PAYG Dedicated Jobs Light Compute",
            "PAYG Standard SQL Compute", "PAYG Premium SQL Compute", "PAYG Enterprise SQL Compute"

            ]
  if cleanSKUItemName is None:
    return cleanSKUItemName
  else:
    cleanSKUCategory = "NA"
    if cleanSKUItemName in SKUS:
      cleanSKUCategory = "dbuSKU"
    else:
      if 'Commitment' in cleanSKUItemName:
        cleanSKUCategory = "Workloads Commitment"
      elif 'Support' in cleanSKUItemName:
        cleanSKUCategory = "Support"
      elif 'Platform Fee' in cleanSKUItemName:
        cleanSKUCategory = "Platform Fee"
      elif 'Time Discount' in cleanSKUItemName:
        cleanSKUCategory = "One Time Discount"
      else:
        cleanSKUCategory = cleanSKUItemName
  return cleanSKUCategory

# COMMAND ----------

zabSubscriptionsSalesOrders = spark.sql(f"""
    WITH nscustomers AS (
    SELECT DISTINCT
        CAST(c.id AS DOUBLE)                  AS customer_id,
        c.custentity_sfdc_account_id          AS sfdc_account_id
    FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.customer c
    WHERE c.processTimestamp = (
        SELECT MAX(processTimestamp)
        FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.customer
    )
    AND c.custentity_sfdc_account_id IS NOT NULL
    ),

    zabSubscriptionItems AS (
    SELECT DISTINCT
        CAST(zsi.custrecordzab_si_subscription AS DOUBLE)     AS subscription_id,
        zsi.name                                             AS zab_subscription_item_name,
        zsi.custrecordzab_si_start_date                      AS item_start_date,
        zsi.custrecordzab_si_end_date                        AS item_end_date,
        zsi.custrecordzab_si_overage_rate                    AS overageusage_rate,
        zsi.custrecordzab_si_rate                            AS rate,
        zsi.custrecordzab_si_included_units                  AS included_units,
        zsi.custrecordzab_si_item_description                AS item_description,
        LOWER(cls.name)                                      AS Cloud,
        COALESCE(dat.name, dat.custrecord_dbu_act_name)      AS SKU
    FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.customrecordzab_subscription_item zsi
    LEFT JOIN {SOURCE_CATALOG}.netsuite2_bronze_hourly.classification cls
        ON CAST(zsi.custrecordzab_si_class AS DOUBLE) = CAST(cls.id AS DOUBLE)
    AND cls.processTimestamp = (
            SELECT MAX(processTimestamp)
            FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.classification
        )
    LEFT JOIN {SOURCE_CATALOG}.netsuite2_bronze_hourly.customrecorddbuactivitytype dat
        ON CAST(zsi.custrecorddb_si_dbuactivitytype AS DOUBLE) = CAST(dat.id AS DOUBLE)
    AND dat.processTimestamp = (
            SELECT MAX(processTimestamp)
            FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.customrecorddbuactivitytype
        )
    WHERE zsi.processTimestamp = (
        SELECT MAX(processTimestamp)
        FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.customrecordzab_subscription_item
    )
    ),

    zabSubscriptions AS (
    SELECT DISTINCT
        CAST(zs.id AS DOUBLE)                                AS zab_subscription_id,
        ns.sfdc_account_id                                   AS ns_sfdc_account_id,
        zs.name                                              AS zab_subscription_name,
        zs.custrecordzab_s_start_date                        AS sub_start_date,
        zs.custrecordzab_s_end_date                          AS sub_end_date,
        zsi.item_start_date,
        zsi.item_end_date,
        CASE
        WHEN zs.custrecord_supersede_contract IN ('T','F') THEN zs.custrecord_supersede_contract
        ELSE CAST(zs.custrecord_supersede_contract AS STRING)
        END                                                  AS supersede,
        zsi.subscription_id,
        zsi.zab_subscription_item_name,
        zsi.overageusage_rate,
        zsi.rate,
        zsi.included_units,
        zsi.item_description,
        zsi.Cloud,
        zsi.SKU
    FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.customrecordzab_subscription zs
    LEFT JOIN zabSubscriptionItems zsi
        ON CAST(zs.id AS DOUBLE) = zsi.subscription_id
    LEFT JOIN nscustomers ns
        ON CAST(zs.custrecordzab_s_customer AS DOUBLE) = ns.customer_id
    WHERE zs.processTimestamp = (
        SELECT MAX(processTimestamp)
        FROM {SOURCE_CATALOG}.netsuite2_bronze_hourly.customrecordzab_subscription
    )
    )

    SELECT
    zab.*,
    sub.*
    FROM zabSubscriptionSalesOrders zab
    JOIN zabSubscriptions sub
    ON lower(trim(zab.zab_subscription)) = lower(trim(sub.zab_subscription_name));
""")

zabSubscriptionsSalesOrders = zabSubscriptionsSalesOrders.withColumn(
    "clean_zab_subscription_item_name",
    zabCleanItemName("zab_subscription_item_name")
).withColumn(
    "cleanSKUCategory",
    zabCleanSKUCategory("clean_zab_subscription_item_name")
)
#print(zabSubscriptionsSalesOrders.count())

zabSubscriptionsSalesOrders.createOrReplaceTempView('sfdcZabSubscriptions')

# 161303

# COMMAND ----------

# keep only the non-consumption sales orders from "zabSubscriptionSalesOrders"
# that will reduce the zab subscription joins ( eventually "sfdcZabSubscriptions")
zabSubscriptionsSalesOrders.write.option("overwriteSchema", "true").format("delta").mode("overwrite").saveAsTable(f"{TARGET_CATALOG}.{TARGET_SCHEMA}.zabsubscription_salesorders")

# COMMAND ----------

if update_flag == 1:
  update_zab_workspaces_mapping()  

# COMMAND ----------


