# Databricks notebook source
dbutils.widgets.text("environment", 'integration') # development, integration, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

if environment == 'production':
  input_schema = "main.it_cpq_silver"
  output_schema = "main.it_cpq_silver"
  promo_pricing_schema = "main.it_billing_and_rating"
  sfdc_promotional_pricing = "main.sfdc_bronze.promotional_pricing__c"
  sfdc_sku_manager = "main.sfdc_bronze.sku_manager__c"
elif environment == 'soxdev':
  input_schema = "integration.it_consumption_silver"
  output_schema = "integration.it_consumption_silver"
  promo_pricing_schema = "integration.it_billing_and_rating"
  sfdc_promotional_pricing = "share_clf_main.sfdc_bronze.promotional_pricing__c"
  sfdc_sku_manager = "share_clf_main.sfdc_bronze.sku_manager__c"
else:
  input_schema = "integration.it_cpq_silver"
  output_schema = "integration.it_cpq_silver"
  promo_pricing_schema = "integration.it_billing_and_rating"
  sfdc_promotional_pricing = "main.sfdc_bronze.promotional_pricing__c"
  sfdc_sku_manager = "main.sfdc_bronze.sku_manager__c"

# COMMAND ----------

spark.sql(f"""
create or replace temp view promo_pricing_exploded as
with promo_select as (
  select * from {sfdc_promotional_pricing} where ((Applied__c and Effective_Date__c <= current_date()) or (Effective_Date__c > current_date())) and processDate = (select max(processDate)  from {sfdc_promotional_pricing})
),
base as (
  select
    u.Active__c,
    u.Effective_Date__c,
    u.End_Date__c,
    u.Promo_Discount__c,
    s.Cloud__c,
    u.Name,
    u.Sku_Code__c,
    s.SKU_Name__c sku_name,
    s.NS_Internal_ID__c
  from
    promo_select u
    left join {sfdc_sku_manager} s on u.Sku__c = s.Id
  where s.processDate = (select max(processDate) from {sfdc_sku_manager})
),
explode_promo as (
  select
    *,
    explode(sequence(Effective_Date__c, End_Date__c, interval 1 day)) promo_date
  from
    base
)
select * from explode_promo
""")

# COMMAND ----------

spark.sql(f"""
create or replace table {output_schema}.cpq_aws_gcp_usage_rates_exploded as 
with explode_promo as (
select *, replace(replace(upper(Sku_Code__c), 'GCP_', ''),'AZURE_','') sku_code from promo_pricing_exploded 
),
distinct_usage_rates as (
  select
    distinct * except(source)
  from
    {input_schema}.cpq_aws_gcp_usage_rates_stg_vw
),
explode_usage_rates as (
  select
    *,
    explode(sequence(effective_start_date, effective_end_date, interval 1 day)) cpq_date
  from
    distinct_usage_rates
)
select
  u.account_id,
  u.consumption_cloud,
  u.effective_start_date,
  u.effective_end_date,
  u.product_code,
  u.usage_price as old_usage_price,
  u.usage_price * (1 - coalesce(p.Promo_Discount__c, 0) / 100) as usage_price,
  u.list_price,
  coalesce(p.Promo_Discount__c, 0) as promo_discount,
  p.Name as promo_name,
  u.is_parallel_contract,
  u.workspace_id,
  cpq_date,
  u.rank
from
  explode_usage_rates u
  left join explode_promo p on u.cpq_date = p.promo_date
  and u.product_code = p.sku_code
  and u.consumption_cloud = p.Cloud__c
  """)

# COMMAND ----------

spark.sql(f"""
create or replace table {output_schema}.cpq_aws_gcp_usage_rates_final as
with seq_row as (
select account_id, consumption_cloud, product_code, usage_price, list_price, promo_discount, promo_name, is_parallel_contract, workspace_id, cpq_date, rank,
        row_number() over (partition by account_id, consumption_cloud, product_code, usage_price, list_price, promo_discount, promo_name, is_parallel_contract, workspace_id, rank ORDER BY cpq_date) seq_date_num
        from {input_schema}.cpq_aws_gcp_usage_rates_exploded
)
select account_id, consumption_cloud, product_code, usage_price, list_price, promo_discount, promo_name, is_parallel_contract, workspace_id, rank, min(cpq_date) effective_start_date, max(cpq_date) effective_end_date
from seq_row
group by account_id, consumption_cloud, product_code, usage_price, list_price, promo_discount, promo_name, is_parallel_contract, workspace_id,rank,  dateadd(day, - seq_date_num, cpq_date)
""")

# COMMAND ----------

try:
    spark.sql(f"""
    create view if not exists {output_schema}.cpq_aws_gcp_usage_rates_vw as
    select * from {input_schema}.cpq_aws_gcp_usage_rates_final
    """)
except Exception as e:
    print("Error creating rates view: ", str(e))
