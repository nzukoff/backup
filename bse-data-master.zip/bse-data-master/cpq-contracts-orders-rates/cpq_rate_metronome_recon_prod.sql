-- Databricks notebook source
-- MAGIC %python
-- MAGIC dbutils.widgets.text("environment", 'integration') # UAT, production
-- MAGIC environment = dbutils.widgets.get("environment")
-- MAGIC print(environment)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC if environment == 'production':
-- MAGIC   print("Environment: Production")
-- MAGIC   SOURCE_CATALOG = 'main'
-- MAGIC   SOURCE_SCHEMA = 'sfdc_bronze'
-- MAGIC
-- MAGIC   TARGET_CATALOG = 'main'
-- MAGIC   TARGET_SCHEMA = 'it_cpq_silver'
-- MAGIC   TABLE_PREFIX = ''
-- MAGIC
-- MAGIC   order_table = 'order'
-- MAGIC   orderitem_table = 'orderitem'
-- MAGIC   product2_table = 'product2'
-- MAGIC   contract_table = 'contract'
-- MAGIC   SBQQ__Quote__c_table = 'SBQQ__Quote__c'
-- MAGIC   SBQQ__QuoteLine__c_table = 'SBQQ__QuoteLine__c'
-- MAGIC   Deal_Product__c_table = 'Deal_Product__c'
-- MAGIC   SBQQ__ProductOption__c_table = 'SBQQ__ProductOption__c'
-- MAGIC   product_option__c_table = 'product_option__c'
-- MAGIC   PricebookEntry_table = 'PricebookEntry'
-- MAGIC   opportunity_table = 'opportunity'
-- MAGIC   sku_manager = 'sku_manager__c'
-- MAGIC   deal_product_cutoff_date = '2025-02-15'
-- MAGIC
-- MAGIC
-- MAGIC   contracts_bronze_table_name = 'cpq_contracts_bronze_met_recon'
-- MAGIC   contracts_silver_table_name = 'cpq_contracts_silver_met_recon'
-- MAGIC   rates_silver_table_name = 'cpq_rates_silver_met_recon'
-- MAGIC
-- MAGIC else:
-- MAGIC   print("Environment: UAT")
-- MAGIC   SOURCE_CATALOG = 'integration'
-- MAGIC   SOURCE_SCHEMA = 'it_sfdc_bronze'
-- MAGIC
-- MAGIC   TARGET_CATALOG = 'integration'
-- MAGIC   TARGET_SCHEMA = 'it_cpq_silver'
-- MAGIC   TABLE_PREFIX = ''
-- MAGIC
-- MAGIC   order_table = 'dev_order'
-- MAGIC   orderitem_table = 'dev_orderitem'
-- MAGIC   product2_table = 'dev_product2'
-- MAGIC   contract_table = 'dev_contract'
-- MAGIC   SBQQ__Quote__c_table = 'dev_SBQQ__Quote__c'
-- MAGIC   SBQQ__QuoteLine__c_table = 'dev_SBQQ__QuoteLine__c'
-- MAGIC   Deal_Product__c_table = 'dev_Deal_Product__c'
-- MAGIC   SBQQ__ProductOption__c_table = 'dev_SBQQ__ProductOption__c'
-- MAGIC   product_option__c_table = 'dev_product_option__c'
-- MAGIC   PricebookEntry_table = 'dev_PricebookEntry'
-- MAGIC   opportunity_table = 'dev_opportunity'
-- MAGIC   sku_manager = 'dev_sku_manager__c'
-- MAGIC   deal_product_cutoff_date = '2025-01-10'
-- MAGIC
-- MAGIC   contracts_bronze_table_name = 'cpq_contracts_bronze_met_recon'
-- MAGIC   contracts_silver_table_name = 'cpq_contracts_silver_met_recon'
-- MAGIC   rates_silver_table_name = 'cpq_rates_silver_met_recon'
-- MAGIC
-- MAGIC spark.sql(f'use {SOURCE_CATALOG}.{SOURCE_SCHEMA}')
-- MAGIC print(f'using {SOURCE_CATALOG}.{SOURCE_SCHEMA}')

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC process_date_arg = None
-- MAGIC
-- MAGIC process_date = f"'{process_date_arg}'" if process_date_arg else 'current_date()'
-- MAGIC process_date_query = f'select cast({process_date} as date) as processDate'
-- MAGIC
-- MAGIC print(process_date_query)
-- MAGIC
-- MAGIC spark.sql(process_date_query).createOrReplaceTempView('vw_process_date')

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_order as 
-- MAGIC select * from {order_table}
-- MAGIC where processdate = (select max(processdate) from {order_table});
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_orderitem as 
-- MAGIC select * from {orderitem_table}
-- MAGIC where processdate = (select max(processdate) from {orderitem_table});
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_product2 as 
-- MAGIC select * from {product2_table}
-- MAGIC where processdate = (select max(processdate) from {product2_table});
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_contract as 
-- MAGIC select * from {contract_table}
-- MAGIC where processdate = (select max(processdate) from {contract_table});
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_quote as 
-- MAGIC select * from {SBQQ__Quote__c_table}
-- MAGIC where processdate = (select max(processdate) from {SBQQ__Quote__c_table});
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_quote_line as 
-- MAGIC select * from {SBQQ__QuoteLine__c_table}
-- MAGIC where processdate = (select max(processdate) from {SBQQ__QuoteLine__c_table});
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_Deal_Product__c as 
-- MAGIC select * from {Deal_Product__c_table}
-- MAGIC where processdate = (select max(processdate) from {Deal_Product__c_table})
-- MAGIC and CreatedDate >= '2023-03-18';
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_SBQQ__ProductOption__c as 
-- MAGIC select * from {SBQQ__ProductOption__c_table}
-- MAGIC where processdate = (select max(processdate) from {SBQQ__ProductOption__c_table});
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_product_option__c as 
-- MAGIC select * from {product_option__c_table}
-- MAGIC where processdate = (select max(processdate) from {product_option__c_table});
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_PricebookEntry as 
-- MAGIC select * from {PricebookEntry_table}
-- MAGIC where processdate = (select max(processdate) from {PricebookEntry_table});
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_opportunity as 
-- MAGIC select * from {opportunity_table}
-- MAGIC where processdate = (select max(processdate) from {opportunity_table});
-- MAGIC """)
-- MAGIC spark.sql(f"""
-- MAGIC create or replace temporary view cpq_sku_manager as 
-- MAGIC select * from {sku_manager}
-- MAGIC where processdate = (select max(processdate) from {sku_manager});
-- MAGIC """)

-- COMMAND ----------

create or replace temp view product2_enhanced as 
select distinct p.*, s.Metronome_ProductID__c as metronome_product_id, s.SKU_Group__c
from cpq_product2 p left join cpq_sku_manager s on p.id = s.Product__c

-- COMMAND ----------

create or replace temp view cpq_contract_enhanced as (
select distinct c.*, case when o.CPQ_Order_Type__c in ('Co-term') and c.CPQ_Original_Order_ID__c <> c.SBQQ__Order__c  then True else False end as original_order_retention
from cpq_contract c
left join cpq_order or on c.CPQ_Original_Order_ID__c = or.id
left join cpq_order o on c.SBQQ__Order__c = o.id
)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Get all the orders to be processed

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW vw_tmp_final_orders AS
with co_term_orders as 
  (
    select CPQ_Original_Order__c, collect_list(Id) as co_term_orders
    from cpq_order
    where CPQ_Original_Order__c is not null 
    and CPQ_Order_Type__c = 'Co-term'
    and SBQQ__Contracted__c = true
    and Status = 'Activated'
    group by CPQ_Original_Order__c
  ),
contracts_order_items as
  (
    select c.id as contract_id,
          coi.orderid as order_id,
          contractnumber,
          CPQ_Cancellation_Date__c,
          StartDate,
          CPQ_Original_Contract_End_Date__c
    from cpq_contract c
    inner join ( select distinct orderid,
                  SBQQ__Contract__c
                  from cpq_orderitem oi 
                  where SBQQ__Contract__c is not null
                 ) coi on c.id = coi.SBQQ__Contract__c
  ),

  
order_rates as 
  (
    select o.accountid as account_id,
    COALESCE(c.id, coi.contract_id) as contract_id,
    COALESCE(c.contractnumber, coi.contractnumber) as contract_number,
    case when c.id is not null then c.CPQ_Cancellation_Date__c else coi.CPQ_Cancellation_Date__c end as contract_cancellation_date,
    COALESCE(c.StartDate, coi.StartDate) as contract_start_date__c,
    COALESCE(c.CPQ_Original_Contract_End_Date__c, coi.CPQ_Original_Contract_End_Date__c) as contract_end_date__c, 
    o.Id as order_id,
    OrderNumber as order_number,
    Type as order_type,
    CPQ_Order_Type__c as cpq_order_type,
    o.Status as order_status,
    o.ATG_Migrated_Record__c as is_migrated_order,
    o.ATG_Order_Migration_External_ID__c as migration_ext_id,
    NS_InternalID__c as ns_internal_id,
    NS_TargetType__c as ns_target_type,
    o.SBQQ__Quote__c as quote_id,
    o.CurrencyIsoCode as currency_iso_code,
    NS_TargetType__c as migrated_ns_type,
    Billing_Address__c as billing_address_id,
    --Billing_Address__r as billing_address,
    Shipping_Address__c as shipping_address_id,
    --ShippingAddress as shipping_address,
    o.CPQ_Original_Order__c as orginal_order,
    prv_cto.co_term_orders as original_co_term_orders,
    curr_cto.co_term_orders,
    o.ActivatedDate as activation_date,
    o.CreatedDate as created_date, 
    EffectiveDate as order_start_date, 
    COALESCE(CPQ_Order_End_Date__c, o.EndDate) as order_end_date, 
    --date_sub(lead(EffectiveDate) over (partition by contract_id order by EffectiveDate),1) as order_effective_end_date,
    SBQQ__PaymentTerm__c as paytment_term,
    CPQ_PO_Number__c as po_number,
    CPQ_Marketplace__c as is_marketplace_order,
    CPQ_Termination_for_Convenience__c as cpq_termination_convenience,
    SBQQ__OrderBookings__c as order_bookings,
    TotalAmount as order_amount,
    o.SBQQ__RenewalTerm__c as renewal_term,
    SBQQ__TaxAmount__c as tax_amount,
    CPQ_ATR__c as cpq_atr,
    o.atg_TCV__c as atg_tcv,
    atg_ARR__c as atg_arr,
    atg_Non_Recurring_Revenue__c as atg_nrr,
    CPQ_Effective_Support_Percentage__c as cpq_support_per,
    CPQ_Autorenewal__c as is_cpq_autorenewal,
    CPQ_MultiCloud__c as is_cpq_multicloud,
    SBQQ__RenewalOpportunity__c as renewal_opportunity,
    OpportunityId as opportunity_id,
    o.Billing_System_ID__c as metronome_contract_id

    from cpq_order o   
    left join co_term_orders prv_cto on prv_cto.CPQ_Original_Order__c = o.CPQ_Original_Order__c and o.CPQ_Order_Type__c = 'Supersede'
    left join co_term_orders curr_cto on curr_cto.CPQ_Original_Order__c = o.Id 
    left join cpq_contract_enhanced c on ((o.id = c.CPQ_Original_Order_ID__c and c.original_order_retention is true)  or o.id = c.SBQQ__Order__c)
    left join contracts_order_items coi on coi.order_id = o.id

    where o.status != 'Draft'
 )   
  

select order_rates.account_id,
    order_rates.contract_id,
    order_rates.contract_number,
    COALESCE(contract_number, order_number) as generated_contract_number,
    order_rates.contract_cancellation_date,
    order_rates.contract_start_date__c,
    order_rates.contract_end_date__c,
    case when contract_cancellation_date is not null then true else false end as is_contract_cancelled,
    order_rates.order_id,
    order_rates.order_number,
    order_rates.order_type,
    order_rates.cpq_order_type,
    order_rates.order_status,
    order_rates.currency_iso_code,
    order_rates.quote_id,
    order_rates.is_migrated_order,
    order_rates.migration_ext_id,
    order_rates.ns_internal_id,
    order_rates.ns_target_type,
    order_rates.migrated_ns_type,
    order_rates.billing_address_id,
    order_rates.shipping_address_id,
    order_rates.orginal_order,
    order_rates.original_co_term_orders,
    order_rates.co_term_orders,
    order_rates.activation_date,
    order_rates.created_date, 
    order_rates.order_start_date, 
    order_rates.order_end_date, 
    --COALESCE(date_sub(lead(order_start_date) over (partition by COALESCE(contract_number, order_number) order by order_start_date), 1), order_rates.order_end_date)  as order_effective_end_date,
    order_rates.paytment_term,
    order_rates.po_number,
    order_rates.is_marketplace_order,
    order_rates.cpq_termination_convenience,
    order_rates.order_bookings,
    order_rates.order_amount,
    order_rates.renewal_term,
    order_rates.tax_amount,
    order_rates.cpq_atr,
    order_rates.atg_tcv,
    order_rates.atg_arr,
    order_rates.atg_nrr,
    order_rates.cpq_support_per,
    order_rates.is_cpq_autorenewal,
    order_rates.is_cpq_multicloud,
    order_rates.renewal_opportunity,
    order_rates.opportunity_id,
    metronome_contract_id

from order_rates
           
group by order_rates.account_id,
    order_rates.contract_id,
    order_rates.contract_number,
    order_rates.contract_cancellation_date,
    order_rates.contract_start_date__c,
    order_rates.contract_end_date__c,
    order_rates.order_id,
    order_rates.order_number,
    order_rates.order_type,
    order_rates.cpq_order_type,
    order_rates.order_status,
    order_rates.is_migrated_order,
    order_rates.migration_ext_id,
    order_rates.ns_internal_id,
    order_rates.ns_target_type,
    order_rates.migrated_ns_type,
    order_rates.billing_address_id,
    order_rates.shipping_address_id,
    order_rates.orginal_order,
    order_rates.original_co_term_orders,
    order_rates.co_term_orders,
    order_rates.activation_date,
    order_rates.created_date, 
    order_rates.order_start_date, 
    order_rates.order_end_date, 
    --COALESCE(order_rates.order_effective_end_date, order_rates.order_end_date),
    order_rates.paytment_term,
    order_rates.po_number,
    order_rates.is_marketplace_order,
    order_rates.cpq_termination_convenience,
    order_rates.order_bookings,
    order_rates.order_amount,
    order_rates.renewal_term,
    order_rates.tax_amount,
    order_rates.cpq_atr,
    order_rates.atg_tcv,
    order_rates.atg_arr,
    order_rates.atg_nrr,
    order_rates.cpq_support_per,
    order_rates.is_cpq_autorenewal,
    order_rates.is_cpq_multicloud,
    order_rates.quote_id,
    order_rates.currency_iso_code,
    order_rates.renewal_opportunity,
    order_rates.opportunity_id,
    metronome_contract_id

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Get all the order items of the orders

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(f"""
-- MAGIC CREATE OR REPLACE TEMPORARY VIEW vw_tmp_final_order_items AS
-- MAGIC
-- MAGIC select orderid as order_id,
-- MAGIC OrderItemNumber as order_item_number,
-- MAGIC SBQQ__QuoteLine__c as quote_line_id,
-- MAGIC --c.id as orderitem_contract_id,
-- MAGIC oi.ATG_Migrated_Record__c as is_migrated_order,
-- MAGIC COALESCE(oi.CPQ_Cloud__C,p.Platform_type__c) as cpq_cloud,
-- MAGIC oi.CPQ_Service_Family__c as service_family,
-- MAGIC p.Family as product_family, 
-- MAGIC p.ProductCode as product_code,
-- MAGIC p.metronome_product_id,
-- MAGIC oi.CreatedDate as created_date, 
-- MAGIC ServiceDate as order_item_start_date, 
-- MAGIC oi.EndDate as order_item_end_date, 
-- MAGIC --COALESCE(date_sub(lead(ServiceDate) over (partition by orderid, p.ProductCode order by ServiceDate), 1), oi.EndDate) as order_item_effective_end_date,
-- MAGIC CPQ_Usage_Total__c as cpq_usage_price,
-- MAGIC ListPrice as list_price,
-- MAGIC UnitPrice as unit_price,
-- MAGIC TotalPrice as total_price,
-- MAGIC SBQQ__QuotedListPrice__c as quoted_list_price,
-- MAGIC AvailableQuantity as available_quantity,
-- MAGIC SBQQ__ContractAction__c as contract_action,
-- MAGIC SBQQ__OrderedQuantity__c as ordered_quantity,
-- MAGIC SBQQ__QuotedQuantity__c as quoted_quantity,
-- MAGIC CPQ_Amendment_Quote_Usage_Discount__c as cpq_amendment_quote_usage_discount,
-- MAGIC 0 CPQ_Cross_Service_Discount_multiplier__c,
-- MAGIC 0 CPQ_Cross_Service_Discount_AWS__c,
-- MAGIC 0 CPQ_Cross_Service_Discount_GCP__c,
-- MAGIC 0 CPQ_MCT_Hero_Reservation_Discount__c,
-- MAGIC 0 CPQ_MCT_Reservation_Discount__c,
-- MAGIC 0 CPQ_Service_Family_Discount__c,
-- MAGIC 0 cross_service_reservation_discount,
-- MAGIC CPQ_Discount__c as cpq_discount,
-- MAGIC CPQ_Original_Quote_Usage_Discount__c,
-- MAGIC CPQ_Previous_Cross_Service_Discount_AWS__c,
-- MAGIC CPQ_Previous_Cross_Service_Discount_GCP__c,
-- MAGIC CPQ_Previous_Usage_Discount__c,
-- MAGIC CPQ_Previous_Usage_Discount_holding__c,
-- MAGIC oi.CPQ_Commit_Royalty__c as cloud_royalty_perc,
-- MAGIC CPQ_Net_Total_After_Royalty__c as net_total_after_royalty,
-- MAGIC oi.CPQ_Support__c as support_perc,
-- MAGIC oi.atg_TCV__c as oi_atg_tcv,
-- MAGIC SBQQ__QuoteLine__c,
-- MAGIC 'pre_deal_order_item' as product_source
-- MAGIC
-- MAGIC from cpq_orderitem oi 
-- MAGIC left join product2_enhanced p on oi.Product2Id = p.Id
-- MAGIC
-- MAGIC WHERE COALESCE(lower(p.Family), '') != 'usage' OR p.ProductCode like '%BUNDLE%'
-- MAGIC         OR (lower(p.Family) = 'usage' and (oi.CreatedDate < '2023-03-18' or oi.CreatedDate > '{deal_product_cutoff_date}')) -- TODO: need to check whether cutoff date is required
-- MAGIC         OR (orderid in ('8018Y000002y3riQAA'))       -- CPQ Fixed as per BSEDATA-478 
-- MAGIC
-- MAGIC
-- MAGIC
-- MAGIC UNION 
-- MAGIC
-- MAGIC
-- MAGIC SELECT 
-- MAGIC Related_Order__c as order_id,
-- MAGIC dp.id as order_item_number,
-- MAGIC dp.id as quote_line_id,
-- MAGIC CASE WHEN dp.Migrated_Order_Product_ID__c IS NOT null THEN true ELSE false END as is_migrated_order,
-- MAGIC COALESCE(dp.CPQ_Cloud__C,p.Platform_type__c) as cpq_cloud,
-- MAGIC p.CPQ_Service_Family__c as service_family,
-- MAGIC dp.Product_Family__c as product_family, 
-- MAGIC dp.Product_Code__c as product_code,
-- MAGIC p.metronome_product_id,
-- MAGIC dp.CreatedDate as created_date, 
-- MAGIC dp.Start_Date__c as order_item_start_date, 
-- MAGIC dp.End_Date__c as order_item_end_date, 
-- MAGIC dp.Sales_Price__c as cpq_usage_price,
-- MAGIC dp.List_Price__c as list_price,
-- MAGIC dp.List_Price__c as unit_price,
-- MAGIC dp.Sales_Price__c as total_price,
-- MAGIC dp.List_Price__c as quoted_list_price,
-- MAGIC dp.Quantity__c as available_quantity,
-- MAGIC oi.SBQQ__ContractAction__c as contract_action,
-- MAGIC oi.SBQQ__OrderedQuantity__c as ordered_quantity,
-- MAGIC oi.SBQQ__QuotedQuantity__c as quoted_quantity,
-- MAGIC oi.CPQ_Amendment_Quote_Usage_Discount__c as cpq_amendment_quote_usage_discount,
-- MAGIC 0 CPQ_Cross_Service_Discount_multiplier__c,
-- MAGIC 0 CPQ_Cross_Service_Discount_AWS__c,
-- MAGIC 0 CPQ_Cross_Service_Discount_GCP__c,
-- MAGIC 0 CPQ_MCT_Hero_Reservation_Discount__c,
-- MAGIC 0 CPQ_MCT_Reservation_Discount__c,
-- MAGIC 0 CPQ_Service_Family_Discount__c,
-- MAGIC 0 cross_service_reservation_discount,
-- MAGIC dp.Discount__c as cpq_discount,
-- MAGIC oi.CPQ_Original_Quote_Usage_Discount__c,
-- MAGIC oi.CPQ_Previous_Cross_Service_Discount_AWS__c,
-- MAGIC oi.CPQ_Previous_Cross_Service_Discount_GCP__c,
-- MAGIC oi.CPQ_Previous_Usage_Discount__c,
-- MAGIC oi.CPQ_Previous_Usage_Discount_holding__c,
-- MAGIC oi.CPQ_Commit_Royalty__c as cloud_royalty_perc,
-- MAGIC oi.CPQ_Net_Total_After_Royalty__c as net_total_after_royalty,
-- MAGIC oi.CPQ_Support__c as support_perc,
-- MAGIC oi.atg_TCV__c as oi_atg_tcv,
-- MAGIC SBQQ__QuoteLine__c,
-- MAGIC 'deal_product' as product_source
-- MAGIC
-- MAGIC FROM cpq_Deal_Product__c dp
-- MAGIC INNER JOIN cpq_orderitem oi on dp.Related_Order_Product__c = oi.id
-- MAGIC left join product2_enhanced p on dp.Product__c = p.Id
-- MAGIC where dp.CreatedDate < '{deal_product_cutoff_date}' -- TODO: need to check whether this is required
-- MAGIC
-- MAGIC """)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Union two different product option together

-- COMMAND ----------

create or replace temp view product_option_union as 
with sbqq_product_option as (    
    SELECT id,
        SBQQ__ProductCode__c,
        CPQ_Cloud__c,
        CPQ_Cross_Service_Discount_multiplier__c,
        SBQQ__ConfiguredSKU__c,
        SBQQ__OptionalSKU__c,
        CPQ_Service_Family__c,
        'old_po' as po_cource
    FROM cpq_SBQQ__ProductOption__c
    where SBQQ__ProductCode__c is not null
),
product_option as (
      SELECT id,
        Product_Code__c as SBQQ__ProductCode__c,
        Cloud__c as CPQ_Cloud__c,
        Cross_Service_Multiplier__c as CPQ_Cross_Service_Discount_multiplier__c,
        Configured_SKU__c as SBQQ__ConfiguredSKU__c,
        Optional_SKU__c as SBQQ__OptionalSKU__c,
        Service_Family__c as CPQ_Service_Family__c,
        'new_po' as po_cource
    FROM cpq_product_option__c
    where Product_Code__c is not null
),
union_both as (
select * from sbqq_product_option
union all
select * from product_option
where SBQQ__ProductCode__c is not null
)
select distinct u.*, p.metronome_product_id 
from union_both u left join product2_enhanced p on u.SBQQ__OptionalSKU__c = p.id


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Add new products from BUNDLE skus

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(f"""
-- MAGIC CREATE OR REPLACE TEMPORARY VIEW vw_tmp_final_new_sku AS
-- MAGIC with product_options as
-- MAGIC (
-- MAGIC     SELECT po.id as product_option_id, 
-- MAGIC           p.id as product_id, 
-- MAGIC           po.SBQQ__ProductCode__c as sku, 
-- MAGIC           po.metronome_product_id,
-- MAGIC           p.ProductCode as parent_sf,   -- Bundle SF 
-- MAGIC           lower(po.CPQ_Cloud__c) as cloud,
-- MAGIC           coalesce(po.CPQ_Cross_Service_Discount_multiplier__c, 0) as CPQ_Cross_Service_Discount_multiplier__c,
-- MAGIC           p.Cloud_Service_Family__c as CPQ_Service_Family__c
-- MAGIC     FROM product_option_union po
-- MAGIC     INNER JOIN product2_enhanced p on po.SBQQ__ConfiguredSKU__c = p.id and lower(p.CPQ_Charge_Type__c) = 'usage'
-- MAGIC     WHERE lower(po.CPQ_Cloud__c) in ('aws', 'gcp', 'azure','mct')
-- MAGIC           and lower(p.ProductCode) not like ('sku_level_bundle_%')
-- MAGIC ),
-- MAGIC
-- MAGIC service_families AS (
-- MAGIC   select distinct parent_sf from product_options
-- MAGIC ),
-- MAGIC
-- MAGIC order_pricebook AS (
-- MAGIC   select distinct id, Pricebook2Id from cpq_order
-- MAGIC ),
-- MAGIC order_sf as
-- MAGIC (
-- MAGIC   select order_id, order_item_start_date, order_item_end_date, cpq_cloud, sku, coalesce(oi.metronome_product_id,sf.metronome_product_id) metronome_product_id, service_family,
-- MAGIC   product_family, created_date, order_item_start_date, order_item_end_date, available_quantity, 
-- MAGIC   contract_action, oi.ordered_quantity, oi.quoted_quantity,
-- MAGIC   cpq_PricebookEntry.UnitPrice,
-- MAGIC   cpq_amendment_quote_usage_discount,
-- MAGIC   cpq_discount,
-- MAGIC   sf.CPQ_Cross_Service_Discount_multiplier__c,
-- MAGIC   oi.CPQ_Original_Quote_Usage_Discount__c,
-- MAGIC   oi.CPQ_Previous_Cross_Service_Discount_AWS__c,
-- MAGIC   oi.CPQ_Previous_Cross_Service_Discount_GCP__c,
-- MAGIC   q.CPQ_Cross_Service_Discount_AWS__c,
-- MAGIC   q.CPQ_Cross_Service_Discount_GCP__c,
-- MAGIC   q.CPQ_MCT_Hero_Reservation_Discount__c,
-- MAGIC   q.CPQ_MCT_Reservation_Discount__c,
-- MAGIC   oi.CPQ_Previous_Usage_Discount__c,
-- MAGIC   oi.CPQ_Previous_Usage_Discount_holding__c,
-- MAGIC   oi.cloud_royalty_perc,
-- MAGIC   oi.net_total_after_royalty,
-- MAGIC   oi.support_perc,
-- MAGIC   oi.oi_atg_tcv,
-- MAGIC   oi.SBQQ__QuoteLine__c,
-- MAGIC   max(coalesce(cpq_quote_line.CPQ_Service_Family_Discount__c, 0)) as CPQ_Service_Family_Discount__c,
-- MAGIC   case when COALESCE(sf.CPQ_Cross_Service_Discount_multiplier__c, 0) > 0 and lower(cpq_cloud) = 'aws' then COALESCE(q.CPQ_Cross_Service_Discount_AWS__c, 0) 
-- MAGIC     when COALESCE(sf.CPQ_Cross_Service_Discount_multiplier__c, 0) > 0 and lower(cpq_cloud) = 'gcp' then COALESCE(q.CPQ_Cross_Service_Discount_GCP__c, 0)
-- MAGIC     when COALESCE(q.CPQ_MCT_Hero_Reservation_Discount__c, 0) > 0 and lower(cpq_cloud) = 'mct' and sf.CPQ_Service_Family__c in ('MCT-MCT Model Training - Hero Reservation') then COALESCE(q.CPQ_MCT_Hero_Reservation_Discount__c, 0)
-- MAGIC     when COALESCE(q.CPQ_MCT_Reservation_Discount__c, 0) > 0 and lower(cpq_cloud) = 'mct' and sf.CPQ_Service_Family__c in ('MCT-MCT Model Training - Reservation') then COALESCE(q.CPQ_MCT_Reservation_Discount__c, 0)
-- MAGIC     end as cross_service_reservation_discount
-- MAGIC
-- MAGIC   from product_options sf 
-- MAGIC   inner join vw_tmp_final_order_items oi on oi.product_code = sf.parent_sf
-- MAGIC   left join cpq_quote_line on cpq_quote_line.id = oi.SBQQ__QuoteLine__c
-- MAGIC   left join order_pricebook on order_pricebook.id = oi.order_id
-- MAGIC   left join cpq_PricebookEntry on order_pricebook.Pricebook2Id = cpq_PricebookEntry.Pricebook2Id and cpq_PricebookEntry.isactive = true 
-- MAGIC                                   and sf.sku = cpq_PricebookEntry.ProductCode
-- MAGIC   left join cpq_quote q on cpq_quote_line.SBQQ__Quote__c = q.id
-- MAGIC
-- MAGIC   group by order_id, order_item_start_date, order_item_end_date, cpq_cloud, sku, coalesce(oi.metronome_product_id,sf.metronome_product_id), service_family, 
-- MAGIC   product_family, created_date, available_quantity, 
-- MAGIC   contract_action, oi.ordered_quantity, oi.quoted_quantity,
-- MAGIC   cpq_PricebookEntry.UnitPrice,
-- MAGIC   sf.CPQ_Cross_Service_Discount_multiplier__c,
-- MAGIC   q.CPQ_Cross_Service_Discount_AWS__c,
-- MAGIC   q.CPQ_Cross_Service_Discount_GCP__c,
-- MAGIC   q.CPQ_MCT_Hero_Reservation_Discount__c,
-- MAGIC   q.CPQ_MCT_Reservation_Discount__c,
-- MAGIC   sf.CPQ_Service_Family__c,
-- MAGIC   cpq_amendment_quote_usage_discount,
-- MAGIC   cpq_discount,
-- MAGIC   oi.CPQ_Original_Quote_Usage_Discount__c,
-- MAGIC   oi.CPQ_Previous_Cross_Service_Discount_AWS__c,
-- MAGIC   oi.CPQ_Previous_Cross_Service_Discount_GCP__c,
-- MAGIC   oi.CPQ_Previous_Usage_Discount__c,
-- MAGIC   oi.CPQ_Previous_Usage_Discount_holding__c,
-- MAGIC   oi.cloud_royalty_perc,
-- MAGIC   oi.net_total_after_royalty,
-- MAGIC   oi.support_perc,
-- MAGIC   oi.oi_atg_tcv,
-- MAGIC   oi.SBQQ__QuoteLine__c
-- MAGIC )
-- MAGIC
-- MAGIC
-- MAGIC
-- MAGIC SELECT distinct o.order_id,
-- MAGIC concat_ws('-', o.order_id, sku) as order_item_number,
-- MAGIC null as quote_line_id,
-- MAGIC false as is_migrated_order,
-- MAGIC o.cpq_cloud,
-- MAGIC o.service_family,
-- MAGIC o.product_family, 
-- MAGIC sku as product_code,
-- MAGIC coalesce(o.metronome_product_id,oi.metronome_product_id) as metronome_product_id,
-- MAGIC o.created_date, 
-- MAGIC o.order_item_start_date, 
-- MAGIC o.order_item_end_date,
-- MAGIC --8018Y000002pmdHQAQ is walmart account fix (BSEDATA-3344)
-- MAGIC --UnitPrice - (UnitPrice * CPQ_Service_Family_Discount__c / 100) as cpq_usage_price,
-- MAGIC --case when co.order_start_date >= "{deal_product_cutoff_date}" or o.order_id = '8018Y000002pmdHQAQ' then UnitPrice - (UnitPrice * greatest(o.CPQ_Service_Family_Discount__c, o.cross_service_reservation_discount) / 100) else UnitPrice - (UnitPrice * o.CPQ_Service_Family_Discount__c / 100) end as cpq_usage_price,
-- MAGIC UnitPrice - (UnitPrice * greatest(o.CPQ_Service_Family_Discount__c, o.cross_service_reservation_discount) / 100) as cpq_usage_price,
-- MAGIC UnitPrice as list_price,
-- MAGIC UnitPrice as unit_price,
-- MAGIC --UnitPrice - (UnitPrice * CPQ_Service_Family_Discount__c / 100) as total_price,
-- MAGIC --case when co.order_start_date >= "{deal_product_cutoff_date}"  or o.order_id = '8018Y000002pmdHQAQ' then UnitPrice - (UnitPrice * greatest(o.CPQ_Service_Family_Discount__c, o.cross_service_reservation_discount) / 100) else UnitPrice - (UnitPrice * o.CPQ_Service_Family_Discount__c / 100) end as total_price,
-- MAGIC UnitPrice - (UnitPrice * greatest(o.CPQ_Service_Family_Discount__c, o.cross_service_reservation_discount) / 100) as total_price,
-- MAGIC UnitPrice as quoted_list_price,
-- MAGIC o.available_quantity,
-- MAGIC o.contract_action,
-- MAGIC o.ordered_quantity,
-- MAGIC o.quoted_quantity,
-- MAGIC o.cpq_amendment_quote_usage_discount,
-- MAGIC o.CPQ_Cross_Service_Discount_multiplier__c,
-- MAGIC o.CPQ_Cross_Service_Discount_AWS__c,
-- MAGIC o.CPQ_Cross_Service_Discount_GCP__c,
-- MAGIC o.CPQ_MCT_Hero_Reservation_Discount__c,
-- MAGIC o.CPQ_MCT_Reservation_Discount__c,
-- MAGIC o.CPQ_Service_Family_Discount__c,
-- MAGIC o.cross_service_reservation_discount,
-- MAGIC o.cpq_discount,
-- MAGIC o.CPQ_Original_Quote_Usage_Discount__c,
-- MAGIC o.CPQ_Previous_Cross_Service_Discount_AWS__c,
-- MAGIC o.CPQ_Previous_Cross_Service_Discount_GCP__c,
-- MAGIC o.CPQ_Previous_Usage_Discount__c,
-- MAGIC o.CPQ_Previous_Usage_Discount_holding__c,
-- MAGIC o.cloud_royalty_perc,
-- MAGIC o.net_total_after_royalty,
-- MAGIC o.support_perc,
-- MAGIC o.oi_atg_tcv,
-- MAGIC o.SBQQ__QuoteLine__c,
-- MAGIC 'bundle_explode' as product_source
-- MAGIC
-- MAGIC from order_sf o
-- MAGIC left join vw_tmp_final_order_items oi on o.order_id = oi.order_id and o.sku = oi.product_code
-- MAGIC left join vw_tmp_final_orders co on o.order_id = co.order_id and o.order_item_start_date >= co.order_start_date and o.order_item_end_date <= co.order_end_date and o.order_item_start_date >= co.contract_start_date__c and o.order_item_end_date <= co.contract_end_date__c
-- MAGIC left join cpq_quote q on co.quote_id = q.id
-- MAGIC where oi.product_code is null
-- MAGIC """)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Add new products from new service families

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW vw_tmp_final_new_sf AS

with product_options as
(
    SELECT po.id as product_option_id, 
          p.id as product_id, 
          po.SBQQ__ProductCode__c as sku, 
          po.metronome_product_id,
          p.ProductCode as parent_sf,   -- Bundle SF 
          lower(po.CPQ_Cloud__c) as cloud,
          coalesce(po.CPQ_Cross_Service_Discount_multiplier__c, 0) as CPQ_Cross_Service_Discount_multiplier__c,
          --po.CPQ_Service_Family__c,
          p.Cloud_Service_Family__c as CPQ_Service_Family__c,
          p.family
    FROM product_option_union po
    INNER JOIN product2_enhanced p on po.SBQQ__ConfiguredSKU__c = p.id and lower(p.CPQ_Charge_Type__c) = 'usage'
    WHERE lower(po.CPQ_Cloud__c) in ('aws', 'gcp', 'azure','mct')
          and lower(p.ProductCode) not like ('sku_level_bundle_%') and lower(p.ProductCode) not like ('%_compliance_bundle')
          and p.Cloud_Service_Family__c <> 'GCP MP-'
),

contract_sku as
(
  select distinct contract_id, product_code 
  from
    (
      select COALESCE(o.contract_id, oi.order_id) as contract_id, oi.product_code
      from vw_tmp_final_orders o
      inner join vw_tmp_final_order_items oi on o.order_id = oi.order_id

      union all
      
      select COALESCE(o.contract_id, oi.order_id) as contract_id, oi.product_code
      from vw_tmp_final_orders o
      inner join vw_tmp_final_new_sku oi on o.order_id = oi.order_id
    )
  
),

contract_sf as
(
  select COALESCE(o.contract_id, oi.order_id) as contract_id, 
          oi.cpq_cloud, 
          oi.product_code,
          --po.metronome_product_id,
          max(q.CPQ_Cross_Service_Discount_AWS__c) as CPQ_Cross_Service_Discount_AWS__c, 
          max(q.CPQ_Cross_Service_Discount_GCP__c) as CPQ_Cross_Service_Discount_GCP__c,
          max(q.CPQ_MCT_Hero_Reservation_Discount__c) AS CPQ_MCT_Hero_Reservation_Discount__c,
          max(q.CPQ_MCT_Reservation_Discount__c) AS CPQ_MCT_Reservation_Discount__c
          
  from vw_tmp_final_orders o
  inner join vw_tmp_final_order_items oi on o.order_id = oi.order_id
  inner join cpq_quote q on o.quote_id = q.id
  inner join product_options po on po.parent_sf = oi.product_code
  group by COALESCE(o.contract_id, oi.order_id), oi.cpq_cloud, oi.product_code--, po.metronome_product_id
),

contract_cloudlevel_dis as
(
  select contract_id, cpq_cloud, max(CPQ_Cross_Service_Discount_AWS__c) as CPQ_Cross_Service_Discount_AWS__c, max(CPQ_Cross_Service_Discount_GCP__c) as CPQ_Cross_Service_Discount_GCP__c,
  max(CPQ_MCT_Hero_Reservation_Discount__c) AS CPQ_MCT_Hero_Reservation_Discount__c, max(CPQ_MCT_Reservation_Discount__c) AS CPQ_MCT_Reservation_Discount__c
  from contract_sf
  group by contract_id, cpq_cloud
),

order_pricebook AS (
  select distinct id, Pricebook2Id from cpq_order
),

contract_base as
(
  select cld.contract_id, o.order_id, cld.cpq_cloud, po.cloud, po.parent_sf, 
  o.created_date, o.order_start_date, o.order_end_date, 
  CPQ_Cross_Service_Discount_AWS__c, CPQ_Cross_Service_Discount_GCP__c, 
  po.sku, po.metronome_product_id, po.family, cpq_PricebookEntry.UnitPrice, CPQ_Service_Family__c, 
  po.CPQ_Cross_Service_Discount_multiplier__c,
  CPQ_Cross_Service_Discount_AWS__c,
  CPQ_Cross_Service_Discount_GCP__c,
  cld.CPQ_MCT_Hero_Reservation_Discount__c,
  cld.CPQ_MCT_Reservation_Discount__c,

  case when COALESCE(po.CPQ_Cross_Service_Discount_multiplier__c, 0) > 0 and lower(cloud) = 'aws' then COALESCE(CPQ_Cross_Service_Discount_AWS__c, 0) 
       when COALESCE(po.CPQ_Cross_Service_Discount_multiplier__c, 0) > 0 and lower(cloud) = 'gcp' then COALESCE(CPQ_Cross_Service_Discount_GCP__c, 0)
       when COALESCE(cld.CPQ_MCT_Hero_Reservation_Discount__c, 0) > 0 and lower(cloud) = 'mct' and CPQ_Service_Family__c in ('MCT-MCT Model Training - Hero Reservation') then COALESCE(CPQ_MCT_Hero_Reservation_Discount__c, 0)
       when COALESCE(cld.CPQ_MCT_Reservation_Discount__c, 0) > 0 and lower(cloud) = 'mct' and CPQ_Service_Family__c in ('MCT-MCT Model Training - Reservation') then COALESCE(CPQ_MCT_Reservation_Discount__c, 0)
       else 0
       end as cpq_discount

  from contract_cloudlevel_dis cld
  inner join product_options po on lower(cld.cpq_cloud) = po.cloud
  inner join vw_tmp_final_orders o on COALESCE(o.contract_id, o.order_id) = cld.contract_id and lower(o.cpq_order_type) != 'co-term'
  left join order_pricebook on order_pricebook.id = o.order_id
  left join cpq_PricebookEntry on order_pricebook.Pricebook2Id = cpq_PricebookEntry.Pricebook2Id and cpq_PricebookEntry.isactive = true 
                                  and po.sku = cpq_PricebookEntry.ProductCode
)

select distinct cb.order_id,
concat_ws('-', cb.order_id, sku) as order_item_number,
null as quote_line_id,
false as is_migrated_order,
cb.cpq_cloud,
cb.CPQ_Service_Family__c as service_family,
cb.family as product_family, 
sku as product_code,
cb.metronome_product_id as metronome_product_id,
cb.created_date, 
cb.order_start_date as order_item_start_date, 
cb.order_end_date as order_item_end_date,
UnitPrice - (UnitPrice * cpq_discount / 100) as cpq_usage_price,
UnitPrice as list_price,
UnitPrice as unit_price,
UnitPrice - (UnitPrice * cpq_discount / 100) as total_price,
UnitPrice as quoted_list_price,
null as available_quantity,
null as contract_action,
null as ordered_quantity,
null as quoted_quantity,
null as cpq_amendment_quote_usage_discount,
CPQ_Cross_Service_Discount_multiplier__c,
cb.CPQ_Cross_Service_Discount_AWS__c,
cb.CPQ_Cross_Service_Discount_GCP__c,
cb.CPQ_MCT_Hero_Reservation_Discount__c,
cb.CPQ_MCT_Reservation_Discount__c,
0 CPQ_Service_Family_Discount__c,
cpq_discount as cross_service_reservation_discount,
cb.cpq_discount,
null as CPQ_Original_Quote_Usage_Discount__c,
null as CPQ_Previous_Cross_Service_Discount_AWS__c,
null as CPQ_Previous_Cross_Service_Discount_GCP__c,
null as CPQ_Previous_Usage_Discount__c,
null as CPQ_Previous_Usage_Discount_holding__c,
null as cloud_royalty_perc,
null as net_total_after_royalty,
null as support_perc,
null as oi_atg_tcv,
null as SBQQ__QuoteLine__c,
'new_sf' as product_source

from contract_base cb
left join contract_sf csf on cb.contract_id = csf.contract_id and cb.parent_sf = csf.product_code
left join contract_sku csku on cb.contract_id = csku.contract_id and cb.sku = csku.product_code
where csf.product_code is null and csku.product_code is null

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW vw_tmp_final_oi_new_sf_sku AS
  with union_df as (
    SELECT * FROM vw_tmp_final_order_items
    UNION ALL
    SELECT * FROM vw_tmp_final_new_sf
    UNION ALL
    SELECT * FROM vw_tmp_final_new_sku
  )
  select distinct * from union_df

-- COMMAND ----------

-- MAGIC %python
-- MAGIC table_name = 'cpq_contracts_bronze_union_stage_met_recon'
-- MAGIC full_table_name = f'{TARGET_CATALOG}.{TARGET_SCHEMA}.{table_name}'
-- MAGIC print(full_table_name)
-- MAGIC
-- MAGIC df = spark.table('vw_tmp_final_oi_new_sf_sku')
-- MAGIC df.write.mode('overwrite').format('delta').option('overwriteSchema', 'true').saveAsTable(full_table_name)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(f"""
-- MAGIC --Need to dedup this view (Done below)
-- MAGIC CREATE OR REPLACE TEMPORARY VIEW vw_tmp_cpq_final_dup_contracts AS
-- MAGIC select o.account_id,
-- MAGIC o.contract_id,
-- MAGIC o.contract_number,
-- MAGIC o.generated_contract_number,
-- MAGIC o.contract_cancellation_date,
-- MAGIC o.contract_start_date__c,
-- MAGIC o.contract_end_date__c,
-- MAGIC coalesce(o.contract_cancellation_date, o.contract_end_date__c) as contract_effective_end_date,
-- MAGIC o.is_contract_cancelled,
-- MAGIC o.order_id,
-- MAGIC o.order_number,
-- MAGIC o.metronome_contract_id,
-- MAGIC o.order_type,
-- MAGIC o.cpq_order_type,
-- MAGIC o.order_status,
-- MAGIC o.is_migrated_order,
-- MAGIC o.migration_ext_id,
-- MAGIC o.ns_internal_id,
-- MAGIC o.ns_target_type,
-- MAGIC o.currency_iso_code,
-- MAGIC o.orginal_order,
-- MAGIC o.original_co_term_orders,
-- MAGIC o.co_term_orders,
-- MAGIC o.activation_date as order_activation_date,
-- MAGIC o.created_date as order_creation_date, 
-- MAGIC o.order_start_date, 
-- MAGIC o.order_end_date, 
-- MAGIC oi.order_item_number,
-- MAGIC oi.order_item_start_date, 
-- MAGIC oi.order_item_end_date, 
-- MAGIC
-- MAGIC ---Handeling co-term orders rates
-- MAGIC case when product_family = 'Usage' and date_sub(lead(order_item_start_date) over (partition by account_id, generated_contract_number, product_code order by order_item_start_date, o.created_date, cpq_usage_price desc), 1) is null
-- MAGIC                 then oi.order_item_end_date          
-- MAGIC      when product_family = 'Usage' and date_sub(lead(order_item_start_date) over (partition by account_id, generated_contract_number, product_code order by order_item_start_date, o.created_date, cpq_usage_price desc), 1) < oi.order_item_start_date  
-- MAGIC                 then oi.order_item_start_date 
-- MAGIC      when product_family = 'Usage' then date_sub(lead(order_item_start_date) over (partition by account_id, generated_contract_number, product_code order by order_item_start_date, o.created_date, cpq_usage_price desc), 1) 
-- MAGIC      
-- MAGIC      else oi.order_item_end_date
-- MAGIC end as order_item_effective_end_date,
-- MAGIC
-- MAGIC oi.cpq_cloud,
-- MAGIC split(oi.cpq_cloud,'\\-')[0] as consumption_cloud,   -- retunr AWS if cpq_cloud is AWS-MP
-- MAGIC oi.service_family,
-- MAGIC oi.product_family, 
-- MAGIC oi.product_code,
-- MAGIC oi.metronome_product_id,
-- MAGIC coalesce(oi.cpq_usage_price, oi.list_price) as cpq_usage_price,
-- MAGIC oi.list_price,
-- MAGIC oi.unit_price,
-- MAGIC oi.total_price,
-- MAGIC oi.quoted_list_price,
-- MAGIC oi.available_quantity,
-- MAGIC oi.contract_action,
-- MAGIC oi.ordered_quantity,
-- MAGIC oi.quoted_quantity,
-- MAGIC oi.cpq_discount,
-- MAGIC oi.cloud_royalty_perc,
-- MAGIC oi.net_total_after_royalty,
-- MAGIC oi.support_perc,
-- MAGIC oi.oi_atg_tcv,
-- MAGIC o.is_marketplace_order,
-- MAGIC o.cpq_termination_convenience,
-- MAGIC o.order_bookings,
-- MAGIC o.order_amount,
-- MAGIC o.renewal_term,
-- MAGIC o.tax_amount,
-- MAGIC o.cpq_atr,
-- MAGIC o.atg_tcv,
-- MAGIC o.atg_arr,
-- MAGIC o.atg_nrr,
-- MAGIC o.cpq_support_per,
-- MAGIC o.is_cpq_autorenewal,
-- MAGIC o.is_cpq_multicloud,
-- MAGIC o.quote_id,
-- MAGIC vw_process_date.processDate,
-- MAGIC false is_parallel_contract,
-- MAGIC cast(null as array<string>) as parallel_contracts_list,
-- MAGIC o.renewal_opportunity,
-- MAGIC o.opportunity_id
-- MAGIC
-- MAGIC from vw_tmp_final_orders o
-- MAGIC inner join {TARGET_CATALOG}.{TARGET_SCHEMA}.cpq_contracts_bronze_union_stage_met_recon oi on o.order_id = oi.order_id
-- MAGIC cross join vw_process_date
-- MAGIC inner join cpq_opportunity on cpq_opportunity.id = o.opportunity_id and coalesce(cpq_opportunity.Platform_Type__c, '') != 'Azure – P3 Only'
-- MAGIC where oi.product_code not in ('UNIVERSAL-COMMIT-DOLLAR') and oi.product_code not like '%BUNDLE%'
-- MAGIC order by contract_number,order_number
-- MAGIC """)

-- COMMAND ----------

-- Deduplicate orders from contracts
create
or replace temporary view vw_tmp_cpq_final_contracts as (
  with duplicate_orders as (
    select
      order_id as dup_order_id,
      count(distinct contract_id)
    from
      vw_tmp_cpq_final_dup_contracts -- where
      --   lower(consumption_cloud) <> 'azure'
    group by
      order_id
    having
      count(distinct contract_id) > 1
  ),
  nonduplicate_contract_orders as (
    select
      c.account_id,
      c.contract_id,
      c.contract_number,
      c.generated_contract_number,
      c.contract_cancellation_date,
      c.contract_start_date__c,
      c.contract_end_date__c,
      c.contract_effective_end_date,
      c.is_contract_cancelled,
      c.order_id,
      c.order_number,
      c.metronome_contract_id,
      c.order_type,
      c.cpq_order_type,
      c.order_status,
      c.is_migrated_order,
      c.migration_ext_id,
      c.ns_internal_id,
      c.ns_target_type,
      c.currency_iso_code,
      c.orginal_order,
      c.original_co_term_orders,
      c.co_term_orders,
      c.order_activation_date,
      c.order_creation_date,
      c.order_item_number,
      cast(c.order_start_date as date) as order_start_date,
      cast(c.order_end_date as date) as order_end_date,
      cast(c.order_item_start_date as date) as order_item_start_date,
      cast(c.order_item_end_date as date) as order_item_end_date,
      cast(c.order_item_effective_end_date as date) as order_item_effective_end_date,
      c.cpq_cloud,
      c.consumption_cloud,
      c.service_family,
      c.product_family,
      c.product_code,
      c.metronome_product_id,
      c.cpq_usage_price,
      c.list_price,
      c.unit_price,
      c.total_price,
      c.quoted_list_price,
      c.available_quantity,
      c.contract_action,
      c.ordered_quantity,
      c.quoted_quantity,
      c.cpq_discount,
      c.cloud_royalty_perc,
      c.net_total_after_royalty,
      c.support_perc,
      c.oi_atg_tcv,
      c.is_marketplace_order,
      c.cpq_termination_convenience,
      c.order_bookings,
      c.order_amount,
      c.renewal_term,
      c.tax_amount,
      c.cpq_atr,
      c.atg_tcv,
      c.atg_arr,
      c.atg_nrr,
      c.cpq_support_per,
      c.is_cpq_autorenewal,
      c.is_cpq_multicloud,
      c.quote_id,
      c.processDate,
      c.is_parallel_contract,
      c.parallel_contracts_list,
      c.renewal_opportunity,
      c.opportunity_id
    from
      vw_tmp_cpq_final_dup_contracts c left anti
      join duplicate_orders d on c.order_id = d.dup_order_id -- where
      --   lower(consumption_cloud) <> 'azure'
  ),
  duplicate_contract_orders as (
    select
      c.account_id,
      c.contract_id,
      c.contract_number,
      c.generated_contract_number,
      c.contract_cancellation_date,
      c.contract_start_date__c,
      c.contract_end_date__c,
      c.contract_effective_end_date,
      c.is_contract_cancelled,
      c.order_id,
      c.order_number,
      c.metronome_contract_id,
      c.order_type,
      c.cpq_order_type,
      c.order_status,
      c.is_migrated_order,
      c.migration_ext_id,
      c.ns_internal_id,
      c.ns_target_type,
      c.currency_iso_code,
      c.orginal_order,
      c.original_co_term_orders,
      c.co_term_orders,
      c.order_activation_date,
      c.order_creation_date,
      c.order_item_number,
      cast(c.order_start_date as date) as order_start_date,
      cast(c.order_end_date as date) as order_end_date,
      cast(c.order_item_start_date as date) as order_item_start_date,
      cast(c.order_item_end_date as date) as order_item_end_date,
      cast(c.order_item_effective_end_date as date) as order_item_effective_end_date,
      c.cpq_cloud,
      c.consumption_cloud,
      c.service_family,
      c.product_family,
      c.product_code,
      c.metronome_product_id,
      c.cpq_usage_price,
      c.list_price,
      c.unit_price,
      c.total_price,
      c.quoted_list_price,
      c.available_quantity,
      c.contract_action,
      c.ordered_quantity,
      c.quoted_quantity,
      c.cpq_discount,
      c.cloud_royalty_perc,
      c.net_total_after_royalty,
      c.support_perc,
      c.oi_atg_tcv,
      c.is_marketplace_order,
      c.cpq_termination_convenience,
      c.order_bookings,
      c.order_amount,
      c.renewal_term,
      c.tax_amount,
      c.cpq_atr,
      c.atg_tcv,
      c.atg_arr,
      c.atg_nrr,
      c.cpq_support_per,
      c.is_cpq_autorenewal,
      c.is_cpq_multicloud,
      c.quote_id,
      c.processDate,
      c.is_parallel_contract,
      c.parallel_contracts_list,
      c.renewal_opportunity,
      c.opportunity_id
    from
      duplicate_orders d
      left join vw_tmp_cpq_final_dup_contracts c on d.dup_order_id = c.order_id -- where
      --   lower(consumption_cloud) <> 'azure'
  ),
  filter_duplicate_orders as (
    select
      c.*,
      o.Id,
      o.Type,
      o.StageName,
      case
        when c.order_type = ''
        or c.order_type is null then true
        else false
      end as o_type_flag,
      case
        when o.StageName = 'Closed Won'
        and o.Type = 'Renewal' then false
        else true
      end as exclude_flag,
      case
        when c.order_type = 'amendment' then true
        else false
      end as amend_type_flag,
      case
        when c.order_end_date >= contract_start_date__c then false
        else true
      end as exclude_date_flag,
      case
        when c.order_end_date >= contract_start_date__c
        and c.order_end_date <= contract_end_date__c then false
        else true
      end as exclude_end_date_flag,
      case
        when c.order_start_date >= contract_start_date__c
        and c.order_start_date <= contract_end_date__c then false
        else true
      end as exclude_start_date_flag
    from
      duplicate_contract_orders c
      left join cpq_opportunity o on c.renewal_opportunity = o.Id
    where
      --c.source <> 'aws_contracts' and
      o.processDate = (
        select
          max(processDate)
        from
          cpq_opportunity
      )
    order by
      c.order_start_date,
      c.generated_contract_number
  ),
  union_orders as (
    select
      *
    from
      nonduplicate_contract_orders
    union
    select
      account_id,
      contract_id,
      contract_number,
      generated_contract_number,
      contract_cancellation_date,
      contract_start_date__c,
      contract_end_date__c,
      contract_effective_end_date,
      is_contract_cancelled,
      order_id,
      order_number,
      metronome_contract_id,
      order_type,
      cpq_order_type,
      order_status,
      is_migrated_order,
      migration_ext_id,
      ns_internal_id,
      ns_target_type,
      currency_iso_code,
      orginal_order,
      original_co_term_orders,
      co_term_orders,
      order_activation_date,
      order_creation_date,
      order_item_number,
      order_start_date,
      order_end_date,
      order_item_start_date,
      order_item_end_date,
      order_item_effective_end_date,
      cpq_cloud,
      consumption_cloud,
      service_family,
      product_family,
      product_code,
      metronome_product_id,
      cpq_usage_price,
      list_price,
      unit_price,
      total_price,
      quoted_list_price,
      available_quantity,
      contract_action,
      ordered_quantity,
      quoted_quantity,
      cpq_discount,
      cloud_royalty_perc,
      net_total_after_royalty,
      support_perc,
      oi_atg_tcv,
      is_marketplace_order,
      cpq_termination_convenience,
      order_bookings,
      order_amount,
      renewal_term,
      tax_amount,
      cpq_atr,
      atg_tcv,
      atg_arr,
      atg_nrr,
      cpq_support_per,
      is_cpq_autorenewal,
      is_cpq_multicloud,
      quote_id,
      processDate,
      is_parallel_contract,
      parallel_contracts_list,
      renewal_opportunity,
      opportunity_id
    from
      filter_duplicate_orders
    where
      exclude_flag = false
      and exclude_date_flag = false
      and exclude_start_date_flag = false
      and exclude_end_date_flag = false
  )
  select
    account_id,
    contract_id,
    contract_number,
    generated_contract_number,
    contract_cancellation_date,
    contract_start_date__c,
    contract_end_date__c,
    contract_effective_end_date,
    is_contract_cancelled,
    order_id,
    order_number,
    metronome_contract_id,
    order_type,
    cpq_order_type,
    order_status,
    is_migrated_order,
    migration_ext_id,
    ns_internal_id,
    ns_target_type,
    currency_iso_code,
    orginal_order,
    original_co_term_orders,
    co_term_orders,
    order_activation_date,
    order_creation_date,
    order_item_number,
    order_start_date,
    cast(order_end_date as date) as order_end_date,
    order_item_start_date,
    order_item_end_date,
    case
      when contract_cancellation_date < order_item_effective_end_date
      and contract_cancellation_date is not null then contract_cancellation_date
      else order_item_effective_end_date
    end as order_item_effective_end_date,
    --order_item_effective_end_date,
    cpq_cloud,
    consumption_cloud,
    service_family,
    product_family,
    product_code,
    metronome_product_id,
    cpq_usage_price,
    list_price,
    unit_price,
    total_price,
    quoted_list_price,
    available_quantity,
    contract_action,
    ordered_quantity,
    quoted_quantity,
    cpq_discount,
    cloud_royalty_perc,
    net_total_after_royalty,
    support_perc,
    oi_atg_tcv,
    is_marketplace_order,
    cpq_termination_convenience,
    order_bookings,
    order_amount,
    renewal_term,
    tax_amount,
    cpq_atr,
    atg_tcv,
    atg_arr,
    atg_nrr,
    cpq_support_per,
    is_cpq_autorenewal,
    is_cpq_multicloud,
    quote_id,
    processDate,
    is_parallel_contract,
    parallel_contracts_list,
    renewal_opportunity,
    opportunity_id
  from
    union_orders
)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC table_name = 'cpq_contracts_bronze_intermediate_met_recon'
-- MAGIC full_table_name = f'{TARGET_CATALOG}.{TARGET_SCHEMA}.{table_name}'
-- MAGIC print(full_table_name)
-- MAGIC
-- MAGIC df = spark.table('vw_tmp_cpq_final_contracts')
-- MAGIC df.write.mode('overwrite').format('delta').option('overwriteSchema', 'true').partitionBy('processDate').saveAsTable(full_table_name)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(f'use {TARGET_CATALOG}.{TARGET_SCHEMA}')

-- COMMAND ----------

create or replace temp view contracts_with_cancellation_dates
as
with 
base_1
(
    select distinct account_id, 
                    contract_id, 
                    contract_cancellation_date, 
                    contract_start_date__c   
    from cpq_contracts_bronze_intermediate
),

base_2 (
select distinct 
       contract_id, 
       contract_cancellation_date,
       lag(contract_cancellation_date) over(partition by account_id order by contract_start_date__c) previous_contract_cancellation_date
from base_1 
)

select distinct o.account_id, 
       o.generated_contract_number, 
       o.orginal_order, 
       o.order_item_start_date,
       o.product_family,
       o.cpq_order_type,
       o.original_co_term_orders,
       o.contract_id,
       o.order_item_effective_end_date,
       b.previous_contract_cancellation_date
from cpq_contracts_bronze_intermediate o
left join base_2 b on o.contract_id = b.contract_id

-- COMMAND ----------

create or replace temp view update_order_end_date_check
as 
        select account_id, generated_contract_number, orginal_order, order_item_start_date, contract_id, order_item_effective_end_date
        from contracts_with_cancellation_dates
        where product_family != 'Usage'
        and cpq_order_type = 'Supersede'
        and orginal_order is not null
        and previous_contract_cancellation_date is not null

        union

        select  account_id, generated_contract_number, explode(original_co_term_orders) orginal_order, order_item_effective_end_date order_item_start_date, contract_id, order_item_effective_end_date
        from contracts_with_cancellation_dates
        where product_family != 'Usage'
        and cpq_order_type = 'Supersede'
        and original_co_term_orders is not null
        and previous_contract_cancellation_date is not null

-- COMMAND ----------

---Handeling Superseded orders effective date

MERGE INTO cpq_contracts_bronze_intermediate contracts
USING
( 
  select *, row_number() over (partition by account_id,orginal_order order by order_item_start_date) as rw
  from
     (
        select account_id, generated_contract_number, orginal_order, order_item_start_date
        from contracts_with_cancellation_dates
        where product_family != 'Usage'
        and cpq_order_type = 'Supersede'
        and orginal_order is not null
        and previous_contract_cancellation_date is not null

        union

        select  account_id, generated_contract_number, explode(original_co_term_orders) orginal_order, order_item_start_date
        from contracts_with_cancellation_dates
        where product_family != 'Usage'
        and cpq_order_type = 'Supersede'
        and original_co_term_orders is not null
        and previous_contract_cancellation_date is not null
      ) 
) supersede_orders

ON supersede_orders.orginal_order = contracts.order_id and supersede_orders.account_id = contracts.account_id and rw = 1
WHEN MATCHED AND contracts.order_item_effective_end_date > date_sub(supersede_orders.order_item_start_date, 1) THEN UPDATE SET order_item_effective_end_date = date_sub(supersede_orders.order_item_start_date, 1)

-- COMMAND ----------

---Handeling parallel contracts - based on contract id

create or replace temp view parallel_contracts as
with base_contracts
(
  select account_id, consumption_cloud, generated_contract_number, order_item_start_date, order_item_effective_end_date, contract_cancellation_date
  from cpq_contracts_bronze_intermediate
  where product_family = 'License'
  and order_status = 'Activated'
  and consumption_cloud is not null
  and lower(consumption_cloud) <> 'azure'
)

select base.account_id , base.consumption_cloud, base.generated_contract_number, base.order_item_start_date, base.order_item_effective_end_date
 , true is_parallel_contract
 , collect_list(pc.generated_contract_number) as parallel_contracts_list
from base_contracts base
inner join base_contracts pc on base.account_id = pc.account_id and base.generated_contract_number != pc.generated_contract_number 
         and base.consumption_cloud = pc.consumption_cloud
         and (
            (base.order_item_start_date between pc.order_item_start_date and pc.order_item_effective_end_date) 
              or (base.order_item_effective_end_date between pc.order_item_start_date and pc.order_item_effective_end_date)
              or (pc.order_item_start_date between base.order_item_start_date and base.order_item_effective_end_date) 
              or (pc.order_item_effective_end_date between base.order_item_start_date and base.order_item_effective_end_date)
           )

group by base.account_id, base.consumption_cloud, base.generated_contract_number, base.order_item_start_date, base.order_item_effective_end_date


-- COMMAND ----------

MERGE INTO cpq_contracts_bronze_intermediate contracts
USING parallel_contracts 

ON contracts.account_id = parallel_contracts.account_id and contracts.consumption_cloud = parallel_contracts.consumption_cloud and contracts.generated_contract_number = parallel_contracts.generated_contract_number
and contracts.order_item_start_date = parallel_contracts.order_item_start_date and contracts.order_item_effective_end_date = parallel_contracts.order_item_effective_end_date

WHEN MATCHED THEN UPDATE SET contracts.is_parallel_contract = parallel_contracts.is_parallel_contract,  contracts.parallel_contracts_list = parallel_contracts.parallel_contracts_list

-- COMMAND ----------

---Handeling parallel orders only for azure (in azure we have to consider co-term as parallel contracts)

create or replace temp view parallel_contracts_azure_only as
with base_contracts
(
  select account_id, consumption_cloud, order_id, order_item_start_date, order_item_effective_end_date, contract_cancellation_date
  from cpq_contracts_bronze_intermediate
  where product_family = 'License'
  and order_status = 'Activated'
  and consumption_cloud is not null
  and lower(consumption_cloud) = 'azure'
)

select base.account_id , base.consumption_cloud, base.order_id, base.order_item_start_date, base.order_item_effective_end_date
 , true is_parallel_contract
 , collect_list(pc.order_id) as parallel_contracts_list
from base_contracts base
inner join base_contracts pc on base.account_id = pc.account_id and base.order_id != pc.order_id
         and base.consumption_cloud = pc.consumption_cloud
         and (
            (base.order_item_start_date between pc.order_item_start_date and pc.order_item_effective_end_date) 
              or (base.order_item_effective_end_date between pc.order_item_start_date and pc.order_item_effective_end_date)
              or (pc.order_item_start_date between base.order_item_start_date and base.order_item_effective_end_date) 
              or (pc.order_item_effective_end_date between base.order_item_start_date and base.order_item_effective_end_date)
           )

group by base.account_id, base.consumption_cloud, base.order_id, base.order_item_start_date, base.order_item_effective_end_date


-- COMMAND ----------

MERGE INTO cpq_contracts_bronze_intermediate contracts
USING parallel_contracts_azure_only 

ON contracts.account_id = parallel_contracts_azure_only.account_id and contracts.consumption_cloud = parallel_contracts_azure_only.consumption_cloud and contracts.order_id = parallel_contracts_azure_only.order_id
and contracts.order_item_start_date = parallel_contracts_azure_only.order_item_start_date and contracts.order_item_effective_end_date = parallel_contracts_azure_only.order_item_effective_end_date

WHEN MATCHED THEN UPDATE SET contracts.is_parallel_contract = parallel_contracts_azure_only.is_parallel_contract,  contracts.parallel_contracts_list = parallel_contracts_azure_only.parallel_contracts_list

-- COMMAND ----------

-- MAGIC %python
-- MAGIC from datetime import date
-- MAGIC today = date.today()
-- MAGIC today_str = process_date_arg or today.strftime('%Y-%m-%d')
-- MAGIC print(today_str)
-- MAGIC
-- MAGIC
-- MAGIC intm_tbl = 'cpq_contracts_bronze_intermediate_met_recon'
-- MAGIC
-- MAGIC print(f'{contracts_bronze_table_name} : {intm_tbl}')
-- MAGIC full_table_name = f'{TARGET_CATALOG}.{TARGET_SCHEMA}.{contracts_bronze_table_name}'
-- MAGIC print(full_table_name)
-- MAGIC df = spark.table(intm_tbl)
-- MAGIC df.write.mode('overwrite').format('delta').option('mergeSchema', 'true')\
-- MAGIC         .option('replaceWhere', f"processDate = '{today_str}'")\
-- MAGIC         .partitionBy('processDate').saveAsTable(full_table_name)  

-- COMMAND ----------

-- MAGIC %python
-- MAGIC sql_str = f'''CREATE  VIEW IF NOT EXISTS {TARGET_CATALOG}.{TARGET_SCHEMA}.cpq_contracts_bronze__met_recon_vw AS
-- MAGIC           SELECT * FROM {full_table_name}
-- MAGIC           WHERE processDate = (select max(processDate) from {full_table_name})
-- MAGIC        '''
-- MAGIC        
-- MAGIC print(sql_str)
-- MAGIC spark.sql(sql_str)

-- COMMAND ----------

select count(account_id) from cpq_contracts_bronze_vw

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(f"""
-- MAGIC -- Silver tables creation
-- MAGIC
-- MAGIC CREATE OR REPLACE TEMPORARY VIEW tmp_cpq_latest_contracts_vw AS
-- MAGIC
-- MAGIC select base.account_id,
-- MAGIC base.contract_id,
-- MAGIC base.generated_contract_number,
-- MAGIC base.contract_cancellation_date,
-- MAGIC base.contract_start_date__c,
-- MAGIC base.contract_end_date__c,
-- MAGIC base.contract_effective_end_date,
-- MAGIC base.is_contract_cancelled,
-- MAGIC base.order_id,
-- MAGIC base.order_number,
-- MAGIC base.metronome_contract_id,
-- MAGIC base.order_type,
-- MAGIC base.cpq_order_type,
-- MAGIC base.order_status,
-- MAGIC base.is_migrated_order,
-- MAGIC base.ns_internal_id,
-- MAGIC base.ns_target_type,
-- MAGIC base.currency_iso_code,
-- MAGIC base.orginal_order,
-- MAGIC base.original_co_term_orders,
-- MAGIC base.co_term_orders,
-- MAGIC base.order_activation_date,
-- MAGIC base.order_creation_date, 
-- MAGIC base.order_start_date, 
-- MAGIC base.order_end_date, 
-- MAGIC base.order_item_number,
-- MAGIC base.order_item_start_date, 
-- MAGIC base.order_item_end_date, 
-- MAGIC base.order_item_effective_end_date,
-- MAGIC base.cpq_cloud,
-- MAGIC base.consumption_cloud,
-- MAGIC base.service_family,
-- MAGIC base.product_family, 
-- MAGIC replace(replace(upper(base.product_code), 'GCP_', ''),'AZURE_','') as sku,
-- MAGIC base.metronome_product_id,
-- MAGIC base.cpq_usage_price,
-- MAGIC base.list_price,
-- MAGIC base.unit_price,
-- MAGIC base.total_price,
-- MAGIC base.quoted_list_price,
-- MAGIC base.available_quantity,
-- MAGIC base.contract_action,
-- MAGIC base.ordered_quantity,
-- MAGIC base.quoted_quantity,
-- MAGIC base.cpq_discount,
-- MAGIC base.oi_atg_tcv,
-- MAGIC base.cloud_royalty_perc,
-- MAGIC base.net_total_after_royalty,
-- MAGIC base.support_perc,
-- MAGIC base.is_marketplace_order,
-- MAGIC base.cpq_termination_convenience,
-- MAGIC base.order_bookings,
-- MAGIC base.order_amount,
-- MAGIC base.renewal_term,
-- MAGIC base.tax_amount,
-- MAGIC base.cpq_atr,
-- MAGIC base.atg_tcv,
-- MAGIC base.atg_arr,
-- MAGIC base.atg_nrr,
-- MAGIC base.cpq_support_per,
-- MAGIC base.is_cpq_autorenewal,
-- MAGIC base.is_cpq_multicloud,
-- MAGIC base.quote_id,
-- MAGIC base.processDate as updated_date,
-- MAGIC base.is_parallel_contract,
-- MAGIC base.parallel_contracts_list,
-- MAGIC base.renewal_opportunity
-- MAGIC
-- MAGIC from {contracts_bronze_table_name} base
-- MAGIC
-- MAGIC where account_id != '0014N00002BCGRqQAP'   -- DD4.0 - Test Account
-- MAGIC and processDate = (select max(processDate) FROM {contracts_bronze_table_name})
-- MAGIC """)

-- COMMAND ----------

select count(account_id) from tmp_cpq_latest_contracts_vw

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC ## persisting cpq rates to the silver delta table
-- MAGIC
-- MAGIC
-- MAGIC full_table_name = f'{TARGET_CATALOG}.{TARGET_SCHEMA}.{rates_silver_table_name}'
-- MAGIC print(full_table_name)
-- MAGIC
-- MAGIC df = spark.sql("""SELECT * FROM tmp_cpq_latest_contracts_vw WHERE product_family = 'Usage'""")
-- MAGIC df.write.mode('overwrite').format('delta').option("overwriteSchema", "true").saveAsTable(full_table_name)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(spark.sql(f"select count(account_id) from {TARGET_CATALOG}.{TARGET_SCHEMA}.{rates_silver_table_name}"))

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC ## persisting cpq contracts to the silver delta table
-- MAGIC
-- MAGIC
-- MAGIC full_table_name = f'{TARGET_CATALOG}.{TARGET_SCHEMA}.{contracts_silver_table_name}'
-- MAGIC print(full_table_name)
-- MAGIC
-- MAGIC df = spark.sql("""SELECT * FROM tmp_cpq_latest_contracts_vw WHERE product_family != 'Usage'""")
-- MAGIC df.write.mode('overwrite').format('delta').option("overwriteSchema", "true").saveAsTable(full_table_name)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(spark.sql(f"select count(account_id) from {TARGET_CATALOG}.{TARGET_SCHEMA}.{contracts_silver_table_name}"))

-- COMMAND ----------


