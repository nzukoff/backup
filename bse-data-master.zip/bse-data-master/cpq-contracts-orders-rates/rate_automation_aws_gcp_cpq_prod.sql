-- Databricks notebook source
-- MAGIC %python
-- MAGIC dbutils.widgets.text("environment", 'integration') # development, integration, production
-- MAGIC environment = dbutils.widgets.get("environment")
-- MAGIC print(environment)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.conf.set("spark.databricks.unityCatalog.allowCrossMetastoreViews","true")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC if environment == 'production':
-- MAGIC   print("Environment: Production")
-- MAGIC   SOURCE_CATALOG = 'main'
-- MAGIC   SOURCE_SCHEMA = 'it_cpq_silver'
-- MAGIC
-- MAGIC   TARGET_CATALOG = 'main'
-- MAGIC   TARGET_SCHEMA = 'it_cpq_silver'
-- MAGIC   TABLE_PREFIX = ''
-- MAGIC elif environment == 'soxdev':
-- MAGIC   print("Environment: Sox Dev")
-- MAGIC   SOURCE_CATALOG = 'integration'
-- MAGIC   SOURCE_SCHEMA = 'it_consumption_silver'
-- MAGIC
-- MAGIC   TARGET_CATALOG = 'integration'
-- MAGIC   TARGET_SCHEMA = 'it_consumption_silver'
-- MAGIC   TABLE_PREFIX = ''
-- MAGIC else: 
-- MAGIC   print("Environment: Integration/UAT")
-- MAGIC   SOURCE_CATALOG = 'integration'
-- MAGIC   SOURCE_SCHEMA = 'it_cpq_silver'
-- MAGIC
-- MAGIC   TARGET_CATALOG = 'integration'
-- MAGIC   TARGET_SCHEMA = 'it_cpq_silver'
-- MAGIC   TABLE_PREFIX = ''
-- MAGIC print(f'Using {SOURCE_CATALOG}.{SOURCE_SCHEMA}')
-- MAGIC spark.sql(f'use {SOURCE_CATALOG}.{SOURCE_SCHEMA}')

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #Merging completed orders with CPQ active orders

-- COMMAND ----------

create or replace temp view tmp_cpq_aws_gcp_contracts_orders_vw as
select account_id, order_id, contract_id, generated_contract_number, contract_cancellation_date, is_contract_cancelled, is_parallel_contract, order_number, order_type, cpq_order_type, order_status, is_migrated_order, order_activation_date, order_item_number,order_start_date,order_end_date , order_item_start_date, order_item_end_date, 
case when contract_cancellation_date < order_item_effective_end_date 
     and contract_cancellation_date is not null 
     then contract_cancellation_date 
else order_item_effective_end_date
end as order_item_effective_end_date,
cpq_cloud, consumption_cloud, 
case when product_family = 'License' and sku like '%PLATFORM%' then 'PLATFORM'
     when product_family = 'License' then 'Workload Commitment' 
else product_family end as product_family, 
sku,
-- this is to handle $1 commits
case when product_family = 'License' and sku not like '%PLATFORM%'       
            and ordered_quantity = 1 and oi_atg_tcv = 0
     then 0 
    else ordered_quantity
end as committed_quantity, 
co_term_orders, parallel_contracts_list, ns_internal_id, renewal_opportunity, case when is_migrated_order = true then 'cpq_migrated' else 'cpq' end as source,
contract_start_date__c, contract_end_date__c, contract_effective_end_date, cpq_discount, oi_atg_tcv as order_line_item_tcv
from cpq_contracts_silver
union all
select account_id, null, null, generated_contract_number, null, null, false, order_number, null, null, contract_status, false, Bookings_Date, null, Order_Start_Date, Order_End_Date, order_item_start_date,order_item_end_date,order_item_effective_end_date, cpq_cloud, cpq_cloud, case when product_family = 'Workloads Commitment' then 'Workload Commitment' else product_family end as product_family, sku, gross_amount, null, null, null, null, case when contract_status = '' then 'netsuite' else 'aws_contracts' end as source, order_item_start_date,order_item_end_date,order_item_effective_end_date, null, gross_amount
from main.it_cpq_silver.aws_contracts_completed_aws_orders


-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC silver_table_name = 'cpq_aws_gcp_contracts_orders'
-- MAGIC full_table_name = f'{TARGET_CATALOG}.{TARGET_SCHEMA}.{silver_table_name}'
-- MAGIC
-- MAGIC df = spark.sql("""SELECT * FROM tmp_cpq_aws_gcp_contracts_orders_vw""")
-- MAGIC print(full_table_name)
-- MAGIC
-- MAGIC df.write.mode('overwrite').format('delta').option('overwriteSchema', 'true').saveAsTable(full_table_name)

-- COMMAND ----------

select count(1) from cpq_aws_gcp_contracts_orders

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Merging completed orders rates with CPQ active orders rates

-- COMMAND ----------

create or replace temp view cpq_aws_contracts_orders_price_intmd_vw as
with duplicate_orders as (
  select
    order_id as dup_order_id, count(distinct contract_id)
  from
    cpq_rates_silver
  group by
    order_id
  having
    count(distinct contract_id) > 1
),
exclude_duplicate_orders as (
  select distinct contract_id, order_id
  from cpq_rates_silver r
  inner join duplicate_orders o on o.dup_order_id = r.order_id
  where contract_start_date__c is not null and order_end_date is not null
    and order_end_date <= contract_start_date__c
),
pricing_base_data as
(
  select account_id, generated_contract_number, contract_cancellation_date, is_contract_cancelled, is_parallel_contract, order_number, order_type, cpq_order_type, order_status, is_migrated_order, 
         order_activation_date, order_item_number, order_start_date, order_end_date, order_item_start_date, order_item_end_date, 
         case when order_id = '8018Y0000035tdhQAA' then '2022-11-30' else order_item_effective_end_date end as order_item_effective_end_date, --temp fix for comcast
         cpq_cloud, consumption_cloud, product_family, sku, 
         cpq_usage_price, list_price, unit_price, quoted_list_price, co_term_orders, parallel_contracts_list, ns_internal_id, z.name zab_subscription, 
         case when is_migrated_order = true then 'cpq_migrated' else 'cpq' end as source
  from cpq_rates_silver a
  left anti join exclude_duplicate_orders edo 
    on a.contract_id = edo.contract_id and a.order_id = edo.order_id
  left join (
    select 
      id, 
      name, 
      processTimestamp,
      row_number() over (partition by id order by processTimestamp desc) as rn
    from main.netsuite2_bronze_hourly.customrecordzab_subscription
  ) z
    on cast(a.ns_internal_id as string) = cast(z.id as string) and z.rn = 1

  union all

  select account_id, generated_contract_number, null, null, false, order_number, null, null, contract_status, false, Bookings_Date, null, Order_Start_Date, Order_End_Date, 
         order_item_start_date, order_item_end_date, order_item_effective_end_date, cpq_cloud, cpq_cloud, 'Usage' as product_family, sku, 
         usage_price, null, null, null, null, null, null, contract_number,
         case when contract_status = '' then 'netsuite' else 'aws_contracts' end as source
  from main.it_cpq_silver.aws_contracts_completed_orders_rates
)

select account_id, generated_contract_number, contract_cancellation_date, is_contract_cancelled, is_parallel_contract, order_number, order_type, cpq_order_type, order_status, is_migrated_order, 
  order_activation_date, order_item_number, order_start_date, order_end_date , 
           
           case when (is_migrated_order = false and order_status = 'Activated' ) or source = 'aws_contracts' or zab_subscription is null then order_item_start_date  
           
    -- handled netsuite orginal rates that were not migrated to CPQ - as per Kashturi only latest rates/orderitems were migrated to the cpq 
    when date_add(lag(order_item_effective_end_date)
         over (partition by account_id, zab_subscription, consumption_cloud, sku order by order_item_effective_end_date, order_item_start_date, order_status desc), 1) is null
      then order_item_start_date 
    when date_add(lag(order_item_effective_end_date)
         over (partition by account_id, zab_subscription, consumption_cloud, sku order by order_item_effective_end_date, order_item_start_date, order_status desc), 1) < order_item_start_date 
      then order_item_start_date 
    else date_add(lag(order_item_effective_end_date)
         over (partition by account_id, zab_subscription, consumption_cloud, sku order by order_item_effective_end_date, order_item_start_date, order_status desc), 1)
  end as order_item_start_date, 
           
  order_item_end_date, order_item_effective_end_date, cpq_cloud, consumption_cloud, product_family, sku, cpq_usage_price, list_price, co_term_orders, parallel_contracts_list, ns_internal_id, zab_subscription, source
      
from pricing_base_data

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC silver_table_name = 'cpq_aws_contracts_orders_price_intmd'
-- MAGIC full_table_name = f'{TARGET_CATALOG}.{TARGET_SCHEMA}.{silver_table_name}'
-- MAGIC print(full_table_name)
-- MAGIC
-- MAGIC df = spark.sql("""SELECT * FROM cpq_aws_contracts_orders_price_intmd_vw where order_item_start_date < order_item_effective_end_date""")
-- MAGIC df.write.mode('overwrite').format('delta').option('overwriteSchema', 'true').saveAsTable(full_table_name)

-- COMMAND ----------

---Handeling parallel contracts

create or replace temp view parallel_pricing as
with orders_price_intmd
(
  select distinct account_id, consumption_cloud, generated_contract_number, order_item_start_date, order_item_effective_end_date, contract_cancellation_date, zab_subscription
  from cpq_aws_contracts_orders_price_intmd
  where consumption_cloud is not null
)

select base.account_id , base.consumption_cloud, base.generated_contract_number,  base.order_item_start_date, base.order_item_effective_end_date
 , true is_parallel_contract
 , collect_list(distinct pc.generated_contract_number) as parallel_contracts_list
from orders_price_intmd base
inner join orders_price_intmd pc on base.account_id = pc.account_id 
         and (base.generated_contract_number is null or pc.generated_contract_number is null or base.generated_contract_number != pc.generated_contract_number) 
         and base.consumption_cloud = pc.consumption_cloud
         and (
            (base.order_item_start_date between pc.order_item_start_date and pc.order_item_effective_end_date) 
              or (base.order_item_effective_end_date between pc.order_item_start_date and pc.order_item_effective_end_date)
              or (pc.order_item_start_date between base.order_item_start_date and base.order_item_effective_end_date) 
              or (pc.order_item_effective_end_date between base.order_item_start_date and base.order_item_effective_end_date)
           )

group by base.account_id, base.consumption_cloud, base.generated_contract_number, base.order_item_start_date, base.order_item_effective_end_date


-- COMMAND ----------

MERGE INTO cpq_aws_contracts_orders_price_intmd price_intmd
USING parallel_pricing 

ON price_intmd.account_id = parallel_pricing.account_id and price_intmd.consumption_cloud = parallel_pricing.consumption_cloud and ( (price_intmd.generated_contract_number is null and parallel_pricing.generated_contract_number is null) or  (price_intmd.generated_contract_number = parallel_pricing.generated_contract_number ))
    and price_intmd.order_item_start_date = parallel_pricing.order_item_start_date and price_intmd.order_item_effective_end_date = parallel_pricing.order_item_effective_end_date 

WHEN MATCHED THEN UPDATE SET price_intmd.is_parallel_contract = parallel_pricing.is_parallel_contract,  price_intmd.parallel_contracts_list = parallel_pricing.parallel_contracts_list

-- COMMAND ----------

create or replace temp view order_workspaces_vw as
with paltform_sub as (
select OrderNumber__c, Id as BS_SFDC_ID, name as BSID, Start_Date__c, End_Date__c
from main.sfdc_bronze.platformsubscription__c where processDate = (select max(processDate) from main.sfdc_bronze.platformsubscription__c)
and OrderNumber__c is not null
),
workspace as (
select Business_Subscription__c, workspaceId__c, workspaceName__c, workspaceStatus__c, Id as workspace_sfdc_id, Name workspace_name from main.sfdc_bronze.workspace__c where processDate = (select max(processDate) from main.sfdc_bronze.workspace__c)
and Business_Subscription__c is not null
),
final_sfdc_workspace as (
select distinct p.*, c.generated_contract_number, w.* from paltform_sub p
left join workspace w on p.BS_SFDC_ID = w.Business_Subscription__c
left join main.it_cpq_silver.cpq_contracts_silver c on p.OrderNumber__c = c.order_number
where workspace_sfdc_id is not null 
and OrderNumber__c in ('00022435','00024074') -- temp cigna fix
),
latest_zab_subscription as
(
  select distinct *
  from 
    (select *,
      DENSE_RANK() OVER (PARTITION BY workspaceId ORDER BY sub_start_date desc, sub_end_date desc) AS workspace_mapping_rank
      from main.it_finance_silver.zab_worspace_mapping
    )
  where workspace_mapping_rank = 1
)

select distinct a.account_id, a.generated_contract_number, ns_internal_id, a.zab_subscription, zw.workspaceId as workspace_id, order_item_start_date, order_item_end_date, order_item_effective_end_date, cpq_cloud, consumption_cloud, product_family, sku, cpq_usage_price, list_price, source
from
(
  select cpq_cloud,ns_internal_id,*
  from cpq_aws_contracts_orders_price_intmd 
  where is_parallel_contract = true 
) a
inner join latest_zab_subscription zw on a.zab_subscription = zw.zab_subscription
where consumption_cloud != 'Azure'
and a.zab_subscription is not null
union
select distinct a.account_id, a.generated_contract_number, ns_internal_id, a.zab_subscription, sw.workspaceId__c as workspace_id, order_item_start_date, order_item_end_date, order_item_effective_end_date, cpq_cloud, consumption_cloud, product_family, sku, cpq_usage_price, list_price, source
from
(
  select cpq_cloud,ns_internal_id,*
  from cpq_aws_contracts_orders_price_intmd 
  where is_parallel_contract = true 
) a
inner join final_sfdc_workspace sw on a.generated_contract_number = sw.generated_contract_number
where consumption_cloud != 'Azure'
and sw.generated_contract_number is not null

-- COMMAND ----------

create or replace temp view cpq_aws_gcp_usage_prices_vw as
with base as
(
  select * 
  from cpq_aws_contracts_orders_price_intmd 
  where is_parallel_contract = true 
  and consumption_cloud != 'Azure'
),

begindates as 
(
  select distinct account_id, sku, start_date
  from ((select account_id, sku, order_item_start_date as start_date from base)
        union all
        (select account_id, sku, date_add(order_item_effective_end_date, 1) as start_date from base)
       )
),
enddates as 
(
  select distinct account_id, sku, end_date
  from ((select account_id, sku, date_add(order_item_start_date, -1) as end_date from base)
        union all
        (select account_id, sku, order_item_effective_end_date as end_date from base)
       )
),
datepair as 
(
  select *
  from (select d1.account_id, d1.sku, d1.start_date,
               MIN(d2.end_date) as end_date
        from begindates d1 
        left outer join enddates d2
        on d1.sku = d2.sku and d1.start_date <= d2.end_date 
        and d1.account_id = d2.account_id
        group by d1.account_id, d1.sku, d1.start_date
       ) t
  where start_date <= end_date
)

select base.account_id, base.sku, base.consumption_cloud, dp.start_date as effective_start_date, dp.end_date as effective_end_date
, min(cpq_usage_price) as cpq_usage_price
, min(list_price) as list_price
, cast(collect_set(source) as string) as source

from datepair dp 
join base on dp.sku = base.sku and dp.account_id = base.account_id
          and dp.start_date >= base.order_item_start_date 
          and dp.end_date <= base.order_item_effective_end_date        
group by base.account_id, base.sku, base.consumption_cloud, dp.start_date, dp.end_date


-- COMMAND ----------

create or replace temp view tmp_cpq_aws_gcp_usage_rates_vw as

select account_id, consumption_cloud, order_item_start_date as effective_start_date, order_item_effective_end_date as effective_end_date 
, sku, cpq_usage_price as usage_price, list_price, is_parallel_contract, null as workspace_id  -- accounts don't have any parallel contracts
, source
--, row_number() over (partition by account_id, consumption_cloud, sku order by order_item_effective_end_date desc, order_item_start_date desc) as contract_order_desc
from cpq_aws_contracts_orders_price_intmd 
where consumption_cloud != 'Azure'
and is_parallel_contract = false 

union

select account_id, consumption_cloud, order_item_start_date, order_item_effective_end_date, 
sku, cpq_usage_price, list_price, true as is_parallel_contract, workspace_id
, source
--, row_number() over (partition by account_id, consumption_cloud, sku, workspace_id order by order_item_effective_end_date desc, order_item_start_date desc) as contract_order_desc
from order_workspaces_vw 

union

select account_id, consumption_cloud, effective_start_date, effective_end_date
, sku, cpq_usage_price, list_price, true as is_parallel_contract, null
, source
--, row_number() over (partition by account_id, consumption_cloud, sku order by effective_end_date desc, effective_start_date desc) as contract_order_desc
from cpq_aws_gcp_usage_prices_vw


-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC silver_table_name = 'cpq_aws_gcp_usage_rates'
-- MAGIC full_table_name = f'{TARGET_CATALOG}.{TARGET_SCHEMA}.{silver_table_name}'
-- MAGIC print(full_table_name)
-- MAGIC
-- MAGIC df = spark.sql("""SELECT * FROM tmp_cpq_aws_gcp_usage_rates_vw""")
-- MAGIC df.write.mode('overwrite').format('delta').option('overwriteSchema', 'true').saveAsTable(full_table_name)

-- COMMAND ----------

create view if not exists cpq_aws_gcp_usage_rates_stg_vw as
with base_aws_contracts as
(
  select *
  from main.fin_live_gold.aws_contracts a      --owned by finance table; we can remove it later on
  left join cpq_rates_silver b on a.sfdc_account_id = b.account_id and lower(a.platform_type) = lower(b.consumption_cloud)
  where (a.Contract_status in ('Active','Future') or (a.Contract_status = 'Completed' and a.Order_Start_Date >= '2022-01-01'))
  and b.account_id is null and Line_Item = 'Workload Commitment'
  and platform_type != 'Azure'
  and MC not like '%Flex%'
),

aws_contracts_not_migrated as
(
  
      select distinct a.SFDC_Account_ID as account_id, Platform_Type as consumption_cloud, a.Order_Line_Start_Date as effective_start_date, a.Order_Effective_End_Date as effective_end_date, 
      stack(31,'STANDARD_JOBS_LIGHT_COMPUTE',STANDARD_JOBS_LIGHT_COMPUTE, 'STANDARD_JOBS_COMPUTE', STANDARD_JOBS_COMPUTE, 'STANDARD_ALL_PURPOSE_COMPUTE', STANDARD_ALL_PURPOSE_COMPUTE,'STANDARD_SQL_COMPUTE', STANDARD_SQL_COMPUTE, 'PREMIUM_JOBS_LIGHT_COMPUTE',PREMIUM_JOBS_LIGHT_COMPUTE,'PREMIUM_JOBS_COMPUTE',PREMIUM_JOBS_COMPUTE,'PREMIUM_ALL_PURPOSE_COMPUTE',PREMIUM_ALL_PURPOSE_COMPUTE,'PREMIUM_SQL_COMPUTE',PREMIUM_SQL_COMPUTE,'PREMIUM_SERVERLESS_SQL_COMPUTE',PREMIUM_SERVERLESS_SQL_COMPUTE, 'ENTERPRISE_JOBS_LIGHT_COMPUTE',ENTERPRISE_JOBS_LIGHT_COMPUTE,'ENTERPRISE_JOBS_COMPUTE',ENTERPRISE_JOBS_COMPUTE,'ENTERPRISE_ALL_PURPOSE_COMPUTE',ENTERPRISE_ALL_PURPOSE_COMPUTE, 'ENTERPRISE_SQL_COMPUTE', ENTERPRISE_SQL_COMPUTE, 'ENTERPRISE_SERVERLESS_SQL_COMPUTE',ENTERPRISE_SERVERLESS_SQL_COMPUTE, 'STANDARD_DLT_CORE_COMPUTE',STANDARD_DLT_CORE_COMPUTE, 'STANDARD_DLT_PRO_COMPUTE',STANDARD_DLT_PRO_COMPUTE, 'STANDARD_DLT_ADVANCED_COMPUTE',STANDARD_DLT_ADVANCED_COMPUTE, 'PREMIUM_DLT_CORE_COMPUTE',PREMIUM_DLT_CORE_COMPUTE, 'PREMIUM_DLT_PRO_COMPUTE',PREMIUM_DLT_PRO_COMPUTE, 'PREMIUM_DLT_ADVANCED_COMPUTE', PREMIUM_DLT_ADVANCED_COMPUTE, 'ENTERPRISE_DLT_CORE_COMPUTE',ENTERPRISE_DLT_CORE_COMPUTE, 'ENTERPRISE_DLT_PRO_COMPUTE',ENTERPRISE_DLT_PRO_COMPUTE, 'ENTERPRISE_DLT_ADVANCED_COMPUTE',ENTERPRISE_DLT_ADVANCED_COMPUTE, 'PREMIUM_SERVERLESS_SQL_COMPUTE_US_EAST_N_VIRGINIA',PREMIUM_SERVERLESS_SQL_COMPUTE_US_EAST_N_VIRGINIA, 'PREMIUM_SERVERLESS_SQL_COMPUTE_US_WEST_OREGON',PREMIUM_SERVERLESS_SQL_COMPUTE_US_WEST_OREGON, 'PREMIUM_SERVERLESS_SQL_COMPUTE_EUROPE_IRELAND',PREMIUM_SERVERLESS_SQL_COMPUTE_EUROPE_IRELAND, 'PREMIUM_SERVERLESS_SQL_COMPUTE_AP_SYDNEY',PREMIUM_SERVERLESS_SQL_COMPUTE_AP_SYDNEY, 'ENTERPRISE_SERVERLESS_SQL_COMPUTE_US_EAST_N_VIRGINIA',ENTERPRISE_SERVERLESS_SQL_COMPUTE_US_EAST_N_VIRGINIA ,'ENTERPRISE_SERVERLESS_SQL_COMPUTE_US_WEST_OREGON',ENTERPRISE_SERVERLESS_SQL_COMPUTE_US_WEST_OREGON, 'ENTERPRISE_SERVERLESS_SQL_COMPUTE_EUROPE_IRELAND',ENTERPRISE_SERVERLESS_SQL_COMPUTE_EUROPE_IRELAND, 'ENTERPRISE_SERVERLESS_SQL_COMPUTE_AP_SYDNEY',ENTERPRISE_SERVERLESS_SQL_COMPUTE_AP_SYDNEY) as (sku, usage_price), null as list_price , false as is_parallel_contract, null as workspace_id, 'aws_contracts_not_migrated' as source
      from base_aws_contracts a
),

new_skus as
(
  select distinct a.consumption_cloud, a.sku, regexp_extract(a.sku,'(\\w+)_') as old_sku
  from cpq_aws_gcp_usage_rates a
  left join aws_contracts_not_migrated b on a.consumption_cloud = b.consumption_cloud and a.sku = b.sku and b.source like '%aws_contracts%' 
  where a.source like '%cpq%' and b.sku is null
),

final_aws_gcp_rates as
( 

      select *
      from cpq_aws_gcp_usage_rates
      
      union 
      
      select *
      from aws_contracts_not_migrated

      union
      
      select distinct account_id, rates.consumption_cloud, effective_start_date, effective_end_date, new_skus.sku as sku, usage_price, list_price, is_parallel_contract, workspace_id, source
      from new_skus 
      inner join aws_contracts_not_migrated rates on new_skus.consumption_cloud = rates.consumption_cloud and new_skus.old_sku = rates.sku and source = 'aws_contracts_not_migrated'

)

select account_id, consumption_cloud, cast(effective_start_date as date) as effective_start_date, cast(effective_end_date as date) as effective_end_date, sku as product_code, usage_price, list_price, is_parallel_contract, workspace_id, source, dense_rank() OVER (PARTITION BY account_id, consumption_cloud, sku ORDER BY effective_end_date) as rank
from final_aws_gcp_rates where workspace_id is null

union

select account_id, consumption_cloud, cast(effective_start_date as date) as effective_start_date, cast(effective_end_date as date) as effective_end_date, sku as product_code, usage_price, list_price,  is_parallel_contract, workspace_id, source, null as rank
from final_aws_gcp_rates where workspace_id is not null



-- COMMAND ----------

describe cpq_aws_gcp_usage_rates_stg_vw

-- COMMAND ----------

-- Deduplicate orders from contracts
create
view if not exists cpq_aws_gcp_filtered_contracts_orders_vw as (
  with duplicate_orders as (
    select
      order_id as dup_order_id,
      count(distinct contract_id)
    from
      cpq_aws_gcp_contracts_orders
    group by
      order_id
    having
      count(distinct contract_id) > 1
  ),
  nonduplicate_contract_orders as (
    select
      c.account_id,
      c.order_id,
      c.contract_id,
      c.generated_contract_number,
      c.contract_cancellation_date,
      c.is_contract_cancelled,
      c.is_parallel_contract,
      c.order_number,
      c.order_type,
      c.cpq_order_type,
      c.order_status,
      c.is_migrated_order,
      c.order_activation_date,
      c.order_item_number,
      cast(c.order_start_date as date) as order_start_date,
      cast(c.order_end_date as date) as order_end_date,
      cast(c.order_item_start_date as date) as order_item_start_date,
      cast(c.order_item_end_date as date) as order_item_end_date,
      cast(c.order_item_effective_end_date as date) as order_item_effective_end_date,
      c.cpq_cloud,
      c.consumption_cloud,
      c.product_family,
      c.sku as product_code,
      c.committed_quantity,
      c.co_term_orders,
      c.parallel_contracts_list,
      c.ns_internal_id,
      c.renewal_opportunity,
      c.source,
      c.contract_start_date__c,
      c.contract_end_date__c,
      c.contract_effective_end_date,
      c.cpq_discount,
      c.order_line_item_tcv
    from
      cpq_aws_gcp_contracts_orders c left anti
      join duplicate_orders d on c.order_id = d.dup_order_id
  ),
  duplicate_contract_orders as (
    select
      c.account_id,
      c.order_id,
      c.contract_id,
      c.generated_contract_number,
      c.contract_cancellation_date,
      c.is_contract_cancelled,
      c.is_parallel_contract,
      c.order_number,
      c.order_type,
      c.cpq_order_type,
      c.order_status,
      c.is_migrated_order,
      c.order_activation_date,
      c.order_item_number,
      cast(c.order_start_date as date) as order_start_date,
      cast(c.order_end_date as date) as order_end_date,
      cast(c.order_item_start_date as date) as order_item_start_date,
      cast(c.order_item_end_date as date) as order_item_end_date,
      cast(c.order_item_effective_end_date as date) as order_item_effective_end_date,
      c.cpq_cloud,
      c.consumption_cloud,
      c.product_family,
      c.sku as product_code,
      c.committed_quantity,
      c.co_term_orders,
      c.parallel_contracts_list,
      c.ns_internal_id,
      c.renewal_opportunity,
      c.source,
      c.contract_start_date__c,
      c.contract_end_date__c,
      c.contract_effective_end_date,
      c.cpq_discount,
      c.order_line_item_tcv
    from
      duplicate_orders d
      left join cpq_aws_gcp_contracts_orders c on d.dup_order_id = c.order_id
  ),
  filter_duplicate_orders as (
    select
      c.*,
      o.Id,
      o.Type,
      o.StageName,
      case
        when c.order_type = ''
        or c.order_type is null then true
        else false
      end as o_type_flag,
      case
        when o.StageName = 'Closed Won'
        and o.Type = 'Renewal' then false
        else true
      end as exclude_flag,
      case
        when c.order_type = 'amendment' then true
        else false
      end as amend_type_flag,
      case
        when c.order_end_date >= contract_start_date__c then false
        else true
      end as exclude_date_flag
    from
      duplicate_contract_orders c
      left join main.sfdc_bronze.opportunity o on c.renewal_opportunity = o.Id
    where
      --c.source <> 'aws_contracts' and
      o.processDate = (
        select
          max(processDate)
        from
          main.sfdc_bronze.opportunity
      )
    order by
      c.order_start_date,
      c.generated_contract_number
  )
  select
    *
  from
    nonduplicate_contract_orders
  union
  select
    account_id,
    order_id,
    contract_id,
    generated_contract_number,
    contract_cancellation_date,
    is_contract_cancelled,
    is_parallel_contract,
    order_number,
    order_type,
    cpq_order_type,
    order_status,
    is_migrated_order,
    order_activation_date,
    order_item_number,
    order_start_date,
    order_end_date,
    order_item_start_date,
    order_item_end_date,
    order_item_effective_end_date,
    cpq_cloud,
    consumption_cloud,
    product_family,
    product_code,
    committed_quantity,
    co_term_orders,
    parallel_contracts_list,
    ns_internal_id,
    renewal_opportunity,
    source,
    contract_start_date__c,
    contract_end_date__c,
    contract_effective_end_date,
    cpq_discount,
    order_line_item_tcv
  from
    filter_duplicate_orders
  where
    exclude_flag = false
    and exclude_date_flag = false
)

-- COMMAND ----------

describe cpq_aws_gcp_filtered_contracts_orders_vw

-- COMMAND ----------

create view if not exists cpq_aws_gcp_contracts_orders_stg_vw as
with base_aws_contracts as
(
  select a.*
  from main.fin_live_gold.aws_contracts a
  left join cpq_rates_silver b on a.sfdc_account_id = b.account_id and lower(a.platform_type) = lower(b.consumption_cloud)
  where (a.Contract_status in ('Active','Future') or (a.Contract_status = 'Completed' and a.Order_Start_Date >= '2022-01-01'))
  and b.account_id is null 
)

select account_id, order_id, contract_id, generated_contract_number, contract_cancellation_date, is_contract_cancelled, is_parallel_contract, order_number, order_type, cpq_order_type, order_status, is_migrated_order, order_activation_date, order_item_number, cast(order_start_date as date) as order_start_date, cast(order_end_date as date) as order_end_date, cast(order_item_start_date as date) as order_item_start_date, cast(order_item_end_date as date) as order_item_end_date, cast(order_item_effective_end_date as date) as order_item_effective_end_date, cpq_cloud, consumption_cloud, product_family, product_code, committed_quantity, co_term_orders, parallel_contracts_list, ns_internal_id, renewal_opportunity, source, contract_start_date__c, contract_end_date__c, contract_effective_end_date, cpq_discount, order_line_item_tcv
from cpq_aws_gcp_filtered_contracts_orders_vw

union

select distinct a.SFDC_Account_ID as account_id, null, null, ifnull(Subscription_ID,a.sales_order) generated_contract_number,  null, null, false,
a.sales_order as order_number, null, null, contract_status, false, Bookings_Date, null, cast(a.Order_Start_Date as date), cast(a.Order_End_Date as date), cast(a.Order_Line_Start_Date as date) as order_item_start_date, cast(a.Order_Line_End_Date as date) as order_item_end_date, cast(a.Order_Effective_End_Date  as date) as order_item_effective_end_date, Platform_Type as cpq_cloud, case when Platform_Type = 'MC - Flex' then 'Flex' else Platform_Type end as consumption_cloud,line_item as product_family, case when line_item = 'Workload Commitment' then concat(Platform_Type,'-COMMIT-DOLLAR') end as product_code, a.gross_amount, null, null, null, null, 'aws_contracts_not_migrated' as source, cast(a.Order_Line_Start_Date as date) as order_item_start_date, cast(a.Order_Line_End_Date as date) as order_item_end_date, cast(a.Order_Effective_End_Date  as date) as order_item_effective_end_date, null, gross_amount
from base_aws_contracts a

-- COMMAND ----------

describe cpq_aws_gcp_contracts_orders_stg_vw

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #Rates Final Validation

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC ## Raise error if there are duplicates
-- MAGIC
-- MAGIC df = spark.sql(f"""
-- MAGIC                 select * from cpq_aws_gcp_usage_rates_stg_vw base
-- MAGIC                 inner join cpq_aws_gcp_usage_rates_stg_vw pc on base.account_id = pc.account_id        
-- MAGIC                          and base.consumption_cloud = pc.consumption_cloud 
-- MAGIC                          and (base.effective_start_date  != pc.effective_start_date or base.effective_end_date  != pc.effective_end_date)
-- MAGIC                          --and base.workspace_id = pc.workspace_id
-- MAGIC                          and base.product_code = pc.product_code
-- MAGIC                          and (
-- MAGIC                             (base.effective_start_date between pc.effective_start_date and pc.effective_end_date) 
-- MAGIC                               or (base.effective_end_date between pc.effective_start_date and pc.effective_end_date)
-- MAGIC                               or (pc.effective_start_date between base.effective_start_date and base.effective_end_date) 
-- MAGIC                               or (pc.effective_end_date between base.effective_start_date and base.effective_end_date)
-- MAGIC                            )
-- MAGIC                inner join main.sfdc_bronze.account sfdc_account
-- MAGIC                    on base.account_id = sfdc_account.id
-- MAGIC                    and sfdc_account.processDate = (select max(processDate) from main.sfdc_bronze.account) and sfdc_account.IsDeleted=false
-- MAGIC                 where (base.is_parallel_contract = true and pc.workspace_id is null and base.workspace_id is null) or base.is_parallel_contract = false
-- MAGIC           """)
-- MAGIC
-- MAGIC display(df)
-- MAGIC
-- MAGIC if df.count() > 0:
-- MAGIC   raise Exception("dupicates issue in final rate table. please verify.")

-- COMMAND ----------



-- COMMAND ----------

create view if not exists cpq_aws_gcp_contracts_orders_parallel_workspaces_vw as
with parallel_accounts as
(
  select distinct account_id 
  from cpq_aws_gcp_contracts_orders_stg_vw
  where is_parallel_contract
),
parallel_contracts as
(
  select o.*
  from cpq_aws_gcp_contracts_orders_stg_vw o
  inner join parallel_accounts pa on pa.account_id = o.account_id
),
latest_zab_subscription as
(
  select distinct *
  from 
    (select *,
      DENSE_RANK() OVER (PARTITION BY workspaceId ORDER BY sub_start_date desc, sub_end_date desc) AS workspace_mapping_rank
      from main.it_finance_silver.zab_worspace_mapping
    )
  where workspace_mapping_rank = 1
),
cpq_aws_gcp_contracts_orders_parallel_vw
(
  select
    a.*,
    z.name as zab_subscription,
    zw.workspaceId as workspace_id
  from parallel_contracts a
  left join main.netsuite2_bronze_hourly.customrecordzab_subscription z
    on a.ns_internal_id = z.id
   and z.processTimestamp = (
         select max(processTimestamp)
         from main.netsuite2_bronze_hourly.customrecordzab_subscription
       )
  left join latest_zab_subscription zw
    on z.name = zw.zab_subscription
),
base as
(
  select * 
  from cpq_aws_gcp_contracts_orders_parallel_vw
  where product_family = 'Workload Commitment'
),

begindates as 
(
  select distinct account_id,consumption_cloud, start_date
  from ((select account_id,consumption_cloud, order_item_start_date as start_date from base)
        union all
        (select account_id,consumption_cloud, date_add(order_item_effective_end_date, 1) as start_date from base)
       )
),
enddates as 
(
  select distinct account_id,consumption_cloud, end_date
  from ((select account_id,consumption_cloud, date_add(order_item_start_date, -1) as end_date from base)
        union all
        (select account_id,consumption_cloud, order_item_effective_end_date as end_date from base)
       )
),
datepair as 
(
  select *
  from (select d1.account_id, d1.consumption_cloud, d1.start_date,
               MIN(d2.end_date) as end_date
        from begindates d1 
        left outer join enddates d2
        on d1.start_date <= d2.end_date 
        and d1.account_id = d2.account_id
        group by d1.account_id, d1.consumption_cloud, d1.start_date
       ) t
  where start_date <= end_date
),
cpq_aws_gcp_contracts_orders_parallel_itm as
(
    select distinct base.*, dp.start_date as effective_start_date, dp.end_date as effective_end_date
    from datepair dp 
    join base on dp.account_id = base.account_id and dp.consumption_cloud = base.consumption_cloud
              and dp.start_date >= base.order_item_start_date 
              and dp.end_date <= base.order_item_effective_end_date                 
),
workspaces as
(
  select account__c as account_id, id, workspaceId__c as workspace_id
  from main.sfdc_bronze.workspace__c
  where account__c is not null
  and processdate = (select max(processdate) from main.sfdc_bronze.workspace__c)
)

select po.account_id,
po.order_id,
po.contract_id,
po.generated_contract_number,
po.contract_cancellation_date,
po.is_contract_cancelled,
po.is_parallel_contract,
po.order_number,
po.order_type,
po.cpq_order_type,
po.order_status,
po.is_migrated_order,
po.order_activation_date,
po.order_item_number,
po.order_start_date,
po.order_end_date,
po.order_item_start_date,
po.order_item_end_date,
po.order_item_effective_end_date,
po.cpq_cloud,
po.consumption_cloud,
po.product_family,
po.product_code,
po.committed_quantity,
po.co_term_orders,
po.parallel_contracts_list,
po.ns_internal_id,
po.renewal_opportunity,
po.source,
po.zab_subscription,
po.effective_start_date,
po.effective_end_date,
coalesce(po.workspace_id,w.workspace_id) as workspace_id

from cpq_aws_gcp_contracts_orders_parallel_itm po
left join workspaces w on po.account_id = w.account_id and po.workspace_id is null
left join cpq_aws_gcp_contracts_orders_parallel_itm po1 on po.account_id = po1.account_id and po1.effective_start_date = po.effective_start_date and po1.effective_end_date = po.effective_end_date and po.consumption_cloud = po1.consumption_cloud and w.workspace_id = po1.workspace_id and po.generated_contract_number != po1.generated_contract_number
where po1.account_id is null

-- COMMAND ----------

create view if not exists azure_contracts_orders_parallel_vw as
with parallel_accounts as
(
  select distinct account_id 
  from cpq_aws_gcp_contracts_orders_stg_vw
  where is_parallel_contract
),
parallel_contracts as
(
  select o.*
  from cpq_aws_gcp_contracts_orders_stg_vw o
  inner join parallel_accounts pa on pa.account_id = o.account_id
  where lower(o.consumption_cloud) = 'azure' and product_family = 'Workload Commitment'
)

select po.account_id,
po.order_id,
po.contract_id,
po.generated_contract_number,
po.contract_cancellation_date,
po.is_contract_cancelled,
po.is_parallel_contract,
po.order_number,
po.order_type,
po.cpq_order_type,
po.order_status,
po.is_migrated_order,
po.order_activation_date,
po.order_item_number,
po.order_start_date,
po.order_end_date,
po.order_item_start_date,
po.order_item_end_date,
po.order_item_effective_end_date,
po.cpq_cloud,
po.consumption_cloud,
po.product_family,
po.product_code,
po.committed_quantity,
po.co_term_orders,
po.parallel_contracts_list,
po.ns_internal_id,
po.renewal_opportunity,
po.source

from parallel_contracts po

-- COMMAND ----------


