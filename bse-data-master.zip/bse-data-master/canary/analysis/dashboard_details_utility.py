# Databricks notebook source
# MAGIC %pip install databricks-sdk==0.18.0

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC Utility to get legacy dashboard details

# COMMAND ----------

import json
import pandas as pd
from databricks.sdk import WorkspaceClient
from pyspark.sql.functions import col, lit
from databricks.sdk.service.dashboards import LakeviewAPI
from databricks.sdk.service.jobs import JobSettings, GitSource, GitProvider, CronSchedule, PauseStatus

def get_workspace_client():
  host = 'https://adb-2548836972759138.18.azuredatabricks.net'
  
  return WorkspaceClient(
    host  = host,
    token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
  )
def get_legacy_dashboard_name(dashboard_id):
  try:
    w = get_workspace_client()
    dashboard_name = w.dashboards.get(dashboard_id= dashboard_id).name
    # print(f"Dashboard Name: {dashboard_name}, Dashboard Id: {dashboard_id}")
    return dashboard_name
  except Exception as e:
    # print(f"Failed to retrieve dashboard details. Error: {e}")
    return None

# COMMAND ----------

# MAGIC %md
# MAGIC Utility to get Lakeview dashboard details

# COMMAND ----------

import requests


HOST = 'https://adb-2548836972759138.18.azuredatabricks.net'
TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
def get_lakeview_dashboard_name(dashboard_id, host = HOST, token= TOKEN):
  # Construct the API endpoint
  url = f"{host}/api/2.0/lakeview/dashboards/{dashboard_id}"

  # Set up headers for authentication
  headers = {
      "Authorization": f"Bearer {token}"
  }

  # Make the GET request to retrieve dashboard details
  response = requests.get(url, headers=headers)

  if response.status_code == 200:
      dashboard_details = response.json()
    #   print(f"Dashboard Name: {dashboard_details.get('display_name')}, Dashboard Id: {dashboard_id}")
      return str(dashboard_details.get('display_name'))
  else:
      # print(f"Failed to retrieve dashboard details. Status code: {response.status_code}, Error: {response.text}")
      return None
