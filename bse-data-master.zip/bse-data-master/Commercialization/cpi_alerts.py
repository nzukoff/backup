# Databricks notebook source
!pip install bs4

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import *
import sys
sys.path.insert(0, "./")
from it_data_lib import email, configure_logging
from urllib.request import urlopen
import logging
import base64
from datetime import datetime, timedelta
import json
import ast

# COMMAND ----------

logger = configure_logging(s_level='ERROR')

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, integration, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

dbutils.widgets.text("mode", 'append') # append, overwrite
mode = dbutils.widgets.get("mode")
print(mode)

# COMMAND ----------

dbutils.widgets.text("process_date", '') # if empty string then current date else the process date
process_date = dbutils.widgets.get("process_date")
print(process_date)

# COMMAND ----------

dbutils.widgets.text("source_environment", 'production') # stage, production
source_environment = dbutils.widgets.get("source_environment")
print(source_environment)

# COMMAND ----------

if environment == 'production':
  red_to_address = ['vicky.wang@databricks.com']
  yellow_to_address = ['jose.lainer@databricks.com']
  schema = "main.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage'
  final_table_name = 'contract_price_interface'
  table_suffix = '_prod'
elif environment == 'integration':
  red_to_address = ['jose.lainer@databricks.com'] 
  yellow_to_address = ['jose.lainer@databricks.com']
  schema = "integration.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage'
  final_table_name = 'contract_price_interface'
  table_suffix = '_int'
elif environment == 'preprod':
  to_address = ['jose.lainer@databricks.com']
  yellow_to_address = ['jose.lainer@databricks.com']
  schema = "integration.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage_preprod'
  final_table_name = 'contract_price_interface_preprod'
  table_suffix = '_preprod'
else:
  red_to_address = ['jose.lainer@databricks.com'] 
  yellow_to_address = ['jose.lainer@databricks.com']
  schema ="integration.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage_dev'
  final_table_name = 'contract_price_interface_dev'
  table_suffix = '_dev'

validation_check_table =f"{schema}.contract_price_validation_check{table_suffix}"
latency_table = f"{schema}.contract_price_interface_latency{table_suffix}"

if source_environment == 'production':
  sfdc_input_schema = "main.sfdc_bronze"
  input_schema = "main.it_billing_and_rating"
  environment_type = "'PRODUCTION'"
  promo_tag = "'promo-pricing'"
elif source_environment == 'sox_dev':
  sfdc_input_schema = "share_clf_main.sfdc_bronze"
  input_schema = "share_clf_main.it_billing_and_rating"
  environment_type = "'PRODUCTION'"
  promo_tag = "'promo-pricing'"
else:
  input_schema = "integration.it_billing_and_rating"
  sfdc_input_schema = "main.it_sfdc_uat2_bronze"
  environment_type = "'STAGING'"
  promo_tag = "'promo-pricing-service-account-stg', 'promo-pricing-user'"

# COMMAND ----------

def send_email_alert(to_address, alert, dry_run=False):
  subject = f'''Contract Price Interface Alert'''
  email_body = f"""
  <html>
    <head>
      <title>Contract Price Interface Alert</title>
    </head>
    <body>
      <p>Hi Team,</p>
      <p>Alert from Contract Price Interface {environment} run: {alert}</a>.</p>
    </body>
    </html>    
  """
  message_id = email.send_it_data_email(
    to_emails=to_address,
    subject=subject,
    body_html=email_body,
    dbutils=dbutils,
    logger=logger,
    dry_run=dry_run
  )
  return message_id


def send_alert(alert, to_address):
  #raise Exception("Data mismatch with metronome")
  alert_id = send_email_alert(to_address, alert, dry_run=False)
  print("Alert sent through email alert id:" + alert_id)


def create_metric_alert(alert_sql, alert_msg, alert_name, alert_type):
  df = spark.sql(alert_sql)
  cnt = df.count()
  if cnt > 0:
    alert_dict[alert_name] = cnt
    if alert_type == 'red':
      send_alert(alert_msg, red_to_address)
    elif alert_type == 'yellow':
      send_alert(alert_msg, yellow_to_address)
    else:
      pass
    display(df)
  else:
    alert_dict[alert_name] = 0

# COMMAND ----------

alert_dict = {}

# COMMAND ----------

process_timestamp = spark.sql(f"""select max(process_timestamp) from {schema}.contract_price_interface_alerts_stage""").collect()[0][0]
process_timestamp


# COMMAND ----------

alert_dict['process_timestamp'] = process_timestamp

# COMMAND ----------

spark.sql(f"""
create or replace temp view contract_price_interface_exploded as
with base as (
select * , dense_rank() over (partition by customer_id, contract_id, platform_product_code, business_subscription_id, sku_cloud order by lastUpdateTimestamp desc) as row_num from {schema}.{final_table_name}
),
filter_latest_timestamp as (
select * from base where row_num = 1
),
explode_price as (
select * except(row_num), explode(sku_prices) as sku_prices_exploded from filter_latest_timestamp
),
expand_price as (
select * except(sku_prices_exploded, sku_prices), sku_prices_exploded.* from explode_price
)
select * from expand_price
""")

# COMMAND ----------

print(f"{schema}.{final_table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view contract_price_dup_check as 
# MAGIC with base as (
# MAGIC select contract_id, business_subscription_id, platform_product_code, sku_cloud, sku_gfm_region, effective_discounted_rate, effective_start_date, effective_end_date from contract_price_interface_exploded
# MAGIC ),
# MAGIC join_base as (
# MAGIC select b1.*, b2.contract_id as b2_contract_id, b2.effective_discounted_rate b2_effective_discounted_rate, b2.effective_start_date b2_effective_start_date, b2.effective_end_date b2_effective_end_date from base b1
# MAGIC left join base b2 on b1.business_subscription_id = b2.business_subscription_id and b1.platform_product_code = b2.platform_product_code and b1.sku_cloud = b2.sku_cloud and b1.sku_gfm_region <=> b2.sku_gfm_region and b1.effective_start_date <= b2.effective_end_date and b1.effective_end_date >= b2.effective_start_date
# MAGIC --and b1.contract_id <> b2.contract_id
# MAGIC ),
# MAGIC dups_filter as (
# MAGIC select contract_id, business_subscription_id, platform_product_code, sku_cloud, sku_gfm_region, effective_discounted_rate, effective_start_date, effective_end_date, count(*) cnt from join_base
# MAGIC group by all
# MAGIC having cnt > 1
# MAGIC ),
# MAGIC final_dup_rows as (
# MAGIC select j.* from dups_filter d
# MAGIC left join join_base j on d.contract_id = j.contract_id and  j.business_subscription_id = d.business_subscription_id and  j.platform_product_code = d.platform_product_code and j.sku_cloud = d.sku_cloud and j.sku_gfm_region <=> d.sku_gfm_region and j.effective_discounted_rate = d.effective_discounted_rate and j.effective_start_date = d.effective_start_date and j.effective_end_date = d.effective_end_date 
# MAGIC )
# MAGIC select * from final_dup_rows 
# MAGIC  where   contract_id <> b2_contract_id

# COMMAND ----------

df = spark.sql("""select * from contract_price_dup_check""")
dup_bsid_count = df.select('business_subscription_id').distinct().count()
print(dup_bsid_count)

# COMMAND ----------

alert_sql = f"""
select * from contract_price_dup_check
"""
alert_msg = f"WARNING: Duplicate contract price for business subscription ID and SKU combination found. Total BSID with duplicates: {dup_bsid_count}"
alert_name = "ContractPriceDupCheck"
#create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow') Need to activate this once fixed

# COMMAND ----------

bsid_sku_count = spark.sql(f"""
with base as (
  select distinct platform_product_code, business_subscription_id, sku_cloud from contract_price_interface_exploded
)
select count(*) from base
""").collect()[0][0]
bsid_sku_count

# COMMAND ----------

alert_dict['CpiBsidSkuCount'] = bsid_sku_count

# COMMAND ----------

spark.sql(f"""create or replace table {validation_check_table} as
with platform_sub as (
  select * from {sfdc_input_schema}.platformsubscription__c where processDate = (select max(processDate) from {sfdc_input_schema}.platformsubscription__c)
),
rated_events as (
select distinct m.business_subscription_id, 
        upper(cloud) as cloud, 
        sku, 
        cast(unit_rate as decimal(38, 18)) / 100.0 as metronome_price, 
        to_date(`timestamp`) as usage_date
        from {input_schema}.draft_rated_events_silver m
    join platform_sub s on (m.business_subscription_id = s.Name)
    where s.Subscription_Channel__c = "DIRECT"
    and s.Type__c = "COMMIT"
    and environment_type = {environment_type}
    and `timestamp` < (select max(`timestamp`) -  interval 2 hours from {input_schema}.draft_rated_events_silver)
    and date(`timestamp`) > '2024-02-01'
),
rates as (
  select distinct c.business_subscription_id, 
                  c.contract_id, 
                  c.customer_id, 
                  c.effective_discounted_rate, 
                  c.effective_start_date, 
                  c.effective_end_date, 
                  c.platform_product_code, 
                  c.sku_cloud, 
                  c.contract_start_date, 
                  c.contract_end_date, 
                  s.cpq_product_code, 
                  s.product_list_item_id
  from contract_price_interface_exploded c left join {schema}.cpi_sku_final s on c.platform_product_code = s.product_code
),
missing_rates as (
  select e.*, r.* except(business_subscription_id) 
  from rated_events e left join rates r 
  on e.business_subscription_id = r.business_subscription_id and e.sku = r.cpq_product_code and e.cloud = r.sku_cloud and e.usage_date >= r.effective_start_date and e.usage_date <= r.effective_end_date
  where effective_discounted_rate is null
),
rates_mismatch as (
  select 'CONTRACTS_RATES_MISMATCH' as validation_error_code, 
        null as list_rate, 
        e.*, 
        r.* except(business_subscription_id)  
  from rated_events e left join rates r 
  on e.business_subscription_id = r.business_subscription_id and e.sku = r.cpq_product_code and e.cloud = r.sku_cloud and e.usage_date >= r.effective_start_date and e.usage_date <= r.effective_end_date
  where metronome_price is null or round(abs(effective_discounted_rate - metronome_price), 6) > 0 
  ),
list_prices as (
  select l.*, 
         s.cpq_product_code 
  from {schema}.metronome_list_rates l left join {schema}.cpi_sku_final s on s.product_list_item_id = l.product_id 
),
list_price_mismtach as (
  select 'CONTRACTS_RATES_MISSING' as validation_error_code, 
         l.unit_price as list_rate, 
         m.* 
  from missing_rates m left join list_prices l 
  on m.sku = l.cpq_product_code and m.usage_date >= l.list_start_date and m.usage_date <= l.list_end_date
  where unit_price <> metronome_price and metronome_price <> cast(0 as decimal(38, 18)) / 100.0
)
select * from rates_mismatch
union
select * from list_price_mismtach
""")

# COMMAND ----------

alert_sql = f"""
select * from {validation_check_table}
"""
alert_msg = f"WARNING: Data mismatch between contract price stage and draft rated events for timestamp {process_timestamp}"
alert_name = "ContractPriceValidationFinalCheck"
if spark.table(f"{validation_check_table}").count() > 200:
    create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow')
else:
    create_metric_alert(alert_sql, alert_msg, alert_name, 'None')

# COMMAND ----------

total_events_count = spark.sql(f"""select count(*) from {input_schema}.draft_rated_events_silver where to_date(`timestamp`) >= date_sub(current_date(), 1)""").collect()[0][0]
print(total_events_count)
alert_dict['TotalEventsCount'] = total_events_count

# COMMAND ----------

df = spark.sql(f"""
with platform_sub as (
  select * from {sfdc_input_schema}.platformsubscription__c where processDate = (select max(processDate) from {sfdc_input_schema}.platformsubscription__c)
),
rated_events as (
select distinct m.business_subscription_id, 
        upper(cloud) as cloud, 
        sku, 
        cast(unit_rate as decimal(38, 18)) / 100.0 as metronome_price, 
        to_date(`timestamp`) as usage_date
        from {input_schema}.draft_rated_events_silver m
    join platform_sub s on (m.business_subscription_id = s.Name)
    where s.Subscription_Channel__c = "DIRECT"
    and s.Type__c = "COMMIT"
    and environment_type = {environment_type}
    --and `timestamp` < (select max(`timestamp`) -  interval 2 hours from {input_schema}.draft_rated_events_silver)
    and `timestamp` > current_timestamp() - interval 24 hours
)
select count(*) from rated_events
""")
total_commit_events_count = df.collect()[0][0]
print(total_commit_events_count)
alert_dict['TotalCommitEventsCount'] = total_events_count

# COMMAND ----------

if alert_dict['TotalEventsCount'] > 0:
  events_mismatch_percent = (alert_dict['ContractPriceValidationFinalCheck']/alert_dict['TotalEventsCount']) * 100
else:
  events_mismatch_percent = 0
print(events_mismatch_percent)
if events_mismatch_percent > 0.01:
  alert_msg = f"WARNING: Data mismatch between contract price Interface and draft rated events for timestamp {process_timestamp}. Total mismatch: {alert_dict['ContractPriceValidationFinalCheck']}"
  send_alert(alert_msg, red_to_address)


# COMMAND ----------

df = spark.sql(f"""with min_update_overrides as (
select contract_id, min(updated_at) as min_updated_at from {schema}.cpi_contract_overrides
group by all 
),
min_update_list as (
  select contract_id, min(contract_updated_at) as min_updated_at from {schema}.contracts_customer_map
group by all 
),
latest_cpi as (
select * from {schema}.{final_table_name} where lastUpdateTimestamp = cast('{process_timestamp}' as timestamp)
),
overrides_cpi_join as (
select l.*, m.min_updated_at, timestampdiff(MINUTE, min_updated_at, l.lastUpdateTimestamp) time_diff from latest_cpi l
left join min_update_overrides m on l.contract_id = m.contract_id
where m.contract_id is not null and lastUpdateReason = 'SKU Price Overrides'
),
list_cpi_join as (
select l.*, m.min_updated_at, timestampdiff(MINUTE, min_updated_at, l.lastUpdateTimestamp) time_diff from latest_cpi l
left join min_update_list m on l.contract_id = m.contract_id
where m.contract_id is not null and lastUpdateReason = 'List Price'
),
final_time_diff as (
select contract_id, business_subscription_id, platform_product_code, sku_gfm_region, sku_cloud, lastUpdateReason, lastUpdateTimestamp, min_updated_at, time_diff  from list_cpi_join
union
select contract_id, business_subscription_id, platform_product_code, sku_gfm_region, sku_cloud, lastUpdateReason, lastUpdateTimestamp, min_updated_at, time_diff  from overrides_cpi_join
)
select * from final_time_diff""")

# COMMAND ----------

df.write \
      .format("delta") \
      .mode("append") \
      .option("mergeSchema", "true")\
      .partitionBy("lastUpdateTimestamp") \
      .saveAsTable(latency_table)
      

# COMMAND ----------

total_rates_cpi = spark.sql(f"select distinct contract_id, business_subscription_id, sku_cloud, platform_product_code, sku_gfm_region from {schema}.{final_table_name}").count()
total_rates_today = spark.sql(f"select distinct contract_id, business_subscription_id, sku_cloud, product_code, sku_gfm_region from {schema}.{stage_table_name} where lastUpdateTimestamp = (select max(lastUpdateTimestamp) from {schema}.{stage_table_name})").count()
percent_rates_cpi = str((total_rates_cpi/total_rates_today)*100)
print("Total Rates in Metronome as of today: " + str(total_rates_today))
print("Total Rates in CPI: " + str(total_rates_cpi))
print("Percentage SKUs in Contract Price Interface:" + percent_rates_cpi)
alert_dict['process_timestamp'] = process_timestamp #.strftime("%Y-%m-%dT%H:%M:%SZ") 
alert_dict['total_rates_cpi'] = total_rates_cpi
alert_dict['total_rates_today'] = total_rates_today
alert_dict['percent_rates_cpi'] = percent_rates_cpi

# COMMAND ----------

alert_list = [alert_dict,]
alert_list

# COMMAND ----------

alert_df_mod = spark.createDataFrame(alert_list)
alert_df_mod.createOrReplaceTempView('alert_vw')

# COMMAND ----------

alert_stage_df = spark.table(f"{schema}.contract_price_interface_alerts_stage")

# COMMAND ----------

alert_df = spark.sql(f"""
with alerts as (
select * from {schema}.contract_price_interface_alerts_stage
)
select a.*, v.* except(process_timestamp) from alerts a join alert_vw v on a.process_timestamp = v.process_timestamp
""")

# COMMAND ----------

display(alert_df)

# COMMAND ----------



# COMMAND ----------

alert_df.write \
      .format("delta") \
      .mode("overwrite") \
      .option("mergeSchema", "true")\
      .option("replaceWhere", "process_timestamp = '{0}'".format(process_timestamp)) \
      .saveAsTable(f"{schema}.contract_price_interface_alerts")

# COMMAND ----------


