# Databricks notebook source
from datetime import datetime, timedelta
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, integration, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

dbutils.widgets.text("mode", 'append') # append, overwrite
mode = dbutils.widgets.get("mode")
print(mode)

# COMMAND ----------

dbutils.widgets.text("process_date", '') # if empty string then current date else the process date
process_date = dbutils.widgets.get("process_date")
print(process_date)

# COMMAND ----------

dbutils.widgets.text("overlap_fix", 'false') # if empty string then current date else the process date
overlap_fix = dbutils.widgets.get("overlap_fix")
print(process_date)

# COMMAND ----------

if environment == 'production':
  to_address = ['jose.lainer@databricks.com', 'vicky.wang@databricks.com']
  schema = "main.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage'
  final_table_name = 'contract_price_interface'
elif environment == 'integration':
  to_address = ['jose.lainer@databricks.com'] #'vicky.wang@databricks.com']
  schema = "integration.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage'
  final_table_name = 'contract_price_interface'
elif environment == 'preprod':
  to_address = ['jose.lainer@databricks.com']
  schema = "integration.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage_preprod'
  final_table_name = 'contract_price_interface_preprod'
else:
  to_address = ['jose.lainer@databricks.com']
  schema = "integration.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage_dev'
  final_table_name = 'contract_price_interface_dev'

output_schema = schema
# if source_environment == 'production':
#   sfdc_input_schema = "main.sfdc_bronze"
#   input_schema = "main.it_billing_and_rating"
#   environment_type = "'PRODUCTION'"
#   promo_tag = "'promo-pricing'"
# else:
#   input_schema = "integration.it_billing_and_rating"
#   sfdc_input_schema = "main.it_sfdc_uat2_bronze"
#   environment_type = "'STAGING'"
#   promo_tag = "'promo-pricing-service-account-stg', 'promo-pricing-user'"

# COMMAND ----------

# cpi_stage_process_timestamp = spark.sql(f"""select max(lastUpdateTimestamp) from {schema}.{stage_table_name}""").collect()[0][0].strftime("%Y-%m-%dT%H:%M:%SZ")
# cpi_stage_process_timestamp

# COMMAND ----------

# if process_date == '':
#   if mode == 'overwrite':
#     process_timestamp = spark.sql(f"""select min(lastUpdateTimestamp) from {schema}.{stage_table_name}""").collect()[0][0].strftime("%Y-%m-%dT%H:%M:%SZ")
#   else:
#     process_timestamp = spark.sql(f"""select max(lastUpdateTimestamp) from {schema}.{final_table_name}""").collect()[0][0].strftime("%Y-%m-%dT%H:%M:%SZ")
# else:
#   process_timestamp = process_date.strip() + "T23:59:59Z"
#   #process_date = str(datetime.today().date())
# print(process_timestamp)
# #print(process_date)

# COMMAND ----------

#process_timestamp = '2024-09-26T10:49:04Z' #'2024-09-25T20:49:08.000+00:00'

# COMMAND ----------

# previous_process_date = str((datetime.strptime(process_date, '%Y-%m-%d') - timedelta(days=1)).date())
# print(previous_process_date)

# COMMAND ----------

output_schema

# COMMAND ----------

schema

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write the final table

# COMMAND ----------

#current_timestamp_df = spark.sql(f"select max(lastUpdateTimestamp) from {schema}.{stage_table_name}")

# COMMAND ----------

#current_timestamp_df.collect()[0][0]

# COMMAND ----------

process_timestamp = spark.sql(f"""select max(lastUpdateTimestamp) from {schema}.{stage_table_name}""").collect()[0][0].strftime("%Y-%m-%dT%H:%M:%SZ")

# COMMAND ----------

process_timestamp

# COMMAND ----------

def write_to_cpi(view_name):
  df = spark.sql(f"""
      with base as (
      select  customer_id,
              customer_name,
              contract_id,
              cast(contract_start_date as date) contract_start_date,
              cast(contract_end_date as date) contract_end_date,
              business_subscription_id,
              name as product_name,
              product_code as platform_product_code,
              sku_gfm_region,
              sku_cloud,
              reseller_contracts,
              collect_set(struct(effective_price as effective_discounted_rate, type, cast(effective_start_date as date) as effective_start_date, cast(effective_end_date as date) as effective_end_date)) as sku_prices_unsorted,
              promo_tag_max as promo_tag,
              lastUpdateReason_max as lastUpdateReason,
              lastUpdateTimestamp
      from {view_name}
      group by all
      ),
      sort_sku_prices as (
      select * except(sku_prices_unsorted),
              array_sort(sku_prices_unsorted, (l, r) -> case when l.effective_start_date < r.effective_start_date then -1
                                                              when l.effective_start_date > r.effective_start_date then 1                                                       
                                                              else 0
                                                      end)
                                                      as sku_prices_sorted
      from base
      )
      select * except(sku_prices_sorted),
              transform(sku_prices_sorted, x -> struct(x.effective_discounted_rate, x.type, cast(x.effective_start_date as date) as effective_start_date, cast(x.effective_end_date as date) as effective_end_date)) as sku_prices
      from sort_sku_prices
  """)
  print(f"Writing data to the table {output_schema}.{final_table_name}. Total records: {df.count()}")
  df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true")\
    .option("replaceWhere", "lastUpdateTimestamp = cast('{0}' as timestamp)".format(process_timestamp)) \
    .saveAsTable(f"{output_schema}.{final_table_name}")

# COMMAND ----------

print(f"Processing data for {process_timestamp}")
if mode == 'overwrite':
  print(f"Overwriting data for on table {output_schema}.{final_table_name}")
  print("Creating or replacing the table schema {output_schema}.{final_table_name}")
  spark.sql(f"""
    create or replace table {output_schema}.{final_table_name} 
    (
      customer_id string NOT NULL COMMENT 'Metronome Customer ID',
      customer_name string NOT NULL COMMENT 'Metronome Customer Name',
      contract_id string NOT NULL COMMENT 'Metronome Contract ID',
      contract_start_date date NOT NULL COMMENT 'Metronome Contract Start Date',
      contract_end_date date NOT NULL COMMENT 'Metronome Contract End Date',
      business_subscription_id string NOT NULL COMMENT 'Business Subscription ID',
      product_name string NOT NULL COMMENT 'Metronome Product/SKU Name',
      platform_product_code string NOT NULL COMMENT 'Platform Product/SKU Code',
      sku_gfm_region string COMMENT 'SKU Region from Salesforce SKU Manager',
      sku_cloud string NOT NULL COMMENT 'SKU Cloud',
      reseller_contracts boolean NOT NULL COMMENT 'Metronome Reseller Contracts',        
      promo_tag string COMMENT 'Metronome Promotional Pricing Tag',
      lastUpdateReason string NOT NULL COMMENT 'Reason for the last update',
      lastUpdateTimestamp timestamp NOT NULL COMMENT 'Last Updated Timestamp',
      sku_prices array < struct < effective_discounted_rate:decimal(38,17),
                                  type:string,
                                  effective_start_date:date,
                                  effective_end_date:date
                        >> NOT NULL COMMENT 'SKU Prices'
    )
    using DELTA
    partitioned by (lastUpdateTimestamp)
    """)
  spark.sql(f"""create or replace temp view cpi_stage as
            select *
            from {schema}.{stage_table_name} 
            where lastUpdateTimestamp = (select max(lastUpdateTimestamp) from {schema}.{stage_table_name})
            """)
  write_to_cpi("cpi_stage")
else:
  print(f"Appending data on table {output_schema}.{final_table_name}")
  spark.sql(f"""
    create or replace temp view contract_price_interface_exploded as
      with base as (
      select * , dense_rank() over (partition by customer_id, contract_id, platform_product_code, business_subscription_id, sku_cloud order by lastUpdateTimestamp desc) as row_num from {output_schema}.{final_table_name}
    ),
    filter_latest_timestamp as (
      select * from base where row_num = 1
    ),
    explode_price as (
      select * except(row_num), explode(sku_prices) as sku_prices_exploded from filter_latest_timestamp
    ),
    expand_price as (
      select * except(sku_prices_exploded, sku_prices), sku_prices_exploded.* from explode_price
    )
    select * from expand_price
  """)
  spark.sql(f"""
    create or replace temp view contract_price_interface_append as
    with base as (
      select customer_id, contract_id, contract_start_date, contract_end_date, product_code as platform_product_code, sku_cloud, business_subscription_id, name as product_name, sku_gfm_region, effective_price, cast(effective_start_date as date) as effective_start_date, cast(effective_end_date as date) effective_end_date, promo_tag_max as promo_tag  from {schema}.{stage_table_name} where lastUpdateTimestamp = (select max(lastUpdateTimestamp) from {schema}.{stage_table_name}) and sku_cloud <> 'PVC'
      except
      select customer_id, contract_id, contract_start_date, contract_end_date, platform_product_code, sku_cloud, business_subscription_id, product_name, sku_gfm_region, effective_discounted_rate as effective_price, cast(effective_start_date as date) as effective_start_date, cast(effective_end_date as date) effective_end_date, promo_tag  from contract_price_interface_exploded where sku_cloud <> 'PVC'
  ),
  append_rows as (
  select c.*  from base b
    left join {schema}.{stage_table_name} c on b.customer_id = c.customer_id and b.contract_id = c.contract_id and b.platform_product_code = c.product_code and b.product_name = c.name and b.sku_cloud = c.sku_cloud and b.business_subscription_id = c.business_subscription_id and b.sku_gfm_region <=> c.sku_gfm_region
    where c.lastUpdateTimestamp = (select max(lastUpdateTimestamp) from {schema}.{stage_table_name})
  )
  select * from append_rows
  """)
  write_to_cpi("contract_price_interface_append")

# COMMAND ----------

if overlap_fix == 'true':
    spark.sql(f"""
        create or replace temp view cpi_overlap as
        with base as (
        select *,
            row_number() over(partition by business_subscription_id, contract_id, platform_product_code, sku_cloud, sku_gfm_region order by lastUpdateTimestamp desc) as rn
        from {output_schema}.{final_table_name}
        qualify rn =1
        ),
        explode_prices as (
        select *,
            explode(sku_prices) as price
        from base
        ),
        flatten_price as (
        select *,
            price.*
        from explode_prices
        ),
        get_next_date as (
        select 
            *,
            lead(effective_start_date) over(partition by business_subscription_id, contract_id, platform_product_code, sku_cloud, sku_gfm_region, lastUpdateTimestamp order by effective_start_date) as next_start_date,
            lead(effective_end_date) over(partition by business_subscription_id, contract_id, platform_product_code, sku_cloud, sku_gfm_region, lastUpdateTimestamp order by effective_end_date) as next_end_date
        from flatten_price
        ),
        overlap_check as (
        select 
            *,
            case when effective_end_date >= next_start_date and effective_start_date <= next_end_date then true else false end as is_overlapping
        from get_next_date
        where next_start_date is not null
        )
        select * from overlap_check where is_overlapping is true
    """)
    spark.sql(f"""
        create or replace temp view cpi_overlap_fix as 
        with base as (
        select distinct contract_id, business_subscription_id, product_name, sku_cloud, sku_gfm_region from cpi_overlap
        )
        select c.*  from base b
        left join {schema}.{stage_table_name} c on b.contract_id = c.contract_id and b.product_name = c.name and b.sku_cloud = c.sku_cloud and b.business_subscription_id = c.business_subscription_id and b.sku_gfm_region <=> c.sku_gfm_region
        where c.lastUpdateTimestamp = (select max(lastUpdateTimestamp) from {schema}.{stage_table_name})
    """)
    write_to_cpi("cpi_overlap_fix")

# COMMAND ----------

spark.sql(f"""
create or replace temp view reseller_contracts_dup as 
with dup_find as (
select contract_id, count(distinct reseller_contracts) cnt from {output_schema}.{final_table_name}
group by all
having cnt > 1
)
select d.contract_id, c.reseller_contracts from dup_find d left join {schema}.contracts_customer_map c on d.contract_id = c.contract_id
""")

# COMMAND ----------

spark.sql(f"""
MERGE into {output_schema}.{final_table_name} cpi
USING reseller_contracts_dup ccm ON cpi.contract_id = ccm.contract_id 
WHEN MATCHED THEN UPDATE set cpi.reseller_contracts = ccm.reseller_contracts;
""")

# COMMAND ----------

df = spark.sql(f"""
select distinct lastUpdateTimestamp from {schema}.{final_table_name}
""")
display(df)

# COMMAND ----------

df = spark.sql(f"""
select * from {schema}.{final_table_name}
""")
display(df)

# COMMAND ----------


