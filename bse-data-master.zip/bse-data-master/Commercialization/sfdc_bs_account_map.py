# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE main.it_cpq_silver.sfdc_bs_account_map AS 
# MAGIC with distinct_platform as (
# MAGIC   select
# MAGIC     *
# MAGIC   from
# MAGIC     (
# MAGIC       select
# MAGIC         Id,
# MAGIC         Name,
# MAGIC         Start_Date__c,
# MAGIC         End_Date__c,
# MAGIC         Account_Id__c,
# MAGIC         Platform__c,
# MAGIC         OrderNumber__c,
# MAGIC         Order__c as Platform_Order__c,
# MAGIC         processDate,
# MAGIC         DENSE_RANK() OVER (
# MAGIC           PARTITION BY Name
# MAGIC           ORDER BY
# MAGIC             processDate desc
# MAGIC         ) AS process_date_rank
# MAGIC       from
# MAGIC         main.sfdc_bronze.platformsubscription__c
# MAGIC       where processDate >= '2024-02-01'
# MAGIC     )
# MAGIC   where
# MAGIC     process_date_rank = 1
# MAGIC ),
# MAGIC distinct_order as (
# MAGIC   select
# MAGIC     *
# MAGIC   from
# MAGIC     (
# MAGIC       select
# MAGIC         Account__c,
# MAGIC         Business_Subscription__c,
# MAGIC         Contract__c,
# MAGIC         Effective_Date__c,
# MAGIC         End_Date__c as Effective_End_Date__c,
# MAGIC         Order__c,
# MAGIC         Status__c,
# MAGIC         Type__c,
# MAGIC         processDate,
# MAGIC         DENSE_RANK() OVER (
# MAGIC           PARTITION BY Business_Subscription__c
# MAGIC           ORDER BY
# MAGIC             processDate desc
# MAGIC         ) AS process_date_rank
# MAGIC       from
# MAGIC         main.sfdc_bronze.Order_Subscription__c
# MAGIC       where processDate >= '2024-02-01'
# MAGIC     )
# MAGIC   where
# MAGIC     process_date_rank = 1
# MAGIC ),
# MAGIC bs_orders as (
# MAGIC   select
# MAGIC     p.*,
# MAGIC     o.*
# MAGIC   from
# MAGIC     distinct_platform p
# MAGIC     left join distinct_order o on p.Id = o.Business_Subscription__c
# MAGIC )
# MAGIC select
# MAGIC   distinct
# MAGIC   Name as business_subscription_id,
# MAGIC   Start_Date__c as start_date,
# MAGIC   End_Date__c as end_date,
# MAGIC   case
# MAGIC     when Account_Id__c is null then Account__c
# MAGIC     else Account_Id__c
# MAGIC   end as account_id,
# MAGIC   Platform__c as platform,
# MAGIC   OrderNumber__c as order_number,
# MAGIC   Platform_Order__c as order_id,
# MAGIC   Contract__c as contract_id,
# MAGIC   Type__c
# MAGIC from
# MAGIC   bs_orders

# COMMAND ----------


