# Databricks notebook source
dbutils.widgets.text("environment", 'production') # development, integration, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

dbutils.widgets.text("source_environment", 'production') # integration, production
source_environment = dbutils.widgets.get("source_environment")
print(source_environment)

# COMMAND ----------

if environment == 'production':
  schema = "main.it_sfdc_silver"
  source_environment == 'production'
elif environment == 'integration':
  schema = "integration.it_sfdc_silver"
else:
  schema = "users.prabhakar_guha"

if source_environment == 'production':
  sfdc_input_schema = "main.sfdc_bronze"
  finance_schema = "main.fin_live_gold"
  finance_table = "main.it_sfdc_silver.list_prices_old"
else:
  sfdc_input_schema = "main.it_sfdc_uat2_bronze"
  finance_schema = "main.fin_live_gold"
  finance_table = "main.it_sfdc_silver.list_prices_old"

# COMMAND ----------

print(schema)
print(source_environment)

# COMMAND ----------

price_change_df = spark.sql(f"""select Id, CreatedDate, IsDeleted, Name, CurrencyIsoCode, LastActivityDate,LastModifiedDate, OwnerId, Price_Book__c, Product__c, New_Value__c, Old_Value__c, Start_DateTime__c, End_DateTime__c from main.sfdc_bronze.price_change__c where processDate = (select max(processDate) from main.sfdc_bronze.price_change__c)""")
price_change_df.createOrReplaceTempView("price_change")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view price_change_master as 
# MAGIC with base as (
# MAGIC select * from price_change
# MAGIC ),
# MAGIC identify_dup_start_date as (
# MAGIC select End_DateTime__c, New_Value__c, Old_Value__c, Price_Book__c, Product__c, Start_DateTime__c, row_number() over (partition by Price_Book__c,Product__c, Start_DateTime__c order by CreatedDate desc) as latest_start_date from base
# MAGIC ),
# MAGIC filter_dup_start_date as (
# MAGIC   select * except(latest_start_date) from identify_dup_start_date where latest_start_date = 1
# MAGIC )
# MAGIC select Price_Book__c PriceChange_PriceBookId, 
# MAGIC        Product__c PriceChange_ProductId, 
# MAGIC        New_Value__c as list_price, 
# MAGIC        date(Start_DateTime__c) as list_start_date,
# MAGIC        coalesce(date_sub(lead(Start_DateTime__c) over (partition by Price_Book__c,Product__c order by Start_DateTime__c),1),cast('2030-12-31' as date)) as list_end_date,
# MAGIC        y.ProductCode AS PriceChange_ProductCode,
# MAGIC         y.CPQ_Usage_Cloud__c AS PriceChange_CPQUsageCloud,
# MAGIC         y.CPQ_Service_Family__c AS PriceChange_ServiceFamily
# MAGIC from filter_dup_start_date x
# MAGIC  JOIN
# MAGIC         main.sfdc_bronze.product2 y
# MAGIC     ON x.Product__c = y.Id
# MAGIC     WHERE
# MAGIC         y.processDate = (SELECT MAX(processdate) FROM main.sfdc_bronze.product2)
# MAGIC         --AND y.IsActive = TRUE
# MAGIC         AND y.Family IN ('Usage')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from price_change_master

# COMMAND ----------

df = spark.sql(f"""
select * from price_change_master p
left join {schema}.list_prices l
on p.PriceChange_ProductCode = l.sku and p.PriceChange_CPQUsageCloud = upper(l.platform )
and p.list_start_date <=l.end_date and p.list_end_date >= l.start_date
where p.list_price <> l.raw_list_price
""")

# COMMAND ----------

if df.count() > 0:
  display(df)
  raise Exception("List price is not updated in the SFDC. Please check and update the code.")

# COMMAND ----------

spark.sql(f"""
create or replace temp view sku_base as
  select Id,
      replace(replace(upper(SkuName__c), 'GCP_', ''),'AZURE_','') as sku,
      SKU_Name__c sku_name,
      Platform_Product_Code__c,
      upper(coalesce(Money_Specific_Cloud__c, Cloud__c)) sub_platform,
      NS_Internal_ID__c,
      upper(Cloud__c) as platform,
      SKU_Type__c,
      List_Price_US__c,
      CAST(List_Price_Effective_Date__c as date) as List_Price_Effective_Date__c,
      CAST('2030-01-01' as date) as list_price_end_date,
      LastModifiedDate,
      case when Region_Type__c = 'GovCloud' or Region__c = 'US_GOV' then 'GOV'
            when Region_Type__c = 'China' then 'CHINA'
            else 'E2'
      end as region_type,
      Region_Type__c,
      Region__c,
      case when lower(Region__c) = 'us_gov_arizona' then 'usgovarizona'
            when lower(Region__c) = 'us_gov_virginia' then 'usgovvirginia'
            when Region_Type__c = 'GovCloud' then lower(Region__c) 
            else null 
      end as region
  from {sfdc_input_schema}.sku_manager__c 
  where processDate = (select max(processDate) from {sfdc_input_schema}.sku_manager__c) 
      and SKU_Type__c = 'Usage' 
      and SkuName__c not like "%BUNDLE%" 
      and List_Price_Effective_Date__c is not null 
      and List_Price_US__c is not null
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sku_base

# COMMAND ----------

spark.sql(f"""
create or replace temp view promo_select as
  select Active__c, 
      Applied__c, 
      Effective_Date__c, 
      End_Date__c, 
      Name, 
      Promo_Discount__c, 
      Sku_Code__c, 
      Sku__c, 
      Status__c          
  from {sfdc_input_schema}.promotional_pricing__c
  where processDate = (select max(processDate) from {sfdc_input_schema}.promotional_pricing__c)
    and ((Applied__c and Effective_Date__c <= current_date()) or (Effective_Date__c > current_date()))
      --and (Applied__c) --or (Effective_Date__c > current_date()))
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view promo_list_prices as
# MAGIC   select round(List_Price_US__c * (1 - coalesce(Promo_Discount__c, 0) / 100),5) as promo_list_price,
# MAGIC       case when List_Price_Effective_Date__c > Effective_Date__c and List_Price_Effective_Date__c < End_Date__c 
# MAGIC             then List_Price_Effective_Date__c 
# MAGIC             else Effective_Date__c 
# MAGIC       end as promo_start_date,
# MAGIC       p.* 
# MAGIC   from sku_base s
# MAGIC   left join promo_select p on s.Id = p.Sku__c
# MAGIC   where Promo_Discount__c is not null

# COMMAND ----------

spark.sql(f"""
create or replace temp view fin_prices as
  select * except(platform), 
      upper(platform) as platform,
      case when sku like "%COREWEAVE%" then 'COREWEAVE'
            when sku like "%OCI%" then 'OCI'
            when sku like "%CRUSOE%" then 'CRUSOE'
            else upper(platform)
      end as sub_platform
  from {finance_table}
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view promo_percent as
# MAGIC   select p.*, s.sub_platform, s.platform  from promo_select p
# MAGIC   left join sku_base s on s.Id = p.Sku__c

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view fin_prices_promo_join as
# MAGIC with promo_percent_exploded as (
# MAGIC   select
# MAGIC       *,
# MAGIC       explode(sequence(Effective_Date__c, End_Date__c, interval 1 day)) promo_percent_date
# MAGIC   from promo_percent
# MAGIC ),
# MAGIC fin_prices_exploded as (
# MAGIC   select *,
# MAGIC       explode(sequence(start_date, end_date, interval 1 day)) list_date
# MAGIC   from fin_prices
# MAGIC )
# MAGIC select f.*,
# MAGIC     p.Promo_Discount__c,
# MAGIC     case when f.promotion <> 'Yes' and p.Promo_Discount__c is not null then round(f.list_price * (1 - coalesce(p.Promo_Discount__c, 0) / 100),5)
# MAGIC     else list_price
# MAGIC     end as effetive_list_price,
# MAGIC     case when f.promotion <> 'Yes' and p.Promo_Discount__c is not null then 'Yes'
# MAGIC     else promotion
# MAGIC     end as effective_promotion
# MAGIC from fin_prices_exploded f
# MAGIC left join promo_percent_exploded p 
# MAGIC     on f.sku = p.Sku_Code__c and f.platform = p.platform and f.list_date = p.promo_percent_date

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view list_price_exploded as
# MAGIC with 
# MAGIC sku_base_exploded as (
# MAGIC      select
# MAGIC           *,
# MAGIC           explode(sequence(List_Price_Effective_Date__c, list_price_end_date, interval 1 day)) sku_base_date
# MAGIC      from sku_base
# MAGIC      where List_Price_Effective_Date__c <= list_price_end_date
# MAGIC ),
# MAGIC promo_prices_exploded as (
# MAGIC      select
# MAGIC           *,
# MAGIC           explode(sequence(promo_start_date, End_Date__c, interval 1 day)) promo_date
# MAGIC      from
# MAGIC           promo_list_prices
# MAGIC ),
# MAGIC explode_join as (
# MAGIC      select * from sku_base_exploded s
# MAGIC      left join promo_prices_exploded p 
# MAGIC           on s.Id = p.Sku__c and s.sku_base_date = p.promo_date
# MAGIC ),
# MAGIC final_join as (
# MAGIC      select case when e.sku is not null then e.sku
# MAGIC                else f.sku
# MAGIC           end as final_sku,
# MAGIC           case when e.platform is not null then e.platform
# MAGIC                else f.platform
# MAGIC           end as final_platform,
# MAGIC           case when e.sub_platform is not null then e.sub_platform
# MAGIC                else f.sub_platform
# MAGIC           end as final_sub_platform,
# MAGIC           case when promo_list_price is not null then promo_list_price
# MAGIC                when List_Price_US__c is not null then List_Price_US__c
# MAGIC                --when list_price is not null and f.promotion 
# MAGIC                else effetive_list_price
# MAGIC           end as final_list_price,
# MAGIC           case when List_Price_US__c is not null then List_Price_US__c
# MAGIC                when list_price is not null and f.effective_promotion = 'No' then list_price
# MAGIC                else null
# MAGIC           end as final_raw_list_price,
# MAGIC           coalesce(sku_base_date,promo_date, list_date) as final_date,
# MAGIC           e.region as sku_manager_region,
# MAGIC           f.region as fin_region,
# MAGIC           coalesce(e.region, f.region) as final_region,
# MAGIC           coalesce(e.region_type, f.type) as final_region_type,
# MAGIC           case when promo_list_price is not null then 'Yes'
# MAGIC                when List_Price_US__c is not null and  promo_list_price is null then 'No'
# MAGIC                else effective_promotion
# MAGIC           end as final_promotion,
# MAGIC           coalesce(LastModifiedDate, uploaded_time) as final_uploaded_time,
# MAGIC           coalesce(LastModifiedDate, modified_time) as final_modified_time,
# MAGIC           case when promo_list_price is not null then 'promo pricing'
# MAGIC                when List_Price_US__c is not null and  promo_list_price is null then 'sku manager'
# MAGIC                when f.effetive_list_price is not null and f.effective_promotion <> f.promotion then 'finance list price promo add'
# MAGIC                else 'finance list price'
# MAGIC           end as final_source,
# MAGIC           List_Price_US__c    
# MAGIC           --*
# MAGIC      from fin_prices_promo_join f
# MAGIC      full outer join explode_join e on f.sku = e.sku and f.platform = e.platform and f.list_date = e.sku_base_date and f.region <=> e.region
# MAGIC )
# MAGIC select * from final_join 
# MAGIC --where List_Price_US__c is  null and  promo_list_price is null
# MAGIC --where f.sku is not null and e.sku_name is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view list_prices_agg
# MAGIC  as
# MAGIC with list_price_exploded_final as (
# MAGIC   select final_sku as sku,
# MAGIC          lower(final_platform) as platform,
# MAGIC          lower(final_sub_platform) as sub_platform,
# MAGIC          final_list_price as list_price,
# MAGIC          final_raw_list_price as raw_list_price,
# MAGIC          final_date,
# MAGIC          final_region as region,
# MAGIC          final_region_type as type,
# MAGIC          final_promotion as promotion,
# MAGIC          final_uploaded_time as uploaded_time,
# MAGIC          final_modified_time as modified_time,
# MAGIC          final_source as source
# MAGIC   from list_price_exploded
# MAGIC ),
# MAGIC seq_row as (
# MAGIC   select
# MAGIC     *,
# MAGIC     row_number() over (
# MAGIC       partition by sku,
# MAGIC       platform,
# MAGIC       sub_platform,
# MAGIC       list_price,
# MAGIC       raw_list_price,
# MAGIC       region,
# MAGIC       type,
# MAGIC       promotion,
# MAGIC       source
# MAGIC       ORDER BY
# MAGIC         final_date
# MAGIC     ) seq_date_num
# MAGIC   from
# MAGIC     list_price_exploded_final
# MAGIC ),
# MAGIC aggregated_col as (
# MAGIC select
# MAGIC   sku,
# MAGIC   platform,
# MAGIC   sub_platform,
# MAGIC   list_price,
# MAGIC   raw_list_price,
# MAGIC   region,
# MAGIC   type,
# MAGIC   promotion,
# MAGIC   uploaded_time,
# MAGIC   modified_time,
# MAGIC   source,
# MAGIC   min(final_date) start_date,
# MAGIC   max(final_date) end_date
# MAGIC from
# MAGIC   seq_row
# MAGIC group by
# MAGIC   sku,
# MAGIC   platform,
# MAGIC   sub_platform,
# MAGIC   list_price,
# MAGIC   raw_list_price,
# MAGIC   region,
# MAGIC   type,
# MAGIC   promotion,
# MAGIC   uploaded_time,
# MAGIC   modified_time,
# MAGIC   source,
# MAGIC   dateadd(day, - seq_date_num, final_date)
# MAGIC )
# MAGIC select * from aggregated_col

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from list_prices_agg

# COMMAND ----------

df = spark.sql(f"""
with promo_pricing as (
  select *,
         replace(replace(upper(Sku_Code__c), 'GCP_', ''),'AZURE_','') as sku
  from promo_percent
)
select * 
from 
list_prices_agg l
join promo_pricing p on l.sku = p.sku and l.platform = lower(p.platform) and l.start_date <= p.End_Date__c and l.end_date >= p.Effective_Date__c
where promotion not in ('Yes')
""")
if df.count() > 0:
  raise Exception("Promotion not applied correctly in the list prices! Please check the code.")

# COMMAND ----------

spark.sql(f"""
  create or replace table {schema}.list_prices as 
  select * from list_prices_agg
""")
