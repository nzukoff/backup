# Databricks notebook source
#Note: If we change the percentages later, we might trigger email alerts for old fund requests as those burndown level are not in the completed table(acclerate_burndown_snap_table)

# COMMAND ----------

# MAGIC %run ../gtm-growth/SalesforceFunctions

# COMMAND ----------

import sys
sys.path.insert(0, "./")
from it_data_lib import email, configure_logging
from urllib.request import urlopen
import logging
import base64
from datetime import datetime

# COMMAND ----------

logger = configure_logging(s_level='ERROR')

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, integration, production
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

processDate = datetime.now().strftime("%Y-%m-%d")
print("processing :", processDate)

# COMMAND ----------

if environment == 'production':
  schema = "main.it_billing_and_rating"
  metronome_schema = "main.it_billing_and_rating"  
  sfdc_schema = "main.sfdc_bronze"
  sfdc_url = "databricks.lightning.force.com"
  fundrequest_table = "main.sfdc_bronze.fundrequest__c"
  platform_sub_table = "main.sfdc_bronze.platformsubscription__c"
  sfdc_order_table = "main.sfdc_bronze.`order`"
  acclerate_burndown_snap_table = "main.it_consumption_silver.accelerate_burndown_snap"
  accelerate_notifications_table = "main.it_consumption_silver.accelerate_notifications"
  recipent_email = "prabhakar.guha@databricks.com"
elif environment == 'integration':
  schema = "integration.it_billing_and_rating"
  metronome_schema = "integration.it_billing_and_rating"
  sfdc_schema = "integration.it_sfdc_bronze"
  sfdc_url = "databricks--uat2.sandbox.lightning.force.com"
  fundrequest_table = "integration.it_sfdc_bronze.uat2_fundrequest__c"
  platform_sub_table = "integration.it_sfdc_bronze.uat2_platformsubscription__c"
  sfdc_order_table = "main.it_sfdc_uat2_bronze.`order`"
  acclerate_burndown_snap_table = "integration.it_consumption_silver.accelerate_burndown_snap"
  accelerate_notifications_table = "integration.it_consumption_silver.accelerate_notifications"
  recipent_email = "prabhakar.guha@databricks.com"
else:
  schema = "users.prabhakar_guha"
  metronome_schema = "integration.it_billing_and_rating"
  sfdc_schema = "integration.it_sfdc_bronze"
  sfdc_url = "databricks--uat2.sandbox.lightning.force.com"
  fundrequest_table = "integration.it_sfdc_bronze.uat2_fundrequest__c"
  platform_sub_table = "integration.it_sfdc_bronze.uat2_platformsubscription__c"
  sfdc_order_table = "main.it_sfdc_uat2_bronze.`order`"
  acclerate_burndown_snap_table = "users.prabhakar_guha.accelerate_burndown_snap"
  accelerate_notifications_table = "users.prabhakar_guha.accelerate_notifications"
  recipent_email = "prabhakar.guha@databricks.com"

# COMMAND ----------

if environment == "production":
  cred_str = "lfsf"
  sf_str = "databricks.my"
else:
  cred_str = "uat2"
  sf_str = "test"

creds = get_creds(cred_str)
sf = get_sfdc_connection(creds, sf_str)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Email Setup

# COMMAND ----------

def send_email_to_ae(to_address, ae_name, account_name, account_id, sfdc_url, burndown_level, fund_request_id, environment, dry_run=False):
  if environment == 'production':
    subject = f'''POC Usage alert for {account_name}'''
  else:
    subject = f'''[TEST EMAIL: PLEASE IGNORE] POC Usage alert for {account_name}'''
  email_body = f"""
  <html>
    <head>
      <title>{subject}</title>
    </head>
    <body>
      <p>Hello {ae_name},</p>
      <p>This notification is to inform you that your customer, <a href="https://{sfdc_url}/lightning/r/Account/{account_id}/view" target="_blank">{account_name}</a>, has used {burndown_level}% of their POC credits. Fund Request ID: <a href="https://{sfdc_url}/lightning/r/FundRequest__c/{fund_request_id}/view" target="_blank">{fund_request_id}</a>.</p>
    </body>
    </html>    
  """
  message_id = email.send_it_data_email(

    to_emails=to_address,
    subject=subject,
    body_html=email_body,
    dbutils=dbutils,
    logger=logger,
    dry_run=dry_run
  )
  return message_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract burndown data

# COMMAND ----------

soql = "select Id, Name, ApprovalStatus__c, Account__c, Business_Subscription__c  from FundRequest__c"
df = get_dataframe(soql, cred_str, sf_str)

# COMMAND ----------

df['Id'] = df['Id'].astype('str')
df['Name'] = df['Name'].astype('str')
df['ApprovalStatus__c'] = df['ApprovalStatus__c'].astype('str')
df['Account__c'] = df['Account__c'].astype('str')
df['Business_Subscription__c'] = df['Business_Subscription__c'].astype('str')
fund_df = spark.createDataFrame(df)
fund_df.createOrReplaceTempView("fund_request_live")

# COMMAND ----------

spark.sql(f"""
create or replace temp view accelerate_base as
with metronome_accounts as (
  select id, 
         customer_id,
         ending_before as contract_end_date
  from {metronome_schema}.contracts_contracts_silver
),
commits as (
select metadata:custom_fields:fundRequestId, 
       a.customer_id,
       a.contract_end_date,
       GET(access_schedule.schedule_items,0).end_date as commit_end_date,
       case when GET(access_schedule.schedule_items,0).end_date < a.contract_end_date then GET(access_schedule.schedule_items,0).end_date else a.contract_end_date end as poc_end_date,
       c.* 
from {metronome_schema}.contracts_commits_silver c
left join metronome_accounts a on c.contract_id = a.id
where 1=1
--environment_type = 'STAGING' and 
--contract_id = '10005699-5929-4c81-87f7-5679a93877ce'
and metadata:custom_fields:fundRequestId is not null
),
sfdc_user as (
  select id, 
         name 
  from main.sfdc_bronze.`user` 
  where processDate = (select max(processDate) from main.sfdc_bronze.`user`)
),
sfdc_accounts as (
  select id as acc_id, 
         Name as acc_name, 
         Owner_Email__c,          
         OwnerId 
  from {sfdc_schema}.account 
  where processDate = (select max(processDate) from {sfdc_schema}.account)
),
fund_request as (
  select * 
  from {fundrequest_table}
  where processDate = (select max(processDate) from {fundrequest_table})
),
bus_sub as (
  select * from {platform_sub_table}  where processDate = (select max(processDate) from {platform_sub_table})
),
fun_account_join as (
  select a.*, 
         f.id as fund_req_id,
         f.Business_Subscription__c,
         b.name as ae_name,
         bs.name as business_subscription_id,
         bs.Customer_Email__c as customer_email
from fund_request_live f 
left join sfdc_accounts a on f.Account__c = a.acc_id
left join sfdc_user b on a.OwnerId = b.id
left join bus_sub bs on f.Business_Subscription__c = bs.id
)
select case when burndown_fraction >= 0.5 and burndown_fraction < 0.75 then '50' 
            when burndown_fraction >= 0.75 and burndown_fraction < 0.95 then '75'
            when burndown_fraction >= 0.95 and burndown_fraction < 1 then '95' 
            when burndown_fraction >= 1 then '100'
            else 'N/A' end as burndown_level,
        case when burndown_fraction >= 0.5 and burndown_fraction < 0.75 then '50% Consumed' 
              when burndown_fraction >= 0.75 and burndown_fraction < 0.90 then '75% Consumed'
              when burndown_fraction >= 0.90 and burndown_fraction < 1 then '90% Consumed'
              when burndown_fraction >= 1 then 'Funds Exhausted'
              when poc_end_date < current_date() then 'Funds Expired'
              else 'N/A' end as burndown_bs_status,        
        * from commits c left join fun_account_join a on c.fundRequestId = a.fund_req_id
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from accelerate_base

# COMMAND ----------

if environment == 'development':
  burndown_df = spark.sql("""
  with burndown as (
  select id as commit_id, contract_id, name, burndown_fraction, burndown_fraction_updated, total_commit, total_consumed, total_cost, remaining_balance, remaining_balance_updated 
  from main.it_billing_and_rating.contracts_commits_silver --timestamp as of '2024-07-01'
  where name = 'Complimentary Usage - AWS'
  ),
  contract_acc as (
    select id, customer_id, salesforce_opportunity_id as opp_id from main.it_billing_and_rating.contracts_contracts_silver
  ),
  sfdc_acc as (
  select Billing_System_ID__c, id as acc_id, name as acc_name, account.OwnerId, account.Owner_Email__c from main.sfdc_bronze.account where processDate = (select max(processDate) from main.sfdc_bronze.account)
  and Billing_System_ID__c is not null
  ),
  sfdc_user as (
    select id, 
          name as ae_name
    from main.sfdc_bronze.`user` 
    where processDate = (select max(processDate) from main.sfdc_bronze.`user`)
  ),
  sfdc_order as (
    select Billing_System_ID__c as metronome_order_id,Business_Subscription_Type__c, id as sfdc_order_id, AccountId from main.sfdc_bronze.`order` where processDate = (select max(processDate) from main.sfdc_bronze.order)
  ),
  sfdc_opp as (
    select id sfdc_opportunity_id, AccountId from main.sfdc_bronze.opportunity where processDate = (select max(processDate) from main.sfdc_bronze.opportunity)
  ),
  opp_join as (
  select *,
        case when burndown_fraction >= 0.5 and burndown_fraction < 0.75 then '50' 
              when burndown_fraction >= 0.75 and burndown_fraction < 0.90 then '75'
              when burndown_fraction >= 0.90 and burndown_fraction < 0.95 then '90'
              when burndown_fraction >= 0.95 and burndown_fraction < 1 then '95' 
              when burndown_fraction >= 1 then '100' 
              else 'N/A' end as burndown_level,
        case when burndown_fraction >= 0.5 and burndown_fraction < 0.75 then '50% Consumed' 
              when burndown_fraction >= 0.75 and burndown_fraction < 0.90 then '75% Consumed'
              when burndown_fraction >= 0.90 and burndown_fraction < 0.95 then '90% Consumed'
              when burndown_fraction >= 0.95 and burndown_fraction < 1 then 'N/A' 
              when burndown_fraction >= 1 then 'Funds Exhausted' 
              else 'N/A' end as burndown_bs_status
          
  from burndown b 
    left join contract_acc c on b.contract_id = c.id
    left join sfdc_opp o on c.opp_id = o.sfdc_opportunity_id
    left join sfdc_acc s on trim(s.acc_id) = o.AccountId
    left join sfdc_user u on s.OwnerId = u.id
  )
  select distinct customer_id as account_id,
        contract_id,
        name as sku_name,
        sfdc_opportunity_id as fund_request_id,
        acc_id as sfdc_account_id,
        acc_name as sfdc_account_name,
        burndown_fraction,
        burndown_level,
        'AE' as recipent_type,
        Owner_Email__c as recipent_email,
        ae_name as recipent_name,
        current_date() as process_date
        --'2024-07-01' as process_date
  from opp_join
    """)
else:
  burndown_df = spark.sql(f"""
  select distinct customer_id as account_id,
        contract_id,
        name as sku_name,
        fundRequestId as fund_request_id,
        acc_id as sfdc_account_id,
        acc_name as sfdc_account_name,
        contract_end_date,
        commit_end_date,
        string(poc_end_date) poc_end_date,
        burndown_fraction,
        burndown_level,
        burndown_bs_status,
        Owner_Email__c as ae_email,
        ae_name,
        customer_email,
        Business_Subscription__c as business_sub_sfdc_id,
        date(current_date()) as process_date
  from accelerate_base
  --where burndown_level <> 'N/A' --and acc_id is not null
  """)

# COMMAND ----------

display(burndown_df)

# COMMAND ----------

if burndown_df.count() == 0:
  print("Nothing to write!")
else:
  print(f"Writing on table: {acclerate_burndown_snap_table}")
  burndown_df.write\
    .format('delta') \
    .mode('overwrite') \
    .option("overwriteSchema", "true") \
    .option("replaceWhere", f"process_date = '{processDate}'") \
    .saveAsTable(acclerate_burndown_snap_table)

# COMMAND ----------

burndown_email_df = spark.sql(f"""
with notifications as (
  select fund_request_id, burndown_level, sku_name from {accelerate_notifications_table}
),
burndown as (
select distinct * except (contract_id, contract_end_date, commit_end_date, poc_end_date)
from {acclerate_burndown_snap_table} where burndown_level <> 'N/A' and sfdc_account_id is not null and process_date = current_date()
)
select burndown.* from burndown left join notifications on burndown.fund_request_id = notifications.fund_request_id and burndown.sku_name = notifications.sku_name and burndown.burndown_level = notifications.burndown_level
where notifications.fund_request_id is null
""")

# COMMAND ----------

display(burndown_email_df)

# COMMAND ----------

burndown_collect = burndown_email_df.collect()
email_reciept_list = []
for i in burndown_collect:
  email_reciept_dict = {}
  ae_name = i['ae_name']
  account_name = i['sfdc_account_name']
  account_id = i['sfdc_account_id']
  burndown_level = i['burndown_level']
  fund_request_id = i['fund_request_id']
  to_address = i['ae_email']
  if environment == 'production':
    dry_run = False
  elif environment == 'integration':
    dry_run = False
    to_address = recipent_email
  else:
    dry_run = True
  message_id = send_email_to_ae(to_address, ae_name, account_name, account_id, sfdc_url, burndown_level, fund_request_id, environment, dry_run)
  print(i['ae_name'],account_name, message_id)
  email_reciept_dict['account_id'] = i['sfdc_account_id']
  email_reciept_dict['account_name'] = i['sfdc_account_name']
  #email_reciept_dict['contract_id'] = i['contract_id']
  email_reciept_dict['sku_name'] = i['sku_name']
  email_reciept_dict['timestamp'] = str(datetime.now())
  email_reciept_dict['burndown_level'] = i['burndown_level']
  email_reciept_dict['recipent_name'] = i['ae_name']
  email_reciept_dict['fund_request_id'] = i['fund_request_id']
  email_reciept_dict['recipent_type'] = 'AE'
  email_reciept_dict['recipent_email'] = to_address
  email_reciept_dict['message_id'] = message_id
  email_reciept_list.append(email_reciept_dict)
#print(message_id)

# COMMAND ----------

if len(email_reciept_list) == 0:
  accelerate_schema = spark.sql(f"select * from {accelerate_notifications_table}").schema
  email_reciept_df = spark.createDataFrame([], accelerate_schema)
else:
  email_reciept_df = spark.createDataFrame(email_reciept_list)

# COMMAND ----------

display(email_reciept_df)

# COMMAND ----------

# %sql
# CREATE OR REPLACE TABLE main.it_consumption_silver.accelerate_notifications AS
# select * from integration.it_billing_and_rating.accelerate_notifications

# COMMAND ----------

burndown_bs_df = burndown_email_df.select("business_sub_sfdc_id", "burndown_bs_status") \
                                  .withColumnRenamed("business_sub_sfdc_id", "Id") \
                                  .withColumnRenamed("burndown_bs_status", "Accelerate_Funds_Usage_Status__c") \
                                  .filter("Id is not null")


# COMMAND ----------

display(burndown_bs_df)

# COMMAND ----------

df = burndown_bs_df.toPandas()
if df.count().all() != 0:
  upsert_data = [val for val in df.T.to_dict().values()]
  print(len(upsert_data), upsert_data[0])
  print("Writing data: ")
  try:
    result = sf.bulk.PlatformSubscription__c.upsert(data=upsert_data, external_id_field='Id', batch_size=50)
    success=0
    fail=0
    error_list=[]
    for i in result:
      if i['success'] == False:
        fail+=1
        if i['errors'] not in error_list:
          error_list.append(i['errors'])
      else:
        success+=1
    print("Successs {} failure {}".format(success, fail))
    print(error_list)
  except Exception as e:
    print("The upsert operation errored out! Error code: " + str(e))
else:
  print("No data to write!")

# COMMAND ----------

# accelerate_schema = spark.sql("select * from integration.it_consumption_silver.accelerate_notifications").schema
# email_reciept_df = spark.createDataFrame([], accelerate_schema)

# COMMAND ----------

if email_reciept_df.count() == 0:
  print("Nothing to write!")
else:
  print(f"Writing data to : {accelerate_notifications_table}")
  email_reciept_df.write.option("overwriteSchema", "true").mode('append').format('delta').saveAsTable(f'{accelerate_notifications_table}')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Script for Navya

# COMMAND ----------

# soql = "select Fund_Request__c,Billing_System_ID__c, id,Order_SubType__c from Order"
# df = get_dataframe(soql, cred_str, sf_str)
# display(df)

# COMMAND ----------

try:
  validation_df = spark.sql(f"""
  with fund_request as (
    select Id as fund_request_id from {fundrequest_table} where processDate = (select max(processDate) from {fundrequest_table}) and Status__c = 'POC Initiated' and FundSource__c = 'Accelerate' and CreatedDate > '2024-07-29'
  ),
  order as (
  select Fund_Request__c, order.Billing_System_ID__c, id, order.Order_SubType__c from {sfdc_order_table} where processDate = (select max(processDate) from {sfdc_order_table}) --and order.Fund_Request__c is not null and Billing_System_ID__c is null
  )
  select * from fund_request left join order on order.Fund_Request__c = fund_request.fund_request_id
  """)
  display(validation_df)
except Exception as e:
  print("Error in validating salesforce Orders recon to metnome contract. Error code: " + str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Report for exhausted fund request

# COMMAND ----------

exhausted_df = spark.sql(f"""
select distinct account_id as metronome_accountid, 
                sku_name, 
                fund_request_id, 
                sfdc_account_id, 
                sfdc_account_name, 
                burndown_level,
                burndown_bs_status as burndown_status, 
                business_sub_sfdc_id as business_subscription_id  
from {acclerate_burndown_snap_table}
where burndown_level = '100' 
  and sfdc_account_id is not null 
  and process_date = (select max(process_date) from {acclerate_burndown_snap_table})
  and business_sub_sfdc_id is not null
""")

# COMMAND ----------

display(exhausted_df)

# COMMAND ----------


