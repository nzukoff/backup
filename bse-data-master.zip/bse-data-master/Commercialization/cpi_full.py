# Databricks notebook source
# MAGIC %md
# MAGIC ### Core Rates Logic
# MAGIC   * Get contract information
# MAGIC   * Calculate Exploded list price
# MAGIC   * Get SKU information
# MAGIC   * Map contract with SKU information
# MAGIC   * Calculate overrides
# MAGIC   * explode overrides and filter out duplicate price and get the right price for each date.
# MAGIC   * explode the list price 
# MAGIC   * Join list rates with the contracts  
# MAGIC   * Join overrides with the contracts
# MAGIC   * join the cleaned overrides with list rates(list rates left join overrides and if overrides is null then list rates else list rates)
# MAGIC   * Group them back
# MAGIC   * Join the grouped data with BS ID

# COMMAND ----------

!pip install bs4

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

import sys
sys.path.insert(0, "./")
from it_data_lib import email, configure_logging
from urllib.request import urlopen
import logging
import base64
from datetime import datetime, timedelta
import json
import ast

# COMMAND ----------

logger = configure_logging(s_level='ERROR')

# COMMAND ----------

dbutils.widgets.text("environment", 'production') # development, integration, production, test
environment = dbutils.widgets.get("environment")
print(environment)

# COMMAND ----------

dbutils.widgets.text("source_environment", 'production') # stage, production
source_environment = dbutils.widgets.get("source_environment")
print(source_environment)

# COMMAND ----------

dbutils.widgets.text("mode", 'append') # append, overwrite
mode = dbutils.widgets.get("mode")
print(mode)

# COMMAND ----------

dbutils.widgets.text("process_date", '') # if empty string then current date else the process date
process_date = dbutils.widgets.get("process_date")
print(process_date)

# COMMAND ----------

alert_sub = f"[{environment.upper()}]"
if environment == 'production':
  red_to_address = ['vicky.wang@databricks.com']
  bsid_dup_alert = ['vicky.wang@databricks.com', 'navya.gattupally@databricks.com', 'salil.mishra@databricks.com']
  yellow_to_address = ['jose.lainer@databricks.com']
  schema = "main.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage'
  final_table_name = 'contract_price_interface'
  alert_sub = ""
elif environment == 'integration':
  red_to_address = ['jose.lainer@databricks.com']
  bsid_dup_alert = ['jose.lainer@databricks.com']
  yellow_to_address = ['jose.lainer@databricks.com']
  schema = "integration.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage'
  final_table_name = 'contract_price_interface'  
elif environment == 'preprod':
  red_to_address = ['jose.lainer@databricks.com'] 
  bsid_dup_alert = ['jose.lainer@databricks.com']
  yellow_to_address = ['jose.lainer@databricks.com']
  schema = "integration.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage_preprod'
  final_table_name = 'contract_price_interface_preprod'
else:
  red_to_address = ['jose.lainer@databricks.com'] 
  bsid_dup_alert = ['jose.lainer@databricks.com']
  yellow_to_address = ['jose.lainer@databricks.com']
  schema = "integration.it_billing_and_rating"
  stage_table_name = 'contract_price_interface_stage_dev'
  final_table_name = 'contract_price_interface_dev'

if source_environment == 'production':
  sfdc_input_schema = "main.sfdc_bronze"
  input_schema = "main.it_billing_and_rating"
  environment_type = "'PRODUCTION'"
  promo_tag = "'promo-pricing'"
elif source_environment == 'sox_dev':
  sfdc_input_schema = "share_clf_main.sfdc_bronze"
  input_schema = "share_clf_main.it_billing_and_rating"
  environment_type = "'PRODUCTION'"
  promo_tag = "'promo-pricing'"
else:
  input_schema = "integration.it_billing_and_rating"
  sfdc_input_schema = "main.it_sfdc_uat2_bronze"
  environment_type = "'STAGING'"
  promo_tag = "'promo-pricing-service-account-stg', 'promo-pricing-user'"

# COMMAND ----------

def send_email_alert(to_address, alert, dry_run=False):
  subject = f'''{alert_sub}Contract Price Interface Alert'''
  email_body = f"""
  <html>
    <head>
      <title>{alert_sub}Contract Price Interface Alert</title>
    </head>
    <body>
      <p>Hi Team,</p>
      <p>Alert from Contract Price Interface {environment} run: {alert}</a>.</p>
    </body>
    </html>    
  """
  message_id = email.send_it_data_email(
    to_emails=to_address,
    subject=subject,
    body_html=email_body,
    dbutils=dbutils,
    logger=logger,
    dry_run=dry_run
  )
  return message_id


def send_alert(alert, to_address):
  #raise Exception("Data mismatch with metronome")
  alert_id = send_email_alert(to_address, alert, dry_run=False)
  print("Alert sent through email alert id:" + alert_id)


def create_metric_alert(alert_sql, alert_msg, alert_name, alert_type):
  df = spark.sql(alert_sql)
  cnt = df.count()
  if cnt > 0:
    alert_dict[alert_name] = cnt
    if alert_type == 'red':
      send_alert(alert_msg, red_to_address)
    elif alert_type == 'yellow':
      send_alert(alert_msg, yellow_to_address)
    elif alert_type == 'bsid_dup_alert':
      send_alert(alert_msg, bsid_dup_alert)
    display(df)
  else:
    alert_dict[alert_name] = 0

# COMMAND ----------

alert_dict = {}
alert_dict['environment'] = environment
alert_dict['mode'] = mode

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get all input date

# COMMAND ----------

def get_input_data(input_table, temp_view, process_date, table_schema):
  if table_schema == "it_billing_and_rating":
    predicate = ''
  elif table_schema == "sfdc_bronze":
    predicate = f" where processDate = (select max(processDate) from {input_table})"
  else:
    predicate = ''
  if process_date != '':
    process_timestamp = process_date.strip() + "T23:59:59Z"
    sql = f"""create or replace global temp view {temp_view} as
                    select * from {input_table} 
                    {predicate}"""
                    #timestamp as of '{process_timestamp}' 
    #print(sql)
    spark.sql(sql)
  else:
    sql = f"""create or replace global temp view {temp_view} as
                    select * from {input_table} {predicate} """
    #print(sql)
    spark.sql(sql)

# COMMAND ----------

process_date

# COMMAND ----------

input_tables = [
  {
    "table_name" : f"{input_schema}.contracts_contracts_silver",
    "temp_view" : "contracts_contracts_silver",
    "table_schema" : "it_billing_and_rating"
  },
  {
    "table_name" : f"{input_schema}.customer_silver",
    "temp_view" : "customer_silver",
    "table_schema" : "it_billing_and_rating"
  },
  {
    "table_name" : f"{input_schema}.contracts_usage_filters_silver",
    "temp_view" : "contracts_usage_filters_silver",
    "table_schema" : "it_billing_and_rating"
  },
  {
    "table_name" : f"{input_schema}.customer_bronze",
    "temp_view" : "customer_bronze",
    "table_schema" : "it_billing_and_rating"
  },
  {
    "table_name" : f"{input_schema}.contracts_rate_card_entries_silver",
    "temp_view" : "contracts_rate_card_entries_silver",
    "table_schema" : "it_billing_and_rating"
  },
  {
    "table_name" : f"{sfdc_input_schema}.pricebookentry",
    "temp_view" : "pricebookentry",
    "table_schema" : "sfdc_bronze"
  },
  {
    "table_name" : f"{sfdc_input_schema}.sku_manager__c",
    "temp_view" : "sku_manager__c",
    "table_schema" : "sfdc_bronze"
  },
  {
    "table_name" : f"{input_schema}.contracts_product_list_item_versions_silver",
    "temp_view" : "contracts_product_list_item_versions_silver",
    "table_schema" : "it_billing_and_rating"
  },
  {
    "table_name" : f"{input_schema}.contracts_amendments_silver",
    "temp_view" : "contracts_amendments_silver",
    "table_schema" : "it_billing_and_rating"
  },
  {
    "table_name" : f"{input_schema}.contracts_overrides_silver",
    "temp_view" : "contracts_overrides_silver",
    "table_schema" : "it_billing_and_rating"
  },
  {
    "table_name" : f"{sfdc_input_schema}.platformsubscription__c",
    "temp_view" : "platformsubscription__c",
    "table_schema" : "sfdc_bronze"
  },
  {
    "table_name" : f"{input_schema}.draft_rated_events_silver",
    "temp_view" : "draft_rated_events_silver",
    "table_schema" : "it_billing_and_rating"
  }
]
print("Processing data for " + process_date.strip() + "T23:59:59Z")
for i in input_tables:
  print("Creating global temp view: ", i["temp_view"])
  get_input_data(i["table_name"], i["temp_view"], process_date, i["table_schema"])

# COMMAND ----------

if process_date != '':
  process_timestamp = process_date.strip() + "T23:59:59Z"
else:
  process_timestamp = ''
  process_date = str(datetime.today().date())
  process_timestamp = str(datetime.today().strftime('%Y-%m-%dT%H:%M:%SZ'))
print(process_timestamp)
print(process_date)

# COMMAND ----------

alert_dict['process_date'] = process_date
alert_dict['process_timestamp'] = process_timestamp

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get Contract Information

# COMMAND ----------

spark.sql(f"""
create or replace table {schema}.contracts_customer_map as (
  with contracts as (
    select id as contract_id,
          customer_id,
          rate_card_id,
          to_date(starting_at) as contract_start_date,
          date_sub(ending_before,1) as contract_end_date,
          case when size(reseller_royalties) > 0 then true else false end as reseller_contracts,
          environment_type as contract_environment,
          min(updated_at) as contract_updated_at,
          archived_at as contract_archived_at
    from global_temp.contracts_contracts_silver
    where environment_type = {environment_type}
  group by all
  ),
  customers as (
    select id as customer_id, 
          name as customer_name,
          min(updated_at) as customer_updated_at,
          environment_type as customer_environment,          
          archived_at as customer_archived_at
    from global_temp.customer_silver
    where environment_type = {environment_type}
  group by all
  ),
  join_base as (
  select c.*, 
         cu.* except(customer_id),
         case when contract_start_date >= contract_end_date then true else false end as invalid_contract_date
  from contracts c
    left join customers cu on c.customer_id = cu.customer_id
  where cu.customer_name not like "%ARCHIVED" 
    and cu.customer_archived_at is null
    and c.contract_archived_at is null
  ),
  contract_filter as (
    select * except(invalid_contract_date, contract_archived_at, customer_archived_at)
    from join_base
    where invalid_contract_date is false
  )
  select distinct * from contract_filter 
  where contract_id not in ('84be75b6-780b-4e5e-afd2-6f714d3f03f2', '9569cd2a-a8c2-4d79-a588-ebc5a1f00f6e') -- Diameter Health and True Digital Group contract has overlapping bsid with active contracts, so exclude it. These two contracts have ended before FY25 so safe to exclude them
)
""")

# COMMAND ----------

spark.sql(f"""
create or replace temp view contracts_customer_map as 
select distinct * except(contract_updated_at, customer_updated_at) from {schema}.contracts_customer_map
""")

# COMMAND ----------

#Check if effective contract start date > effective contract end date
alert_sql = f"""
select distinct(contract_id), count(*) cnt from contracts_customer_map
group by all
having cnt > 1
"""
alert_msg = f"Duplicate records in Contract Customer Map!"
alert_name = "ContractDuplicateRecordsCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Business Subscription ID to the contract information

# COMMAND ----------

# MAGIC %md
# MAGIC Four different types of date that plays a crucial role in identifying the BSID's effective start date in a contract:
# MAGIC * bsid start date in ingest alias (updated_at)
# MAGIC * bsid start date in usage filter (effective_date)
# MAGIC * contract_start_date
# MAGIC * contract_end_date
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Steps for Ingest Alias start and end date
# MAGIC * Get all the contract customers data from customer_bronze
# MAGIC * Explode the ingest alias on customer_bronze
# MAGIC * Get a dataframe with customer and all its ingest alias
# MAGIC * For each ingest alias in a customer get the journey of it to understand the start and end date of the ingest alias for that customer.
# MAGIC   * For each ingest alias for a customer:
# MAGIC     * For each ingest alias history sorted by updated_at:
# MAGIC       * Get the first updated_at as the start date.
# MAGIC       * Check if the next update of ingest alias has the BSID. 
# MAGIC         * If yes continue
# MAGIC         * else mark it as the end date
# MAGIC       * If the end comes and there are BSID which doesnt have any end date then mark it as null.

# COMMAND ----------

def get_ingest_alias_dates():
  spark.sql(f"""
            create or replace temp view customer_ingest_aliases as 
              with contract_customer as (
                select distinct customer_id, customer_name from contracts_customer_map
              ),
              base as (
                select distinct b.id,
                                ingest_aliases,
                                c.customer_name,
                                updated_at, 
                                b.process_date,
                                cast(updated_at as date) as updated_date
                from contract_customer c
                left join global_temp.customer_bronze b on b.id =c.customer_id
                where archived_at is null
                    and c.customer_name not like "%ARCHIVED"
                    and c.customer_name not like "%[DEV]%"
                    and environment_type = {environment_type}
              )
              select * from base
  """)
  df = spark.sql("""
    with base as (
    select * except(ingest_aliases), explode_outer(from_json(ingest_aliases, 'array<string>')) business_subscription_id from customer_ingest_aliases
  )
  select id, collect_set(business_subscription_id) business_subscription_ids from base
        group by all
  """)
  customer_list = json.loads(df.toPandas().to_json(orient = 'records'))

  ingest_alias_df = spark.table("customer_ingest_aliases").toPandas()

  customer_dates_list = []
  for i in customer_list:
    #print(i)
    filter_customer_df = ingest_alias_df[ingest_alias_df.id == i['id']].sort_values(by=['updated_at', 'process_date'])
    #display(filter_customer_df)
    customer_dates_dict = {'id': i['id']}
    for j in i['business_subscription_ids']:
      bsid_dates_list = customer_dates_dict.copy()
      bsid_dates_list['business_subscription_id'] = j
      start_date = None
      end_date =None
      cnt = 0
      bsid_ind_list = []
      for k in filter_customer_df.iterrows():
        #print(k[1]['ingest_aliases'])
        if k[1]['ingest_aliases'] is not None:
          bsid_list = ast.literal_eval(k[1]['ingest_aliases'])
        else:
          bsid_list = []
        #print(bsid_list)
        if j in bsid_list:
          #print(k[1]['bsid_start_date'])
          if start_date is None:
            start_date = k[1]['updated_at']
            #print(f"start date {start_date}")
          # elif end_date is None:
          #   end_date = k[1]['bsid_start_date']
          else:
            pass
          #print(f"start date {start_date}")
        else:
          #if end_date is None and start_date is not None:
          if start_date is not None and k[1]['updated_at'] > start_date:
            end_date = (k[1]['updated_at'] - timedelta(days=1)).strftime("%Y-%m-%d")          
          else:
            start_date = None
          #print(f"end date {end_date}")

        if start_date is not None and end_date is not None:
          bsid_ind_dict = bsid_dates_list.copy()
          bsid_ind_dict['start_date'] = str(start_date)
          bsid_ind_dict['end_date'] = str(end_date)
          cnt+=1
          bsid_ind_dict['version'] = cnt
          #print(bsid_ind_dict)
          #bsid_dates_list[j].append(bsid_ind_dict)
          start_date = None
          end_date = None
          bsid_ind_list.append(bsid_ind_dict)
      if start_date is not None:
        bsid_ind_dict = bsid_dates_list.copy()
        bsid_ind_dict['start_date'] = str(start_date)
        if end_date is not None:
          bsid_ind_dict['end_date'] = str(end_date)
        else:
          bsid_ind_dict['end_date'] = None
        cnt+=1
        bsid_ind_dict['version'] = cnt
        #print(bsid_ind_dict)
        bsid_ind_list.append(bsid_ind_dict)
        #if len(bsid_ind_list) > 0:        
        #bsid_dates_list[j].append(bsid_ind_dict)
      start_date = None
      end_date = None
      customer_dates_list.extend(bsid_ind_list)

  ingest_alias_schema = StructType([StructField('id', StringType(), False), 
            StructField('business_subscription_id', StringType(), False), 
            StructField('start_date', StringType(), True), 
            StructField('end_date', StringType(), True), 
            StructField('version', StringType(), True)            
            ])
  df = spark.createDataFrame(customer_dates_list, ingest_alias_schema)

  return df

# COMMAND ----------

ingest_alias_df = get_ingest_alias_dates()
ingest_alias_df = ingest_alias_df.withColumn("start_date", col('start_date').cast('timestamp')) \
                                 .withColumn("end_date", col('end_date').cast('timestamp'))
ingest_alias_df.distinct().createOrReplaceTempView("ingest_alias_date_map")

# COMMAND ----------

def get_usage_filters_date():
  spark.sql(f"""create or replace temp view usage_filter_version as
      with base as (
      select contract_id,
                version,
                date(starting_at) as bsid_start_date,
                group_values,
                environment_type as business_subscription_environment
        from global_temp.contracts_usage_filters_silver
        where environment_type = {environment_type}
      ),
      filter_out_dates as (
      select b.* from base b
      left join contracts_customer_map c on c.contract_id = b.contract_id 
      where b.bsid_start_date>=c.contract_start_date and b.bsid_start_date <= date_sub(c.contract_end_date, -1)

      ),
      MinDates AS (
          -- Find the minimum date for each id
          SELECT contract_id, MIN(bsid_start_date) AS min_date
          FROM filter_out_dates
          GROUP BY contract_id
      ),
      MaxVersions AS (
          -- Find the maximum version for the minimum date of each id
          SELECT t.contract_id, t.min_date, MAX(y.version) AS max_version
          FROM MinDates t
          JOIN filter_out_dates y
            ON t.contract_id = y.contract_id AND t.min_date = y.bsid_start_date
          GROUP BY t.contract_id, t.min_date
      ),
      filter_version as (
      -- Step 3: Select only the records where the version matches the maximum version
      SELECT y.*, mv.* except(contract_id)
      FROM filter_out_dates y
      JOIN MaxVersions mv
        ON y.contract_id = mv.contract_id 
      where version >= max_version and max_version is not null
      )
      select * from filter_version --where contract_id = '7837347f-d0a5-4dec-a61f-65eafc06a593'
  """)
  df = spark.sql("""
      with base as (
      select contract_id, explode_outer(from_json(group_values, 'array<string>')) as business_subscription_id from usage_filter_version --where contract_id in ('5cac84af-d80e-4249-b82c-ad97a66b8227')
      )
      select contract_id, collect_set(business_subscription_id) business_subscription_ids from base
      group by all
  """)
  contract_list = json.loads(df.toPandas().to_json(orient = 'records'))


  usage_filters_df = spark.sql(f"""with usage_filter as (
      select contract_id,
              version,
              bsid_start_date,
              group_values,
              business_subscription_environment
        from usage_filter_version
        order by version
      )
      select c.contract_id, c.customer_id, c.contract_start_date, c.contract_end_date, u.version, u.bsid_start_date, group_values, business_subscription_environment  from {schema}.contracts_customer_map c
      left join usage_filter u on c.contract_id = u.contract_id and c.contract_start_date <= u.bsid_start_date and c.contract_end_date >= u.bsid_start_date
      where bsid_start_date is not null
      order by contract_id, version
  """).toPandas()

  contract_dates_list = []
  for i in contract_list:
    #print(i)
    filter_contract_df = usage_filters_df[usage_filters_df.contract_id == i['contract_id']].sort_values(by=['version'])
    #print(filter_contract_df['bsid_start_date'])
    contract_dates_dict = {'contract_id': i['contract_id']}  
    for j in i['business_subscription_ids']:
      #print(j)
      bsid_dates_list = contract_dates_dict.copy()
      bsid_dates_list['business_subscription_id'] = j
      start_date = None
      end_date =None
      cnt = 0
      bsid_ind_list = []
      for k in filter_contract_df.iterrows():
        #print(k[1]['bsid_start_date'])
        bsid_list = ast.literal_eval(k[1]['group_values'])
        if j in bsid_list:
          #print(k[1]['bsid_start_date'])
          if start_date is None:
            start_date = k[1]['bsid_start_date']
          else:
            pass
          #print(f"start date {start_date}")
        else:
          #if end_date is None and start_date is not None:
          if start_date is not None and k[1]['bsid_start_date'] > start_date:
            end_date = (k[1]['bsid_start_date'] - timedelta(days=1)).strftime("%Y-%m-%d")
          else:
            start_date = None
        if start_date is not None and end_date is not None:
          bsid_ind_dict = bsid_dates_list.copy()
          bsid_ind_dict['start_date'] = str(start_date)
          bsid_ind_dict['end_date'] = str(end_date)
          cnt+=1
          bsid_ind_dict['version'] = cnt
          #print(bsid_ind_dict)
          start_date = None
          end_date = None
          bsid_ind_list.append(bsid_ind_dict)
      if start_date is not None:
        bsid_ind_dict = bsid_dates_list.copy()
        bsid_ind_dict['start_date'] = str(start_date)
        if end_date is not None:
          bsid_ind_dict['end_date'] = str(end_date)
        else:
          bsid_ind_dict['end_date'] = str(k[1]['contract_end_date'])
        cnt+=1
        bsid_ind_dict['version'] = cnt
        #print(bsid_ind_dict)
        bsid_ind_list.append(bsid_ind_dict)
      contract_dates_list.extend(bsid_ind_list)
      start_date = None
      end_date = None
  
  df = spark.createDataFrame(contract_dates_list)
  return df

# COMMAND ----------

usage_filter_df = get_usage_filters_date()
usage_filter_df.distinct().createOrReplaceTempView("usage_filter_date_map")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view ingest_alias_date_map_filtered as
# MAGIC with usage_filter_base as(
# MAGIC   select distinct business_subscription_id, contract_id, max(end_date) over (partition by business_subscription_id, contract_id) as max_filter_end_date from usage_filter_date_map
# MAGIC ),
# MAGIC prev_contract_base as (
# MAGIC select *,lag(contract_id) over (partition by business_subscription_id order by max_filter_end_date) prev_contract_id from usage_filter_base
# MAGIC ),
# MAGIC usage_filter_final as (
# MAGIC select p.*, u.max_filter_end_date as prev_max_filter_end_date, c.contract_start_date as prev_contract_start_date, c.contract_end_date as prev_contract_end_date, c.customer_id as prev_customer_id, c1.customer_id, c1.contract_start_date, c1.contract_end_date  from prev_contract_base p 
# MAGIC   left join usage_filter_base u on p.prev_contract_id = u.contract_id
# MAGIC   left join contracts_customer_map c on p.prev_contract_id = c.contract_id
# MAGIC   left join contracts_customer_map c1 on p.contract_id = c1.contract_id
# MAGIC ),
# MAGIC ingest_alias_base as (
# MAGIC select i.*, c.* except(business_subscription_id, customer_id), i1.start_date as prev_alias_start_date, i1.end_date as prev_alias_end_date from ingest_alias_date_map i
# MAGIC left join usage_filter_final c on i.id = c.customer_id and c.contract_start_date <= coalesce(i.end_date, c.max_filter_end_date) and c.contract_end_date >= i.start_date  and i.business_subscription_id = c.business_subscription_id
# MAGIC left join ingest_alias_date_map i1 on i1.id = c.prev_customer_id
# MAGIC ),
# MAGIC final_filter as (
# MAGIC select * except(start_date, end_date), 
# MAGIC         case  when prev_contract_id is null then date_add(last_day(add_months(Date(start_date), -1 )),1) 
# MAGIC               when prev_contract_end_date is not null and prev_contract_end_date > date_add(last_day(add_months(Date(start_date), -1 )),1) then start_date
# MAGIC               else date_add(last_day(add_months(Date(start_date), -1 )),1)
# MAGIC         end as start_date,
# MAGIC         case when end_date is null then contract_end_date
# MAGIC             else end_date 
# MAGIC         end as end_date
# MAGIC from ingest_alias_base
# MAGIC )
# MAGIC
# MAGIC select * from final_filter

# COMMAND ----------

spark.sql(f"""
create or replace temp view contracts_bsid_map as
with bsid_base as (
  select business_subscription_id, 
         contract_id,
         to_date(start_date) uf_start_date,
         to_date(end_date) uf_end_date
  from usage_filter_date_map
),
ingest_aliases as (
  select distinct business_subscription_id, id, to_date(start_date) as start_date,  to_date(end_date) as end_date, contract_id
  from ingest_alias_date_map_filtered
),
join_base as (
select c.*,
       b.* except(contract_id),
       e.* except(business_subscription_id, id, contract_id),
       case when b.uf_start_date <= c.contract_end_date and b.uf_start_date >= c.contract_start_date and b.uf_end_date >= c.contract_start_date and b.uf_end_date <= c.contract_end_date then false else true end as invalid_bsid_start_date,
       case when to_date(greatest(b.uf_start_date,e.start_date)) > c.contract_start_date then to_date(greatest(b.uf_start_date,e.start_date)) else contract_start_date end as effective_contract_start_date,
       case when to_date(least(b.uf_end_date,e.end_date)) < c.contract_end_date then to_date(least(b.uf_end_date,e.end_date)) else contract_end_date end as effective_contract_end_date
from contracts_customer_map c
left join bsid_base b on c.contract_id = b.contract_id
left join ingest_aliases e on e.business_subscription_id = b.business_subscription_id and c.customer_id = e.id and b.uf_start_date <= coalesce(e.end_date, contract_end_date) and b.uf_end_date >= e.start_date and c.contract_id = e.contract_id
where b.business_subscription_id is not null
and e.id is not null
)
select * from join_base where invalid_bsid_start_date is false
""")

# COMMAND ----------

#Check if effective contract start date > effective contract end date
alert_sql = f"""
select * from contracts_bsid_map where effective_contract_start_date > effective_contract_end_date
"""
alert_msg = f"Contract Effective Start Date > Contract Effective End Date detected. Please check the workflow run."
alert_name = "BSIDDuplicateRecordsCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow')


# COMMAND ----------

if spark.sql(alert_sql).count() > 0:
  spark.sql("""create or replace temp view contracts_bsid_final_map_filtered as 
            select * from contracts_bsid_map where date(effective_contract_start_date) <= date(effective_contract_end_date)
            """)
  bsid_contract_map_vw = 'contracts_bsid_final_map_filtered'
else:
  bsid_contract_map_vw = 'contracts_bsid_map'

spark.sql(f"""
create or replace temp view contracts_bsid_exploded as
with base as (
select distinct contract_id, customer_id, rate_card_id, contract_start_date, contract_end_date, contract_environment, customer_name, customer_environment, business_subscription_id, reseller_contracts, effective_contract_start_date, effective_contract_end_date  from {bsid_contract_map_vw}
),
customer_exploded as (
    select distinct
    * except(effective_contract_end_date, effective_contract_start_date),
    explode(
      sequence(
        effective_contract_start_date,
        effective_contract_end_date,
        interval 1 day
      )
    ) contract_date
  from
    base
)
select * from customer_exploded
""")

# COMMAND ----------

spark.sql(f"""
create or replace table {schema}.contracts_bsid_final_map as
with seq_row as (
  select distinct
    *,
    row_number() over (
      partition by  contract_id, customer_id, rate_card_id, contract_start_date, contract_end_date, contract_environment, customer_name, customer_environment, business_subscription_id, reseller_contracts
      ORDER BY
        contract_date
    ) seq_date_num
  from
    contracts_bsid_exploded
),
final_group as (
select
contract_id, customer_id, rate_card_id, contract_start_date, contract_end_date, contract_environment, customer_name, customer_environment, business_subscription_id, reseller_contracts,
  min(contract_date) effective_contract_start_date,
  max(contract_date) effective_contract_end_date
from
  seq_row
group by
contract_id, customer_id, rate_card_id, contract_start_date, contract_end_date, contract_environment, customer_name, customer_environment, business_subscription_id, reseller_contracts,
  dateadd(day, -seq_date_num, contract_date)
)
select * from final_group
""")


# COMMAND ----------

#Check if there is duplicate dates for business subscription ID
if source_environment == 'production':
  predicate = "where business_subscription_id not in ('BS-0000005751','BS-0000011004','BS-0000157749','BS-0000010910', 'BS-0000166709', 'BS-0000007047')"   
else:
  predicate = "where customer_id not in ('e1d257af-0a46-48d1-a757-40b94f15dc3e', 'c3c82f00-c265-495c-986a-ffe326150d05')" #Duplicates in these two accounts in staging environment
alert_sql = f"""
select business_subscription_id, contract_date, count(*) cnt from contracts_bsid_exploded
{predicate}
group by all
having cnt > 1
"""
df = spark.sql(alert_sql)
bs_df = df.select('business_subscription_id').distinct().collect()
bs_list = [x.business_subscription_id for x in bs_df]
alert_msg = f"Duplicate records for business subscription ID for a given date detected. The business subscription with duplicates are: {bs_list}. Please check the workflow run."
alert_name = "BSIDDuplicateRecordsCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'bsid_dup_alert')
alert_dict['BSIDDuplicateRecords'] = bs_list

# COMMAND ----------

#Check if contract End Date and Effective Contract Start Date are same 
alert_sql = f"""
select * from {schema}.contracts_bsid_final_map where contract_end_date = effective_contract_start_date and contract_id not in ('3a44cbf7-40f8-4a3c-b54d-7ed0d8a5fc34','a314de89-1f76-4b15-b540-8043860bd90a') -- This is a legit record
"""
alert_msg = f"Contract End Date and Effective Contract Start Date are same in contract to Business Subscription ID mapping. Please check the workflow run."
alert_name = "EffectiveContractStartDateCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Calculate Exploded list price

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view promo_pricing_exploded as 
# MAGIC with sku_manager as (
# MAGIC   select * from main.sfdc_bronze.sku_manager__c where processDate = (select max(processDate) from main.sfdc_bronze.sku_manager__c)
# MAGIC ),
# MAGIC final as (
# MAGIC select p.*, s.Metronome_ProductID__c, s.Platform_Product_Code__c from main.it_billing_and_rating.promo_pricing_exploded p
# MAGIC left join sku_manager s on p.NS_Internal_ID__c = s.NS_Internal_ID__c
# MAGIC )
# MAGIC select *  from final

# COMMAND ----------

spark.sql(f"""
create or replace table {schema}.metronome_list_rates as
with list_price as (
  SELECT distinct rate_card_id,
      product_id,
      cast(rate:unit_price as decimal(38, 18)) / 100.0 as unit_price,
      to_date(starting_at) list_start_date,
      to_date(coalesce(ending_before, '2050-01-01')) list_end_date,
      entitled as sku_entitled,
      version,
      --row_number() over(partition by product_id order by version desc) as version_rank,
      environment_type as rate_env_type
  FROM global_temp.contracts_rate_card_entries_silver
  where environment_type = {environment_type} 
),
list_exploded as (
    select
    *,
    explode(
      sequence(
        list_start_date,
        date_sub(list_end_date,1),
        interval 1 day
      )
    ) list_date
  from
    list_price
),
list_version_rank as (
  select *,
  row_number() over(partition by product_id, list_date order by version desc) as version_rank
  from list_exploded
),
filter_version as (
  select * from list_version_rank where version_rank = 1
),
seq_row as (
  select
    *,
    row_number() over (
      partition by   rate_card_id,
        product_id,
        unit_price,
        sku_entitled,
        rate_env_type
      ORDER BY
        list_date
    ) seq_date_num
  from
    filter_version 
),
final_group as (
select
  rate_card_id,
  product_id,
  unit_price,
  rate_env_type,
  sku_entitled,
  min(list_date) list_start_date,
  max(list_date) list_end_date
from
  seq_row
group by
  rate_card_id,
  product_id,
  unit_price,
  rate_env_type,
  sku_entitled,
  dateadd(day, - seq_date_num, list_date)
),
collect_group as (
  select * except (min_start_rank),
  case when  min_start_rank = 1 and list_start_date > '2020-01-01' then to_date('2020-01-01') else list_start_date end as effective_list_start_date
  from (
    select *, row_number() over (partition by product_id, rate_env_type order by list_start_date) min_start_rank from final_group
  )
),
list_promo_exploded as (
    select
    *,
    explode(
      sequence(
        effective_list_start_date,
        list_end_date,
        interval 1 day
      )
    ) list_date
  from
    collect_group
),
promo_add as (
  select
  * except(unit_price),
  u.unit_price * (1 - coalesce(p.Promo_Discount__c, 0) / 100) as unit_price,
  p.Name as promo_name
  from list_promo_exploded u
  left join promo_pricing_exploded p on u.list_date = p.promo_date
  and u.product_id = p.Metronome_ProductID__c
),
promo_seq_row as (
  select
    *,
    row_number() over (
      partition by   rate_card_id,
        product_id,
        unit_price,
        sku_entitled,
        rate_env_type,
        promo_name
      ORDER BY
        list_date
    ) seq_date_num
  from
    promo_add 
),
promo_final_group as (
select
  rate_card_id,
  product_id,
  unit_price,
  rate_env_type,
  sku_entitled,
  promo_name,
  min(list_date) list_start_date,
  max(list_date) list_end_date
from
  promo_seq_row
group by
  rate_card_id,
  product_id,
  unit_price,
  rate_env_type,
  sku_entitled,
  promo_name,
  dateadd(day, - seq_date_num, list_date)
)
select * except(unit_price),
cast(unit_price as decimal(38, 17)) as unit_price
from promo_final_group
""")

# COMMAND ----------

spark.sql(f"""
create or replace temp view list_rates_exploded as 
  select *,
    explode(
      sequence(
        list_start_date,
        list_end_date,
        interval 1 day
      )
    ) list_date
  from
    {schema}.metronome_list_rates
""")

# COMMAND ----------

#check duplicates in the list dates
alert_sql = f"""
select * except(list_start_date, list_end_date, unit_price, sku_entitled), count(*) cnt from list_rates_exploded
group by all
having cnt > 1
"""
alert_msg = f"Duplicates in list rates found. Please check the workflow run."
alert_name = "ListRatesDuplicateRecordsCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get the SKU information

# COMMAND ----------

if source_environment == 'production':
  predicate =''
else:
  predicate = """and sku_cloud is not null and name not in ('MCT Model Training On Demand - GCP Canada (Montreal)',
'MCT Model Training On Demand - GCP Canada (Montreal)',
'MCT Model Training On Demand - GCP Europe (Belgium)',
'MCT Model Training On Demand - GCP Europe (Belgium)',
'AWS Enterprise Model Training - US East (N. Virginia)',
'AWS Enterprise Model Training - US East (N.Virginia)',
'MCT Inference in Enterprise Cluster - OCI',
'MCT Inference in Enterprise Cluster - AWS',
'GCP Premium Automated Serverless Compute - Asia (Singapore)',
'GCP Premium Automated Serverless Compute - Asia (Singapore)',
'MCT Model Training Res - AWS Europe (Frankfurt)',
'MCT Model Training Hero Res - AWS Europe (Frankfurt)',
'MCT Model Training On Demand - GCP Australia (Sydney)',
'MCT Model Training On Demand - GCP Australia (Sydney)',
'MCT Model Training Hero Res - OCI US (Phoenix)',
'MCT Model Training Res - AWS US West (N. California)',
'AWS Inter-Region Egress from AWS GovCloud (US-West)',
'AWS Inter-Region Egress from AWS GovCloud (US-West)')"""

spark.sql(f"""
create or replace table {schema}.cpi_sku_final as (
  --salesforce product_code
  with sfdc_pricebook as (
    SELECT DISTINCT Name, ProductCode
      FROM global_temp.pricebookentry
    WHERE processDate = (SELECT MAX(processDate) FROM global_temp.pricebookentry)
  ),
  sku_manager as (
    select Cloud__c,
            SKU_Name__c,
            SKUName__c,
            Platform_Sku_Name__c,
            NS_Internal_ID__c,
            Region__c as sku_gfm_region,
            Money_Specific_Cloud__c,
            Cloud__c,
            Region_Type__c
    from global_temp.sku_manager__c
    where processDate = (select max(processDate) from global_temp.sku_manager__c) 
      --and SKU_Type__c = 'Usage'
  ),
  products_base as (
    select
      product_list_item_id,
      cp.name,
      Platform_Sku_Name__c,
      Region_Type__c,
      coalesce(Platform_Sku_Name__c, sm.SKUName__c, ProductCode) as product_code,
      SKUName__c as cpq_product_code,
      metadata :netsuite_internal_item_id as netsuite_internal_item_id,
      environment_type as product_env_type,
            case when Cloud__c is null and cp.name like "%AWS%" then "AWS"
           when Cloud__c is null and cp.name like "%Azure%" then "AZURE"
           when Cloud__c is null and cp.name like "%GCP%" then "GCP"
           when Cloud__c = 'MCT' and Money_Specific_Cloud__c is not null then upper(Money_Specific_Cloud__c)
           else Cloud__c
      end as sku_cloud,
      sku_gfm_region,
      Money_Specific_Cloud__c,
      row_number() over(partition by product_list_item_id order by version desc) as version_rank
    from
      global_temp.contracts_product_list_item_versions_silver cp
      left join sfdc_pricebook sp on cp.name = sp.Name
      left join sku_manager sm on cp.metadata :netsuite_internal_item_id = sm.NS_Internal_ID__c
    where lower(type) = 'usage' and environment_type = {environment_type}
  ),
  products as (
    select * except(version_rank)
    from products_base
    where version_rank = 1
    and product_code is not null
  )
  --join product with list rates
  select distinct
    products.*,
    mr.rate_card_id,
    mr.sku_entitled
  from
    products
    left join {schema}.metronome_list_rates mr on products.product_list_item_id = mr.product_id
  where name not in ('ARCHIVED', 'DUPLICATE', 'Duplicate', 'xx duplicate','xx')
  and name not like '%IGNORE%' {predicate}
)
""")

# COMMAND ----------

#Check whether SKU region has changed from the previous day
if mode == 'append':
  alert_sql = f"""
    with sku_distinct as (
      select distinct product_code, sku_gfm_region, sku_cloud  from {schema}.cpi_sku_final
    ),
    sku_manager as ( 
    select distinct  coalesce(Platform_Sku_Name__c, SKUName__c) sku_name,
                    case when Cloud__c is null and name like "%AWS%" then "AWS"
                          when Cloud__c is null and name like "%Azure%" then "AZURE"
                          when Cloud__c is null and name like "%GCP%" then "GCP"
                          when Cloud__c = 'MCT' and Money_Specific_Cloud__c is not null then Money_Specific_Cloud__c
                          else Cloud__c
                    end as sku_cloud,
                    Region__c
    from global_temp.sku_manager__c where processDate = date_sub('{process_date}',1)
    )
    select * from sku_distinct d left join sku_manager m on d.product_code = m.sku_name and d.sku_cloud = m.sku_cloud where d.sku_gfm_region <> m.Region__c
  """
  alert_msg = f"SKU Region has changed! Please check the workflow run."
  alert_name = "SkuRegionCheck"
  create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow')

# COMMAND ----------

#Check if duplicate product_code with metronome
# alert_sql = f"""
#   with product as 
#   ( 
#     select product_code, 
#                     sku_cloud, 
#                     name 
#     from {schema}.cpi_sku_final
#   ),
#   dups as (
#     select product_code, 
#           sku_cloud, 
#           count(*) cnt 
#     from product
#     group by all
#     having cnt > 1
#   )
#   select product_code as platform_product_code, 
#         sku_cloud, 
#         name as metronome_product_name 
#   from product 
#   where product_code in 
#     (
#       select product_code from dups
#       where product_code not in ('AWS_ENHANCED_SECURITY_COMPLIANCE', 'GCP_HIPAA_COMPLIANCE')
#     )
# """
# alert_msg = f"Duplicate product code in final sku dataframe found. Please check the workflow run."
# alert_name = "SkuDuplicateRecordsCheck"
# create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow')

# COMMAND ----------

#Check if the product_code and sku_cloud are not null
alert_sql = f"""select * 
from {schema}.cpi_sku_final 
where product_code is null 
      or sku_cloud is null
"""
alert_msg = f"Product code or sku cloud is null. Please check the workflow run."
alert_name = "SkuCloudNullCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'red')  

# COMMAND ----------

# MAGIC %md
# MAGIC ### Map Contract with SKU information

# COMMAND ----------

spark.sql(f"""
create or replace temp view contracts_product_map as 
with contract_info as (
  select distinct contract_id, customer_name, customer_id, rate_card_id, contract_start_date, contract_end_date from {schema}.contracts_customer_map
),
final as (
select customer_id, 
         customer_name, 
         contract_id, 
         c.rate_card_id, 
         contract_start_date, 
         contract_end_date,
         s.* except(rate_card_id)
from contract_info c
left join {schema}.cpi_sku_final s on c.rate_card_id = s.rate_card_id
)
select * from final
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Calculate the rates overrides

# COMMAND ----------

spark.sql(f"""
create or replace table {schema}.cpi_contract_overrides
as select * from global_temp.contracts_overrides_silver
""")

# COMMAND ----------

spark.sql(f"""
create or replace temp view overrides as
with amendments as (
    select * 
    from global_temp.contracts_amendments_silver
    where environment_type in ({environment_type})
),
overrides_base as (
  select * 
  from {schema}.cpi_contract_overrides
  where new_rate:unit_price is not null
),
amend_join as (
  select
    c.contract_id,
    c.product_id,
    cast(new_rate:unit_price as decimal(38, 18)) / 100.0  as unit_price,
    c.starting_at as override_start_date,
    c.entitled as overrides_entitled,
    case when rate_type is null then 'unknown rate type' 
      when rate_type = 'overwrite_flat' then 'fixed rate'
      when rate_type = 'overwrite_percentage' then 'percentage' 
      --when promo_price_tag is not null then 'promotion'
      else null
    end as type,
    case when cast(c.starting_at as date) >= cast(c.ending_before as date) then c.ending_before
      else date_sub(c.ending_before,1) 
      end as override_end_date,
    c.environment_type,
    row_number() over(partition by c.contract_id, c.product_id, c.starting_at, c.ending_before order by a.created_at desc) as amend_rank,
    a.created_at amend_created_at,
    case when trim(a.created_by) in ({promo_tag}) then 'promo_rate_change'
         else null
    end as promo_tag,
    case when trim(a.created_by) in ({promo_tag}) then 'Promotional Pricing Overrides'
         else 'SKU Price Overrides'
    end as override_type
  from overrides_base c
    left join amendments a on c.amendment_id = a.id
  where c.environment_type in ({environment_type})
)
select * except(amend_rank)
from amend_join 
where case when amend_rank is null then 1 else amend_rank end = 1
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Join overrides with contract information

# COMMAND ----------

spark.sql(f"""
create or replace temp view overrides_contract_join as
with distinct_contract_product as (
  select distinct contract_id, product_list_item_id, contract_start_date, contract_end_date from contracts_product_map
),
join_contract as (
select c.* except(c.contract_id, c.product_list_item_id), 
        o.*,
        case
          when override_start_date is null then contract_start_date
          else override_start_date
        end as effective_order_item_start_date,
        case
          when override_end_date is null then contract_end_date
          else override_end_date
        end as effective_order_item_end_date
from distinct_contract_product c
left join overrides o on c.contract_id = o.contract_id and c.product_list_item_id = o.product_id
where o.contract_id is not null
),
corrected_date as (
select * except (effective_order_item_start_date),
      -- case when effective_order_item_start_date < effective_order_item_end_date then date_sub(effective_order_item_end_date, 1)    
      --   else effective_order_item_end_date
      -- end as effective_order_item_end_date,
      case when contract_start_date > effective_order_item_start_date then contract_start_date else effective_order_item_start_date end as effective_order_item_start_date  -- fix for  rows where override start date < contract start date
from join_contract
)
select * except (effective_order_item_end_date),
      case when effective_order_item_end_date > contract_end_date then contract_end_date -- fix for  rows where override end date > contract end date
      else effective_order_item_end_date
      end as effective_order_item_end_date
from corrected_date
where effective_order_item_start_date <= contract_end_date
""")

# COMMAND ----------

#Check whether the overrides start and end date are within contract start and end dates
alert_sql = f"""
select * from overrides_contract_join where effective_order_item_end_date > contract_end_date or effective_order_item_start_date < contract_start_date
"""
alert_msg = f"Overrides start and end date are not within contract start and end dates. Please check the workflow run."
alert_name = "EffectiveContractrItemDateCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow')

# COMMAND ----------

spark.sql(f"""
create or replace temp view overrides_rates_exploded as 
  select *,
    explode(
      sequence(
        effective_order_item_start_date,
        effective_order_item_end_date,
        interval 1 day
      )
    ) effective_date
  from
    overrides_contract_join
""")

# COMMAND ----------

#Check whether effective_order_item_start_date > effective_order_item_end_date
alert_sql = f"""
select * from overrides_contract_join where effective_order_item_start_date > effective_order_item_end_date
"""
alert_msg = f"Effective order item start date is greater than effective order item end date in the overrides join temp view. Please check the workflow run."
alert_name = "EffectiveContractrItemDateCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- unfilter the duplicates and union the filtered rows and the rows which didnt have any duplicates
# MAGIC create or replace temp view contract_override_rates_exploded as 
# MAGIC --Filter the rows which has duplicates 
# MAGIC with metronome_dupe_check as (
# MAGIC   select
# MAGIC       distinct contract_id,
# MAGIC       product_id,
# MAGIC       effective_date,
# MAGIC       count(*) cnt
# MAGIC     from
# MAGIC       overrides_rates_exploded
# MAGIC     group by
# MAGIC       all
# MAGIC     having
# MAGIC       cnt > 1
# MAGIC     order by
# MAGIC       cnt desc
# MAGIC ),
# MAGIC --Filter the rows which does not have duplicates
# MAGIC non_dup_sku_rates as (
# MAGIC   select
# MAGIC     r.*
# MAGIC   from
# MAGIC     overrides_rates_exploded r left anti
# MAGIC     join metronome_dupe_check d on r.contract_id = d.contract_id
# MAGIC     and r.product_id = d.product_id
# MAGIC     and r.effective_date = d.effective_date
# MAGIC ),
# MAGIC dup_sku_rates as (
# MAGIC   select
# MAGIC     r.*,
# MAGIC     row_number() over(partition by r.contract_id, r.product_id, r.effective_date order by r.amend_created_at desc) as amend_date_rank
# MAGIC   from
# MAGIC     overrides_rates_exploded r
# MAGIC     left join metronome_dupe_check d on r.contract_id = d.contract_id
# MAGIC     and r.product_id = d.product_id
# MAGIC     and r.effective_date = d.effective_date
# MAGIC   where
# MAGIC     d.contract_id is not null
# MAGIC     and d.product_id is not null
# MAGIC     and d.effective_date is not null
# MAGIC ),
# MAGIC dup_clean_rates as (
# MAGIC   select
# MAGIC     r.*
# MAGIC   except(amend_date_rank)
# MAGIC   from
# MAGIC     dup_sku_rates r
# MAGIC   where
# MAGIC     amend_date_rank = 1
# MAGIC ),
# MAGIC union_rates as (
# MAGIC   select
# MAGIC     *
# MAGIC   from
# MAGIC     dup_clean_rates
# MAGIC   union all
# MAGIC   select
# MAGIC     *
# MAGIC   from
# MAGIC     non_dup_sku_rates
# MAGIC ),
# MAGIC distinct_rate as (
# MAGIC select distinct * from union_rates
# MAGIC ),
# MAGIC list_rate_add as (
# MAGIC   select d.*, l.unit_price as list_price, l.sku_entitled from distinct_rate d left join list_rates_exploded l on d.product_id = l.product_id and d.effective_date = l.list_date
# MAGIC )
# MAGIC select contract_id, product_id, unit_price as effective_price, overrides_entitled, type, promo_tag, override_type, effective_date, list_price, sku_entitled from list_rate_add
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Join list rates with contract information and overrides

# COMMAND ----------

spark.sql(f"""
create or replace table {schema}.contract_price_interface_exploded as
with list_base as (
select c.contract_id,
       l.product_id,
       unit_price as effective_price,
       null as overrides_entitled,
       'list_price' as type, -- need to recheck
       null as promo_tag,
       'List Price' as override_type,
       list_date as effective_date,
       unit_price as list_price,
       c.sku_entitled       
from contracts_product_map c 
  left join list_rates_exploded l
  on c.rate_card_id = l.rate_card_id 
     and c.contract_start_date <= list_date 
     and c.contract_end_date >= list_date 
     and c.product_list_item_id = l.product_id
),
join_base as (
select   coalesce(s.contract_id, l.contract_id) as contract_id,
         coalesce(s.product_id, l.product_id) as product_id,
         coalesce(s.overrides_entitled, l.overrides_entitled) as overrides_entitled,
         coalesce(s.promo_tag, l.promo_tag) as promo_tag,
         coalesce(s.effective_date, l.effective_date) as effective_date,
         coalesce(s.list_price, l.list_price) as list_price,
         coalesce(s.sku_entitled, l.sku_entitled) as sku_entitled,
         case when l.contract_id is null and s.contract_id is not null then s.effective_price
              when l.contract_id is not null and s.contract_id is null then l.effective_price
              when l.contract_id is not null and s.contract_id is not null then s.effective_price
              else null end as effective_price,
         case when l.contract_id is null and s.contract_id is not null then s.type
              when l.contract_id is not null and s.contract_id is null then l.type
              when l.contract_id is not null and s.contract_id is not null then s.type
              else null end as type,
         case when l.contract_id is null and s.contract_id is not null then s.override_type
              when l.contract_id is not null and s.contract_id is null then l.override_type
              when l.contract_id is not null and s.contract_id is not null then s.override_type
              else null end as override_type             

from contract_override_rates_exploded s
full outer join  list_base l
on l.contract_id = s.contract_id 
   and l.product_id = s.product_id 
   and l.effective_date = s.effective_date
)
select distinct * from join_base
   """)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Aggregate to get the base contract rate table

# COMMAND ----------

spark.sql(f"""
create or replace table {schema}.contract_price_interface_aggregated as
with seq_row as (
  select
    *,
    row_number() over (
      partition by contract_id,
      product_id,
      overrides_entitled,
      promo_tag,
      list_price,
      sku_entitled,
      effective_price,
      type,
      override_type
      ORDER BY
        effective_date
    ) seq_date_num
  from
    {schema}.contract_price_interface_exploded
),
aggregated_col as (
select
  contract_id,
  product_id,
  overrides_entitled,
  promo_tag,
  list_price,
  sku_entitled,
  effective_price,
  type,
  override_type,
  min(effective_date) effective_start_date,
  max(effective_date) effective_end_date
from
  seq_row
group by
  contract_id,
  product_id,
  overrides_entitled,
  promo_tag,
  list_price,
  sku_entitled,
  effective_price,
  type,
  override_type,
  dateadd(day, - seq_date_num, effective_date)
)
select * from aggregated_col
""")

# COMMAND ----------

#Check whether effective_start_date and effective end date are within contract start and end date
alert_sql = f"""
with base as (
select c.* except(c.contract_environment),r.* except(r.contract_id) from {schema}.contract_price_interface_aggregated r
left join contracts_customer_map c using(contract_id)
)
select * from base where timestamp(contract_end_date) < effective_end_date or timestamp(contract_start_date) > effective_start_date
"""
alert_msg = f"Effective start date is greater than Contract Start Date or Effective end date is less than Contract end Date in the overrides join temp view. Please check the workflow run."
alert_name = "EffectiveDatesCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'yellow')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add Business Subscription ID to the aggregated table

# COMMAND ----------

if source_environment == 'production':
  predicate = ''
else:
  predicate = "and sku_cloud is not null"
spark.sql(f"""
create or replace temp view tmp_contract_price_interface_stage as
  with base as (
  select c.* except(product_list_item_id), 
        b.business_subscription_id, 
        b.reseller_contracts,
        b.effective_contract_start_date, 
        r.* except(contract_id, effective_start_date, effective_end_date, sku_entitled),
        case when effective_contract_start_date >=  effective_start_date then effective_contract_start_date 
          else effective_start_date 
          end as effective_start_date,
        case when effective_contract_end_date <=  effective_end_date then effective_contract_end_date 
          else effective_end_date 
          end as effective_end_date
  from {schema}.contracts_bsid_final_map b
    left join {schema}.contract_price_interface_aggregated r  on r.contract_id = b.contract_id
    left join contracts_product_map c on b.contract_id = c.contract_id and r.product_id = c.product_list_item_id
  where effective_end_date >= effective_contract_start_date and effective_start_date <= effective_contract_end_date
  ),
  shield_sku_fix as (
    select * except (effective_start_date, effective_end_date, name),
          case when name = 'AWS Enhanced Security and Compliance' and effective_end_date >= '2024-02-28' then '2024-02-28'
              when name = 'GCP HIPAA Compliance' and effective_end_date >= '2024-02-28' then '2024-02-28'
            else effective_end_date
            end as effective_end_date,
          case when name = 'AWS Shield Usage' and effective_start_date <= '2024-02-28' then '2024-03-01'
              when name = 'GCP Shield Usage' and effective_start_date <= '2024-02-28' then '2024-03-01'
            else effective_start_date
            end as effective_start_date,
          case when name = 'AWS Enhanced Security and Compliance' then 'AWS Shield Usage'
              when name = 'GCP HIPAA Compliance' then 'GCP Shield Usage'
            else name
            end as name,
          first_value(promo_tag, true) ignore nulls over (partition by customer_id, contract_id, contract_start_date, contract_end_date, product_code, sku_cloud ) as promo_tag_max,
          last_value(override_type, true) over (partition by customer_id, contract_id, contract_start_date, contract_end_date, product_code, sku_cloud order by effective_start_date ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as lastUpdateReason_max,
          cast('{process_timestamp}' as timestamp) lastUpdateTimestamp,
          cast('{process_date}' as date) as processDate
    from base
  ),
  filter_invalid_dates as (
    select *,
    case when effective_start_date > effective_end_date  and name in ('AWS Shield Usage', 'GCP Shield Usage') then 'Invalid Date' else null end as invalid_date
    from shield_sku_fix
  )
  select distinct * except(invalid_date) from filter_invalid_dates where invalid_date is null {predicate}
""")

# COMMAND ----------

process_timestamp

# COMMAND ----------

#Check whether effective_order_item_start_date > effective_order_item_end_date
alert_sql = f"""
select * from tmp_contract_price_interface_stage where effective_start_date > effective_end_date
"""
alert_msg = f"WARNING: Effective start date is greater than effective end date in the Price Interface temp view. Please check the workflow run."
alert_name = "EffectiveDatesCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'red')

# COMMAND ----------

#Check whether there is any null price
alert_sql = f"""
select * from tmp_contract_price_interface_stage where effective_price is null
"""
alert_msg = f"WARNING: Null Price found in the Price Interface temp view. Please check the workflow run."
alert_name = "PriceNullCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'red')

# COMMAND ----------

if mode == "overwrite":
  spark.sql(f"DELETE FROM {schema}.{stage_table_name}")

# COMMAND ----------

df = spark.sql("select * from tmp_contract_price_interface_stage")
df.write \
      .format("delta") \
      .mode("overwrite") \
      .option("overwriteSchema", "true")\
      .option("replaceWhere", "lastUpdateTimestamp = cast('{0}' as timestamp)".format(process_timestamp)) \
      .partitionBy("processDate", "lastUpdateTimestamp") \
      .saveAsTable(f"{schema}.{stage_table_name}")

# COMMAND ----------

#Validate the data with metronome draft rated events
alert_sql = f"""
with platform_sub as (
  select * from global_temp.platformsubscription__c where processDate = (select max(processDate) from global_temp.platformsubscription__c)
),
rated_events as (
select distinct m.business_subscription_id, 
        upper(cloud) as cloud, 
        sku, 
        cast(unit_rate as decimal(38, 18)) / 100.0 as metronome_price, 
        to_date(`timestamp`) as usage_date
        from global_temp.draft_rated_events_silver m
    join platform_sub s on (m.business_subscription_id = s.Name)
    where s.Subscription_Channel__c = "DIRECT"
    and s.Type__c = "COMMIT"
    and environment_type = {environment_type}
    and cast(unit_rate as decimal(38, 18)) / 100.0 <> cast(0 as decimal(38, 18)) / 100.0
    and m.business_subscription_id not in ('BS-0000172702') -- These BS IDs are valid even though it shows up in the validation check.
),
rates as (
  select distinct business_subscription_id, contract_id, customer_id, effective_price, effective_start_date, effective_end_date, product_code, cpq_product_code, sku_cloud, contract_start_date, contract_end_date from {schema}.{stage_table_name} where lastUpdateTimestamp = cast('{process_timestamp}' as timestamp)
)
select * from rated_events e left join rates r on e.business_subscription_id = r.business_subscription_id and e.sku = r.cpq_product_code and e.cloud = r.sku_cloud and e.usage_date >= r.effective_start_date and e.usage_date <= r.effective_end_date
   where metronome_price is null or round(abs(effective_price - metronome_price), 6) > 0 or effective_price is null
   """
alert_msg = f"WARNING: Data mismatch between contract price stage and draft rated events for process date {process_date} and timestamp {process_timestamp}"
alert_name = "ContractPriceValidationStageCheck"
create_metric_alert(alert_sql, alert_msg, alert_name, 'info')

# COMMAND ----------

df = spark.sql(f"select distinct lastUpdateTimestamp from {schema}.{stage_table_name}")
display(df)

# COMMAND ----------

df = spark.sql(f"select * from {schema}.{stage_table_name}")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation checks

# COMMAND ----------

total_contracts = spark.sql(f"select distinct contract_id from contracts_customer_map").count()
total_contracts_bsid = spark.sql(f"select distinct contract_id from {schema}.contracts_bsid_final_map").count()
total_contracts_price = spark.sql(f"select distinct contract_id from {schema}.{stage_table_name}").count()
percent_bsid_total_contracts = str((total_contracts_price/total_contracts_bsid)*100)
total_contracts_active = spark.sql(f"select distinct contract_id from contracts_customer_map where contract_start_date <= current_date() and contract_end_Date >= current_date()").count()
total_contracts_bsid_active = spark.sql(f"select distinct contract_id from {schema}.contracts_bsid_final_map where contract_start_date <= current_date() and contract_end_Date >= current_date()").count()
total_contracts_price_active = spark.sql(f"select distinct contract_id from {schema}.{stage_table_name} where contract_start_date <= current_date() and contract_end_Date >= current_date()").count()
percent_bsid_total_contracts_active = str((total_contracts_price_active/total_contracts_bsid_active)*100)
print("Total Contracts in Metronome: " + str(total_contracts))
print("Total Contracts in Metronome which has bsid: " + str(total_contracts_bsid))
print("Total Contracts in Metronome present in rates table: " + str(total_contracts_price))
print("Percentage of Contracts whcih has BSID assigned to total contracts in the interface table:" + percent_bsid_total_contracts)
print("Total Contracts in Metronome active today: " + str(total_contracts_active))
print("Total Contracts in Metronome active today which has bsid: " + str(total_contracts_bsid_active))
print("Total Contracts in Metronome active today present in rates table: " + str(total_contracts_price_active))
print("Percentage of Customers whcih has BSID assigned to total customers in the interface table where we have active contracts:" + percent_bsid_total_contracts_active)
alert_dict['total_contracts'] = total_contracts
alert_dict['total_contracts_bsid'] = total_contracts_bsid
alert_dict['total_contracts_price'] = total_contracts_price
alert_dict['percent_bsid_total_contracts'] = percent_bsid_total_contracts
alert_dict['total_contracts_active'] = total_contracts_active
alert_dict['total_contracts_bsid_active'] = total_contracts_bsid_active
alert_dict['total_contracts_price_active'] = total_contracts_price_active
alert_dict['percent_bsid_total_contracts_active'] = percent_bsid_total_contracts_active

# COMMAND ----------

total_customer = spark.sql(f"select distinct customer_id from contracts_customer_map").count()
total_customer_bsid = spark.sql(f"select distinct customer_id from {schema}.contracts_bsid_final_map").count()
total_customer_price = spark.sql(f"select distinct customer_id from {schema}.{stage_table_name}").count()
percent_bsid_total_customer = str((total_customer_price/total_customer_bsid)*100)
total_customer_active = spark.sql(f"select distinct customer_id from contracts_customer_map where contract_start_date <= current_date() and contract_end_Date >= current_date()").count()
total_customer_bsid_active = spark.sql(f"select distinct customer_id from {schema}.contracts_bsid_final_map where contract_start_date <= current_date() and contract_end_Date >= current_date()").count()
total_customer_price_active = spark.sql(f"select distinct customer_id from {schema}.{stage_table_name} where contract_start_date <= current_date() and contract_end_Date >= current_date()").count()
percent_bsid_total_customer_active = str((total_customer_price_active/total_customer_bsid_active)*100)
print("Total Customers in Metronome: " + str(total_customer))
print("Total Customers in Metronome which has bsid: " + str(total_customer_bsid))
print("Total Customers in Metronome present in rates table: " + str(total_customer_price))
print("Percentage of Customers whcih has BSID assigned to total customers in the interface table:" + percent_bsid_total_customer)
print("Total Customers in Metronome active today: " + str(total_customer_active))
print("Total Customers in Metronome active today which has bsid: " + str(total_customer_bsid_active))
print("Total Customers in Metronome active today present in rates table: " + str(total_customer_price_active))
print("Percentage of Customers whcih has BSID assigned to total customers in the interface table where we have active contracts:" + percent_bsid_total_customer_active)
alert_dict['total_customer'] = total_customer
alert_dict['total_customer_bsid'] = total_customer_bsid
alert_dict['total_customer_price'] = total_customer_price
alert_dict['percent_bsid_total_customer'] = percent_bsid_total_customer
alert_dict['total_customer_active'] = total_customer_active
alert_dict['total_customer_bsid_active'] = total_customer_bsid_active
alert_dict['total_customer_price_active'] = total_customer_price_active
alert_dict['percent_bsid_total_customer_active'] = percent_bsid_total_customer_active

# COMMAND ----------

total_sku = spark.sql(f"select distinct product_code, sku_cloud from {schema}.cpi_sku_final where sku_cloud <> 'AZURE'").count()
total_sku_cpi = spark.sql(f"select distinct product_code, sku_cloud from {schema}.{stage_table_name}").count()
percent_sku_cpi = str((total_sku_cpi/total_sku)*100)
print("Total Uage SKU in Metronome: " + str(total_sku))
print("Total SKU in Contract Price Interface: " + str(total_sku_cpi))
print("Percentage SKUs in Contract Price Interface:" + percent_sku_cpi)
alert_dict['total_sku'] = total_sku
alert_dict['total_sku_cpi'] = total_sku_cpi
alert_dict['percent_sku_cpi'] = percent_sku_cpi

# COMMAND ----------

alert_list = [alert_dict,]
alert_list

# COMMAND ----------

alert_stage_schema = StructType([StructField('BSIDDuplicateRecords', ArrayType(StringType(), True), True), 
            StructField('BSIDDuplicateRecordsCheck', LongType(), True), 
            StructField('ContractDuplicateRecordsCheck', LongType(), True), 
            StructField('ContractPriceValidationStageCheck', LongType(), True), 
            StructField('EffectiveContractStartDateCheck', LongType(), True), 
            StructField('EffectiveContractrItemDateCheck', LongType(), True), 
            StructField('EffectiveDatesCheck', LongType(), True), 
            StructField('ListRatesDuplicateRecordsCheck', LongType(), True), 
            StructField('PriceNullCheck', LongType(), True), 
            StructField('SkuCloudNullCheck', LongType(), True), 
            StructField('SkuDuplicateRecordsCheck', LongType(), True), 
            StructField('SkuRegionCheck', LongType(), True), 
            StructField('environment', StringType(), True), 
            StructField('mode', StringType(), True), 
            StructField('percent_bsid_total_contracts', StringType(), True), 
            StructField('percent_bsid_total_contracts_active', StringType(), True), 
            StructField('percent_bsid_total_customer', StringType(), True), 
            StructField('percent_bsid_total_customer_active', StringType(), True), 
            StructField('percent_sku_cpi', StringType(), True), 
            StructField('process_date', StringType(), True), 
            StructField('process_timestamp', StringType(), True), 
            StructField('total_contracts', LongType(), True), 
            StructField('total_contracts_active', LongType(), True), 
            StructField('total_contracts_bsid', LongType(), True), 
            StructField('total_contracts_bsid_active', LongType(), True), 
            StructField('total_contracts_price', LongType(), True), 
            StructField('total_contracts_price_active', LongType(), True), 
            StructField('total_customer', LongType(), True), 
            StructField('total_customer_active', LongType(), True), 
            StructField('total_customer_bsid', LongType(), True), 
            StructField('total_customer_bsid_active', LongType(), True), 
            StructField('total_customer_price', LongType(), True), 
            StructField('total_customer_price_active', LongType(), True), 
            StructField('total_sku', LongType(), True), 
            StructField('total_sku_cpi', LongType(), True)
            ])

# COMMAND ----------

alert_df = spark.createDataFrame(alert_list, alert_stage_schema)

# COMMAND ----------

display(alert_df)

# COMMAND ----------

alert_df.write \
      .format("delta") \
      .mode("overwrite") \
      .option("mergeSchema", "true")\
      .saveAsTable(f"{schema}.contract_price_interface_alerts_stage")
