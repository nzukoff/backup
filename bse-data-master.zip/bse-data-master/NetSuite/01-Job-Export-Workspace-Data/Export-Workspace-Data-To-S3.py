# Databricks notebook source
# MAGIC %run "../Suite-Analytics-Defs"

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

from pprint import pprint

logger = configure_logging(dbutils.widgets.get("log_level"))
config = get_configuration(dbutils.widgets.get("configuration"))
pprint(config)

# COMMAND ----------

RECREATE = dbutils.widgets.get("recreate") == "yes"
logger.info(f"{RECREATE=}")

# COMMAND ----------

sql = make_sql(
    spark=spark,
    logger=logger,
    log_level=logging.INFO
)

# COMMAND ----------

access_key = dbutils.secrets.get(config.secret_scope, config.usage_s3_access_key_secret)
secret_key = dbutils.secrets.get(config.secret_scope, config.usage_s3_secret_key_secret)
S3_WORKSPACE_EXTRACTION_FOLDER = (
    f"s3a://{access_key}:{secret_key}@{config.usage_s3_bucket}/{config.workspace_extraction_folder}"
)
logger.debug(f"{S3_WORKSPACE_EXTRACTION_FOLDER=}")

# COMMAND ----------

from pyspark.sql import functions as F
from it_data_lib.csvhelpers import export_to_csv


sql(f"USE CATALOG {config.uc_catalog}")
full_table_name = f"{config.gold_database}.{GOLD_WORKSPACE_LIST_TABLE}"
df_table = spark.table(full_table_name)

max_process_date = df_table.select(F.max(F.col('processDate')).alias('processDate')).first().processDate

logger.debug(f"Exporting workspace data from {config.uc_catalog}.{full_table_name} "
             f"for process date {max_process_date}")
df = (
  df_table
    .select('workspaceName',
            'subscriptionId',
            'subscriptionName',
            'startDate',
            'endDate',
            'workspaceId')
    .where(F.col('IncludeInUpload') == True)
    .where(F.col('processDate') == max_process_date)
    .drop('processDate', 'IncludeInUpload')
    .orderBy(F.col('workspaceName'))
)
exported_file = export_to_csv(
  df=df,
  folder_path=S3_WORKSPACE_EXTRACTION_FOLDER, 
  file_prefix='workspaceList',
  dbutils=dbutils
)
logger.info(f'Exported usage data for {max_process_date} to {exported_file}')
