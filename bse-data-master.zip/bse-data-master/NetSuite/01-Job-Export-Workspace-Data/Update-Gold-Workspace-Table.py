# Databricks notebook source
# MAGIC %run "../Suite-Analytics-Defs"

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

from pprint import pprint

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get('log_level'))

# COMMAND ----------

config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)

# COMMAND ----------

RECREATE = dbutils.widgets.get("recreate") == "yes"
logger.debug(f"{RECREATE=}")

# COMMAND ----------

sql = make_sql(
    logger=logger,
    spark=spark,
    log_level=logging.INFO
)

# COMMAND ----------

import os
from datetime import date, datetime

table_name = 'workspaces'
full_table_name = f'{config.gold_database}.{table_name}'
logger.info(f"Preparing to update {config.uc_catalog}.{full_table_name}")

# COMMAND ----------

sql(f'USE CATALOG {config.uc_catalog}')
sql(f'USE {config.silver_database}')

# COMMAND ----------

if RECREATE:
  sql(f'DROP TABLE IF EXISTS {full_table_name}')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view AWSNewWorkspaces as
# MAGIC select * from (
# MAGIC   select distinct 
# MAGIC     agg.workspaceId as workspaceName,
# MAGIC     cast(w.workspace_id as int) as workspaceId,
# MAGIC     cast(o.NS_InternalID__c as int) as subscriptionId,
# MAGIC     s.subscription_name as subscriptionName,
# MAGIC     to_date(s.start_date, "yyyy-MM-dd") as startDate,
# MAGIC     to_date(s.end_date, "yyyy-MM-dd") as endDate,
# MAGIC     CASE 
# MAGIC       WHEN p.is_paygo is null then FALSE
# MAGIC       ELSE p.is_paygo 
# MAGIC     END as IsPayGo,
# MAGIC     CASE
# MAGIC       WHEN (p.is_paygo is null or p.is_paygo = false) and ((select count(*) from netsuite_subscription_items 
# MAGIC                                   where (processDate = (select max(processDate) from netsuite_subscription_items))
# MAGIC                                     and (subscription_id = s.subscription_id) 
# MAGIC                                     and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE --FALSE -- added 24 July 2022--TRUE --added Mar 15, 2022 to include all commit 
# MAGIC       WHEN p.is_paygo THEN TRUE
# MAGIC       ELSE FALSE
# MAGIC     END as IncludeInUpload,
# MAGIC     CASE 
# MAGIC       WHEN (p.is_paygo is null or p.is_paygo = false) AND ((select count(*) from netsuite_subscription_items 
# MAGIC                                   where (processDate = (select max(processDate) from netsuite_subscription_items))
# MAGIC                                     and (subscription_id = s.subscription_id) 
# MAGIC                                     and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE --added Mar 15, 2022 to include all commit 
# MAGIC       WHEN p.is_paygo THEN FALSE
# MAGIC       ELSE FALSE
# MAGIC     END as HasCommitLine,
# MAGIC     'AWS_BizSub' as MappingSource
# MAGIC     FROM it_bui_silver.bui_metering_agg agg
# MAGIC     left join netsuite_workspaces w on (w.name = agg.workspaceId 
# MAGIC       and w.processDate = (select max(processDate) from netsuite_workspaces))
# MAGIC     left join it_bui_silver.bui_workspaces_latest wl on wl.workspaceId = agg.workspaceId
# MAGIC     left join it_bui_silver.bui_subscriptions bui_sub on bui_sub.subscriptionId = wl.subscriptionId 
# MAGIC       and wl.subscriptionId is not null
# MAGIC       --changes done 25Apr2022 related to ticket https://databricks.atlassian.net/browse/BSEINT-250
# MAGIC       and bui_sub.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.bui_subscriptions ) 
# MAGIC     -- Have to use "main" catalog for SFDC tables, regardless of what catalog we're using
# MAGIC     -- for NetSuite silver tables, because "integration.sfdc_bronze" is locked down.
# MAGIC     left join main.sfdc_bronze.platformsubscription__c bs on bs.Platform_Account_ID__c = wl.accountId
# MAGIC       and bs.processDate = (select max(processDate) from main.sfdc_bronze.platformsubscription__c)
# MAGIC     left join main.sfdc_bronze.order bsOrder on bsOrder.id = bs.Order__c 
# MAGIC       and bsOrder.processDate = (select max(processDate) from main.sfdc_bronze.order)
# MAGIC     left join main.sfdc_bronze.order o on o.id = CASE 
# MAGIC       WHEN bsOrder.CPQ_Order_Type__c = 'Co-term' THEN  bsOrder.CPQ_Original_Order__c
# MAGIC       ELSE bsOrder.Id
# MAGIC       END 
# MAGIC       and o.processDate = (select max(processDate) from main.sfdc_bronze.order)
# MAGIC     left join netsuite_subscriptions s on s.subscription_id = o.NS_InternalID__c 
# MAGIC       and s.processDate = (select max(processDate) from netsuite_subscriptions)
# MAGIC     left join netsuite_plans p on (p.plan_id = s.plan_id and p.processDate = s.processDate)
# MAGIC   where date >=  date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 ) 
# MAGIC       AND  date <= last_day(current_date()-1)
# MAGIC       AND w.name is NULL
# MAGIC       and o.NS_InternalID__c is not null and o.NS_TargetType__c = 'Subscription') a 
# MAGIC       where a.HasCommitLine = true and a.endDate >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 
# MAGIC ) 

# COMMAND ----------

# MAGIC %sql
# MAGIC -- PayG New workspaces
# MAGIC create or replace temporary view AWSPayGoNewWorkspaces as
# MAGIC select * from (
# MAGIC   select distinct 
# MAGIC     agg.workspaceId as workspaceName,
# MAGIC     cast(w.workspace_id as int) as workspaceId,
# MAGIC     cast(s.subscription_id as int) as subscriptionId,
# MAGIC     s.subscription_name as subscriptionName,
# MAGIC     to_date(s.start_date, "yyyy-MM-dd") as startDate,
# MAGIC     to_date(s.end_date, "yyyy-MM-dd") as endDate,
# MAGIC     CASE 
# MAGIC       WHEN p.is_paygo is null then FALSE
# MAGIC       ELSE p.is_paygo 
# MAGIC     END as IsPayGo,
# MAGIC     CASE
# MAGIC       WHEN (p.is_paygo is null or p.is_paygo = false) and ((select count(*) from netsuite_subscription_items 
# MAGIC                                   where (processDate = (select max(processDate) from netsuite_subscription_items))
# MAGIC                                     and (subscription_id = s.subscription_id) 
# MAGIC                                     and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN FALSE -- added 24 July 2022--TRUE --added Mar 15, 2022 to include all commit 
# MAGIC       WHEN p.is_paygo THEN TRUE
# MAGIC       ELSE FALSE
# MAGIC     END as IncludeInUpload,
# MAGIC     CASE 
# MAGIC       WHEN (p.is_paygo is null or p.is_paygo = false) AND ((select count(*) from netsuite_subscription_items 
# MAGIC                                   where (processDate = (select max(processDate) from netsuite_subscription_items))
# MAGIC                                     and (subscription_id = s.subscription_id) 
# MAGIC                                     and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE --added Mar 15, 2022 to include all commit 
# MAGIC       WHEN p.is_paygo THEN FALSE
# MAGIC       ELSE FALSE
# MAGIC     END as HasCommitLine,
# MAGIC     'PlatformSubscription' MappingSource
# MAGIC     FROM it_bui_silver.bui_metering_agg agg
# MAGIC     left join netsuite_workspaces w on (w.name = agg.workspaceId
# MAGIC       and w.processDate = (select max(processDate) from netsuite_workspaces))
# MAGIC     left join it_bui_silver.bui_workspaces_latest wl on wl.workspaceId = agg.workspaceId
# MAGIC     left join it_bui_silver.bui_subscriptions bui_sub on bui_sub.subscriptionId = wl.subscriptionId
# MAGIC       and wl.subscriptionId is not null 
# MAGIC       and bui_sub.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.bui_subscriptions ) 
# MAGIC     left join netsuite_subscriptions s 
# MAGIC       on s.subscription_id = CASE 
# MAGIC                                WHEN bui_sub.externalSubscriptionId is not null THEN bui_sub.externalSubscriptionId
# MAGIC                                ELSE agg.netsuite_subscription_id 
# MAGIC                              END
# MAGIC       and s.processDate = (select max(processDate) from netsuite_subscriptions)
# MAGIC     left join netsuite_plans p on (p.plan_id = s.plan_id and p.processDate = s.processDate)
# MAGIC     -- left join it_usage_gold.ManualWorkspaceList ml on (ml.workspaceId = agg.workspaceId 
# MAGIC     -- and ml.processDate = (SELECT max(processDate) AS lastProcessDate from it_usage_gold.ManualWorkspaceList))
# MAGIC     WHERE date >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 )
# MAGIC       AND date <= last_day(current_date()-1)
# MAGIC       AND date between s.start_date and s.end_date -- Usage date is between subscription active dates
# MAGIC       AND s.subscription_id is not null -- subscription matches with metering table
# MAGIC       -- and ml.workspaceId is null -- do not include workspace in ManualWorkspaceList table
# MAGIC       and w.name is NULL -- workspace does not exist in workspace table
# MAGIC   ) a 
# MAGIC   where  a.IncludeInUpload = true and a.endDate >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1
# MAGIC  )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view GCPNewWorkspaces as
# MAGIC select workspaceName,
# MAGIC        workspaceId,
# MAGIC        subscriptionId,
# MAGIC        subscriptionName,
# MAGIC        startDate,
# MAGIC        endDate,
# MAGIC        IsPayGo,
# MAGIC        IncludeInUpload,
# MAGIC        HasCommitLine,
# MAGIC        MappingSource
# MAGIC   from (
# MAGIC     select distinct 
# MAGIC       agg.workspaceId as workspaceName,
# MAGIC       cast(w.workspace_id as int) as workspaceId,
# MAGIC       cast(o.NS_InternalID__c as int) as subscriptionId,
# MAGIC       s.subscription_name as subscriptionName,
# MAGIC       to_date(s.start_date, "yyyy-MM-dd") as startDate,
# MAGIC       to_date(s.end_date, "yyyy-MM-dd") as endDate,
# MAGIC       CASE 
# MAGIC         WHEN p.is_paygo is null then FALSE
# MAGIC         ELSE p.is_paygo 
# MAGIC       END as IsPayGo,
# MAGIC       c.customer_type as customerType,
# MAGIC       CASE
# MAGIC         WHEN 
# MAGIC         (c.customer_type not in ('PAYG')) and 
# MAGIC         ((select count(*) from it_finance_silver.netsuite_subscription_items 
# MAGIC                                     where (processDate = (select max(processDate) from it_finance_silver.netsuite_subscription_items))
# MAGIC                                       and (subscription_id = s.subscription_id) 
# MAGIC                                       and (ITEM_ID in (2294,2616,1467))) > 0) THEN TRUE --FALSE -- added 24 July 2022--TRUE --added Mar 15, 2022 to include all commit 
# MAGIC         WHEN c.customer_type in ('PAYG') THEN FALSE
# MAGIC         ELSE FALSE
# MAGIC       END as IncludeInUpload,
# MAGIC       CASE
# MAGIC         WHEN 
# MAGIC         (c.customer_type not in ('PAYG')) and 
# MAGIC         ((select count(*) from it_finance_silver.netsuite_subscription_items 
# MAGIC                                     where (processDate = (select max(processDate) from it_finance_silver.netsuite_subscription_items))
# MAGIC                                       and (subscription_id = s.subscription_id) 
# MAGIC                                       and (ITEM_ID in (2294,2616,1467))) > 0) THEN TRUE 
# MAGIC         WHEN c.customer_type in ('PAYG') THEN FALSE
# MAGIC         ELSE FALSE
# MAGIC       END as HasCommitLine,
# MAGIC       'GCP_BizSub' MappingSource
# MAGIC       FROM it_bui_silver.gcp_metering_agg agg
# MAGIC       left join it_finance_silver.netsuite_workspaces w
# MAGIC         on (w.name = agg.workspaceId
# MAGIC         and w.processDate = (select max(processDate) from it_finance_silver.netsuite_workspaces))
# MAGIC       left join it_bui_silver.gcp_workspaces_latest wl on wl.workspaceId = agg.workspaceId
# MAGIC       left join it_bui_silver.gcp_subscriptions bui_sub
# MAGIC         on bui_sub.subscriptionId = wl.subscriptionId
# MAGIC         and wl.subscriptionId is not null
# MAGIC         and bui_sub.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.gcp_subscriptions )
# MAGIC       left join main.sfdc_bronze.platformsubscription__c bs
# MAGIC         on bs.Platform_Account_ID__c = wl.accountId
# MAGIC         and bs.processDate = (select max(processDate) from main.sfdc_bronze.platformsubscription__c)
# MAGIC       left join main.sfdc_bronze.order o
# MAGIC         on o.id = bs.Order__c
# MAGIC         and o.processDate = (select max(processDate) from main.sfdc_bronze.order)
# MAGIC       left join it_finance_silver.netsuite_subscriptions s
# MAGIC         on s.subscription_id = o.NS_InternalID__c
# MAGIC         and s.processDate = (select max(processDate) from it_finance_silver.netsuite_subscriptions)
# MAGIC       left join it_finance_silver.netsuite_plans p on (p.plan_id = s.plan_id and p.processDate = s.processDate)
# MAGIC       left join it_finance_silver.netsuite_customers c
# MAGIC         on c.customer_id = s.customer_id
# MAGIC         and c.processDate = (select max(processDate) from it_finance_silver.netsuite_customers)
# MAGIC   where date >=  date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 ) 
# MAGIC       AND  date <= last_day(current_date()-1)
# MAGIC       AND w.name is NULL
# MAGIC       and o.NS_InternalID__c is not null and o.NS_TargetType__c = 'Subscription'
# MAGIC       ) a
# MAGIC where a.customerType not in ('PAYG') and a.endDate >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 ) 

# COMMAND ----------

# MAGIC %md
# MAGIC `CancelledWorkspaces` and `MatchedByProductAccountId` are not currently used. Retained for history and reference.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- CREATE OR REPLACE TEMPORARY VIEW CancelledWorkspaces AS
# MAGIC -- WITH LsNsList AS (
# MAGIC --   SELECT workspaceId,
# MAGIC --          max(DISTINCT billing.netsuiteSubscription.subscriptionId) AS lastNetsuiteId
# MAGIC --     -- Note: prod.workspaces_history is deprecated in favor of
# MAGIC --     -- main.data_df_workspaces.workspaces_history_legacy
# MAGIC --     FROM prod.workspaces_history -- has no processDate
# MAGIC --    WHERE billing.netsuiteSubscription.subscriptionId IS NOT NULL
# MAGIC --   GROUP BY workspaceId
# MAGIC -- )
# MAGIC -- select distinct 
# MAGIC --   agg.workspaceId as workspaceName,
# MAGIC --   cast(w.workspace_id as int) as workspaceId,
# MAGIC --   cast(LsNsList.lastNetsuiteId as int) as subscriptionId,
# MAGIC --   s.subscription_name as subscriptionName,
# MAGIC --   to_date(s.start_Date, "yyyy-MM-dd") as startDate,
# MAGIC --   to_date(s.end_Date, "yyyy-MM-dd") as endDate,
# MAGIC --   CASE 
# MAGIC --     WHEN p.is_paygo is null then FALSE
# MAGIC --     ELSE p.is_paygo 
# MAGIC --   END as IsPayGo,
# MAGIC --   CASE
# MAGIC --     WHEN (NOT p.is_paygo) and ((select count(*) from subscription_items 
# MAGIC --                                  where (processDate = (select max(processDate) from subscription_items)) 
# MAGIC --                                    and (subscription_id = s.subscription_id) 
# MAGIC --                                    and (ITEM_ID in (282,2292,2617,2294,2616)) ) > 0) THEN TRUE --added Mar 15, 2022 to include all commit 
# MAGIC --     WHEN p.is_paygo THEN TRUE
# MAGIC --     ELSE FALSE
# MAGIC --   END as IncludeInUpload,
# MAGIC --   CASE 
# MAGIC --     WHEN (NOT p.is_paygo) AND ((select count (*) from subscription_items 
# MAGIC --                                  where (processDate = (select max(processDate) from subscription_items))
# MAGIC --                                    and (subscription_id = s.subscription_id)
# MAGIC --                                    and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE --added Mar 15, 2022 to include all commit 
# MAGIC --     WHEN p.is_paygo THEN FALSE
# MAGIC --     ELSE FALSE
# MAGIC --   END as HasCommitLine,
# MAGIC --   'CancelledWorkspaces' MappingSource
# MAGIC -- from bdw.bui_metering_agg agg
# MAGIC -- left join workspaces w on (w.name = agg.workspaceId and
# MAGIC --                            w.processDate = (select max(processDate) from workspaces))
# MAGIC -- left join prod.workspaces pw on pw.workspaceId = agg.workspaceId  -- has no processDate
# MAGIC -- left join LsNsList on LsNsList.workspaceId = agg.workspaceId
# MAGIC -- left join subscriptions s on (s.subscription_id = lsNsList.lastNetsuiteId and
# MAGIC --                               s.processDate = (select max(processDate) from subscriptions))
# MAGIC -- left join plans p on (p.plan_id = s.plan_id and p.processDate = s.processDate)
# MAGIC -- left join usage_gold.ManualWorkspaceList ml on (ml.workspaceId = agg.workspaceId and ml.processDate = (SELECT max(processDate) AS lastProcessDate from usage_gold.ManualWorkspaceList))
# MAGIC -- where date >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 )
# MAGIC --   and date <= last_day(current_date()-1) --for specific month
# MAGIC --   and agg.netsuite_subscription_id is  null -- subscription is empty due to cancellation
# MAGIC --   and pw.workspaceStatus = 'CANCELLED' --get list of workspaces only if it is in cancelled state
# MAGIC --   and ml.workspaceId is NULL --do not include workspace listed in ManualWorkspaceList
# MAGIC --   and w.name is NULL -- workspace does not exist in Netsuite workspace table
# MAGIC --   and lsNsList.lastNetsuiteId is not NULL -- get the last updated NS id if it exists
# MAGIC --   and s.start_date < s.end_date
# MAGIC --   and s.end_date >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 )

# COMMAND ----------

# MAGIC %sql
# MAGIC -- --Populate Ns ID by ProductAccountId match
# MAGIC -- CREATE OR REPLACE TEMPORARY VIEW MatchedByProductAccountId AS
# MAGIC -- select 
# MAGIC --   workspaceId as workspaceName,
# MAGIC --   cast(workspaceId as int) as workspaceId,
# MAGIC --   cast(NsSubId as int) as subscriptionId,
# MAGIC --   s.subscription_name as subscriptionName,
# MAGIC --   to_date(s.start_Date, "yyyy-MM-dd") as startDate,
# MAGIC --   to_date(s.end_Date, "yyyy-MM-dd") as endDate,
# MAGIC --   CASE 
# MAGIC --         WHEN (p.is_paygo = 'false' or p.is_paygo is NULL) THEN FALSE
# MAGIC --         WHEN p.is_paygo = 'true' THEN TRUE
# MAGIC --         ELSE FALSE
# MAGIC --       END AS IsPayGo,
# MAGIC --       CASE
# MAGIC --         WHEN (p.is_paygo = 'false' or p.is_paygo is NULL) and ((select count(*) from subscription_items 
# MAGIC --                                                                  where (subscription_id = NsSubId)
# MAGIC --                                                                    and (processDate = (select max(processDate) from subscription_items))
# MAGIC --                                                                    and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE --added Mar 15, 2022 to include all commit 
# MAGIC --         WHEN p.is_paygo = 'true' THEN TRUE
# MAGIC --         ELSE FALSE
# MAGIC --       END as IncludeInUpload,
# MAGIC --       CASE 
# MAGIC --         WHEN (p.is_paygo = 'false' or p.is_paygo is NULL) AND (select count (*) from subscription_items 
# MAGIC --                                                                 where (subscription_id = NsSubId)
# MAGIC --                                                                   and (processDate = (select max(processDate) from subscription_items))
# MAGIC --                                                                   and (ITEM_ID in (282,2292,2617,2294,2616))) > 0 THEN TRUE --added Mar 15, 2022 to include all commit 
# MAGIC --         WHEN p.is_paygo = 'true' THEN FALSE
# MAGIC --         ELSE FALSE
# MAGIC --       END as HasCommitLine,
# MAGIC --       'Match_ProductAccountId' MappingSource
# MAGIC
# MAGIC -- from (
# MAGIC --   select distinct agg.workspaceId,agg.netsuite_subscription_id, wl.accountId, wl.subscriptionId,agg.isPaying 
# MAGIC --   from it_bui_silver.bui_metering_agg agg 
# MAGIC --   left join it_bui_silver.bui_workspaces_latest wl on wl.workspaceId = agg.workspaceId
# MAGIC --   left join it_usage_gold_prod_staging.ManualWorkspaceList ml on (ml.workspaceId = agg.workspaceId and ml.processDate = (SELECT max(processDate) AS lastProcessDate from usage_gold_prod_staging.ManualWorkspaceList))
# MAGIC --   left join workspaces w on (w.name = agg.workspaceId and w.processDate = (select max(processDate) AS lastProcessDate from workspaces))
# MAGIC --   where date >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 )
# MAGIC --         and date <= last_day(current_date()-1) 
# MAGIC --         and ml.workspaceId is null
# MAGIC --         and w.name is null
# MAGIC --         and agg.netsuite_subscription_id is null
# MAGIC --         order by accountId) as emptySub
# MAGIC --         left join 
# MAGIC --               --get netsuite id for ProductAccoutnID
# MAGIC --   (select distinct agg.netsuite_subscription_id as NsSubId, wl.accountId, wl.subscriptionId,agg.isPaying from bdw.bui_metering_agg agg 
# MAGIC --   left join bdw.bui_workspaces_latest wl on wl.workspaceId = agg.workspaceId
# MAGIC --   left join usage_gold.ManualWorkspaceList ml on (ml.workspaceId = agg.workspaceId and ml.processDate = (SELECT max(processDate) AS lastProcessDate from usage_gold.ManualWorkspaceList))
# MAGIC --   left join workspaces w on (w.name = agg.workspaceId and w.processDate = (select max(processDate) AS lastProcessDate from workspaces))
# MAGIC --   where date >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 )
# MAGIC --         and date <= last_day(current_date()-1) 
# MAGIC --         and ml.workspaceId is null
# MAGIC --         and w.name is null
# MAGIC --         and agg.netsuite_subscription_id is not null
# MAGIC --         order by accountId) as Sub on emptySub.accountId = Sub.accountId
# MAGIC --         left join subscriptions s on (s.subscription_id = NsSubId and s.processDate = (select max(processDate) from subscriptions ))
# MAGIC --         left join plans p on (p.plan_id = s.plan_id and p.processDate = (select max(processDate) from plans))
# MAGIC --         left join workspaces w on (w.name = workspaceId and w.processDate = (select max(processDate) from workspaces))
# MAGIC --   where NsSubId is not null and s.end_Date > date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 
# MAGIC -- )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view BSUpdatedWorkspaces as
# MAGIC WITH Wsub as (
# MAGIC   select wsub.workspace_id,
# MAGIC          wsub.subscription_id, 
# MAGIC          wsub.workspaceName,
# MAGIC          case 
# MAGIC            when subscription_end_date > current_date() then True
# MAGIC            else False
# MAGIC         end as sub_status 
# MAGIC   from (
# MAGIC     select ws.workspace_id, ws.subscription_id, w.name workspaceName, subscription_end_date ,
# MAGIC     RANK() OVER (PARTITION BY ws.workspace_id ORDER BY subscription_end_date DESC) AS sub_rank 
# MAGIC     from it_finance_silver.netsuite_workspace_subscriptions ws
# MAGIC     left join it_finance_silver.netsuite_workspaces w
# MAGIC       on w.workspace_id = ws.workspace_id
# MAGIC       and w.processDate = (select max(processDate) from it_finance_silver.netsuite_workspaces)
# MAGIC     where ws.processDate = (select max(processDate) from it_finance_silver.netsuite_workspace_subscriptions) 
# MAGIC     and ws.subscription_start_date <= current_date()
# MAGIC   ) wsub
# MAGIC   where sub_rank = 1
# MAGIC   and wsub.workspace_id is not null
# MAGIC ),
# MAGIC workspaceUpdateList as (
# MAGIC   select distinct 
# MAGIC     agg.workspaceId as workspaceName,
# MAGIC     cast(w.workspace_id as int) as workspaceId,
# MAGIC     cast(o.NS_InternalID__c as int) as subscriptionId,
# MAGIC     s.subscription_name as subscriptionName,
# MAGIC     to_date(s.start_date, "yyyy-MM-dd") as startDate,
# MAGIC     to_date(s.end_date, "yyyy-MM-dd") as endDate,
# MAGIC     CASE 
# MAGIC       WHEN p.is_paygo is null then FALSE
# MAGIC       ELSE p.is_paygo 
# MAGIC     END as IsPayGo,
# MAGIC     CASE
# MAGIC       WHEN (p.is_paygo is null or p.is_paygo = false) and ((select count(*) from it_finance_silver.netsuite_subscription_items 
# MAGIC                                   where (processDate = (select max(processDate) from it_finance_silver.netsuite_subscription_items))
# MAGIC                                     and (subscription_id = s.subscription_id) 
# MAGIC                                     and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE 
# MAGIC       WHEN p.is_paygo THEN TRUE
# MAGIC       ELSE FALSE
# MAGIC     END as IncludeInUpload,
# MAGIC     CASE 
# MAGIC       WHEN (p.is_paygo is null or p.is_paygo = false) AND ((select count(*) from it_finance_silver.netsuite_subscription_items 
# MAGIC                                   where (processDate = (select max(processDate) from it_finance_silver.netsuite_subscription_items))
# MAGIC                                     and (subscription_id = s.subscription_id) 
# MAGIC                                     and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE  
# MAGIC       WHEN p.is_paygo THEN FALSE
# MAGIC       ELSE FALSE
# MAGIC     END as HasCommitLine,
# MAGIC     'AWS_UpdateBizSub' as MappingSource
# MAGIC     FROM it_bui_silver.bui_metering_agg agg
# MAGIC     left join it_finance_silver.netsuite_workspaces w
# MAGIC       on (w.name = agg.workspaceId)
# MAGIC       and (w.processDate = (select max(processDate) from it_finance_silver.netsuite_workspaces))
# MAGIC     left join it_bui_silver.bui_workspaces_latest wl on wl.workspaceId = agg.workspaceId
# MAGIC     left join it_bui_silver.bui_subscriptions bui_sub 
# MAGIC       on bui_sub.subscriptionId = wl.subscriptionId 
# MAGIC       and wl.subscriptionId is not null 
# MAGIC       and bui_sub.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.bui_subscriptions ) 
# MAGIC     left join main.sfdc_bronze.platformsubscription__c bs 
# MAGIC       on bs.Platform_Account_ID__c = wl.accountId 
# MAGIC       and bs.processDate = (select max(processDate) from main.sfdc_bronze.platformsubscription__c)
# MAGIC     left join main.sfdc_bronze.order o 
# MAGIC       on o.id = bs.Order__c 
# MAGIC       and o.processDate = (select max(processDate) from main.sfdc_bronze.order)
# MAGIC     left join main.sfdc_bronze.account a
# MAGIC       on a.id = o.AccountId
# MAGIC       and a.processDate = (select max(processDate) from main.sfdc_bronze.account)
# MAGIC     left join it_finance_silver.netsuite_subscriptions s
# MAGIC       on s.subscription_id = o.NS_InternalID__c
# MAGIC       and s.processDate = (select max(processDate) from it_finance_silver.netsuite_subscriptions)
# MAGIC     left join it_finance_silver.netsuite_plans p on (p.plan_id = s.plan_id and p.processDate = s.processDate)
# MAGIC   where date >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 ) 
# MAGIC       AND  date <= last_day(current_date()-1)
# MAGIC       AND w.name is not NULL
# MAGIC       and o.NS_InternalID__c is not null and o.NS_TargetType__c = 'Subscription' and (w.workspace_external_id is not null and w.workspace_external_id = agg.workspaceId)
# MAGIC ) 
# MAGIC select a.* from workspaceUpdateList a
# MAGIC left join Wsub on Wsub.workspace_id = a.workspaceId
# MAGIC where a.HasCommitLine = true and a.workspaceId is not null
# MAGIC and Wsub.subscription_id != a.subscriptionId
# MAGIC and a.endDate >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 ) 
# MAGIC and Wsub.sub_status = false

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view DirectPayGo4 as
# MAGIC with PayGSet as (
# MAGIC   select name,
# MAGIC         bs.Platform_Account_ID__c,
# MAGIC         bs.Subscription_Id__c,
# MAGIC         bs.Type__c,
# MAGIC         bs.Subscription_Channel__c,
# MAGIC         bs.NS_Customer_Internal__c,
# MAGIC         bs.NS_Subscription_Internal__c,
# MAGIC         bs.Country_Code__c
# MAGIC   from main.sfdc_bronze.platformsubscription__c bs
# MAGIC   where bs.processDate = (select max(processDate) from main.sfdc_bronze.platformsubscription__c)
# MAGIC   and bs.Type__c = 'PAYG' 
# MAGIC   and bs.Subscription_Channel__c = 'DIRECT' 
# MAGIC   and bs.Platform__c = 'aws'
# MAGIC   and bs.NS_Customer_Internal__c != ''
# MAGIC   and  bs.Trial_End_Date__c <= current_Date()
# MAGIC ),
# MAGIC NS_Sub as (
# MAGIC   select s.subscription_id subscriptionId,
# MAGIC          PayGSet.*
# MAGIC   from it_finance_silver.netsuite_subscriptions s
# MAGIC   left join PayGSet on PayGSet.NS_Customer_Internal__c = s.customer_id
# MAGIC   left join it_finance_silver.netsuite_plans p 
# MAGIC     on p.plan_id = s.plan_id
# MAGIC     and p.processDate = (select max(processDate) from it_finance_silver.netsuite_plans )
# MAGIC   where s.processDate = (select max(processDate) from it_finance_silver.netsuite_subscriptions)
# MAGIC   and PayGSet.NS_Customer_Internal__c!= ''
# MAGIC   --and p.is_paygo is null
# MAGIC   and s.end_date >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 )
# MAGIC )
# MAGIC select distinct 
# MAGIC   agg.workspaceId as workspaceName,
# MAGIC   cast(w.workspace_id as integer) as workspaceId,
# MAGIC   cast(NS_Sub.subscriptionId as integer) as subscriptionId,
# MAGIC   s.subscription_name as subscriptionName,
# MAGIC   to_date(s.start_date, "yyyy-MM-dd") as startDate,
# MAGIC   to_date(s.end_date, "yyyy-MM-dd") as endDate,
# MAGIC   p.is_paygo as IsPayGo,
# MAGIC   TRUE as IncludeInUpload,
# MAGIC   CASE 
# MAGIC     WHEN (p.is_paygo is null or p.is_paygo = false) AND ((select count(*) from it_finance_silver.netsuite_subscription_items 
# MAGIC                                  where (processDate = (select max(processDate) from it_finance_silver.netsuite_subscription_items))
# MAGIC                                    and (subscription_id = s.subscription_id) 
# MAGIC                                    and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE --added Mar 15, 2022 to include all commit 
# MAGIC     WHEN p.is_paygo THEN FALSE
# MAGIC     ELSE FALSE
# MAGIC   END as HasCommitLine,
# MAGIC   'AWS_Direct_PayGo4' as MappingSource
# MAGIC   FROM it_bui_silver.bui_metering_agg agg
# MAGIC   left join it_bui_silver.bui_workspaces_latest wl on wl.workspaceId = agg.workspaceId
# MAGIC   left join NS_Sub on NS_Sub.Platform_Account_ID__c = wl.accountId
# MAGIC   left join it_finance_silver.netsuite_workspaces w
# MAGIC     on (w.name = agg.workspaceId
# MAGIC     and w.processDate = (select max(processDate) from it_finance_silver.netsuite_workspaces))
# MAGIC   left join it_bui_silver.bui_subscriptions bui_sub
# MAGIC     on bui_sub.subscriptionId = wl.subscriptionId
# MAGIC     and wl.subscriptionId is not null
# MAGIC     and bui_sub.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.bui_subscriptions )
# MAGIC   left join main.sfdc_bronze.platformsubscription__c bs 
# MAGIC     on bs.Platform_Account_ID__c = wl.accountId
# MAGIC     and bs.processDate = (select max(processDate) from main.sfdc_bronze.platformsubscription__c)
# MAGIC   left join main.sfdc_bronze.order bsOrder
# MAGIC     on bsOrder.id = bs.Order__c
# MAGIC     and bsOrder.processDate = (select max(processDate) from main.sfdc_bronze.order)
# MAGIC   left join main.sfdc_bronze.order o
# MAGIC     on o.id = CASE WHEN bsOrder.CPQ_Order_Type__c = 'Co-term' THEN  bsOrder.CPQ_Original_Order__c ELSE bsOrder.Id END
# MAGIC     and o.processDate = (select max(processDate) from main.sfdc_bronze.order)
# MAGIC   left join it_finance_silver.netsuite_subscriptions s
# MAGIC     on s.subscription_id = NS_Sub.subscriptionId
# MAGIC     and s.processDate = (select max(processDate) from it_finance_silver.netsuite_subscriptions)
# MAGIC   left join it_finance_silver.netsuite_plans p on (p.plan_id = s.plan_id and p.processDate = s.processDate)
# MAGIC where date >=  date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 ) 
# MAGIC     AND  date <= last_day(current_date()-1)
# MAGIC     AND w.name is NULL
# MAGIC     and NS_Sub.subscriptionId is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view GCPBSUpdatedWorkspaces as
# MAGIC WITH Wsub as (
# MAGIC   select wsub.workspace_id, wsub.subscription_id ,wsub.workspaceName,
# MAGIC   case 
# MAGIC     when subscription_end_date > current_date() then True
# MAGIC     else False
# MAGIC   end as sub_status 
# MAGIC   from (
# MAGIC     select ws.workspace_id, ws.subscription_id, w.name workspaceName, subscription_end_date ,
# MAGIC     RANK() OVER (PARTITION BY ws.workspace_id ORDER BY subscription_end_date DESC) AS sub_rank 
# MAGIC     from it_finance_silver.netsuite_workspace_subscriptions ws
# MAGIC     left join it_finance_silver.netsuite_workspaces w
# MAGIC       on w.workspace_id = ws.workspace_id
# MAGIC       and w.processDate = (select max(processDate) from it_finance_silver.netsuite_workspaces )
# MAGIC     where ws.processDate = (select max(processDate) from it_finance_silver.netsuite_workspace_subscriptions )
# MAGIC     and ws.subscription_start_date <= current_date()
# MAGIC     ) wsub
# MAGIC   where sub_rank = 1
# MAGIC   and wsub.workspace_id is not null
# MAGIC ),
# MAGIC workspaceUpdateList as (
# MAGIC   select distinct 
# MAGIC     agg.workspaceId as workspaceName,
# MAGIC     cast(w.workspace_id as int) as workspaceId,
# MAGIC     cast(o.NS_InternalID__c as int) as subscriptionId,
# MAGIC     s.subscription_name as subscriptionName,
# MAGIC     to_date(s.start_date, "yyyy-MM-dd") as startDate,
# MAGIC     to_date(s.end_date, "yyyy-MM-dd") as endDate,
# MAGIC     CASE 
# MAGIC       WHEN p.is_paygo is null then FALSE
# MAGIC       ELSE p.is_paygo 
# MAGIC     END as IsPayGo,
# MAGIC     CASE
# MAGIC       WHEN (p.is_paygo is null or p.is_paygo = false) and ((select count(*) from it_finance_silver.netsuite_subscription_items 
# MAGIC                                   where (processDate = (select max(processDate) from it_finance_silver.netsuite_subscription_items))
# MAGIC                                     and (subscription_id = s.subscription_id) 
# MAGIC                                     and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE 
# MAGIC       WHEN p.is_paygo THEN TRUE
# MAGIC       ELSE FALSE
# MAGIC     END as IncludeInUpload,
# MAGIC     CASE 
# MAGIC       WHEN (p.is_paygo is null or p.is_paygo = false) AND ((select count(*) from it_finance_silver.netsuite_subscription_items 
# MAGIC                                   where (processDate = (select max(processDate) from it_finance_silver.netsuite_subscription_items))
# MAGIC                                     and (subscription_id = s.subscription_id) 
# MAGIC                                     and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE  
# MAGIC       WHEN p.is_paygo THEN FALSE
# MAGIC       ELSE FALSE
# MAGIC     END as HasCommitLine,
# MAGIC     'GCP_UpdateBizSub' as MappingSource
# MAGIC     FROM it_bui_silver.gcp_metering_agg agg
# MAGIC     left join it_finance_silver.netsuite_workspaces w
# MAGIC       on (w.name = agg.workspaceId
# MAGIC       and w.processDate = (select max(processDate) from it_finance_silver.netsuite_workspaces))
# MAGIC     left join it_bui_silver.gcp_workspaces_latest wl on wl.workspaceId = agg.workspaceId
# MAGIC     left join it_bui_silver.gcp_subscriptions bui_sub
# MAGIC       on bui_sub.subscriptionId = wl.subscriptionId
# MAGIC       and wl.subscriptionId is not null
# MAGIC       and bui_sub.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.bui_subscriptions ) 
# MAGIC     left join main.sfdc_bronze.platformsubscription__c bs
# MAGIC       on bs.Subscription_Id__c = wl.subscriptionId
# MAGIC       and bs.processDate = (select max(processDate) from main.sfdc_bronze.platformsubscription__c)
# MAGIC     left join main.sfdc_bronze.`order` o
# MAGIC       on o.id = bs.Order__c
# MAGIC       and o.processDate = (select max(processDate) from main.sfdc_bronze.`order`)
# MAGIC     left join main.sfdc_bronze.account a
# MAGIC       on a.id = o.AccountId
# MAGIC       and a.processDate = (select max(processDate) from main.sfdc_bronze.account)
# MAGIC     left join it_finance_silver.netsuite_subscriptions s
# MAGIC       on s.subscription_id = o.NS_InternalID__c
# MAGIC       and s.processDate = (select max(processDate) from it_finance_silver.netsuite_subscriptions)
# MAGIC     left join it_finance_silver.netsuite_plans p on (p.plan_id = s.plan_id and p.processDate = s.processDate)
# MAGIC   where date >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 ) 
# MAGIC       AND  date <= last_day(current_date()-1)
# MAGIC       AND w.name is not NULL
# MAGIC       and o.NS_InternalID__c is not null and o.NS_TargetType__c = 'Subscription' and (w.workspace_external_id is not null and w.workspace_external_id = agg.workspaceId)
# MAGIC ) 
# MAGIC select a.* from workspaceUpdateList a
# MAGIC left join Wsub on Wsub.workspace_id = a.workspaceId
# MAGIC where a.HasCommitLine = true and a.workspaceId is not null
# MAGIC and Wsub.subscription_id != a.subscriptionId
# MAGIC and a.endDate >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 ) 
# MAGIC and Wsub.sub_status = false 

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temp view UpdateDirectPayGo4 as
# MAGIC with PayGSet as (
# MAGIC   select name,
# MAGIC          bs.Platform_Account_ID__c,
# MAGIC          bs.Subscription_Id__c,
# MAGIC          bs.Type__c,
# MAGIC          bs.Subscription_Channel__c,
# MAGIC          bs.NS_Customer_Internal__c,
# MAGIC          bs.NS_Subscription_Internal__c,
# MAGIC          bs.Country_Code__c
# MAGIC   from main.sfdc_bronze.platformsubscription__c bs
# MAGIC   where bs.processDate = (select max(processDate) from main.sfdc_bronze.platformsubscription__c)
# MAGIC     and bs.Type__c = 'PAYG'
# MAGIC     and bs.Subscription_Channel__c = 'DIRECT'
# MAGIC     and bs.Platform__c = 'aws'
# MAGIC     and bs.NS_Customer_Internal__c != ''
# MAGIC     and bs.Trial_End_Date__c <= current_Date()
# MAGIC   ),
# MAGIC   NS_Sub as (
# MAGIC     select s.subscription_id subscriptionId,PayGSet.*
# MAGIC     from it_finance_silver.netsuite_subscriptions s
# MAGIC     left join PayGSet on PayGSet.NS_Customer_Internal__c = s.customer_id
# MAGIC     left join it_finance_silver.netsuite_plans p
# MAGIC       on p.plan_id = s.plan_id
# MAGIC       and p.processDate = (select max(processDate) from it_finance_silver.netsuite_plans )
# MAGIC     where s.processDate = (select max(processDate) from it_finance_silver.netsuite_subscriptions)
# MAGIC     and PayGSet.NS_Customer_Internal__c!= ''
# MAGIC     -- and p.is_paygo is null
# MAGIC     and s.end_date >= date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 )
# MAGIC   )
# MAGIC select distinct 
# MAGIC   agg.workspaceId as workspaceName,
# MAGIC   cast(w.workspace_id as integer) as workspaceId,
# MAGIC   cast(NS_Sub.subscriptionId as integer) as subscriptionId,
# MAGIC   s.subscription_name as subscriptionName,
# MAGIC   to_date(s.start_date, "yyyy-MM-dd") as startDate,
# MAGIC   to_date(s.end_date, "yyyy-MM-dd") as endDate,
# MAGIC   p.is_paygo as IsPayGo,
# MAGIC   TRUE as IncludeInUpload,
# MAGIC   CASE 
# MAGIC     WHEN (p.is_paygo is null or p.is_paygo = false) AND ((select count(*) from it_finance_silver.netsuite_subscription_items 
# MAGIC                                  where (processDate = (select max(processDate) from it_finance_silver.netsuite_subscription_items))
# MAGIC                                    and (subscription_id = s.subscription_id) 
# MAGIC                                    and (ITEM_ID in (282,2292,2617,2294,2616))) > 0) THEN TRUE --added Mar 15, 2022 to include all commit 
# MAGIC     WHEN p.is_paygo THEN FALSE
# MAGIC     ELSE FALSE
# MAGIC   END as HasCommitLine,
# MAGIC   'AWS_UpdateDirect_PayGo4' as MappingSource
# MAGIC   FROM it_bui_silver.bui_metering_agg agg
# MAGIC   left join it_bui_silver.bui_workspaces_latest wl on wl.workspaceId = agg.workspaceId
# MAGIC   left join NS_Sub on NS_Sub.Platform_Account_ID__c = wl.accountId
# MAGIC   left join it_finance_silver.netsuite_workspaces w
# MAGIC     on (w.name = agg.workspaceId)
# MAGIC     and w.processDate = (select max(processDate) from it_finance_silver.netsuite_workspaces)
# MAGIC   left join it_bui_silver.bui_subscriptions bui_sub
# MAGIC     on bui_sub.subscriptionId = wl.subscriptionId
# MAGIC     and wl.subscriptionId is not null
# MAGIC     and bui_sub.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.bui_subscriptions )
# MAGIC   left join main.sfdc_bronze.platformsubscription__c bs
# MAGIC     on bs.Platform_Account_ID__c = wl.accountId
# MAGIC     and bs.processDate = (select max(processDate) from main.sfdc_bronze.platformsubscription__c)
# MAGIC   left join main.sfdc_bronze.order bsOrder
# MAGIC     on bsOrder.id = bs.Order__c
# MAGIC     and bsOrder.processDate = (select max(processDate) from main.sfdc_bronze.order)
# MAGIC   left join main.sfdc_bronze.order o
# MAGIC     on o.id = CASE WHEN bsOrder.CPQ_Order_Type__c = 'Co-term' THEN  bsOrder.CPQ_Original_Order__c ELSE bsOrder.Id END
# MAGIC     and o.processDate = (select max(processDate) from main.sfdc_bronze.order)
# MAGIC   left join it_finance_silver.netsuite_subscriptions s
# MAGIC     on s.subscription_id = NS_Sub.subscriptionId
# MAGIC     and s.processDate = (select max(processDate) from it_finance_silver.netsuite_subscriptions)
# MAGIC   left join it_finance_silver.netsuite_plans p on (p.plan_id = s.plan_id and p.processDate = s.processDate)
# MAGIC where date >=  date_sub(last_day(current_date()-1),dayofmonth(last_day(current_date()-1))-1 ) 
# MAGIC     AND  date <= last_day(current_date()-1)
# MAGIC     AND w.name is not NULL
# MAGIC     and NS_Sub.subscriptionId is not null
# MAGIC     and NS_Sub.subscriptionId <> w.subscription_Id

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW GoldWorkspacesView AS
# MAGIC SELECT DISTINCT(*), current_date() AS processDate FROM (
# MAGIC   SELECT * FROM AWSNewWorkspaces
# MAGIC   UNION
# MAGIC   SELECT * FROM GCPNewWorkspaces
# MAGIC   UNION
# MAGIC   SELECT * FROM AWSPayGoNewWorkspaces
# MAGIC   UNION
# MAGIC   SELECT * FROM BSUpdatedWorkspaces
# MAGIC   UNION
# MAGIC   SELECT * FROM GCPBSUpdatedWorkspaces
# MAGIC   UNION
# MAGIC   SELECT * FROM DirectPayGo4
# MAGIC   UNION
# MAGIC   SELECT * FROM UpdateDirectPayGo4
# MAGIC )
# MAGIC WHERE IncludeInUpload = true
# MAGIC ORDER BY workspaceName

# COMMAND ----------

today = datetime.utcnow().date()
today_str = today.strftime('%Y-%m-%d')

df = spark.table('GoldWorkspacesView')
if not table_exists(config.gold_database, table_name, spark):
    logger.info(f'Creating {full_table_name}')
    sql(f'CREATE TABLE {full_table_name} PARTITIONED BY ({METADATA_PROCESS_DATE_COLUMN}) '
        f'AS SELECT * FROM GoldWorkspacesView')
else:
    logger.info(f'(Re)creating data in {full_table_name} for processDate {today_str}')
    # Ensure that any new columns are merged into the schema.
    # See https://docs.databricks.com/delta/update-schema.html#automatic-schema-evolution-for-delta-lake-merge
    spark.conf.set('spark.databricks.delta.schema.autoMerge.enabled', 'true')    
    (df.write
        .mode('overwrite')
        .format('delta')
        .option('mergeSchema', 'true')
        .option('overwriteSchema', 'true')
        .option('replaceWhere', f"processDate = '{today_str}'")
        .saveAsTable(full_table_name)
  )    
