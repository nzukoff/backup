# Databricks notebook source
# MAGIC %run "./Update-Gold-Workspace-Table"

# COMMAND ----------

# MAGIC %run "./Export-Workspace-Data-To-S3"

# COMMAND ----------

