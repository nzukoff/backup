# Databricks notebook source
# MAGIC %run "./Update-Usage-Gold-from-S3"