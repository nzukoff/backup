# Databricks notebook source
# MAGIC %run "../Suite-Analytics-Defs"

# COMMAND ----------

from pprint import pprint
from pyspark.sql import functions as F

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get('log_level'))
config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)

# COMMAND ----------

sql = make_sql(
    logger=logger,
    spark=spark,
    log_level=logging.INFO
)

# COMMAND ----------

GOLD_TABLE = f'{config.gold_database}.{GOLD_USAGE_EXTRACT_TABLE}'
logger.debug(f"{GOLD_TABLE=}, UC catalog={config.uc_catalog}")

access_key = dbutils.secrets.get(config.secret_scope, config.usage_s3_access_key_secret)
secret_key = dbutils.secrets.get(config.secret_scope, config.usage_s3_secret_key_secret)

S3_EXPORT_URL = f's3a://{access_key}:{secret_key}@{config.usage_s3_bucket}'
logger.debug(f"{S3_EXPORT_URL=}")

# COMMAND ----------

files_to_process = [f.path for f in dbutils.fs.ls(f'{S3_EXPORT_URL}/status')]

# COMMAND ----------

logger.info(f"Total files to process: {len(files_to_process):,}")

# COMMAND ----------

sql(f"USE CATALOG {config.uc_catalog}")
gold_df = spark.table(GOLD_TABLE)

# COMMAND ----------

csv_schema = '''
externalId STRING,
workspaceName LONG,
SkuId INTEGER,
UsageDate STRING,
wsEntryInternalId INTEGER,
isSuccess BOOLEAN,
errorMessage STRING
'''

# COMMAND ----------

from pyspark.sql.functions import max as sql_max

max_process_date = (
  gold_df
    .select(sql_max('processDate').alias('max_process_date'))
    .first()
    .max_process_date
)

s_max_process_date = format_sql_date(max_process_date)
logger.info(f"Merging into gold table {config.uc_catalog}.{GOLD_TABLE} for processDate {s_max_process_date}")

# COMMAND ----------

CSV_VIEW_NAME = 'gold_table_updates'

merge_sql = f'''
MERGE INTO {GOLD_TABLE}
USING {CSV_VIEW_NAME}
ON {GOLD_TABLE}.ExternalId = {CSV_VIEW_NAME}.externalId
AND {GOLD_TABLE}.processDate = '{s_max_process_date}'
WHEN MATCHED AND {CSV_VIEW_NAME}.isSuccess AND (NOT {GOLD_TABLE}.Status IN ('P', 'S')) THEN
UPDATE SET -- {GOLD_TABLE}.WorkspaceName = {CSV_VIEW_NAME}.workspaceName,
           {GOLD_TABLE}.Status = 'P',
           {GOLD_TABLE}.InternalId = {CSV_VIEW_NAME}.wsEntryInternalId
WHEN MATCHED AND (NOT {CSV_VIEW_NAME}.isSuccess) AND (NOT {GOLD_TABLE}.Status IN ('P', 'S')) THEN
UPDATE SET {GOLD_TABLE}.errorMessage = {CSV_VIEW_NAME}.errorMessage,
           {GOLD_TABLE}.Status = 'E'
'''
logger.info("merge_sql=" + merge_sql)

# COMMAND ----------

errors = []
archive_dir = f'{S3_EXPORT_URL}/archive'

total = len(files_to_process)
for i, path in enumerate(files_to_process):
  logger.info('-' * 30)
  n = i + 1
  logger.info(f'{n:,} of {total:,}: Merging data from "{path}" into {GOLD_TABLE}')

  csv_df = spark.read.csv(path, header=True, schema=csv_schema)
  csv_df.createOrReplaceTempView(CSV_VIEW_NAME)
  try:
    spark.sql(merge_sql)
    logger.info(f'Moving {path} to {archive_dir}')
    dbutils.fs.mv(path, archive_dir)
  except Exception as e:
    logger.error(f'Merge failed: {e}')
    errors.append(f'Failed to merge "{path}" into {GOLD_TABLE}: {e}')
  finally:
    logger.info(f'Done with "{path}"')
    spark.catalog.dropTempView(CSV_VIEW_NAME)



# COMMAND ----------

if len(errors) > 0:
  logger.error(f'Failed to merge {len(errors):,} file(s). Errors follow.')
  for e in errors:
    logger.error(e)
  raise Exception('Failed to merge {len(errors):,} file(s).')
