# Databricks notebook source
# MAGIC %run "../Suite-Analytics-Defs"

# COMMAND ----------

from pyspark.sql import DataFrame
from typing import Optional
from pprint import pprint

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get('log_level'))
config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)

# COMMAND ----------

sql = make_sql(
    logger=logger,
    spark=spark,
    log_level=logging.INFO
)

# COMMAND ----------

RECREATE = dbutils.widgets.get("recreate") == "yes"
logger.debug(f"{RECREATE=}")

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Bronze
# MAGIC
# MAGIC Download the transaction-related bronze tables first.

# COMMAND ----------

load_bronze_with_retries(
    tables=TRANSACTION_TABLES,
    config=config,
    logger=logger,
    sql=sql,
    recreate=RECREATE,
    max_retries=3
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver
# MAGIC
# MAGIC Refine the raw transactions table.

# COMMAND ----------

sql(f'USE CATALOG {config.uc_catalog}')
sql(f'USE {config.bronze_database}')

# COMMAND ----------

def update_silver_table(
    table_name: str, source_view: str, process_date: Optional[date] = None
) -> None:
    """
    Take a source DataFrame containing new data for a silver table, and
    update the silver table. This function assumes the source DataFrame
    contains ALL the data. It creates (or overwrites) the table for the
    current/specific process date. It does not merge the data into an existing
    process date.

    Parameters:

    table_name:   The name of the (Delta) table to create or update
    source_df:    DataFrame with source data
    process_date: Optional date to override the process date (which defaults to today)
    """
    full_table_name = f"{config.silver_database}.{table_name}"
    source_df = spark.table(source_view)

    rows = source_df.count()
    logger.info(f"{rows:,} row(s) in update data set")
    if rows == 0:
        logger.info(f'Skipping "{table_name}". New data has no rows.')
        return

    # Add metadata columns.
    final_df, process_date = add_silver_metadata(source_df, process_date)

    logger.info(f"In catalog {config.uc_catalog}:")
    if not table_exists(config.silver_database, table_name, spark):
        logger.info(f"Creating {full_table_name}")
        (
            final_df.write.mode("overwrite")
                .format("delta")
                .partitionBy(METADATA_PROCESS_DATE_COLUMN)
                .saveAsTable(full_table_name)
        )
    else:
        date_str = format_sql_date(process_date)
        logger.info(f"Updating data in {full_table_name} for {process_date}")
        (
            final_df.write.mode("overwrite")
                .format("delta")
                .option("mergeSchema", "true")
                .option("replaceWhere", f"{METADATA_PROCESS_DATE_COLUMN} = '{date_str}'")
                .saveAsTable(full_table_name)
        )

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW silver_transactions AS
# MAGIC WITH
# MAGIC  StandardTransactions AS (
# MAGIC    SELECT 
# MAGIC      lastmodifieddate,
# MAGIC      exchangerate,
# MAGIC      type,
# MAGIC      trandate,
# MAGIC      id,
# MAGIC      memo,
# MAGIC      status,
# MAGIC      entity,
# MAGIC      currency,
# MAGIC      custbody_agreement_type
# MAGIC    FROM main.netsuite2_bronze_hourly.transaction
# MAGIC    WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.transaction)
# MAGIC  ),
# MAGIC  StatisticalJournalTransactions AS (
# MAGIC    SELECT 
# MAGIC      lastmodifieddate,
# MAGIC      1 AS exchangerate,            -- Non-monetary transaction, default as 1 
# MAGIC      'Journal' AS type,
# MAGIC      trandate,
# MAGIC      id,
# MAGIC      memo,
# MAGIC      status,
# MAGIC      NULL AS entity,
# MAGIC      1 AS currency,                -- Non-monetary transaction, default as 1 
# MAGIC      custbody_agreement_type
# MAGIC    FROM main.netsuite2_bronze_hourly.statisticaljournalentry
# MAGIC    WHERE processTimestamp = (SELECT MAX(processTimestamp) FROM main.netsuite2_bronze_hourly.statisticaljournalentry)
# MAGIC  ),
# MAGIC  StatisticalJournalTransactionLine AS (
# MAGIC    SELECT 
# MAGIC      journal, 
# MAGIC      line
# MAGIC    FROM main.netsuite2_bronze_hourly.statisticaljournalentryline
# MAGIC    WHERE processTimestamp = (SELECT MAX(processTimestamp) FROM main.netsuite2_bronze_hourly.statisticaljournalentryline)
# MAGIC  ),
# MAGIC  TransactionStatus AS (
# MAGIC    SELECT *
# MAGIC    FROM main.netsuite2_bronze_hourly.transactionstatus
# MAGIC    WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.transactionstatus)
# MAGIC  ),
# MAGIC  TransactionAccountingLine AS (
# MAGIC    SELECT *
# MAGIC    FROM main.netsuite2_bronze_hourly.transactionaccountingline
# MAGIC    WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.transactionaccountingline)
# MAGIC  ),
# MAGIC  TransactionLines AS (
# MAGIC    SELECT id, transaction
# MAGIC    FROM main.netsuite2_bronze_hourly.transactionline
# MAGIC    WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.transactionline)
# MAGIC  ),
# MAGIC  CompleteTransactions AS (
# MAGIC    SELECT * FROM StandardTransactions
# MAGIC    UNION ALL
# MAGIC    SELECT * FROM StatisticalJournalTransactions
# MAGIC  ),
# MAGIC  CompleteTransactionLines AS (
# MAGIC    SELECT * FROM TransactionLines
# MAGIC    UNION ALL
# MAGIC    SELECT journal AS id, line AS transaction FROM StatisticalJournalTransactionLine
# MAGIC  ),
# MAGIC  Customers AS (
# MAGIC    SELECT *
# MAGIC    FROM main.netsuite2_bronze_hourly.customer
# MAGIC    WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.customer)
# MAGIC  ),
# MAGIC  Currencies AS (
# MAGIC    SELECT id, name, symbol
# MAGIC    FROM main.netsuite2_bronze_hourly.currency
# MAGIC    WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.currency)
# MAGIC  ),
# MAGIC  AgreementTypes AS (
# MAGIC    SELECT name AS agreement_type, id AS agreement_type_id
# MAGIC    FROM main.netsuite2_bronze.customlist_agreement_type_list
# MAGIC    WHERE processDate = (SELECT max(processDate) FROM main.netsuite2_bronze.customlist_agreement_type_list)
# MAGIC  )
# MAGIC SELECT
# MAGIC   Customers.companyname AS customer_name,
# MAGIC   CAST(Customers.id AS double) AS customer_id,
# MAGIC   Currencies.symbol AS currency_symbol, 
# MAGIC   AgreementTypes.agreement_type,
# MAGIC   CAST(AgreementTypes.agreement_type_id AS double) AS agreement_type_id,
# MAGIC   CAST(TransactionAccountingLine.amount    AS DECIMAL(10,2)) AS amount,
# MAGIC   CAST(TransactionAccountingLine.netamount AS DECIMAL(10,2)) AS net_amount,
# MAGIC   CompleteTransactions.lastmodifieddate AS last_modified_date,
# MAGIC   CAST(CompleteTransactions.exchangerate  AS DECIMAL(10,2)) AS exchange_rate,
# MAGIC   TransactionStatus.name AS status,
# MAGIC
# MAGIC   -- NS2 → NS1 mapping for transaction type
# MAGIC   CASE lower(trim(CompleteTransactions.type))
# MAGIC     WHEN 'vendpymt'  THEN 'Bill Payment'
# MAGIC     WHEN 'custinvc'  THEN 'Invoice'
# MAGIC     WHEN 'custpymt'  THEN 'Payment'
# MAGIC     WHEN 'salesord'  THEN 'Sales Order'
# MAGIC     WHEN 'purchord'  THEN 'Purchase Order'
# MAGIC     WHEN 'cashsale'  THEN 'Cash Sale'
# MAGIC     WHEN 'cashrfnd'  THEN 'Cash Refund'
# MAGIC     WHEN 'creditmemo' THEN 'Credit Memo'
# MAGIC     WHEN 'itemrcpt'  THEN 'Item Receipt'
# MAGIC     WHEN 'itemship'  THEN 'Item Fulfillment'
# MAGIC     WHEN 'rtnauth'   THEN 'Return Authorization'
# MAGIC     WHEN 'opprtnty'  THEN 'Opportunity'
# MAGIC     WHEN 'vendbill'  THEN 'Bill'
# MAGIC     WHEN 'exprept'   THEN 'Expense Report'
# MAGIC     WHEN 'revarrng'  THEN 'Revenue Arrangement'
# MAGIC     WHEN 'fxreval'   THEN 'Currency Revaluation'
# MAGIC     WHEN 'custcred'  THEN 'Credit Memo'
# MAGIC     WHEN 'vendcred'  THEN 'Bill Credit'
# MAGIC     WHEN 'custrfnd'  THEN 'Customer Refund'
# MAGIC     WHEN 'custchrg'  THEN 'Statement Charge'
# MAGIC     WHEN 'vendauth'  THEN 'Vendor Return Authorization'
# MAGIC     ELSE CompleteTransactions.type
# MAGIC   END AS transaction_type,
# MAGIC   CompleteTransactions.trandate AS transaction_date,
# MAGIC   CAST(CompleteTransactions.id AS double)  AS transaction_id,
# MAGIC   CAST(CompleteTransactionLines.id AS double) AS transaction_line_id,
# MAGIC   CompleteTransactions.memo AS memo
# MAGIC FROM CompleteTransactions
# MAGIC
# MAGIC LEFT JOIN TransactionStatus
# MAGIC   ON CompleteTransactions.status = TransactionStatus.id
# MAGIC  AND CompleteTransactions.type   = TransactionStatus.trantype
# MAGIC
# MAGIC LEFT OUTER JOIN CompleteTransactionLines
# MAGIC   ON CompleteTransactionLines.transaction = CompleteTransactions.id
# MAGIC
# MAGIC LEFT JOIN TransactionAccountingLine 
# MAGIC   ON CompleteTransactionLines.id          = TransactionAccountingLine.transactionline
# MAGIC  AND CompleteTransactionLines.transaction = TransactionAccountingLine.transaction
# MAGIC
# MAGIC LEFT OUTER JOIN Customers
# MAGIC   ON CompleteTransactions.entity = Customers.id
# MAGIC
# MAGIC LEFT OUTER JOIN Currencies
# MAGIC   ON CompleteTransactions.currency = Currencies.id
# MAGIC
# MAGIC LEFT OUTER JOIN AgreementTypes
# MAGIC   ON AgreementTypes.agreement_type_id = CompleteTransactions.custbody_agreement_type;

# COMMAND ----------

update_silver_table('netsuite_transactions', 'silver_transactions')
