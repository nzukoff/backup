# Databricks notebook source
# MAGIC %md
# MAGIC This notebook updates a specific subset of the bronze NetSuite tables. It is intended to be run manually, as needed.

# COMMAND ----------

# MAGIC %run "../Suite-Analytics-Defs"

# COMMAND ----------

from pprint import pprint

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get('log_level'))
config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)

# COMMAND ----------

RECREATE = dbutils.widgets.get("recreate") == "yes"
logger.debug(f"{RECREATE=}")

# COMMAND ----------

sql = make_sql(
    logger=logger,
    spark=spark,
    log_level=logging.INFO
)

# COMMAND ----------

# The names of the tables to be updated. They must
# be present in the TableConfig list.
TABLES = (
    'customers',
    'items',
    'workspace',
    'zab_plan',
    'zab_subscription',
    'zab_subscription_item',
)

# COMMAND ----------

table_configs = []
to_find = set(TABLES)

for t in (MAIN_TABLES + TRANSACTION_TABLES):
    if t.netsuite_table_name.lower() in to_find:
        table_configs.append(t)
        to_find.remove(t.netsuite_table_name.lower())

if len(to_find) > 0:
    raise Exception(f'The following tables are not present in the table configuration: {", ".join(sorted(to_find))}')


# COMMAND ----------

def attempt_download(table_data: TableConfig) -> None:
    load_bronze_data(
      table_data=table_data,
      target_database=config.bronze_database,
      logger=logger,
      config=config,
      recreate=RECREATE,
      sql=sql
    )

sql(f"USE CATALOG {config.uc_catalog}")

errors = []
MAX_RETRIES = 3
total = len(table_configs)
for i, table_data in enumerate(table_configs):
    n = i + 1
    logger.info(f"{n:,} of {total:,} tables: {table_data.netsuite_table_name}")
    try:
        run_with_retries(
            MAX_RETRIES,
            f"Downloading NetSuite table {table_data.netsuite_table_name}",
            logger,
            attempt_download,
            table_data
        )
    except Exception as e:
        # All retries failed. Capture this error, but keep going.
        # Note that run_with_retries() already logged the error
        # inline, but we'll capture it and log all of the errors
        # again at the bottom.
        errors.append(str(e))

if len(errors) > 0:
    logger.error(f"{len(errors):,} error(s) occurred during downloads. Errors follow:")
    for e in errors:
        logger.error(e)
    raise Exception(f"ERRORS IN NetSuite DOWNLOAD")
