# Databricks notebook source
# MAGIC %run "./Suite-Analytics-Defs"

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

import logging

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get("log_level"))
config = get_configuration(dbutils.widgets.get("configuration"))
sql = make_sql(spark=spark, logger=logger, log_level=logging.DEBUG)
RECREATE = dbutils.widgets.get("recreate") == "yes"
logger.debug(f"{RECREATE=}")
logger.debug(f"{config=}")

# COMMAND ----------

if not config.name.lower().startswith("sandbox"):
    raise Exception(
        "This job is only intended to be run against a NetSuite "
        'sandbox instance, but the "configuration" parameter specifies '
        f'"{config.name.lower()}."'
    )

# COMMAND ----------

# Special case for SYSTEM_NOTES table. See
# comments associated with load_system_notes()
# in Suite-Analytics-Defs notebook.
def do_system_notes_download() -> None:
    load_system_notes(config=config, sql=sql, logger=logger, recreate_sandbox=RECREATE)

run_with_retries(
    3,
    f"Downloading NetSuite table {SYSTEM_NOTES_TABLE.netsuite_table_name}",
    logger,
    do_system_notes_download
)

# COMMAND ----------

load_bronze_with_retries(
    tables=SOX_SANDBOX_DAILY_TABLES,
    config=config,
    logger=logger,
    sql=sql,
    recreate=RECREATE
)
