# Databricks notebook source
# MAGIC %run "./Suite-Analytics-Defs"

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

import logging

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get("log_level"))
config = get_configuration(dbutils.widgets.get("configuration"))
sql = make_sql(spark=spark, logger=logger, log_level=logging.DEBUG)
RECREATE = dbutils.widgets.get("recreate") == "yes"
logger.debug(f"{RECREATE=}")
logger.debug(f"{config=}")

timestamppartition = dbutils.widgets.get("timestamppartition") == "yes"


# COMMAND ----------

if not config.name.lower().startswith("sandbox"):
    raise Exception(
        "This job is only intended to be run against a NetSuite "
        'sandbox instance, but the "configuration" parameter specifies '
        f'"{config.name.lower()}."'
    )

# COMMAND ----------

load_bronze_with_retries(
    tables=SOX_SANDBOX_HOURLY_TABLES,
    config=config,
    logger=logger,
    sql=sql,
    recreate=RECREATE,
    partition_by_timestamp=timestamppartition,
    max_retries=3
)

