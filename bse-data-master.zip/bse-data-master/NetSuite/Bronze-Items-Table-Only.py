# Databricks notebook source
# MAGIC %md
# MAGIC This notebook downloads _only_ the NetSuite `ITEMS` table to the bronze schema, per a request from
# MAGIC sachin.khurana@databricks.com

# COMMAND ----------

# MAGIC %run "./Suite-Analytics-Defs"

# COMMAND ----------

from pprint import pprint

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)


# COMMAND ----------

logger = configure_logging(dbutils.widgets.get('log_level'))
config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)

# COMMAND ----------

sql = make_sql(
    logger=logger,
    spark=spark,
    log_level=logging.INFO
)

# COMMAND ----------

# We're only download the ITEMS table.
tables = [t for t in MAIN_TABLES if t.netsuite_table_name.lower() == "items"]
assert len(tables) == 1

# COMMAND ----------

sql(f"USE CATALOG {config.uc_catalog}")

# COMMAND ----------

load_bronze_with_retries(tables=tables,
                         config=config,
                         logger=logger,
                         sql=sql,
                         max_retries=3)
