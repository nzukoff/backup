# Databricks notebook source
# This notebook is intended to be included (via %run) into other notebooks.


# COMMAND ----------

# Import our common functions
import sys
sys.path.insert(0, "../..")
from it_data_lib import *

# COMMAND ----------

# Ensure that we're using DBR 13.3 or better, and double-check
# that it's Spark 3 (which is should definitely be, if we're on
# DBR 13.3 or greater).

ensure_dbr_version((13,3), spark)
major_spark_version = int(spark.version.split(".")[0])
if major_spark_version < 3:
    raise Exception(
        f"Minimum version of Apache Spark is 3. This cluster is running {spark.version}."
    )

# COMMAND ----------

from typing import Callable, Optional, Sequence, Tuple, Any, Union
from pyspark.sql import DataFrame, functions as F, SparkSession
from datetime import datetime, date, timedelta
from dataclasses import dataclass, field
from enum import Enum
import logging

# COMMAND ----------

@dataclass(frozen=True)
class Configuration:
    name: str
    hostname: str
    account_id: str
    netsuite_1_role_id: str
    netsuite_2_role_id: str
    user_key: str
    password_key: str
    uc_catalog: str
    bronze_database: str
    bronze_hourly_database: str
    silver_database: str
    gold_database: str
    usage_s3_bucket: str
    usage_s3_access_key_secret: str
    usage_s3_secret_key_secret: str
    usage_extraction_folder: str
    workspace_extraction_folder: str
    secret_scope: str

PRODUCTION = Configuration(
    name="Production",
    hostname="3822968.connect.api.netsuite.com",
    account_id="3822968",
    netsuite_1_role_id="1102",
    netsuite_2_role_id="1141",
    user_key="suite-analytics-production-user",
    password_key="suite-analytics-production-password",
    uc_catalog="main",
    bronze_database="it_netsuite_bronze",
    bronze_hourly_database="it_netsuite_bronze_hourly",
    silver_database="it_finance_silver",
    gold_database="it_usage_gold",
    usage_s3_bucket="usage-data-upload-prod-bucket",
    usage_s3_access_key_secret="usage-extract-s3-access-key",
    usage_s3_secret_key_secret="usage-extract-s3-secret-key",
    usage_extraction_folder="unprocessed",
    workspace_extraction_folder="workspaceList/unprocessed",
    secret_scope="netsuite",
)

PRODUCTION_STAGING = Configuration(
    name="Production Staging",
    hostname="3822968.connect.api.netsuite.com",
    account_id="3822968",
    netsuite_1_role_id="1102",
    netsuite_2_role_id="1141",
    user_key="suite-analytics-production-user",
    password_key="suite-analytics-production-password",
    uc_catalog="integration",
    bronze_database="it_netsuite_bronze",
    bronze_hourly_database="it_netsuite_bronze_hourly",
    silver_database="it_finance_silver",
    gold_database="it_usage_gold",
    usage_s3_bucket="usage-data-upload-dev-bucket",
    usage_s3_access_key_secret="usage-extract-s3-access-key-staging",
    usage_s3_secret_key_secret="usage-extract-s3-secret-key-staging",
    usage_extraction_folder="unprocessed",
    workspace_extraction_folder="workspaceList/unprocessed",
    secret_scope="netsuite",
)

SANDBOX = Configuration(
    name="Sandbox",
    hostname="3822968-sb1.connect.api.netsuite.com",
    account_id="3822968_SB1",
    netsuite_1_role_id="1102",
    netsuite_2_role_id="1141",
    user_key="suite-analytics-sandbox-user",
    uc_catalog="integration", # should be "integration", but permissions aren't right yet
    password_key="suite-analytics-sandbox-password",
    bronze_database="it_netsuite_sandbox1_bronze",
    bronze_hourly_database="it_netsuite_sandbox1_bronze", # not really applicable for sandbox data
    silver_database="it_finance_sandbox1_silver",
    gold_database="it_usage_sandbox1_gold",
    usage_s3_bucket="usage-data-upload-dev-bucket",
    usage_s3_access_key_secret="usage-extract-s3-access-key-sandbox",
    usage_s3_secret_key_secret="usage-extract-s3-secret-key-sandbox",
    usage_extraction_folder="sandbox/unprocessed",
    workspace_extraction_folder="sandbox/workspaceList/unprocessed",
    secret_scope="netsuite-integration",
)

SANDBOX2 = Configuration(
    name="Sandbox2",
    hostname="3822968-sb2.connect.api.netsuite.com",
    account_id="3822968_SB2",
    netsuite_1_role_id="1102",
    netsuite_2_role_id="1141",
    user_key="suite-analytics-sandbox2-user",
    password_key="suite-analytics-sandbox2-password",
    uc_catalog="integration",
    bronze_database="it_netsuite_sandbox2_bronze",
    bronze_hourly_database="it_netsuite_sandbox2_bronze", # not really applicable for sandbox data
    silver_database="it_finance_sandbox2_silver",
    gold_database="it_usage_sandbox2_gold",
    usage_s3_bucket="usage-data-upload-dev-bucket",
    usage_s3_access_key_secret="usage-extract-s2-access-key-sandbox",
    usage_s3_secret_key_secret="usage-extract-s2-secret-key-sandbox",
    usage_extraction_folder="sandbox2/unprocessed",
    workspace_extraction_folder="sandbox2/workspaceList/unprocessed",
    secret_scope="netsuite-integration",
)
SANDBOX3 = Configuration(
    name="Sandbox3",
    hostname="3822968-sb3.connect.api.netsuite.com",
    account_id="3822968_SB3",
    netsuite_1_role_id="1102",
    netsuite_2_role_id="1141",
    user_key="suite-analytics-sandbox3-user",
    password_key="suite-analytics-sandbox3-password",
    uc_catalog="integration",
    bronze_database="it_netsuite_sandbox3_bronze",
    bronze_hourly_database="it_netsuite_sandbox3_bronze", # not really applicable for sandbox data
    silver_database="it_finance_sandbox3_silver",
    gold_database="it_usage_sandbox3_gold",
    usage_s3_bucket="usage-data-upload-dev-bucket",
    usage_s3_access_key_secret="usage-extract-s3-access-key-sandbox",
    usage_s3_secret_key_secret="usage-extract-s3-secret-key-sandbox",
    usage_extraction_folder="sandbox3/unprocessed",
    workspace_extraction_folder="sandbox3/workspaceList/unprocessed",
    secret_scope="netsuite-integration",
)


# COMMAND ----------

class Protocol(Enum):
    NETSUITE_1 = 1
    NETSUITE_2 = 2

# COMMAND ----------

CONFIGS = {
    "production": PRODUCTION,
    "prod_staging": PRODUCTION_STAGING,
    "sandbox": SANDBOX,
    "sandbox1": SANDBOX, # alias
    "sandbox2": SANDBOX2,
    "sandbox3": SANDBOX3,
}

def valid_configurations() -> Tuple[Seq[str], str]:
    return (sorted(CONFIGS.keys()), "sandbox")

def get_configuration(key: str) -> Configuration:
    return CONFIGS[key]

# COMMAND ----------

JDBC_DRIVER = "com.netsuite.jdbc.openaccess.OpenAccessDriver"

# COMMAND ----------

GOLD_USAGE_EXTRACT_TABLE = 'usage_extract'
GOLD_WORKSPACE_LIST_TABLE = 'workspaces'

#S3_EXPORT_URL = f's3a://{usage_extract_s3_access_key}:{usage_extract_s3_secret_key}@{CONFIG.usage_s3_bucket}'

#S3_USAGE_EXTRACTION_FOLDER = f'{S3_EXPORT_URL}/{CONFIG.usage_extraction_folder}'
#S3_WORKSPACE_EXTRACTION_FOLDER = f'{S3_EXPORT_URL}/{CONFIG.workspace_extraction_folder}'

# COMMAND ----------

METADATA_PROCESS_DATE_COLUMN = 'processDate' # naming is consistent with push from SalesForce
METADATA_PROCESS_TIMESTAMP_COLUMN = 'processTimestamp'
BRONZE_METADATA_SOURCE_TABLE_COLUMN = 'sourceNetsuiteTable'

BRONZE_METADATA_COLUMNS = (
    METADATA_PROCESS_DATE_COLUMN,
    BRONZE_METADATA_SOURCE_TABLE_COLUMN,
)

# COMMAND ----------

def read_netsuite_table_into_df(
    table_name: str, 
    protocol: Protocol,
    config: Configuration,
    logger: Optional[logging.Logger] = None
) -> DataFrame:
    """
    Open a JDBC-based DataFrame that points to a NetSuite table. Assumes that the
    global variables url, user, and password have already been set.

    Parameters:

    table_name - the name of the NetSuite table
    protocol   - which NetSuite protocol to use
    config     - the configuration to use
    logger     - Optional logger object to which to log debug messages
    """
    match protocol:
        case Protocol.NETSUITE_1:
            data_source = "NetSuite.com"
            role_id = config.netsuite_1_role_id
        case Protocol.NETSUITE_2:
            data_source = "NetSuite2.com"
            role_id = config.netsuite_2_role_id

    url = (f"jdbc:ns://{config.hostname}:1708;ServerDataSource={data_source};Encrypted=1;"
           f"NegotiateSSLClose=false;CustomProperties=(AccountID={config.account_id};RoleID={role_id})")
    if logger is not None:
        logger.debug(f"Loading table {table_name} into DataFrame, using URL {url}")
    user = dbutils.secrets.get(config.secret_scope, config.user_key)
    password = dbutils.secrets.get(config.secret_scope, config.password_key)
    return spark.read.jdbc(url, table_name,
                           properties={"user": user, "password": password, "driver": JDBC_DRIVER})



# COMMAND ----------

def get_s3_import_export_url(config: Configuration) -> str:
    """
    Using the supplied configuration, construct and
    return the S3 URL to which we export usage records
    and from which we import updated records.
    """
    usage_extract_s3_access_key = dbutils.secrets.get(config.secret_scope, config.usage_s3_access_key_secret)
    usage_extract_s3_secret_key = dbutils.secrets.get(config.secret_scope, config.usage_s3_secret_key_secret)    
    return f's3a://{usage_extract_s3_access_key}:{usage_extract_s3_secret_key}@{config.usage_s3_bucket}'

# COMMAND ----------

def get_process_date() -> date:
    """
    Get the process date (which is added as a metadata column to all bronze 
    and silver tables.)
    """
    return datetime.utcnow().date()

def add_bronze_metadata(
    df: DataFrame,
    netsuite_table_name: str,
    process_date: Optional[datetime.date] = None
) -> Tuple[DataFrame, datetime.date]:
    """
    Add desired bronze metadata to a NetSuite table DataFrame, prior to writing it
    to the Delta bronze table. Only suitable for use with tables that are
    partitioned by processDate. For tables partitioned by processTimestamp,
    use add_bronze_metadata_for_timestamp().
    
    Returns a (DataFrame, processDate) tuple
    """
    now = process_date or get_process_date()
    df2 = (df
        .withColumn(METADATA_PROCESS_DATE_COLUMN, F.lit(now))
        .withColumn(BRONZE_METADATA_SOURCE_TABLE_COLUMN, F.lit(netsuite_table_name))
    )
    return (df2, now)

def add_bronze_metadata_for_timestamp(
    df: DataFrame,
    netsuite_table_name: str
) -> Tuple[DataFrame, datetime]:
    """
    Add desired bronze metadata to a NetSuite table DataFrame, prior to writing it
    to the Delta bronze table. Only suitable for use with tables that are
    partitioned by processTimestamp. For tables partitioned by processDate,
    use add_bronze_metadata().

    Note that the timestamp is (deliberately) only granular to the second.
    
    Returns a (DataFrame, processTimestamp) tuple
    """   
    now = datetime.utcnow().replace(microsecond=0)
    df2 = (df
        .withColumn(METADATA_PROCESS_TIMESTAMP_COLUMN, F.lit(now))
        .withColumn(BRONZE_METADATA_SOURCE_TABLE_COLUMN, F.lit(netsuite_table_name))
    )
    return (df2, now)

def add_silver_metadata(df: DataFrame, process_date: Optional[date] = None) -> Tuple[DataFrame, datetime]:
    """
    Add desired silver metadata to a source DataFrame, prior to writing it
    to the Delta silver table.
    """
    pd = process_date or get_process_date()
    return (df.withColumn(METADATA_PROCESS_DATE_COLUMN, F.lit(pd)), pd)

def format_sql_date(the_date: date) -> str:
    """
    Format a Python date into a string suitable for use in a SQL
    statement. Does not add the quotes.
    """
    return the_date.strftime('%Y-%m-%d')

def format_sql_timestamp(ts: datetime) -> str:
    """
    Format a Python datetime into a string suitable for use in a
    SQL query. The datetime is assumed to be in the UTC timezone.
    Returns a string of the form "yyyy-mm-dd HH:MM:SS" (e.g.,
    "2024-01-01 13:01:03". The result is granular to the second.
    """
    #return ts.strftime('%Y-%m-%dT%H:%M:%SZ')
    return ts.isoformat(sep=' ', timespec='seconds')

def get_log_path(pipeline: str, catalog: str, schema: str) -> str:
    """
    Given a pipeline name, a catalog name, and a schema name,
    return the path to the log file to use for a current run of
    the pipeline. This string is suitable for passing to the
    it_data_lib.configure_logging() function, as the "path"
    argument.

    The function assumes that every schema contains a volume
    called "logs".
    """
    # The log file name is of the form:
    #
    # <pipeline>_<yymmdd_HHMM_UTC>.log
    #
    # Seconds granularity in the log file name isn't
    # necessary or useful.
    now = datetime.utcnow()
    for c in "-. ":
        pipeline = pipeline.replace(c, "_")
    s_timestamp = now.strftime('%Y%m%d_%H%M_UTC')
    volume_path = f"/Volumes/{catalog}/{schema}/logs"
    return f"{volume_path}/{pipeline}_{s_timestamp}.log"

# COMMAND ----------

# Verify that we can load the JDBC driver. The OA_FKEYS table is a special
# pseudo-table provided by the JDBC driver. If we can't load it into a
# DataFrame, there's a problem, and we might as well find out quickly.
# It doesn't matter which configuration we use here, since we're not doing
# anything with the returned DataFrame.
# read_netsuite_table_into_df("OA_FKEYS", Protocol.NETSUITE_1, PRODUCTION)

# COMMAND ----------

# Load up all the primary key columns in NetSuite. Some tables will have
# multiple columns forming the primary key.
#
# Validation of this approach:
# https://media.datadirect.com/download/docs/openaccess/alloa/index.html#page/programguide%2Fforeign-keys-catalog-table-oa-fkeys.html%23
#
# Foreign keys catalog table OA_FKEYS
#
# The OA_FKEYS table contains information about foreign keys referenced by each
# table and the primary keys in each table. Each row identifies one primary key
# in a table and an associated foreign key or primary key. At this time the
# OpenAccess SDK SQL engine requires only the columns marked with an asterisk to
# be filled in. The foreign keys information is exposed through the
# SQLForeignKeys ODBC call. A row is considered a primary key definition if the
# FKTABLE_NAME column is NULL. The primary keys information is exposed through
# the SQLPrimaryKeys ODBC call.

def get_primary_keys(table_name: str, use_netsuite2: bool, config: Configuration) -> Sequence[str]:
    prot = Protocol.NETSUITE_2 if use_netsuite2 else Protocol.NETSUITE_1
    df = read_netsuite_table_into_df(
        table_name='OA_FKEYS',
        protocol=prot,
        config=config,
        logger=None
    )
    keys = (df
        .filter(F.col('FKTABLE_NAME').isNull())
        .filter(F.lower('PKTABLE_NAME') == table_name.lower())
        .select(F.col('PKCOLUMN_NAME').alias('primary_key'))
        .collect()
    )
    res: Sequence[str] = []
    for row in keys:
        res.append(row.primary_key)

    return res

# COMMAND ----------

from functools import total_ordering

@total_ordering
@dataclass
class TableConfig:
    """
    An instance of this data class defines a single NetSuite table
    to be downloaded.
    
    Fields:
    
    netsuite_table_name:   The name of the NetSuite table. This name is
                           converted to lower case to derive the name of
                           the target Delta table.
    last_modified_column:  Name of the last modified column for the table,
                           or None.
    adjust_dataframe:      An optional function that, if defined, will
                           be called to transform the NetSuite DataFrame
                           before it is written to the Delta table.
    override_primary_keys: Normally, the table's primary keys are determined
                           via a lookup against the table_primary_keys dict
                           initialized above. To override the primary keys
                           manually (i.e., to use other columns for uniqueness
                           checks during Delta merges), supply this argument.
                           It must be a list of column names.
    use_netsuite2:         Use the NetSuite2 protocol, instead of the older
                           NetSuite protocol. Defaults to False.
    rename_to:             If not None, defines the name the downloaded table
                           should have in Central Logfood. If None, the name
                           of the NetSuite table (lowercased) will be used.

    Methods:
    
    primary_keys: Returns a list of primary key columns for the table,
                  or None if there are none.
    """
    netsuite_table_name: str
    last_modified_column: str | list[str] | None
    partition_column: Optional[str] = field(default=None)
    override_primary_keys: Optional[Sequence[str]] = field(default=None)
    adjust_dataframe: Optional[Callable[[DataFrame], DataFrame]] = field(default=None)
    use_netsuite2: bool = field(default=False)
    rename_to: Optional[str] = field(default=None)

    def __post_init__(self):
        self._primary_keys = None

    def last_modified_columns(self) -> list[str] | None:
        if self.last_modified_column is None:
            return None
        if type(self.last_modified_column) is str:
            return [self.last_modified_column]
        if type(self.last_modified_column) is list:
            return None if len(self.last_modified_column) == 0 else self.last_modified_column
        raise TypeError(f"Invalid type of {type(self.last_modified_column)} for "
                        f"{self.netsuite_table_name} last_modified_column value.")

    def primary_keys(self, config: Configuration) -> Optional[Sequence[str]]:
        if self.override_primary_keys is not None:
            return self.override_primary_keys
        elif self._primary_keys is not None:
            return self._primary_keys
        else:
            self._primary_keys = get_primary_keys(self.netsuite_table_name,
                                                  self.use_netsuite2,
                                                  config)
            return self._primary_keys
        
    def __hash__(self) -> int:
        """
        Permits storing in a set or a dict (as a key).
        """
        return self.netsuite_table_name.lower().__hash__()
    
    def __eq__(self, other: 'TableConfig') -> bool:
        """
        Checks equivalence based solely on table name.
        Useful for sorting lists of TableConfig objects.
        Note that this method only checks the table name, not
        any other attributes of the TableConfig object.
        """
        return self.netsuite_table_name.lower() == other.netsuite_table_name.lower()
    
    def __lt__(self, other: 'TableConfig') -> bool:
        return self.netsuite_table_name.lower() < other.netsuite_table_name.lower()

# COMMAND ----------

# DBTITLE 1,Data Integrity Check
class DataIntegrityError(Exception):
    "Check when the delta table was not updated correctly"
    pass

class NoLastUpdateTimestampError(Exception):
    """
    Thrown by the incremental download function to indicate
    that no non-NULL last update timestamp value was found,
    and that a full download should be attempted, instead.
    """
    pass

def schemas_match(netsuite_df: DataFrame, delta_df: DataFrame, logger: logging.Logger) -> bool:
    """
    Determine whether the schema for a NetSuite-sourced DataFrame
    matches the schema for a Delta DataFrame.

    Note that this code isn't checking for an exact match, because
    that's too rigid. It's always possible for a Delta file to have
    more columns than its NetSuite counterpart, because of schema
    migration. All we really care about is whether there are columns
    in the NetSuite data that are not present in the Delta table.
    That's the condition this function tests, and it returns False if
    there are any columns in the NetSuite data frame that are not
    present in the Delta DataFrame.

    Note that the function only checks column names. If types change,
    the Delta schema migration code will either handle it (if it can)
    or abort because it can't. That's true whether we do a full
    download or an incremental download.
    """
    def schema_names(df: DataFrame) -> set[str]:
        return set([s.lower() for s in df.schema.fieldNames()])

    ns_col_names = schema_names(netsuite_df)
    delta_col_names = schema_names(delta_df)

    # Do a set difference, with NetSuite on the left.
    ns_extra_cols = ns_col_names - delta_col_names

    if len(ns_extra_cols) > 0:
        logger.debug(f"There are new columns in the NetSuite schema: {', '.join(ns_extra_cols)}")
        return False
    else:
        logger.debug("There are no new columns in the NetSuite schema.")
        return True

def check_data_integrity(
    table_data: TableConfig,
    incoming_df: DataFrame,
    partition_column: Union[datetime, date],
    full_table_name: str,
    config: Configuration,
    logger: logging.Logger,
) -> None:
    """
    Used with incremental downloading, this function ensures that
    the downloaded data passes some basic integrity checks.
    """
    # We're no longer checking the row count or the primary keys, because
    # doing those properly requires checking the source DataFrame that points
    # directly to the NetSuite table via JDBC. With some tables, the chances
    # of the data changing in NetSuite between the time we do the download
    # and the time we do these checks is surprisingly high. Example:
    #
    # 1. There are 1,000 rows in the NetSuite table at the create the DataFrame.
    # 2. 200 of those rows are changed from the previous download.
    # 3. We download the 200 and merge them into our Delta table.
    # 4. While we're downloading and merging, someone adds 5 new rows to the 
    #    source table.
    # 5. We finish merging and compare the row count in the table with the
    #    row count in NetSuite DataFrame. There are 1,000 rows in the Delta
    #    table, but 1,005 in the NetSuite DataFrame.
    # 6. Integrity check fails, and we back off to a slower full download.
    #
    # With a huge table (like TRANSACTIONS), this dramatically changes the
    # download time. The same failure can occur with the primary key check.
    # This problem is also theoretically possible with the schema check,
    # but it's less likely, especially since we do a schema check up front,
    # as well.
    #
    # For now, we're simply not checking row counts or primary keys.

    delta_table_df = spark.table(full_table_name)
    if type(partition_column) == date:
        delta_table_partitioned_df = delta_table_df.filter(F.col("processDate") == partition_column)
    elif type(partition_column == datetime):
        delta_table_partitioned_df = delta_table_df.filter(F.col("processTimestamp") == partition_column) 
    else:
        raise Exception(f"Invalid partition column type: {type(partition_column)}")

    # logger.debug("Row count check")
    # incoming_count = incoming_df.count()
    # table_row_count = delta_table_partitioned_df.count()
    # if incoming_count != table_row_count:
    #     raise DataIntegrityError(
    #         f"Incoming data row count {incoming_count} does not match: "
    #         f"{full_table_name} row count {table_row_count}"
    #     )

    # logger.debug("Primary key check")
    # pk = table_data.primary_keys(config)
    # jdbc_keys = incoming_df.select(pk)
    # delta_keys = delta_table_partitioned_df.select(pk)
    # keys_comparison_count = delta_keys.exceptAll(jdbc_keys).count()
    # if keys_comparison_count != 0:
    #     raise DataIntegrityError(f"Primary Keys do not match: {keys_comparison_count=}")

    logger.debug("Schema check")
    if not schemas_match(netsuite_df=incoming_df, delta_df=delta_table_df, logger=logger):
        raise DataIntegrityError(
            f"Schemas differ between NetSuite table and Delta table: {full_table_name}"
        )

    logger.debug(f"All data quality checks passed for {full_table_name}")

# COMMAND ----------

def get_staging_dir(catalog: str, target_schema: str) -> str:
    """
    Given a catalog and a target schema, return the location
    of the staging directory.
    """
    return f"dbfs:/Volumes/{catalog}/{target_schema}/staging"

def download_and_stage(netsuite_df: DataFrame,
                       table_name: str,
                       staging_path: str,
                       logger: logging.Logger
) -> DataFrame:
    """
    Download the contents of a NetSuite DataFrame and stage the data
    in the staging area.

    Parameters:

    netsuite_df  - the DataFrame to download and stage
    table_name   - the simple table name associated with the DataFrame (no catalog or schema)
    staging_path - path to the staging directory (with "dbfs:" prefix)

    Returns a new DataFrame pointing to the staged data
    """
    staging_delta_file = f"{staging_path}/{table_name}.delta"
    dbutils.fs.mkdirs(staging_path)
    logger.debug(f"Staging {table_name} data to {staging_delta_file}")
    if dbfs_file_exists(staging_path, f"{table_name}.delta", dbutils):
        logger.debug(f"Deleting existing staging data {staging_delta_file}")
        dbutils.fs.rm(staging_delta_file, recurse=True)
  
    logger.debug(f"Writing data to {staging_delta_file}")
    netsuite_df.write.format("delta").save(staging_delta_file)
    logger.debug("Write complete")
    return spark.read.format("delta").load(staging_delta_file)


# COMMAND ----------

def load_bronze_data_full_download(
    table_data: TableConfig,
    netsuite_df: DataFrame,
    partition_value: Union[date, datetime],
    table_name: str,
    config: Configuration,
    target_database: str,
    logger: logging.Logger,
    sql: Callable[[str], DataFrame],
) -> None:
    """
    Download the contents of a table from NetSuite, overwriting the specified Delta table name.
    Assumes that "url", "user", and "password" have been set and are globally available.

    Parameters:

    netsuite_df:     the DataFrame that's pointing to the NetSuite table to be downloaded,
                     with appropriate metadata columns (e.g., processDate, source table) added
    partition_value: Can be of type date or datetime, and is used to partition the data. The
                     appropriate column (named METADATA_PROCESS_DATE_COLUMN or METADATA_PROCESS_TIMESTAMP_COLUMN)
                     is assumed to be in the DataFrame already
    table_name:      the simple name of the Delta table to receive the data (no schema)
    config:          the configuration to use
    target_database: the target database for the final table. Usually, this is either
                     config.bronze_database or config.bronze_hourly_database
    logger:          where to log messages
    sql:             function to issue SQL statements (e.g. from make_sql())
    """
    assert type(partition_value) in (date, datetime), f"Partition column type ({type(partition_value)}) is not a date or datetime"
    full_table_name = f"{config.uc_catalog}.{target_database}.{table_name}"
    ns_table = table_data.netsuite_table_name
    if type(partition_value) == date:
        partition_column = METADATA_PROCESS_DATE_COLUMN
        partition_str = format_sql_date(partition_value)
    else:
        partition_column = METADATA_PROCESS_TIMESTAMP_COLUMN
        partition_str = format_sql_timestamp(partition_value)

    logger.info(f"Doing full download of {ns_table} for {partition_column} {partition_str}")
    temp_view_name = f"{ns_table.lower()}_temp_view"
    logger.debug(f"Creating temporary view {temp_view_name} from NetSuite table {ns_table}")
    table_already_exists = table_exists(
        schema_name=target_database,
        table_name=table_name,
        spark=spark,
        logger=logger,
        catalog=config.uc_catalog
    )
    if table_already_exists:
        logger.debug(f"{full_table_name} already exists.")
        logger.info(f"Deleting any data for {partition_column} {partition_str}")
        sql(f"DELETE FROM {full_table_name} WHERE {partition_column} = '{partition_str}'")

    staged_df = download_and_stage(
        netsuite_df=netsuite_df,
        table_name=table_name,
        staging_path=get_staging_dir(catalog=config.uc_catalog, target_schema=target_database),
        logger=logger
    )

    logger.info(f"Writing new data to {full_table_name}.")
    columns = sorted([c.lower() for c in staged_df.columns])
    assert partition_column.lower() in columns
    total_rows = staged_df.count()
    logger.debug(f"Writing {total_rows} rows to {full_table_name}.")
    (
        staged_df
            .write
            .format('delta')
            .mode('overwrite')
            .option('mergeSchema', 'true')
            .option('replaceWhere', f"{partition_column} = '{partition_str}'")
            .saveAsTable(full_table_name)
    )
    logger.info(f"Write to {full_table_name} complete.")

# COMMAND ----------

# DBTITLE 1,Incremental Download
def load_bronze_data_incremental_download(
    table_data: TableConfig,
    last_modified_column: str,
    netsuite_df: DataFrame,
    partition_value: Union[date, datetime],
    table_name: str,
    config: Configuration,
    target_database: str,
    logger: logging.Logger,
    sql: Callable[[str], DataFrame]
) -> None:
    """
    Performs an incremental download for a table that has a last modified
    column.

    Parameters:

    table_data:             the TableConfig object for the table to be downloaded
    last_modified_column:   Previously determined last modified column to use
    netsuite_df:            the DataFrame that's pointing to the NetSuite table to be downloaded,
                            with appropriate metadata columns (e.g., processDate, source table) added
    partition_value:        Can be of type date or datetime, and is used to partition the data. The
                            appropriate column (named METADATA_PROCESS_DATE_COLUMN or METADATA_PROCESS_TIMESTAMP_COLUMN)
                            is assumed to be in the DataFrame already
    table_name:             the simple name of the Delta table to receive the data (no schema)
    config:                 the configuration to use
    target_database:        the target database for the final table. Usually, this is either
                            config.bronze_database or config.bronze_hourly_database
    logger:                 where to log messages
    sql:                    function to issue SQL statements (e.g. from make_sql())
    """
    assert type(partition_value) in (date, datetime), f"Partition column type ({type(partition_value)}) is not a date or datetime"

    if type(partition_value) == date:
        partition_str = format_sql_date(partition_value)
        partition_column = METADATA_PROCESS_DATE_COLUMN
    else:
        partition_str = format_sql_timestamp(partition_value)
        partition_column = METADATA_PROCESS_TIMESTAMP_COLUMN

    def possibly_delete_records(netsuite_table_df: DataFrame,
                                delta_table_df: DataFrame) -> None:
        """
        Compare the passed-in DataFrames, one pointing to the Delta table
        (filtered by a specific process date or timestamp), the other pointing at the
        corresponding NetSuite source table, looking for deleted records.
        Deletes any that are found.

        Parameters:

        netsuite_table_df: DataFrame pointing to incoming NetSuite data
        delta_table_df:    DataFrame pointing to a specific processDate
                           partition of the corresponding Delta table
        """
        pk = table_data.primary_keys(config)
        delta_primary_keys = delta_table_df.select(pk)
        netsuite_primary_keys = netsuite_table_df.select(pk)
        deleted_records_df = delta_primary_keys.exceptAll(netsuite_primary_keys)
        total_deleted_records = deleted_records_df.count()        
        if total_deleted_records == 0:
            logger.debug(f"No records to be deleted from Delta table.")
        else:
            deleted_records_df.createOrReplaceTempView("deleted_records")
            where_conditions = [
                f"{full_table_name}.{col_name} = deleted_records.{col_name}"
                for col_name in pk
            ]
            deletes_where_clause = " AND ".join(where_conditions)
            primary_keys_str = ", ".join(pk)

            logger.debug(f"Deleting {total_deleted_records} row(s) from {full_table_name}")
            sql(f"""
              DELETE FROM {full_table_name} 
              WHERE EXISTS (
                SELECT {primary_keys_str} FROM deleted_records
                WHERE {full_table_name}.{partition_column} = '{partition_str}'
                AND {deletes_where_clause}
              )
              """
            )

    def filter_deleted_records(
        netsuite_table_df: DataFrame,
        delta_table_df: DataFrame,
        previous_partition_value: Union[date, datetime]
    ) -> DataFrame:
        """
        Given a NetSuite DataFrame and a DataFrame pointing
        to the corresponding Delta table, find deleted records
        and filter them out of the NetSuite (incoming) DataFrame.

        Parameters:

        netsuite_table_df:        DataFrame pointing to the incoming NetSuite table
        delta_table_df:           DataFrame pointing to the corresponding Delta table,
                                  WITH NO FILTERS APPLIED.
        previous_partition_value: The process date or process timestamp in the Delta
                                  table from which deleted records should be filtered

        Returns an updated Delta DataFrame that does not contain any
        records that have been deleted from the NetSuite data, and that also
        has a properly updated processDate column.
        """
        # In this case, we're not actually deleting anything from the Delta table.
        # Instead, we're filtering out the deleted records before copying the data
        # from the previous process date to the current process date.
        previous_partition_df = (
            delta_table_df
                .filter(F.col(partition_column) == previous_partition_value)
        )

        pk = table_data.primary_keys(config)

        # Find the deleted records.
        delta_primary_keys = previous_partition_df.select(pk)
        netsuite_primary_keys = netsuite_table_df.select(pk)
        deleted_records_df = delta_primary_keys.exceptAll(netsuite_primary_keys)
        total_deleted_records = deleted_records_df.count()

        if total_deleted_records == 0:
            logger.debug(f"No records to be deleted.")
            data_to_copy = previous_partition_df
        else:
            # Filter out deleted records.
            logger.debug(f"Filtering out {total_deleted_records:,} deleted records")
            data_to_copy = previous_partition_df.join(
                deleted_records_df, on=pk, how="left_anti"
            )

        # Update processDate to today.
        return data_to_copy
    
    def download_and_stage_incremental_data(netsuite_df: DataFrame) -> DataFrame:
        return download_and_stage(
            netsuite_df=netsuite_df,
            table_name=table_name,
            staging_path=get_staging_dir(catalog=config.uc_catalog, target_schema=target_database),
            logger=logger
        )

    full_table_name = f"{config.uc_catalog}.{target_database}.{table_name}"
    ns_table = table_data.netsuite_table_name
    logger.info(f"Doing incremental download of {ns_table} for {partition_column} {partition_str}")
    delta_table_df = spark.table(full_table_name)
    total_existing_partition_rows = (
      delta_table_df
          .filter(F.col(partition_column) == partition_value)
          .count()
    )

    if total_existing_partition_rows > 0:
        # Load current processDate.
        logger.debug(f"Data for {partition_column} {partition_str} "
                     "already exists. Loading existing data.")
        current_data = (
          spark
              .table(full_table_name)
              .filter(F.col(partition_column) == partition_value)
        )
        possibly_delete_records(
          netsuite_table_df=netsuite_df,
          delta_table_df=current_data
        )
        # At this point, we have some data in the current partition,
        # though we might be missing some recently inserted and updated
        # records in the NetSuite data. However, we *have* just deleted
        # deleted any records from the current partition that no longer
        # exist in NetSuite. We're ready to merge NetSuite data in.
    else:
        # Load previous processDate.

        previous_partition_value = (
            delta_table_df
                .select(F.max(partition_column).alias("max_partition_value"))
                .first()["max_partition_value"]
        )
        if type(partition_value) == date:
            prev_partition_str = format_sql_date(previous_partition_value)
        else:
            prev_partition_str = format_sql_timestamp(previous_partition_value)

        logger.debug(
            f"There is no data for {partition_column} {partition_str}. "
            f"Copying data from {prev_partition_str} to {partition_str}, "
            f"except for any deleted rows."
        )

        current_data = filter_deleted_records(
          previous_partition_value=previous_partition_value,
          netsuite_table_df=netsuite_df,
          delta_table_df=delta_table_df
        )

        # Copy modified data into new processDate.
        current_data = (current_data
                .drop(partition_column)
                .withColumn(partition_column, F.lit(partition_value))
        )
        logger.info(f"Updating data in {full_table_name} for {partition_column} {partition_str}")
        (
            current_data
                .write
                .mode("overwrite")
                .format("delta")
                .option("mergeSchema", "true")
                .option("replaceWhere", f"{partition_column} = '{partition_str}'")
                .saveAsTable(full_table_name)
        )
        logger.info(f"Update of {full_table_name} complete for {partition_column} {partition_str}")

        # At this point, we've just copied the most recent partition's data
        # into the current partition, skipping any records that have been deleted
        # from NetSuite. Now we're ready to mere the NetSuite data in.          

    # Determine the set of changed records. Start with the most recent last-modified
    # date in the Delta table.
    logger.debug(f"Loading largest last-modified timestamp for {full_table_name}")
    greatest_timestamp = (
        current_data
            .select(F.max(last_modified_column).alias("last_modified"))
            .first()["last_modified"]
    )
    
    if greatest_timestamp is None:
        raise NoLastUpdateTimestampError(
            f"No non-NULL {last_modified_column} values found in {full_table_name}"
        )

    # Add a small buffer to account for possible time skew.
    query_timestamp = greatest_timestamp - timedelta(hours=2)

    logger.debug(f"Looking for records in {table_data.netsuite_table_name} "
                 f"with a {last_modified_column} value newer than "
                 f"{query_timestamp.strftime('%Y-%m-%d %H:%M:%S')}")

    # Now, find all records in the NetSuite data that are newer than that.
    changed_records = netsuite_df.filter(F.col(last_modified_column) >= query_timestamp)

    if changed_records.count() == 0:
        logger.info(f"No new records found in {table_data.netsuite_table_name}")
    else:
        staged_changes = download_and_stage_incremental_data(changed_records)
        staged_changes.createOrReplaceTempView("changed_records")
        on_conditions = [
            f"{full_table_name}.{col_name} = changed_records.{col_name}"
            for col_name in table_data.primary_keys(config)
        ]
        on_clause = " AND ".join(on_conditions)

        logger.debug(
            f"Merging {changed_records.count()} changed records into {full_table_name}"
        )

        sql(f"""
            MERGE INTO {full_table_name} 
            USING changed_records
            ON {full_table_name}.{partition_column} = changed_records.{partition_column} 
            AND {on_clause}
            WHEN MATCHED THEN
            UPDATE SET * 
            WHEN NOT MATCHED THEN
            INSERT *
            """
        )
        logger.debug(f"Merge complete")

    # Check if delta table was updated correctly.
    logger.info(f"Checking data integrity for {table_data.netsuite_table_name}")
    check_data_integrity(
        table_data=table_data,
        incoming_df=netsuite_df,
        partition_column=partition_value,
        full_table_name=full_table_name,
        config=config,
        logger=logger
    )

# COMMAND ----------

# DBTITLE 1,Main Load Function
def find_last_modified_column(
    table_data: TableConfig,
    table_df: DataFrame
) -> str | None:
    """
    Given an open DataFrame to a NetSuite table, plus the
    configuration data for the table, find the last modified
    column to use, if any.
    """
    lm_cols = table_data.last_modified_columns()
    if lm_cols is None:
        return None
    table_columns = [c.lower() for c in table_df.columns]
    for candidate_col in lm_cols:
        if candidate_col.lower() in table_columns:
            return candidate_col
        
    return None

def set_clustering_for_table(
    full_table_name: str,
    cluster_column: str,
    logger: logging.Logger
) -> None:
    """
    Alters the specified table to cluster by the specified column, using
    Databricks Delta liquid clustering. We're only clustering by one
    column, and it should be either processDate or processTimestamp,
    depending on the table. If the table is already partitioned, then
    this function simply refuses to do anything, since liquid clustering
    is not supported on a partitioned table.
    """
    def table_is_partitioned() -> bool:
        # SHOW PARTITIONS fails with an exception if the
        # table doesn't have partitions.
        try:
            spark.sql(f"show partitions {full_table_name}")
            return True
        except Exception as e:
            logger.debug(f"Attempt to check for partitioning failed with {e}. (May not be an error.)")
            if "not partitioned" in str(e):
                logger.debug(f"{full_table_name} is not partitioned.")
                return False
            else:
                raise


    # First, determine whether the table is partitioned. If it is,
    # do nothing.
    if table_is_partitioned():
        logger.info(f"{full_table_name} is already partitioned. Skipping clustering.")
        return

    logger.info(f"{full_table_name} is not partitioned. Adding liquid clustering.")

    # Ensure that liquid clustering is enabled on the partition column. See
    # https://docs.databricks.com/delta/optimizations/clustering.html
    # for details on liquid clustering. Note that clustering only works on
    # columns for which Databricks collects statistics, and Databricks only
    # collects statistics for the first 32 columns in a table. By setting
    # the following table property, we're overriding that limit.
    logger.debug(f"Getting list of columns for {full_table_name}")
    columns = [r.col_name for r in sql(f"DESCRIBE {full_table_name}").select("col_name").collect()]
    total_columns = len(columns)
    logger.debug(f"{full_table_name} has {total_columns} columns")
    sql(f"ALTER TABLE {full_table_name} SET TBLPROPERTIES(delta.dataSkippingNumIndexedCols = {len(columns)})")
    sql(f"ALTER TABLE {full_table_name} CLUSTER BY ({cluster_column})")
    sql(f"OPTIMIZE {full_table_name}")


def load_bronze_data(
    table_data: TableConfig, 
    target_database: str,
    config: Configuration,
    logger: logging.Logger,
    sql: Callable[[str], DataFrame],
    partition_by_timestamp: bool = False,
    recreate: bool = False
) -> None:
    """
    Download the contents of a table from NetSuite, overwriting the specified Delta table name.
    Assumes that "url", "user", and "password" have been set and are globally available.
    
    Parameters:
    
    table_data:             The TableConfig object for the table to be downloaded
    target_database:        The Metastore database to contain the target table
    config:                 The configuration to use
    logger:                 Where to log data
    sql:                    function to issue SQL statements (e.g. from make_sql())
    partition_by_timestamp: whether to partition by a timestamp (True) or a date (False).
                            This is passed in, rather than configured in the TableConfig,
                            to allow it to be controlled by the job. That way, some tables
                            can be downloaded into one schema with processDate partitions
                            and into the hourly schema with processTimestamp partitions.
    recreate:               If True, delete and recreate the table and Delta file
    """
    # Ensure that schema merges happen properly.
    spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

    # Load the NetSuite table into a DataFrame, and optionally adjust it.
    logger.debug(f'Loading {table_data.netsuite_table_name} into DataFrame.')
    if table_data.use_netsuite2:
        protocol = Protocol.NETSUITE_2
    else:
        protocol = Protocol.NETSUITE_1

    df = read_netsuite_table_into_df(table_data.netsuite_table_name, 
                                     protocol=protocol, 
                                     config=config,
                                     logger=logger)
    
    if table_data.adjust_dataframe is not None:
        logger.debug(f"Filtering table with {table_data.adjust_dataframe.__name__}")
        df = table_data.adjust_dataframe(df)

    if df.count() == 0:
        logger.info(f'Source table {table_data.netsuite_table_name} is empty. Skipping')
        return

    partition_value: Optional[Union[datetime, date]] = None

    # Add metadata columns.
    if partition_by_timestamp:
        partition_column = METADATA_PROCESS_TIMESTAMP_COLUMN
        final_df, partition_value = add_bronze_metadata_for_timestamp(df, table_data.netsuite_table_name)
    else:
        partition_column = METADATA_PROCESS_DATE_COLUMN
        final_df, partition_value = add_bronze_metadata(df, table_data.netsuite_table_name)

    if table_data.rename_to is not None:
        target_table_name = table_data.rename_to
    else:
        target_table_name = table_data.netsuite_table_name.lower()

    full_table_name = f'{config.uc_catalog}.{target_database}.{target_table_name}'

    logger.info(f"Downloading {table_data.netsuite_table_name} and "
                f"writing it to {full_table_name}")

    if recreate:
        sql(f'DROP TABLE IF EXISTS {full_table_name}')

    full: bool = False
    last_modified_column = find_last_modified_column(table_data=table_data, table_df=final_df)
    exists = table_exists(
        catalog=config.uc_catalog,
        schema_name=target_database,
        table_name=target_table_name,
        spark=spark,
        logger=logger
    )
    logger.debug(f"{full_table_name} exist? {exists}")
    if not exists:
        logger.info(f"{full_table_name} does not exist. Full download required.")
        full = True
    elif last_modified_column is None:
        logger.debug(f"{table_data.netsuite_table_name} does not have a last modified column. "
                     "Forcing full download.")
        full = True
    elif not schemas_match(netsuite_df=final_df, delta_df=spark.table(full_table_name), logger=logger):
        logger.debug(f"The JDBC schema and the Delta schema are too different for {full_table_name}. "
                     "Forcing full download.")
        full = True
    else:
        logger.debug(f"Using last modified column {last_modified_column} for incremental download of "
                     f"{table_data.netsuite_table_name}")
        full = False

    if full:
        load_bronze_data_full_download(
            table_data=table_data,
            netsuite_df=final_df,
            partition_value=partition_value,
            table_name=target_table_name,
            config=config,
            target_database=target_database,
            logger=logger,
            sql=sql            
        )
    else:
        try:
            load_bronze_data_incremental_download(
                table_data=table_data,
                last_modified_column=last_modified_column,
                netsuite_df=final_df,
                partition_value=partition_value,
                table_name=target_table_name,
                config=config,
                target_database=target_database,
                logger=logger,
                sql=sql                
            )
        except (NoLastUpdateTimestampError, DataIntegrityError) as e:
            logger.error(f"Recoverable exception for incremental download of "
                         f"{table_data.netsuite_table_name}: {e}")
            logger.error(f"Falling back to full download.")
            load_bronze_data_full_download(
                table_data=table_data,
                netsuite_df=final_df,
                partition_value=partition_value,
                table_name=target_table_name,
                config=config,
                target_database=target_database,
                logger=logger,
                sql=sql            
            )

    # Now that the table exists, enforce liquid clustering.
    set_clustering_for_table(
        full_table_name=full_table_name,
        cluster_column=partition_column,
        logger=logger
    )


# COMMAND ----------

# TODO: Migrate all bronze notebooks to use this function, instead
# of doing it inline.
def load_bronze_with_retries(tables: Sequence[TableConfig],
                             config: Configuration,
                             logger: logging.Logger,
                             sql: Callable[[str], DataFrame],
                             target_database: Optional[str] = None,
                             partition_by_timestamp: bool = False,
                             max_retries: int = 3,
                             recreate: bool = False) -> None:
    """
    Download the tables in the specified list of tables, retrying up to 
    max_retries on each download. If recreate is set to True, then the
    tables will be dropped and recreated.

    This function buffers up errors. If one table fails to download after
    max_retries attempts, all the other tables are still attempted, and the
    error is logged (and an exception is thrown) only at the end.

    Parameters:

    tables                 - list of TableConfig objects for the tables to download and update
    config                 - the current configuration
    logger                 - Logger object to use for output
    sql                    - function to issue SQL statements (e.g. from make_sql())
    partition_by_timestamp - whether to partition by a timestamp (True) or a date (False)
    max_retries            - number of times to retry a download
    recreate               - whether to drop and recreate each table
    target_database        - if specified, indicates the target database (schema) for the
                             tables. If not specified, then config.bronze_database is
                             used.
    """
    import traceback

    if target_database is None:
        target_database = config.bronze_database

    def attempt_download(table_data: TableConfig) -> None:
        load_bronze_data(
            table_data=table_data,
            target_database=target_database,
            logger=logger,
            config=config,
            recreate=recreate,
            sql=sql,
            partition_by_timestamp=partition_by_timestamp
        )
        flush_logger(logger)

    errors = []
    for i, table_data in enumerate(tables):
        n = i + 1
        logger.info(f"{n:,} of {len(tables):,} tables: "
                    f"{config.uc_catalog}.{target_database}.{table_data.netsuite_table_name.lower()}")
        try:
            run_with_retries(
                max_retries,
                f"Downloading NetSuite table {table_data.netsuite_table_name}",
                logger,
                attempt_download,
                table_data
            )
        except Exception as e:
            # All retries failed. Capture this error, but keep going.
            # Note that run_with_retries() already logged the error
            # inline, but we'll capture it and log all of the errors
            # again at the bottom.
            errors.append(e)

        print('-' * 50)

    if len(errors) > 0:
        logger.error(f"{len(errors):,} error(s) occurred during downloads. Errors follow:")
        for e in errors:
            logger.error("-" * 30)
            logger.error(str(e))
            logger.error("".join(traceback.format_exception(e)))        
            logger.error(f"{len(errors):,} error(s) occurred during downloads. Errors follow:")

        raise Exception(f"ERRORS IN NetSuite DOWNLOAD")

# COMMAND ----------

def dedup_revenue_plans(df: DataFrame) -> DataFrame:
    """
    Used as a filter for the REVENUE_PLANS table, to de-dup rows.
    """
    return (df.select('*').distinct())

def customers_nullify_sensitive_columns(df: DataFrame) -> DataFrame:
    """
    SIRT-871: Used as filter for the CUSTOMERS table,
    to null out sensitive columns from the table (e.g.,
    SUPPLIER_PORTAL_PASSWORD).
    """
    return df.withColumn("SUPPLIER_PORTAL_PASSWORD", F.lit(None).cast("string"))

def entity_nullify_sensitive_columns(df: DataFrame) -> DataFrame:
    """
    SIRT-871: Used as filter for the ENTITY table,
    to null out sensitive columns from the table (e.g.,
    SUPPLIER_PORTAL_PASSWORD).
    """
    return df.withColumn("SUPPLIER_PORTAL_PASSWORD", F.lit(None).cast("string"))

# COMMAND ----------

# Configured list of tables to download from NetSuite

# Main tables are the tables necessary for the silver portion of 
# the usage gold pipeline (Job 2).
MAIN_TABLES = (
    # NOTE: CLASSES, CURRENCIES, CUSTOMERS, CUSTOMER_TYPES, and ZAB_SUBSCRIPTION, and 
    # ZAB_SUBSCRIPTION_ITEM are needed by the bronze-silver-gold pipeline (which downloads
    # this list of tables), but those tables now downloaded more frequently. See
    # NETSUITE_FREQUENT_REFRESH below.
    #
    # NOTE #2: The gold pipeline is deprecated now, but we're still using these tables to
    # create the silver layer (for now).
    TableConfig(netsuite_table_name='DBU_ACTIVITY_TYPE', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='PAYMENT_TERMS', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='WORKSPACE', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='WORKSPACE_CLOUD', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='WORKSPACE_SUBSCRIPTION', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_BILLING_PROFILE', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_CHARGE_SCHEDULE', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PLAN', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_REVENUE_ORDER', last_modified_column='LAST_MODIFIED_DATE'),
)

# This table is handled specially. See load_system_notes().
SYSTEM_NOTES_TABLE = TableConfig(netsuite_table_name='SYSTEM_NOTES',
                                 last_modified_column='DATE_CREATED')

# These are miscellaneous tables not used by any pipeline
# we maintain, but which may be used by other people. They
# used to be downloaded by job 02's bronze download. However, 
# they are now downloaded by a separate job. Job 02 only downloads
# the bronze tables it needs. These tables are downloaded
# by Bronze-Misc-Tables
MISC_TABLES = (
    # NOTE: ACCOUNTING_PERIODS, ACCOUNTS, DEPARTMENTS, and SUBSIDIARIES are needed more frequently.
    # TableConfig(netsuite_table_name='ACCOUNTING_PERIODS', last_modified_column='DATE_LAST_MODIFIED',
    #             override_primary_keys=['ACCOUNTING_PERIOD_ID', 'FISCAL_CALENDAR_ID']),
    # TableConfig(netsuite_table_name='ACCOUNTS', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='AGREEMENT_TYPE_LIST', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='BILLING_SCHEDULE', last_modified_column=None),
    TableConfig(netsuite_table_name='BILLING_SCHEDULE_DESCRIPTIONS', last_modified_column=None),
    TableConfig(netsuite_table_name='PRODUCT_FAMILY_LIST', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='BILLING_RATE_CARDS', rename_to='BILLING_RATE_CARDS_deprecated', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='CASH_FLOW_TYPE_LIST', rename_to='CASH_FLOW_TYPE_LIST_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='CLOUD_PLATFORM_LIST', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='CONTACTS', rename_to='CONTACTS_deprecated', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='COUNTRIES', last_modified_column=None),
    TableConfig(netsuite_table_name='CREDIT_MEMO_REASON_LIST', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='CURRENCY_EXCHANGE_RATES', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='DEAL_TYPE', rename_to='DEAL_TYPE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='DELIVERY_TERMS', rename_to='DELIVERY_TERMS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    # TableConfig(netsuite_table_name='DEPARTMENTS', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='DUE_DATE_ADJUSTMENT', rename_to='DUE_DATE_ADJUSTMENT_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ENTITLEMENT_TIER_LIST', rename_to='ENTITLEMENT_TIER_LIST_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ENTITLEMENT_TIERS', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='EVENT_CODES', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='FEATURE_TIERS', rename_to='FEATURE_TIERS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ITEMS', last_modified_column='MODIFIED'),
    TableConfig(netsuite_table_name='LOCATIONS', rename_to='LOCATIONS_deprecated', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='MULTIYEAR_YEAR', rename_to='MULTIYEAR_YEAR_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='NATURE_OF_TRANSACTION', rename_to='NATURE_OF_TRANSACTION_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='NATURE_OF_TRANSACTION_CODE', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='PAYMENT_DUE_DATE', rename_to='PAYMENT_DUE_DATE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='PAYMENT_DUE_MONTH', rename_to='PAYMENT_DUE_MONTH_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='PAYMENT_STATUS_LIST', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='PAYMENT_TERM', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='PAYMENT_TRANSACTIONS_MAP', rename_to='PAYMENT_TRANSACTIONS_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='PLAN_ITEM_ASSOCIATION_MAP', rename_to='PLAN_ITEM_ASSOCIATION_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='PLANSCHEDULEMAP', rename_to='PLANSCHEDULEMAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='REVENUE_PLANS', rename_to='REVENUE_PLANS_deprecated', last_modified_column='DATE_LAST_MODIFIED', adjust_dataframe=dedup_revenue_plans),
    TableConfig(netsuite_table_name='REVENUE_RECOGNITION_RULES', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='SUBSCRIPTION_PLANS', rename_to='SUBSCRIPTION_PLANS_deprecated', last_modified_column='DATE_LAST_MODIFIED'),
    # TableConfig(netsuite_table_name='SUBSIDIARIES', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='TERRITORY', rename_to='TERRITORY_deprecated', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='UOM_LIST', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='WORKSPACE_ENTRY', rename_to='WORKSPACE_ENTRY_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_ACTIVITY_TYPE', rename_to='ZAB_ACTIVITY_TYPE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_ADJUSTMENT_TO_BE_PROCESSE', rename_to='ZAB_ADJUSTMENT_TO_BE_PROCESSE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
  #  TableConfig(netsuite_table_name='ZAB_API_EXPORT', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_APPROVAL_STATUS', rename_to='ZAB_APPROVAL_STATUS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_AUTOMATION', rename_to='ZAB_AUTOMATION_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_BILLING_CONSOLIDATION_GRO', rename_to='ZAB_BILLING_CONSOLIDATION_GRO_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_BILLING_CONSOLIDATION_GROUP_LIMIT_TO_CUSTOMERS_MAP', rename_to='ZAB_BILLING_CONSOLIDATION_GROUP_LIMIT_TO_CUSTOMERS_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_BILLING_PROFILE_COMBINE_A', rename_to='ZAB_BILLING_PROFILE_COMBINE_A_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_CHARGE', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_CHARGE_CONTAINER', rename_to='ZAB_CHARGE_CONTAINER_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_CHARGE_SCHEDULE_DATES', rename_to='ZAB_CHARGE_SCHEDULE_DATES_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_CHARGE_SCHEDULE_INHERIT', rename_to='ZAB_CHARGE_SCHEDULE_INHERIT_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_CHARGE_STAGE', rename_to='ZAB_CHARGE_STAGE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_CHARGE_STATUS', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_CHARGE_TYPE', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_CONTRACT_PRICING', rename_to='ZAB_CONTRACT_PRICING_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_EVENT_TYPES', rename_to='ZAB_EVENT_TYPES_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_IGNORED_CHARGES', rename_to='ZAB_IGNORED_CHARGES_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_INTERVAL', rename_to='ZAB_INTERVAL_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_ITEM_CATEGORY', rename_to='ZAB_ITEM_CATEGORY_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_LINE_ITEM_SHIPPING_OPTION', rename_to='ZAB_LINE_ITEM_SHIPPING_OPTION_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_MASTER_CONTRACT', rename_to='ZAB_MASTER_CONTRACT_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_MINIMUM_COMMITMENT', rename_to='ZAB_MINIMUM_COMMITMENT_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_MONTHS', rename_to='ZAB_MONTHS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_ORDER_APPROVAL', rename_to='ZAB_ORDER_APPROVAL_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PLAN_API_GROUP', rename_to='ZAB_PLAN_API_GROUP_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PLAN_INITIAL_BILL_OPTIONS', rename_to='ZAB_PLAN_INITIAL_BILL_OPTIONS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PLAN_ITEM', rename_to='ZAB_PLAN_ITEM_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PLAN_ITEM_FIELD_MAP', rename_to='ZAB_PLAN_ITEM_FIELD_MAP_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PLAN_ITEM_FIELD_TEMPLATE', rename_to='ZAB_PLAN_ITEM_FIELD_TEMPLATE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PLAN_ITEM_FIELD_TEMPLATE_PLAN_ITEM_FIELD_MAP_MAP', rename_to='ZAB_PLAN_ITEM_FIELD_TEMPLATE_PLAN_ITEM_FIELD_MAP_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_PLAN_PLAN_ITEMS_MAP', rename_to='ZAB_PLAN_PLAN_ITEMS_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_PREFERENCES', rename_to= 'ZAB_PREFERENCES_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PREFERENCES_DEFAULTS', rename_to='ZAB_PREFERENCES_DEFAULTS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PREFERENCES_REVENUE_ELEMENT_FIELDS_TO_SYNC_WITH_REVENUE_DETAIL_MAP', rename_to='ZAB_PREFERENCES_REVENUE_ELEMENT_FIELDS_TO_SYNC_WITH_REVENUE_DETAIL_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_PREFERENCES_ZAB_ADMINISTRATOR_MAP', rename_to='ZAB_PREFERENCES_ZAB_ADMINISTRATOR_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_PRICE_BOOK', rename_to='ZAB_PRICE_BOOK_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PROCESS', rename_to='ZAB_PROCESS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PROCESS_CONTEXT', rename_to='ZAB_PROCESS_CONTEXT_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PROCESS_FILTERS', rename_to='ZAB_PROCESS_FILTERS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PROCESS_STATUS', rename_to='ZAB_PROCESS_STATUS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PROCESS_TYPE', rename_to='ZAB_PROCESS_TYPE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PRORATION_QUANTITY_TYPES', rename_to='ZAB_PRORATION_QUANTITY_TYPES_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_PRORATION_RATE_TYPES', rename_to='ZAB_PRORATION_RATE_TYPES_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RATE_PLAN', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RATE_PLAN_SEARCH_MAP', rename_to='ZAB_RATE_PLAN_SEARCH_MAP_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RATE_PLAN_SEARCH_MAP_AVAILABLE_FOR_SEARCH_TYPE_MAP', rename_to='ZAB_RATE_PLAN_SEARCH_MAP_AVAILABLE_FOR_SEARCH_TYPE_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_RATE_POLICY', rename_to='ZAB_RATE_POLICY_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RATE_POLICY_ACTION', rename_to='ZAB_RATE_POLICY_ACTION_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RATE_POLICY_RATE_POLICY_RULES_TO_APPLY_MAP', rename_to='ZAB_RATE_POLICY_RATE_POLICY_RULES_TO_APPLY_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_RATE_POLICY_RULE', rename_to='ZAB_RATE_POLICY_RULE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RATE_POLICY_SEARCH_MAP', rename_to='ZAB_RATE_POLICY_SEARCH_MAP_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RATEVALUE_ADJUSTMENT_MAP', rename_to='ZAB_RATEVALUE_ADJUSTMENT_MAP_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RATEVALUE_ADJUSTMENTS', rename_to='ZAB_RATEVALUE_ADJUSTMENTS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RECORD_TYPES', rename_to='ZAB_RECORD_TYPES_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RECORD_TYPES_AVAILABLE_TO_MAP', rename_to='ZAB_RECORD_TYPES_AVAILABLE_TO_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_RENEWAL', rename_to='ZAB_RENEWAL_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RENEWAL_ACTION', rename_to='ZAB_RENEWAL_ACTION_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RENEWAL_ESTIMATE', rename_to='ZAB_RENEWAL_ESTIMATE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RENEWAL_ESTIMATE_ITEM', rename_to='ZAB_RENEWAL_ESTIMATE_ITEM_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RENEWAL_FIELD_MAP', rename_to='ZAB_RENEWAL_FIELD_MAP_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RENEWAL_FIELD_VALUE_TRANS', rename_to='ZAB_RENEWAL_FIELD_VALUE_TRANS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RENEWAL_FIELD_VALUE_TRANS_1', rename_to='ZAB_RENEWAL_FIELD_VALUE_TRANS_1_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RENEWAL_ITEM', rename_to='ZAB_RENEWAL_ITEM_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_RENEWAL_TEMPLATE', rename_to='ZAB_RENEWAL_TEMPLATE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_REVENUE_CONFIGURATION', rename_to='ZAB_REVENUE_CONFIGURATION_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_REVENUE_DETAIL', rename_to='ZAB_REVENUE_DETAIL_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_SUBSCRIPTION_CONTACTS_MAP', rename_to='ZAB_SUBSCRIPTION_CONTACTS_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_REVENUE_ORDER_SOURCE', rename_to='ZAB_REVENUE_ORDER_SOURCE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_REVENUE_RECOGN_EVENT_TYPE', rename_to='ZAB_REVENUE_RECOGN_EVENT_TYPE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_REVENUE_TRANSACTION_LINK', rename_to='ZAB_REVENUE_TRANSACTION_LINK_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_REVENUE_TYPE', rename_to='ZAB_REVENUE_TYPE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_REVENUE_TYPE_OPTIONS', rename_to='ZAB_REVENUE_TYPE_OPTIONS_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_SUBSCRIPTION_ITEM_PREPAID_ELIGIBLE_SUBSCRIPTION_ITEMS_MAP', rename_to= 'ZAB_SUBSCRIPTION_ITEM_PREPAID_ELIGIBLE_SUBSCRIPTION_ITEMS_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_SUBSCRIPTION_PROCESSING', rename_to='ZAB_SUBSCRIPTION_PROCESSING_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_SUBSCRIPTION_STATUS', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_SUMMARY_TYPE', rename_to='ZAB_SUMMARY_TYPE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_SUMMARY_TYPE_VALID_FIELD_TYPES_MAP', rename_to='ZAB_SUMMARY_TYPE_VALID_FIELD_TYPES_MAP_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='ZAB_TRANSACTION_CHARGE_MAP', rename_to='ZAB_TRANSACTION_CHARGE_MAP_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_TRANSACTION_TYPE', rename_to='ZAB_TRANSACTION_TYPE_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_UNITS_EXPIRATION', rename_to='ZAB_UNITS_EXPIRATION_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_USAGE_DATA', rename_to='ZAB_USAGE_DATA_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
)

# Tables that are downloaded very frequently. These tables are used for Metronome,
# for SFDC/Netsuite recon dashboards and queries, and other things.
# See the Bronze-Frequent-Refresh and Bronze-Frequent-Refresh-2 notebooks.
# Note that we have split the hourly refresh into two concurrent tasks, to
# try to keep the download under one hour. NETSUITE_FREQUENT_REFRESH is used
# by the Bronze-Frequent-Refresh notebook. NETSUITE_FREQUENT_REFRESH_2 is used
# by the Bronze-Frequent-Refresh-2 notebook. The split into two isn't done
# half-and-half. Some tables are larger than others.
#
# At the time this change was made (2024-09-27), the table counts were:
#     ADDRESS_BOOK: 43,932
#     CLASSES: 32
#     CURRENCIES: 33
#     CUSTOMER_TYPES: 14
#     CUSTOMERS: 27,667
#     ENTITY: 49,819
#     MARKETPLACE_FEES: 4,329
#     ORDER_TYPE_LIST: 14
#     TRANSACTIONS: 1,069,701
#     TRANSACTION_LINES: 5,926,553
#     VENDORS: 6,156
#     ZAB_RATE_TYPE: 9
#     ZAB_SUBSCRIPTION: 32,779
#     ZAB_SUBSCRIPTION_ITEM: 5,381,188
#
# The tables are split so that one set of very large tables (the transaction-related ones)
# are in one list and processed by one concurrent task, and the other large tables 
# (ZAB_SUBSCRIPTION-related) are in the other. The one list only contains the transaction
# tables because, combined, they are the largest set.
#
# Update (2024-12-10): These tables are now downloaded into a separate schema and are
# partitioned by a processTimestamp column, rather than a processDate column. They are also
# downloaded separately into the main bronze schema less often, as part of the transactions
# tables job.
NETSUITE_FREQUENT_REFRESH = (
    TableConfig(netsuite_table_name='ACCOUNTING_PERIODS', last_modified_column='DATE_LAST_MODIFIED',
                override_primary_keys=['ACCOUNTING_PERIOD_ID', 'FISCAL_CALENDAR_ID']),
    TableConfig(netsuite_table_name='ACCOUNTS', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='ADDRESS_BOOK', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='CLASSES', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='CURRENCIES', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='CUSTOMER_TYPES', last_modified_column='DATE_LAST_MODIFIED'),
    # NOTE: The last_modified_column is not reliable in the customers table, so we are disabling 
    # incremental download by setting last_modified_column to None, which forces the full download.
    # The table is relatively small, so we can download it in full.
    TableConfig(netsuite_table_name='CUSTOMERS', # last_modified_column='DATE_LAST_MODIFIED', 
                last_modified_column=None,
                adjust_dataframe=customers_nullify_sensitive_columns),
    TableConfig(netsuite_table_name='DEPARTMENTS', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='ENTITY', last_modified_column='DATE_LAST_MODIFIED',
                adjust_dataframe=entity_nullify_sensitive_columns),
    TableConfig(netsuite_table_name='MARKETPLACE_FEES', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ORDER_TYPE_LIST', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='SUBSIDIARIES', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='VENDORS', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='ZAB_RATE_TYPE', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_SUBSCRIPTION', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='ZAB_SUBSCRIPTION_ITEM', last_modified_column='LAST_MODIFIED_DATE'),
)
NETSUITE_FREQUENT_REFRESH_2 = (
    TableConfig(netsuite_table_name='TRANSACTIONS', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='TRANSACTION_LINES', last_modified_column=['DATE_LAST_MODIFIED', 'DATE_LAST_MODIFIED_GMT']),
    TableConfig(netsuite_table_name='TRANSACTION_LINKS', last_modified_column=None),
)

TRANSACTION_TABLES = (
    # NOTE: Some transaction tables are downloaded in the more frequent refresh, above.
    #
    # NOTE: Incremental download is not currently working with the NetSuite2 protocol
    # connection, so it's currently disabled (by disabling the last_modified_column) for
    # any table that needs to use that protocol.
    #
    # NOTE: Excluding the ns2_transactionline table for now, as no one is using this 
    # netsuite2 table and only this one takes ~1 hour to download.
    # TableConfig(netsuite_table_name='transactionLine', use_netsuite2=True, rename_to="ns2_transactionline",
    #             last_modified_column=None), # last_modified_column="linelastmodifieddate")
    TableConfig(netsuite_table_name='paymentEvent', last_modified_column=None, use_netsuite2=True),
    TableConfig(netsuite_table_name='NextTransactionLineLink', last_modified_column=None, use_netsuite2=True),
    # Note that TRANSACTIONS and TRANSACTION_LINES are now downloaded more frequently. See
    # NETSUITE_FREQUENT_REFRESH, above.
    TableConfig(netsuite_table_name='TRANSACTION_ADDRESS', last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='TRANSACTION_LINE_BOOK_MAP', rename_to='TRANSACTION_LINE_BOOK_MAP_deprecated', last_modified_column='DATE_LAST_MODIFIED'),
    # TableConfig(netsuite_table_name='TRANSACTION_LINKS', last_modified_column=None), # <- temporary last_modified_column='DATE_LAST_MODIFIED'),
    TableConfig(netsuite_table_name='TRANSACTION_REGION',rename_to='TRANSACTION_REGION_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='TRANSACTION_SHIPPING_GROUPS', rename_to='TRANSACTION_SHIPPING_GROUPS_deprecated', last_modified_column=None),
    TableConfig(netsuite_table_name='TRANSACTION_TYPE_LIST', rename_to='TRANSACTION_TYPE_LIST_deprecated', last_modified_column='LAST_MODIFIED_DATE'),
    TableConfig(netsuite_table_name='TRANSACTIONS_MAP', rename_to='TRANSACTIONS_MAP_deprecated', last_modified_column=None),
) + NETSUITE_FREQUENT_REFRESH + NETSUITE_FREQUENT_REFRESH_2

ALL_TABLES = sorted(set(MAIN_TABLES + NETSUITE_FREQUENT_REFRESH + NETSUITE_FREQUENT_REFRESH_2 + TRANSACTION_TABLES + MISC_TABLES + (SYSTEM_NOTES_TABLE,)))

# Create a quick lookup by table name. Key is table name in lower case.
# Abort on conflicts.
TABLE_LOOKUP = dict((t.netsuite_table_name.lower(), t) for t in ALL_TABLES)
assert len(TABLE_LOOKUP) == len(ALL_TABLES)

# COMMAND ----------

def load_system_notes(
    config: Configuration, logger: logging.Logger, sql: Callable[[str], DataFrame], recreate_sandbox: bool = False
) -> None:
    """
    Load the SYSTEM_NOTES table. This is a special case. SYSTEM_NOTES, in
    NetSuite, is an enormous append-only audit log, and it needs to be treated
    a little differently.

    1. It must be downloaded incrementally.
    2. We CANNOT fall back to a full download if the incremental download
       fails, because the full audit log is just too large to download in a 
       reasonable time.
    3. The table has no primary key.
    4. There's no processDate in this table, and there shouldn't be. Maintaining
       full snapshots of the data on a daily basis is prohibitive.
    5. We don't have to process deleted records, because there should not be any.
    """
    table_config = SYSTEM_NOTES_TABLE
    protocol = Protocol.NETSUITE_2 if table_config.use_netsuite2 else Protocol.NETSUITE_1
    netsuite_df = read_netsuite_table_into_df(
            table_name=table_config.netsuite_table_name,
            protocol=protocol,
            config=config,
            logger=logger
        )    
    
    uc_table_name = table_config.netsuite_table_name.lower()
    uc_full_table_name = f"{config.uc_catalog}.{config.bronze_database}.{uc_table_name}"
    
    if config.name.lower().startswith("sandbox"):
        if recreate_sandbox:
            full = True
        else:
            exists = table_exists(
                catalog=config.uc_catalog,
                schema_name=config.bronze_database,
                table_name=uc_table_name,
                spark=spark,
                logger=logger
            )
            logger.debug(f"{uc_full_table_name} exist? {exists}")
            if exists:
                uc_df = sql(f"select max({table_config.last_modified_column}) as max_ts from {uc_full_table_name}")
                row = uc_df.first()
                if row is None:
                    full = True
                else:
                    full = False
            else:
                full = True
    else:
        full = False
    
    if not full:
        uc_df = sql(f"select max({table_config.last_modified_column}) as max_ts from {uc_full_table_name}")
        row = uc_df.first()
        if row is None:
            raise Exception(f"No {table_config.last_modified_column} value(s) in "
                            f"{uc_full_table_name}.")
        max_ts = row.max_ts
        netsuite_df = netsuite_df.filter(F.col(table_config.last_modified_column) > max_ts)
        total_new_records = netsuite_df.count()
        logger.debug(f"Looking for records newer than <{max_ts}> in {table_config.netsuite_table_name}")
        if total_new_records == 0:
            logger.info(f"No records newer than <{max_ts}> in {table_config.netsuite_table_name}")
        else:
            logger.info(f"Appending {total_new_records} record(s) newer than <{max_ts}> to {uc_full_table_name}")
            netsuite_df.write.mode("append").saveAsTable(uc_full_table_name)
    else:
        logger.info(f"Starting Full download of {table_config.netsuite_table_name} in delta table: {uc_full_table_name}")
        temp_view_name = f"{uc_table_name}_temp_view"
        logger.debug(f"Creating temporary view {temp_view_name} from NetSuite table {table_config.netsuite_table_name}")
        table_already_exists = table_exists(
            catalog=config.uc_catalog,
            schema_name=config.bronze_database,
            table_name=uc_table_name,
            spark=spark,
            logger=logger
        )
        if table_already_exists:
            logger.debug(f"{uc_full_table_name} already exists.")
            logger.info(f"Deleting any data for {uc_full_table_name}")
            sql(f"DELETE FROM {uc_full_table_name}")

        staged_df = download_and_stage(
            netsuite_df=netsuite_df,
            table_name=uc_table_name,
            staging_path=get_staging_dir(catalog=config.uc_catalog, target_schema=config.bronze_database),
            logger=logger
        )

        logger.info(f"Writing new data to {uc_table_name}.")
        total_rows = staged_df.count()
        logger.debug(f"Writing {total_rows} rows to {uc_full_table_name}.")
        (
            staged_df
                .write
                .format('delta')
                .mode('overwrite')
                .option('mergeSchema', 'true')
                .saveAsTable(uc_full_table_name)
        )
        logger.info(f"Write to {uc_full_table_name} complete.")

# COMMAND ----------

def load_system_notes_hourly(
    config: Configuration, logger: logging.Logger, sql: Callable[[str], DataFrame]
) -> None:
    """
    Load the SYSTEM_NOTES table. This is a special case. SYSTEM_NOTES, in
    NetSuite, is an enormous append-only audit log, and it needs to be treated
    a little differently.

    1. It must be downloaded incrementally.
    2. We CANNOT fall back to a full download if the incremental download
       fails, because the full audit log is just too large to download in a 
       reasonable time.
    3. The table has no primary key.
    4. There's no processDate in this table, and there shouldn't be. Maintaining
       full snapshots of the data on a daily basis is prohibitive.
    5. We don't have to process deleted records, because there should not be any.
    """
    table_config = SYSTEM_NOTES_TABLE
    protocol = Protocol.NETSUITE_2 if table_config.use_netsuite2 else Protocol.NETSUITE_1
    netsuite_df = read_netsuite_table_into_df(
        table_name=table_config.netsuite_table_name,
        protocol=protocol,
        config=config,
        logger=logger
    )
    uc_table_name = table_config.netsuite_table_name.lower()
    uc_full_table_name = f"{config.uc_catalog}.{config.bronze_hourly_database}.{uc_table_name}"
    uc_df = sql(f"select max({table_config.last_modified_column}) as max_ts from {uc_full_table_name}")
    row = uc_df.first()
    if row is None:
        raise Exception(f"No {table_config.last_modified_column} value(s) in "
                        f"{uc_full_table_name}.")
    max_ts = row.max_ts
    netsuite_df = netsuite_df.filter(F.col(table_config.last_modified_column) > max_ts)
    total_new_records = netsuite_df.count()
    logger.debug(f"Looking for records newer than <{max_ts}> in {table_config.netsuite_table_name}")
    if total_new_records == 0:
        logger.info(f"No records newer than <{max_ts}> in {table_config.netsuite_table_name}")
    else:
        logger.info(f"Appending {total_new_records} record(s) newer than <{max_ts}> to {uc_full_table_name}")
        netsuite_df.write.mode("append").saveAsTable(uc_full_table_name)


# COMMAND ----------

def table_config_for_name(netsuite_table_name: str) -> Optional[TableConfig]:
    """
    Given a NetSuite table name, return the corresponding TableConfig
    object, or None if there isn't one for the table.
    """
    return TABLE_LOOKUP.get(netsuite_table_name.lower())

def load_one_table(netsuite_table_name: str) -> None:
    """
    Convenience function, mostly for testing: Finds the TableData object
    for a named table and attempts to download it.
    """
    tc = table_config_for_name(netsuite_table_name)
    if tc is None:
        raise Exception(
            f'There is no configuration for NetSuite table "{netsuite_table_name}".'
        )

    load_bronze_data(
        table_data=tc,
        target_database=config.bronze_database,
        logger=logger,
        config=config,
        recreate=RECREATE,
        sql=sql
    )

# COMMAND ----------

# The following tables must be downloaded to each sandbox on a regular
# basis. Rather than duplicate the TableConfigs, they're listed here
# by name and looked up below.

SANDBOXES_REQUIRED_TABLE_NAMES = (
    "credit_memo_reason_list",
    "dbu_activity_type",
    "items",
    "NextTransactionLineLink",
    "paymentEvent",
    "product_family_list",
    "revenue_plans",
    # "transactionLine",
    "transaction_address",
    "transaction_line_book_map",
    "transaction_lines",
    "transaction_links",
    "transaction_region",
    "transaction_shipping_groups",
    "transaction_type_list",
    "transactions",
    "transactions_map",
    "zab_revenue_order",
    "zab_revenue_order_source",
    "zab_subscription",
    "zab_subscription_contacts_map",
    "zab_subscription_item",
    "zab_subscription_item_prepaid_eligible_subscription_items_map",
    "zab_subscription_processing",
    "zab_subscription_status",
)

SANDBOXES_REQUIRED_TABLES = tuple(
    table_config_for_name(name) for name in SANDBOXES_REQUIRED_TABLE_NAMES
)

# COMMAND ----------

SOX_SANDBOX_DAILY_TABLE_NAMES = ( 
"accounting_periods",
 "accounts",
 "billing_schedule",
 "billing_schedule_descriptions",
 "cloud_platform_list",
 "credit_memo_reason_list",
 "departments",
 "items",
 "payment_status_list",
 "product_family_list",
 "subsidiaries",
 "zab_charge",
 "zab_charge_status",
 "zab_charge_type",
 "zab_rate_plan",
 "dbu_activity_type",
 "payment_terms"
 )

SOX_SANDBOX_DAILY_TABLES = tuple(
    table_config_for_name(name) for name in SOX_SANDBOX_DAILY_TABLE_NAMES
)

# COMMAND ----------

SOX_SANDBOX_HOURLY_TABLE_NAMES = ( 
 "classes",
 "customer_types",
 "customers",
 "entity",
 "order_type_list",
 "transaction_address",
 "transaction_lines",
 "transaction_links",
 "transactions",
 "zab_rate_type",
 "zab_subscription",
 "zab_subscription_item"
 )

SOX_SANDBOX_HOURLY_TABLES = tuple(
    table_config_for_name(name) for name in SOX_SANDBOX_HOURLY_TABLE_NAMES
)
