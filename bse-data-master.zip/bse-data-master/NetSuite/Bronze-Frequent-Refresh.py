# Databricks notebook source
# MAGIC %md
# MAGIC # NetSuite Hourly Refresh
# MAGIC
# MAGIC This notebook downloads a subset of NetSuite bronze tables
# MAGIC more frequently (currently, hourly).
# MAGIC
# MAGIC See full set of comments in Suite-Analytics-Defs, above the
# MAGIC `NETSUITE_FREQUENT_REFRESH` definition.
# MAGIC
# MAGIC Note that this notebook expects, among its parameters, a parameter
# MAGIC indicating which list of tables to download.

# COMMAND ----------

# MAGIC %run "./Suite-Analytics-Defs"

# COMMAND ----------

import logging

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

dbutils.widgets.dropdown(
    name='table_list',
    label='Which list of tables to refresh',
    choices=('1', '2'),
    defaultValue='1'
)

# COMMAND ----------

config = get_configuration(dbutils.widgets.get("configuration"))

# COMMAND ----------

#log_path = get_log_path(pipeline="Bronze-Frequent-Refresh", catalog=config.uc_catalog, schema=config.bronze_hourly_database)
#logger = configure_logging(dbutils.widgets.get("log_level"), path=log_path)
logger = configure_logging(dbutils.widgets.get("log_level"))
sql = make_sql(spark=spark, logger=logger, log_level=logging.DEBUG)
table_list_index = dbutils.widgets.get("table_list")
assert table_list_index in ('1', '2')

if table_list_index == '1':
    tables = NETSUITE_FREQUENT_REFRESH
else:
    tables = NETSUITE_FREQUENT_REFRESH_2

RECREATE = dbutils.widgets.get("recreate") == "yes"
logger.debug(f"{RECREATE=}")
logger.debug(f"{config=}")

logger.info(f"Will write to tables in {config.bronze_hourly_database}")
table_names = [t.netsuite_table_name for t in tables]
logger.info(f"Downloading the following tables: {', '.join(table_names)}")

# COMMAND ----------

# Special case for SYSTEM_NOTES table. See
# comments associated with load_system_notes_hourly()
# in Suite-Analytics-Defs notebook.
def do_system_notes_download() -> None:
    load_system_notes_hourly(config=config, sql=sql, logger=logger)

if table_list_index == '1':
    run_with_retries(3, f"Downloading NetSuite table {SYSTEM_NOTES_TABLE.netsuite_table_name}", logger, do_system_notes_download)

# COMMAND ----------

load_bronze_with_retries(
    tables=tables,
    config=config,
    logger=logger,
    sql=sql,
    recreate=RECREATE,
    partition_by_timestamp=True,
    target_database=config.bronze_hourly_database,
    max_retries=3
)
