# Databricks notebook source
# MAGIC %md
# MAGIC # NetSuite-Sandboxes-Refresh
# MAGIC
# MAGIC Per Jira ticket [BSEDATA-1705](https://databricks.atlassian.net/browse/BSEDATA-1705),
# MAGIC this notebook refreshes NetSuite bronze data for Sandbox 1, Sandbox 2, and Sandbox 3.
# MAGIC This notebook refreshes the same set of tables (see the `SANDBOXES_REQUIRED_TABLES` constant
# MAGIC in the `Suite-Analytics-Defs` notebook) for all sandboxes. It operates on one sandbox
# MAGIC (specified via parameter `configuration`), so that it can be run in parallel for all
# MAGIC sandboxes.

# COMMAND ----------

# MAGIC %run "./Suite-Analytics-Defs"

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

import logging

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get("log_level"))
config = get_configuration(dbutils.widgets.get("configuration"))
sql = make_sql(spark=spark, logger=logger, log_level=logging.DEBUG)
RECREATE = dbutils.widgets.get("recreate") == "yes"
logger.debug(f"{RECREATE=}")
logger.debug(f"{config=}")

# COMMAND ----------

if not config.name.lower().startswith("sandbox"):
    raise Exception(
        "This job is only intended to be run against a NetSuite "
        'sandbox instance, but the "configuration" parameter specifies '
        f'"{config.name.lower()}."'
    )

# COMMAND ----------

load_bronze_with_retries(
    tables=SANDBOXES_REQUIRED_TABLES,
    config=config,
    logger=logger,
    sql=sql,
    recreate=RECREATE
)
