# Databricks notebook source
# MAGIC %md
# MAGIC This notebook creates or updates the usage_gold.ManualWorkspaceList table
# MAGIC from CSV files in an S3 folder.
# MAGIC
# MAGIC It is not yet in production; it is currently run manually.

# COMMAND ----------

# MAGIC %run "./Suite-Analytics-Defs"

# COMMAND ----------

from datetime import date
from pyspark.sql.functions import *
from pprint import pprint

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get('log_level'))

# COMMAND ----------

config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)

# COMMAND ----------

RECREATE = dbutils.widgets.get("recreate") == "yes"
print(f"{RECREATE=}")

# COMMAND ----------

s3_access_key = dbutils.secrets.get(config.secret_scope, config.usage_s3_access_key_secret)
s3_secret_key = dbutils.secrets.get(config.secret_scope, config.usage_s3_secret_key_secret)
S3_FOLDER = f"s3a://{s3_access_key}:{s3_secret_key}@{config.usage_s3_bucket}/workspaceList/manualList"

# COMMAND ----------

#CSV_PATH = S3_FOLDER
CSV_PATH = 'dbfs:/FileStore/shared_uploads/bmc@databricks.com/ManualWorkspaces___Dec20_data.csv'

# COMMAND ----------

display(dbutils.fs.ls(CSV_PATH))

# COMMAND ----------

# wc -l /path/to/upload.csv
import subprocess
path = '/' + CSV_PATH.replace(":", "")
with subprocess.Popen(['wc', '-l', path], stdout=subprocess.PIPE, stderr=subprocess.PIPE) as p:
  err = p.stderr.read().decode('utf-8').strip()
  out = p.stdout.read().decode('utf-8')
  if len(err) > 0:
    raise Exception(err)
  print(out)

# COMMAND ----------

CSV_SCHEMA = '''
workspaceId STRING,
CompanyName STRING,
manualType STRING
'''

# COMMAND ----------

TARGET_TABLE = f"{config.gold_database}.ManualWorkspaceList"
logger.info(f"Updating: {TARGET_TABLE}")

# COMMAND ----------

today = date.today()
today_str = today.strftime('%Y-%m-%d')

# COMMAND ----------

df = (
  spark
    .read
    .option('header', 'true')
    .csv(CSV_PATH, schema=CSV_SCHEMA)
    .withColumn(METADATA_PROCESS_DATE_COLUMN, lit(today))
    .withColumnRenamed("CompanyName", "companyName")
    .withColumnRenamed("ManualType", "manualType")
)

# COMMAND ----------

df.count()

# COMMAND ----------

df.createOrReplaceTempView("ManualWorkspaceListInput")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW ManualWorkspaceListDups AS
# MAGIC WITH 
# MAGIC   Dups AS (
# MAGIC     SELECT workspaceId, count(workspaceId) AS total
# MAGIC     FROM ManualWorkspaceListInput
# MAGIC     GROUP BY workspaceId
# MAGIC     HAVING count(workspaceId) > 1
# MAGIC   )
# MAGIC SELECT ManualWorkspaceListInput.* FROM ManualWorkspaceListInput, Dups
# MAGIC WHERE ManualWorkspaceListInput.workspaceId = Dups.workspaceId

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ManualWorkspaceListDups order by workspaceId

# COMMAND ----------

totalDuplicates = spark.table('ManualWorkspaceListDups').select(col('workspaceId')).distinct().count()
if totalDuplicates > 0:
  raise Exception(f'Duplicates exist for {totalDuplicates} workspace(s) in input CSV.')

# COMMAND ----------

#df = df.dropDuplicates()

# COMMAND ----------

if RECREATE:
  sql(f'DROP TABLE IF EXISTS {TARGET_TABLE}')
  print(f'Removing {TARGET_PARQUET}...')
  dbutils.fs.rm(TARGET_PARQUET, recurse=True)

# COMMAND ----------

if RECREATE:
  print(f'Creating {TARGET_PARQUET}')
  (df
     .write
     .mode("overwrite")
     .format("delta")
     .partitionBy(METADATA_PROCESS_DATE_COLUMN)
     .save(TARGET_PARQUET)
  )
  sql(f'CREATE TABLE {TARGET_TABLE} USING DELTA LOCATION "{TARGET_PARQUET}"')
else:
  print(f'Updating {TARGET_PARQUET} for processDate {today_str}')
  (df
     .write
     .mode("overwrite")
     .format("delta")
     .option('replaceWhere', f"processDate = '{today_str}'")
     .save(TARGET_PARQUET)
  )

# TODO: Move files to archive

# COMMAND ----------

display(sql(f'select processDate, count(processDate) from {TARGET_TABLE} group by processDate order by processDate desc'))

# COMMAND ----------


