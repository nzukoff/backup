# Databricks notebook source
# MAGIC %md
# MAGIC # Copy Usage Gold Data
# MAGIC
# MAGIC Copies the latest `usage_gold.usage_extract` data — i.e., the most recent `processDate` — to a
# MAGIC secure Azure Blob store, for downstream consumption.

# COMMAND ----------

# MAGIC %run ../Suite-Analytics-Defs

# COMMAND ----------

from pyspark.sql import functions as F
from pprint import pprint

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get('log_level'))
config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)

# COMMAND ----------

sql = make_sql(
    logger=logger,
    spark=spark,
    log_level=logging.INFO
)

# COMMAND ----------

SOURCE_GOLD_TABLE = f"{config.gold_database}.{GOLD_USAGE_EXTRACT_TABLE}"
SECURE_BLOB_WRITE_KEY = dbutils.secrets.get("bse-dev-creds", "bse-bui-gold-schema-write")
EXPORT_FOLDER = "wasbs://bse-bui-gold-schema@dbbusinesssystems1.blob.core.windows.net/bse_tables"
EXPORT_DELTA_FILE = "usage_gold.delta"
EXPORT_LOCATION = f"{EXPORT_FOLDER}/{EXPORT_DELTA_FILE}"

# COMMAND ----------

sql(f"use catalog {config.uc_catalog}")

df = spark.table(SOURCE_GOLD_TABLE)
max_process_date = (
    df
    .select(F.max(F.col("processDate")).alias("maxProcessDate"))
    .collect()[0]
    .maxProcessDate
)
s_max_process_date = max_process_date.strftime('%Y-%m-%d')
logger.debug(f"Using processDate {s_max_process_date} partition in {SOURCE_GOLD_TABLE}")

# COMMAND ----------

# Enable write access to the blob.
spark.conf.set(
    "fs.azure.sas.bse-bui-gold-schema.dbbusinesssystems1.blob.core.windows.net",
    SECURE_BLOB_WRITE_KEY
)

# COMMAND ----------

# Delete the existing data.

# Note that dbutils.fs.rm with recurse=True doesn't work here. It results in an error:
# "This operation is not permitted on a non-empty directory."
#
# So, we do it recursively, ourselves.
def recursively_delete(dir: str) -> None:
    logger.info(f"Recursively deleting directory {dir}")
    entries = dbutils.fs.ls(dir)

    # Split into files and directories
    directories = [e for e in entries if e.name[-1] == '/']
    files = [e for e in entries if e not in directories]
    for d in directories:
        recursively_delete(d.path)
    for f in files:
        logger.debug(f"Deleting file {f.path}")
        dbutils.fs.rm(f.path)

    logger.info(f"Deleting now-empty directory {dir}")
    dbutils.fs.rm(dir)

if dbfs_file_exists(EXPORT_FOLDER, EXPORT_DELTA_FILE, dbutils):
    recursively_delete(EXPORT_LOCATION)

# COMMAND ----------

df_filtered = df.filter(F.col("processDate") == max_process_date)
total_rows = df_filtered.count()

# COMMAND ----------

logger.info(f"Copying data from {SOURCE_GOLD_TABLE}, processDate {s_max_process_date}, to {EXPORT_LOCATION}")
logger.info(f"Total rows to copy: {total_rows:,}")
(    
    df_filtered
    .write
    .option("overwriteSchema", "true")
    .format("delta")
    .mode("overwrite")
    .save(EXPORT_LOCATION)
)

# COMMAND ----------

df_target = spark.read.format("delta").load(EXPORT_LOCATION)
target_count = df_target.count()

# COMMAND ----------

if target_count != total_rows:
    raise Exception(
        f"Source data has {total_rows:,} rows, but exported Delta file has {target_count:,} rows."
    )
