# Databricks notebook source
# MAGIC %run "./Update-Bronze-Data"

# COMMAND ----------

# MAGIC %run "./Update-Silver-Data"

# COMMAND ----------

# MAGIC %run "./Update-Usage-Gold-from-Silver"

# COMMAND ----------

# MAGIC %run "./Export-Usage-Data-to-S3"

# COMMAND ----------

# MAGIC %run "./Copy-Usage-Gold-Data"
