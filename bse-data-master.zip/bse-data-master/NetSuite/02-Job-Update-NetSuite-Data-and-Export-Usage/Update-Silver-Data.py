# Databricks notebook source
# MAGIC %run "../Suite-Analytics-Defs"

# COMMAND ----------

from typing import Callable, Optional, Set
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit, max as sql_max
from datetime import datetime
from pprint import pprint

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get('log_level'))
sql = make_sql(
    logger=logger,
    spark=spark,
    log_level=logging.INFO
)

# COMMAND ----------

config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)

# COMMAND ----------

# RECREATE:
# - True: Destroy and recreate the database tables
# - False: Retrieve the latest NetSuite data and store it in a partition
#          with the current date (processDate)
RECREATE = dbutils.widgets.get('recreate') == 'yes'
logger.info(f'{RECREATE=}')

# COMMAND ----------

def full_silver_table_name(base_table_name: str) -> str:
    return f"{config.silver_database}.{base_table_name}"

# COMMAND ----------

def get_existing_silver_tables() -> Set[str]:
    """
    Get the names of all tables that currently
    exist in the silver schema. Uses the global
    "config" object.
    """
    return {row.tableName
            for row in spark.sql(f"SHOW TABLES IN {config.silver_database}").collect()}




def create_silver_table(
    silver_table_name: str,
    source_df: DataFrame
) -> None:
    """
    Creates or recreates the specified silver table.
    If the table already exists, it is dropped first.

    Parameters:

    silver_table_name: The name of the table to create, without
                       the schema name (i.e., no ".")
    source_df:         The DataFrame containing the source data
                       to be written to the table
    """
    assert "." not in silver_table_name
    logger.debug(f"(Re)creating {silver_table_name}.")
    final_df, _ = add_silver_metadata(source_df)
    full_table_name = full_silver_table_name(silver_table_name)
    with temporary_view(f"{silver_table_name}_incoming_view", final_df, spark) as temp_view_name:
        sql(f"DROP TABLE IF EXISTS {full_table_name}")
        sql(f"CREATE TABLE {full_table_name} PARTITIONED BY ({METADATA_PROCESS_DATE_COLUMN}) AS "
            f"SELECT * FROM {temp_view_name}")

def update_silver_table(
    silver_table_name: str,
    source_df: DataFrame,
) -> None:
    """
    Create a new copy (with the current process date) of the specified silver table.

    Parameters:

    silver_table_name - the silver table to be updated
    source_df         - the DataFrame representing the source (bronze) data
    """
    full_table_name = full_silver_table_name(silver_table_name)
    logger.debug(f"Updating {full_table_name}")
    silver_table_df = spark.table(full_table_name)
    # No need for an incremental copy. Just delete any rows with the
    # new process date and copy the data over fresh from the bronze
    # tables.
    process_date = get_process_date()
    process_date_str = format_sql_date(process_date)
    source_df, _ = add_silver_metadata(source_df, process_date)
    sql(f"DELETE FROM {full_table_name} WHERE processDate = '{process_date_str}'")
    logger.debug(
        f"Copying fresh data into {full_table_name} for process date {process_date_str}.",
    )
    with temporary_view(f"{silver_table_name}_view", source_df, spark) as temp_view_name:
        sql(f"INSERT INTO {full_table_name} BY NAME SELECT * FROM {temp_view_name}")

# COMMAND ----------

def load_silver_table_from_view(source_view_name: str,
                                silver_table_name: str,
                                force_recreate: bool = False) -> None:
    try:
        df = spark.table(source_view_name)
        full_table_name = full_silver_table_name(silver_table_name)
        if force_recreate or (silver_table_name not in get_existing_silver_tables()):
            create_silver_table(silver_table_name, df)
        else:
            update_silver_table(silver_table_name, df)
    finally:
        spark.catalog.dropTempView(source_view_name) 

# COMMAND ----------

sql(f"USE CATALOG {config.uc_catalog}")
sql(f"USE DATABASE {config.bronze_database}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Subscription
# MAGIC
# MAGIC NOTE: Unlike the tables coming out of `transactions`, the SQL for `subscriptions`
# MAGIC does not need to be parameterized by a target table name. Since it's easier
# MAGIC to read in a `%sql` cell (because of syntax highlighting), we're running it
# MAGIC there and creating a temporary view that the subsequent Python code can use
# MAGIC to create the silver table.

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW silver_subscriptions_view AS
# MAGIC WITH
# MAGIC   BillingProfiles AS (
# MAGIC     SELECT id AS billing_profile_id,
# MAGIC            name AS billing_profile_name
# MAGIC       FROM main.netsuite2_bronze.customrecordzab_billing_profile
# MAGIC      WHERE processDate = (SELECT max(processDate) FROM main.netsuite2_bronze.customrecordzab_billing_profile)
# MAGIC   ),
# MAGIC   ChargeSchedules AS (
# MAGIC     SELECT id AS charge_schedule_id,
# MAGIC            name AS charge_schedule_name
# MAGIC       FROM main.netsuite2_bronze_hourly.customrecordzab_charge_schedules
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.customrecordzab_charge_schedules)
# MAGIC   ),
# MAGIC   Classes AS (
# MAGIC     SELECT id AS class_id,
# MAGIC            fullname AS class_name
# MAGIC       FROM main.netsuite2_bronze_hourly.classification
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.classification)
# MAGIC   ),
# MAGIC   Customers AS (
# MAGIC     SELECT id AS customer_id,
# MAGIC            companyname AS customer_name
# MAGIC       FROM main.netsuite2_bronze_hourly.customer
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.customer)
# MAGIC   ),
# MAGIC   Subscriptions AS (
# MAGIC     SELECT id AS subscription_id,
# MAGIC            custrecordzab_s_billing_profile AS billing_profile_id,
# MAGIC            custrecordzab_s_customer AS customer_id,
# MAGIC            custrecordzab_s_bill_to_customer AS bill_to_customer_id,
# MAGIC            custrecordzab_s_start_date AS start_date,
# MAGIC            custrecordzab_s_end_date AS end_date,
# MAGIC            custrecorddb_cancellationdate AS cancellation_date,
# MAGIC            custrecord_chargify_sub_id AS chargify_subscription,
# MAGIC            externalid AS subscription_external_id,
# MAGIC            name AS subscription_name,
# MAGIC            custrecordzab_s_currency AS currency_id,
# MAGIC            custrecordzab_s_plan AS plan_id,
# MAGIC            custrecordzab_s_revenue_order AS revenue_order_id,
# MAGIC            custrecordzab_s_charge_schedule AS charge_schedule_id,
# MAGIC            custrecordzab_s_class AS class_id,
# MAGIC            CASE
# MAGIC              WHEN custrecord_autorenewal_contract = 'F' THEN false
# MAGIC              WHEN custrecord_autorenewal_contract = 'T' THEN true
# MAGIC              WHEN custrecord_autorenewal_contract IS NULL THEN true
# MAGIC            END AS auto_renewal,
# MAGIC            CASE
# MAGIC              WHEN isinactive = 'F' THEN true
# MAGIC              WHEN isinactive = 'T' THEN false
# MAGIC              WHEN isinactive IS NULL THEN true
# MAGIC            END AS is_active
# MAGIC       FROM main.netsuite2_bronze_hourly.customrecordzab_subscription
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.customrecordzab_subscription)
# MAGIC   ),
# MAGIC   Currencies AS (
# MAGIC     SELECT id AS currency_id,
# MAGIC            name AS currency_name, 
# MAGIC            symbol AS currency_symbol
# MAGIC       FROM main.netsuite2_bronze_hourly.currency
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.currency)
# MAGIC   ),
# MAGIC   Plans AS (
# MAGIC     SELECT altname AS plan_name,
# MAGIC            id AS plan_id,
# MAGIC            CASE 
# MAGIC              WHEN isinactive = 'F' THEN true
# MAGIC              WHEN isinactive = 'T' THEN false
# MAGIC              WHEN isinactive IS NULL THEN true
# MAGIC            END AS is_active
# MAGIC       FROM main.netsuite2_bronze_hourly.customrecordzab_plan
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.customrecordzab_plan)
# MAGIC   ),
# MAGIC   RevenueOrders AS (
# MAGIC     SELECT id AS revenue_order_id,
# MAGIC            name AS revenue_order_number,
# MAGIC            CASE 
# MAGIC              WHEN isinactive = 'F' THEN true
# MAGIC              WHEN isinactive = 'T' THEN false
# MAGIC              WHEN isinactive IS NULL THEN true
# MAGIC            END AS is_active
# MAGIC       FROM main.netsuite2_bronze.customrecordzab_revenue
# MAGIC      WHERE processDate = (SELECT max(processDate) FROM main.netsuite2_bronze.customrecordzab_revenue)
# MAGIC   )
# MAGIC SELECT 
# MAGIC        cast(Subscriptions.subscription_id as double) as subscription_id,
# MAGIC        Subscriptions.auto_renewal,
# MAGIC        cast(Subscriptions.billing_profile_id as double) as billing_profile_id,
# MAGIC        BillingProfiles.billing_profile_name,
# MAGIC        cast(Subscriptions.bill_to_customer_id as double) as bill_to_customer_id,
# MAGIC        bill_to_cust.customer_name AS bill_to_customer_name,
# MAGIC        cast(Subscriptions.customer_id as double) as customer_id,
# MAGIC        cust.customer_name,
# MAGIC        Subscriptions.start_date,
# MAGIC        Subscriptions.end_date,
# MAGIC        Subscriptions.cancellation_date,
# MAGIC        Subscriptions.chargify_subscription,
# MAGIC        Subscriptions.subscription_external_id,
# MAGIC        Subscriptions.subscription_name,
# MAGIC        Subscriptions.is_active,
# MAGIC        Currencies.currency_symbol,
# MAGIC        Plans.plan_name,
# MAGIC        cast(Plans.plan_id as double) as plan_id,
# MAGIC        Plans.is_active AS plan_is_active,
# MAGIC        cast(RevenueOrders.revenue_order_id as double) as revenue_order_id,
# MAGIC        RevenueOrders.revenue_order_number,
# MAGIC        RevenueOrders.is_active AS revenue_order_is_active,
# MAGIC        cast(Subscriptions.charge_schedule_id as double) as charge_schedule_id,
# MAGIC        ChargeSchedules.charge_schedule_name,
# MAGIC        cast(Subscriptions.class_id as double) as class_id,
# MAGIC        Classes.class_name
# MAGIC   FROM Subscriptions
# MAGIC JOIN Currencies
# MAGIC ON Subscriptions.currency_id = Currencies.currency_id -- subscriptions.currency_id never seems to be null
# MAGIC LEFT OUTER JOIN BillingProfiles
# MAGIC     ON Subscriptions.billing_profile_id = BillingProfiles.billing_profile_id
# MAGIC LEFT OUTER JOIN Plans
# MAGIC     ON Subscriptions.plan_id = Plans.plan_id
# MAGIC LEFT OUTER JOIN RevenueOrders
# MAGIC     ON Subscriptions.revenue_order_id = RevenueOrders.revenue_order_id
# MAGIC LEFT OUTER JOIN ChargeSchedules
# MAGIC     ON ChargeSchedules.charge_schedule_id = Subscriptions.charge_schedule_id
# MAGIC LEFT OUTER JOIN Classes
# MAGIC     ON Classes.class_id = Subscriptions.class_id
# MAGIC LEFT OUTER JOIN Customers cust
# MAGIC     ON cust.customer_id = Subscriptions.customer_id
# MAGIC LEFT OUTER JOIN Customers bill_to_cust
# MAGIC     ON bill_to_cust.customer_id = Subscriptions.bill_to_customer_id

# COMMAND ----------

load_silver_table_from_view(source_view_name='silver_subscriptions_view',
                             silver_table_name='netsuite_subscriptions',
                            force_recreate=RECREATE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Subscription Items

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW silver_subscription_items_view AS
# MAGIC SELECT
# MAGIC     CAST (id AS double) AS subscription_item_id,
# MAGIC     name AS subscription_item_name,
# MAGIC     externalid AS subscription_item_external_id,
# MAGIC     CAST(custrecordzab_si_subscription AS double) AS subscription_id,
# MAGIC     custrecordzab_si_discount_amount AS additional_discount_amount,
# MAGIC     custrecordzab_si_discount_charge_desc AS additional_discount_description,
# MAGIC     CAST(custrecordzab_si_discount_charge_item AS double) AS additional_discount_item_id,
# MAGIC     custrecordzab_si_discount AS additional_discount_percentage,
# MAGIC     custrecordzab_si_quantity AS quantity,
# MAGIC     custrecordzab_si_rate AS rate,
# MAGIC     CAST(custrecordzab_si_item AS double) AS item_id,
# MAGIC     custrecordzab_si_start_date AS start_date,
# MAGIC     custrecordzab_si_end_date AS end_date,
# MAGIC     CASE
# MAGIC         WHEN isinactive = 'F' THEN true
# MAGIC         WHEN isinactive = 'T' THEN false
# MAGIC         WHEN isinactive IS NULL THEN true
# MAGIC     END AS is_active
# MAGIC FROM main.netsuite2_bronze_hourly.customrecordzab_subscription_item
# MAGIC WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.customrecordzab_subscription_item)

# COMMAND ----------

load_silver_table_from_view(source_view_name='silver_subscription_items_view',
                            silver_table_name='netsuite_subscription_items',
                            force_recreate=RECREATE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Workspace Subscription

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW silver_workspace_subscriptions_view AS
# MAGIC WITH
# MAGIC   Workspaces AS (
# MAGIC     SELECT id AS workspace_id,
# MAGIC            custrecordaws_shard_id AS shard_id,
# MAGIC            custrecorddb_workspacecloud AS cloud_id,
# MAGIC            CASE
# MAGIC              WHEN custrecord3 = 'F' THEN false
# MAGIC              WHEN custrecord3 = 'T' THEN true
# MAGIC              WHEN custrecord3 IS NULL THEN false
# MAGIC            END AS to_delete
# MAGIC       FROM main.netsuite2_bronze.customrecorddb_workspace
# MAGIC      WHERE processDate = (SELECT max(processDate) FROM main.netsuite2_bronze.customrecorddb_workspace)
# MAGIC   ),
# MAGIC   WorkspaceClouds AS (
# MAGIC     SELECT id,
# MAGIC            name,
# MAGIC            CASE 
# MAGIC              WHEN isinactive = 'F' THEN true
# MAGIC              WHEN isinactive = 'T' THEN false
# MAGIC              WHEN isinactive IS NULL THEN true
# MAGIC            END AS is_active
# MAGIC       FROM main.netsuite2_bronze.customlistworkspacecloudlist
# MAGIC      WHERE processDate = (SELECT max(processDate) FROM main.netsuite2_bronze.customlistworkspacecloudlist)
# MAGIC   ),
# MAGIC   WorkspaceSubscriptions AS (
# MAGIC     SELECT id AS workspace_subscription_id,
# MAGIC            externalid AS workspace_subscription_external_id,
# MAGIC            created AS created_date,
# MAGIC            custrecorddb_wsub_subscription AS subscription_id,
# MAGIC            custrecorddb_wsub_workspace AS workspace_id,
# MAGIC            CASE 
# MAGIC              WHEN isinactive = 'F' THEN true
# MAGIC              WHEN isinactive = 'T' THEN false
# MAGIC              WHEN isinactive IS NULL THEN false
# MAGIC            END AS is_active
# MAGIC       FROM main.netsuite2_bronze.customrecorddb_workspacesubscription
# MAGIC      WHERE processDate = (SELECT max(processDate) FROM main.netsuite2_bronze.customrecorddb_workspacesubscription)
# MAGIC   ),
# MAGIC   Subscriptions AS (
# MAGIC     SELECT id AS subscription_id,
# MAGIC            custrecordzab_s_start_date AS start_date,
# MAGIC            custrecordzab_s_end_date AS end_date
# MAGIC       FROM main.netsuite2_bronze_hourly.customrecordzab_subscription
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.customrecordzab_subscription)
# MAGIC   )
# MAGIC SELECT cast(WorkspaceSubscriptions.workspace_subscription_id as double) as workspace_subscription_id,
# MAGIC        WorkspaceSubscriptions.workspace_subscription_external_id,
# MAGIC        WorkspaceSubscriptions.created_date,
# MAGIC        cast(WorkspaceSubscriptions.subscription_id as double) as subscription_id,
# MAGIC        WorkspaceSubscriptions.is_active,
# MAGIC        cast(Workspaces.workspace_id as double) as workspace_id,
# MAGIC        cast(Workspaces.cloud_id as double) as cloud_id,
# MAGIC        WorkspaceClouds.name,
# MAGIC        WorkspaceClouds.is_active AS cloud_is_active,
# MAGIC        Subscriptions.start_date AS subscription_start_date,
# MAGIC        Subscriptions.end_date AS subscription_end_date
# MAGIC   FROM WorkspaceSubscriptions,
# MAGIC        Subscriptions
# MAGIC LEFT OUTER JOIN Workspaces
# MAGIC     ON Workspaces.workspace_id = WorkspaceSubscriptions.workspace_id
# MAGIC LEFT OUTER JOIN WorkspaceClouds
# MAGIC     ON Workspaces.cloud_id = WorkspaceClouds.id
# MAGIC WHERE Subscriptions.subscription_id = WorkspaceSubscriptions.subscription_id

# COMMAND ----------

load_silver_table_from_view(source_view_name='silver_workspace_subscriptions_view',
                            silver_table_name='netsuite_workspace_subscriptions',
                            force_recreate=RECREATE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Workspaces

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW silver_workspaces_view AS
# MAGIC WITH
# MAGIC   Workspaces AS (
# MAGIC     SELECT 
# MAGIC       id as WORKSPACE_ID,
# MAGIC       externalid as WORKSPACE_EXTID,
# MAGIC       name as WORKSPACE_NAME,
# MAGIC       custrecordaws_shard_id as SHARD_ID,
# MAGIC       custrecorddb_workspacecloud as WORKSPACE_CLOUD_ID,
# MAGIC       null as PARENT_ID,
# MAGIC       custrecord3 as TO_DELETE,
# MAGIC       isinactive as IS_INACTIVE,
# MAGIC       custrecordworkspace_subscription as SUBSCRIPTION_ID
# MAGIC       FROM main.netsuite2_bronze.customrecorddb_workspace
# MAGIC      WHERE processDate = (SELECT max(processDate) FROM main.netsuite2_bronze.customrecorddb_workspace)
# MAGIC   ),
# MAGIC   WorkspaceClouds AS (
# MAGIC     SELECT id,
# MAGIC            name,
# MAGIC            CASE 
# MAGIC              WHEN isinactive = 'F' THEN true
# MAGIC              WHEN isinactive = 'T' THEN false
# MAGIC              WHEN isinactive IS NULL THEN true
# MAGIC            END AS is_active
# MAGIC       FROM main.netsuite2_bronze.customlistworkspacecloudlist
# MAGIC      WHERE processDate = (SELECT max(processDate) FROM main.netsuite2_bronze.customlistworkspacecloudlist)
# MAGIC   ),
# MAGIC   Subscriptions AS (
# MAGIC     SELECT id AS SUBSCRIPTION_ID,
# MAGIC            name AS subscription_name
# MAGIC       FROM main.netsuite2_bronze_hourly.customrecordzab_subscription
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.customrecordzab_subscription)
# MAGIC   )
# MAGIC SELECT cast(WORKSPACE_ID as double) AS workspace_id,
# MAGIC        WORKSPACE_EXTID AS workspace_external_id,
# MAGIC        cast(PARENT_ID as double) AS parent_id,
# MAGIC        WORKSPACE_NAME AS name,
# MAGIC        cast(WORKSPACE_CLOUD_ID as double) AS workspace_cloud_id,
# MAGIC        WorkspaceClouds.name AS workspace_cloud_name,
# MAGIC        SHARD_ID AS shard_id,
# MAGIC        cast(Workspaces.SUBSCRIPTION_ID as double) AS subscription_id,
# MAGIC        Subscriptions.subscription_name,
# MAGIC        CASE
# MAGIC          WHEN TO_DELETE = 'F' THEN false
# MAGIC          WHEN TO_DELETE = 'T' THEN true
# MAGIC          WHEN TO_DELETE IS NULL THEN false
# MAGIC        END AS to_delete,
# MAGIC        CASE
# MAGIC          WHEN IS_INACTIVE = 'T' THEN false
# MAGIC          WHEN IS_INACTIVE = 'F' THEN true
# MAGIC          WHEN IS_INACTIVE IS NULL THEN true
# MAGIC        END AS is_active
# MAGIC   FROM Workspaces
# MAGIC LEFT OUTER JOIN WorkspaceClouds
# MAGIC     ON Workspaces.WORKSPACE_CLOUD_ID = WorkspaceClouds.id
# MAGIC LEFT OUTER JOIN Subscriptions
# MAGIC     ON Subscriptions.subscription_id = Workspaces.SUBSCRIPTION_ID

# COMMAND ----------

load_silver_table_from_view(source_view_name='silver_workspaces_view',
                            silver_table_name='netsuite_workspaces',
                            force_recreate=RECREATE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plans

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW silver_plans_view AS
# MAGIC SELECT
# MAGIC     CAST(id AS double) AS plan_id,
# MAGIC     externalid AS plan_external_id,
# MAGIC     altname AS name,
# MAGIC     name AS plan_number,
# MAGIC     custrecordzab_p_start_date AS available_date,
# MAGIC     custrecordzab_p_end_date AS expiration_date,
# MAGIC     CAST(NULL AS double) AS parent_id,    
# MAGIC     created AS created_date,
# MAGIC     CASE
# MAGIC         WHEN custrecord_payg_plan = 'F' THEN false
# MAGIC         WHEN custrecord_payg_plan = 'T' THEN true
# MAGIC         WHEN custrecord_payg_plan IS NULL THEN false
# MAGIC     END AS is_paygo,
# MAGIC     CASE
# MAGIC         WHEN custrecorddb_zp_multiyear = 'F' THEN false
# MAGIC         WHEN custrecorddb_zp_multiyear = 'T' THEN true
# MAGIC         WHEN custrecorddb_zp_multiyear IS NULL THEN NULL
# MAGIC     END AS is_multiyear,
# MAGIC     CASE
# MAGIC         WHEN isinactive = 'F' THEN true
# MAGIC         WHEN isinactive = 'T' THEN false
# MAGIC         WHEN isinactive IS NULL THEN NULL
# MAGIC     END AS is_active
# MAGIC FROM main.netsuite2_bronze_hourly.customrecordzab_plan
# MAGIC WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.customrecordzab_plan)

# COMMAND ----------

load_silver_table_from_view(source_view_name='silver_plans_view',
                            silver_table_name='netsuite_plans',
                            force_recreate=RECREATE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customers

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW silver_customers_view AS
# MAGIC WITH
# MAGIC   Customers AS (
# MAGIC     SELECT *
# MAGIC       FROM main.netsuite2_bronze_hourly.customer
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.customer)
# MAGIC   ),
# MAGIC   CustomerTypes AS (
# MAGIC     SELECT id AS customer_type_id,
# MAGIC            name AS customer_type_name
# MAGIC       FROM main.netsuite2_bronze_hourly.customercategory
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) from main.netsuite2_bronze_hourly.customercategory)
# MAGIC   ),
# MAGIC   ChargeSchedules AS (
# MAGIC     SELECT id AS charge_schedule_id,
# MAGIC            name AS charge_schedule_name
# MAGIC       FROM main.netsuite2_bronze_hourly.customrecordzab_charge_schedules
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) from main.netsuite2_bronze_hourly.customrecordzab_charge_schedules)
# MAGIC   ),
# MAGIC   BillingProfiles AS (
# MAGIC     SELECT id AS billing_profile_id,
# MAGIC            name AS billing_profile_name
# MAGIC       FROM main.netsuite2_bronze.customrecordzab_billing_profile
# MAGIC      WHERE processDate = (SELECT max(processDate) from main.netsuite2_bronze.customrecordzab_billing_profile)
# MAGIC   ),
# MAGIC   WorkspaceClouds AS (
# MAGIC     SELECT id,
# MAGIC            name,
# MAGIC            CASE 
# MAGIC              WHEN isinactive = 'F' THEN true
# MAGIC              WHEN isinactive = 'T' THEN false
# MAGIC              WHEN isinactive IS NULL THEN true
# MAGIC            END AS is_active
# MAGIC       FROM main.netsuite2_bronze.customlistworkspacecloudlist
# MAGIC      WHERE processDate = (SELECT max(processDate) from main.netsuite2_bronze.customlistworkspacecloudlist)
# MAGIC   ),
# MAGIC   Currencies AS (
# MAGIC     SELECT id AS currency_id,
# MAGIC            name AS currency_name, 
# MAGIC            symbol AS currency_symbol
# MAGIC       FROM main.netsuite2_bronze_hourly.currency
# MAGIC      WHERE processTimestamp = (SELECT max(processTimestamp) FROM main.netsuite2_bronze_hourly.currency)
# MAGIC   ),
# MAGIC   PaymentTerms AS (
# MAGIC     SELECT id AS payment_terms_id,
# MAGIC            name AS payment_terms_name
# MAGIC       FROM main.netsuite2_bronze.term
# MAGIC      WHERE processDate = (SELECT max(processDate) FROM main.netsuite2_bronze.term)
# MAGIC   ),
# MAGIC BillingAddress AS (
# MAGIC   select 
# MAGIC     addrtext as BILLADDRESS,
# MAGIC     nkey as ADDRESS_ID,
# MAGIC     city,
# MAGIC     country
# MAGIC     from main.netsuite2_bronze_hourly.transactionbillingaddress 
# MAGIC   where processTimestamp = (select max(processTimestamp) from main.netsuite2_bronze_hourly.transactionbillingaddress)
# MAGIC ),
# MAGIC CustomerBalance AS (
# MAGIC   select 
# MAGIC     entity,
# MAGIC     balance
# MAGIC       from main.netsuite2_bronze_hourly.customersubsidiaryrelationship 
# MAGIC     where processTimestamp = (select max(processTimestamp) from main.netsuite2_bronze_hourly.customersubsidiaryrelationship) 
# MAGIC     and isprimarysub = 'T'
# MAGIC ),
# MAGIC LatestTransactionStatus AS (
# MAGIC     SELECT *
# MAGIC     FROM main.netsuite2_bronze_hourly.transactionstatus
# MAGIC     WHERE processTimestamp = (SELECT MAX(processTimestamp) 
# MAGIC                               FROM main.netsuite2_bronze_hourly.transactionstatus)
# MAGIC ),
# MAGIC LatestTransaction AS (
# MAGIC     SELECT *
# MAGIC     FROM main.netsuite2_bronze_hourly.transaction
# MAGIC     WHERE processTimestamp = (SELECT MAX(processTimestamp) 
# MAGIC                               FROM main.netsuite2_bronze_hourly.transaction)
# MAGIC ),
# MAGIC DaysOverdue AS (
# MAGIC     SELECT 
# MAGIC         t.entity, 
# MAGIC         MAX(CASE 
# MAGIC                 WHEN DATEDIFF(CURRENT_DATE, t.duedate) < 0 THEN 0
# MAGIC                 ELSE DATEDIFF(CURRENT_DATE, t.duedate)
# MAGIC             END) AS overduedate
# MAGIC     FROM LatestTransaction t
# MAGIC     LEFT JOIN LatestTransactionStatus s
# MAGIC         ON t.status = s.id
# MAGIC        AND t.type = s.trantype
# MAGIC     WHERE t.type = 'CustInvc'
# MAGIC       AND s.name NOT IN ('Paid In Full')
# MAGIC     GROUP BY t.entity
# MAGIC )
# MAGIC SELECT cast(Customers.id as double) AS customer_id,
# MAGIC        externalid AS customer_external_id,
# MAGIC        accountnumber AS account_number,
# MAGIC        datecreated AS date_created,
# MAGIC        dateclosed AS date_closed,
# MAGIC        Customers.firstorderdate AS date_first_order,
# MAGIC        Customers.lastorderdate AS date_last_order,
# MAGIC        Customers.firstsaledate AS date_first_sale,
# MAGIC        Customers.lastsaledate AS date_last_sale,
# MAGIC        cast(custentityzab_default_billing_profile as double) AS default_billing_profile_id,
# MAGIC        BillingProfiles.billing_profile_name AS default_billing_profile_name,
# MAGIC        cast(custentityzab_default_charge_schedule as double) AS default_charge_schedule_id,
# MAGIC        ChargeSchedules.charge_schedule_name AS default_charge_schedule_name,
# MAGIC        COMPANYNAME AS name,
# MAGIC        BillingAddress.BILLADDRESS AS billing_address,
# MAGIC        BillingAddress.CITY AS city,
# MAGIC        BillingAddress.COUNTRY AS country,
# MAGIC        firstname AS contact_first_name,
# MAGIC        lastname AS contact_last_name,
# MAGIC        email AS email,
# MAGIC        phone AS phone,
# MAGIC        cast(Customers.category as double) AS customer_type_id,
# MAGIC        CustomerTypes.customer_type_name AS customer_type,
# MAGIC        cast(Customers.currency as double) AS currency_id,
# MAGIC        Currencies.currency_symbol,
# MAGIC        comments AS comments,
# MAGIC        custentity_chargify_id AS chargify_id,
# MAGIC        cast(custentity_cloud_platform as double) AS cloud_platform_id,
# MAGIC        WorkspaceClouds.name AS cloud_platform,
# MAGIC        cast(DaysOverdue.overduedate as double) AS days_overdue,
# MAGIC        CustomerBalance.balance AS overdue_balance,
# MAGIC        cast(Customers.terms as double) AS payment_terms_id,
# MAGIC        PaymentTerms.payment_terms_name,
# MAGIC        CASE 
# MAGIC          WHEN lower(isinactive) = 'f' THEN true
# MAGIC          WHEN lower(isinactive) = 'no' THEN true
# MAGIC          WHEN lower(isinactive) = 't' THEN false
# MAGIC          WHEN lower(isinactive) = 'yes' THEN false
# MAGIC          WHEN isinactive IS NULL THEN true
# MAGIC        END AS is_active
# MAGIC   FROM Customers
# MAGIC LEFT JOIN DaysOverdue
# MAGIC     ON Customers.id = DaysOverdue.entity
# MAGIC LEFT JOIN BillingAddress
# MAGIC     ON Customers.defaultbillingaddress = BillingAddress.ADDRESS_ID
# MAGIC LEFT JOIN CustomerBalance
# MAGIC     ON Customers.id = CustomerBalance.entity
# MAGIC LEFT OUTER JOIN WorkspaceClouds
# MAGIC     ON Customers.custentity_cloud_platform = WorkspaceClouds.id
# MAGIC LEFT OUTER JOIN Currencies
# MAGIC     ON Customers.currency = Currencies.currency_id
# MAGIC LEFT OUTER JOIN CustomerTypes
# MAGIC     ON Customers.category = CustomerTypes.customer_type_id
# MAGIC LEFT OUTER JOIN BillingProfiles
# MAGIC     ON Customers.custentityzab_default_billing_profile = BillingProfiles.billing_profile_id
# MAGIC LEFT OUTER JOIN ChargeSchedules
# MAGIC     ON Customers.custentityzab_default_charge_schedule = ChargeSchedules.charge_schedule_id
# MAGIC LEFT OUTER JOIN PaymentTerms
# MAGIC     ON Customers.terms = PaymentTerms.payment_terms_id

# COMMAND ----------

load_silver_table_from_view(source_view_name='silver_customers_view',
                            silver_table_name='netsuite_customers',
                            force_recreate=RECREATE)

# COMMAND ----------

# MAGIC %md
# MAGIC ## DBU Activity Type

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW silver_dbu_activity_type_view AS
# MAGIC SELECT
# MAGIC     cast(id AS int) AS dbu_activity_type_id,
# MAGIC     externalid AS dbu_activity_type_external_id,
# MAGIC     name AS dbu_activity_type_name,
# MAGIC     CASE
# MAGIC         WHEN isinactive = 'F' THEN true
# MAGIC         WHEN isinactive = 'T' THEN false
# MAGIC         WHEN isinactive IS NULL THEN true
# MAGIC     END AS is_active,
# MAGIC     created AS created_date,
# MAGIC     lastmodified AS last_modified_date
# MAGIC FROM main.netsuite2_bronze_hourly.customrecorddbuactivitytype
# MAGIC WHERE processTimestamp = (
# MAGIC     SELECT max(processTimestamp)
# MAGIC     FROM main.netsuite2_bronze_hourly.customrecorddbuactivitytype
# MAGIC )

# COMMAND ----------

load_silver_table_from_view(source_view_name='silver_dbu_activity_type_view',
                            silver_table_name='netsuite_dbu_activity_types',
                            force_recreate=RECREATE)
