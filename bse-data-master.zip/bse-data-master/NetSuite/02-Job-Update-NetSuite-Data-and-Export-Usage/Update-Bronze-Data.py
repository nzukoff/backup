# Databricks notebook source
# MAGIC %run "../Suite-Analytics-Defs"

# COMMAND ----------

from typing import Callable, Optional
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit
from datetime import datetime
from pprint import pprint

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

import logging

logger = configure_logging(dbutils.widgets.get('log_level'))
config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)
logger.info(f"{config=}")

sql = make_sql(
    logger=logger,
    spark=spark,
    log_level=logging.INFO
)

# COMMAND ----------

# RECREATE:
# - True: Destroy and recreate the database tables
# - False: Retrieve the latest NetSuite data and store it in a partition
#          with the current date (processDate)
RECREATE = dbutils.widgets.get('recreate') == 'yes'
logger.info(f'{RECREATE=}')

# COMMAND ----------

logger.info(f"Downloading tables to {config.uc_catalog}.{config.bronze_database}")
sql(f'USE CATALOG {config.uc_catalog}')

# COMMAND ----------

def load_one_table(netsuite_table_name: str) -> None:
    """
    Convenience function, mostly for testing: Finds the TableData object
    for a named table and attempts to download it.
    """
    lower_name = netsuite_table_name.lower()
    matches = [t for t in ALL_TABLES if t.netsuite_table_name.lower() == lower_name]
    if len(matches) == 0:
        raise Exception(f'No match for table name "{netsuite_table_name}".')
    if len(matches) > 1:
        raise Exception(f'Huh? Multiple matches for "{netsuite_table_name}"!')

    load_bronze_data(
        table_data=matches[0],
        target_database=config.bronze_database,
        logger=logger,
        config=config,
        recreate=RECREATE,
        sql=sql
    )

# COMMAND ----------

load_bronze_with_retries(tables=MAIN_TABLES, config=config, logger=logger, sql=sql, recreate=RECREATE)
