# Databricks notebook source
# MAGIC %run "../Suite-Analytics-Defs"

# COMMAND ----------

from pprint import pprint
from pyspark.sql import functions as F
from datetime import datetime

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

dbutils.widgets.dropdown(
    name='recreate',
    label='Recreate all tables?',
    choices=('yes', 'no'),
    defaultValue='no'
)

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get('log_level'))

# COMMAND ----------

config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)

# COMMAND ----------

RECREATE = dbutils.widgets.get('recreate') == 'yes'
logger.info(f'{RECREATE=}')

# COMMAND ----------

sql = make_sql(
    logger=logger,
    spark=spark,
    log_level=logging.INFO
)

# COMMAND ----------

sql(f'USE CATALOG {config.uc_catalog}')
sql(f'USE {config.silver_database}')

# COMMAND ----------

if RECREATE:
    sql(f'DROP TABLE IF EXISTS {config.gold_database}.{GOLD_USAGE_EXTRACT_TABLE}')

# COMMAND ----------

# DBTITLE 1,AWS
# MAGIC %sql
# MAGIC create or replace temporary view AWSUsageUnfilteredByDate as
# MAGIC with 
# MAGIC   wsSubLatest as (
# MAGIC     select wsub.workspace_id,
# MAGIC            wsub.subscription_id,
# MAGIC            wsub.workspaceName,
# MAGIC            to_date(subscription_start_date,'yyyy-mm-dd') as subscription_start_date,
# MAGIC            to_date(subscription_end_date,'yyyy-mm-dd') as subscription_end_date,
# MAGIC           case 
# MAGIC             when subscription_end_date > current_date() then True
# MAGIC             else False
# MAGIC           end as sub_status 
# MAGIC           from (
# MAGIC             select ws.workspace_id,
# MAGIC                    ws.subscription_id,
# MAGIC                    w.name as workspaceName,
# MAGIC                    subscription_start_date, 
# MAGIC                    subscription_end_date,
# MAGIC                    RANK() OVER (PARTITION BY ws.workspace_id ORDER BY subscription_end_date DESC) AS sub_rank 
# MAGIC             from netsuite_workspace_subscriptions ws
# MAGIC             left join netsuite_workspaces w on w.workspace_id = ws.workspace_id 
# MAGIC                                            and w.processDate = (select max(processDate) from netsuite_workspaces)
# MAGIC             where ws.processDate = (select max(processDate) from netsuite_workspace_subscriptions) 
# MAGIC               and ws.subscription_start_date <= current_date()
# MAGIC           ) wsub
# MAGIC     where sub_rank = 1
# MAGIC     and wsub.workspace_id is not null
# MAGIC   ),
# MAGIC   dbuActivityTypebase as (
# MAGIC     select *,
# MAGIC           row_number() over(partition by dbu_activity_type_name order by created_date) rno
# MAGIC     from netsuite_dbu_activity_types
# MAGIC     where processDate = (select max(processDate) from netsuite_dbu_activity_types)
# MAGIC   ),
# MAGIC   dbuActivityType as (
# MAGIC     select * except(rno, processDate)
# MAGIC     from dbuActivityTypebase
# MAGIC     where rno = 1
# MAGIC   )
# MAGIC select
# MAGIC   cast(s.subscription_id as int) as SubscriptionInternalId,
# MAGIC   agg.workspaceId as WorkspaceName,
# MAGIC   cast(w.workspace_id as int) as WorkspaceInternalId,
# MAGIC   w.workspace_external_id as WorkspaceExternalId,
# MAGIC   agg.quantity as Qty,
# MAGIC   agg.date as UsageDate,
# MAGIC   date(s.start_date) as SubscriptionStartDate,
# MAGIC   date(s.end_date) as SubscriptionEndDate,
# MAGIC   cast(NULL as string) as TrialExpirationDate, -- to be filled in when this info is in the aggregate table
# MAGIC   agg.sku as skuType,
# MAGIC   dbu.dbu_activity_type_id as SkuId,
# MAGIC   agg.isPaying as isPaying,
# MAGIC   p.is_paygo as isPayGo,
# MAGIC   (agg.date between s.start_date and s.end_date) as WithinSubscriptionDates,
# MAGIC   case
# MAGIC     when ml.workspaceId is not null then true
# MAGIC     else false
# MAGIC   end as IsManual, --added for tagging manual workspace usages
# MAGIC   case
# MAGIC     when (p.is_paygo is null or p.is_paygo = false) and (ml.workspaceId is null) and s.subscription_id is not null and w.workspace_id is not null then TRUE
# MAGIC     when p.is_paygo = true and (agg.isPaying) and (agg.date between s.start_date and s.end_date) and (w.workspace_id is not null) and (w.subscription_id is not null) then TRUE
# MAGIC     else FALSE
# MAGIC   end as IncludeInUsageUpload,
# MAGIC   concat(cast(agg.workspaceId as string), '-', cast(dbu.dbu_activity_type_id as string), '-', cast(agg.date as string), '-', cast(agg.isPaying as string)) as ExternalId,
# MAGIC   wl.accountId as ProductAccountId,
# MAGIC   wl.subscriptionId as ProductSubscriptionId,
# MAGIC   bui_s.businessSubscriptionId as businessSubscriptionId,
# MAGIC   bui_a.cloudAccountId cloudAccountId,
# MAGIC   '' offerId,
# MAGIC   bui_s.cloudSubscriptionId cloudSubscriptionId,
# MAGIC   bui_s.subscriptionType platformSubscriptionType,
# MAGIC   bui_s.subscriptionChannel platformSubscriptionChannel,
# MAGIC   'aws' as cloudType,
# MAGIC   'N' as Status,
# MAGIC   cast(null as int) as InternalId,
# MAGIC   cast(null as string) as ErrorMessage,
# MAGIC   current_date() as processDate
# MAGIC from it_bui_silver.bui_metering_agg agg 
# MAGIC left join it_bui_silver.bui_workspaces_latest wl on wl.workspaceId = agg.workspaceId
# MAGIC left join it_bui_silver.bui_subscriptions bui_s on bui_s.accountId = wl.accountId 
# MAGIC                                                and bui_s.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.bui_subscriptions)
# MAGIC left join it_bui_silver.bui_accounts bui_a on bui_a.accountId = bui_s.accountId 
# MAGIC                                           and bui_a.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.bui_accounts)
# MAGIC left join netsuite_workspaces w on w.name = agg.workspaceId 
# MAGIC                                and w.processDate = (select max(processDate) from netsuite_workspaces)
# MAGIC left join wsSubLatest wsLatest on (wsLatest.workspace_Id = w.workspace_id and
# MAGIC                                     agg.date between wsLatest.subscription_start_date and wsLatest.subscription_end_date)
# MAGIC left join netsuite_workspace_subscriptions ws on (
# MAGIC   case
# MAGIC     when wsLatest.subscription_id is not null then (ws.workspace_id = w.workspace_id and
# MAGIC                                                     ws.subscription_id = wsLatest.subscription_id and
# MAGIC                                                     agg.date between wsLatest.subscription_start_date and wsLatest.subscription_end_date -- VALIDATE this
# MAGIC                                                     )
# MAGIC     else (ws.workspace_id = w.workspace_id and agg.date between ws.subscription_start_date and ws.subscription_end_date)
# MAGIC   end 
# MAGIC   and ws.processDate = (select max(processDate) from netsuite_workspace_subscriptions)
# MAGIC )
# MAGIC left join netsuite_subscriptions s on s.subscription_id =
# MAGIC   case
# MAGIC     when ws.subscription_id is not null then ws.subscription_id
# MAGIC     else w.subscription_id
# MAGIC   end
# MAGIC   and s.processDate = (select max(processDate) from netsuite_subscriptions)
# MAGIC left join dbuActivityType dbu on dbu.dbu_activity_type_name = agg.sku 
# MAGIC left join netsuite_plans p on p.plan_id = s.plan_id and p.processDate = (select max(processDate) from netsuite_plans)
# MAGIC -- Note that workspaces for manual billing are excluded from usage upload
# MAGIC left join it_usage_gold.ManualWorkspaceList ml on (ml.workspaceId = agg.workspaceId 
# MAGIC                                               and ml.processDate = (select max(processDate) from it_usage_gold.ManualWorkspaceList))

# COMMAND ----------

# DBTITLE 1,GCP
# MAGIC %sql
# MAGIC create or replace temporary view GCPUsageUnfilteredByDate as
# MAGIC with W_Sub_Latest as (
# MAGIC   select 
# MAGIC     wsub.workspace_id,
# MAGIC     wsub.subscription_id,
# MAGIC     wsub.workspaceName,
# MAGIC     case 
# MAGIC       when subscription_end_date > current_date() then True
# MAGIC       else False
# MAGIC     end as sub_status 
# MAGIC   from (
# MAGIC     select 
# MAGIC       ws.workspace_id,
# MAGIC       ws.subscription_id,
# MAGIC       w.name as workspaceName,
# MAGIC       subscription_end_date,
# MAGIC       rank() over (partition by ws.workspace_id order by subscription_end_date desc) as sub_rank 
# MAGIC     from netsuite_workspace_subscriptions ws
# MAGIC     left join netsuite_workspaces w on w.workspace_id = ws.workspace_id 
# MAGIC                                    and w.processDate = (select max(processDate) from netsuite_workspaces)
# MAGIC     where ws.processDate = (select max(processDate) from netsuite_workspace_subscriptions) 
# MAGIC       and ws.subscription_start_date <= current_date()
# MAGIC   ) wsub
# MAGIC   where sub_rank = 1
# MAGIC   and wsub.workspace_id is not null
# MAGIC ),
# MAGIC dbuActivityTypebase as (
# MAGIC   select *,
# MAGIC         row_number() over(partition by dbu_activity_type_name order by created_date) rno
# MAGIC   from netsuite_dbu_activity_types
# MAGIC   where processDate = (select max(processDate) from netsuite_dbu_activity_types)
# MAGIC ),
# MAGIC dbuActivityType as (
# MAGIC   select * except(rno, processDate)
# MAGIC   from dbuActivityTypebase
# MAGIC   where rno = 1
# MAGIC )
# MAGIC select 
# MAGIC   cast(s.subscription_id as int) as SubscriptionInternalId
# MAGIC   ,agg.workspaceId as WorkspaceName
# MAGIC   ,cast(w.workspace_id as int) as WorkspaceInternalId
# MAGIC   ,w.workspace_external_id as WorkspaceExternalId
# MAGIC   ,agg.quantity as Qty
# MAGIC   ,agg.date UsageDate
# MAGIC   ,date(s.start_date) as SubscriptionStartDate
# MAGIC   ,date(s.end_date) as SubscriptionEndDate
# MAGIC   ,date(timestamp_millis(p_sub.trialExpirationTime)) as TrialExpirationDate
# MAGIC   ,agg.sku skuType
# MAGIC   ,dbu.dbu_activity_type_id as SkuId
# MAGIC   ,agg.isPaying
# MAGIC   ,p.is_paygo as isPayGo
# MAGIC   ,(agg.date between s.start_date and s.end_date) as WithinSubscriptionDates
# MAGIC   ,case
# MAGIC       when ml.workspaceId is not null then true
# MAGIC       else false
# MAGIC     end as IsManual
# MAGIC   ,false as IncludeInUsageUpload
# MAGIC   ,concat(cast(agg.workspaceId as string), '-', cast(dbu.dbu_activity_type_id as string), '-', cast(agg.date as string), '-', cast(agg.isPaying as string)) as ExternalId
# MAGIC   ,wl.accountId ProductAccountId
# MAGIC   ,wl.subscriptionId ProductSubscriptionId
# MAGIC   ,p_sub.businessSubscriptionId businessSubscriptionId
# MAGIC   ,p_acc.cloudAccountId cloudAccountId
# MAGIC   ,p_sub.externalQuoteId offerId
# MAGIC   ,p_sub.cloudSubscriptionId cloudSubscriptionId
# MAGIC   ,p_sub.subscriptionType platformSubscriptionType
# MAGIC   ,p_sub.subscriptionChannel platformSubscriptionChannel
# MAGIC   ,'gcp' cloudType
# MAGIC   ,'S' as Status -- GCP usage data isn't pushed to NetSuite. (S = Skip)
# MAGIC   ,cast(null as int) as InternalId
# MAGIC   ,cast(null as string) as ErrorMessage
# MAGIC   ,current_date() as processDate
# MAGIC from it_bui_silver.gcp_metering_agg agg
# MAGIC left join it_bui_silver.gcp_workspaces_latest wl on wl.workspaceId = agg.workspaceId 
# MAGIC                                                 and wl.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.gcp_workspaces_latest)
# MAGIC left join it_bui_silver.gcp_subscriptions p_sub on p_sub.subscriptionId = wl.subscriptionId 
# MAGIC                                                and p_sub.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.gcp_subscriptions)
# MAGIC left join it_bui_silver.gcp_accounts p_acc on p_acc.accountId = p_sub.accountId 
# MAGIC                                           and p_acc.queryTimestamp = (select max(queryTimestamp) from it_bui_silver.gcp_accounts)
# MAGIC left join W_Sub_Latest WSub on WSub.workspaceName = agg.workspaceId
# MAGIC left join netsuite_workspaces w on w.name = agg.workspaceId 
# MAGIC                                and w.processDate = (select max(processDate) from netsuite_workspaces)
# MAGIC left join netsuite_subscriptions s on s.subscription_id =
# MAGIC   case
# MAGIC     when WSub.subscription_id is not null then WSub.subscription_id
# MAGIC     else w.subscription_id
# MAGIC   end
# MAGIC   and s.processDate = (select max(processDate) from netsuite_subscriptions)
# MAGIC left join dbuActivityType dbu on dbu.dbu_activity_type_name = agg.sku 
# MAGIC left join netsuite_plans p on p.plan_id = s.plan_id 
# MAGIC                           and p.processDate = (select max(processDate) from netsuite_plans)
# MAGIC left join it_usage_gold.ManualWorkspaceList ml on (ml.workspaceId = agg.workspaceId 
# MAGIC                                               and ml.processDate = (select max(processDate) from it_usage_gold.ManualWorkspaceList))

# COMMAND ----------

# DBTITLE 1,AWS + GCP Combined Usage
# MAGIC %sql
# MAGIC create or replace temporary view UnfilteredByDateView as
# MAGIC select * from GCPUsageUnfilteredByDate
# MAGIC union
# MAGIC select * from AWSUsageUnfilteredByDate

# COMMAND ----------

full_view_name = 'GoldUsageTableView'
df = spark.table('UnfilteredByDateView')
if RECREATE:
    df = spark.sql("select * from UnfilteredByDateView where UsageDate > '2020-10-31'")
  #df = spark.sql("select * from UnfilteredByDateView where UsageDate >= '2022-12-01'")
else:
  # Current month only.
    df = spark.sql("select * from UnfilteredByDateView where (UsageDate >= date_sub(last_day(current_date()-2), dayofmonth(last_day(current_date()-2))-1)) and (UsageDate <= (current_date() - 2))")
  #df = spark.sql("select * from UnfilteredByDateView where (UsageDate >= '2022-11-01') and (UsageDate <= current_date())")

df.createOrReplaceTempView('GoldUsageTableView')                 

# COMMAND ----------

no_null_extids_view_name = 'GoldUsageViewNoNullExtIds'
(spark
  .table(full_view_name)
  .filter(F.col('externalId').isNotNull())
  .createOrReplaceTempView(no_null_extids_view_name)
)

# COMMAND ----------

# MAGIC %md If we have duplicate external IDs in the view, abort before trying to copy anything into the gold table.
# MAGIC
# MAGIC What this step used to do:
# MAGIC
# MAGIC ```
# MAGIC duplicates = sql(f'select externalId, count(externalId) as total from {no_null_extids_view_name} group by externalId having count(externalId) > 1').collect()
# MAGIC if len(duplicates) > 0:
# MAGIC     print(f'*** {len(duplicates):,} duplicate external ID(s) in the incoming data. ABORTING.')
# MAGIC     print('-' * 50)
# MAGIC     for row in duplicates:
# MAGIC         print(f'{row.externalId}: {row.total}')
# MAGIC
# MAGIC     raise Exception('Duplicate external ID(s) in input data.')
# MAGIC ```
# MAGIC
# MAGIC Doing the aggregation in the SELECT is a little slower, in this case, because of
# MAGIC shuffling, etc. Just pulling the IDs into driver memory and aggregating them
# MAGIC there shaves off about 25% of the time. (It's still slow, but it isn't _as_ slow.)

# COMMAND ----------

select = f'select externalId from {no_null_extids_view_name}'
ids_and_counts = {}
for eid in [r.externalId for r in sql(select).collect()]:
    ids_and_counts[eid] = ids_and_counts.get(eid, 0) + 1

# COMMAND ----------

duplicates = [(eid, count) for eid, count in ids_and_counts.items() if count > 1]
if len(duplicates) > 0:
    from pyspark.sql import types as T

    print(f'*** {len(duplicates):,} duplicate external ID(s) in the incoming data. ABORTING.')
    print('-' * 50)
    for eid, count in duplicates:
        print(f'{eid}: {count}')

    # Don't raise an exception. The non-duplicate usage data should
    # still get merged into gold. Instead, write the duplicates to
    # a table.
    dups_process_date = datetime.utcnow().date()
    schema = T.StructType([
        T.StructField(name="externalId", dataType=T.StringType()),
        T.StructField(name="count", dataType=T.IntegerType())
    ])
    dups_df = (
        spark
            .createDataFrame(duplicates, schema)
            .withColumn(METADATA_PROCESS_DATE_COLUMN, F.lit(dups_process_date))
    )
    date_str = format_sql_date(dups_process_date)
    dups_table = f"{config.gold_database}.duplicate_external_ids"
    print(f"Saving duplicates to {dups_table}")
    (
        dups_df
            .write
             .format('delta')
             .mode('overwrite')
             .option("replaceWhere", f"{METADATA_PROCESS_DATE_COLUMN} = '{date_str}'")
             .saveAsTable(dups_table)
    )

    # Remove the duplicates from consideration.
    dups_df.createOrReplaceTempView("dup_ext_ids")
    rm_dups_df = sql(f"""
      select * from {no_null_extids_view_name}
      where externalId not in (select externalId from dup_ext_ids)
    """)
    # Replace the no_null_ext_ids_view_name with this filtered data,
    # so that the duplicates aren't present in the data being merged
    # into the gold table (which would cause an error).
    rm_dups_df.createOrReplaceTempView(no_null_extids_view_name)
    

# COMMAND ----------

def create_gold_usage_table(view_name: str, table_name: str) -> None:
    logger.info(f"Creating {table_name} from {view_name}")
    sql(f"DROP TABLE IF EXISTS {table_name}")
    sql(f"CREATE TABLE {table_name} AS SELECT * FROM {view_name}")


def update_gold_usage_table(
    view_name: str,
    table_name: str,
    overwrite_for_today: bool = False
) -> None:
    """
    Update the gold usage table from the specified view, using the following approach:

    - Find the most recent processDate in the table.
    - Clone all the data from that date into a partition with today's date, to preserve
      any updates that were done from CSV files uploaded to S3.
    - Merge in the data from the view.

    Parameters:

    view_name           - the name of the view containing the data to be merged in
    parquet_path        - path to the underlying gold table parquet file
    table_name          - fully qualified name of the gold table
    overwrite_for_today - overwrite any existing partition for the current date.
                          False by default. Should only be True for debugging.
    """
    # First, copy the entire most recent day's data.
    from pyspark.sql.functions import col, max as sql_max, current_date
    from datetime import date

    def get_max_process_date(df: DataFrame) -> date:
        return df.select(sql_max(col("processDate")).alias("date")).collect()[0].date

    today = date.today()
    today_str = format_sql_date(today)

    df = spark.table(table_name)
    max_date = get_max_process_date(df)
    adj_df = (
        df
            .where(col(METADATA_PROCESS_DATE_COLUMN) == max_date)
            .drop(METADATA_PROCESS_DATE_COLUMN)
            .withColumn(METADATA_PROCESS_DATE_COLUMN, current_date())
    )

    print(f"Today = {today}, max table processDate = {max_date}")
    if today == max_date:
        if not overwrite_for_today:
            raise Exception(f"Data for {today_str} already exists in {table_name}")

        sql(f"DELETE FROM {table_name} WHERE {METADATA_PROCESS_DATE_COLUMN} = '{today_str}'")
        adj_df = df.where(col("processDate") < today)
        logger.debug(
            f"Max date in table is {max_date}, which is the same as today's date. Adjusting."
        )
        max_date = get_max_process_date(adj_df)
        logger.debug(f"Max date is now {max_date}")

    # bmc (2023-12-22): Somehow, somewhere, duplicate rows got created in the
    # table and, therefore, were propagate forward. To prevent that from happening,
    # create an intermediate view that does a SELECT DISTINCT *
    adj_df_view = f"{view_name}Adjusted"
    adj_df.createOrReplaceTempView(adj_df_view)
    de_dup_view = f"{view_name}DeDuped"
    sql(f"CREATE OR REPLACE TEMP VIEW {de_dup_view} AS "
        f"SELECT DISTINCT * FROM {adj_df_view}")
    # Write this data out. If this process date exists already, it's been
    # deleted, above.
    logger.info(f"Copying data from {format_sql_date(max_date)} to {today_str}")
    sql(f"INSERT INTO {table_name} BY NAME SELECT * FROM {de_dup_view}")

    # Ensure that any new columns are merged into the schema.
    # See https://docs.databricks.com/delta/update-schema.html#automatic-schema-evolution-for-delta-lake-merge
    spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
    # Finally, merge the data from the view in. SQL is easier here.
    merge = f"""
  MERGE INTO {table_name}
  USING {view_name}
  ON {table_name}.externalId = {view_name}.externalId AND
     {table_name}.processDate = {view_name}.processDate
  WHEN MATCHED AND (NOT ({table_name}.status IN ('P', 'S'))) THEN
    UPDATE SET *
  WHEN NOT MATCHED THEN
    INSERT *
  """
    sql(merge)

# COMMAND ----------

full_table_name = f'{config.gold_database}.{GOLD_USAGE_EXTRACT_TABLE}'
logger.info(f"Preparing to update {config.uc_catalog}.{full_table_name}")

# COMMAND ----------

if not table_exists(config.gold_database, GOLD_USAGE_EXTRACT_TABLE, spark):
  # Initial creation
    create_gold_usage_table(view_name=no_null_extids_view_name,
                            table_name=full_table_name)
else:
  # Update/merge
    update_gold_usage_table(view_name=no_null_extids_view_name,
                            table_name=full_table_name,
                            overwrite_for_today=True)  

# COMMAND ----------

# Create a report of null external IDs in another gold table.
NULL_EXTERNAL_ID_TABLE = 'null_external_ids'
FULL_NULL_EXTERNAL_ID_TABLE = f"{config.gold_database}.{NULL_EXTERNAL_ID_TABLE}"

# COMMAND ----------

if RECREATE:
    sql(f'DROP TABLE IF EXISTS {NULL_EXTERNAL_ID_TABLE}')

# COMMAND ----------

df_view = spark.table(full_view_name)
df_null_external_ids = df_view.where(F.col("externalId").isNull())
sql(f"use catalog {config.uc_catalog}")
if not table_exists(config.gold_database, NULL_EXTERNAL_ID_TABLE, spark):
    logger.info(f"Creating {FULL_NULL_EXTERNAL_ID_TABLE} ...")
    temp_view_name = "null_ext_ids_view"
    with temporary_view(temp_view_name, df_null_external_ids, spark):
        sql(f"CREATE TABLE {FULL_NULL_EXTERNAL_ID_TABLE} "
            f"PARTITIONED BY ({METADATA_PROCESS_DATE_COLUMN}) "
            f"AS SELECT * FROM {temp_view_name}")
else:
    logger.info(f"Updating {FULL_NULL_EXTERNAL_ID_TABLE} ...")
    process_date_row = df_view.select(df_view[METADATA_PROCESS_DATE_COLUMN]).first()
    if process_date_row is None:
        process_date = datetime.utcnow().date()
    else:
        process_date = process_date_row[METADATA_PROCESS_DATE_COLUMN]

    date_str = format_sql_date(process_date)
    sql(f"DELETE FROM {FULL_NULL_EXTERNAL_ID_TABLE} WHERE {METADATA_PROCESS_DATE_COLUMN} = '{date_str}'")
    logger.info(f"Merging data into {FULL_NULL_EXTERNAL_ID_TABLE} for {date_str}")
    with temporary_view("null_ext_ids_view", df_null_external_ids, spark) as temp_view_name:
        sql(f"INSERT INTO {FULL_NULL_EXTERNAL_ID_TABLE} BY NAME SELECT * FROM {temp_view_name}")


# COMMAND ----------

if RECREATE:
    sql(f"UPDATE {config.gold_database}.{GOLD_USAGE_EXTRACT_TABLE} SET Status = 'S' WHERE (Status <> 'P') AND UsageDate < '2021-05-01'")
