# Databricks notebook source
# MAGIC %run "../Suite-Analytics-Defs"

# COMMAND ----------

log_levels, default_log_level = get_log_levels()
dbutils.widgets.dropdown(
    name='log_level',
    label='Logging Level',
    choices=log_levels,
    defaultValue=default_log_level
)

configs, default_config = valid_configurations()
dbutils.widgets.dropdown(
    name='configuration',
    label='Configuration',
    choices=configs,
    defaultValue=default_config
)

# COMMAND ----------

from pprint import pprint

# COMMAND ----------

logger = configure_logging(dbutils.widgets.get('log_level'))
config = get_configuration(dbutils.widgets.get('configuration'))
pprint(config)

# COMMAND ----------

sql = make_sql(
    logger=logger,
    spark=spark,
    log_level=logging.INFO
)

# COMMAND ----------

s3_access_key = dbutils.secrets.get(config.secret_scope, config.usage_s3_access_key_secret)
s3_secret_key = dbutils.secrets.get(config.secret_scope, config.usage_s3_secret_key_secret)

S3_EXPORT_URL = f's3a://{s3_access_key}:{s3_secret_key}@{config.usage_s3_bucket}'
S3_USAGE_EXTRACTION_FOLDER = f'{S3_EXPORT_URL}/{config.usage_extraction_folder}'

logger.info(f'Extracting usage data to {S3_USAGE_EXTRACTION_FOLDER}')

# COMMAND ----------

view_sql = f'''
create or replace temp view UsageExportView as
select ExternalId,
       SubscriptionInternalId,
       WorkspaceName,
       SkuId,
       SkuType,
       UsageDate,
       WorkspaceInternalId,
       Qty
  from {config.gold_database}.{GOLD_USAGE_EXTRACT_TABLE}
 where processDate = (select max(processDate) from {config.gold_database}.{GOLD_USAGE_EXTRACT_TABLE})
   and IncludeInUsageUpload = true
   and (Status <> 'P')
   and (Status <> 'S')
   and (UsageDate >= date_sub(last_day(current_date()-2),dayofmonth(last_day(current_date()-2))-1)) 
   and (UsageDate <= (current_date() - 2))
   --and (UsageDate >= '2022-05-01') and (UsageDate <= '2022-05-31') 
   and (ExternalId IS NOT NULL)
order by UsageDate
'''
sql(f"USE CATALOG {config.uc_catalog}")
sql(view_sql)

# COMMAND ----------

from pyspark.sql import functions as F
from it_data_lib.csvhelpers import export_to_csv

try:
    df = spark.table('UsageExportView')
    exported_file = export_to_csv(
      df=df,
      folder_path=S3_USAGE_EXTRACTION_FOLDER,
      file_prefix='workspaceUsage',
      dbutils=dbutils
    )
    logger.info(f'Exported usage data to {exported_file}')
finally:
    spark.catalog.dropTempView('UsageExportView')

# COMMAND ----------

count = spark.read.option("header", "true").csv(exported_file).count()
logger.info(f'Exported {count:,} rows')
