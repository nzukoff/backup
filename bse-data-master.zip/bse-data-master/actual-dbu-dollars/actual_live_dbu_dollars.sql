-- Databricks notebook source
-- MAGIC %md
-- MAGIC This process creates the table actual_live_dollars which has combined usage_dollars from snap and live tables. Usage dollars from snap are combined with live dollars which have been generated after the snap. 

-- COMMAND ----------

create or replace table main.it_finance_silver.actual_live_dbu_dollars as 
select a.*
 , region 
 , vertical 
 , ifnull(bu, "AMER Enterprise") as bu
 , ifnull(sub_bu , "Other") as sub_bu
 , sfdc_region_l1 
 , sfdc_region_l2 
 , sfdc_region_l3 
 , billing_country 
 , anaplan_billing_country 
 , ae_type 
 , ae_segment 
 , curdate() as process_date

from
(
--live paid usage metering - dbu_dollars excluding year and month usage_dollars which are there in snap
select azure_sub_id 
 , sfdc_account_id 
 , sfdc_account_name 
 , net_usage_amount 
 , platform 
 , sku 
 , fiscal_year 
 , fiscal_qtr 
 , year 
 , month 
 , rev_share_price 
 , usage_dollars as dbu_dollars
 , "live" as dollars_type
 from main.fin_live_gold.paid_usage_metering
where (year, month) not in (select distinct year, month from main.fin_snap.paid_usage_metering_snap)
union all
-- Snap paid usage metering - dbu_dollars
select azure_sub_id 
 , sfdc_account_id 
 , sfdc_account_name 
 , net_usage_amount 
 , platform 
 , sku 
 , fiscal_year 
 , fiscal_qtr 
 , year 
 , month 
 , rev_share_price 
 , usage_dollars as dbu_dollars
 , "snap" as dollars_type
 from main.fin_snap.paid_usage_metering_snap

union all

--live pubsec_usage - dbu_dollars excluding year and month usage_dollars which are there in snap
select null as azure_sub_id 
 , sfdc_account_id 
 , sfdc_account_name 
 , dbu 
 , platform 
 , null as sku 
 , fiscal_year 
 , fiscal_qtr 
 , year 
 , month 
 , dbu_price as rev_share_price
 , dbu_dollars 
 , "live" as dollars_type
from main.fin_live_gold.pubsec_usage
where (year, month) not in (select distinct year, month from main.fin_snap.pubsec_usage_snap)
union all
--pubsec_usage_snap - dbu_dollars
select null as azure_sub_id 
 , sfdc_account_id 
 , sfdc_account_name 
 , dbu 
 , platform 
 , null as sku 
 , fiscal_year 
 , fiscal_qtr 
 , year 
 , month 
 , dbu_price as rev_share_price
 , dbu_dollars 
 , "snap" as dollars_type
from main.fin_snap.pubsec_usage_snap

union all

--live pvc_usage - dbu_dollars excluding year and month usage_dollars which are there in snap
select null as azure_sub_id 
 , sfdc_account_id 
 , sfdc_account_name 
 , dbu 
 , platform 
 , null as sku 
 , fiscal_year 
 , fiscal_qtr 
 , year 
 , month 
 , dbu_price as rev_share_price
 , dbu_dollars 
 , "live" as dollars_type
from main.fin_live_gold.pvc_usage
where (year, month) not in (select distinct year, month from main.fin_snap.pvc_usage_snap)
union all
--pvc_usage_snap - dbu_dollars
select null as azure_sub_id 
 , sfdc_account_id 
 , sfdc_account_name 
 , dbu 
 , platform 
 , null as sku 
 , fiscal_year 
 , fiscal_qtr 
 , year 
 , month 
 , dbu_price as rev_share_price
 , dbu_dollars  
 , "snap" as dollars_type
from main.fin_snap.pvc_usage_snap
) a
left join main.fin_live_gold.sfdc_hierarchy_mapping b
on a.sfdc_account_id = b.sfdc_account_id

-- COMMAND ----------

-- create or replace table integration.it_finance_silver.actual_live_dbu_dollars as 
-- select a.*
--  , region 
--  , vertical 
--  , ifnull(bu, "AMER Enterprise") as bu
--  , ifnull(sub_bu , "Other") as sub_bu
--  , sfdc_region_l1 
--  , sfdc_region_l2 
--  , sfdc_region_l3 
--  , billing_country 
--  , anaplan_billing_country 
--  , ae_type 
--  , ae_segment 
--  , curdate() as process_date

-- from
-- (
-- --live paid usage metering - dbu_dollars excluding year and month usage_dollars which are there in snap
-- select azure_sub_id 
--  , sfdc_account_id 
--  , sfdc_account_name 
--  , net_usage_amount 
--  , platform 
--  , sku 
--  , fiscal_year 
--  , fiscal_qtr 
--  , year 
--  , month 
--  , rev_share_price 
--  , usage_dollars as dbu_dollars
--  , "live" as dollars_type
--  from main.fin_live_gold.paid_usage_metering
-- where (year|| lpad(month,2,0)) > (select max( year|| lpad(month,2,0)) from main.fin_snap.paid_usage_metering_snap)
-- union all
-- -- Snap paid usage metering - dbu_dollars
-- select azure_sub_id 
--  , sfdc_account_id 
--  , sfdc_account_name 
--  , net_usage_amount 
--  , platform 
--  , sku 
--  , fiscal_year 
--  , fiscal_qtr 
--  , year 
--  , month 
--  , rev_share_price 
--  , usage_dollars as dbu_dollars
--  , "snap" as dollars_type
--  from main.fin_snap.paid_usage_metering_snap

-- union all

-- --live pubsec_usage - dbu_dollars excluding year and month usage_dollars which are there in snap
-- select null as azure_sub_id 
--  , sfdc_account_id 
--  , sfdc_account_name 
--  , dbu 
--  , platform 
--  , null as sku 
--  , fiscal_year 
--  , fiscal_qtr 
--  , year 
--  , month 
--  , dbu_price as rev_share_price
--  , dbu_dollars 
--  , "live" as dollars_type
-- from main.fin_live_gold.pubsec_usage
-- where (year|| lpad(month,2,0)) > (select max( year|| lpad(month,2,0)) from main.fin_snap.pubsec_usage_snap)
-- union all
-- --pubsec_usage_snap - dbu_dollars
-- select null as azure_sub_id 
--  , sfdc_account_id 
--  , sfdc_account_name 
--  , dbu 
--  , platform 
--  , null as sku 
--  , fiscal_year 
--  , fiscal_qtr 
--  , year 
--  , month 
--  , dbu_price as rev_share_price
--  , dbu_dollars 
--  , "snap" as dollars_type
-- from main.fin_snap.pubsec_usage_snap

-- union all

-- --live pvc_usage - dbu_dollars excluding year and month usage_dollars which are there in snap
-- select null as azure_sub_id 
--  , sfdc_account_id 
--  , sfdc_account_name 
--  , dbu 
--  , platform 
--  , null as sku 
--  , fiscal_year 
--  , fiscal_qtr 
--  , year 
--  , month 
--  , dbu_price as rev_share_price
--  , dbu_dollars 
--  , "live" as dollars_type
-- from main.fin_live_gold.pvc_usage
-- where (year|| lpad(month,2,0)) > (select max( year|| lpad(month,2,0)) from main.fin_snap.pvc_usage_snap)
-- union all
-- --pvc_usage_snap - dbu_dollars
-- select null as azure_sub_id 
--  , sfdc_account_id 
--  , sfdc_account_name 
--  , dbu 
--  , platform 
--  , null as sku 
--  , fiscal_year 
--  , fiscal_qtr 
--  , year 
--  , month 
--  , dbu_price as rev_share_price
--  , dbu_dollars  
--  , "snap" as dollars_type
-- from main.fin_snap.pvc_usage_snap
-- ) a
-- left join main.fin_live_gold.sfdc_hierarchy_mapping b
-- on a.sfdc_account_id = b.sfdc_account_id
